// HVisionTCP_Cognex.cpp: implementation of the HVisionTCP_Cognex class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HVisionTCP_Cognex.h"
#include "ClientSock_Cognex.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HVisionTCP_Cognex::HVisionTCP_Cognex()
{
	m_pClientSock_Cognex		= NULL;
}

HVisionTCP_Cognex::~HVisionTCP_Cognex()
{
	if( NULL != m_pClientSock_Cognex)
	{
		delete m_pClientSock_Cognex;
		m_pClientSock_Cognex = NULL;
	}
}

BOOL HVisionTCP_Cognex::InitMatroxTCP()
{
	m_pClientSock_Cognex = new CClientSock_Cognex();
	m_pClientSock_Cognex->ReConnectTry();
	return m_pClientSock_Cognex->m_bConnect;
}

BOOL HVisionTCP_Cognex::ConnectStatus()
{
	return m_pClientSock_Cognex->m_bConnect;
}
BOOL HVisionTCP_Cognex::ReConnect()
{
	m_pClientSock_Cognex->ReConnectTry();
	return m_pClientSock_Cognex->m_bConnect;
}
BOOL HVisionTCP_Cognex::OnCamChange(int nCamNo)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnCamChange(nCamNo);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnAcquire(int nCamNo) // refresh vision
{

	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnAcquire(nCamNo);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnContrastAndBrightness( nCamNo,  dContrast,  dBrightness);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL HVisionTCP_Cognex::OnContrast(int nCamNo, double dContrast)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnContrast( nCamNo,  dContrast);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnBrightness(int nCamNo, double dBrightness)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnBrightness( nCamNo,  dBrightness);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::SaveImg(int nCamNo, CString strFilePathName)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->SaveImg( nCamNo, strFilePathName);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnLive(int nCamNo, BOOL bIsLive)
{

	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnLive( nCamNo,  bIsLive);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnApplyVisionParameter(int nID, int nCamNo, VISION_INFO sVisionInfo)
{

	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnApplyVisionParameter( nID,  nCamNo,  sVisionInfo);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::OnApplyVisionParam(int nID,  int nCamNo, SVISIONINFO sVisionInfo)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->OnApplyVisionParam( nID,   nCamNo,  sVisionInfo);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::LoadOptionFile(int nType)
{

	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->LoadOptionFile( nType);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL HVisionTCP_Cognex::ShowArea(int nShow, int nPatternNo, int nCam)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->ShowArea( nShow,  nPatternNo,  nCam);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::SetInspectionArea(int nSize, int nCam)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->SetInspectionArea( nSize,  nCam);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL HVisionTCP_Cognex::SetInspectionAreaPercent(double nPercent, int nCam)
{
	if(!ConnectStatus())
		return FALSE;


	int nReturn = m_pClientSock_Cognex->SetInspectionAreaPercent( nPercent,  nCam);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;

}

BOOL HVisionTCP_Cognex::SetAcceptScore(double dVal)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->SetAcceptScore( dVal);

		if(nReturn == RETURN_FAIL_)
		{
			return FALSE;
		}
		else if(nReturn == TIME_OUT_)
		{
			return FALSE;
		}

		return TRUE;
}

BOOL HVisionTCP_Cognex::GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->GetDispParam(pVisionInfo, nSel, nCamNo);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}
BOOL HVisionTCP_Cognex::ClearInteractiveGraphics(int nCam)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->ClearInteractiveGraphics( nCam);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;

}

BOOL HVisionTCP_Cognex::TransformPixel()
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->TransformPixel();

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL HVisionTCP_Cognex::PMToolFind( int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag )
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->PMToolFind(  iDisplay,  iPatternNo,  bShowResult,  patternFlag );

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;

}

BOOL HVisionTCP_Cognex::InitVisionPixelData(int nCam)
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->InitVisionPixelData(nCam);

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL HVisionTCP_Cognex::InitDistancePerPixel()
{
	if(!ConnectStatus())
		return FALSE;

	int nReturn = m_pClientSock_Cognex->InitDistancePerPixel();

	if(nReturn == RETURN_FAIL_)
	{
		return FALSE;
	}
	else if(nReturn == TIME_OUT_)
	{
		return FALSE;
	}

	return TRUE;
}

