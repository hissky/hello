// HEocard5Pusan1DualbandNew.h: interface for the HEocard5Pusan1DualbandNew class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEOCARD5PUSAN1DUALBANDNEW_H__C6D292CB_1103_4D0C_B8AC_46D61A227A03__INCLUDED_)
#define AFX_HEOCARD5PUSAN1DUALBANDNEW_H__C6D292CB_1103_4D0C_B8AC_46D61A227A03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ETSx_Api.h"
#include "FParameter.h"
#include "..\Model\ToolCodeList.h"
#include "IEODriverDLPortIO.h"
#include "CorrectTime.h"
#include "Calibration.h"
#include "BicubicInterpolation.h"
#include "..\EocardDef.h"
struct DOUBLE_POINT {
	float dX;
	float dY;
};

struct MARKING_DATA
{
	int nAction;
	POINT nPoint;
};

typedef CArray <MARKING_DATA, MARKING_DATA> MARKDATA;

#define ASC_AXIS_SIZE			65
#define ROUND_0_FFFF(signedValue)	( (signedValue)<0 ? 0 : ((signedValue)&0xffff) )

#define MARK_JUMP	0
#define MARK_DRAW	1

#define DSP_ONLY		0
#define DSP_CONST_ONLY	1
#define ALL_DOWN		2
#define EXCEPT_DSP		3

class HEocard5Pusan1DualbandNew  
{
public:
	BOOL SetLPCDataReadReady();
	BOOL DownloadPowerLevel(unsigned int nToolNo, unsigned int nShotIndex, double dMinVal, double dMAxVal);
	void LoadLPCCalibrationFile(CString strPath);
#ifndef __LPC_FOR_3RD_AOD__
	TDrill_LPCMonitor* GetLPCResult();
#else
	TLpc_Buffer* GetLPCResult();
#endif
	CPoint GetDownHoleFirePos(int nIndex);
	void UpdateLPCCalibrationFile(CString strPath);
	BOOL GetScannerError(int *nWarningNo, int *nAlarmNo, int *nMaxValue, int* nInposMissNo);
	BOOL ResetScannerPosErrorCount();
	BOOL SetScannerErrorLevel(double dWarning_mm, double dAlarm_mm);
	BOOL SetFieldSizeToEocard();
	BOOL SetMasterSlave(BOOL bMaster);
	int GetUmData(USHORT usLSB);
	BOOL ChangeScannerAxis();
	BOOL SetVoltage(double d1st, double d2nd);
	BOOL GetApplyCalibrationFile(int nBeam);
	BOOL SetApplyCalibrationFile(int nBeam, BOOL bOn);
	double GetDummyFreeStart();
	BOOL SubCallStart(int nIndex, BOOL bDryrun);
	BOOL SubDownloadStop();
	BOOL SubDownloadReset(int nIndex);
	BOOL SetParameterCavityDuty(BOOL bShortLine);
	BOOL EndMarkDummy();
	BOOL StartMarkDummy();

	int IsStannbyShotRun();
	BOOL DrillStandbyShotStart(BOOL bStart, BOOL bUserStop);
	BOOL DrillStandbyShotStartHole(BOOL bStart);
	BOOL StandbyParamSet();
	BOOL SetInpositionCheckINI(BOOL bUseFile);
	BOOL IsSameHoleData(TDrillHoleData* DrillHoleData, int nCount);
	BOOL DummyParamSet(BOOL bPowervia = FALSE);
	TArrayPos2D m_DummyPos;
	BOOL DummyStopAndDataShotStart(BOOL bDryRun);
	BOOL DummyFieldStart(int nShotNo, BOOL bDryRun);
	BOOL IsFireCntOK(int& nDownCnt, int& nReadCnt);
	BOOL ReDownloadHole();
	BOOL DownloadAOMProfile(int nTool, int nSubTool, CString strPath, 
		double dDuty, double dAOMDelay, double dAOMDuty, double dAOMOffset, 
		double dDutyOffsetM, double dDutyOffsetS, double dVolOffsetM, double dVolOffsetS, int nMask);
	void ReloadDevice();
	BOOL	m_b4Beam;
	int		m_nApertureMode;
	int		m_nBurstShotNo;

	void ResetCO2Laser();
	short m_cCO2Laser;

	BOOL FieldPreStart(int nShotNo);
	BOOL StatusOK(int nStatus);
	BOOL FlyingModeEnable(BOOL bEnable);
	BOOL SetQuantaParam(int nFPK, int nCurrent);
	BOOL markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd);
	BOOL GetStatus(WORD* pStat) const;
	USHORT GetFunction();
	BOOL SetFunction(USHORT Value);
	BOOL DownloadShotDrillScannerParam(int nJumpDelayPlus);
	BOOL DownloadOneAperture(CString str, int nTool);
	BOOL DownloadOneSubTool(int nTool, SUBTOOLDATA subTool,  BOOL bSetPowerLevel = TRUE,  BOOL bMakeLPCTable = FALSE);
	BOOL ResetSubToolForAllTool();
	void MoveToCenter();
	BOOL jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd);
	BOOL LaserOnOff(BOOL bOn);
	void GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY);
	BOOL IsDSPBusy();
	BOOL ResetScannerStatusErrorCount();
	BOOL IsDrillTimeOut();
	BOOL IsDrillTimeOutType();
	BOOL IsMotorFault();
	BOOL IsScannerCableError();
	void MakeInpositionTable();
	void SaveInposTimeTable();
	void mark(int x, int y, int xS, int yS, BOOL bWaitEnd);
	void jump(int x, int y, int xS, int yS, BOOL bWaitEnd);
	BOOL DownloadDutyAOM(unsigned int nToolNo, unsigned int nShotIndex, double dDuty, double dAOMDelay, double dAOMDuty);
	BOOL DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture);
	BOOL DownloadDummyFreeInfo();
	BOOL Create();
	BOOL GetParameter(FParameter *Para);
	BOOL CO2LaserMainShutter(BOOL bOn);
	void CO2LaserEnable(BOOL bEnable);
	BOOL LoadCalibrationFile(char *strM1path, char *strS1path, char *strM2path, char *strS2path);
	void GetASCPos(int &nX, int &nY, int nScannerNo);
	void GetApplyCalPos(int &nX, int &nY, int nScannerNo);
	void DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd);
	void DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
				   int xS = HALF_LSB, int yS = HALF_LSB, BOOL bS1ApplyCal = FALSE,
				   int x_2 = HALF_LSB, int y_2 = HALF_LSB, BOOL bM2ApplyCal = FALSE,
				   int xS_2 = HALF_LSB, int yS_2 = HALF_LSB, BOOL bS2ApplyCal = FALSE, BOOL bWaitEnd = FALSE);
	int ReadHoleCount();
	BOOL FieldStart(BOOL bDryRun);
	void EStop();
	BOOL DownloadTcode(TCODE_INFO *pToolInfo);
	BOOL SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode);
	BOOL ShotDataReset();
	BOOL DownloadShotData2(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode,
		 int nShotFilePosForLPCX,
		 int nShotFilePosForLPCY);
	BOOL DownloadShotDataDummy(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode);
	BOOL DownloadAperture(int nToolNo, int nX, int nY, int nAction);
	BOOL ApertureDataReset(int nToolNo);
	BOOL MoveDrillCenterPos();
	void mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	void jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	BOOL SetMinShotTime(int us);
	BOOL SetSelfLineDivide(BOOL bOn);
	BOOL SetMinCycleTime(int us);
	BOOL SetParameter(FParameter *pParam, double dAOMOffset, int nMask);
	BOOL InitCard();
	HEocard5Pusan1DualbandNew();
	virtual ~HEocard5Pusan1DualbandNew();

	CETSx_API*	m_pDriver;
	FParameter		m_Parameter;

	DOUBLE_POINT* m_pM1Asc;
	DOUBLE_POINT* m_pM2Asc;
	DOUBLE_POINT* m_pS1Asc;
	DOUBLE_POINT* m_pS2Asc;
	
	TDrillToolInfo	m_ToolInfo[32]; // max tool no = 30 (include scal, onehole)
#ifndef __NEW_STRUCTURE__
	TDrillPtnInfo	m_PtnInfo[31];
#else
	TDrillPtn		m_PtnInfo;
	TDrillSubToolInfo	m_SubToolConfig[64];
#endif

	CToolCodeList* m_pToolcode[32];

	TDrillHoleData m_ptData[1000];
	int				m_nDownHoleCount;
	TDrillHoleData* m_pBackUpData;
	int				m_nBackUpIndex;
	int				m_nSameShotPrestartCount;
	int				m_nBackupCount;
	TDrillDummyfreeInfo	m_DummyFreeInfo;
	MARKDATA m_MarkingData;

	USHORT m_usFunction;
	int m_nHoleCnt[64];
	BOOL m_bStandbyShotRun;

	double m_dDutyBackup;
	double m_dAOMDelayBackup;
	double m_dAOMDutyBackup;
	double m_usFreqBackup;
	int	m_nAOMDutyOffsetBackup;
	CCorrectTime m_StandbyTime;
	int m_nToolOldNo;
	SUBTOOLDATA m_subToolOld;
	CCalibration*	m_CalLPC;
	double			m_dAOMOpenLastTime;
private:
	TDrillPara m_TDrillParam;
	TUsedBeamBitMap m_UsedBeam;
	TDrillAomPara m_TAomParam;
	TDrillMonitor m_TMonitor;
#ifndef __NEW_STRUCTURE__
	TDrill_LPCMonitor*  m_pLPC_Monitor;
#else
	TLpc_Buffer*		m_pLPC_Monitor;
#endif
#ifdef __3RDAOD__
	TDrillDummyShotMode m_TDummyMode;
#endif
};	

#endif // !defined(AFX_HEOCARD5PUSAN1DUALBANDNEW_H__C6D292CB_1103_4D0C_B8AC_46D61A227A03__INCLUDED_)
