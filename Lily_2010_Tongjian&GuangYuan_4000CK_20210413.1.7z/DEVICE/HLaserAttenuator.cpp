// HLaserAttenuator.cpp: implementation of the HLaserAttenuator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HLaserAttenuator.h"
#include "InterfaceAttenuatorModule.h"
#include "DeviceMotor.h"
#include "HMotor.h"
#include "..\model\DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaserAttenuator::HLaserAttenuator()
{
	m_pMotor = NULL;
	m_nCmdPos = 0;
}

HLaserAttenuator::~HLaserAttenuator()
{
	DestroyEOAttenuator();
	
	m_bInit = FALSE;
	m_bAutoRun = FALSE;
	m_bDryRunMode = FALSE;
}
#ifdef __MP920_MOTOR__
	BOOL HLaserAttenuator::Initialize(HMotor* pMotor)
	{
		m_pMotor = pMotor;
		if( FALSE == InitializeEOAttenuator() )
		{
			ErrMessage(_T("Can not initialize attenuator"), MB_ICONERROR);
			
			return FALSE;
		}
		
		m_bInit = TRUE;
		m_bAutoRun = FALSE;
		m_bDryRunMode = FALSE;
		return TRUE;
	}
#else
	BOOL HLaserAttenuator::Initialize(DeviceMotor* pMotor)
	{
		m_pMotor = pMotor;
		if( FALSE == InitializeEOAttenuator() )
		{
			ErrMessage(_T("Can not initialize attenuator"), MB_ICONERROR);
			
			return FALSE;
		}
		
		m_bInit = TRUE;
		m_bAutoRun = FALSE;
		m_bDryRunMode = FALSE;
		return TRUE;
	}
#endif


BOOL HLaserAttenuator::ChangePort()
{
	if( FALSE != ChangeEOAttenuatorPort() )
	{
		m_bInit = TRUE;
		m_bAutoRun = FALSE;
		m_bDryRunMode = FALSE;
		return TRUE;
	}
	else
	{
		m_bInit = FALSE;
		m_bAutoRun = FALSE;
		m_bDryRunMode = FALSE;
		return FALSE;
	}
}

BOOL HLaserAttenuator::HomingCmd()
{
	int nMotorStatus = GetCurrentEOAttenuatorStatus();
	
	if( 0 == nMotorStatus )
	{
		ErrMessage(_T("Motor status is running"), MB_ICONERROR);
		return FALSE;
	}
	
	if( TRUE != OnEOAttenuatorHoming() )
	{
		ErrMessage(_T("Can not send home command to cool muscle"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}

BOOL HLaserAttenuator::Move(int nPulse)
{
	int nMotorStatus = GetCurrentEOAttenuatorStatus();
	
	if( 8 != nMotorStatus )
	{
		ErrMessage(_T("Motor is not idle or occurred error"), MB_ICONERROR);
		return FALSE;
	}
	m_nCmdPos = nPulse;

	if(m_nCmdPos < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus ||
		m_nCmdPos > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus)
	{
		ErrMessage(_T(" Moving position limit!"));
		return FALSE;
	}
	double dSpeed = m_pMotor->GetMoveSpeed(AXIS_X);
	double dAccel = m_pMotor->GetMoveAccel(AXIS_X);
	if( TRUE != SetEOAttenuatorManualMove( (int)dSpeed, (int)dAccel, nPulse ) )
	{
		ErrMessage(_T("Can not send move command to cool muscle"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}

BOOL HLaserAttenuator::MoveStop()
{
	if( TRUE != SetEOAttenuatorMoveStop() )
	{
		ErrMessage(_T("Can not send stop command to cool muscle"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}

int HLaserAttenuator::GetCurrentPos()
{
	return GetCurrentEOAttenuatorPosition();
}

int HLaserAttenuator::GetCurrentStatus()
{
	return GetCurrentEOAttenuatorStatus();
}

BOOL HLaserAttenuator::IsInposition()
{
#ifndef __TEST__
	int nCount = 0;
	while(nCount < 100)
	{
		if(8 == GetCurrentStatus() && 
			abs(GetCurrentPos() - m_nCmdPos) < 10)
			return TRUE;

		nCount++;
		Sleep(100);// 10 sec

	}
	ErrMessage(_T("Inposition Time out!"));
	return FALSE;
#else
	return TRUE;
#endif
}

CString HLaserAttenuator::GetError()
{
	int nStatus = GetCurrentEOAttenuatorStatus();
	CString strData;

	// Set Status
	switch( nStatus )
	{
	case -1 :
		strData.Format(_T("Time out"));
		break;
	case 0 :
		strData.Format(_T("Moving"));
		break;
	case 1 :
		strData.Format(_T("Out of position"));
		break;
	case 2 :
		strData.Format(_T("Over speed / dynamic braking"));
		break;
	case 3 :
		strData.Format(_T("Overload"));
		break;
	case 8 :
		strData.Format(_T("Done"));
		break;
	case 16 :
		strData.Format(_T("Motor free"));
		break;
	case 31 :
		strData.Format(_T("Under dynamic braking"));
		break;
	case 40 :
		strData.Format(_T(" Dynamic braking done"));
		break;
	case 128 :
		strData.Format(_T("Abnormal temperature"));
		break;
	case 255 :
		strData.Format(_T("Emergency stop"));
		break;
	default:
		strData.Format(_T(""));
		break;
	}
	return strData;

}

BOOL HLaserAttenuator::MoveIndex(int nIndex)
{
#ifndef __TEST__
	int nMotorStatus = GetCurrentEOAttenuatorStatus();
	
	if( 8 != nMotorStatus )
	{
		ErrMessage(_T("Motor is not idle or occurred error"), MB_ICONERROR);
		return FALSE;
	}
	m_nCmdPos = (int)m_pMotor->GetMPosition(nIndex);

	if(m_nCmdPos < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus ||
		m_nCmdPos > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus)
	{
		ErrMessage(_T(" Moving position limit!"));
		return FALSE;
	}
	double dSpeed = m_pMotor->GetMoveSpeed(AXIS_X);
	double dAccel = m_pMotor->GetMoveAccel(AXIS_X);
	if( TRUE != SetEOAttenuatorManualMove( (int)dSpeed, (int)dAccel, m_nCmdPos ) )
	{
		ErrMessage(_T("Can not send move command to cool muscle"), MB_ICONERROR);
		return FALSE;
	}
#endif
	return TRUE;
}
