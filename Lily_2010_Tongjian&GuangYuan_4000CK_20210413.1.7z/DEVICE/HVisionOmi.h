// HVisionOmi.h: interface for the HVisionOmi class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVISIONOMI_H__B74884A6_B26A_4C44_AA14_192E84763073__INCLUDED_)
#define AFX_HVISIONOMI_H__B74884A6_B26A_4C44_AA14_192E84763073__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef USE_VISION_PRO
	#include "aculnk.h"             // The OMI interface definition header file
#endif
#include "OmiView.h"
#include "MVisionLamp.h"
#include "..\model\dfiddata.h"
#include "..\model\2DTransform.h"
#define NO_USE_VISION

class CClientSock;

typedef struct _tagVISIONINFO
{
	int		nModelType;
	int		nPolarity;
	double	dSizeA;
	double	dSizeB;
	double	dSizeC;
//	double	dOrientation;
	int		nCoaxial[4];
	int		nRing[4];
	int		nIR[4];
	int		nBlob[4];
	double	dContrast[4];
	double	dBrightness[4];
	double	dScoreAngle;
	double	dScoreSize;
	double	dAspectRatio;
	int		nThreshold;
} SVISIONINFO;

class HVisionOmi  
{
public:
	static UINT LiveThread(LPVOID pParam);
	void InitDistancePerPixel();
	void CalPixelDistance();
	void TransformPixel();
	void InitVisionPixelData(int nCam);
	HVisionOmi();
	virtual ~HVisionOmi();

	BOOL	CheckOmiHandle();
	void	SetOmiView(int nCamNo, COmiView* pView);
	BOOL	LoadOmiProject(CString strDir);
	void	InitOmiVision();
	void	GetLivePos(int nZoom, DPOINT* pPos);
	void	OnConnectView();
	void	OnCamChange(int nCamNo);
	void	OnAcquire(int nCamNo);
	void	OnContrastAndBrightness(int nCamNo,	double dContrast, double dBrightness);
	void	OnContrast(int nCamNo, double dContrast);
	void	OnBrightness(int nCamNo, double dBrightness);
	void	SaveImg(int nCamNo, CString strFilePathName);
	BOOL	GetIsLive()				{ return m_bIsLive; }
	void	SetIsLive(BOOL bLive)	{ m_bIsLive = bLive; }
	void	OnLive(int nCamNo, BOOL bIsLive);
	void	OnApplyVisionParam(int nCamNo, SVISIONINFO sVisionInfo);
	void	OnApplyVisionParameter(int nCamNo, VISION_INFO sVisionInfo);
	void	UpdateMinMax(double dSizeA, double dSizeB, double dSizeC);
	BOOL	OnFindFiducial(int nCamNo, CString& strMsg);
	void	OnLightAll(int nCamNo, int nCoaxial, int nRing);
	void	OnLight(int nCamNo, int nType, int nVal);
	void	SetVisionZoom(int nCamNo, int nZoom=50);
	void	SetPixel(int nCamNo, DPOINT dPixel);
	
	BOOL	GetRealPos(DPOINT* rPos, int nCam, BOOL bRefresh, double& dSize, char* pchar = NULL);
	
	void	ShowArea(int nShow);
	void	SetInspectionArea(int nSize);
	BOOL	GetTcpIpResult(CString strOrder);
	BOOL	GetTcpIpFindFiducial(CString& strMsg);
	BOOL	GetTcpIpRealPos(DPOINT* rPos, double& dSize, char* pChar);
	void	ConnectOmiVision();
	double			m_dResultSize;
	CWnd*	m_pVisionHndle;
protected :
	COmiView*		m_pVisionView[4];

	int				m_nZoom[4];
	long			m_nCross[4];
	long			m_nLive[4];
	BOOL			m_bIsLive;

	SVISIONINFO		m_sVisionInfo;
	DPOINT			m_dPixel[4];
	DPOINT			m_dPos;

	double			m_dSizeAMin;
	double			m_dSizeAMax;
	double			m_dSizeBMin;
	double			m_dSizeBMax;
	double			m_dSizeCMin;
	double			m_dSizeCMax;

	MVisionLamp*	m_clsLamp;
	CEvent			m_evtUseOmiVision;
	C2DTransform	m_2DTrans[4]; //cam number
	DPOINT			m_dHighPixel;
	DPOINT			m_dLowPixel;
	CWinThread*		m_pLiveThread;
	int				m_nCam;
	CClientSock*    m_pClientSock;
};

#endif // !defined(AFX_HVISIONOMI_H__B74884A6_B26A_4C44_AA14_192E84763073__INCLUDED_)
