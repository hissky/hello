// MMelsecFx.cpp: implementation of the MMelsecFx class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MMelsecFx.h"
#include "..\EasyDriller.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
MMelsecFx::MMelsecFx()
{
	::InitializeCriticalSection( &m_CritSocket );
	m_hLocalSocket			= INVALID_SOCKET;

	m_strDestAddr.Format(_T("192.168.100.100"));
	m_nDestPortNo			= 0x7D0;//10010;
 
	m_strLocalAddr.Format(_T("192.168.100.101"));
	m_nLocalPortNo			= 0x7D0;//m_nDestPortNo;//20010;

	m_nCommErrorCount		= 0;
	m_nTimeOut				= 10;
}

MMelsecFx::~MMelsecFx()
{
	CloseWinSock();
	::DeleteCriticalSection( &m_CritSocket );
}

BOOL MMelsecFx::InitWinSock()
{
	WSADATA wsaData;
	WORD wVersion =  MAKEWORD(2,2);

	// Init Win Sock
	if( 0 != ::WSAStartup( wVersion, &wsaData ) )
	{
		ErrMessage(_T("WSAStartup Error"), MB_ICONERROR);
		return FALSE;
	}

	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */
 	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 ) 
	{
		ErrMessage(_T("Invalid Socket Version"), MB_ICONERROR);
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		WSACleanup( );
		return FALSE; 
	}

	return TRUE;
}

BOOL MMelsecFx::Connect()
{
	if( INVALID_SOCKET != m_hLocalSocket )
		return TRUE;

/*	if( INVALID_SOCKET == m_hLocalSocket )
	{
		if( FALSE == InitWinSock() )
			return FALSE;
	}
*/
	// Socket
	m_hLocalSocket = ::socket( AF_INET, SOCK_STREAM, 0 );
	if( INVALID_SOCKET == m_hLocalSocket )
	{
		ShowErrMsg(_T("socket()"));
		::WSACleanup();

		return FALSE;
	}

	// Get Client PC Name & IP Address
	char szLocalName[MAXBUFSIZE] = {0,};

	::gethostname( szLocalName, MAXBUFSIZE );

	// Init Socket Address Struct
	memset( &m_sDestAddr, 0, sizeof(m_sDestAddr) );
	memset( &m_sLocalAddr, 0, sizeof(m_sLocalAddr) );

	// Destination Address
	m_sDestAddr.sin_family			= AF_INET;
	m_sDestAddr.sin_port			= htons( m_nDestPortNo );
	m_sDestAddr.sin_addr.s_addr		= inet_addr( (LPSTR)(LPCTSTR)m_strDestAddr );

	// Local Address
	m_sLocalAddr.sin_family			= AF_INET;
	m_sLocalAddr.sin_port			= htons( m_nDestPortNo ); // htons( m_nLocalPortNo );
	m_sLocalAddr.sin_addr.s_addr	= inet_addr( (LPSTR)(LPCTSTR)m_strLocalAddr );

	// bind. 
	int nRet = ::bind( m_hLocalSocket, (SOCKADDR*)&m_sLocalAddr, sizeof(m_sLocalAddr) );

	if( SOCKET_ERROR == nRet )
	{
		ShowErrMsg(_T("bind()"));
 		CloseWinSock();
		return FALSE;
	}

	MSG msg;
	for(int i = 0; i<1000; i++)
	{
		nRet = ::connect( m_hLocalSocket, (SOCKADDR*)&m_sDestAddr, sizeof(m_sDestAddr) );
		if(nRet != SOCKET_ERROR)
			break;
		Sleep(50);
	
		if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
		{
			TranslateMessage((LPMSG)&msg);
			DispatchMessage((LPMSG)&msg);
		}
	}
	if( SOCKET_ERROR == nRet )
	{
	//	ShowErrMsg(_T("bind()"));
		CloseWinSock();
		return FALSE;
	}

	// Timeout Option
	int nTimeout = 1000 * m_nTimeOut;
	nRet = ::setsockopt( m_hLocalSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&nTimeout, sizeof(nTimeout) );

	if( SOCKET_ERROR == nRet )
	{
		ShowErrMsg(_T("setsockopt()"));
		CloseWinSock();

		return FALSE;
	}

	return TRUE;
}

void MMelsecFx::CloseWinSock()
{
	if( INVALID_SOCKET == m_hLocalSocket )
		return;

	int nErrCode = ::closesocket( m_hLocalSocket );
	if( 0 != nErrCode )
	{
		ShowErrMsg(_T("closesocket()"));
	}
	::WSACleanup();

	m_hLocalSocket	= INVALID_SOCKET;
}

void MMelsecFx::ShowErrMsg(CString strMsg)
{
	LPVOID lpMsgBuf;

	::FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
					 ::WSAGetLastError(), MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ),
					 (LPTSTR)&lpMsgBuf, 0, NULL );

	CString strErrMsg;

	strErrMsg.Format(_T("[%s] %s"), strMsg, (LPCTSTR)lpMsgBuf);
	ErrMessage(strErrMsg, MB_ICONERROR);

	::LocalFree( lpMsgBuf );
}

int MMelsecFx::SendMsg(char* pData, int nDataSize)
{
	int nRet = 0;

//	nRet = ::sendto( m_hLocalSocket, pData, nDataSize, 0, (SOCKADDR*)&m_sDestAddr, sizeof(m_sDestAddr) );
	nRet = ::send( m_hLocalSocket, pData, nDataSize, 0);

	if( SOCKET_ERROR == nRet )
	{
		//ShowErrMsg(_T("sendto()"));
		if( m_nCommErrorCount <= 7 )
			m_nCommErrorCount++;

		return 0;
	}
	else
		m_nCommErrorCount = 0;

	return nRet;
}

int MMelsecFx::RecvMsg(char* pData, int nDataSize)
{
	int nRet = 0;
	int nCount = 0;

//	SOCKADDR_IN sPeerAddr;
	int nAddrLen = sizeof(SOCKADDR_IN);

	while(nRet == 0)
	{
		nCount++;
//		::Sleep(0);
//		nRet = ::recvfrom( m_hLocalSocket, pData, nDataSize, 0, (SOCKADDR*)&sPeerAddr, &nAddrLen );
		nRet = ::recv( m_hLocalSocket, pData, nDataSize, 0);
		if(nCount > 100)
		{
			TRACE(_T("Time over\n"));
			break;
		}
	}

	if( SOCKET_ERROR == nRet )
	{
		//ShowErrMsg(_T("recvfrom()"));
		if( m_nCommErrorCount <= 7 )
			m_nCommErrorCount++;

		return 0;
	}
	else
		m_nCommErrorCount = 0;

	// Sender�� IP Address �˻�
/*	if( 0 != memcmp( &sPeerAddr, &m_sDestAddr, sizeof(sPeerAddr) ) )
	{
		ErrMessage(_T("Unknown Sender"), MB_ICONERROR);
		
		return 0;
	}
*/
	return nRet;
}

BOOL MMelsecFx::IsConnect()
{
	if( INVALID_SOCKET == m_hLocalSocket )
		return FALSE;

	return TRUE;
}

BOOL MMelsecFx::Create()
{
#ifdef __TEST__
	return TRUE;
#endif
	BOOL bRet = 0;
	
	// Initialize WinSock
	bRet = InitWinSock();
	
	if( FALSE == bRet )
		return bRet;
	
	// Connect Melsec
	bRet = Connect();
	
	if( FALSE == bRet )
	{
		CloseWinSock();
		return bRet; 
	}

	// Initialzie Motor Command
	InitCommand();

	return bRet;
}

void MMelsecFx::InitCommand()
{
	m_qSendData.sHeader.cSubHeader1			= 0x03;			// sub-header no
	m_qSendData.sHeader.cPCNo1				= 0xFF;			// PC no
	m_qSendData.sHeader.wCPUWaitTime[0]		= 0x0A;			// monitoring timer
	m_qSendData.sHeader.wCPUWaitTime[1]		= 0x00;

	m_qRecieveData.sHeader.cSubHeader1		= 0x01;			// sub-header no
	m_qRecieveData.sHeader.cPCNo1			= 0xFF;			// PC no
	m_qRecieveData.sHeader.wCPUWaitTime[0]	= 0x0A;
	m_qRecieveData.sHeader.wCPUWaitTime[1]	= 0x00;

}

BOOL MMelsecFx::ReadMemsbyWord(WORD *wData, WORD wAddress, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BOOL bRet;
	int nRet;
	BYTE cVal;
	memset(m_qRecieveData.cData, 0, sizeof(m_qSendData.cData));
		
	wVal = wAddress;
	memcpy((void*)(&m_qRecieveData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD)*2;

	cVal = CMD_DEVICE_NAME_L;
	memcpy((void*)(&m_qRecieveData.cData[wCmdSize]), &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);
	cVal = CMD_DEVICE_NAME_H;
	memcpy((void*)(&m_qRecieveData.cData[wCmdSize]), &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);

	cVal = (BYTE)nSize; 
	memcpy((void*)(&m_qRecieveData.cData[wCmdSize]), &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);

	bRet = SendMsg((char*)(&m_qRecieveData), sizeof(m_qRecieveData.sHeader) + wCmdSize +1);
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}

	memset(&m_qResponse, 0 , sizeof(m_qResponse));
	nRet = RecvMsg((char*)&m_qResponse, sizeof(m_qResponse));
	
	if(m_qResponse.cCompleateCode != 0x00)
	{
		TRACE(_T("Recieve Error code: %d\n"), m_qResponse.cData[0]);
		::LeaveCriticalSection( &m_CritSocket );
		return FALSE;
	}
	else 
	{	
		memcpy(wData, (void*)(&m_qResponse.cData), nSize * sizeof(WORD));
	}	
			
	::LeaveCriticalSection( &m_CritSocket );

	return TRUE;
}

BOOL MMelsecFx::WriteMemsbyWord(WORD *wData, WORD wAddress, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BYTE cVal;
	BOOL bRet;
	int nRet;
	
	memset(m_qSendData.cData, 0, sizeof(m_qSendData.cData));
	wVal = wAddress;
	memcpy(&m_qSendData.cData[wCmdSize], &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD)*2;
	
	cVal = CMD_DEVICE_NAME_L;
	memcpy(&m_qSendData.cData[wCmdSize], &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);
	cVal = CMD_DEVICE_NAME_H;
	memcpy(&m_qSendData.cData[wCmdSize], &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);

	wVal = 0x01; 
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);

	cVal = 0x00; 
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &cVal, sizeof(BYTE));
	wCmdSize += sizeof(BYTE);

	memcpy((void*)(&m_qSendData.cData[wCmdSize]), wData,  sizeof(WORD));
	wCmdSize += nSize * sizeof(WORD);
	
	
 	bRet = SendMsg((char*)(&m_qSendData), sizeof(m_qSendData.sHeader) + wCmdSize );
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	memset(&m_qResponse, 0 , sizeof(m_qRecieveData));
	nRet = RecvMsg((char*)&m_qResponse, sizeof(m_qResponse));
	
	if(m_qResponse.cCompleateCode != 0x00)
	{
		TRACE(_T("Recieve Error code: %d\n"), m_qResponse.cData[0]);
		::LeaveCriticalSection( &m_CritSocket );
		return FALSE;
	}

	::LeaveCriticalSection( &m_CritSocket );
	
	return TRUE;	
}