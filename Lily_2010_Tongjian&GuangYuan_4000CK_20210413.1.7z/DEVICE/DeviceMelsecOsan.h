// DeviceMelsecOsan.h: interface for the DeviceMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEMELSECOSAN_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEMELSECOSAN_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
#include "MMelsec.h"

const int HANDLER_AXIS_MAX = 0x08;	

struct PLC_BIT_SIGNAL
{
	//M1500
	WORD	bLCReady:1;					// 0 : M1500
	WORD	bLCBusy:1;					// 1 : M1501
	WORD	bLCStop:1;					// 2 : M1502
	WORD	bLCInitialEnd:1;			// 3 : M1503
	WORD	cDummyM1504:1;				// 4
	WORD	cDummyM1505:1;				// 5
	WORD	cDummyM1506:1;				// 6
	WORD	cDummyM1507:1;				// 7
	WORD	cDummyM1508:1;				// 8
	WORD	cDummyM1509:1;				// 9

	//M1510
	WORD	bLP1Ready:1;				// 0 : M1510
	WORD	bLP1Busy:1;					// 1 : M1511
	WORD	bLP1Stop:1;					// 2 : M1512
	WORD	bLP1InitialEnd:1;			// 3 : M1513
	WORD	cDummyM1514:1;				// 4
	WORD	cDummyM1515:1;				// 5
	WORD	cDummyM1516:1;				// 6
	WORD	cDummyM1517:1;				// 7
	WORD	cDummyM1518:1;				// 8
	WORD	cDummyM1519:1;				// 9

	//M1520
	WORD	bLP2Ready:1;				// 0 : M1520
	WORD	bLP2Busy:1;					// 1 : M1521
	WORD	bLP2Stop:1;					// 2 : M1522
	WORD	bLP2InitialEnd:1;			// 3 : M1523
	WORD	cDummyM1524:1;				// 4
	WORD	cDummyM1525:1;				// 5
	WORD	cDummyM1526:1;				// 6
	WORD	cDummyM1527:1;				// 7
	WORD	cDummyM1528:1;				// 8
	WORD	cDummyM1529:1;				// 9

	//M1530
	WORD	bLP3Ready:1;				// 0 : M1530
	WORD	bLP3Busy:1;					// 1 : M1531
	WORD	bLP3Stop:1;					// 2 : M1532
	WORD	bLP3InitialEnd:1;			// 3 : M1533
	WORD	cDummyM1534:1;				// 4
	WORD	cDummyM1535:1;				// 5
	WORD	cDummyM1536:1;				// 6
	WORD	cDummyM1537:1;				// 7
	WORD	cDummyM1538:1;				// 8
	WORD	cDummyM1539:1;				// 9

	//M1540
	WORD	bUCReady:1;					// 0 : M1540
	WORD	bUCBusy:1;					// 1 : M1541
	WORD	bUCStop:1;					// 2 : M1542
	WORD	bUCInitialEnd:1;			// 3 : M1543
	WORD	cDummyM1544:1;				// 4
	WORD	cDummyM1545:1;				// 5
	WORD	cDummyM1546:1;				// 6
	WORD	cDummyM1547:1;				// 7
	WORD	cDummyM1548:1;				// 8
	WORD	cDummyM1549:1;				// 9

	//M1550
	WORD	bUP1Ready:1;				// 0 : M1550
	WORD	bUP1Busy:1;					// 1 : M1551
	WORD	bUP1Stop:1;					// 2 : M1552
	WORD	bUP1InitialEnd:1;			// 3 : M1553
	WORD	cDummyM1554:1;				// 4
	WORD	cDummyM1555:1;				// 5
	WORD	cDummyM1556:1;				// 6
	WORD	cDummyM1557:1;				// 7
	WORD	cDummyM1558:1;				// 8
	WORD	cDummyM1559:1;				// 9

	//M1560
	WORD	bUP2Ready:1;				// 0 : M1560
	WORD	bUP2Busy:1;					// 1 : M1561
	WORD	bUP2Stop:1;					// 2 : M1562
	WORD	bUP2InitialEnd:1;			// 3 : M1563
	WORD	cDummyM1564:1;				// 4
	WORD	cDummyM1565:1;				// 5
	WORD	cDummyM1566:1;				// 6
	WORD	cDummyM1567:1;				// 7
	WORD	cDummyM1568:1;				// 8
	WORD	cDummyM1569:1;				// 9

	//M1570
	WORD	bUP3Ready:1;				// 0 : M1570
	WORD	bUP3Busy:1;					// 1 : M1571
	WORD	bUP3Stop:1;					// 2 : M1572
	WORD	bUP3InitialEnd:1;			// 3 : M1573
	WORD	cDummyM1574:1;				// 4
	WORD	cDummyM1575:1;				// 5
	WORD	cDummyM1576:1;				// 6
	WORD	cDummyM1577:1;				// 7
	WORD	cDummyM1578:1;				// 8
	WORD	cDummyM1579:1;				// 9

	//M1580
	WORD	cDummyM1580:1;
	WORD	cDummyM1581:1;
	WORD	cDummyM1582:1;
	WORD	cDummyM1583:1;
	WORD	cDummyM1584:1;
	WORD	cDummyM1585:1;
	WORD	cDummyM1586:1;
	WORD	cDummyM1587:1;
	WORD	cDummyM1588:1;
	WORD	cDummyM1589:1;
	
	//M1590
	WORD	cDummyM1590:1;
	WORD	cDummyM1591:1;
	WORD	cDummyM1592:1;
	WORD	cDummyM1593:1;
	WORD	cDummyM1594:1;
	WORD	cDummyM1595:1;
	WORD	cDummyM1596:1;
	WORD	cDummyM1597:1;
	WORD	cDummyM1598:1;
	WORD	cDummyM1599:1;

	//M1600
	WORD	bAlignRun:1;				// 0 : M1600
	WORD	bAlignEnd:1;				// 1 : M1601
	WORD	bLoadRun:1;					// 2 : M1602
	WORD	bLoadEnd:1;					// 3 : M1603
	WORD	bUnloadRun:1;				// 4 : M1604
	WORD	bUnloadEnd:1;				// 5 : M1605
	WORD	bLoadRequestReady:1;		// 6 : M1606
	WORD	cDummyM1607:1;				// 7
	WORD	cDummyM1608:1;				// 8
	WORD	cDummyM1609:1;				// 9

	//M1610
	WORD	bLP1PCBExist:1;				// 0 : M1610
	WORD	bLP2PCBExist:1;				// 1 : M1611
	WORD	bUP1PCBExist:1;				// 2 : M1612
	WORD	bUP2PCBExist:1;				// 3 : M1613
	WORD	bLdElvPCBExist:1;			// 4 : M1614
	WORD	bLdTablePCBExist:1;			// 5 : M1615
	WORD	bLdPaperTransPCBExist:1;	// 6 : M1616
	WORD	bUdTablePCBExist:1;			// 7 : M1617
	WORD	bUdPaperTransPCBExist:1;	// 8 : M1618
	WORD	cDummyM1619:1;				// 9

	//M1620
	WORD	bSystemReset:1;				// 0 : M1620
	WORD	bLoaderInterlockBypass:1;	// 1 : M1621
	WORD	bMelsecConnect:1;			// 2 : M1622
	WORD	cDummyM1623:1;				// 3
	WORD	cDummyM1624:1;				// 4
	WORD	cDummyM1625:1;				// 5
	WORD	cDummyM1626:1;				// 6
	WORD	cDummyM1627:1;				// 7
	WORD	cDummyM1628:1;				// 8
	WORD	cDummyM1629:1;				// 9
	
	//M1630
	WORD	bLoadPartError:1;			// 0 : M1630
	WORD	bUnloadPartError:1;			// 1 : M1631
	WORD	cDummyM1632:1;
	WORD	cDummyM1633:1;
	WORD	cDummyM1634:1;
	WORD	cDummyM1635:1;
	WORD	cDummyM1636:1;
	WORD	cDummyM1637:1;
	WORD	cDummyM1638:1;
	WORD	cDummyM1639:1;

	//M1640
	WORD	bLdPaperTransFwd:1;			// 0 : M1640
	WORD	bLdPaperTransBwd:1;			// 1 : M1641
	WORD	bLdPCBTransFwd:1;			// 2 : M1642
	WORD	bLdPCBTransBwd:1;			// 3 : M1643
	WORD	bLdAlignSheetFwd:1;			// 4 : M1644
	WORD	bLdAlignSheetBwd:1;			// 5 : M1645
	WORD	bLdAlignGuideFwd:1;			// 6 : M1646
	WORD	bLdAlignGuideBwd:1;			// 7 : M1647
	WORD	bLdCartClampUp:1;			// 8 : M1648
	WORD	bLdCartClampDown:1;			// 9 : M1649

	//M1650
	WORD	bLdPick1VacOn:1;			// 0 : M1650
	WORD	bLdPick1VacOff:1;			// 1 : M1651
	WORD	bLdPick2VacOn:1;			// 2 : M1652
	WORD	bLdPick2VacOff:1;			// 3 : M1653
	WORD	bLdPick3VacOn:1;			// 4 : M1654
	WORD	bLdPick3VacOff:1;			// 5 : M1655
	WORD	cDummyM1656:1;
	WORD	cDummyM1657:1;
	WORD	cDummyM1658:1;
	WORD	cDummyM1659:1;

	//M1660
	WORD	bUdPaperTransFwd:1;			// 0 : M1660
	WORD	bUdPaperTransBwd:1;			// 1 : M1661
	WORD	bUdPCBTransFwd:1;			// 2 : M1662
	WORD	bUdPCBTransBwd:1;			// 3 : M1663
	WORD	bUdCartClampUp:1;			// 4 : M1664
	WORD	bUdCartClampDown:1;			// 5 : M1665
	WORD	bUdPick1VacOn:1;			// 6 : M1666
	WORD	bUdPick1VacOff:1;			// 7 : M1667
	WORD	bUdPick2VacOn:1;			// 8 : M1668
	WORD	bUdPick2VacOff:1;			// 9 : M1669

	//M1670
	WORD	bUdPick3VacOn:1;			// 0 : M1670
	WORD	bUdPick3VacOff:1;			// 1 : M1671
	WORD	cDummyM1672:1;
	WORD	cDummyM1673:1;
	WORD	cDummyM1674:1;
	WORD	cDummyM1675:1;
	WORD	cDummyM1676:1;
	WORD	cDummyM1677:1;
	WORD	cDummyM1678:1;
	WORD	cDummyM1679:1;

	//M1680
	WORD	bLCinElvPos:1;				// 0 : M1680
	WORD	bLCinTablePos:1;			// 1 : M1681
	WORD	bLP1inUpPos:1;				// 2 : M1682
	WORD	bLP2inUpPos:1;				// 3 : M1683
	WORD	bLP3inUpPos:1;				// 4 : M1684
	WORD	bUCinElvPos:1;				// 5 : M1685
	WORD	bUCinTablePos:1;			// 6 : M1686
	WORD	bUP1inUpPos:1;				// 7 : M1687
	WORD	bUP2inUpPos:1;				// 8 : M1688
	WORD	bUP3inUpPos:1;				// 9 : M1689

	//M1690
	WORD	bLP1VacuumOn:1;				// 0 : M1690
	WORD	bLP1VacuumOff:1;			// 1 : M1691
	WORD	bLP2VacuumOn:1;				// 2 : M1692
	WORD	bLP2VacuumOff:1;			// 3 : M1693
	WORD	bUP1VacuumOn:1;				// 4 : M1694
	WORD	bUP1VacuumOff:1;			// 5 : M1695
	WORD	bUP2VacuumOn:1;				// 6 : M1696
	WORD	bUP2VacuumOff:1;			// 7 : M1697
	WORD	cDummyM1698:1;
	WORD	cDummyM1699:1;

	//M1700
	WORD	cDummyM1700:1;
	WORD	cDummyM1701:1;
	WORD	cDummyM1702:1;
	WORD	cDummyM1703:1;
	WORD	cDummyM1704:1;
	WORD	cDummyM1705:1;
	WORD	cDummyM1706:1;
	WORD	cDummyM1707:1;
	WORD	cDummyM1708:1;
	WORD	cDummyM1709:1;

	//M1710
	WORD	cDummyM1710:1;
	WORD	cDummyM1711:1;
	WORD	cDummyM1712:1;
	WORD	cDummyM1713:1;
	WORD	cDummyM1714:1;
	WORD	cDummyM1715:1;
	WORD	cDummyM1716:1;
	WORD	cDummyM1717:1;
	WORD	cDummyM1718:1;
	WORD	cDummyM1719:1;

	//M1720
	WORD	cDummyM1720:1;
	WORD	cDummyM1721:1;
	WORD	cDummyM1722:1;
	WORD	cDummyM1723:1;
	WORD	cDummyM1724:1;
	WORD	cDummyM1725:1;
	WORD	cDummyM1726:1;
	WORD	cDummyM1727:1;
	WORD	cDummyM1728:1;
	WORD	cDummyM1729:1;

	//M1730
	WORD	cDummyM1730:1;
	WORD	cDummyM1731:1;
	WORD	cDummyM1732:1;
	WORD	cDummyM1733:1;
	WORD	cDummyM1734:1;
	WORD	cDummyM1735:1;
	WORD	cDummyM1736:1;
	WORD	cDummyM1737:1;
	WORD	cDummyM1738:1;
	WORD	cDummyM1739:1;

	//M1740
	WORD	cDummyM1740:1;
	WORD	cDummyM1741:1;
	WORD	cDummyM1742:1;
	WORD	cDummyM1743:1;
	WORD	cDummyM1744:1;
	WORD	cDummyM1745:1;
	WORD	cDummyM1746:1;
	WORD	cDummyM1747:1;
	WORD	cDummyM1748:1;
	WORD	cDummyM1749:1;

	//M1750
	WORD	cDummyM1750:1;
	WORD	cDummyM1751:1;
	WORD	cDummyM1752:1;
	WORD	cDummyM1753:1;
	WORD	cDummyM1754:1;
	WORD	cDummyM1755:1;
	WORD	cDummyM1756:1;
	WORD	cDummyM1757:1;
	WORD	cDummyM1758:1;
	WORD	cDummyM1759:1;

	//M1760
	WORD	cDummyM1760:1;
	WORD	cDummyM1761:1;
	WORD	cDummyM1762:1;
	WORD	cDummyM1763:1;
	WORD	cDummyM1764:1;
	WORD	cDummyM1765:1;
	WORD	cDummyM1766:1;
	WORD	cDummyM1767:1;
	WORD	cDummyM1768:1;
	WORD	cDummyM1769:1;

	//M1770
	WORD	cDummyM1770:1;
	WORD	cDummyM1771:1;
	WORD	cDummyM1772:1;
	WORD	cDummyM1773:1;
	WORD	cDummyM1774:1;
	WORD	cDummyM1775:1;
	WORD	cDummyM1776:1;
	WORD	cDummyM1777:1;
	WORD	cDummyM1778:1;
	WORD	cDummyM1779:1;

	//M1780
	WORD	cDummyM1780:1;
	WORD	cDummyM1781:1;
	WORD	cDummyM1782:1;
	WORD	cDummyM1783:1;
	WORD	cDummyM1784:1;
	WORD	cDummyM1785:1;
	WORD	cDummyM1786:1;
	WORD	cDummyM1787:1;
	WORD	cDummyM1788:1;
	WORD	cDummyM1789:1;

	//M1790
	WORD	cDummyM1790:1;
	WORD	cDummyM1791:1;
	WORD	cDummyM1792:1;
	WORD	cDummyM1793:1;
	WORD	cDummyM1794:1;
	WORD	cDummyM1795:1;
	WORD	cDummyM1796:1;
	WORD	cDummyM1797:1;
	WORD	cDummyM1798:1;
	WORD	cDummyM1799:1;
	
	//M1800 Error
	WORD	cdummyM1800:1;				// 0
	WORD	bErrPlcCPU:1;				// 1 : M7001
	WORD	bErrPLCLowBattery:1;		// 2 : M7002
	WORD	bErrPLCFuse:1;				// 3 : M7003
	WORD	bErrQD75Unit1:1;			// 4 : M7004
	WORD	bErrCOMLed:1;				// 5 : M7005
	WORD	bErrWDT:1;					// 6 : M7006
	WORD	bErrQD75Unit2:1;			// 7 : M7007
	WORD	bErrUdFull:1;				// 8 : M7008
	WORD	bErrMotorPowerOff:1;		// 9 : M7009

	//M1810 Error
	WORD	bErrMotorPowerOn:1;			// 0 : M7010
	WORD	bErrLdUdAirOff:1;			// 1 : M7011
	WORD	bErrEmergencyOn:1;			// 2 : M7012
	WORD	bErrLdUdTimeOver:1;			// 3 : M7013
	WORD	bErrLdDoorInterlock:1;		// 4 : M7014
	WORD	bErrUdDoorInterlock:1;		// 5 : M7015
	WORD	bErrLdNoBasket:1;			// 6 : M7016
	WORD	bErrUdNoBasket:1;			// 7 : M7017
	WORD	bErrLdPartInitial:1;		// 8 : M7018
	WORD	bErrUdPartInitial:1;		// 9 : M7019

	//M1820 Error
	WORD	bErrLCOriginTimeOver:1;		// 0 : M7020
	WORD	bErrLCMoving:1;				// 1 : M7021
	WORD	bErrLCPosData:1;			// 2 : M7022
	WORD	bErrLCAlarm:1;				// 3 : M7023
	WORD	bErrLCPlusLimit:1;			// 4 : M7024
	WORD	bErrLCMinusLimit:1;			// 5 : M7025
	WORD	bErrLP1OriginTimeOver:1;	// 6 : M7026
	WORD	bErrLP1Moving:1;			// 7 : M7027
	WORD	bErrLP1PosData:1;			// 8 : M7028
	WORD	bErrLP1Alarm:1;				// 9 : M7029

	//M1830 Error
	WORD	bErrLP1PlusLimit:1;			// 0 : M7030
	WORD	bErrLP1MinusLimit:1;		// 1 : M7031
	WORD	bErrLP2OriginTimeOver:1;	// 2 : M7032
	WORD	bErrLP2Moving:1;			// 3 : M7033
	WORD	bErrLP2PosData:1;			// 4 : M7034
	WORD	bErrLP2Alarm:1;				// 5 : M7035
	WORD	bErrLP2PlusLimit:1;			// 6 : M7036
	WORD	bErrLP2MinusLimit:1;		// 7 : M7037
	WORD	bLdBasketPaperFull:1;		// 8 : M7038
	WORD	cDummyM1839:1;				// 9

	//M1840 Error
	WORD	bErrLP3OriginTimeOver:1;	// 0 : M7040
	WORD	bErrLP3Moving:1;			// 1 : M7041
	WORD	bErrLP3PosData:1;			// 2 : M7042
	WORD	bErrLP3Alarm:1;				// 3 : M7043
	WORD	bErrLP3PlusLimit:1;			// 4 : M7044
	WORD	bErrLP3MinusLimit:1;		// 5 : M7045
	WORD	bErrUCOriginTimeOver:1;		// 6 : M7046
	WORD	bErrUCMoving:1;				// 7 : M7047
	WORD	bErrUCPosData:1;			// 8 : M7048
	WORD	bErrUCAlarm:1;				// 9 : M7049

	//M1850 Error
	WORD	bErrUCPlusLimit:1;			// 0 : M7050
	WORD	bErrUCMinusLimit:1;			// 1 : M7051
	WORD	bErrUP1OriginTimeOver:1;	// 2 : M7052
	WORD	bErrUP1Moving:1;			// 3 : M7053
	WORD	bErrUP1PosData:1;			// 4 : M7054
	WORD	bErrUP1Alarm:1;				// 5 : M7055
	WORD	bErrUP1PlusLimit:1;			// 6 : M7056
	WORD	bErrUP1MinusLimit:1;		// 7 : M7057
	WORD	bErrUdElvPCBFull:1;			// 8 : M7058
	WORD	cDummyM1859:1;				// 9

	//M1860 Error
	WORD	bErrUP2OriginTimeOver:1;	// 0 : M7060
	WORD	bErrUP2Moving:1;			// 1 : M7061
	WORD	bErrUP2PosData:1;			// 2 : M7062
	WORD	bErrUP2Alarm:1;				// 3 : M7063
	WORD	bErrUP2PlusLimit:1;			// 4 : M7064
	WORD	bErrUP2MinusLimit:1;		// 5 : M7065
	WORD	bErrUP3OriginTimeOver:1;	// 6 : M7066
	WORD	bErrUP3Moving:1;			// 7 : M7067
	WORD	bErrUP3PosData:1;			// 8 : M7068
	WORD	bErrUP3Alarm:1;				// 9 : M7069
	
	//M1870 Error
	WORD	bErrUP3PlusLimit:1;			// 0 : M7070
	WORD	bErrUP3MinusLimit:1;		// 1 : M7071
	WORD	cDummyM1872:1;				// 2
	WORD	cDummyM1873:1;				// 3
	WORD	cDummyM1874:1;				// 4
	WORD	cDummyM1875:1;				// 5
	WORD	cDummyM1876:1;				// 6
	WORD	cDummyM1877:1;				// 7
	WORD	cDummyM1878:1;				// 8
	WORD	cDummyM1879:1;				// 9

	//M1880 Error
	WORD	bErrLdElvHoming:1;			// 0 : M7080
	WORD	bErrLdElvLoading:1;			// 1 : M7081
	WORD	bErrLdElvAlarm:1;			// 2 : M7082
	WORD	bErrLdElvPlusLimit:1;		// 3 : M7083
	WORD	bErrLdElvMinusLimit:1;		// 4 : M7084
	WORD	bErrUdElvHoming:1;			// 5 : M7085
	WORD	bErrUdElvLoading:1;			// 6 : M7086
	WORD	bErrUdElvAlarm:1;			// 7 : M7087
	WORD	bErrUdElvPlusLimit:1;		// 8 : M7088
	WORD	bErrUdElvMinusLimit:1;		// 9 : M7089

	//M1890 Error
	WORD	bErrLdPaperTransFwdBwd:1;	// 0 : M7090
	WORD	bErrLdPCBTransFwdBwd:1;		// 1 : M7091
	WORD	bErrLdAlignSheetFwdBwd:1;	// 2 : M7092
	WORD	bErrLdAlignGuideFwdBwd:1;	// 3 : M7093
	WORD	bErrLdCartClampUpDown:1;	// 4 : M7094
	WORD	bErrLP1Vacuum:1;			// 5 : M7095
	WORD	bErrLP2Vacuum:1;			// 6 : M7096
	WORD	bErrLP3Vacuum:1;			// 7 : M7097
	WORD	bErrUdPaperTransFwdBwd:1;	// 8 : M7098
	WORD	bErrUdPCBTransFwdBwd:1;		// 9 : M7099

	//M1900 Error
	WORD	bErrUdCartClampUpDown:1;	// 0 : M7100
	WORD	bErrUP1Vacuum:1;			// 1 : M7101
	WORD	bErrUP2Vacuum:1;			// 2 : M7102
	WORD	bErrUP3Vacuum:1;			// 3 : M7103
	WORD	bErrLdCartDetectSensor:1;	// 4 : M7104
	WORD	bErrUdCartDetectSensor:1;	// 5 : M7105
	WORD	bErrLP1Status:1;			// 6 : M7106
	WORD	bErrLP2Status:1;			// 7 : M7107
	WORD	bErrLP3Status:1;			// 8 : M7108
	WORD	bErrLdPCBTableStatus:1;		// 9 : M7109

	//M1910 Error
	WORD	bErrLdPaperTableStatus:1;	// 0 : M7110
	WORD	bErrUP1Status:1;			// 1 : M7111
	WORD	bErrUP2Status:1;			// 2 : M7112
	WORD	bErrUP3Status:1;			// 3 : M7113
	WORD	bErrUdPCBTableStatus:1;		// 4 : M7114
	WORD	bErrUdPaperTableStatus:1;	// 5 : M7115
	WORD	bErrLEstopPCBDrop:1;		// 6 : M7116
	WORD	bErrULEstopPCBDrop:1;		// 7 : M7117
	WORD	cDummyM1918:1;				// 8
	WORD	cDummyM1919:1;				// 9
	
	//M1920 Error
	WORD	cDummyM1920:1;				// 0
	WORD	cDummyM1921:1;				// 1
	WORD	cDummyM1922:1;				// 2
	WORD	cDummyM1923:1;				// 3
	WORD	cDummyM1924:1;				// 4
	WORD	cDummyM1925:1;				// 5
	WORD	cDummyM1926:1;				// 6
	WORD	cDummyM1927:1;				// 7
};

struct POSITION_INFO
{
	int		nLCCurrentPos;				// D1500
	int		nLP1CurrentPos;				// D1502
	int		nLP2CurrentPos;				// D1504
	int		nLP3CurrentPos;				// D1506
	int		nUCCurrentPos;				// D1508
	int		nUP1CurrentPos;				// D1510
	int		nUP2CurrentPos;				// D1512
	int		nUP3CurrentPos;				// D1514
};

class DeviceMelsecOsan : public CWnd  
{
public:
	static  UINT ThreadStatus(LPVOID pParam);
	static UINT ThreadInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceMelsecOsan();
	virtual ~DeviceMelsecOsan();

protected:
	CWinThread*		m_thdStatus;
	CWinThread*		m_thdInPosition;		// Window Thread Inposition
	int				m_nAxisMax;
	LONG			m_lErrorHandlerMain;
	LONG			m_lErrorHandlerLoader;
	LONG			m_lErrorHandlerUnloader;
	LONG			m_lErrorHandlerEtc1;
	LONG			m_lErrorHandlerEtc2;
	LONG			m_lStatusHandlerLoader;
	LONG			m_lStatusHandlerUnloader;
	LONG			m_lStautsOther;

public:
	BOOL IsLoaderAlignTableForward();
	BOOL IsUnloaderAlignTableForward();
	BOOL IsAlignGuideForward();
	BOOL IsAlignSheetTableForward();
	BOOL IsUnloaderCartClamp();
	BOOL IsLoaderCartClamp();
	BOOL LoaderAlignYBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignXForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderClampForward();
	BOOL UnloaderTableBackward();
	BOOL UnloaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderTableForward();
	BOOL CheckMelsecConnect();
	void ReadStautsOther();
	BOOL IsUPVacuum(BOOL b1st, BOOL bOn);
	BOOL IsLPVacuum(BOOL b1st, BOOL bOn);
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL IsHandlerPaperTransPCBExist(BOOL bLoader);
	BOOL IsHandlerPartError(BOOL bLoader);

	int GetWritePos(int nAxis);
	int GetCurrentPos(int nAxis);
	void GetBitSiganl(PLC_BIT_SIGNAL* pData);
	int GetAxisMax();
	
	MMelsec*		m_pMelsec;

	BOOL IsHandlerBusy(int nAxis);
	BOOL IsHandlerStop(int nAxis);	

	BOOL IsReady(int nAxis = -1);
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsInPositionThread(int nAxis, BYTE nCommand);
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);

	void ReadStatus(BOOL bFirst);
	void ReadPosition();
	void ReadErrorHandlerMain();
	void ReadErrorHandlerLoader();
	void ReadErrorHandlerUnloader();
	void ReadErrorHandlerEtc1();
	void ReadErrorHandlerEtc2();
	void ReadStatusHandlerLoader();
	void ReadStatusHandlerUnloader();
	
	LONG GetCurrentError(ERRORCOMMAND nError);

	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE);

	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsResetSwitch();
	BOOL IsSystemDoorBypass(BOOL bLoader);
	BOOL IsAnyMotorRun();
	BOOL IsLoadCartNoPCB();

	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);

	BOOL LoaderAlign();
	BOOL LoaderLoading();
	BOOL UnloadUnloading();
	BOOL LoaderInit();
	BOOL UnloaderInit();
	BOOL LoaderAlignLoading();
	
	BOOL MainReset(BOOL bOn);
	BOOL UnloaderPCBReset();
	BOOL LoaderPCBReset();

	BOOL LoaderCarrierElvPos();
	BOOL LoaderCarrierTablePos();
	BOOL UnloaderCarrierElvPos();
	BOOL UnloaderCarrierTablePos();

	BOOL LoaderPickerUpPos(int nNum);
	BOOL UnloaderPickerUpPos(int nNum);
	BOOL IsUnloaderNGBoxForward();
	BOOL IsUnloaderNGBoxBackward();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();

	BOOL UseRoll(BOOL bUse);
	BOOL UsePaper(BOOL bUse);
	PLC_BIT_SIGNAL GetMelsecIOStuct();

	BOOL m_bStatusStop; // Thread Stop Signal
	
	PLC_BIT_SIGNAL	m_NewPLCBitSignal;
	POSITION_INFO	m_NewPositionInfo;
	PLC_BIT_SIGNAL	m_OldPLCBitSignal;
	POSITION_INFO	m_OldPositionInfo;

	long			m_lWritePos[HANDLER_AXIS_MAX];
	BOOL			m_bIsInPosition[HANDLER_AXIS_MAX];
	double			m_dScale[HANDLER_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;
	BOOL			m_bPositionStop;		// Thread Stop Signal
	int				m_nInPositionCount;
	int				m_nInPositionError;

	int				m_nInposTimeCount;
};

#endif // !defined(AFX_DEVICEMELSECOSAN_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
