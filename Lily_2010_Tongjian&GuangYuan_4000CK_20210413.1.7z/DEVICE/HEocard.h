// HEocard.h: interface for the HEocard class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_)
#define AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#undef __LPC_FOR_3RD_AOD__
#undef __NEW_STRUCTURE__

#undef	__CUNGJU__			//  û�� ���  
#undef	__PUSAN_OLD_17__	//	�λ� 17ȣ��
#undef  __PUSAN_OLD_32__	// �λ� 32 ~ 34 ȣ�� 
#undef	__PUSAN1__			//  �λ� 18ȣ�� (0ȣ��) 
#undef	__KUNSAN_6__		//  ��� (6ȣ��~ , 23�� ����) ���� 
#undef  __KUNSAN_8__
#undef	__KUNSAN_1__			//  ��� (1ȣ��~ 5, 5�� ����) ����
#undef  __PUSAN_LDD__		// �λ� LDD ��� : undef USE_VISION_PRO
#undef	__PUSAN_2012__		//  �λ� ���� 5�� ( 1~5ȣ��), 11, 12, 13, 14, 35
#undef __KUNSAN_2012__		// ���� ���, �ѵ� �ż���
#undef	__HANDO_2012__		// �ѵ� �ż���
#undef	__CUNGJU_LG__		// �ѵ� �ż���
#undef	__OSAN_LG__			// ���� LG 
#undef __ANSAN_KCC__		// �Ȼ� KCC
#undef  __OSAN_LG_2013__		// ���� LG 2013 3RDAOD ���
#define __KUNSAN_2013__		// ��� 3RDAOD ��� 
#undef __CUNGJU_JASMINE_NEW__ // �λ� 2�� 36 (umac���) --> û�� ����
#undef __CUNGJU_JASMINE_OLD__ // �λ� 2�� 35 (mp���) --> û�� ����
#undef __KUNSAN_SAMSUNG_LARGE__ // ��� �Ｚ���� large panel
#undef  __JEUNGPYEONG_DNP_BGA__       // ����DNP BGA 1��

#ifdef __CUNGJU_JASMINE_NEW__
	#define __KUNSAN_1__
#endif

#ifdef  __PUSAN_2012__
	#define __PUSAN2__			//  �λ� ���� 5�� ( 1~5ȣ��),
#endif

#ifdef  __KUNSAN_2012__
	#define __PUSAN2__			//   ���� ���,
	#define	__3RDAOD__
#endif

#ifdef  __HANDO_2012__
	#define __PUSAN2__			//  �ѵ� �ż���
#endif

#ifdef  __CUNGJU_LG__
	#define __PUSAN2__			//  �ѵ� �ż���
#endif

#ifdef  __JEUNGPYEONG_DNP_BGA__
	#define __PUSAN2__			//  �ѵ� �ż���
#endif

#ifdef  __ANSAN_KCC__
	#define	__3RDAOD__
	#define __PUSAN2__			//  �Ȼ� KCC
#endif

#ifdef  __OSAN_LG_2013__
	#define	__3RDAOD__
	#define __PUSAN2__			//  ���� LG 3RDAOD
#endif


#ifdef  __KUNSAN_2013__
#define	__3RDAOD__
#define __PUSAN2__			//  �Ȼ� KCC
#endif


#ifdef __KUNSAN_SAMSUNG_LARGE__
	#define	__3RDAOD__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define __LPC_FOR_3RD_AOD__
	#define __NEW_STRUCTURE__
//	#define __LPC_FOR_3RD_AOD__
#endif

#ifdef  __CUNGJU__ 
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define	__3RDAOD__
	#define __PUSAN_OLD_17__
#endif

#ifdef  __PUSAN_OLD_17__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef  __PUSAN_OLD_32__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define	__3RDAOD__
#endif

#ifdef  __PUSAN1__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define	__3RDAOD__
#endif

#ifdef  __PUSAN2__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define	__3RDAOD__
#endif

#ifdef  __KUNSAN_6__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef  __KUNSAN_8__
	#define	__3RDAOD__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef  __KUNSAN_1__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef  __PUSAN_LDD__
	#define __USEAOD__
	#define	__3RDAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef  __CUNGJU_JASMINE_OLD__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
	#define __PUSAN_LDD__
#endif

#ifdef  __OSAN_LG__
	#define __USEAOD__
	#define __USE_DUALBAND_EOCARD__
#endif

#ifdef __USEAOD__	
	#ifdef __USE_DUALBAND_EOCARD__
		#ifndef __NEW_STRUCTURE__
			#include "HEocard5Pusan1Dualband.h"
		#else
			#include "HEocard5Pusan1DualbandNew.h"
		#endif
	#else
		#include "HEocard5Pusan1.h"
	#endif
#else
	#include "HEocard5.h"
#endif

class CCalibration;

class HEocard
{
public:
	MARKDATA m_MarkingData;
	virtual BOOL Create();
	virtual void Destroy();
	
	virtual BOOL Initialize();
	
	virtual void RunConfig();
	
	DOUBLE_POINT* m_pM1Asc;
	DOUBLE_POINT* m_pM2Asc;
	DOUBLE_POINT* m_pS1Asc;
	DOUBLE_POINT* m_pS2Asc;

	BOOL	m_b4Beam;
	int		m_nSP;
	int		m_nApertureMode;
	int		m_nBurstShotNo;

#ifdef __USEAOD__	
	#ifdef __USE_DUALBAND_EOCARD__
		#ifndef __NEW_STRUCTURE__
			HEocard5Pusan1Dualband* m_pEocard5;
		#else
			HEocard5Pusan1DualbandNew* m_pEocard5;
		#endif
	#else
		HEocard5Pusan1* m_pEocard5;
	#endif
#else
	HEocard5*	m_pEocard5;
#endif

	CCalibration*	m_Calibration;
	CCalibration*	m_SlaveCalibration;

public:
	BOOL SetLPCDataReadReady();
	BOOL CheckShotDutyLimitDummyOff(double dLimit);
	BOOL CheckShotDutyLimitDummyOn();
	BOOL CheckLaserDutyLimit();
	BOOL GetScannerError(int* nWarningNo, int* nAlarmNo, int* nMaxValue, int* nInposMissNo);
	BOOL ResetScannerPosErrorCount();
	BOOL SetScannerErrorLevel(double dWarning_mm, double dAlarm_mm);
	BOOL SetFieldSizeToEocard();
	BOOL SetMasterSlave(BOOL bMaster);

#ifndef __LPC_FOR_3RD_AOD__
	TDrill_LPCMonitor* GetLPCResult();
#else
	TLpc_Buffer* GetLPCResult();
#endif
	BOOL GetLPCErrorCount(int& nMinError, int& nMaxError);
	CPoint GetDownHoleFirePos(int nIndex);

	void UpdateLPCCalibrationFile(CString strPath);
	BOOL ChangeScannerAxis();
	BOOL SetVoltage(double d1st, double d2nd);
	BOOL GetApplyCalibrationFile(int nBeam);
	BOOL SetApplyCalibrationFile(int nBeam, BOOL bOn);
	void UpdateLaserCalibrationFile(CString strPath, BOOL b1stPanel);
	void GetLaserOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag);
	void LoadLaserCalibrationFile(CString strPath);
	double GetDummyFreeStart();
	BOOL SubCallStart(int nIndex, BOOL bDryrun);
	BOOL SubDownloadStop();
	BOOL SubDownloadReset(int nIndex);
	BOOL SetParameterCavityDuty(BOOL bShortLine);
	BOOL EndMarkDummy();
	BOOL StartMarkDummy();

	int IsStannbyShotRun();
	BOOL DrillStandbyShotStart(BOOL bStart, BOOL bUserStop = FALSE);
	BOOL DrillStandbyShotStartHole(BOOL bStart);
	BOOL StandbyParamSet();
	BOOL DummyParamSet(BOOL bPowervia = FALSE);
	BOOL DummyStopAndDataShotStart(BOOL bDryRun);
	BOOL DummyFieldStart(int nShotNo, BOOL bDryRun);
	BOOL IsFireCntOK(int& nDownCnt, int& nReadCnt);
	BOOL DownloadAOMProfile(int nTool, int nSubTool, CString strPath, int nMask);
	void ReloadDevice();
	BOOL FieldPreStart(int nShotNo = 0);
	BOOL FlyingModeEnable(BOOL bEnable);
	BOOL SetQuantaParam(int nFPK, int nCurrent);
	BOOL markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	BOOL GetAperturePos(int nIndex, int& nX, int& nY, int& nAction);
	BOOL DownloadShotDrillScannerParam(int nJumpDelayPlus = 0);
	BOOL DownloadOneAperture(CString str, int nTool);
	BOOL DownloadOneSubTool(int nTool, SUBTOOLDATA subTool,BOOL bSetPowerLevel = TRUE, BOOL bMakeLPCTable = FALSE);
	BOOL ResetSubToolForAllTool();
	void MoveToCenter();
	void DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd = FALSE);
	BOOL jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	BOOL LaserOnOff(BOOL bOn);
	void GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY);
	void SetDumperPosition(USHORT usDumpMX, USHORT usDumpMY, USHORT usDumpSX, USHORT usDumpSY );
	BOOL DownloadShotData(unsigned short usX,unsigned short usY,BOOL bIsMaster,BOOL bApplyCalibration,int nTCode);
	BOOL IsDSPBusy();
	BOOL ResetScannerStatusErrorCount();
	BOOL IsDrillTimeOutType();
	BOOL IsDrillTimeOut();
	BOOL IsMotorFault();
	BOOL IsScannerCableError();
	void MakeInpositionTable();

	void mark_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd = FALSE);
	void jump_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd = FALSE);
	void mark_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, BOOL bWaitEnd = FALSE);
	void jump_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, BOOL bWaitEnd = FALSE);

	BOOL DownloadDutyAOM(unsigned int nToolNo, unsigned int  nShotIndex, double dDuty, double dAOMDelay = 0, double dAOMDuty = 0);
	BOOL DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int  nBurstShot, unsigned int nTotalShot, BOOL bUseAperture);
	BOOL GetParameter(FParameter *Para);
	void CO2LaserMainShutter(BOOL bOn);
	void CO2LaserEnable(BOOL bEnable);
	BOOL LoadCalibrationFile(char* strM1path, char* strS1path = NULL, char* strM2path = NULL, char* strS2path = NULL );
	void GetASCPos(int &nX, int &nY, int nScannerNo);
	void GetApplyCalPos(int& nX, int& nY, int nScannerNo);
	void DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
				   int xS = HALF_LSB, int yS = HALF_LSB, BOOL bS1ApplyCal = FALSE,
				   int x_2 = HALF_LSB, int y_2 = HALF_LSB, BOOL bM2ApplyCal = FALSE,
				   int xS_2 = HALF_LSB, int yS_2 = HALF_LSB, BOOL bS2ApplyCal = FALSE, BOOL bWaitEnd = FALSE);
	BOOL ShotCountReset();
	int ReadHoleCount();
	BOOL DownloadProfileJumpDelay(int nIndex, int nValue);
	BOOL DownloadProfile(int nIndex, int nValue);
	BOOL MoveProfileReset(int nIndex);
	BOOL SetMoveProfileLength(int nIndex, int nLength);
	BOOL StatusOK(int nStatus);
	BOOL FieldStart(BOOL bDryRun);
	void ReStartMark();
	void PauseMark();
	void EStop();
	BOOL DownloadTcode(TCODE_INFO *pToolInfo);
	BOOL SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode);
	BOOL ShotDataReset();
	BOOL DownloadShotData4(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		unsigned short usMasterX2,
		unsigned short usMasterY2,
		unsigned short usSlaveX2,
		unsigned short usSlaveY2,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		BOOL bApplyCalibrationMaster2,
		BOOL bApplyCalibrationSlave2,
		int nTCode);
	/*
	BOOL DownloadShotData2(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode, 
		int nShotFilePosForLPCX = INT_MAX,
		int nShotFilePosForLPCY =INT_MAX);
	*/
	BOOL DownloadShotData2_Use_vm(	double dMasterX,
		double dMasterY,
		double dSlaveX,
		double dSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode, 
		int nShotFilePosForLPCX = INT_MAX,
		int nShotFilePosForLPCY =INT_MAX);





	BOOL DownloadShotDataDummy(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode);
	BOOL DownloadAperture(int nToolNo, int nX, int nY, int nAction);
	BOOL ApertureDataReset(int nToolNo);
	BOOL MoveDrillCenterPos();





	BOOL SetMinShotTime(int us);
	BOOL SetMinCycleTime(int us);
	BOOL SetSelfLineDivide(BOOL bOn);
	BOOL SetParameter(FParameter *pParam, double dAOMOffset = 0, int nMask = -1);
	BOOL InitCard();
	USHORT	GetFunction();
	BOOL SetFunction(USHORT Value);
	BOOL GetStatus(WORD* pStat) const;
	IEODriverDLPortIO* m_pDriver;
	HEocard();
	virtual ~HEocard();

};

#endif // !defined(AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_)
