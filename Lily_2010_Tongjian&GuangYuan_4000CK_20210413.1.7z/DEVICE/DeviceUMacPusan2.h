// DeviceUMacPusan2.h: interface for the DeviceUMacPusan2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEUMACPUSAN2_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEUMACPUSAN2_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//Block 1 
	//$61000
	UINT m_bRunReady:1;					// 0
	UINT m_bMainRunReady:1;				// 1 
	UINT m_bPLCAlive:1;					// 2
	UINT m_bMachineRunning:1;			// 3
	UINT m_bManualMode:1;				// 4
	UINT m_bAutoMode:1;					// 5
	UINT m_bSafteyMode:1;				// 6
	UINT m_bMPGMode:1;					// 7
	UINT m_bPCWorkStart:2;				// 8 ~ 9
	UINT m_bDoorInterlockBypass:1;		// 10
	UINT m_b1stTablePCBExist:1;			// 11
	UINT m_b2ndTablePCBExist:1;			// 12
	UINT m_bMainInitialEnd:1;			// 13
	UINT m_bMainInitializing:1;			// 14
	UINT m_bMainStationAlarm:17;		// 15 ~ 31

	//$61001
	UINT m_bXInitialEnd:1;				// 0
	UINT m_bXInitializing:1;			// 1 
	UINT m_bYInitialEnd:1;				// 2
	UINT m_bYInitializing:1;			// 3
	UINT m_bZ1InitialEnd:1;				// 4
	UINT m_bZ1Initializing:1;			// 5 
	UINT m_bZ2InitialEnd:1;				// 6
	UINT m_bZ2Initializing:1;			// 7
	UINT m_bM1InitialEnd:1;				// 8
	UINT m_bM1Initializing:3;			// 9 ~ 11
	UINT m_bC1InitialEnd:1;				// 12 
	UINT m_bC1Initializing:1;			// 13
	UINT m_bC2InitialEnd:1;				// 14
	UINT m_bC2Initializing:17;			// 15 ~ 31

	//$61002
	UINT m_bXInposition:1;				// 0
	UINT m_bXRun:1;						// 1
	UINT m_bYInposition:1;				// 2
	UINT m_bYRun:1;						// 3
	UINT m_bZ1Inposition:1;				// 4
	UINT m_bZ1Run:1;					// 5
	UINT m_bZ2Inposition:1;				// 6
	UINT m_bZ2Run:1;					// 7
	UINT m_bM1Inposition:1;				// 8
	UINT m_bM1Run:3;					// 9 ~ 11
	UINT m_bC1Inposition:1;				// 12  
	UINT m_bC1Run:1;					// 13
	UINT m_bC2Inposition:1;				// 14
	UINT m_bC2Run:17;					// 15 ~ 31

	//$61003
	UINT m_bXInTargetPosition:1;		// 0
	UINT m_bYInTargetPosition:2;		// 1 ~ 2
//	UINT m_bXYInRemovePosition:1;		// 2
	UINT m_bXYInLoadPosition:1;			// 3
	UINT m_bXYInUnload1Position:1;		// 4
	UINT m_bXYInUnload2Position:1;		// 5
	UINT m_bZ1InTargetPosition:1;		// 6
	UINT m_bZ2InTargetPosition:1;		// 7
	UINT m_bM1InTargetPosition:2;		// 8 ~ 9
	UINT m_bC1InTargetPosition:1;		// 10 
	UINT m_bC2InTargetPosition:21;		// 11 ~ 31

	//$61004
	UINT m_bLoaderRunReady:1;			// 0
	UINT m_bLoaderAlignTablePCBExist:2;	// 1
//	UINT m_bLoaderAlignReady:1;			// 2
	UINT m_bLoaderAligning:1;			// 3
	UINT m_bLoaderAlignEnd:1;			// 4
	UINT m_bPCBLoading:1;				// 5
	UINT m_bPCBLoadEnd:1;				// 6
	UINT m_bPCBLoadRequestReady:1;		// 7
	UINT m_bLoaderPicker1PCBExist:1;	// 8
	UINT m_bLoaderPicker2PCBExist:1;	// 9
	UINT m_bLoaderCartNoPCB:3;			// 10 ~ 12
	UINT m_bLoaderInitialEnd:1;			// 13
	UINT m_bLoaderInitialing:1;			// 14
	UINT m_bLoaderAlarm:17;				// 15 ~ 31

	//$61005
	UINT m_bLCInitialEnd:1;				// 0
	UINT m_bLCInitialing:1;				// 1
	UINT m_bLCInposition:1;				// 2
	UINT m_bLCRun:1;					// 3
	UINT m_bLCInCartPosition:1;			// 4
	UINT m_bLCInUnloadPosition:1;		// 5
	UINT m_bLCInAlignPosition:1;		// 6
#if defined ( __OSAN_LG_2013__) || defined (__ANSAN_KCC__)
	UINT m_bLCInAlignPosition2:1;		// 7
	UINT m_bLCInCartPosition2:24;       // 8 ~ 31
#else
	UINT m_bLCInOriginPosition:1;       // 7 
	UINT m_bLCInReadyPosition:24;		// 8 ~ 31
#endif

	//$61006 ~ $61007
	int m_61006Space[2];

	//$61008
	UINT m_bUnloaderRunReady:1;			// 0
	UINT m_bUnloaderAlignTablePCBExist:1;// 1
	UINT m_bSpare61008:2;				// 2,3	
//	UINT m_bPCBUnloadReady:1;			// 4
	UINT m_bPCBUnloading:1;				// 4
	UINT m_bPCBUnloadEnd:1;				// 5
	UINT m_bSpare61008_2:2;				// 6,7
//	UINT m_bPCBLoadRequest:1;			// 7
	UINT m_bUnloader1PCBExist:1;		// 8
	UINT m_bUnloader2PCBExist:1;		// 9
	UINT m_bUnloaderCartFull:1;			// 10
	UINT m_bSpare61008_3:2;				// 11,12
	UINT m_bUnloaderInitialEnd:1;		// 13
	UINT m_bUnloaderInitialing:1;		// 14
	UINT m_bUnloaderAlarm:1;			// 15
	UINT m_bSpare61008_4:16;			// 16 ~ 31

	//$61009
//	int m_61009Space;

	UINT m_bUCInitialEnd:1;				// 0
	UINT m_bUCInitialing:1;				// 1
	UINT m_bUCInposition:1;				// 2
	UINT m_bUCRun:1;					// 3
	UINT m_bUCInLoadPosition:1;			// 4
	UINT m_bUCInCartPosition:1;			// 5
	UINT m_bUCInAlignPosition:1;		// 6
	UINT m_bUCInOriginPosition:25;		// 7 ~ 31

	//$6100A ~ $6100B
	int m_6100ASpace[2];

	//$6100C
	UINT m_bEMStopSW:1;					// 0
	UINT m_bLaserPowerOn:1;				// 1
	UINT m_bServoPowerOn:1;				// 2
	UINT m_bTableVacuumMotorRunStatus:1;// 3
	UINT m_bTableVacuumFanRunStatus:1;	// 4
	UINT m_bResetSW:1;					// 5
	UINT m_bInitializeSW:1;				// 6
	UINT m_bManualModeSW:1;				// 7
	UINT m_bAutoModeSW:1;				// 8
	UINT m_bExternalLaserShotSW:1;		// 9
	UINT m_bFrontDoorSW:1;				// 10
	UINT m_bRearDoorSW:2;				// 11 ~ 12
	UINT m_bMainAirSW:1;				// 13
	UINT m_bTableVacuumPressSW1:1;		// 14
	UINT m_bTableVacuumPressSW2:17;		// 15 ~ 31

	//$6100D
	UINT m_bLaserShutter1Ext:1;			// 0
	UINT m_bLaserShutter1Ret:1;			// 1
	UINT m_bLaserShutter2Ext:1;			// 2
	UINT m_bLaserShutter2Ret:1;			// 3
	UINT m_bHeightSensorUp:1;			// 4
	UINT m_bHeightSensorDown:1;			// 5
	UINT m_bHeightSensor2Up:1;			// 6
	UINT m_bHeightSensor2Down:1;		// 7
	UINT m_bChillerOnCheck:1;			// 8
	UINT m_bChillerOnError:1;			// 9
	UINT m_bMPGAxisSelect1:1;			// 10
	UINT m_bMPGAxisSelect2:1;			// 11
	UINT m_bMPGAxisSelect3:1;			// 12
	UINT m_bMPGFeedSelect1:1;			// 13
	UINT m_bMPGFeedSelect2:1;			// 14
	UINT m_bDustSuctionError:17;		// 15 ~ 31

	//$6100E
	UINT m_bLoaderCartClampSW:1;		// 0
	UINT m_bLoaderCartUnclampSW:1;		// 1
	UINT m_bLoaderDoorSW:1;				// 2
	UINT m_bLoaderElvAlarm:1;			// 3
	UINT m_bLoaderElvPositiveLimit:1;	// 4
	UINT m_bLoaderElvNegativeLimit:1;	// 5
	UINT m_bLoaderElvOrigin:1;			// 6
	UINT m_bLoaderElvLevelCheck:1;		// 7
	UINT m_bLoaderPick1Pad1Up:1;		// 8
	UINT m_bLoaderPick1Pad1Down:1;		// 9
	UINT m_bLoaderPick1Pad2Down:1;		// 10
	UINT m_bLoaderPick2Pad1Up:1;		// 11
	UINT m_bLoaderPick2Pad1Down:1;		// 12
	UINT m_bLoaderPick2Pad2Down:1;		// 13
	UINT m_bLoaderCartClampUp:1;		// 14
	UINT m_bLoaderCartClampDown:17;		// 15 ~ 31

	//$6100F
	UINT m_bLoaderCartDetector:1;		// 0
	UINT m_bLoaderElvSheetDetector:1;	// 1
	UINT m_bLoaderAlignGuideForward:1;	// 2
	UINT m_bLoaderAlignGuideBackward:1;	// 3
	UINT m_bLoaderAlignTblForward:1;	// 4
	UINT m_bLoaderAlignTblBackward:1;	// 5
	UINT m_bLoaderPick1Detector:1;		// 6 
	UINT m_bLoaderPick2Detector:1;		// 7 
	UINT m_bLoaderPicker1Vacuum1:1;		// 8
	UINT m_bLoaderPicker2Vacuum1:1;		// 9
	UINT m_bLoaserAlignTablePCBSen:1;   // 10
	UINT m_bLoaderPickerVibratorDown:1; // 11
	UINT m_bLoaderPicker1LeftPCBDetect:1;// 12
	UINT m_bLoaderPicker1RightPCBDetect:1;// 13
	UINT m_bLoaderPicker2LeftPCBDetect:1;// 14
	UINT m_bLoaderPicker2RightPCBDetect:17;// 15~ 31

	//$61010
	UINT m_bUnloaderCartClampSW:1;		// 0
	UINT m_bUnloaderCartUnclampSW:1;		// 1
	UINT m_bUnloaderDoorSW:1;			// 2
	UINT m_bUnloaderElvAlarm:1;			// 3
	UINT m_bUnloaderElvPositiveLimit:1;	// 4
	UINT m_bUnloaderElvNegativeLimit:1;	// 5
	UINT m_bUnloaderElvOrigin:1;		// 6
	UINT m_bUnloaderElvLevelCheck:1;	// 7
	UINT m_bUnloaderPick1Pad1Up:1;		// 8
	UINT m_bUnloaderPick1Pad1Down:1;	// 9
	UINT m_bUnloaderPick1Pad2Down:1;	// 10
	UINT m_bUnloaderPick2Pad1Up:1;		// 11
	UINT m_bUnloaderPick2Pad1Down:1;	// 12
	UINT m_bUnloaderPick2Pad2Down:1;	// 13
	UINT m_bUnloaderCartClampUp:1;		// 14
	UINT m_bUnloaderCartClampDown:17;	// 15 ~ 31

	//$61011
	UINT m_bUnloaderCartDetector:1;		// 0
	UINT m_bUnloadElvSheetDectect:5;	// 1 ~ 5
	UINT m_bUnloaderPick1Detector:1;	// 6
	UINT m_bUnloaderPick2Detector:1;	// 7
	UINT m_bUnloaderPicker1Vacuum1:1;	// 8
	UINT m_bUnloaderPicker2Vacuum1:1;	// 9
	UINT m_bUnloaserAlignTablePCBSen:1; // 10
	UINT m_bUnloaderNGBoxForward:1; // 11
	UINT m_bUnloaderNGBoxBackward:1; // 12
	UINT m_bUnloaderNGBoxPNLCheck:19; //13 ~ 32



	//$61012
	UINT m_bLaserPass1Up:1;				// 0
	UINT m_bLaserPass1Down:1;			// 1
	UINT m_bLaserPass2Up:1;				// 2
	UINT m_bLaserPass2Down:1;			// 3
	UINT m_bTopHatForwordSensor:1;		// 4
	UINT m_bTopHatBackwordSensor:1;		// 5
	UINT m_bPowerDetectorExt:1;			// 6
	UINT m_bPowerDetectorRet:1;			// 7
	UINT m_bSutcionHoodOpen:1;			// 8
	UINT m_bSutcionHoodClose:1;			// 9
	UINT m_bTableClamp1Up:1;			// 10
	UINT m_bTableClamp1Down:1;			// 11
	UINT m_bTableClamp2Up:1;			// 12
	UINT m_bTableClamp2Down:19;			// 13 ~ 31

	//$61013
	UINT m_bLaserSystemWarning:1;		// 0
	UINT m_bWaterFlowSensorError:1;		// 1
	UINT m_bLaserOverTempFault:1;		// 2
	UINT m_bB1ServoDriveAlarm:1;		// 3
	UINT m_bB2ServoDriveAlarm:1;		// 4
	UINT m_bMaskAxisServoDriveAlarm:27;	// 5 ~ 31

//	int m_61013Space[1];

	//$61014
	UINT m_bResetSWLamp:1;				// 0
	UINT m_bInitializeSWLamp:1;			// 1
	UINT m_bManualModeSWLamp:1;			// 2
	UINT m_bAutoModeSWLamp:1;			// 3
	UINT m_bTowerRedLamp:1;				// 4
	UINT m_bTowerYellowLamp:1;			// 5
	UINT m_bTowerGreenLamp:1;			// 6
	UINT m_bTowerBuzzer:1;				// 7
	UINT m_bMPGLamp:1;					// 8
	UINT m_bExternalLaserSWLamp:1;		// 9
	UINT m_bFluorescentLamp:1;			// 10
	UINT m_bFrontDoorLockSol:1;			// 11
	UINT m_bRearDoorLockSol:1;			// 12
	UINT m_bDoorInterlockBypassSen:1;	// 13 no use
	UINT m_bChiller:1;					// 14
	UINT m_bDoorInterlockLamp:17;		// 15 ~ 31

	//$61015
	UINT m_bTableVacuumMotorOn:1;		// 0
	UINT m_bTableVacuumFanOn:1;			// 1
	UINT m_bTableVacuumPumpSol1:1;		// 2
	UINT m_bTableVacuumPumpSol2:1;		// 3
	UINT m_bTable12VacuumBypassSol:1;	// 4
	UINT m_b61015Spare2:1;				// 5
	UINT m_bLaserShutter1ExtSol:1;		// 6
	UINT m_bLaserShutter1RetSol:1;		// 7
	UINT m_bLaserShutter2ExtSol:1;		// 8
	UINT m_bLaserShutter2RetSol:1;		// 9
	UINT m_bHeightSensorUpSol:1;		// 10
	UINT m_bHeightSensorDownSol:1;		// 11
	UINT m_bPowerDetectorFwdBwdSol:1;	// 12
	UINT m_bTopHatFwdBwdSol:1;			// 13
	UINT m_bLaserBeamPath1UpDown:1;		// 14
	UINT m_bLaserBeamPath2UpDown:17;		// 15 ~ 31

	//$61016
	UINT m_bLoadCartClampLamp:1;		// 0
	UINT m_bLoadCartUnClampLamp:1;		// 1
	UINT m_bLoadElevatorUp:1;			// 2
	UINT m_bLoadElevatorDown:1;			// 3
	UINT m_bLoadPicker1VacuumOn:1;	// 4
	UINT m_bLoadPicker1VacuumBlowerSol:1;// 5
	UINT m_bLoadPicker2VacuumOn:1;	// 6
	UINT m_bLoadPicker2VacuumBlowerSol:1;// 7
	UINT m_bLoadPicker1Pad1Up:1;		// 8
	UINT m_bLoadPicker1Pad1Down:1;		// 9
	UINT m_bLoadPicker1Pad2Up:1;		// 10
	UINT m_bLoadPicker1Pad2Down:1;		// 11
	UINT m_bLoadPicker2Pad1Up:1;		// 12
	UINT m_bLoadPicker2Pad1Down:1;		// 13
	UINT m_bLoadPicker2Pad2Up:1;		// 14
	UINT m_bLoadPicker2Pad2Down:17;		// 15 ~ 31

	//$61017
	UINT m_bLoaderPickerVibrator:1;			// 0
	UINT m_bLoadCartClampUnclampSol:1;		// 1
	UINT m_bLoadAlignTableFwdBwd:1;			// 2
	UINT m_bLoadAlignGuideFwdBwd:4;			// 3 ~ 6
	UINT m_bPCBGuideAirBlowerSol:25;		// 7 ~ 31

	//$61018
	UINT m_bUnloadCartClampLamp:1;			// 0
	UINT m_bUnloadCartUnClampLamp:1;		// 1
	UINT m_bUnloadElevatorUp:1;				// 2
	UINT m_bUnloadElevatorDown:1;			// 3
	UINT m_bUnloadPicker1VacuumOn:1;		// 4
	UINT m_bUnloadPicker1VacuumBlowerSol:1;	// 5
	UINT m_bUnloadPicker2VacuumOn:1;		// 6
	UINT m_bUnloadPicker2VacuumBlowerSol:1;	// 7
	UINT m_bUnloadPicker1Pad1Up:1;			// 8
	UINT m_bUnloadPicker1Pad1Down:1;		// 9
	UINT m_bUnloadPicker1Pad2Up:1;			// 10
	UINT m_bUnloadPicker1Pad2Down:1;		// 11
	UINT m_bUnloadPicker2Pad1Up:1;			// 12
	UINT m_bUnloadPicker2Pad1Down:1;		// 13
	UINT m_bUnloadPicker2Pad2Up:1;			// 14
	UINT m_bUnloadPicker2Pad2Down:17;		// 15 ~ 31

	//$61019
	UINT m_bUnloadCartClampUnclampSol:32;	// 0 ~ 31
	
	//$6101A
	UINT m_bLeftTableVacuumOn:1;			// 0
	UINT m_bRightTableVacuumOn:1;			// 1
	UINT m_bSuctionHoodAirOpenClose:1;		// 2
	UINT m_bLeftTableICVacuumOn:1;			// 3
	UINT m_bRightTableICVacuumOn:1;			// 4
	UINT m_bSuctionHoodAirBlowerSol:3;		// 5 ~ 7
	UINT m_bWorkingTableClamp1UpDownSol:1;	// 8
	UINT m_bWorkingTableClamp2UpDownSol:23;	// 9 ~ 31

	//$6101B ~ $6101F 
	//int m_6101BSpare[5];
	UINT m_bAOMPowerOnOff:1;				// 0
	UINT m_bScannerOn:1;					// 1
	UINT m_6101BSpare:8;					// 2 ~ 9
	UINT m_6101BSpare2:22;					//10 ~ 31

	int m_6102BSpare[4];

	//$61020
	UINT m_bXFault:1;						// 0
	UINT m_bXFollowError:1;					// 1
	UINT m_bXOpenLoop:1;					// 2
	UINT m_bXPositiveLimitOver:1;			// 3
	UINT m_bXNegativeLimitOver:1;			// 4
	UINT m_bXHomeTimeOver:1;				// 5
	UINT m_bOverSpeedErr:1;					// 6
	UINT m_bXServoTempOver:1;				// 7
	UINT m_bYFault:1;						// 8
	UINT m_bYFollowError:1;					// 9
	UINT m_bYOpenLoop:1;					// 10
	UINT m_bYPositiveLimitOver:1;			// 11
	UINT m_bYNegativeLimitOver:1;			// 12
	UINT m_bYHomeTimeOver:2;				// 13 ~ 14
	UINT m_bYServoTempOver:17;				// 15 ~ 31

	//$61021
	UINT m_bZ1Fault:1;						// 0
	UINT m_bZ1FollowError:1;				// 1
	UINT m_bZ1OpenLoop:1;					// 2
	UINT m_bZ1PositiveLimitOver:1;			// 3
	UINT m_bZ1NegativeLimitOver:1;			// 4
	UINT m_bZ1HomeTimeOver:3;				// 5 ~ 7
	UINT m_bZ2Fault:1;						// 8
	UINT m_bZ2FollowError:1;				// 9
	UINT m_bZ2OpenLoop:1;					// 10
	UINT m_bZ2PositiveLimitOver:1;			// 11
	UINT m_bZ2NegativeLimitOver:1;			// 12
	UINT m_bZ2HomeTimeOver:19;				// 13 ~ 31

	//$61022
	UINT m_bM1Fault:1;						// 0
	UINT m_bM1FollowError:1;				// 1
	UINT m_bM1OpenLoop:1;					// 2
	UINT m_bM1PositiveLimitOver:1;			// 3
	UINT m_bM1NegativeLimitOver:1;			// 4
	UINT m_bM1HomeTimeOver:1;				// 5
	UINT m_bM1ServoError:26;				// 6 ~ 31

	//$61023
	UINT m_bC1Fault:1;						// 0 no use
	UINT m_bC1FollowError:1;				// 1
	UINT m_bC1OpenLoop:1;					// 2
	UINT m_bC1PositiveLimitOver:1;			// 3
	UINT m_bC1NegativeLimitOver:1;			// 4
	UINT m_bC1HomeTimeOver:1;				// 5
	UINT m_bC1ServoError:2;					// 6 ~ 7
	UINT m_bC2Fault:1;						// 8
	UINT m_bC2FollowError:1;				// 9
	UINT m_bC2OpenLoop:1;					// 10
	UINT m_bC2PositiveLimitOver:1;			// 11
	UINT m_bC2NegativeLimitOver:1;			// 12
	UINT m_bC2HomeTimeOver:1;				// 13
	UINT m_bC2ServoError:18;				// 14 ~ 31

	//$61024
	UINT m_bEmergencyStopAlarm:1;				// 0
	UINT m_bServoPowerOffAlarm:1;				// 1
	UINT m_bMainStationInitialError:2;			// 2 ~ 3
//	UINT m_bPCAliveOffError:1;					// 3
	UINT m_bFrontDoorOpenAlarm:1;				// 4
	UINT m_bRearDoorOpenAlarm:1;				// 5
	UINT m_bMPGOnAlarm:1;						// 6
	UINT m_bLaserPowerOffAlarm:1;				// 7
	UINT m_bMainAirAlarm:1;						// 8
	UINT m_bXYMoveDangerError:1;				// 9
	UINT m_bPCError:1;							// 10 no use
	UINT m_bDustCollectorError:1;					// 11 no use
	UINT m_b1stTablePCBExistError:1;			// 12
	UINT m_b1stTablePCBNotExistError:1;			// 13   no use
	UINT m_b2ndTablePCBExistError:1;			// 14
	UINT m_b2ndTablePCBNotExistError:17;		// 15 ~ 31  no use

	//$61025
	UINT m_bSuctionHoodAirOpenError:1;			// 0	
	UINT m_bSuctionHoodAirCloseError:3;			// 1 ~ 3
	UINT m_bLaserTophatFwdError:1;				// 4
	UINT m_bLaserTophatBwdError:1;				// 5 
	UINT m_bHeightSensor2UpError:1;				// 6
	UINT m_bHeightSensor2DownError:1;			// 7
	UINT m_b1stTableVacuumOnError:1;			// 8
	UINT m_b1stTableVacuumOffError:1;			// 9
	UINT m_b2ndTableVacuumOnError:1;			// 10
	UINT m_b2ndTableVacuumOffError:1;			// 11
	UINT m_b1stShutterCylinderOpenError:1;		// 12
	UINT m_b1stShutterCylinderCloseError:1;		// 13
	UINT m_b2ndShutterCylinderOpenError:1;		// 14
	UINT m_b2ndShutterCylinderCloseError:17;	// 15 ~ 31

	//$61026
	UINT m_bHeightSensorUpError:1;				// 0
	UINT m_bHeightSensorDownError:1;			// 1
	UINT m_bPowerDetectorShutterForwardError:1;	// 2
	UINT m_bPowerDetectorShutterBackwardError:1;// 3 
	UINT m_bBeamPassUpErr:1;				// 4
	UINT m_bBeamPassDownErr:1;					// 5
	UINT m_bBeamPass2UpErr:1;				// 6
	UINT m_bBeamPass2DownErr:1;					// 7
	UINT m_bTableClampUpError:1;				// 8
	UINT m_bTableClampDownError:1;				// 9
	UINT m_bTableClamp2UpError:1;				// 10
	UINT m_bTableClamp2DownError:21;				// 11 ~ 31
//	UINT m_bLaserSystemWarning:1;				// 12			//20130603������ bskim (PLC Ȯ��)	
//	UINT m_bLaserWaterFlowFault:1;				// 13			//20130603������ bskim (PLC Ȯ��)
//	UINT m_bLaserOverTempFaultErr:18;				// 14 ~ 31	//20130603������ bskim (PLC Ȯ��)

	//$61027
	UINT m_bXYStopError:1;						// 0
	UINT m_bZ1StopError:1;						// 1
	UINT m_bZ2StopError:1;						// 2
	UINT m_bM1StopError:2;						// 3 ~ 4
	UINT m_bC1StopError:1;						// 5
	UINT m_bC2StopError:3;						// 6 ~ 8
	UINT m_bXYMotionParamError:1;				// 9
	UINT m_bZ1MotionParamError:1;				// 10
	UINT m_bZ2MotionParamError:1;				// 11
	UINT m_bM1MotionParamError:2;				// 12 ~ 13
	UINT m_bC1MotionParamError:1;				// 14
	UINT m_bC2MotionParamError:17;				// 15 ~ 31

	//$61028
	UINT m_bLoaderInitialError:1;					// 0
	UINT m_bLoadLeftPickerPCBExistError:1;			// 1
	UINT m_bLoadLeftPickerPCBNotExistError:1;		// 2
	UINT m_bLoadRightPickerPCBExistError:1;			// 3
	UINT m_bLoadRightPickerPCBNotExistError:1;		// 4 
	UINT m_bLoadAlignTablePCBExistError:1;			// 5
	UINT m_bLoadAlignTablePCBNotExistError:1;		// 6
	UINT m_bLoadDoorOpenError:1;					// 7
	UINT m_bLoadLeftPCBTakeReadyError:1;			// 8
	UINT m_bLoadRightPCBTakeReadyError:1;			// 9
	UINT m_bLoaderPickerNotAllUp:1;					// 10
	UINT m_bLoaderProcessTimeOverError:1;			// 11
	UINT m_bSpare61028:3;							// 12 ~ 14
	UINT m_bLoaderPickerUnableDownError:17;			// 15 ~ 31

	//$61029
	UINT m_bLoadLeftPickerPad1UpError:1;		// 0
	UINT m_bLoadLeftPickerPad1DownError:1;		// 1
	UINT m_bLoadLeftPickerPad1Down2Error:2;		// 2 ~ 3
	UINT m_bLoadLeftPickerVacuumOnError:1;		// 4
	UINT m_bLoadLeftPickerVacuumOffError:2;		// 5 ~ 6
	UINT m_bLoadRightPickerPad1UpError:1;		// 7
	UINT m_bLoadRightPickerPad1DownError:1;		// 8
	UINT m_bLoadRightPickerPad1Down2Error:2;	// 9 ~ 10
	UINT m_bLoadRightPickerVacuumOnError:1;		// 11
	UINT m_bLoadRightPickerVacuumOffError:20;	// 12 ~ 31


	//$6102A
	UINT m_bLoadCartClampError:1;				// 0
	UINT m_bLoadCartUnClampError:1;				// 1
	UINT m_bLoadAlignSheetTableForwardError:1;	// 2
	UINT m_bLoadAlignSheetTableBackwardError:1;	// 3
	UINT m_bLoadAlignGuideForwardError:1;		// 4
	UINT m_bLoadAlignGuideBackwardError:1;		// 5
	UINT m_bLoadAlignTableMoveLeftError:1;		// 6
	UINT m_bLoadAlignTableMoveRightError:1;		// 7
	UINT m_bLoadElevatorMoveLoadLevelError:1;	// 8
	UINT m_bLoadElevatorMoveOriginError:1;		// 9
//	UINT m_bLoadElevatorSensorError:1;			// 10
	UINT m_bLoadElevatorAlarmError:1;			// 10
	UINT m_bLoadCartDetectSensorError:1;		// 11
	UINT m_bLoadElvAxisLimitError:1;			// 12
	UINT m_bLoadCarrierMoveCartPosError:1;		// 13
	UINT m_bLoadCarrierMoveLoadPosError:1;		// 14
	UINT m_bLoadCarrierMotionParamError:17;		// 15 ~ 31

	//$6102B
	UINT m_bLoadCarrierFault:1;					// 0
	UINT m_bLoadCarrierFollowingError:1;		// 1
	UINT m_bLoadCarrierOpenLoop:1;				// 2
	UINT m_bLoadCarrierPositiveLimit:1;			// 3
	UINT m_bLoadCarrierNegativeLimit:1;			// 4
	UINT m_bLoadCarrierHomeTimeOver:1;			// 5
	UINT m_bLoadCarrierMoveAlignPosError:2;		// 6
	UINT m_bLoadCarrierAxisStopError:1;
	UINT m_bLoadLeftPickerFallPCBError:23;
//	UINT m_b6102BSpare:2;						// 7 ~ 8
//	UINT m_bLoadEStopError:5;					// 9 ~ 13
//	UINT m_bLDStopRNError:1;					// 14
//	UINT m_bLDStopAfterRunError:17;				// 15 ~ 31

	////////////////////-----
	//$6102C
	UINT m_bUnloaderInitialError:1;					// 0
	UINT m_bUnloadLeftPickerPCBExistError:1;		// 1
	UINT m_bUnloadLeftPickerPCBNotExistError:1;		// 2
	UINT m_bUnloadRightPickerPCBExistError:1;		// 3
	UINT m_bUnloadRightPickerPCBNotExistError:1;	// 4 
	UINT m_bUnloadTablePCBExistError:1;				// 5
	UINT m_bUnloadTablePCBNotExistError:1;			// 6
	UINT m_bUnloadDoorOpenError:1;					// 7
	UINT m_bUnloadLeftPCBTakeReadyError:1;			// 8
	UINT m_bUnloadRightPCBTakeReadyError:1;			// 9
	UINT m_bUnloaderPickerNotAllUp:5;				// 10 ~ 14
	UINT m_bUnloadPickerUnableDownError:17;			// 15 ~ 31
	
	//$6102D
	UINT m_bUnloadLeftPickerPad1UpError:1;			// 0
	UINT m_bUnloadLeftPickerPad1DownError:1;		// 1
	UINT m_bUnloadLeftPickerPad1Down2Error:2;		// 2 ~ 3
	UINT m_bUnloadLeftPickerVacuumOnError:1;		// 4
	UINT m_bUnloadLeftPickerVacuumOffError:2;		// 5 ~ 6
	UINT m_bUnloadRightPickerPad1UpError:1;			// 7
	UINT m_bUnloadRightPickerPad1DownError:1;		// 8
	UINT m_bUnloadRightPickerPad1Down2Error:2;		// 9 ~ 10
	UINT m_bUnloadRightPickerVacuumOnError:1;		// 11
	UINT m_bUnloadRightPickerVacuumOffError:20;		// 12 ~ 31
	
	//$6102E
	UINT m_bUnloadCartClampError:1;					// 0
	UINT m_bUnloadCartUnClampError:1;				// 1 
	UINT m_bUnloadAlignTableMoveLeftError:1;		// 2
	UINT m_bUnloadAlignTableMoveRightError:1;		// 3
	UINT m_bUnloadNGBoxForwardError:1;				// 4
	UINT m_bUnloadNGBoxBackwardError:3;				// 5 !7
	UINT m_bUnloadElevatorMoveLoadLevelError:1;		// 8
	UINT m_bUnloadElevatorMoveOriginError:1;		// 9
//	UINT m_bUnloadElevatorSensorError:1;			// 10
	UINT m_bUnloaderElevatorAlarmError:1;			// 11
	UINT m_bUnloadCartDetectSensorError:1;			// 11
	UINT m_bUnloadElvAxisLimitError:1;				// 12
	UINT m_bUnloadCarrierMoveLoadPosError:1;		// 13
	UINT m_bUnloadCarrierMoveCartPosError:1;		// 14
	UINT m_bUnloadCarrierMotionParamError:17;		// 15 ~ 31
	
	//$6102F
	UINT m_bUnloadCarrierFault:1;					// 0
	UINT m_bUnloadCarrierFollowingError:1;			// 1
	UINT m_bUnloadCarrierOpenLoop:1;				// 2
	UINT m_bUnloadCarrierPositiveLimit:1;			// 3
	UINT m_bUnloadCarrierNegativeLimit:1;			// 4
	UINT m_bUnloadCarrierHomeTimeOver:1;			// 5
	UINT m_bUnloadCarrierMoveAlignPosError:2;		// 6 7
	UINT m_bUnloadCarrierAxisStopError:24;
//	UINT m_bUDStopRNError:1;						// 14
//	UINT m_bUDStopAfterRunError:17;					// 15 ~ 31

	//$61030
	int m_b61030Space;
//	UINT m_bSpare61030_1:1;							// 0
//	UINT m_bCartNotClamped:31;						// 1 ~ 31
//	UINT m_bLoaderNoPCB:1;							// 1
//	UINT m_bLoadRightPickerVacuumOnError:1;			// 2
//	UINT m_bSpare61030_2:29;						// 3 ~ 31

	//$61031
	int m_61031Space;

	//$61032
	UINT m_b61032Space:3;							// 0 ~ 2
	UINT m_bNotReadyLoadLeftPCBUpWarn:1;			// 3
	UINT m_bNotReadyLoadElevatorUpWarn:1;			// 4
	UINT m_bNotReadyLoadRightPCBUpWarn:1;			// 5
	UINT m_bNoPCB:2;								// 6 ~ 7
	UINT m_bAlignReadyBeforePCBAlignWarn:24;		// 8 ~ 31

	//$61033
	UINT m_b61033Space:3;							// 0 ~ 2
	UINT m_bNotReadyUnloadLeftPCBUpWarn:1;			// 3
	UINT m_bNotReadyUnloadElevatorUpWarn:1;			// 4
	UINT m_bNotReadyUnloadRightPCBUpWarn:27;		// 5 ~ 31

	//$61034 ~ $6103F
	int m_61034Space[12];

	//$61040 ~ $61041
	int m_nXCommandPos;
	int m_nXActualPos;

	//$61042 ~ $61047
	int m_61042Spare[6];

	//$61048 ~ $61049
	int m_nYCommandPos;
	int m_nYActualPos;

	//$6104A ~ $6104F
	int m_6104ASpare[6];

	//$61050 ~ $61051
	int m_nZ1CommandPos;
	int m_nZ1ActualPos;
	
	//$61052 ~ $61057
	int m_61052Spare[6];
	
	//$61058 ~ $61059
	int m_nZ2CommandPos;
	int m_nZ2ActualPos;
	
	//$6105A ~ $6105D
	int m_6105ASpare[4];
	
	//$6105 ~ $6105F
	int	m_nWaterFlowValue1;
	int	m_nWaterFlowValue2;

	//$61060 ~ $61061
	int m_nM1CommandPos;
	int m_nM1ActualPos;
	
	//$61062 ~ $61063
	int m_nLaserPassUp;
	int m_nLaserPassDown;

	//$61064 ~ $61065
	int m_nM2CommandPos;
	int m_nM2ActualPos;

	//$61066 ~ $61067
	int m_nLaserPassFwd;
	int m_nLaserPassBwd;

	//$61068 ~ $61069
	int m_61068Spare[2];
	
	//$6106A ~ $6106B
	int m_6106ASpare[2];
	
	//$6106C ~ $6106D
	int m_nC1CommandPos;
	int m_nC1ActualPos;
//	int m_nC2CommandPos; 
//	int m_nC2ActualPos;
	
	//$6106E ~ $6106F
//	int m_6106ESpare[2];

	int m_nC2CommandPos; 
	int m_nC2ActualPos;

	/////////////////////////////////////////
	//$61070 ~ $61071
	int m_nLoadCarrierCommandPos;
	int m_nLoadCarrierActualPos;
	
	//$61072
	int m_61072Spare;
	
	//$61073 ~ $61074
	int m_nLoadLeftPickerLevel;
	int m_nLoadRightPickerLevel;
	
	//$61075 ~ $61077
	int m_61075Spare[3];
	
	//$61078 ~ $61079
	int m_nUnloadCarrierCommandPos;
	int m_nUnloadCarrierActualPos;
	
	//$6107A
	int m_6107ASpare;
	
	//$6107B ~ $6107C
	int m_nUnloadLeftPickerLevel;
	int m_nUnloadRightPickerLevel;
	
	} DpramReadPosition;

	
	typedef struct {
		///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
		//Block 1 
		//$61000
		int m_nXPos;
		int m_nYPos;
		int m_nZ1Pos;
		int m_nZ2Pos;
		int m_nMPos;
		int m_nB1Pos;
		int m_nB2Pos;
		
		int m_nXPosInpos;
		int m_nYPosInpos;
		int m_nZ1PosInpos;
		int m_nZ2PosInpos;
		int m_nMPosInpos;
		int m_nB1PosInpos;
		int m_nB2PosInpos;
	} InposRam;

typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//Block 1 
	//$61000
	// PLC->PC Input #1	Equipment		$61000
	int m_bHomingEQP;					// 0
} DpramWritePosition;

#define  PCB_NONE		0x00
#define  PCB_ALIGN		0x01
#define  PCB_LOADER		0x02

class DeviceUMacPusan2 : public CWnd  
{
public:
	static  UINT ThreadUMacStatus(LPVOID pParam);
	static UINT ThreadUMacInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceUMacPusan2();
	virtual ~DeviceUMacPusan2();

	/* Table IO Control -------------------------------------------------- */
	BOOL SetMoveIO(int nMoveAxis);
	BOOL IsCmdPosOK();
	BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE);
	int InPositionIO(int nAxis);
	/* Table IO Control end ---------------------------------------------- */

protected:
	int				m_nNoPCBCount;
	CWinThread*		m_thdStatus;
	CWinThread*		m_thdInPosition;		// Window Thread Inposition
	double			m_dMaskPosition[BEAMPATH_COUNT];
	double			m_dMaskPosition2[BEAMPATH_COUNT];
	int				m_nAxisMax;
	int				m_nMaskPos;
	int				m_nMaskPos2;
	LONG			m_lErrorIo;
	LONG			m_lErrorLoad;
	LONG			m_lErrorLoad2;
	LONG			m_lErrorLoad3;
	LONG			m_lErrorUnload;
	LONG			m_lErrorUnload2;
	LONG			m_lErrorUnload3;
	LONG			m_lErrorAligner;
	LONG			m_lErrorTableLimit;
	LONG			m_lErrorOtherLimit;
	LONG			m_lErrorTable;
	LONG			m_lErrorLaser;
	LONG			m_lErrorOthers;
	LONG			m_lErrorOthers2;
	LONG			m_lErrorOthers3;
	LONG			m_lErrorOthers4;
	BOOL			m_bCheckInposition;
	
	LONG			m_lStatusIO1;
	LONG			m_lStatusIO2;
	LONG			m_lStatusIO3;
	LONG			m_lStatusIO4;

public:
	BOOL GetLPCStatus();
	int ChangeMotorPosition(double dXPos, double dYPos);
	BOOL SetNextTATS(int nAxis, long nTA, long nTS);
	BOOL SetPreTATS(int nAxis, long nTA, long nTS);
	BOOL IsOrigin(int nAxis);
	BOOL MotorMoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2);
	BOOL MotorMoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2);
	BOOL SetServoOnOff(int nAxis, BOOL bOn);
	BOOL Connect(int nPortNo, long lBaudrate);
	BOOL Disconnect();
	BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL bTophat);
	BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bTophat);
	BOOL NoUseClamp(BOOL bNoUse);
	BOOL IsBMMotorHomeEnd();
	BOOL IsHandlerPartError(BOOL bLoader);
	BOOL GetTopHatStatus(BOOL bUp);
	BOOL SetOutportTableVacuum(BOOL bUseBTable);
	BOOL GetAOMAlarm();
	BOOL GetAOMStatus();
	BOOL SetAOMPowerON(BOOL bOn);
	BOOL HoodOpen(BOOL bOpen);
	BOOL IsHoodOK(BOOL bOpen);
	BOOL GetBeamPathStatus(BOOL bUp);
	BOOL GetResetSWStatus();
	BOOL GetScannerStatus();
	BOOL UnloaderCarrierAlignPos();
	BOOL LoaderCarrierCartPos();
	BOOL LoaderCarrierCartPos2();
	BOOL SetLimitYPos(double dPos);
	BOOL GetCurrentSuctionMotor();
	BOOL ScannerPower(BOOL bOn);
	BOOL MoveTophatShutter(BOOL bUp);
	void SetFixedMaskPos(double dPos);
	double GetMPosition(int nIndex);
	BOOL WriteLoadUnload(int nAdd, BOOL bOn);
	void SetResetCmd();
	void SetInitialCmd();
	BOOL IsFluorescentLampOn();
	BOOL IsOpticsDoorStop();
	BOOL IsMainDoorStop();
	BOOL IsSystemDoorBypass();
	UINT IsScannerFault();
	BOOL IsFlowWater();
	BOOL IsLaserSystemWarning();
	BOOL IsLaserOverTempFault();
	BOOL IsReady(int nAxis = -1);
	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsAnyMotorRun();
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsInPositionThread(int nAxis, BYTE nCommand);
	void ReadPosition();
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);
	BOOL GetCurrentHeight(BOOL bFirst, BOOL bDown);
	BOOL GetCurrentVacuumMotor(BOOL b1st);
	BYTE GetExternalLaser();
	BYTE GetCurrentSuction();
	BOOL GetCurrentAcrylSuction(BOOL b1st);
	BYTE GetCurrentUnloadDetect();
	BYTE GetCurrentLoadDetect();
	BYTE GetCurrentShutter2();
	BYTE GetCurrentShutter1();
	BYTE GetCurrentPowerMeter();
	BYTE GetCurrentEMStop();
	void SetCurrentCycle(BYTE cCycle);
	BYTE GetCurrentMode();
	void	ReadErrorIo();
	void	ReadErrorLoad1();
	void	ReadErrorLoad2();
	void	ReadErrorLoad3();
	void	ReadErrorUnload1();
	void	ReadErrorUnload2();
	void	ReadErrorUnload3();
	void	ReadErrorAligner();
	void	ReadErrorTableLimit();
	void	ReadErrorOtherLimit();
	void	ReadErrorTable();
	void	ReadErrorLaser();
	void	ReadErrorOthers();
	void	ReadErrorOthers2();
	void	ReadErrorOthers3();
	void	ReadErrorOthers4();
	void	ReadStatusIO1();
	void	ReadStatusIO2();
	void	ReadStatusIO3();
	void	ReadStatusIO4();
	LONG GetCurrentError(ERRORCOMMAND nError);
	BOOL Stop(int nAxis = -1);

	BOOL IsLoadCartNoPCB();
		
	BOOL SetDrillStatus(BOOL bDrilling);
	BOOL LoaderLoading();
	BOOL LoaderAlign();
	BOOL LoaderOrigin();
	BOOL LoaderElvOriginPos();
	BOOL LoaderElvLoadPos();
	BOOL LoaderCarrierAlignPos();
	BOOL LoaderCarrierAlignPos2();
	BOOL LoaderCarrierLoadPos();
	BOOL LoaderPicker1Init();
	BOOL LoaderPicker1Align();
	BOOL LoaderPicker1Load();
	BOOL LoaderPicker1P2();
	BOOL LoaderPicker2Init();
	BOOL LoaderPicker2Align();
	BOOL LoaderPicker2Load();
	BOOL LoaderPicker2P2();
	BOOL LoaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderVacuum1On();
	BOOL LoaderVacuum1Off();
	BOOL LoaderVacuum2On();
	BOOL LoaderVacuum2Off();
	BOOL LoaderBlow1On();
	BOOL LoaderBlow1Off();
	BOOL LoaderBlow2On();
	BOOL LoaderBlow2Off();
	BOOL LoaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsAlignerPCBExist();
	BOOL IsULAlignerPCBExist();
	BOOL IsLoader1Error();
	BOOL IsLoader2Error();
	BOOL IsAlignerError();
	BOOL IsULAlignerError();
	BOOL TablePCBReset();
	BOOL LoaderPCBReset();
	BOOL UnLoaderPCBReset();
	BOOL Loader1PCBExist(BOOL bOn);
	BOOL Loader2PCBExist(BOOL bOn);
	BOOL SendLoadCartNoPCB();
	BOOL AlignTablePCBExist(BOOL bOn);
	BOOL ULAlignTablePCBExist(BOOL bOn);
	BOOL LoaderPickerPad(int nPicker, int nPad, BOOL bUp);

	BOOL TableCalibration(BOOL bAxisX);

	BOOL TableClamp(BOOL bClamp, double dLimitY, BOOL bLeft);

	BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff);
	BOOL WriteOutputDWord(UINT nAddr, DWORD dwVal);

	BOOL TableLoadPos();
	BOOL TableUnloadPos(BOOL b1st = TRUE);

	BOOL GetCurrentTableClamp(BOOL b1st, BOOL bClamp);

	BOOL GetCurrentMotorSol();

	BOOL UnloadUnloading();
	BOOL UnloadOrigin();
	BOOL UnloaderElvOriginPos();
	BOOL UnloaderElvUnloadPos();
	BOOL UnloaderCarrierTablePos();
	BOOL UnloaderCarrierUnloadPos();
	BOOL UnloaderPicker1Init();
	BOOL UnloaderPicker1Table();
	BOOL UnloaderPicker1Unload();
	BOOL UnloaderPicker1P2();
	BOOL UnloaderPicker2Init();
	BOOL UnloaderPicker2Table();
	BOOL UnloaderPicker2Unload();
	BOOL UnloaderPicker2P2();
	BOOL UnloaderClampForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderVacuum1On();
	BOOL UnloaderVacuum1Off();
	BOOL UnloaderVacuum2On();
	BOOL UnloaderVacuum2Off();
	BOOL UnloaderBlow1On();
	BOOL UnloaderBlow1Off();
	BOOL UnloaderBlow2On();
	BOOL UnloaderBlow2Off();
	BOOL UnloaderTableForward();
	BOOL UnloaderTableBackward();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsUnloader1Error();
	BOOL IsUnloader2Error();
	BOOL Unloader1PCBExist(BOOL bOn);
	BOOL Unloader2PCBExist(BOOL bOn);
	BOOL UnloadTablePCBExist(BOOL bOn);
	BOOL UnloaderPickerPad(int nPicker, int nPad, BOOL bUp);

	BOOL Table1VacuumMotor(BOOL bOn);
	BOOL Table2VacuumMotor(BOOL bOn);

	BOOL TableVacuumSelect(BOOL bOn);

	BOOL IsTable1PCBExist();
	BOOL IsTable2PCBExist();
	BOOL IsTable1Error();
	BOOL IsTable2Error();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	

	BOOL MotorShutterAll(BOOL bOpenMaster = TRUE, BOOL bOpenSlave = TRUE);
	BOOL DownloadPosition(int nAxis, double dPosition);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetOrigin(int nAxis = -1);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);
	BOOL SetLimitZ(double dPosZ1Low, double dPosZ1High, double dPosZ2Low, double dPosZ2High, double dXMin, double dXMax);
	BOOL SetVibration(int nCount, double dDelay, int nLPTime); // Vibration Count & Delay
	BOOL SetOriginSpeed(long lSpeed[]);
	BOOL SetOriginSpeed(int nAxis, long lSpeed);
	BOOL SetSpeed(long lSpeed[]);
	BOOL SetSpeed(int nAxis, long lSpeed);
	BOOL SetOffset(double dOffset[]);
	BOOL SetOffset(int nAxis, double dOffset);
	void ReadStatus(BOOL bFirst);
	BOOL			m_bStatusStop;			// Thread Stop Signal
	void SetScale(int nAxis, double dScale);

	BOOL SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y);
	BOOL SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y, double dLoaderX2, double dLoaderY2);
	BOOL SetLoaderUnloaderPickerPos(double dLoaderCartPos, double dLoaderCartPos2, double dLoaderLoadPos, double dLoaderLoadPos2, double dLoaderAlignPos, double dUnloaderCartPos, double dUnloaderUnloadPos, double dUnloaderUnloadPos2, double dUnloaderAlignPos);
	
	BOOL	MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2,  double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL    MotorMoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bTophat);
	BOOL	MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL	MotorMoveAMC2(double dPosA1, double dPosA2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, BOOL bTophat);
	BOOL	MotorMoveAMC2(double dPosA1, double dPosA2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat);
	
	BOOL	MotorMoveAxis(int nAxis, double dPosition);
	BOOL	MotorMoveXY(double dPosX, double dPosY);
	BOOL	MotorMoveZ(double dPosZ1);
	BOOL	MotorMoveZ(double dPosZ1, double dPosZ2);
	BOOL	MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2);
	BOOL	MotorMoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MotorMoveM(int nMaskPos);
	BOOL	MotorMoveM(double dMaskPos);
	BOOL	MotorMoveMC(double dMaskPos, double dPosC);
	BOOL	MotorMoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat = FALSE);
	BOOL	IsLCinCartPos();
	BOOL	IsLCinCartPos2();
	BOOL	IsLCinLoadPos();
	BOOL	IsLCinOriginPos();
	BOOL	IsLCinReadyPos();
	BOOL	IsUCinCartPos();
	BOOL	IsUCinUnloadPos();
	BOOL	IsUCinOriginPos();
	BOOL	IsLCinAlignPos();
	BOOL	IsLCinAlignPos2();
	BOOL	IsUCinAlignPos();
	BOOL	IsLP1P1Up();
	BOOL	IsLP1P2Up();
	BOOL	IsLP2P1Up();
	BOOL	IsLP2P2Up();
	BOOL	IsULP1P1Up();
	BOOL	IsULP1P2Up();
	BOOL	IsULP2P1Up();
	BOOL	IsULP2P2Up();
	BOOL	IsLoaderAlignTableForward();
	BOOL	IsUnloaderAlignTableForward();
	BOOL	IsTableUnloadPosition();
	BOOL	IsLoaderCartClamp();
	BOOL	IsAlignSheetTableForward();
	BOOL	IsAlignGuideForward();
	BOOL	IsLoaderPicker1Vacuum();
	BOOL	IsLoaderPicker2Vacuum();
	BOOL	IsLoaderPicker1Blow();
	BOOL	IsLoaderPicker2Blow();
	BOOL	IsUnloaderCartClamp();
	BOOL	IsUnloaderPicker1Vacuum();
	BOOL	IsUnloaderPicker2Vacuum();
	BOOL	IsUnloaderPicker1Blow();
	BOOL	IsUnloaderPicker2Blow();
	BOOL	IsUnloaderNGBoxForward();
	BOOL	IsUnloaderNGBoxBackward();
	

	BOOL	IsSafetyMode();
	
	DpramReadPosition m_OldStatus;
	DpramReadPosition m_NewStatus;
	long			m_lWritePos[MOTOR_AXIS_MAX];
	BOOL			m_bIsInPosition[MOTOR_AXIS_MAX];
	double			m_dScale[MOTOR_AXIS_MAX];
	long			m_lSpeed[MOTOR_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;
	BOOL			m_bPositionStop;		// Thread Stop Signal
	int				m_nInPositionCount;
	BYTE			m_cCycleStart;
	int				m_nInPositionError;
	double			m_dFixedMaskPos;
	BOOL			m_bConnect;	
	BYTE			m_nPort;
	BOOL			m_bShowErrMsg; 
	BOOL			m_bOldM2;
	BOOL			m_bOldM3;
	BOOL			m_bReadStatus;
	BOOL	IsHandlerReady();
	BOOL	IsHandlerAlarm();
	BOOL	IsHandlerLotEnd();
	BOOL	IsHandler1stTableExist();
	BOOL	IsHandler2ndTableExist();
	BOOL	IsHandlerLoadReady();
	BOOL	IsHandlerLoadEnd();
	BOOL	IsHandlerLoadAlarm();
	BOOL	IsHandlerUnloadReady();
	BOOL	IsHandlerUnloadEnd();
	BOOL	IsHandlerUnloadAlarm();

	BOOL	MainReady(BOOL bOn);
	BOOL	MainAlarm(BOOL bOn);
	BOOL	MainStart(BOOL bOn);
	BOOL	MainStop(BOOL bOn);
	BOOL	MainReset(BOOL bOn);
	BOOL	MainUseTable(int nUseTable);
	BOOL	MainLoadReady(BOOL bOn);
	BOOL	MainLoadEnd(BOOL bOn);
	BOOL	MainUnloadReady(BOOL bOn);
	BOOL	MainUnloadEnd(BOOL bOn);
	BOOL	MainPCBExist(int nPCBExist);
	BOOL	MainLotEnd(BOOL bOn);
	BOOL	MainLoadStart(BOOL bOn);
	BOOL	MainUnloadStart(BOOL bOn);

	BOOL	DustSuctionControl(BOOL bLeft, BOOL bUp, double dMin, double dMax);

	BOOL	SetAlarmTolLed(BOOL bOn);
	int		GetWaterFlow1Value();
	int		GetWaterFlow2Value();
	BOOL	GetChillerRun();
	void	ReadAllError(int* pnVal);
	BOOL	SetDustCollectorErrorUse(BOOL bUse);
};

#endif // !defined(AFX_DEVICEUMACPUSAN2_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
