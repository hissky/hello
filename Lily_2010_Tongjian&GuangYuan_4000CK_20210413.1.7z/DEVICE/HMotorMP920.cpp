// HMotorMP920.cpp: implementation of the HMotorMP920 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HMotorMP920.h"

#include "..\InterfaceMP920Module.h"
#include <math.h>
#include "..\alarmmsg.h"
#include "BiLinear.h"
#include "BicubicInterpolation.h"
//#include "BicubicSpline.h"
//#include "..\model\AutoSettingFile.h"
#include "..\model\DEasyDrillerINI.h"

#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

UINT MotorLoop(LPVOID lpParam)
{
	HMotorMP920* pMotor = (HMotorMP920*)lpParam;

	while( 0 == pMotor->GetThreadStopFlag() )
	{
		::Sleep( pMotor->GetPeriod() );

		// Read Input Data
		pMotor->ReadArrayData();

		// Check Motor Inposition
		pMotor->CheckMotorInPosition();
	}

	return 1L;
}

HMotorMP920::HMotorMP920()
{
	m_pMotorThread		= NULL;
	m_bThreadStop		= FALSE;
	m_nPeriod			= 50;

	memset( m_wRegData, 1, sizeof(m_wRegData) );
	memset( m_nWritePos, 0, sizeof(m_nWritePos) );
	memset( m_bIsInPosition, 0, sizeof(m_bIsInPosition) );

	m_nInPositionAxis	= -1;
	m_nInPositionError	= -1;
	m_bInPositionCmd	= 0;
	m_nInPositionStatus	= 0;

	m_lpDataNew			= new MP920DATA;
	m_lpDataOld			= new MP920DATA;

	memset( m_lpDataNew, 0, sizeof(MP920DATA) );
	memset( m_lpDataOld, 0, sizeof(MP920DATA) );

	m_bInitCalibration	= FALSE;
	m_nAutoDataMax		= 0;

	memset( m_nOriginOffset, 0, sizeof(m_nOriginOffset) );
	memset( m_nWorkSpeed, 0, sizeof(m_nWorkSpeed) );
	memset( m_nOriginSpeed, 0, sizeof(m_nOriginSpeed) );

	memset( m_dDestinationPos, 0, sizeof(m_dDestinationPos) );
	memset( m_dCalibrationOffset, 0, sizeof(m_dCalibrationOffset) );
	memset( m_dSlaveCalibrationOffset, 0, sizeof(m_dSlaveCalibrationOffset) );
	memset( m_dMaskPosition, 0, sizeof(m_dMaskPosition) );

	memset( &m_sAutoSetting, 0, sizeof(m_sAutoSetting) );

	m_Calibration = NULL;
	m_SlaveCalibration = NULL;

	memset( &m_pSetting, 0, sizeof(m_pSetting) );
	memset( &m_pAutoData, 0, sizeof(m_pAutoData) );
}

HMotorMP920::~HMotorMP920()
{
	if( NULL != m_lpDataNew )
	{
		delete m_lpDataNew;
		m_lpDataNew = NULL;
	}

	if( NULL != m_lpDataOld )
	{
		delete m_lpDataOld;
		m_lpDataOld = NULL;
	}

	if( NULL != m_pCalibration )
	{
		delete m_pCalibration;
		m_pCalibration = NULL;
	}

	if( NULL != m_pAutoData )
	{
		delete m_pAutoData;
		m_pAutoData = NULL;
	}
//
//#ifdef __SERVO_MOTOR__
//	Disconnect();
//#endif
}

BOOL HMotorMP920::InitMotor()
{
#ifdef __NOUSE_MP920__
	return TRUE;
#endif

	if( FALSE == m_bInitCalibration )
	{
		m_bInitCalibration = TRUE;
		CreateTableCalibration();
	}

	BOOL bRet = 0;

	bRet = InitializeMP920();

	if( FALSE == bRet )
		return bRet;

	m_pMotorThread = ::AfxBeginThread( MotorLoop, this );

	if( NULL == m_pMotorThread )
		return FALSE;

	if (m_nCalType == 1)
	{
		m_Calibration = new CBicubicInterpolation;
		m_SlaveCalibration = new CBicubicInterpolation;
	}
	else
	{
		m_Calibration = new CBiLinear;
		m_SlaveCalibration = new CBiLinear;
	}
	m_Calibration->SetMaster(TRUE);
	m_SlaveCalibration->SetMaster(FALSE);

	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	LoadCalibrationFile(strCalPath);

//#ifdef __SERVO_MOTOR__
//	int nPortNo = gSystemINI.m_sSystemDevice.sServoPort.nPortNo + 1;//2;
//	long lBaudRate; //115200;
//	switch(gSystemINI.m_sSystemDevice.sServoPort.nBaudRate)
//	{
//	case 0: lBaudRate = 2400;	break;
//	case 1: lBaudRate = 4800;	break;
//	case 2: lBaudRate = 9600;	break;
//	case 3: lBaudRate = 19200;	break;
//	case 4: lBaudRate = 38400;	break;
//	case 5: lBaudRate = 57600;	break;
//	case 6: lBaudRate = 115200; break;
//	}
//	Connect(nPortNo, lBaudRate);
//#endif

	return bRet;
}

void HMotorMP920::DestroyMotor()
{
#ifdef __NOUSE_MP920__
	return;
#endif

	DestroyMP920();

	SetThreadStopFlag( TRUE );
	Sleep(100);

	if( NULL != m_pMotorThread )
		::WaitForSingleObject( m_pMotorThread->m_hThread, INFINITE );

	SetThreadStopFlag( FALSE );

	if(m_Calibration)
	{
		delete m_Calibration;
		m_Calibration = NULL;
	}
	
	if(m_SlaveCalibration)
	{
		delete m_SlaveCalibration;
		m_SlaveCalibration = NULL;
	}
}

void HMotorMP920::ReadArrayData()
{
	WORD	wRegData[REG_DATA_MAX] = {0,};

	GetInputArrayData( wRegData );

//	if( 0 == memcmp( m_wRegData, wRegData, sizeof(wRegData) ) )
//		return;

	memcpy( m_wRegData, wRegData, sizeof(wRegData) );

	// Read Position
	ReadPosition();

	// Read Status
	ReadStatus();

	// Read Loader & Unloader
	ReadLoadUnload();

	// Read Input
	ReadInput();

	// Read Error
	ReadError();

	// Read Servo
	ReadServo();



//	if(!GetCurrentStatus(CURRENT_CHILLER))
//	{
//		ErrMsgDlg(STDGNALM1005);
//	}
}

void HMotorMP920::ReadPosition()
{
	int nAxisSize = GetAxisSize();

	long nCmd = 0;
	long nEnc = 0;
	int nCmdAddr = ADD09_COMMAND - ADD09_START;
	int nEncAddr = ADD09_ENCODER - ADD09_START;
//	SAXISINFO sAxisInfo;

	for( int i = 0 ; i < nAxisSize ; i++ )
	{
//		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
		nCmd = ReadLong( m_wRegData, nCmdAddr );
		nEnc = ReadLong( m_wRegData, nEncAddr );

//		ejpark 20110117
//		if( FALSE == GetAxisInfo(i, &sAxisInfo) )
//			continue;

//		if( nCmd == m_lpDataNew->Index.lCommand[i] )
//			continue;

		m_lpDataNew->Index.lCommand[i]		= nCmd;
		m_lpDataNew->Index.lEncoder[i]		= nEnc;
		m_lpDataNew->Index.dPosition[i]		= double(nCmd) / m_pSetting[i].dScale;//sAxisInfo.dScale;

		m_lpDataOld->Index.lCommand[i]		= nCmd;
		m_lpDataOld->Index.lEncoder[i]		= nEnc;
		m_lpDataOld->Index.dPosition[i]		= double(nCmd) / m_pSetting[i].dScale;//sAxisInfo.dScale;
	}
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return;
//		long lGetPos;
//		//m_lWritePos = pos * m_dScale
//		Servo_GetActualPos(0, &lGetPos);
//		if(lGetPos != m_lWritePos[AXIS_M2])
//		{
//			m_bCommandStop = FALSE;
//			m_nInPositionError = 7;
//			return;
//		}
//		
//		Servo_GetActualPos(1, &lGetPos);
//		if(lGetPos != m_lWritePos[AXIS_M3])
//		{
//			m_bCommandStop = FALSE;
//			m_nInPositionError = 9;
//			return;
//		}
//#endif

}

void HMotorMP920::ReadStatus()
{
	int nAxisSize = GetAxisSize();
	WORD wStatus = 0;
	int nAddr = ADD09_STATUS - ADD09_START;
	BOOL bReady, bError, bPosition, bOrigin;

	for( int i = 0 ; i < nAxisSize ; i++ )
	{
		wStatus = m_wRegData[nAddr+i];

		if( wStatus == m_lpDataOld->Index.wStatus[i] )
			continue;

		bReady		= wStatus & 0x0001;
		bError		= wStatus & 0x0002;
		bPosition	= wStatus & 0x0004;
		bOrigin		= wStatus & 0x0008;

		m_lpDataNew->Index.wStatus[i]		= wStatus;
		m_lpDataOld->Index.wStatus[i]		= wStatus;

		if( bReady != m_lpDataOld->Index.bIsReady[i] )
		{
			m_lpDataNew->Index.bIsReady[i]		= bReady;
			m_lpDataOld->Index.bIsReady[i]		= bReady;
		}

		if( bError != m_lpDataOld->Index.bIsError[i] )
		{
			m_lpDataNew->Index.bIsError[i]		= bError;
			m_lpDataOld->Index.bIsError[i]		= bError;
		}

		if( bPosition != m_lpDataOld->Index.bIsPosition[i] )
		{
			m_lpDataNew->Index.bIsPosition[i]	= bPosition;
			m_lpDataOld->Index.bIsPosition[i]	= bPosition;
		}

		if( bOrigin != m_lpDataOld->Index.bIsOrigin[i] )
		{
			m_lpDataNew->Index.bIsOrigin[i]		= bOrigin;
			m_lpDataOld->Index.bIsOrigin[i]		= bOrigin;
		}
	}

//#ifdef __SERVO_MOTOR__
//	BOOL bM2, bM3;
//	bM2 = Servo_GetEnable(0);
//	bM3 = Servo_GetEnable(1);
//	
//	// �Ѵ� enable�� ����� ������ ����ɷ� ���� 
//	if(!bM2 && !bM3 && !m_bShowErrMsg && m_bConnect)
//	{
//		ErrMessage(_T("2 Mask Connection is closed.\nPlease Check Connection and Initial 2 Mask."));
//		m_bConnect = FALSE;
//		m_bShowErrMsg = TRUE; 
//		Servo_SetReconnect(TRUE);
//	}
//	//�ٽ� ������ �Ǽ� enable�� ����� ������ m_bConnect Flag�� �ٲ��� 
//	if(!m_bOldM2 && bM2 && !m_bOldM3 && bM3)
//	{
//		m_bShowErrMsg = FALSE;
//		if(!m_bConnect)
//		{
//			m_bConnect = TRUE;
//		}
//	}
//	m_bOldM2 = bM2; 
//	m_bOldM3 = bM3;
//#endif
}

void HMotorMP920::ReadLoadUnload()
{
	int nAxisSize = GetAxisSize();
	WORD wStatus = 0;
	int nAddr = ADD09_LOADUNLOAD - ADD09_START;

	wStatus = m_wRegData[nAddr];

	// Loader
	// 0 : Align Run
	// 1 : Align End
	// 2 : Loading Run
	// 3 : Loading End
	m_lpDataNew->Load.wStatus		= wStatus & 0x000F; 
	m_lpDataOld->Load.wStatus		= wStatus & 0x000F;

	m_lpDataNew->Load.bAlignRun		= ((wStatus & 0x0001) ? 0x0001 : 0x0000); // Align Run
	m_lpDataNew->Load.bAlignStop	= ((wStatus & 0x0002) ? 0x0002 : 0x0000); // Aling End
	m_lpDataNew->Load.bLoaderRun	= ((wStatus & 0x0004) ? 0x0004 : 0x0000); // Loader Run
	m_lpDataNew->Load.bLoaderStop	= ((wStatus & 0x0008) ? 0x0008 : 0x0000); // Loader End

	// Unloader
	// 4 : Unloading Run
	// 5 : Unloading End
	// 6 : Load Request Ready
	m_lpDataNew->UnLoad.wStatus		= wStatus & 0x0070;
	m_lpDataOld->UnLoad.wStatus		= wStatus & 0x0070;

	m_lpDataNew->UnLoad.bUnloadRun	= ((wStatus & 0x0010) ? 0x0010 : 0x0000); // Unloading Run
	m_lpDataNew->UnLoad.bUnloadStop	= ((wStatus & 0x0020) ? 0x0020 : 0x0000); // Unloading End
	m_lpDataNew->UnLoad.bUnloadToLoadStart	= ((wStatus & 0x0040) ? 0x0040 : 0x0000); // Load Request Ready
}

void HMotorMP920::ReadInput()
{
 	int nAddr = ADD09_INPUT - ADD09_START;
	BYTE wStatus = 0;

	for( int i = 0 ; i < 15 ; i++ )
	{
		wStatus = (BYTE)m_wRegData[nAddr+i];

		switch( i )
		{
		case 0 : // Mode Signal
			m_lpDataOld->IO.nMode			= m_lpDataNew->IO.nMode;
			m_lpDataNew->IO.nMode			= wStatus;
			break;
		case 1 : // Emergency
			m_lpDataOld->IO.nEMStop		  	= m_lpDataNew->IO.nEMStop;
			m_lpDataNew->IO.nEMStop			= wStatus;
			break;
		case 2 : // System Ready & Reset
			m_lpDataOld->IO.nSystem			= m_lpDataNew->IO.nSystem;
			m_lpDataNew->IO.nSystem			= wStatus;
			break;
		case 3 : // Cycle On & Off
			m_lpDataOld->IO.nCycle			= m_lpDataNew->IO.nCycle;
			m_lpDataNew->IO.nCycle			= wStatus;
			break;
		case 4 : // High Speed Shutter #1
			m_lpDataOld->IO.nHighShutter1	= m_lpDataNew->IO.nHighShutter1;
			m_lpDataNew->IO.nHighShutter1	= wStatus;
			break;
		case 5 : // High Speed Shutter #2
			m_lpDataOld->IO.nHighShutter2	= m_lpDataNew->IO.nHighShutter2;
			m_lpDataNew->IO.nHighShutter2	= wStatus;
			break;
		case 6 : // Loader Picker1, 2 PCB Detect
			m_lpDataOld->IO.nIsPcbLoad		= m_lpDataNew->IO.nIsPcbLoad;
			m_lpDataNew->IO.nIsPcbLoad		= wStatus;
			break;
		case 7 : // Table Suction Check
			m_lpDataOld->IO.nIsSuction		= m_lpDataNew->IO.nIsSuction;
			m_lpDataNew->IO.nIsSuction		= wStatus;
			break;
		case 8 : // Unloader Picker1, 2 PCB Detect
			m_lpDataOld->IO.nIsPcbUnload	= m_lpDataNew->IO.nIsPcbUnload;
			m_lpDataNew->IO.nIsPcbUnload	= wStatus;
			break;
		case 9 : // Dust Suction
			//m_lpDataOld->IO.nDustSuction	= m_lpDataNew->IO.nDustSuction;
			//m_lpDataNew->IO.nDustSuction	= wStatus;
			m_lpDataNew->IO.nDustSuction = TRUE;
			break;
		case 10 : // External Laser Shot Switch
			m_lpDataNew->IO.nExternalLaser	= wStatus;
			break;
		case 11: // Table Clamp
			m_lpDataNew->IO.nTableClamp = wStatus;
			break;
#ifdef __PUSAN_LDD__
	#ifdef __CUNGJU_JASMINE_OLD__
		case 12: // Table Vacuum Motor
			m_lpDataOld->IO.nVacuumMotor	= m_lpDataNew->IO.nVacuumMotor;
			m_lpDataNew->IO.nVacuumMotor	= wStatus;
			break;
		case 13:// Table Clamp 2
//			m_lpDataOld->IO.nTableClamp2 = m_lpDataNew->IO.nTableClamp2;
//			m_lpDataNew->IO.nTableClamp2 = wStatus;
			break;
		case 14: //Height Sensor2 
//			m_lpDataOld->IO.nHeightSensor2 = m_lpDataNew->IO.nHeightSensor2;
//			m_lpDataNew->IO.nHeightSensor2 = wStatus;
			break;
	#else
		case 12: // Chiller Alarm
			m_lpDataNew->IO.nChillerAlarm = wStatus;
			break;
	#endif
#endif

			
		}
	}
}

void HMotorMP920::ReadError()
{
	BOOL bIsChangeErr = FALSE;
	int nAddr = ADD09_ERROR - ADD09_START;

	for( int i = 0 ; i < LEN09_ERROR ; i++ )
	{
		m_lpDataNew->IO.lError[i] = m_wRegData[nAddr+i];

		if( m_lpDataNew->IO.lError[i] == m_lpDataOld->IO.lError[i] )
			continue;

		bIsChangeErr = TRUE;
		m_lpDataOld->IO.lError[i] = m_lpDataNew->IO.lError[i];
	}

	if( FALSE == bIsChangeErr )
		return;

	ReadErrorIo();
	ReadErrorLoading();
	ReadErrorUnloading();
	ReadErrorAligner();
	ReadErrorTableLimit();
	ReadErrorOtherLimit();
	ReadErrorTable();
	ReadErrorLaser();

}

void HMotorMP920::ReadErrorIo()
{
	long nError = m_lpDataNew->IO.lError[0];

	m_lpDataNew->IO.lErrorIo = 0;
	m_lpDataNew->IO.lErrorIo += (m_lpDataNew->IO.nEMStop > 0) ? 0x0001 : 0x0000;	// em stop
#ifdef __CUNGJU_JASMINE_OLD__
	m_lpDataNew->IO.lErrorIo += (nError & 0x0002) ? 0x0002 : 0x0000;	// DustSuctionError
#else
	m_lpDataNew->IO.lErrorIo += (nError & 0x0100) ? 0x0002 : 0x0000;	// DustSuctionError
#endif

	nError = m_lpDataNew->IO.lError[2];
	m_lpDataNew->IO.lErrorIo += (nError & 0x0010) ? 0x0010 : 0x0000;	// Height Sensor On
	m_lpDataNew->IO.lErrorIo += (nError & 0x0020) ? 0x0020 : 0x0000;	// Height Sensor Off
	m_lpDataNew->IO.lErrorIo += (nError & 0x0200) ? 0x0100 : 0x0000;	// laser shutter1 open err
	m_lpDataNew->IO.lErrorIo += (nError & 0x0400) ? 0x0200 : 0x0000;	// laser shutter1 close err
	m_lpDataNew->IO.lErrorIo += (nError & 0x0800) ? 0x0400 : 0x0000;	// laser shutter2 open err
	m_lpDataNew->IO.lErrorIo += (nError & 0x1000) ? 0x0800 : 0x0000;	// laser shutter2 close err
	m_lpDataNew->IO.lErrorIo += (nError & 0x2000) ? 0x1000 : 0x0000;	// water flow error

#ifdef __CUNGJU_JASMINE_OLD__
	nError = m_lpDataNew->IO.lError[3];
//	m_lpDataNew->IO.lErrorIo += (nError & 0x0001) ? 0x0040 : 0x0000; // HeightSensor2 Up/Down // for cavity 3
//	m_lpDataNew->IO.lErrorIo += (nError & 0x0200) ? 0x4000 : 0x0000; // Table Clamp 1 For/Bwd
//	m_lpDataNew->IO.lErrorIo += (nError & 0x0400) ? 0x8000 : 0x0000; // Table Clamp 2 For/Bwd
#endif
}

void HMotorMP920::ReadErrorLoading()
{
	long nError = m_lpDataNew->IO.lError[0];

	m_lpDataNew->IO.lErrorLoad = 0;
	m_lpDataNew->IO.lErrorLoad += (nError & 0x0004) ? 0x0001 : 0x0000;	// Loading Section Alarm
	m_lpDataNew->IO.lErrorLoad += (nError & 0x0200) ? 0x0002 : 0x0000;	// Loading Detect Alarm#1 (PCB�� Card�� ����)
	m_lpDataNew->IO.lErrorLoad += (nError & 0x0400) ? 0x0004 : 0x0000;	// Loading Detect Alarm#2 (Loading�� ��ħ) -> Picker1
	m_lpDataNew->IO.lErrorLoad += (nError & 0x0800) ? 0x0008 : 0x0000;	// Loading Detect Alarm#3 (Carrier�� ��ħ) -> Picker2
}

void HMotorMP920::ReadErrorUnloading()
{
	long nError = m_lpDataNew->IO.lError[0];

	m_lpDataNew->IO.lErrorUnload = 0;
	m_lpDataNew->IO.lErrorUnload += (nError & 0x0008) ? 0x0001 : 0x0000;	// Unloading Section Alarm #1
	m_lpDataNew->IO.lErrorUnload += (nError & 0x0010) ? 0x0002 : 0x0000;	// Unloading Section Alarm #2 (PCB�� Cart�� ������)
	m_lpDataNew->IO.lErrorUnload += (nError & 0x1000) ? 0x0004 : 0x0000;	// Unloading Section Alarm #3 (Unloading�� ��ħ) -> Picker1
	m_lpDataNew->IO.lErrorUnload += (nError & 0x2000) ? 0x0008 : 0x0000;    // Unloading Section Alarm #4   Add (Picker2�� PCB ����) yhchung 060714
}

void HMotorMP920::ReadErrorAligner()
{
	m_lpDataNew->IO.lErrorAligner = 0;
}

void HMotorMP920::ReadErrorTableLimit()
{
	long nError = m_lpDataNew->IO.lError[1];

	m_lpDataNew->IO.lErrorTableLimit = 0;
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0001) ? 0x0001 : 0x0000;	// X+ Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0002) ? 0x0002 : 0x0000;	// X- Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0004) ? 0x0004 : 0x0000;	// Y+ Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0008) ? 0x0008 : 0x0000;	// Y- Limit
//	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0010) ? 0x0010 : 0x0000;	// L+ Limit
//	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0020) ? 0x0020 : 0x0000;	// L- Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0010) ? 0x0010 : 0x0000;	// Z1+ Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0020) ? 0x0020 : 0x0000;	// Z1- Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0040) ? 0x0040 : 0x0000;	// Z2+ Limit
	m_lpDataNew->IO.lErrorTableLimit += (nError & 0x0080) ? 0x0080 : 0x0000;	// Z2- Limit
}

void HMotorMP920::ReadErrorOtherLimit()
{
	long nError = m_lpDataNew->IO.lError[1];

	m_lpDataNew->IO.lErrorOtherLimit = 0;
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0100) ? 0x0001 : 0x0000;	// M1+ Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0200) ? 0x0002 : 0x0000;	// M1- Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0400) ? 0x0004 : 0x0000;	// C1+ Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0800) ? 0x0008 : 0x0000;	// C1- Limit

	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x1000) ? 0x0010 : 0x0000;	// LC+ Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x2000) ? 0x0020 : 0x0000;	// LC- Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x4000) ? 0x0040 : 0x0000;	// UC+ Limit
	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x8000) ? 0x0080 : 0x0000;	// UC- Limit

//	nError = m_lpDataNew->IO.lError[2];
//	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0001) ? 0x0040 : 0x0000;	// P2+ Limit
//	m_lpDataNew->IO.lErrorOtherLimit += (nError & 0x0002) ? 0x0080 : 0x0000;	// P2- Limit
}

void HMotorMP920::ReadErrorTable()
{
	long nError = m_lpDataNew->IO.lError[0];

	m_lpDataNew->IO.lErrorTable = 0;
//	m_lpDataNew->IO.lErrorTable += (nError & 0x1000) ? 0x0001 : 0x0000;			// Homing Error
}

void HMotorMP920::ReadErrorLaser()
{
	long nError = m_lpDataNew->IO.lError[0];

	m_lpDataNew->IO.lErrorLaser = 0;
	m_lpDataNew->IO.lErrorLaser += (nError & 0x0020) ? 0x0001 : 0x0000;	// Chiller Alarm

	nError = m_lpDataNew->IO.lError[3];
	m_lpDataNew->IO.lErrorLaser += (nError & 0x0200) ? 0x0002 : 0x0000;	// AOM Alarm

//	m_lpDataNew->IO.lErrorLaser += (nError & 0x0040) ? 0x0002 : 0x0000;	// Laser Power Overload
//	m_lpDataNew->IO.lErrorLaser += (nError & 0x0080) ? 0x0004 : 0x0000;	// Chiller Power Overload // blow motor error
//	m_lpDataNew->IO.lErrorLaser += (nError & 0x8000) ? 0x0008 : 0x0000;	// Optic Door Open
}

void HMotorMP920::ReadServo()
{
	BOOL bIsChangeServo = FALSE;
	int nAddr = ADD09_SERVO - ADD09_START;

	for( int i = 0 ; i < LEN09_SERVO ; i++ )
	{
		m_lpDataNew->IO.lErrorServo[i] = m_wRegData[nAddr+i];

		if( m_lpDataNew->IO.lErrorServo[i] == m_lpDataOld->IO.lErrorServo[i] )
			continue;

		bIsChangeServo = TRUE;
		m_lpDataOld->IO.lErrorServo[i] = m_lpDataNew->IO.lErrorServo[i];
	}

	if( FALSE == bIsChangeServo )
		return;
}

BOOL HMotorMP920::PeekMessage()
{
	MSG msg;

	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}

	return FALSE;
}

BOOL HMotorMP920::IsMotor(int nAxis, BOOL bMotor[])
{
	if(nAxis == AXIS_L_CARRIER || nAxis == AXIS_UL_CARRIER)
		return TRUE;

	if( -1 != nAxis )
	{
//		if( nAxis >= MOTOR_AXIS_MAX || nAxis < 0 )
//			return FALSE;
// Loader, Unload���� �ּ� ó��...

		return bMotor[nAxis];
	}

	int nSize = GetAxisSize();
	for(int i = 0 ; i < nSize ; i++ )
	{
		if( FALSE == bMotor[i] )
			return FALSE;
	}
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		bMask2 = Servo_IsOrigin(0);
//		bMask3 = Servo_IsOrigin(1);
//#endif
	
	return TRUE;
}

BOOL HMotorMP920::IsMotorEnd(int nAxis)
{
//#ifdef __SERVO_MOTOR__
//	long lGetPos, lSetPos;
//#endif
	if(nAxis == AXIS_L_CARRIER || nAxis == AXIS_UL_CARRIER)
		return TRUE;

	double dDiff = 0.;
	double dTolerance = 0.;
	double dScale = 0.;
//	SAXISINFO sAxisInfo;

	if( -1 != nAxis ) // All Axis
	{
		if( TRUE == m_bIsInPosition[nAxis] )
		{
			if( FALSE == m_lpDataNew->Index.bIsPosition[nAxis] )
			{
				m_nInPositionError = nAxis;
				return FALSE;
			}
			
			// Axis Scale
//			memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
//			if( FALSE == GetAxisInfo( nAxis, &sAxisInfo ) )
//				dScale = 1.;
//			else
				dScale = m_pSetting[nAxis].dScale;//sAxisInfo.dScale;

			// ���� ��ġ�� ������ ������ ��ġ�� ��
			dDiff = (double)abs(m_nWritePos[nAxis] - m_lpDataNew->Index.lCommand[nAxis] );
			
			// ���� ��ġ ���� ��� ����
			if( 1 == GetUseDualPanel() )
			{
				if( AXIS_M == nAxis )
					dTolerance = dScale * 2.;
				else
					dTolerance = dScale / 200.;
			}
			else
			{
				if( SINGLE_M == nAxis )
					dTolerance = dScale * 2.;
				else
					dTolerance = dScale / 200.;
			}

			if( dDiff > dTolerance )
			{
				m_nInPositionError = nAxis;
				return FALSE;
			}			
		}

//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		Servo_GetActualPos(0 , &lGetPos);
//		if(abs(m_lWritePos[AXIS_M2] - (int)lGetPos) > 2)
//		{
//			bM2 = FALSE;
//			m_nInPositionError = 7;
//			return FALSE;
//		}
//		
//		Servo_GetActualPos(1 , &lGetPos);
//		if(abs(m_lWritePos[AXIS_M3] - (int)lGetPos) > 2)
//		{
//			bM3 = FALSE;
//			m_nInPositionError = 9;
//			return FALSE;
//		}
//#endif

		return TRUE;
	}
	else 
	{
		int nSize = GetAxisSize();
		for( int i = 0 ; i < nSize ; i++ )
		{
			if( TRUE == m_bIsInPosition[i] )
			{
				if( FALSE == m_lpDataNew->Index.bIsPosition[i] )
				{
					m_nInPositionError = i;
					return FALSE;
				}
				
				// Axis Scale
//				memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
//				if( FALSE == GetAxisInfo( i, &sAxisInfo ) )
//					dScale = 1.;
//				else
					dScale = m_pSetting[nAxis].dScale;//sAxisInfo.dScale;

				// ���� ��ġ�� ������ ������ ��ġ�� ��
				dDiff = (double)abs( m_nWritePos[i] - m_lpDataNew->Index.lCommand[i] );
				
				// ���� ��ġ ���� ��� ����
				if( 1 == GetUseDualPanel() )
				{
					if( AXIS_M == i )
						dTolerance = dScale * 2.;
					else
						dTolerance = dScale / 200.;
				}
				else
				{
					if( SINGLE_M == i )
						dTolerance = dScale * 2.;
					else
						dTolerance = dScale / 200.;
				}

				if( dDiff > dTolerance )
				{
					m_nInPositionError = i;
					return FALSE;
				}			
			}
		}
//#ifdef __SERVO_MOTOR__
//			if(!m_bConnect)
//				return FALSE;
//			Servo_GetActualPos(0, &lGetPos);
//			Servo_GetCommandPos(0, &lSetPos);
//			
//			if(abs(lSetPos - lGetPos) < 3)
//			{
//				m_nInPositionError = 7;
//				return FALSE;
//			}
//			
//			if(!m_bConnect)
//				return FALSE;
//			Servo_GetActualPos(1, &lGetPos);
//			Servo_GetCommandPos(1, &lSetPos);
//			
//			if(abs(lSetPos - lGetPos) < 3)
//			{
//				m_nInPositionError = 9;
//				return FALSE;
//			}
//			
//			return TRUE;
//#endif
//		TRACE(_T("MOVE END OK\n"));
		return TRUE;
	}
}

int HMotorMP920::IsInPositionThread(int nAxis, BYTE bCmd)
{
/*	BYTE bMode = GetCurrentMode();

	if( MODE_OFF == bMode || MODE_MPG == bMode || MODE_HOME == bMode )
		return FALSE;*/

	if( IsMotorEnd( nAxis ) )
		return TRUE;

	m_nInPositionStatus = 0;  // Inposition Status
	m_clsTimer.Pause();
	m_clsTimer.StartTime();
	m_bInPositionCmd = bCmd;

	do
	{
		PeekMessage();
		
		::Sleep( GetPeriod() );

		if( FALSE != m_nInPositionStatus )
			break;
	} while( 0 == GetThreadStopFlag() );

	m_bInPositionCmd = 0;

	switch( m_nInPositionStatus )
	{
	case -1 :
		{
			if( 1 == GetUseDualPanel() )
			{
/*				switch( m_nInPositionError )
				{
				case AXIS_X :
					ErrMsgDlg(STDGNALM404);
					break;
				case AXIS_Y :
					ErrMsgDlg(STDGNALM405);
					break;
				case AXIS_Z1 :
					ErrMsgDlg(STDGNALM406);
					break;
				case AXIS_Z2 :
					ErrMsgDlg(STDGNALM407);
					break;
				case AXIS_M :
					ErrMsgDlg(STDGNALM409);
					break;
				case AXIS_C :
					ErrMsgDlg(STDGNALM411);
					break;
				}
*/			}
			else
			{
/*				switch( m_nInPositionError )
				{
				case SINGLE_X :
					ErrMsgDlg(STDGNALM404);
					break;
				case SINGLE_Y :
					ErrMsgDlg(STDGNALM405);
					break;
				case SINGLE_Z :
					ErrMsgDlg(STDGNALM406);
					break;
				case SINGLE_M :
					ErrMsgDlg(STDGNALM409);
					break;
				case SINGLE_C :
					ErrMsgDlg(STDGNALM411);
					break;
				}
*/			}
		}
		break;
	case -2 :
		ErrMsgDlg(STDGNALM1001);
		break;
	case -3 :
		m_nInPositionStatus = TRUE;
		break;
	}

	return m_nInPositionStatus;
}

void HMotorMP920::CheckMotorInPosition()
{
	if( 0 == m_bInPositionCmd )
		return;

	switch( m_bInPositionCmd )
	{
	case COMMAND_INPOSITION :	// ���� ����
		if( IsMotorEnd(m_nInPositionAxis) )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_INORIGIN :		// ���� ����
		if( IsMotor( m_nInPositionAxis, m_lpDataNew->Index.bIsOrigin ) )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_LOADSTOP :		// �δ� ����
		if( m_lpDataNew->Load.bLoaderStop )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_LOADMOVING :	// �δ� ����
		if( m_lpDataNew->Load.bLoaderRun )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_UNLOADSTOP :	// ��δ� ����
		if( m_lpDataNew->UnLoad.bUnloadStop )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_UNLOADMOVING :	// ��δ� ����
		if( m_lpDataNew->UnLoad.bUnloadRun )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_ALIGNERSTOP :	// ����̳� ����
		if( m_lpDataNew->Load.bAlignStop )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_ALIGNERMOVING : // ����̳� ����
		if( m_lpDataNew->Load.bAlignRun )
			m_nInPositionStatus = TRUE;
		break;
	case COMMAND_SHUTTER :		// ���� ���ǵ� ����
		if( 1 != m_lpDataNew->IO.nHighShutter2 &&
			2 != m_lpDataNew->IO.nHighShutter2 )
			m_nInPositionStatus = TRUE;
		break;
	}

	if( TRUE == m_nInPositionStatus )
		m_clsTimer.StartTime();

	if( m_clsTimer.PresentTime() > MAX_STOPOVER_TIME )
		m_nInPositionStatus = -1;
}

BOOL HMotorMP920::SetOrigin(int nAxis)
{
	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		if(GetCurrentTableClamp(TRUE, FALSE) )
		{
			ErrMessage(_T("Can not Homing when Table is Unclamping."));
			return FALSE;
		}
	}
	if(gSystemINI.m_sHardWare.nTableClamp > 1)
	{
		if(GetCurrentTableClamp(FALSE, FALSE) )
		{
			ErrMessage(_T("Can not Homing when Table is Unclamping"));
			return FALSE;
		}
	}

	int nCount = 0;
	long nData= INDEX_ORIGIN;
	BYTE bData[REG_DATA_MAX] = {0,};
	//switch(nAxis)
	//{
	//case -1:
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		bResult = Servo_ServoEnable(0, TRUE);
//		bResult = Servo_ServoEnable(1, TRUE);
//		bResult = Servo_AllMoveOriginSingleAxis();
//#endif
//
//	case AXIS_M2:
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		bResult = Servo_ServoEnable(0, TRUE);
//		bResult = Servo_MoveOriginSingleAxis(0);
//#else
////		bResult = MotionControlDLL_WriteOutputDWord(0x610B4, 1);
//#endif
//		break;
//	case AXIS_M3:
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		bResult = Servo_ServoEnable(1, TRUE);
//		bResult = Servo_MoveOriginSingleAxis(1);
//#endif
//		break;
//	}
	WriteLong( bData, nData, nCount );

	return WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bData );

	return TRUE;
}

BOOL HMotorMP920::MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel, BOOL bZCalUse, int nMoveMode, BOOL bPass)
{
	m_dDestinationPos[nAxis] = dPosition;

	double dPos2;

	if(nAxis == AXIS_X)
	{
		dPos2 = GetPosition(AXIS_Y);
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosition, dPos2, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			m_dDestinationPos[nAxis] += m_dCalibrationOffset[nAxis];
		}
		else
		{
			GetAxisMoveOffset(dPosition, dPos2, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			m_dDestinationPos[nAxis] += m_dSlaveCalibrationOffset[nAxis];
		}
	}
	else if(nAxis == AXIS_Y)
	{
		dPos2 = GetPosition(AXIS_X);
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPos2, dPosition, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			m_dDestinationPos[nAxis] += m_dCalibrationOffset[nAxis];
		}
		else
		{
			GetAxisMoveOffset(dPos2, dPosition, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			m_dDestinationPos[nAxis] += m_dSlaveCalibrationOffset[nAxis];
		}
	}
//	else if(nAxis == AXIS_M2)
//	{
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//		Servo_MoveSingleAxisAbsPos(0 , (int)(m_lWritePos[AXIS_M] * m_dScale[AXIS_M2]), m_lSpeed[AXIS_M2]);
//
//#endif
//				
//	}
//	else if(nAxis == AXIS_M2)
//	{
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//
//		Servo_MoveSingleAxisAbsPos(0 , (int)(m_lWritePos[AXIS_M] * m_dScale[AXIS_M2]), m_lSpeed[AXIS_M2]);
//	}
//#endif

	if(FALSE == IsValidAxisPosition(nAxis, m_dDestinationPos[nAxis]))
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxis, m_dDestinationPos[nAxis] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZ1Z2MC(x,y,z1,z2,m,c,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[AXIS_X]	= x;
	m_dDestinationPos[AXIS_Y]	= y;
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;
	m_dDestinationPos[AXIS_M]	= m;
	m_dDestinationPos[AXIS_C]	= c;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) ||
		FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
	WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );
	WritePosition( bPosData, AXIS_C, m_dDestinationPos[AXIS_C] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZ1Z2M(x,y,z1,z2,m,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel,BOOL bRawMove)
{
	m_dDestinationPos[AXIS_X]	= x;
	m_dDestinationPos[AXIS_Y]	= y;
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;
	m_dDestinationPos[AXIS_M]	= m;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}
	
	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) ||
		FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
	WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZ1Z2(x,y,z1,z2,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[AXIS_X]	= x;
	m_dDestinationPos[AXIS_Y]	= y;
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
	WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZ1Z2_W(x,y,z2,z2,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[AXIS_X]	= x;
	m_dDestinationPos[AXIS_Y]	= y;
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;
	
	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}
	
	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
	WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MoveZMC_W(double z1, double z2, int nMaskIndex, double c)
{
	int nAxisM = 0, nAxisC = 0;

	nAxisM = AXIS_M;
	nAxisC = AXIS_C;

	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;
	m_dDestinationPos[nAxisM]		= m_dMaskPosition[nMaskIndex];
	m_dDestinationPos[nAxisC]		= c;
	
	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ))
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MoveZMC_W(double z1, double z2, double m, double c)
{
	int nAxisM = 0, nAxisC = 0;

	nAxisM = AXIS_M;
	nAxisC = AXIS_C;
	
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;
	m_dDestinationPos[nAxisM]		= m;
	m_dDestinationPos[nAxisC]		= c;
	
	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ))
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MotorMoveZ1Z2(double z1, double z2, BOOL bRawMove)
{
	return MoveZ1Z2(z1,z2,bRawMove);
}

BOOL HMotorMP920::MoveZ1Z2(double z1, double z2, BOOL bRawMove)
{
	m_dDestinationPos[AXIS_Z1]	= z1;
	m_dDestinationPos[AXIS_Z2]	= z2;

	if( FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZMC(x,y,z,m,c,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[AXIS_X]		= x;
	m_dDestinationPos[AXIS_Y]		= y;
	m_dDestinationPos[AXIS_Z1]		= z;
	m_dDestinationPos[AXIS_Z2]		= z;
	m_dDestinationPos[AXIS_M]		= m;
	m_dDestinationPos[AXIS_C]		= c;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] ) ||
		FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
	WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
	WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );
	WritePosition( bPosData, AXIS_C, m_dDestinationPos[AXIS_C] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZM(double x, double y, double z, double m, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZM(x,y,z,m,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZM(double x, double y, double z, double m, BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[SINGLE_X]		= x;
	m_dDestinationPos[SINGLE_Y]		= y;
	m_dDestinationPos[SINGLE_Z]		= z;
	m_dDestinationPos[SINGLE_M]		= m;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( SINGLE_X, m_dDestinationPos[SINGLE_X] ) ||
		FALSE == IsValidAxisPosition( SINGLE_Y, m_dDestinationPos[SINGLE_Y] ) ||
		FALSE == IsValidAxisPosition( SINGLE_Z, m_dDestinationPos[SINGLE_Z] ) ||
		FALSE == IsValidAxisPosition( SINGLE_M, m_dDestinationPos[SINGLE_M] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, SINGLE_X, m_dDestinationPos[SINGLE_X] );
	WritePosition( bPosData, SINGLE_Y, m_dDestinationPos[SINGLE_Y] );
	WritePosition( bPosData, SINGLE_Z, m_dDestinationPos[SINGLE_Z] );
	WritePosition( bPosData, SINGLE_M, m_dDestinationPos[SINGLE_M] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXYZ(double x, double y, double z, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXYZ(x,y,z,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXYZ(double x, double y, double z,BOOL b1stPanel, BOOL bRawMove)
{
	m_dDestinationPos[SINGLE_X]	= x;
	m_dDestinationPos[SINGLE_Y]	= y;
	m_dDestinationPos[SINGLE_Z]	= z;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( SINGLE_X, m_dDestinationPos[SINGLE_X] ) ||
		FALSE == IsValidAxisPosition( SINGLE_Y, m_dDestinationPos[SINGLE_Y] ) ||
		FALSE == IsValidAxisPosition( SINGLE_Z, m_dDestinationPos[SINGLE_Z] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, SINGLE_X, m_dDestinationPos[SINGLE_X] );
	WritePosition( bPosData, SINGLE_Y, m_dDestinationPos[SINGLE_Y] );
	WritePosition( bPosData, SINGLE_Z, m_dDestinationPos[SINGLE_Z] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveZ(double z, BOOL bRawMove)
{
	return MoveZ(z,bRawMove);
}

BOOL HMotorMP920::MoveZ(double z, BOOL bRawMove)
{
	m_dDestinationPos[SINGLE_Z]	= z;

	if( FALSE == IsValidAxisPosition( SINGLE_Z, m_dDestinationPos[SINGLE_Z] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, SINGLE_Z, m_dDestinationPos[SINGLE_Z] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveXY(double x, double y, BOOL b1stPanel,BOOL bRawMove)
{
	return MoveXY(x,y,b1stPanel,bRawMove);
}

BOOL HMotorMP920::MoveXY(double x, double y, BOOL b1stPanel,BOOL bRawMove)
{
	int nAxisX = 0, nAxisY = 0;

	if( 1 == GetUseDualPanel() )
	{
		nAxisX = AXIS_X;
		nAxisY = AXIS_Y;
	}
	else
	{
		nAxisX = SINGLE_X;
		nAxisY = SINGLE_Y;
	}

	m_dDestinationPos[nAxisX]		= x;
	m_dDestinationPos[nAxisY]		= y;

	if( FALSE == bRawMove )
	{
		if(b1stPanel)
		{
			GetAxisMoveOffset( x, y, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
		}
		else
		{
			GetAxisMoveOffset( x, y, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
			m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
			m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
		}
	}

	if( FALSE == IsValidAxisPosition( nAxisX, m_dDestinationPos[nAxisX] ) ||
		FALSE == IsValidAxisPosition( nAxisY, m_dDestinationPos[nAxisY] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisX, m_dDestinationPos[nAxisX] );
	WritePosition( bPosData, nAxisY, m_dDestinationPos[nAxisY] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveMC(double m, double c)
{
	return MoveMC(m,c);
}

BOOL HMotorMP920::MoveMC(double m, double c)
{
	int nAxisM = 0, nAxisC = 0;

	nAxisM = AXIS_M;
	nAxisC = AXIS_C;

	m_dDestinationPos[nAxisM]		= m;
	m_dDestinationPos[nAxisC]		= c;

	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveMC(int nIndexMask, double c)
{
	return MoveMC(nIndexMask, c);
}

BOOL HMotorMP920::MoveMC(int nIndexMask, double c)
{
	int nAxisM = 0, nAxisC = 0;

	nAxisM = AXIS_M;
	nAxisC = AXIS_C;

	m_dDestinationPos[nAxisM]		= m_dMaskPosition[nIndexMask];
	m_dDestinationPos[nAxisC]		= c;

	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveMC_W(double m, double c)
{
	return MoveMC_W(m,c);
}

BOOL HMotorMP920::MoveMC_W(double m, double c)
{
	int nAxisM = 0, nAxisC = 0;
	
	nAxisM = AXIS_M;
	nAxisC = AXIS_C;
	
	m_dDestinationPos[nAxisM]		= m;
	m_dDestinationPos[nAxisC]		= c;
	
	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MotorMoveMC_W(int nIndexMask, double c)
{
	return MoveMC_W(nIndexMask, c);
}

BOOL HMotorMP920::MoveMC_W(int nIndexMask, double c)
{
	int nAxisM = 0, nAxisC = 0;
	
	nAxisM = AXIS_M;
	nAxisC = AXIS_C;
	
	m_dDestinationPos[nAxisM]		= m_dMaskPosition[nIndexMask];
	m_dDestinationPos[nAxisC]		= c;
	
	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) ||
		FALSE == IsValidAxisPosition( nAxisC, m_dDestinationPos[nAxisC] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );
	WritePosition( bPosData, nAxisC, m_dDestinationPos[nAxisC] );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::MotorMoveM(double m)
{
	return MoveM(m);
}

BOOL HMotorMP920::MoveM(double m)
{
	int nAxisM = 0;

	nAxisM = AXIS_M;

	m_dDestinationPos[nAxisM]		= m;

	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::MotorMoveM(int nIndexMask)
{
	return MoveM(nIndexMask);
}

BOOL HMotorMP920::MoveM(int nIndexMask)
{
	int nAxisM = 0;

	nAxisM = AXIS_M;

	m_dDestinationPos[nAxisM]		= m_dMaskPosition[nIndexMask];

	if( FALSE == IsValidAxisPosition( nAxisM, m_dDestinationPos[nAxisM] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return TRUE;
	}

	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];

	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );
	WritePosition( bPosData, nAxisM, m_dDestinationPos[nAxisM] );

	BOOL bRet = 0;

	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );

	return bRet;
}

BOOL HMotorMP920::GetAxisScale(int nAxis, double* pScale)
{
/*
	SAXISINFO sAxisInfo;

	memset( &sAxisInfo, 0, sizeof(SAXISINFO) );

	if( FALSE == GetAxisInfo( nAxis, &sAxisInfo ) )
	{
		*pScale = 1.;
		return FALSE;
	}
*/
	*pScale = m_pSetting[nAxis].dScale;//sAxisInfo.dScale;

	return TRUE;
}

BOOL HMotorMP920::IsValidAxisPosition(int nAxisNo, double dPos)
{
/*
	SAXISINFO sAxisInfo;

	memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

	if( FALSE == GetAxisInfo( nAxisNo, &sAxisInfo ) )
		return FALSE;
*/

	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		if( nAxisNo == AXIS_Y && dPos > m_sAutoSetting.dUnclampLimitY && GetCurrentTableClamp(TRUE, FALSE) )
		{
//			ErrMessage(_T("Table Unclamp���·� Table �̵� �� �� �����ϴ�."));
			return FALSE;
		}
	}
	if(gSystemINI.m_sHardWare.nTableClamp > 1)
	{
		if( nAxisNo == AXIS_Y && dPos > m_sAutoSetting.dUnclampLimitY && GetCurrentTableClamp(FALSE, FALSE) )
		{
//			ErrMessage(_T("Table Unclamp���·� Table �̵� �� �� �����ϴ�."));
			return FALSE;
		}
	}
	
	if( dPos < m_pSetting[nAxisNo].dLimitMinus)//sAxisInfo.dLimitMinus )
	{
		return FALSE;
	}
	else if( dPos > m_pSetting[nAxisNo].dLimitPlus)//sAxisInfo.dLimitPlus )
	{
		return FALSE;
	}

	// HeightSensor
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 0)
	{
		if( (nAxisNo == AXIS_X || nAxisNo == AXIS_Y) && GetCurrentStatus(CURRENT_HEIGHT, TRUE) )
			return FALSE;
	}
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1)
	{
		if( (nAxisNo == AXIS_X || nAxisNo == AXIS_Y) && (GetCurrentStatus(CURRENT_HEIGHT, TRUE) || GetCurrentStatus(CURRENT_HEIGHT2, TRUE)) )
			return FALSE;
	}

	return TRUE;
}

void HMotorMP920::WriteMode(BYTE* pData, int& nCount)
{
	long nMode = 1;

	WriteLong( pData, nMode, nCount );
}

void HMotorMP920::WriteMode2(BYTE* pData, int& nCount)
{
	long nMode = 0;
	
	WriteLong( pData, nMode, nCount );
}

void HMotorMP920::WriteCurrentPos(BYTE* pData, int& nCount)
{
	int nSize = GetAxisSize();
	for( int i = 0 ; i < nSize ; i++ )
	{
		m_bIsInPosition[i] = FALSE;
		m_nWritePos[i] = m_lpDataNew->Index.lCommand[i];
		WriteLong( pData, m_lpDataNew->Index.lCommand[i], nCount );
	}
}

void HMotorMP920::WritePosition(BYTE* pData, int nAxisNo, double dPos)
{
	int nAddr = 4 + ( nAxisNo * 4 );
	double dScale;
//	SAXISINFO sAxisInfo;

//	memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
//	if( FALSE == GetAxisInfo( nAxisNo, &sAxisInfo ) )
//		dScale = 1.;

	dScale = m_pSetting[nAxisNo].dScale;//sAxisInfo.dScale;
	long nPos = long( dPos * dScale );

	m_nWritePos[nAxisNo] = nPos;
	m_bIsInPosition[nAxisNo] = TRUE;
	pData[nAddr]	= (BYTE)( nPos & 0xFF );
	pData[nAddr+1]	= (BYTE)( ( nPos >> 8 ) & 0xFF );
	pData[nAddr+2]	= (BYTE)( ( nPos >> 16 ) & 0xFF );
	pData[nAddr+3]	= (BYTE)( ( nPos >> 24 ) & 0xFF );
}

BOOL HMotorMP920::GetPosition(int nAxisNo, double &dPosition, BOOL b1stPanel)
{
/*
	int nAxisSize = GetAxisSize();
	
	if( nAxisNo > nAxisSize || nAxisNo < 0 )
		return FALSE;
	
	dPosition = m_lpDataNew->Index.dPosition[nAxisNo];

	return TRUE;
*/
	dPosition = m_lpDataNew->Index.dPosition[nAxisNo]; 
	if (nAxisNo == AXIS_X || nAxisNo == AXIS_Y)
	{
		double dx = m_lpDataNew->Index.dPosition[AXIS_X];
		double dy = m_lpDataNew->Index.dPosition[AXIS_Y];
		if(b1stPanel)
		{
			GetAxisMoveOffset(dx, dy, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			dPosition -= m_dCalibrationOffset[nAxisNo];
		}
		else
		{
			GetAxisMoveOffset(dx, dy, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			dPosition -= m_dSlaveCalibrationOffset[nAxisNo];
		}
	}
	return TRUE;
}

double HMotorMP920::GetPosition(int nAxisNo, BOOL b1stPanel)
{
/*
	int nAxisSize = GetAxisSize();

	if( nAxisNo > nAxisSize || nAxisNo < 0 )
		return 0.;

	return m_lpDataNew->Index.dPosition[nAxisNo];
*/
	double dPosition = m_lpDataNew->Index.dPosition[nAxisNo];
	if (nAxisNo == AXIS_X || nAxisNo == AXIS_Y)
	{
		double dx = m_lpDataNew->Index.dPosition[AXIS_X];
		double dy = m_lpDataNew->Index.dPosition[AXIS_Y];
		if(b1stPanel)
		{
			GetAxisMoveOffset(dx, dy, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			dPosition -= m_dCalibrationOffset[nAxisNo];
		}
		else
		{
			GetAxisMoveOffset(dx, dy, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			dPosition -= m_dSlaveCalibrationOffset[nAxisNo];
		}
	}
//	else if(nAxis == AXIS_M2)
//	{
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//		
//		long lCurrPos;
//		Servo_GetActualPos(0, &lCurrPos);
//		dPosition = (double)lCurrPos/ m_dScale[nAxis];		
//#endif
//	}
//	else if( nAxis == AXIS_M3)
//	{
//#ifdef __SERVO_MOTOR__
//		if(!m_bConnect)
//			return FALSE;
//		
//		long lCurrPos;
//		Servo_GetActualPos(1, &lCurrPos);
//		dPosition = (double)lCurrPos/ m_dScale[nAxis];		
//#endif
//	}
	return dPosition;
}

double HMotorMP920::GetMoveSpeed(int nAxisNo)
{
/*
	int nAxisSize = GetAxisSize();

	if( nAxisNo > nAxisSize || nAxisNo < 0 )
		return 0.;

	SAXISINFO sAxisInfo;

	memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
	if( FALSE == GetAxisInfo( nAxisNo, &sAxisInfo ) )
		return 0.;

	return 1;//sAxisInfo.dMoveVelocity;
*/
	if(nAxisNo >= MOTOR_AXIS_MAX)
		return 0.;

	return m_pSetting[nAxisNo].dTableFeedRate;
}

BOOL HMotorMP920::SetOutPort(DWORD dwOffset, DWORD dwOnOff, BOOL bAbs)
{
	WORD wOffset = (WORD)dwOffset;
	WORD wOnOff = (WORD)dwOnOff;

	return WriteWordData( wOffset, wOnOff, bAbs );
}

BOOL HMotorMP920::HandlerOperation(int nHandlerOperationID, BOOL bAction)
{
#ifdef __NOUSE_MP920__
	return TRUE;
#endif

	BOOL bRet = 0;

	switch( nHandlerOperationID )
	{
	case HANDLER_LOADER_ALIGN :
		bRet = WriteLoadCommand( LOADER_ALIGN );
		break;
	case HANDLER_LOADER_LOAD :
		bRet = WriteLoadCommand( LOADER_LOADING );
		break;
	case HANDLER_LOADER_HOMING :
		bRet = WriteLoadCommand( LOADER_ORIGIN );
		break;
	case HANDLER_LOADER_PICKER :
			if( FALSE == bAction ) // DOWN
				bRet = WriteLoadCommand( LOADER_PICKER_DOWN );
			else // TRUE, UP
				bRet = WriteLoadCommand( LOADER_PICKER_UP );
		break;
	case HANDLER_UNLOADER_UNLOAD :
//		if( FALSE == bAction )
//			bRet = WriteUnloadCommand( UNLOADER_UNLOADING2 );
//		else
			bRet = WriteUnloadCommand( UNLOADER_UNLOADING1 );
		break;
	case HANDLER_UNLOADER_HOMING :
		bRet = WriteUnloadCommand( UNLOADER_ORIGIN );
		break;

	case UI_DIRLL_STATUS_SET:
		bRet = WriteLoadReadyReset( bAction );
		break;
	case HANDLER_UNLOADER_PICKER :
		{
			UNLOADERCOMMAND wUnloaderCmd;

			switch( bAction )
			{
			case 0 : // Down
				wUnloaderCmd = UNLOADER_PICKER_DOWN;
				break;
			case 1 : // Up
				wUnloaderCmd = UNLOADER_PICKER_UP;
				break;
			case 2 : // Left
				wUnloaderCmd = UNLOADER_PICKER_LEFT;
				break;
			case 3 : // Right
				wUnloaderCmd = UNLOADER_PICKER_RIGHT;
				break;
			}

			return WriteUnloadCommand( wUnloaderCmd );
		}
		break;
	default :
		bRet = FALSE;
	}

	return bRet;
}

BOOL HMotorMP920::WriteLoadCommand(LOADERCOMMAND wLoaderCmd)
{
	WORD wAddr = ADD0B_LOAD_COMMAND;
	BYTE bData = 0;
	
	bData = wLoaderCmd;

	return WriteWordData( wAddr, bData, TRUE );
}

BOOL HMotorMP920::WriteLoadReadyReset(BOOL bDrill)
{
	WORD wAddr = ADD0B_LOAD_READY_RESET;
	BYTE bData = 0;
	
	bData = (BYTE)bDrill;

	return WriteWordData( wAddr, bData, TRUE );
}

BOOL HMotorMP920::WriteUnloadCommand(UNLOADERCOMMAND wUnloaderCmd)
{
	WORD wAddr = ADD0B_UNLOAD_COMMAND;
	BYTE bData = 0;
	
	bData = wUnloaderCmd;

	return WriteWordData( wAddr, bData, TRUE );
}

BOOL HMotorMP920::IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait)
{
#ifdef __NOUSE_MP920__
	return TRUE;
#endif

	BOOL bRet = 0;

	switch( nHandlerOperationID )
	{
	case HANDLER_LOADER_ALIGN :
		{
			if( bWait )
			{
				if( bStop )
					return IsInPositionThread( -1, COMMAND_ALIGNERSTOP );

				return IsInPositionThread( -1, COMMAND_ALIGNERMOVING );
			}

			if( bStop )
				return m_lpDataNew->Load.bAlignStop;

			return m_lpDataNew->Load.bAlignRun;
		}
		break;
	case HANDLER_LOADER_LOAD :
		{
			if( bWait )
			{
				if( bStop )
					return IsInPositionThread( -1, COMMAND_LOADSTOP );

				return IsInPositionThread( -1, COMMAND_LOADMOVING );
			}

			if( bStop )
				return m_lpDataNew->Load.bLoaderStop;

			return m_lpDataNew->Load.bLoaderRun;
		}
		break;
	case HANDLER_UNLOADER_UNLOAD :
		{
			if( bWait )
			{
				if( bStop )
					return IsInPositionThread( -1, COMMAND_UNLOADSTOP );

				return IsInPositionThread( -1, COMMAND_UNLOADMOVING );
			}

			if( bStop )
				return m_lpDataNew->UnLoad.bUnloadStop;

			return m_lpDataNew->UnLoad.bUnloadRun;
		}
		break;
	case HANDLER_UNLOADER_TO_LOAD_START :
		{
			if(m_lpDataNew->UnLoad.bUnloadToLoadStart )
				return TRUE;
			else
				return FALSE;
		}
		break;
	case HANDLER_UNLOADER_CHECK :
		{
			return !m_lpDataNew->UnLoad.bUnloadToLoadStart;
		}
		break;
	default :
		bRet = FALSE;
		break;
	}

	return bRet;
}

BOOL HMotorMP920::IsInPosition(int nAxis, BOOL bWait)
{
#ifdef __TEST__
	return TRUE;
#endif
	
#ifdef __NOUSE_MP920__
	return TRUE;
#endif

	if( FALSE == bWait )
		return IsMotor( nAxis, m_lpDataNew->Index.bIsPosition );

	CCorrectTime	MyTestTime;
	MyTestTime.StartTime();
	double dWaitTime = 0.0;
		
	while(TRUE)
	{
		::Sleep(0);
		m_nInPositionAxis = nAxis;
		if(IsInPositionThread( nAxis, COMMAND_INPOSITION ))
		{
			return TRUE;
		}
			
		dWaitTime = MyTestTime.PresentTime();
		if(dWaitTime > 10) // 10 sec time out
			return FALSE;
	}
}

BOOL HMotorMP920::IsInOrigin(int nAxis, BOOL bWait)
{
#ifdef __NOUSE_MP920__
	return TRUE;
#endif
	if( FALSE == bWait )
		return IsMotor( nAxis, m_lpDataNew->Index.bIsOrigin );

	m_nInPositionAxis = nAxis;
	return IsInPositionThread( nAxis, COMMAND_INORIGIN );
}

void HMotorMP920::CreateTableCalibration()
{
	switch( GetCalType() )
	{
	case 0 :
		m_pCalibration = new CBiLinear;
		break;
	case 1 :
		m_pCalibration = new CBicubicInterpolation;
		break;
	//case 2 :
		//m_pCalibration = new CBicubicSpline;
		//break;
	default :
		m_pCalibration = new CBiLinear;
		break;
	}
}

void HMotorMP920::LoadCalibrationFile(CString strPath)
{
	CString strFileName;
	strFileName.Format(_T("%sxy.calibration"), strPath);
	m_Calibration->LoadCalibration(strFileName);
	
	strFileName.Format(_T("%sxy.Scalibration"), strPath);
	m_SlaveCalibration->LoadCalibration(strFileName);
}

BOOL HMotorMP920::AutoSaveInit()
{
	if( NULL != m_pAutoData )
	{
		delete m_pAutoData;
		m_pAutoData = NULL;
	}

	m_pAutoData = new SAUTODATA;
	m_nAutoDataMax = 0;

	return TRUE;
}

BOOL HMotorMP920::AutoSaveXY(double dPosX, double dPosY)
{
	if(m_nAutoDataMax >= MAX_AUTODATA)
		return FALSE;

	TRACE(_T("AUTO SAVE NO : %3d %10.3f %10.3f\n"), m_nAutoDataMax, dPosX, dPosY);
	m_pAutoData->dMoveXY[m_nAutoDataMax].dX = dPosX;
	m_pAutoData->dMoveXY[m_nAutoDataMax].dY = dPosY;
	m_nAutoDataMax++;

	return TRUE;
}

BOOL HMotorMP920::AutoSaveZ(double dPosZ)
{
	TRACE(_T("AUTO SAVE Z1 : %10.3f\n"), dPosZ);

	m_pAutoData->dMoveZ1	= dPosZ;
	m_pAutoData->dMoveZ2	= 0.0;

	return TRUE;
}

BOOL HMotorMP920::AutoSaveZ(double dPosZ1, double dPosZ2)
{
	TRACE(_T("AUTO SAVE Z1 Z2 : %10.3f %10.3f\n"), dPosZ1, dPosZ2);
	
	m_pAutoData->dMoveZ1	= dPosZ1;
	m_pAutoData->dMoveZ2	= dPosZ2;

	return TRUE;
}

BOOL HMotorMP920::AutoNext(int nCount)
{
	if (nCount >= m_nAutoDataMax || nCount < 0)
		return FALSE;

	BOOL bFlag = FALSE;
	double dPosX = m_pAutoData->dMoveXY[nCount].dX;
	double dPosY = m_pAutoData->dMoveXY[nCount].dY;

	bFlag = MoveXYZ1Z2(dPosX, dPosY, m_pAutoData->dMoveZ1,m_pAutoData->dMoveZ2);
	TRACE(_T("AUTO STEP : %3d %.3f %.3f %.3f %.3f \n"),	nCount,	dPosX, dPosY, m_pAutoData->dMoveZ1, 
													m_pAutoData->dMoveZ2);

	return bFlag;
}

int HMotorMP920::GetAutoDataMax()
{
	return m_nAutoDataMax;
}

BOOL HMotorMP920::SetOffset(int nAxisNo, double dOffset, double dScale)
{
	m_nOriginOffset[nAxisNo] = long( dOffset * dScale );

	int nSize = GetAxisSize();
	if( nAxisNo == (nSize-1) )
	{
		long nOffset = 0;
		int nCount = 0;
		BYTE bOffsetData[REG_DATA_MAX] = {0,};
		
		for( int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			nOffset = m_nOriginOffset[i];
			WriteLong( bOffsetData, nOffset, nCount );
		}

		return WriteArrayData( ADD0B_ORIGIN_OFFSET, (WORD)nCount, bOffsetData );
	}

	return FALSE;
}

BOOL HMotorMP920::SetSpeed(int nAxisNo, long nSpeed)
{
	m_nWorkSpeed[nAxisNo] = nSpeed;

	int nSize = GetAxisSize();
	if( nAxisNo == (nSize-1) )
	{
		long nSpeed;
		int nCount = 0;
		BYTE bSpeedData[REG_DATA_MAX] = {0,};
		
		for( int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			nSpeed = m_nWorkSpeed[i];
			WriteLong( bSpeedData, nSpeed, nCount );
		}

		return WriteArrayData( ADD0B_INDEX_SPEED, (WORD)nCount, bSpeedData );
	}

	return FALSE;
}

BOOL HMotorMP920::SetOriginSpeed(int nAxisNo, long nSpeed)
{
	m_nOriginSpeed[nAxisNo] = nSpeed;

	int nSize = GetAxisSize();
	if( nAxisNo == (nSize-1) )
	{
		long nSpeed;
		int nCount = 0;
		BYTE bSpeedData[REG_DATA_MAX] = {0,};
		
		for( int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			nSpeed = m_nOriginSpeed[i];
			WriteLong( bSpeedData, nSpeed, nCount );
		}

		return WriteArrayData( ADD0B_ORIGIN_SPEED, (WORD)nCount, bSpeedData );
	}

	return FALSE;
}

BOOL HMotorMP920::SetMaskPosition(double dMaskPosition[], double dMaskPosition2[])
{
	for(int i = 0; i < MOTOR_MASK_MAX; i++)
	{
		m_dMaskPosition[i] = dMaskPosition[i];
		m_dMaskPosition2[i] = dMaskPosition2[i];
	}

	return TRUE;
}
/*
void HMotorMP920::ReadProfile()
{
	int nSize = GetAxisSize();
	SAXISINFO sAxisInfo;

	for(int i = 0 ; i < nSize ; i++ )
	{
		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

		if( FALSE == GetAxisInfo( i, &sAxisInfo ) )
		{
			sAxisInfo.dHomeOffset = 0.;
			sAxisInfo.dMoveVelocity = 0;
			sAxisInfo.dHomeVelocity = 0;
			sAxisInfo.dScale = 1.;
		}

		SetOffset( i, sAxisInfo.dHomeOffset, sAxisInfo.dScale );
		SetSpeed( i, long(sAxisInfo.dMoveVelocity) );
		SetOriginSpeed( i, long(sAxisInfo.dHomeVelocity) );
	}
}

void HMotorMP920::WriteProfile()
{
	int nSize = GetAxisSize();
	SAXISINFO sAxisInfo;

	for(int i = 0 ; i < nSize ; i++ )
	{
		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

		if( FALSE == GetAxisInfo( i, &sAxisInfo ) )
		{
			sAxisInfo.dHomeOffset = 0.;
			sAxisInfo.dMoveVelocity = 0;
			sAxisInfo.dHomeVelocity = 0;
			sAxisInfo.dScale = 1.;
		}

		SetOffset( i, sAxisInfo.dHomeOffset, sAxisInfo.dScale );
		SetSpeed( i, long(sAxisInfo.dMoveVelocity) );
		SetOriginSpeed( i, long(sAxisInfo.dHomeVelocity) );
	}

	SetLimitZ();
}
*/
void HMotorMP920::GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag)
{
#ifdef __NOUSE_MP920__
	dXOffset = 0;
	dYOffset = 0;
	return;
#endif
	// reference of reference is undefined. so this stupid-like handling
	double dXOff, dYOff, dXOff2, dYOff2;
	m_Calibration->GetCalibrationOffset(dX, dY, dXOff, dYOff);
	m_SlaveCalibration->GetCalibrationOffset(dX, dY, dXOff2, dYOff2);
	if(cFlag == FIRST_PANEL_OFFSET)
	{
		dXOffset = (int(dXOff*100000))/100000.0;
		dYOffset = (int(dYOff*100000))/100000.0;
	}
	else if(cFlag == SECOND_PANEL_OFFSET)
	{
		dXOffset = (int(dXOff2*100000))/100000.0;
		dYOffset = (int(dYOff2*100000))/100000.0;
	}
	else
	{
		dXOffset = (int((dXOff2 - dXOff)*100000))/100000.0;
		dYOffset = (int((dYOff2 - dYOff)*100000))/100000.0;
	}
}

BOOL HMotorMP920::SetLimitZ()
{
	BOOL bRet = 0;
//	SAXISINFO sAxisInfo;

//	memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

	if( 1 == GetUseDualPanel() )
	{
		double dZ1Min, dZ1Max, dZ2Min, dZ2Max;

		// Z1
//		if( FALSE == GetAxisInfo( AXIS_Z1, &sAxisInfo ) )
//			return FALSE;

		dZ1Min = m_pSetting[AXIS_Z1].dLimitMinus * m_pSetting[AXIS_Z1].dScale;
		dZ1Max = m_pSetting[AXIS_Z1].dLimitPlus * m_pSetting[AXIS_Z1].dScale;

		// Z2
//		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );
//		if( FALSE == GetAxisInfo( AXIS_Z2, &sAxisInfo ) )
//			return FALSE;

		dZ2Min = m_pSetting[AXIS_Z2].dLimitMinus * m_pSetting[AXIS_Z2].dScale;
		dZ2Max = m_pSetting[AXIS_Z2].dLimitPlus * m_pSetting[AXIS_Z2].dScale;

		long nData = 0;
		int nCount = 0;
		BYTE bLimitData[REG_DATA_MAX] = {0,};

		nData = long( dZ1Min );
		WriteLong( bLimitData, nData, nCount );
		nData = long( dZ1Max );
		WriteLong( bLimitData, nData, nCount );
		nData = long( dZ2Min );
		WriteLong( bLimitData, nData, nCount );
		nData = long( dZ2Max );
		WriteLong( bLimitData, nData, nCount );

		bRet = WriteArrayData( ADD0B_AXISZ_LIMIT_POS, (WORD)nCount, bLimitData );
	}
	else
	{
		double dZMin, dZMax;

//		if( FALSE == GetAxisInfo( SINGLE_X, &sAxisInfo ) )
//			return FALSE;

		dZMin = m_pSetting[AXIS_Z1].dLimitMinus * m_pSetting[AXIS_Z1].dScale;
		dZMax = m_pSetting[AXIS_Z1].dLimitPlus * m_pSetting[AXIS_Z1].dScale;

		long nData = 0;
		int nCount = 0;
		BYTE bLimitData[REG_DATA_MAX] = {0,};

		nData = long( dZMin );
		WriteLong( bLimitData, nData, nCount );
		nData = long( dZMax );
		WriteLong( bLimitData, nData, nCount );

		bRet = WriteArrayData( ADD0B_AXISZ_LIMIT_POS, (WORD)nCount, bLimitData );
	}

	return bRet;
}

BOOL HMotorMP920::SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnloadX, double dUnloadY)
{
	long nData = 0;
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX] = {0,};

	nData = long( dLoadX );
	WriteLong( bPosData, nData, nCount );
	nData = long( dLoadY );
	WriteLong( bPosData, nData, nCount );
	nData = long( dUnloadX );
	WriteLong( bPosData, nData, nCount );
	nData = long( dUnloadY );
	WriteLong( bPosData, nData, nCount );

	return WriteArrayData( ADD0B_LOADER_UNLOADER_POS, (WORD)nCount, bPosData );
}

BOOL HMotorMP920::SetLoaderUnloaderPos2(double dLoadX, double dLoadY)
{
	long nData = 0;
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX] = {0,};

	nData = long( dLoadX );
	WriteLong( bPosData, nData, nCount );
	nData = long( dLoadY );
	WriteLong( bPosData, nData, nCount );

	return WriteArrayData( ADD0B_LOADER_UNLOADER_POS2, (WORD)nCount, bPosData );
}

BOOL HMotorMP920::SetShutter(BOOL bMaster, BOOL bSlave)
{
	WORD wData = 0;
	int nCount = 0;
	BYTE bShutterData[REG_DATA_MAX] = {0,};

	wData = (WORD)bMaster;
	WriteWord( bShutterData, wData, nCount );
	wData = (WORD)bSlave;
	WriteWord( bShutterData, wData, nCount );

	WORD wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_MASTER;

	return WriteArrayData( wAddr, (WORD)nCount, bShutterData );
}

void HMotorMP920::InPositionStop()
{
	m_nInPositionStatus = -3;
}

BOOL HMotorMP920::StopMotor(int nAxis)
{
	long nStop = 0;
	int nCount = 0;
	BYTE bStopData[REG_DATA_MAX] = {0,};

	nStop = INDEX_NULL;
	WriteLong( bStopData, nStop, nCount );

	return WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bStopData );
}

long HMotorMP920::GetCurrentError(ERRORCOMMAND nError)
{
	long nVal = 0;

	switch( nError )
	{
	case ERROR_IO :
		nVal = m_lpDataNew->IO.lErrorIo;
		break;
	case ERROR_LOAD :
		nVal = m_lpDataNew->IO.lErrorLoad;
		break;
	case ERROR_UNLOAD :
		nVal = m_lpDataNew->IO.lErrorUnload;
		break;
	case ERROR_ALIGN :
		nVal = m_lpDataNew->IO.lErrorAligner;
		break;
	case ERROR_TABLELIMIT :
		nVal = m_lpDataNew->IO.lErrorTableLimit;
		break;
	case ERROR_OTHERLIMIT :
		nVal = m_lpDataNew->IO.lErrorOtherLimit;
		break;
	case ERROR_TABLE :
		nVal = m_lpDataNew->IO.lErrorTable;
		break;
	case ERROR_LASER :
		nVal = m_lpDataNew->IO.lErrorLaser;
		break;
	}

	return nVal;
}

int HMotorMP920::GetCurrentMode()
{
	return m_lpDataNew->IO.nMode;
}

BOOL HMotorMP920::IsSafetyMode()
{
	if(m_lpDataNew->IO.nMode == MODE_SAFE)
		return TRUE;
	else 
		return FALSE;
}

int HMotorMP920::GetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag)
{
	int nStat = 0;

	switch( nStatus )
	{
	case CURRENT_MODE :
		nStat = m_lpDataNew->IO.nMode;
		break;
	case CURRENT_CYCLE :
		nStat = m_lpDataNew->IO.nCycle;
		break;
	case CURRENT_SYSTEM :
		nStat = m_lpDataNew->IO.nSystem;
		break;
	case CURRENT_EMSTOP :
		nStat = m_lpDataNew->IO.nEMStop;
		break;
	case CURRENT_SHUTTER1 :
		nStat = m_lpDataNew->IO.nHighShutter1;
		break;
	case CURRENT_SHUTTER2 :
		nStat = m_lpDataNew->IO.nHighShutter2;
		break;
	case CURRENT_SUCTION :
		// 1 = 1stSuctionCmd, 2 = 2ndSuctionCmd, 4 = 1stSuctionSol, 8 = 2ndSuctionSol
		nStat = m_lpDataNew->IO.nIsSuction;
		break;
	case CURRENT_LOADDETECT :
		nStat = m_lpDataNew->IO.nIsPcbLoad;
		break;
	case CURRENT_UNLOADDETECT :
		nStat = m_lpDataNew->IO.nIsPcbUnload;
		break;
	case CURRENT_DUSTSUCTION :
		nStat = m_lpDataNew->IO.nDustSuction;
		break;
	case EXTERNAL_LASER :
		nStat = m_lpDataNew->IO.nExternalLaser;
		break;
	case CURRENT_HEIGHT :
#ifdef __NOUSE_MP920__
		nStat = 0;
#else
		if( FALSE == bFlag ) // Hight Sensor Up
			nStat = m_lpDataNew->IO.lErrorIo & 0x0010;
		else // Height Sensor Down
			nStat = m_lpDataNew->IO.lErrorIo & 0x0020;
#endif
		break;

	case CURRENT_CHILLER :
		nStat = m_lpDataNew->IO.nChillerAlarm;
		break;

#ifdef __CUNGJU_JASMINE_OLD__
	case CURRENT_HEIGHT2 :
#ifdef __NOUSE_MP920__
		nStat = 0;
#else
		if( FALSE == bFlag ) // Hight Sensor Up
			nStat = m_lpDataNew->IO.lErrorIo & 0x0010;
		else // Height Sensor Down
			nStat = m_lpDataNew->IO.lErrorIo & 0x0020;
#endif
		break;
	case CURRENT_CLAMP1 :
//		nStat = m_lpDataNew->IO.nTableClamp; // up : 1, down :2
		break;
	case CURRENT_CLAMP2 :
//		nStat = m_lpDataNew->IO.nTableClamp2;
		break;
#endif
	}



	return nStat;
}

BOOL HMotorMP920::SetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag)
{
	BOOL bRet = TRUE;
	WORD wAddr;

	switch( nStatus )
	{
	case CURRENT_SHUTTER1 :
		wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_MASTER;
		SetOutPort( wAddr, bFlag, TRUE );
		break;
	case CURRENT_SHUTTER2 :
		wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_SLAVE;
		SetOutPort( wAddr, bFlag, TRUE );
		break;
	case CURRENT_HEIGHT :
		wAddr = ADD0B_WRITE_OUTPORT + PORT_HEIGHT_SENSOR;
		SetOutPort( wAddr, bFlag, TRUE );
		break;
	default :
		bRet = FALSE;
		break;
	}

	return bRet;
}

int HMotorMP920::IsStatus(ISSTATUS nStatus, BOOL bFlag)
{
	int nIsStat = 0;

	switch( nStatus )
	{
	case IS_READY :
		nIsStat = IsMotor( int(bFlag), m_lpDataNew->Index.bIsReady );
		break;
	case IS_SCANNER_FAULT :
		{
			long nError = m_lpDataNew->IO.lError[3];
			UINT nIsFault = 0;
	
			nIsFault += (nError & 0x0008) ? 1 : 0;
			nIsFault += (nError & 0x0010) ? 2 : 0;
			nIsFault += (nError & 0x0020) ? 4 : 0;
			nIsFault += (nError & 0x0040) ? 8 : 0;

			nIsStat = nIsFault;
		}
		break;
	case IS_CLOSED_HS :
		{
			long nError = m_lpDataNew->IO.lError[3];

			nIsStat = (nError & 0x0004) ? TRUE : FALSE;
		}
		break;
	case IS_OPEN_LASER_SHUTTER :
		{
			long nError = m_lpDataNew->IO.lError[2];

			BOOL bOpen	= (nError & 0x0080) ? TRUE : FALSE;	// Laser Shutter Closed ����
			BOOL bClose	= (nError & 0x0100) ?  TRUE: FALSE;	// Laser Shutter Open ����

			if((bClose && bOpen) || (!bClose && !bOpen))
				nIsStat = -1;
			else 
				nIsStat = bOpen;
		}
		break;
	case IS_FLOW_WATER :
		{
			long nError = m_lpDataNew->IO.lError[2];

			nIsStat = (nError & 0x2000) ? FALSE : TRUE; // WaterFlow Error
		}
		break;
	case IS_LOADER_STOP :
		{
			long nError = m_lpDataNew->IO.lError[2];
			
			nIsStat = (nError & 0x4000) ? TRUE : FALSE; // Load/Unload Stop error
		}
		break;
	case IS_UNLOADER_STOP :
		{
			long nError = m_lpDataNew->IO.lError[2];
			
			nIsStat = (nError & 0x8000) ? TRUE : FALSE; // Load/Unload Stop error
		}
		break;
	case IS_SYSTEM_ALARM_OFF_ERROR :
		{
			long nError = m_lpDataNew->IO.lError[3];

			nIsStat = (nError & 0x0200) ? TRUE : FALSE;
		}
		break;
	case IS_SYSTEM_DOOR_BYPASS :
		{
//			long nError = m_lpDataNew->IO.lError[5];
			
//			nIsStat = (nError & 0x0010) ? TRUE : FALSE;	
		}
		break;
	case IS_MAIN_DOOR_STOP :
		{
			long nError = m_lpDataNew->IO.lError[3];

			nIsStat = (nError & 0x0080) ? TRUE : FALSE;
		}
		break;
	case IS_OPTICS_DOOR_STOP :
		{
			long nError = m_lpDataNew->IO.lError[3];

			nIsStat = (nError & 0x0100) ? TRUE : FALSE;
		}
		break;
	case IS_MAIN_DOOR_OPEN :
		{
//			long nError = m_lpDataNew->IO.lError[5];

//			nIsStat = (nError & 0x0080) ? TRUE : FALSE;
		}
		break;
	case IS_LOADER_DOOR_OPEN :
		{
//			long nError = m_lpDataNew->IO.lError[5];

//			nIsStat = (nError & 0x0200) ? TRUE : FALSE;
		}
		break;
	case IS_UNLOADER_DOOR_OPEN :
		{
//			long nError = m_lpDataNew->IO.lError[5];
			
//			nIsStat = (nError & 0x0400) ? TRUE : FALSE;
		}
		break;
	case IS_OPTICS_DOOR_OPEN :
		{
//			long nError = m_lpDataNew->IO.lError[5];

//			nIsStat = (nError & 0x0100) ? TRUE : FALSE;
		}
		break;
	case IS_BYPASS_ON :
		{
			long nError = m_lpDataNew->IO.lError[2];

			nIsStat = (nError & 0x0001) ? TRUE : FALSE;
		}
		break;
	}

	return nIsStat;
}

BOOL HMotorMP920::ReadAutoSetting()
{
	BOOL bRet = FALSE;
/*	CString strFilePath;
	CAutoSettingFile clsAutoFile;

	strFilePath.Format(_T("%sauto.ini"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	bRet = clsAutoFile.OpenAutoSettingFile( strFilePath, &m_sAutoSetting );

	if( FALSE != bRet )
	{
		SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
							  m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000. );
	}*/

	return bRet;
}

BOOL HMotorMP920::WriteAutoSetting()
{
	BOOL bRet = FALSE;
/*	CString strFilePath;
	CAutoSettingFile clsAutoFile;

	strFilePath.Format(_T("%sauto.ini"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	bRet = clsAutoFile.SaveAutoSettingFile( strFilePath, m_sAutoSetting );

	if( FALSE != bRet )
	{
		SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
							  m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000. );
	}*/

	return bRet;
}

BOOL HMotorMP920::SetAutoSetting(SAUTOSETTING sAutoSetting)
{
	memcpy( &m_sAutoSetting, &sAutoSetting, sizeof(m_sAutoSetting) );

	return TRUE;
}

BOOL HMotorMP920::DownloadAxisInfo()
{
/*
	BOOL bRet = FALSE;
	
	int nSize = GetAxisSize();
	SAXISINFO sAxisInfo;

	for(int i = 0 ; i < nSize ; i++ )
	{
		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

		if( FALSE == GetAxisInfo( i, &sAxisInfo ) )
		{
//			sAxisInfo.dHomeOffset = 0.;
//			sAxisInfo.dMoveVelocity = 0;
//			sAxisInfo.dHomeVelocity = 0;
//			sAxisInfo.dScale = 1.;
		}

//		SetOffset( i, sAxisInfo.dHomeOffset, sAxisInfo.dScale );
//		SetSpeed( i, long(sAxisInfo.dMoveVelocity) );
//		SetOriginSpeed( i, long(sAxisInfo.dHomeVelocity) );
	}
*/

	BOOL bRet = FALSE;
	
	for(int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
	{
		SetSpeed( i, long(m_pSetting[i].dTableFeedRate) );
		SetOffset( i, m_pSetting[i].dTableAcceleration, m_pSetting[i].dScale);
//		SetScale( i, m_pSetting[i].dScale );
	}

	SetLimitZ();

	bRet = TRUE;

	return bRet;
}

BOOL HMotorMP920::DownloadAutoSetting()
{
	BOOL bRet = FALSE;

	bRet = SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
						  m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000. );

	bRet = bRet & SetLoaderUnloaderPos2(m_sAutoSetting.dLoadPosX2 * 1000., m_sAutoSetting.dLoadPosY2 * 1000.);
	return bRet;
}

void HMotorMP920::SetScale(int nAxis, double dScale)
{

}

void HMotorMP920::UpdateCalibrationFile(CString strPath)
{
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;
	CString strFileName(strPath + TABLE_CALIBRATION_FILE);
	
	if (NULL == fopen_s(&fp, strFileName, _T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			ErrMessage(_T("FileError1"));
			fclose(fp);
			return;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			ErrMessage(_T("FileError2"));
			fclose(fp);
			return;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			ErrMessage(_T("FileError3"));
			fclose(fp);
			return;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			ErrMessage(_T("FileError4"));
			fclose(fp);
			return;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			ErrMessage(_T("FileError5"));
			fclose(fp);
			return;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			ErrMessage(_T("FileError6"));
			fclose(fp);
			return;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			ErrMessage(_T("SizeError1"));
			fclose(fp);
			return;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return;
		}
		END_CATCH

		double dX = 0.0, dY = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					ErrMessage(_T("FileError7"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					ErrMessage(_T("FileError8"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					ErrMessage(_T("FileError9"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1000.0)
				{
					ErrMessage(_T("PositionError1"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					ErrMessage(_T("FileError10"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dX = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					ErrMessage(_T("FileError11"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dY = atof(token);

				if (fabs(dX) > 5.0 || fabs(dY) > 5.0)
				{
					ErrMessage(_T("SizeError2"));
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = dY;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		m_Calibration->UpdateCalibration(calHead);
		delete [] dpOffset;
	}
}

BYTE HMotorMP920::GetCurrentSuction()
{
	return m_lpDataNew->IO.nIsSuction;
}

BOOL HMotorMP920::MotorMove()
{
	return TRUE;
	
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	
	BOOL bRet = 0;
	
	bRet = WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
	
	return bRet;
}

BOOL HMotorMP920::FireMoveXY(double dX, double dY, double dSFX, double dEFX, int nSpeed, int nLaserOnDelay, int nLaserOffDelay)
{
	return FALSE;
}

BOOL HMotorMP920::SetAxisInfo(SAXISINFO* sAxisInfo)
{
	memcpy( &m_pSetting, sAxisInfo, sizeof(m_pSetting) );
	
	return TRUE;
}

BOOL HMotorMP920::TableClamp(BOOL bClamp, BOOL bLeft)
{
	BOOL bRet;
	int n1st, n2nd;

	if(gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		return TRUE;
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		if(bClamp)
		{
			if(bLeft)
			{
				bRet = SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_CLAMP, 0x02);
			}
		}
		else
		{
			if(m_lpDataNew->Index.dPosition[AXIS_Y] > gProcessINI.m_sProcessAutoSetting.dUnclampLimitY)
			{
				ErrMessage(_T("Current Pos. can not Unclamping."));
				return FALSE;
			}
			
			if(bLeft)
			{
				bRet = SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_CLAMP, 0x04);
			}
		}
	}
	else
	{
		if(GetCurrentTableClamp(TRUE, TRUE))
			n1st = 0x02;
		else
			n1st = 0x04;
		
		if(GetCurrentTableClamp(FALSE, TRUE))
			n2nd = 0x08;
		else
			n2nd = 0x10;
		
		if(bClamp)
		{
			if(bLeft)
			{
				bRet = SetOutPort(PORT_TABLE_CLAMP, 0x02 + n2nd);
			}
			else
			{
				bRet = SetOutPort(PORT_TABLE_CLAMP, 0x08 + n1st);
			}
		}
		else
		{
			if(m_lpDataNew->Index.dPosition[AXIS_Y] > gProcessINI.m_sProcessAutoSetting.dUnclampLimitY)
			{
				ErrMessage(_T("Current Pos. can not Unclamping."));
				return FALSE;
			}
			
			if(bLeft)
			{
				bRet = SetOutPort(PORT_TABLE_CLAMP, 0x04 + n2nd);
			}
			else
			{
				bRet = SetOutPort(PORT_TABLE_CLAMP, 0x10 + n1st);
			}
		}
	}
	return bRet;
}

BOOL HMotorMP920::GetCurrentTableClamp(BOOL b1st, BOOL bClamp)
{
	if(b1st)
	{
		if(bClamp)
			return (m_lpDataNew->IO.nTableClamp & 0x02);
		else
			return (m_lpDataNew->IO.nTableClamp & 0x04);
	}
	else
	{
		if(gSystemINI.m_sHardWare.nTableClamp == 2)
		{
			if(bClamp)
				return (m_lpDataNew->IO.nTableClamp & 0x08);
			else
				return (m_lpDataNew->IO.nTableClamp & 0x10);
		}
	}

	return TRUE;
}

BOOL HMotorMP920::IsBMMotorHomeEnd()
{
#ifdef __TEST__
	return TRUE;
#endif

	return m_lpDataOld->Index.bIsOrigin[AXIS_C] & m_lpDataOld->Index.bIsOrigin[AXIS_M];		
}

BYTE HMotorMP920::GetCurrentShutter1()
{
#ifdef __TEST__
	return 1;
#endif
	return (m_lpDataNew->IO.nHighShutter1);
//		return 1; // open
//	else
//		return 2; // close
}

BYTE HMotorMP920::GetCurrentShutter2()
{
#ifdef __TEST__
	return 1;
#endif

	return m_lpDataNew->IO.nHighShutter2;
//		return 1; // open
//	else
//		return 2; // close
}

BOOL HMotorMP920::MotorShutterAll(BOOL bMaster, BOOL bSlave)
{
#ifdef __TEST__
	return TRUE;
#endif

	BOOL bRet = TRUE;
	WORD wAddr;

	wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_MASTER;
	bRet = SetOutPort( wAddr, bMaster, TRUE );

	wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_SLAVE;
	bRet &= SetOutPort( wAddr, bSlave, TRUE );

	return bRet;

}

BOOL HMotorMP920::MainReset(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::SetError(BOOL bError)
{
	return TRUE;
}

BOOL HMotorMP920::IsAnyError()
{
	return FALSE;
}

BOOL HMotorMP920::InPositionIO(int nAxis) 
{
	BOOL bRet = TRUE; 
	if((nAxis & 0x0001) && bRet)  // X 
	{
		bRet &= IsInPosition(AXIS_X);
	}

	if(((nAxis >> 1) & 0x0001) && bRet) // y 
	{
		bRet &= IsInPosition(AXIS_Y);
	}

	if(((nAxis >> 2) & 0x0001) && bRet) //z1
	{
		bRet &= IsInPosition(AXIS_Z1);
	}

	if(((nAxis >> 3) & 0x0001) && bRet) //z2 
	{
		bRet &= IsInPosition(AXIS_Z2);
	}

	if(((nAxis >> 4) & 0x0001) && bRet) // m 
	{
		bRet &= IsInPosition(AXIS_M);
	}

	if(((nAxis >> 5) & 0x0001) && bRet) // c 
	{
		bRet &= IsInPosition(AXIS_C);
	}

	if(((nAxis >> 6) & 0x0001) && bRet) //m2
	{
		bRet &= IsInPosition(AXIS_M2);
	}

	if(((nAxis >> 7) & 0x0001) && bRet) // c2
	{
		bRet &= IsInPosition(AXIS_C2);
	}

	return bRet;
}

BOOL HMotorMP920::GetCurrentLoadDetect(int nUsePanel)
{
	return m_lpDataNew->IO.nIsPcbLoad;
}

BOOL HMotorMP920::ScannerPower(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::SetAOMPowerON(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::IsLoaderPicker1PCBExist()
{
	return m_lpDataNew->IO.nIsPcbLoad & 0x01;
}

BOOL HMotorMP920::IsLoaderPicker2PCBExist()
{
	return m_lpDataNew->IO.nIsPcbLoad & 0x02;
}

BOOL HMotorMP920::IsLoadCartNoPCB()
{
	return 	m_lpDataNew->IO.lErrorLoad & 0x0002; // ������� ���� 
}

BOOL HMotorMP920::GetAOMStatus()
{
	return TRUE;
}

BOOL HMotorMP920::GetScannerStatus()
{
	return TRUE;
}

BOOL HMotorMP920::IsTable1PCBExist()
{
	if(m_lpDataNew->IO.nIsSuction & 0x01) // table vacuum���� ���� üũ 
		return TRUE;
	else
		return FALSE;
}

BOOL HMotorMP920::IsTable2PCBExist()
{
	if(m_lpDataNew->IO.nIsSuction & 0x02) // table vacuum���� ���� üũ 
		return TRUE;
	else
		return FALSE;
}

BOOL HMotorMP920::GetCurrentSuctionMotor()
{
	return m_lpDataNew->IO.nVacuumMotor; 
}

BOOL HMotorMP920::IsUnloaderPicker1PCBExist()
{
//	return m_lpDataNew->IO.nIsPcbUnload & 0x01;
	if(m_lpDataNew->IO.nIsPcbUnload & 0x01) 
		return TRUE;
	else
		return FALSE;
}

BOOL HMotorMP920::IsUnloaderPicker2PCBExist()
{
//	return m_lpDataNew->IO.nIsPcbUnload & 0x02;
	if(m_lpDataNew->IO.nIsPcbUnload & 0x02) 
		return TRUE;
	else
		return FALSE;
}

BOOL HMotorMP920::IsHandlerPartError(BOOL bLoader)
{
	if(bLoader)
	{
		return m_lpDataNew->IO.lErrorLoad;
	}
	else
	{
		return m_lpDataNew->IO.lErrorUnload;
	}
}

BOOL HMotorMP920::SetTowerLampBuzzer(int nColor, BOOL bBuzzer)
{	
	return TRUE;
}

BOOL HMotorMP920::IonizerOn(BOOL bOn)
{
	return TRUE;	
}

BOOL HMotorMP920::DustSuctionControl(BOOL bLeft, BOOL bUp)
{
	return TRUE;
}

BOOL HMotorMP920::HoodOpen(BOOL bOpen)
{
	return TRUE;
}

BOOL HMotorMP920::MoveTophatShutter(BOOL bUp)
{
	return TRUE;
}

BOOL HMotorMP920::MoveLaserBeamPath(BOOL bUp)
{
	return TRUE;
}

BOOL HMotorMP920::IsHoodOK(BOOL bOpen)
{
	return TRUE;
}

BOOL HMotorMP920::MainStop(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::MainReady(BOOL bOn)
{	
	return TRUE;
}

BOOL HMotorMP920::SetMoveIO(int nMoveAxis)
{
	// just move command 
	int nCount = 0;
	BYTE bPosData[REG_DATA_MAX];
	
	memset( &bPosData, 0, sizeof(bPosData) );
	WriteMode( bPosData, nCount );
	WriteCurrentPos( bPosData, nCount );

	BOOL bResult = TRUE;
	if(nMoveAxis == MOVE_XYZ)
	{
		WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
		WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
		WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
		WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
	}
	else if(nMoveAxis == MOVE_XY)
	{
		WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
		WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
	}
	else if(nMoveAxis == MOVE_XYMC)
	{
		WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
		WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
		WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );
		WritePosition( bPosData, AXIS_C, m_dDestinationPos[AXIS_C] );
	}
	else if(nMoveAxis == MOVE_XYZMC)
	{
		WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
		WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
		WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
		WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
		WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );
		WritePosition( bPosData, AXIS_C, m_dDestinationPos[AXIS_C] );
	}
	else if(nMoveAxis == MOVE_XYMCA)
	{
		WritePosition( bPosData, AXIS_X, m_dDestinationPos[AXIS_X] );
		WritePosition( bPosData, AXIS_Y, m_dDestinationPos[AXIS_Y] );
		WritePosition( bPosData, AXIS_Z1, m_dDestinationPos[AXIS_Z1] );
		WritePosition( bPosData, AXIS_Z2, m_dDestinationPos[AXIS_Z2] );
		WritePosition( bPosData, AXIS_M, m_dDestinationPos[AXIS_M] );
		WritePosition( bPosData, AXIS_C, m_dDestinationPos[AXIS_C] );
	}
	else
		return TRUE;

	return WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bPosData );
}

BOOL HMotorMP920::WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff)
{
	return TRUE;
}

BOOL HMotorMP920::GetCurrentAcrylSuction(BOOL b1st)
{
	if(b1st)
		return m_lpDataNew->IO.nIsSuction & 0x01;
	else
		return m_lpDataNew->IO.nIsSuction & 0x02; 
}

BOOL HMotorMP920::GetRawPosition(int nAxis, double &dPosition) // get real position 
{

#ifdef __TEST__
	return TRUE;
#else

	if(nAxis >= MOTOR_AXIS_MAX)
		return FALSE;
	else
		return TRUE;
	
	dPosition = m_lpDataNew->Index.dPosition[nAxis]; 

	return TRUE;
#endif
}

BOOL HMotorMP920::MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
	return MoveXYZ1Z2MC(dPosX,dPosY,dPosZ1,dPosZ2,dPosM,dPosC,b1stPanel,FALSE);
}
BOOL HMotorMP920::MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, nMaskPos, dPosC);
}
BOOL HMotorMP920::MoveZMCA2(double dPosZ1, double dPosZ2, double dPosM1, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, dPosM1, dPosC);
}
BOOL HMotorMP920::MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
	return MoveXYZ1Z2MC(dPosX,dPosY,dPosZ1,dPosZ2,dPosM,dPosC,b1stPanel,FALSE);
}

BOOL HMotorMP920::MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat)
{

	m_dDestinationPos[AXIS_M]	= dMaskPos;
	m_dDestinationPos[AXIS_C]	= dPosC;
	
	if(	FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}
BOOL HMotorMP920::MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
	m_dDestinationPos[AXIS_X]	= dPosX;
	m_dDestinationPos[AXIS_Y]	= dPosY;
	m_dDestinationPos[AXIS_Z1]	= dPosZ1;
	m_dDestinationPos[AXIS_Z2]	= dPosZ2;
	m_dDestinationPos[AXIS_M]	= dPosZ2;

	if(b1stPanel)
	{
		GetAxisMoveOffset( dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET );
		m_dDestinationPos[AXIS_X] += m_dCalibrationOffset[AXIS_X];
		m_dDestinationPos[AXIS_Y] += m_dCalibrationOffset[AXIS_Y];
	}
	else
	{
		GetAxisMoveOffset( dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET );
		m_dDestinationPos[AXIS_X] += m_dSlaveCalibrationOffset[AXIS_X];
		m_dDestinationPos[AXIS_Y] += m_dSlaveCalibrationOffset[AXIS_Y];
	}
	
	if( FALSE == IsValidAxisPosition( AXIS_X, m_dDestinationPos[AXIS_X] ) ||
		FALSE == IsValidAxisPosition( AXIS_Y, m_dDestinationPos[AXIS_Y] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z1, m_dDestinationPos[AXIS_Z1] ) ||
		FALSE == IsValidAxisPosition( AXIS_Z2, m_dDestinationPos[AXIS_Z2] )  )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}
	
	return TRUE;
}

BOOL HMotorMP920::MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat)
{
	m_dDestinationPos[AXIS_M]	= dMaskPos;
	m_dDestinationPos[AXIS_C]	= dPosC;
	
	if(	FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}

BOOL HMotorMP920::MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat)
{
	m_dDestinationPos[AXIS_M]	= dMaskPos;
	m_dDestinationPos[AXIS_C]	= dPosC;
	
	if(	FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}

BOOL HMotorMP920::MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, dMaskPos, dPosC);
}

BOOL HMotorMP920::MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
	return MoveXYZ1Z2MC(dPosX,dPosY,dPosZ1,dPosZ2,dPosM,dPosC,b1stPanel,FALSE);
}

BOOL HMotorMP920::MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove)
{
	return MoveZ1Z2(dPosZ1, dPosZ2, bRawMove);
}

BOOL HMotorMP920::MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, BOOL bZCalUse, int nMoveMode, BOOL bPass)
{
	return MoveXYZ1Z2(dPosX, dPosY, dPosZ1, dPosZ2, b1stPanel, FALSE);
}

BOOL HMotorMP920::MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
	return MoveXYZ1Z2(dPosX, dPosY, dPosZ1, dPosZ2, b1stPanel, FALSE);
}

BOOL HMotorMP920::MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, dMaskPos, dPosC);
}

BOOL HMotorMP920::IsReady(int nAxis)
{
	return m_lpDataNew->IO.nSystem;	
}

BOOL HMotorMP920::SetOutportTableVacuum(BOOL bUseBTable)
{
	return TRUE;
}

BOOL HMotorMP920::SetLimitYPos(double dPos)
{
	return TRUE;
}

BOOL HMotorMP920::Stop(int nAxis)
{
	long nStop = 0;
	int nCount = 0;
	BYTE bStopData[REG_DATA_MAX] = {0,};
	
	nStop = INDEX_NULL;
	WriteLong( bStopData, nStop, nCount );
	
	return WriteArrayData( ADD0B_INDEX_POSITION, (WORD)nCount, bStopData );
}

void HMotorMP920::SetAxisSpeed(int nAxis, long nSpeed)
{
	m_nWorkSpeed[nAxis] = nSpeed;
	
	int nSize = GetAxisSize();
	if( nAxis == (nSize-1) )
	{
		long nSpeed;
		int nCount = 0;
		BYTE bSpeedData[REG_DATA_MAX] = {0,};
		
		for( int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			nSpeed = m_nWorkSpeed[i];
			WriteLong( bSpeedData, nSpeed, nCount );
		}
		
		WriteArrayData( ADD0B_INDEX_SPEED, (WORD)nCount, bSpeedData );
	}
	
}

void HMotorMP920::SetOriginalSpeed()
{
	for(int i=0; i<MOTOR_AXIS_MAX; i++)
	{
		m_nOriginSpeed[i] = (int)m_pSetting[i].dTableFeedRate;
		
		int nSize = GetAxisSize();
		if( i == (nSize-1) )
		{
			long nSpeed;
			int nCount = 0;
			BYTE bSpeedData[REG_DATA_MAX] = {0,};
			
			for( int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
			{
				nSpeed = m_nOriginSpeed[i];
				WriteLong( bSpeedData, nSpeed, nCount );
			}
			
			WriteArrayData( ADD0B_ORIGIN_SPEED, (WORD)nCount, bSpeedData );
		}
	}	
	return ;
}

void HMotorMP920::SetFixedMaskPos(double dPos)
{
	return;
}

BOOL HMotorMP920::GetCurrentHeight(BOOL bFirst, BOOL bDown)
{
#ifdef __TEST__
	return TRUE;
#endif

#ifdef __CUNGJU_JASMINE_OLD__
	bDown = !bDown;
#endif

	if(bFirst)
	{
		if(GetCurrentStatus(CURRENT_HEIGHT, !bDown))
			return TRUE;
	}
	else
	{
		if(GetCurrentStatus(CURRENT_HEIGHT2, !bDown))
			return TRUE;
	}
	
 	return FALSE;
}

BOOL HMotorMP920::GetCurrentEMStop()
{
	return m_lpDataOld->IO.nEMStop;
}

BOOL HMotorMP920::IsFluorescentLampOn()
{
	return FALSE;
}

void HMotorMP920::UpdateZCalibrationFile(CALHEAD &calHead, BOOL bFirst)
{
	return;
}

BOOL HMotorMP920::LoaderCarrierLoadPos()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderCarrierTablePos()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderCarrierAlignPos()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderCarrierUnloadPos()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderCarrierCartPos()
{
	return TRUE;
}

BOOL HMotorMP920::Table1VacuumMotor(BOOL bOn)
{
#ifdef __CUNGJU_JASMINE_OLD__
	WORD wAddr = ADD0B_WRITE_OUTPORT + PORT_TABLE1_VACUUM_MOTOR; // 0x0013
	return SetOutPort( wAddr, bOn, TRUE );
#endif
	return TRUE;
}

BYTE HMotorMP920::GetCurrentPowerMeter()
{
	return TRUE;
}

BOOL HMotorMP920::GetChuckStatus(BOOL bClamp)
{
	return FALSE;
}

BOOL HMotorMP920::GetSystemAir()
{
	return TRUE;
}

BOOL HMotorMP920::GetLoadingShutterStatus(BOOL bOpen)
{
	return FALSE;
}

BOOL HMotorMP920::IsFrontDoorOpen()
{
	return FALSE;
}

BOOL HMotorMP920::IsLeftDoorOpen()
{
	return FALSE;
}

BOOL HMotorMP920::IsRear1DoorOpen()
{
	return FALSE;
}

BOOL HMotorMP920::IsRear2DoorOpen()
{
	return FALSE;
}	

BOOL HMotorMP920::IsRightDoorOpen()
{
	return FALSE;
}

BOOL HMotorMP920::GetBrushStatus(BOOL bUp)
{
	return TRUE;
}

BOOL HMotorMP920::IsAlignerPCBExist()
{
	return FALSE;
}
BOOL HMotorMP920::IsULAlignerPCBExist()
{
	return FALSE;	
}
BOOL HMotorMP920::GetResetSW()
{
	return FALSE;
}

BOOL HMotorMP920::GetStartSW()
{
	return TRUE;
}

BOOL HMotorMP920::GetStopSW()
{
	return TRUE;
}


BOOL HMotorMP920::IsLCinCartPos()
{
	return FALSE;
}	

BOOL HMotorMP920::IsLCinLoadPos()
{
	return FALSE;	
}

BOOL HMotorMP920::IsUCinCartPos()
{
	return FALSE;
}

BOOL HMotorMP920::IsUCinUnloadPos()
{
	return FALSE;
}

BOOL HMotorMP920::GetCurrentMotorSol()
{
	return TRUE;
}

BOOL HMotorMP920::Loader1PCBExist(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::Loader2PCBExist(BOOL bOn)
{
	return  TRUE;
}

BOOL HMotorMP920::AlignTablePCBExist(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::Unloader1PCBExist(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::Unloader2PCBExist(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::ULAlignTablePCBExist(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::TablePCBReset()
{
	return TRUE;
}

BOOL HMotorMP920::IsLP1P1Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsLP2P1Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsLoaderCartClamp()
{
	return TRUE;
}

BOOL HMotorMP920::IsLoaderPicker1Vacuum()
{
	return m_lpDataNew->IO.nIsPcbLoad;
}

BOOL HMotorMP920::IsLoaderPicker2Vacuum()
{
	return m_lpDataNew->IO.nIsPcbLoad;
}

BOOL HMotorMP920::IsLoaderAlignTableForward()
{
	return TRUE;
}

BOOL HMotorMP920::IsAlignGuideForward()
{
	return TRUE;
}

BOOL HMotorMP920::IsAlignSheetTableForward()
{
	return TRUE;
}

BOOL HMotorMP920::IsULP1P1Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsULP2P1Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsUnloaderPicker1Vacuum()
{	
	return  m_lpDataNew->IO.nIsPcbUnload;
}

BOOL HMotorMP920::IsUnloaderPicker2Vacuum()
{
	return  m_lpDataNew->IO.nIsPcbUnload;
}

BOOL HMotorMP920::Table2VacuumMotor(BOOL bOn)
{
	return TRUE;
} 

BOOL HMotorMP920::LoaderElvLoadPos()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderElvOriginPos()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderElvUnloadPos()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderElvOriginPos()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderCarrierAlignPos()
{
	return TRUE;
}

BOOL HMotorMP920::WriteOutPort(int nAdd, BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::IsLP1P2Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsLP2P2Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsULP1P2Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsULP2P2Up()
{
	return TRUE;
}

BOOL HMotorMP920::IsUnloaderCartClamp()
{
	return TRUE;
}

BOOL HMotorMP920::IsUnloaderAlignTableForward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker1Init()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker1Align()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker1P2()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker1Load()
{
	return TRUE;
}	

BOOL HMotorMP920::LoaderPicker2Init()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker2Align()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker2P2()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker2Load()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderVacuum1On()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderVacuum1Off()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderVacuum2On()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderVacuum2Off()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderClampForward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderClampBackward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderTableForward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderTableBackward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderAlignYBackward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderAlignYForward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderAlignXBackward()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderAlignXForward()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker1Init()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker1Table()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker1P2()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker1Unload()
{
	return TRUE;
}
BOOL HMotorMP920::UnloaderPicker2Init()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker2Table()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker2P2()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker2Unload()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderVacuum1On()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderVacuum1Off()
{
	return TRUE;
}
BOOL HMotorMP920::UnloaderVacuum2On()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderVacuum2Off()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderClampForward()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderClampBackward()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderTableForward()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderTableBackward()
{
	return TRUE;
}
BOOL HMotorMP920::IsLCinAlignPos()
{
	return TRUE;
}

BOOL HMotorMP920::IsUCinAlignPos()
{
	return TRUE;
}

BOOL HMotorMP920::TableVacuumSelect(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::GetAOMAlarm()
{
	return FALSE;
}

BOOL HMotorMP920::UnLoaderPCBReset()
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPCBReset()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerReady()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerAlarm()
{
	return FALSE;
}

BOOL HMotorMP920::IsHandlerLotEnd()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandler1stTableExist()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandler2ndTableExist()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerLoadReady()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerLoadEnd()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerLoadAlarm()
{
	return FALSE;
}

BOOL HMotorMP920::IsHandlerUnloadReady()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerUnloadEnd()
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerUnloadAlarm()
{
	return FALSE;
}

void HMotorMP920::UpdateTCalibrationFile(CALDATA &calData)
{

}

double HMotorMP920::GetMoveAccel(int nAxis)
{
	if(nAxis >= MOTOR_AXIS_MAX)
		return 0.;
	
	return m_pSetting[nAxis].dTableAcceleration;
}

double HMotorMP920::GetMPosition(int nIndex)
{
	if(nIndex < 0 || nIndex > 9)
		return 0;
	
	return m_dMaskPosition[nIndex];
}

BOOL HMotorMP920::SendLoadCartNoPCB()
{
	return TRUE;
}

BOOL HMotorMP920::SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::IsResetSwitch()
{	
	return TRUE;
}

BOOL HMotorMP920::IsHandlerDoorBypass(BOOL bLoader)
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerReady(int nAxis)
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerBusy(int nAxis)
{
	return FALSE;
}

BOOL HMotorMP920::IsHandlerStop(int nAxis)
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerInitEnd(int nAxis)
{
	return TRUE;
}

BOOL HMotorMP920::UseRoll(BOOL bUse)
{
	return TRUE;
}

BOOL HMotorMP920::IsHandlerTablePCBExist(BOOL bLoader)
{
	return TRUE;
}

BOOL HMotorMP920::LoaderPicker3Init()
{
	return TRUE;
}

BOOL HMotorMP920::UnloaderPicker3Init()
{
	return TRUE;
}
int HMotorMP920::ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel)
{
	return FALSE;
}
int HMotorMP920::GetInpositionError()
{
	return m_nInPositionError;
}
BOOL HMotorMP920::SetAlarmTolLed(BOOL bOn)
{
	return TRUE;
}

BOOL HMotorMP920::SetWaterFlow1Value(double dVal)
{
//#ifdef __KUNSAN_SAMSUNG_LARGE__
//	return m_clsMotor->SetWaterFlow1Value(dVal);
//#else
	return TRUE;
//#endif
}

BOOL HMotorMP920::SetWaterFlow2Value(double dVal)
{ 
	return TRUE;
}
BOOL HMotorMP920::SetMainAirValue(double dVal)
{
	return TRUE;
}
BOOL HMotorMP920::SetDustSuctionValue(double dVal)
{
	return TRUE;
}
BOOL HMotorMP920::SetTableVauumValue(BOOL b1st, double dVal)
{
	return TRUE;
}
BOOL HMotorMP920::Set2DBarcodeTrigger()
{
	return TRUE;
}
BOOL HMotorMP920::MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, dMaskPos, dPosC);
}
BOOL HMotorMP920::GetChillerRun()
{
	return TRUE;
}
BOOL HMotorMP920::GetLPCStatus()
{
	return TRUE;
}
BYTE HMotorMP920::GetBasketIn()
{
	return TRUE;
}
BOOL HMotorMP920::SetUseNGBox(BOOL bUse)
{
	return TRUE;
}
BOOL HMotorMP920::SetUsePaperBox(BOOL bUse)
{
	return TRUE;
}
BOOL HMotorMP920::SetTablePCBExist(BOOL b1st, BOOL b2nd)
{
	return TRUE;
}
BOOL HMotorMP920::IsStartMode()
{
	return TRUE;
}
BOOL HMotorMP920::MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2)
{
	m_dDestinationPos[AXIS_M]	= dMaskPos;
	m_dDestinationPos[AXIS_C]	= dPosC;
	
	if(	FALSE == IsValidAxisPosition( AXIS_M, m_dDestinationPos[AXIS_M] ) ||
		FALSE == IsValidAxisPosition( AXIS_C, m_dDestinationPos[AXIS_C] ) )
	{
		ErrMessage(_T("Incorrect Axis Position"), MB_ICONERROR);
		return FALSE;
	}
	return TRUE;
}
BOOL HMotorMP920::MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	return MoveZMC_W(dPosZ1, dPosZ2, dMaskPos, dPosC);
}
void HMotorMP920::ReadAddressTemperatureComp()
{

}
void HMotorMP920::ReadTemperatureComp()
{

}
BOOL HMotorMP920::GetReverseDirection()
{
	return TRUE;
}
void HMotorMP920::ReadAllError(int* pnVal)
{

}
BOOL HMotorMP920::GetReverseReady()
{
	return TRUE;
}
void HMotorMP920::DisconnectAnyDevice(int nType)
{

}
void HMotorMP920::ConnectAnyDevice(int nType) // 0 : chiller 1: thermo-hyprometer
{

}
BOOL HMotorMP920::MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
	return MoveXYZ1Z2MC(dPosX,dPosY,dPosZ1,dPosZ2,dPosM,dPosC,b1stPanel,FALSE);
}
BOOL HMotorMP920::SetLoadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	return TRUE;
}
BOOL HMotorMP920::IsUnloaderNGBoxForward()
{
	return TRUE;
}
BOOL HMotorMP920::IsUnloaderNGBoxBackward()
{
	return TRUE;
}
BOOL HMotorMP920::IsLCinCartPos2()
{
	return TRUE;
}
BOOL HMotorMP920::IsLCinAlignPos2()
{
	return TRUE;
}
BOOL HMotorMP920::LoaderCarrierAlignPos2()
{
	return TRUE;
}
BOOL HMotorMP920::LoaderCarrierCartPos2()
{
	return TRUE;
}
BOOL HMotorMP920::IsOrigin(int nAxis)
{
	return TRUE;
}
BOOL HMotorMP920::SetReverseDirection(BOOL bChange)
{
	return TRUE;
}
BOOL HMotorMP920::SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	return TRUE;
}
BOOL HMotorMP920::SetOutputBasket(BOOL bLoad)
{
	return TRUE;
}
BOOL HMotorMP920::UnloaderNGBoxForward()
{
	return TRUE;
}
BOOL HMotorMP920::UnloaderNGBoxBackward()
{
	return TRUE;
}
BOOL HMotorMP920::IsMainDoorStop()
{
	return TRUE;
}
void HMotorMP920::GetTemperatureForAllCh (double* dTemper)
{

}
void HMotorMP920::GetTCTemperature (double& d1stTemper, double& d2ndTemper)
{

}
void HMotorMP920::GetSBTemperature (double& d1stTemper, double& d2ndTemper)
{

}
int	HMotorMP920::GetMainAirValue()
{
	return TRUE;
}
double HMotorMP920::GetChillerTemp()
{
	return TRUE;
}
int	HMotorMP920::GetWaterFlow1Value()
{
	return TRUE;
}
int	HMotorMP920::GetWaterFlow2Value()
{
	return TRUE;
}
double HMotorMP920::GetVolateSubData(int nIndex)
{
	return TRUE;
}

void HMotorMP920::GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint)
{
}

void HMotorMP920::GetVoltage(double& dV, double& dA,double& dKw)
{
}

BOOL HMotorMP920::GetLoadBasketSignal(BOOL bIn)
{
	return FALSE;
}
BOOL HMotorMP920::GetUnloadBasketSignal(BOOL bIn)
{
	return FALSE;
}
BOOL HMotorMP920::ResetBasketInfo(BOOL bLoad)
{
	return TRUE;
}