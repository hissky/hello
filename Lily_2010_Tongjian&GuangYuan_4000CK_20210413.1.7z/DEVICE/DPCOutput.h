// DPCOutput.h: interface for the DPCOutput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPCOUTPUT_H__9B09B92E_24C5_4897_B6B2_6DE60281F08F__INCLUDED_)
#define AFX_DPCOUTPUT_H__9B09B92E_24C5_4897_B6B2_6DE60281F08F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DPCOutput  
{
public:
	DPCOutput();
	virtual ~DPCOutput();

public :  // Attribute

	// Sys Request
	BOOL		m_bSysStart;
	BOOL		m_bSysStop;
	BOOL		m_bSysAlarmClearReq;
	BOOL		m_bDoorByPass;
	BOOL		m_bNotUseBuzzer;
	BOOL		m_bNewCassetteChangeReq;
	BOOL		m_bCoatingParamDownReq;
	BOOL		m_bCleaningParamDownReq;
	BOOL		m_bHandlerPosDownReq;
	BOOL		m_bCoaterPosDownReq;
	BOOL		m_bWaferSize;
	BOOL		m_bWorkingTool;
	BOOL		m_bTableVacuumSolReq;
	BOOL		m_bTableVacuumExhaustReq;
	BOOL		m_bLaserEnableReq;
	BOOL		m_bN2GasSolReq;

	// Chuck Interface between Stage and PLC
	SSTAGEIF	m_sStageIF;
	BOOL		m_bHandlerRun;
	BOOL		m_bAllInitReq;
	BOOL		m_bOnlyHanadlerInitReq;
	BOOL		m_bOnlyStageInitReq;
	BOOL		m_bOnlyCoaterInitReq;
	BOOL		m_bAllInitIgnoreErr;

	// Dry Run
	BOOL		m_bFullDryRun;
	BOOL		m_bNoWaferFullDryRun;
	BOOL		m_bSkipCoaterRun;

	// Manual Wafer Status Change
	BOOL		m_bRailZoneWaferStatusClearReq;
	BOOL		m_bCoaterZoneWaferStatusClearReq;
	BOOL		m_bLPickerZoneWaferStatusClearReq;
	BOOL		m_bBufferZoneWaferStatusClearReq;
	BOOL		m_bChuckZoneWaferStatusClearReq;
	BOOL		m_bBPickerZoneWaferStatusClearReq;
	BOOL		m_bCassetteSlotWaferStatusChangeReq;
	BOOL		m_bSlot[13];

	// Mpg Mode
	DWORD		m_nMpgMode;
};

#endif // !defined(AFX_DPCOUTPUT_H__9B09B92E_24C5_4897_B6B2_6DE60281F08F__INCLUDED_)
