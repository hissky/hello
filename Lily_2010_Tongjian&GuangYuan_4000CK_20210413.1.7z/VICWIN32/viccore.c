/* Victor Image Processing Library for Windows core routines
   Copyright (c) 1989-1998, ALL RIGHTS RESERVED
         Catenary Systems
         470 Belleview
         St Louis, MO 63119
         (314)962-7833
   Contents:
      DllMain           DLL entry routine
      allocimage        Allocate global memory for a DIB
      copyimgdes        Copy all elements of an image descriptor
      freeimage         Free a DIB and zero the image descriptor
      imageareatorect   Set RECT structure from image area fields
      recttoimagearea   Set image area fields from a RECT structure
      setimagearea      Set image area fields of an image descriptor
      setupimgdes       Set up an image descriptor from a DIB
      viewimage         Display a Victor image
      viewimageex       Display a Victor image
      zeroimgdes        Zero all elements of an image descriptor
      Victorversion     Return Victor Library version
      updatebitmapcolortable  Update a device-independent bitmap's color table
      checkrange_       Check range of arguments, allow 8- and 24-bit images
      checkrange1_      Check range of arguments, allow 1-, 8- and 24-bit images
      checkrange16_     Check range of arguments, allow 1-, 8-, 16- and 24-bit images
      CreateDefaultPalette_ Create a default palette
      isgrayscaleimage  Determines if an image has a grayscale palette
   Privately used routines:
      set_rows_cols_    Set the dimensions of the image area to be processed
      calc_DIBcolors_   Determine the number of colors in the palette table
*/
#define STRICT
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <vicdefs.h>

/*-------Global Variables------*/
HANDLE hDLLInst_;
MYVERSIONINFO WinVersion;
BOOL NewDIB;  // Flag indicates if we can use CreateDIBSection
/*-----------------------------*/

static void deleteCriticalSections(void);
int calc_DIBcolors_(BITMAPINFOHEADER far *bmHdr);

BOOL __stdcall DllMain(HANDLE hDLL, DWORD dwReason, LPVOID lpReserved)
{
   static int processesAttached = 0;
   BOOL rval = TRUE;

   switch(dwReason) {
      case DLL_PROCESS_ATTACH:
         if(processesAttached++ == 0) { // The first initialization.
            DWORD dwVersion = GetVersion();
            // Save the major and minor version numbers (3.51 = 351)
            WinVersion.version = 
               (UINT)(((dwVersion & 0xff00) >> 8) + ((dwVersion & 0x00ff) * 100));
            // Save the platform ID (0=>Win32s, 1=>Win95, 2=>WinNT)
            if(dwVersion < 0x80000000)
               WinVersion.platformID = VER_PLATFORM_WIN32_NT;
            else if(WinVersion.version < 395)
               WinVersion.platformID = VER_PLATFORM_WIN32s;
            else
               WinVersion.platformID = VER_PLATFORM_WIN32_WINDOWS;

            // Set flag to TRUE if we can use CreateDIBSection, etc.
            NewDIB = FALSE;
            // Make sure operating environment is Win95 or WinNT 3.5+
            if(WinVersion.platformID == VER_PLATFORM_WIN32_WINDOWS ||
               WinVersion.platformID == VER_PLATFORM_WIN32_NT && 
               WinVersion.version >= 350)
               // Set flag to TRUE if we can use CreateDIBSection
               NewDIB = TRUE;
            // Save DLL handle in a global variable
            hDLLInst_ = hDLL;
            }
         break;

      // The calling process is detaching the DLL
      case DLL_PROCESS_DETACH:
         if(--processesAttached == 0) {
            deleteCriticalSections();
            }
         break;

      // A new thread is being created in the current process.
      case DLL_THREAD_ATTACH:
         break;
      // A thread is exiting cleanly.
      case DLL_THREAD_DETACH:
         break;
      }
   return(rval);
}

/* Allocate global memory for a Device Independent Bitmap (DIB). Fills in the 
   image descriptor buffer address, image area fields, DIB handle, and bitmap 
   info data if successful.  If bppixel is 4, an 8-bit image buffer is allocated.
   Returns NO_ERROR, BAD_MEM (insufficient global memory), BAD_BPP (bits per 
   pixel not 1, 4, 8, 16, or 24), or BAD_RANGE (image width or length is zero).
*/
static int near allocFct(imgdes far *image, 
   int iwidth, int ilength, // Image width, length in pixels
   int bppixel, // Image bits per pixel: 1, 4, 8, 16, or 24
   BOOL useCreateDIB) // TRUE => use CreateDIBSection
{
   static UCHAR validBPPList[] = { 1, 4, 8, 16, 24 };
   unsigned palbyts, buffwidth; // Width of an image row in bytes
   long bufsize, imgsize;
   int j;
   UCHAR huge *gmem;

   // Zero image descriptor
   zeroimgdes(image);
   // Check for a valid bits per pixel
   j = dim(validBPPList);
   while(--j >= 0 && bppixel != validBPPList[j])
      ;
   if(j < 0)
      return(BAD_BPP);   // Invalid bits per pixel
   // Allocate an 8-bit buffer if bits per pixel is 4
   if(bppixel == 4)
      bppixel = 8;
   // Return BAD_RANGE if iwidth or ilength is zero
   if(iwidth == 0 || ilength == 0)
      return(BAD_RANGE);
   // Calculate 'colors' based on bits per pixel
   image->colors = (bppixel >= 16) ? 0 : (1 << bppixel);
   palbyts = image->colors * sizeof(RGBQUAD);
   /* Calculate the buffer width in bytes: make sure the buffer width is
      a multiple of 4
   */
   buffwidth = (unsigned)BUFFER_BYTES(iwidth * (long)bppixel);
   // Calculate the size of just the image
   imgsize = buffwidth * (long)ilength;

   // Allocate a global buffer to hold the header, palette, and perhaps, the image data
   bufsize = sizeof(BITMAPINFOHEADER) + palbyts;
   if(useCreateDIB == FALSE)
      bufsize += imgsize;
   if((gmem = (UCHAR huge *)BIG_ALLOC_AREA(bufsize)) == 0)
      return(BAD_MEM);   // Allocation failed!

   // Fill in the image descriptor and bitmapinfoheader header
   // Zero all elements of our BITMAPINFOHEADER header
   image->bmh = (BITMAPINFOHEADER far *)gmem;
   _fmemset(image->bmh, 0, sizeof(BITMAPINFOHEADER));
   // Fill out the bitmap header
   image->bmh->biSize = sizeof(BITMAPINFOHEADER);
   image->bmh->biWidth  = iwidth;
   image->bmh->biHeight = ilength;
   image->bmh->biBitCount = (WORD)bppixel;
   image->bmh->biPlanes = 1;
   image->bmh->biCompression = BI_RGB; // No compression
   image->bmh->biSizeImage = imgsize;
   image->bmh->biClrUsed = image->bmh->biClrImportant = image->colors;

   // Save the address of where the palette data will be stored
   image->palette = (RGBQUAD far *)(gmem + sizeof(BITMAPINFOHEADER));
   // Set up a default palette
   CreateDefaultPalette_(image);
   if(useCreateDIB == FALSE)
      // Save the address of where the image data will be stored
      image->ibuff = (UCHAR huge *)(gmem + sizeof(BITMAPINFOHEADER) + palbyts);
   else {
      // Create the DIB and store the DIB handle and the address of where 
      //  the image data will be stored   
      HWND hWnd = GetDesktopWindow();
      HDC hDC = GetDC(hWnd);
      image->hBitmap = CreateDIBSection(hDC, (LPBITMAPINFO)gmem, 
         DIB_RGB_COLORS, &image->ibuff, 0, 0L);
      ReleaseDC(hWnd, hDC);
      // Make sure allocation worked
      if(image->hBitmap == 0 || image->ibuff == 0) {
         if(image->hBitmap != 0)
            DeleteObject(image->hBitmap);
         BIG_FREE_AREA(gmem);
         return(BAD_MEM);   // Could not create DIB section
         }
      }
   // Set buffer width in bytes and fill in the image area fields
   image->buffwidth = buffwidth;
   image->endx = (unsigned)image->bmh->biWidth - 1;
   image->endy = (unsigned)image->bmh->biHeight - 1;
   return(NO_ERROR);
}

/* Allocate global memory for a Device Independent Bitmap (DIB). Fills in the 
   image descriptor buffer address, image area fields, DIB handle, and bitmap 
   info data if successful.  If bppixel is 4, an 8-bit image buffer is allocated.

   Allocimage() uses CreateDIBSection if the operating environment is Win95 
   or WinNT 3.51. Otherwise, allocimage() calls the allocDIB function.

   Returns NO_ERROR, BAD_MEM (insufficient global memory), BAD_BPP (bits per 
   pixel not 1, 4, 8, 16, or 24), or BAD_RANGE (image width or length is zero).
*/
int _export WINAPI allocimage(imgdes far *image, int iwidth, int ilength, int bppixel)
{
   // NewDIB == TRUE if we can use CreateDIBSection
   return( allocFct(image, iwidth, ilength, bppixel, NewDIB) );
}

/* Allocate global memory for a Device Independent Bitmap (DIB). Fills in
   the image descriptor buffer address, image area fields, and bitmap info
   data if successful. 

   This function creates a DIB in contiguous memory, that is, the DIB's 
   BITMAPINFO structure is followed by the DIB's image data.

   AllocDIB does not create a Window's device-independent bitmap, so 
   'image->hBitmap' is set to zero. 
   
   Returns NO_ERROR, BAD_MEM (insufficient global memory), BAD_BPP (bits 
   per pixel not 1, 8, 16, or 24), or BAD_RANGE (image width or length is zero).
*/
int _export WINAPI allocDIB(imgdes far *image, int iwidth, int ilength, int bppixel)
{
   return( allocFct(image, iwidth, ilength, bppixel, FALSE) );
}

// Copy all elements of an image descriptor
void _export WINAPI copyimgdes(imgdes far *srcimg, imgdes far *desimg)
{
   _fmemcpy(desimg, srcimg, sizeof(imgdes));
}

// Free a DIB and zero the image descriptor
void _export WINAPI freeimage(imgdes far *image)
{
   unsigned bufsiz;

   bufsiz = image->hBitmap ?
      sizeof(BITMAPINFOHEADER) + image->colors * sizeof(RGBQUAD) : image->bmh->biSizeImage;
   // Make sure the image buffer address will not cause a protection fault
   if(IsBadReadPtr(image->bmh, bufsiz) == FALSE) {
      // If it exists, free BMI header and palette
      if(image->bmh) // Free the allocated memory
         BIG_FREE_AREA(image->bmh);
      if(image->hBitmap) // Delete the bitmap too
         DeleteObject(image->hBitmap);
      // Zero the image descriptor
      zeroimgdes(image);
      }
}

// Fill a RECT structure from the image descriptor area fields
void _export WINAPI imageareatorect(imgdes far *image, RECT far *rect)
{
   rect->left = image->stx;
   rect->top = image->sty;
   rect->right = image->endx;
   rect->bottom = image->endy;
}

// Set image area fields of an image descriptor from a RECT structure
void _export WINAPI recttoimagearea(RECT far *rect, imgdes far *image)
{
   image->stx = rect->left;
   image->sty = rect->top;
   image->endx = rect->right;
   image->endy = rect->bottom;
}

// Set image area fields of an image descriptor
void _export WINAPI setimagearea(imgdes far *image,
   unsigned stx, unsigned sty, unsigned endx, unsigned endy)
{
   image->stx = stx;
   image->sty = sty;
   image->endx = endx;
   image->endy = endy;
}

/* Set up an image descriptor from a Device Independednt Bitmap (DIB).
   Returns NO_ERROR, BAD_DIB (DIB is compressed), or BAD_BPP (bits per
   pixel is not 1, 8, or 24).
*/
int _export WINAPI setupimgdes(UCHAR huge *dib, // Address of DIB
   imgdes far *image)         // Image descriptor to fill in
{
   int colors;
   BITMAPINFOHEADER far *bmHdr;

   zeroimgdes(image); // Zero the image descriptor
   // Set up the image descriptor fields
   image->bmh = bmHdr = (BITMAPINFOHEADER far *)dib;
   // Make sure DIB is Victor compatible
   if(bmHdr->biBitCount == 4) // Bits per pixel must be 1, 8, or 24
      return(BAD_BPP);
   if(bmHdr->biCompression != BI_RGB) // Comp must be none
      return(BAD_DIB);
   // Determine the number of colors in the palette table
   colors = calc_DIBcolors_(bmHdr);
   image->palette = (RGBQUAD far *)&dib[sizeof(BITMAPINFOHEADER)];
   image->ibuff = (UCHAR huge *)&dib[sizeof(BITMAPINFOHEADER) + colors * sizeof(RGBQUAD)];
   image->colors = colors;
   image->endx = (unsigned)bmHdr->biWidth - 1;
   image->endy = (unsigned)bmHdr->biHeight - 1;
   // Calc buffer width in bytes
   image->buffwidth =
      (unsigned)BUFFER_BYTES(bmHdr->biWidth * (long)bmHdr->biBitCount);
   return(NO_ERROR);
}

/* Display a Victor image. The method used to display the image depends on 
   'image->hBitmap.' If 'image->hBitmap' is nonzero, a Window's 
   device-independent bitmap object was created and the image is displayed 
   with BitBlt(). If 'image->hBitmap' is zero, the image is displayed with 
   SetDIBitsToDevice(). Returns NO_ERROR or BAD_MEM (insufficient memory).
*/
static int near displayImage(HWND hwnd, HDC hdc,
   HPALETTE far *hPal, // Variable to receive logical palette handle
   int xpos, int ypos, // Horiz, vert displacement to first visible pixel
   imgdes far *image,
   int scrx, int scry) // Position on client rect to display image
{
   int rcode, rows2disp, rowsleft, cols2disp, colsleft;
   HPALETTE hOldPal;
   RECT rc;

   // Create a logical palette from a Victor palette
   if((rcode = victowinpal(image, hPal)) == NO_ERROR && *hPal) {
      // Select and realize the palette
      hOldPal = SelectPalette(hdc, *hPal, 0);
      RealizePalette(hdc);
      }

   // Calculate the number of image rows to display
   GetClientRect(hwnd, &rc);
   rows2disp = rc.bottom - scry; // Maximum rows to display
   rowsleft = (int)image->bmh->biHeight - ypos;
   if(rows2disp > rowsleft)
      rows2disp = rowsleft;
   cols2disp = rc.right - scrx;  // Maximum cols to display
   colsleft = (int)image->bmh->biWidth - xpos;
   if(cols2disp > colsleft)
      cols2disp = colsleft;

   if(image->hBitmap == 0) { // If 'image' is a Win32s/WinNT 3.1 DIB 
      int xofs;
      long laddr, oldheight, oldsize;

      /* Calculate the position in the image buffer that
         contains the bits to display
      */
      laddr = (image->bmh->biBitCount * (long)xpos) / 8 +
              (rowsleft - rows2disp) * (long)image->buffwidth;
      // Calculate an X offset to use (0 or 0 - 7 for a 1-bit image)
      xofs = (image->bmh->biBitCount == 1) ? (xpos & 7) : 0;

      // Save the info we change
      oldheight = image->bmh->biHeight;
      oldsize   = image->bmh->biSizeImage;

      // Change biHeight and biSizeImage for the area we display
      image->bmh->biHeight    = rows2disp;
      image->bmh->biSizeImage = image->buffwidth * (long)rows2disp;

      // Display the DIB
      SetDIBitsToDevice(hdc,
         scrx, scry, // X,Y of dest rect
         cols2disp, rows2disp, // Width and height of rectangle to display
         xofs, 0,   // X,Y coords of source rectangle in image buffer
         0U,        // Scanline number of data contained in image buffer
         rows2disp, // Number of scanlines to copy from image buffer
         (char far *)&image->ibuff[laddr], // Image buffer address
         (BITMAPINFO far *)image->bmh, DIB_RGB_COLORS);

      // Restore the info we changed
      image->bmh->biHeight    = oldheight;
      image->bmh->biSizeImage = oldsize;
      }

   else { // If 'image' is a Win95/WinNT 3.5+ DIB
      // Create a memory DC
      HDC hMemDC = CreateCompatibleDC(hdc);
      if(hMemDC == 0)
         rcode = BAD_MEM;
      else {
         HPALETTE hOldPal1;
         HBITMAP hOldBitmap;
         
         if(*hPal)
            hOldPal1 = SelectPalette(hMemDC, *hPal, 0);
         // Select bitmap into the memory DC
         hOldBitmap = SelectObject(hMemDC, image->hBitmap);
         // BitBlt the bits to the screen
         if(BitBlt(hdc,
            scrx, scry,   // X,Y of dest rect
            cols2disp, rows2disp, // Width and height of rectangle to display
            hMemDC, 
            xpos, ypos,    // X,Y coords of source rectangle in image buffer
            SRCCOPY) == FALSE)
            rcode = BAD_MEM;
         // Clean up
         if(*hPal)
            SelectPalette(hMemDC, hOldPal1, 0);
         SelectObject(hMemDC, hOldBitmap);
         DeleteDC(hMemDC);
         }
      }

   // Restore original palette to screen DC
   if(*hPal)
      SelectPalette(hdc, hOldPal, 0);
   return(rcode);
}

/* Create an 8-bit image to display from an 8- or 24-bit image.
   We use color reduction to accurately, quickly display:
      1) A 24-bit image on a 256-color (8-bit) display adapter or
      2) An 8-bit image on a 16-color (4-bit) display adapter
*/
static int near Create8bitImage(HWND hWnd,
   int xpos, int ypos, // Horiz, vert displacement to first visible pixel
   int scrx, int scry, // Position on client rect to display image
   int displayBits, // Display mode bits per pixel
   imgdes far *srcimg,  // 8- or 24-bit source image
   imgdes far *dispimg, // 8-bit display image
   int colRedMode) // Color reduction mode (used on 4- or 8-bit display only)
{
#define PAL_COLORS 256   // Number of palette colors to create
   int rcode, imgWidth, imgLength;
   imgdes timage;
   RECT rc;

   /* Create a temporary 8- or 24-bit image and set its image
      area to the area that will be displayed
   */
   copyimgdes(srcimg, &timage);
   GetClientRect(hWnd, &rc);
   // Set stx and sty to the upper left corner of the area displayed
   timage.stx = xpos;
   timage.sty = ypos;
   // Set endx and endy to the lower right corner of the area displayed
   timage.endx = timage.stx + rc.right - scrx - 1;
   if(timage.endx >= (UINT)timage.bmh->biWidth) // Limit xend to the image
      timage.endx = (UINT)timage.bmh->biWidth - 1;
   // ImgWidth and imgLength are the dimensions of the
   //  temporary 8-bit image that will be displayed
   imgWidth = timage.endx - timage.stx + 1;

   timage.endy = timage.sty + rc.bottom - scry - 1;
   if(timage.endy >= (UINT)timage.bmh->biHeight)
      timage.endy = (UINT)timage.bmh->biHeight - 1;
   imgLength = timage.endy - timage.sty + 1;

   // Allocate the 8-bit image that will be displayed
   if((rcode = allocimage(dispimg, imgWidth, imgLength, 8)) == NO_ERROR) {
      // Color reduction method depends on display bits and colRedMode
      // Check if we're to use an optimized palette
      if(colRedMode == VIEWOPTPAL && displayBits >= 8)
         // Create an 8-bit image using an optimized palette
         rcode = convertrgbtopalex(PAL_COLORS, &timage, dispimg, CR_TSDNODIFF);
      else { // Use dither or scatter mode
         int (WINAPI *dispFctn)(imgdes far *,imgdes far *,int);
         int dispMode = (displayBits >= 8) ? COLORDITHER256 : COLORDITHER16;
         
         dispFctn = (colRedMode == VIEWSCATTER) ? colorscatter : colordither;
         // Create an 8-bit scatter or dither image using a rainbow palette
         rcode = dispFctn(&timage, dispimg, dispMode);
         }
      // If there's an error, free the allocated memory
      if(rcode != NO_ERROR)
         freeimage(dispimg);
      }
   return(rcode);
}

/* Display a Victor image. Remember to delete hPal after you're done 
   using it! This should be done before calling viewimage():

         if(hPalette)
            DeleteObject(hPalette);
         rcode = viewimage(...);

   The method used to display the image depends on 'image->hBitmap.' If 
   'image->hBitmap' is nonzero, a Window's device-independent bitmap object 
   was created and the image is displayed with BitBlt(). If 'image->hBitmap' 
   is zero, the image is displayed with SetDIBitsToDevice().

   Returns NO_ERROR or BAD_MEM (insufficient memory).
*/
int _export WINAPI viewimage(HWND hwnd, HDC hdc,
   HPALETTE far *hPal, // Variable to receive logical palette handle
   int xpos, int ypos, // Horiz, vert displacement to first visible pixel
   imgdes far *image)
{
   return( displayImage(hwnd, hdc, hPal, xpos, ypos, image, 0, 0) );
}

/* Display a Victor image using color reduction, if needed. 
   Remember to delete hPal after you're done using it! This should be 
   done before calling viewimage():

         if(hPalette)
            DeleteObject(hPalette);
         rcode = viewimage(...);

   The method used to display the image depends on 'image->hBitmap.' If 
   'image->hBitmap' is nonzero, a Window's device-independent bitmap object 
   was created and the image is displayed with BitBlt(). If 'image->hBitmap' 
   is zero, the image is displayed with SetDIBitsToDevice().

   Returns NO_ERROR or BAD_MEM (insufficient memory).
*/
int _export WINAPI viewimageex(HWND hwnd, HDC hdc,
   HPALETTE far *hPal, // Variable to receive logical palette handle
   int xpos, int ypos, // Horiz, vert displacement to first visible pixel
   imgdes far *image, 
   int scrx, int scry, // Position on client rect to display image
   int colRedMode) // Color reduction mode (used on 4- or 8-bit display only)
{
   int displayBits, val, rcode = NO_ERROR;
   BOOL tmpimg = FALSE; // Set TRUE if a temp image is allocated
   imgdes timage;

   // Set display adapter bits per pixel
   displayBits =  GetDeviceCaps(hdc, BITSPIXEL);

   // Adjust xpos,ypos and scrx,srcy so scrolling works
   val = xpos - scrx;
   if(val < 0) {
      xpos = 0; scrx = -val;
      }
   else {
      xpos = val; scrx = 0;
      }
   val = ypos - scry;
   if(val < 0) {
      ypos = 0; scry = -val;
      }
   else {
      ypos = val; scry = 0;
      }

   // If we're displaying a 24-bit RGB image on an 8-bit display adapter 
   // or an 8- or 24-bit image on a 4-bit display adapter, 
   // create a temporary 8-bit image for display
   if((image->bmh->biBitCount == 24 && displayBits == 8) ||
      (displayBits <= 4 && image->bmh->biBitCount >= 8 && 
      outrange(1, image->colors, 16))) {
      rcode = Create8bitImage(hwnd, xpos, ypos, scrx, scry, displayBits, 
         image, &timage, colRedMode);
      tmpimg = TRUE; // A temp image was created
      // Compensate for timage containing just the area to display
      xpos = 0; ypos = 0;
      }
   if(rcode == NO_ERROR) {
      rcode = displayImage(hwnd, hdc, hPal, xpos, ypos, 
         // If a temp image was created, display it
         tmpimg ? (imgdes far *)&timage : image, scrx, scry);
      }
   if(tmpimg)   // Free any temporary image
      freeimage(&timage);
   return(rcode);
}

// Zero all elements of an image descriptor
void _export WINAPI zeroimgdes(imgdes far *image)
{
   _fmemset(image, 0, sizeof(imgdes));
}

/* Update a device-independent bitmap's color table. 
   Returns NO_ERROR or BAD_MEM (insufficient memory).

   When a bitmap is created with allocimage(), the palette data stored at 
   'image->palette' at that time fills the bitmap's color table. If the 
   palette data subsequently changes, through a file load, for instance, 
   the bitmap's color table may need to be updated. This can be done using 
   the updatebitmappalette() function. 
   
   Note that viewimage() and viewimageex() internally updates a bitmap's 
   color table, so if either function is used, updatebitmapcolortable() 
   does not need to be called.
*/
int _export WINAPI updatebitmapcolortable(imgdes far *image)
{
   int rcode = NO_ERROR;

   if(image->hBitmap != 0 && image->colors != 0) {
      HWND hWnd = GetDesktopWindow(); // Use desktop window
      HDC hDC   = GetDC(hWnd);
      // Create a memory DC
      HDC hMemDC = CreateCompatibleDC(hDC);
      if(hMemDC != 0) {
         // Select bitmap into the DC
         HBITMAP hOldBitmap = SelectObject(hMemDC, image->hBitmap);
         // Update palette associated with bitmap
         SetDIBColorTable(hMemDC, 0, // Color table index of first entry to set
            image->colors,    // Number of color table entries to set
            image->palette);
         // Clean up
         SelectObject(hMemDC, hOldBitmap);
         DeleteDC(hMemDC);
         }
      else // hMemDC == 0
         rcode = BAD_MEM;
      ReleaseDC(hWnd, hDC);
      }
   return(rcode);
}

// Check range of startx, starty, endx, endy, etc. Swap values if needed.
// Returns NO_ERROR, BAD_RANGE, BAD_BPP, BAD_DIB, or BAD_IBUF
static int checkRange(imgdes far *image, DWORD validBitvals)
{
   int temp, rcode = BAD_IBUF;
   unsigned xlimit;

   // Make sure the image buffer address will not cause a protection fault
   if(IsBadReadPtr(image->ibuff, 1) == FALSE) {
      rcode = NO_ERROR;
      xlimit = (image->bmh->biBitCount != 1) ? XLIMIT :
#if XLIMIT < 8192
         (XLIMIT * 8);
#else
         65535;
#endif
      // Make sure there's a nonzero image location and BMH address
      if(image->ibuff == 0 || image->bmh == 0)
         return(BAD_RANGE);
      /* Swap end x with start x and end y with start y, if necessary - image
         processing routines require that endx >= startx and endy >= starty
      */
      if(image->stx > image->endx) {
         temp = image->endx;
         image->endx = image->stx;
         image->stx = temp;
         }
      if(image->sty > image->endy) {
         temp = image->endy;
         image->endy = image->sty;
         image->sty = temp;
         }
      // Range error if endx is greater than image width, etc.
      if(image->endx >= (unsigned)image->bmh->biWidth ||
         image->endx >= xlimit ||
         image->endy >= (unsigned)image->bmh->biHeight ||
         image->endy >= YLIMIT)
         return(BAD_RANGE);
      // Make sure our buffer width is greater than our image width
      if((unsigned)(image->bmh->biWidth * image->bmh->biBitCount / 8) > image->buffwidth)
         return(BAD_RANGE);
      // Check bits per pixel
      if(((1L << image->bmh->biBitCount) & validBitvals) == 0)
         rcode = BAD_BPP;   // Invalid bits per pixel
      // Make sure DIB is not compressed
      if(image->bmh->biCompression != BI_RGB)
         return(BAD_DIB);
      }
   return(rcode);
}

/* Check range of startx, starty, endx, endy, etc. Swap values if needed.
   ** Standard range checking routine called by image processing functions **
Return code   Condition
===========   ================================================
NO_ERROR      No errors encountered, function was successful
BAD_RANGE     Invalid image dimension:
                 endx >= biWidth
                 endx >= XLIMIT
                 endy >= biHeight
                 endy >= YLIMIT
              Invalid image location:
                 ibuff == 0 or bmh == 0
              Image width is greater than buffer width:
                 biWidth * biBitCount / 8 > buffwidth
BAD_BPP       Bits per pixel is not 8 or 24):
                 biBitCount != 8 && biBitCount != 24
BAD_DIB       DIB is compressed:
                 biCompression != BI_RGB
BAD_IBUF      Image buffer address is invalid
*/
int _export WINAPI checkrange_(imgdes far *image)
{  // Allow 8- and 24-bit images
   return( checkRange(image, (1L<<8) | (1L<<24)) );
}

/* Check range of arguments, allow 1-, 8- and 24-bit images.
   Returns NO_ERROR, BAD_RANGE, BAD_DIB (DIB is compressed),
   BAD_IBUF (invalid image buffer address), or BAD_BPP.
*/
int _export WINAPI checkrange1_(imgdes far *image)
{  // Allow 1-, 8-, and 24-bit images
   return( checkRange(image, (1L<<1) | (1L<<8) | (1L<<24)) );
}

/* Check range of arguments, allow 1-, 8-, 16- and 24-bit images.
   Returns NO_ERROR, BAD_RANGE, BAD_DIB (DIB is compressed),
   BAD_IBUF (invalid image buffer address), or BAD_BPP.
*/
int _export WINAPI checkrange16_(imgdes far *image)
{  // Allow 1-, 8-, 16-, and 24-bit images
   return( checkRange(image, (1L<<1) | (1L<<8) | (1L<<16) | (1L<<24)) );
}

// Return "increment." Used by CreateDefaultPalette_() and isgrayscaleimage()
static int getBppIncrem(int bppixel)
{  // For 0 to 8 bits per pixel
   static const UCHAR incremList[] = { 255, 255, 85, 36, 17, 8, 4, 2, 1 };
   int increm = 1;
   if(inrange(0, bppixel, 8))
      increm = incremList[bppixel];
   return(increm);
}

/* Create a default palette. Sets image->colors to 2 ^^ bits per pixel
   unless image is a 24-bit image. Also sets imgtype for grayscale and
   updates DIB's color table, if present.
*/
void _export WINAPI CreateDefaultPalette_(imgdes far *image)
{
   int j, k, increm, bitcount;

   // If image is 16-bit, it's a grayscale image
   bitcount = image->bmh->biBitCount;
   if(bitcount == 16)
      image->imgtype = IMGTYPE_GRAYSCALE; // Set image type to grayscale
   // If image palette exists and image is not 24-bits per pixel...
   else if(image->palette && bitcount <= 8) {
      increm = getBppIncrem(bitcount);  // Get increment to use
      image->imgtype |= IMGTYPE_GRAYSCALE; // Set image type to grayscale
      image->colors = calc_DIBcolors_(image->bmh);
      // Set up a default grayscale palette
      for(j=0, k=0; j<image->colors; j++, k+=increm) {
         image->palette[j].rgbRed   = (UCHAR)k;
         image->palette[j].rgbGreen = (UCHAR)k;
         image->palette[j].rgbBlue  = (UCHAR)k;
         image->palette[j].rgbReserved = (UCHAR)0;
         }
      // Update DIB's color table, if present
      if(image->hBitmap)
         updatebitmapcolortable(image);
      }
}

/* Determines if an image has a grayscale palette. Returns TRUE if the 
   palette is grayscale, otherwise FALSE is returned. 
   To be judged grayscale a palette must have these characteristics:
   1) The red, green, and blue values must be equal.
   2) The interval between adjacent palette entries must be increasing, 
   equal, and correct (see CreateDefaultPalette_).
*/
BOOL _export WINAPI isgrayscaleimage(imgdes far *image)
{
   int j, colors, increm, bitcount, palval;

   // Pass thru 16-bit grayscale
   if((bitcount = image->bmh->biBitCount) == 16 && 
      image->imgtype == IMGTYPE_GRAYSCALE)
      return(TRUE);

   // Bit count must be 16 or less and palette must exist
   if(image->colors && image->palette && bitcount <= 16) {
      RGBQUAD far *palptr = image->palette;
      colors = image->colors;
      // Check that red = green = blue for each palette entry
      for(j=0; j<colors; j++) {
         if(palptr->rgbRed != palptr->rgbGreen || palptr->rgbRed != palptr->rgbBlue)
            goto xit;
         palptr++;
         }
      // Check that the interval between adjacent palette entries is correct
      palptr = image->palette;
      // Get increment to use
      increm = getBppIncrem(bitcount);
      for(j=0, palval=0; j<colors; j++, palval += increm) {
         if(palptr->rgbRed != palval)
            goto xit;
         palptr++;
         }
      return(TRUE); // Palette is grayscale
      }
xit:
   return(FALSE);
}

/* Set the dimensions of the image area to be processed.
   Use the smaller of the two areas.
*/
void set_rows_cols_(imgdes far *srcimg, imgdes far *desimg,
   unsigned far *rows, unsigned far *cols)  // Image area dimensions
{
   unsigned drows, dcols;

   // Calculate destination area dimensions
   dcols = desimg->endx - desimg->stx + 1;
   drows = desimg->endy - desimg->sty + 1;
   // Image area to process is based on the source image
   *cols = srcimg->endx - srcimg->stx + 1;
   *rows = srcimg->endy - srcimg->sty + 1;
   /* Use the smaller of the dimensions to make sure
      destination can contain the processed image area
   */
   if(*cols > dcols)
      *cols = dcols;
   if(*rows > drows)
      *rows = drows;
}

// Determine and return the number of colors in the palette table
int calc_DIBcolors_(BITMAPINFOHEADER far *bmHdr)
{
   int colors;

   if((colors = (int)bmHdr->biClrUsed) == 0)
      // 1 bppixel => 2, 4 => 16, 8 => 256, 24 => 0 color in palette
      colors = (bmHdr->biBitCount >= 16) ? 0 : (1 << bmHdr->biBitCount);
   return(colors);
}

/* Return Victor Library version as a WORD. The high-order byte
   contains the major version number. The low-order byte contains
   the minor version number as a two-digit decimal number.
*/
WORD _export WINAPI Victorversion(void)
{
   VIC_VERSION_INFO vicVSInfo;
   return( Victorversionex(&vicVSInfo) );
}

/* Return Victor Library version as a WORD. The high-order byte
   contains the major version number. The low-order byte contains
   the minor version number as a two-digit decimal number.
   Also returns extended library information:
      VIC_VS_STATIC_RTL   1 = Uses static C run-time lib (0 => uses MSVCRTxx.DLL)
      VIC_VS_THREAD_SAFE  2 = Multithread safe
      VIC_VS_RELEASE      4 = Release version (0 => prerelease version)
      VIC_VS_EVAL_LIB     8 = Evaluation version (0 => release version)
*/
WORD _export WINAPI Victorversionex(VIC_VERSION_INFO far *vicVSInfo)
{
   char szFullPath[256];
   DWORD dwHandle;
   LPVOID pbData;
   DWORD dwBufsiz;

   // Clear struct
   _fmemset(vicVSInfo, 0, sizeof(VIC_VERSION_INFO));
   // Get module's name
   GetModuleFileName(hDLLInst_, szFullPath, sizeof(szFullPath));
   // Get the size of the version data struct
   if((dwBufsiz = GetFileVersionInfoSize((LPSTR)szFullPath, &dwHandle)) != 0) {
      // Allocate space for version data
      if((pbData = malloc(dwBufsiz)) != 0) {
         if(GetFileVersionInfo(szFullPath, dwHandle, dwBufsiz, pbData) != 0) {
            UINT j, len;
            BOOL nRc;
            char far *pp;
            VS_FIXEDFILEINFO *pvsfi;

            nRc = VerQueryValue(pbData, "\\", (void far * far *)&pvsfi, &len);
            if(nRc) 
               vicVSInfo->version = (((UCHAR)HIWORD(pvsfi->dwFileVersionMS)) << 8) | ((UCHAR)LOWORD(pvsfi->dwFileVersionMS));
            // Extended lib info is stored at the end of InternalName string as 0x3x
            nRc = VerQueryValue(pbData, "\\StringFileInfo\\040904E4\\InternalName", &pp, &len);
            if(nRc) {
               len = lstrlen(pp);
               pp += len - 4;  // Point pp at last four chars in string
               for(j=0; j<4; j++) { // Combine LSBs into WORD
                  vicVSInfo->flags <<= 4;
                  vicVSInfo->flags |= (WORD)(*pp++ & 0x0f);
                  }
               }
            }
         // Free memory
         free(pbData);
         }
      }
   return(vicVSInfo->version);
}

// Delete any critical sections that were allocated
static void deleteCriticalSections(void)
{
   extern void deleteGIFCs(void);
   extern void deleteBMPCs(void);
   extern void deleteTGACs(void);
   extern void deleteTIFCs(void);
   extern void deleteJPGCs(void);
   extern void deleteMatchcolorimageCs(void);
   extern void deletePrintimageCs(void);
   extern void deleteCoverCs(void);
   extern void deleteWtaverageCs(void);
   extern void deleteCoverclearCs(void);
   extern void deletePNGCs(void);
   typedef struct { void (*fctn)(void); } DELETE_CS;
   static DELETE_CS deleteCs[] = {
      { deleteGIFCs }, { deleteBMPCs }, { deleteTGACs }, 
      { deleteTIFCs }, { deleteJPGCs }, 
      { deletePrintimageCs }, { deleteMatchcolorimageCs },
      { deleteCoverCs }, { deleteWtaverageCs }, { deleteCoverclearCs },
      { deletePNGCs },
      };
   int j = dim(deleteCs);

   while(--j >= 0)
      deleteCs[j].fctn();
}
