#if !defined(AFX_DLGMATROXVISIONVIEW_H__66E1A7E3_5987_43B1_8736_C3956600D380__INCLUDED_)
#define AFX_DLGMATROXVISIONVIEW_H__66E1A7E3_5987_43B1_8736_C3956600D380__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgMatroxVisionView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgMatroxVisionView dialog

class CDlgMatroxVisionView : public CDialog
{
// Construction
public:
	CDlgMatroxVisionView(CWnd* pParent = NULL);   // standard constructor

	void	SetPanelNo(int nNo);//	{ m_nPanelNo = nNo; }
	void	SetInspectArea(BOOL bSet);
	void	GetInspectArea(DPOINT& dpStart, DPOINT& dpEnd);
	
	HWND	m_hVision;

// Dialog Data
	//{{AFX_DATA(CDlgMatroxVisionView)
	enum { IDD = IDD_DLG_MATROX_VISION_VIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgMatroxVisionView)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int		m_nPanelNo;
	
	DPOINT m_dpMoving;
	DPOINT m_dpStart;
	DPOINT m_dpEnd;
	BOOL m_bSetting;
	BOOL m_bClick;

	// Generated message map functions
	//{{AFX_MSG(CDlgMatroxVisionView)
		// NOTE: the ClassWizard will add member functions here
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMATROXVISIONVIEW_H__66E1A7E3_5987_43B1_8736_C3956600D380__INCLUDED_)
