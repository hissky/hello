#if !defined(AFX_PANEMANUALCONTROLLASER_H__64A154B8_33FB_4E4E_BFC7_4C28E0E22B0D__INCLUDED_)
#define AFX_PANEMANUALCONTROLLASER_H__64A154B8_33FB_4E4E_BFC7_4C28E0E22B0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlLaser.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaser form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorStatic.h"
#include "LedButton.h"
#include "UEasyButtonEx.h"
#include "UEasyButton.h"
#include "DlgDisp.h"
#include "..\device\devicemotor.h"
#include "..\DEVICE\CorrectTime.h"	// Added by ClassView
#include "..\device\HMotor.h"
#include "DlgLaserOnTime.h"
class CPaneManualControlLaser : public CFormView
{
protected:
	CPaneManualControlLaser();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlLaser)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlLaser)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_LASER };
	CLedButton	m_ledWaterFlowAlarm;
	CLedButton	m_ledShutter;
	CLedButton	m_ledReady;
	CLedButton	m_ledPowerError;
	CLedButton	m_ledMod;
	CLedButton	m_ledLaserPower;
	CLedButton	m_ledFault;
	CLedButton	m_ledDummyFree;
	CLedButton	m_ledChiller;
	CLedButton  m_ledLPC;

	UEasyButton	m_btnShutter;
	UEasyButton	m_btnPower;
	UEasyButton	m_btnDummyFree;
	UEasyButton m_btnChiller;
	UEasyButton m_btnLPC;

	UEasyButtonEx	m_btnLaserWarmUp;
	UEasyButtonEx	m_btnLaserOnTimeSet;
	UEasyButtonEx	m_btnTurnOn;
	UEasyButtonEx	m_btnTurnOff;
	UEasyButtonEx	m_btnScannerCheck;
	UEasyButtonEx	m_btnScannerInposition;

	CColorStatic	m_stcLaserOntime;
	CCorrectTime   m_pLaserOnTime;
	//2011527
	UEasyButton	m_btnAOMPower;
	CLedButton	m_ledAomPower;
	CLedButton	m_ledAomAlarm;

	UEasyButton	m_btnScannerPower;
	CLedButton	m_ledScannerPower;

	CDlgLaserOnTime* m_pdlgLaserOnTime;
	//}}AFX_DATA

// Attributes
public:
	BOOL			m_bShutter;
	BOOL			m_bLaserPower;
	BOOL			m_bAomPower;
	BOOL			m_bScannerPower;
	BOOL			m_bChiller;
	POWER_STATUS	m_gStatus;
	BOOL			m_bLPC;
	BOOL			m_bLaserOnTime;
	BOOL			m_bFirstLaserOnTime;
	LONG			m_lDay;
	LONG			m_lHour;
	LONG			m_lMin;
	LONG			m_lSec;
	LONG			m_lBackupDay;
	LONG			m_lBackupHour;
	LONG			m_lBackupMin;
	LONG			m_lBackupSec;
	double			m_dTime;
	//2011527
#ifndef __MP920_MOTOR__
	DeviceMotor*	m_pMotor;
#else
	HMotor*			m_pMotor;
#endif
	BOOL			m_bSkipTabControl;
	BOOL			m_bScannerOld;
	BOOL			m_bLaserPowerOld;
	BOOL			m_bDummyFree;
// Attributes
protected:
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntBtn2;
	CFont			m_fntStatic2;

	BOOL			m_bReady;
	BOOL			m_bFault;
	BOOL			m_bMod;
	BOOL			m_bWaterFlowAlarm;
	BOOL			m_bPowerError;

	int				m_nTimerID;

// Operations
public:
	void SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
						int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
						int ndiff, int nJobType);
	BOOL GetUserDummyOn();
	BOOL m_bOnDummy;
	void SetAuthorityByLevel(int nLevel);

	CDlgDisp*		m_pDisp;

	void			InitBtnControl();
	void			InitStaticControl();

	void			InitTimer();
	void			DestroyTimer();

	void			MessageLoop();
	void GetTime(double dTime, LONG& lDay, LONG& lHour, LONG& lMin, LONG& lSec);
	void SetTime(double& dTime, LONG lDay, LONG lHour, LONG lMin, LONG lSec);
	BOOL	OpenFile();
	BOOL	SaveFile( LONG lDay, LONG lHour, LONG lMin, LONG lSec);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlLaser)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlLaser();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlLaser)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonTurnOn();
	afx_msg void OnButtonTurnOff();
	afx_msg void OnButtonLaserWarmUp();
	afx_msg void OnButtonLaserWarmUpOnTimeSet();
	afx_msg void OnButtonPower();
	afx_msg void OnButtonShutter();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonRelaod();
	afx_msg void OnButtonAOMPower(); //2011527
	afx_msg void OnButtonScannerPower();
	afx_msg void OnButtonDummyFree();
	afx_msg void OnButtonScannerCheck();
	afx_msg void OnButtonChiller();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonScannerInposition();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonLpc();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLLASER_H__64A154B8_33FB_4E4E_BFC7_4C28E0E22B0D__INCLUDED_)
