#if !defined(AFX_PANEHV2_H__80E235B2_1883_4698_A02A_EA008B53434F__INCLUDED_)
#define AFX_PANEHV2_H__80E235B2_1883_4698_A02A_EA008B53434F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// panehv2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneHV2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneHV2 : public CFormView
{
protected:
	CPaneHV2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneHV2)

// Form Data
public:
	//{{AFX_DATA(CPaneHV2)
#ifdef __USE_COGNEX_7_LIB__
	enum { IDD = IDD_HV_2 };
#else
	enum { IDD = IDD_HV_2_NEW };
#endif
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneHV2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneHV2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneHV2)
	afx_msg void OnDblClickVisionpro2h();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEHV2_H__80E235B2_1883_4698_A02A_EA008B53434F__INCLUDED_)
