// DTextData.h: interface for the DTextData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DTEXTDATA_H__1FDEC84E_9DF8_42B3_8794_8BA6C73D6FFE__INCLUDED_)
#define AFX_DTEXTDATA_H__1FDEC84E_9DF8_42B3_8794_8BA6C73D6FFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct  FONT_DATA // OCR Font add
{
	int		nCount;
	CPoint	ptData[20];	
};

struct CHARLINE {
	CPoint		npStartPos;
	CPoint		npEndPos;
};
typedef CHARLINE*	LPCHARLINE;
typedef CTypedPtrList <CPtrList, LPCHARLINE>	CharDataList;

struct CHARINFO {
	CharDataList lpCharData;
	int nWidth;
	int nHeight;
	int nCenterX;
	int nCenterY;
};

struct CHARHOLE {
	CPoint		npHolePos;
};
typedef CHARHOLE*	LPCHARHOLE;
typedef CTypedPtrList <CPtrList, LPCHARHOLE>	CharHoleDataList;

#define  GRID_X  5
#define  GRID_Y  9
class DTextData  
{
public:
	int GetAxis(int nRefMode, int nAxisInfo);
	void GetOneCharSize(double dRatio, int nStartX);
	int GetRotateOffset(int nAxisInfo);
	BOOL AddGridHole();
	void SetTextGrid(int nX, int nY);
	POSITION m_pos;
	BOOL GetNextPoint(BOOL bDot, int &nX, int &nY, int &nX2, int &nY2);
	int GetDataCount(BOOL bDot);
	void ChangeAxis(BOOL bFilpX, BOOL bFilpY, int nRotate,int nAxisInfo);
	BOOL AddHoletoTempData(LPCHARHOLE pHole);
	void RepositionData(int nMode);
	void SaveTempHoleToList();
	void SetOneLine(LPCHARLINE pLine, int nGab);
	void RemoveTempData();
	void RemoveResultData();
	int m_nCharHeight;
    int m_nCharWidth;
	BOOL GetTextData(CString str, int nSize, int nGabSize, BOOL bDot, int nRefMode, int umFieldSize, BOOL bFlipX, BOOL bFilpY, int nRotate, double dInterval, int nAxisInfo, BOOL UseInnerOCRFont);
	void GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY);
	void SaveExcellon();
	void RemoveOneCharData(int nIndex);
	int m_nLeft;
	int m_nRight;
	int m_nBottom;
	int m_nTop;
	int m_nOneCharLeft;
	int m_nOneCharRight;
	int m_nOneCharBottom;
	int m_nOneCharTop;
	void RemoveAllCharInfo();
	BOOL readEOChar(CFile &file, int index, int offset, int size);
	BOOL InitCharData();
	DTextData();
	virtual ~DTextData();

	CharDataList m_LineData;
	CharHoleDataList m_HoleData;
	CharHoleDataList m_tempHoleData;

	CHARINFO m_CharList[128];
	int m_nUmFieldSize;

	BOOL m_bGrid[GRID_X][GRID_Y];
	int	m_nSelChar;
	int m_nDivide;

	FONT_DATA	m_OCRFontInfo[14];
	int m_nFinalRotation;//OCR MOVE
    double m_dOcrWidth_mm;
    double m_dOneOcrWidth_mm;
};

extern DTextData gTextData;
extern DTextData gTextDataTemp;
#endif // !defined(AFX_DTEXTDATA_H__1FDEC84E_9DF8_42B3_8794_8BA6C73D6FFE__INCLUDED_)
