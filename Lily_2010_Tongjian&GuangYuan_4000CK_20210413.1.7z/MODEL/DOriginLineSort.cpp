// DLineSort.cpp: implementation of the DLineSort class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DOriginLineSort.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DOriginLineSort::DOriginLineSort()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	m_bUsed = FALSE;
}

DOriginLineSort::~DOriginLineSort()
{
	m_LineData.RemoveAll();
}

void DOriginLineSort::AddLineData(ORIGINLINE_SORT_DATA *pLineData)
{
	if (pLineData->pLine->npStartPos.x > m_nMaxX)
		m_nMaxX = pLineData->pLine->npStartPos.x;
	
	if (pLineData->pLine->npStartPos.x < m_nMinX)
		m_nMinX = pLineData->pLine->npStartPos.x;
	
	if (pLineData->pLine->npStartPos.y > m_nMaxY)
		m_nMaxY = pLineData->pLine->npStartPos.y;
	
	if (pLineData->pLine->npStartPos.y < m_nMinY)
		m_nMinY = pLineData->pLine->npStartPos.y;
	

	if (pLineData->pLine->npEndPos.x > m_nMaxX)
		m_nMaxX = pLineData->pLine->npEndPos.x;
	
	if (pLineData->pLine->npEndPos.x < m_nMinX)
		m_nMinX = pLineData->pLine->npEndPos.x;
	
	if (pLineData->pLine->npEndPos.y > m_nMaxY)
		m_nMaxY = pLineData->pLine->npEndPos.y;
	
	if (pLineData->pLine->npEndPos.y < m_nMinY)
		m_nMinY = pLineData->pLine->npEndPos.y;

	m_LineData.AddTail(pLineData);
}

void DOriginLineSort::AddHeadLineData(ORIGINLINE_SORT_DATA *pLineData)
{
	if (pLineData->pLine->npStartPos.x > m_nMaxX)
		m_nMaxX = pLineData->pLine->npStartPos.x;
	
	if (pLineData->pLine->npStartPos.x < m_nMinX)
		m_nMinX = pLineData->pLine->npStartPos.x;
	
	if (pLineData->pLine->npStartPos.y > m_nMaxY)
		m_nMaxY = pLineData->pLine->npStartPos.y;
	
	if (pLineData->pLine->npStartPos.y < m_nMinY)
		m_nMinY = pLineData->pLine->npStartPos.y;
	
	
	if (pLineData->pLine->npEndPos.x > m_nMaxX)
		m_nMaxX = pLineData->pLine->npEndPos.x;
	
	if (pLineData->pLine->npEndPos.x < m_nMinX)
		m_nMinX = pLineData->pLine->npEndPos.x;
	
	if (pLineData->pLine->npEndPos.y > m_nMaxY)
		m_nMaxY = pLineData->pLine->npEndPos.y;
	
	if (pLineData->pLine->npEndPos.y < m_nMinY)
		m_nMinY = pLineData->pLine->npEndPos.y;
	
	m_LineData.AddHead(pLineData);
}

CPoint DOriginLineSort::GetHeadPoint()
{
	ORIGINLINE_SORT_DATA* pData = m_LineData.GetHead();
	if(pData)
		return pData->pLine->npStartPos;

	CPoint pt;
	pt.x = INT_MAX;
	return pt;
}

CPoint DOriginLineSort::GetTailPoint()
{
	ORIGINLINE_SORT_DATA* pData = m_LineData.GetTail();
	if(pData)
		return pData->pLine->npEndPos;
	
	CPoint pt;
	pt.x = INT_MAX;
	return pt;
}

double DOriginLineSort::GetDistance()
{
	CPoint ptStart, ptEnd;
	ptStart = GetHeadPoint();
	ptEnd = GetTailPoint();
	if(ptStart.x == INT_MAX || ptEnd.x == INT_MAX)
		return 0;
	else
		return max( abs(ptStart.x - ptEnd.x) , abs(ptStart.y - ptEnd.y));
}

void DOriginLineSort::ChangeStartEnd()
{
	OriginLineSortList TempData;
	ORIGINLINE_SORT_DATA* pData;
	POSITION pos;
	CPoint tempP;
	pos = m_LineData.GetHeadPosition();
	while(pos)
	{
		pData = m_LineData.GetNext(pos);
		tempP = pData->pLine->npStartPos;
		pData->pLine->npStartPos = pData->pLine->npEndPos;
		pData->pLine->npEndPos = tempP;
		TempData.AddHead(pData);
	}
	m_LineData.RemoveAll();

	pos = TempData.GetHeadPosition();
	while(pos)
	{
		pData = TempData.GetNext(pos);
		m_LineData.AddTail(pData);
	}
}

void DOriginLineSort::AddDataTail(DOriginLineSort* pLineData, BOOL bReverse)
{
	CPoint tempPoint;
	ORIGINLINE_SORT_DATA* pData;
	if(bReverse)
	{
		POSITION pos = pLineData->m_LineData.GetTailPosition();
		while(pos)
		{
			pData = pLineData->m_LineData.GetPrev(pos);
			tempPoint = pData->pLine->npStartPos;
			 pData->pLine->npStartPos =  pData->pLine->npEndPos;
			 pData->pLine->npEndPos = tempPoint;
			AddLineData(pData);
		}
	}
	else
	{
		POSITION pos = pLineData->m_LineData.GetHeadPosition();
		while(pos)
		{
			pData = pLineData->m_LineData.GetNext(pos);
			AddLineData(pData);
		}
	}
}

void DOriginLineSort::AddDataHead(DOriginLineSort* pLineData, BOOL bReverse)
{
	CPoint tempPoint;
	ORIGINLINE_SORT_DATA* pData;
	if(!bReverse)
	{
		POSITION pos = pLineData->m_LineData.GetTailPosition();
		while(pos)
		{
			pData = pLineData->m_LineData.GetPrev(pos);
			AddHeadLineData(pData);
		}
	}
	else
	{
		POSITION pos = pLineData->m_LineData.GetHeadPosition();
		while(pos)
		{
			pData = pLineData->m_LineData.GetNext(pos);
			tempPoint = pData->pLine->npStartPos;
			 pData->pLine->npStartPos =  pData->pLine->npEndPos;
			 pData->pLine->npEndPos = tempPoint;
			AddHeadLineData(pData);
		}
	}
}