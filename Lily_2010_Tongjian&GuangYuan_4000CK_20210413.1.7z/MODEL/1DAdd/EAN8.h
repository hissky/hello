// EAN13.h: interface for the CEAN8 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EAN8_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_)
#define AFX_EAN8_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Barcode.h"

class CEAN8 : public CBarcode  
{
public:
	CString EncodingDigit(int iNo, int iCnt);
	CString m_strStructure;
	void StructureOfEAN8(int iNo);
	CEAN8();
	CEAN8(int nSymbology);

	virtual ~CEAN8();
	void LoadData(CString csMessage, double dNarrowBar, double dFinalHeight, long nGuardbarHeight, int nStartingXPixel, int nStartingYPixel, double dRatio);
	
	void DrawBitmap();
	void BitmapToClipboard();
	CStringList list;
	CStringList numList;
	
	private:
	long m_nGuardbarHeight;
	long CalculateCheckSumDigit();

	CString RetrieveSystemNumberPattern(int iSystemNumber/* = 0*/, int iNumber);

	CString RetrieveLeftOddParityPattern(int iNumber); //used for encoding UPCE barcode
	CString RetrieveLeftEvenParityPattern(int iNumber);//used for encoding UPCE barcode
	
	CString RetrieveLeftPattern(int iNumber);
	CString RetrieveRightPattern(int iNumber);

	void DrawPattern(CString csPattern);

	void DrawEAN8();
	void DrawUPCE();


};

#endif // !defined(AFX_EAN13_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_)
