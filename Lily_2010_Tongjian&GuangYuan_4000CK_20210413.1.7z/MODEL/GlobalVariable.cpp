// GlobalVariable.cpp: implementation of the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "GlobalVariable.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\device\hdevicefactory.h"
#include "..\device\deviceMotor.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
GlobalVariable gVariable;

GlobalVariable::GlobalVariable()
{
	m_strPath.Format(_T(""));
	m_strPath2.Format(_T(""));
	memset( &m_sGlobal, 0, sizeof(m_sGlobal) );
	Initialize();
	m_bNoUseVisionCompen = FALSE;
	m_bUseSkiveAutoSetting = FALSE;

	InitFirstPulseCheckFlag();
	m_bShowBlockOnly = false;
	m_bShowNoBlockOnly = false;
	m_bShowSelectAreaOnly = false;
	m_bShowSelectFidBlockOnly = false;
	m_nSelectFidBlock = -1;
	m_bHideTool = false;
	m_nSelectArea = -1;
	m_bShowBlockNo = false;
	m_bMarkingCavity = FALSE;
	for(int i=0; i<2; i++)
	{
		m_dGlobal_FidScaleX[i] = 100;
		m_dGlobal_FidScaleY[i] = 100;
	}
}

GlobalVariable::~GlobalVariable()
{
//	SaveGlobalTool();
//	SaveRefuseList();

	for(int i=0; i<MAX_TOOL_NO; i++)
	{
		delete m_pToolCode[i];
		m_pToolCode[i] = NULL;
	}

	if(m_pRefuse != NULL)
	{
		delete m_pRefuse;
		m_pRefuse = NULL;
	}
}

void GlobalVariable::Initialize()
{
	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = new CToolCodeList;
		m_pToolCode[i]->Initialize();
		if(i < 1)
			m_pToolCode[i]->m_bUseTool = TRUE;
	}
//	LoadGlobalTool();
	
	m_pRefuse = new CRefuseList;
	m_pRefuse->Initialize();
}

BOOL GlobalVariable::SaveGlobalTool()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10029);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadGlobalTool()
{

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeRead))
		{
			return FALSE;
		}
		
//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10029);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::SaveRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeRead))
		{
			return FALSE;
		}

//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}
void GlobalVariable::SaveTableCalLog(BOOL b1st)
{

	CString strFile, strLog;
	strFile.Format(_T("TableCalCheckLog"));
	strLog.Format("Master T Cal Start");

	if(!b1st)
		strLog.Format("Slave T Cal Start");

	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	double dStartX, dStartY,dLaserMOffsetX, dLaserMOffsetY, dPanelOffsetX, dPanelOffsetY;

	dStartX = 44.846;
	dStartY = 3.46;

	int nFlag = 1;//FIRST_PANEL_OFFSET;

	if(!b1st)
		nFlag = 2;//SECOND_PANEL_OFFSET;

	for(int ii = 0; ii < 86; ii++)
	{

		dLaserMOffsetX  = dStartX; 
		dLaserMOffsetY  = dStartY + (10 * ii);

		gDeviceFactory.GetMotor()->GetAxisMoveOffset(dLaserMOffsetX, dLaserMOffsetY, dPanelOffsetX, dPanelOffsetY, nFlag);
		CString str;
		str.Format("%d \t %.3f \t %.3f \t %8f \t %.8f",ii+1, dLaserMOffsetX, dLaserMOffsetY, dPanelOffsetX, dPanelOffsetY);
		TRACE("%s\n",str);

		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
	}

}
void GlobalVariable::Serialize(CArchiveMark &ar, int nVersion, int nMode)
{

	TRY
	{
		if (ar.IsStoring())
		{	// storing code

			if(nMode == 0)
			{
				m_nVersion = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion << _T("\n");
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->SaveFile10000(ar, m_nVersion);
					}
				}
			}
			else
			{
				m_nVersion2 = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion2 << _T("\n");
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->SaveFile10000(ar, m_nVersion2);
				}
			}
		}
		else
		{	// loading code

			if(nMode == 0)
			{
				ar >> m_nVersion; 
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->LoadFile10000(ar, m_nVersion, TRUE);
					}
				}
			}
			else
			{
				ar >> m_nVersion2; 
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->LoadFile10000(ar, m_nVersion2);
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
	}
	END_CATCH
}

void GlobalVariable::SetPath()
{
	m_strPath.Format(_T("%sGlobalTool.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	m_strPath2.Format(_T("%sRefuseList.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
}

double GlobalVariable::GetLMDuty_us(int nFrq ,double dDutyPercent)//20160627
{

	double dMaxLM_us = 1/(double)nFrq * 1000000. ;

	double dTagetLM_us = dDutyPercent/100 * dMaxLM_us;

	return dTagetLM_us;
}
void GlobalVariable::GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax)
{
	//Get Min,Max Power
	double dGap = dTagetPower * dTol/100;

	dMin = dTagetPower - dGap;
	dMax = dTagetPower + dGap;
}
void GlobalVariable::InitFirstPulseCheckFlag()
{
	for(int ii = 0; ii < BEAMPATH_COUNT; ii++)
		m_bFirstPulseCheckFlag[ii] = FALSE;
}

