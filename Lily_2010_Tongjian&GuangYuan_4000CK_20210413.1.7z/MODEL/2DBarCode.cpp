// 2DBarCode.cpp: implementation of the C2DBarCode class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "2DBarCode.h"

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

#include "deasydrillerini.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define SZ_EQUAL	_T("= ")
#define SZ_MARKDRAW	_T("MARK_DRAW")
#define SZ_MARKJUMP	_T("MARK_JUMP")

// Marking type
#define MARKINGTYPE_DOT				0
#define MARKINGTYPE_LINE			1
#define MARKINGTYPE_BOXANDLINE		2
#define NUM_BARCODE2D_MARKINGTYPE	3

//////////////////////////////////////////////////////////////////////////////////////////
#define ASCII_ENCODE    1
#define C40_ENCODE      2
#define TEXT_ENCODE     3
#define X12_ENCODE      4
#define EDIFACT_ENCODE  5
#define BASE256_ENCODE  6

#define SHIFT1_SET  0
#define SHIFT2_SET  1
#define SHIFT3_SET  2
#define BASIC_SET   3
#define GEN			0x2d
#define NUM_SIZES	30

const int LATCH_CODES[BASE256_ENCODE+1] = {
	0,   // DUMMY VALUE
	254, // UNLATCH TO ASCII_ENCODE
	230, // LATCH TO C40_ENCODE
	239, // TEXT_ENCODE
	238, // X12_ENCODE
	240, // EDIFACT_ENCODE
	231  // BASE256_ENCODE
};

int nrow, ncol, *array;



  extern const int  NUM_ROWS         [ NUM_SIZES ] =
    {   10,   12,   14,   16,   18,   20,   22,   24,   26,   32,   36,   40,
        44,   48,   52,   64,   72,   80,   88,   96,  104,  120,  132,  144,
         8,    8,   12,   12,   16,   16 } ;

  extern const int NUM_COLS         [ NUM_SIZES ] =
    {   10,   12,   14,   16,   18,   20,   22,   24,   26,   32,   36,   40,
        44,   48,   52,   64,   72,   80,   88,   96,  104,  120,  132,  144,
        18,   32,   26,   36,   36,   48 } ;

  extern const int TOTAL_SYMBOLS    [ NUM_SIZES ] =
    {    8,   12,   18,   24,   32,   40,   50,   60,   72,   98,  128,  162,
       200,  242,  288,  392,  512,  648,  800,  968, 1152, 1458, 1800, 2178,
        12,   21,   30,   40,   56,   77 } ;

  extern const int DATA_SYMBOLS     [ NUM_SIZES ] =
    {    3,    5,    8,   12,   18,   22,   30,   36,   44,   62,   86,  114,
       144,  174,  204,  280,  368,  456,  576,  696,  816, 1050, 1304, 1558,
         5,   10,   16,   22,   32,   49 } ;

  extern const int CHECK_SYMBOLS    [ NUM_SIZES ] =
    {    5,    7,   10,   12,   14,   18,   20,   24,   28,   36,   42,   48,
        56,   68,   84,  112,  144,  192,  224,  272,  336,  408,  496,  620,
         7,   11,   14,   18,   24,   28 } ;

  extern const int NUM_INTERLEAVES  [ NUM_SIZES ] =
    {    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
         1,    1,    2,    2,    4,    4,    4,    4,    6,    6,    8,   10,
         1,    1,    1,    1,    1,    1 } ;

  extern const int CHECK_BLOCK_SIZE [ NUM_SIZES ] =
    {    5,    7,   10,   12,   14,   18,   20,   24,   28,   36,   42,   48,
        56,   68,   42,   56,   36,   48,   56,   68,   56,   68,   62,   62,
			7,   11,   14,   18,   24,   28 } ;


int poly5[5] = { 62, 111, 15, 48, 228 };

int poly7[7] = { 254, 92, 240, 134, 144, 68, 23 };

int poly10[10] = { 61, 110, 255, 116, 248, 223, 166, 185, 24, 28 };

int poly11[11] = { 120, 97, 60, 245, 39, 168, 194, 12, 205, 138, 175 };

int poly12[12] = { 242, 100, 178, 97, 213, 142, 42, 61, 91, 158, 153, 41 };

int poly14[14] = { 185, 83, 186, 18, 45, 138, 119, 157, 9, 95, 252, 192, 97,
                   156 };

int poly18[18] = { 188, 90, 48, 225, 254, 94, 129, 109, 213, 241, 61, 66, 75,
                   188, 39, 100, 195, 83 };

int poly20[20] = { 172, 186, 174, 27, 82, 108, 79, 253, 145, 153, 160, 188,
                   2, 168, 71, 233, 9, 244, 195, 15 };

int poly24[24] = { 193, 50, 96, 184, 181, 12, 124, 254, 172, 5, 21, 155, 223,
                   251, 197, 155, 21, 176, 39, 109, 205, 88, 190, 52 };

int poly28[28] = { 255, 93, 168, 233, 151, 120, 136, 141, 213, 110, 138, 17,
                   121, 249, 34, 75, 53, 170, 151, 37, 174, 103, 96, 71, 97,
                   43, 231, 211 };

int poly36[36] = { 112, 81, 98, 225, 25, 59, 184, 175, 44, 115, 119, 95, 137,
                   101, 33, 68, 4, 2, 18, 229, 182, 80, 251, 220, 179, 84, 120,
                   102, 181, 162, 250, 130, 218, 242, 127, 245 };

int poly42[42] = { 5, 9, 5, 226, 177, 150, 50, 69, 202, 248, 101, 54, 57, 253,
                   1, 21, 121, 57, 111, 214, 105, 167, 9, 100, 95, 175, 8, 242,
                   133, 245, 2, 122, 105, 247, 153, 22, 38, 19, 31, 137, 193,
                   77 };

int poly48[48] = { 19, 225, 253, 92, 213, 69, 175, 160, 147, 187, 87, 176, 44,
						 82, 240, 186, 138, 66, 100, 120, 88, 131, 205, 170, 90, 37,
                   23, 118, 147, 16, 106, 191, 87, 237, 188, 205, 231, 238, 133,
                   238, 22, 117, 32, 96, 223, 172, 132, 245 };

int poly56[56] = { 46, 143, 53, 233, 107, 203, 43, 155, 28, 247, 67, 127, 245,
                   137, 13, 164, 207, 62, 117, 201, 150, 22, 238, 144, 232, 29,
                   203, 117, 234, 218, 146, 228, 54, 132, 200, 38, 223, 36,
                   159, 150, 235, 215, 192, 230, 170, 175, 29, 100, 208, 220,
                   17, 12, 238, 223, 9, 175 };

int poly62[62] = { 204, 11, 47, 86, 124, 224, 166, 94, 7, 232, 107, 4, 170,
                   176, 31, 163, 17, 188, 130, 40, 10, 87, 63, 51, 218,
                   27, 6, 147, 44, 161, 71, 114, 64, 175, 221, 185, 106, 250,
                   190, 197, 63, 245, 230, 134, 112, 185, 37, 196, 108, 143,
                   189, 201, 188, 202, 118, 39, 210, 144, 50, 169, 93, 242 };

int poly68[68] = { 186, 82, 103, 96, 63, 132, 153, 108, 54, 64, 189, 211, 232,
                   49, 25, 172, 52, 59, 241, 181, 239, 223, 136, 231, 210, 96,
                   232, 220, 25, 179, 167, 202, 185, 153, 139, 66, 236, 227,
                   160, 15, 213, 93, 122, 68, 177, 158, 197, 234, 180, 248,
						 136, 213, 127, 73, 36, 154, 244, 147, 33, 89, 56, 159, 149,
                   251, 89, 173, 228, 220 };

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//##ModelId=3E410B2202EF
C2DBarCode::C2DBarCode()
{
	Xindex = 0 ;
	SwitchMode = 0;
	m_bFlipX = FALSE;
	m_bFlipY = FALSE;
	m_dRotate1 = 0;
	m_dRotate2 = 0;
	m_nUmFieldSize = 50000;
	m_nUmBarcodeSize = 2000;
	m_nXIndex = 0;
	m_nYIndex = 0;
}

//##ModelId=3E410B2202FD
C2DBarCode::~C2DBarCode()
{

}

//##ModelId=3E410B22035B
double C2DBarCode::CalcReal2DObjectSize(double InputMatrixSize, double InputOneCellSize, CString Contents)
{
	if (Make2DBarcode((unsigned char *)LPCTSTR(Contents), MatrixData) != 1)
		return FALSE ;
	MatrixWidth = MatrixData[0] ;
	MatrixHeight = MatrixData[1] ;

	double MatrixSize =0, OneCellSize =0, CellGap =0, RealObjectSize=0, OneDotSize;
	int NumOfCell; 
   
   MatrixSize  =  InputMatrixSize;
   OneDotSize =   InputOneCellSize;
  
   NumOfCell = MatrixData[0];
   
   OneCellSize = MatrixSize / NumOfCell;
   CellGap = (OneCellSize - InputOneCellSize );
   RealObjectSize = MatrixSize - CellGap;

   RealObjectSize = RealObjectSize;
   	if( array )  
	{	
		free(array) ;
		array = NULL;
	}

   return RealObjectSize;
	
}

//##ModelId=3E410B220341
int C2DBarCode::NewObject(BOOL bFlipX, BOOL bFlipY, double dRotate1, double dRotate2, int umSize, int umFieldSize, CString strContents, int nMSize)
{ 
//	strContents = _T("12 3");

	m_bFlipX = bFlipX;
	m_bFlipY = bFlipY;
	m_dRotate1 = dRotate1 * M_PI / 180.;
	m_dRotate2 = dRotate2 * M_PI / 180.;
	m_nUmFieldSize = umFieldSize;
	m_nUmBarcodeSize = umSize;
	m_nBarMSize = nMSize;

//	if (Make2DBarcode((unsigned char *)LPCTSTR(strContents), MatrixData) != 1)
	if (Make2DBarcodeNew(strContents, MatrixData) != 1)
		return FALSE ;

	MatrixWidth = MatrixData[0] ;
	MatrixHeight = MatrixData[1] ;

//	double MatrixSize =0, OneDotSize=0, NumOfContents =0, DrawOneDotSize=0;

//	MatrixSize  = 1000.0;

//	NumOfContents = strContents.GetLength();

//	DrawOneDotSize = MatrixSize / (MatrixWidth - 1);

//	OneDotSize = DrawOneDotSize / 2.0;

//	double dX, dY;
	int w, h;

	int nCount = 0;

	for( h = 0 ; h < MatrixHeight ; ++ h )
	{
		for( w = 0 ; w < MatrixWidth ; ++ w )
		{
			if ( MatrixData[ MatrixWidth * h + w + 2 ] == 0 ) //No Marking
			{
			}
			if ( MatrixData[ MatrixWidth * h + w + 2 ] == 1 ) // Marking
			{
//				dX = ((w - MatrixWidth/2) * DrawOneDotSize + OneDotSize);
//				dY = ((h - MatrixWidth/2) * DrawOneDotSize + OneDotSize);
				
//				m_pExcellon->m_DrillData[nTool].AddTail(m_pExcellon->AllocNewItem(nTool, dX, dY, 0));
				nCount++;
				TRACE(_T("%d, %d\n"), h, w);
			}
		}
	}
	m_nXIndex = 0;
	m_nYIndex = 0;
	
	return nCount;
}

BOOL C2DBarCode::GetNextPoint(int &nBarX1, int &nBarY1, int &nBarX2, int &nBarY2)
{
	double dHalfSizeX, dHalfSizeY, dDotSize;
	double dX, dY;
	int nX, nY;
	double cosTheta, sinTheta;
	
	dDotSize = 65535.0 * m_nUmBarcodeSize / m_nUmFieldSize / MatrixData[0]; // LSB ����
	dHalfSizeX = dDotSize * MatrixData[0] / 2.0;
	dHalfSizeY = dDotSize * MatrixData[1] / 2.0;
	
	for(int i = m_nYIndex; i < MatrixData[1]; i++)
	{
		
		for(int j = m_nXIndex; j < MatrixData[0]; j++)
		{
			if ( MatrixData[ MatrixWidth * i + j + 2 ] == 1 ) // Marking
			{
				if(m_bFlipX)
					nX = MatrixData[0] - j - 1;
				else
					nX = j;

				if(m_bFlipY)
					nY = MatrixData[1] - i - 1;
				else
					nY = i;

				dX = -dHalfSizeX + (nX + 0.5) * dDotSize;
				dY = -dHalfSizeY + (nY + 0.5) * dDotSize;

				cosTheta = cos(m_dRotate1);
				sinTheta = sin(m_dRotate1);
				nBarX1 = (int)(cosTheta*(dX) - sinTheta*(dY));
				nBarY1 = (int)(sinTheta*(dX) + cosTheta*(dY));
				
				nBarX2 = nBarX1;
				nBarY2 = nBarY1;
//				cosTheta = cos(m_dRotate2);
//				sinTheta = sin(m_dRotate2);
//				nBarX2 = (int)(cosTheta*(dX) - sinTheta*(dY));
//				nBarY2 = (int)(sinTheta*(dX) + cosTheta*(dY));

				TRACE(_T("%d, %d\n"), i, j);
				
				if(j == MatrixData[0] - 1)
				{
					m_nYIndex = i + 1;
					m_nXIndex = 0;
				}
				else
				{
					m_nYIndex = i;
					m_nXIndex = j + 1;
				}
				
				return TRUE;
			}
			else
			{
				if(j == MatrixData[0] - 1)
				{
					m_nXIndex = 0;
				}
			}
		}
	}
	return FALSE;
}

//##ModelId=3E410B22036B
void C2DBarCode::GetX12Value( unsigned char ch, unsigned char *value )
{
	if( ch == ' ' )  *value = 3 ;
	else if( isdigit(ch) )  *value = ch + 4 ;
	else if( isupper(ch) )  *value = 51 ;
	else *value = 0 ;
}

/* "module" places "chr+bit" with appropriate wrapping within array[]	*/
//##ModelId=3E410B22037C
void C2DBarCode::module(int row, int col, int chr, int bit)
{
	if (row < 0) { row += nrow; col += 4 - ((nrow+4)%8); }
	if (col < 0) { col += ncol; row += 4 - ((ncol+4)%8); }
	array[row*ncol+col] = 10*chr + bit;
}

/* "utah" places the 8 bits of a utah-shaped symbol character in ECC200 */
//##ModelId=3E410B220399
void C2DBarCode::utah(int row, int col, int chr)
{	
	module(row-2,col-2,chr,1);
	module(row-2,col-1,chr,2);
	module(row-1,col-2,chr,3);
	module(row-1,col-1,chr,4);
	module(row-1,col,chr,5);
	module(row,col-2,chr,6);
	module(row,col-1,chr,7);
	module(row,col,chr,8);
}

/* "cornerN" places 8 bits of the four special corner cases in ECC200	*/
//##ModelId=3E410B2203A9
void C2DBarCode::corner1(int chr)
{	
	module(nrow-1,0,chr,1);
	module(nrow-1,1,chr,2);
	module(nrow-1,2,chr,3);
	module(0,ncol-2,chr,4);
	module(0,ncol-1,chr,5);
	module(1,ncol-1,chr,6);
	module(2,ncol-1,chr,7);
	module(3,ncol-1,chr,8);
}
//##ModelId=3E410B2203B9
void C2DBarCode::corner2(int chr)
{	
	module(nrow-3,0,chr,1);
	module(nrow-2,0,chr,2);
	module(nrow-1,0,chr,3);
	module(0,ncol-4,chr,4);
	module(0,ncol-3,chr,5);
	module(0,ncol-2,chr,6);
	module(0,ncol-1,chr,7);
	module(1,ncol-1,chr,8);
}
//##ModelId=3E410B2203C8
void C2DBarCode::corner3(int chr)
{	
	
	module(nrow-3,0,chr,1);
	module(nrow-2,0,chr,2);
	module(nrow-1,0,chr,3);
	module(0,ncol-2,chr,4);
	module(0,ncol-1,chr,5);
	module(1,ncol-1,chr,6);
	module(2,ncol-1,chr,7);
	module(3,ncol-1,chr,8);
}
//##ModelId=3E410B2203D8
void C2DBarCode::corner4(int chr)
{	
	module(nrow-1,0,chr,1);
	module(nrow-1,ncol-1,chr,2);
	module(0,ncol-3,chr,3);
	module(0,ncol-2,chr,4);
	module(0,ncol-1,chr,5);
	module(1,ncol-3,chr,6);
	module(1,ncol-2,chr,7);
	module(1,ncol-1,chr,8);
}

/* "ecc200" fills an nrow x ncol array with appropriate values for ECC200 */
//##ModelId=3E410B2203DA
void C2DBarCode::ecc200(void)
{	int row, col, chr;

/* First, fill the array[] with invalid entries */
	for (row=0; row<nrow; row++) {
		for (col=0; col<ncol; col++) {
			array[row*ncol+col] = 0;
		}
	}

/* Starting in the correct location for character #1, bit H,... */
	chr = 1; row = 4; col = 0;

	do {
/* repeatedly first check for one of the special corner cases, then... */
		if ((row == nrow) && (col == 0)) corner1(chr++);
		if ((row == nrow-2) && (col == 0) && (ncol%4)) corner2(chr++);
		if ((row == nrow-2) && (col == 0) && (ncol%8 == 4)) corner3(chr++);
		if ((row == nrow+4) && (col == 2) && (!(ncol%8))) corner4(chr++);

/* sweep upward diagonally, inserting successive characters,... */
		do {
			if ((row < nrow) && (col >= 0) && (!array[row*ncol+col]))
				utah(row,col,chr++);
			row -= 2; col += 2;
		} while ((row >= 0) && (col < ncol));
		row += 1; col += 3;

/* & then sweep downward diagonally, inserting successive characters,... */
		do {
			if ((row >= 0) && (col < ncol) && (!array[row*ncol+col]))
				utah(row,col,chr++);
			row += 2; col -= 2;
		} while ((row < nrow) && (col >= 0));
		row += 3; col += 1;

/* ... until the entire array is scanned */
	} while ((row < nrow) || (col < ncol));

/* Lastly, if the lower righthand corner is untouched, fill in fixed pattern */
	if (!array[nrow*ncol-1]) {
		array[nrow*ncol-1] = array[nrow*ncol-ncol-2] = 1;
	}
}

//##ModelId=3E410B230001
void C2DBarCode::MakeECC200(int row, int col)
{
	if ( !row || !col) {
		printf(_T("I can't make ecc200 table\n"));
	} else {
		nrow = ncol = 0;
		nrow = row; ncol = col;
		if ((nrow >= 6) && (~nrow&0x01) && (ncol >= 6) && (~ncol&0x01)) {
			if( array ) {
				free(array) ;
				array = NULL;
				}
			array = (int *)malloc(sizeof(int) * nrow * ncol);

			ecc200();
		}
	}
}

//##ModelId=3E410B23010D
unsigned char C2DBarCode::State253( unsigned char Tcode, int Pos )
{
	int Tvalue;

	Tvalue = (((149 * Pos) % 253) + 1) + Tcode ;
	if( Tvalue < 254 )
		return( (unsigned char)Tvalue );
	else
		return( (unsigned char)(Tvalue - 254) );
}


//##ModelId=3E410B230010
void C2DBarCode::InitLogTables() 
{
	int i, j;

	for (j = 0; j < 256; j++) { gflog[j] = 0; }
	i = 1;
	for (j = 0; j < 255; j++) {
		gfpwr[j] = i;
		gflog[i] = j;

		i <<= 1;
		if (i > 255) {
			i ^= GEN + 256;
		}
	}
	return;
}


//##ModelId=3E410B230050
int C2DBarCode::GFmul(int p1, int p2)
 {
	int i;
	if ((p1 == 0) || (p2 == 0)) {
		return(0);
	}
	i = (int)gflog[p1] + (int)gflog[p2];
	if (i > 254) i -= 255;
	i = (int)gfpwr[i];
	return(i);
}

//##ModelId=3E410B23006D
int C2DBarCode::CalcChecks( int size )
 {
	int t, n, v, dsize, csize, isize, *p;

	/* Calculate Code 1 version, interleave for F & G need to be added */
   dsize = DATA_SYMBOLS [ size ] ;
   csize = CHECK_SYMBOLS [ size ] ;
   isize = NUM_INTERLEAVES [ size ] ;
   switch ( csize )
   {
     case 5 :
      p = poly5 ;
      break;
     case 7 :
      p = poly7 ;
      break;
	  case 10 :
		p = poly10 ;
      break;
	  case 11 :
      p = poly11 ;
		break;
     case 12 :
      p = poly12 ;
      break;
     case 14 :
      p = poly14 ;
      break;
     case 18 :
      p = poly18 ;
      break;
     case 20 :
      p = poly20 ;
      break;
     case 24 :
      p = poly24 ;
      break;
     case 28 :
      p = poly28 ;
		break;
     case 36 :
		p = poly36 ;
      break;
     case 42 :
      p = poly42 ;
      break;
     case 48 :
      p = poly48 ;
      break;
     case 56 :
      p = poly56 ;
      break;
     case 62 :
      p = poly62 ;
      break;
     case 68 :
      p = poly68 ;
      break;
     default:
		printf(_T("illegal code size\n"));
		break;
	}

	/* init chk bytes to 0 */
	for (v = 0; v < isize; v++) {
		for (n = dsize; n < dsize+csize; n++) {
			sym[v + (n * isize)] = 0;
		}
	}
	/* calculate csize check bytes from dsize data bytes */
	for (v = 0; v < isize; v++) {
		for ( n = 0; n < dsize; n++ ) {
			t = sym[v + (dsize * isize)] ^ sym[v + (n * isize)];
			for(int i =  0; i < csize-1; i++) {
				sym[v + ((dsize+i) * isize)] =
						sym[v + ((dsize+i+1) * isize)] ^ GFmul(t, p[i]);
			}
			sym[v + ((dsize+csize-1) * isize)] = GFmul(t, p[csize-1]);
		}
	}

	/* return symbol length in bytes */
	return( dsize+csize );
}

//##ModelId=3E410B23007D
int C2DBarCode::CalError( int code )
{
	int j, dsize, isize;

	InitLogTables();
		  //code = SIZE_44_44;
		  //code = SIZE_10_10;
		  /* Calculate the matrix size with interleave need to be added */

	dsize = DATA_SYMBOLS [ code ] ;
	/*csize = CHECK_SYMBOLS [ code ] ;*/
	isize = NUM_INTERLEAVES [ code ] ;
	for (j = 0; j < isize; j++) {
		for(int i =  0; i < dsize; i++) {
			sym[j + (i*isize)] = (unsigned char)(datacode[i]);
		}
	}

	return( CalcChecks(code) ) ;

}


//##ModelId=3E410B23007F
int C2DBarCode::EDIFACTEncode( void )
{
	int i ;
	char Str[5] ;

	if( (SrcLen - (Sindex+1)) < 4 ) {
		CurrentMode = ASCII_ENCODE; // JH.CHO�������� ..
		//ASCII encodation
		return(1) ;
	}

	for( i = 0; i < 4; i++ ) {
		Str[i] = SrcStr[Sindex++] & 0x3f ;
	}

	CodeStr[Cindex++] = (Str[0]<<2) | (Str[1]>>4) ;
	CodeStr[Cindex++] = (Str[1]<<4) | (Str[2]>>2) ;
	CodeStr[Cindex++] = (Str[2]<<6) | (Str[3]) ;

	return(1);
}

//##ModelId=3E410B23004E
int C2DBarCode::X12Encode( void )
{
	int i ;
	unsigned long CalValue ;
	unsigned char Value ;

	do {
		GetX12Value( SrcStr[Sindex++], &Value ) ;

		StrXValue[Xindex++] = Value ;

	} while( (!Xindex) || (Xindex%3) ) ;

	CalValue = (1600*StrXValue[0]) + (40*StrXValue[1]) + StrXValue[2] + 1 ;
	CodeStr[Cindex++] = (unsigned char)(CalValue / 256) ;
	CodeStr[Cindex++] = (unsigned char)(CalValue % 256) ;

	for( i = 3; i < Xindex; i++ ) {
		StrXValue[i-3] = StrXValue[i] ;
	}
	Xindex -= 3 ;

	return(1) ;
}

//##ModelId=3E410B23008D
int C2DBarCode::GetTextCodewords( unsigned int *Values, unsigned int *Code1, unsigned int *Code2 )
{
	unsigned long CalValue ;

	CalValue = (1600*Values[0]) + (40*Values[1]) + Values[2] + 1 ;
	*Code1 = (unsigned)(CalValue / 256) ;
	*Code2 = (unsigned)(CalValue % 256) ;
	return(1);
}

//##ModelId=3E410B23001F
void C2DBarCode::GetTextValue( unsigned char ch, int *type, unsigned int *value )
{
	if( ch == 32 || isdigit(ch) || islower(ch) ) {
		*type = BASIC_SET ;
		if( ch == 32 )  *value = ch - 29 ;
		else if( isdigit(ch) )  *value = ch - 44 ;
		else if( islower(ch) )  *value = (unsigned int)(ch - 83) ;
	}

	else if( /*ch >= 0 &&*/ ch <= 31 ) {
		*type = SHIFT1_SET ;
		*value = ch ;
	}

	else if( ch >= 33 && ch <= 47 ) {
		*type = SHIFT2_SET ;
		*value = ch - 33 ;
	}
	else if( ch >= 58 && ch <= 64 ) {
		*type = SHIFT2_SET ;
		*value = ch - 43 ;
	}
	else if( ch >= 91 && ch <= 95 ) {
		*type = SHIFT2_SET ;
		*value = ch - 69 ;
	}

	else if( ch == 96 ) {
		*type = SHIFT3_SET ;
		*value = ch - 96 ;
	}
	else if( ch >= 'A' && ch <= 'Z' ) {
		*type = SHIFT3_SET ;
		*value = ch - 64 ;
	}
	else if( ch >= 123 && ch <= 127 ) {
		*type = SHIFT3_SET ;
		*value = ch - 96 ;
	}
}

//##ModelId=3E410B23009D
int C2DBarCode::GetTextValues( unsigned char DataCh, unsigned int *Value )
{
	int SetType, in = 0;
	unsigned int Val ;

	if( DataCh > 127 ) {
		Value[in++] = 1;
		Value[in++] = 30;
		DataCh -= 128;
	}

	GetTextValue( DataCh, &SetType, &Val ) ;

	if( SetType != BASIC_SET )  Value[in++] = SetType ;
	Value[in++] = (unsigned int)Val ;

	return(in) ;
}

//##ModelId=3E410B2300AD
int C2DBarCode::FindMatrixType( void )
{
	int code ;

	for( code = 0; code < 30; code++ )
		if( Cindex <= DATA_SYMBOLS[code] )
			return( code );
	return(-1) ;
}

//##ModelId=3E410B2300BB
int C2DBarCode::IsNativeEDF( int index )
{
	char ch;
	ch = SrcStr[index] ;
	if( ch >= 32 && ch <= 94 ) {
		return(1);
	}
	return(0);
}

//##ModelId=3E410B2300BD
int C2DBarCode::IsNativeX12( int index )
{
	char ch;

	ch = SrcStr[index] ;
	if( ch == ' ' || isdigit(ch) || isupper(ch) ) {
		return(1);
	}
	return(0);
}

/********************** TEXT ENCODE *****************************/
//##ModelId=3E410B2300CC
int C2DBarCode::IsNativeText( int index )
{
	unsigned char ch;
	int SetType ;
	unsigned Val ;

	ch = SrcStr[index] ;

	GetTextValue( ch, &SetType, &Val ) ;

	return( (SetType == BASIC_SET) );
}

//##ModelId=3E410B23002E
void C2DBarCode::GetC40Value( unsigned char ch, int *type, unsigned int *value )
{
	if( ch == 32 || isdigit(ch) || isupper(ch) ) {
		*type = BASIC_SET ;
		if( ch == 32 )  *value = ch - 29 ;
		else if( isdigit(ch) )  *value = ch - 44 ;
		else if( isupper(ch) )  *value = ch - 51 ;
	}

	else if( /*ch >= 0 &&*/ ch <= 31 ) {
		*type = SHIFT1_SET ;
		*value = ch ;
	}

	else if( ch >= 33 && ch <= 47 ) {
		*type = SHIFT2_SET ;
		*value = ch - 33 ;
	}
	else if( ch >= 58 && ch <= 64 ) {
		*type = SHIFT2_SET ;
		*value = ch - 43 ;
	}
	else if( ch >= 91 && ch <= 95 ) {
		*type = SHIFT2_SET ;
		*value = ch - 69 ;
	}

	else if( ch == 96 ) {
		*type = SHIFT3_SET ;
		*value = ch - 96 ;
	}
	else if( ch >= 'a' && ch <= 'z' ) {
		*type = SHIFT3_SET ;
		*value = ch - 96 ;
	}
	else if( ch >= 123 && ch <= 127 ) {
		*type = SHIFT3_SET ;
		*value = ch - 96 ;
	}
}


//##ModelId=3E410B2300DA
int C2DBarCode::IsNativeC40( int index )
{
	unsigned char ch;
	int SetType ;
	unsigned Val ;

	ch = SrcStr[index] ;

	GetC40Value( ch, &SetType, &Val ) ;

	return( (SetType == BASIC_SET) );
}


//##ModelId=3E410B2300DC
int C2DBarCode::LookAheadTest( int index )
{
	int NumProcessChar = 0;
	double ASCII_cnt, C40_cnt, Text_cnt, X12_cnt, EDF_cnt, B256_cnt ;
	static int OldIn = -1 ;

	if( OldIn == index )
		return( CurrentMode );
	OldIn = index ;

	// Initialize counts
	if( CurrentMode == ASCII_ENCODE ) {
		ASCII_cnt = 0;
		C40_cnt = Text_cnt = X12_cnt = EDF_cnt = 1 ;
		B256_cnt = 1.25 ;
	}
	else {
		ASCII_cnt = 1 ;
		C40_cnt = Text_cnt = X12_cnt = EDF_cnt = 2 ;
		B256_cnt = 2.25 ;
	}

	if( CurrentMode == C40_ENCODE ) {
		C40_cnt = 0 ;
	}

	if( CurrentMode == TEXT_ENCODE ) {
		Text_cnt = 0 ;
	}

	if( CurrentMode == X12_ENCODE ) {
		X12_cnt = 0 ;
	}

	if( CurrentMode == EDIFACT_ENCODE ) {
		EDF_cnt = 0 ;
	}

	if( CurrentMode == BASE256_ENCODE ) {
		B256_cnt = 0 ;
	}

	//Repeat Test until a return condition occurs
	RepeatStep:

	//if at the end of data
	if( index == SrcLen ) {
		//Round up all the counts
		ASCII_cnt = ceil(ASCII_cnt) ;
		C40_cnt = ceil(C40_cnt) ;
		Text_cnt = ceil(Text_cnt) ;
		X12_cnt = ceil(X12_cnt) ;
		EDF_cnt = ceil(EDF_cnt) ;
		B256_cnt = ceil(B256_cnt) ;

		//if the ASCII cout is less than or equal to all the other counts
		//return ASCII_ENCODE
		if( (ASCII_cnt <= C40_cnt) &&  (ASCII_cnt <= Text_cnt) &&
			 (ASCII_cnt <= X12_cnt) &&  (ASCII_cnt <= EDF_cnt) &&
			 (ASCII_cnt <= B256_cnt) ) {
			return( ASCII_ENCODE ) ;
		}

		//if the B256 cout is less than all the other counts
		//return BASE256_ENCODE
		if( (B256_cnt < C40_cnt) &&  (B256_cnt < Text_cnt) &&
			 (B256_cnt < X12_cnt) &&  (B256_cnt < EDF_cnt) &&
			 (B256_cnt < ASCII_cnt) ) {
			return( BASE256_ENCODE ) ;
		}

		//if the EDF cout is less than all the other counts
		//return EDIFACT_ENCODE
		if( (EDF_cnt < C40_cnt) &&  (EDF_cnt < Text_cnt) &&
			 (EDF_cnt < X12_cnt) &&  (EDF_cnt < B256_cnt) &&
			 (EDF_cnt < ASCII_cnt) ) {
			return( EDIFACT_ENCODE ) ;
		}

		//if the Text cout is less than all the other counts
		//return TEXT_ENCODE
		if( (Text_cnt < C40_cnt) &&  (Text_cnt < EDF_cnt) &&
			 (Text_cnt < X12_cnt) &&  (Text_cnt < B256_cnt) &&
			 (Text_cnt < ASCII_cnt) ) {
			return( TEXT_ENCODE ) ;
		}

		//if the X12 cout is less than all the other counts
		//return X12_ENCODE
		if( (X12_cnt < C40_cnt) &&  (X12_cnt < EDF_cnt) &&
			 (X12_cnt < Text_cnt) &&  (X12_cnt < B256_cnt) &&
			 (X12_cnt < ASCII_cnt) ) {
			return( X12_ENCODE ) ;
		}

		//else
		return( C40_ENCODE ) ;
	}

	//Process the ASCII count
	if( isdigit(SrcStr[index]) ) {
		ASCII_cnt += 1/2. ;
	}
	else if( SrcStr[index] > 127 ) {
		//ASCII_cnt = (int)(ASCII_cnt+0.5) ;
		ASCII_cnt = ceil(ASCII_cnt) ;
		ASCII_cnt += 2 ;
	}
	else {
		ASCII_cnt += 1 ;
	}

	//Process the C40 count
	//if the data character is a native C40 character
	if( IsNativeC40(index) ) {
		C40_cnt += 2/3. ;
	}
	else if( SrcStr[index] > 127 ) {
		C40_cnt += 8/3. ;
	}
	else {
		C40_cnt += 4/3. ;
	}

	//Process th Text count
	if( IsNativeText(index) ) {
		Text_cnt += 2/3. ;
	}
	else if( SrcStr[index] > 127 ) {
		Text_cnt += 8/3. ;
	}
	else {
		Text_cnt += 4/3. ;
	}

	//Process the X12 count
	if( IsNativeX12( index ) ) {
		X12_cnt += 2/3. ;
	}
	else if( SrcStr[index] > 127 ) {
		X12_cnt += 13/3. ;
	}
	else {
		X12_cnt += 10/3. ;
	}

	//Process the EDF count
	if( IsNativeEDF( index ) ) {
		EDF_cnt += 3/4. ;
	}
	else if( SrcStr[index] > 127 ) {
		EDF_cnt += 17/4. ;
	}
	else {
		EDF_cnt += 13/4. ;
	}

	//Process the B256 count
	//if the character is a Function character (FNC1, Structured Append,
	//Reader Program, or Code Page), add 4 to the B256 count

	// write code here !!!

	//else
	B256_cnt += 1 ;

	// increase Num of Processed char and index
	NumProcessChar++ ;
	index++;

	//if at least 4 data character have been Processed
	if( NumProcessChar >= 4 ) {
		//if the ASCII cout plus 1 is less than or equal to all the other counts
		//return ASCII_ENCODE
		if( (ASCII_cnt+1 <= C40_cnt) &&  (ASCII_cnt+1 <= Text_cnt) &&
			 (ASCII_cnt+1 <= X12_cnt) &&  (ASCII_cnt+1 <= EDF_cnt) &&
			 (ASCII_cnt+1 <= B256_cnt) ) {
			return( ASCII_ENCODE ) ;
		}

		//if the B256 cout plus 1 is less than or equal to ASCII count
		//or less than the other counts
		//return BASE256_ENCODE
		if( (B256_cnt+1 <= ASCII_cnt ) ||
			 (B256_cnt+1 < C40_cnt) &&  (B256_cnt+1 < Text_cnt) &&
			 (B256_cnt+1 < X12_cnt) &&  (B256_cnt+1 < EDF_cnt) ) {
			return( BASE256_ENCODE ) ;
		}

		//if the EDF cout plus 1 is less than or equal to all the other counts
		//return EDIFACT_ENCODE
		if( (EDF_cnt+1 < C40_cnt) &&  (EDF_cnt+1 < Text_cnt) &&
			 (EDF_cnt+1 < X12_cnt) &&  (EDF_cnt+1 < B256_cnt) &&
			 (EDF_cnt+1 < ASCII_cnt) ) {
			return( EDIFACT_ENCODE ) ;
		}

		//if the Text cout plus 1 is less than or equal to all the other counts
		//return TEXT_ENCODE
		if( (Text_cnt+1 < C40_cnt) &&  (Text_cnt+1 < EDF_cnt) &&
			 (Text_cnt+1 < X12_cnt) &&  (Text_cnt+1 < B256_cnt) &&
			 (Text_cnt+1 < ASCII_cnt) ) {
			return( TEXT_ENCODE ) ;
		}

		//if the X12 cout plus 1 is less than or equal to all the other counts
		//return X12_ENCODE
		if( (X12_cnt+1 < C40_cnt) &&  (X12_cnt+1 < EDF_cnt) &&
			 (X12_cnt+1 < Text_cnt) &&  (X12_cnt+1 < B256_cnt) &&
			 (X12_cnt+1 < ASCII_cnt) ) {
			return( X12_ENCODE ) ;
		}

		//if the C40 count plus 1 is less than the ASCII, B256, EDF, and Text counts
		if( (C40_cnt+1 < ASCII_cnt) && (C40_cnt+1 < B256_cnt) &&
			 (C40_cnt+1 < EDF_cnt) && (C40_cnt+1 < Text_cnt ) ) {
			if( (C40_cnt < X12_cnt) ) {
				return( C40_ENCODE ) ;
			}
			if( (C40_cnt == X12_cnt) ) {
				//if one of the three X12 terminator/separator characters first
				//occurs in the yet to be prcessed data before a non-X12
				//character, return from the test indicating X12 Encodation.

				//else
				return( C40_ENCODE ) ;
			}
		}
	}

	//Repeat Test until a return condition occurs
	goto RepeatStep ;

}

//##ModelId=3E410B2300EA
int C2DBarCode::TextEncode( void )
{
	static unsigned int NewSym = 0, ValStr[7], VSsize = 0;
	unsigned int i ;
	int Mode, remain;
	unsigned int Values[5], Vsize, Code1, Code2;

	if( NewSym == 0 ) {
		Mode = LookAheadTest( Sindex );
		if( Mode != CurrentMode ) {
			if( Mode != ASCII_ENCODE )
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ; //UNLatch to Other Encodation
			CodeStr[Cindex++] = LATCH_CODES[Mode] ; //Latch to Other Encodation
			CurrentMode = Mode ;
			return(0) ;
		}
		if( VSsize == 0 )
			memset( ValStr, 0, 7 );
		memset( Values, 0, 5 );
		NewSym = 1;
	}

	Vsize = GetTextValues( SrcStr[Sindex++], Values );

	for( i = 0; i < Vsize; i++ )
		ValStr[VSsize+i] = Values[i] ;
	VSsize += Vsize ;

	while( VSsize >= 3 ) {
		NewSym = 0;

		GetTextCodewords( ValStr, &Code1, &Code2 );

		CodeStr[Cindex++] = Code1 ;
		CodeStr[Cindex++] = Code2 ;

		for( i = 0; i < VSsize-3; i++ )
			ValStr[i] = ValStr[i+3] ;
		VSsize -= 3;
	}

	if( Sindex >= SrcLen ) {
		remain = (DATA_SYMBOLS[FindMatrixType()] - Cindex) ;
		if( VSsize == 0 ) {
			if( remain != 0 && remain != 1 ) {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				CurrentMode = ASCII_ENCODE;
			}
		}
		else if( VSsize == 2 ) {
			if( remain == 2 ) {
				ValStr[VSsize++] = 0;
				GetTextCodewords( ValStr, &Code1, &Code2 );

				CodeStr[Cindex++] = Code1 ;
				CodeStr[Cindex++] = Code2 ;
			}
			else {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 2;
				CurrentMode = ASCII_ENCODE;
			}
		}
		else if( VSsize == 1 ) {
			if( remain == 2 ) {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
			else if( remain == 1 ) {
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
			else {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
		}
		NewSym = VSsize = 0;
	}
	return(1) ;
}

//##ModelId=3E410B2300EC
int C2DBarCode::GetC40Values( unsigned char DataCh, unsigned int *Value )
{
	int SetType, in = 0;
	unsigned int Val ;

	if( DataCh > 127 ) {
		Value[in++] = 1;
		Value[in++] = 30;
		DataCh -= 128;
	}

	GetC40Value( DataCh, &SetType, &Val ) ;

	if( SetType != BASIC_SET )  Value[in++] = SetType ;
	Value[in++] = (unsigned int)Val ;

	return(in) ;
}

//##ModelId=3E410B2300FB
int C2DBarCode::GetC40Codewords( unsigned int *Values, unsigned int *Code1, unsigned int *Code2 )
{
	unsigned long CalValue ;

	CalValue = (1600*Values[0]) + (40*Values[1]) + Values[2] + 1 ;
	*Code1 = (unsigned)(CalValue / 256) ;
	*Code2 = (unsigned)(CalValue % 256) ;
	return(1);
}

//##ModelId=3E410B230109
int C2DBarCode::C40Encode( void )
{
	static unsigned int NewSym = 0, ValStr[7], VSsize;
	unsigned int i ;
	int Mode, remain;
	unsigned int Values[5], Vsize, Code1, Code2;

	if( NewSym == 0 ) {
		Mode = LookAheadTest( Sindex );
		if( Mode != CurrentMode ) {
			if( Mode != ASCII_ENCODE )
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ; //UNLatch to Other Encodation
			CodeStr[Cindex++] = LATCH_CODES[Mode] ; //Latch to Other Encodation
			CurrentMode = Mode ;			
			VSsize=0; // MLPM6L3X3OPT1COLCu(E) ���� �������� �߰� Jh.Cho
			return(0) ;
		}
		if( VSsize == 0 )
			memset( ValStr, 0, 7 );
		memset( Values, 0, 5 );
		NewSym = 1;
	}

	Vsize = GetC40Values( SrcStr[Sindex++], Values );

	for( i = 0; i < Vsize; i++ )
		ValStr[VSsize+i] = Values[i] ;
	VSsize += Vsize ;

	while( VSsize >= 3 ) {
		NewSym = 0;

		GetC40Codewords( ValStr, &Code1, &Code2 );

		CodeStr[Cindex++] = Code1 ;
		CodeStr[Cindex++] = Code2 ;

		for( i = 0; i < VSsize-3; i++ ) { 
			ValStr[i] = ValStr[i+3] ;
			ValStr[i+3]=0;
		}
		if (VSsize>3) {
			NewSym=1;
		}
		VSsize -=3;
	}

	if( Sindex >= SrcLen ) {
		remain = (DATA_SYMBOLS[FindMatrixType()] - Cindex) ;
		if( VSsize == 0 ) {
			if( remain != 0 && remain != 1 ) {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				CurrentMode = ASCII_ENCODE;
			}
		}
		else if( VSsize == 2 ) {
			if( remain == 2 ) {
				ValStr[VSsize++] = 0;
				GetC40Codewords( ValStr, &Code1, &Code2 );

				CodeStr[Cindex++] = Code1 ;
				CodeStr[Cindex++] = Code2 ;
			}
			else {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 2;
				CurrentMode = ASCII_ENCODE;
			}
		}
		else if( VSsize == 1 ) {
			if( remain == 2 ) {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
			else if( remain == 1 ) {
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
			else {
				CodeStr[Cindex++] = LATCH_CODES[ASCII_ENCODE] ;
				Sindex -= 1;
				CurrentMode = ASCII_ENCODE;
			}
		}
		NewSym = VSsize = 0;
	}
	return(1) ;
}



//##ModelId=3E410B23010B
int C2DBarCode::ASCIIEncode( void )
{
	int Mode, TempNum;
	unsigned char TempStr[3] = {0,};

	if( isdigit(SrcStr[Sindex]) && isdigit(SrcStr[Sindex+1]) ) {
		strncpy_s( (char*)TempStr, 3, (char*)&SrcStr[Sindex], 2 );
		TempNum = atoi( (char*)TempStr );
		CodeStr[Cindex] = TempNum + 130 ;
		Sindex += 2;
		Cindex++;
		return(1) ;
	}

	Mode = LookAheadTest( Sindex );
	if( Mode == C40_ENCODE ) {
		CodeStr[Cindex++] = 230 ; //Latch to C40 Encodation
		CurrentMode = Mode ;
		SwitchMode = 1;
		return(0) ;
	}
	if( Mode == TEXT_ENCODE ) {
		CodeStr[Cindex++] = 239 ;
		CurrentMode = Mode ;
		SwitchMode = 1;
		return(0);
	}
	if( Mode == X12_ENCODE ) {
		CodeStr[Cindex++] = 238 ;
		CurrentMode = Mode ;
		SwitchMode = 1;
		return(0);
	}
	if( Mode == EDIFACT_ENCODE ) {
		CodeStr[Cindex++] = 240 ;
		CurrentMode = Mode ;
		SwitchMode = 1;
		return(0) ;
	}
	if( Mode == BASE256_ENCODE ) {
		CodeStr[Cindex++] = 231 ;
		Cindex++ ;
		CurrentMode = Mode ;
		SwitchMode = 1;
		return(0);
	}

	if( SrcStr[Sindex] > 127 ) {
		CodeStr[Cindex++] = 235 ;
		CodeStr[Cindex++] = SrcStr[Sindex++] - 128 ;
	}
	else {
		CodeStr[Cindex++] = SrcStr[Sindex++]+1 ;
	}
	return(1) ;
}

int C2DBarCode::Make2DBarcodeNew(CString& strContents, int *BarcodeArray)
{
	t_BarCode* pBC2D;

//	BCLicenseMe("dpiX LLC, CO-80916 - James Botkin", eLicKindSingle, 1, "D9DFB5E4692A76676A989D46B07D9D95", eLicProd2D);

	BCLicenseMe("Mem: EO Technics Co., Ltd KR-431 062", eLicKindDeveloper, 1, "9E965AF2783393A23441FD25CF8FF07F", eLicProd2D);

	ERRCODE eCode = BCAlloc (&pBC2D);

	int nRow = 0;
	int nCol = 0;

	CString strPath;
	strPath.Format(_T("%sTemp\\Ecc200Temp.bmp"), gEasyDrillerINI.m_clsDirPath.GetRootDir());

	if(eCode == S_OK)
	{
		eCode = BCSetText (pBC2D, strContents, strContents.GetLength());
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}

		eCode = BCSetBCType(pBC2D, static_cast <e_BarCType>(71));
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}		

		eCode = BCSetCDMethod(pBC2D, eCDStandard);
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}
		
		eCode = BCSetModWidth(pBC2D, _T(""));
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}
		
		eCode = BCCheck	(pBC2D);
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}

		eCode = BCCalcCD(pBC2D);
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}

		if(71 == eBC_DataMatrix)
		{
//			if(pGlyphBarcode->m_nRectangleMode)
//				eCode = BCSet_DM_Rectangular(pBC2D, TRUE);
			//eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(pGlyphBarcode->m_nColRow));
			//eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(4 + m_nBarMSize)); // 16x16
			eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(m_nBarMSize)); // 2015.12.02
		}

		eCode = BCCreate(pBC2D);
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}

		double lTotalCount = BCGetCountModules(pBC2D);
		
		nRow = (int)(BCGetCountRows(pBC2D));
		nCol = (int)(lTotalCount / nRow );

		eCode = BCSaveImage (pBC2D, strPath, eIMBmp, nCol * 20, nRow* 20, 600, 600);
		if(eCode != 0)
		{
//			ShowErrorMsg(eCode);
			return 0;
		}
	}

	CString strPath2;
	strPath2.Format(_T("%sTemp\\Ecc200Temp2.bmp"), gEasyDrillerINI.m_clsDirPath.GetRootDir());

	BCFree (pBC2D);

	imgdes SImage, DImage;
	BITMAPINFOHEADER bdat;
	int rrcode = 0;
	
	if((rrcode = bmpinfo(strPath, &bdat)) == NO_ERROR)
	{
		int bitcount = bdat.biBitCount;
		if((rrcode=resiz_imgbuf(&SImage, (int)bdat.biWidth, (int)bdat.biHeight, bitcount)) == NO_ERROR)
			loadbmp(strPath, &SImage);
	}
	
//	if(bReverse)
//		negative(&SImage, &SImage);	
	
	if((rrcode = resiz_imgbuf(&DImage, (int)SImage.bmh->biWidth,(int)SImage.bmh->biHeight, 8)) == NO_ERROR)
	{
		if (convert1bitto8bit(&SImage, &DImage) == NO_ERROR)
		{
			freeimage(&SImage);
			copyimgdes(&DImage, &SImage);
			//	flipimage(&DImage, &DImage);
			savebmp(strPath2, &DImage, 0);
			freeimage(&DImage);
		}
	}
	HANDLE fd = CreateFile(strPath2, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if(fd < 0)
		return 0;
	
	BITMAPFILEHEADER bmpHeader;
	DWORD size, len;
	
	if(!ReadFile(fd, (LPSTR)&bmpHeader, sizeof(bmpHeader), &len, NULL))
		return 0;
	
	size = bmpHeader.bfSize - sizeof(bmpHeader);
	
	LPSTR tDib = new char[size];
	
	if(!ReadFile(fd, tDib, size, &len, NULL))
		return 0;
	
	if(len != size)
		return 0;
	
	CloseHandle(fd);
	
	LPBITMAPINFO pBitmapInfo = (LPBITMAPINFO)tDib;
	
	LPSTR m_pDib = (tDib + *(LPDWORD)tDib + 256 * sizeof(RGBQUAD));
	
	int dx = pBitmapInfo->bmiHeader.biWidth;
	int dy = pBitmapInfo->bmiHeader.biHeight;
	
//	CStdioFile File;
	CString OutStr;
	
//	if (!File.Open(_T("C:\\MiME\\Data\\temp.plt"), CFile::modeCreate|CFile::modeWrite|CFile::typeText))
//	{
//		ErrMessage(_T("Unable To Open Image File!"));
//		return 0;
//	}
	
	unsigned char result1;
	int nX = 0;
	int nY = 0;
	
	BarcodeArray[0] = nCol;
	BarcodeArray[1] = nRow;
	BarArray = BarcodeArray + 2;
	
	for(int y = 0; y < nRow; y++)
	{
		for(int x = 0; x < nCol; x++)
		{
			nX = (int)(dx / nCol * x + dx/nCol/2);
			nY = (int)(dy / nRow * y + dy/nRow/2);
			
			result1 = m_pDib[dx * nY + nX];
			if(result1 == 0)
				BarArray[(nRow - y -1)*nCol +x] = 1;
			else
				BarArray[(nRow - y -1)*nCol +x] = 0;
		}
	}
	
	delete []tDib;
	tDib = NULL;
	m_pDib = NULL;
	
//	File.Close();
	
//yj	return (float)dy / (float)dx;;

	return TRUE;
}

int C2DBarCode::resiz_imgbuf(imgdes *image, int width, int length, int bppixel)
{
	int rcode;
	int DefImgBppixel = 8;
	
	
	// Release the current image buffer
	if (image->bmh != 0)
		freeimage(image);
		/* Try to allocate the new image buffer, but don't allow
		width < ImgWidth or length < ImgLength 
	*/
	if(width < 16)
		width = 16;
	if(length < 16)
		length = 16;
	if((rcode = allocimage(image, width, length, bppixel)) != NO_ERROR)
	/* Didn't get what we asked for, reallocate initial buffer and
	assume we get it
	*/
	allocimage(image, 512, 480, DefImgBppixel);
	return(rcode);
}

//##ModelId=3E410B23003E
int C2DBarCode::Make2DBarcode( unsigned char *SrcStr1, int *BarcodeArray )
{
	int i, j, TempNum, code, index, bit, z;

	// Encodtion Part

	strncpy_s( (char*)SrcStr, 100, (char*)SrcStr1, 100 );
	SrcLen = strlen( (char*)SrcStr );
	Sindex = Cindex = 0;
	CurrentMode = ASCII_ENCODE ;

	while( Sindex < SrcLen ) {
		if( CurrentMode == ASCII_ENCODE )    ASCIIEncode();
		if( CurrentMode == C40_ENCODE )      C40Encode();
		if( CurrentMode == TEXT_ENCODE )     TextEncode();
		if( CurrentMode == X12_ENCODE )      X12Encode();
		if( CurrentMode == EDIFACT_ENCODE )  EDIFACTEncode() ;
		//if( CurrentMode == BASE256_ENCODE )  BASE256Encode();
	}

	if( CurrentMode == BASE256_ENCODE ) {
		//set the length to 0
	}

	for( code = 0; code < 30; code++ ) {
		if( Cindex <= DATA_SYMBOLS[code] )
			break;
	}
	if( code == 30 ) {
		return(0) ;
	}

	// pad characters
	TempNum = DATA_SYMBOLS[code] - Cindex ;
	if( TempNum > 0 ) {
		CodeStr[Cindex++] = 129 ;
		while( DATA_SYMBOLS[code] - Cindex ) {
			CodeStr[Cindex] = State253( 129, Cindex+1 );
			Cindex++ ;
		}
	}
	CodeStr[Cindex] = NULL;

	// CalError Part
	for( i = 0; i < Cindex; i++ )
		datacode[i] = CodeStr[i] ;
	CalError(code);

	// Placement Part

	MakeECC200( NUM_ROWS[code]-2, NUM_COLS[code]-2 ) ;

	BarRow = nrow + 2;
	BarCol = ncol + 2;

	BarcodeArray[0] = BarRow ;
	BarcodeArray[1] = BarCol ;
	BarArray = BarcodeArray + 2;

	for( i = 0 ; i < nrow; i++ ) {
		for( j = 0; j < ncol; j++ ) {
			z = array[i*ncol+j] ;
			if (z == 0) BarArray[(i+1)*(ncol+2)+(j+1)] = 0;
			else if (z == 1) BarArray[(i+1)*(ncol+2)+(j+1)] = 1;
			else {
				index = z / 10 ;
				bit = z % 10 ;
				bit = 9 - bit;
				BarArray[(i+1)*(ncol+2)+(j+1)] = ((sym[index-1] & (0x01 << (bit-1)))? 1 : 0) ;
			}
		}
	}
	for( i = 0 ; i < nrow+2; i++ )
		BarArray[i*(ncol+2)] = 1 ;
	for( i = 0 ; i < ncol+2; i++ )
		BarArray[(nrow+1)*(ncol+2)+i] = 1 ;
	for( i = 1 ; i < nrow+2; i++ ) {
		if( i%2 )  BarArray[i*(ncol+2)+(ncol+1)] = 1;
		else  BarArray[i*(ncol+2)+(ncol+1)] = 0;
	}
	for( i = 1 ; i < ncol+2; i++ ) {
		if( i%2 )  BarArray[i] = 0;
		else  BarArray[i] = 1;
	}

	return(1);
}


