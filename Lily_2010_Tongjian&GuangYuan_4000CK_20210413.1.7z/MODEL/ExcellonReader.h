// ExcellonReader.h: interface for the ExcellonReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXCELLONREADER_H__A6275DFA_4C23_4190_BD6A_439029D1CED9__INCLUDED_)
#define AFX_EXCELLONREADER_H__A6275DFA_4C23_4190_BD6A_439029D1CED9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GlyphExcellon.h"
#include "DProject.h"
#include "..\EasyDriller.h"
#include "..\ui\DlgOpenExcellon.h"

class ExcellonReader  
{
public:
	CPoint GetExtendPoint(int nStartX, int nStartY, int nEndX, int nEndY, BOOL bStart, int nDist);
	CPoint GetNormalPointWithDistance(int nStartX, int nStartY, int nEndX, int nEndY,  BOOL bStart, int nDist);
	void RemoveNodataFiducial();
	BOOL m_bCorrectTool;
	BOOL m_bRepeatXFlip;
	BOOL m_bRepeatYFlip;
	BOOL m_bRepeatSwap;
	BOOL GetRepeatAxisInfo(TCHAR *szBuffer);
	LPDUNIT m_pUnit;
	void ReadCCode();
	BOOL Save(CString strPath, GlyphExcellon* pExcellon, DProject* pProject);
	void SaveTCode(CStdioFile& sFile, int nToolNo);
	void SaveTCCode(CStdioFile& sFile, int nTCode);
	void SaveFiducial(CStdioFile& sFile,int nFidKind);
	void SavePosition(CStdioFile& sFile);
	void SaveHoleData(CStdioFile& sFile);
	BOOL IsInHoleData(DAreaInfo* pAreaInfo, int nTool);
	void CollectHoleData(CStdioFile& sFile, DAreaInfo*, int nToolNo);
	void AddHoleList(int nRealTool, int nx, int ny);
//	BOOL GetXYPos(TCHAR *szBuffer, int &nParam1, int &nParam2, BOOL &bUse1, BOOL &bUse2);
	int GetXYPos(TCHAR *szBuffer, double &dParam1, double &dParam2, BOOL &bUse1, BOOL &bUse2);
//	BOOL GetParam(TCHAR* szBuffer, int &nParam1, int &nParam2, int &nParam3, int &nParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4);
	BOOL GetParam(TCHAR* szBuffer, double &dParam1, double &dParam2, double &dParam3, double &dParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4);
	BOOL HeaderSetting(TCHAR *szBuffer);

	void SetContensIndex(TCHAR *szBuffer);


	void ReadTCode();
	void InitData(short nTzs, int nInputUnit);
	BOOL IsNumber(TCHAR cNumber);
	BOOL GetValid(TCHAR character, TCHAR* szString);
	BOOL IsFiducialMarkExist(double dX, double dY);
	void ReadFiducial(int nFidKind);
	void ReadPosition();
	void ReadPosition_Old();
	void ReadLine();
	BOOL ReadDuplicatePos();
	BOOL ReadDuplicatePos_Old();
	void ReadMCode();
	void ReadMCode_Old();
	void SetMetric();
	void IsTzs(int nCount);
	BOOL	ExtractNums(TCHAR* szBuffer, TCHAR& chCode, double& dValue, BOOL bCheckValidity = TRUE );

	BOOL	m_bReadStart;
	byte	m_nNewTCode;
	byte	m_nNewMCode;
	int		m_nHoleSize;
	int		m_nStartX;
	int		m_nStartY;
	int		m_nPositionX;
	int		m_nPositionY;
	int		m_nPositionG93X;
	int		m_nPositionG93Y;

	int		m_nDupliMovX;
	int		m_nDupliMovY;
	int		m_nRRepeat;
	int		m_nRDupliMX;
	int		m_nRDupliMY;
	BOOL	m_bRandM2;
	double		m_dMetric;
	long	m_lTzsLzs;
	int		m_nLength;

	BOOL	m_bRepeat;
	BOOL	m_bIsSwap;
	BOOL	m_bStoreData;
	int		m_nMirrorX;
	int		m_nMirrorY;
	BOOL	m_bIsRead;
	BOOL	m_bSetFid;
	BOOL	m_bSetFid2;
	BOOL	m_bReadHole;
	BOOL	m_bRotate;
	BOOL	m_bHeaderEnd;
	BOOL	m_bHeaderStart;
	BOOL	m_bSaveRotate;
	BOOL	m_bm80m90;

	BOOL	m_nContensIndex;
	BOOL	m_bUseContensIndexFlag;
	CString m_strHoleContents;
	int		m_nArrayNo;
	BOOL	m_bOCR; //OCR Makring Code $
	int		m_nOCRType;

	CDlgOpenExcellon m_dlgExcellon;

	int		m_nMinX;
	int		m_nMinY;
	int		m_nMaxX;
	int		m_nMaxY;

	short	m_nLzs;
	int		m_nInputUnit;

	TCHAR	m_szData[BUFMAX];

	BOOL	m_bOverlapXY;
	int		m_nFidBlock;//20111123 bskim
	int     m_nFidCount_In_Block;
	BOOL	m_bToolChange;
	BOOL	m_bToolG93;
	BOOL	m_bFiducialDataLastRead;//20171010
	BOOL	m_bToolCodeDataLastRead;//20171010

	BOOL	m_nG821Count;
	BOOL	m_bFidTool;

	CPoint	m_ptSkivePos[30];
	int		m_nMultiSkiveCount;

	BOOL	m_bFirstTCode_NoCode;

	BOOL    m_bCheckHoleCount;
	int		m_nLineNo;
	int		m_nLineDistance;
	BOOL	m_bZigZag;
	int		m_nLineExtend;
	BOOL	m_bAbsoluteMode;
	BOOL	m_bDrillMode;
	double  m_dIncrementalFirstPosX;
	double  m_dIncrementalFirstPosY;
	CList <HOLEDATA, HOLEDATA>	m_listData;
	CList <LINEDATA, LINEDATA>	m_listLineData;

	CList <HOLEDATA, HOLEDATA>	m_RepeatlistData;
	CList <LINEDATA, LINEDATA>	m_RepeatlistLineData;
	
	HoleDataList	m_pCollectHoleList[MAX_TOOL_NO];
	int				m_nReadHoleCount[28];
	int				m_nRealToolNo[28];
    	int m_nBlockName;
		BOOL m_bLineBlock;
	int				m_nRefTCode;
	int			m_nApertureBlockNo;
	GlyphExcellon*	m_pGlyphExcell;
	DProject*		m_pDProject;

	void ReadNums(TCHAR* szBuffer);
	void ReadHoleData(TCHAR *szBuffer);
	int Read(CString strPath, short nLzs, int nInputUnit, GlyphExcellon* pExcellon, DProject* pProject, int nLineNo, int nLineDist, BOOL bZigZag, int nLineExtend, BOOL &bHeaderReadComplete, int m_nG821Count);
	int	 HeaderRead(CString strPath, GlyphExcellon* pExcellon, DProject* pProject, BOOL &bHeaderReadComplete, int &m_nG821Count);
	ExcellonReader();
	virtual ~ExcellonReader();

};

#endif // !defined(AFX_EXCELLONREADER_H__A6275DFA_4C23_4190_BD6A_439029D1CED9__INCLUDED_)
