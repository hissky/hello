// DSystemINI.h: interface for the DSystemINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSYSTEMINI_H__3AE1FC60_7941_4C7F_97C2_8BCE29D43844__INCLUDED_)
#define AFX_DSYSTEMINI_H__3AE1FC60_7941_4C7F_97C2_8BCE29D43844__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DSystemINI  
{
public:
	void InitValue();
	DSystemINI();
	virtual ~DSystemINI();

	SHARDWAREINFO		m_sHardWare;
	SSYSTEMDEVICE		m_sSystemDevice;
	SSYSTEMCOLLIMATOR	m_sSystemCollimator;
	SSYSTEMTOPHAT		m_sSystemTophat;
	SSYSTEMDUMP			m_sSystemDump;
	SAXISINFO			m_sAxisInfo[MOTOR_AXIS_MAX];
	SYSTEMCOMPONENT		m_sSystemComponent;
	SSYSTEMVACUUM		m_sSystemVacuum;
};

extern DSystemINI gSystemINI;

#endif // !defined(AFX_DSYSTEMINI_H__3AE1FC60_7941_4C7F_97C2_8BCE29D43844__INCLUDED_)
