#pragma once


#include "XMultiLang.h"

#define RESOURCE_PATH			GetThisPath() + _T("system\\resource.h")
#define LANG_KOREAN_PATH		GetThisPath() + _T("system\\korean.ini")
#define LANG_ENGLISH_PATH		GetThisPath() + _T("system\\english.ini")
#define LANG_VIETNAM_PATH		GetThisPath() + _T("system\\vietnam.ini")

extern XMultiLang				g_multilang;
#define LANG(x)					Lang(_T(#x), _T("TEXT"))
LPCTSTR Lang(LPCTSTR szLangKey, LPCTSTR szSection=_T("TEXT") );



CString  GetThisPath(HMODULE hModule=NULL);

