#include "stdafx.h"
#include "Global.h"


XMultiLang		g_multilang;


LPCTSTR Lang(LPCTSTR szLangKey, LPCTSTR szSection)
{
	return g_multilang.Lang(szLangKey, szSection);
}



CString  GetThisPath(HMODULE hModule)
{
	static TCHAR szModuleName[MAX_PATH*4];
	static BOOL bIsFirst = TRUE;
	if(bIsFirst)
	{
		::GetModuleFileName(hModule,szModuleName,MAX_PATH*4);
		*(_tcsrchr( szModuleName, '\\' ) + 1) = NULL;
		bIsFirst = FALSE;
	}
	return CString(szModuleName);
}
