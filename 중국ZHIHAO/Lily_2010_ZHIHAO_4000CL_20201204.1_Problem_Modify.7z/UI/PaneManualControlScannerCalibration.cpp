// PaneManualControlScannerCalibration.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlScannerCalibration.h"
#include "DlgCalResult.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\deasydrillerini.h"
#include "..\model\dprocessini.h"
#include "..\model\dsystemini.h"
#include "..\model\GlobalVariable.h"
#include "..\alarmmsg.h"
#include "..\ui\DlgMeasuringPCBThickness.h"
#include "..\Model\ToolCodeList.h"
#include "..\Model\DProject.h"
#include "..\Device\HLaser.h"
#include <math.h>
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DTempINI.h"
#include "..\device\HMotor.h"
#include "DlgTableView.h"
#include"..\MODEL\DTemperCompensation.h"
#include "PaneManualControl.h"
#include "PaneManualControlOneHole.h"
#include "PaneManualControlVision.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define COAXIAL 0
#define RING 1
#define IR 2

#define MAX_AUTOCAL_COUNT	400
#define SHOT_DISTANCE		0.3

volatile AUTOCALTHREADPARAM CPaneManualControlScannerCalibration::m_ThreadParam = {NULL, {INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE}};

//const double MAX_TABLE_SIZE	= 1000.0;

const int	CALIBRATION_AUTO	= 0;
const int	CALIBRATION_MANUAL	= 1;
const UINT	CALIBRATION_SLEEP	= 100;		// 100 ms
const UINT	WAIT_TIME			= 2000;

const int SEL_HEAD_BOTH		= 0;
const int SEL_HEAD_MASTER	= 1;
const int SEL_HEAD_SLAVE	= 2;

const UINT UM_START_THREAD_AGAIN	= WM_APP + 11;
const UINT UM_THREAD_FINISHED		= WM_APP + 12;
const UINT UM_AUTOCAL_FAILED		= WM_APP + 13;
const UINT UM_AUTOCAL_START			= WM_APP + 14;
const UINT UM_CHANGE_VISION_PARAM	= WM_APP + 15;
const UINT UM_VISION_FIND2			= WM_APP + 16;
const UINT UM_VISION_ROI_SET		= WM_APP + 17;
const UINT UM_VISION_FIND1			= WM_APP + 18;
const UINT UM_VISION_LAMP			= WM_APP + 19;
extern volatile HANDLE g_hDoScalManual;

int GetPointIndex(int nCountX, int nCountY, int nDivision, emHEAD emHead)
{
	if ((nCountX % 2) == 1)
		return (nCountX ) * nDivision + nCountY;
	else
		return nCountX * nDivision + nCountY;
}

BOOL ChangeBeamParam(AUTOCALTHREADPARAM* pAuto);
BOOL InPositionCheck();
/////////////////////////////////////////////////////////////////////////
// Auto Calibration Thread

bool FindShotForScannerTableCompen(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;
	double dOffsetX[9], dOffsetY[9], dSumX, dSumY;
	CString strResult, strPos, strData;
	BOOL bUseLowCam, bMaster, bRet = FALSE;
	int nKK;
	int nCam = pCalDlg->GetCAmNumInfo(bUseLowCam, emHead);
		
	int nRepeatTime = 1;
	if(bSave)
		nRepeatTime = 10;
		
	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	if (!gDeviceFactory.GetMotor()->MoveZ(dZ1, dZ2))	
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}
	if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_Z1 + IND_Z2))
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}

	FILE* fp = NULL, *fpTable = NULL;
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	if (NULL != fopen_s(&fp, strCalPath + "LaserOffset.txt", "w"))
		fp = NULL;

	if(emHead == emMaster)
	{
		if (NULL != fopen_s(&fpTable, strCalPath + "LaserM.Table", "w"))
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			if(fp) fclose(fp);
			if(fpTable) fclose(fpTable);
			return FALSE;
		}
	}
	else
	{
		if (NULL != fopen_s(&fpTable, strCalPath + "LaserS.Table", "w"))
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			if(fp) fclose(fp);
			if(fpTable) fclose(fpTable);
			return FALSE;
		}
	}

//	if(!pCalDlg->CreateTableCompenFile(fp, fpTable, emHead))
//		return true;

	if(fpTable) fprintf(fpTable, "%d\t%d\t%d\n", pCalDlg->m_nGridXNo, pCalDlg->m_nGridYNo, pCalDlg->m_nGridSize);

	for (int j = pCalDlg->m_nGridXNo - 1; j >= 0; j--)
	{
		for (int i = pCalDlg->m_nGridYNo - 1; i >= 0; i--)
		{
			for(int q = 0; q < 9; q++)
			{
				dOffsetX[q] = dOffsetY[q] = 10000;
			}
			dPosX = pCalDlg->GetCalStartX() - j * pCalDlg->m_nGridSize ;
			dPosY = pCalDlg->GetCalStartY() - i * pCalDlg->m_nGridSize ;
			for(int m = -1; m < 2; m++)
			{
				for(int n = -1; n < 2; n++)
				{
					pCalDlg->EnableCalibrationWindow(FALSE);
					if( m != n)
						continue;

					if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						if(fpTable) fclose(fpTable);
						return true;
					}

					pCalDlg->GetTableMovePosForTableCompen(dMoveX, dMoveY, j, i, m, n, emHead);
					if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1,dZ2, bMaster, !pCalDlg->m_bIsAutoProcessMode))	
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						if(fpTable) fclose(fpTable);
						return true;
					}
					
					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						if(fpTable) fclose(fpTable);
						return true;
					}
					::Sleep(50);

					pCalDlg->ChangeFindCamera(emHead);
					
					for(nKK = 0; nKK< nRepeatTime; nKK++)
					{
						bRet = pCalDlg->SendMessage(UM_VISION_FIND2, nCam, MODEL_CIRCLE);
						if(bRet)
							break;
						else if(!bRet && bSave)
						{
							if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
							{
								if(fp) fclose(fp);
								if(fpTable) fclose(fpTable);
								return true;
							}
						}
						::Sleep(50);
					}

					if (bRet) 
					{
						if(fp) fprintf(fp, "%lf\t%lf\t%lf\t%lf\n", dMoveX, dMoveY, pCalDlg->dpRealPos.x, pCalDlg->dpRealPos.y);
					}
					else
					{
						pCalDlg->dpRealPos.x = pCalDlg->dpRealPos.y = 10000;
						if(fp) fprintf(fp, "%lf\t%lf\t0.0000\t0.0000\n", dMoveX, dMoveY);
					}
//					for(int q = 0; q < 9; q++) // sort
					for(int q = 0; q < 3; q++) // sort
					{
//						if(dOffsetX[q] > pCalDlg->dpRealPos.x) 
//						{
//							for(int p = 7; p >= q; p--)
//								dOffsetX[p + 1] = dOffsetX[p];
							dOffsetX[q] = pCalDlg->dpRealPos.x;
//							break;
//						}
					}
//					for(int q = 0; q < 9; q++)
					for(int q = 0; q < 3; q++)
					{
//						if(dOffsetY[q] > pCalDlg->dpRealPos.y) 
//						{
//							for(int p = 7; p >= q; p--)
//								dOffsetY[p + 1] = dOffsetY[p];
							dOffsetY[q] = pCalDlg->dpRealPos.y;
//							break;
//						}
					}
					
					strResult.Format(_T("%s(%d)"), pCalDlg->myResultChar, nKK);
					pCalDlg->m_stcVisionResult.SetWindowText( strResult );
					
					strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
					if(emHead == emMaster)
						strData.Format(_T("1st %s %s"), strPos, strResult);
					else
						strData.Format(_T("2nd %s %s"), strPos, strResult);
						
					if(pCalDlg->m_lboxResult.GetCount() > 400) 
						pCalDlg->m_lboxResult.DeleteString(0);
					
					pCalDlg->m_lboxResult.AddString((LPCTSTR)strData);
					pCalDlg->m_lboxResult.SetCurSel(pCalDlg->m_lboxResult.GetCount() - 1);
				}
			}
			// sum
			dSumX = dSumY = 0;
//			for(int q = 2; q < 7; q++)
			for(int q = 0; q < 3; q++)
			{
				dSumX += dOffsetX[q];
				dSumY += dOffsetY[q];
			}
//			dSumX /= 5.;
//			dSumY /= 5.;
			dSumX /= 3.;
			dSumY /= 3.;
			if(fpTable) fprintf(fpTable, "%lf\t%lf\t%lf\t%lf\n", dPosX, dPosY, dSumX, dSumY);
		}
	}

	if(fp) fclose(fp);
	if(fpTable) fclose(fpTable);

	if(emHead == emMaster)
		pCalDlg->m_bOKMaster = TRUE;
	else
		pCalDlg->m_bOKSlave = TRUE;

	return false;
}

bool FindShotForScannerTableVerify(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;
	double dSumX, dSumY;
	CString strResult, strPos, strData;
	BOOL bUseLowCam, bMaster, bRet = FALSE;
	int nKK;
	int nCam = pCalDlg->GetCAmNumInfo(bUseLowCam, emHead);
	int nDivision = pCalDlg->GetDivision();	
	int nDivisionX = pCalDlg->m_nDivisionX;
	int nDivisionY = pCalDlg->m_nDivisionY;

	int nRepeatTime = 1;
	if(bSave)
		nRepeatTime = 10;
	
	int nVisionTryNo;

	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	if (!gDeviceFactory.GetMotor()->MoveZ(dZ1, dZ2))	
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}
	if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_Z1 + IND_Z2))
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}

	FILE* fp = NULL;
	CString strCalPath;
	CTime cTime = CTime::GetCurrentTime();
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strFileName;
	strFileName.Format(_T("LaserVerifyOffset_%s.txt"),cTime.Format(_T("%Y%m%d%H%M%S")));
	
	if (NULL != fopen_s(&fp, strCalPath + strFileName/*"LaserVerifyOffset.txt"*/, "w"))
		fp = NULL;

	if(fp) fprintf(fp, "%d\t%d\t%d\n", pCalDlg->m_nGridXNo, pCalDlg->m_nGridYNo, pCalDlg->m_nGridSize);

	for (int j = pCalDlg->m_nGridXNo - 1; j >= 0; j--)
	{
		for (int i = pCalDlg->m_nGridYNo - 1; i >= 0; i--)
		{
			dPosX = pCalDlg->GetCalStartX() - j * pCalDlg->m_nGridSize ;
			dPosY = pCalDlg->GetCalStartY() - i * pCalDlg->m_nGridSize ;
			for(int nCountY = 0, nCountX; nCountY < nDivisionY; nCountY++)
			{
				for (nCountX = 0; nCountX < nDivisionX; nCountX++)
				{
					pCalDlg->EnableCalibrationWindow(FALSE);
					//if( m != n)
					//	continue;
					if(!bSave && nCountX != 0)
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						return false;
					}
					if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						return true;
					}

					
					pCalDlg->GetTableMovePosForTableVerify(dMoveX, dMoveY,dPosX,dPosY, nCountX, nCountY, emHead);
						if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1 + pCalDlg->m_sProcessScannerCal.dVisionZOffset,
																			dZ2 + pCalDlg->m_sProcessScannerCal.dVisionZOffset, 
																			bMaster, !pCalDlg->m_bIsAutoProcessMode))	
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						return true;
					}
					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
					{
						pCalDlg->EnableCalibrationWindow(TRUE);
						if(fp) fclose(fp);
						return true;
					}

					//nVisionTryNo = pCalDlg->GetOffsetFromVisionData(nCountX, nCountY, emHead, pHandle, nCam, bSave, pdPos, pdOffset, pSuccess);
					//if(nVisionTryNo == FALSE)
					//{
					//	if(fp) fclose(fp);
					//	return true;
					//}

					pCalDlg->ChangeFindCamera(emHead);
					
					for(nKK = 0; nKK< nRepeatTime; nKK++)
					{
						bRet = pCalDlg->SendMessage(UM_VISION_FIND2, nCam, MODEL_CIRCLE);
						if(bRet)
							break;
						else if(!bRet && bSave)
						{
							if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
							{
								if(fp) fclose(fp);
								return true;
							}
						}
						::Sleep(50);
					}

					if (bRet) 
					{
						if(fp) fprintf(fp, "%lf\t%lf\t%lf\t%lf\n", dMoveX, dMoveY, pCalDlg->dpRealPos.x, pCalDlg->dpRealPos.y);
					}
					else
					{
						pCalDlg->dpRealPos.x = pCalDlg->dpRealPos.y = 10000;
						if(fp) fprintf(fp, "%lf\t%lf\t0.0000\t0.0000\n", dMoveX, dMoveY);
					}

					strResult.Format(_T("%s(%d)"), pCalDlg->myResultChar, nKK);
					pCalDlg->m_stcVisionResult.SetWindowText( strResult );

					strPos.Format(_T("[%.3f, %.3f]"), dMoveX, dMoveY);
					if(emHead == emMaster)
						strData.Format(_T("1st %s %s"), strPos, strResult);
					else
						strData.Format(_T("2nd %s %s"), strPos, strResult);
						
					if(pCalDlg->m_lboxResult.GetCount() > 400) 
						pCalDlg->m_lboxResult.DeleteString(0);
					
					pCalDlg->m_lboxResult.AddString((LPCTSTR)strData);
					pCalDlg->m_lboxResult.SetCurSel(pCalDlg->m_lboxResult.GetCount() - 1);

				}
			}
		}
	}
	if(fp) fclose(fp);

	if(emHead == emMaster)
		pCalDlg->m_bOKMaster = TRUE;
	else
		pCalDlg->m_bOKSlave = TRUE;

	return false;
}



bool GetHeadOffset(AUTOCALTHREADPARAM* pAuto, emHEAD em1st, emHEAD em2nd)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	HVision* pVision = gDeviceFactory.GetVision();

	int nRepeatTime = 1;
	BOOL bRet;
	double dMoveY, dMoveX;
	
	if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		return true;
	
	while(pCalDlg->m_bAutoPause)
	{
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
			return true;
		
		::Sleep(1);
	}
	BOOL bFindM = FALSE, bFindS = FALSE;
	CDPoint dIndexP, dFindOffsetM, dFindOffsetS;
	double dFindPosMX, dFindPosMY, dFindPosSX, dFindPosSY;
	double dReTryOffX, dReTryOffY, dStepX, dStepY, dModelX, dModelY;
	double dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	dModelX = dModelY = pCalDlg->m_sProcessScannerCal.dModelSize;
	
	dReTryOffX = max((dHighFOVX - dModelX)/2 - 0.03, 0.1); // 0.1 ����
	dReTryOffY = max((dHighFOVY - dModelY)/2 - 0.03, 0.1); // 0.1 ����
	
	dStepX = dHighFOVX - dModelX - 0.03;
	dStepY = dHighFOVY - dModelY - 0.03;

	int nMove = max(1, (int)ceil((3 - dHighFOVX)/(2 * dStepX)));
	dStepX = min(dStepX, (3 - dHighFOVX) / (2 * nMove));
	dStepY = min(dStepY, (3 - dHighFOVY) / (2 * nMove));
	nRepeatTime = (nMove * 2 + 1) * (nMove * 2 + 1);
	
	//low -> high  
	double dCalThick = pCalDlg->GetCalThick();
	double dCalThick2nd = pCalDlg->GetCalThick2nd();
	
	double dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
	double dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	int nCam;

	if(em1st == emMaster && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		dMoveY = pCalDlg->m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dMoveX = pCalDlg->m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, TRUE, !pCalDlg->m_bIsAutoProcessMode))	
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			return true;
		}
		
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			return true;
		}
		
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			return true;
		}

		nCam = LOW_1ST_CAM; 
		pCalDlg->CameraChange(nCam);
		pCalDlg->SendMessage(UM_CHANGE_VISION_PARAM, nCam);
		
		bRet = pCalDlg->SendMessage(UM_VISION_FIND1, nCam, MODEL_CIRCLE);
		Sleep(10);
		if(bRet)
		{
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dFindPosMX, TRUE); // low vision pos 
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dFindPosMY, TRUE);
			dFindOffsetM.x = pCalDlg->dpRealPos.x; 
			dFindOffsetM.y = pCalDlg->dpRealPos.y;
			bFindM = TRUE;
			
		}
	}
	
	if(em2nd == emSlave && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		dMoveY = pCalDlg->m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		dMoveX = pCalDlg->m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, FALSE, !pCalDlg->m_bIsAutoProcessMode))	
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			return true;
		}
		
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			pCalDlg->EnableCalibrationWindow(TRUE);
			return true;
		}
		
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			return true;
		}

		nCam = LOW_2ND_CAM; 
		pCalDlg->CameraChange(nCam);
		pCalDlg->SendMessage(UM_CHANGE_VISION_PARAM, nCam);
		
		bRet = pCalDlg->SendMessage(UM_VISION_FIND1, nCam, MODEL_CIRCLE);
		
		if(bRet)
		{
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dFindPosSX, FALSE);
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dFindPosSY, FALSE);
			dFindOffsetS.x = pCalDlg->dpRealPos.x; 
			dFindOffsetS.y = pCalDlg->dpRealPos.y;
			bFindS = TRUE;
		}
	}
		
	if(em1st == emMaster && !bFindM)
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}
	if(em2nd == emSlave && !bFindS)
	{
		pCalDlg->EnableCalibrationWindow(TRUE);
		return true;
	}
	int nKK;
	dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
	dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	//set roi 
	pCalDlg->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, 0);
	pCalDlg->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, 2);
	pCalDlg->SendMessage(UM_VISION_LAMP, 0, pCalDlg->m_sProcessScannerCal.nUseTool);
	pCalDlg->SendMessage(UM_VISION_LAMP, 2, pCalDlg->m_sProcessScannerCal.nUseTool);

	if(em1st == emMaster)
	{
		if(bFindM)
		{
			nCam = HIGH_1ST_CAM; 
			pCalDlg->CameraChange(nCam);
			pCalDlg->SendMessage(UM_CHANGE_VISION_PARAM, nCam);
			
			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				{
					return true;
				}

				dIndexP = pCalDlg->GetNextStepIndex(nKK);

				dMoveY = pCalDlg->m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - (dIndexP.y * dStepY) ;
				dMoveX = pCalDlg->m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - (dIndexP.x * dStepX) ;
				
				if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, TRUE, !pCalDlg->m_bIsAutoProcessMode))	
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
				
				bRet = pCalDlg->SendMessage(UM_VISION_FIND1, nCam, MODEL_CIRCLE);
				
				if(bRet)
				{
					if(dReTryOffX > fabs(pCalDlg->dpRealPos.x ) && dReTryOffY > fabs(pCalDlg->dpRealPos.y ))
					{
						pCalDlg->m_dOffsetM.x = pCalDlg->dpRealPos.x - dFindOffsetM.x;
						pCalDlg->m_dOffsetM.y = pCalDlg->dpRealPos.y - dFindOffsetM.y;
						break;
					}
				}
			}

			if(!bRet)
				return true;
		}
		else
			return true;
	}
	
	if(em2nd == emSlave)
	{
		if(bFindS)
		{
			nCam = HIGH_2ND_CAM; 
			pCalDlg->CameraChange(nCam);
			pCalDlg->SendMessage(UM_CHANGE_VISION_PARAM, nCam);
			
			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				{
					return true;
				}

				dIndexP = pCalDlg->GetNextStepIndex(nKK);
				dMoveY = pCalDlg->m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - (dIndexP.y * dStepY) ;
				dMoveX = pCalDlg->m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - (dIndexP.x * dStepX) ;
				
				if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, FALSE, !pCalDlg->m_bIsAutoProcessMode))	
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
				
				bRet = pCalDlg->SendMessage(UM_VISION_FIND1, nCam, MODEL_CIRCLE);
				
				if(bRet)
				{
					if(dReTryOffX > fabs(pCalDlg->dpRealPos.x ) && dReTryOffY > fabs(pCalDlg->dpRealPos.y ))
					{
						pCalDlg->m_dOffsetS.x = pCalDlg->dpRealPos.x - dFindOffsetS.x;
						pCalDlg->m_dOffsetS.y = pCalDlg->dpRealPos.y - dFindOffsetS.y;
						break;
					}
				}
			}
			if(!bRet)
				return true;
		}
		else
			return true;
	}
	return false;
}
bool FindShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, bool bSave, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	double dStartPosX = pCalDlg->GetCalStartX();
	double dStartPosY = pCalDlg->GetCalStartY();
	int nDivision = pCalDlg->GetDivision();
	double dMoveX, dMoveY;
	double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	double dHalfFieldSize = dFieldSize / 2.0;
	BOOL bUseLowCam;
	pCalDlg->GetCAmNumInfo(bUseLowCam, emNone);

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			if(!bSave && nCountX != 0)
				return false;

			if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				return true;
			while(pCalDlg->m_bAutoPause)
			{
				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					return true;
				::Sleep(1);
			}

			if(bUseLowCam)
			{
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}
			else
			{
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}
			if ((nCountY % 2) == 1)
				dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));

			if(em1st == emMaster)
			{
				if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1 + pCalDlg->m_sProcessScannerCal.dVisionZOffset,
					dZ2 + pCalDlg->m_sProcessScannerCal.dVisionZOffset, 
					TRUE, !pCalDlg->m_bIsAutoProcessMode))	
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
			}
			else
			{
				if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1 + pCalDlg->m_sProcessScannerCal.dVisionZOffset,
					dZ2 + pCalDlg->m_sProcessScannerCal.dVisionZOffset, 
					FALSE, !pCalDlg->m_bIsAutoProcessMode))	
				{
					pCalDlg->EnableCalibrationWindow(TRUE);
					return true;
				}
			}
			if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				pCalDlg->EnableCalibrationWindow(TRUE);
				return true;
			}

			if(!pCalDlg->GetOffsetFromVisionData(dMoveX, dMoveY, nCountX, nCountY, pHandle, bUseLowCam, em1st, em2nd, bSave, pdPos1, pdOffset1, pSuccess1, pdPos2, pdOffset2, pSuccess2))
				return true;
		}
	}
	return false;
}
bool FindShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	//Ž������
	// 1 2 3
	// 6 5 4
	// 7 8 9
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	CString strResult, strPos, strData;
	int nDivision = pCalDlg->GetDivision();
	double dMoveX, dMoveY;
	BOOL bUseLowCam, bMaster;
	int nVisionTryNo;
	int nCam = pCalDlg->GetCAmNumInfo(bUseLowCam, emHead);

	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	pCalDlg->ChangeFindCamera(emHead);

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			if(!bSave && nCountX != 0)
				return false;
			
			if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				return true;
			while(pCalDlg->m_bAutoPause)
			{
				::Sleep(1);
			}

			pCalDlg->GetTableMovePosForSCal(dMoveX, dMoveY, nCountX, nCountY, emHead);
			
			// 110620
			if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
			{
				gVariable.m_sGlobal.bCalFalse = TRUE;
				return false;
			}

			if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1 + pCalDlg->m_sProcessScannerCal.dVisionZOffset,
																	dZ2 + pCalDlg->m_sProcessScannerCal.dVisionZOffset, 
																	bMaster, !pCalDlg->m_bIsAutoProcessMode))	
			{
				pCalDlg->EnableCalibrationWindow(TRUE);
				return true;
			}
			if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				pCalDlg->EnableCalibrationWindow(TRUE);
				return true;
			}

			nVisionTryNo = pCalDlg->GetOffsetFromVisionData(nCountX, nCountY, emHead, pHandle, nCam, bSave, pdPos, pdOffset, pSuccess);
			if(nVisionTryNo == FALSE)
				return true;
			
			strResult.Format(_T("%s(%d)"), pCalDlg->myResultChar, nVisionTryNo);
			pCalDlg->m_stcVisionResult.SetWindowText( strResult );

			strPos.Format(_T("[%.3f, %.3f]"), dMoveX, dMoveY);

			switch( nCam )
			{
			case HIGH_1ST_CAM :
			case LOW_1ST_CAM :
				strData.Format(_T("1st %s %s"), strPos, strResult);
				break;
			case HIGH_2ND_CAM :
			case LOW_2ND_CAM :
				strData.Format(_T("2nd %s %s"), strPos, strResult);
				break;
			}
			
			if(pCalDlg->m_lboxResult.GetCount() > 400) 
				pCalDlg->m_lboxResult.DeleteString(0);

			pCalDlg->m_lboxResult.AddString((LPCTSTR)strData);
			pCalDlg->m_lboxResult.SetCurSel(pCalDlg->m_lboxResult.GetCount() - 1);
		}
	}
	return false;
}
bool FindPreviousShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd)
{
	return FindShot(pAuto, dZ1, dZ2, em1st, em2nd, false, NULL, NULL, NULL, NULL, NULL, NULL);
}

bool FindPreviousShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead)
{
	return FindShot(pAuto, dZ1, dZ2, emHead, false, NULL, NULL);
}

bool FindCurrentShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	return FindShot(pAuto, dZ1, dZ2, em1st, em2nd, true, pdPos1, pdOffset1, pSuccess1, pdPos2, pdOffset2, pSuccess2);
}
bool FindCurrentShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	if(pCalDlg->m_nGridMode == 3)
		return FindShotForScannerTableCompen(pAuto, dZ1, dZ2, emHead, true, pdPos, pdOffset, pSuccess);
	else if(pCalDlg->m_nGridMode == 5)
		return FindShotForScannerTableVerify(pAuto, dZ1, dZ2, emHead, true, pdPos, pdOffset, pSuccess);
	else
		return FindShot(pAuto, dZ1, dZ2, emHead, true, pdPos, pdOffset, pSuccess);
}

BOOL InPositionCheck()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2); 
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3 + IND_A1 + IND_A2);
	}
	else // not use M, C
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
 			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2);// ���� 
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3 +IND_A1 + IND_A2);
	}
	return TRUE;
}

BOOL ChangeBeamParam(AUTOCALTHREADPARAM* pAuto)
{
	SUBTOOLDATA subTool;
 	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEocard = gDeviceFactory.GetEocard();
	HLaser* pLaser = gDeviceFactory.GetLaser();
	
	double dC1, dC2, dA1, dA2, dM1, dM2, dM3; 
	double dVoltage1, dVoltage2;
	double dCalThick = pCalDlg->GetCalThick();
	double dCalThick2nd = pCalDlg->GetCalThick2nd();
	BOOL bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[pCalDlg->m_sProcessScannerCal.nUseTool];

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		if(!pCalDlg->m_bDryRunCheck)
			ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}
	BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[pCalDlg->m_sProcessScannerCal.nUseTool];
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return FALSE;
	}

	double dLaserHeight1, dLaserHeight2;

	dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[pCalDlg->m_sProcessScannerCal.nUseTool];
	dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[pCalDlg->m_sProcessScannerCal.nUseTool];
	dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[pCalDlg->m_sProcessScannerCal.nUseTool];
	dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[pCalDlg->m_sProcessScannerCal.nUseTool];
	
	dLaserHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[pCalDlg->m_sProcessScannerCal.nUseTool];
	dLaserHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[pCalDlg->m_sProcessScannerCal.nUseTool];
	dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[pCalDlg->m_sProcessScannerCal.nUseTool];

#ifdef __PUSAN_OLD_17__
	if(bTophat)
		dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[pCalDlg->m_sProcessScannerCal.nUseTool];
	else
		dM2 = gBeamPathINI.m_sBeampath.nFixedMask;
#else
	dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[pCalDlg->m_sProcessScannerCal.nUseTool];
#endif

	dM3 =  gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[pCalDlg->m_sProcessScannerCal.nUseTool];

	dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[pCalDlg->m_sProcessScannerCal.nUseTool];
	dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[pCalDlg->m_sProcessScannerCal.nUseTool];

	// Mask�� Z�� �̵�
	double dHeight1 = dLaserHeight1 - dCalThick;
	double dHeight2 = dLaserHeight2 - dCalThick2nd; 
#ifndef __SERVO_MOTOR__
	if(!pMotor->MoveZMCA2(dHeight1, dHeight2, dM1,
		dM2, dC1, dC2, dA1, dA2, TRUE, bTophat))
#else
	if(!pMotor->MoveZMCA3(dHeight1, dHeight2, dM1,
		dM2, dM3, dC1, dC2, dA1, dA2,
		TRUE, bTophat))
#endif
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "Z,M,C");
		if(!pCalDlg->m_bDryRunCheck)
			ErrMessage(strMsg);
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		return FALSE;
	}
	
	pCalDlg->GetLaserParam(subTool);
	// subTool download
//	if(!pEocard->SetVoltage(dVoltage1, dVoltage2))
//	{
//#ifndef __MP920_MOTOR__
//		pMotor->SetOutPort(PORT_ALARM, 1);
//#else
//		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
//#endif
//		CString strString, strMsg;
//		strString.LoadString(IDS_ERR_DOWNLOAD);
//		strMsg.Format(strString, "Scanner Voltage");
//		if(!pCalDlg->m_bDryRunCheck)
//		{
//			ErrMsgDlg(STDGNALM117);
//		}
//		::Sleep(500);
//#ifndef __MP920_MOTOR__
//		pMotor->SetOutPort(PORT_ALARM, 0);
//#else
//		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
//#endif
//		return FALSE;
//	}
	if(!pEocard->DownloadOneSubTool(SCANNER_CAL_TOOL, subTool))
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner parameter");
		if(!pCalDlg->m_bDryRunCheck)
			ErrMessage(strMsg);
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		return FALSE;
	}
	if(!pEocard->DownloadShotDrillScannerParam(subTool.nJumpDelay))// / subTool.nDrawStepPeriod))
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner move profile parameter");
		if(!pCalDlg->m_bDryRunCheck)
			ErrMessage(strMsg);
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		return FALSE;
	}
	// Laser Current Set
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(!pLaser->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack))
		{
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
			if(!pCalDlg->m_bDryRunCheck)
				ErrMessage(_T("Current Set Error"));
			::Sleep(500);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 0);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		if(!pLaser->SetCurrent(subTool.dCurrent))
		{
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
			if(!pCalDlg->m_bDryRunCheck)
				ErrMessage(_T("Current Set Error"));
			::Sleep(500);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 0);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
			return FALSE;
		}
	}
	// M, C, Z Inposition
	//Inposition check
	if(!InPositionCheck())
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		if(!pCalDlg->m_bDryRunCheck)
			ErrMessage(_T("Inposition Error"));
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nMaskInposWait)
		::Sleep(gSystemINI.m_sSystemDevice.nMaskInposWait);

	return TRUE;
}

bool FireCalibrationHole(AUTOCALTHREADPARAM* pAuto, int nSelectHead, double dXTablePos, double dYTablePos, bool bFire, bool bGetOffset)
{
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

	HEocard* pEoCard = gDeviceFactory.GetEocard();

	CCalibrationPath* pMasterPath = pCalDlg->GetMasterPath();
	CCalibrationPath* pSlavePath = pCalDlg->GetSlavePath();
	
	int nDivision = pCalDlg->GetDivision();

	int nMaxIndex = nDivision * nDivision;

	if(pCalDlg->m_nGridMode == 5)
	{
		nMaxIndex = pCalDlg->m_nDivisionX * pCalDlg->m_nDivisionY;
	}
	unsigned short usLaserPosMX = 32767, usLaserPosMY = 32767, usLaserPosSX = 32767, usLaserPosSY = 32767;

	if(bGetOffset)
		nMaxIndex = 1; //�ѹ游 ���� 
	else
	{
		pMasterPath->SetCalibrationGridSize(nDivision);
		pSlavePath->SetCalibrationGridSize(nDivision);
		pMasterPath->SetCalibrationGridIndex(usLaserPosMX, usLaserPosMY);
		pSlavePath->SetCalibrationGridIndex(usLaserPosSX, usLaserPosSY);
	}

	int nX, nY, nAction, nCount;
	int nXYORDER;

	int nUseTool = pCalDlg->GetUseTool();
	BOOL bFind = FALSE;

	SUBTOOLDATA ToolData;
	ToolData.nToolType = SHOT_DRILL_TYPE;

	if(!ChangeBeamParam(pAuto))
		return true;

	pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);

	if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		return true;
		
	if(ToolData.nToolType == SHOT_DRILL_TYPE)
		pEoCard->ShotDataReset();
		
	//pEoCard->SetApplyCalibrationFile(0,FALSE);
	//pEoCard->SetApplyCalibrationFile(1,FALSE);
	if(pCalDlg->m_nGridMode == 0)
	{
		for (int nIndex = 0; nIndex < nMaxIndex; nIndex++)
		{
			// yhchung 060802 Grid XY Order
			nXYORDER = gProcessINI.m_sProcessCal.nXYOrder;
			if(!bGetOffset)
			{
				pMasterPath->GetNextLSBXYORDER(usLaserPosMX, usLaserPosMY, nDivision, nIndex, nXYORDER);
				pSlavePath->GetNextLSBXYORDER(usLaserPosSX, usLaserPosSY, nDivision, nIndex, nXYORDER);
			}
			else
			{
				usLaserPosMX = usLaserPosSX = usLaserPosMY = usLaserPosSY = 32767;
			}

			TRACE("[%2d] (%d, %d)\n",nIndex, usLaserPosMX, usLaserPosMY);
				
			if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				return true;
				
			// Choi - DLPortIoEOCard - Start
			if(ToolData.nToolType == SHOT_DRILL_TYPE)
			{
				if(nSelectHead == SEL_HEAD_MASTER)
				{
					pEoCard->DownloadShotData2(usLaserPosMX, usLaserPosMY, HALF_LSB, HALF_LSB,
												TRUE, FALSE, SCANNER_CAL_TOOL);
				}
				else if(nSelectHead == SEL_HEAD_SLAVE)
				{
					pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, usLaserPosSX, usLaserPosSY,
												FALSE, TRUE, SCANNER_CAL_TOOL);
				}
			}
			else
			{
				nCount = 0;
				while(pEoCard->GetAperturePos(nCount, nX, nY, nAction))
				{
					nCount++;
//						if(nSelectHead == SEL_HEAD_MASTER)
//							pEoCard->DrillMove(nAction, usLaserPosMX + nX, usLaserPosMY + nY, TRUE);
//						else if(nSelectHead == SEL_HEAD_SLAVE)
//							pEoCard->DrillMove(nAction,HALF_LSB, HALF_LSB, FALSE, 
//												usLaserPosMX + nX, usLaserPosMY + nY, TRUE);
				}
			}
		}
	}
	else if(pCalDlg->m_nGridMode == 5)
	{
		int nMaxLSB = (int)(MAXLSB * pCalDlg->m_dFieldSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
		int nStartLSBX, nStartLSBY, nStepX, nStepY;
		int nX, nY;
		LPHOLEDATA pHoleData;

		if(pCalDlg->m_nDivisionX == 1)
			nStepX = nMaxLSB;
		else
			nStepX = nMaxLSB / (pCalDlg->m_nDivisionX - 1);

		if(pCalDlg->m_nDivisionY == 1)
			nStepY = nMaxLSB;
		else
			nStepY = nMaxLSB / (pCalDlg->m_nDivisionY - 1);

		nStartLSBX = (int)(32767 - (pCalDlg->m_nDivisionX/2.0 - 0.5)*nStepX);
		nStartLSBY = (int)(32767 - (pCalDlg->m_nDivisionY/2.0 - 0.5)*nStepY);

		for(int i = 0; i < pCalDlg->m_nDivisionX; i++)
		{
			for(int j = 0; j < pCalDlg->m_nDivisionY; j++)
			{		
				nX = nStartLSBX + i * nStepX;
				if(nX > MAXLSB) nX = MAXLSB;
				if(nX < 0)		nX = 0;
				nY = nStartLSBY + j * nStepY;
				if(nY > MAXLSB) nY = MAXLSB;
				if(nY < 0)		nY = 0;

				if(nSelectHead == SEL_HEAD_MASTER) // Master
				{
					pEoCard->DownloadShotData2(nX , nY , HALF_LSB, HALF_LSB, TRUE, FALSE,	ONE_HOLE_TOOL);
				}
				else if(nSelectHead == SEL_HEAD_SLAVE) // Slave
				{
					pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, nX , nY , FALSE, TRUE, ONE_HOLE_TOOL);
				}
				TRACE(_T("%d, %d \n"), nX, nY);
			}
		}

	}
	else // pCalDlg->m_nGridMode == 3  head offset fire
	{
		double dOffsetX = 0, dOffsetY = 0;
		int nTempVal;
//		pEoCard->GetLaserOffset(dXTablePos, dYTablePos, dOffsetX, dOffsetY, nSelectHead);
		for(int i = -1; i < 2; i++)
		{
			for(int j = -1; j < 2; j++)
			{
				if(nSelectHead == SEL_HEAD_MASTER)
				{
					nTempVal = (int)(32767 + (i * SHOT_DISTANCE - dOffsetX) * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x);
					usLaserPosMX = nTempVal;
					nTempVal = (int)(32767 + (j * SHOT_DISTANCE - dOffsetY) * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x);
					usLaserPosMY = nTempVal;
					pEoCard->DownloadShotData2(usLaserPosMX, usLaserPosMY, HALF_LSB, HALF_LSB, TRUE, FALSE, SCANNER_CAL_TOOL);
				}
				else if(nSelectHead == SEL_HEAD_SLAVE)
				{
					nTempVal = (int)(32767 + (i * SHOT_DISTANCE - dOffsetX) * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x);
					usLaserPosSX = nTempVal;
					nTempVal = (int)(32767 + (j * SHOT_DISTANCE - dOffsetY) * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x);
					usLaserPosSY = nTempVal;
					pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, usLaserPosSX, usLaserPosSY, FALSE,TRUE, SCANNER_CAL_TOOL);
				}
			}
		}
	}
		
	if(!pCalDlg->DrillStartCmd(ToolData))
		return true;

	if(!pCalDlg->WaitOneFireProcess(pHandle))
		return true;

#ifndef __TEST__
	if(pCalDlg->m_nGridMode == 0)
	{
		if( (pEoCard->ReadHoleCount() != nMaxIndex) &&
			(ToolData.nToolType == SHOT_DRILL_TYPE) )
		{
#ifndef __MP920_MOTOR__
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
#else
			gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
			if(!pCalDlg->m_bDryRunCheck)
				ErrMessage(_T("shot count error"));
			::Sleep(500);
#ifndef __MP920_MOTOR__
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
#else
			gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		}
	}
#endif

	//pEoCard->SetApplyCalibrationFile(0,TRUE);
	//pEoCard->SetApplyCalibrationFile(1,TRUE);

	return false;
}

void StopProcess(AUTOCALTHREADPARAM* pAuto, BOOL bDecreaseCount = FALSE, BOOL bStopParticleBlow = FALSE)
{
#ifdef __3RDAOD__
	if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
			ErrMsgDlg(STDGNALM781);
		}
	}
#endif
	gVariable.m_sGlobal.bCalFalse = TRUE;
	
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	
	pCalDlg->m_cmbUseVision.SetCurSel(pCalDlg->m_nStartCam);

	::SetEvent(pHandle[2]);

	pCalDlg->m_bDryRunCheck = FALSE;
	pCalDlg->WriteCalibrationStopEvent();
	pDlg->ShutterMove(FALSE, FALSE); // 20090629 Front Mode error
	
	pCalDlg->EnableCalibrationWindow(TRUE);

	if(pCalDlg->m_bIsAutoProcessMode)
	{
		gVariable.m_sGlobal.bCalFalse = TRUE;
		pCalDlg->m_bAutoCalStop = TRUE;
		
		if(bDecreaseCount)
			pCalDlg->m_nCountAuto--;
	}

	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
	gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			if(!pCalDlg->m_bDryRunCheck)
				ErrMessage(_T("Dust Suction Shutter Off Error."));
		}
	}
	gProcessINI.m_sProcessScannerCal.nCountAuto = pCalDlg->m_nCountAuto;
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);
	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);

	::SetEvent(g_hDoScalManual);
}

UINT CheckAcrylic(LPVOID pParam)
{
	AUTOCALTHREADPARAM* pAuto = static_cast<AUTOCALTHREADPARAM*>(pParam);
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;
	
	if(pCalDlg->m_chkSkipCheckBoard.GetCheck() || !pCalDlg->m_bIsAutoProcessMode)
		return true;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dStartPrefindZ1, dStartPrefindZ2 = 0.;
	BOOL bUseLowCam, bFindFast = FALSE;
	pCalDlg->GetCAmNumInfo(bUseLowCam, emNone);
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	int nMax = max(1, gProcessINI.m_sProcessCal.nAutoCalibrationCount);
	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(pCalDlg->GetSelectedHead() != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (pCalDlg->GetSelectedHead() != SEL_HEAD_MASTER)
		n2ndUse = emSlave;

	if(::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
	{
		StopProcess(pAuto, TRUE);
		return 0;
	}
	
	if(bUseLowCam)
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - pCalDlg->GetCalThick();
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - pCalDlg->GetCalThick2nd();
	}
	else
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - pCalDlg->GetCalThick();
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - pCalDlg->GetCalThick2nd();
	}
	///////////////////////////////////////////////
	for(int l = 0; l < nMax; l++)
	{
		BOOL bPreFound = FALSE;
		if(bFindFast)
		{
			bPreFound = FindPreviousShot(pAuto, dStartPrefindZ1, dStartPrefindZ2, n1stUse, n2ndUse);
		}
		else
		{
			if(n1stUse == emMaster)
				bPreFound = FindPreviousShot(pAuto, dStartPrefindZ1, dStartPrefindZ2, n1stUse);
			if(!bPreFound && n2ndUse == emSlave)
				bPreFound = FindPreviousShot(pAuto, dStartPrefindZ1, dStartPrefindZ2, n2ndUse);
		}

		if(bPreFound && !gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard)
		{
			// change by lark for auto mode cal
			if(pCalDlg->m_bRestart)
			{
				if(nMax == l + 1)
				{
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
					if(!pCalDlg->m_bDryRunCheck)
						ErrMessage(IDS_SCAL_HOLE_PREV);
					StopProcess(pAuto, FALSE);
					gVariable.m_sGlobal.bCalFalse = TRUE;
					::Sleep(500);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
					return 0;
				}
				pCalDlg->CalculateAutoStartPosition();
				pCalDlg->m_nCountAuto++;
						
				if (!pCalDlg->CheckMotorPositionValidity())
				{
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1 );
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
					if(!pCalDlg->m_bDryRunCheck)
						ErrMessage(IDS_SCAL_POSITION);
					pCalDlg->m_nCountAuto--;
					StopProcess(pAuto, FALSE);
					gVariable.m_sGlobal.bCalFalse = TRUE;
					::Sleep(500);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
					return 0;
				}
				continue;
			}
					
			if(pCalDlg->GetAutoProcessMode() && !pCalDlg->m_bAutoCalStop)
			{
				StopProcess(pAuto, FALSE);
				gVariable.m_sGlobal.bCalFalse = TRUE;
			}
			else
			{
				StopProcess(pAuto, FALSE);
			}
			return 0;
		}
		break;
	}
	return true;
}

UINT FireAcrylic(LPVOID pParam)
{
	AUTOCALTHREADPARAM* pAuto = static_cast<AUTOCALTHREADPARAM*>(pParam);
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bUseLowCam, bFindFast = FALSE;
	pCalDlg->GetCAmNumInfo(bUseLowCam, emNone);
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;
	double dStartPosX = pCalDlg->GetCalStartX();
	double dStartPosY = pCalDlg->GetCalStartY();

	if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
	{
		StopProcess(pAuto, FALSE);
		gVariable.m_sGlobal.bCalFalse = TRUE;
		return 0;
	}

	double dFirePosOffsetX = 0, dFirePosOffsetY = 0;
	int nXGrid = 1, nYGrid = 1;
	if(pCalDlg->m_nGridMode == 3 || pCalDlg->m_nGridMode == 5) // 
	{
		nXGrid = pCalDlg->m_nGridXNo;
		nYGrid = pCalDlg->m_nGridYNo;
	}

	for(int nPanelNo = 0; nPanelNo < 2; nPanelNo++) // 0 = master fire, 0 = slave fire
	{
		if(nPanelNo == 0 && pCalDlg->GetSelectedHead() == SEL_HEAD_SLAVE) // master fire skip
			continue;
		if(nPanelNo == 1 && pCalDlg->GetSelectedHead() == SEL_HEAD_MASTER) // slave fire skip
			continue;

		BOOL bMaterShutterOpen, bSlavShutterOpen, b1stPanel;
		int nFireHead;
		if(nPanelNo == 0) // master fire
		{
			bMaterShutterOpen = TRUE; bSlavShutterOpen = FALSE; b1stPanel = TRUE; nFireHead = SEL_HEAD_MASTER;
		}
		else
		{
			bMaterShutterOpen = FALSE; bSlavShutterOpen = TRUE; b1stPanel = FALSE; nFireHead = SEL_HEAD_SLAVE;
			// ī�޶� ���� ��ġ ���߱�
			if(gProcessINI.m_sProcessScannerCal.bDefaultLow)
			{
				dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			}
			else
			{	
				dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
				dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			}
			if(pCalDlg->m_nGridMode == 3 || pCalDlg->m_nGridMode == 5) 
			{
				dFirePosOffsetX = dFirePosOffsetY = 0;
			}
		}

		if (!pDlg->ShutterMove(bMaterShutterOpen, bSlavShutterOpen))
		{
			StopProcess(pAuto, TRUE, TRUE);
			return 0;
		}
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			StopProcess(pAuto, TRUE, TRUE);
			return 0;
		}

		 BYTE cFlag = FIRST_PANEL_OFFSET;
		 if(!b1stPanel)
			 cFlag = SECOND_PANEL_OFFSET;
		
		double dLaserOffsetX, dLaserOffsetY;
		for(int i = 0; i < nYGrid; i++)
		{
			for(int j = 0; j < nXGrid; j++)
			{
				pCalDlg->EnableCalibrationWindow(FALSE);

				dLaserOffsetX = dLaserOffsetY = 0;
				if(pCalDlg->m_nGridMode != 3)
				{
					gDeviceFactory.GetEocard()->GetLaserOffset(dStartPosX - j * pCalDlg->m_nGridSize - dFirePosOffsetX, 
																									   dStartPosY - i * pCalDlg->m_nGridSize - dFirePosOffsetY, 
																										dLaserOffsetX, dLaserOffsetY, cFlag);
				}

				if(!pMotor->MoveXY(dStartPosX - j * pCalDlg->m_nGridSize - dFirePosOffsetX + dLaserOffsetX, dStartPosY - i * pCalDlg->m_nGridSize - dFirePosOffsetY + dLaserOffsetY, b1stPanel, SHOT_MOVE)) 
				{
					StopProcess(pAuto, FALSE, TRUE);
					return 0;
				}
				if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
				{
					StopProcess(pAuto, FALSE, TRUE);
					return 0;
				}
				BOOL bChangeSubTool = FALSE;
				if(i == 0 && j == 0)
					bChangeSubTool = TRUE;
				
				if (FireCalibrationHole(pAuto, nFireHead, dStartPosX - j * pCalDlg->m_nGridSize - dFirePosOffsetX, dStartPosY - i * pCalDlg->m_nGridSize - dFirePosOffsetY, true)) 
				{
					StopProcess(pAuto, FALSE, TRUE);
					return 0;
				}
			}
		}

		if(pCalDlg->m_bGetHeadOffset )
		{
			if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
			{
				StopProcess(pAuto, TRUE, TRUE);
				return 0;
			}
			
			if(!pMotor->MoveXY(pCalDlg->m_dOffsetStartXAuto, pCalDlg->m_dOffsetStartYAuto, FALSE, SHOT_MOVE))
			{
				StopProcess(pAuto, FALSE, TRUE);
				return 0;
			}
			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
			{
				StopProcess(pAuto, FALSE, TRUE);
				return 0;
			}
			
			if (FireCalibrationHole(pAuto, nFireHead, pCalDlg->m_dOffsetStartXAuto, pCalDlg->m_dOffsetStartYAuto, true, true)) 
			{
				StopProcess(pAuto, FALSE, TRUE);
				return 0;
			}
		}
	}
	pCalDlg->MessageLoop();

	if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}
	return true;
}

UINT FindSCalHole(LPVOID pParam)
{
	AUTOCALTHREADPARAM* pAuto = static_cast<AUTOCALTHREADPARAM*>(pParam);
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	BOOL bUseLowCam, bFindFast = FALSE;
	double dStartZ1, dStartZ2;
	pCalDlg->GetCAmNumInfo(bUseLowCam, emNone);
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	if(bUseLowCam)
	{
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - pCalDlg->GetCalThick();
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - pCalDlg->GetCalThick2nd();
	}
	else
	{	
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - pCalDlg->GetCalThick();
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - pCalDlg->GetCalThick2nd();
	}

	CString szPath, szSavePath;
	CTime ct = CTime::GetCurrentTime();
	if(pCalDlg->m_bDryRunCheck)
	{
		szPath.Format(_T("%sCalOffset%2d%2d%2d%2d%2d%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir(),ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(), ct.GetSecond());
	}
	else
		szPath.Format(_T("%sCalOffset.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());

	CFile file;
	CFile fileResult;
	if (FALSE == file.Open(szPath, CFile::modeCreate|CFile::modeWrite))
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}
	szSavePath.Format(_T("%sCalResult%2d%2d%2d%2d%2d%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(),ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(), ct.GetSecond());
	if (FALSE == fileResult.Open(szSavePath, CFile::modeCreate|CFile::modeWrite))
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}

	TCHAR szCode[256] = {0,};
	TCHAR szResult[256] = {0,};
	DPOINT *pdPos = NULL, *pdOffset = NULL;
	bool* pSuccess = NULL;
	DPOINT *pdPos2 = NULL, *pdOffset2 = NULL;
	bool* pSuccess2 = NULL;
	TRY
	{
		pdPos = new DPOINT[pCalDlg->GetDivision() * pCalDlg->GetDivision()];
		pdOffset = new DPOINT[pCalDlg->GetDivision() * pCalDlg->GetDivision()];
		pSuccess = new bool[pCalDlg->GetDivision() * pCalDlg->GetDivision()];
		
		pdPos2 = new DPOINT[pCalDlg->GetDivision() * pCalDlg->GetDivision()];
		pdOffset2 = new DPOINT[pCalDlg->GetDivision() * pCalDlg->GetDivision()];
		pSuccess2 = new bool[pCalDlg->GetDivision() * pCalDlg->GetDivision()];

		for (int i = 0; i < pCalDlg->GetDivision() * pCalDlg->GetDivision(); i++)
		{
			pSuccess[i] = true;
			pdPos[i].x = pdPos[i].y = 0.0;
			pdOffset[i].x = pdOffset[i].y = 0.0;

			pSuccess2[i] = true;
			pdPos2[i].x = pdPos2[i].y = 0.0;
			pdOffset2[i].x = pdOffset2[i].y = 0.0;

		}
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		StopProcess(pAuto, FALSE);
		return 0;
	}
	END_CATCH

	if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
	{
		StopProcess(pAuto, FALSE);
		pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		return 0;
	}

	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(pCalDlg->GetSelectedHead() != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (pCalDlg->GetSelectedHead() != SEL_HEAD_MASTER)
		n2ndUse = emSlave;

	if(pCalDlg->m_nGridMode == 3)
	{
		n1stUse = emMaster;
		if(pCalDlg->GetSelectedHead() == SEL_HEAD_SLAVE)
			n1stUse = emSlave;
		if (FindCurrentShot(pAuto, dStartZ1, dStartZ2, n1stUse, NULL, NULL, NULL))
		{
			StopProcess(pAuto, FALSE);
			pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
			return 0;
		}
		::SetEvent(pHandle[2]);
		pDlg->ShutterMove(FALSE, FALSE); // 20090629 Front Mode error

		pCalDlg->m_bDryRunCheck = FALSE;
		::SetEvent(g_hDoScalManual);
		ErrMessage(_T("Finish Laser Calibration Process\nIf you want make LaserM.Cal or LaserS.Cal,\n click [Apply Laser Cal] button."));
		StopProcess(pAuto, FALSE);
		pCalDlg->ReaseFileAndMem(NULL, NULL, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		return 0;
	}
	else if(pCalDlg->m_nGridMode == 5)
	{
		n1stUse = emMaster;
		if(pCalDlg->GetSelectedHead() == SEL_HEAD_SLAVE)
			n1stUse = emSlave;
		if (FindCurrentShot(pAuto, dStartZ1, dStartZ2, n1stUse, NULL, NULL, NULL))
		{
			StopProcess(pAuto, FALSE);
			pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
			return 0;
		}
		::SetEvent(pHandle[2]);
		pDlg->ShutterMove(FALSE, FALSE); 

		pCalDlg->m_bDryRunCheck = FALSE;
		::SetEvent(g_hDoScalManual);
		ErrMessage(_T("Finish Verify S.Cal."));
		StopProcess(pAuto, FALSE);
		pCalDlg->ReaseFileAndMem(NULL, NULL, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		return 0;
	}
	else
	{
		BOOL bPostFound = FALSE;
		if(bFindFast)
		{
			bPostFound = FindCurrentShot(pAuto, dStartZ1, dStartZ2, n1stUse, n2ndUse, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		}
		else
		{
			if(n1stUse == emMaster)
				bPostFound = FindCurrentShot(pAuto, dStartZ1, dStartZ2, n1stUse, pdPos, pdOffset, pSuccess);
			if(!bPostFound && n2ndUse == emSlave)
				bPostFound = FindCurrentShot(pAuto, dStartZ1, dStartZ2, n2ndUse, pdPos2, pdOffset2, pSuccess2);
		}
		if (bPostFound)
		{
			StopProcess(pAuto, FALSE);
			pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
			return 0;
		}
	}

	if(pCalDlg->m_bGetHeadOffset)
	{
		if(GetHeadOffset(pAuto, n1stUse, n2ndUse))
		{
			StopProcess(pAuto, FALSE);
			pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
			return 0;
		}
	}
	// 110620
	if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
	{
		StopProcess(pAuto, FALSE);
		pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		gVariable.m_sGlobal.bCalFalse = TRUE;
		return 0;
	}
	double dMaxTemp = 0;
	TRY
	{
		pCalDlg->m_dMaxOffsetMasterX = 0;
		pCalDlg->m_dMaxOffsetMasterY = 0;
		pCalDlg->m_dMaxOffsetMasterR = 0;
		
		for (int i = 0; i < pCalDlg->GetDivision() * pCalDlg->GetDivision(); i++)
		{
			pCalDlg->m_calAGCMaster.AddOffsetInfo(pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
			if (pSuccess[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				_stprintf_s(szResult, "T\tPos\t%f\t%f\tOffset\t%f\t%f\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(pCalDlg->m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					pCalDlg->m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(pCalDlg->m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					pCalDlg->m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				_stprintf_s(szResult, "F\tPos\t%f\t%f\tOffset\t%f\t%f\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(pCalDlg->m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					pCalDlg->m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(pCalDlg->m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					pCalDlg->m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}
			// 110620
			if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
			{
				StopProcess(pAuto, FALSE);
				gVariable.m_sGlobal.bCalFalse = TRUE;
				pCalDlg->ReaseFileAndMem(&file, &fileResult, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
				return 0;
			}

			file.Write(szCode, strlen(szCode));
			fileResult.Write(szResult, strlen(szResult));

			dMaxTemp = sqrt((pdOffset[i].x * pdOffset[i].x) + (pdOffset[i].y * pdOffset[i].y));
			if(pCalDlg->m_dMaxOffsetMasterR < dMaxTemp)
				pCalDlg->m_dMaxOffsetMasterR = dMaxTemp;
		}
	
		pCalDlg->m_dMaxOffsetSlaveX = 0;
		pCalDlg->m_dMaxOffsetSlaveY = 0;
		pCalDlg->m_dMaxOffsetSlaveR = 0;

		for (int i = 0; i < pCalDlg->GetDivision() * pCalDlg->GetDivision(); i++)
		{
			pCalDlg->m_calAGCSlave.AddOffsetInfo(pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
			if (pSuccess2[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				_stprintf_s(szResult, "T\tPos\t%f\t%f\tOffset\t%f\t%f\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(pCalDlg->m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					pCalDlg->m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(pCalDlg->m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					pCalDlg->m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				_stprintf_s(szResult, "F\tPos\t%f\t%f\tOffset\t%f\t%f\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(pCalDlg->m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					pCalDlg->m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(pCalDlg->m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					pCalDlg->m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);
			}
			file.Write(szCode, strlen(szCode));
			fileResult.Write(szResult, strlen(szResult));

			dMaxTemp = sqrt((pdOffset2[i].x * pdOffset2[i].x) + (pdOffset2[i].y * pdOffset2[i].y));
			if(pCalDlg->m_dMaxOffsetSlaveR < dMaxTemp)
				pCalDlg->m_dMaxOffsetSlaveR = dMaxTemp;
		}
	
		file.Close();
		fileResult.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		StopProcess(pAuto, FALSE);
		pCalDlg->ReaseFileAndMem(NULL, NULL, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		return 0;
	}
	END_CATCH

	if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
	{
		StopProcess(pAuto, FALSE);
		gVariable.m_sGlobal.bCalFalse = TRUE;
		pCalDlg->ReaseFileAndMem(NULL, NULL, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
		return 0;
	}

	::SetEvent(pHandle[2]);
	pCalDlg->ReaseFileAndMem(NULL, NULL, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
	return true;
}

UINT CalibrationThread(LPVOID pParam)
{
	AUTOCALTHREADPARAM* pAuto = static_cast<AUTOCALTHREADPARAM*>(pParam);
	CPaneManualControlScannerCalibration* pCalDlg = pAuto->pParent;
	HANDLE* pHandle = pAuto->pHandle;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();
	int nSelHead = pCalDlg->GetSelectedHead();
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

	DWORD dwRetCode = ::WaitForMultipleObjects(3, pHandle, FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pHandle[0]);
	else
	{
		StopProcess(pAuto, TRUE);
		return 0;
	}
	// shutter close
	if (!pDlg->ShutterMove(FALSE, FALSE))
	{
		StopProcess(pAuto, TRUE);
		return 0;
	}

	// check acrylic pre-hole
	if(pCalDlg->m_nGridMode == 3)
	{
		if(IDYES == ErrMessage("Do you want laser cal fire?", MB_YESNO))
		{
			pCalDlg->m_bLaserCalFire = TRUE;
		}
		else
		{
			pCalDlg->m_bLaserCalFire = FALSE;
		}
	}
	if(pCalDlg->m_bLaserCalFire == TRUE)
	{
		if(CheckAcrylic(pParam) == false)
			return 0;
		pCalDlg->MessageLoop();
		if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
		{
			StopProcess(pAuto, FALSE);
			gVariable.m_sGlobal.bCalFalse = TRUE;
			return 0;
		}
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			StopProcess(pAuto, TRUE, TRUE);
			return 0;
		}

		//�������� �߻�!!
		if(FireAcrylic(pParam) == false)
		{
			StopProcess(pAuto, FALSE);
			return 0;
		}
	}
	
	if(pCalDlg->GetAutoProcessMode() && pCalDlg->m_bAutoCalStop)
	{
		StopProcess(pAuto, FALSE);
		gVariable.m_sGlobal.bCalFalse = TRUE;
		return 0;
	}
	if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}

	//shutter close
	if (!pDlg->ShutterMove(FALSE, FALSE))
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}

	// find holes
	if(FindSCalHole(pParam) == false)
	{
		StopProcess(pAuto, FALSE);
		return 0;
	}

	// release thread
	if(pCalDlg->m_nGridMode != 0)
	{
		StopProcess(pAuto, FALSE);
		pCalDlg->m_bDryRunCheck = FALSE;
		::SetEvent(g_hDoScalManual);
		return 0;
	}

	pCalDlg->WriteCalibrationStopEvent(TRUE);
	pCalDlg->SaveSCalResult(FALSE);

	if(gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_FIELD)
	{
		if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				StopProcess(pAuto, FALSE);
				ErrMsgDlg(STDGNALM781);
				return 0U;
			}
		}
	}
	

	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		
	gProcessINI.m_sProcessScannerCal.nCountAuto = pCalDlg->m_nCountAuto;
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);
	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);

	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

	::SetEvent(g_hDoScalManual);
	
	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	pCalDlg->SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
							cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
							cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
							cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, SCAL_JOB);

	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			if(!pCalDlg->m_bDryRunCheck)
				ErrMessage(_T("Dust Suction Shutter Off Error."));
		}
	}
	return 0;
}








/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibration

IMPLEMENT_DYNCREATE(CPaneManualControlScannerCalibration, CFormView)

CPaneManualControlScannerCalibration::CPaneManualControlScannerCalibration()
	: CFormView(CPaneManualControlScannerCalibration::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlScannerCalibration)
	m_bIsLive = FALSE;
	m_nPolarity = 0;
	m_bAutoPause = FALSE;
	m_strPath = _T("");
	m_nGridMode = 0;
	m_dMaxOffsetMasterX = 0;
	m_dMaxOffsetMasterY = 0;
	m_dMaxOffsetSlaveX = 0;
	m_dMaxOffsetSlaveY = 0;
	m_dMaxOffsetMasterR = 0;
	m_dMaxOffsetSlaveR = 0;
	m_nUserLevel = 0;
	m_bOKMaster = FALSE;
	m_bOKSlave = FALSE;
	m_bGetHeadOffset = FALSE;
	m_dOffsetStartXAuto = 0;
	m_dOffsetStartYAuto = 0;
	m_dScal1stTemper = 0;
	m_dScal2ndTemper = 0;
	m_dScal1stSBTemper = 0;
	m_dScal2ndSBTemper = 0;
	m_bLaserCalFire = TRUE;
	memset(m_dScalAllTemper, 0, sizeof(m_dScalAllTemper));
	//}}AFX_DATA_INIT
}

CPaneManualControlScannerCalibration::~CPaneManualControlScannerCalibration()
{
}

void CPaneManualControlScannerCalibration::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlScannerCalibration)
	DDX_Control(pDX, IDC_EDIT_JOB_FILE, m_edtPath);
	DDX_Control(pDX, IDC_COMBO_USE_VISION, m_cmbUseVision);
	DDX_Control(pDX, IDC_EDIT_CONTRAST, m_edtContrast);
	DDX_Control(pDX, IDC_EDIT_BRIGHTNESS, m_edtBrightness);
	DDX_Control(pDX, IDC_EDIT_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_COAXIAL, m_edtCoaxial);
	DDX_Control(pDX, IDC_EDIT_IR, m_edtIR);
	DDX_Control(pDX, IDC_EDIT_VISION_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_VISION_ANGLE, m_edtAngle);
	DDX_Control(pDX, IDC_EDIT_VISION_ASPECT_RATIO, m_edtAspectRatio);
	DDX_Control(pDX, IDC_EDIT_MODEL_ORIENTATION, m_edtModelOrientation);
	DDX_Control(pDX, IDC_EDIT_MODEL_SIZE, m_edtModelSize);
	DDX_Control(pDX, IDC_EDIT_MANUAL_Y_POS, m_edtManualYPos);
	DDX_Control(pDX, IDC_EDIT_MANUAL_X_POS, m_edtManualXPos);
	DDX_Control(pDX, IDC_EDIT_GRID_X_NO, m_edtGridXNo);
	DDX_Control(pDX, IDC_EDIT_GRID_Y_NO, m_edtGridYNo);
	DDX_Control(pDX, IDC_EDIT_GRID_GAP, m_edtGridGap);

	DDX_Control(pDX, IDC_EDIT_DIVISION_X, m_edtDivisionX);
	DDX_Control(pDX, IDC_EDIT_DIVISION_Y, m_edtDivisionY);
	DDX_Control(pDX, IDC_EDIT_FIELD_SIZE, m_edtFieldSize);

	
	DDX_Control(pDX, IDC_EDIT_MANUAL_2ND_THICKNESS, m_edtManual2ndThickness);
	DDX_Control(pDX, IDC_EDIT_MANUAL_1ST_THICKNESS, m_edtManual1stThickness);
	DDX_Control(pDX, IDC_EDIT_AUTO_Y_POS, m_edtAutoYPos);
	DDX_Control(pDX, IDC_EDIT_AUTO_X_POS, m_edtAutoXPos);
	DDX_Control(pDX, IDC_EDIT_AUTO_1ST_THICKNESS, m_edtAuto1stThickness);
	DDX_Control(pDX, IDC_EDIT_AUTO_2ND_THICKNESS, m_edtAuto2ndThickness);
	DDX_Control(pDX, IDC_EDIT_VISION_Z_OFFSET, m_edtVisionZOffset);

	DDX_Control(pDX, IDC_EDIT_SHOT_NO, m_edtShotNo);
	DDX_Control(pDX, IDC_EDIT_DUTY, m_edtDuty);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY, m_edtAOMDelay);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY, m_edtAOMDuty);

	DDX_Control(pDX, IDC_CHECK_INSP_AREA, m_chkInspArea);
	DDX_Control(pDX, IDC_CHECK_SKIP_BOARD, m_chkSkipCheckBoard);
	DDX_Control(pDX, IDC_COMBO_MANUAL_HEAD, m_cmbManualHead);
	DDX_Control(pDX, IDC_COMBO_MANUAL_DIVISION, m_cmbManualDivision);
	DDX_Control(pDX, IDC_COMBO_AUTO_HEAD, m_cmbAutoHead);
	DDX_Control(pDX, IDC_COMBO_AUTO_DIVISION, m_cmbAutoDivision);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_BUTTON_CHANGE_BOARD, m_btnChangeBoard);
	DDX_Control(pDX, IDC_BUTTON_CAL_STOP, m_btnCalStop);
	DDX_Control(pDX, IDC_BUTTON_CAL_START, m_btnCalStart);
	DDX_Control(pDX, IDC_BUTTON_APPLY_BEAMPATH, m_btnApplyBeamPath);
	DDX_Control(pDX, IDC_BUTTON_CAL_START_AUTO, m_btnCalStartAuto);
	DDX_Control(pDX, IDC_BUTTON_OFFSET_VERIFY, m_btnVisionOffsetVerify);
	DDX_Control(pDX, IDC_BUTTON_OFFSET_VERIFY_NEXT, m_btnVisionOffsetVerifyNext);
	DDX_Control(pDX, IDC_STATIC_VISION_RESULT, m_stcVisionResult);
	DDX_Radio(pDX, IDC_RADIO_DARK, m_nPolarity);
	DDX_Control(pDX, IDC_BUTTON_TRAIN, m_btnTrain);
	DDX_Control(pDX, IDC_BUTTON_TEST, m_btnTest);
	DDX_Control(pDX, IDC_BUTTON_LIVE, m_btnLive);
	DDX_Control(pDX, IDC_BUTTON_JOB_FILE_OPEN, m_btnJobFile);
	DDX_Control(pDX, IDC_BUTTON_TRIGGER, m_btnTrigger);
	DDX_Control(pDX, IDC_BUTTON_TRIGGER_AGC, m_btnTriggerAgc);
	DDX_Control(pDX, IDC_BUTTON_SHOW_DIALOG, m_btnShowDialog);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cmbTool);
	DDX_Control(pDX, IDC_BUTTON_X_GET_TIME, m_btnLaserCalibration);
	DDX_Control(pDX, IDC_BUTTON_Y_GET_TIME, m_btnApplyLaserCalibration);
	DDX_Control(pDX, IDC_SLIDER_COAXIAL, m_SliderCoaxial);
	DDX_Control(pDX, IDC_SLIDER_RING, m_SliderRing);
	DDX_Control(pDX, IDC_SLIDER_IR, m_SliderIR);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlScannerCalibration, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlScannerCalibration)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_LIVE, OnButtonLive)
	ON_BN_CLICKED(IDC_BUTTON_TEST, OnButtonTest)
	ON_BN_CLICKED(IDC_BUTTON_TRAIN, OnButtonTrain)
	ON_BN_CLICKED(IDC_BUTTON_CAL_START_AUTO, OnButtonCalStartAuto)
	ON_BN_CLICKED(IDC_BUTTON_CAL_START, OnButtonCalStart)
	ON_BN_CLICKED(IDC_BUTTON_CAL_START_VERIFY, OnButtonCalStartVerify)
	ON_BN_CLICKED(IDC_BUTTON_CAL_STOP, OnButtonCalStop)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_CBN_SELCHANGE(IDC_COMBO_USE_VISION, OnSelchangeComboUseVision)
	ON_CBN_SELCHANGE(IDC_COMBO_TOOL, OnSelchangeComboUseTool)
	ON_EN_KILLFOCUS(IDC_EDIT_COAXIAL, OnKillfocusEdit)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_BOARD, OnBtnChangeBoard)
	ON_MESSAGE(UM_START_THREAD_AGAIN, CalibrationThreadRestart)
	ON_MESSAGE(UM_THREAD_FINISHED, ModalDlgCalResult)
	ON_MESSAGE(UM_AUTOCAL_FAILED, MessageQuit)
	ON_BN_CLICKED(IDC_CHECK_INSP_AREA, OnInspectionArea)
	ON_MESSAGE(UM_AUTOCAL_START, OnCalibrationStart)
	ON_BN_CLICKED(IDC_BUTTON_TRIGGER, OnButtonTrigger)
	ON_BN_CLICKED(IDC_BUTTON_TRIGGER_AGC, OnButtonTriggerAgc)
	ON_BN_CLICKED(IDC_BUTTON_JOB_FILE_OPEN, OnButtonJobFileOpen)
	ON_BN_CLICKED(IDC_BUTTON_SHOW_DIALOG, OnButtonShowDialog)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM, ChangeVisionParam)
	ON_MESSAGE(UM_VISION_FIND2, GetVisionResult)
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	ON_MESSAGE(UM_VISION_LAMP, SetVisionLamp)
	ON_BN_CLICKED(IDC_BUTTON_X_GET_TIME, OnButtonXGetTime)
	ON_BN_CLICKED(IDC_BUTTON_Y_GET_TIME, OnButtonYGetTime)
	ON_EN_KILLFOCUS(IDC_EDIT_RING, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_IR, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_CONTRAST, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_BRIGHTNESS, OnKillfocusEdit)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_BEAMPATH, OnButtonApplyBeampath)
	ON_BN_CLICKED(IDC_CHECK_SKIP_BOARD, OnCheckSkipBoard)
	ON_MESSAGE(UM_VISION_FIND1, GetGrabVisionResult)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OFFSET_VERIFY, &CPaneManualControlScannerCalibration::OnBnClickedButtonOffsetVerify)
	ON_BN_CLICKED(IDC_BUTTON_OFFSET_VERIFY_NEXT, OnBnClickedButtonOffsetVerifyNext)
	ON_EN_KILLFOCUS(IDC_EDIT_AUTO_X_POS, &CPaneManualControlScannerCalibration::OnEnKillfocusEditAutoXPos)
	ON_EN_KILLFOCUS(IDC_EDIT_AUTO_Y_POS, &CPaneManualControlScannerCalibration::OnEnKillfocusEditAutoYPos)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_COAXIAL, &CPaneManualControlScannerCalibration::OnNMReleasedcaptureSliderCoaxial)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_RING, &CPaneManualControlScannerCalibration::OnNMReleasedcaptureSliderRing)
	ON_EN_KILLFOCUS(IDC_EDIT_AUTO_1ST_THICKNESS, &CPaneManualControlScannerCalibration::OnEnKillfocusEdit1stThick)
	ON_EN_KILLFOCUS(IDC_EDIT_AUTO_2ND_THICKNESS, &CPaneManualControlScannerCalibration::OnEnKillfocusEdit2ndThick)

	ON_EN_UPDATE(IDC_EDIT_COAXIAL, &CPaneManualControlScannerCalibration::OnEnUpdateEditCoaxial)
	ON_EN_UPDATE(IDC_EDIT_RING, &CPaneManualControlScannerCalibration::OnEnUpdateEditRing)
	ON_EN_UPDATE(IDC_EDIT_IR, &CPaneManualControlScannerCalibration::OnEnUpdateEditIR)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibration diagnostics

#ifdef _DEBUG
void CPaneManualControlScannerCalibration::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlScannerCalibration::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibration message handlers

void CPaneManualControlScannerCalibration::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = 0;
		m_nRing[i] = 0;
		m_nIR[i] = 0;
		m_dContrast[i] = 0.0;
		m_dBrightness[i] = 0.0;
	}

	InitStaticControl();
	InitBtnControl();
	InitListBoxControl();
	InitEditControl();
	InitComboControl();
	InitSlideControl();
#ifdef __PUSAN_LDD__
	m_nTimerID = SetTimer( 346, 250, NULL );
#endif
//	OnBtnManualCal();
	
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
	{
//		GetDlgItem(IDC_STATIC_VISION_LIGHT)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_IR)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_IR)->EnableWindow(FALSE);
	}

	m_nAutoProcessRepeat = 0;
	m_bIsAutoProcessMode = FALSE;
	m_bAutoCalibration = FALSE;
	m_bVerifyCalibration = FALSE;
	m_nCountAuto = 0;

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		m_chkInspArea.SetCheck(0);
		ChangeControl(FALSE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		ChangeControl(FALSE);
	}
	else
		ChangeControl(TRUE);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_cmbManualHead.SetCurSel(1);
		m_cmbAutoHead.SetCurSel(1);
		GetDlgItem(IDC_COMBO_AUTO_HEAD)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_MANUAL_HEAD)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_MANUAL_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_2ND_THICKNESS)->EnableWindow(FALSE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
	{
		GetDlgItem(IDC_STATIC_AUTO_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_AUTO_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_MANUAL_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_MANUAL_2ND_THICKNESS)->EnableWindow(FALSE);
	}

	m_sProcessScannerCal.bIsSkipCheckBoard = FALSE;
	gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard = FALSE;
#ifdef __3RDAOD__
	GetDlgItem(IDC_STATIC_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DUTY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_US2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_US3)->ShowWindow(SW_HIDE);
#endif

}

BOOL CPaneManualControlScannerCalibration::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlScannerCalibration::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(120, "Arial Bold");
	m_fntBtn3.CreatePointFont(140, "Arial Bold");

	// Calibration Start
	m_btnCalStart.SetFont( &m_fntBtn );
	m_btnCalStart.SetFlat( FALSE );
	m_btnCalStart.EnableBallonToolTip();
	m_btnCalStart.SetToolTipText( _T("Calibration Manual-Start") );
	m_btnCalStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCalStart.SetBtnCursor(IDC_HAND_1);

	// Calibration Start Auto
	m_btnCalStartAuto.SetFont( &m_fntBtn3 );
	m_btnCalStartAuto.SetFlat( FALSE );
	m_btnCalStartAuto.EnableBallonToolTip();
	m_btnCalStartAuto.SetToolTipText( _T("Calibration Auto-Start") );
	m_btnCalStartAuto.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCalStartAuto.SetBtnCursor(IDC_HAND_1);
	m_btnCalStartAuto.SetColorType(1); // Blue & Bold Line

	//Verify Vision Offset
	m_btnVisionOffsetVerify.SetFont( &m_fntBtn );
	m_btnVisionOffsetVerify.SetFlat( FALSE );
	m_btnVisionOffsetVerify.EnableBallonToolTip();
	m_btnVisionOffsetVerify.SetToolTipText( _T("Recheck Last S.Cal Position.") );
	m_btnVisionOffsetVerify.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVisionOffsetVerify.SetBtnCursor(IDC_HAND_1);

	m_btnVisionOffsetVerifyNext.SetFont( &m_fntBtn );
	m_btnVisionOffsetVerifyNext.SetFlat( FALSE );
	m_btnVisionOffsetVerifyNext.EnableBallonToolTip();
	m_btnVisionOffsetVerifyNext.SetToolTipText( _T("Recheck next S.Cal Position.") );
	m_btnVisionOffsetVerifyNext.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVisionOffsetVerifyNext.SetBtnCursor(IDC_HAND_1);

	// Calibration Stop
	m_btnCalStop.SetFont( &m_fntBtn );
	m_btnCalStop.SetFlat( FALSE );
	m_btnCalStop.EnableBallonToolTip();
	m_btnCalStop.SetToolTipText( _T("Calibration Stop") );
	m_btnCalStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCalStop.SetBtnCursor(IDC_HAND_1);

	// apply to beam path
	m_btnApplyBeamPath.SetFont( &m_fntBtn );
	m_btnApplyBeamPath.SetFlat( FALSE );
	m_btnApplyBeamPath.EnableBallonToolTip();
	m_btnApplyBeamPath.SetToolTipText( _T("Apply Scanner parameter to the beam path.") );
	m_btnApplyBeamPath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyBeamPath.SetBtnCursor(IDC_HAND_1);

	// Change Board
	m_btnChangeBoard.SetFont( &m_fntBtn );
	m_btnChangeBoard.SetFlat( FALSE );
	m_btnChangeBoard.EnableBallonToolTip();
	m_btnChangeBoard.SetToolTipText( _T("Change Board") );
	m_btnChangeBoard.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeBoard.SetBtnCursor(IDC_HAND_1);

	// Polarity
	GetDlgItem(IDC_RADIO_DARK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LIGHT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_IGNORE)->SetFont( &m_fntBtn );

	// Inspection Area
	//GetDlgItem(IDC_CHECK_INSP_AREA)->SetFont( &m_fntBtn );
	m_chkInspArea.SetFont( &m_fntBtn );
	m_chkInspArea.SetImageOrg( 10, 3 );
	m_chkInspArea.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkInspArea.EnableBallonToolTip();
	m_chkInspArea.SetToolTipText( _T("Inspection Area") );
	m_chkInspArea.SetBtnCursor(IDC_HAND_1);
	m_chkInspArea.SetCheck(0);

	// Skip check board
	m_chkSkipCheckBoard.SetFont( &m_fntBtn );
	m_chkSkipCheckBoard.SetImageOrg( 10, 3 );
	m_chkSkipCheckBoard.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSkipCheckBoard.EnableBallonToolTip();
	m_chkSkipCheckBoard.SetToolTipText( _T("Skip Board-check before firing") );
	m_chkSkipCheckBoard.SetBtnCursor(IDC_HAND_1);
	m_chkSkipCheckBoard.SetCheck(TRUE);

	// Live
	m_btnLive.SetFont( &m_fntBtn );
	m_btnLive.SetRectAlign( 1 );
	m_btnLive.SetToolTipText( _T("Omi Vision Live Start/Stop") );
	m_btnLive.SetBtnCursor( IDC_HAND_1 );
	
	// Test
	m_btnTest.SetFont( &m_fntBtn );
	m_btnTest.SetFlat( FALSE );
	m_btnTest.EnableBallonToolTip();
	m_btnTest.SetToolTipText( _T("Test") );
	m_btnTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTest.SetBtnCursor(IDC_HAND_1);
	
	// Train
	m_btnTrain.SetFont( &m_fntBtn3 );
	m_btnTrain.SetFlat( FALSE );
	m_btnTrain.EnableBallonToolTip();
	m_btnTrain.SetToolTipText( _T("Train") );
	m_btnTrain.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrain.SetBtnCursor(IDC_HAND_1);
	m_btnTrain.SetColorType(1); // Blue & Bold Line

	// Trigger
	m_btnTrigger.SetFont( &m_fntBtn );
	m_btnTrigger.SetFlat( FALSE );
	m_btnTrigger.EnableBallonToolTip();
	m_btnTrigger.SetToolTipText( _T("Trigger") );
	m_btnTrigger.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrigger.SetBtnCursor(IDC_HAND_1);
	
	// Trigger Agc
	m_btnTriggerAgc.SetFont( &m_fntBtn );
	m_btnTriggerAgc.SetFlat( FALSE );
	m_btnTriggerAgc.EnableBallonToolTip();
	m_btnTriggerAgc.SetToolTipText( _T("Trigger Agc") );
	m_btnTriggerAgc.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTriggerAgc.SetBtnCursor(IDC_HAND_1);

	// Show Dialog
	m_btnShowDialog.SetFont( &m_fntBtn );
	m_btnShowDialog.SetFlat( FALSE );
	m_btnShowDialog.EnableBallonToolTip();
	m_btnShowDialog.SetToolTipText( _T("Show Vision Dialog") );
	m_btnShowDialog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShowDialog.SetBtnCursor(IDC_HAND_1);
	
	m_btnJobFile.SetFont( &m_fntBtn2 );
	m_btnJobFile.SetFlat( FALSE );
	m_btnJobFile.EnableBallonToolTip();
	m_btnJobFile.SetToolTipText( _T("Job FilePath Selection") );
	m_btnJobFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobFile.SetBtnCursor(IDC_HAND_1);

	m_btnLaserCalibration.SetFont( &m_fntBtn2 );
	m_btnLaserCalibration.SetFlat( FALSE );
	m_btnLaserCalibration.EnableBallonToolTip();
	m_btnLaserCalibration.SetToolTipText( _T("Job FilePath Selection") );
	m_btnLaserCalibration.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserCalibration.SetBtnCursor(IDC_HAND_1);

	m_btnApplyLaserCalibration.SetFont( &m_fntBtn2 );
	m_btnApplyLaserCalibration.SetFlat( FALSE );
	m_btnApplyLaserCalibration.EnableBallonToolTip();
	m_btnApplyLaserCalibration.SetToolTipText( _T("Job FilePath Selection") );
	m_btnApplyLaserCalibration.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyLaserCalibration.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlScannerCalibration::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	m_fntStatic2.CreatePointFont(140, "Arial Bold");

	GetDlgItem(IDC_STATIC_VISION_Z_OFFSET)->SetFont( &m_fntStatic );
	// Auto Calibration
	GetDlgItem(IDC_STATIC_AUTO_CAL)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_DIVISION)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_HEAD)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_1ST_THICKNESS)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_2ND_THICKNESS)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_X_POS)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_AUTO_Y_POS)->SetFont( &m_fntStatic2 );

	// Manual Calibration
	GetDlgItem(IDC_STATIC_MANUAL_CAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_DIVISION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_HEAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_X_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_Y_POS)->SetFont( &m_fntStatic );

	// Tool
	GetDlgItem(IDC_STATIC_TOOL_SELECTION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOOL_NO)->SetFont( &m_fntStatic );

	// Vision Model
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL_ORIENTATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );

	// Accept Score
	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ASPECT_RATIO)->SetFont( &m_fntStatic );

	// Light
//	GetDlgItem(IDC_STATIC_VISION_LIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );

	// Contrast / Brightness
	GetDlgItem(IDC_STATIC_CONTRAST_BRIGHNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONTRAST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->SetFont( &m_fntStatic );

	// Vision Result
	m_stcVisionResult.SetFont( &m_fntStatic );
	m_stcVisionResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcVisionResult.SetBackColor( VALUE_BACK_COLOR );

	// Laser setting
	GetDlgItem(IDC_STATIC_LASER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DUTY)->SetFont( &m_fntStatic );

	// Use Vision For Calibration
	GetDlgItem(IDC_STATIC_USE_VISION)->SetFont( &m_fntStatic );

	// JobFile
	GetDlgItem(IDC_STATIC_JOB_FILE)->SetFont( &m_fntStatic );

//	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
//		GetDlgItem(IDC_STATIC_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
//		GetDlgItem(IDC_STATIC_2ND_THICKNESS)->EnableWindow(FALSE);
//	}
}

void CPaneManualControlScannerCalibration::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Auto Calibration
	m_edtAuto1stThickness.SetFont( &m_fntEdit );
	m_edtAuto1stThickness.SetReceivedFlag( 3 );
	m_edtAuto1stThickness.SetWindowText( _T("3.0") );

	m_edtAuto2ndThickness.SetFont( &m_fntEdit );
	m_edtAuto2ndThickness.SetReceivedFlag( 3 );
	m_edtAuto2ndThickness.SetWindowText( _T("3.0") );

	m_edtAutoXPos.SetFont( &m_fntEdit );
	m_edtAutoXPos.SetReceivedFlag( 3 );
	m_edtAutoXPos.SetWindowText( _T("500.0") );

	m_edtAutoYPos.SetFont( &m_fntEdit );
	m_edtAutoYPos.SetReceivedFlag( 3 );
	m_edtAutoYPos.SetWindowText( _T("400.0") );

	m_edtGridXNo.SetFont( &m_fntEdit );
	m_edtGridXNo.SetReceivedFlag( 1 );
	m_edtGridXNo.SetWindowText( _T("19") );
	
	m_edtGridYNo.SetFont( &m_fntEdit );
	m_edtGridYNo.SetReceivedFlag( 1 );
	m_edtGridYNo.SetWindowText( _T("26") );
	
	m_edtGridGap.SetFont( &m_fntEdit );
	m_edtGridGap.SetReceivedFlag( 1 );
	m_edtGridGap.SetWindowText( _T("25") );

	m_edtFieldSize.SetFont( &m_fntEdit );
	m_edtFieldSize.SetReceivedFlag( 3 );
	m_edtFieldSize.SetWindowText( _T("65") );
	
	m_edtDivisionX.SetFont( &m_fntEdit );
	m_edtDivisionX.SetReceivedFlag( 1 );
	m_edtDivisionX.SetWindowText( _T("9") );
	
	m_edtDivisionY.SetFont( &m_fntEdit );
	m_edtDivisionY.SetReceivedFlag( 1 );
	m_edtDivisionY.SetWindowText( _T("9") );

	// Manual Calibration	
	m_edtManual1stThickness.SetFont( &m_fntEdit );
	m_edtManual1stThickness.SetReceivedFlag( 3 );
	m_edtManual1stThickness.SetWindowText( _T("3.0") );

	m_edtManual2ndThickness.SetFont( &m_fntEdit );
	m_edtManual2ndThickness.SetReceivedFlag( 3 );
	m_edtManual2ndThickness.SetWindowText( _T("3.0") );

//	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
//		m_edtAuto2ndThickness.SetWindowText(_T("NO USE"));
//		m_edtAuto2ndThickness.EnableWindow(FALSE);

//		m_edtManual2ndThickness.SetWindowText(_T("NO USE"));
//		m_edtManual2ndThickness.EnableWindow(FALSE);
//	}

	m_edtManualXPos.SetFont( &m_fntEdit );
	m_edtManualXPos.SetReceivedFlag( 3 );
	m_edtManualXPos.SetWindowText( _T("500.0") );

	m_edtManualYPos.SetFont( &m_fntEdit );
	m_edtManualYPos.SetReceivedFlag( 3 );
	m_edtManualYPos.SetWindowText( _T("400.0") );

	// Model
	m_edtModelSize.SetFont( &m_fntEdit );
	m_edtModelSize.SetReceivedFlag( 3 );
	m_edtModelSize.SetWindowText( _T("0.26") );
	
	m_edtModelOrientation.SetFont( &m_fntEdit );
	m_edtModelOrientation.SetReceivedFlag( 3 );
	m_edtModelOrientation.SetWindowText( _T("0.0") );

	// Accept Score
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetReceivedFlag( 1 );
	m_edtSize.SetWindowText( _T("20") );

	m_edtVisionZOffset.SetFont( &m_fntEdit );
	m_edtVisionZOffset.SetReceivedFlag( 3 );
	m_edtVisionZOffset.SetWindowText( _T("0.08") );
	
	m_edtAngle.SetFont( &m_fntEdit );
	m_edtAngle.SetReceivedFlag( 1 );
	m_edtAngle.SetWindowText( _T("20") );

	m_edtAspectRatio.SetFont( &m_fntEdit );
	m_edtAspectRatio.SetReceivedFlag( 1 );
	m_edtAspectRatio.SetWindowText( _T("1") );

	// Light
	m_edtCoaxial.SetFont( &m_fntEdit );
	m_edtCoaxial.SetReceivedFlag( 1 );
	m_edtCoaxial.SetWindowText( _T("150") );
	
	m_edtRing.SetFont( &m_fntEdit );
	m_edtRing.SetReceivedFlag( 1 );
	m_edtRing.SetWindowText( _T("150") );

	m_edtIR.SetFont( &m_fntEdit );
	m_edtIR.SetReceivedFlag( 1 );
	m_edtIR.SetWindowText( _T("150") );

	// Contrast / Brightness
	m_edtContrast.SetFont( &m_fntEdit );
	m_edtContrast.SetReceivedFlag( 3 );
	m_edtContrast.SetWindowText( _T("0.6") );
	
	m_edtBrightness.SetFont( &m_fntEdit );
	m_edtBrightness.SetReceivedFlag( 3 );
	m_edtBrightness.SetWindowText( _T("0.6") );

	m_edtShotNo.SetFont( &m_fntEdit );
	m_edtShotNo.SetReceivedFlag( 1 );
	m_edtShotNo.SetWindowText( _T("1") );

	m_edtDuty.SetFont( &m_fntEdit );
	m_edtDuty.SetReceivedFlag( 3 );
	m_edtDuty.SetWindowText( _T("40") );

	m_edtAOMDelay.SetFont( &m_fntEdit );
	m_edtAOMDelay.SetReceivedFlag( 3 );
	m_edtAOMDelay.SetWindowText( _T("20") );

	m_edtAOMDuty.SetFont( &m_fntEdit );
	m_edtAOMDuty.SetReceivedFlag( 3 );
	m_edtAOMDuty.SetWindowText( _T("20") );

	m_fntEdit2.CreatePointFont(120, "Arial Bold");
	// Job File Path
	m_edtPath.SetFont( &m_fntEdit2 );
	m_edtPath.SetForeColor( BLACK_COLOR );
	m_edtPath.SetBackColor( WHITE_COLOR );
	m_edtPath.SetWindowText( (LPCTSTR)m_strPath );
}

void CPaneManualControlScannerCalibration::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(110, "Arial Bold");

	m_lboxResult.SetFont( &m_fntListBox );
}

void CPaneManualControlScannerCalibration::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbAutoDivision.SetFont( &m_fntCombo );
	m_cmbAutoDivision.SetCurSel( 2 );

	m_cmbAutoHead.SetFont( &m_fntCombo );
	m_cmbAutoHead.SetCurSel( 0 );

	m_cmbManualDivision.SetFont( &m_fntCombo );
	m_cmbManualDivision.SetCurSel( 3 );

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );

	m_cmbManualHead.SetFont( &m_fntCombo );
	m_cmbManualHead.SetCurSel( 0 );

	m_cmbUseVision.SetFont( &m_fntCombo );
	
	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("Vision");
		m_cmbUseVision.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("High Vision");
		m_cmbUseVision.AddString("Low Vision");
		break;
	}

	m_cmbUseVision.SetCurSel( 1 );
	SetValue( 0 );

	m_cmbTool.SetCurSel(gProcessINI.m_sProcessScannerCal.nUseTool);
	m_sProcessScannerCal.nUseTool = gProcessINI.m_sProcessScannerCal.nUseTool;

}

HBRUSH CPaneManualControlScannerCalibration::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_AUTO_CAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MANUAL_CAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MODEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POLARITY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
//		GetDlgItem(IDC_STATIC_VISION_LIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CONTRAST_BRIGHNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TOOL_SELECTION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_JOB_FILE)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlScannerCalibration::NotifyError(int nAlarmNo, BOOL bDisplayErr, CString strMsg, BOOL bWindowMsg)
{
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
	if(bDisplayErr)
	{
		if(bWindowMsg)
		{
			if(nAlarmNo > 0)
				ErrMessage(nAlarmNo);
			else
				ErrMessage(strMsg);
		}
		else
		{
			ErrMsgDlg(nAlarmNo);
		}
	}
	::Sleep(500);
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
}

LRESULT CPaneManualControlScannerCalibration::CalibrationThreadRestart(WPARAM, LPARAM)
{
	if (m_pThread != NULL)
	{
		::SetEvent(m_ThreadParam.pHandle[1]);
		::Sleep(100);
		
		DWORD dwRetCode = ::WaitForSingleObject(m_ThreadParam.pHandle[2], WAIT_TIME);
		if (dwRetCode == WAIT_OBJECT_0)
		{
			::ResetEvent(m_ThreadParam.pHandle[1]);
			m_pThread = NULL;
		}
		else
		{
			NotifyError(IDS_SCAL_THREAD_PREV);
			return 0L;
		}
		::Sleep(100);
	}
	
	int nMaxCount = gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount*100;
	/*if(gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount == 2)
		nMaxCount = MAX_AUTOCAL_COUNT - 100;*/

	if (m_nCountAuto >= nMaxCount)		
	{
#ifndef __TEST__
		MakeThreadClear();
		EnableCalibrationWindow(TRUE);
		NotifyError(IDS_SCAL_BOARD);
		return 0L;
#else
		m_nCountAuto = 0;
#endif
	}
	
	CalculateAutoStartPosition();
	m_nCountAuto++;
	
#ifndef __TEST__
	if (!CheckMotorPositionValidity())
	{
		MakeThreadClear();
		EnableCalibrationWindow(TRUE);
		m_nCountAuto--;
		NotifyError(IDS_SCAL_POSITION);
		return 0L;
	}
#endif
	
	m_pThread = ::AfxBeginThread(CalibrationThread, static_cast<LPVOID>(const_cast<AUTOCALTHREADPARAM*>(&m_ThreadParam)));
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		EnableCalibrationWindow(TRUE);
		m_nCountAuto--;
		NotifyError(IDS_SCAL_THREAD_CREATE);
		return 0L;
	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
	::ResetEvent(m_ThreadParam.pHandle[2]);
	::SetEvent(m_ThreadParam.pHandle[0]);
	
	CString strEvent, strInfo, strTemp;
	strEvent = _T("Started automatic scanner calibration.");
	if(m_bIsAutoProcessMode)
		strInfo = _T("Automatic Calibration | ");
	else
		strInfo = _T("Manual Calibration | ");

	strTemp.Format(_T("Grid size = %dx%d | Beam Path No. = %d | PCB Thickness = %f, %f mm | Start Position ( X = %f mm, Y = %f mm )"),
		GetDivision(), GetDivision(), GetMaskNo(), GetCalThick(), GetCalThick2nd(), GetCalStartX(), GetCalStartY());	
	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	
	return 1L;
}

LRESULT CPaneManualControlScannerCalibration::ModalDlgCalResult(WPARAM, LPARAM)
{
	::Sleep(100);
	CDlgCalResult DlgCalResult;
	DlgCalResult.SetTablePos(GetCalStartX(), GetCalStartY());
	DlgCalResult.SetToolIndex(m_sProcessScannerCal.nUseTool);
	DlgCalResult.SetTemperature(m_bFullCoolingAGC, m_dScal1stTemper, m_dScal2ndTemper, m_dScal1stSBTemper, m_dScal2ndSBTemper, m_dScalAllTemper);


	CString strMaster, strSlave;
	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_sProcessScannerCal.nUseTool]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_sProcessScannerCal.nUseTool]);

	DlgCalResult.SetASCFilePath(strMaster, strSlave);
	
	if (m_bAutoCalibration)
		DlgCalResult.SetAutoProcessMode();
	
	// yhchung 070307
	DlgCalResult.SetAGCUnit(&m_calAGCMaster, &m_calAGCSlave);
	DlgCalResult.SetSelectHead(GetSelectedHead());
	
	if(DlgCalResult.DoModal() == IDOK)
	{
		if(m_bGetHeadOffset)
		{
			gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x -= m_dOffsetM.x;
			gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y -= m_dOffsetM.y;
			gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x -= m_dOffsetS.x;
			gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y -= m_dOffsetS.y;
			
			if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
				ErrMsgDlg(STDGNALM110);
		}
		SaveSCalResult(TRUE);
	}
	
	if (m_bIsAutoProcessMode)
	{		
		if (gVariable.m_sGlobal.bCalFalse)
			this->PostMessage(UM_AUTOCAL_START);
		else
		{
			m_bIsAutoProcessMode = FALSE;
			m_bAutoCalibration = FALSE;
		}
	}
	
	if (m_pThread != NULL)
	{
		::WaitForSingleObject(m_ThreadParam.pHandle[2], INFINITE);
		MakeThreadClear();
	}
	EnableCalibrationWindow(TRUE);

	return 1L;
}

LRESULT CPaneManualControlScannerCalibration::MessageQuit(WPARAM wParam, LPARAM)
{
	STDGNALM nMessage = static_cast<STDGNALM>(wParam);
	
	if (nMessage != STDGNALM9999)
	{
#ifndef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
#else
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		::ErrMsgDlg(nMessage);
		::Sleep(500);
#ifndef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
#else
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
	}
	return 1L;
}

void CPaneManualControlScannerCalibration::OnButtonCalStartAuto() 
{
	::ResetEvent(g_hDoScalManual);

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		if(!m_bDryRunCheck)
			ErrMessage(_T("Please Reset Error")); // 110603
		::SetEvent(g_hDoScalManual);
		return;
	}
	
	// �µ����� ���� ����
	m_bFullCoolingAGC = FALSE;
	double dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
	double dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
	if(dEndTime >= dWaitTime)
		m_bFullCoolingAGC = TRUE;

	if(gDeviceFactory.Get1stTemperCompen()->GetTableNo() > 1 || 
		gDeviceFactory.Get2ndTemperCompen()->GetTableNo() > 1) // �Ŀ��� ���� ���̺��� 2�� �̻��̶�� AGC ���� ��Ȳ���� ��ٷ�����
	{
		if( !((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAnyDoAutoSCal ) // AGC ���� ��Ȳ�� �ƴ� ���
			dEndTime = dWaitTime + 1;
	}
	else // �Ŀ� ���̺��� 1����� ���α׷� ���ۿ����� ���������� ��ٷ��� ��. �µ�����
	{
		if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT() && gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT()) // �Ѵ� �µ� �������� �������� ��쿡�� 5�� ��ٸ��� ����.
			dEndTime =  (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLilyStartTime;
	}

	if(!gProcessINI.m_sProcessOption.bTemperCompensationMode) // Temper ���� ��尡 �ƴϸ� ��ٸ� �ʿ� ����
		dEndTime = dWaitTime + 1;
	else
	{
		if(gProcessINI.m_sProcessOption.bWaitTemperDownForAGC) // ������ �Ź� ��ٸ��� �ɼ��� ���ϸ�
		{
			dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
			dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
		}
	}

	if(dWaitTime > dEndTime)
	{
		CString strMessage;
		strMessage.Format(_T("User can start. program start or drilling after %.0fsec \n%Try again after %.0fsec \n Temperature value occur reversal phenomenon, or must to down temperature"), dWaitTime, dWaitTime - dEndTime);
		ErrMessage(strMessage);
		return;
	}	
	
	if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("DrillEndTime\t%d\tLimit\t%.0f" ),   
							((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime,
							dWaitTime);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	// �µ����� ���� ���� ��

	m_nGridMode = 0;	
	SetAutoProcessMode();
	
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = pMotor->GetAOMStatus(); // 110607
		BOOL bScanner = pMotor->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			NotifyError(STDGNALM303, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		NotifyError(STDGNALM559, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			NotifyError(STDGNALM607, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	if(pMotor->IsSafetyMode())
	{
		NotifyError(STDGNALM207, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}

	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
	::Sleep(500);

	int nHead = GetSelectedHead();

	BOOL bRet = FALSE;
		
	int nSuction1 = pMotor->GetCurrentSuction();
	BOOL b1stAcrylSuction = pMotor->GetCurrentAcrylSuction(TRUE);
	BOOL b2ndAcrylSuction = pMotor->GetCurrentAcrylSuction(FALSE);
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if(nSuction1 & 0x01 && bMotor) b1st = TRUE;
	if(nSuction1 & 0x02 && bMotor) b2nd = TRUE;
	
	if(nHead == 0)
	{
		if(!b1stAcrylSuction || !b2ndAcrylSuction)
		{
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		}

		if(b1st && b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else if(nHead == 1)
	{
		if(!b1stAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );

		if(b1st)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else
	{
		if(!b2ndAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );

		if(b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}

	int nBeamPathNo = m_cmbTool.GetCurSel();
	if(gBeamPathINI.m_sBeampath.nLastIndex >= nBeamPathNo && nBeamPathNo >= 0)
		ChangeLaserParam(nBeamPathNo);

	OnCalibrationStart();
}

void CPaneManualControlScannerCalibration::OnButtonCalStart() 
{
	::ResetEvent(g_hDoScalManual);

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		if(!m_bDryRunCheck)
			ErrMessage(_T("Please Reset Error")); // 110603
		::SetEvent(g_hDoScalManual);
		return;
	}

	// �µ����� ���� ����
	m_bFullCoolingAGC = FALSE;
	double dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
	double dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
	if(dEndTime >= dWaitTime)
		m_bFullCoolingAGC = TRUE;

	if(gDeviceFactory.Get1stTemperCompen()->GetTableNo() > 1 || 
		gDeviceFactory.Get2ndTemperCompen()->GetTableNo() > 1) // �Ŀ��� ���� ���̺��� 2�� �̻��̶�� AGC ���� ��Ȳ���� ��ٷ�����
	{
		if( !((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAnyDoAutoSCal ) // AGC ���� ��Ȳ�� �ƴ� ���
			dEndTime = dWaitTime + 1;
	}
	else // �Ŀ� ���̺��� 1����� ���α׷� ���ۿ����� ���������� ��ٷ��� ��. �µ�����
	{
		if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT() && gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT()) // �Ѵ� �µ� �������� �������� ��쿡�� 5�� ��ٸ��� ����.
			dEndTime =  (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLilyStartTime;
	}

	if(!gProcessINI.m_sProcessOption.bTemperCompensationMode) // Temper ���� ��尡 �ƴϸ� ��ٸ� �ʿ� ����
		dEndTime = dWaitTime + 1;
	else
	{
		if(gProcessINI.m_sProcessOption.bWaitTemperDownForAGC) // ������ �Ź� ��ٸ��� �ɼ��� ���ϸ�
		{
			dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
			dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
		}
	}
	
	if(dWaitTime > dEndTime)
	{
		CString strMessage;
		strMessage.Format(_T("User can start. program start or drilling after %.0fsec \n%Try again after %.0fsec \n Temperature value occur reversal phenomenon, or must to down temperature."), dWaitTime, dWaitTime - dEndTime);
		ErrMessage(strMessage);
		return;
	}	
	
	if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("DrillEndTime\t%d\tLimit\t%.0f" ),   
							((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime,
							dWaitTime);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	// �µ����� ���� ���� ��

	m_nGridMode = 0;
	m_bAutoPause = FALSE;
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = pMotor->GetAOMStatus(); // 110607
		BOOL bScanner = pMotor->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		
		if(!bPower || !bShutter | !bAOM || !bScanner)
		{
			NotifyError(STDGNALM303, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			NotifyError(STDGNALM607, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		NotifyError(STDGNALM559, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		NotifyError(STDGNALM207, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}

	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
	::Sleep(500);

	int nHead = GetSelectedHead();
	
	BOOL bRet = FALSE;
	
	int nSuction1 = pMotor->GetCurrentSuction();
	BOOL b1stAcrylSuction = pMotor->GetCurrentAcrylSuction(TRUE);
	BOOL b2ndAcrylSuction = pMotor->GetCurrentAcrylSuction(FALSE);
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if(nSuction1 & 0x01 && bMotor) b1st = TRUE;
	if(nSuction1 & 0x02 && bMotor) b2nd = TRUE;
	
	if(nHead == 0)
	{
		if(!b1stAcrylSuction || !b2ndAcrylSuction)
		{
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		}
		
		if(b1st && b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else if(nHead == 1)
	{
		if(!b1stAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
		
		if(b1st)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else
	{
		if(!b2ndAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		
		if(b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}

	if(!bRet && !gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		NotifyError(STDGNALM423, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return;
	}

	m_bIsAutoProcessMode = FALSE;
	m_bAutoCalibration = FALSE;
	m_bVerifyCalibration = FALSE;

	OnCalibrationStart();
}

BOOL CPaneManualControlScannerCalibration::CalibrationStart()
{
	return OnCalibrationStart();
}

LRESULT CPaneManualControlScannerCalibration::OnCalibrationStart(WPARAM, LPARAM)
{
	if(!m_bAutoCalibration)
		m_bDryRunCheck = FALSE;
	
	UpdateData();

	m_bRestart = FALSE;
	m_bGetHeadOffset = FALSE;

	GetProcessScannerCal( &gProcessINI.m_sProcessScannerCal );

	if (m_pThread != NULL)
		MakeThreadClear();
	
	EnableCalibrationWindow(FALSE);
	if (m_bAutoCalibration)
	{
		int nRegCalRepeat = gProcessINI.m_sProcessCal.nAutoCalibrationCount;

		if (nRegCalRepeat <= m_nAutoProcessRepeat)
		{
			NotifyError(STDGNALM712, TRUE, _T(""), FALSE);
			EnableCalibrationWindow(TRUE);
			m_bAutoCalStop = TRUE;
			::SetEvent(g_hDoScalManual);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
			return 0L;
		}
		m_nAutoProcessRepeat++;
	}
		
	if (!UpdateData(TRUE))
	{
		EnableCalibrationWindow(TRUE);
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return 0L;
	}

	CWaitCursor wait;
	int nMaxCount = gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount*100;
	/*if(gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount == 2)
		nMaxCount = MAX_AUTOCAL_COUNT - 100;*/

	if (m_nCountAuto >= nMaxCount)		
	{
#ifndef __TEST__
		EnableCalibrationWindow(TRUE);
		NotifyError(IDS_SCAL_BOARD, !m_bDryRunCheck);
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);

		return 0L;
#else
		m_nCountAuto = 0;
#endif
	}

	BOOL bUseLowCam;
	GetCAmNumInfo(bUseLowCam, emNone);
	CalculateAutoStartPosition();

	CString strData;
	if(m_bIsAutoProcessMode)
	{
		gProcessINI.m_sProcessScannerCal.dScanXTemp = m_dCalculateStartXAuto;
		gProcessINI.m_sProcessScannerCal.dScanYTemp = m_dCalculateStartYAuto;
		if(m_nUserLevel <= 2)
		{	
			if(m_dCalculateStartXAuto < gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 ||
				m_dCalculateStartXAuto > gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 ||
				m_dCalculateStartYAuto < gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 ||
				m_dCalculateStartYAuto > gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				EnableCalibrationWindow(TRUE);
				NotifyError(-1, TRUE, _T("Auto S. Cal. Table Pos Error : Check the auto Scanner Cal. Position in Process Setup Tab"));
				return 0L;
			}
		}
	}
	else
	{
		double dScanX, dScanY;
		m_edtManualXPos.GetWindowText( strData );
		dScanX = atof(strData);
		m_edtManualYPos.GetWindowText( strData );
		dScanY = atof(strData);

		gProcessINI.m_sProcessScannerCal.dScanXTemp = dScanX;
		gProcessINI.m_sProcessScannerCal.dScanYTemp = dScanY;

		if(m_nUserLevel <= 2)
		{
			if(dScanX >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dScanX <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dScanY >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
				dScanY <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				CString strM;
				strM.Format(_T("S. Cal. Table Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
					gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
					gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
				NotifyError(-1, TRUE, strM);

				EnableCalibrationWindow(TRUE);
				return 0L;
			}
		}
	}

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if(m_bIsAutoProcessMode)
		{
			if(bUseLowCam)
			{
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowCalArea, 1);
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowCalArea, 3);
				this->SendMessage(UM_VISION_LAMP, 1, m_sProcessScannerCal.nUseTool);
				this->SendMessage(UM_VISION_LAMP, 3, m_sProcessScannerCal.nUseTool);
			}
			else
			{
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, 0);
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, 2);
				this->SendMessage(UM_VISION_LAMP, 0, m_sProcessScannerCal.nUseTool);
				this->SendMessage(UM_VISION_LAMP, 2, m_sProcessScannerCal.nUseTool);
			}
		}

		
	}

	if(m_bIsAutoProcessMode)
	{
		m_nCountAuto++;
	} 

	::Sleep(CALIBRATION_SLEEP);

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION ||
		gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		if(m_strPath.GetLength() < 1)
		{
			NotifyError(-1, !m_bDryRunCheck, _T("Select Job File"));
			EnableCalibrationWindow(TRUE);
			::SetEvent(g_hDoScalManual);

			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
			return 0L;
		}
		gDeviceFactory.GetVision()->LoadProject(m_strPath);
	}
	else
	{
		if(GetSelectedHead() != SEL_HEAD_SLAVE)
		{
			if(bUseLowCam)
			{
				CameraChange(1);
				::Sleep(50);
				gDeviceFactory.GetVision()->SetVisionZoom(1);
			}
			else
			{
				CameraChange(0);
				::Sleep(50);
				gDeviceFactory.GetVision()->SetVisionZoom(0);
			}
		}
		else
		{
			if(bUseLowCam)
			{
				CameraChange(3);
				::Sleep(50);
				gDeviceFactory.GetVision()->SetVisionZoom(3);
			}
			else
			{
				CameraChange(2);
				::Sleep(50);
				gDeviceFactory.GetVision()->SetVisionZoom(2);
			}
		}
		SetVisionInfo();
	}

	if (!UpdateData(FALSE))
	{
		EnableCalibrationWindow(TRUE);
		::SetEvent(g_hDoScalManual);

		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);

		return 0L;
	}
	
#ifndef __TEST__
	if (!CheckMotorPositionValidity())
	{
		NotifyError(IDS_SCAL_POSITION, !m_bDryRunCheck);
		EnableCalibrationWindow(TRUE);
		m_nCountAuto--;
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return 0L;
	}
#endif

	if(!DownloadASC())
	{
#ifndef __TEST__
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, "ASC");
		NotifyError(-1, !m_bDryRunCheck, strMsg);
		EnableCalibrationWindow(TRUE);
		m_nCountAuto--;
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return 0L;
#endif
	}
	
	if(m_bIsAutoProcessMode)
	{
		if(m_nStartCam%2 != 0)
		{
			if(gProcessINI.m_sProcessSystem.bUseGetHighCamOffset)
				m_bGetHeadOffset = TRUE;
		}
	}
	else
		m_bGetHeadOffset = FALSE;

#ifdef __3RDAOD__
	if(gProcessINI.m_sProcessScannerCal.bUseDummy)
	{
		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_FIELD)
		{
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
				{
					EnableCalibrationWindow(TRUE);
					return 0U;
				}
			}
		}
	}
	else
	{
		if(gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_FIELD)
		{
			if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					EnableCalibrationWindow(TRUE);
					ErrMsgDlg(STDGNALM781);
					return 0U;
				}
			}
		}
	}
#endif

	m_ThreadParam.pParent = this;
	m_ThreadParam.pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Main Thread Start event
	m_ThreadParam.pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Main Thread Stop event
	m_ThreadParam.pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Main Thread Finished event

	gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);

	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		NotifyError(-1, !m_bDryRunCheck, _T("Dust Suction Shutter On Error."));
		EnableCalibrationWindow(TRUE);
		m_nCountAuto--;
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return 0L;
	}

	gDeviceFactory.GetMotor()->TableClamp(TRUE);
	gDeviceFactory.GetMotor()->TableClamp(TRUE, FALSE);

	::AfxGetMainWnd()->SendMessage(UM_CAL_AUTO_SCAL_POS);

	m_pThread = ::AfxBeginThread(CalibrationThread, static_cast<LPVOID>(const_cast<AUTOCALTHREADPARAM*>(&m_ThreadParam)));
	if (m_pThread == NULL)
	{
		NotifyError(IDS_SCAL_THREAD_CREATE, TRUE);
		EnableCalibrationWindow(TRUE);
		if(m_bIsAutoProcessMode)
			m_nCountAuto--;
		::SetEvent(g_hDoScalManual);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return 0L;
	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
	
	CString strEvent, strInfo, strTemp;
	strEvent = _T("Started automatic scanner calibration.");

	if(m_bIsAutoProcessMode)
		strInfo = _T("Automatic Calibration | ");
	else
		strInfo = _T("Manual Calibration | ");

	
	strTemp.Format(_T("Grid size = %dx%d | Beam Path No. = %d | PCB Thickness = %f, %f mm | Start Position ( X = %f mm, Y = %f mm )"),
		GetDivision(), GetDivision(), GetMaskNo(), GetCalThick(), GetCalThick2nd(), GetCalStartX(), GetCalStartY());	
	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

	::SetEvent(m_ThreadParam.pHandle[0]);

	::Sleep(CALIBRATION_SLEEP);
	EnableCalibrationWindow(FALSE);	

	return 1L;
}

void CPaneManualControlScannerCalibration::OnButtonCalStop() 
{
	if (m_bIsAutoProcessMode)
		m_bAutoCalStop = TRUE;

	if (m_pThread == NULL)
		return;

	gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
	
	gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2); // 110219 ejpark C2 �߰� 
	
	if (m_pThread != NULL)
	{
		::SetEvent(m_ThreadParam.pHandle[1]);
		DWORD dwRetCode = ::WaitForSingleObject(m_ThreadParam.pHandle[2], WAIT_TIME);
		if (dwRetCode == WAIT_OBJECT_0)
		{
			MakeThreadClear();
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);// 20090629 Front Mode error
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);// 20090629 Front Mode error
			NotifyError(IDS_SCAL_THREAD_END, !m_bDryRunCheck);
		}
	}

	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);

	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			if(!m_bDryRunCheck)
			ErrMessage(_T("Dust Suction Shutter Off Error."));
		}
	}
	EnableCalibrationWindow(TRUE);

	
}

void CPaneManualControlScannerCalibration::OnSelchangeComboUseVision()
{
	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	
	pVision->OnCamChange( nCamNo );

	SetValue( nCamNo );
}

void CPaneManualControlScannerCalibration::OnSelchangeComboUseTool()
{
	int nBeamPathNo = m_cmbTool.GetCurSel();
	if(nBeamPathNo >= 0)
		ChangeLaserParam(nBeamPathNo);
	
	gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNoForMotor = nBeamPathNo;

	m_sProcessScannerCal.nUseTool = nBeamPathNo;
}

void CPaneManualControlScannerCalibration::SetValue(int nNumber)
{
	CString str;


	str.Format(_T("%d"), m_nCoaxial[nNumber]);
	m_edtCoaxial.SetWindowText(str);
	m_SliderCoaxial.SetPos(m_nCoaxial[nNumber]);

	str.Format(_T("%d"), m_nRing[nNumber]);
	m_edtRing.SetWindowText(str);
	m_SliderRing.SetPos(m_nRing[nNumber]);

	str.Format(_T("%d"), m_nIR[nNumber]);
	m_edtIR.SetWindowText(str);
	m_SliderIR.SetPos(m_nIR[nNumber]);

// 	str.Format(_T("%d"), m_nCoaxial[nNumber]);
// 	m_edtCoaxial2.SetWindowText(str);
// 
// 	str.Format(_T("%d"), m_nRing[nNumber]);
// 	m_edtRing2.SetWindowText(str);

	str.Format(_T("%.1f"), m_dContrast[nNumber]);
	m_edtContrast.SetWindowText(str);

	str.Format(_T("%.1f"), m_dBrightness[nNumber]);
	m_edtBrightness.SetWindowText(str);	
	
	UpdateData(FALSE);
}

void CPaneManualControlScannerCalibration::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntBtn3.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntStatic2.DeleteObject();
	m_fntListBox.DeleteObject();
	m_fntCombo.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlScannerCalibration::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		CRect rtPos;
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(SCANNER_CAL_VISION_VIEW);
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(SCANNER_CAL_VISION_VIEW);
		CRect rtPos;
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
	}
	GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->ShowWindow(SW_HIDE);
	int nCamNo = m_cmbUseVision.GetCurSel();
	OnCamChange( nCamNo );
}

void CPaneManualControlScannerCalibration::OnCamChange(int nCamNo)
{
	switch(nCamNo)
	{
	case 0:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
		break;
	case 1:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
		break;
	case 2:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
		break;
	case 3:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
		break;
	}
}

void CPaneManualControlScannerCalibration::OnMoveVisionView()
{
	CRect rtPos;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneManualControlScannerCalibration::OnKillfocusEdit()
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
	double dTempVal;
	int nCam = m_cmbUseVision.GetCurSel();

	m_edtCoaxial.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
	{
		m_SliderCoaxial.SetPos(nTempVal);
		m_nCoaxial[nCam] = nTempVal;
	}
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
	{
		m_SliderRing.SetPos(nTempVal);
		m_nRing[nCam] = nTempVal;
	}
	m_edtIR.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nIR[nCam] = nTempVal;
	m_edtBrightness.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
	{
		m_dBrightness[nCam] = dTempVal;
	}
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dContrast[nCam] = dTempVal;
}

void CPaneManualControlScannerCalibration::SetProcessScannerCal(SPROCESSSCANNERCAL sProcessScannerCal)
{
	memcpy( &m_sProcessScannerCal, &sProcessScannerCal, sizeof(m_sProcessScannerCal) );
	
	DispProcessScannerCal();
}

void CPaneManualControlScannerCalibration::GetProcessScannerCal(SPROCESSSCANNERCAL* pProcessScannerCal)
{
	SetControlToData();

	CString strMessage, strInfo, strTemp;
	strInfo.Format(_T(""));

	// Auto Division
	if(m_sProcessScannerCal.nAutoDivision != pProcessScannerCal->nAutoDivision)
	{
		strTemp.Format(_T("| AutoDivision = %d"), m_sProcessScannerCal.nAutoDivision);
		strInfo += strTemp;
	}
	// Auto 1st Thickness
	if(m_sProcessScannerCal.dAuto1stThickness != pProcessScannerCal->dAuto1stThickness)
	{
		strTemp.Format(_T("| AutoThick1 = %.3f"), m_sProcessScannerCal.dAuto1stThickness);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dAuto2ndThickness != pProcessScannerCal->dAuto2ndThickness)
	{
		strTemp.Format(_T("| AutoThick2 = %.3f"), m_sProcessScannerCal.dAuto2ndThickness);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dAutoStart.x != pProcessScannerCal->dAutoStart.x ||
		m_sProcessScannerCal.dAutoStart.y != pProcessScannerCal->dAutoStart.y)
	{
		strTemp.Format(_T("| Auto S.Pos. = %.3f, %.3f"), m_sProcessScannerCal.dAutoStart.x,
													m_sProcessScannerCal.dAutoStart.y);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.nManualDivision != pProcessScannerCal->nManualDivision)
	{
		strTemp.Format(_T("| M. Division = %d"), m_sProcessScannerCal.nManualDivision);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.nManualHead != pProcessScannerCal->nManualHead)
	{
		strTemp.Format(_T("| M. Head = %d"), m_sProcessScannerCal.nManualHead);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dManual1stThickness != pProcessScannerCal->dManual1stThickness)
	{
		strTemp.Format(_T("| M. Thick1 = %.3f"), m_sProcessScannerCal.dManual1stThickness);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dManual2ndThickness != pProcessScannerCal->dManual2ndThickness)
	{
		strTemp.Format(_T("| M. Thick2 = %.3f"), m_sProcessScannerCal.dManual2ndThickness);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dManualStart.x != pProcessScannerCal->dManualStart.x ||
		m_sProcessScannerCal.dManualStart.y != pProcessScannerCal->dManualStart.y)
	{
		strTemp.Format(_T("| M. S.Pos. = %.3f, %.3f"), m_sProcessScannerCal.dManualStart.x,
			m_sProcessScannerCal.dManualStart.y);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.dModelSize != pProcessScannerCal->dModelSize)
	{
		strTemp.Format(_T("| ModelSize = %.3f"), m_sProcessScannerCal.dModelSize);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dModelOrientation != pProcessScannerCal->dModelOrientation)
	{
		strTemp.Format(_T("| ModelOrientation = %.3f"), m_sProcessScannerCal.dModelOrientation);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.nModelPolarity != pProcessScannerCal->nModelPolarity)
	{
		strTemp.Format(_T("| ModelPolarity = %d"), m_sProcessScannerCal.nModelPolarity);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dSizeTolerance != pProcessScannerCal->dSizeTolerance)
	{
		strTemp.Format(_T("| ModelTolerance = %.3f"), m_sProcessScannerCal.dSizeTolerance);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dAngleTolerance != pProcessScannerCal->dAngleTolerance)
	{
		strTemp.Format(_T("| ModelAngleTol. = %.3f"), m_sProcessScannerCal.dAngleTolerance);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dAspectRatio != pProcessScannerCal->dAspectRatio)
	{
		strTemp.Format(_T("| ModelAspectR. = %.3f"), m_sProcessScannerCal.dAspectRatio);
		strInfo += strTemp;
	}
	if(m_sProcessScannerCal.dVisionZOffset != pProcessScannerCal->dVisionZOffset)
	{
		strTemp.Format(_T("| VisionZOffset. = %.3f"), m_sProcessScannerCal.dVisionZOffset);
		strInfo += strTemp;
	}

	for(int i=0; i<4; i++)
	{
		if(m_sProcessScannerCal.nCoaxial[i] != pProcessScannerCal->nCoaxial[i])
		{
			strTemp.Format(_T("| ModelCoaxial[%d] = %d"), i, m_sProcessScannerCal.nCoaxial[i]);
			strInfo += strTemp;
		}
		if(m_sProcessScannerCal.nRing[i] != pProcessScannerCal->nRing[i])
		{
			strTemp.Format(_T("| ModelRing[%d] = %d"), i,  m_sProcessScannerCal.nRing[i]);
			strInfo += strTemp;
		}
		if(m_sProcessScannerCal.dContrast[i] != pProcessScannerCal->dContrast[i])
		{
			strTemp.Format(_T("| ModelContrast[%d] = %.3f") , i, m_sProcessScannerCal.dContrast[i]);
			strInfo += strTemp;
		}
		if(m_sProcessScannerCal.dBrightness[i] != pProcessScannerCal->dBrightness[i])
		{
			strTemp.Format(_T("| Modelbright[%d] = %.3f") , i, m_sProcessScannerCal.dBrightness[i]);
			strInfo += strTemp;
		}
	}
	
	if(m_sProcessScannerCal.nUseTool != pProcessScannerCal->nUseTool)
	{
		strTemp.Format(_T("| BeamPath No = %d"), m_sProcessScannerCal.nUseTool);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.nShotCount != pProcessScannerCal->nShotCount)
	{
		strTemp.Format(_T("| Shot No = %d"), m_sProcessScannerCal.nShotCount);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.dDuty != pProcessScannerCal->dDuty)
	{
		strTemp.Format(_T("| Duty = %.3f"), m_sProcessScannerCal.dDuty);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.dAOMDelay != pProcessScannerCal->dAOMDelay)
	{
		strTemp.Format(_T("| AOM Delay = %.3f"), m_sProcessScannerCal.dAOMDelay);
		strInfo += strTemp;
	}

	if(m_sProcessScannerCal.dAOMDuty != pProcessScannerCal->dAOMDuty)
	{
		strTemp.Format(_T("| AOM Duty = %.3f"), m_sProcessScannerCal.dAOMDuty);
		strInfo += strTemp;
	}

	m_sProcessScannerCal.dMasterCalTablePosX = gProcessINI.m_sProcessScannerCal.dMasterCalTablePosX;
	m_sProcessScannerCal.dMasterCalTablePosY = gProcessINI.m_sProcessScannerCal.dMasterCalTablePosY;
	m_sProcessScannerCal.dSlaveCalTablePosX = gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX;
	m_sProcessScannerCal.dSlaveCalTablePosY = gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY;

	m_sProcessScannerCal.nVisionCountAuto = gProcessINI.m_sProcessScannerCal.nVisionCountAuto;

	memcpy( pProcessScannerCal, &m_sProcessScannerCal, sizeof(m_sProcessScannerCal) );
	
	if(0 != strInfo.CollateNoCase(""))
	{
		strMessage.Format(_T("Modify AGC Param."));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
#ifndef __MP920_MOTOR__
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
#else
			gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
			ErrMsgDlg(STDGNALM108);
			::Sleep(500);
#ifndef __MP920_MOTOR__
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
#else
			gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);
	}
}

void CPaneManualControlScannerCalibration::DispProcessScannerCal()
{
	CString strData;
			
	// Auto Division
	m_cmbAutoDivision.SetCurSel(m_sProcessScannerCal.nAutoDivision);

	// Auto Head
	m_cmbAutoHead.SetCurSel(m_sProcessScannerCal.nAutoHead);
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		m_cmbAutoHead.SetCurSel(1);

	// Auto 1st Thickness
	strData.Format(_T("%.2f"), m_sProcessScannerCal.dAuto1stThickness);
	m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );

//	if( 1 != gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
		// Auto 2nd Thickness
		strData.Format(_T("%.2f"), m_sProcessScannerCal.dAuto2ndThickness);
		m_edtAuto2ndThickness.SetWindowText( (LPCTSTR)strData );
//	}

	// Auto Start X
	strData.Format(_T("%.3f"), m_sProcessScannerCal.dAutoStart.x);
	m_edtAutoXPos.SetWindowText( (LPCTSTR)strData );

	// Auto Start Y
	strData.Format(_T("%.3f"), m_sProcessScannerCal.dAutoStart.y);
	m_edtAutoYPos.SetWindowText( (LPCTSTR)strData );

	// Use Tool
	m_cmbTool.SetCurSel(m_sProcessScannerCal.nUseTool);
	ChangeLaserParam(m_sProcessScannerCal.nUseTool);
//	OnSelchangeComboUseTool();

	// Manual Division
	m_cmbManualDivision.SetCurSel(m_sProcessScannerCal.nManualDivision);

	// Manual Head
	m_cmbManualHead.SetCurSel(m_sProcessScannerCal.nManualHead);
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		m_cmbManualHead.SetCurSel(1);

	if( 0 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		// Manual 1st Thickness
		strData.Format(_T("%.2f"), m_sProcessScannerCal.dManual1stThickness);
		m_edtManual1stThickness.SetWindowText( (LPCTSTR)strData );	
	}
	if( 1 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		// Manual 2nd Thickness
		strData.Format(_T("%.2f"), m_sProcessScannerCal.dManual2ndThickness);
		m_edtManual2ndThickness.SetWindowText( (LPCTSTR)strData );
	}

	// Manual Start X
	strData.Format(_T("%.3f"), m_sProcessScannerCal.dManualStart.x);
	m_edtManualXPos.SetWindowText( (LPCTSTR)strData );

	// Manual Start Y
	strData.Format(_T("%.3f"), m_sProcessScannerCal.dManualStart.y);
	m_edtManualYPos.SetWindowText( (LPCTSTR)strData );

	// Model Size
	strData.Format(_T("%.3f"), m_sProcessScannerCal.dModelSize);
	m_edtModelSize.SetWindowText( (LPCTSTR)strData );

	// Model Orientation
	strData.Format(_T("%.2f"), m_sProcessScannerCal.dModelOrientation);
	m_edtModelOrientation.SetWindowText( (LPCTSTR)strData );

	// Model Polarity
	m_nPolarity = m_sProcessScannerCal.nModelPolarity;

	// Size Tolerance
	strData.Format(_T("%.1f"), m_sProcessScannerCal.dSizeTolerance);
	m_edtSize.SetWindowText( (LPCTSTR)strData );

	// Angle Tolerance
	strData.Format(_T("%.1f"), m_sProcessScannerCal.dAngleTolerance);
	m_edtAngle.SetWindowText( (LPCTSTR)strData );

	// Aspect Ratio
	strData.Format(_T("%.1f"), m_sProcessScannerCal.dAspectRatio);
	m_edtAspectRatio.SetWindowText( (LPCTSTR)strData );

	// Vision Z Offset
	strData.Format(_T("%.1f"), m_sProcessScannerCal.dVisionZOffset);
	m_edtVisionZOffset.SetWindowText( (LPCTSTR)strData );

	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = m_sProcessScannerCal.nCoaxial[i];
		m_nRing[i] = m_sProcessScannerCal.nRing[i];
		m_nIR[i] = m_sProcessScannerCal.nIR[i];
		m_dContrast[i] = m_sProcessScannerCal.dContrast[i];
		m_dBrightness[i] = m_sProcessScannerCal.dBrightness[i];
	}
	SetValue( 0 );

	m_nCountAuto = m_sProcessScannerCal.nCountAuto;

	strData.Format(_T("%s"), m_sProcessScannerCal.szJobFilePath);
	m_edtPath.SetWindowText( (LPCTSTR)strData);

	UpdateData(FALSE);
}

void CPaneManualControlScannerCalibration::SetControlToData()
{
	UpdateData(TRUE);
	
	CString strData;

	// Auto Division
	m_sProcessScannerCal.nAutoDivision = m_cmbAutoDivision.GetCurSel();

	// Auto Mask
	m_sProcessScannerCal.nAutoMask = 0;

	// Auto Head
	m_sProcessScannerCal.nAutoHead = m_cmbAutoHead.GetCurSel();

	// Auto PulseWidth
	m_sProcessScannerCal.dAutoPulseWidth = 0.0;

	// Auto 1st Thickness
	m_edtAuto1stThickness.GetWindowText( strData );
	m_sProcessScannerCal.dAuto1stThickness = atof( (LPSTR)(LPCTSTR)strData );


//	if( 1 != gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
		// Auto 2nd Thickness
		m_edtAuto2ndThickness.GetWindowText( strData );
		m_sProcessScannerCal.dAuto2ndThickness = atof( (LPSTR)(LPCTSTR)strData );
//	}

	// Auto Start X
	m_edtAutoXPos.GetWindowText( strData );
	m_sProcessScannerCal.dAutoStart.x = atof( (LPSTR)(LPCTSTR)strData );

	// Auto Start Y
	m_edtAutoYPos.GetWindowText( strData );
	m_sProcessScannerCal.dAutoStart.y = atof( (LPSTR)(LPCTSTR)strData );

	// Use Tool
	m_sProcessScannerCal.nUseTool = m_cmbTool.GetCurSel();
	gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNoForMotor = m_sProcessScannerCal.nUseTool;
	// Manual Division
	m_sProcessScannerCal.nManualDivision = m_cmbManualDivision.GetCurSel();

	// Manual Mask
	m_sProcessScannerCal.nManualMask = 0;

	// Manual Head
	m_sProcessScannerCal.nManualHead = m_cmbManualHead.GetCurSel();

	// Manual PulseWidth
	m_sProcessScannerCal.dManualPulseWidth = 0.0;

	// Manual 1st Thickness
	m_edtManual1stThickness.GetWindowText( strData );
	m_sProcessScannerCal.dManual1stThickness = atof( (LPSTR)(LPCTSTR)strData );

//	if( 1 != gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
		// Manual 2nd Thickness
		m_edtManual2ndThickness.GetWindowText( strData );
		m_sProcessScannerCal.dManual2ndThickness = atof( (LPSTR)(LPCTSTR)strData );
//	}

	// Manaul Start X
	m_edtManualXPos.GetWindowText( strData );
	m_sProcessScannerCal.dManualStart.x = atof( (LPSTR)(LPCTSTR)strData );

	// Manual Start Y
	m_edtManualYPos.GetWindowText( strData );
	m_sProcessScannerCal.dManualStart.y = atof( (LPSTR)(LPCTSTR)strData );

	// Model Size
	m_edtModelSize.GetWindowText( strData );
	m_sProcessScannerCal.dModelSize = atof( (LPSTR)(LPCTSTR)strData );

	// Model Orientation
	m_edtModelOrientation.GetWindowText( strData );
	m_sProcessScannerCal.dModelOrientation = atof( (LPSTR)(LPCTSTR)strData );

	// Model Polarity
	m_sProcessScannerCal.nModelPolarity = m_nPolarity;

	// Size Tolerance
	m_edtSize.GetWindowText( strData );
	m_sProcessScannerCal.dSizeTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// Angle Tolerance
	m_edtAngle.GetWindowText( strData );
	m_sProcessScannerCal.dAngleTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// Aspect Ratio
	m_edtAspectRatio.GetWindowText( strData );
	m_sProcessScannerCal.dAspectRatio = atof( (LPSTR)(LPCTSTR)strData );

	// Vision Z Offset
	m_edtVisionZOffset.GetWindowText( strData );
	m_sProcessScannerCal.dVisionZOffset = atof( (LPSTR)(LPCTSTR)strData );


	int nNum = m_cmbUseVision.GetCurSel();

	// Coaxial
/*	m_edtCoaxial.GetWindowText( strData );
	m_nCoaxial[nNum] = atoi( (LPSTR)(LPCTSTR)strData );

	// Ring
	m_edtRing.GetWindowText( strData );
	m_nRing[nNum] = atoi( (LPSTR)(LPCTSTR)strData);

	// Contrast
	m_edtContrast.GetWindowText( strData );
	m_dContrast[nNum] = atof( (LPSTR)(LPCTSTR)strData);

	// Brightness
	m_edtBrightness.GetWindowText( strData );
	m_dBrightness[nNum] = atof( (LPSTR)(LPCTSTR)strData);
*/
	for(int i=0; i<4; i++)
	{
		m_sProcessScannerCal.nCoaxial[i] = m_nCoaxial[i];
		m_sProcessScannerCal.nRing[i] = m_nRing[i];
		m_sProcessScannerCal.nIR[i] = m_nIR[i];
		m_sProcessScannerCal.dContrast[i] = m_dContrast[i];
		m_sProcessScannerCal.dBrightness[i] = m_dBrightness[i];
	}

	m_sProcessScannerCal.nCountAuto = m_nCountAuto;

	// JobFilePath
	m_edtPath.GetWindowText( strData );
	m_strPath = strData;

	lstrcpy(m_sProcessScannerCal.szJobFilePath, (LPCSTR)m_strPath);
}

void CPaneManualControlScannerCalibration::OnBtnChangeBoard()
{
// 	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
// 	{
// 		ErrMsgDlg(STDGNALM108);
// 		return;
// 	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

 	CalculateAutoStartPosition();

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		return;
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2 &&
		m_cmbAutoHead.GetCurSel() >= 2)
	{
		NotifyError(IDS_NO_HEIGHTSENSOR2, !m_bDryRunCheck);
		return;
	}
	
	CDlgMeasuringPCBThickness dlgPcbHeight;
	dlgPcbHeight.SetBaseZ(gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
						  gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	dlgPcbHeight.m_bZCalEnable = FALSE;

	if(m_cmbAutoHead.GetCurSel() < 2 || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
	{
		double dOffsetX = gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetX;
		double dOffsetY = gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetY;
		
		double dPosX = 	m_dCalculateStartXAuto + dOffsetX;
		double dPosY = 	m_dCalculateStartYAuto + dOffsetY;
		dlgPcbHeight.SetPosition(dPosX, dPosY, 
								 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
								 gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		dlgPcbHeight.AutoSelectHead(m_cmbAutoHead.GetCurSel());
		dlgPcbHeight.SelectHead(m_cmbAutoHead.GetCurSel());
	}
	else
	{
		double dOffsetX = gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetX;
		double dOffsetY = gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetY;
		
		double dPosX = 	m_dCalculateStartXAuto + dOffsetX;
		double dPosY = 	m_dCalculateStartYAuto + dOffsetY;
		dlgPcbHeight.SetPosition(dPosX, dPosY, 
								 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
								 gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		dlgPcbHeight.AutoSelectHead(2);
		dlgPcbHeight.SelectHead(2);
	}
	dlgPcbHeight.ChangeHeadSelectStatus(FALSE);
	
	pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, TRUE);
	pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, TRUE);

	if(dlgPcbHeight.DoModal() != IDOK)
		return;

	double dThickness;
	CString strData;

	m_nCountAuto = 0;
	gProcessINI.m_sProcessScannerCal.nCountAuto = 0;
	gProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto = 0;
	gProcessINI.m_sProcessScannerCal.nVisionCountAuto = 0;
	m_sProcessScannerCal.nVisionCountAuto = 0;

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
	{
		ErrMsgDlg(STDGNALM108);
		return;
	}
	CalculateAutoStartPosition();

	if(m_cmbAutoHead.GetCurSel() == 0 && gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 2)
	{
		dThickness = dlgPcbHeight.GetHeight();
		strData.Format(_T("%.3f"), dThickness);
		m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto1stThickness = dThickness;
		if( dThickness <=0. )
		{
			NotifyError(STDGNALM702, TRUE, _T(""), FALSE);
			return;
		}

		dThickness = dlgPcbHeight.GetHeight(FALSE);
		strData.Format(_T("%.3f"), dThickness);
		m_edtAuto2ndThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto2ndThickness = dThickness;
		if( dThickness <=0. )
		{
			NotifyError(STDGNALM702, TRUE, _T(""), FALSE);
			return;
		}
	}
	else if(m_cmbAutoHead.GetCurSel() < 2 || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
	{
		dThickness = dlgPcbHeight.GetHeight();
		strData.Format(_T("%.3f"), dThickness);
		m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto1stThickness = dThickness;
		m_edtAuto2ndThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto2ndThickness = dThickness;
	}
	else
	{
		dThickness = dlgPcbHeight.GetHeight(FALSE);
		strData.Format(_T("%.3f"), dThickness);
		m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto1stThickness = dThickness;
		m_edtAuto2ndThickness.SetWindowText( (LPCTSTR)strData );
		m_sProcessScannerCal.dAuto2ndThickness = dThickness;
	}
	
	if( dThickness <=0. )
	{
		NotifyError(STDGNALM702, TRUE, _T(""), FALSE);
		return;
	}
}

void CPaneManualControlScannerCalibration::SetVisionInfo()
{
	SetControlToData();

	m_sVisionInfo.nModelType = 1;
	m_sVisionInfo.nPolarity = m_sProcessScannerCal.nModelPolarity;
	m_sVisionInfo.dSizeA = m_sProcessScannerCal.dModelSize;
	m_sVisionInfo.dSizeB = m_sProcessScannerCal.dModelSize;
	m_sVisionInfo.dSizeC = m_sProcessScannerCal.dModelSize;
	
	for(int i=0; i<4; i++)
	{
		m_sVisionInfo.nCoaxial[i] = m_sProcessScannerCal.nCoaxial[i];
		m_sVisionInfo.nRing[i] = m_sProcessScannerCal.nRing[i];
		m_sVisionInfo.dContrast[i] = m_sProcessScannerCal.dContrast[i];
		m_sVisionInfo.dBrightness[i] = m_sProcessScannerCal.dBrightness[i];
	}
	
	m_sVisionInfo.dScoreAngle = m_sProcessScannerCal.dAngleTolerance;
	m_sVisionInfo.dScoreSize = m_sProcessScannerCal.dSizeTolerance;
	m_sVisionInfo.dAspectRatio = m_sProcessScannerCal.dAspectRatio;

	CString strData;
	int nCamNo = m_cmbUseVision.GetCurSel();

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParam(MODEL_CIRCLE, nCamNo, m_sVisionInfo );
	SetValue(nCamNo);
}

void CPaneManualControlScannerCalibration::SetAutoProcessMode()
{
	m_bAutoCalibration = FALSE;
	m_bIsAutoProcessMode = TRUE;
	m_bVerifyCalibration = FALSE;
	m_nAutoProcessRepeat = 0;

	m_bAutoCalStop = FALSE;
	gVariable.m_sGlobal.bCalFalse = FALSE;
}

void CPaneManualControlScannerCalibration::SetAutoCalibration()
{
	SetAutoProcessMode();
	
	if(m_bDryRunCheck)
	{
		m_cmbAutoHead.SetCurSel(0);
		m_cmbUseVision.SetCurSel(1);
		m_chkSkipCheckBoard.SetCheck(TRUE);
	}
	else
		m_chkSkipCheckBoard.SetCheck(FALSE);

	m_bAutoCalibration = TRUE; // auto run�� auto calibration
	m_bVerifyCalibration = FALSE;
}

int CPaneManualControlScannerCalibration::GetMaskNo()
{
	return m_sProcessScannerCal.nUseTool;
}

int CPaneManualControlScannerCalibration::GetUseTool()
{
	return m_cmbTool.GetCurSel();
}

int CPaneManualControlScannerCalibration::GetDivision()
{
	if (m_bIsAutoProcessMode)
	{
		int nCalDivision = m_cmbAutoDivision.GetCurSel();
		
		if (nCalDivision == 0) return 3;
		if (nCalDivision == 1) return 5;
		if (nCalDivision == 2) return 9;
		if (nCalDivision == 3) return 17;
		if (nCalDivision == 4) return 33;
		if (nCalDivision == 5) return 65;
	}
	else
	{
		int nCalDivision = m_cmbManualDivision.GetCurSel();
		
		if (nCalDivision == 0) return 3;
		if (nCalDivision == 1) return 5;
		if (nCalDivision == 2) return 9;
		if (nCalDivision == 3) return 17;
		if (nCalDivision == 4) return 33;
		if (nCalDivision == 5) return 65;
	}
	return -1;
}

int CPaneManualControlScannerCalibration::GetSelectedHead()
{
	int nAuto, nManual;
	nAuto = m_cmbAutoHead.GetCurSel();
	nManual = m_cmbManualHead.GetCurSel();
	
	if(m_bAutoCalibration)
		return gDProject.m_nSeparation;
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		nAuto = nManual = 1;

	return (m_bIsAutoProcessMode) ? nAuto : nManual;
}

double CPaneManualControlScannerCalibration::GetCalThick()
{
	double dAuto, dManual;
	CString strData;
	m_edtAuto1stThickness.GetWindowText( strData );
	dAuto = atof(strData);
	m_edtManual1stThickness.GetWindowText( strData );
	dManual = atof(strData);

	return (m_bIsAutoProcessMode) ? dAuto : dManual;
}

double CPaneManualControlScannerCalibration::GetCalThick2nd()
{
	double dAuto, dManual;
	CString strData;
	m_edtAuto2ndThickness.GetWindowText( strData );
	dAuto = atof(strData);
	
	m_edtManual2ndThickness.GetWindowText( strData );
	dManual = atof(strData);

	return (m_bIsAutoProcessMode) ? dAuto : dManual;
}

double CPaneManualControlScannerCalibration::GetCalStartX()
{
//	double dAuto, dManual;
	double dManual;
	CString strData;
//	m_edtAutoXPos.GetWindowText( strData );
//	dAuto = atof(strData);
	m_edtManualXPos.GetWindowText( strData );
	dManual = atof(strData);

	return (m_bIsAutoProcessMode) ? m_dCalculateStartXAuto : dManual;
}

double CPaneManualControlScannerCalibration::GetCalStartY()
{
//	double dAuto, dManual;
	double dManual;
	CString strData;
//	m_edtAutoYPos.GetWindowText( strData );
//	dAuto = atof(strData);
	m_edtManualYPos.GetWindowText( strData );
	dManual = atof(strData);

	return (m_bIsAutoProcessMode) ? m_dCalculateStartYAuto : dManual;
}

BOOL CPaneManualControlScannerCalibration::GetAutoProcessMode()
{
	return m_bIsAutoProcessMode;
}

void CPaneManualControlScannerCalibration::EnableCalibrationWindow(BOOL bIsEnable)
{
	GetDescendantWindow(IDC_BUTTON_CAL_START_AUTO)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_OFFSET_VERIFY)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_OFFSET_VERIFY_NEXT)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_CAL_START)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_CHANGE_BOARD)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_X_GET_TIME)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_Y_GET_TIME)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_LIVE)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_TRAIN)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_BUTTON_TEST)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_CHECK_INSP_AREA)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_CHECK_SKIP_BOARD)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_COMBO_AUTO_DIVISION)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_COMBO_AUTO_HEAD)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_DIVISION)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_HEAD)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_COMBO_USE_VISION)->EnableWindow(bIsEnable);	
	GetDescendantWindow(IDC_COMBO_TOOL)->EnableWindow(bIsEnable);

	GetDescendantWindow(IDC_EDIT_VISION_Z_OFFSET)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_1ST_THICKNESS)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(bIsEnable);

	GetDescendantWindow(IDC_EDIT_MANUAL_1ST_THICKNESS)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_2ND_THICKNESS)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_X_POS)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_Y_POS)->EnableWindow(bIsEnable);

	GetDescendantWindow(IDC_EDIT_CONTRAST)->EnableWindow(bIsEnable);
	GetDescendantWindow(IDC_EDIT_BRIGHTNESS)->EnableWindow(bIsEnable);

	if(m_nUserLevel == 3)
	{
		GetDescendantWindow(IDC_EDIT_AUTO_X_POS)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_AUTO_Y_POS)->EnableWindow(bIsEnable);
	}
	else
	{
		GetDescendantWindow(IDC_EDIT_AUTO_X_POS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_AUTO_Y_POS)->EnableWindow(FALSE);
	}
	if(m_nUserLevel >= 2)
	{
		GetDescendantWindow(IDC_EDIT_AUTO_1ST_THICKNESS)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(bIsEnable);
	}
	else
	{
		GetDescendantWindow(IDC_EDIT_AUTO_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);
	}
	if(m_nUserLevel != 0)
	{

		GetDescendantWindow(IDC_EDIT_MODEL_SIZE)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_VISION_SIZE)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_VISION_ANGLE)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_VISION_ASPECT_RATIO)->EnableWindow(bIsEnable);
#ifndef __PUSAN_LDD__ 
		GetDescendantWindow(IDC_RADIO_DARK)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_RADIO_LIGHT)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_RADIO_IGNORE)->EnableWindow(bIsEnable);
#endif
		
		GetDescendantWindow(IDC_EDIT_SHOT_NO)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_DUTY)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_AOM_DELAY)->EnableWindow(bIsEnable);
		GetDescendantWindow(IDC_EDIT_AOM_DUTY)->EnableWindow(bIsEnable);
	}
	else
	{
		GetDescendantWindow(IDC_EDIT_AUTO_X_POS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_AUTO_Y_POS)->EnableWindow(FALSE);

//		GetDescendantWindow(IDC_EDIT_MODEL_SIZE)->EnableWindow(FALSE);
//		GetDescendantWindow(IDC_EDIT_VISION_SIZE)->EnableWindow(FALSE);
//		GetDescendantWindow(IDC_EDIT_VISION_ANGLE)->EnableWindow(FALSE);
//		GetDescendantWindow(IDC_EDIT_VISION_ASPECT_RATIO)->EnableWindow(FALSE);
#ifndef __PUSAN_LDD__
		GetDescendantWindow(IDC_RADIO_DARK)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_RADIO_LIGHT)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_RADIO_IGNORE)->EnableWindow(FALSE);
#endif		
		GetDescendantWindow(IDC_EDIT_SHOT_NO)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_DUTY)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_AOM_DELAY)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_AOM_DUTY)->EnableWindow(FALSE);
#ifdef __KUNSAN_SAMSUNG_LARGE__
		GetDescendantWindow(IDC_CHECK_INSP_AREA)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_CHECK_SKIP_BOARD)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_COMBO_AUTO_DIVISION)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_COMBO_AUTO_HEAD)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_COMBO_MANUAL_DIVISION)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_COMBO_MANUAL_HEAD)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_COMBO_USE_VISION)->EnableWindow(FALSE);	
//		GetDescendantWindow(IDC_COMBO_TOOL)->EnableWindow(FALSE);

		GetDescendantWindow(IDC_EDIT_VISION_Z_OFFSET)->EnableWindow(FALSE);
//		GetDescendantWindow(IDC_EDIT_AUTO_1ST_THICKNESS)->EnableWindow(FALSE);
//		GetDescendantWindow(IDC_EDIT_AUTO_2ND_THICKNESS)->EnableWindow(FALSE);

		GetDescendantWindow(IDC_EDIT_MANUAL_1ST_THICKNESS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_MANUAL_2ND_THICKNESS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_MANUAL_X_POS)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_MANUAL_Y_POS)->EnableWindow(FALSE);

		GetDescendantWindow(IDC_EDIT_CONTRAST)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_BRIGHTNESS)->EnableWindow(FALSE);

		GetDescendantWindow(IDC_EDIT_VISION_SIZE)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_MODEL_SIZE)->EnableWindow(FALSE);
		GetDescendantWindow(IDC_EDIT_VISION_ASPECT_RATIO)->EnableWindow(FALSE);

#endif
	}

	
	GetDescendantWindow(IDC_BUTTON_APPLY_BEAMPATH)->EnableWindow(bIsEnable);
		
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bIsEnable);

//	GetDescendantWindow(IDC_BUTTON_CAL_STOP)->EnableWindow(TRUE);
}

void CPaneManualControlScannerCalibration::WriteCalibrationStopEvent(BOOL bFinish)
{
	CString strEvent, strInfo, strTemp;
	
	if (bFinish)
		strEvent = _T("Finished automatic scanner calibration.");
	else
	{
		strEvent = _T("Stopped automatic scanner calibration on account of system failure or user's stop event.");
	}
	
	if (m_bIsAutoProcessMode)
	{
		strInfo = _T("Automatic Calibration | ");
	}
	else
	{
		strInfo = _T("Manual Calibration | ");
	}
	strTemp.Format(_T("Grid size = %dx%d | Beam Path No. = %d | PCB Thickness = %f, %f mm | Start Position ( X = %f mm, Y = %f mm )"),
		GetDivision(), GetDivision(), GetMaskNo(), GetCalThick(), GetCalThick2nd(), GetCalStartX(), GetCalStartY());
	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
}

void CPaneManualControlScannerCalibration::EnableAutoCalibrationResource(BOOL bEnable)
{
	GetDescendantWindow(IDC_COMBO_AUTO_DIVISION)			->EnableWindow(bEnable);
	GetDescendantWindow(IDC_COMBO_AUTO_HEAD)				->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_PULSE_WIDTH)			->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_1ST_THICKNESS)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_X_POS)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_AUTO_Y_POS)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_DIVISION)			->EnableWindow(bEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_HEAD)				->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_PULSE_WIDTH)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_1ST_THICKNESS)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_X_POS)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_Y_POS)				->EnableWindow(!bEnable);

	GetDescendantWindow(IDC_EDIT_VISION_Z_OFFSET)			->EnableWindow(!bEnable);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() != 1)
	{
		GetDescendantWindow(IDC_EDIT_AUTO_2ND_THICKNESS)		->EnableWindow(bEnable);
		GetDescendantWindow(IDC_EDIT_MANUAL_2ND_THICKNESS)		->EnableWindow(bEnable);
	}
}

void CPaneManualControlScannerCalibration::MakeThreadClear()
{
	if (m_ThreadParam.pHandle[0] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[0]);
	if (m_ThreadParam.pHandle[1] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[1]);
	if (m_ThreadParam.pHandle[2] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[2]);
	m_ThreadParam.pHandle[0] = m_ThreadParam.pHandle[1]
		= m_ThreadParam.pHandle[2] = INVALID_HANDLE_VALUE;
	m_pThread = NULL;
}

void CPaneManualControlScannerCalibration::CalculateAutoStartPosition()
{
	int nOpreationTime = m_nCountAuto;
	if(m_nGridMode == 4)
	{
		if(m_bLastPosSCalVerify) 
			nOpreationTime = m_nCountAuto - 1;
		else
		{
			if(m_nVerifyPosIndex < 1)
				m_nVerifyPosIndex = 1;
			if(m_nVerifyPosIndex > m_nCountAuto)
				m_nVerifyPosIndex = m_nCountAuto - 1;

			nOpreationTime = m_nVerifyPosIndex - 1;
		}
		m_nVerifyPosIndex = nOpreationTime;
	}

	int nField = nOpreationTime / 100;
	int nStartPosY = (nOpreationTime % 100) / 10;
	int nStartPosX = (nOpreationTime % 100) % 10;
	
	int nOffsetPosY = (nOpreationTime) / 19;
	int nOffsetPosX = (nOpreationTime) % 19;

	double dPosX, dPosY;
	CString strData;
	m_edtAutoXPos.GetWindowText( strData );
	dPosX = atof(strData);
	m_edtAutoYPos.GetWindowText( strData );
	dPosY = atof(strData);
	
	m_dCalculateStartYAuto = dPosY + (nStartPosY * 0.62);
	m_dCalculateStartXAuto = dPosX + (nStartPosX * 0.62) + (nField * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );//60);
	
	// 4��° �ʵ� �ϴ�
	m_dOffsetStartYAuto = dPosY + (nStartPosY * 0.62);
//	m_dOffsetStartXAuto = dPosX + (nStartPosX * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2 + (3 * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );
	m_dOffsetStartXAuto = dPosX + (nStartPosX * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2 + (gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );
}

BOOL CPaneManualControlScannerCalibration::CheckMotorPositionValidity()
{
	double dStartPosX = GetCalStartX();
	double dStartPosY = GetCalStartY();
	double dCalThick = GetCalThick();
	double dCalThick2nd = GetCalThick2nd();
	int nSelHead = GetSelectedHead();
	int nCam = m_cmbUseVision.GetCurSel();
	
	const double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	const double dHalfFieldSize = dFieldSize / 2.0;
	
	double dVisionZ1, dVisionZ2;

	BOOL bUseLowCam;
	if(nCam == 0 || nCam == 2)
		bUseLowCam = FALSE;
	else
		bUseLowCam = TRUE;
	
	if(bUseLowCam)
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}

	double dFireZ1, dFireZ2;

	dFireZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[m_sProcessScannerCal.nUseTool] - dCalThick;
	dFireZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[m_sProcessScannerCal.nUseTool] - dCalThick2nd;

		
	if (IsOutOfAxisValidity(AXIS_X, dStartPosX))
		return FALSE;
	if (IsOutOfAxisValidity(AXIS_Y, dStartPosY))
		return FALSE;

	double dHeadOffsetX, dHeadOffsetY;
	
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}

		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Z1, dVisionZ1))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z1, dFireZ1))
			return FALSE;
	}
	
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
		
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Z2, dVisionZ2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z2, dFireZ2))
			return FALSE;
	}

	return TRUE;
}

BOOL CPaneManualControlScannerCalibration::IsOutOfAxisValidity(int nAxis, double dVal)
{
	if (dVal < gSystemINI.m_sAxisInfo[nAxis].dLimitMinus || dVal > gSystemINI.m_sAxisInfo[nAxis].dLimitPlus)
		return TRUE;
	else
		return FALSE;
}

void CPaneManualControlScannerCalibration::CameraChange(int nCam)
{
	OnCamChange(nCam);

	m_cmbUseVision.SetCurSel(nCam);
}

void CPaneManualControlScannerCalibration::ApplyVisionParam(int nCam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnApplyVisionParam(MODEL_CIRCLE, nCam, m_sVisionInfo );
		SetValue(nCam);
	}
}

void CPaneManualControlScannerCalibration::OnInspectionArea()
{
	UpdateData(TRUE);

	BOOL bCheck = m_chkInspArea.GetCheck();
	int nCam = m_cmbUseVision.GetCurSel();
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if(bCheck)
		{
			gDeviceFactory.GetVision()->ShowArea(2, MODEL_CIRCLE, nCam);
			GetDlgItem(IDC_CHECK_INSP_AREA)->SetWindowText(_T("Apply ROI"));
			GetDlgItem(IDC_BUTTON_TEST)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_TRAIN)->EnableWindow(FALSE);
		}
		else
		{
			gDeviceFactory.GetVision()->ShowArea(0, MODEL_CIRCLE, nCam);
			GetDlgItem(IDC_CHECK_INSP_AREA)->SetWindowText(_T("Show ROI"));
			GetDlgItem(IDC_BUTTON_TEST)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_TRAIN)->EnableWindow(TRUE);
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		if(bCheck)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetInspectArea(TRUE);
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetInspectArea(FALSE);

			DPOINT dpStart, dpEnd;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->GetInspectArea(dpStart, dpEnd);
			gDeviceFactory.GetVision()->SetInspectArea(dpStart, dpEnd);
		}
	}
}

void CPaneManualControlScannerCalibration::WaitingThreadEnd()
{
	do {
		::Sleep(0);
		MessageLoop();

		if(!m_bAutoCalibration)
			break;
		
	} while(!m_bAutoCalStop);
}

void CPaneManualControlScannerCalibration::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}


void CPaneManualControlScannerCalibration::OnButtonLive() 
{
	m_bIsLive = !m_bIsLive;
	
	m_btnLive.SetClick( m_bIsLive );
	
	if( m_bIsLive )
	{
		m_btnLive.SetWindowText( _T("Stop\nLive") );
		m_btnTest.EnableWindow(FALSE);
		m_btnTrain.EnableWindow(FALSE);
		m_cmbUseVision.EnableWindow(FALSE);
		m_btnTrigger.EnableWindow(FALSE);
		m_btnTriggerAgc.EnableWindow(FALSE);
		m_btnShowDialog.EnableWindow(FALSE);
	}
	else
	{
		m_btnLive.SetWindowText( _T("Start\nLive") );
		m_btnTest.EnableWindow(TRUE);
		m_btnTrain.EnableWindow(TRUE);
		m_cmbUseVision.EnableWindow(TRUE);
		m_btnTrigger.EnableWindow(TRUE);
		m_btnTriggerAgc.EnableWindow(TRUE);
		m_btnShowDialog.EnableWindow(TRUE);
	}
	
	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive(nCamNo, m_bIsLive);
}


void CPaneManualControlScannerCalibration::OnButtonTest() 
{
	int nCamNo = m_cmbUseVision.GetCurSel();
	CString strMsg;

	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );
	else
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );

	m_stcVisionResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;
	
	CString strData;
	
	switch( nCamNo )
	{
	case HIGH_1ST_CAM :
	case LOW_1ST_CAM :
		b1st = TRUE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strMsg);
		break;
	case HIGH_2ND_CAM :
	case LOW_2ND_CAM :
		b1st = FALSE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strMsg);
		break;
	}

	if(m_lboxResult.GetCount() > 400) 
		m_lboxResult.DeleteString(0);
	
	m_lboxResult.AddString((LPCTSTR)strData);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);
}

void CPaneManualControlScannerCalibration::OnButtonTrain() 
{
	UpdateData();
	int nCamNo = m_cmbUseVision.GetCurSel();
	CString strData;
	
	// Model Type
	m_sVisionInfo.nModelType = 1;
	
	// Size A, B, C, Orientation
	m_edtModelSize.GetWindowText( strData );
	m_sVisionInfo.dSizeA	= atof( (LPSTR)(LPCTSTR)strData );
	m_sVisionInfo.dSizeB	= atof( (LPSTR)(LPCTSTR)strData );
	m_sVisionInfo.dSizeC	= atof( (LPSTR)(LPCTSTR)strData );
	
	// Polarity
	if( 2 == m_nPolarity )
		m_sVisionInfo.nPolarity = 3;
	else
		m_sVisionInfo.nPolarity = m_nPolarity;
	
	if(!ValidateValue())
		return;
	
	// Contast & Brightness
	m_edtContrast.GetWindowText( strData );
	m_dContrast[nCamNo] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtBrightness.GetWindowText( strData );
	m_dBrightness[nCamNo]	= atof( (LPSTR)(LPCTSTR)strData );
	
	// Accept Score
	m_edtSize.GetWindowText( strData );
	m_sVisionInfo.dScoreSize	= atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtAngle.GetWindowText( strData );
	m_sVisionInfo.dScoreAngle	= atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtAspectRatio.GetWindowText( strData );
	m_sVisionInfo.dAspectRatio	= atof( (LPSTR)(LPCTSTR)strData );

	// Light
	m_edtCoaxial.GetWindowText( strData );
	m_nCoaxial[nCamNo]		= atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtRing.GetWindowText( strData );
	m_nRing[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );

	m_edtIR.GetWindowText( strData );
	m_nIR[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );

	for(int i=0; i<4; i++)
	{
		m_sVisionInfo.nCoaxial[i] = m_nCoaxial[i];
		m_sVisionInfo.nRing[i] = m_nRing[i];
		m_sVisionInfo.nIR[i] = m_nIR[i];
		m_sVisionInfo.dContrast[i] = m_dContrast[i];
		m_sVisionInfo.dBrightness[i] = m_dBrightness[i];
		m_sProcessScannerCal.nRing[i] = m_nRing[i];
		m_sProcessScannerCal.nCoaxial[i] = m_nCoaxial[i];
		m_sProcessScannerCal.nIR[i] = m_nIR[i];
	}
	this->SendMessage(UM_VISION_LAMP, nCamNo, m_sProcessScannerCal.nUseTool);

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParam( MODEL_CIRCLE, nCamNo, m_sVisionInfo );
	
	

	OnButtonTest();
}

BOOL CPaneManualControlScannerCalibration::ValidateValue()
{
	CString strData;
	double dValue;
	int nValue;
	
	// Contast & Brightness
	m_edtContrast.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 1.0)
	{
		NotifyError(-1, TRUE, _T("0.0 <= Contrast <= 1.0"));
		m_edtContrast.SetFocus();
		return FALSE;
	}
	
	m_edtBrightness.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 1.0)
	{
		NotifyError(-1, TRUE, _T("0.0 <= Brightness <= 1.0"));
		m_edtBrightness.SetFocus();
		return FALSE;
	}
	
	// Accept Score
	m_edtSize.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 100.0)
	{
		NotifyError(-1, TRUE, _T("0.0 <= Size <= 100.0"));
		m_edtSize.SetFocus();
		return FALSE;
	}
	
	m_edtAngle.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 360.0)
	{
		NotifyError(-1, TRUE, _T("0.0 <= Angle <= 360.0"));
		m_edtAngle.SetFocus();
		return FALSE;
	}
	
	m_edtAspectRatio.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 100.0)
	{
		NotifyError(-1, TRUE, _T("0.0 <= Aspect Ratio <= 100.0"));
		m_edtAspectRatio.SetFocus();
		return FALSE;
	}
	
	// Light
	m_edtCoaxial.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		NotifyError(-1, TRUE, _T("0 <= Coaxial <= 255"));
		m_edtCoaxial.SetFocus();
		return FALSE;
	}
	
	m_edtRing.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		NotifyError(-1, TRUE, _T("0 <= Ring <= 255"));
		m_edtRing.SetFocus();
		return FALSE;
	}

	m_edtIR.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		NotifyError(-1, TRUE, _T("0 <= IR <= 255"));
		m_edtIR.SetFocus();
		return FALSE;
	}

	return TRUE;
}

void CPaneManualControlScannerCalibration::ChangeControl(BOOL bUse)
{
	GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CONTRAST_BRIGHNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_TOOL_SELECTION)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_MODEL_SIZE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_MODEL_ORIENTATION)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_MODEL_SIZE_MM)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_MODEL_ORIENTATION_DEG)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_SIZE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_SIZE_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ANGLE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ANGLE_DEG)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_ASPECT_RATIO)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_ASPECT_RATIO_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_MODEL_SIZE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_MODEL_ORIENTATION)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_DARK)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_IGNORE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_VISION_SIZE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_VISION_ANGLE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_VISION_ASPECT_RATIO)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_BRIGHTNESS)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_USE_VISION)->ShowWindow(bUse);
//	GetDlgItem(IDC_COMBO_USE_VISION)->ShowWindow(bUse);
	GetDlgItem(IDC_BUTTON_TRAIN)->ShowWindow(bUse);
	GetDlgItem(IDC_BUTTON_TEST)->ShowWindow(bUse);
	
	GetDlgItem(IDC_BUTTON_TRIGGER)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_TRIGGER_AGC)->ShowWindow(!bUse);
	GetDlgItem(IDC_STATIC_JOB_FILE)->ShowWindow(!bUse);
	GetDlgItem(IDC_EDIT_JOB_FILE)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_SHOW_DIALOG)->ShowWindow(!bUse);

	// Laser setting
	GetDlgItem(IDC_STATIC_LASER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SHOT_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_LM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_AOM_DELAY)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_AOM_DUTY)->ShowWindow(bUse);

	GetDlgItem(IDC_EDIT_SHOT_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_DUTY)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(bUse);

	GetDlgItem(IDC_STATIC_US)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_US2)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_US3)->ShowWindow(bUse);

	GetDlgItem(IDC_BUTTON_APPLY_BEAMPATH)->ShowWindow(bUse);

}

void CPaneManualControlScannerCalibration::OnButtonTrigger()
{
	CString strMsg;
	
	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );
	else
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );
	
	m_stcVisionResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	CString strData;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);
	strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
	strData.Format(_T("%s %s"), strPos, strMsg);
	
//	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
//	m_lboxResult.SetCurSel( 0 );	

	if(m_lboxResult.GetCount() > 400) 
		m_lboxResult.DeleteString(0);
	
	m_lboxResult.AddString((LPCTSTR)strData);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);
}

void CPaneManualControlScannerCalibration::OnButtonTriggerAgc()
{
	int nCamNo = m_cmbUseVision.GetCurSel();
	CString strMsg;
	
	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );
	else
		pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg );
	
	m_stcVisionResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	CString strData;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);
	strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
	strData.Format(_T("%s %s"), strPos, strMsg);
	
//	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
//	m_lboxResult.SetCurSel( 0 );	

	if(m_lboxResult.GetCount() > 400) 
		m_lboxResult.DeleteString(0);
	
	m_lboxResult.AddString((LPCTSTR)strData);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);
}

void CPaneManualControlScannerCalibration::OnButtonShowDialog()
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->ShowVisionDialog();
}

void CPaneManualControlScannerCalibration::OnButtonJobFileOpen()
{
	TCHAR BASED_CODE szFilter[] = _T("Job Files (*.Job)|*.job|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.Job"), NULL, dwFlags, szFilter);
	
	CString strPath;
	strPath.Format(_T("%s\\JobFile\\"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	dlg.m_ofn.lpstrInitialDir = strPath;
	
	if(IDOK != dlg.DoModal())
		return;
	
	m_strPath = dlg.GetPathName();
	
	m_edtPath.SetWindowText(m_strPath);
}

void CPaneManualControlScannerCalibration::ResetLive()
{
	if( FALSE == m_bIsLive )
		return;
	
	m_bIsLive = !m_bIsLive;
	m_btnLive.SetClick(m_bIsLive);
	m_btnLive.SetWindowText( _T("Start\nLive") );
	m_btnTest.EnableWindow(TRUE);
	m_btnTrain.EnableWindow(TRUE);
	m_cmbUseVision.EnableWindow(TRUE);
	m_btnTrigger.EnableWindow(TRUE);
	m_btnTriggerAgc.EnableWindow(TRUE);
	m_btnShowDialog.EnableWindow(TRUE);

	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive(nCamNo, m_bIsLive);
}

LRESULT CPaneManualControlScannerCalibration::ChangeVisionParam(WPARAM wParam, LPARAM lPatam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnApplyVisionParam(MODEL_CIRCLE, wParam, m_sVisionInfo );
		SetValue(wParam);
	}
	return 1L;
}
LRESULT CPaneManualControlScannerCalibration::GetVisionResult(WPARAM wParam, LPARAM lParam)
{
	m_dFoundSize = 0;
	HVision* pVision = gDeviceFactory.GetVision();
	int nResult = pVision->GetNoGrabRealPos(&dpRealPos, wParam, lParam, FALSE, myResultChar, m_dFoundSize);

	if(nResult == 1)
		return TRUE;
	else
		return FALSE;
}

LRESULT CPaneManualControlScannerCalibration::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}

void CPaneManualControlScannerCalibration::OnButtonXGetTime() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		if(!m_bDryRunCheck)
			ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}


	// TODO: Add your control notification handler code here
	m_bAutoPause = FALSE;
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = pMotor->GetAOMStatus(); // 110607
		BOOL bScanner = pMotor->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			NotifyError(STDGNALM303, TRUE, _T(""), FALSE);
			return;
		}
	}

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		NotifyError(STDGNALM559, TRUE, _T(""), FALSE);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		NotifyError(STDGNALM207, TRUE, _T(""), FALSE);
		return;
	}

	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
	::Sleep(500);

	int nHead = GetSelectedHead();
	
	BOOL bRet = FALSE;
	
	int nSuction1 = pMotor->GetCurrentSuction();
	BOOL b1stAcrylSuction = pMotor->GetCurrentAcrylSuction(TRUE);
	BOOL b2ndAcrylSuction = pMotor->GetCurrentAcrylSuction(FALSE);
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if(nSuction1 & 0x01 && bMotor) b1st = TRUE;
	if(nSuction1 & 0x02 && bMotor) b2nd = TRUE;
	
	if(nHead == 0)
	{
		if(!b1stAcrylSuction || !b2ndAcrylSuction)
		{
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		}
		
		if(b1st && b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else if(nHead == 1)
	{
		if(!b1stAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
		
		if(b1st)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else
	{
		if(!b2ndAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		
		if(b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	
	if(!bRet)
	{
		NotifyError(STDGNALM423, TRUE, _T(""), FALSE);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return;
	}

	m_bIsAutoProcessMode = FALSE;
	m_bAutoCalibration = FALSE;
	
	m_nGridMode = 3;
	CString strData;
	m_edtGridXNo.GetWindowText( strData );
	m_nGridXNo = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtGridYNo.GetWindowText( strData );
	m_nGridYNo = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtGridGap.GetWindowText( strData );
	m_nGridSize = atoi( (LPSTR)(LPCTSTR)strData );
	
	if(m_nGridXNo < 2 || m_nGridYNo < 2)
	{
		CString strmsg = _T("");
		strmsg.Format(_T("Grid X and Y need over 2\n now X = %d, Y = %d"), m_nGridXNo, m_nGridYNo);
		ErrMessage(strmsg);
		return;
	}

	OnCalibrationStart();
}

void CPaneManualControlScannerCalibration::OnButtonYGetTime() 
{
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	if(m_bOKMaster)
	{
		gDeviceFactory.GetEocard()->UpdateLaserCalibrationFile(strCalPath, TRUE);
		m_bOKMaster = FALSE;
	}
	if(m_bOKSlave)
	{
		gDeviceFactory.GetEocard()->UpdateLaserCalibrationFile(strCalPath, FALSE);
		m_bOKSlave = FALSE;
	}
}

void CPaneManualControlScannerCalibration::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		GetDlgItem(IDC_BUTTON_X_GET_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_Y_GET_TIME)->ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_EDIT_GRID_GAP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_GRID_GAP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_GRID_X_NO)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_COMMA)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_GRID_Y_NO)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_BUTTON_APPLY_BEAMPATH)->ShowWindow(SW_HIDE);
		break;
	case 2:
	case 3:
		GetDlgItem(IDC_BUTTON_X_GET_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_Y_GET_TIME)->ShowWindow(SW_SHOW);
		
		GetDlgItem(IDC_EDIT_GRID_GAP)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STC_GRID_GAP)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_GRID_X_NO)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STC_COMMA)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_GRID_Y_NO)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_BUTTON_APPLY_BEAMPATH)->ShowWindow(SW_SHOW);
		break;
	}
	EnableCalibrationWindow(TRUE);
}

void CPaneManualControlScannerCalibration::SetToolComboBox()
{
	m_cmbTool.ResetContent();
	
	CString strTool;

	m_nCountAuto = gProcessINI.m_sProcessScannerCal.nCountAuto ;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbTool.AddString(strTool);
	}
	if(gBeamPathINI.m_sBeampath.nLastIndex >= m_sProcessScannerCal.nUseTool && m_sProcessScannerCal.nUseTool >= 0)
	{
		m_cmbTool.SetCurSel(m_sProcessScannerCal.nUseTool);
		ChangeLaserParam(m_sProcessScannerCal.nUseTool);
	}
	else
		m_sProcessScannerCal.nUseTool = -1;

	SUBTOOLDATA subTool;
	BOOL bProjectOpen = FALSE;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		for(int j = 0; j < gDProject.m_pToolCode[i]->m_SubToolData.GetCount(); j++)
		{
			if(gDProject.GetSubTool(i, j, subTool))
			{
				m_sProcessScannerCal.nUseTool = subTool.nMask;
				m_cmbTool.SetCurSel(m_sProcessScannerCal.nUseTool);
				ChangeLaserParam(m_sProcessScannerCal.nUseTool);
				bProjectOpen = TRUE;
			}
			if(bProjectOpen)
				return;
		}
	}
	if(!bProjectOpen)
		m_sProcessScannerCal.nUseTool = -1;
}

void CPaneManualControlScannerCalibration::OnButtonApplyBeampath() 
{
	
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeBeamPath_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}
	
	file.SeekToEnd();

	strDetail = _T("----------------------------------------------------------------------------------------------\n");
	file.Write(strDetail, strDetail.GetLength());

	strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
	file.Write(strDetail, strDetail.GetLength());



	// TODO: Add your control notification handler code here
	int nIndex = m_cmbTool.GetCurSel();
	if(gBeamPathINI.m_sBeampath.nLastIndex >= nIndex && nIndex >= 0)
	{
		UpdateData();
		CString strData;

		int nCam = m_cmbUseVision.GetCurSel();
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] != nCam)
		{
			str.Format(_T("%d Scanner Cam : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex], nCam );
		}
		if(nCam == LOW_1ST_CAM || nCam == LOW_2ND_CAM)
			gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] = 1; // low
		else
			gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] = 0; // high

		// Model Size
		m_edtModelSize.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerVisionModelSize[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Size : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerVisionModelSize[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerVisionModelSize[nIndex] = atof(strData);
		
		// Model Polarity
		if(gBeamPathINI.m_sBeampath.nScannerPolarity[nIndex] != m_nPolarity)
		{
			str.Format(_T("%d Scanner Polarity : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nScannerPolarity[nIndex], m_nPolarity );
		}
		gBeamPathINI.m_sBeampath.nScannerPolarity[nIndex] = m_nPolarity;
		
		// Size Tolerance
		m_edtSize.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Accept Size : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[nIndex] = atof(strData);
		
		// Aspect Ratio
		m_edtAspectRatio.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Accept Ratio : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[nIndex] = atof(strData);
		
		m_edtContrast.GetWindowText(strData);
		if(gBeamPathINI.m_sBeampath.dScannerContrast[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Accept Contrast : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerContrast[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerContrast[nIndex] = atof(strData);

		m_edtBrightness.GetWindowText(strData);
		if(gBeamPathINI.m_sBeampath.dScannerBrightness[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Bright : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerBrightness[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerBrightness[nIndex] = atof(strData);
		
		// Shot no.
		m_edtShotNo.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.nScannerTotalShot[nIndex] != atoi(strData))
		{
			str.Format(_T("%d Scanner Total Shot : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nScannerTotalShot[nIndex], atoi(strData) );
		}
		gBeamPathINI.m_sBeampath.nScannerTotalShot[nIndex] = atoi(strData);
		
		// duty
		m_edtDuty.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerDuty[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner Duty : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerDuty[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerDuty[nIndex] = atof(strData);
		
		// AOM delay
		m_edtAOMDelay.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerAomdelay[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner AOM Delay : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerAomdelay[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerAomdelay[nIndex] = atof(strData);
		
		// AOM duty
		m_edtAOMDuty.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dScannerAomDuty[nIndex] != atof(strData))
		{
			str.Format(_T("%d Scanner AOM Duty : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dScannerAomDuty[nIndex], atof(strData) );
		}
		gBeamPathINI.m_sBeampath.dScannerAomDuty[nIndex] = atof(strData);
	
		if(nCam == LOW_1ST_CAM)/* || nCam == HIGH_1ST_CAM)*/
		{
			m_edtCoaxial.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerCoaxial[nIndex] = atoi(strData);
			m_edtRing.GetWindowText( strData );
 			gBeamPathINI.m_sBeampath.nScannerRing[nIndex] = atoi(strData);
			m_edtIR.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerIR[nIndex] = atoi(strData);
		}
		else if(nCam == HIGH_1ST_CAM)
		{
 			m_edtCoaxial.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerCoaxial[nIndex] = atoi(strData);
			m_edtRing.GetWindowText( strData );
 			gBeamPathINI.m_sBeampath.nScannerRing[nIndex] = atoi(strData);
			m_edtIR.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerIR[nIndex] = atoi(strData);
		}
		else if(nCam == HIGH_2ND_CAM)
		{
	 		m_edtCoaxial.GetWindowText( strData );
 			gBeamPathINI.m_sBeampath.nScannerCoaxial2[nIndex] = atoi(strData);
			m_edtRing.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerRing2[nIndex] = atoi(strData);
			m_edtIR.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerIR2[nIndex] = atoi(strData);
		}
		else if(nCam == LOW_2ND_CAM)
		{
			m_edtCoaxial.GetWindowText( strData );
 			gBeamPathINI.m_sBeampath.nScannerCoaxial2[nIndex] = atoi(strData);
			m_edtRing.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerRing2[nIndex] = atoi(strData);
			m_edtIR.GetWindowText( strData );
			gBeamPathINI.m_sBeampath.nScannerIR2[nIndex] = atoi(strData);
		}
 		
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
		else
		{
			ErrMessage(IDS_DATA_CHANGED);
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SYSTEM_BEAMPATH);
	}
}

void CPaneManualControlScannerCalibration::ChangeLaserParam(int nIndex)
{
	CString strData;
	if(nIndex > gBeamPathINI.m_sBeampath.nLastIndex)
		return;

	int nCam = m_cmbUseVision.GetCurSel();
	if(nCam <= LOW_1ST_CAM)
	{
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] == 0) // high
		{
			m_cmbUseVision.SetCurSel(HIGH_1ST_CAM);
			gDeviceFactory.GetVision()->OnCamChange( HIGH_1ST_CAM );
		}
		else
		{
			m_cmbUseVision.SetCurSel(LOW_1ST_CAM);
			gDeviceFactory.GetVision()->OnCamChange( LOW_1ST_CAM );
		}
	}
	else
	{
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] == 0) // high
		{
			m_cmbUseVision.SetCurSel(HIGH_2ND_CAM);
			gDeviceFactory.GetVision()->OnCamChange( HIGH_2ND_CAM );
		}
		else
		{
			m_cmbUseVision.SetCurSel(LOW_2ND_CAM);
			gDeviceFactory.GetVision()->OnCamChange( LOW_2ND_CAM );
		}
	}
	// Model Size
	strData.Format(_T("%.3f"), gBeamPathINI.m_sBeampath.dScannerVisionModelSize[nIndex]);
	m_edtModelSize.SetWindowText( (LPCTSTR)strData );
	
	// Model Polarity
	m_nPolarity = gBeamPathINI.m_sBeampath.nScannerPolarity[nIndex];
	
	// Size Tolerance
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[nIndex]);
	m_edtSize.SetWindowText( (LPCTSTR)strData );
	
	// Aspect Ratio
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[nIndex]);
	m_edtAspectRatio.SetWindowText( (LPCTSTR)strData );
	
	for(int i = 0; i < 4; i++)
	{
		if(i <= LOW_1ST_CAM)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] == 0) 
			{
				m_nCoaxial[0] = gBeamPathINI.m_sBeampath.nScannerCoaxial[nIndex];
				m_nRing[0] = gBeamPathINI.m_sBeampath.nScannerRing[nIndex];
				m_nIR[0] = gBeamPathINI.m_sBeampath.nScannerIR[nIndex];
				m_nCoaxial[1] = 0;
				m_nRing[1] = 0;
				m_nIR[1] = 0;
			}
			else
			{
				m_nCoaxial[0] = 0;
				m_nRing[0] = 0;
				m_nIR[0] = 0;
				m_nCoaxial[1] = gBeamPathINI.m_sBeampath.nScannerCoaxial[nIndex];
				m_nRing[1] = gBeamPathINI.m_sBeampath.nScannerRing[nIndex];
				m_nIR[1] = gBeamPathINI.m_sBeampath.nScannerIR[nIndex];
			}
		}
		else
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex] == 0) 
			{
				m_nCoaxial[2] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[nIndex];
				m_nRing[2] = gBeamPathINI.m_sBeampath.nScannerRing2[nIndex];
				m_nIR[2] = gBeamPathINI.m_sBeampath.nScannerIR2[nIndex];
				m_nCoaxial[3] = 0;
				m_nRing[3] = 0;
				m_nIR[3] = 0;
			}
			else
			{
				m_nCoaxial[2] = 0;
				m_nRing[2] = 0;
				m_nIR[2] = gBeamPathINI.m_sBeampath.nScannerIR2[nIndex];
				m_nCoaxial[3] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[nIndex];
				m_nRing[3] = gBeamPathINI.m_sBeampath.nScannerRing2[nIndex];
				m_nIR[3] = gBeamPathINI.m_sBeampath.nScannerIR2[nIndex];
			}
			
		}
		m_dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[nIndex];
		m_dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[nIndex];
	}
	SetValue( nCam );

	// Shot no.
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nScannerTotalShot[nIndex]);
	m_edtShotNo.SetWindowText( (LPCTSTR)strData );
	
	// duty
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dScannerDuty[nIndex]);
	m_edtDuty.SetWindowText( (LPCTSTR)strData );
	
	// AOM delay
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dScannerAomdelay[nIndex]);
	m_edtAOMDelay.SetWindowText( (LPCTSTR)strData );
	
	// AOM duty
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dScannerAomDuty[nIndex]);
	m_edtAOMDuty.SetWindowText( (LPCTSTR)strData );
	
	UpdateData(FALSE);
}

BOOL CPaneManualControlScannerCalibration::DownloadASC()
{
	CString strString, strMsg;
	strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
	strMsg.Format(strString, "ASC");

	if(m_sProcessScannerCal.nUseTool == -1)
	{
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}

	CString strMaster, strSlave;
	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_sProcessScannerCal.nUseTool]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_sProcessScannerCal.nUseTool]);
	
	TCHAR sz1stFile[255], sz2ndFile[255];
	lstrcpy(sz1stFile, strMaster);
	lstrcpy(sz2ndFile, strSlave);

	if(!InitAGCInfo(sz1stFile, sz2ndFile))
	{
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s : ASC dll Set Fail"), m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
	
	if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, _T("ASC"));
		ErrMessage(strMsg);

		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
	return TRUE;
}

void CPaneManualControlScannerCalibration::GetLaserParam(SUBTOOLDATA &subToolResult)
{
	subToolResult.nSubToolNo = 1;
	subToolResult.nToolType = SHOT_DRILL_TYPE;
	
	// Mark
//	subToolResult.nDrawStep;
//	subToolResult.nJumpStep;
//	subToolResult.nJumpStepPeriod;
//	subToolResult.nDrawStepPeriod;
//	subToolResult.nCornerDelay;
	subToolResult.nJumpDelay = (int)(gBeamPathINI.m_sBeampath.dScannerJumpDelay);
//	subToolResult.nLineDelay;
	subToolResult.nLaserOnDelay = 1;
	subToolResult.nLaserOffDelay = 1;
	subToolResult.nFrequency = 1000;
//	subToolResult.nFPS;
//	subToolResult.dCurrent;
//	subToolResult.dA1; 
//	subToolResult.dA2;
	
	// Shot no.
	CString strData;
	m_edtShotNo.GetWindowText( strData );
	int nShotNo = atoi(strData);
	
	// duty
	m_edtDuty.GetWindowText( strData );
	double dDuty = atof(strData);
	
	// AOM delay
	m_edtAOMDelay.GetWindowText( strData );
	double dAOMDelay = atof(strData);
	
	// AOM duty
	m_edtAOMDuty.GetWindowText( strData );
	double dAOMDuty = atof(strData);
	// Drill
	subToolResult.nShotMode = 1; // cycle mode
	subToolResult.nTotalShot = nShotNo;
	subToolResult.nBurstShot = 1;
	subToolResult.nMask = m_sProcessScannerCal.nUseTool;
	subToolResult.bUseTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_sProcessScannerCal.nUseTool];

	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < subToolResult.nTotalShot; i++)
	{
		subToolResult.dShotDuty[i] = dDuty;
		subToolResult.dShotAOMDelay[i] = dAOMDelay;
		subToolResult.dShotAOMDuty[i] = dAOMDuty;

		subToolResult.dShotDutyOffsetM[i] = 0;
		subToolResult.dShotDutyOffsetS[i] = 0;
		subToolResult.dShotVolOffsetM[i] = 0;
		subToolResult.dShotVolOffsetS[i] = 0;

		strcpy_s(subToolResult.cAOMFilePath[i], strAOMFile);
	}
	subToolResult.bUseAperture = FALSE;
	subToolResult.nApertureBurst = 1;
//	subToolResult.nThermalTrack;
	subToolResult.dZOffset = 0;
	subToolResult.nFPS = 0;
	// Flying
//	subToolResult.nLeadIn;
//	subToolResult.nLeadOut;
//	subToolResult.nTableSpeed;
	
	// Barcode
//	subToolResult.bFlipX;
//	subToolResult.bFlipY;
//	subToolResult.nRotate;
	
	// Memo
	subToolResult.cToolMemo[0] = NULL;
//	subToolResult.dMinPower;
//	subToolResult.dMaxPower;
//	subToolResult.dHoleSize;

}

void CPaneManualControlScannerCalibration::OnCheckSkipBoard() 
{
	// TODO: Add your control notification handler code here
	m_sProcessScannerCal.bIsSkipCheckBoard = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard = m_chkSkipCheckBoard.GetCheck();
}

BOOL CPaneManualControlScannerCalibration::InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave)
{
	if(!m_calAGCMaster.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	TCHAR szBackupFolder[255];
	lstrcpy(szBackupFolder, gEasyDrillerINI.m_clsDirPath.GetBackupDir());
	m_calAGCMaster.SetBackupFolder(szBackupFolder);
	if(!m_calAGCMaster.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCMaster.SetAGCInfo(GetDivision(), strMaster, FALSE, TRUE))
		return FALSE;

	if(!m_calAGCSlave.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	m_calAGCSlave.SetBackupFolder(szBackupFolder);
	if(!m_calAGCSlave.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCSlave.SetAGCInfo(GetDivision(), strSlave, FALSE, TRUE))
		return FALSE;
	
	return TRUE;
}

void CPaneManualControlScannerCalibration::SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
														  int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
														  int ndiff, int nJobType)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strpathName+=_T("JobTime");
	CTime  curDate = CTime::GetCurrentTime();
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//�켱 ���� �˻�
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	
	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strType;
		if(nJobType == PREHEAT_JOB)
			strType.Format(_T("H"));
		else if(nJobType == SCAL_JOB)
			strType.Format(_T("S"));
		else if(nJobType == POWER_JOB)
			strType.Format(_T("P"));
		else
			strType.Format(_T("D"));
		
		strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
			strType,
			nStartYear, nStartMonth, nStartDay, nStartHour, nStartMin, nStartSec, 
			nEndYear, nEndMonth, nEndDay, nEndHour, nEndMin, nEndSec,
			ndiff);
		
		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();

	// copy
	CString strFileName, strMovePath;
	strFileName.Format(_T("JobTime%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strMovePath.Format(_T("%s%d\\%s"), gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo, strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
}

void CPaneManualControlScannerCalibration::SaveSCalResult(BOOL bApplyed)
{
	int nSelHead = GetSelectedHead();
	int nDivision = GetDivision();
	int nCam = m_cmbUseVision.GetCurSel();

	if(!bApplyed)
	{
		if(!m_bDryRunCheck)
			PostMessage(UM_THREAD_FINISHED);
		else
		{
			if (m_bIsAutoProcessMode)
			{		
				if(m_bDryRunCheck)
				{
					CString strEvent, strInfo;
					if(nSelHead == SEL_HEAD_BOTH)
					{					
						strEvent = _T("Automatic scanner calibration result.");
						strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um ) | 2nd Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um)"),
							m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000, m_dMaxOffsetMasterR*1000, 
							m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000, m_dMaxOffsetSlaveR*1000);
					
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
					}
					else if(nSelHead == SEL_HEAD_MASTER)
					{
						strEvent = _T("Automatic scanner calibration result.");
						strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um )"),
							m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000, m_dMaxOffsetMasterR*1000);
					
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
					}
					else if(nSelHead == SEL_HEAD_SLAVE)
					{
						strEvent = _T("Automatic scanner calibration result.");
						strInfo.Format(_T("2nd Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um  )"),
							m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000, m_dMaxOffsetSlaveR*1000);
					
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
					}
				}
				m_bAutoCalStop = TRUE;
				m_bIsAutoProcessMode = FALSE;
				m_bAutoCalibration = FALSE;
				if (m_pThread != NULL)
				{
					::WaitForSingleObject(m_ThreadParam.pHandle[2], INFINITE);
					MakeThreadClear();
				}
				EnableCalibrationWindow(TRUE);
			}
			m_bDryRunCheck = FALSE;
		}
	}

	if(!bApplyed)
		return;

	BOOL bSuccess = FALSE;
#ifdef __2016_KUNSAN__ //20190621

	if(fabs(m_dMaxOffsetMasterX*1000) <= 12 && fabs(m_dMaxOffsetMasterY*1000) <= 12 && 
		fabs(m_dMaxOffsetSlaveX*1000) <= 12 && fabs(m_dMaxOffsetSlaveY*1000) <= 12)// drilling less than 12 .
	{
		bSuccess = TRUE;
	}

	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strPathName2 = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	CString strPathName3;
	strPathName3.Format(_T("%sBackup\\"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	strPathName += _T("SCalLog");
	strPathName2 += _T("PreworkDetailLog");
	strPathName3 += _T("TempResult");//20190621

	CTime curDate = CTime::GetCurrentTime();

	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;
	strPathName2 += strCurTime;
	strPathName3 += strCurTime;//20190621

	if(bSuccess)
	{
		CStdioFile file;
		if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
			return;

		CString strBuf;
		CString strCam, strPanel, strOP;

		if(nCam %2 == 0)
			strCam.Format(_T("High"));
		else
			strCam.Format(_T("Low"));

		if(m_bIsAutoProcessMode)
			strOP.Format(_T("Auto"));
		else
			strOP.Format(_T("Manual"));

		TRY
		{
			file.SeekToEnd();

			if(nSelHead == USE_DUAL)
			{
				strPanel.Format(_T("Dual-1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());

				strPanel.Format(_T("Dual-2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_MASTER)
			{
				strPanel.Format(_T("1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_SLAVE)
			{
				strPanel.Format(_T("2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			return;
		}
		END_CATCH
			file.Close();
	}
	if(bSuccess)
	{
		CStdioFile file2;
		if (FALSE == file2.Open(strPathName2, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
			return;

		CString strBuf;
		CString strCam, strPanel, strOP;

		if(nCam %2 == 0)
			strCam.Format(_T("High"));
		else
			strCam.Format(_T("Low"));

		if(m_bIsAutoProcessMode)
			strOP.Format(_T("Auto"));
		else
			strOP.Format(_T("Manual"));

		TRY
		{
			file2.SeekToEnd();

			if(nSelHead == USE_DUAL)
			{
				strPanel.Format(_T("Dual-1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());

				strPanel.Format(_T("Dual-2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_MASTER)
			{
				strPanel.Format(_T("1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_SLAVE)
			{
				strPanel.Format(_T("2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			return;
		}
		END_CATCH
			file2.Close();
	}
	{
		CStdioFile file3;
		if (FALSE == file3.Open(strPathName3, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
			return;

		CString strBuf;
		CString strCam, strPanel, strOP;

		if(nCam %2 == 0)
			strCam.Format(_T("High"));
		else
			strCam.Format(_T("Low"));

		if(m_bIsAutoProcessMode)
			strOP.Format(_T("Auto"));
		else
			strOP.Format(_T("Manual"));

		TRY
		{
			file3.SeekToEnd();

			if(nSelHead == USE_DUAL)
			{
				strPanel.Format(_T("Dual-1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file3.Write(strBuf, strBuf.GetLength());

				strPanel.Format(_T("Dual-2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file3.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_MASTER)
			{
				strPanel.Format(_T("1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file3.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_SLAVE)
			{
				strPanel.Format(_T("2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file3.Write(strBuf, strBuf.GetLength());
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			return;
		}
		END_CATCH
			file3.Close();
	}
#else
	if(fabs(m_dMaxOffsetMasterX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&  // drilling limit
		fabs(m_dMaxOffsetMasterY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY &&
		fabs(m_dMaxOffsetSlaveX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
		fabs(m_dMaxOffsetSlaveY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
	{
		bSuccess = TRUE;
	}

	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strPathName2 = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	strPathName += _T("SCalLog");
	strPathName2 += _T("PreworkDetailLog");
	CTime curDate = CTime::GetCurrentTime();

	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;
	strPathName2 += strCurTime;


	if(bSuccess)
	{
		CStdioFile file;
		if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
			return;

		CString strBuf;
		CString strCam, strPanel, strOP;

		if(nCam %2 == 0)
			strCam.Format(_T("High"));
		else
			strCam.Format(_T("Low"));

		if(m_bIsAutoProcessMode)
			strOP.Format(_T("Auto"));
		else
			strOP.Format(_T("Manual"));

		TRY
		{
			file.SeekToEnd();

			if(nSelHead == USE_DUAL)
			{
				strPanel.Format(_T("Dual-1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());

				strPanel.Format(_T("Dual-2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_MASTER)
			{
				strPanel.Format(_T("1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_SLAVE)
			{
				strPanel.Format(_T("2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file.Write(strBuf, strBuf.GetLength());
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			return;
		}
		END_CATCH
			file.Close();
	}
	{
		CStdioFile file2;
		if (FALSE == file2.Open(strPathName2, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
			return;

		CString strBuf;
		CString strCam, strPanel, strOP;

		if(nCam %2 == 0)
			strCam.Format(_T("High"));
		else
			strCam.Format(_T("Low"));

		if(m_bIsAutoProcessMode)
			strOP.Format(_T("Auto"));
		else
			strOP.Format(_T("Manual"));

		TRY
		{
			file2.SeekToEnd();

			if(nSelHead == USE_DUAL)
			{
				strPanel.Format(_T("Dual-1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());

				strPanel.Format(_T("Dual-2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_MASTER)
			{
				strPanel.Format(_T("1st"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
			else if(nSelHead == SEL_HEAD_SLAVE)
			{
				strPanel.Format(_T("2nd"));
				strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
					m_sProcessScannerCal.nUseTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				file2.Write(strBuf, strBuf.GetLength());
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			return;
		}
		END_CATCH
			file2.Close();
	}

#endif
	
}

void CPaneManualControlScannerCalibration::OnTimer(UINT nIDEvent) 
{
#ifdef __PUSAN_LDD__
	if( m_bIsLive )
	{
		int nCamNo = m_cmbUseVision.GetCurSel();
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnAcquire(nCamNo);
	}
#endif
	CFormView::OnTimer(nIDEvent);
}
LRESULT CPaneManualControlScannerCalibration::GetGrabVisionResult(WPARAM wParam, LPARAM lParam)
{
	m_dFoundSize = 0;
	HVision* pVision = gDeviceFactory.GetVision();
	
	int nResult = pVision->GetRealPos(&dpRealPos, wParam, lParam, FALSE, myResultChar, (BOOL)m_dFoundSize);
	
	if(nResult == 1)
		return TRUE;
	else
		return FALSE;
	
}

CDPoint CPaneManualControlScannerCalibration::GetNextStepIndex(int nStepNo)
{
	CDPoint pos(0,0);
	if(nStepNo == 0)
		return pos;
	int num = (int)sqrt((double)nStepNo) + 2;
	
	for(int j = 1; j< num; j++)
	{
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.x++;
			else pos.x--;
			if(nStepNo == 0) return pos;
		}
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.y++;
			else pos.y--;
			if(nStepNo == 0) return pos;
		}
	}
	return pos;
}

void CPaneManualControlScannerCalibration::ChangeFindCamera(emHEAD emHead)
{
	BOOL bUseLowCam = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		// yhchung 060601 Apply Calibration High/Low Start	
		int nVision = m_cmbUseVision.GetCurSel();
		if(nVision == 0 || nVision == 2)
			bUseLowCam = FALSE;
		else
			bUseLowCam = TRUE;
	}
	
	BOOL bMaster;
	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	if(emHead == emMaster &&  (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		if(bUseLowCam)
		{
			this->CameraChange(1);
			this->SendMessage(UM_CHANGE_VISION_PARAM, 1);
		}
		else
		{
			this->CameraChange(0);
			this->SendMessage(UM_CHANGE_VISION_PARAM, 0);
		}
	}
	if(emHead == emSlave &&  (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		if(bUseLowCam)
		{
			this->CameraChange(3);
			this->SendMessage(UM_CHANGE_VISION_PARAM, 3);
		}
		else
		{
			this->CameraChange(2);
			this->SendMessage(UM_CHANGE_VISION_PARAM, 2);
		}
	}
}

BOOL CPaneManualControlScannerCalibration::CreateTableCompenFile(FILE* fp, FILE* fpTable, emHEAD emHead)
{
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	if (NULL != fopen_s(&fp, strCalPath + "LaserOffset.txt", "w"))
		fp = NULL;

	if(emHead == emMaster)
	{
		if (NULL != fopen_s(&fpTable, strCalPath + "LaserM.Table", "w"))
		{
			EnableCalibrationWindow(TRUE);
			if(fp) fclose(fp);
			if(fpTable) fclose(fpTable);
			return FALSE;
		}
	}
	else
	{
		if (NULL != fopen_s(&fpTable, strCalPath + "LaserS.Table", "w"))
		{
			EnableCalibrationWindow(TRUE);
			if(fp) fclose(fp);
			if(fpTable) fclose(fpTable);
			return FALSE;
		}
	}
	return TRUE;
}

void CPaneManualControlScannerCalibration::GetTableMovePosForTableCompen(double& dX, double& dY, int nXIndex, int nYIndex, int nSubXIndex, int nSubYIndex, emHEAD emHead)
{
	BOOL bUseLowCam = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		// yhchung 060601 Apply Calibration High/Low Start	
		int nVision = m_cmbUseVision.GetCurSel();
		if(nVision == 0 || nVision == 2)
			bUseLowCam = FALSE;
		else
			bUseLowCam = TRUE;
	}

	double dStartPosX = GetCalStartX();
	double dStartPosY = GetCalStartY();
	if(emHead == emMaster)
	{
		if(bUseLowCam)
		{
			dY = dStartPosY + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - nYIndex * m_nGridSize - nSubYIndex * SHOT_DISTANCE;
			dX = dStartPosX + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nXIndex * m_nGridSize - nSubXIndex * SHOT_DISTANCE;
		}
		else
		{
			dY = dStartPosY + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - nYIndex * m_nGridSize - nSubYIndex * SHOT_DISTANCE;
			dX = dStartPosX + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nXIndex * m_nGridSize - nSubXIndex * SHOT_DISTANCE;
		}
	}
	else if(emHead == emSlave)
	{
		if(bUseLowCam)
		{
			dY = dStartPosY + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - nYIndex * m_nGridSize - nSubYIndex * SHOT_DISTANCE;
			dX = dStartPosX + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - nXIndex * m_nGridSize - nSubXIndex * SHOT_DISTANCE;
		}
		else
		{
			dY = dStartPosY + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - nYIndex * m_nGridSize - nSubYIndex * SHOT_DISTANCE;
			dX = dStartPosX + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - nXIndex * m_nGridSize - nSubXIndex * SHOT_DISTANCE;
		}
	}
}

void CPaneManualControlScannerCalibration::GetTableMovePosForTableVerify(double& dX, double& dY, double nXIndex, double nYIndex, int nSubXIndex, int nSubYIndex, emHEAD emHead)
{
	BOOL bUseLowCam = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		// yhchung 060601 Apply Calibration High/Low Start	
		int nVision = m_cmbUseVision.GetCurSel();
		if(nVision == 0 || nVision == 2)
			bUseLowCam = FALSE;
		else
			bUseLowCam = TRUE;
	}
	CString strData;

	m_edtFieldSize.GetWindowText( strData );
	double dFieldSize = atof( (LPSTR)(LPCTSTR)strData );

	m_edtDivisionX.GetWindowText( strData );
	int nDivisionX = atof( (LPSTR)(LPCTSTR)strData );

	m_edtDivisionY.GetWindowText( strData );
	int nDivisionY = atof( (LPSTR)(LPCTSTR)strData );

	double dStartPosX = GetCalStartX();
	double dStartPosY = GetCalStartY();
	int nDivision = GetDivision();
	//double dFieldSize =  gSystemINI.m_sSystemDevice.dFieldSize.x;

	double dHalfFieldSize = dFieldSize / 2.0;
	int nMaxLSB = (int)(MAXLSB * dFieldSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;

	int nX, nY;
	if(nDivisionX == 1)
		nStepX = nMaxLSB;
	else
		nStepX = nMaxLSB / (nDivisionX - 1);

	if(nDivisionY == 1)
		nStepY = nMaxLSB;
	else
		nStepY = nMaxLSB / (nDivisionY - 1);


	nStartLSBX = (int)(HALF_LSB - (nDivisionX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(HALF_LSB - (nDivisionY/2.0 - 0.5)*nStepY);

	nX = nStartLSBX + nSubXIndex * nStepX;
	if(nX > MAXLSB) nX = MAXLSB;
	if(nX < 0)		nX = 0;

	nY = nStartLSBY + nSubYIndex * nStepY;
	if(nY > MAXLSB) nY = MAXLSB;
	if(nY < 0)		nY = 0;
	
	dX = ( nX * (gSystemINI.m_sSystemDevice.dFieldSize.x )/FIELD_LSB - (gSystemINI.m_sSystemDevice.dFieldSize.x /2) );
	dY = ( nY * (gSystemINI.m_sSystemDevice.dFieldSize.x )/FIELD_LSB - (gSystemINI.m_sSystemDevice.dFieldSize.x /2) );

	dX = nXIndex - dX;
	dY = nYIndex - dY;
	if(emHead == emMaster)
	{
		if(bUseLowCam)
		{
			dX = dX + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dY = dY + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else
		{
			dX = dX + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dY = dY + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}
	}
	else if(emHead == emSlave)
	{
		if(bUseLowCam)
		{
			dX = dX + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dY = dY + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		}
		else
		{
			dX = dX + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dY = dY + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
	}

	//TRACE(_T(" %.3f, %.3f"), dX, dY);
	//if(emHead == emMaster)
	//{
	//	if(bUseLowCam)
	//	{
	//		dX = nXIndex + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nSubXIndex * (dFieldSize / (nDivisionX - 1.0));
	//		dY = nYIndex - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nSubYIndex * (dFieldSize / (nDivisionY - 1.0));
	//	}
	//	else
	//	{
	//		dX = nXIndex + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nSubXIndex * (dFieldSize / (nDivisionX - 1.0));
	//		dY = nYIndex - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nSubYIndex * (dFieldSize / (nDivisionY - 1.0));
	//	}
	//}
	//else if(emHead == emSlave)
	//{
	//	if(bUseLowCam)
	//	{
	//		dX = nXIndex + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - nSubXIndex * (dFieldSize / (nDivisionX - 1.0));
	//		dY = nYIndex - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y + nSubYIndex * (dFieldSize / (nDivisionY - 1.0));
	//	}
	//	else
	//	{
	//		dX = nXIndex + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - nSubXIndex * (dFieldSize / (nDivisionX - 1.0));
	//		dY = nYIndex - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y + nSubYIndex * (dFieldSize / (nDivisionY - 1.0));
	//	}
	//}
}

void CPaneManualControlScannerCalibration::GetTableMovePosForSCal(double& dMoveX, double& dMoveY, int nCountX, int nCountY, emHEAD emHead)
{
	double dStartPosX = GetCalStartX();
	double dStartPosY = GetCalStartY();
	int nDivision = GetDivision();
	double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	double dHalfFieldSize = dFieldSize / 2.0;

	BOOL bUseLowCam = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		// yhchung 060601 Apply Calibration High/Low Start	
		int nVision = m_cmbUseVision.GetCurSel();
		if(nVision == 0 || nVision == 2)
			bUseLowCam = FALSE;
		else
			bUseLowCam = TRUE;
	}

	if(emHead == emMaster)
	{
		if(bUseLowCam)
		{
			dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		else
		{
			dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
	}
	else if(emHead == emSlave)
	{
		if(bUseLowCam)
		{
			dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		else
		{
			dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
	}
	else
	{
		dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
		dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
	}
	if ((nCountY % 2) == 1)
	{
		if(emHead == emMaster)
			dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
		else if(emHead == emSlave)
			dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
	}

	// ī�޶� ���� ��ġ ���߱�
	if(emHead == emSlave && gProcessINI.m_sProcessScannerCal.bDefaultLow)
	{
		dMoveY -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y);
		dMoveX -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x);
	}
	if(emHead == emSlave && !gProcessINI.m_sProcessScannerCal.bDefaultLow)
	{
		dMoveY -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y);
		dMoveX -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x);
	}
}

int  CPaneManualControlScannerCalibration::GetCAmNumInfo(BOOL& bUseLowCam, emHEAD emHead)
{
	bUseLowCam = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		// yhchung 060601 Apply Calibration High/Low Start	
		int nVision = m_cmbUseVision.GetCurSel();
		if(nVision == 0 || nVision == 2)
			bUseLowCam = FALSE;
		else
			bUseLowCam = TRUE;
	}

	if(emHead == emMaster)
	{
		if(bUseLowCam)
			return LOW_1ST_CAM;
		else
			return HIGH_1ST_CAM;
	}
	else
	{
		if(bUseLowCam)
			return LOW_2ND_CAM;
		else
			return HIGH_2ND_CAM;
	}
}

BOOL CPaneManualControlScannerCalibration::GetOffsetFromVisionData(double dMoveX, double dMoveY, int nCountX, int nCountY, 
																	HANDLE* pHandle, BOOL bUseLowCam, emHEAD em1st, emHEAD em2nd, bool bSave, 
																	DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	BOOL bRet;
	int nCam = 0, nKK, nDivision = GetDivision();
	CString strResult, strPos, strData, strGetVal;
	int nRepeatTime = 1;
	if(bSave)
		nRepeatTime = 10;
	double dPosX, dPosY, dPanelOffsetX, dPanelOffsetY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, FALSE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, FALSE);

	if(em1st == emMaster && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		ChangeFindCamera(em1st);
		nCam = GetCAmNumInfo(bUseLowCam, em1st);
		
 		for(nKK = 0; nKK < nRepeatTime; nKK++)
		{
			bRet = this->SendMessage(UM_VISION_FIND2, nCam, MODEL_CIRCLE);

			if(bRet || (!bRet && bSave && m_nUserLevel == 2 && !m_bIsAutoProcessMode ))
				break;
			else if(!bRet && bSave)
			{
				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					return FALSE;
			}
			
		}

		if (bRet) 
		{
			if (bSave)
			{
				int nIndex;
				if(nCountY%2)
					nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, em1st);
				else
					nIndex = GetPointIndex(nCountX, nCountY, nDivision, em1st);

				pdPos1[nIndex].x = dMoveX;
				pdPos1[nIndex].y = dMoveY;
				pdOffset1[nIndex] = dpRealPos;
				pSuccess1[nIndex] = true;
			}
			else
			{
				m_bRestart = TRUE;
				return FALSE;
			}
		}
		else
		{
			if(m_nUserLevel == 2 && !m_bIsAutoProcessMode)
			{
				int nIndex;
				if(nCountY%2)
					nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, em1st);
				else
					nIndex = GetPointIndex(nCountX, nCountY, nDivision, em1st);

				pdPos1[nIndex].x = dMoveX;
				pdPos1[nIndex].y = dMoveY;
				pdOffset1[nIndex].x = pdOffset1[nIndex].y = 0;
				pSuccess1[nIndex] = true;
			}
			else
			{
				if (bSave)
				{
					if (m_bIsAutoProcessMode)
						this->PostMessage(UM_AUTOCAL_FAILED, STDGNALM711);

					return FALSE;
				}
			}
		}
		
		strResult.Format(_T("%s(%d)"), myResultChar, nKK);
		m_stcVisionResult.SetWindowText( strResult );

		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strResult);
		
		if(m_lboxResult.GetCount() > 400) 
			m_lboxResult.DeleteString(0);

		m_lboxResult.AddString((LPCTSTR)strData);
		m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);

		
	}

	if(em2nd == emSlave && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		ChangeFindCamera(em2nd);
		nCam = GetCAmNumInfo(bUseLowCam, em2nd);

		for(nKK = 0; nKK < nRepeatTime; nKK++)
		{
			bRet = this->SendMessage(UM_VISION_FIND2, nCam, MODEL_CIRCLE);
					
			if(bRet || (!bRet && bSave && m_nUserLevel == 2 && !m_bIsAutoProcessMode ) )
				break;
			else if(!bRet && bSave)
			{
				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					return FALSE;
			}
			
		}

		strGetVal.Format(_T("X : 0.000, Y : 0.000, (0.000)"));

		if (bRet) 
		{
			if (bSave)
			{
				int nIndex;
				if(nCountY%2)
					nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, em2nd);
				else
					nIndex = GetPointIndex(nCountX, nCountY, nDivision, em2nd);

				dPanelOffsetX = dMoveX - dPosX;
				dPanelOffsetY = dMoveY - dPosY;
				pdPos2[nIndex].x = dPosX;
				pdPos2[nIndex].y = dPosY;
				pdOffset2[nIndex].x = dpRealPos.x + dPanelOffsetX;
				pdOffset2[nIndex].y = dpRealPos.y + dPanelOffsetY;

				strGetVal.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), pdOffset2[nIndex].x, 
					pdOffset2[nIndex].y,
					m_dFoundSize);

				pSuccess2[nIndex] = true;
			}
			else
			{
				m_bRestart = TRUE;
				return FALSE;
			}
		}
		else
		{
			if(m_nUserLevel == 2 && !m_bIsAutoProcessMode)
			{
				int nIndex;
				if(nCountY%2)
					nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, em2nd);
				else
					nIndex = GetPointIndex(nCountX, nCountY, nDivision, em2nd);
				pdPos2[nIndex].x = dPosX;
				pdPos2[nIndex].y = dPosY;
				pdOffset2[nIndex].x = pdOffset2[nIndex].y = 0;
				pSuccess2[nIndex] = true;
			}
			else
			{
				if (bSave)
				{
					if (m_bIsAutoProcessMode)
						this->PostMessage(UM_AUTOCAL_FAILED, STDGNALM711);

					return FALSE;
				}
			}
		}

		strResult.Format(_T("%s(%d)"), strGetVal, nKK);
		m_stcVisionResult.SetWindowText( strResult );
				
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strResult);
			
		if(m_lboxResult.GetCount() > 400) 
			m_lboxResult.DeleteString(0);
				
		m_lboxResult.AddString((LPCTSTR)strData);
		m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);
	}
	return TRUE;
}

int CPaneManualControlScannerCalibration::GetOffsetFromVisionData(int nCountX, int nCountY, emHEAD emHead, HANDLE* pHandle, int nCam, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	BOOL bRet;
	int nKK, nDivision = GetDivision();
	double dPosX, dPosY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY);
	int nRepeatTime = 1;
	if(bSave)
		nRepeatTime = 10;

	for(nKK=0; nKK< nRepeatTime; nKK++)
	{
		bRet = this->SendMessage(UM_VISION_FIND1, nCam, MODEL_CIRCLE);
		if(bRet)
			break;
		else if(!bRet && bSave)
		{
			if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				return FALSE;
		}
		::Sleep(1);
	}
			
	if (bRet) 
	{
		if (bSave)
		{
			int nIndex;
			if(nCountY%2)
				nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, emHead);
			else
				nIndex = GetPointIndex(nCountX, nCountY, nDivision, emHead);
					
			pdPos[nIndex].x = dPosX;
			pdPos[nIndex].y = dPosY;
			pdOffset[nIndex] = dpRealPos;
			pSuccess[nIndex] = true;
		}
		else
		{
			m_bRestart = TRUE;
			return FALSE;
		}
	}
	else
	{
		if (bSave)
		{
			if (m_bIsAutoProcessMode)
			{
				PostMessage(UM_AUTOCAL_FAILED, STDGNALM711);
				return FALSE;
			}
			else
			{
				int nIndex;
				if(nCountY%2)
					nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision, emHead);
				else
					nIndex = GetPointIndex(nCountX, nCountY, nDivision, emHead);

				pdPos[nIndex].x = dPosX;
				pdPos[nIndex].y = dPosY;
				pdOffset[nIndex].x = pdOffset[nIndex].y = 0.0;
				pSuccess[nIndex] = false;
			}
		}
	}
	return nKK + 1;
}

BOOL CPaneManualControlScannerCalibration::DrillStartCmd(SUBTOOLDATA ToolData)
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	
	if(ToolData.nToolType == SHOT_DRILL_TYPE)
	{
		//20111107
		#ifndef  __KUNSAN_8__
			if(!pEoCard->FieldPreStart(gSystemINI.m_sSystemDump.nDummyShot))
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					pEoCard->EStop();
				ErrMsgDlg(STDGNALM445);	
				return FALSE;
			}

			if(!gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
			{
				if(gSystemINI.m_sSystemDump.nDummyShot > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
				{
					if(!pEoCard->DummyFieldStart(gSystemINI.m_sSystemDump.nDummyShot, gProcessINI.m_sProcessSystem.bDryRun))
					{
						if(gSystemINI.m_sSystemDevice.nEStop == 1)
							pEoCard->EStop();
						ErrMsgDlg(STDGNALM445);	
						return FALSE;
					}
				}
			}

			if(gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
			{
				if(gSystemINI.m_sSystemDump.nDummyShot > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
				{
					if(!pEoCard->DummyFieldStart(gSystemINI.m_sSystemDump.nDummyShot, FALSE))
					{
						if(gSystemINI.m_sSystemDevice.nEStop == 1)
							pEoCard->EStop();
						ErrMsgDlg(STDGNALM445);	
						return FALSE;
					}
				}
			}

			if(gSystemINI.m_sSystemDump.nDummyShot > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!pEoCard->DummyStopAndDataShotStart(FALSE))
				{
					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						pEoCard->EStop();
					ErrMsgDlg(STDGNALM445);	
					return FALSE;
				}
			}
			else
			{
				gDeviceFactory.GetMotor()->GetTCTemperature(m_dScal1stTemper, m_dScal2ndTemper);
				gDeviceFactory.GetMotor()->GetSBTemperature(m_dScal1stSBTemper, m_dScal2ndSBTemper);
				gDeviceFactory.GetMotor()->GetTemperatureForAllCh(m_dScalAllTemper);
				if(!pEoCard->FieldStart(FALSE))
				{
					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						pEoCard->EStop();
					ErrMsgDlg(STDGNALM445);	
					return FALSE;
				}
			}
		#else
			if(!pEoCard->FieldPreStart())
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					pEoCard->EStop();
				ErrMsgDlg(STDGNALM445);	
				return FALSE;
			}
				
			gDeviceFactory.GetMotor()->GetTCTemperature(m_dScal1stTemper, m_dScal2ndTemper);
			gDeviceFactory.GetMotor()->GetSBTemperature(m_dScal1stSBTemper, m_dScal2ndSBTemper);
			gDeviceFactory.GetMotor()->GetTemperatureForAllCh(m_dScalAllTemper);
			if(!pEoCard->FieldStart(FALSE))
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					pEoCard->EStop();
				ErrMsgDlg(STDGNALM445);	
				return FALSE;
			}
		#endif
		::Sleep(100);
	}	
	return TRUE;
}

BOOL CPaneManualControlScannerCalibration::WaitOneFireProcess(HANDLE* pHandle)
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	BOOL bResult = TRUE;
	do
	{
		::Sleep(1);
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			return FALSE;
		}
/*		if(pEoCard->IsDrillTimeOut())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM566);
			return FALSE;
		}
		if(pEoCard->IsMotorFault())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM567);
			return FALSE;
		}
*/
		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, _T("Scanner Cable Error."));
			return FALSE;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, strErrorMsg);
			return FALSE;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, strErrorMsg);
			return FALSE;
		}
		else if(bTimeOutType)
		{
			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM566, strErrorMsg);
			return FALSE;
		}
		bResult = pEoCard->IsDSPBusy();
	}while(bResult);

	return TRUE;
}

BOOL CPaneManualControlScannerCalibration::ReaseFileAndMem(CFile* pFileOri, CFile* pFileResult, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	if (pdPos1 != NULL)
		delete [] pdPos1;
	if (pdOffset1 != NULL)
		delete [] pdOffset1;
	if (pSuccess1 != NULL)
		delete [] pSuccess1;
		
	if (pdPos2 != NULL)
		delete [] pdPos2;
	if (pdOffset2 != NULL)
		delete [] pdOffset2;
	if (pSuccess2 != NULL)
		delete [] pSuccess2;
	
	if(pFileOri)
		pFileOri->Close();
	if(pFileResult)
		pFileResult->Close();

	return TRUE;
}

void CPaneManualControlScannerCalibration::HeadChangeVerify()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		if(!m_bDryRunCheck)
			ErrMessage(_T("Please Reset Error")); // 110603
		::SetEvent(g_hDoScalManual);
		return;
	}

	double dStartPosX, dStartPosY, dFirePosOffsetX = 0, dFirePosOffsetY = 0;
	double dHeadOffsetX, dHeadOffsetY;
	BOOL b1stPanel = TRUE;
	dStartPosX = m_dCalculateStartXAuto;
	dStartPosY = m_dCalculateStartYAuto;

	int nCamNo = m_cmbUseVision.GetCurSel();

	if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
	{
		if(nCamNo == LOW_2ND_CAM)
		{
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		}
		else
		{	
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
		b1stPanel = FALSE;
	}
	else
	{
		if(nCamNo == LOW_1ST_CAM)
		{
//			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
//			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else
		{	
//			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
//			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}
	}

	if(!pMotor->MoveXY(dStartPosX - dFirePosOffsetX + dHeadOffsetX, dStartPosY - dFirePosOffsetY + dHeadOffsetY, b1stPanel, SHOT_MOVE)) 
	{
		ErrMessage(_T("Can't move Table to Scanner Calibration Zone"));
		return;
	}
	SetVisionInfo();
	this->CameraChange(nCamNo);
	this->SendMessage(UM_CHANGE_VISION_PARAM, nCamNo);

	if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
	{
		ErrMessage(_T("Can't move Table to Scanner Calibration Zone : Inposition Error"));
		return;
	}

	BOOL bRet = this->SendMessage(UM_VISION_FIND1, nCamNo, MODEL_CIRCLE);
	CString strResult, strPos, strData;
		
	strResult.Format(_T("%s"), myResultChar);
	m_stcVisionResult.SetWindowText( strResult );

	strPos.Format(_T("[%.3f, %.3f]"), dStartPosX - dFirePosOffsetX + dHeadOffsetX, dStartPosY - dFirePosOffsetY + dHeadOffsetY);
	strData.Format(_T("1st %s %s"), strPos, strResult);
		
	if(m_lboxResult.GetCount() > 400) 
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strData);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);
}

void CPaneManualControlScannerCalibration::OnBnClickedButtonOffsetVerify()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_nGridMode = 4;	//4 = Verify Vision Head Offset.
	m_bLastPosSCalVerify = TRUE;
	CalculateAutoStartPosition();

	HeadChangeVerify();
}

void CPaneManualControlScannerCalibration::OnBnClickedButtonOffsetVerifyNext()
{
	m_nGridMode = 4;	//4 = Verify Vision Head Offset.
	m_bLastPosSCalVerify = FALSE;
	CalculateAutoStartPosition();

	HeadChangeVerify();
}


BOOL CPaneManualControlScannerCalibration::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_ScannerCal) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

void CPaneManualControlScannerCalibration::OnEnKillfocusEditAutoXPos()
{
	// TODO: Add your control notification handler code here
	::AfxGetMainWnd()->SendMessage(UM_CAL_AUTO_SCAL_POS);
}


void CPaneManualControlScannerCalibration::OnEnKillfocusEditAutoYPos()
{
	// TODO: Add your control notification handler code here
	::AfxGetMainWnd()->SendMessage(UM_CAL_AUTO_SCAL_POS);
}

LRESULT CPaneManualControlScannerCalibration::SetVisionLamp(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();

	int nCam = (int)wParam;
	int nBeamPath = lParam;
	int nRing;
	int nCoaxial;

//	if( nCam <= LOW_1ST_CAM)
//	{
		nRing =  m_sProcessScannerCal.nRing[nCam];
		nCoaxial =  m_sProcessScannerCal.nCoaxial[nCam];
	//}
	//else
	//{
	//	nRing =  m_sProcessScannerCal.nRing2[nCam];
	//	nCoaxial =  m_sProcessScannerCal.nCoaxial2[nCam];
	//}
#ifndef __2016_KUNSAN__
	for(int i = 0; i < 4; i++)
	{
		nRing =  m_sProcessScannerCal.nRing[i];
		nCoaxial =  m_sProcessScannerCal.nCoaxial[i];
		pVision->OnLightAll(i, nCoaxial, nRing, 0);
	}
#else
	if( nCam == 0 || nCam ==2)
	{
		pVision->OnLightAll(0, m_sProcessScannerCal.nCoaxial[0], m_sProcessScannerCal.nRing[0], m_sProcessScannerCal.nIR[0]);
		pVision->OnLightAll(1, 0, 0, 0);
		pVision->OnLightAll(2, m_sProcessScannerCal.nCoaxial[2], m_sProcessScannerCal.nRing[2], m_sProcessScannerCal.nIR[2]);
		pVision->OnLightAll(3, 0, 0, 0);
	}
	else
	{
		pVision->OnLightAll(0, 0, 0, 0);
		pVision->OnLightAll(1, m_sProcessScannerCal.nCoaxial[1], m_sProcessScannerCal.nRing[1], m_sProcessScannerCal.nIR[1]);
		pVision->OnLightAll(2, 0, 0, 0);
		pVision->OnLightAll(3, m_sProcessScannerCal.nCoaxial[3], m_sProcessScannerCal.nRing[3], m_sProcessScannerCal.nIR[3]);
	}
#endif
	return TRUE;
}

void CPaneManualControlScannerCalibration::InitSlideControl()
{
	m_SliderCoaxial.SetRange(0, 255);
	m_SliderRing.SetRange(0, 255);
	m_SliderIR.SetRange(0, 255);

	// ��ġ ����.
	m_SliderCoaxial.SetPos(50);
	m_SliderRing.SetPos(50);
	m_SliderIR.SetPos(50);

	// ���� ������ �����Ѵ�.
	// �Ӽ��� Tick Marks�� Auto Ticks�� True�� �Ǿ� �־�� �Ѵ�.
	m_SliderCoaxial.SetTicFreq(10);
	m_SliderRing.SetTicFreq(10);
	m_SliderIR.SetTicFreq(10);

	// Ű���� Ŀ��Ű�� �����̴��� �����϶��� ���� ũ�⸦ ����
	m_SliderCoaxial.SetLineSize(1);
	m_SliderRing.SetLineSize(1);
	m_SliderIR.SetLineSize(1);

	// Ű������ PgUp, PgDnŰ�� �����ų� ���콺�� �����̴��� ������ Ŭ���� ������ ũ�� 
	m_SliderCoaxial.SetPageSize(10);
	m_SliderRing.SetPageSize(10);
	m_SliderIR.SetPageSize(10);
}

void CPaneManualControlScannerCalibration::OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
/*	int nCoaxial = 0;
	CString strData;
	nCoaxial= m_SliderCoaxial.GetPos();
	strData.Format(_T("%d"), nCoaxial);
	m_edtCoaxial.SetWindowText( strData );
*/
	*pResult = 0;
}


void CPaneManualControlScannerCalibration::OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
/*	int nRing = 0;
	CString strData;
	nRing = m_SliderRing.GetPos();
	strData.Format(_T("%d"), nRing);
	m_edtRing.SetWindowText( strData );
*/
	*pResult = 0;
}
void CPaneManualControlScannerCalibration::OnEnKillfocusEdit1stThick()
{
	// TODO: Add your control notification handler code here
	CString strData;
	m_edtAuto1stThickness.GetWindowText( strData );
	double dThick = atof( (LPSTR)(LPCTSTR)strData );

	if( m_sProcessScannerCal.dAuto1stThickness != dThick)
	{
		if( ErrMessage(_T("1st ThickNess Change? "),MB_YESNO) == IDYES)
		{
			 gProcessINI.m_sProcessScannerCal.dAuto1stThickness = dThick;
			 m_sProcessScannerCal.dAuto1stThickness = dThick;
			 SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
		}
		else
		{
			strData.Format(_T("%.2f"), m_sProcessScannerCal.dAuto1stThickness);
			m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );
		}
	}
}


void CPaneManualControlScannerCalibration::OnEnKillfocusEdit2ndThick()
{
	// TODO: Add your control notification handler code here
	CString strData;
	m_edtAuto2ndThickness.GetWindowText( strData );
	double dThick = atof( (LPSTR)(LPCTSTR)strData );

	if( m_sProcessScannerCal.dAuto2ndThickness != dThick)
	{
		if( ErrMessage(_T("2nd ThickNess Change? "),MB_YESNO) == IDYES)
		{
			gProcessINI.m_sProcessScannerCal.dAuto2ndThickness = dThick;
			m_sProcessScannerCal.dAuto2ndThickness = dThick;
			SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
		}
		else
		{
			strData.Format(_T("%.2f"), m_sProcessScannerCal.dAuto1stThickness);
			m_edtAuto1stThickness.SetWindowText( (LPCTSTR)strData );
		}
	}
}

void CPaneManualControlScannerCalibration::OnButtonCalStartVerify() 
{
	::ResetEvent(g_hDoScalManual);

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		if(!m_bDryRunCheck)
			ErrMessage(_T("Please Reset Error")); // 110603
		::SetEvent(g_hDoScalManual);
		return;
	}

	// �µ����� ���� ����
	m_bFullCoolingAGC = FALSE;
	double dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
	double dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
	if(dEndTime >= dWaitTime)
		m_bFullCoolingAGC = TRUE;

	if(gDeviceFactory.Get1stTemperCompen()->GetTableNo() > 1 || 
		gDeviceFactory.Get2ndTemperCompen()->GetTableNo() > 1) // �Ŀ��� ���� ���̺��� 2�� �̻��̶�� AGC ���� ��Ȳ���� ��ٷ�����
	{
		if( !((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAnyDoAutoSCal ) // AGC ���� ��Ȳ�� �ƴ� ���
			dEndTime = dWaitTime + 1;
	}
	else // �Ŀ� ���̺��� 1����� ���α׷� ���ۿ����� ���������� ��ٷ��� ��. �µ�����
	{
		if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT() && gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT()) // �Ѵ� �µ� �������� �������� ��쿡�� 5�� ��ٸ��� ����.
			dEndTime =  (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLilyStartTime;
	}

	if(!gProcessINI.m_sProcessOption.bTemperCompensationMode) // Temper ���� ��尡 �ƴϸ� ��ٸ� �ʿ� ����
		dEndTime = dWaitTime + 1;
	else
	{
		if(gProcessINI.m_sProcessOption.bWaitTemperDownForAGC) // ������ �Ź� ��ٸ��� �ɼ��� ���ϸ�
		{
			dEndTime = (double)((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime;
			dWaitTime = gProcessINI.m_sProcessOption.dTemperTWaitScal;
		}
	}
	
	if(dWaitTime > dEndTime)
	{
		CString strMessage;
		strMessage.Format(_T("User can start. program start or drilling after %.0fsec \n%Try again after %.0fsec \n Temperature value occur reversal phenomenon, or must to down temperature."), dWaitTime, dWaitTime - dEndTime);
		ErrMessage(strMessage);
		return;
	}	
	
	if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("DrillEndTime\t%d\tLimit\t%.0f" ),   
							((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nDrillOneBoardEndTime,
							dWaitTime);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	// �µ����� ���� ���� ��

	m_nGridMode = 5;
	m_bAutoPause = FALSE;
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = pMotor->GetAOMStatus(); // 110607
		BOOL bScanner = pMotor->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		
		if(!bPower || !bShutter | !bAOM || !bScanner)
		{
			NotifyError(STDGNALM303, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			NotifyError(STDGNALM607, TRUE, _T(""), FALSE);
			::SetEvent(g_hDoScalManual);
			return;
		}
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		NotifyError(STDGNALM559, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		NotifyError(STDGNALM207, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		return;
	}

	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
	::Sleep(500);

	int nHead = GetSelectedHead();
	
	BOOL bRet = FALSE;
	
	int nSuction1 = pMotor->GetCurrentSuction();
	BOOL b1stAcrylSuction = pMotor->GetCurrentAcrylSuction(TRUE);
	BOOL b2ndAcrylSuction = pMotor->GetCurrentAcrylSuction(FALSE);
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if(nSuction1 & 0x01 && bMotor) b1st = TRUE;
	if(nSuction1 & 0x02 && bMotor) b2nd = TRUE;
	
	if(nHead == 0)
	{
		if(!b1stAcrylSuction || !b2ndAcrylSuction)
		{
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		}
		
		if(b1st && b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else if(nHead == 1)
	{
		if(!b1stAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );
		
		if(b1st)
			bRet = TRUE;
		else
			bRet = FALSE;
	}
	else
	{
		if(!b2ndAcrylSuction)
			pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1 );
		
		if(b2nd)
			bRet = TRUE;
		else
			bRet = FALSE;
	}

	if(!bRet && !gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		NotifyError(STDGNALM423, TRUE, _T(""), FALSE);
		::SetEvent(g_hDoScalManual);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		return;
	}

	CString strData;
	m_edtGridXNo.GetWindowText( strData );
	m_nGridXNo = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtGridYNo.GetWindowText( strData );
	m_nGridYNo = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtGridGap.GetWindowText( strData );
	m_nGridSize = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtFieldSize.GetWindowText( strData );
	m_dFieldSize = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtDivisionX.GetWindowText( strData );
	m_nDivisionX = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtDivisionY.GetWindowText( strData );
	m_nDivisionY = atoi( (LPSTR)(LPCTSTR)strData );

	m_bIsAutoProcessMode = FALSE;
	m_bAutoCalibration = FALSE;
	m_bVerifyCalibration = TRUE;

	OnCalibrationStart();
}

void CPaneManualControlScannerCalibration::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	if(gSystemINI.m_sHardWare.nUseLampRS232)
	{
		if(pScrollBar == (CScrollBar*)&m_SliderCoaxial ||
			pScrollBar == (CScrollBar*)&m_SliderRing ||
			pScrollBar == (CScrollBar*)&m_SliderIR )
		{
			HVision* pVision = gDeviceFactory.GetVision();
			int nCamNo = m_cmbUseVision.GetCurSel();
			int nPosCoax = m_SliderCoaxial.GetPos();
			int nPosRing = m_SliderRing.GetPos();
			int nPosIR = m_SliderIR.GetPos();
			pVision->OnLightAll(nCamNo, nPosCoax, nPosRing, nPosIR);
			CString strCoax = _T("");
			CString strRing = _T("");
			CString strIR = _T("");
			strCoax.Format("%d", nPosCoax);
			m_edtCoaxial.SetWindowText(strCoax);
			strRing.Format("%d", nPosRing);
			m_edtRing.SetWindowText(strRing);
			strIR.Format("%d", nPosIR);
			m_edtIR.SetWindowText(strIR);
		}
	}
	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CPaneManualControlScannerCalibration::OnEnUpdateEditCoaxial()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);

	CString str;
	int nTempVal;
	int nCam = m_cmbUseVision.GetCurSel();

	HVision* pVision = gDeviceFactory.GetVision();

	m_edtCoaxial.GetWindowText(str);
	int nCoaxial = atoi(str);
	m_SliderCoaxial.SetPos(nCoaxial);
	pVision->OnLightEach(nCam, COAXIAL, nCoaxial);
}

void CPaneManualControlScannerCalibration::OnEnUpdateEditIR()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);

	CString str;
	int nTempVal;
	int nCam = m_cmbUseVision.GetCurSel();

	HVision* pVision = gDeviceFactory.GetVision();
	m_edtIR.GetWindowText(str);
	int nIR = atoi(str);
	m_SliderIR.SetPos(nIR);
	pVision->OnLightEach(nCam, IR, nIR);
}

void CPaneManualControlScannerCalibration::OnEnUpdateEditRing()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);

	CString str;
	int nTempVal;
	int nCam = m_cmbUseVision.GetCurSel();

	HVision* pVision = gDeviceFactory.GetVision();
	m_edtRing.GetWindowText(str);
	int nRing = atoi(str);
	m_SliderRing.SetPos(nRing);
	pVision->OnLightEach(nCam, RING, nRing);
}