// PaneSysSetupComponentLaser.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "PaneSysSetupComponentLaser.h"
#include "GridCtrl_src\GridCtrl.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "..\Model\DSystemINI.h"
#include "..\MODEL\GlobalVariable.h"
#include "alarmmsg.h"
#include "DlgLogin.h"

#define		COLOR_BEAMPATH		RGB(255, 255, 162)
#define		COLOR_POWEROFFSET	RGB(243, 255, 72)
#define		COLOR_COMPENSATION	RGB(207, 255, 36)
#define		COLOR_SCANNERFACTS	RGB(255, 202, 108)
#define		COLOR_HOLEFACTS		RGB(180, 255, 255)


#define		COLOR_RED		RGB(255, 0, 0)
#define		COLOR_GREEN		RGB(0, 255, 0)

#define		COLOR_WHITE		RGB(255, 255, 255)
#define		COLOR_YELLOW		RGB(255, 255, 0)
#define		COLOR_TABLE		RGB(255, 255, 162)

// CPaneSysSetupComponentLaser

IMPLEMENT_DYNCREATE(CPaneSysSetupComponentLaser, CFormView)

CPaneSysSetupComponentLaser::CPaneSysSetupComponentLaser()
	: CFormView(CPaneSysSetupComponentLaser::IDD)
{
	m_ctStart = CTime::GetCurrentTime();
	strTable0[0] = "  No.  ";
	strTable0[1] = "  Laser Check Time  ";
	m_bAlarmCheck = FALSE;
	m_nUseYearLaser = 0;
}

CPaneSysSetupComponentLaser::~CPaneSysSetupComponentLaser()
{
}

void CPaneSysSetupComponentLaser::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);

	DDX_GridControl(pDX, IDC_GRID, m_Grid);

	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_BUTTON_RESET, m_btnReset);
	DDX_Control(pDX, IDC_EDIT_COMPONENT_USING_TIME, m_edtLaserUsingTime);
}

BEGIN_MESSAGE_MAP(CPaneSysSetupComponentLaser, CFormView)
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID, OnGridEndEdit)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CPaneSysSetupComponentLaser::OnBnClickedButtonSave)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CPaneSysSetupComponentLaser::OnBnClickedButtonReset)
END_MESSAGE_MAP()


// CPaneSysSetupComponentLaser �����Դϴ�.

#ifdef _DEBUG
void CPaneSysSetupComponentLaser::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPaneSysSetupComponentLaser::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPaneSysSetupComponentLaser �޽��� ó�����Դϴ�.


void CPaneSysSetupComponentLaser::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();

	OnCheckRefresh();
}

void CPaneSysSetupComponentLaser::InitBtnControl()
{ 
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

	// Reset
	m_btnReset.SetFont( &m_fntBtn );
	m_btnReset.SetFlat( FALSE );
	m_btnReset.EnableBallonToolTip();
	m_btnReset.SetToolTipText( _T("Save") );
	m_btnReset.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReset.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupComponentLaser::InitStaticControl()
{ 
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_COMPONENT_TIME)->SetFont(&m_fntStatic);

	GetDlgItem(IDC_STATIC_LASER_COMPONENT_SET)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_COMPONENT_TIME2)->SetFont(&m_fntStatic);

}

void CPaneSysSetupComponentLaser::InitEditControl()
{ 
	m_fntEdit.CreatePointFont(130, "Arial Bold");
	m_fntEtc.CreatePointFont(150, "Arial Bold");	
	m_dtcStart.SetFont( &m_fntEtc );

	m_edtLaserUsingTime.SetFont( &m_fntEdit );
	m_edtLaserUsingTime.SetForeColor( BLACK_COLOR );
	m_edtLaserUsingTime.SetBackColor( WHITE_COLOR );
	m_edtLaserUsingTime.SetWindowText( _T("0") );
	
}

void CPaneSysSetupComponentLaser::InitGrid()
{ 
	m_Grid.SetEditable(TRUE);
	m_Grid.SetListMode(FALSE);
	m_Grid.EnableDragAndDrop(FALSE);
	m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	m_Grid.SetFixedRowCount(1);        //1���� ��
	m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����
}

void CPaneSysSetupComponentLaser::OnCheckRefresh()
{
	m_nColumnCount = 0;
	SetDrawMember(1);

	Invalidate(FALSE);
}

void CPaneSysSetupComponentLaser::SetDrawMember(int listcount)
{
	int i;
	LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = (LASER_COMPONENT_COUNT -1) ; i >= 0 ;i--)
		{
			m_Grid.SetRowCount(1 + LASER_COMPONENT_COUNT);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
}

void CPaneSysSetupComponentLaser::InsertListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	//m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strTable0[i].GetLength();
			nStrLen = 150;

			ColumnNo++;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strTable0[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else
	{

	}
}

void CPaneSysSetupComponentLaser::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	
	BOOL bOnOff;
	COLORREF pColor = COLOR_TABLE;
	COLORREF pColorSelect = COLOR_GREEN;
	COLORREF pColorCombo = COLOR_BEAMPATH;

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%d"),  gVariable.m_sgComponentLaser.nInfoId[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));

		DWORD oldMask = Gvitem.mask;
		Gvitem.mask = GVIF_TEXT|GVIF_FORMAT;
		m_Grid.SetItem(&Gvitem);
		Gvitem.mask = oldMask;
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgComponentLaser.nLaserCheckTime[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

		////Interval Month
		//int nIntervalMonth = gVariable.m_sgComponentLaser.nIntervalMonth[ColCount];

		//strData.Format(_T("%d"), nIntervalMonth);
		//Gvitem.strText = strData;
		//Gvitem.col = ColumnNo;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		//CStringArray options;
		//options.RemoveAll();
		//CString strMonth;
		//for(int i = 0 ; i < 12 ; i++)
		//{
		//	strMonth.Format(_T("%d"),i+1);
		//	options.Add(strMonth);
		//}

		//CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		//pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		//pCell->SetOptions(options);
		//pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		//m_Grid.SetItem(&Gvitem);
		//if(gVariable.m_sgComponentLaser.nUseYear[ColCount] == m_nUseYearLaser)
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColorSelect);
		//else
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColorCombo);
		//m_Grid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		//ColumnNo++;

	}

	m_Grid.AutoSize();
}

void CPaneSysSetupComponentLaser::SetComponentLaser(SCOMPONENTLASER sComponentLaser)
{
	memcpy( &gVariable.m_sgComponentLaser, &sComponentLaser, sizeof(gVariable.m_sgComponentLaser) );	
	time_t timeStart;
	timeStart = gVariable.m_sgComponentLaser.nComponentStartTime;
	m_ctStart = timeStart;
	UpdateData(FALSE);
}
void CPaneSysSetupComponentLaser::GetComponentLaser(SCOMPONENTLASER* pComponentLaser)
{
	memcpy( pComponentLaser, &gVariable.m_sgComponentLaser, sizeof(gVariable.m_sgComponentLaser) );
}

void CPaneSysSetupComponentLaser::OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	m_posClicked.x = pItem->iColumn;
	m_posClicked.y = pItem->iRow - 1;
	str = m_Grid.GetItemText( pItem->iRow, pItem->iColumn);
	if(!ListUpdate(m_posClicked, str))
		OnCheckRefresh();

	m_Grid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));


	//if(pItem->iColumn == 4||pItem->iColumn == 6 )
	//{
	//	OnCheckRefresh2(2);
	//}
	//if(pItem->iColumn == 7||pItem->iColumn == 8 || pItem->iColumn == 3 || pItem->iColumn == 6 )
	//{
	//	OnCheckRefresh2(1);
	//}
}

BOOL CPaneSysSetupComponentLaser::ListUpdate(CPoint ClickedPos, CString str)
{
	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(xPos < TABLE0_COLUMN_COUNT)
	{
		if(!FillTable0Data(xPos,yPos, str))
			return FALSE;
	}
	/*	else
	{
	xPos -= TABLE0_COLUMN_COUNT;
	FillTable1Data(xPos,yPos, str);
	}*/	
	return TRUE;
}

BOOL CPaneSysSetupComponentLaser::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	//if(xPos == 0)
	//	gVariable.m_sgAutoManualScaleTable.nFilmLayer[yPos] = atoi(str);
	if(xPos == 1)
	{
		gVariable.m_sgComponentLaser.nLaserCheckTime[yPos] = atoi(str);
	}
	return TRUE;
}

void CPaneSysSetupComponentLaser::OnBnClickedButtonSave()
{
	CDlgLogin dlg;
	CString strMsg;

	if(!ValidateComponentLaser())
		return;

	if( IDOK != dlg.DoModal() )
		return;

	if(dlg.GetUserLevel() < 2)
	{
		::AfxMessageBox(_T("Only Eo/Super Engineer can save data"), MB_OK);
		return;
	}

	UpdateData(TRUE);
	CString strData;
	CTime ctCurTime;
	ctCurTime = CTime::GetCurrentTime();
	CTime ctSaveTime(m_ctStart.GetYear(), m_ctStart.GetMonth(), m_ctStart.GetDay(),ctCurTime.GetHour(),0,0,-1);
	gVariable.m_sgComponentLaser.nComponentStartTime = ctSaveTime.GetTime();

	gVariable.m_sgComponentLaser.bLaserAlarmReset =1;

	for(int i = 0 ; i < LASER_COMPONENT_COUNT; i++)
	{
		for(int j = 0 ; j < 10; j++)
			gVariable.m_sgComponentLaser.bLaserAlarm[i][j] = FALSE;
	}

	//TRACE(_T("Y : %d, M : %d, D : %d, H : %d\n"),ctSaveTime.GetYear(), ctSaveTime.GetMonth(), ctSaveTime.GetDay(), ctSaveTime.GetHour() );
	GetComponentLaser( &gComponentLaserINI.m_sComponentLaser );

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, COMPONENTLASER_INI))
	{
		//ErrMsgDlg(STDGNALM114);
	}

	strMsg.Format(_T("Component Laser Data Save Complete"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
	CheckComponentOverDate();
	//gVariable.m_sgComponentLaser.bLaserAlarmReset =1;
	OnCheckRefresh();
	::AfxMessageBox(_T("Component Laser Data Save Complete"), MB_OK);
}

void CPaneSysSetupComponentLaser::CheckComponentOverDate()
{
	CTime ctCurTime, ctStartTime;
	time_t timeNow;
	double dDiffTime;
	int nElapsedTime, nUseYearLaser, nIntervalMonth;
	int nCurYear, nCurMonth, nCurDay,nCurHour, nCurMin, nStartYear, nStartMonth, nStartDay;
	ctCurTime = CTime::GetCurrentTime();
	time(&timeNow);
	dDiffTime = difftime(timeNow, gVariable.m_sgComponentLaser.nComponentStartTime);

	nElapsedTime = (int)dDiffTime/3600;
	//gVariable.m_nComponentLaserTime = nElapsedTime;

	CString strLaserUsingTime;
	strLaserUsingTime.Format(_T("%d"),nElapsedTime);
	m_edtLaserUsingTime.SetWindowText(strLaserUsingTime);

	nCurYear		= ctCurTime.GetYear();
	nCurMonth	= ctCurTime.GetMonth();
	nCurDay		= ctCurTime.GetDay();
	nCurHour	= ctCurTime.GetHour();
	nCurMin		= ctCurTime.GetMinute();
	nStartYear		= m_ctStart.GetYear();
	nStartMonth	= m_ctStart.GetMonth();
	nStartDay		= m_ctStart.GetDay();
	
	int nAlarmNo = -1;
	int nAlarmCheckNo = 0;
	CString strErr;
	
	if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1]-720)
	{
		nAlarmNo = 0;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1415,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1416,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1417,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1418,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] && !gVariable.m_sgComponentLaser.bLaserAlarm[0][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1419,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1420,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1421,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[0][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1422,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[0] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] && !gVariable.m_sgComponentLaser.bLaserAlarm[0][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1423,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2]-720)
	{
		nAlarmNo = 1;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1424,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1425,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1426,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1427,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] && !gVariable.m_sgComponentLaser.bLaserAlarm[1][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1428,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1429,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1430,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[1][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1431,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[1] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] && !gVariable.m_sgComponentLaser.bLaserAlarm[1][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1432,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3]-720)
	{
		nAlarmNo = 2;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1433,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1434,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1435,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1436,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] && !gVariable.m_sgComponentLaser.bLaserAlarm[2][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1437,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1438,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1439,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[2][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1440,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[2] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] && !gVariable.m_sgComponentLaser.bLaserAlarm[2][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1441,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4]-720)
	{
		nAlarmNo = 3;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1442,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1443,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1444,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1445,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] && !gVariable.m_sgComponentLaser.bLaserAlarm[3][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1446,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1447,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1448,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[3][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1449,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[3] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] && !gVariable.m_sgComponentLaser.bLaserAlarm[3][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1450,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5]-720)
	{
		nAlarmNo = 4;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1451,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1452,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1453,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1454,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] && !gVariable.m_sgComponentLaser.bLaserAlarm[4][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1455,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1456,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1457,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[4][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1458,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[4] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] && !gVariable.m_sgComponentLaser.bLaserAlarm[4][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1459,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6]-720)
	{
		nAlarmNo = 5;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1460,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1461,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1462,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1463,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] && !gVariable.m_sgComponentLaser.bLaserAlarm[5][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1464,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1465,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1466,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[5][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1467,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[5] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] && !gVariable.m_sgComponentLaser.bLaserAlarm[5][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1468,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7]-720)
	{
		nAlarmNo = 6;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1489,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1470,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1471,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1472,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] && !gVariable.m_sgComponentLaser.bLaserAlarm[6][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1473,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1474,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1475,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[6][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1476,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[6] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] && !gVariable.m_sgComponentLaser.bLaserAlarm[6][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1477,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8]-720)
	{
		nAlarmNo = 7;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1478,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1479,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1480,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1481,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] && !gVariable.m_sgComponentLaser.bLaserAlarm[7][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1482,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1483,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1484,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[7][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1485,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[7] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] && !gVariable.m_sgComponentLaser.bLaserAlarm[7][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1486,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9]-720)
	{
		nAlarmNo = 8;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1487,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1488,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1489,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1490,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] && !gVariable.m_sgComponentLaser.bLaserAlarm[8][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1491,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1492,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1493,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[8][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1494,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[8] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] && !gVariable.m_sgComponentLaser.bLaserAlarm[8][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1495,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10]-720)
	{
		nAlarmNo = 9;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1496,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1497,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1498,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1499,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] && !gVariable.m_sgComponentLaser.bLaserAlarm[9][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1500,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1501,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1502,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[9][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1503,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[9] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] && !gVariable.m_sgComponentLaser.bLaserAlarm[9][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1504,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11]-720)
	{
		nAlarmNo = 10;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1505,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1506,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1507,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1508,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] && !gVariable.m_sgComponentLaser.bLaserAlarm[10][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1509,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1510,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1511,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[10][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1512,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[10] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] && !gVariable.m_sgComponentLaser.bLaserAlarm[10][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1513,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12]-720)
	{
		nAlarmNo = 11;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1514,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1515,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1516,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1517,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] && !gVariable.m_sgComponentLaser.bLaserAlarm[11][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1518,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1519,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1520,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[11][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1521,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[11] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] && !gVariable.m_sgComponentLaser.bLaserAlarm[11][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1522,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13]-720)
	{
		nAlarmNo = 12;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1523,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1524,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1525,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1526,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] && !gVariable.m_sgComponentLaser.bLaserAlarm[12][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1527,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1528,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1529,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[12][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1530,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[12] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] && !gVariable.m_sgComponentLaser.bLaserAlarm[12][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1531,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14]-720)
	{
		nAlarmNo = 13;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1532,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1533,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1534,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1535,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] && !gVariable.m_sgComponentLaser.bLaserAlarm[13][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1536,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1537,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1538,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[13][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1539,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[13] +720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] && !gVariable.m_sgComponentLaser.bLaserAlarm[13][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1540,strErr);
		}
	}
	else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 720)
	{
		nAlarmNo = 14;
		strErr.Format(_T("%d"),gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14]);
		if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 720 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][0])
		{
			nAlarmCheckNo = 0;
			ErrMsgDlg(STDGNALM1541,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 336 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][1])
		{
			nAlarmCheckNo = 1;
			ErrMsgDlg(STDGNALM1542,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 336 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][2])
		{
			nAlarmCheckNo = 2;
			ErrMsgDlg(STDGNALM1543,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][3])
		{
			nAlarmCheckNo = 3;
			ErrMsgDlg(STDGNALM1544,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] - 24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] && !gVariable.m_sgComponentLaser.bLaserAlarm[14][4])
		{
			nAlarmCheckNo = 4;
			ErrMsgDlg(STDGNALM1545,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] + 24 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][5])
		{
			nAlarmCheckNo = 5;
			ErrMsgDlg(STDGNALM1400 + nAlarmNo,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] +24 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] + 168 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][6])
		{
			nAlarmCheckNo = 6;
			ErrMsgDlg(STDGNALM1546,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] +168 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] + 504 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][7])
		{
			nAlarmCheckNo = 7;
			ErrMsgDlg(STDGNALM1547,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] +504 && nElapsedTime < gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] + 720 && !gVariable.m_sgComponentLaser.bLaserAlarm[14][8])
		{
			nAlarmCheckNo = 8;
			ErrMsgDlg(STDGNALM1548,strErr);
		}
		else if(nElapsedTime >= gComponentLaserINI.m_sComponentLaser.nLaserCheckTime[14] +720  && !gVariable.m_sgComponentLaser.bLaserAlarm[14][9])
		{
			nAlarmCheckNo = 9;
			ErrMsgDlg(STDGNALM1549,strErr);
		}
	}

	if(gVariable.m_sgComponentLaser.bLaserAlarm[nAlarmNo][nAlarmCheckNo] == FALSE)
	{
		m_nUseYearLaser = nAlarmNo;
		if(nAlarmNo != -1)
			gVariable.m_sgComponentLaser.bLaserAlarmReset = 0;
		gVariable.m_sgComponentLaser.nLaserCheckIndex = nAlarmNo;
		for(int i = 0 ; i < LASER_COMPONENT_COUNT; i++)
		{
			if(i == nAlarmNo)
			{
				for(int j = 0 ; j < 10; j++)
				{
					if(j <= nAlarmCheckNo)
						gVariable.m_sgComponentLaser.bLaserAlarm[i][j] = TRUE;
					else
						gVariable.m_sgComponentLaser.bLaserAlarm[i][j] = FALSE;
				}
			}
			else if(i < nAlarmNo)
			{
				for(int l = 0 ; l < 10; l++)
					gVariable.m_sgComponentLaser.bLaserAlarm[i][l] = TRUE;
			}
			else
			{
				for(int k = 0 ; k < 10; k++)
					gVariable.m_sgComponentLaser.bLaserAlarm[i][k] = FALSE;
			}
		}
		GetComponentLaser( &gComponentLaserINI.m_sComponentLaser );

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, COMPONENTLASER_INI))
		{
			//ErrMsgDlg(STDGNALM114);
		}
		CString strMsg;
		strMsg.Format(_T("Component Laser Alarm. ID : %d"),1400 + nAlarmNo);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
	}
	//Err TEST
	//for(int i = 0 ; i < 150; i++)
	//{
	//	ErrMsgDlg(STDGNALM1400 + i);
	//}
	TRACE(_T("Elapsed Time %d\n"),nElapsedTime);
}

void CPaneSysSetupComponentLaser::UpdateLaserUseTime()
{
	CTime ctCurTime, ctStartTime;
	time_t timeNow;
	double dDiffTime;
	int nElapsedTime;
	time(&timeNow);
	dDiffTime = difftime(timeNow, gVariable.m_sgComponentLaser.nComponentStartTime);

	nElapsedTime = (int)dDiffTime/3600;
	gVariable.m_nComponentLaserTime = nElapsedTime;
}

void CPaneSysSetupComponentLaser::OnDestroy()
{
	CFormView::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntEdit.DeleteObject();
}


HBRUSH CPaneSysSetupComponentLaser::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if( GetDlgItem(IDC_STATIC_LASER_COMPONENT_SET)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}


void CPaneSysSetupComponentLaser::OnBnClickedButtonReset()
{
	CDlgLogin dlg;
	CString strMsg;
	if( IDOK != dlg.DoModal() )
		return;

	if(dlg.GetUserLevel() < 2)
	{
		::AfxMessageBox(_T("Only Eo/Super Engineer can Alarm Reset"), MB_OK);
		return;
	}

	gVariable.m_sgComponentLaser.bLaserAlarmReset =1;
	
	for(int i = 0 ; i < LASER_COMPONENT_COUNT; i++)
	{
		if(i <= gVariable.m_sgComponentLaser.nLaserCheckIndex )
		{
			for(int j = 0 ; j < 10; j++)
				gVariable.m_sgComponentLaser.bLaserAlarm[i][j] = TRUE;
		}
	}
	
	GetComponentLaser( &gComponentLaserINI.m_sComponentLaser );

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, COMPONENTLASER_INI))
	{
		//ErrMsgDlg(STDGNALM114);
	}

	strMsg.Format(_T("Component Laser Alarm Reset"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));

	OnCheckRefresh();
	::AfxMessageBox(_T("Component Laser Alarm Reset"), MB_OK);
}
BOOL	CPaneSysSetupComponentLaser::ValidateComponentLaser()
{
	CString strMsg = _T("");
	for(int i = 0 ; i < LASER_COMPONENT_COUNT-1; i++)
	{
		if(gVariable.m_sgComponentLaser.nLaserCheckTime[i+1] <=  gVariable.m_sgComponentLaser.nLaserCheckTime[i])
		{
			strMsg.Format(_T("Next Laser Use Check Time is less than before time  "));
			ErrMessage( strMsg);
			return FALSE;
		}

		if((gVariable.m_sgComponentLaser.nLaserCheckTime[i+1] - gVariable.m_sgComponentLaser.nLaserCheckTime[i]) < 720)
		{
			strMsg.Format(_T("Laser Use Time Check interval must 720 hour over. "));
			ErrMessage( strMsg);
			return FALSE;
		}
	}
	
	return TRUE;
}