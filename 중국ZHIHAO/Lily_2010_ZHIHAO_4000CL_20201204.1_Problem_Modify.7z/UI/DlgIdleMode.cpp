// ui\DlgIdleMode.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "..\EasyDrillerDlg.h"
#include "ui\DlgIdleMode.h"
#include "afxdialogex.h"
#include "..\MODEL\DSystemINI.h"
#include "..\MODEL\DBeampathINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\MODEL\DProject.h"
#include "..\MODEL\DTempINI.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "DlgVisionView.h"
#include "DlgMatroxVisionView.h"
#include "DlgVisionProView.h"
#include "..\alarmmsg.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\CorrectTime.h"
#include "..\DEVICE\DeviceMotor.h"
#include "..\DEVICE\HMotor.h"
#include "..\DEVICE\HEocard.h"
#include "..\DEVICE\HLaser.h"
#include "..\DEVICE\HVision.h"
#include "DlgCalResult.h"
#include"..\MODEL\DTemperCompensation.h"
#include <math.h>
#include "..\MODEL\DSystemINI.h"
#include "..\model\globalvariable.h"
#include "..\MODEL\DShotTableINI.h"

const int SEL_HEAD_BOTH		= 0;
const int SEL_HEAD_MASTER	= 1;
const int SEL_HEAD_SLAVE	= 2;
const UINT UM_VISION_ROI_SET		= WM_APP + 61;
const UINT UM_CHANGE_VISION_PARAM3	= WM_APP + 62;
const UINT UM_VISION_FIND			= WM_APP + 63;
const UINT UM_VISION_LAMP			= WM_APP + 64;
#define MAX_AUTOCAL_COUNT	400
#define CALIBRATION_SLEEP	100
// CDlgIdleMode ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgIdleMode, CDialog)
UINT IdleThread(LPVOID pParam)
{
	CDlgIdleMode* pRun = (CDlgIdleMode*)pParam;
	BOOL bFirst = TRUE;
	do 
	{
		if(pRun->m_bDoAutoSCal || bFirst)
		{
			if(!pRun->DoSCalProcess())
				break;
		}
		Sleep(1000);
		if(pRun->m_bDoAutoPower || bFirst)
		{
			if(!pRun->DoPowerProcess())
				break;
		}
		Sleep(1000);
	
		if(!pRun->HeatingScannerBlockUsingIdleInfo())
			break;
		bFirst = FALSE;
	}while(!pRun->m_bStop);

	pRun->IdleStopProcess();
	//add stop process 
	return TRUE;
}
UINT CheckIdleTimeThread(LPVOID pParam)
{
	CDlgIdleMode* pRun = (CDlgIdleMode*)pParam;
	CTime CurTime;
	time_t timeNow, timeRef, timeRef2;
	int nSecond;
	double dNowTime, dNowTime2;
	int nPNLCount = 1;
	CString strFile, strLog;
	strFile.Format(_T("PreWork"));

	while(TRUE)
	{	
		if(!pRun->m_bDoAutoPower)
		{
			timeRef = gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][0]; //master
			timeRef2 = gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][1]; //slave

			nSecond = gProcessINI.m_sProcessCal.nPowerRelTime * 60;

			time(&timeNow);
			dNowTime = difftime(timeNow, timeRef);
			dNowTime2 = difftime(timeNow, timeRef2);
			if(gDProject.m_nSeparation == USE_DUAL)
			{
				if((int)dNowTime > nSecond || (int)dNowTime2 > nSecond)
				{
					pRun->m_bDoAutoPower = TRUE;
					strLog.Format(_T("Power Time Over dual : limit %d, last %d[%d], curr %d, last :  %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][0], pRun->m_nBeamPath, (int)dNowTime,
						gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][1], pRun->m_nBeamPath, (int)dNowTime2);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else if(gDProject.m_nSeparation == USE_1ST)
			{
				if((int)dNowTime > nSecond)
				{
					pRun->m_bDoAutoPower = TRUE;
					strLog.Format(_T("Power Time Over 1st : limit %d, last %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][0],pRun->m_nBeamPath, (int)dNowTime);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else if(gDProject.m_nSeparation == USE_2ND)
			{
				if((int)dNowTime2 > nSecond)
				{
					pRun->m_bDoAutoPower = TRUE;
					strLog.Format(_T("Power Time Over dual : limit %d, last %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoPowerEndTime[pRun->m_nBeamPath][1], pRun->m_nBeamPath, (int)dNowTime2);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
		}
		

		if(!pRun->m_bDoAutoSCal)
		{
				
			timeRef = gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][0]; //master
			timeRef2 = gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][1]; //slave

			nSecond = gProcessINI.m_sProcessCal.nScalRelTime * 60;

			time(&timeNow);
			dNowTime = difftime(timeNow, timeRef);
			dNowTime2 = difftime(timeNow, timeRef2);
			if(gDProject.m_nSeparation == USE_DUAL)
			{
				if((int)dNowTime > nSecond || (int)dNowTime2 > nSecond)
				{
					pRun->m_bDoAutoSCal = TRUE;
					strLog.Format(_T("Scanner Time Over dual : limit %d, last %d[%d], curr %d, last :  %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][0], pRun->m_nBeamPath, (int)dNowTime,
						gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][1], pRun->m_nBeamPath, (int)dNowTime2);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else if(gDProject.m_nSeparation == USE_1ST)
			{
				if((int)dNowTime > nSecond )
				{
					pRun->m_bDoAutoSCal = TRUE;
					strLog.Format(_T("Scanner Time Over 1st : limit %d, last %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][0], pRun->m_nBeamPath, (int)dNowTime);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else 
			{
				if((int)dNowTime2 > nSecond)
				{
					pRun->m_bDoAutoSCal = TRUE;
					strLog.Format(_T("Scanner Time Over 2nd : limit %d, last %d[%d], curr %d"), nSecond, 
						gTempINI.m_sTempTime.nAutoScalEndTime[pRun->m_nBeamPath][1], pRun->m_nBeamPath, (int)dNowTime2);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			
		}
	
		for(int i = 0 ; i < 600; i++) //1�п� �ѹ��� 
		{
			::Sleep(100);
			pRun->MessageLoop();

			if(!pRun->m_bTimeThread)
				return TRUE;
		}
	}
	return TRUE;
}

CDlgIdleMode::CDlgIdleMode(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIdleMode::IDD, pParent)
{
	m_pTimeThread = NULL;
	m_pRunThread = NULL;
	m_bTimeThread = FALSE;
	m_bRunIdleModeThread = FALSE;
	m_bDoAutoPower = FALSE;
	m_bDoAutoSCal = FALSE;
	m_bUserDummyOn = FALSE;
	m_bStop = FALSE;
	m_nBeamPath = -1;
	m_nErrID = -1;
	m_nMeasureCount = 0;
	m_bOldPanel = FALSE;
	m_bCtrlInit = FALSE;
	m_bIdleRun = FALSE;
	m_d1stTemper = 0;
	m_d2ndTemper = 0;
	m_d1stSBTemper = 0;
	m_d2ndSBTemper = 0;
	m_nTimer = -1;
	m_nApplyCount = 0;
}

CDlgIdleMode::~CDlgIdleMode()
{
}

void CDlgIdleMode::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SCAL_TOOL, m_listScannerTool);
	DDX_Control(pDX, IDC_LIST_SCAL2, m_listScannerResult);
	DDX_Control(pDX, IDC_LIST_POWER_TOOL2, m_listPowerTool);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_EXIT, m_btnExit);
	DDX_Control(pDX, IDC_PROGRESS_MEASURE, m_progMeasure);
	DDX_Control(pDX, IDC_STATIC_VISION_RESULT, m_stcVisionResult);
}


BEGIN_MESSAGE_MAP(CDlgIdleMode, CDialog)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_START, &CDlgIdleMode::OnBnClickedButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_EXIT, &CDlgIdleMode::OnBnClickedButtonExit)
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM3, ChangeVisionParameter)
	ON_MESSAGE(UM_VISION_FIND, GetVisionResult)
	ON_MESSAGE(UM_VISION_LAMP, SetVisionLamp)
	ON_WM_SHOWWINDOW()
	ON_WM_MOVE()
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CDlgIdleMode �޽��� ó�����Դϴ�.

BOOL CDlgIdleMode::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	this->GetSystemMenu(NULL)->EnableMenuItem(SC_CLOSE, MF_DISABLED);
	m_bCtrlInit = TRUE;

	if(m_pTimeThread == NULL)
	{
		m_pTimeThread = ::AfxBeginThread(CheckIdleTimeThread, this, THREAD_PRIORITY_NORMAL);
		m_bTimeThread = TRUE;
	}
	if(m_nTimer == -1)
	{
		m_nTimer = SetTimer(0070, 500, NULL);
	}
	return TRUE;
}

void CDlgIdleMode::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_SCANNER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL2)->SetFont( &m_fntStatic );
	
	m_stcVisionResult.SetFont( &m_fntStatic );
	m_stcVisionResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcVisionResult.SetBackColor( VALUE_BACK_COLOR );

	m_fntStatic2.CreatePointFont(300, "Arial Bold");
	GetDlgItem(IDC_STATIC_STATUS2)->SetFont( &m_fntStatic2 );


}
void CDlgIdleMode::InitListControl()
{

	m_fntList.CreatePointFont(100, "Arial Bold");

	m_listScannerTool.SetFont( &m_fntList );
	m_listScannerTool.SetExtendedStyle(m_listScannerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	m_listScannerTool.DeleteAllItems();
	m_listScannerTool.InsertColumn(0, _T(" BeamPath "), LVCFMT_CENTER, 100);
	m_listScannerTool.InsertColumn(1, _T(" Freq "), LVCFMT_CENTER, 80);
	m_listScannerTool.InsertColumn(2, _T(" Duty "), LVCFMT_CENTER, 80);
	m_listScannerTool.InsertColumn(3, _T(" ASC "), LVCFMT_CENTER, 195);

	m_listScannerResult.SetFont( &m_fntList );
	m_listScannerResult.SetExtendedStyle(m_listScannerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	m_listScannerResult.DeleteAllItems();
	m_listScannerResult.InsertColumn(0, _T(" BeamPath "), LVCFMT_CENTER, 100);
	m_listScannerResult.InsertColumn(1, _T(" 1st X "), LVCFMT_CENTER, 89);
	m_listScannerResult.InsertColumn(2, _T(" 1st Y "), LVCFMT_CENTER, 89);
	m_listScannerResult.InsertColumn(3, _T(" 2nd X "), LVCFMT_CENTER, 89);
	m_listScannerResult.InsertColumn(4, _T(" 2nd Y "), LVCFMT_CENTER, 89);

	m_listPowerTool.SetFont( &m_fntList );
	m_listPowerTool.SetExtendedStyle(m_listPowerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	m_listPowerTool.DeleteAllItems();
	m_listPowerTool.InsertColumn(0, _T(" BeamPath "), LVCFMT_CENTER, 100);
	m_listPowerTool.InsertColumn(1, _T(" Freq. "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(2, _T(" Duty "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(3, _T(" Min "), LVCFMT_CENTER, 57);
	m_listPowerTool.InsertColumn(4, _T(" Max "), LVCFMT_CENTER, 57);
	m_listPowerTool.InsertColumn(5, _T(" 1st"), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(6, _T(" 2nd"), LVCFMT_CENTER, 60);

	//Result List
	m_lboxResult.SetFont( &m_fntList );

}

void CDlgIdleMode::InitBtnControl()
{
	m_fntBtn.CreatePointFont(120, "Arial Bold");
	
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Idle Mode Start/Stop") );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.SetBtnCursor(IDC_HAND_1);

	m_btnExit.SetFont( &m_fntBtn );
	m_btnExit.SetFlat( FALSE );
	m_btnExit.EnableBallonToolTip();
	m_btnExit.SetToolTipText( _T("Idle Mode Start/Stop") );
	m_btnExit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnExit.SetBtnCursor(IDC_HAND_1);

}
HBRUSH CDlgIdleMode::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_SCANNER_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_POWER_SETTING)->GetSafeHwnd() == pWnd->m_hWnd  )
			pDC->SetTextColor( RGB(0, 0, 255 ) );

		if( GetDlgItem(IDC_STATIC_STATUS2)->GetSafeHwnd() == pWnd->m_hWnd )
			pDC->SetTextColor( RGB(255, 0, 0 ) );

	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


void CDlgIdleMode::OnBnClickedButtonStart()
{
	if(m_bRunIdleModeThread)
		IdleEndProcess();
	else
		IdleStartProcess();
}


void CDlgIdleMode::OnBnClickedButtonExit()
{
	gProcessINI.m_sProcessCal.nIdleBeamPath = m_nBeamPathBackup;
	if(m_bTimeThread && m_pTimeThread != NULL)
	{
		m_bTimeThread = FALSE;
		::WaitForSingleObject(m_pTimeThread->m_hThread, 10000); //10��
		m_pTimeThread = NULL;
		delete m_pTimeThread;
	}
	
	if(m_pRunThread != NULL)
	{
		m_bRunIdleModeThread = FALSE;
		::WaitForSingleObject(m_pRunThread->m_hThread, 10000); //10��
		m_pRunThread = NULL;
		delete m_pRunThread;
	}

	OnOK();
}
void CDlgIdleMode::IdleStopProcess()
{
	if(m_pRunThread != NULL)
	{
		m_bRunIdleModeThread = FALSE;
		::WaitForSingleObject(m_pRunThread->m_hThread, 2000); //2��
		m_pRunThread = NULL;
		delete m_pRunThread;
	}

	m_bStop = FALSE;
	m_btnStart.SetWindowText((LPCTSTR)"Start");
	m_btnExit.EnableWindow(TRUE);
	m_bIdleRun = FALSE;
	if(m_nErrID != 0)
	{
#ifndef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);	
#else
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
#endif
		ErrMsgDlg(m_nErrID);
#ifndef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);	
#else
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);	
#endif

	}

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				ErrMsgDlg(STDGNALM781);
				return;
			}
		}
	}
}
void CDlgIdleMode::IdleStartProcess()
{
	m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	m_bStop = FALSE;
	m_nMeasureCount = 0;
	m_nErrID = 0;
	m_nApplyCount = 0;

	if(!gDeviceFactory.GetLaser()->IsPowerOn()	|| !gDeviceFactory.GetLaser()->IsShutterOpen() ||
		!gDeviceFactory.GetMotor()->GetAOMStatus()	|| !gDeviceFactory.GetMotor()->GetScannerStatus() ) // LaserPower
	{

		ErrMsgDlg(STDGNALM303);
		return ;
	}

	if(m_pRunThread == NULL)
	{
		m_pRunThread = ::AfxBeginThread(IdleThread, this, THREAD_PRIORITY_NORMAL);
		m_bRunIdleModeThread = TRUE;
	}
	else
	{
		CString str;
		str.Format(_T("Wait Stop that before thread"));
		ErrMessage(str);
		return;
	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
	m_btnStart.SetWindowText((LPCTSTR)"Stop");
	m_btnExit.EnableWindow(FALSE);
	m_bIdleRun = TRUE;

}
void CDlgIdleMode::IdleEndProcess()
{
	m_bStop = TRUE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
	/*if(m_pRunThread != NULL)
	{
		m_bRunIdleModeThread = FALSE;
		::WaitForSingleObject(m_pRunThread->m_hThread, 10000); //10��
		m_pRunThread = NULL;
		delete m_pRunThread;
	}
	*/
}
void CDlgIdleMode::OnMoveVisionView()
{

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
	
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );

		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(MAIN_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );

		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(MAIN_VISION_VIEW);

		CRect rtPos; 
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->m_bTopMost = TRUE;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}

	GetDlgItem(IDC_STC_RUN_VIEW)->ShowWindow(SW_HIDE);

}

void CDlgIdleMode::MessageLoop()
{
	MSG msg;

	if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		TranslateMessage((LPMSG)&msg);
		DispatchMessage((LPMSG)&msg);
	}
}

int CDlgIdleMode::GetFirstBeamPath()
{
	BOOL bAuto = TRUE;
	BOOL bSelectOnly = FALSE;

	POSITION pos;
	LPFIREHOLE pHole;

	// ������ ���� �ִ� tool �� areaTempList�� ����
	AreaList AreaTempList;
	POSITION posArea;
	DAreaInfo *pAreaInfo;
	BOOL bFirstArea = FALSE;
	int nTool = -1;
	int nStartFidBlock, nEndFidBlock;
	if(gDProject.m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; nEndFidBlock = gDProject.m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1;
	}

	for(int nFidBlock = nStartFidBlock; nFidBlock <= nEndFidBlock; nFidBlock++) // �ٽ� ������ ���� 
	{

		for(int i = 1; i < MAX_TOOL_NO; i++)
		{
			if(!gDProject.m_pToolCode[i]->m_bUseTool)
				continue;

			posArea = gDProject.m_Areas[i].GetHeadPosition();
			while (posArea) 
			{
				pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
				if(IsAvailableArea(pAreaInfo, i, nFidBlock))
				{
					bFirstArea = TRUE;
					break;
				}
			}
			if(bFirstArea != NULL)
				break;
		}
	}
	if(!bFirstArea)
		return -1;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
					if(pHole->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
					{
						nTool  = pHole->pOrigin->nToolNo;
						break;
					}
				}
				else
				{
					if(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pHole->pOrigin->nToolNo;
						break;
					}
				}
			}
			else
			{
				nTool = pHole->pOrigin->nToolNo;
				break;
			}
		}
		if(nTool != -1)
			break;
	}

	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
					if(pLine->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pLine->pOrigin->nToolNo;
						break;
					}
				}
				else
				{
					if(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pLine->pOrigin->nToolNo;
						break;
					}
				}
			}
			else
			{
				nTool = pLine->pOrigin->nToolNo;
				break;
			}
		}
		if(nTool != -1)
			break;
	}

	SUBTOOLDATA subdata;

	if(nTool != -1)
	{
		pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		subdata = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
		return subdata.nMask;
	}
	else
		return -1;
}
BOOL CDlgIdleMode::IsAvailableArea(DAreaInfo *pAreaInfo, int nToolNo, int nFidBlock)
{
	if(pAreaInfo->IsThereSameBlockData(nFidBlock))
	{
		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emFlying)
			return FALSE;

		if(pAreaInfo->IsThereSameBlockData(nFidBlock))
			return TRUE;
		
		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emOneBoardTool)
		{
			if(!gDProject.m_pToolCode[nToolNo]->IsVisable())
				return FALSE;
			else
				return TRUE;
		}
		else
		{
			for(int i = nToolNo; i < MAX_TOOL_NO; i++)
			{
				if(pAreaInfo->IsThereData())
					return TRUE;
			}
			return FALSE;
		}
		return TRUE;
	}
	else
		return FALSE;
}

BOOL CDlgIdleMode::DoPowerProcess()
{
	CString strLog;
	strLog.Format(_T(" --- Idle Power Start ---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	InsertInfo(DO_POWER);

	BOOL bTempRunOK = OnDoPowerMeasurement();
	if(!bTempRunOK)
	{
		strLog.Format(_T(" --- Idle Power Fail ---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
		return FALSE;
	}

	m_bDoAutoPower = FALSE;

	strLog.Format(_T(" --- Idle Power End ---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));


	return TRUE;
}

BOOL CDlgIdleMode::OnDoPowerMeasurement()
{
	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();

	BOOL bRet = CheckPowerAuto();
	::Sleep(100);
	gDeviceFactory.GetEocard()->LaserOnOff(FALSE);

#ifdef __TEST__
	bRet = TRUE;
#endif

	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
		cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
		cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
		cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, POWER_JOB);
	
	return bRet;
}

BOOL CDlgIdleMode::CheckPowerAuto()
{
	time_t timeNow;
	time(&timeNow);
	memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );
	if(gDProject.m_nSeparation == USE_DUAL)
	{
		gTempINI.m_sTempTime.nAutoPowerEndTime[m_nBeamPath][0] = (int)timeNow;
		gTempINI.m_sTempTime.nAutoPowerEndTime[m_nBeamPath][1] = (int)timeNow;
	}
	else if(gDProject.m_nSeparation == USE_1ST)
		gTempINI.m_sTempTime.nAutoPowerEndTime[m_nBeamPath][0] = (int)timeNow;
	else
		gTempINI.m_sTempTime.nAutoPowerEndTime[m_nBeamPath][1] = (int)timeNow;

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
	{
		m_nErrID = STDGNALM119;
		return FALSE;
	}
	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, TRUE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif
	int nUsePanel = gDProject.m_nSeparation; 
	

	FParameter fPara;
	SUBTOOLDATA ToolData;

	if(!ChangeBeamPath(DO_POWER))
	{
		
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
		m_nErrID = STDGNALM600;
		return FALSE;
	}

	GetBeamPathLaserInfo(ToolData);

	if(!UpdateNewParam())
	{	
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
		m_nErrID = STDGNALM445;
		return FALSE;
	}
	
	double dX[2], dY[2], dZ1, dZ2;
	dX[0] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x;
	dY[0] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y;
	dX[1] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x;
	dY[1] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y;
	dZ1  = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
	dZ2  = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;

	int nCount = 0;
	double dMeasureResult[2] = {0, 0};
	CString strEvent, strInfo;
	double dVal = 0;
	int nRepeat; 
	if(gDProject.m_nSeparation == USE_DUAL)
		nRepeat = 2;
	else
		nRepeat = 1;

	for(int nHead=0; nHead<nRepeat; nHead++)
	{

		StartMeasurement(100);

		if(gDProject.m_nSeparation == USE_2ND)
			nHead = 1;

		if(!CheckStatus())
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			return FALSE;
		}

		if(!pMotor->MotorMoveXYZ(dX[nHead], dY[nHead], dZ1, dZ2, TRUE, SHOT_MOVE, TRUE))
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_nErrID = STDGNALM438;
			return FALSE;
		}

		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			if(nHead == 1)
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
				{
					
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					m_nErrID = STDGNALM417;
					return FALSE;
				}
			}
			else
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
				{
					
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					m_nErrID = STDGNALM417;
					return FALSE;
				}
			}
		}

		if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis, TRUE);
			return FALSE;
		}

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				m_nErrID = STDGNALM781;
				return FALSE;
			}
		}
		else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!gDeviceFactory.GetEocard()->EndMarkDummy())
			{
				m_nErrID = STDGNALM445; 
				return FALSE;
			}
		}

		gDeviceFactory.GetEocard()->jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);

		bResult = TRUE;
		CString strErrorPlus = _T("");
		do
		{
			::Sleep(1);
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			BOOL bTimeOutType =  gDeviceFactory.GetEocard()->IsDrillTimeOutType();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
			
				strErrorPlus = _T("Scanner Cable Error.");
				::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
				return FALSE;
			}
			else if(bScannerMotorFault)
			{
				if(bScannerMotorFault & 0x01)
					strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
				if(bScannerMotorFault & 0x02)
					strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
				if(bScannerMotorFault & 0x04)
					strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
				if(bScannerMotorFault & 0x08)
					strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
			
				strErrorPlus = strErrorMsg;
				::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
				return FALSE;
			}
			else if(bScannerDrillTimeOut)
			{
				if(bScannerDrillTimeOut & 0x01)
					strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x02)
					strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x04)
					strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x08)
					strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
			
				strErrorPlus = strErrorMsg;
				::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
				return FALSE;
			}
			if(bTimeOutType)
			{
				if(bTimeOutType & 0x01)
					strErrorMsg += _T("Unknown Time Out\r\n");
				if(bTimeOutType & 0x02)
					strErrorMsg += _T("Drill Time Out\r\n");
				if(bTimeOutType & 0x04)
					strErrorMsg += _T("LPC Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();

				strErrorPlus = strErrorMsg;
				::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM566, reinterpret_cast<LPARAM>(&strErrorPlus));
		
				return FALSE;
			}
			bResult = pEOCard->IsDSPBusy();
		}while(bResult);


		//measure
		pEOCard->LaserOnOff(TRUE);
		nCount = 0;
		while(nCount < 20) // 2 sec
		{
			if(!CheckStatus())
			{
				pEOCard->LaserOnOff(FALSE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
				{
					if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
					{
						if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
						{
							m_nErrID = STDGNALM781;
							return FALSE;
						}
					}
				}
				else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
				{
					if(!gDeviceFactory.GetEocard()->StartMarkDummy())
					{
						m_nErrID = STDGNALM445;
						return FALSE;
					}
				}
				return FALSE;
			}
			::Sleep(100);
			MessageLoop();
			nCount++;
			UpdateMeasurement(nCount);
		}

		dMeasureResult[nHead] = 0;
		double dTemp[6];
		memset( dTemp, 0, sizeof(dTemp));
		for(int i = 0; i < 6; i++)
		{

			nCount = 0;
			while(nCount < 15) // 2.5 sec
			{
				if(!CheckStatus())
				{
					pEOCard->LaserOnOff(FALSE);
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
					{
						if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
						{
							if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
							{
								m_nErrID  = STDGNALM781;
								return FALSE;
							}
						}
					}
					else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!gDeviceFactory.GetEocard()->StartMarkDummy())
						{
							m_nErrID = STDGNALM445;
							return FALSE;
						}
					}
					return FALSE;
				}
				::Sleep(100);
				MessageLoop();
				nCount++;
				UpdateMeasurement(20 + (nCount+15*i));
			}
			dTemp[i] = ::AfxGetMainWnd()->SendMessage(UM_POWER_MEASURE, nHead, -1);
			dTemp[i] /= 1000.;
		
			InsertPowerResult(dTemp[i],i,!nHead,FALSE);
			
			if(dTemp[i] <= 0.5)
			{
				pEOCard->LaserOnOff(FALSE);
				CString strMsg = _T("");
				strMsg.Format(_T("Laser power = %.3f.\nCheck laser power measuring position or port setting"), dTemp[i]);
				ErrMessage(strMsg);
				
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				m_nErrID = STDGNALM707;
				return FALSE;
			}
		}
		pEOCard->LaserOnOff(FALSE);
		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun()  && m_bUserDummyOn)
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
				{
					m_nErrID = STDGNALM781;
					return FALSE;
				}
			}
		}
		else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!gDeviceFactory.GetEocard()->StartMarkDummy())
			{
				m_nErrID = STDGNALM445;
				return FALSE;
			}
		}
		double dMin1 = 99999;
		int nMinIndex = -1;
		for(int k = 0; k < 6; k++)
		{
			if(dMin1 >= dTemp[k])
			{
				dMin1 = dTemp[k];
				nMinIndex = k;
			}
		}
		for(int k = 0; k < 6; k++)
		{
			if(k != nMinIndex)
				dMeasureResult[nHead] += dTemp[k];
		}

		dMeasureResult[nHead] = dMeasureResult[nHead]/5; 
		InsertPowerResult(dMeasureResult[nHead], -1, !nHead, TRUE);

#ifdef __TEST__
		dMeasureResult[nHead] = 5.52;
#endif

		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_nBeamPath];

		if(dMeasureResult[nHead] >= gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0] &&
			dMeasureResult[nHead] <= gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0])
		{
			bResult &= TRUE;
		}

	}

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
	{
		
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
		m_nErrID = STDGNALM417; // shutter sensor error
		return FALSE;
	}

	// log
	strEvent = _T("Idle Power Measure Result");


	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_nBeamPath];

	strInfo.Format(_T("Master Power Average = %f | Slave Power Average = %f | Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Duty = %.1f um | Beam Path No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm "),
			dMeasureResult[0], dMeasureResult[1],
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0], 
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0],
			m_nBeamPath, dZ1, dZ2);
			
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));


		SavePowerAuto(TRUE, dMeasureResult[0], dMeasureResult[1], dZ1, dZ2, m_nBeamPath, gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath], 
			gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex], 
			gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath],
			gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath]);

		SavePowerAuto(FALSE, dMeasureResult[0], dMeasureResult[1], dZ1, dZ2,m_nBeamPath, gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath], 
			gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex], 
			gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath],
			gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath]);

	

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif


	gOPCParam.dPowerMeasure[0] = dMeasureResult[0];
	gOPCParam.dPowerMeasure[1] = dMeasureResult[1];

	gOPCParam.dPowerTarget[0] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[m_nBeamPath];
	gOPCParam.dPowerTarget[1] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[m_nBeamPath];
	gOPCParam.dPowerTargetMin[0] = gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[m_nBeamPath];
	gOPCParam.dPowerTargetMin[1] = gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[m_nBeamPath];
	gOPCParam.dPowerTargetMax[0] = gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[m_nBeamPath];
	gOPCParam.dPowerTargetMax[1] = gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[m_nBeamPath];
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_POWER);
	return TRUE;
}

BOOL CDlgIdleMode::DoSCalProcess()
{
	CString strLog;
	strLog.Format(_T(" --- Idle SCal Start ---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	m_nApplyCount++;
	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();

	if(DoSCalAuto())
	{
		m_bDoAutoSCal = FALSE;

		strLog.Format(_T(" --- Idle SCal End ---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
			m_nErrID = STDGNALM119;
			return FALSE;
		}
		if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam())
		{
			m_nErrID = STDGNALM445;
			return FALSE;
		}
	}
	else
	{
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
			m_nErrID = STDGNALM119;
			return FALSE;
		}
		strLog.Format(_T(" --- Idle SCal Fail ---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

		return FALSE;
	}
	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
		cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
		cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
		cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, SCAL_JOB);


	return TRUE;
}


void CDlgIdleMode::SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
								  int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
								  int ndiff, int nJobType)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strpathName+=_T("JobTime");
	CTime  curDate = CTime::GetCurrentTime();
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());

	strpathName+=strCurTime;

	//�켱 ���� �˻�
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;

	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strType;
		if(nJobType == PREHEAT_JOB)
			strType.Format(_T("H"));
		else if(nJobType == SCAL_JOB)
			strType.Format(_T("S"));
		else if(nJobType == POWER_JOB)
			strType.Format(_T("P"));
		else
			strType.Format(_T("D"));

		strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
			strType,
			nStartYear, nStartMonth, nStartDay, nStartHour, nStartMin, nStartSec, 
			nEndYear, nEndMonth, nEndDay, nEndHour, nEndMin, nEndSec,
			ndiff);


		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH

		file.Close();

}


BOOL CDlgIdleMode::ChangeBeamPath(int nToolType)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dC1, dC2, dA1, dA2, dM1, dM2, dM3, dZ1, dZ2; 
	CString strVal;
	BOOL bTophat;

	if(nToolType == DO_POWER)
	{
		dZ1 = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
		dZ2 = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
	}
	else if(nToolType == DO_SCANNER)
	{
		dZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[m_nBeamPath] - gProcessINI.m_sProcessScannerCal.dAuto1stThickness; 
		dZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[m_nBeamPath] - gProcessINI.m_sProcessScannerCal.dAuto2ndThickness; 
	}
	
	BOOL bLaserPath; 
	
	bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nBeamPath];
	bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[m_nBeamPath];

	dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[m_nBeamPath];
	dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[m_nBeamPath];
	dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[m_nBeamPath];
	dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[m_nBeamPath];

	dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_nBeamPath];
	dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_nBeamPath];
	dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_nBeamPath];	

	
	if(!pMotor->MoveTophatShutter(bTophat))
		return FALSE;

	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrID = STDGNALM974;
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
	
#ifndef __SERVO_MOTOR__
		if(!pMotor->MoveZMCA2(	dZ1, dZ2, dM1, dM2, dC1, dC2, dA1, dA2, TRUE, bTophat))
#else 
		if(!pMotor->MoveZMCA3(	dZ1, dZ2, dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, bTophat))
#endif
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			return FALSE;
		}
	}
	else // not use M, C
	{

		if(!pMotor->MoveZMC2(dZ1, dZ2, dA1, dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
			return FALSE;
		}
	}

	if(!pMotor->InPositionIO(IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
		return FALSE;
	}

	return TRUE;
}

void CDlgIdleMode::GetBeamPathLaserInfo(SUBTOOLDATA &subTool)
{
	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_nBeamPath];
	subTool.nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath];
	subTool.dShotDuty[0] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex];
	subTool.dShotAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath];
	subTool.dShotAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath];

	
	

	subTool.dMinPower = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0];
	subTool.dMaxPower = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0];
}
BOOL CDlgIdleMode::UpdateNewParam()
{
	ASSERT(gDeviceFactory.GetEocard() != NULL);
	FParameter  fParameter;
	gDeviceFactory.GetEocard()->GetParameter(&fParameter);

	CString strData;
	fParameter.Frequency =  gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath];
	double dCurrent;
	int nThermalTrack;

	double dMaskDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowOffsetDuty[m_nBeamPath];
	double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[m_nBeamPath];
	double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[m_nBeamPath];
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[m_nBeamPath];
	//double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[m_nBeamPath];
	//double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[m_nBeamPath];
	//BOOL bRet = gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2);
	/*if(!bRet)
	{
		m_nErrID = STDGNALM117;
		return bRet;
	}*/
	int nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_nBeamPath];

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		fParameter.dDuty = 5000; // 50%
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;
		nThermalTrack = gProcessINI.m_sProcessPowerMeasure.nThermalTrack;		
		gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, fParameter.Frequency, nThermalTrack);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;		
		fParameter.dDuty = 5000; // 50%
	}
	else
	{
		//fParameter.dDuty = static_cast<unsigned short>(gBeamPathINI.m_sBeampath.dPowCompensationDuty[m_nBeamPath] * 100 + 0.5);
		//fParameter.dDuty += (dMaskDutyOffset) * 100 + dPowerDutyOffset * 100;
		//
		//dAOMDelay = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath];//subTool.dShotAOMDelay[0];
		//dAOMDuty = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath];//subTool.dShotAOMDuty[0];
		//fParameter.dAOMDelay = dAOMDelay + dMaskAOMDelayOffset;
		//fParameter.dAOMDuty = dAOMDuty + dMaskAOMDutyOffset + dPowerDutyOffset;
//		//
	//tool�� ��� eocard�� �ٿ�ε����ִ� aodfile ���
	//	strData.Format(_T("%s"), gBeamPathINI.m_sBeampath.strPowCompensationAomFile[m_nBeamPath]);//subTool.cAOMFilePath);
	//	memcpy(fParameter.cAOMFilePath, strData, strData.GetLength() + 1);

		fParameter.dDuty = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nSelectShotIndex];
	}

	
	//gVariable.m_sgShotGroupTable.		gShotTableINI.m_sShotGroupTable.dVoltage_M[nSelectShotIndex]

	//gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
	//		subTool.dShotDuty[0] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

	gVariable.m_sgShotGroupTable.dVoltage_M[nSelectShotIndex] = gShotTableINI.m_sShotGroupTable.dVoltage_M[nSelectShotIndex];
	gVariable.m_sgShotGroupTable.dVoltage_S[nSelectShotIndex] = gShotTableINI.m_sShotGroupTable.dVoltage_S[nSelectShotIndex];


	return gDeviceFactory.GetEocard()->SetParameter(&fParameter, m_nBeamPath, 0, 0, 0);


//		return /*bRet &&*/ m_pEOCard->SetParameter(&m_NewParameter, m_sProcessPowerMeasure.nMask);

}
void CDlgIdleMode::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : m_nErrID = STDGNALM404; break;
	case IND_Y : m_nErrID = STDGNALM405; break;
	case IND_Z1 : m_nErrID = STDGNALM406; break;
	case IND_Z2 : m_nErrID = STDGNALM407; break;
	case IND_M1 : m_nErrID = STDGNALM408; break;
	case IND_M2 : m_nErrID = STDGNALM409; break;
	case IND_M3 : m_nErrID = STDGNALM990; break;
	case IND_C1 : m_nErrID = STDGNALM410; break;
	case IND_C2 : m_nErrID = STDGNALM411; break;
	}

	if(bShow)
		ErrMsgDlg(m_nErrID);
}


BOOL CDlgIdleMode::SavePowerAuto(BOOL bSaveOri, double d1stMeasureResult, double d2ndMeasureResult, double dZ1, double dZ2, int nMask, int nFrequency, double dDuty, double dAOMDelay, double dAOMDuty)
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();

	CTime curDate = CTime::GetCurrentTime();

	CString strDate;
	strDate.Format(_T("%04d%02d"),curDate.GetYear(), curDate.GetMonth());

	if(bSaveOri)
		strPathName += _T("PowerTrend");
	else
		strPathName += _T("PowerAuto") + strDate;

	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return FALSE;


	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nMask];
	TRY
	{
		file.SeekToEnd();
		CString strBuf;
#ifdef __3RDAOD__
#ifdef __SERVO_MOTOR__
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f | %d, %d, %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			nMask, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nMask], gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nMask],dZ1, dZ2,
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0],
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);

#else
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f | %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			nMask, dZ1, dZ2,
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0],
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);
#endif
#else
#ifdef __SERVO_MOTOR__
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f, %.1f, %.1f | %d, %d, %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			dAOMDelay, dAOMDuty, nMask, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nMask], gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nMask],dZ1, dZ2,
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0],
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);

#else
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f, %.1f, %.1f | %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			dAOMDelay, dAOMDuty, nMask, dZ1, dZ2,
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0],
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);
#endif
#endif
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
		file.Close();
	return TRUE;
}

BOOL CDlgIdleMode::DoSCalAuto() 
{
	SaveScalTime(TRUE, TRUE);
	SaveScalTime(FALSE, TRUE);

	if(!ControlDeviceForScal(TRUE))
		return FALSE;

	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	//do table clamp checking need?

	int nSelHead = gDProject.m_nSeparation;

	if(!DownScalParam())
	{
		return FALSE;
	}
	double dPosX = 0.0, dPosY = 0.0, dStartX = 0.0, dStartY = 0.0;
	dPosX = gProcessINI.m_sProcessScannerCal.dAutoStart.x;
	dPosY = gProcessINI.m_sProcessScannerCal.dAutoStart.y;

	// ROI���� ����
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		for(int ii = 0; ii<MAX_CAMERA; ii++)
		{
			if(ii%2)
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowCalArea, ii);
			else
				this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, ii);
		}
	}

	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];

	for(int i=0; i<4; i++)
	{
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nBeamPath];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nBeamPath];
		if( i < 2)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[0] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[0] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[0] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
				sVisionInfo.nCoaxial[1] = 0;
				sVisionInfo.nRing[1] = 0;
				sVisionInfo.nIR[1] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[0] = 0;
				sVisionInfo.nRing[0] = 0;
				sVisionInfo.nIR[0] = 0;
				sVisionInfo.nCoaxial[1] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[1] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[1] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
			}
		}
		else
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[2] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[2] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[2] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
				sVisionInfo.nCoaxial[3] = 0;
				sVisionInfo.nRing[3] = 0;
				sVisionInfo.nIR[3] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[2] = 0;
				sVisionInfo.nRing[2] = 0;
				sVisionInfo.nIR[2] = 0;
				sVisionInfo.nCoaxial[3] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[3] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[3] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
			}
		}
	}

	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nBeamPath];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nBeamPath];

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = 9; //������ 

	BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath];
	CString strEvent, strInfo, strTemp;

	if(!CheckStatus()) // StopȮ��
		return FALSE;

	BOOL bSuccess;
	int nDo;
	// Find Previous Hole & Fire Hole & Find Hole
	for( nDo = 0; nDo < gProcessINI.m_sProcessCal.nAutoCalibrationCount; nDo++)
	{
		bSuccess = FALSE;
		InsertInfo(DO_SCANNER);

		if(!DownloadASC())
		{
			return FALSE;
		}

		int nMaxCount = gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount*100;
		/*if(gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount == 2)
			nMaxCount = MAX_AUTOCAL_COUNT - 100;*/

		if (gProcessINI.m_sProcessScannerCal.nCountAuto >= nMaxCount)		
		{
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif

			::Sleep(500);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 0);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
			m_nErrID = STDGNALM778;
			return FALSE;
		}

		// ��ġ�� ���		
		CalculateAutoStartPosition();

		if(nSelHead != SEL_HEAD_SLAVE)
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
			::Sleep(CALIBRATION_SLEEP / 2);
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
			::Sleep(CALIBRATION_SLEEP / 2);
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}

		if(!CheckStatus()) // StopȮ��
			return FALSE;

		gProcessINI.m_sProcessScannerCal.nCountAuto++;

		// ���� Hole�� �ִ� �� Ȯ��
		if(!bIsSkipBoardCheck)
		{
			if(!DoFindPreviousHole(bUseLowCam))
			{
				continue;
			}
		}

		if(!CheckStatus()) // StopȮ��
			return FALSE;

		// Laser�߻�~
		if(!DoFireCalibrationHole(nSelHead, bUseLowCam))
		{
			continue;
		}

		if(!CheckStatus()) // StopȮ��
			return FALSE;

		// Holeã��
		if(!DoFindCurrentShot(bUseLowCam))
		{
			continue;
		}
		
		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			// apply ASC
//			if(m_nApplyCount <3)
			{
				if(!DoApplySCalResult())
				{
#ifdef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1);
#else
					pMotor->SetOutPort((BYTE)(ADD0B_WRITE_OUTPORT + PORT_ALARM), 1);
#endif
					::Sleep(500);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
					m_nErrID = STDGNALM116;
					return FALSE;
				}
			}
			//ã���� ���а� �����̰� �α׳��� 
			SaveSCalResult();
			InsertSCalResult(m_dMaxOffsetMasterX ,m_dMaxOffsetMasterY, m_dMaxOffsetSlaveX, m_dMaxOffsetSlaveY );

			if(nSelHead == USE_DUAL)
			{
				if(fabs(m_dMaxOffsetMasterX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
				fabs(m_dMaxOffsetMasterY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY &&
				fabs(m_dMaxOffsetSlaveX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
				fabs(m_dMaxOffsetSlaveY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
				{
					bSuccess = TRUE;
					break;
				}
			}
			else if(nSelHead == USE_1ST)
			{
				if(fabs(m_dMaxOffsetMasterX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
				fabs(m_dMaxOffsetMasterY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
				{
					bSuccess = TRUE;
					break;
				}
			}
			else
			{
				if(fabs(m_dMaxOffsetSlaveX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
				fabs(m_dMaxOffsetSlaveY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
				{
					bSuccess = TRUE;
					break;
				}
			}
		}
	}

	if(nDo >= gProcessINI.m_sProcessCal.nAutoCalibrationCount)
	{
#ifndef __TEST__
		m_nErrID = STDGNALM712;
		return FALSE;
#endif
	}

	if(bSuccess)
	{
		if(nSelHead != SEL_HEAD_SLAVE)
			SaveScalTime(TRUE, FALSE);

		if(nSelHead != SEL_HEAD_MASTER)
			SaveScalTime(FALSE, FALSE);
	}

	if(!bSuccess)
	{
#ifndef __TEST__
		m_nErrID = STDGNALM712;
		return FALSE;
#endif
	}

#ifdef __TEST__
	bResult = TRUE;
#endif
	return bResult;
}

BOOL CDlgIdleMode::ControlDeviceForScal(BOOL bStart)
{
	BOOL bRes = TRUE, bCalmp = FALSE;
	if(bStart)
	{
		gDeviceFactory.GetMotor()->TableClamp(TRUE, TRUE);
		gDeviceFactory.GetMotor()->TableClamp(TRUE, FALSE);
	}

	bRes = ((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE); // �׻� �ݱ�

	gDeviceFactory.GetEocard()->MoveToCenter();

	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, bStart);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, bStart);

	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, bStart);

	int nCount = 0;
	BOOL bmaster, bslave;
	do 
	{
		if(!gSystemINI.m_sHardWare.nTableClamp)
		{
			bCalmp = TRUE;
			break;
		}

		bmaster = gDeviceFactory.GetMotor()->GetCurrentTableClamp(TRUE, TRUE);
		bslave = gDeviceFactory.GetMotor()->GetCurrentTableClamp(FALSE, TRUE);

		if(gDProject.m_nSeparation == USE_DUAL)
		{
			if(bmaster && bslave)
			{	
				bCalmp = TRUE;
				break;
			}
		}
		else if(gDProject.m_nSeparation == USE_1ST)
		{
			if(bmaster)
			{
				bCalmp = TRUE;
				break;
			}
		}
		else 
		{
			if(bslave)
				bCalmp = TRUE;
			break;
		}

		if (++nCount > 200)	//4 Sec
			break;

		::Sleep(20);
	} while (TRUE);

	if(!bRes)
	{
		m_nErrID = STDGNALM417;
	}
	else if(!bCalmp)
	{
		if(!bmaster)
			m_nErrID = STDGNALM530;
		else if(!bslave)
			m_nErrID = STDGNALM531;
	}
	bRes = bRes & bCalmp;

	return bRes;
}

BOOL CDlgIdleMode::DownScalParam()
{
	SUBTOOLDATA subTool;
	GetLaserParam(subTool);

	// subTool download
	//if(!gDeviceFactory.GetEocard()->SetVoltage(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[m_nBeamPath], gBeamPathINI.m_sBeampath.dBeamPathVoltage2[m_nBeamPath]))
	//{
	//	m_nErrID = STDGNALM117;
	//	return FALSE;
	//}
	if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(SCANNER_CAL_TOOL, subTool))
	{
		m_nErrID = STDGNALM445;
		return FALSE;
	}

	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(subTool.nJumpDelay))// / subTool.nDrawStepPeriod))
	{
		m_nErrID = STDGNALM445;
		return FALSE;
	}

	// Laser Current Set
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(!gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack))
		{
			m_nErrID = STDGNALM444;
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		if(!gDeviceFactory.GetLaser()->SetCurrent(subTool.dCurrent))
		{
			m_nErrID = STDGNALM444;
			return FALSE;
		}
	}

	return TRUE;
}


void CDlgIdleMode::GetLaserParam(SUBTOOLDATA &subTool)
{
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;

	subTool.nJumpDelay = (int)(gBeamPathINI.m_sBeampath.dScannerJumpDelay);

	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1000;

	// Drill
	subTool.nShotMode = 1; // cycle mode
	subTool.nTotalShot = gBeamPathINI.m_sBeampath.nScannerTotalShot[m_nBeamPath];
	subTool.nBurstShot = 1;
	subTool.nMask = m_nBeamPath;
	subTool.bUseTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nBeamPath];

	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < subTool.nTotalShot; i++)
	{
		subTool.dShotDuty[i] = gBeamPathINI.m_sBeampath.dScannerDuty[m_nBeamPath];
		subTool.dShotAOMDelay[i] = gBeamPathINI.m_sBeampath.dScannerAomdelay[m_nBeamPath];
		subTool.dShotAOMDuty[i] = gBeamPathINI.m_sBeampath.dScannerAomDuty[m_nBeamPath];
		strcpy_s(subTool.cAOMFilePath[i], strAOMFile);

		subTool.dShotDutyOffsetM[i] = 0;
		subTool.dShotDutyOffsetS[i] = 0;
		subTool.dShotVolOffsetM[i] = 0;
		subTool.dShotVolOffsetS[i] = 0;
	}
	subTool.bUseAperture = FALSE;
	subTool.nApertureBurst = 1;
	subTool.dZOffset = 0;

	// Memo
	subTool.cToolMemo[0] = NULL;

}

LRESULT CDlgIdleMode::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}

BOOL CDlgIdleMode::DownloadASC()
{
	CString strString, strMsg;
	strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
	strMsg.Format(strString, "ASC");

	CString strMaster, strSlave;
	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);

	TCHAR sz1stFile[255], sz2ndFile[255];
	lstrcpy(sz1stFile, strMaster);
	lstrcpy(sz2ndFile, strSlave);

	if(!InitAGCInfo(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		m_nErrID = STDGNALM118;
		return FALSE;
#endif
	}

	if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		m_nErrID = STDGNALM105;
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL CDlgIdleMode::InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave)
{
	if(!m_calAGCMaster.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	TCHAR szBackupFolder[255];
	lstrcpy(szBackupFolder, gEasyDrillerINI.m_clsDirPath.GetBackupDir());
	m_calAGCMaster.SetBackupFolder(szBackupFolder);
	if(!m_calAGCMaster.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCMaster.SetAGCInfo(9, strMaster, FALSE, TRUE))
		return FALSE;

	if(!m_calAGCSlave.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	m_calAGCSlave.SetBackupFolder(szBackupFolder);
	if(!m_calAGCSlave.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCSlave.SetAGCInfo(9, strSlave, FALSE, TRUE))
		return FALSE;

	return TRUE;
}

void CDlgIdleMode::CalculateAutoStartPosition()
{
	int nOpreationTime = gProcessINI.m_sProcessScannerCal.nCountAuto;
	int nField = nOpreationTime / 100;
	int nStartPosY = (nOpreationTime % 100) / 10;
	int nStartPosX = (nOpreationTime % 100) % 10;
	int nOffsetPosY = nOpreationTime / 19;
	int nOffsetPosX = nOpreationTime % 19;

	gProcessINI.m_sProcessScannerCal.dScanYTemp = gProcessINI.m_sProcessScannerCal.dAutoStart.y + (nStartPosY * 0.62);
	gProcessINI.m_sProcessScannerCal.dScanXTemp = gProcessINI.m_sProcessScannerCal.dAutoStart.x + (nStartPosX * 0.62) + (nField * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );

}
LRESULT CDlgIdleMode::ChangeVisionParameter(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);

		pVision->OnApplyVisionParameter(pVisInfo->nModelType, wParam, *pVisInfo );
	}
	return 1L;
}

BOOL CDlgIdleMode::DoFindPreviousHole(BOOL bUseLowCam)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	double dStartPrefindZ1, dStartPrefindZ2 = 0.;
	int nMax = max(1, gProcessINI.m_sProcessCal.nAutoCalibrationCount);

	if(bUseLowCam)
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}

	if (!pMotor->MoveZ(dStartPrefindZ1, dStartPrefindZ2))
	{
		m_nErrID = STDGNALM438;
		return FALSE;
	}

	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}


	if(!CheckStatus()) // StopȮ��
		return FALSE;

 	if (!CheckMotorPositionValidity())
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		gProcessINI.m_sProcessScannerCal.nCountAuto--;
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		m_nErrID = STDGNALM780;
		return FALSE;
	}

	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(nSelHead != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (nSelHead != SEL_HEAD_MASTER)
		n2ndUse = emSlave;

	BOOL bPreFound = TRUE;
	if(bFindFast)
	{
		bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n1stUse, n2ndUse);
	}
	else
	{
		if(n1stUse == emMaster)
			bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n1stUse);
		if(bPreFound && n2ndUse == emSlave)
			bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n2ndUse);
	}
	if(!bPreFound)
	{
		if(!CheckStatus()) // StopȮ��
			return FALSE;

		m_nErrID = STDGNALM779;
		return FALSE;
	}
	return TRUE;
}

BOOL CDlgIdleMode::CheckMotorPositionValidity()
{
	double dStartPosX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
	double dStartPosY = gProcessINI.m_sProcessScannerCal.dScanYTemp;
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;

	double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	double dHalfFieldSize = dFieldSize / 2.0;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath];

	double dVisionZ1 = 0.0, dVisionZ2 = 0.0;
	if(bUseLowCam)
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}

	double dFireZ1, dFireZ2;

	dFireZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[m_nBeamPath] - dCalThick;
	dFireZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[m_nBeamPath] - dCalThick2nd;

	if (IsOutOfAxisValidity(AXIS_X, dStartPosX))
		return FALSE;
	if (IsOutOfAxisValidity(AXIS_Y, dStartPosY))
		return FALSE;

	double dHeadOffsetX, dHeadOffsetY;

	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}

		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Z1, dVisionZ1))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z1, dFireZ1))
			return FALSE;
	}

	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}

		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Z2, dVisionZ2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z2, dFireZ2))
			return FALSE;
	}

	return TRUE;
}

BOOL CDlgIdleMode::IsOutOfAxisValidity(int nAxis, double dVal)
{
	if (dVal < gSystemINI.m_sAxisInfo[nAxis].dLimitMinus || dVal > gSystemINI.m_sAxisInfo[nAxis].dLimitPlus)
		return TRUE;
	else
		return FALSE;
}
BOOL CDlgIdleMode::FindPreviousShot(double dZ1, double dZ2, emHEAD emHead)
{
	return FindShot(dZ1, dZ2, emHead, false);
}

BOOL CDlgIdleMode::FindPreviousShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd)
{
	return FindShot(dZ1, dZ2, em1st, em2nd, false, NULL);
}

BOOL CDlgIdleMode::FindShot(double dZ1, double dZ2, emHEAD emHead, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	if(!CheckStatus()) // StopȮ��
		return FALSE;

	//Ž������
	// 1 2 3
	// 6 5 4
	// 7 8 9

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = 9;
	int nSelHead = gDProject.m_nSeparation;
	BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath];//TRUE; // ������ ����

	double dStartPosX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
	double dStartPosY = gProcessINI.m_sProcessScannerCal.dScanYTemp;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;

	const double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	const double dHalfFieldSize = dFieldSize / 2.0;

	int nRepeatTime = 1;
	if(bSave == true)
		nRepeatTime = 10;

	BOOL bMaster;
	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	if (!pMotor->MoveZ(dZ1, dZ2))	
	{
		m_nErrID = STDGNALM438;
		return FALSE;
	}

	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString strResult, strPos, strData;
	BOOL bRet;
	int nKK, nCam, nIndexNo, nIndex;

	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];

	for(int i=0; i<4; i++)
	{
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nBeamPath];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nBeamPath];
		if( i < 2)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[0] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[0] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[0] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
				sVisionInfo.nCoaxial[1] = 0;
				sVisionInfo.nRing[1] = 0;
				sVisionInfo.nIR[1] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[0] = 0;
				sVisionInfo.nRing[0] = 0;
				sVisionInfo.nIR[0] = 0;
				sVisionInfo.nCoaxial[1] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[1] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[1] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
			}
		}
		else
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[2] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[2] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[2] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
				sVisionInfo.nCoaxial[3] = 0;
				sVisionInfo.nRing[3] = 0;
				sVisionInfo.nIR[3] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[2] = 0;
				sVisionInfo.nRing[2] = 0;
				sVisionInfo.nIR[2] = 0;
				sVisionInfo.nCoaxial[3] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[3] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[3] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
			}
		}

	}

	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nBeamPath];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nBeamPath];

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		if(emHead == emMaster && nCountY == 0 && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}
		if(emHead == emSlave && nCountY == 0 && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}

		if(emHead == emMaster)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			else
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		else if(emHead == emSlave)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			else
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		// ���� ���� ��ȭ�� ���� ������ ��ġ�� ����Ǵ� ���� �ذ��� ���� �߰�
		if(emHead == emSlave && gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dMoveY -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y);
		}
		if(emHead == emSlave && !gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dMoveY -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y);
		}

		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			
			if(!bSave && nCountX != 0)
				return TRUE;
			if(emHead == emMaster)
			{
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
				else
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}
			else if(emHead == emSlave)
			{
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
				else
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}

			if ((nCountY % 2) == 1)
			{
				if(emHead == emMaster)
					dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
				else if(emHead == emSlave)
					dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
			}
			// ���� ���� ��ȭ�� ���� ������ ��ġ�� ����Ǵ� ���� �ذ��� ���� �߰�
			if(emHead == emSlave && gProcessINI.m_sProcessScannerCal.bDefaultLow)
			{
				dMoveX -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x);
			}
			if(emHead == emSlave && !gProcessINI.m_sProcessScannerCal.bDefaultLow)
			{
				dMoveX -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x);
			}

			if(!CheckStatus()) // StopȮ��
				return FALSE;

			if (!pMotor->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2 , bMaster, FALSE))	
			{
				m_nErrID = STDGNALM438;
				return FALSE;
			}

			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}

			if (bSave)
			{
				pMotor->GetPosition(AXIS_X, dPosX);
				pMotor->GetPosition(AXIS_Y, dPosY);
			}

			nCam = 0;
			if(emHead == emMaster)
			{
				if(bUseLowCam)
					nCam = 1;
				else
					nCam = 0;
			}
			else
			{
				if(bUseLowCam)
					nCam = 3;
				else
					nCam = 2;
			}

			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				nIndexNo = 6;
				if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
					nIndexNo = 4;

				bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);

				if(bRet)
					break;
			}
			strResult.Format(_T("%s"), myResultChar);
			m_stcVisionResult.SetWindowText( strResult );
			
			if (bRet) 
			{
				if(bSave)
				{
					if(nCountY%2)
						nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
					else
						nIndex = GetPointIndex(nCountX, nCountY, nDivision);

#ifndef __TEST__
					pdPos[nIndex].x = dPosX;
					pdPos[nIndex].y = dPosY;
#else
					pdPos[nIndex].x = dMoveX;
					pdPos[nIndex].y = dMoveY;
#endif
					pdOffset[nIndex] = visionResult;
					pSuccess[nIndex] = true;
				}
				else
				{
#ifdef __TEST__
					return TRUE;
#else
					m_nErrID = STDGNALM711; // hole �� �߰ߵǾ��ٴ� �޽��� 2011.9.28
					return FALSE;
#endif
				}
			}
			else
			{
				if(bSave)
				{
					m_nErrID = STDGNALM711;
					return FALSE;
				}
			}
		}
	}
	Sleep(100);

	return TRUE;
}


BOOL CDlgIdleMode::FindShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	if(!CheckStatus()) // StopȮ��
		return FALSE;

	//Ž������
	// 1 2 3
	// 6 5 4
	// 7 8 9

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = 9;
	int nSelHead = gDProject.m_nSeparation;
	BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath]; // ������ ����

	double dStartPosX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
	double dStartPosY = gProcessINI.m_sProcessScannerCal.dScanYTemp;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;

	CString strGetVal = _T("");

	const double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	const double dHalfFieldSize = dFieldSize / 2.0;

	int nRepeatTime = 1;
	if(bSave == true)
		nRepeatTime = 10;

	if(!bSave)
		nDivision = 2;

	if (!pMotor->MoveZ(dZ1, dZ2))	
	{
		m_nErrID = STDGNALM438;
		return FALSE;
	}

	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString strResult, strPos, strData;
	BOOL bRet;
	int nKK, nCam, nIndexNo, nIndex;

	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];

	for(int i=0; i<4; i++)
	{
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nBeamPath];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nBeamPath];
		if( i < 2)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[0] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[0] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[0] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
				sVisionInfo.nCoaxial[1] = 0;
				sVisionInfo.nRing[1] = 0;
				sVisionInfo.nIR[1] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[0] = 0;
				sVisionInfo.nRing[0] = 0;
				sVisionInfo.nIR[0] = 0;
				sVisionInfo.nCoaxial[1] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
				sVisionInfo.nRing[1] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
				sVisionInfo.nIR[1] = gBeamPathINI.m_sBeampath.nScannerIR[m_nBeamPath];
			}
		}
		else
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) 
			{
				sVisionInfo.nCoaxial[2] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[2] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[2] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
				sVisionInfo.nCoaxial[3] = 0;
				sVisionInfo.nRing[3] = 0;
				sVisionInfo.nIR[3] = 0;
			}
			else
			{
				sVisionInfo.nCoaxial[2] = 0;
				sVisionInfo.nRing[2] = 0;
				sVisionInfo.nIR[2] = 0;
				sVisionInfo.nCoaxial[3] = gBeamPathINI.m_sBeampath.nScannerCoaxial2[m_nBeamPath];
				sVisionInfo.nRing[3] = gBeamPathINI.m_sBeampath.nScannerRing2[m_nBeamPath];
				sVisionInfo.nIR[3] = gBeamPathINI.m_sBeampath.nScannerIR2[m_nBeamPath];
			}
		}
	}

	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nBeamPath];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nBeamPath];

	double dPanelOffsetX, dPanelOffsetY;

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		else
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));

		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0)
				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			else
				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));

			if ((nCountY % 2) == 1)
			{
				dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
			}

			if(!CheckStatus()) // StopȮ��
				return FALSE;

			if (!pMotor->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2 , TRUE, FALSE))	
			{
				m_nErrID = STDGNALM438;
				return FALSE;
			}

			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}

#ifndef __TEST__
			//			::Sleep(50);
#endif

			if (bSave)
			{
				gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, FALSE);
				gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, FALSE);
			}

			if(em1st == emMaster)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
					else
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
				}

				if(bUseLowCam)
					nCam = 1;
				else
					nCam = 0;

				for(nKK=0; nKK< nRepeatTime; nKK++)
				{
					nIndexNo = 6;
					if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
						nIndexNo = 4;

					bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);

					if(bRet)
						break;
				}
					strResult.Format(_T("%s"), myResultChar);
				m_stcVisionResult.SetWindowText( strResult );
				
				if (bRet) 
				{
					if(bSave)
					{
						if(nCountY%2)
							nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
						else
							nIndex = GetPointIndex(nCountX, nCountY, nDivision);

#ifndef __TEST__
						pdPos[nIndex].x = dMoveX; 
						pdPos[nIndex].y = dMoveY;
#else
						pdPos[nIndex].x = dMoveX;
						pdPos[nIndex].y = dMoveY;
#endif
						pdOffset[nIndex] = visionResult;
						pSuccess[nIndex] = true;
					}
					else
					{
#ifdef __TEST__
						return TRUE;
#else
						m_nErrID = STDGNALM711; // hole �� �߰ߵǾ��ٴ� �޽��� 2011.9.28
						return FALSE;
#endif
					}
				}
				else
				{
					if(bSave)
					{
						m_nErrID = STDGNALM711;
						return FALSE;
					}
				}
			}

			if(em2nd == emSlave)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] == 0) // high vision
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
					else
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
				}

				if(bUseLowCam)
					nCam = 3;
				else
					nCam = 2;

				for(nKK=0; nKK< nRepeatTime; nKK++)
				{
					nIndexNo = 6;
					if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
						nIndexNo = 4;

					bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);

					if(bRet)
						break;
				}
			
				if (bRet) 
				{
					if(bSave)
					{
						if(nCountY%2)
							nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
						else
							nIndex = GetPointIndex(nCountX, nCountY, nDivision);

						dPanelOffsetX = dMoveX - dPosX;
						dPanelOffsetY = dMoveY - dPosY;
						pdPos2[nIndex].x = dMoveX;
						pdPos2[nIndex].y = dMoveY;
						pdOffset2[nIndex].x = visionResult.x + dPanelOffsetX;
						pdOffset2[nIndex].y = visionResult.y + dPanelOffsetY;
						pSuccess2[nIndex] = true;

						strGetVal.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), pdOffset2[nIndex].x, 
											pdOffset2[nIndex].y,
											m_dFoundSize);

						m_stcVisionResult.SetWindowText( strGetVal );

					}
					else
					{
#ifdef __TEST__
						return TRUE;
#else
						m_nErrID = STDGNALM711;
						return FALSE;
#endif
					}
				}
				else
				{
					if(bSave)
					{
						m_nErrID = STDGNALM711;
						return FALSE;
					}
				}

			}
		}
	}
	Sleep(100);

	return TRUE;
}

int CDlgIdleMode::GetPointIndex(int nCountX, int nCountY, int nDivision)
{
	if ((nCountX % 2) == 1)
		return (nCountX ) * nDivision + nCountY;
	else
		return nCountX * nDivision + nCountY;
}

LRESULT CDlgIdleMode::GetVisionResult(WPARAM wParam, LPARAM lParam)
{
	m_dFoundSize = 0;
	HVision* pVision = gDeviceFactory.GetVision();
	
	int nResult = pVision->GetRealPos(&visionResult, wParam, lParam, FALSE, myResultChar, (BOOL)m_dFoundSize);
	
	if(nResult == 1)
		return TRUE;
	else
		return FALSE;
}


BOOL CDlgIdleMode::DoFireCalibrationHole(int nSelHead, BOOL bUseLowCam)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	// Master ���
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		double dLaserOffsetX = 0, dLaserOffsetY = 0;
		gDeviceFactory.GetEocard()->GetLaserOffset(gProcessINI.m_sProcessScannerCal.dScanXTemp, 
																						gProcessINI.m_sProcessScannerCal.dScanYTemp, 
																						dLaserOffsetX, dLaserOffsetY, FIRST_PANEL_OFFSET);

		if(!pMotor->MoveXY(gProcessINI.m_sProcessScannerCal.dScanXTemp + dLaserOffsetX, gProcessINI.m_sProcessScannerCal.dScanYTemp + dLaserOffsetY, TRUE, SHOT_MOVE))
		{
			m_nErrID = STDGNALM438;
			return FALSE;
		}		

		if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
#ifdef __OSAN_LG__
		if(TRUE) // ���꿡�� DryRun���� Prework�� ���� - prewor data �ɼ����� �ȵȴ� �� 
#else
		if(!gProcessINI.m_sProcessSystem.bDryRun)
#endif
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
			{
				m_nErrID = STDGNALM417;
				return FALSE;
			}
		}

		::Sleep(CALIBRATION_SLEEP);

		if(!CheckStatus()) // StopȮ��
			return FALSE;

		if (!FireCalibrationHole(TRUE, TRUE))
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
			{
				m_nErrID = STDGNALM417;
				return FALSE;
			}
			return FALSE;
		}

	

		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			m_nErrID = STDGNALM417;
			return FALSE;
		}
	}

	// Slave ���
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		double dFirePosOffsetX, dFirePosOffsetY;
		// ī�޶� ���� ��ġ ���߱�
		if(gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else
		{	
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}

		double dLaserOffsetX = 0, dLaserOffsetY = 0;
		gDeviceFactory.GetEocard()->GetLaserOffset(gProcessINI.m_sProcessScannerCal.dScanXTemp - dFirePosOffsetX, 
																						gProcessINI.m_sProcessScannerCal.dScanYTemp - dFirePosOffsetY, 
																						dLaserOffsetX, dLaserOffsetY, SECOND_PANEL_OFFSET);

		if(!pMotor->MoveXY(gProcessINI.m_sProcessScannerCal.dScanXTemp - dFirePosOffsetX + dLaserOffsetX, 
											gProcessINI.m_sProcessScannerCal.dScanYTemp - dFirePosOffsetY + dLaserOffsetY, FALSE, SHOT_MOVE))
		{
			m_nErrID = STDGNALM438;
			return FALSE;
		}

		if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
#ifndef __OSAN_LG__
		if(!gProcessINI.m_sProcessSystem.bDryRun)
#else
		if(TRUE) // ���꿡�� DryRun���� Prework�� ���� - prewor data �ɼ����� �ȵȴ� �� 
#endif
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
			{
				m_nErrID = STDGNALM417;
				return FALSE;
			}
		}

		::Sleep(CALIBRATION_SLEEP);

		if(!CheckStatus()) // StopȮ��
			return FALSE;

		if (!FireCalibrationHole(TRUE, FALSE))
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
			{
				m_nErrID = STDGNALM417;
				return FALSE;
			}

			return FALSE;
		}
		
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			m_nErrID = STDGNALM417;
			return FALSE;
		}
	}

	return TRUE;
}


BOOL CDlgIdleMode::FireCalibrationHole(bool bFire, bool b1stPanel)
{
	CString strErrorPlus;
	strErrorPlus = _T("");

	if(!CheckStatus()) // StopȮ��
		return FALSE;

	if(!ChangeBeamPath(DO_SCANNER))
	{
		m_nErrID = STDGNALM600;
		return FALSE;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	CCalibrationPath* pMasterPath = GetMasterPath();
	CCalibrationPath* pSlavePath = GetSlavePath();

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = 9;

	int nMaxIndex = nDivision * nDivision;
	unsigned short usLaserPosMX = 32767, usLaserPosMY = 32767, usLaserPosSX = 32767, usLaserPosSY = 32767;

	pMasterPath->SetCalibrationGridSize(nDivision);
	pSlavePath->SetCalibrationGridSize(nDivision);

	pMasterPath->SetCalibrationGridIndex(usLaserPosMX, usLaserPosMY);
	pSlavePath->SetCalibrationGridIndex(usLaserPosSX, usLaserPosSY);

	pMasterPath->GetFirstLSB(usLaserPosMX, usLaserPosMY);
	pSlavePath->GetFirstLSB(usLaserPosSX, usLaserPosSY);
	

	unsigned short usMasterDumpPosX, usMasterDumpPosY, usSlaveDumpPosX, usSlaveDumpPosY;
	int nXYORDER;

	int nUseTool = gProcessINI.m_sProcessPowerMeasure.nUseTool;
	BOOL bFind = FALSE, bResult;

	pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);
	pEoCard->GetDumperPosition(usMasterDumpPosX, usMasterDumpPosY, usSlaveDumpPosX, usSlaveDumpPosY);
	pEoCard->ShotDataReset();

	if(!CheckStatus()) // StopȮ��
		return FALSE;

	for (int nIndex = 0; nIndex < nMaxIndex; nIndex++)
	{
		nXYORDER = gProcessINI.m_sProcessCal.nXYOrder;
		
		pMasterPath->GetNextLSBXYORDER(usLaserPosMX, usLaserPosMY, nDivision, nIndex, nXYORDER);
		pSlavePath->GetNextLSBXYORDER(usLaserPosSX, usLaserPosSY, nDivision, nIndex, nXYORDER);
		
		if(b1stPanel)
		{
			pEoCard->DownloadShotData2(
				usLaserPosMX,
				usLaserPosMY,
				usSlaveDumpPosX,
				usSlaveDumpPosY,
				TRUE,
				FALSE,
				SCANNER_CAL_TOOL
				);
		}
		else
		{
			pEoCard->DownloadShotData2(
				usMasterDumpPosX,
				usMasterDumpPosY,
				usLaserPosSX,
				usLaserPosSY,
				FALSE,
				TRUE,
				SCANNER_CAL_TOOL
				);
		}
	}

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			m_nErrID = STDGNALM445;
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}
	}

	if(!pEoCard->FieldPreStart())
	{
		if(gSystemINI.m_sSystemDevice.nEStop == 1)
			pEoCard->EStop();

		m_nErrID = STDGNALM445;
		return FALSE;
	}

	gDeviceFactory.GetMotor()->GetTCTemperature(m_d1stTemper, m_d2ndTemper);
	gDeviceFactory.GetMotor()->GetSBTemperature(m_d1stSBTemper, m_d2ndSBTemper);

	if(!pEoCard->FieldStart(FALSE))
	{
		if(gSystemINI.m_sSystemDevice.nEStop == 1)
			pEoCard->EStop();

		m_nErrID = STDGNALM445;
		return FALSE;
	}


	::Sleep(100);

	bResult = TRUE;
	do
	{
		::Sleep(1);
		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType =  gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			
			strErrorPlus = _T("Scanner Cable Error.");
			::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
			return FALSE;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			
			strErrorPlus = strErrorMsg;
			::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
			return FALSE;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			
			strErrorPlus = strErrorMsg;
			::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM1017, reinterpret_cast<LPARAM>(&strErrorPlus));
			return FALSE;
		}
		if(bTimeOutType)
		{
			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();

			strErrorPlus = strErrorMsg;
			::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, STDGNALM566, reinterpret_cast<LPARAM>(&strErrorPlus));
		
			return FALSE;
		}
		bResult = pEoCard->IsDSPBusy();
	}while(bResult);


	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			m_nErrID = STDGNALM445;
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}
	}
#ifndef __TEST__
	if( (pEoCard->ReadHoleCount() != nMaxIndex))
	{
		m_nErrID = STDGNALM603;
		return FALSE;
	}
#endif
	return TRUE;
}

void CDlgIdleMode::SaveSCalResult()
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strPathName += _T("SCalLog");
	CTime curDate = CTime::GetCurrentTime();

	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;

	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;

	int nSelHead = gDProject.m_nSeparation;
	int nDivision = 9;

	CString strBuf;
	CString strCam, strPanel, strOP;
	if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nBeamPath] % 2 == 0)
		strCam.Format(_T("High"));
	else
		strCam.Format(_T("Low"));
	strOP.Format(_T("Idle"));

	TRY
	{
		file.SeekToEnd();

		if(nSelHead == USE_DUAL)
		{
			strPanel.Format(_T("Dual-1st"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000, 
				m_nBeamPath, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());

			strPanel.Format(_T("Dual-2nd"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
				m_nBeamPath, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
		else if(nSelHead == SEL_HEAD_MASTER)
		{
			strPanel.Format(_T("1st"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX* 1000, m_dMaxOffsetMasterY* 1000, m_dMaxOffsetMasterR*1000,
				m_nBeamPath, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
		else if(nSelHead == SEL_HEAD_SLAVE)
		{
			strPanel.Format(_T("2nd"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX* 1000, m_dMaxOffsetSlaveY* 1000, m_dMaxOffsetSlaveR*1000,
				m_nBeamPath, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
		file.Close();

}

void CDlgIdleMode::SaveScalTime(BOOL b1st, BOOL bOnlyTime)
{
	int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
	TCHAR cASC[256] ={0,};

	_stprintf_s(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);

	time_t timeNow;
	time(&timeNow);

	CString strFile, strLog;
	strFile.Format(_T("PreWork"));

	for(int i =0; i<= nCount; i++)  
	{
		if(strcmp(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) == 0)
		{
			if(bOnlyTime)
			{
				if(b1st)
				{		gTempINI.m_sTempTime.nAutoScalEndTime[i][0] = (int)timeNow;
						strLog.Format(_T("Idle ScannerSaveTime 1st [%d] = %d"), i, timeNow);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
				else
				{
						gTempINI.m_sTempTime.nAutoScalEndTime[i][1] = (int)timeNow;
						strLog.Format(_T("Idle ScannerSaveTime 2nd [%d] = %d"), i, timeNow);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
				if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
				{
					m_nErrID = STDGNALM119;
					return;
				}
			}
			else
			{
				if(b1st)
				{
					if((m_d1stTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d1stTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit &&
						m_d1stSBTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d1stSBTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
						!gProcessINI.m_sProcessOption.bTemperCompensationMode)
					{
				
						gTempINI.m_sTempTime.dAutoScalTemperature[i][0] = m_d1stTemper;
						gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0] = gDeviceFactory.Get1stTemperCompen()->GetAutoRunLastTemperature();;
						if(gTempINI.m_sTempTime.dAutoScalTemperature[i][0] > gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0])
							gTempINI.m_sTempTime.dAutoScalTemperature[i][0] = gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0];
						strLog.Format(_T("Idle ScannerSave Temperature 1st [%d] = %.3f, %.3f"), i, m_d1stTemper, m_d1stSBTemper);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}
				}
				else
				{
					if((m_d2ndTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d2ndTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit &&
						m_d2ndSBTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d2ndSBTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
						!gProcessINI.m_sProcessOption.bTemperCompensationMode)
					{
					
						gTempINI.m_sTempTime.dAutoScalTemperature[i][1] = m_d2ndTemper;
						gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1] = gDeviceFactory.Get2ndTemperCompen()->GetAutoRunLastTemperature();;
						if(gTempINI.m_sTempTime.dAutoScalTemperature[i][1] > gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1])
							gTempINI.m_sTempTime.dAutoScalTemperature[i][1] = gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1];
						strLog.Format(_T("Idle ScannerSave Temperature 2nd [%d] = %.3f, %.3f"), i, m_d2ndTemper, m_d2ndSBTemper);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}
				}
			}
		}
	}
}

BOOL CDlgIdleMode::DoFindCurrentShot(BOOL bUseLowCam)
{

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = 9;
	double dStartZ1, dStartZ2;

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
	{
		m_nErrID = STDGNALM417;
		return FALSE;
	}

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	if(bUseLowCam)
	{
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{	
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}

	if (!pMotor->MoveZ(dStartZ1, dStartZ2))
	{
		m_nErrID = STDGNALM438; 
		return FALSE;
	}

	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString szPath;
	CTime ct= CTime::GetCurrentTime();

	szPath.Format(_T("%sCalOffset_%02d%02d_%02d%02d.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir(), ct.GetMonth(),ct.GetDay(), ct.GetHour(), ct.GetMinute());
	CFile file;

	if (FALSE == file.Open(szPath, CFile::modeCreate|CFile::modeWrite))
	{
		return FALSE;
	}

	TCHAR szCode[128];
	DPOINT *pdPos = NULL, *pdOffset = NULL;
	bool* pSuccess = NULL;
	DPOINT *pdPos2 = NULL, *pdOffset2 = NULL;
	bool* pSuccess2 = NULL;
	TRY
	{
		pdPos = new DPOINT[nDivision * nDivision];
		pdOffset = new DPOINT[nDivision * nDivision];
		pSuccess = new bool[nDivision * nDivision];

		pdPos2 = new DPOINT[nDivision * nDivision];
		pdOffset2 = new DPOINT[nDivision * nDivision];
		pSuccess2 = new bool[nDivision * nDivision];
	}
	CATCH (CMemoryException, e)
	{
		if (pdPos != NULL)
			delete [] pdPos;
		if (pdOffset != NULL)
			delete [] pdOffset;
		if (pSuccess != NULL)
			delete [] pSuccess;

		if (pdPos2 != NULL)
			delete [] pdPos2;
		if (pdOffset2 != NULL)
			delete [] pdOffset2;
		if (pSuccess2 != NULL)
			delete [] pSuccess2;

		e->ReportError();
		e->Delete();

		file.Close();
		return 0;
	}
	END_CATCH

		emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(nSelHead != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (nSelHead != SEL_HEAD_MASTER)
		n2ndUse = emSlave;

	for (int i = 0; i < nDivision * nDivision; i++)
	{
		pSuccess[i] = true;
		pdPos[i].x = pdPos[i].y = 0.0;
		pdOffset[i].x = pdOffset[i].y = 0.0;

		pSuccess2[i] = true;
		pdPos2[i].x = pdPos2[i].y = 0.0;
		pdOffset2[i].x = pdOffset2[i].y = 0.0;
	}

	BOOL bPostFound = TRUE;
	if(bFindFast)
	{
		bPostFound = FindCurrentShot(dStartZ1, dStartZ2, n1stUse, n2ndUse, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
	}
	else
	{
		if(n1stUse == emMaster)
			bPostFound = FindCurrentShot(dStartZ1, dStartZ2, n1stUse, pdPos, pdOffset, pSuccess);
		if(bPostFound && n2ndUse == emSlave)
			bPostFound = FindCurrentShot(dStartZ1, dStartZ2, n2ndUse, pdPos2, pdOffset2, pSuccess2);
	}
	if (!bPostFound)
	{
		file.Close();
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;

		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;

		return 0;
	}
	double dDist;
	// Master ����
	TRY
	{
		m_dMaxOffsetMasterX = 0;
		m_dMaxOffsetMasterY = 0;
		m_dMaxOffsetMasterR = 0;

		for (int i = 0; i < nDivision * nDivision; i++)
		{
			m_calAGCMaster.AddOffsetInfo(pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
			if (pSuccess[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}

			dDist = sqrt(pdOffset[i].x * pdOffset[i].x + pdOffset[i].y * pdOffset[i].y);
			if(dDist > m_dMaxOffsetMasterR)
				m_dMaxOffsetMasterR = dDist;

			file.Write(szCode, strlen(szCode));
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();

		file.Close();
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		return 0;
	}
	END_CATCH
		// Master ��
		TRY
	{
		m_dMaxOffsetSlaveX = 0;
		m_dMaxOffsetSlaveY = 0;
		m_dMaxOffsetSlaveR = 0;
		for (int i = 0; i < nDivision * nDivision; i++)
		{
			m_calAGCSlave.AddOffsetInfo(pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
			if (pSuccess[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);				
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);
			}

			dDist = sqrt(pdOffset2[i].x * pdOffset2[i].x + pdOffset2[i].y * pdOffset2[i].y);
			if(dDist > m_dMaxOffsetMasterR)
				m_dMaxOffsetSlaveR = dDist;

			file.Write(szCode, strlen(szCode));
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();

		file.Close();
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		return 0;
	}
	END_CATCH
		////////////////////////////////////////////////////


	CString strEvent, strInfo;
	if(nSelHead == SEL_HEAD_BOTH)
	{					
		strEvent = _T("Idle SCal Result");
		strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um ) | 2nd Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um)"),
			m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000, m_dMaxOffsetMasterR*1000, 
			m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000, m_dMaxOffsetSlaveR*1000);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	}
	else if(nSelHead == SEL_HEAD_MASTER)
	{
		strEvent = _T("Idle SCal Result");
		strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um )"),
			m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000, m_dMaxOffsetMasterR*1000);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	}
	else if(nSelHead == SEL_HEAD_SLAVE)
	{
		strEvent = _T("Idle SCal Result");
		strInfo.Format(_T("2nd Panel Head Max. ( X = %.3f um, Y = %.3f um, R = %.3f um  )"),
			m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000, m_dMaxOffsetSlaveR*1000);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	}

	delete [] pdPos;
	delete [] pdOffset;
	delete [] pSuccess;
	delete [] pdPos2;
	delete [] pdOffset2;
	delete [] pSuccess2;
	return TRUE;
}
BOOL CDlgIdleMode::FindCurrentShot(double dZ1, double dZ2, emHEAD emHead, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	return FindShot(dZ1, dZ2, emHead, true, pdPos, pdOffset, pSuccess);
}

BOOL CDlgIdleMode::FindCurrentShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	return FindShot(dZ1, dZ2, em1st, em2nd, true, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
}


BOOL CDlgIdleMode::DestroyWindow()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	return CDialog::DestroyWindow();
}


void CDlgIdleMode::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);

	if(bShow)
	{
		OnMoveVisionView();
		m_nBeamPathBackup = gProcessINI.m_sProcessCal.nIdleBeamPath;

		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
			m_nBeamPath = GetFirstBeamPath();
		else
			m_nBeamPath = gProcessINI.m_sProcessCal.nIdleBeamPath;

		gProcessINI.m_sProcessCal.nIdleBeamPath = m_nBeamPathBackup;
		if(m_nBeamPath == -1)
			return;

		InsertInfo(DO_NOTING);
	}
	else
	{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_HIDE );
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_HIDE );
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_HIDE );
	}
	
}

INT_PTR CDlgIdleMode::DoModal()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	return CDialog::DoModal();
}

void CDlgIdleMode::InsertInfo(int nType)
{
	int nIndex;
	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_nBeamPath];

	CString strBeamPath, strFreq, strDuty,strASC, strMin, strMax;
	strBeamPath.Format(_T("%d"), m_nBeamPath);
	strFreq.Format(_T("%d"), gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath]);
	strDuty.Format(_T("%.1f"), gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex]);
	strASC.Format(_T("%s"), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);
	strMin.Format(_T("%.1f"), gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0]);
	strMax.Format(_T("%.1f"), gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);


	

	if(nType == DO_POWER)
	{
		nIndex = m_listPowerTool.GetItemCount();
		m_listPowerTool.InsertItem(nIndex, _T(""));
		m_listPowerTool.SetItemText(nIndex, 0, strBeamPath);
		m_listPowerTool.SetItemText(nIndex, 1, strFreq);
		m_listPowerTool.SetItemText(nIndex, 2, strDuty);
		m_listPowerTool.SetItemText(nIndex, 3, strMin);
		m_listPowerTool.SetItemText(nIndex, 4, strMax);

	}
	else if(nType == DO_SCANNER)
	{
		nIndex = m_listScannerResult.GetItemCount();
		m_listScannerResult.InsertItem(nIndex, _T(""));
		m_listScannerResult.SetItemText(nIndex, 0, strBeamPath);
	}
	else //DO_NOTING
	{
		nIndex = m_listScannerTool.GetItemCount() ;
		m_listScannerTool.DeleteAllItems();
		m_listScannerTool.InsertItem(nIndex, _T(""));
		m_listScannerTool.SetItemText(nIndex, 0, strBeamPath);
		m_listScannerTool.SetItemText(nIndex, 1, strFreq);
		m_listScannerTool.SetItemText(nIndex, 2, strDuty);
		m_listScannerTool.SetItemText(nIndex, 3, strASC);

		CString str;
		double dNowTime;

		time_t timeNow;
		time(&timeNow);

		time_t timeEnd;

		timeEnd = gTempINI.m_sTempTime.nAutoScalEndTime[m_nBeamPath][0];
		dNowTime = difftime(timeNow, timeEnd); //sec

		dNowTime = dNowTime / 60 / 60 ; // hour  
		str.Format(_T("%.1f"), dNowTime);
		GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetWindowText(str);

		timeEnd = gTempINI.m_sTempTime.nAutoPowerEndTime[m_nBeamPath][0];
		dNowTime = difftime(timeNow, timeEnd); //sec

		dNowTime = dNowTime / 60 / 60 ; // hour  
		str.Format(_T("%.1f"), dNowTime);
		GetDlgItem(IDC_STATIC_AFTER_TIME_VAL2)->SetWindowText(str);

	}


}

void CDlgIdleMode::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);
	if(m_bCtrlInit)
		OnMoveVisionView();
}
void CDlgIdleMode::InsertPowerResult(double dResult,int nIndex, BOOL b1st, BOOL bAvg)
{
	int nCount = m_lboxResult.GetCount();

	CString str, strTemp;

	if(m_bOldPanel != b1st)
	{
		m_lboxResult.ResetContent();
		m_nMeasureCount = 0;
		m_bOldPanel = b1st;
	}
	if(!bAvg)
	{
		if(b1st)
			strTemp.Format(_T("1st #%d : %.1f "), m_nMeasureCount+1, dResult);
		else
			strTemp.Format(_T("2nd #%d : %.1f "), m_nMeasureCount+1, dResult);
	}
	else
	{
		if(b1st)
			strTemp.Format(_T("## Avg 1st : %.1f "),  dResult);
		else
			strTemp.Format(_T("## Avg 2nd : %.1f "),  dResult);

		InsertPowerResult2(b1st, dResult);
	}

	m_lboxResult.SetCurSel(nCount);
	m_lboxResult.AddString((LPCTSTR)strTemp);

	m_nMeasureCount++;
}
void CDlgIdleMode::InsertPowerResult2(BOOL b1st, double dVal)
{
	int nCount = m_listPowerTool.GetItemCount();

	CString strVal;
	strVal.Format(_T("%.1f"), dVal);

	if(b1st)
	{
		m_listPowerTool.SetItemText(nCount -1 , 5, strVal);
	}
	else
	{
		m_listPowerTool.SetItemText(nCount -1 , 6, strVal);
	}
	
}

void CDlgIdleMode::InsertSCalResult( double dMaxX, double dMaxY ,double dMaxX2, double dMaxY2)
{
	int nCount = m_listScannerResult.GetItemCount();
	
	CString strValX, strValY, strValX2, strValY2;
	strValX.Format(_T("%.1f"), dMaxX*1000);
	strValY.Format(_T("%.1f"), dMaxY*1000);
	strValX2.Format(_T("%.1f"), dMaxX2*1000);
	strValY2.Format(_T("%.1f"), dMaxY2*1000);
	
	m_listScannerResult.SetItemText(nCount -1 , 1, strValX);
	m_listScannerResult.SetItemText(nCount -1 , 2, strValY);
	m_listScannerResult.SetItemText(nCount- 1, 3, strValX2);
	m_listScannerResult.SetItemText(nCount -1, 4, strValY2); 
	
}

BOOL CDlgIdleMode::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format(_T("USER_CLICK(Idle view) : %s"), strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
void CDlgIdleMode::StartMeasurement(int nPos)
{
	m_progMeasure.SetRange32(0, nPos);
}

void CDlgIdleMode::UpdateMeasurement(int nPos)
{
	m_progMeasure.SetPos(nPos);

	int nStep = nPos % 18;
	if(nStep < 3)
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring"));
	else if(nStep >= 3 && nStep < 6)
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring."));
	else if(nStep >= 6 && nStep < 9)
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring.."));
	else if(nStep >= 9 && nStep < 12)
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring..."));
	else if(nStep >= 12 && nStep < 15)
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring...."));
	else
		GetDlgItem(IDC_PROGRESS_MEASURE)->SetWindowText(_T("Power Measuring....."));
}
BOOL CDlgIdleMode::CheckStatus()
{
	if(m_bStop)
		return FALSE;

	if(gDeviceFactory.GetMotor()->IsMainDoorStop())
	{
		if(gSystemINI.m_sSystemDevice.nEStop == 1)
		{
			gDeviceFactory.GetEocard()->EStop();
			gDeviceFactory.GetMotor()->MotorShutterAll(FALSE, FALSE);
		}
		return FALSE;
	}
	return TRUE;
}
LRESULT CDlgIdleMode::SetVisionLamp(WPARAM wParam, LPARAM lParam)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return TRUE ;
	HVision* pVision = gDeviceFactory.GetVision();
	int nCam = (int)wParam;
	VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);

	pVision->OnLightAll(nCam, pVisInfo->nCoaxial[nCam], pVisInfo->nRing[nCam], pVisInfo->nIR[nCam]);
	return TRUE;
}

BOOL CDlgIdleMode::DoApplySCalResult()
{
#ifdef __TEST__
	return TRUE;
#endif
	::Sleep(100);
	CDlgCalResult DlgCalResult;
	CString strMaster, strSlave;
	
	DlgCalResult.SetToolIndex(m_nBeamPath);
	DlgCalResult.SetTablePos(gProcessINI.m_sProcessScannerCal.dScanXTemp, gProcessINI.m_sProcessScannerCal.dScanYTemp);

	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);

	gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(strMaster);
	gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(strSlave);

	int nResultASC;
	nResultASC = m_calAGCMaster.CreateAGCFile();
	if(0 != nResultASC)
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_CREATE);
		strMsg.Format(strString, strMaster, _T("ASC Calibration"));
//		ErrMessage(strMsg);
		 
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
	nResultASC = m_calAGCSlave.CreateAGCFile();
	if(0 != nResultASC)
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_CREATE);
		strMsg.Format(strString, strSlave, _T("ASC Calibration"));
//		ErrMessage(strMsg);
		
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
	
	CString strString, strMsg;
	strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
	strMsg.Format(strString, _T("ASC"));

	if(!gDeviceFactory.GetEocard()->LoadCalibrationFile((LPSTR)(LPCTSTR)strMaster, (LPSTR)(LPCTSTR)strSlave))
	{
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
	return 1L;
}

void CDlgIdleMode::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == m_nTimer)
	{
		long lErrorIo1New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_IO);
		BOOL bAlarm = lErrorIo1New & 0x10000;
		if(bAlarm) // Main Door InOut Sensor Alarm
		{
			CString strLog, strPLCAlarmLogFile;
			strPLCAlarmLogFile.Format(_T("PlcAlarm"));
			strLog.Format(_T("[MB5412] Main Door InOut Sensor Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(m_bIdleRun)
			{
				gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
				gDeviceFactory.GetMotor()->MotorShutterAll(FALSE, FALSE);
				IdleEndProcess();
				gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
				ErrMsgDlg(STDGNALM1035);
			}
		}
	}
	CDialog::OnTimer(nIDEvent);
}
BOOL CDlgIdleMode::HeatingScannerBlockUsingIdleInfo()
{
	if(!gSystemINI.m_sHardWare.bCheckMCMode) // mc mode������ ����
		return TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bDoAutoPower || m_bDoAutoSCal)
		return TRUE;

	double dX, dY;
	dX = rand()%(int)gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus;
	dY = rand()%(int)gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus;
	BOOL bMinusX = FALSE, bMinusY = FALSE;

	double dC1, dC2, dA1, dA2, dM1, dM2, dM3, dZ1, dZ2; 
	CString strVal;
	BOOL bTophat, bLaserPath;
	dZ1 = gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ1;
	dZ2 = gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ2;

	bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nBeamPath];
	bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[m_nBeamPath];

	dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[m_nBeamPath];
	dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[m_nBeamPath];
	dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[m_nBeamPath];
	dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[m_nBeamPath];
		
	dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_nBeamPath];
	dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_nBeamPath];
	dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_nBeamPath];

	
	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMsgDlg(STDGNALM568);
		return FALSE;
	}

	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMsgDlg(STDGNALM974);
		return FALSE;
	}


#ifndef __SERVO_MOTOR__
	if(!pMotor->MoveXYZMC2A(gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX, gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY, dZ1, dZ2, dM1, dM2, dC1, dC2, dA1, dA2, TRUE, SHOT_MOVE, FALSE, bTophat))
#else 
	if(!pMotor->MotorMoveXYZMCA3(gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX, gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY, dZ1, dZ2, dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, SHOT_MOVE, FALSE, bTophat))
#endif
	{
		ErrMsgDlg(STDGNALM438);
		return FALSE;
	}

	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
	subTool.nJumpDelay = gSystemINI.m_sSystemDevice.nJumpDelayShot;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1000;
	// Drill
	subTool.nShotMode = 1; // cycle mode
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 1;
	subTool.nMask = gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo;
	subTool.bUseTophat = bTophat;

	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < subTool.nTotalShot; i++)
	{
		subTool.dShotDuty[i] =gProcessINI.m_sProcessOption.nTemperStartDuty;
		subTool.dShotAOMDelay[i] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath];
		subTool.dShotAOMDuty[i] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath];

		subTool.dShotDutyOffsetM[i] = 0;
		subTool.dShotDutyOffsetS[i] = 0;
		subTool.dShotVolOffsetM[i] = 0;
		subTool.dShotVolOffsetS[i] = 0;

		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		{
			subTool.dShotMaxFreq[i] = subTool.dShotMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;		// shot�� �ּ� �ֱ�.	// 2011-09-28
		}
		else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		{
			subTool.dShotMaxFreq[i] = subTool.dShotMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
		}

		strcpy_s(subTool.cAOMFilePath[i], strAOMFile);
	}
	subTool.bUseAperture = FALSE;
	subTool.nApertureBurst = 1;
	subTool.dZOffset = 0;
	subTool.nFPS = 0;
	// Memo
	subTool.cToolMemo[0] = NULL;

	BOOL bIsDspBusy = TRUE;
	double dFireTime;
	CCorrectTime ctFireTime; //1�� ������ �˶�
	ctFireTime.StartTime();
	while(bIsDspBusy)
	{
		dFireTime = ctFireTime.PresentTime();
		if(dFireTime >= 60)
		{
			gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM566);
			return FALSE;
		}
		bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
	}

	// subTool download
	if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool))
	{
		ErrMsgDlg(STDGNALM445);
		return FALSE;
	}
	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(subTool.nJumpDelay))
	{
		ErrMsgDlg(STDGNALM445);
		return FALSE;
	}
	// Laser Current Set - no use

#ifndef __SERVO_MOTOR__
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2))
#else 
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3 + IND_A1)) //110219 ejpark c2�߰� 
#endif
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
		return FALSE;
	}

	BOOL b1st = FALSE, b2nd = FALSE;
	if(gDProject.m_nSeparation != USE_2ND)
		b1st = TRUE;
	if(gDProject.m_nSeparation != USE_1ST)
		b2nd = TRUE;


	double dTableMinX, dTableMinY, dTableMaxX, dTableMaxY;
	dTableMinX = 200;
	dTableMaxX = 500;
	dTableMinY = 400;
	dTableMaxY = 800;
	//////
	while(TRUE)
	{
		if(m_bDoAutoPower || m_bDoAutoSCal || m_bStop)
			return TRUE;

		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(b1st, b2nd, FALSE))
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
			ErrMsgDlg(STDGNALM417); // shutter sensor error
			return FALSE;
		}

		if(!gDeviceFactory.GetEocard()->ShotDataReset())
		{
			ErrMsgDlg(STDGNALM445);
			return FALSE;
		}

		int nPosX, nPosY;
		int nCount = 0;
		while(nCount <= 6000)
		{
			nPosX = rand()%65535;
			nPosY = rand()%65535;

			if(!gDeviceFactory.GetEocard()->DownloadShotData2(nPosX, nPosY, nPosX, nPosY, TRUE, TRUE, 1))
			{
				gDeviceFactory.GetEocard()->ShotDataReset();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
				ErrMsgDlg(STDGNALM445);
				return FALSE;
			}
			TRACE(_T("%d\t%d\n"), nPosX, nPosY);
			nCount ++;
		}	

		CCorrectTime	m_HeatingTime;
		m_HeatingTime.StartTime();
		BOOL bTemperReady = FALSE;

		if(!gDeviceFactory.GetEocard()->FieldPreStart(0))
		{
			ErrMsgDlg(STDGNALM445); 
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
			return FALSE;
		}
		if(!gDeviceFactory.GetEocard()->FieldStart(FALSE))
		{
			ErrMsgDlg(STDGNALM445); 
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
			return FALSE;
		}
		::Sleep(10);

		BOOL bResult = TRUE;
		while(bResult)
		{
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
				ErrMsgDlg(STDGNALM1017);
				return FALSE;
			}
			else if(bScannerMotorFault)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				ErrMsgDlg(STDGNALM1017);
				return FALSE;
			}
			else if(bScannerDrillTimeOut)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
				ErrMsgDlg(STDGNALM1017);
				return FALSE;
			}
			if(!CheckStatus())
			{
				gDeviceFactory.GetEocard()->EStop();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
				::Sleep(200);
				return FALSE;
			}
			bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
			::Sleep(100);
		}
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			ErrMsgDlg(STDGNALM417); // shutter sensor error
			return FALSE;
		}
		
		if(m_bDoAutoPower || m_bDoAutoSCal || m_bStop)
			return TRUE;

		if(dX + gSystemINI.m_sSystemDevice.dFieldSize.x > dTableMaxX)
		{
			dY -= gSystemINI.m_sSystemDevice.dFieldSize.y;
			bMinusX = TRUE;
		}
		if(dX - gSystemINI.m_sSystemDevice.dFieldSize.x < dTableMinX)
		{
			dY -= gSystemINI.m_sSystemDevice.dFieldSize.y;
			bMinusX = FALSE;
		}

		if(bMinusX)
			dX -= gSystemINI.m_sSystemDevice.dFieldSize.x;
		else
			dX += gSystemINI.m_sSystemDevice.dFieldSize.x;

		if(dY+ gSystemINI.m_sSystemDevice.dFieldSize.y > dTableMaxY)
			bMinusY = TRUE;
		if(dY - gSystemINI.m_sSystemDevice.dFieldSize.y < dTableMinY)
			bMinusY = FALSE;

//		if(bMinusY)
//			dY -= gSystemINI.m_sSystemDevice.dFieldSize.y;
//		else
//			dY += gSystemINI.m_sSystemDevice.dFieldSize.y;

		if(dY < dTableMinY)
			dY = dTableMaxY;
		if(dY > dTableMaxY)
			dY = dTableMaxY;

		if(dX < dTableMinX)
			dX = dTableMinX;
		if(dX > dTableMaxX)
			dX = dTableMaxX;

		if(!pMotor->MotorMoveXY(dX, dY, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			return FALSE;
		}
		Sleep(100);
		if(!pMotor->InPositionIO(IND_X + IND_Y))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis, TRUE);
			return FALSE;
		}
	}
	return TRUE;
}