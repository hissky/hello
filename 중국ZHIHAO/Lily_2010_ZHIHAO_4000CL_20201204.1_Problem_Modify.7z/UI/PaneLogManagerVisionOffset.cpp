// CPaneLogManagerVisionOffset.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerVisionOffset.h"
#include <cfloat>
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\Model\DProject.h"
#include "..\model\dbeampathini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
const double		NONE_DATA	= DBL_MAX;
/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerJobTime
IMPLEMENT_DYNCREATE(CPaneLogManagerVisionOffset, CFormView)

CPaneLogManagerVisionOffset::CPaneLogManagerVisionOffset()
	: CFormView(CPaneLogManagerVisionOffset::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerVisionOffset)
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();

	m_nTimerID = 0;
	m_bShow = FALSE;
	m_bOnTimer = FALSE;
	m_nSelectHead = -1;
	m_strFilePath = "";
	m_bShow			= FALSE;
	m_nBeamPath = gBeamPathINI.m_sBeampath.nLastIndex + 1;
	m_nPanel = 0;

	m_logFont.lfHeight = 140;
	m_logFont.lfWidth = 0;
	m_logFont.lfEscapement = 0;
	m_logFont.lfOrientation = 0;
	m_logFont.lfWeight = FW_NORMAL;
	m_logFont.lfItalic = FALSE;
	m_logFont.lfStrikeOut = FALSE;
	m_logFont.lfUnderline = FALSE;
	m_logFont.lfCharSet = DEFAULT_CHARSET;
	m_logFont.lfOutPrecision = OUT_CHARACTER_PRECIS;
	m_logFont.lfClipPrecision = OUT_CHARACTER_PRECIS;
	m_logFont.lfQuality = DEFAULT_QUALITY;
	m_logFont.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
	lstrcpy(m_logFont.lfFaceName, DEF_FONT_FACE_NAME);

	//}}AFX_DATA_INIT
	
	memset(&m_lpszColumnHead2, 0, sizeof(m_lpszColumnHead2));

}

CPaneLogManagerVisionOffset::~CPaneLogManagerVisionOffset()
{
}

void CPaneLogManagerVisionOffset::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerVisionOffset)
	DDX_Control(pDX, IDC_LIST_FIDUCIAL_SCALE, m_listFiducialScale);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_Control(pDX, IDC_BUTTON_FIDSAVE, m_btnSave);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_CHOICE, m_cmbHead);

	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_START, m_edtHourStart);
	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_END, m_edtHourEnd);
	DDX_Control(pDX, IDC_EDIT_LOTID, m_edtLotID);
	DDX_Control(pDX, IDC_COMBO_BEAMPATH, m_cmbBeamPath);
	DDX_Control(pDX, IDC_COMBO_PANEL, m_cmbPanel);
	DDX_Control(pDX, IDC_COMBO_OFFSET, m_cmbOffset);
	//DDX_CBIndex(pDX, IDC_COMBO_HEAD, m_nSelectHead);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerVisionOffset, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerVisionOffset)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_BN_CLICKED(IDC_BUTTON_FIDSAVE,OnButtonSave)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_LIST_FIDUCIAL_SCALE, OnClickListLog)
	ON_CBN_SELCHANGE(IDC_COMBO_CHOICE, OnSelchangeCombo)
	ON_CBN_SELCHANGE(IDC_COMBO_BEAMPATH, &CPaneLogManagerVisionOffset::OnCbnSelchangeComboBeampath)
	//}}AFX_MSG_MAP
	ON_CBN_SELCHANGE(IDC_COMBO_PANEL, &CPaneLogManagerVisionOffset::OnCbnSelchangeComboPanel)
	ON_CBN_SELCHANGE(IDC_COMBO_OFFSET, &CPaneLogManagerVisionOffset::OnCbnSelchangeComboOffset)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerVisionOffset diagnostics

#ifdef _DEBUG
void CPaneLogManagerVisionOffset::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerVisionOffset::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerJobTime message handlers






void CPaneLogManagerVisionOffset::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEtcControl();
	InitEditControl();
	InitListControl();
	

	m_cmbHead.SetCurSel(0);
	m_nSelectHead = 0;

}

BOOL CPaneLogManagerVisionOffset::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}


void CPaneLogManagerVisionOffset::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	// save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

	if(m_nTimerID == 0)
		m_nTimerID = SetTimer(100, 300, NULL);

}

void CPaneLogManagerVisionOffset::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
// 	m_edtHourStart.SetFont( &m_fntEdit );
// 	m_edtHourStart.SetReceivedFlag( 5 ); 
// 
// 	m_edtHourEnd.SetFont( &m_fntEdit );
// 	m_edtHourEnd.SetReceivedFlag( 5 ); 



	m_edtHourStart.SetFont( &m_fntEdit );
	m_edtHourStart.SetForeColor( BLACK_COLOR );
	m_edtHourStart.SetBackColor( WHITE_COLOR );
	m_edtHourStart.SetReceivedFlag( 1 ); 
	m_edtHourStart.SetWindowText( _T("0") );


	m_edtHourEnd.SetFont( &m_fntEdit );
	m_edtHourEnd.SetForeColor( BLACK_COLOR );
	m_edtHourEnd.SetBackColor( WHITE_COLOR );
	m_edtHourEnd.SetReceivedFlag( 1 ); // Floating-Point
	m_edtHourEnd.SetWindowText( _T("24") );

	m_edtLotID.SetFont( &m_fntEdit );
	m_edtLotID.SetForeColor( BLACK_COLOR );
	m_edtLotID.SetBackColor( WHITE_COLOR );
	m_edtLotID.SetWindowText( _T("") );


}


void CPaneLogManagerVisionOffset::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_LOTID)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_TIME)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_DATE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PANEL)->SetFont( &m_fntStatic );
}

void CPaneLogManagerVisionOffset::InitListControl()
{
	// Set List Font
	if(&m_fntList == NULL)
		m_fntList.CreatePointFont(100, "Arial Bold");
	m_listFiducialScale.SetFont(&m_fntList);
	
	m_listFiducialScale.SetExtendedStyle(m_listFiducialScale.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_ImageList.DeleteImageList();
	m_ImageList.Create(IDB_SMALL_TYPE, 16, 1, RGB(0, 0, 0));
	
	m_listFiducialScale.DeleteAllItems();
	m_listFiducialScale.SetImageList(&m_ImageList, LVSIL_SMALL);

	for(int i = 13; i >= 0; i--)
		m_listFiducialScale.DeleteColumn(i);

	if(m_nSelectHead == 0) // scal 
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time " );
		lstrcpy(m_lpszColumnHead[2], " Panel ");
		lstrcpy(m_lpszColumnHead[3], " Operation ");
		lstrcpy(m_lpszColumnHead[4], " Cam ");
		lstrcpy(m_lpszColumnHead[5], " Division "); 
		lstrcpy(m_lpszColumnHead[6], " BeamPath ");
		lstrcpy(m_lpszColumnHead[7], " Offset X ");
		lstrcpy(m_lpszColumnHead[8], " Offset Y ");
		lstrcpy(m_lpszColumnHead[9], " Offset R ");
		lstrcpy(m_lpszColumnHead[10], " Min Offset X ");
		lstrcpy(m_lpszColumnHead[11], " Min Offset Y ");
		lstrcpy(m_lpszColumnHead[12], " Min Offset R ");
		lstrcpy(m_lpszColumnHead[13], " Accept Score ");
		lstrcpy(m_lpszColumnHead[14], " Edge Score ");
		lstrcpy(m_lpszColumnHead[15], " Cycle ");
		
		m_listFiducialScale.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listFiducialScale.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 70);
		m_listFiducialScale.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, 60);
		m_listFiducialScale.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_CENTER, 90);
		m_listFiducialScale.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_CENTER, 60);
		m_listFiducialScale.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_CENTER, 70);
		m_listFiducialScale.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_CENTER, 90);
		m_listFiducialScale.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(12, m_lpszColumnHead[11], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(13, m_lpszColumnHead[12], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(14, m_lpszColumnHead[13], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(15, m_lpszColumnHead[14], LVCFMT_CENTER, 95);
		m_listFiducialScale.InsertColumn(16, m_lpszColumnHead[15], LVCFMT_CENTER, 95);
	}
	else //head offset 
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time " );
		lstrcpy(m_lpszColumnHead[2], " Cam ");
		lstrcpy(m_lpszColumnHead[3], " Old X ");
		lstrcpy(m_lpszColumnHead[4], " New X "); 
		lstrcpy(m_lpszColumnHead[5], " Old Y ");
		lstrcpy(m_lpszColumnHead[6], " New Y ");
		lstrcpy(m_lpszColumnHead[7], " Old Z ");
		lstrcpy(m_lpszColumnHead[8], " New Z ");

		m_listFiducialScale.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listFiducialScale.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, 120);
		m_listFiducialScale.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, 105);
	}

}

void CPaneLogManagerVisionOffset::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");	
	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );

	m_cmbHead.SetFont( &m_fntEtc );
	m_nSelectHead = 0;
	m_cmbHead.ResetContent();
	m_cmbHead.AddString(_T("S.Cal"));
	m_cmbHead.SetCurSel(m_nSelectHead);

	m_cmbPanel.SetFont( &m_fntEtc );
	m_nPanel = 0;
	m_cmbPanel.ResetContent();
	m_cmbPanel.AddString(_T("1st Panel"));
	m_cmbPanel.AddString(_T("2nd Panel"));
	m_cmbPanel.AddString(_T("Both"));
	m_cmbPanel.SetCurSel(m_nPanel);

	m_cmbOffset.SetFont( &m_fntEtc );
	m_nOffset = 0;
	m_cmbOffset.ResetContent();
	m_cmbOffset.AddString(_T("Offset X"));
	m_cmbOffset.AddString(_T("Offset Y"));
	m_cmbOffset.AddString(_T("Offset R"));
	m_cmbOffset.AddString(_T("ALL"));
	m_cmbOffset.SetCurSel(m_nPanel);
	

	m_cmbBeamPath.SetFont( &m_fntEtc );
	SetToolComboBox();
	m_cmbBeamPath.SetCurSel(gBeamPathINI.m_sBeampath.nLastIndex + 1);
}

void CPaneLogManagerVisionOffset::OnTimer(UINT nIDEvent) 
{	
	if( m_bOnTimer )
	{
		CFormView::OnTimer(nIDEvent);
	}
	m_bOnTimer = FALSE;

	switch(nIDEvent)
	{
	case 100:
		if (!m_bShow)
		{
			ShowBackGround();
			m_bShow = TRUE;
		}
		else
		{
			if(m_nTimerID)
			{
				KillTimer(m_nTimerID);
				m_nTimerID = 0;
			}
		}
		break;
	default:
		break;
	}
	m_bOnTimer = FALSE;

	CFormView::OnTimer(nIDEvent);
}



void CPaneLogManagerVisionOffset::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneLogManagerVisionOffset::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if (m_bShow)
		ShowGraph();
}


void CPaneLogManagerVisionOffset::OnButtonView()
{
	UpdateData(TRUE);
	if(!CheckHour())
		return ;

	UpdateTime();
	m_bDataAdd = FALSE;

	m_strDate.Format(_T(""));

	m_nTotalTime[0] = m_nTotalTime[1] = m_nTotalTime[2] = m_nTotalTime[3] = m_nTotalTime[4] = 0;
	m_nSumTime[0] = m_nSumTime[1] = m_nSumTime[2] = m_nSumTime[3] = m_nSumTime[4] = 0;
	
	m_nOldYear = -1;
	m_listFiducialScale.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();
	
	m_dMax = m_dMaxOffsetX = m_dMaxOffsetY = m_dMaxOffsetR = -NONE_DATA;
	m_dMin = m_dMinOffsetX = m_dMinOffsetY = m_dMinOffsetR = NONE_DATA;

	int i,j;
	
	if( (m_ctStart.GetYear() != m_ctEnd.GetYear() ) && (m_ctStart.GetMonth() != m_ctEnd.GetMonth()))
	{
		for(i = m_ctStart.GetYear() ; i <= m_ctEnd.GetYear(); i++)
		{
			if(i == m_ctStart.GetYear() )
			{
				for( j =  m_ctStart.GetMonth(); j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else if( i == m_ctEnd.GetYear() )
			{
				for( j =  m_ctStart.GetMonth(); j <= m_ctEnd.GetMonth(); j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else
			{
				for( j =  1; j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
		}
	}
	else if( (m_ctStart.GetMonth() != m_ctEnd.GetMonth() ) )
	{
		for(int i = m_ctStart.GetMonth(); i <= m_ctEnd.GetMonth(); i++)
		{
			MakeFileString(m_ctEnd.GetYear() ,i);		
			FillList();
		}
	}
	else
	{
		MakeFileString(m_ctEnd.GetYear(),m_ctEnd.GetMonth());
		FillList();
	}

	ShowGraph();
}

void CPaneLogManagerVisionOffset::UpdateTime()
{
	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	int nStartHour, nEndHour;
	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	nEndHour = atoi((LPSTR)(LPCTSTR) strData);

	int nYear = m_ctStart.GetYear();
	int nMon = m_ctStart.GetMonth();
	int nDay = m_ctStart.GetDay();

	m_ctStart = CTime(nYear, nMon, nDay, nStartHour, 0, 0);
	
	nYear = m_ctEnd.GetYear();
	nMon = m_ctEnd.GetMonth();
	nDay = m_ctEnd.GetDay();
	
	if(nEndHour == 24)
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour-1, 59, 59);
	else
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour, 0, 0);
}

void CPaneLogManagerVisionOffset::MakeFileString(int nYear, int nMonth)
{
	CString strProcessLog;
	strProcessLog.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());	
	CString strFiducialScaleFile(strProcessLog);
	if(m_cmbHead.GetCurSel() == 0)
		strFiducialScaleFile += _T("SCalLog_Vision");
	else
		strFiducialScaleFile += _T("ChangeHeadOffset");

	CString strTime;
	strTime.Format(_T("%02d%02d"),nYear,nMonth);
	m_strFilePath = strFiducialScaleFile + strTime;	
}

void CPaneLogManagerVisionOffset::FillList()
{
	CString strFiducialScaleFile = m_strFilePath;
	BOOL bCamOffset = m_cmbHead.GetCurSel();

	int nStartYear = m_ctStart.GetYear();
	int nStartMon = m_ctStart.GetMonth();
	int nStartDay = m_ctStart.GetDay();
	int nEndYear = m_ctEnd.GetYear();
	int nEndMon = m_ctEnd.GetMonth();
	int nEndDay = m_ctEnd.GetDay();

	FILE *fp;

	if(NULL != fopen_s(&fp, (LPCTSTR) strFiducialScaleFile,"r"))
		return ;

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;

	CString strTime, strDate, strPanel, strOP, strCam, strDivision, strOffsetX, strOffsetY, strTemp, strOffsetR, strBeamPath, strScore1, strScore2, strCycle, strMinOffsetX, strMinOffsetY, strMinOffsetR;
	CString strOldX, strOldY, strOldZ, strNewX, strNewY, strNewZ;
	int nYear, nMon, nDay;
	int nBeamPath, nIndex;
	double dOffsetX, dOffsetY, dOffsetR, dMinOffsetX, dMinOffsetY, dMinOffsetR;
	for(int nStart = m_listFiducialScale.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{
		if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ��¥
		{
			if (feof(fp))
				break;
			else
				continue;
		}
		
		strDate = token;
		strDate.TrimLeft();
		strDate.TrimRight();
		
		int nPos = strDate.Find(_T('/'));
		int nLen = strDate.GetLength();
		nYear = atoi(strDate.Left(nPos));
		strTemp = strDate.Right(nLen - nPos - 1);
		nPos = strTemp.Find(_T('/'));
		nLen = strTemp.GetLength();
		nMon = atoi(strTemp.Left(nPos));
		nDay = atoi(strTemp.Right(nLen - nPos - 1));
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ð�
			continue;
		
		strTime = token;
		strTime.TrimLeft();
		strTime.TrimRight();

		// �ð� �̱�	
		nPos = strTime.Find(_T(':'));
		nLen = strTime.GetLength();
		int nHour = atoi(strTime.Left(nPos));
		
		CTime cTime2(nYear, nMon, nDay, nHour, 1, 1);
		if (cTime2 < m_ctStart || cTime2 > m_ctEnd)
		{
			m_strDate.Format(_T(""));
			continue;
		}

		if(!bCamOffset)
		{
			//Panel
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strPanel = token; 
			strPanel.TrimLeft(); 
			strPanel.TrimRight();

			if( m_nPanel == 0 && strPanel.Find(_T('1')) == -1)
				continue;
			else if(m_nPanel == 1 && strPanel.Find(_T('2')) == -1)
				continue;
			
			//Operation
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOP = token; 
			strOP.TrimLeft(); 
			strOP.TrimRight();

			//if( 0 != strOP.CompareNoCase(_T("Prework")) ) //vision ���� �����ϱ� ����
			//	continue;

			// Cam"scal
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strCam = token; 
			strCam.TrimLeft(); 
			strCam.TrimRight();

			// Division
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strDivision = token; 
			strDivision.TrimLeft(); 
			strDivision.TrimRight();

			//if(atoi(strDivision) != 3) //vision���� �����ϱ� ���� 
			//	continue;

			// Offset X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOffsetX = token; 
			strOffsetX.TrimLeft(); 
			strOffsetX.TrimRight();
			dOffsetX = atof(strOffsetX);
			

			// Offset Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOffsetY = token; 
			strOffsetY.TrimLeft(); 
			strOffsetY.TrimRight();
			dOffsetY = atof(strOffsetY);

			// Offset R
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strOffsetR = token; 
			strOffsetR.TrimLeft(); 
			strOffsetR.TrimRight();
			dOffsetR = atof(strOffsetR);

			// Min Offset X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strMinOffsetX = token; 
			strMinOffsetX.TrimLeft(); 
			strMinOffsetX.TrimRight();
			dMinOffsetX = atof(strMinOffsetX);

			// Min Offset Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strMinOffsetY = token; 
			strMinOffsetY.TrimLeft(); 
			strMinOffsetY.TrimRight();
			dMinOffsetY = atof(strMinOffsetY);

			// Min Offset R
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strMinOffsetR = token; 
			strMinOffsetR.TrimLeft(); 
			strMinOffsetR.TrimRight();
			dMinOffsetR = atof(strMinOffsetR);

			// BeamPath
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strBeamPath = token; 
			strBeamPath.TrimLeft(); 
			strBeamPath.TrimRight();

			nBeamPath = atoi(strBeamPath);

			if(m_nBeamPath <= gBeamPathINI.m_sBeampath.nLastIndex && nBeamPath != -1)
			{
				if(nBeamPath != m_nBeamPath)
					continue;
			}

			// Accept Score
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strScore1 = token; 
			strScore1.TrimLeft(); 
			strScore1.TrimRight();

			// Edge Score
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strScore2 = token; 
			strScore2.TrimLeft(); 
			strScore2.TrimRight();

			// Cycle
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
			{
				strCycle = _T("-");
			}
			else
			{
			strCycle = token; 
			strCycle.TrimLeft(); 
			strCycle.TrimRight();
			}

			if (dOffsetX > m_dMaxOffsetX)
				m_dMaxOffsetX = dOffsetX;
			if (dOffsetY > m_dMaxOffsetY)
				m_dMaxOffsetY = dOffsetY;
			if (dOffsetR > m_dMaxOffsetR)
				m_dMaxOffsetR = dOffsetR;

			if (dMinOffsetX < m_dMinOffsetX)
				m_dMinOffsetX = dOffsetX;
			if (dMinOffsetY < m_dMinOffsetY)
				m_dMinOffsetY = dOffsetY;
			if (dMinOffsetR < m_dMinOffsetR)
				m_dMinOffsetR = dOffsetR;

			double TempMax, TempMin;
			TempMax = max(m_dMaxOffsetX, m_dMaxOffsetY);
			TempMax = max(TempMax,m_dMaxOffsetR);

			TempMin = min(m_dMinOffsetX, m_dMinOffsetY);
			TempMin = min(TempMin,m_dMinOffsetR);

			m_dMax = max(m_dMax, TempMax);
			m_dMin = min(m_dMin, TempMin);

			int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
			m_listFiducialScale.SetItemText(nInsert,1,strDate);
			m_listFiducialScale.SetItemText(nInsert,2,strTime);
			m_listFiducialScale.SetItemText(nInsert,3,strPanel);
			m_listFiducialScale.SetItemText(nInsert,4,strOP);
			m_listFiducialScale.SetItemText(nInsert,5,strCam);
			m_listFiducialScale.SetItemText(nInsert,6,strDivision);
			m_listFiducialScale.SetItemText(nInsert,7, strBeamPath);
			m_listFiducialScale.SetItemText(nInsert,8,strOffsetX);
			m_listFiducialScale.SetItemText(nInsert,9,strOffsetY);	
			m_listFiducialScale.SetItemText(nInsert,10,strOffsetR);
			m_listFiducialScale.SetItemText(nInsert,11,strMinOffsetX);
			m_listFiducialScale.SetItemText(nInsert,12,strMinOffsetY);	
			m_listFiducialScale.SetItemText(nInsert,13,strMinOffsetR);
			m_listFiducialScale.SetItemText(nInsert,14,strScore1);
			m_listFiducialScale.SetItemText(nInsert,15,strScore2);
			m_listFiducialScale.SetItemText(nInsert,16,strCycle);		
		}
		else
		{
			//Cam
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strCam = token; 
			strCam.TrimLeft(); 
			strCam.TrimRight();

			//Old X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldX = token; 
			strOldX.TrimLeft(); 
			strOldX.TrimRight();

			//New X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewX = token; 
			strNewX.TrimLeft(); 
			strNewX.TrimRight();

			//Old Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldY = token; 
			strOldY.TrimLeft(); 
			strOldY.TrimRight();
			
			//New Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewY = token; 
			strNewY.TrimLeft(); 
			strNewY.TrimRight();

			//Old Z
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldZ = token; 
			strOldZ.TrimLeft(); 
			strOldZ.TrimRight();
			
			//New Z
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewZ = token; 
			strNewZ.TrimLeft(); 
			strNewZ.TrimRight();

			int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
			m_listFiducialScale.SetItemText(nInsert,1,strDate);
			m_listFiducialScale.SetItemText(nInsert,2,strTime);
			m_listFiducialScale.SetItemText(nInsert,3,strCam);
			m_listFiducialScale.SetItemText(nInsert,4,strOldX);
			m_listFiducialScale.SetItemText(nInsert,5,strNewX);
			m_listFiducialScale.SetItemText(nInsert,6,strOldY);
			m_listFiducialScale.SetItemText(nInsert,7,strNewY);
			m_listFiducialScale.SetItemText(nInsert,8,strOldZ);
			m_listFiducialScale.SetItemText(nInsert,9,strNewZ);
		}
	}
	fclose(fp);
}

void CPaneLogManagerVisionOffset::OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowDetailInformation();
	*pResult = 0;
}

void CPaneLogManagerVisionOffset::ShowDetailInformation()
{
	int nSel = m_listFiducialScale.GetSelectionMark();
	if(-1 == nSel)
		return;
}

void CPaneLogManagerVisionOffset::OnButtonSave()
{
	UpdateData(TRUE);

	
	if (0 == m_listFiducialScale.GetItemCount())
		return;
	
	TCHAR szFilter[] = _T("JobTime File(*.txt)|*.txt||");
	CFileDialog filedlg(FALSE, _T("txt"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	
	//	filedlg.m_ofn.lpstrInitialDir = _T("C:\\");
	
	if(IDOK == filedlg.DoModal())
	{
		CString strSaveAsProjectFileName = filedlg.GetPathName();
		WriteLogFile(strSaveAsProjectFileName);
	}
	else
		return;	
}

void CPaneLogManagerVisionOffset::WriteLogFile(CString& strSaveFileName)
{
	CStdioFile cFile;
	TCHAR seps[] = _T(":\n");
	const CString strSeps = _T(":\n");
	TCHAR szBuf[2048] ={0,};
	CString strDetail, strLine;
	CString str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16;
	int nMax = m_listFiducialScale.GetItemCount();

	if (FALSE == cFile.Open(strSaveFileName, CFile::modeCreate | CFile::modeWrite))
	{
		ErrMessage(IDS_CREATE_FILE_ERR, MB_ICONERROR);
		return;
	}
	
	TRY
	{
		if(m_nSelectHead == 0)
		{
			strLine.Format(_T("Date\t Time\t Panel\t Operation\t Cam\t Division\t BeamPath\t Offset X\t Offset Y\t Offset R\t Min Offset X\t Min Offset Y\t Min Offset R\t Accept Score\t Edge Score\t Cycle\t \n"));
			strDetail += strLine;
			
			for (int i = 0; i < nMax; i++)
			{	
				str1 = m_listFiducialScale.GetItemText(i, 1);
				str2 = m_listFiducialScale.GetItemText(i, 2);
				str3 = m_listFiducialScale.GetItemText(i, 3);
				str4 = m_listFiducialScale.GetItemText(i, 4);
				str5 = m_listFiducialScale.GetItemText(i, 5);
				str6 = m_listFiducialScale.GetItemText(i, 6);
				str7 = m_listFiducialScale.GetItemText(i, 7);
				str8 = m_listFiducialScale.GetItemText(i, 8);
				str9 = m_listFiducialScale.GetItemText(i, 9);
				str10 = m_listFiducialScale.GetItemText(i, 10);
				str11 = m_listFiducialScale.GetItemText(i, 11);
				str12 = m_listFiducialScale.GetItemText(i, 12);
				str13 = m_listFiducialScale.GetItemText(i, 13);
				str14 = m_listFiducialScale.GetItemText(i, 14);
				str15 = m_listFiducialScale.GetItemText(i, 15);
				str16 = m_listFiducialScale.GetItemText(i, 16);

				strLine.Format(_T("%s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t \n"),
					str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13);
				strDetail += strLine;
				cFile.WriteString(strDetail);
				strDetail ="";		
			}
		}
		else
		{
			strLine.Format(_T("Date\t Time\t Cam\t Old X\t New X\t Old Y\t New Y\t Old Z\t New Z\t \n"));
			strDetail += strLine;
			
			for (int i = 0; i < nMax; i++)
			{	
				str1 = m_listFiducialScale.GetItemText(i, 1);
				str2 = m_listFiducialScale.GetItemText(i, 2);
				str3 = m_listFiducialScale.GetItemText(i, 3);
				str4 = m_listFiducialScale.GetItemText(i, 4);
				str5 = m_listFiducialScale.GetItemText(i, 5);
				str6 = m_listFiducialScale.GetItemText(i, 6);
				str7 = m_listFiducialScale.GetItemText(i, 7);
				str8 = m_listFiducialScale.GetItemText(i, 8);
				str9 = m_listFiducialScale.GetItemText(i, 9);
				
				strLine.Format(_T("%s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t \n"),
					str1, str2, str3, str4, str5, str6, str7, str8, str9);
				strDetail += strLine;
				cFile.WriteString(strDetail);
				strDetail ="";		
			}
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
		
	cFile.Close();
}

BOOL CPaneLogManagerVisionOffset::CheckHour()
{
	UpdateData(TRUE);

	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	m_nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	m_nEndHour = atoi((LPSTR)(LPCTSTR) strData);


	if( (m_nStartHour >  m_nEndHour)  || ( m_nStartHour > 24 || 0 > m_nStartHour) || ( m_nEndHour > 24 || 0 > m_nEndHour) )
	{	
		ErrMessage(_T("Please change Time Value "));
		return FALSE;
	}

	return TRUE;


}

void CPaneLogManagerVisionOffset::OnSelchangeCombo() 
{
	m_nSelectHead = m_cmbHead.GetCurSel();
	InitListControl();
}

void CPaneLogManagerVisionOffset::ShowBackGround()
{
	CClientDC dc(GetDlgItem(IDC_TREND_GRAPH));
	CRect cRect;
	GetDlgItem(IDC_TREND_GRAPH)->GetClientRect(&cRect);
	CBrush cBr(RGB(0, 0, 0));
	dc.FrameRect(&cRect, &cBr);
	cRect.DeflateRect(1, 1);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));
}

void CPaneLogManagerVisionOffset::ShowGraph()
{
	CWnd* pGraph = GetDlgItem(IDC_TREND_GRAPH);
	CClientDC dc(pGraph);
	CRect cRect;
	pGraph->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	dc.SelectClipRgn(&cRgn);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));

	int nXRange = m_listFiducialScale.GetItemCount();
	if (nXRange <= 1)
		return;

	const int nX = 1300;
	double dXUnit = 1000.0 / (nXRange - 1);

	double dYRange = m_dMax - m_dMin;

	if (dYRange == 0.0)
	{
		m_dMax += 2.0;
		dYRange = 2.0;
	}

	const int nY = 1600;
	double dYUnit = 1000.0 / (dYRange);

	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12) + 0.5);
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(16) + 0.5);

	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - 2 * nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt(nX, nY);

	CPen* pOldPen;
	CFont *pOldFont;
	CString strVal;
	LOGFONT logFont = m_logFont;
	bool bFirst;

	if(m_nOffset == 0 || m_nOffset == 3)
	{
		CPen pen(PS_SOLID, 10, RGB(0, 0, 255));
		pOldPen = dc.SelectObject(&pen);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 8);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(0, 1250);
		dc.LineTo(50, 1250);
		CFont cFont;
		logFont.lfHeight = 100;
		cFont.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFont);
		dc.TextOut(80, 1320, _T("Max X"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);

		//Min Offset 
		CPen penMinX(PS_SOLID, 10, RGB(240, 100, 160));
		pOldPen = dc.SelectObject(&penMinX);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 11);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(550, 1250);
		dc.LineTo(600, 1250);
		CFont cFontMinX, *pOldFontMinX;
		logFont.lfHeight = 100;
		cFontMinX.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFontMinX);
		dc.TextOut(630, 1320, _T("Min X"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);
	}
	

	if(m_nOffset == 1 || m_nOffset == 3)
	{
		CPen penY(PS_SOLID, 10, RGB(255, 0, 0));
		pOldPen = dc.SelectObject(&penY);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 9);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(180, 1250);
		dc.LineTo(230, 1250);
		CFont cFontY;
		logFont.lfHeight = 100;
		cFontY.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFontY);
		dc.TextOut(260, 1320, _T("Max Y"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);

		CPen penMinY(PS_SOLID, 10, RGB(100, 0, 255));
		pOldPen = dc.SelectObject(&penMinY);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 12);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(730, 1250);
		dc.LineTo(780, 1250);
		CFont cFontMinY;
		logFont.lfHeight = 100;
		cFontMinY.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFontMinY);
		dc.TextOut(810, 1320, _T("Min Y"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);
	}
	
	if(m_nOffset == 2 || m_nOffset == 3)
	{
		CPen penR(PS_SOLID, 10, RGB(0, 255, 0));
		pOldPen = dc.SelectObject(&penR);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 10);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(360, 1250);
		dc.LineTo(410, 1250);
		CFont cFontR;
		logFont.lfHeight = 100;
		cFontR.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFontR);
		dc.TextOut(440, 1320, _T("Max R"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);

		CPen penMinR(PS_SOLID, 10, RGB(255, 220, 0));
		pOldPen = dc.SelectObject(&penMinR);
		bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listFiducialScale.GetItemText(i, 13);
			double dVal = atof(strVal);
			dVal -= m_dMin;

#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(910, 1250);
		dc.LineTo(960, 1250);
		CFont cFontMinR;
		logFont.lfHeight = 100;
		cFontMinR.CreateFontIndirect(&logFont);
		pOldFont = dc.SelectObject(&cFontMinR);
		dc.TextOut(990, 1320, _T("Min R"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);
	}

	// �ѷ��δ� �簢�� �׸���
	dc.MoveTo(0, 0);
	dc.LineTo(1100, 0);
	dc.LineTo(1100, 1150);
	dc.LineTo(0, 1150);
	dc.LineTo(0, 0);

	//X��
	for (int i = 0; i < nXRange; i++)
	{
		if (i == 0 || i == (nXRange - 1) / 2 || i == nXRange - 1)
		{
			strVal = m_listFiducialScale.GetItemText(i, 1);
			/*int n = strVal.Find(_T('/'));
			strVal = strVal.Right(strVal.GetLength() - n - 1);
			if (strVal[0] == _T('0'))
			strVal.SetAt(0, _T(' '));*/

			LOGFONT logFont = m_logFont;
			logFont.lfHeight = 100;

			CFont cfDate, *pOldFont;
			cfDate.CreateFontIndirect(&logFont);
			pOldFont = dc.SelectObject(&cfDate);
			dc.TextOut(static_cast<int>(dXUnit * i + 0.5), -10, strVal);
			dc.SelectObject(pOldFont);

			dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, 0);
			dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, 30);
		}
	}
	// Y ��
	dc.MoveTo(0, 100);
	dc.LineTo(15, 100);
	strVal.Format(_T("%.1f"), m_dMin);

	logFont.lfHeight = 120;

	CFont cfDate;
	cfDate.CreateFontIndirect(&logFont);
	pOldFont = dc.SelectObject(&cfDate);
	dc.SetTextAlign(TA_RIGHT);
	dc.TextOut(-10, 160, strVal);

	dc.MoveTo(0, 600);
	dc.LineTo(15, 600);
	strVal.Format(_T("%.1f"), m_dMin+((m_dMax - m_dMin)/2));
	dc.TextOut(-10, 600, strVal);

	dc.MoveTo(0, 1100);
	dc.LineTo(15, 1100);
	strVal.Format(_T("%.1f"), m_dMax);
	dc.TextOut(-10, 1160, strVal);
	dc.SelectObject(pOldFont);
}

void CPaneLogManagerVisionOffset::OnCbnSelchangeComboBeampath()
{
	// TODO: Add your control notification handler code here
	m_nBeamPath = m_cmbBeamPath.GetCurSel();
}

void CPaneLogManagerVisionOffset::SetToolComboBox()
{
	m_cmbBeamPath.ResetContent();

	CString strTool;

	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbBeamPath.AddString(strTool);
	}

	strTool.Format(_T("Non Select"));
	m_cmbBeamPath.AddString(strTool);

}

void CPaneLogManagerVisionOffset::OnCbnSelchangeComboPanel()
{
	// TODO: Add your control notification handler code here
	m_nPanel = m_cmbPanel.GetCurSel();
}


void CPaneLogManagerVisionOffset::OnCbnSelchangeComboOffset()
{
	// TODO: Add your control notification handler code here
	m_nOffset = m_cmbOffset.GetCurSel();
}
