#pragma once

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "..\model\ComponentLaserINIFile.h"
#include "..\model\DComponentLaserINI.h"
#include "GridCtrl_src\GridCtrl.h"

#define		TABLE0_COLUMN_COUNT 2
#define		TABLE0  0
#define		TABLE1  1
// CPaneSysSetupComponentLaser �� ���Դϴ�.

class CPaneSysSetupComponentLaser : public CFormView
{
	DECLARE_DYNCREATE(CPaneSysSetupComponentLaser)

protected:
	CPaneSysSetupComponentLaser();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CPaneSysSetupComponentLaser();

public:
	enum { IDD = IDD_DLG_SYS_SETUP_COMPONENT_LASER };
public:
	CGridCtrl		m_Grid;
	CString		strTable0[TABLE0_COLUMN_COUNT];// = {"Year", "Month"};
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;
	CFont			m_fntEtc;
	int					m_nColumnCount;
	SCOMPONENTLASER		m_sComponentLaser;
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 
	CDateTimeCtrl	m_dtcStart;
	CTime	m_ctStart;
	UEasyButtonEx	m_btnSave;
	UEasyButtonEx	m_btnReset;
	BOOL m_bAlarmCheck;
	int		m_nUseYearLaser;
	CColorEdit		m_edtLaserUsingTime;

	void	InitBtnControl();
	void	InitStaticControl();
	void	InitEditControl();
	void	InitGrid();
	void	InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount);
	void	InsertListComumn(int startNo, int TableNo);
	void	SetDrawMember(int listcount);
	BOOL	FillTable0Data(int x, int y, CString str);
	BOOL	FillTable1Data(int x, int y, CString str);
	void			OnCheckRefresh();
	void			SetComponentLaser(SCOMPONENTLASER sComponentLaser);
	void			GetComponentLaser(SCOMPONENTLASER* pComponentLaser);
	BOOL		ListUpdate(CPoint ClickedPos, CString str);
	void			CheckComponentOverDate();
	void			UpdateLaserUseTime();
	BOOL		ValidateComponentLaser();

#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	afx_msg void OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonReset();
};


