// PaneManualControlMotorKunsan1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "panemanualcontrolmotorkunsan1.h"

#include "..\device\hdevicefactory.h"
#include "..\device\HMotor.h"
//#include "..\device\devicemotor.h"
#include "..\alarmmsg.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HEocard.h"
#include "..\model\dprocessini.h"
#include "..\model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\easydrillerdlg.h"
#include "..\device\HMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorKunsan1

IMPLEMENT_DYNCREATE(CPaneManualControlMotorKunsan1, CFormView)

CPaneManualControlMotorKunsan1::CPaneManualControlMotorKunsan1()
	: CFormView(CPaneManualControlMotorKunsan1::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlMotorKunsan1)
	m_nAbs = 0;
	m_bTargetX = FALSE;
	m_bTargetY = FALSE;
	m_bTargetZ1 = FALSE;
	m_bTargetZ2 = FALSE;
	m_bTargetC = FALSE;
	m_bTargetM = FALSE;
	m_bTargetM2 = FALSE;
	m_nMasterSlave = 2;
	//}}AFX_DATA_INIT
	m_bMasterSuction		= FALSE;
	m_bSlaveSuction			= FALSE;
	m_bVacuumMotor			= FALSE;
	m_nMPGMode				= 0;
	m_bSafetyMode			= FALSE;
	m_bDoorBypass			= FALSE;
	m_bTableClamp1			= FALSE;
	m_bTableClamp2			= FALSE;
}

CPaneManualControlMotorKunsan1::~CPaneManualControlMotorKunsan1()
{
}

void CPaneManualControlMotorKunsan1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlMotorKunsan1)
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL3, m_stcPosC3);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL4, m_stcPosM2);
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL, m_stcSpeedM);
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL4, m_stcSpeedM2);
	DDX_Control(pDX, IDC_STATIC_SPEED_COLLIMATOR_VAL, m_stcSpeedC);
	DDX_Control(pDX, IDC_STATIC_SPEED_Z2_VAL, m_stcSpeedZ2);
	DDX_Control(pDX, IDC_STATIC_SPEED_Z1_VAL, m_stcSpeedZ1);
	DDX_Control(pDX, IDC_STATIC_SPEED_Y_VAL, m_stcSpeedY);
	DDX_Control(pDX, IDC_STATIC_SPEED_X_VAL, m_stcSpeedX);
	DDX_Control(pDX, IDC_STATIC_POS_Z2_VAL, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VAL, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VAL, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_X_VAL, m_stcPosX);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_HOMING, m_btnUnloaderHoming);
	DDX_Control(pDX, IDC_BUTTON_LOADER_HOMING, m_btnLoaderHoming);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_HOMING, m_btnMotorHoming);
	DDX_Control(pDX, IDC_BUTTON_POS_UNLOADING, m_btnUnloadingPos);
	DDX_Control(pDX, IDC_BUTTON_POS_LOADING, m_btnLoadingPos);
	DDX_Control(pDX, IDC_CHECK_SLAVE_ON, m_chkSlaveOn);
	DDX_Control(pDX, IDC_CHECK_MASTER_ON, m_chkMasterOn);
	DDX_Control(pDX, IDC_CHECK_VACUUM_MOTOR, m_chkVacuumMotorOn);
	DDX_Control(pDX, IDC_CHECK_SAFETY_MODE, m_chkSafetyOn);
	DDX_Control(pDX, IDC_CHECK_DOOR_BYPASS, m_chkDoorBypass);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_chkTableClamp1);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_chkTableClamp2);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_UNLOAD, m_btnUnloaderUnload);
	DDX_Control(pDX, IDC_BUTTON_MPG_MODE, m_btnMPG);
	DDX_Control(pDX, IDC_BUTTON_REJECT, m_btnReject);
	DDX_Control(pDX, IDC_BUTTON_LOADER_LOAD, m_btnLoaderLoad);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN, m_btnLoaderAlign);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_MOVE2, m_btnMove2);
	DDX_Control(pDX, IDC_BUTTON_MOVE_INPOS, m_btnMoveInpos);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_Y, m_edtTargetY);
	DDX_Control(pDX, IDC_EDIT_TARGET_M, m_edtTargetM);
	DDX_Control(pDX, IDC_EDIT_TARGET_M3, m_edtTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_C, m_edtTargetC);
	DDX_Control(pDX, IDC_EDIT_TARGET_X, m_edtTargetX);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z4, m_edtTargetZ4);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z3, m_edtTargetZ3);
	DDX_Control(pDX, IDC_EDIT_TARGET_Y2, m_edtTargetY2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M5, m_edtTargetM4);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2, m_edtTargetC2);
	DDX_Control(pDX, IDC_EDIT_TARGET_X2, m_edtTargetX2);

	DDX_Control(pDX, IDC_EDIT_TARGET_C7, m_edtTargetC2_1);
	DDX_Control(pDX, IDC_EDIT_TARGET_C8, m_edtTargetC2_2);

	DDX_Control(pDX, IDC_EDIT_REPEAT, m_edtRep);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nAbs);
	DDX_Check(pDX, IDC_CHECK_TARGET_X, m_bTargetX);
	DDX_Check(pDX, IDC_CHECK_TARGET_Y, m_bTargetY);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z1, m_bTargetZ1);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z2, m_bTargetZ2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C, m_bTargetC);
	DDX_Check(pDX, IDC_CHECK_TARGET_C3, m_bTargetC3);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK, m_bTargetM);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK3, m_bTargetM2);
	DDX_Radio(pDX, IDC_RADIO_UNLOAD_M, m_nMasterSlave);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlMotorKunsan1, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlMotorKunsan1)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE2, OnButtonMove2)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_INPOS, OnButtonMoveInpos)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN, OnButtonLoaderAlign)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_LOAD, OnButtonLoaderLoad)
	ON_BN_CLICKED(IDC_CHECK_MASTER_ON, OnCheckMasterOn)
	ON_BN_CLICKED(IDC_CHECK_SLAVE_ON, OnCheckSlaveOn)
	ON_BN_CLICKED(IDC_CHECK_VACUUM_MOTOR, OnCheckVacuumMotorOn)
	ON_BN_CLICKED(IDC_CHECK_SAFETY_MODE, OnCheckSafetyOn)
	ON_BN_CLICKED(IDC_CHECK_DOOR_BYPASS, OnCheckDoorBypass)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP1, OnCheckTableClamp1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP2, OnCheckTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_POS_LOADING, OnButtonPosLoading)
	ON_BN_CLICKED(IDC_BUTTON_POS_UNLOADING, OnButtonPosUnloading)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_UNLOAD, OnButtonUnloaderUnload)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_HOMING, OnButtonMotorHoming)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_HOMING, OnButtonLoaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_HOMING, OnButtonUnloaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_MPG_MODE, OnButtonMPG)
	ON_BN_CLICKED(IDC_BUTTON_REJECT, OnButtonReject)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorKunsan1 diagnostics

#ifdef _DEBUG
void CPaneManualControlMotorKunsan1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlMotorKunsan1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorKunsan1 message handlers

void CPaneManualControlMotorKunsan1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();

	DispVelocity();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{	
		GetDlgItem(IDC_CHECK_SLAVE_ON)->EnableWindow(FALSE);
		m_nMasterSlave = 0;
		GetDlgItem(IDC_STATIC_TABLE_USE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_M)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_S)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_MS)->ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);

		GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TARGET_MASK3)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M3)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M5)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK_VAL4)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK_VAL4)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TARGET_C3)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_C)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_C2)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->EnableWindow(FALSE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_TARGET_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_TARGET_Z3)->EnableWindow(FALSE);
			
			GetDlgItem(IDC_STATIC_POS_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_POS_Z1_VAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_SPEED_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_SPEED_Z1_VAL)->EnableWindow(FALSE);
		}
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		GetDlgItem(IDC_STATIC_SAFETY_MODE)->ShowWindow(SW_HIDE);
		m_chkSafetyOn.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_MPG_MODE)->ShowWindow(SW_HIDE);
		m_btnMPG.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_LOADER)->ShowWindow(SW_HIDE);
		m_btnLoaderLoad.ShowWindow(SW_HIDE);

		m_btnStop.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_UNLOADER)->ShowWindow(SW_HIDE);
		m_btnUnloaderUnload.ShowWindow(SW_HIDE);

//		GetDlgItem(IDC_STATIC_LOADING_UNLOADING_POS)->ShowWindow(SW_HIDE);
//		m_btnLoadingPos.ShowWindow(SW_HIDE);
//		m_btnUnloadingPos.ShowWindow(SW_HIDE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		GetDlgItem(IDC_STATIC_HOMING)->ShowWindow(SW_HIDE);
		m_btnMotorHoming.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_VACUUM_MOTOR)->ShowWindow(SW_HIDE);
		m_chkVacuumMotorOn.ShowWindow(SW_HIDE);

		m_chkMasterOn.SetWindowText("Suction On");
		m_chkMasterOn.SetCheck(0);
		
		m_chkSlaveOn.EnableWindow(TRUE);
		m_chkSlaveOn.SetWindowText("Suction Off");
		m_chkSlaveOn.SetCheck(0);
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(TRUE);
		
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(TRUE);
	}

//	m_nTimerID = SetTimer( 38, 300, NULL );
	m_nTimerID = 0;
}

BOOL CPaneManualControlMotorKunsan1::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlMotorKunsan1::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Position
	GetDlgItem(IDC_STATIC_MOTOR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_X_VAL)->SetFont( &m_fntStatic );
	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Y_VAL)->SetFont( &m_fntStatic );
	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Z1_VAL)->SetFont( &m_fntStatic );
	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Z2_VAL)->SetFont( &m_fntStatic );
	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_MASK_VAL)->SetFont( &m_fntStatic );
	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK2)->SetFont( &m_fntStatic );
	m_stcPosM2.SetFont( &m_fntStatic );
	m_stcPosM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM2.SetBackColor( VALUE_BACK_COLOR );
	
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR3)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC3.SetFont( &m_fntStatic );
	m_stcPosC3.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC3.SetBackColor( VALUE_BACK_COLOR );
	
	GetDlgItem(IDC_STATIC_REPEAT)->SetFont(&m_fntStatic);

	// Speed
	GetDlgItem(IDC_STATIC_MOTOR_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SPEED_X)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_X_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedX.SetFont( &m_fntStatic );
	m_stcSpeedX.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedX.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Y)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Y_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedY.SetFont( &m_fntStatic );
	m_stcSpeedY.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedY.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Z1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Z1_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedZ1.SetFont( &m_fntStatic );
	m_stcSpeedZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedZ1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Z2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedZ2.SetFont( &m_fntStatic );
	m_stcSpeedZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedZ2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_MASK)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_MASK_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedM.SetFont( &m_fntStatic );
	m_stcSpeedM.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_MASK2)->SetFont( &m_fntStatic );
	m_stcSpeedM2.SetFont( &m_fntStatic );
	m_stcSpeedM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedC.SetFont( &m_fntStatic );
	m_stcSpeedC.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedC.SetBackColor( VALUE_BACK_COLOR );

	// Target Pos
	GetDlgItem(IDC_STATIC_TARGET_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1_GROUP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2_GROUP)->SetFont( &m_fntStatic );

	// Loader
	GetDlgItem(IDC_STATIC_LOADER)->SetFont( &m_fntStatic );
	
	// Unloader
	GetDlgItem(IDC_STATIC_UNLOADER)->SetFont( &m_fntStatic );

	// Table Suction
	GetDlgItem(IDC_STATIC_TABLE_SUCTION)->SetFont( &m_fntStatic );

	// Table Use
	GetDlgItem(IDC_STATIC_TABLE_USE)->SetFont( &m_fntStatic );

	// MPG Mode
	GetDlgItem(IDC_STATIC_MPG_MODE)->SetFont( &m_fntStatic );

	// Table Reject
	GetDlgItem(IDC_STATIC_REJECT)->SetFont(&m_fntStatic);

	// Vacuum Motor
	GetDlgItem(IDC_STATIC_VACUUM_MOTOR)->SetFont( &m_fntStatic );

	// Safety Mode
	GetDlgItem(IDC_STATIC_SAFETY_MODE)->SetFont( &m_fntStatic );

	// Door by pass
	GetDlgItem(IDC_STATIC_DOOR_BYPASS)->SetFont( &m_fntStatic );

	// Loading / Unloading Position
	GetDlgItem(IDC_STATIC_LOADING_UNLOADING_POS)->SetFont( &m_fntStatic );

	// Table Clamp
	GetDlgItem(IDC_STATIC_TABLE_CLAMP)->SetFont( &m_fntStatic );
	
	// Homing
	GetDlgItem(IDC_STATIC_HOMING)->SetFont( &m_fntStatic );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_STATIC_POS_MASK)->SetWindowText("A1");
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->SetWindowText("A2");
		GetDlgItem(IDC_STATIC_SPEED_MASK)->SetWindowText("A1");
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->SetWindowText("A2");
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->SetWindowText("Theta");
		GetDlgItem(IDC_STATIC_POS_MASK)->SetWindowText("A");
		GetDlgItem(IDC_STATIC_SPEED_Z2)->SetWindowText("Theta");
		GetDlgItem(IDC_STATIC_SPEED_MASK)->SetWindowText("A");
		
		GetDlgItem(IDC_CHECK_TARGET_Z2)->SetWindowText("T");
		GetDlgItem(IDC_CHECK_TARGET_MASK)->SetWindowText("A");

	}
}

void CPaneManualControlMotorKunsan1::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Target Position
	GetDlgItem(IDC_CHECK_TARGET_X)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Y)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C3)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_ABS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_INC)->SetFont( &m_fntBtn );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_CHECK_TARGET_MASK)->SetWindowText("A1");
		GetDlgItem(IDC_CHECK_TARGET_C)->SetWindowText("A2");
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_MOTOR_SPEED)->SetWindowText(" Speed (mm/min) ");
		GetDlgItem(IDC_STATIC_POS_Z2)->SetWindowText("Theta");
		GetDlgItem(IDC_STATIC_POS_MASK)->SetWindowText("A");
		GetDlgItem(IDC_STATIC_SPEED_Z2)->SetWindowText("Theta");
		GetDlgItem(IDC_STATIC_SPEED_MASK)->SetWindowText("A");

		GetDlgItem(IDC_CHECK_TARGET_Z2)->SetWindowText("T");
		GetDlgItem(IDC_CHECK_TARGET_MASK)->SetWindowText("A");

		GetDlgItem(IDC_STATIC_SPEED_MASK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SPEED_MASK_VAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_M)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C2)->ShowWindow(SW_HIDE);
	}
	
	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMove2.SetFont( &m_fntBtn );
	m_btnMove2.SetFlat( FALSE );
	m_btnMove2.EnableBallonToolTip();
	m_btnMove2.SetToolTipText( _T("Move Tagerget Position2") );
	m_btnMove2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove2.SetBtnCursor(IDC_HAND_1);
	
	m_btnMoveInpos.SetFont( &m_fntBtn );
	m_btnMoveInpos.SetFlat( FALSE );
	m_btnMoveInpos.EnableBallonToolTip();
	m_btnMoveInpos.SetToolTipText( _T("XY Table Inposition Test") );
	m_btnMoveInpos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveInpos.SetBtnCursor(IDC_HAND_1);

	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop Tagerget Position") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	// Loader
	m_btnLoaderAlign.SetFont( &m_fntBtn );
	m_btnLoaderAlign.SetFlat( FALSE );
	m_btnLoaderAlign.EnableBallonToolTip();
	m_btnLoaderAlign.SetToolTipText( _T("Loader Align") );
	m_btnLoaderAlign.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlign.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderLoad.SetFont( &m_fntBtn );
	m_btnLoaderLoad.SetFlat( FALSE );
	m_btnLoaderLoad.EnableBallonToolTip();
	m_btnLoaderLoad.SetToolTipText( _T("Loader Load") );
	m_btnLoaderLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderLoad.SetBtnCursor(IDC_HAND_1);

	// Unloader
	m_btnUnloaderUnload.SetFont( &m_fntBtn );
	m_btnUnloaderUnload.SetFlat( FALSE );
	m_btnUnloaderUnload.EnableBallonToolTip();
	m_btnUnloaderUnload.SetToolTipText( _T("Unloader Unload") );
	m_btnUnloaderUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderUnload.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_RADIO_UNLOAD_M)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_UNLOAD_S)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_UNLOAD_MS)->SetFont( &m_fntBtn );

	// Table Suction
	m_chkMasterOn.SetFont( &m_fntBtn );
	m_chkMasterOn.SetImageOrg( 10, 3 );
	m_chkMasterOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkMasterOn.EnableBallonToolTip();
	m_chkMasterOn.SetToolTipText( _T("Master On") );
	m_chkMasterOn.SetBtnCursor(IDC_HAND_1);

	m_chkSlaveOn.SetFont( &m_fntBtn );
	m_chkSlaveOn.SetImageOrg( 10, 3 );
	m_chkSlaveOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSlaveOn.EnableBallonToolTip();
	m_chkSlaveOn.SetToolTipText( _T("Slave On") );
	m_chkSlaveOn.SetBtnCursor(IDC_HAND_1);

	// Vacuum Motor
	m_chkVacuumMotorOn.SetFont( &m_fntBtn );
	m_chkVacuumMotorOn.SetImageOrg( 10, 3 );
	m_chkVacuumMotorOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVacuumMotorOn.EnableBallonToolTip();
	m_chkVacuumMotorOn.SetToolTipText( _T("Vacuum Motor On") );
	m_chkVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	// Safety Mode
	m_chkSafetyOn.SetFont( &m_fntBtn );
	m_chkSafetyOn.SetImageOrg( 10, 3 );
	m_chkSafetyOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSafetyOn.EnableBallonToolTip();
	m_chkSafetyOn.SetToolTipText( _T("Safety Mode") );
	m_chkSafetyOn.SetBtnCursor(IDC_HAND_1);

	// Door Bypass
	m_chkDoorBypass.SetFont( &m_fntBtn );
	m_chkDoorBypass.SetImageOrg( 10, 3 );
	m_chkDoorBypass.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkDoorBypass.EnableBallonToolTip();
	m_chkDoorBypass.SetToolTipText( _T("Door Bypass") );
	m_chkDoorBypass.SetBtnCursor(IDC_HAND_1);

// 	// Table Clamp 1
// 	m_chkTableClamp1.SetFont( &m_fntBtn );
// 	m_chkTableClamp1.SetImageOrg( 10, 3 );
// 	m_chkTableClamp1.SetIcon( IDI_LEDON, IDI_LEDOFF );
// 	m_chkTableClamp1.EnableBallonToolTip();
// 	m_chkTableClamp1.SetBtnCursor(IDC_HAND_1);
// 
// 	// Table Clamp 2
// 	m_chkTableClamp2.SetFont( &m_fntBtn );
// 	m_chkTableClamp2.SetImageOrg( 10, 3 );
// 	m_chkTableClamp2.SetIcon( IDI_LEDON, IDI_LEDOFF );
// 	m_chkTableClamp2.EnableBallonToolTip();
// 	m_chkTableClamp2.SetToolTipText( _T("Right Table Clamp") );
// 	m_chkTableClamp2.SetBtnCursor(IDC_HAND_1);
// 
// 	if(gSystemINI.m_sHardWare.nTableClamp == 0)
// 	{
// 		m_chkTableClamp1.ShowWindow(SW_HIDE);
// 		m_chkTableClamp2.ShowWindow(SW_HIDE);
// 		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_HIDE);
// 	}
// 	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
// 	{
// 		m_chkTableClamp1.ShowWindow(SW_SHOW);
// 		m_chkTableClamp2.ShowWindow(SW_HIDE);
// 		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_SHOW);
// 	}
// 	else
// 	{
// 		m_chkTableClamp1.ShowWindow(SW_SHOW);
// 		m_chkTableClamp2.ShowWindow(SW_SHOW);
// 		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_SHOW);
// 	}

	// Loading / Unloading Position
	m_btnLoadingPos.SetFont( &m_fntBtn );
	m_btnLoadingPos.SetFlat( FALSE );
	m_btnLoadingPos.EnableBallonToolTip();
	m_btnLoadingPos.SetToolTipText( _T("Loading Position") );
	m_btnLoadingPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadingPos.SetFont( &m_fntBtn );
	m_btnUnloadingPos.SetFlat( FALSE );
	m_btnUnloadingPos.EnableBallonToolTip();
	m_btnUnloadingPos.SetToolTipText( _T("Unloading Position") );
	m_btnUnloadingPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadingPos.SetBtnCursor(IDC_HAND_1);

	// Homing
	m_btnMotorHoming.SetFont( &m_fntBtn );
	m_btnMotorHoming.SetFlat( FALSE );
	m_btnMotorHoming.EnableBallonToolTip();
	m_btnMotorHoming.SetToolTipText( _T("Motor Homing") );
	m_btnMotorHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMotorHoming.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderHoming.SetFont( &m_fntBtn );
	m_btnLoaderHoming.SetFlat( FALSE );
	m_btnLoaderHoming.EnableBallonToolTip();
	m_btnLoaderHoming.SetToolTipText( _T("Loader Homing") );
	m_btnLoaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderHoming.SetBtnCursor(IDC_HAND_1);

	m_btnUnloaderHoming.SetFont( &m_fntBtn );
	m_btnUnloaderHoming.SetFlat( FALSE );
	m_btnUnloaderHoming.EnableBallonToolTip();
	m_btnUnloaderHoming.SetToolTipText( _T("Unloader Homing") );
	m_btnUnloaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderHoming.SetBtnCursor(IDC_HAND_1);

	// MPG Mode
	m_btnMPG.SetFont( &m_fntBtn );
	m_btnMPG.SetFlat( FALSE );
	m_btnMPG.EnableBallonToolTip();
	m_btnMPG.SetToolTipText( _T("MPG Mode Select") );
	m_btnMPG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMPG.SetBtnCursor(IDC_HAND_1);

	// Reject
	m_btnReject.SetFont( &m_fntBtn );
	m_btnReject.SetFlat( FALSE );
	m_btnReject.EnableBallonToolTip();
	m_btnReject.SetToolTipText( _T("Table Reject") );
	m_btnReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReject.SetBtnCursor(IDC_HAND_1);
	
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		m_btnLoaderLoad.EnableWindow(FALSE);
		m_btnUnloaderUnload.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		m_btnMPG.EnableWindow(FALSE);
	}
}

void CPaneManualControlMotorKunsan1::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(160, "Arial Bold");

	// RepeatNo
	m_edtRep.SetFont( &m_fntEdit );
	m_edtRep.SetReceivedFlag( 1 );
	m_edtRep.SetWindowText( _T("0") );

	// Target X
	m_edtTargetX.SetFont( &m_fntEdit );
	m_edtTargetX.SetReceivedFlag( 3 );
	m_edtTargetX.SetWindowText( _T("0.0") );

	// Target Y
	m_edtTargetY.SetFont( &m_fntEdit );
	m_edtTargetY.SetReceivedFlag( 3 );
	m_edtTargetY.SetWindowText( _T("0.0") );

	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );

	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );

	// Target M
	m_edtTargetM.SetFont( &m_fntEdit );
	m_edtTargetM.SetReceivedFlag( 3 );
	m_edtTargetM.SetWindowText( _T("0.0") );

	// Target M2
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );

	// Target C
	m_edtTargetC.SetFont( &m_fntEdit );
	m_edtTargetC.SetReceivedFlag( 3 );
	m_edtTargetC.SetWindowText( _T("0.0") );

	m_edtTargetC2_1.SetFont( &m_fntEdit );
	m_edtTargetC2_1.SetReceivedFlag( 3 );
	m_edtTargetC2_1.SetWindowText( _T("0.0") );

	// Target X'2
	m_edtTargetX2.SetFont( &m_fntEdit );
	m_edtTargetX2.SetReceivedFlag( 3 );
	m_edtTargetX2.SetWindowText( _T("0.0") );
	
	// Target Y'2
	m_edtTargetY2.SetFont( &m_fntEdit );
	m_edtTargetY2.SetReceivedFlag( 3 );
	m_edtTargetY2.SetWindowText( _T("0.0") );
	
	// Target Z1'2
	m_edtTargetZ3.SetFont( &m_fntEdit );
	m_edtTargetZ3.SetReceivedFlag( 3 );
	m_edtTargetZ3.SetWindowText( _T("0.0") );
	
	// Target Z2'2
	m_edtTargetZ4.SetFont( &m_fntEdit );
	m_edtTargetZ4.SetReceivedFlag( 3 );
	m_edtTargetZ4.SetWindowText( _T("0.0") );
	
	// Target M'2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );

	// Target M2'2
	m_edtTargetM4.SetFont( &m_fntEdit );
	m_edtTargetM4.SetReceivedFlag( 3 );
	m_edtTargetM4.SetWindowText( _T("0.0") );
	
	// Target C'2
	m_edtTargetC2.SetFont( &m_fntEdit );
	m_edtTargetC2.SetReceivedFlag( 3 );
	m_edtTargetC2.SetWindowText( _T("0.0") );

	m_edtTargetC2_2.SetFont( &m_fntEdit );
	m_edtTargetC2_2.SetReceivedFlag( 3 );
	m_edtTargetC2_2.SetWindowText( _T("0.0") );
}

HBRUSH CPaneManualControlMotorKunsan1::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MOTOR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR_SPEED)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TARGET_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POS1_GROUP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POS2_GROUP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOADER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOADER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_SUCTION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VACUUM_MOTOR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_USE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MPG_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_REJECT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOADING_UNLOADING_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HOMING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SAFETY_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DOOR_BYPASS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlMotorKunsan1::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlMotorKunsan1::EnableAllBtn(BOOL bEnable)
{
	// Target Position
	GetDlgItem(IDC_CHECK_TARGET_X)->EnableWindow( bEnable );
	GetDlgItem(IDC_CHECK_TARGET_Y)->EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 0)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_MASK3)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow( bEnable );
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 1)
		GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bEnable );

	GetDlgItem(IDC_RADIO_ABS)->EnableWindow( bEnable );
	GetDlgItem(IDC_RADIO_INC)->EnableWindow( bEnable );
		
	m_btnMove.EnableWindow( bEnable );

	m_btnMove2.EnableWindow( bEnable );

	m_btnMoveInpos.EnableWindow( bEnable );

	m_btnStop.EnableWindow( bEnable );

	// Loader
	m_btnLoaderAlign.EnableWindow( bEnable );

	m_btnLoaderLoad.EnableWindow( bEnable );

	// Unloader
	m_btnUnloaderUnload.EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1)
	{
		GetDlgItem(IDC_RADIO_UNLOAD_M)->EnableWindow( bEnable );
		GetDlgItem(IDC_RADIO_UNLOAD_S)->EnableWindow( bEnable );
		GetDlgItem(IDC_RADIO_UNLOAD_MS)->EnableWindow( bEnable );
	}

	// Table Suction
	m_chkMasterOn.EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		m_chkSlaveOn.EnableWindow( bEnable );

	// Vacuum Motor
	m_chkVacuumMotorOn.EnableWindow( bEnable );

	// Safety Mode
	m_chkSafetyOn.EnableWindow( bEnable );

	// Door Bypass
//	m_chkDoorBypass.EnableWindow( bEnable );

	// TableClamp
// 	if(gSystemINI.m_sHardWare.nTableClamp > 0)
// 		m_chkTableClamp1.EnableWindow( bEnable );
// 	if(gSystemINI.m_sHardWare.nTableClamp > 1)
// 		m_chkTableClamp2.EnableWindow( bEnable );

	// Loading / Unloading Position
	m_btnLoadingPos.EnableWindow( bEnable );

	m_btnUnloadingPos.EnableWindow( bEnable );

	// Homing
	m_btnMotorHoming.EnableWindow( bEnable );

	m_btnLoaderHoming.EnableWindow( bEnable );

	m_btnUnloaderHoming.EnableWindow( bEnable );

	// MPG Mode
	m_btnMPG.EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);
	}

	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		m_btnLoaderLoad.EnableWindow(FALSE);
		m_btnUnloaderUnload.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		m_btnMPG.EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(bEnable);
	}
	
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}

void CPaneManualControlMotorKunsan1::OnButtonMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetC)
		return;

	EnableAllBtn( FALSE );
//	m_btnStop.EnableWindow( TRUE );

	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;

	// X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	// Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// Z1
	m_edtTargetZ1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );

	// Z2
	m_edtTargetZ2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );

	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2
//	m_edtTargetM3.GetWindowText( strData );
//	dTemp = atof( (LPSTR)(LPCTSTR)strData );
//	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // Mask --> Theta axis
		dPosM = dPosZ2;

	// C
	m_edtTargetC.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );

	// C2
//	m_edtTargetC2_1.GetWindowText( strData );
//	dTemp = atof( (LPSTR)(LPCTSTR)strData );
//	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC3 );

	
	//Dummyfree off 
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	
	// Move
//	BOOL bRet = pMotor->MoveXYZMC(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosC);
	BOOL bRet = pMotor->MoveXYZMC2A(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, 0, dPosC, 0, 0, 0, TRUE, FALSE, FALSE,TRUE);
	
	if(bRet)
	{	
		// Check InPosition
		bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
	}

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}

void CPaneManualControlMotorKunsan1::OnButtonMove2() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetC )
		return;
	
	EnableAllBtn( FALSE );
//	m_btnStop.EnableWindow( TRUE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X'2
	m_edtTargetX2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	
	// Y'2
	m_edtTargetY2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

/*	pMotor->SetOutPort((int)(dPosX + 0.01), (int)(dPosY + 0.01));

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
	return;
*/	
	// Z1'2
	m_edtTargetZ3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2'2
	m_edtTargetZ4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M'2
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M'2
//	m_edtTargetM4.GetWindowText( strData );
//	dTemp = atof( (LPSTR)(LPCTSTR)strData );
//	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // Mask --> Theta axis
		dPosM = dPosZ2;
	
	// C'2
	m_edtTargetC2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );


	// C'2-2
//	m_edtTargetC2_2.GetWindowText( strData );
//	dTemp = atof( (LPSTR)(LPCTSTR)strData );
//	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC3 );
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	BOOL bRet = TRUE;
	// Move
//	bRet = pMotor->MoveXYZMC(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosC);
	bRet = pMotor->MoveXYZMC2A(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, 0, dPosC, 0, 0, 0, TRUE, FALSE, FALSE,TRUE);
	
	if(bRet)
	{
		// Check InPosition
		bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
	}

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}


void CPaneManualControlMotorKunsan1::OnButtonMoveInpos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if( (!m_bTargetX && !m_bTargetY) || (m_bTargetX && m_bTargetY) )
	{
		ErrMessage(IDS_SELECT_XY);
		return;
	}

	EnableAllBtn( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;

	if(!bAbs)
		return;
	
	double dPosX, dPosX2, dPosY, dPosY2;

	// Start,End X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	m_edtTargetX2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX2 = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );
	
	// Start,End Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	m_edtTargetY2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY2 = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// StartPos
	BOOL bRet = pMotor->MoveXY(dPosX, dPosY, TRUE);
	if(bRet)
	{	
		bRet = pMotor->InPositionIO(IND_X + IND_Y);
	}

	// TimeCheck
	if(bRet)
	{
		m_edtRep.GetWindowText( strData );
		int nRep = atoi( (LPSTR)(LPCTSTR)strData );
		int nCnt = 0;
		double dWaitTime = 0.0;
		CCorrectTime MyTestTime;

		if(m_bTargetX)
		{
			MyTestTime.StartTime();

			do {
				if(nCnt%2)
					bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX, TRUE);
				else
					bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX2, TRUE);
				if(bRet)
				{	
					bRet = pMotor->InPositionIO(IND_X);
				}
				if(!bRet)
				{
					ErrMessage(_T("Axis-X Error"));
					break;
				}
				
				nCnt++;
			} while(nCnt < nRep);
		}
		else if(m_bTargetY)
		{
			MyTestTime.StartTime();
			
			do {
				if(nCnt%2)
					bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY, TRUE);
				else
					bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY2, TRUE);
				if(bRet)
				{	
					bRet = pMotor->InPositionIO(IND_Y);
				}
				if(!bRet)
				{
					ErrMessage(_T("Axis-Y Error"));
					break;
				}
				nCnt++;
			} while(nCnt < nRep);
		}

		dWaitTime = MyTestTime.PresentTime();
		strData.Format(_T(" Inposition time : %.3f "), dWaitTime );
		ErrMessage(strData);
	}
	
	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}

void CPaneManualControlMotorKunsan1::OnButtonStop() 
{
	EnableAllBtn(TRUE);
	m_bStop = TRUE;

	m_btnStop.EnableWindow( FALSE );
}

double CPaneManualControlMotorKunsan1::GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( FALSE == bUse )
	{
		return pMotor->GetPosition( nAxisNo);
			
	}

	double dPos = 0.;

	if( FALSE == bAbs ) // Relative Movement
	{
		dPos = dMovePos + pMotor->GetPosition( nAxisNo );
	}
	else // ABS Movement
		dPos = dMovePos;

	return dPos;
}

void CPaneManualControlMotorKunsan1::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dPos = 0;
	CString strData;

	// X
	dPos = pMotor->GetPosition( AXIS_X );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );

	// Y
	dPos = pMotor->GetPosition( AXIS_Y );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );

	// Z1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_Z1 );

	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );

	// Z2
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // theta
	{
		dPos = pMotor->GetPosition( AXIS_Z2 );
	}
	else
	{
		if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
			gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
			dPos = 0.0;
		else
			dPos = pMotor->GetPosition( AXIS_Z2 );
	}
		
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );

	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );

	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M2 );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM2.SetWindowText( (LPCTSTR)strData );

	// C
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // no use
	{
		strData.Format(_T("0.0"), dPos);
		m_stcPosC.SetWindowText( (LPCTSTR)strData );
	}
	else
	{
		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
			dPos = 0.0;
		else
			dPos = pMotor->GetPosition( AXIS_C );
		
		strData.Format(_T("%.3f"), dPos);
		m_stcPosC.SetWindowText( (LPCTSTR)strData );

		dPos = pMotor->GetPosition( AXIS_C2 );
		strData.Format(_T("%.3f"), dPos);
		m_stcPosC3.SetWindowText( (LPCTSTR)strData );
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{
		int nSuction = pMotor->GetCurrentSuction();
		
		if(nSuction & 0x01)
			m_bMasterSuction = TRUE;
		else
			m_bMasterSuction = FALSE;

		m_chkMasterOn.SetCheck(m_bMasterSuction);

		if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() != 0)
		{
			if(nSuction & 0x02)
				m_bSlaveSuction = TRUE;
			else
				m_bSlaveSuction = FALSE;

			m_chkSlaveOn.SetCheck(m_bSlaveSuction);
		}
#ifndef __MP920_MOTOR__
		m_bVacuumMotor = pMotor->GetCurrentVacuumMotor(TRUE) & pMotor->GetCurrentVacuumMotor(FALSE);
#endif
		m_chkVacuumMotorOn.SetCheck(m_bVacuumMotor);

		m_bSafetyMode = pMotor->IsSafetyMode();
		m_chkSafetyOn.SetCheck(m_bSafetyMode);

//		m_bDoorBypass = pMotor->IsSystemDoorBypass();
//		m_chkDoorBypass.SetCheck(m_bDoorBypass);

		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			m_bTableClamp1 = pMotor->GetCurrentTableClamp(TRUE, TRUE);
			m_chkTableClamp1.SetCheck(m_bTableClamp1);
		}

		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			m_bTableClamp2 = pMotor->GetCurrentTableClamp(FALSE, TRUE);
			m_chkTableClamp2.SetCheck(m_bTableClamp2);
		}
	}
}

void CPaneManualControlMotorKunsan1::DispVelocity()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dSpeed = 0;
	CString strData = _T("");

	// X
	dSpeed = pMotor->GetMoveSpeed( AXIS_X );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedX.SetWindowText( (LPCTSTR)strData );

	// Y
	dSpeed = pMotor->GetMoveSpeed( AXIS_Y );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedY.SetWindowText( (LPCTSTR)strData );

	// Z1
	dSpeed = pMotor->GetMoveSpeed( AXIS_Z1 );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedZ1.SetWindowText( (LPCTSTR)strData );

	// Z2
	dSpeed = pMotor->GetMoveSpeed( AXIS_Z2 );

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedZ2.SetWindowText( (LPCTSTR)strData );

	// M
	dSpeed = pMotor->GetMoveSpeed( AXIS_M );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM.SetWindowText( (LPCTSTR)strData );

	// M2
	dSpeed = pMotor->GetMoveSpeed( AXIS_M2 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM2.SetWindowText( (LPCTSTR)strData );

	// C
	dSpeed = pMotor->GetMoveSpeed( AXIS_C );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedC.SetWindowText( (LPCTSTR)strData );
}

void CPaneManualControlMotorKunsan1::OnTimer(UINT nIDEvent) 
{
	DispStatus();

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlMotorKunsan1::OnButtonLoaderAlign() 
{
	UpdateData(TRUE);

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	int nCmd;
	if(m_nMasterSlave < 2)
		nCmd = m_nMasterSlave + 1;
	else
		nCmd = 0;

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
//	pMotor->InPositionIO(IND_X + IND_Y);
	pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, TRUE);
}

void CPaneManualControlMotorKunsan1::OnButtonLoaderLoad() 
{
/*	int nNo = 10;
	CCorrectTime mytime;
	mytime.StartTime();
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();

	for(int i = 0; i < nNo; i++)
	{
		BOOL bRet = pMotor->MoveXY(50, 50);

		if(bRet)
		{	
			bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
		}
		bRet = pMotor->MoveXY(100, 100);
		if(bRet)
		{	
			bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
		}
	}
	double dTime = mytime.PresentTime();
	CString str;
	str.Format(_T(" time %.3f "), dTime / nNo / 2.0);
	ErrMessage(str);
*/

	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	m_bStop = FALSE;
	m_btnStop.EnableWindow( TRUE );
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);


	int nCmd;
	if(m_nMasterSlave < 2)
		nCmd = m_nMasterSlave + 1;
	else
		nCmd = 0;	

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

	pMotor->HandlerOperation(HANDLER_LOADER_LOAD);
//	pMotor->InPositionIO(IND_X + IND_Y);
	pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, TRUE, TRUE );
}

void CPaneManualControlMotorKunsan1::SetTableSuction()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( FALSE == m_bMasterSuction && FALSE == m_bSlaveSuction )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 0 );
	else if( TRUE == m_bMasterSuction && FALSE == m_bSlaveSuction )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 1 );
	else if( FALSE == m_bMasterSuction && TRUE == m_bSlaveSuction )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 2 );
	else // TRUE, TRUE
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 3 );
}

void CPaneManualControlMotorKunsan1::OnCheckMasterOn() 
{
	m_bMasterSuction = !m_bMasterSuction;

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 1);
		m_chkMasterOn.SetCheck(0);
	}
	else
		SetTableSuction();
}

void CPaneManualControlMotorKunsan1::OnCheckSlaveOn() 
{
	m_bSlaveSuction = !m_bSlaveSuction;

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 0);
		m_chkSlaveOn.SetCheck(0);
	}
	else
		SetTableSuction();
}

void CPaneManualControlMotorKunsan1::OnCheckVacuumMotorOn()
{
	m_bVacuumMotor = !m_bVacuumMotor;
#ifndef __MP920_MOTOR__	
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	pMotor->Table1VacuumMotor(m_bVacuumMotor);
#endif
}

void CPaneManualControlMotorKunsan1::OnCheckSafetyOn()
{
	m_bSafetyMode = !m_bSafetyMode;

	int nMode;
	if(m_bSafetyMode)
	{
		nMode = 4;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 1);
	}
	else
	{
		nMode = 1;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 0);
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->SetOutPort(PORT_MODE_SELECT, nMode);
}

void CPaneManualControlMotorKunsan1::OnCheckTableClamp1()
{
	m_bTableClamp1 = !m_bTableClamp1;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->TableClamp(m_bTableClamp1, TRUE);
}

void CPaneManualControlMotorKunsan1::OnCheckTableClamp2()
{
	m_bTableClamp2 = !m_bTableClamp2;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->TableClamp(m_bTableClamp2, FALSE);
}

void CPaneManualControlMotorKunsan1::OnCheckDoorBypass()
{
	m_bDoorBypass = !m_bDoorBypass;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, m_bDoorBypass);
}

void CPaneManualControlMotorKunsan1::OnButtonPosLoading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);
//	pMotor->TableLoadPos();
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}

void CPaneManualControlMotorKunsan1::OnButtonPosUnloading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);
//	pMotor->TableUnloadPos();
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}

void CPaneManualControlMotorKunsan1::OnButtonUnloaderUnload() 
{
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	m_bStop = FALSE;
	m_btnStop.EnableWindow( TRUE );
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);


	int nCmd;
	if(m_nMasterSlave < 2)
		nCmd = m_nMasterSlave + 1;
	else
		nCmd = 0;

	pMotor->SetOutPort( PORT_TABLE_SUCTION, 0);
	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD);
//	pMotor->InPositionIO(IND_X + IND_Y);
	pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, TRUE, TRUE );
}

void CPaneManualControlMotorKunsan1::OnButtonMotorHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	pMotor->SetOrigin();

	BOOL bInOrigin = FALSE;
	BOOL bInPosition = FALSE;

	for( int i = 0 ; i < 600 ; i++ )
	{
#ifndef __NOUSE_MP920__
		::Sleep(100);
#endif

		bInOrigin = pMotor->IsInOrigin( -1, FALSE );
//		bInPosition = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);

		if( bInOrigin ) // && bInPosition )
			break;

		if( 599 == i )
		{
			pMotor->IsInOrigin(-1);
//			pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
		}
	}
}

void CPaneManualControlMotorKunsan1::OnButtonLoaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	pMotor->HandlerOperation(HANDLER_LOADER_HOMING);
}

void CPaneManualControlMotorKunsan1::OnButtonUnloaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	pMotor->HandlerOperation(HANDLER_UNLOADER_HOMING);
}

void CPaneManualControlMotorKunsan1::InitTimer()
{
	if(m_nTimerID == 0)
		m_nTimerID = SetTimer( 38, 300, NULL );
}

void CPaneManualControlMotorKunsan1::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneManualControlMotorKunsan1::OnButtonReject()
{
	gDeviceFactory.GetMotor()->TablePCBReset();
}

void CPaneManualControlMotorKunsan1::OnButtonMPG()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
	}
	else
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
	}
	
	pMotor->SetOutPort(PORT_MPG_MODE, m_nMPGMode);
}

void CPaneManualControlMotorKunsan1::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
		m_chkSafetyOn.EnableWindow(FALSE);
//		m_chkDoorBypass.EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_REPEAT)->ShowWindow(SW_HIDE);
		m_edtRep.ShowWindow(SW_HIDE);
		m_btnMoveInpos.ShowWindow(SW_HIDE);
		break;
	case 1:
	case 2:
	case 3:
		m_chkSafetyOn.EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_REPEAT)->ShowWindow(SW_SHOW);
		m_edtRep.ShowWindow(SW_SHOW);
		m_btnMoveInpos.ShowWindow(SW_SHOW);
//		m_chkDoorBypass.EnableWindow(TRUE);
		break;
	}
}

BOOL CPaneManualControlMotorKunsan1::WaitHandler(int nCmd)
{
#ifdef __TEST__
	return TRUE;
#endif
	int nWaitTime;
	if(nCmd == HANDLER_ALIGNERSTOP)
		nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000 / 200; 
	else if(nCmd == HANDLER_LOADSTOP || nCmd == HANDLER_LOAD_PICKER_DOWN)
		nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 200; 
	else
		nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000 / 200; 
	int nCnt = 0;
	do {
		::Sleep(200);
		MessageLoop();
		if(m_bStop)
			return FALSE;
		
		enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
			HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM};		
		
		switch(nCmd)
		{
		case HANDLER_READY:
			if(gDeviceFactory.GetMotor()->IsHandlerReady())
				return TRUE;
			break;
		case HANDLER_ALARM:
			if(gDeviceFactory.GetMotor()->IsHandlerAlarm())
				return TRUE;
			break;
		case HANDLER_LOTEND:
			if(gDeviceFactory.GetMotor()->IsHandlerLotEnd())
				return TRUE;
			break;
		case HANDLER_1STEXIST:
			if(gDeviceFactory.GetMotor()->IsHandler1stTableExist())
				return TRUE;
			break;
		case HANDLER_2NDEXIST:
			if(gDeviceFactory.GetMotor()->IsHandler2ndTableExist())
				return TRUE;
			break;
		case HANDLER_LOADREADY:
			if(gDeviceFactory.GetMotor()->IsHandlerLoadReady())
				return TRUE;
			break;
		case HANDLER_LOADEND:
			if(gDeviceFactory.GetMotor()->IsHandlerLoadEnd())
				return TRUE;
			break;
		case HANDLER_LOADALARM:
			if(gDeviceFactory.GetMotor()->IsHandlerLoadAlarm())
				return TRUE;
			break;
		case HANDLER_UNLOADREADY:
			if(gDeviceFactory.GetMotor()->IsHandlerUnloadReady())
				return TRUE;
			break;
		case HANDLER_UNLOADEND:
			if(gDeviceFactory.GetMotor()->IsHandlerUnloadEnd())
				return TRUE;
			break;
		case HANDLER_UNLOADALARM:
			if(gDeviceFactory.GetMotor()->IsHandlerUnloadAlarm())
				return TRUE;
			break;
		}
		nCnt++;
		
		if(nCnt > nWaitTime)
		{
			return FALSE;
		}
	} while(TRUE);
	return FALSE;
}

void CPaneManualControlMotorKunsan1::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}

int CPaneManualControlMotorKunsan1::GetMPGMode()
{
	return m_nMPGMode;
}

void CPaneManualControlMotorKunsan1::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}


BOOL CPaneManualControlMotorKunsan1::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Motor) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
