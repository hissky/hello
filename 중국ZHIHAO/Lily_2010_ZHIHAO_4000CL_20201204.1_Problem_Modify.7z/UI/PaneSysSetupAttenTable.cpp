// UI\PaneSysSetupAttenTable.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "..\EasyDrillerDlg.h"
#include "PaneSysSetupAttenTable.h"

#include "..\MODEL\DBeampathINI.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\HLaser.h"
#include "..\DEVICE\DeviceMotor.h"
#include "..\MODEL\DProcessINI.h"
#include "..\MODEL\DSystemINI.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\MODEL\DPowerAttenCompensation.h"
#include "..\DEVICE\HMotor.h"
#include "..\alarmmsg.h"

// CPaneSysSetupAttenTable

IMPLEMENT_DYNCREATE(CPaneSysSetupAttenTable, CFormView)

UINT MakeAttenTableThread(LPVOID pParam)
{
	CPaneSysSetupAttenTable* pRun = (CPaneSysSetupAttenTable*)pParam;
	
	pRun->MakeAttenTableProcess();
	pRun->m_bStop = TRUE;
	//add stop process 
	return TRUE;
}

CPaneSysSetupAttenTable::CPaneSysSetupAttenTable()
	: CFormView(CPaneSysSetupAttenTable::IDD)
{
	m_nBeamPath = -1;
	m_dStartPos = 0;
	m_dEndPos = 0;
	m_dStep = 0;
	m_nRepeatCount = 0;
	memset(	m_nAttPos, 0, sizeof(m_nAttPos));
	memset(m_dResult, 0, sizeof(m_dResult));
	m_pRunThread = NULL;
}

CPaneSysSetupAttenTable::~CPaneSysSetupAttenTable()
{
	if(m_pRunThread)
	{
		WaitForSingleObject(m_pRunThread->m_hThread, INFINITE);
		m_pRunThread = NULL;
	}
}

void CPaneSysSetupAttenTable::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_COMBO_HEAD, m_cmbHead);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cmbBeamPath);
	DDX_Control(pDX, IDC_EDIT_END, m_edtEnd);
	DDX_Control(pDX, IDC_EDIT_START, m_edtStart);
	DDX_Control(pDX, IDC_EDIT_STEP, m_edtStep);
	DDX_Control(pDX, IDC_LIST_RESULT, m_ListResult);
}

BEGIN_MESSAGE_MAP(CPaneSysSetupAttenTable, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_START, &CPaneSysSetupAttenTable::OnBnClickedButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CPaneSysSetupAttenTable::OnBnClickedButtonStop)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CPaneSysSetupAttenTable �����Դϴ�.

#ifdef _DEBUG
void CPaneSysSetupAttenTable::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPaneSysSetupAttenTable::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPaneSysSetupAttenTable �޽��� ó�����Դϴ�.

void CPaneSysSetupAttenTable::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
		
	InitEditControl();
	InitBtnControl();
	InitStaticControl();
	InitCmbControl();
	InitListControl();

	m_btnStop.EnableWindow(FALSE);
}


void CPaneSysSetupAttenTable::OnBnClickedButtonStart()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CString str;

	m_bStop = FALSE;
	m_nErrID = 0;
	m_nHead = m_cmbHead.GetCurSel();
	m_nBeamPath = m_cmbBeamPath.GetCurSel();
	m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	m_edtStart.GetWindowText(str);
	m_dStartPos = atof(str);

	m_edtEnd.GetWindowText(str);
	m_dEndPos = atof(str);

	m_edtStep.GetWindowText(str);
	m_dStep = atof(str);
	
	m_ListResult.DeleteAllItems();

	m_nRepeatCount = (m_dEndPos - m_dStartPos) / m_dStep + 1;
	if(!gDeviceFactory.GetLaser()->IsPowerOn()	|| !gDeviceFactory.GetLaser()->IsShutterOpen() ||
		!gDeviceFactory.GetMotor()->GetAOMStatus()	|| !gDeviceFactory.GetMotor()->GetScannerStatus() ) // LaserPower
	{

		ErrMsgDlg(STDGNALM303);
		return ;
	}

	if(gProcessINI.m_sProcessSystem.bDryRun)
	{
		ErrMessage(_T("Dryrun Mode. Please turn off this mode."));
		return;
	}

	
	if(m_pRunThread == NULL)
	{
		m_pRunThread = ::AfxBeginThread(MakeAttenTableThread, this, THREAD_PRIORITY_NORMAL);
	}
	else
	{
		CString str;
		str.Format(_T("Fail to make thread"));
		ErrMessage(str);
		if(m_pRunThread)
		{
			WaitForSingleObject(m_pRunThread->m_hThread, INFINITE);
			m_pRunThread = NULL;
		}
		return;
	}
	EnableAllButton(FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
//	if(m_pRunThread)
//	{
//		WaitForSingleObject(m_pRunThread->m_hThread, INFINITE);
//		m_pRunThread = NULL;
//	}
}

void	CPaneSysSetupAttenTable::EnableAllButton(BOOL bEnable)
{
	m_btnStart.EnableWindow(bEnable);
	m_btnStop.EnableWindow(!bEnable);
	if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_DUAL)
		m_cmbHead.EnableWindow(bEnable);
	else
		m_cmbHead.EnableWindow(FALSE);

	m_cmbBeamPath.EnableWindow(bEnable);
	m_edtEnd.EnableWindow(bEnable);
	m_edtStart.EnableWindow(bEnable);
	m_edtStep.EnableWindow(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}


void CPaneSysSetupAttenTable::OnBnClickedButtonStop()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_bStop = TRUE;
//	if(m_pRunThread)
//	{
//		WaitForSingleObject(m_pRunThread->m_hThread, INFINITE);
		m_pRunThread = NULL;
//	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
}

void CPaneSysSetupAttenTable::OnDestroy()
{
	CFormView::OnDestroy();
	m_bStop = TRUE;
	m_pRunThread = NULL;
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}


HBRUSH CPaneSysSetupAttenTable::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_RESULT)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_SETTING)->GetSafeHwnd() == pWnd->m_hWnd  )
			pDC->SetTextColor( RGB(0, 0, 255 ) );
	}
	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}

void CPaneSysSetupAttenTable::InitEditControl()
{
	m_fntEdit.CreatePointFont( 120,  _T("Arial Bold"));

	m_edtStart.SetFont( &m_fntEdit );
	m_edtStart.SetForeColor( BLACK_COLOR );
	m_edtStart.SetBackColor( WHITE_COLOR );
	m_edtStart.SetReceivedFlag( 3 );
	m_edtStart.SetWindowText( _T("0") );

	m_edtEnd.SetFont( &m_fntEdit );
	m_edtEnd.SetForeColor( BLACK_COLOR );
	m_edtEnd.SetBackColor( WHITE_COLOR );
	m_edtEnd.SetReceivedFlag( 3 );
	m_edtEnd.SetWindowText( _T("900") );

	m_edtStep.SetFont( &m_fntEdit );
	m_edtStep.SetForeColor( BLACK_COLOR );
	m_edtStep.SetBackColor( WHITE_COLOR );
	m_edtStep.SetReceivedFlag( 3 );
	m_edtStep.SetWindowText( _T("30") );

}
void CPaneSysSetupAttenTable::InitBtnControl()
{
	m_fntBtn.CreatePointFont( 120,  _T("Arial Bold"));
	
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Start Getting Att Table ") );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.SetBtnCursor(IDC_HAND_1);

	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop Getting Att Table ") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

}
void CPaneSysSetupAttenTable::InitStaticControl()
{
	m_fntStatic.CreatePointFont( 120,  _T("Arial Bold"));

	GetDlgItem(IDC_STATIC_RESULT)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_SETTING)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_STEP)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_START)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_END)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_BEAMPATH)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_HEAD)->SetFont( &m_fntStatic);

}
void CPaneSysSetupAttenTable::InitListControl()
{
	m_fntList.CreatePointFont( 100,  _T("Arial Bold"));

	m_ListResult.SetFont( &m_fntList );
	m_ListResult.SetExtendedStyle(m_ListResult.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	m_ListResult.DeleteAllItems();
	if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_DUAL)
	{
		m_ListResult.InsertColumn(0, _T(" Att. Pos "), LVCFMT_CENTER, 150);
		m_ListResult.InsertColumn(1, _T(" Result 1ST "), LVCFMT_CENTER, 120);
		m_ListResult.InsertColumn(2, _T(" Result 2ND"), LVCFMT_CENTER, 120);
	}
	else
	{
		m_ListResult.InsertColumn(0, _T(" Att. Pos "), LVCFMT_CENTER, 150);
		m_ListResult.InsertColumn(1, _T(" Result "), LVCFMT_CENTER, 120);
	}
}
void CPaneSysSetupAttenTable::InitCmbControl()
{
	m_fntCombo.CreatePointFont( 120,  _T("Arial Bold"));

	m_cmbBeamPath.SetFont( &m_fntCombo );
	SetToolComboBox();
	m_cmbBeamPath.SetCurSel( 0 );

	m_cmbHead.SetFont( &m_fntCombo );


	if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_DUAL)
	{
		m_cmbHead.SetCurSel( 0 );
		m_cmbHead.EnableWindow(TRUE);
	}
	else if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_1ST)
	{
		m_cmbHead.SetCurSel( 0 );
		m_cmbHead.EnableWindow(FALSE);
	}
	else if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_2ND)
	{
		m_cmbHead.SetCurSel( 1 );
		m_cmbHead.EnableWindow(FALSE);
	}
	else
	{
		m_cmbHead.SetCurSel( 0 );
		m_cmbHead.EnableWindow(FALSE);
	}

}

BOOL CPaneSysSetupAttenTable::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	CFormView::PreCreateWindow(cs);
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	return TRUE;
}

BOOL CPaneSysSetupAttenTable::MakeAttenTableProcess(void)
{
	CString strLog;
	strLog.Format(_T(" --- Make Atten. Table Start ---"));
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	BOOL bResult =MakeAttenTable();
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
	EnableAllButton(TRUE);
	m_pRunThread = NULL;
	if(!bResult)
	{
//		strLog.Format(_T(" --- Make Atten. Table Fail ---"));
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
		return FALSE;
	}

//	strLog.Format(_T(" --- Make Atten. Table End ---"));
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	return 0;
}
BOOL CPaneSysSetupAttenTable::MakeAttenTable()
{
	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
		
#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, TRUE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif

	gDeviceFactory.GetPwrAttenCompen()->SetCount(m_nRepeatCount, m_dStep, m_dStartPos);

	FParameter fPara;
	SUBTOOLDATA ToolData;

	for(int p = 0; p < m_nRepeatCount; p++)
	{
		if(!ChangeBeamPath(m_nHead, p))
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_nErrID = STDGNALM600;
			return FALSE;
		}

		GetBeamPathLaserInfo(ToolData);

		if(!UpdateNewParam())
		{	
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_nErrID = STDGNALM445;
			return FALSE;
		}

		double dX, dY, dZ1, dZ2;
		if(m_nHead  == 0)
		{
			dX = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x;
			dY = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y;
		}
		else
		{
			dX = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x;
			dY = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y;
		}
		dZ1  = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
		dZ2  = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;

		int nCount = 0;
		double dMeasureResult = 0;
		CString strEvent, strInfo;
		double dVal = 0;


		if(CheckStatus())
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			return FALSE;
		}

		if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, TRUE, SHOT_MOVE, TRUE))
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_nErrID = STDGNALM438;
			return FALSE;
		}

		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			if(m_nHead) // use_2nd
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
				{

#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					m_nErrID = STDGNALM417;
					return FALSE;
				}
			}
			else
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
				{

#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					m_nErrID = STDGNALM417;
					return FALSE;
				}
			}
		}

		if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{

			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis, TRUE);
			return FALSE;
		}

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				m_nErrID = STDGNALM781;
				return FALSE;
			}
		}
		else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!gDeviceFactory.GetEocard()->EndMarkDummy())
			{
				m_nErrID = STDGNALM445; 
				return FALSE;
			}
		}

		gDeviceFactory.GetEocard()->jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);

		//measure
		pEOCard->LaserOnOff(TRUE);
		nCount = 0;
		while(nCount < 20) // 2 sec
		{
			if(CheckStatus())
			{
				pEOCard->LaserOnOff(FALSE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
				{
					if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
					{
						if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
						{
							m_nErrID = STDGNALM781;
							return FALSE;
						}
					}
				}
				else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
				{
					if(!gDeviceFactory.GetEocard()->StartMarkDummy())
					{
						m_nErrID = STDGNALM445;
						return FALSE;
					}
				}
				return FALSE;
			}
			::Sleep(100);
//			MessageLoop();
			nCount++;
		}

		dMeasureResult = 0;
		double dTemp[6];
		memset( dTemp, 0, sizeof(dTemp));
		for(int i = 0; i < 6; i++)
		{
			nCount = 0;
			while(nCount < 15) // 2.5 sec
			{
				if(CheckStatus())
				{
					pEOCard->LaserOnOff(FALSE);
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
					{
						if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
						{
							if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
							{
								m_nErrID  = STDGNALM781;
								return FALSE;
							}
						}
					}
					else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!gDeviceFactory.GetEocard()->StartMarkDummy())
						{
							m_nErrID = STDGNALM445;
							return FALSE;
						}
					}
					return FALSE;
				}
				::Sleep(100);
//				MessageLoop();
				nCount++;
			}
			dTemp[i] = ((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_POWER_MEASURE, 0, 0);
			dTemp[i] /= 1000.;

			if(dTemp[i] <= 0.0)
			{
				pEOCard->LaserOnOff(FALSE);
				CString strMsg = _T("");
				strMsg.Format(_T("Laser power = %.3f.\nCheck laser power measuring position or port setting"), dTemp[i]);
				ErrMessage(strMsg);

#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				m_nErrID = STDGNALM707;
				return FALSE;
			}
		}
		pEOCard->LaserOnOff(FALSE);
		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun()  && m_bUserDummyOn)
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
				{
					m_nErrID = STDGNALM781;
					return FALSE;
				}
			}
		}
		else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!gDeviceFactory.GetEocard()->StartMarkDummy())
			{
				m_nErrID = STDGNALM445;
				return FALSE;
			}
		}
		double dMin1 = 99999;
		int nMinIndex = -1;
		for(int k = 0; k < 6; k++)
		{
			if(dMin1 >= dTemp[k])
			{
				dMin1 = dTemp[k];
				nMinIndex = k;
			}
		}
		for(int k = 0; k < 6; k++)
		{
			if(k != nMinIndex)
				dMeasureResult += dTemp[k];
		}

		dMeasureResult = dMeasureResult/5; 
		m_dResult[m_nHead][p] =dMeasureResult; 
		gDeviceFactory.GetPwrAttenCompen()->SetRawData(dMeasureResult);
		InsertResult(p);
		::Sleep(1000);
#ifdef __TEST__
		dMeasureResult = 5.52;
#endif
		if(dMeasureResult >= gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[m_nBeamPath] &&
			dMeasureResult <= gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[m_nBeamPath])
		{
			bResult &= TRUE;
		}


		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
		{

#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_nErrID = STDGNALM417; // shutter sensor error
			return FALSE;
		}
	}

	if(m_nHead == 1)
		gDeviceFactory.GetPwrAttenCompen()->MakeTable(FALSE);
	else
		gDeviceFactory.GetPwrAttenCompen()->MakeTable(TRUE);

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif

		return TRUE;
}


BOOL CPaneSysSetupAttenTable::ChangeBeamPath(BOOL bHead, int nRepeat)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dC1, dC2, dA1, dA2, dM1, dM2, dM3, dZ1, dZ2; 
	CString strVal;
	BOOL bTophat;

	dZ1 = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
	dZ2 = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
	
	
	BOOL bLaserPath; 
	
	bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nBeamPath];
	bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[m_nBeamPath];

	dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[m_nBeamPath];
	dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[m_nBeamPath];

	dA1 = m_dStartPos;
	dA2 = m_dStartPos;

	if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode == USE_ATTEN_DUAL)
	{
		if(bHead == 0 )
			dA1 += nRepeat * m_dStep;
		else
			dA2 += nRepeat * m_dStep;
	}
	else
		dA1 += nRepeat * m_dStep;

	m_nAttPos[nRepeat] =(int)dA1; 

	dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_nBeamPath];
	dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_nBeamPath];
	dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_nBeamPath];	

	
	if(!pMotor->MoveTophatShutter(bTophat))
		return FALSE;

	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrID = STDGNALM974;
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
	
#ifndef __SERVO_MOTOR__
		if(!pMotor->MoveZMCA2(	dZ1, dZ2, dM1, dM2, dC1, dC2, dA1, dA2, TRUE, bTophat))
#else 
		if(!pMotor->MoveZMCA3(	dZ1, dZ2, dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, bTophat))
#endif
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			return FALSE;
		}
	}
	else // not use M, C
	{
		if(!pMotor->MoveZMC2(dZ1, dZ2, dA1, dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
			return FALSE;
		}
	}

	if(!pMotor->InPositionIO(IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
		return FALSE;
	}

	return TRUE;
}

void CPaneSysSetupAttenTable::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : m_nErrID = STDGNALM404; break;
	case IND_Y : m_nErrID = STDGNALM405; break;
	case IND_Z1 : m_nErrID = STDGNALM406; break;
	case IND_Z2 : m_nErrID = STDGNALM407; break;
	case IND_M1 : m_nErrID = STDGNALM408; break;
	case IND_M2 : m_nErrID = STDGNALM409; break;
	case IND_M3 : m_nErrID = STDGNALM990; break;
	case IND_C1 : m_nErrID = STDGNALM410; break;
	case IND_C2 : m_nErrID = STDGNALM411; break;
	}

	if(bShow)
		ErrMsgDlg(m_nErrID);
}

void CPaneSysSetupAttenTable::GetBeamPathLaserInfo(SUBTOOLDATA &subTool)
{
	subTool.nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath];
	subTool.dShotDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[m_nBeamPath];
	subTool.dShotAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath];
	subTool.dShotAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath];

	subTool.dMinPower = gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[m_nBeamPath];
	subTool.dMaxPower = gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[m_nBeamPath];
}

BOOL CPaneSysSetupAttenTable::UpdateNewParam()
{
	ASSERT(gDeviceFactory.GetEocard() != NULL);
	FParameter  fParameter;
	gDeviceFactory.GetEocard()->GetParameter(&fParameter);

	CString strData;
	fParameter.Frequency =  gBeamPathINI.m_sBeampath.nPowCompensationFrequency[m_nBeamPath];
	double dCurrent, dAOMDelay, dAOMDuty;
	int nThermalTrack;

	double dMaskDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowOffsetDuty[m_nBeamPath];
	double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[m_nBeamPath];
	double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[m_nBeamPath];
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[m_nBeamPath];
	double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[m_nBeamPath];
	double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[m_nBeamPath];
	BOOL bRet = gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2);
	if(!bRet)
	{
		m_nErrID = STDGNALM117;
		return bRet;
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		fParameter.dDuty = 5000; // 50%
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;
		nThermalTrack = gProcessINI.m_sProcessPowerMeasure.nThermalTrack;		
		gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, fParameter.Frequency, nThermalTrack);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;		
		fParameter.dDuty = 5000; // 50%
	}
	else
	{
		fParameter.dDuty = static_cast<unsigned short>(gBeamPathINI.m_sBeampath.dPowCompensationDuty[m_nBeamPath] * 100 + 0.5);
		fParameter.dDuty += (dMaskDutyOffset) * 100 + dPowerDutyOffset * 100;

		dAOMDelay = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[m_nBeamPath];//subTool.dShotAOMDelay[0];
		dAOMDuty = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[m_nBeamPath];//subTool.dShotAOMDuty[0];
		fParameter.dAOMDelay = dAOMDelay + dMaskAOMDelayOffset;
		fParameter.dAOMDuty = dAOMDuty + dMaskAOMDutyOffset + dPowerDutyOffset;
	}

	return bRet && gDeviceFactory.GetEocard()->SetParameter(&fParameter, (dMaskAOMDutyOffset + dPowerDutyOffset),m_nBeamPath);

}
BOOL CPaneSysSetupAttenTable::CheckStatus()
{
	return m_bStop;
}

void CPaneSysSetupAttenTable::InsertResult( int nRepeatCount)
{
	int nIndex = m_ListResult.GetItemCount();

	m_ListResult.InsertItem(nIndex, _T(""));
	CString strPos, strResult;
	strPos.Format(_T("%d"),m_nAttPos[nRepeatCount]);
	m_ListResult.SetItemText(nIndex, 0, strPos);

	strResult.Format(_T("%.2f"),m_dResult[m_nHead][nRepeatCount]);
	m_ListResult.SetItemText(nIndex, 1, strResult);

}

void CPaneSysSetupAttenTable::SetToolComboBox()
{
	m_cmbBeamPath.ResetContent();
	
	CString strTool;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbBeamPath.AddString(strTool);
	}
	m_cmbBeamPath.SetCurSel( 0 );
}
