#if !defined(AFX_DLGINPUTTOTALLOT_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
#define AFX_DLGINPUTTOTALLOT_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

// CDlgInputTotalLot ��ȭ �����Դϴ�.

class CDlgInputTotalLot : public CDialog
{

public:
	CDlgInputTotalLot(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.

	void		InitControl();
	void		SetInputLot(int nLot)	{ m_nInputLot = nLot; }
	int			GetInputLot()			{ return m_nInputLot; }
	void		SetStartNo(int nStartNo)	{ m_nStartNo = nStartNo; }
	int			GetStartNo()			{ return m_nStartNo; }

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_INPUT_TOTAL_LOT };

	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnCancel;
	CColorEdit	m_edtStartNo;
	CColorEdit	m_edtInputLot;
public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

protected:

	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	int				m_nInputLot;
	int				m_nStartNo;

	// Generated message map functions
	//{{AFX_MSG(CDlgInputTotalLot)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP();

};
#endif