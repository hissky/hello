// D:\Source\2010_ver\Lily_2010\UI\DlgNGInfo.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "..\UI\DlgNGInfo.h"
#include "afxdialogex.h"


// CDlgNGInfo ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgNGInfo, CDialog)

CDlgNGInfo::CDlgNGInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNGInfo::IDD, pParent)
{
	m_bMasterNG = FALSE;
	m_bSlaveNG = FALSE;
}

CDlgNGInfo::~CDlgNGInfo()
{
}

void CDlgNGInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK_MASTER, m_chkMasterNG);
	DDX_Control(pDX, IDC_CHECK_SLAVE, m_chkSlaveNG);
}


BEGIN_MESSAGE_MAP(CDlgNGInfo, CDialog)
END_MESSAGE_MAP()


// CDlgNGInfo �޽��� ó�����Դϴ�.


BOOL CDlgNGInfo::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	m_fntBtn.CreatePointFont(120, "Arial Bold");

	GetDlgItem(IDC_STATIC_MESSAGE)->SetFont(&m_fntBtn);

	m_chkMasterNG.SetFont( &m_fntBtn );
	m_chkMasterNG.SetImageOrg( 10, 3 );
	m_chkMasterNG.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkMasterNG.EnableBallonToolTip();
	m_chkMasterNG.SetToolTipText( _T("Set check if master pcb ng ") );
	m_chkMasterNG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkMasterNG.SetBtnCursor(IDC_HAND_1);

	// Save the calibration result to file 
	m_chkSlaveNG.SetFont( &m_fntBtn );
	m_chkSlaveNG.SetImageOrg( 10, 3 );
	m_chkSlaveNG.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSlaveNG.EnableBallonToolTip();
	m_chkSlaveNG.SetToolTipText( _T("Set check if slave pcb ng") );
	m_chkSlaveNG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkSlaveNG.SetBtnCursor(IDC_HAND_1);	

	m_chkMasterNG.SetCheck(m_bMasterNG);
	m_chkSlaveNG.SetCheck(m_bSlaveNG);

	return TRUE;
}
void CDlgNGInfo::SetFiredNGInfo(int nNGCondition)
{
	if(nNGCondition & 0x01)
		m_bMasterNG= TRUE;
	else
		m_bMasterNG= FALSE;
	
	if(nNGCondition & 0x02)
		m_bSlaveNG= TRUE;
	else
		m_bSlaveNG= FALSE;
}
int CDlgNGInfo::GetUseSetNGInfo()
{
	int nVal = 0;
	if(m_chkMasterNG.GetCheck())
		nVal += 1;
	if(m_chkSlaveNG.GetCheck())
		nVal += 2;

	return nVal;
}