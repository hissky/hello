// DeviceUMacKunsan8.cpp: implementation of the DeviceUMacKunsan8 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DeviceUMacKunsan8.h"
#include "..\..\MotionControlDLL_2010\MotionControlDll_Interface.h"
#include "..\alarmmsg.h"
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\InterfaceMotorModule.h"

#define WRITE_BASE			0x610A0
#define READ_BASE			0x61000
#define SET_XY_PARAM_BASE	0x40

#define TIME_STATUS			50
#define WAIT_COMMAND_TIME	20
#define MAX_STOPOVER_TIME	25.0
#define MP920_SCALE			1000.0

UINT DeviceUMacKunsan8::ThreadUMacStatus(LPVOID pParam)
{
	DeviceUMacKunsan8 *pUMac = (DeviceUMacKunsan8 *)pParam;
	BOOL bFirst = TRUE;
	
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
		// read
		pUMac->ReadStatus(bFirst);

		if(bFirst)
			bFirst = FALSE;
		
	} while(!pUMac->m_bStatusStop);
	return TRUE;
}

UINT DeviceUMacKunsan8::ThreadUMacInPosition(LPVOID pParam)
{
	DeviceUMacKunsan8 *pUMac = (DeviceUMacKunsan8 *)pParam;
	
	pUMac->m_bCommandStop = false;
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
			switch(pUMac->m_nInPositionCommand)
			{
			case COMMAND_INPOSITION :		// ���� ����
				if(pUMac->IsMoveEnd(pUMac->m_nInPositionAxis))
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_INORIGIN	:		// ���� ����
				if(pUMac->IsMotorOrigin(pUMac->m_nInPositionAxis))
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_LOADSTOP	:		// Loader ����
				if(pUMac->m_NewStatus.m_bPCBLoadEnd)
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_LOADMOVING	:		// Loader ����
				if(pUMac->m_NewStatus.m_bPCBLoading)
					pUMac->m_nIsInPosition = TRUE;
				break;
//			case COMMAND_UNLOADSTOP	:		// Unload ����
//				if(pUMac->m_NewStatus.m_bPCBUnloadEnd)//2)
//					pUMac->m_nIsInPosition = TRUE;
//				break;
//			case COMMAND_UNLOADMOVING	:	// Unload ����
//				if(pUMac->m_NewStatus.m_bPCBUnloading)
//					pUMac->m_nIsInPosition = TRUE;
//				break;
			case COMMAND_ALIGNERSTOP	:	// Aligner ����
				if(pUMac->m_NewStatus.m_bLoaderAlignEnd)
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_ALIGNERMOVING	:	// Aligner ����
				if(pUMac->m_NewStatus.m_bLoaderAligning)
					pUMac->m_nIsInPosition = TRUE;
				break;
			}
		
		if(pUMac->m_nIsInPosition == TRUE)
			pUMac->m_pStopTime.StartTime();
		
		if(pUMac->m_pStopTime.PresentTime() > MAX_STOPOVER_TIME)
			pUMac->m_nIsInPosition = -1;
	} while(!pUMac->m_bPositionStop);
	return TRUE;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DeviceUMacKunsan8::DeviceUMacKunsan8()
{
	m_thdStatus			= NULL;
	m_thdInPosition		= NULL;
	m_bStatusStop		= FALSE;
	m_nMaskPos			= -1;
	m_nMaskPos2			= -1;
	m_nIsInPosition		= FALSE;
	m_bPositionStop		= FALSE;
	m_nInPositionCount	= 0;

	m_lErrorIo			=0;
	m_lErrorLoad		=0;
	m_lErrorLoad2       =0;
	m_lErrorLoad3       =0;
	m_lErrorUnload		=0;
	m_lErrorUnload2		=0;
	m_lErrorUnload3		=0;
	m_lErrorAligner		=0;
	m_lErrorTableLimit	=0;
	m_lErrorOtherLimit	=0;
	m_lErrorTable		=0;
	m_lErrorLaser		=0;

	m_lStatusIO1		=0;
	m_lStatusIO2		=0;
	m_lStatusIO3		=0;

	for(BYTE nAxis = 0; nAxis < MOTOR_AXIS_MAX; nAxis++)
	{
		m_lWritePos[nAxis] = 0;			// �̵��� ��ġ
		m_bIsInPosition[nAxis] = FALSE;
		m_dScale[nAxis] = MP920_SCALE;
	}
	m_dScale[AXIS_M] = 1.0;		// 1���� �Ÿ� 360.0��
	
#ifdef	__SECOND_OPTICS
	m_dScale[AXIS_M2] = 1.0;		// 1���� �Ÿ� 360.0��
#endif

	SetAxisMax(MOTOR_AXIS_MAX);

}

DeviceUMacKunsan8::~DeviceUMacKunsan8()
{
	m_bStatusStop = TRUE;
	m_bPositionStop = TRUE;

	if(m_thdStatus != NULL)		// Thread ����
		WaitForSingleObject(m_thdStatus->m_hThread, INFINITE);
	m_thdStatus = NULL;

	if(m_thdInPosition != NULL)
	{
		m_thdInPosition->ResumeThread();
		WaitForSingleObject(m_thdInPosition->m_hThread, INFINITE);
	}

	if(::MotionControlDLL_IsInitialized())
	{
		::MotionControlDLL_Uninitialize();
	}
}

BOOL DeviceUMacKunsan8::Initialize()
{
	CString strPath;
	CString strMotionControlProfile, strPMACProfile, strInputIOProfile, strOutputIOProfile;

	strPath.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	strMotionControlProfile.Format(
		_T("%s\\MotionControl.ini"),
		strPath
		);
	
	strPMACProfile.Format(
		_T("%s\\PMACProfile.ini"),
		strPath
		);
	
	strInputIOProfile.Format(
		_T("%s\\InputIOControl.ini"),
		strPath
		);
	
	strOutputIOProfile.Format(
		_T("%s\\OutputIOControl.ini"),
		strPath
		);
	
	BOOL bResult = ::MotionControlDLL_Initialize(
		strPMACProfile,
		strMotionControlProfile,
		strInputIOProfile,
		strOutputIOProfile
		);

	if(bResult)
	{
		if(m_thdStatus == NULL)		// Thread  Ȱ��ȭ
		{
			m_thdStatus = ::AfxBeginThread(ThreadUMacStatus, this);
		}

		if(m_thdInPosition == NULL)
		{
			m_thdInPosition = ::AfxBeginThread(ThreadUMacInPosition, this);
			m_thdInPosition->SuspendThread();
		}
	}

	return bResult;
}

void DeviceUMacKunsan8::ReadStatus(BOOL bFirst)
{
	::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition), &m_NewStatus);

	ReadPosition();
	ReadErrorIo();
	ReadErrorLoad1();
	ReadErrorLoad2();
	ReadErrorLoad3();
	ReadErrorUnload1();
	ReadErrorUnload2();
	ReadErrorUnload3();
	ReadErrorAligner();
	ReadErrorTableLimit();
	ReadErrorOtherLimit();
	ReadErrorTable();
	ReadErrorLaser();
	ReadErrorOthers();
	ReadErrorOthers2();
	ReadErrorOthers3();
	ReadErrorOthers4();
	
	ReadStatusIO1();
	ReadStatusIO2();
	ReadStatusIO3();
	ReadStatusIO4();

	if(bFirst)
	{
		memcpy(&m_OldStatus, &m_NewStatus, sizeof(DpramReadPosition));
		SetInitialCmd();
	}
}

BOOL DeviceUMacKunsan8::SetOffset(int nAxis, double dOffset) // offset or TA
{
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E0, (DWORD)dOffset);
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FD, (DWORD)dOffset);
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F0, (DWORD)dOffset);
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset);
	else if(nAxis == AXIS_C)
		return MotionControlDLL_WriteOutputDWord(0x61104, (DWORD)dOffset);
	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61110, (DWORD)dOffset);
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61118, (DWORD)dOffset);
	else
		return TRUE;
}

BOOL DeviceUMacKunsan8::SetOffset(double dOffset[]) // not use
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E0, (DWORD)dOffset[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FD, (DWORD)dOffset[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F0, (DWORD)dOffset[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset[AXIS_M]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110A, (DWORD)dOffset[AXIS_C]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61110, (DWORD)dOffset[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61118, (DWORD)dOffset[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacKunsan8::SetSpeed(int nAxis, long lSpeed)
{
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E2, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FF, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F2, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61102, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_C)
		return MotionControlDLL_WriteOutputDWord(0x61106, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61112, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x6111A, (long)(lSpeed * m_dScale[nAxis]));
	else
		return TRUE;
}

BOOL DeviceUMacKunsan8::SetSpeed(long lSpeed[])
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E2, lSpeed[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FF, lSpeed[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F2, lSpeed[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61102, lSpeed[AXIS_M]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110C, lSpeed[AXIS_C]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61112, lSpeed[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111A, lSpeed[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacKunsan8::SetOriginSpeed(int nAxis, long lSpeed) // homeSpeed or TS
{
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E1, lSpeed);
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FE, lSpeed);
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F1, lSpeed);
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61101, lSpeed);
	else if(nAxis == AXIS_C)
		return MotionControlDLL_WriteOutputDWord(0x61105, lSpeed);
	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61111, lSpeed);
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61119, lSpeed);
	else
		return TRUE;
}

BOOL DeviceUMacKunsan8::SetOriginSpeed(long lSpeed[]) // homeSpeed or TS
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E1, lSpeed[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FE, lSpeed[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F1, lSpeed[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61101, lSpeed[AXIS_M]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110B, lSpeed[AXIS_C]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61111, lSpeed[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61119, lSpeed[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacKunsan8::SetVibration(int nCount, double dDelay)
{
	BOOL bResult = TRUE;

	int nValue = (int)(dDelay + 0.001) * 10;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61108, nCount);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61109, nValue) ;

	return bResult;
}

BOOL DeviceUMacKunsan8::SetLimitZ(double dPosZ1Low, double dPosZ1High, double dPosZ2Low, double dPosZ2High, double dXMin, double dXMax)
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F5, GetIntPosition(dPosZ1Low, AXIS_Z1));	// z1 limit -
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F6, GetIntPosition(dPosZ1High, AXIS_Z1)); // z1 limit +
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F7, GetIntPosition(dPosZ2Low, AXIS_Z2));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F8, GetIntPosition(dPosZ2High, AXIS_Z2));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E3, GetIntPosition(dXMin, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E4, GetIntPosition(dXMax, AXIS_X));
	return bResult;
}

DWORD DeviceUMacKunsan8::GetIntPosition(double dPos, int nAxis)
{
	DWORD nResult = (DWORD)(((dPos + 0.5) / m_dScale[nAxis]) * m_dScale[nAxis]);
	return nResult;
}

BOOL DeviceUMacKunsan8::SetMaskPosition(double dMaskPosition[], double dMaskPosition2[])
{
	for(int nNo = 0; nNo < MOTOR_MASK_MAX; nNo++)
	{
		m_dMaskPosition[nNo] = dMaskPosition[nNo];
		m_dMaskPosition2[nNo] = dMaskPosition2[nNo];
	}
	
	return TRUE;
}

void DeviceUMacKunsan8::SetScale(int nAxis, double dScale)
{
	m_dScale[nAxis] = dScale;
}

BOOL DeviceUMacKunsan8::SetAxisMax(int nAxisMax)
{
	m_nAxisMax = nAxisMax;
	return TRUE;
}

BOOL DeviceUMacKunsan8::SetOrigin(int nAxis)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	m_nMaskPos2 = -1;

	switch(nAxis)
	{
	case -1:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 0, 1);
//		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B0, 2);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B1, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B2, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B3, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B4, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B5, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B6, 1);
		break;
	case AXIS_X:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 1);
		break;
	case AXIS_Y:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 2);
		break;
	case AXIS_Z1:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B1, 1);
		break;
	case AXIS_Z2:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B2, 1);
		break;
	case AXIS_M:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B3, 1);
		break;
	case AXIS_C:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B4, 1);
		break;
	case AXIS_C2:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B5, 1);
		break;
	case AXIS_L_CARRIER:
		bResult = MotionControlDLL_WriteOutputDWord(0x610C1, 1);
		break;
	case AXIS_UL_CARRIER:
		bResult = MotionControlDLL_WriteOutputDWord(0x610D1, 1);
		break;
	}

	return bResult;
}

BOOL DeviceUMacKunsan8::GetPosition(int nAxis, double &dPosition) // real position
{
	if(nAxis == AXIS_X)
		dPosition = m_NewStatus.m_nXActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Y)
		dPosition = m_NewStatus.m_nYActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Z1)
		dPosition = m_NewStatus.m_nZ1ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Z2)
		dPosition = m_NewStatus.m_nZ2ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_M)
		dPosition = m_NewStatus.m_nM1ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_C)
		dPosition = m_NewStatus.m_nB1ActualPos / m_dScale[nAxis];
//	else if(nAxis == AXIS_M2)
//		dPosition = m_NewStatus.m_nM2ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_C2)
		dPosition = m_NewStatus.m_nB2ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_L_CARRIER)
		dPosition = m_NewStatus.m_nLoadCarrierActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_UL_CARRIER)
		dPosition = m_NewStatus.m_nUnloadCarrierActualPos / m_dScale[nAxis];
	else 
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E7, GetIntPosition(dLoadX, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E8, GetIntPosition(dLoadY, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E9, GetIntPosition(dUnload1X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EA, GetIntPosition(dUnload1Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EB, GetIntPosition(dUnload1X, AXIS_X)); // ����� �ϳ��� ��ε���
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EC, GetIntPosition(dUnload1Y, AXIS_Y));
	
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610ED, GetIntPosition(dUnload2X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EE, GetIntPosition(dUnload2Y, AXIS_Y));
	return bResult;	
}

BOOL DeviceUMacKunsan8::SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y, double dLoadX2, double dLoadY2)
{
	BOOL bResult = TRUE;
	
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E7, GetIntPosition(dLoadX, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E8, GetIntPosition(dLoadY, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E9, GetIntPosition(dUnload1X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EA, GetIntPosition(dUnload1Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EB, GetIntPosition(dUnload2X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EC, GetIntPosition(dUnload2Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610ED, GetIntPosition(dLoadX2, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EE, GetIntPosition(dLoadY2, AXIS_Y));
	
	return bResult;	
}

BOOL DeviceUMacKunsan8::SetLoaderUnloaderPickerPos(double dLoaderCartPos, double dLoaderLoadPos, double dUnloaderCartPos, double dUnloaderUnloadPos)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61113, GetIntPosition(dLoaderCartPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61114, GetIntPosition(dLoaderLoadPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111C, GetIntPosition(dUnloaderCartPos, AXIS_UL_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111B, GetIntPosition(dUnloaderUnloadPos, AXIS_UL_CARRIER));

	return bResult;
}

BOOL DeviceUMacKunsan8::DownloadPosition(int nAxis, double dPosition)
{
	int nCount = 0;
	BOOL bResult = TRUE;
	DWORD nSetPos, nGetPos;
	nSetPos = DWORD(dPosition * m_dScale[nAxis]);
	
	while(nCount < 10)
	{
		switch(nAxis)
		{
		case AXIS_X:
			bResult = MotionControlDLL_WriteOutputDWord(0x610E5, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x40, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_Y:
			bResult = MotionControlDLL_WriteOutputDWord(0x610E6, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x48, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_Z1:
			bResult = MotionControlDLL_WriteOutputDWord(0x610F3, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x50, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			} 
			break;
		case AXIS_Z2:
			bResult = MotionControlDLL_WriteOutputDWord(0x610F4, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x58, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_M:
			bResult = MotionControlDLL_WriteOutputDWord(0x61103, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x60, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_C:
			bResult = MotionControlDLL_WriteOutputDWord(0x61107, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x64, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_C2:
			break;
		case AXIS_M2:
		case AXIS_A1:
		case AXIS_A2:
			return TRUE;
			break;
		}
		nCount++;
	}

	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveAxis(int nAxis, double dPosition)
{
	BOOL bResult = TRUE;
	bResult = DownloadPosition(nAxis, dPosition);
	
//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[%d] (%.3f)"), nAxis, dPosition);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		switch(nAxis)
		{
			case AXIS_X:
				return MotionControlDLL_WriteOutputDWord(0x610B0, 3);
				break;
			case AXIS_Y:
				return  MotionControlDLL_WriteOutputDWord(0x610B0, 4);
				break;
			case AXIS_Z1:
				return  MotionControlDLL_WriteOutputDWord(0x610B1, 2); 
				break;
			case AXIS_Z2:
				return  MotionControlDLL_WriteOutputDWord(0x610B2, 2);
				break;
			case AXIS_M:
				return  MotionControlDLL_WriteOutputDWord(0x610B3, 2);
				break;
			case AXIS_C:
				return  MotionControlDLL_WriteOutputDWord(0x610B4, 2);
				break;
			case AXIS_C2:
				return  MotionControlDLL_WriteOutputDWord(0x610B5, 2);
				break;
		}
		return TRUE;
	}
	else
		return FALSE;
	
}

BOOL DeviceUMacKunsan8::MotorMoveXY(double dPosX, double dPosY)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);

	CString strFile, strLog;
	strFile.Format(_T("Inpos"));
	strLog.Format(_T("Move[XY] (%.3f, %.3f)"), dPosX, dPosY);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(bResult)
	{
		return MotionControlDLL_WriteOutputDWord(0x610B0, 5);
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveZ(double dPosZ1)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B1, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveZ(double dPosZ1, double dPosZ2)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XYZ] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveXYZMC(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosC)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XYZMC] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::MotorMoveXYZMC(double dPosX, double dPosY, double dPosZ1, double dPosZ2, int nPosM, double dPosC)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nPosM]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XYZMC] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::MotorMoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XYZMC2] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::MotorMoveZMC(double dPosZ1, double dPosZ2, int nMaskPos, double dPosC)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveZMC2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition2[nMaskPos2]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveM(int nMaskPos)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;

	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);

	if(bResult)
		return MotionControlDLL_WriteOutputDWord(0x610B3, 2);

	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveM(double dMaskPos)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	
	if(bResult)
		return MotionControlDLL_WriteOutputDWord(0x610B3, 2);
	
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveM2(int nMaskPos1, int nMaskPos2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos1;
	m_nMaskPos2 = nMaskPos2;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos1]);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition[nMaskPos2]);
	
	if(bResult)
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2));
	
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveM2(double dMaskPos1, double dMaskPos2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	m_nMaskPos2 = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos1);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	
	if(bResult)
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2));
	
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveMC(int nMaskPos, double dPosC)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;

	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveMC(double dMaskPos, double dPosC)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveMC2(int nMaskPos, int nMaskPos2, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition2[nMaskPos2]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));		
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveMC2DownOnly(int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition2[nMaskPos2]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	return bResult;
}

BOOL DeviceUMacKunsan8::MotorMoveMC2(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);

	return bResult;
}

BOOL DeviceUMacKunsan8::ResetXYZMCPos()
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, 0);
	bResult = bResult & DownloadPosition(AXIS_Y, 0);
	bResult = bResult & DownloadPosition(AXIS_Z1, 0);
	bResult = bResult & DownloadPosition(AXIS_Z2, 0);
	bResult = bResult & DownloadPosition(AXIS_M, 0);
	bResult = bResult & DownloadPosition(AXIS_C, 0);
#ifdef __SECOND_OPTICS
	bResult = bResult & DownloadPosition(AXIS_M2, 0);
//	bResult = bResult & DownloadPosition(AXIS_C2, 0);
#endif
	
	return bResult;
}

BOOL DeviceUMacKunsan8::MotorShutterAll(BOOL bOpenMaster/*TRUE*/, BOOL bOpenSlave/*TRUE*/)
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 4, bOpenMaster);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 5, !bOpenMaster);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 6, bOpenSlave);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 7, !bOpenSlave);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderOrigin()
{
	return MotionControlDLL_WriteOutputIOBit(3, 0, TRUE);
}

BOOL DeviceUMacKunsan8::LoaderAlign()
{
	return MotionControlDLL_WriteOutputIOBit(3, 2, TRUE); 
}

BOOL DeviceUMacKunsan8::LoaderLoading()
{
	return MotionControlDLL_WriteOutputIOBit(3, 1, TRUE); 
}

BOOL DeviceUMacKunsan8::SetDrillStatus(BOOL bDrilling)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::UnloadOrigin()
{
	return MotionControlDLL_WriteOutputIOBit(6, 0, TRUE);
}

BOOL DeviceUMacKunsan8::UnloadUnloading()
{
	return MotionControlDLL_WriteOutputIOBit(6, 1, TRUE); // bFiducial : not use
} 

BOOL DeviceUMacKunsan8::Stop(int nAxis)
{
	nAxis;
	switch(nAxis)
	{
	case AXIS_X:
	case AXIS_Y:
		MotionControlDLL_WriteOutputDWord(0x610B0, 9);
		break;
	case AXIS_Z1:
		MotionControlDLL_WriteOutputDWord(0x610B1, 3);
		break;
	case AXIS_Z2:
		MotionControlDLL_WriteOutputDWord(0x610B2, 3);
		break;
	case AXIS_M:
		MotionControlDLL_WriteOutputDWord(0x610B3, 3);
		break;
	case AXIS_C:
		MotionControlDLL_WriteOutputDWord(0x610B4, 3);
		break;
	case AXIS_C2:
		MotionControlDLL_WriteOutputDWord(0x610B5, 3);
		break;
	case AXIS_L_CARRIER:
		MotionControlDLL_WriteOutputDWord(0x610C1, 4);
		break;
	case AXIS_UL_CARRIER:
		MotionControlDLL_WriteOutputDWord(0x610D1, 4);
		break;
	}

	return TRUE;
}

int DeviceUMacKunsan8::GetCurrentMask()
{
	return m_nMaskPos;
}

LONG DeviceUMacKunsan8::GetCurrentError(ERRORCOMMAND nError)
{
	switch(nError)
	{
	case ERROR_IO			:
		return m_lErrorIo;
	case ERROR_LOAD			:
		return m_lErrorLoad;
	case ERROR_LOAD2		:
		return m_lErrorLoad2;
	case ERROR_LOAD3		:
		return m_lErrorLoad3;
	case ERROR_UNLOAD		:
		return m_lErrorUnload;
	case ERROR_UNLOAD2		:
		return m_lErrorUnload2;
	case ERROR_UNLOAD3		:
		return m_lErrorUnload3;
	case ERROR_ALIGN		:
		return m_lErrorAligner;
	case ERROR_TABLELIMIT	:
		return m_lErrorTableLimit;
	case ERROR_OTHERLIMIT	:
		return m_lErrorOtherLimit;
	case ERROR_TABLE		:
		return m_lErrorTable;
	case ERROR_LASER		:
		return m_lErrorLaser;
	case ERROR_OTHERS		:
		return m_lErrorOthers;
	case ERROR_OTHERS2		:
		return m_lErrorOthers2;
	case ERROR_OTHERS3		:
		return m_lErrorOthers3;
	case ERROR_OTHERS4		:
		return m_lErrorOthers4;
	case STATUS_IO1			:
		return m_lStatusIO1;
	case STATUS_IO2			:
		return m_lStatusIO2;
	case STATUS_IO3			:
		return m_lStatusIO3;
	case STATUS_IO4			:
		return m_lStatusIO4;
	}
	return 0;
}

void DeviceUMacKunsan8::ReadErrorIo()
{
	m_lErrorIo = 0;
	m_lErrorIo += (m_NewStatus.m_bEmergencyStopAlarm)			? 0x0001 : 0x0000; // em stop
	m_lErrorIo += (m_NewStatus.m_bServoPowerOffAlarm)			? 0x0002 : 0x0000; // Servo power off alarm
	m_lErrorIo += (m_NewStatus.m_bMainStationInitialError)		? 0x0004 : 0x0000; // main station init error
//	m_lErrorIo += (m_NewStatus.m_bPCAliveOffError)				? 0x0008 : 0x0000; // pc alive signal off error
	m_lErrorIo += (m_NewStatus.m_bFrontDoorOpenAlarm)			? 0x0010 : 0x0000; // Main Door Open	
	m_lErrorIo += (m_NewStatus.m_bRearDoorOpenAlarm)			? 0x0020 : 0x0000; // rear door open
	m_lErrorIo += (m_NewStatus.m_bLaserPowerOffAlarm)			? 0x0040 : 0x0000; // laser power off error
	m_lErrorIo += (m_NewStatus.m_bMainAirAlarm)					? 0x0080 : 0x0000; // Main Suction Alarm
	m_lErrorIo += (m_NewStatus.m_bHeightSensorUpError)			? 0x0100 : 0x0000; // Height Sensor up error
	m_lErrorIo += (m_NewStatus.m_bHeightSensorDownError)		? 0x0200 : 0x0000; // Height Sensor down error
//	m_lErrorIo += (m_NewStatus.m_bHeightSensor2UpError)			? 0x0400 : 0x0000; // Height Sensor up error
//	m_lErrorIo += (m_NewStatus.m_bHeightSensor2DownError)		? 0x0800 : 0x0000; // Height Sensor down error
	m_lErrorIo += (m_NewStatus.m_bLoadDoorOpenError)			? 0x0400 : 0x0000; // loader door open
	m_lErrorIo += (m_NewStatus.m_bUnloadDoorOpenError)			? 0x0800 : 0x0000; // unloader door open
	m_lErrorIo += (m_NewStatus.m_b1stShutterCylinderOpenError)	? 0x1000 : 0x0000; // High Speed Shutter#1 �ΰ��� Sensor ON
	m_lErrorIo += (m_NewStatus.m_b1stShutterCylinderCloseError) ? 0x2000 : 0x0000; // High Speed Shutter#1 �ΰ��� Sensor OFF
	m_lErrorIo += (m_NewStatus.m_b2ndShutterCylinderOpenError)	? 0x4000 : 0x0000; // High Speed Shutter#2 �ΰ��� Sensor ON
	m_lErrorIo += (m_NewStatus.m_b2ndShutterCylinderCloseError) ? 0x8000 : 0x0000; // High Speed Shutter#2 �ΰ��� Sensor OFF
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacKunsan8::ReadErrorLoad1()
{
	m_lErrorLoad = 0;
//	m_lErrorLoad += (m_NewStatus.m_bLDStopAfterRunError)				? 0x0001 : 0x0000; 
//	m_lErrorLoad += (m_NewStatus.m_bLDStopRNError)						? 0x0002 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoaderCartNoPCB)					? 0x0004 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPCBNotExistError)		? 0x0008 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPCBExistError)		? 0x0010 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadRightPickerPCBNotExistError)	? 0x0020 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadRightPickerPCBExistError)		? 0x0040 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoaderInitialError)					? 0x0080 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadAlignTablePCBNotExistError)		? 0x0100 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadAlignTablePCBExistError)		? 0x0200 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad1UpError)			? 0x0400 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad1DownError)		? 0x0800 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad2UpError)			? 0x1000 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad2DownError)		? 0x2000 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerVacuumOnError)		? 0x4000 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerVacuumOffError)		? 0x8000 : 0x0000;
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacKunsan8::ReadErrorLoad2()
{
	m_lErrorLoad2 = 0;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadLeftPickerBlowOnError)			? 0x0001 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad1UpError)		? 0x0002 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad1DownError)      ? 0x0004 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad2UpError)		? 0x0008 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad2DownError)	    ? 0x0010 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerVacuumOnError)		? 0x0020 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerVacuumOffError)		? 0x0040 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerBlowOnError)		? 0x0080 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadCartClampError)				? 0x0100 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadCartUnClampError)				? 0x0200 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignSheetTableForwardError)	? 0x0400 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignSheetTableBackwardError)	? 0x0800 : 0x0000;	
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignGuideForwardError)		? 0x1000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignGuideBackwardError)		? 0x2000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignTableMoveLeftError)		? 0x4000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignTableMoveRightError)		? 0x8000 : 0x0000;
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacKunsan8::ReadErrorLoad3()
{
	m_lErrorLoad3 = 0;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorMoveLoadLevelError)	? 0x0001 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorMoveOriginError)		? 0x0002 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorAlarmError)			? 0x0004 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMoveCartPosError)		? 0x0008 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMoveLoadPosError)		? 0x0010 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMotionParamError)		? 0x0020 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierFault)					? 0x0040 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierFollowingError)			? 0x0080 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierOpenLoop)				? 0x0100 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierHomeTimeOver)  			? 0x0200 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadLeftPCBTakeReadyError)			? 0x0400 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadRightPCBTakeReadyError)		? 0x0800 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCartDetectSensorError)			? 0x1000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElvAxisLimitError)				? 0x2000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadNoPCBError)					? 0x4000 : 0x0000;

//	m_lErrorLoad3 += (m_NewStatus.m_bLoadRightPickerStatusError)		? 0x4000 : 0x0000;
//	m_lErrorLoad3 += (m_NewStatus.m_bLoadLeftPickerStatusError)			? 0x8000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoaderPickerUnableDownError)		? 0x10000 : 0x00000;
}

//////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacKunsan8::ReadErrorUnload1()
{
	m_lErrorUnload = 0;
//	m_lErrorUnload += (m_NewStatus.m_bUDStopAfterRunError)					? 0x0001 : 0x0000;
//	m_lErrorUnload += (m_NewStatus.m_bUDStopRNError)						? 0x0002 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadTablePCBExistError)				? 0x0004 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadTablePCBNotExistError)			? 0x0008 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPCBNotExistError)		? 0x0010 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPCBExistError)		? 0x0020 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerPCBNotExistError)	? 0x0040 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerPCBExistError)		? 0x0080 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad1UpError)			? 0x0100 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad1DownError)		? 0x0200 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad2UpError)			? 0x0400 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad2DownError)		? 0x0800 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerVacuumOnError)		? 0x1000 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerVacuumOffError)		? 0x2000 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerBlowOnError)			? 0x4000 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerPad1UpError)			? 0x8000 : 0x0000;
}

////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacKunsan8::ReadErrorUnload2()
{
	m_lErrorUnload2 = 0;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerPad1DownError)		? 0x0001 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerPad2UpError)		? 0x0002 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerPad2DownError)		? 0x0004 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerVacuumOnError)		? 0x0008 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerVacuumOffError)		? 0x0010 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerBlowOnError)		? 0x0020 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCartClampError)				? 0x0040 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCartUnClampError)				? 0x0080 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadAlignTableMoveLeftError)		? 0x0100 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadAlignTableMoveRightError)		? 0x0200 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadElevatorMoveLoadLevelError)	? 0x0400 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadElevatorMoveOriginError)		? 0x0800 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloaderElevatorAlarmError)			? 0x1000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMoveLoadPosError)		? 0x2000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMoveCartPosError)		? 0x4000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMotionParamError)		? 0x8000 : 0x0000;
}

////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacKunsan8::ReadErrorUnload3()
{
	m_lErrorUnload3 = 0;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierFault)				? 0x0001 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierFollowingError)		? 0x0002 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierOpenLoop)			? 0x0004 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierHomeTimeOver)		? 0x0008 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadLeftPCBTakeReadyError)		? 0x0010 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadRightPCBTakeReadyError)	? 0x0020 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloaderInitialError)			? 0x0040 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCartDetectSensorError)		? 0x0080 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadElvAxisLimitError)			? 0x0100 : 0x0000;

//	m_lErrorUnload3 += (m_NewStatus.m_bUnloadRightPickerStatusError)	? 0x0200 : 0x0000;
//	m_lErrorUnload3 += (m_NewStatus.m_bUnloadLeftPickerStatusError)		? 0x0400 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadPickerUnableDownError)		? 0x0800 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloaderCartFull)				? 0x1000 : 0x0000;
}

////////////////////////////////////
// Purpose		: Aligner Error �б�
void DeviceUMacKunsan8::ReadErrorAligner() // not use
{
	m_lErrorAligner = 0;
}

///////////////////////////////////////
// Purpose		: Table Limit Error �б�
void DeviceUMacKunsan8::ReadErrorTableLimit()
{
	m_lErrorTableLimit = 0;
	m_lErrorTableLimit += (m_NewStatus.m_bXPositiveLimitOver) ? 0x0001 : 0x0000;	// X+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bXNegativeLimitOver) ? 0x0002 : 0x0000;	// X- Limit
	m_lErrorTableLimit += (m_NewStatus.m_bYPositiveLimitOver) ? 0x0004 : 0x0000;	// Y+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bYNegativeLimitOver) ? 0x0008 : 0x0000;	// Y- Limit

	m_lErrorTableLimit += (m_NewStatus.m_bZ1PositiveLimitOver) ? 0x0040 : 0x0000;	// Z1+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ1NegativeLimitOver) ? 0x0080 : 0x0000;	// Z1- Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ2PositiveLimitOver) ? 0x0100 : 0x0000;	// Z2+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ2NegativeLimitOver) ? 0x0200 : 0x0000;	// Z2- Limit
}

////////////////////////////////////////
// Purpose		: Other Limit Error �б�
void DeviceUMacKunsan8::ReadErrorOtherLimit()
{
	m_lErrorOtherLimit = 0;
	m_lErrorOtherLimit += (m_NewStatus.m_bB1PositiveLimitOver)			? 0x0001 : 0x0000;	// B1+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bB1NegativeLimitOver)			? 0x0002 : 0x0000;	// B1- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bLoadCarrierPositiveLimit)		? 0x0004 : 0x0000;	// P1+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bLoadCarrierNegativeLimit)		? 0x0008 : 0x0000;	// P1- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bB2PositiveLimitOver)			? 0x0010 : 0x0000;	// B2+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bB2NegativeLimitOver)			? 0x0020 : 0x0000;	// B2- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bUnloadCarrierPositiveLimit)	? 0x0040 : 0x0000;	// P2+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bUnloadCarrierNegativeLimit)	? 0x0080 : 0x0000;	// P2- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bM1PositiveLimitOver)			? 0x0100 : 0x0000;  // M1+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bM1NegativeLimitOver)			? 0x0200 : 0x0000;  // M1- Limit
//	m_lErrorOtherLimit += (m_NewStatus.m_bM2PositiveLimitOver)			? 0x0400 : 0x0000;  // M2+ Limit
//	m_lErrorOtherLimit += (m_NewStatus.m_bM2NegativeLimitOver)			? 0x0800 : 0x0000;  // M2- Limit
}

//////////////////////////////////
// Purpose		: Table Error �б�
void DeviceUMacKunsan8::ReadErrorTable()
{
	m_lErrorTable = 0;
	m_lErrorTable += (m_NewStatus.m_bXYMoveDangerError)					? 0x0001 : 0x0000; // xy move danger error
	m_lErrorTable += (m_NewStatus.m_bXYStopError)						? 0x0002 : 0x0000; // XY Stop Error
	m_lErrorTable += (m_NewStatus.m_bXFault)							? 0x0004 : 0x0000; // X Fault
	m_lErrorTable += (m_NewStatus.m_bXFollowError)						? 0x0008 : 0x0000; // X Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bXOpenLoop)							? 0x0010 : 0x0000; // X Open Loop
	m_lErrorTable += (m_NewStatus.m_bXHomeTimeOver)						? 0x0020 : 0x0000; // X Homing TimeOut
	m_lErrorTable += (m_NewStatus.m_bYFault)							? 0x0040 : 0x0000; // Y Fault
	m_lErrorTable += (m_NewStatus.m_bYFollowError)						? 0x0080 : 0x0000; // Y Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bYOpenLoop)							? 0x0100 : 0x0000; // Y Open Loop
	m_lErrorTable += (m_NewStatus.m_bYHomeTimeOver)						? 0x0200 : 0x0000; // Y Homing TimeOut
	m_lErrorTable += (m_NewStatus.m_bZ1Fault)							? 0x0400 : 0x0000; // Z1 Fault
	m_lErrorTable += (m_NewStatus.m_bZ1FollowError)						? 0x0800 : 0x0000; // Z1 Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bZ1OpenLoop)						? 0x1000 : 0x0000; // Z1 Open Loop
	m_lErrorTable += (m_NewStatus.m_bZ1HomeTimeOver)					? 0x2000 : 0x0000; // Z1 Homing TimeOUt
	m_lErrorTable += (m_NewStatus.m_bZ2Fault)							? 0x4000 : 0x0000; // Z2 Fault
	m_lErrorTable += (m_NewStatus.m_bZ2FollowError)						? 0x8000 : 0x0000; // Z2 Fatal Following Err
}

//////////////////////////////////
// Purpose		: Laser Error �б�
void DeviceUMacKunsan8::ReadErrorLaser()
{
	m_lErrorLaser = 0;
	m_lErrorLaser += (m_NewStatus.m_bChillerOnError) ? 0x0001 : 0x0000;	// Chiller Alarm
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�
void DeviceUMacKunsan8::ReadErrorOthers()
{
	m_lErrorOthers = 0;
//	m_lErrorOthers += (m_NewStatus.m_bTableVacuumMotor1OnError)				? 0x0001 : 0x0000;
//	m_lErrorOthers += (m_NewStatus.m_bTableVacuumMotor1OffError)			? 0x0002 : 0x0000;
//	m_lErrorOthers += (m_NewStatus.m_bTableVacuumMotor2OnError)				? 0x0004 : 0x0000;
//	m_lErrorOthers += (m_NewStatus.m_bTableVacuumMotor2OffError)			? 0x0008 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_b1stTableVacuumOnError)				? 0x0010 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_b1stTableVacuumOffError)				? 0x0020 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_b2ndTableVacuumOnError)				? 0x0040 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_b2ndTableVacuumOffError)				? 0x0080 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bPowerDetectorShutterForwardError)		? 0x0100 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bPowerDetectorShutterBackwardError)	? 0x0200 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bXMovePositionError)					? 0x0400 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bYMovePositionError)					? 0x0800 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bXYMoveLoadPositionError)				? 0x1000 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bXYMovePositionError)					? 0x2000 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bXYMoveUnload1PositionError)			? 0x4000 : 0x0000;
	m_lErrorOthers += (m_NewStatus.m_bXYMoveUnload2PositionError)			? 0x8000 : 0x0000;
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�2
void DeviceUMacKunsan8::ReadErrorOthers2()
{
	m_lErrorOthers2 = 0;
	m_lErrorOthers2 += (m_NewStatus.m_bXYMotionParamError)		? 0x0001 : 0x0000; // xy motion error
	m_lErrorOthers2 += (m_NewStatus.m_bZ1MotionParamError)		? 0x0002 : 0x0000; // z1 motion error
	m_lErrorOthers2 += (m_NewStatus.m_bZ2MotionParamError)		? 0x0004 : 0x0000; // z2 motion error
	m_lErrorOthers2 += (m_NewStatus.m_bM1MotionParamError)		? 0x0008 : 0x0000; // m1 motion error
	m_lErrorOthers2 += (m_NewStatus.m_bB1MotionParamError)		? 0x0010 : 0x0000; // B1 motion error
	m_lErrorOthers2 += (m_NewStatus.m_bTableClampError)			? 0x0020 : 0x0000; // TableClamp error
//	m_lErrorOthers2 += (m_NewStatus.m_bM2MotionParamError)		? 0x0020 : 0x0000; // m2 motion error
	m_lErrorOthers2 += (m_NewStatus.m_bM1Fault)					? 0x0040 : 0x0000; // M1 Fault
	m_lErrorOthers2 += (m_NewStatus.m_bM1FollowError)			? 0x0080 : 0x0000; // M1 Fatal Following Err
	m_lErrorOthers2 += (m_NewStatus.m_bM1OpenLoop)				? 0x0100 : 0x0000; // M1 OpenLoop
	m_lErrorOthers2 += (m_NewStatus.m_bM1HomeTimeOver)			? 0x0200 : 0x0000; // M1 Homing TimeOut
	m_lErrorOthers2 += (m_NewStatus.m_bB1Fault)					? 0x0400 : 0x0000; // B1 Fault
	m_lErrorOthers2 += (m_NewStatus.m_bB1FollowError)			? 0x0800 : 0x0000; // B1 Fatal Following Err
	m_lErrorOthers2 += (m_NewStatus.m_bB1OpenLoop)				? 0x1000 : 0x0000; // B1 OpenLoop
	m_lErrorOthers2 += (m_NewStatus.m_bB1HomeTimeOver)			? 0x2000 : 0x0000; // B1 Homing TimeOut
	m_lErrorOthers2 += (m_NewStatus.m_bTableClamp2Error)		? 0x4000 : 0x0000; // TableClamp2 error
	m_lErrorOthers2 += (m_NewStatus.m_bLoaderNoPCB)				? 0x8000 : 0x0000; // LoaderCart No PCB error

	m_lErrorOthers2 += (m_NewStatus.m_bB2Fault)					? 0x10000 : 0x0000; // B2 Fault
	m_lErrorOthers2 += (m_NewStatus.m_bB2FollowError)			? 0x20000 : 0x0000; // B2 Fatal Following Err
	m_lErrorOthers2 += (m_NewStatus.m_bB2OpenLoop)				? 0x40000 : 0x0000; // B2 OpenLoop
	m_lErrorOthers2 += (m_NewStatus.m_bB2HomeTimeOver)			? 0x80000 : 0x0000; // B2 Homing TimeOut

	m_lErrorOthers2 += (m_NewStatus.m_bB2MotionParamError)		? 0x100000 : 0x0000; // B2 motion error
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�3
void DeviceUMacKunsan8::ReadErrorOthers3()
{
	m_lErrorOthers3 = 0;
	m_lErrorOthers3 += (m_NewStatus.m_bZ1MovePositionError)		? 0x0001 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bZ1StopError)				? 0x0002 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bZ2MovePositionError)		? 0x0004 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bZ2StopError)				? 0x0008 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bM1MovePositionError)		? 0x0010 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bM1StopError)				? 0x0020 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bB1MovePositionError)		? 0x0040 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bB1StopError)				? 0x0080 : 0x0000;
//	m_lErrorOthers3 += (m_NewStatus.m_bM2MovePositionError)		? 0x0100 : 0x0000;
//	m_lErrorOthers3 += (m_NewStatus.m_bM2StopError)				? 0x0200 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bB2MovePositionError)		? 0x0400 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bB2StopError)				? 0x0800 : 0x0000;
//	m_lErrorOthers3 += (m_NewStatus.m_bMPGOnAlarm)				? 0x1000 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bZ2OpenLoop)				? 0x2000 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bZ2HomeTimeOver)			? 0x4000 : 0x0000;
	m_lErrorOthers3 += (m_NewStatus.m_bM1Fault)					? 0x8000 : 0x0000;
	m_lErrorOthers3 += (!m_NewStatus.m_bAOMAlarm)				? 0x10000 : 0x0000;
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�4
void DeviceUMacKunsan8::ReadErrorOthers4()
{
	m_lErrorOthers4 = 0;
//	m_lErrorOthers4 += (m_NewStatus.m_bPCError)						? 0x0001 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_b1stTablePCBExistError)		? 0x0002 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_b1stTablePCBNotExistError)	? 0x0004 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_b2ndTablePCBExistError)		? 0x0008 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_b2ndTablePCBNotExistError)	? 0x0010 : 0x0000;

	m_lErrorOthers4 += (m_NewStatus.m_bMPGOnAlarm)					? 0x0020 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bLaser1PassSensorErr)			? 0x0040 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bLaser2PassSensorErr)			? 0x0080 : 0x0000;

	m_lErrorOthers4 += (m_NewStatus.m_bNoSafetyModeError)			? 0x0100 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bUnUseLdUdError)				? 0x0200 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bMPGOnError)					? 0x0400 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bElvDryRunError)				? 0x0800 : 0x0000;

	m_lErrorOthers4 += (m_NewStatus.m_bLoaderPickerNotAllUp)		? 0x1000 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bUnloaderPickerNotAllUp)		? 0x2000 : 0x0000;
//	m_lErrorOthers4 += (m_NewStatus.m_bAOMAlarm)					? 0x4000 : 0x0000;
	m_lErrorOthers4 += (m_NewStatus.m_bDustSuctionError)			? 0x4000 : 0x0000;
}

void DeviceUMacKunsan8::ReadStatusIO1()
{
	m_lStatusIO1 = 0;
	m_lStatusIO1 += (m_NewStatus.m_bMainRunReady)					? 0x0001 : 0x0000;
//	m_lStatusIO1 += (m_NewStatus.m_bPLCAlive)						? 0x0002 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMachineRunning)					? 0x0004 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bSafteyMode)						? 0x0008 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bDoorInterlockBypass)			? 0x0010 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_b1stTablePCBExist)				? 0x0020 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_b2ndTablePCBExist)				? 0x0040 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainInitialEnd)					? 0x0080 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainInitializing)				? 0x0100 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainStationAlarm)				? 0x0200 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInitialEnd)					? 0x0400 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInitializing)					? 0x0800 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInposition)					? 0x1000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXRun)							? 0x2000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bYInitialEnd)					? 0x4000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bYInitializing)					? 0x8000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bChillerOnCheck)					? 0x10000 : 0x0000;
}

void DeviceUMacKunsan8::ReadStatusIO2()
{
	m_lStatusIO2 = 0;
	m_lStatusIO2 += (m_NewStatus.m_bYInposition)					? 0x0001 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bYRun)							? 0x0002 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1InitialEnd)					? 0x0004 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Initializing)					? 0x0008 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Inposition)					? 0x0010 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Run)							? 0x0020 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2InitialEnd)					? 0x0040 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Initializing)					? 0x0080 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Inposition)					? 0x0100 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Run)							? 0x0200 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bM1InitialEnd)					? 0x0400 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bM1Initializing)					? 0x0800 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bM1Inposition)					? 0x1000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bM1Run)							? 0x2000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bB1InitialEnd)					? 0x4000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bB1Initializing)					? 0x8000 : 0x0000;

	m_lStatusIO2 += (m_NewStatus.m_bB2InitialEnd)					? 0x10000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bB2Initializing)					? 0x20000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bB2Inposition)					? 0x40000 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bB2Run)							? 0x80000 : 0x0000;
}

void DeviceUMacKunsan8::ReadStatusIO3()
{
	m_lStatusIO3 = 0;
	m_lStatusIO3 += (m_NewStatus.m_bB1Inposition)				? 0x0001 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bB1Run)						? 0x0002 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x0004 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x0008 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLaserShutter2Ext)			? 0x0010 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLaserShutter2Ret)			? 0x0020 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bHeightSensorUp)				? 0x0040 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bHeightSensorDown)			? 0x0080 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bPowerDetectorExt)			? 0x0100 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bPowerDetectorRet)			? 0x0200 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bTableVacuumMotor1)			? 0x0400 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bTableClamp1Sensor)			? 0x0800 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bTableUnclamp1Sensor)		? 0x1000 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bTableClamp2Sensor)			? 0x2000 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bTableUnclamp2Sensor)		? 0x4000 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bHeight2Up)					? 0x0400 : 0x0000;	//20111024 �߰� 
	m_lStatusIO3 += (m_NewStatus.m_bLoaderCartClampSW)			? 0x0800 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLoaderCartUnclampSW)		? 0x1000 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLoaderDoorSW)				? 0x2000 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLoaderElvAlarm)				? 0x4000 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bHeight2Down)				? 0x8000 : 0x0000;

}

void DeviceUMacKunsan8::ReadStatusIO4()
{
	m_lStatusIO4 = 0;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass1Up)				? 0x0001 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass1Down)				? 0x0002 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass1Up)				? 0x0004 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass1Down)				? 0x0008 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass2Up)				? 0x0010 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLaserPass2Down)				? 0x0020 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bTableClamp1Up)				? 0x0040 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bTableClamp1Down)			? 0x0080 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bTableClamp2Up)				? 0x0100 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bTableClamp2Down)			? 0x0200 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLoaderInitialEnd)			? 0x0400 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bUnloaderInitialEnd)			? 0x0800 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bLoaderElvOrigin)			? 0x1000 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bUnloaderElvOrigin)			? 0x2000 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bScannerOn)					? 0x8000 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bAOMPowerOn)					? 0x10000 : 0x0000;	
	m_lStatusIO4 += (m_NewStatus.m_bWaterFlowSensor)			? 0x20000 : 0x0000;

}

BYTE DeviceUMacKunsan8::GetCurrentMode()
{
	if(m_NewStatus.m_bMPGMode)		return MODE_MPG; // MPG
	if(m_NewStatus.m_bManualMode)	return MODE_MANUAL; // manual
	if(m_NewStatus.m_bAutoMode)		return MODE_AUTO; // Auto mode
	return MODE_OFF; // off
}

BYTE DeviceUMacKunsan8::GetCurrentCycle()
{
	return m_cCycleStart;  // 1 : start, 2 : stop
}

void DeviceUMacKunsan8::SetCurrentCycle(BYTE cCycle)
{
	m_cCycleStart = cCycle;
}

BYTE DeviceUMacKunsan8::GetCurrentEMStop()
{
	return (BYTE)m_NewStatus.m_bEMStopSW;
}

BYTE DeviceUMacKunsan8::GetCurrentPowerMeter()
{
	if(m_NewStatus.m_bPowerDetectorExt)
	{
		if(m_NewStatus.m_bPowerDetectorRet)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bPowerDetectorRet)
			return 2; // close
		else
			return 3; // half
	}
}

BYTE DeviceUMacKunsan8::GetCurrentShutter1()
{
	if(m_NewStatus.m_bLaserShutter1Ret) 
	{
		if(m_NewStatus.m_bLaserShutter1Ext)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bLaserShutter1Ext)
			return 2; // close
		else
			return 3; //1; // half
	}
}

BYTE DeviceUMacKunsan8::GetCurrentShutter2()
{
	if(m_NewStatus.m_bLaserShutter2Ret) 
	{
		if(m_NewStatus.m_bLaserShutter2Ext)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bLaserShutter2Ext)
			return 2; // close
		else
			return 3; //1; // half
	}
}

BYTE DeviceUMacKunsan8::GetCurrentLoadDetect()
{
	return (BYTE)(((m_NewStatus.m_bLoaderPicker2SheetDetect << 1) & 0x02) +  m_NewStatus.m_bLoaderPicker1SheetDetect); 
}

BYTE DeviceUMacKunsan8::GetCurrentUnloadDetect()
{
	return (BYTE)(((m_NewStatus.m_bUnloaderPicker2SheetDetect << 1) & 0x02) +  m_NewStatus.m_bUnloaderPicker1SheetDetect);
}

BYTE DeviceUMacKunsan8::GetCurrentSuction()
{
	return (BYTE)(m_NewStatus.m_bTableVacuumPressSW1 +
			((m_NewStatus.m_bTableVacuumPressSW2 << 1) & 0x02));
//			((m_NewStatus.m_bTableVacuumPressSW1 << 2) & 0x04) +
//			((m_NewStatus.m_bTableVacuumPressSW2 << 3) & 0x08));
}

BOOL DeviceUMacKunsan8::GetCurrentVacuum(BOOL b1st)
{
	if(b1st)
	{
		if(m_NewStatus.m_bTableVacuumPumpSol1)
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if(m_NewStatus.m_bTableVacuumPumpSol2)
			return TRUE;
		else
			return FALSE;
	}
}

BOOL DeviceUMacKunsan8::GetCurrentVacuumMotor(BOOL b1st)
{
	return TRUE;
/*
	if(b1st)
	{
		if(m_NewStatus.m_bTableVacuumMotor1)
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if(m_NewStatus.m_bTableVacuumMotor2)
			return TRUE;
		else
			return FALSE;
	}
*/
}

BYTE DeviceUMacKunsan8::GetExternalLaser()
{
	return m_NewStatus.m_bExternalLaserShotSW;
}

BOOL DeviceUMacKunsan8::GetCurrentHeight(BOOL bFirst, BOOL bDown)
{
	if(bFirst)
	{
		if(bDown == TRUE)
			return m_NewStatus.m_bHeightSensorDown & !m_NewStatus.m_bHeightSensorUp;
		// Height Sensor Up
		return m_NewStatus.m_bHeightSensorUp & !m_NewStatus.m_bHeightSensorDown;
	}
	else
	{
//		return TRUE;

		if(bDown == TRUE)
			return m_NewStatus.m_bHeight2Down & !m_NewStatus.m_bHeight2Up;
		// Height Sensor Up
		return m_NewStatus.m_bHeight2Up & !m_NewStatus.m_bHeight2Down;

// 		if(bDown == TRUE)
// 			return m_NewStatus.m_bHeightSensor2Down;
// 		// Height Sensor Up
// 		return m_NewStatus.m_bHeightSensor2Up;

	}
}

BOOL DeviceUMacKunsan8::SetOutPort(BYTE nPortNo, WORD wOnOff)
{
	BOOL bResult = TRUE;
	switch(nPortNo)
	{
	case PORT_TABLE_SUCTION	:
		bResult = MotionControlDLL_WriteOutputIOBit(2, 0, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 1, !(wOnOff & 0x01));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 2, (wOnOff >> 1) & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 3, !((wOnOff >> 1) & 0x01));
		return bResult;
		break;
	case PORT_HEIGHT_SENSOR	: // up / down
		bResult = MotionControlDLL_WriteOutputIOBit(2, 8, (BOOL)(!wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 9, (BOOL)wOnOff);
		return bResult;
		break;
	case PORT_HEIGHT_SENSOR_2	: // up / down
//		bResult = MotionControlDLL_WriteOutputIOBit(2, 8, (BOOL)(!wOnOff));
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 9, (BOOL)wOnOff);
// 		bResult = MotionControlDLL_WriteOutputIOBit(1, 13, (BOOL)(!wOnOff));
// 		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 14, (BOOL)wOnOff);
// 		return bResult;
// 		break;																
		bResult = MotionControlDLL_WriteOutputIOBit(2, 8, (BOOL)(!wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 9, (BOOL)wOnOff);
		return bResult;
		break;
	case PORT_POWER_METER	: // open close cover
		bResult = MotionControlDLL_WriteOutputIOBit(2, 10, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 11, (BOOL)!wOnOff);
		return bResult;
		break;
	case PORT_SHUTTER_MASTER:
		bResult = MotionControlDLL_WriteOutputIOBit(2, 4, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 5, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_SHUTTER_SLAVE	:
		bResult = MotionControlDLL_WriteOutputIOBit(2, 6, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 7, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_CYCLE_LAMP	: 
		// ���� lamp on/off�� ����ϴ� �κ�, ���� map�󿡼��� temp stop address�̰�
		// ���� PORT_ALRAM�� ����ص� �ɵ�
		bResult = MotionControlDLL_WriteOutputIOBit(0, 7, (wOnOff >> 1) & 0x01);
		return bResult;
		break;
	case PORT_LOADER_LOCK	: // front door lock unlock
		bResult = MotionControlDLL_WriteOutputIOBit(1, 7, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 8, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_UNLOAD_LOCK	: // rear door lock unlock
		bResult = MotionControlDLL_WriteOutputIOBit(1, 9, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 10, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_ALARM	:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 10, wOnOff);
		return bResult;
		break;
	case PORT_PARTICLE_BLOW	:
//		bResult = MotionControlDLL_WriteOutputIOBit(2, 12, (BOOL)(wOnOff));
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 13, (BOOL)(!wOnOff));
//		return bResult;
		break;
	case PORT_LU_DOOR_LOCK	: // system door bypass�� ������?
		bResult = MotionControlDLL_WriteOutputIOBit(1, 5, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_SYSTEM_DOOR_BYPASS:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 5, wOnOff & 0x01);
		return bResult;
		break;
	case PORT_LASER_BYPASS:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 4, wOnOff & 0x01);
		return bResult;
		break;
	case PORT_DRILL_START: // not use : auto use
		return TRUE;
		break;
	case PORT_PCB_SINGLE	:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 14, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 13, (wOnOff >> 1) & 0x01);
		return bResult;
		break;
	case PORT_INITIAL_RESET		:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 0, wOnOff & 0x01);
		SetResetCmd();
		ResetXYZMCPos();
		return bResult;
		break;
	case PORT_MODE_SELECT		:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 3, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 4, (wOnOff >> 1) & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 5, (wOnOff >> 2) & 0x01);
		return bResult;
		break;
	case PORT_CYCLE_MODE		:
//		bResult = MotionControlDLL_WriteOutputIOBit(0, 6, wOnOff & 0x01);
		bResult = MotionControlDLL_WriteOutputIOBit(0, 7, (wOnOff >> 1) & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 8, (wOnOff >> 2) & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 9, (wOnOff >> 4) & 0x01);
		return bResult;
		break;
	case PORT_MPG_MODE			:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 2, wOnOff);
		return bResult;
		break;
	case PORT_LAMP				:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 6, (BOOL)(wOnOff));
		return bResult;
		break;
	case PORT_LASER_SIGNAL		:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 12, (BOOL)(wOnOff));
		return bResult;
		break;
	}
	return 0;
}

BOOL DeviceUMacKunsan8::IsMotorStop(BOOL bFlag)
{
	if (bFlag == FALSE)
		m_bCommandStop = FALSE;
	
	return m_bCommandStop;
}

void DeviceUMacKunsan8::ReadPosition()
{
	m_nInPositionError = 0;
	
	if(m_NewStatus.m_nXCommandPos != m_lWritePos[AXIS_X]) // x command pos , real encoder pos
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 1;
		return;
	}
	if(m_NewStatus.m_nYCommandPos != m_lWritePos[AXIS_Y]) // y
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 2;
		return;
	}
	
	if(m_NewStatus.m_nZ1CommandPos != m_lWritePos[AXIS_Z1]) // z1
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 3;
		return;
	}
	if(m_NewStatus.m_nZ2CommandPos != m_lWritePos[AXIS_Z2]) // z2
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 4;
		return;
	}
	if(m_NewStatus.m_nM1CommandPos != m_lWritePos[AXIS_M]) // M1
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 5;
		return;
	}

	if(m_NewStatus.m_nB1CommandPos != m_lWritePos[AXIS_C]) // B1
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 6;
		return;
	}

	if(m_NewStatus.m_nB2CommandPos != m_lWritePos[AXIS_C2]) // B2
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 8;
		return;
	}

	m_bCommandStop = TRUE;
}

BOOL DeviceUMacKunsan8::IsInPositionThread(int nAxis, BYTE nCommand)
{
	TRACE(_T("InPosition Start  1\n"));

	CString strLog;

	unsigned char ucMode = GetCurrentMode();
	if(ucMode == MODE_MPG || ucMode == MODE_HOME || ucMode == MODE_SAFE)
		return FALSE;

	if(IsSafetyMode())
		return FALSE;

	if(IsMoveEnd(nAxis))
		return TRUE;

	if(m_thdInPosition != NULL && m_nInPositionCount <= 0)
	{
		m_pStopTime.Pause();
		m_pStopTime.StartTime();

		m_nIsInPosition = FALSE;
		m_nInPositionCommand= nCommand;
		m_nInPositionCount = m_thdInPosition->ResumeThread();
		do
		{
			PeekMessage();
#ifndef __TEST__
			Sleep(TIME_STATUS);
#endif
			if(m_nIsInPosition != FALSE)
			{
				m_nInPositionCount = m_thdInPosition->SuspendThread();
				break;
			}
		} while (!m_bPositionStop);

		// by HJ.Cho 2003. 3. 29
		if (m_nIsInPosition == -1)
		{
			switch(m_nInPositionError)
			{
				case 1:
					ErrMsgDlg(STDGNALM404); // X
					break;
				case 2:
					ErrMsgDlg(STDGNALM405); // Y
					break;
				case 3:
					ErrMsgDlg(STDGNALM406); // Z1
					break;
				case 4:
					ErrMsgDlg(STDGNALM407); // Z2
					break;
				case 5:
					ErrMsgDlg(STDGNALM408); // M					
					break;
				case 6:
					ErrMsgDlg(STDGNALM410); // C
					break;
				case 7:
					ErrMsgDlg(STDGNALM409); // M2
					break;
				case 8:
					ErrMsgDlg(STDGNALM411); // C2
					break;
#ifdef __SERVO_MOTOR__
				case 9 :
					ErrMsgDlg(STDGNALM990); // C2
					break;
#endif
			}
		}
		else if (m_nIsInPosition == -2)
			ErrMessage(_T("Socket time error !!!"));
		else if (m_nIsInPosition == -3)
			m_nIsInPosition = TRUE;

		return m_nIsInPosition;
	}
	TRACE(_T("InPos Thread Error\n"));
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsMoveEnd(int nAxis)
{
	if(nAxis == -1) // all axis
	{
		BOOL bCol1 = TRUE, bMask2 = TRUE, bCol2 = TRUE;
		bCol1 = m_NewStatus.m_bB1Inposition;
		bCol2 = m_NewStatus.m_bB2Inposition;

		if(!m_NewStatus.m_bXInposition || abs(m_lWritePos[AXIS_X] - m_NewStatus.m_nXActualPos) > 2)	
		{
			m_nInPositionError = 1;
			return FALSE;
		}
		if(!m_NewStatus.m_bYInposition || abs(m_lWritePos[AXIS_Y] - m_NewStatus.m_nYActualPos) > 2)	
		{
			m_nInPositionError = 2;
			return FALSE;
		}
		if(!m_NewStatus.m_bZ1Inposition || abs(m_lWritePos[AXIS_Z1] - m_NewStatus.m_nZ1ActualPos) > 2)	
		{
			m_nInPositionError = 3;
			return FALSE;
		}
		if(!m_NewStatus.m_bZ2Inposition || abs(m_lWritePos[AXIS_Z2] - m_NewStatus.m_nZ2ActualPos) > 2)	
		{
			m_nInPositionError = 4;
			return FALSE;
		}
		if(!m_NewStatus.m_bM1Inposition || abs(m_lWritePos[AXIS_M] - m_NewStatus.m_nM1ActualPos) > 2)	
		{
			m_nInPositionError = 5;
			return FALSE;
		}

		if(!bCol1 || abs(m_lWritePos[AXIS_C] - m_NewStatus.m_nB1ActualPos) > 2)							
		{
			m_nInPositionError = 6;
			return FALSE;
		}

		if(!bCol2 || abs(m_lWritePos[AXIS_C2] - m_NewStatus.m_nB2ActualPos) > 2)							
		{
			m_nInPositionError = 8;
			return FALSE;
		}

		
		return (m_bCommandStop & m_NewStatus.m_bXInposition & m_NewStatus.m_bYInposition &
				m_NewStatus.m_bZ1Inposition & m_NewStatus.m_bZ2Inposition & m_NewStatus.m_bM1Inposition &
				bCol1 & bMask2 & bCol2);
	}
	else
	{
		switch(nAxis)
		{
		case AXIS_X:
			if( abs(m_NewStatus.m_nXCommandPos - m_NewStatus.m_nXActualPos) < 3
				&& m_NewStatus.m_bXInposition)
				return TRUE;
			m_nInPositionError = 1;
			break;
		case AXIS_Y:
			if( abs(m_NewStatus.m_nYCommandPos - m_NewStatus.m_nYActualPos) < 3
				&& m_NewStatus.m_bYInposition)
			return TRUE;
			m_nInPositionError = 2;
			break;
		case AXIS_Z1:
			if( abs(m_NewStatus.m_nZ1CommandPos - m_NewStatus.m_nZ1ActualPos) < 3
				&& m_NewStatus.m_bZ1Inposition)
			return TRUE;
			m_nInPositionError = 3;
			break;
		case AXIS_Z2:
			if( abs(m_NewStatus.m_nZ2CommandPos - m_NewStatus.m_nZ2ActualPos) < 3
				&& m_NewStatus.m_bZ2Inposition)
			return TRUE;
			m_nInPositionError = 4;
			break;
		case AXIS_M:
			if( abs(m_NewStatus.m_nM1CommandPos - m_NewStatus.m_nM1ActualPos) < 3
				&& m_NewStatus.m_bM1Inposition)
			return TRUE;	
			m_nInPositionError = 5;
			break;
		case AXIS_C:
			if( abs(m_NewStatus.m_nB1CommandPos - m_NewStatus.m_nB1ActualPos) < 3
				&& m_NewStatus.m_bB1Inposition)
			return TRUE;
			m_nInPositionError = 6;
			break;
		case AXIS_C2:
			if( abs(m_NewStatus.m_nB2CommandPos - m_NewStatus.m_nB2ActualPos) < 3
				&& m_NewStatus.m_bB2Inposition)
			return TRUE;
			m_nInPositionError = 8;
			break;

		default:
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsMotorOrigin(int nAxis)
{
	if(nAxis == -1) // all axis
	{
		BOOL bCol1 = TRUE, bMask2 = TRUE, bCol2 = TRUE;
		bCol1 = m_NewStatus.m_bB1InitialEnd;
//		bCol2 = m_NewStatus.m_bB2InitialEnd;
		
		return (m_NewStatus.m_bXInitialEnd & m_NewStatus.m_bYInitialEnd &
			m_NewStatus.m_bZ1InitialEnd & m_NewStatus.m_bZ2InitialEnd & m_NewStatus.m_bM1InitialEnd &
			bCol1 & bMask2 & bCol2 & m_NewStatus.m_bLoaderInitialEnd & m_NewStatus.m_bUnloaderInitialEnd);
	}
	else
	{
		switch(nAxis)
		{
		case AXIS_X:
			if(m_NewStatus.m_bXInitialEnd)
				return TRUE;
			break;
		case AXIS_Y:
			if(m_NewStatus.m_bYInitialEnd)
				return TRUE;
			break;
		case AXIS_Z1:
			if(m_NewStatus.m_bZ1InitialEnd)
				return TRUE;
			break;
		case AXIS_Z2:
			if(m_NewStatus.m_bZ2InitialEnd)
				return TRUE;
			break;
		case AXIS_M:
			if(m_NewStatus.m_bM1InitialEnd)
				return TRUE;					
			break;
		case AXIS_C:
			if(m_NewStatus.m_bB1InitialEnd)
				return TRUE;
			break;
		case AXIS_C2:
			if(m_NewStatus.m_bB2InitialEnd)
				return TRUE;
			break;
		case AXIS_L_CARRIER:
			if(m_NewStatus.m_bLoaderInitialEnd)
				return TRUE;
			break;
		case AXIS_UL_CARRIER:
			if(m_NewStatus.m_bUnloaderInitialEnd)
				return TRUE;
			break;
		default:
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::PeekMessage()
{
	MSG msg;
	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsAnyMotorRun()
{
	return (m_NewStatus.m_bXRun | m_NewStatus.m_bYRun | m_NewStatus.m_bZ1Run | m_NewStatus.m_bZ2Run 
		| m_NewStatus.m_bB1Run | m_NewStatus.m_bM1Run | m_NewStatus.m_bB2Run);
}

BOOL DeviceUMacKunsan8::InPositionStop()
{
	m_nIsInPosition = -3;
	return TRUE;
}

int DeviceUMacKunsan8::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INPOSITION);
	}
	return IsMoveEnd(nAxis);
}

int DeviceUMacKunsan8::IsInOrigin(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INORIGIN);
	}
	return IsMotorOrigin(nAxis);
}

BOOL DeviceUMacKunsan8::IsLoader(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_LOADSTOP);
		return IsInPositionThread(-1, COMMAND_LOADMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bPCBLoadEnd; 
	return m_NewStatus.m_bPCBLoading;//TRUE;
}

BOOL DeviceUMacKunsan8::IsUnload(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_UNLOADSTOP);
		return IsInPositionThread(-1, COMMAND_UNLOADMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bPCBUnloadEnd;//2;
	return m_NewStatus.m_bPCBUnloading;
}

BOOL DeviceUMacKunsan8::IsAligner(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_ALIGNERSTOP);
		return IsInPositionThread(-1, COMMAND_ALIGNERMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bLoaderAlignEnd;
	return m_NewStatus.m_bLoaderAligning;
}

BOOL DeviceUMacKunsan8::IsUnloadertoLoadStart()
{
	return m_NewStatus.m_bPCBLoadRequestReady;
}

BOOL DeviceUMacKunsan8::IsReady(int nAxis)
{
	return (m_NewStatus.m_bMainRunReady & m_NewStatus.m_bLoaderRunReady & m_NewStatus.m_bUnloaderRunReady);
}

BOOL DeviceUMacKunsan8::IsFlowWater()
{
	return m_NewStatus.m_bWaterFlowSensor;
}

BOOL DeviceUMacKunsan8::IsLaserSystemWarning()
{
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsLaserOverTempFault()
{
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsLoaderStop()
{
	return FALSE;
//	return m_NewStatus.m_bLoadDoorOpenError;
}

BOOL DeviceUMacKunsan8::IsUnLoaderStop()
{
	return FALSE;
//	return m_NewStatus.m_bUnloadDoorOpenError;
}

UINT DeviceUMacKunsan8::IsScannerFault()
{
	UINT nIsFault = 0;
	
//	nIsFault += (m_NewStatus.m_bX1ScannerFault) ? 1 : 0;
//	nIsFault += (m_NewStatus.m_bY1ScannerFault) ? 2 : 0;
//	nIsFault += (m_NewStatus.m_bX2ScannerFault) ? 4 : 0;
//	nIsFault += (m_NewStatus.m_bY2ScannerFault) ? 8 : 0;


	return nIsFault = 0;
}

BOOL DeviceUMacKunsan8::IsSystemDoorBypass()
{
	return m_NewStatus.m_bDoorInterlockBypass;
}

BOOL DeviceUMacKunsan8::IsMainDoorStop()
{
	 return m_NewStatus.m_bFrontDoorOpenAlarm;
}

BOOL DeviceUMacKunsan8::IsOpticsDoorStop()
{
	return m_NewStatus.m_bRearDoorOpenAlarm;
}

BOOL DeviceUMacKunsan8::LoaderElvOriginPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C0, 2);
}

BOOL DeviceUMacKunsan8::LoaderElvLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C0, 1);
}

BOOL DeviceUMacKunsan8::LoaderCarrierLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 3);
}

BOOL DeviceUMacKunsan8::LoaderCarrierAlignPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 2);
}

BOOL DeviceUMacKunsan8::LoaderCarrierAlignPos2()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::UnloaderElvOriginPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D0, 2);
}

BOOL DeviceUMacKunsan8::UnloaderElvUnloadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D0, 1);
}

BOOL DeviceUMacKunsan8::UnloaderCarrierTablePos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D1, 2);
}

BOOL DeviceUMacKunsan8::UnloaderCarrierUnloadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D1, 3);
}

BOOL DeviceUMacKunsan8::LoaderPicker1Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 1);
}

BOOL DeviceUMacKunsan8::LoaderPicker1Align()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 2);
}

BOOL DeviceUMacKunsan8::LoaderPicker1Load()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 4);
}

BOOL DeviceUMacKunsan8::LoaderPicker1P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 3);
}

BOOL DeviceUMacKunsan8::LoaderPicker2Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 1);
}

BOOL DeviceUMacKunsan8::LoaderPicker2Align()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 2);
}

BOOL DeviceUMacKunsan8::LoaderPicker2Load()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 4);
}

BOOL DeviceUMacKunsan8::LoaderPicker2P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 3);
}

BOOL DeviceUMacKunsan8::LoaderClampForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 6, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 7, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderClampBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 6, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 7, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderVacuum1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 5, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 6, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderVacuum1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 5, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 6, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderVacuum2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 15, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 0, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderVacuum2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 15, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 0, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderBlow1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 7, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 8, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderBlow1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 7, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 8, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderBlow2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 1, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 2, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderBlow2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 1, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 2, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderTableForward() // ���̺� ��������
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 14, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 15, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderTableBackward() // ���̺� ��������
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 14, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 15, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderAlignXForward() // ����� ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 12, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 13, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderAlignXBackward() // ����� ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 12, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 13, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderAlignYForward() // sheet table ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 10, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 11, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::LoaderAlignYBackward() // sheet table ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 10, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 11, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderPicker1Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 1);
}

BOOL DeviceUMacKunsan8::UnloaderPicker1Table()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 2);
}

BOOL DeviceUMacKunsan8::UnloaderPicker1Unload()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 4);
}

BOOL DeviceUMacKunsan8::UnloaderPicker1P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 3);
}

BOOL DeviceUMacKunsan8::UnloaderPicker2Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 1);
}

BOOL DeviceUMacKunsan8::UnloaderPicker2Table()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 2);
}

BOOL DeviceUMacKunsan8::UnloaderPicker2Unload()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 4);
}

BOOL DeviceUMacKunsan8::UnloaderPicker2P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 3);
}

BOOL DeviceUMacKunsan8::UnloaderClampForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 6, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 7, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderClampBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 6, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 7, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderVacuum1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 5, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 6, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderVacuum1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 5, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 6, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderVacuum2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 15, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 0, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderVacuum2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 15, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 0, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderBlow1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 7, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 8, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderBlow1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 7, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 8, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderBlow2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 1, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 2, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderBlow2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 1, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 2, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderTableForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 14, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 15, 0);
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderTableBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 14, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 15, 1);
	return bResult;
}

BOOL DeviceUMacKunsan8::IsFluorescentLampOn()
{
	if(m_NewStatus.m_bFluorescentLamp)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker1PCBExist()
{
	if(m_NewStatus.m_bLoaderPicker1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker2PCBExist()
{
	if(m_NewStatus.m_bLoaderPicker2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsAlignerPCBExist()
{
	if(m_NewStatus.m_bLoaderAlignTablePCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsULAlignerPCBExist()
{
	if(m_NewStatus.m_bUnloaderPCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::TablePCBReset()
{
	return MotionControlDLL_WriteOutputIOBit(1, 1, 1);
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker1PCBExist()
{
	if(m_NewStatus.m_bUnloader1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker2PCBExist()
{
	if(m_NewStatus.m_bUnloader2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsTable1PCBExist()
{
	if(m_NewStatus.m_b1stTablePCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsTable2PCBExist()
{
	if(m_NewStatus.m_b2ndTablePCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacKunsan8::IsLoader1Error()
{
	BOOL bError = FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPad1UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPad1DownError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPad2UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPad2DownError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadLeftPickerVacuumOnError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerVacuumOffError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerBlowOnError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPCBExistError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadLeftPickerPCBNotExistError)	bError = bError | TRUE;
	else												bError = bError | FALSE;
		
	return bError;
}

BOOL DeviceUMacKunsan8::IsLoader2Error()
{
	BOOL bError = FALSE;

	if(m_NewStatus.m_bLoadRightPickerPad1UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerPad1DownError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerPad2UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerPad2DownError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerVacuumOnError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerVacuumOffError)	bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerBlowOnError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerPCBExistError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bLoadRightPickerPCBNotExistError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacKunsan8::IsAlignerError()
{
	BOOL bError = FALSE;

	if(m_NewStatus.m_bLoadAlignTablePCBNotExistError ||
		m_NewStatus.m_bLoadAlignTablePCBExistError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignSheetTableForwardError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignSheetTableBackwardError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignGuideForwardError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignGuideBackwardError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignTableMoveLeftError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bLoadAlignTableMoveRightError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacKunsan8::IsULAlignerError()
{
	BOOL bError = FALSE;
	
	if(m_NewStatus.m_bUnloadTablePCBNotExistError || 
		m_NewStatus.m_bUnloadTablePCBExistError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bUnloadAlignTableMoveLeftError)	bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	if(m_NewStatus.m_bUnloadAlignTableMoveRightError)	bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	return bError;
}

BOOL DeviceUMacKunsan8::IsUnloader1Error()
{
	BOOL bError = FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPCBExistError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPCBNotExistError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPad1UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPad1DownError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPad2UpError)		bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerPad2DownError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerVacuumOnError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerVacuumOffError)	bError = bError | TRUE;
	else												bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadLeftPickerBlowOnError)		bError = bError | TRUE;
	else												bError = bError | FALSE;
	
	return bError;
}

BOOL DeviceUMacKunsan8::IsUnloader2Error()
{
	BOOL bError = FALSE;

	if(m_NewStatus.m_bUnloadRightPickerPCBExistError)		bError = bError | TRUE;
	else													bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadRightPickerPCBNotExistError)	bError = bError | TRUE;
	else													bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadRightPickerPad1UpError)			bError = bError | TRUE;
	else													bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadRightPickerPad1DownError)		bError = bError | TRUE;
	else													bError = bError | FALSE;

	if(m_NewStatus.m_bUnloadRightPickerPad2UpError)			bError = bError | TRUE;
	else													bError = bError | FALSE;
	
	return bError;
}

BOOL DeviceUMacKunsan8::IsTable1Error()
{
	BOOL bError = FALSE;

//	if(m_NewStatus.m_bTableVacuumMotor1OnError)		bError = bError | TRUE;
//	else											bError = bError | FALSE;

//	if(m_NewStatus.m_bTableVacuumMotor1OffError)	bError = bError | TRUE;
//	else											bError = bError | FALSE;

	if(m_NewStatus.m_b1stTableVacuumOnError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	if(m_NewStatus.m_b1stTableVacuumOffError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacKunsan8::IsTable2Error()
{
	BOOL bError = FALSE;

//	if(m_NewStatus.m_bTableVacuumMotor2OnError)		bError = bError | TRUE;
//	else											bError = bError | FALSE;

//	if(m_NewStatus.m_bTableVacuumMotor2OffError)	bError = bError | TRUE;
//	else											bError = bError | FALSE;

	if(m_NewStatus.m_b2ndTableVacuumOnError)		bError = bError | TRUE;
	else											bError = bError | FALSE;
	
	if(m_NewStatus.m_b2ndTableVacuumOffError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacKunsan8::Loader1PCBExist(BOOL bOn)
{
	BOOL bResult;
	
	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 6, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 7, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 6, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 7, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::Loader2PCBExist(BOOL bOn)
{
	BOOL bResult;
	
	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 8, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 9, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 8, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 9, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::AlignTablePCBExist(BOOL bOn)
{
	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 10, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 10, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::ULAlignTablePCBExist(BOOL bOn)
{
	BOOL bResult;
	
	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::Unloader1PCBExist(BOOL bOn)
{
	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 7, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 7, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::Unloader2PCBExist(BOOL bOn)
{
	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 9, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 9, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::UnloadTablePCBExist(BOOL bOn)
{
	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::Table1VacuumMotor(BOOL bOn)
{
	return TRUE;

	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 11, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 12, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 11, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 12, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::Table2VacuumMotor(BOOL bOn)
{
	return TRUE;

	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 13, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 14, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 13, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 14, 1);
		return bResult;
	}
}

BOOL DeviceUMacKunsan8::LoaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
	BOOL bResult = TRUE;

	if(nPicker == 1)
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	else
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	return bResult;
}

BOOL DeviceUMacKunsan8::UnloaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
	BOOL bResult = TRUE;
	if(nPicker == 1)
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	else
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	return bResult;
}

void DeviceUMacKunsan8::SetInitialCmd()
{
	m_lWritePos[AXIS_X] = m_NewStatus.m_nXCommandPos;
	m_lWritePos[AXIS_Y] = m_NewStatus.m_nYCommandPos;
	m_lWritePos[AXIS_Z1] = m_NewStatus.m_nZ1CommandPos;
	m_lWritePos[AXIS_Z2] = m_NewStatus.m_nZ2CommandPos;
	m_lWritePos[AXIS_M] = m_NewStatus.m_nM1CommandPos;

	m_lWritePos[AXIS_C] = m_NewStatus.m_nB1CommandPos;
	m_lWritePos[AXIS_C2] = m_NewStatus.m_nB2CommandPos;
}

void DeviceUMacKunsan8::SetResetCmd()
{
	m_lWritePos[AXIS_X] = 0;
	m_lWritePos[AXIS_Y] = 0;
	m_lWritePos[AXIS_Z1] = 0;
	m_lWritePos[AXIS_Z2] = 0;
	m_lWritePos[AXIS_M] = 0;
	
#ifdef __COLLIMATOR
	m_lWritePos[AXIS_C] = 0;
#endif
	
#ifdef __SECOND_OPTICS
	m_lWritePos[AXIS_M2] = 0;
	
#ifdef __COLLIMATOR
	m_lWritePos[AXIS_C2] = 0;
#endif
	
#endif
}

BOOL DeviceUMacKunsan8::IsCmdPosOK()
{
	if(m_NewStatus.m_nXCommandPos != m_lWritePos[AXIS_X]) // x command pos , real encoder pos
	{
		return FALSE;
	}
	if(m_NewStatus.m_nYCommandPos  != m_lWritePos[AXIS_Y]) // y
	{
		return FALSE;
	}
	if(m_NewStatus.m_nZ1CommandPos  != m_lWritePos[AXIS_Z1]) // z1
	{
		return FALSE;
	}
	if(m_NewStatus.m_nZ2CommandPos  != m_lWritePos[AXIS_Z2]) // z2
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL DeviceUMacKunsan8::SetMoveIO(int nMoveAxis)
{
	if(nMoveAxis == MOVE_XYZ)
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	else if(nMoveAxis == MOVE_XY)
		return MotionControlDLL_WriteOutputDWord(0x610B0, 5);
	else if(nMoveAxis == MOVE_XYMC)
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
		MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
		MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
		MotionControlDLL_WriteOutputDWord(0x610B5, 2));
	else if(nMoveAxis == MOVE_XYZMC)
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B5, 2));
	else if(nMoveAxis == MOVE_XYMCA)
	{
		BOOL bResult = TRUE;
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 5);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B1, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B2, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B3, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B4, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B5, 2);
		return bResult;
	}
	else
		return TRUE;
}

BOOL DeviceUMacKunsan8::MotorMoveXYDownOnly(double dPosX, double dPosY, BOOL b1stPanel)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XY2] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	return bResult;
}

BOOL DeviceUMacKunsan8::MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[XYZ2] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	return bResult;
}

int DeviceUMacKunsan8::InPositionIO(int nAxis)
{
	::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition), &m_NewStatus);
	
	if(nAxis & 0x0001)
	{
		if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
			return IND_X;
	
		if(!m_NewStatus.m_bXInposition)
			return IND_X;
	}

	if(nAxis >> 1 & 0x0001)
	{
		if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>2) // y
			return IND_Y;
		
		if(!m_NewStatus.m_bYInposition)
			return IND_Y;
	}

	if(nAxis >> 2 & 0x0001)
	{
		if(abs(m_NewStatus.m_nZ1ActualPos  - m_lWritePos[AXIS_Z1])>2) // z1
			return IND_Z1;
		
		if(!m_NewStatus.m_bZ1Inposition)
			return IND_Z1;
	}

	if(nAxis >> 3 & 0x0001)
	{
		if(abs(m_NewStatus.m_nZ2ActualPos  - m_lWritePos[AXIS_Z2])>2) // z2
			return IND_Z2;
		
		if(!m_NewStatus.m_bZ2Inposition)
			return IND_Z2;
	}

	if(nAxis >> 4 & 0x0001)
	{
		if(abs(m_NewStatus.m_nM1ActualPos  - m_lWritePos[AXIS_M])>2) // m
			return IND_M1;
		
		if(!m_NewStatus.m_bM1Inposition)
			return IND_M1;
	}


	if(nAxis >> 5 & 0x0001)
	{
		if(abs(m_NewStatus.m_nB1ActualPos  - m_lWritePos[AXIS_C])>2) // c
			return IND_C1;
		
		if(!m_NewStatus.m_bB1Inposition)
			return IND_C1;
	}

	return ALL_AXIS_OK;
}

BOOL DeviceUMacKunsan8::InPositionStop2(int nAxis)
{
	// nAxis 0 : xy, 1: z1z2, 2: xyz1z2, 3: mc, 4: z1z2mc, 5:xyz1z2mc, 6: z1, 7: z2;

	::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition), &m_NewStatus);
	
	CString strErr;

	switch(nAxis)
	{
	case 0:
		if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
		{
//			strErr.Format(_T("X Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>2) // y
		{
//			strErr.Format(_T("Y Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bXInposition)
		{
//			strErr.Format(_T("XInposErr : %f, %f"), m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bYInposition)
		{
//			strErr.Format(_T("YInposErr : %f, %f"), m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}
		break;
	case 1:
		if(abs(m_NewStatus.m_nZ1ActualPos - m_lWritePos[AXIS_Z1])>2)
		{
//			strErr.Format(_T("Z1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(abs(m_NewStatus.m_nZ2ActualPos - m_lWritePos[AXIS_Z2])>2)
		{
//			strErr.Format(_T("Z2 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bZ1Inposition)
		{
//			strErr.Format(_T("Z1InposErr : %f, %f"), m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bZ2Inposition)
		{
//			strErr.Format(_T("Z2InposErr : %f, %f"), m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		break;
	case 2:
		if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
		{
//			strErr.Format(_T("X Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>2) // y
		{
//			strErr.Format(_T("Y Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(abs(m_NewStatus.m_nZ1ActualPos - m_lWritePos[AXIS_Z1])>2)
		{
//			strErr.Format(_T("Z1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nZ2ActualPos - m_lWritePos[AXIS_Z2])>2)
		{
//			strErr.Format(_T("Z2 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bXInposition)
		{
//			strErr.Format(_T("XInposErr : %f, %f"), m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bYInposition)
		{
//			strErr.Format(_T("YInposErr : %f, %f"), m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ1Inposition)
		{
//			strErr.Format(_T("Z1InposErr : %f, %f", m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ2Inposition)
		{
//			strErr.Format(_T("Z2InposErr : %f, %f"), m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		break;
	case 3:
		if(m_NewStatus.m_nM1ActualPos != m_lWritePos[AXIS_M])
		{
//			strErr.Format(_T("M1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(m_NewStatus.m_nB1ActualPos != m_lWritePos[AXIS_C])
		{
//			strErr.Format(_T("C1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bM1Inposition)
		{
//			strErr.Format(_T("M1InposErr : %f, %f"), m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bB1Inposition)
		{
//			strErr.Format(_T("C1InposErr : %f, %f"), m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(m_NewStatus.m_nB2ActualPos != m_lWritePos[AXIS_C2])
			return FALSE;

		if(!m_NewStatus.m_bB2Inposition)
			return FALSE;

		break;
	case 4:
		if(abs(m_NewStatus.m_nZ1ActualPos - m_lWritePos[AXIS_Z1])>2)
		{
//			strErr.Format(_T("Z1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nZ2ActualPos - m_lWritePos[AXIS_Z2])>2)
		{
//			strErr.Format(_T("Z2 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ1Inposition)
		{
//			strErr.Format(_T("Z1InposErr : %f, %f"), m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ2Inposition)
		{
//			strErr.Format(_T("Z2InposErr : %f, %f"), m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(m_NewStatus.m_nM1ActualPos != m_lWritePos[AXIS_M])
		{
//			strErr.Format(_T("M1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(m_NewStatus.m_nB1ActualPos != m_lWritePos[AXIS_C])
		{
//			strErr.Format(_T("C1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bM1Inposition)
		{
//			strErr.Format(_T("M1InposErr : %f, %f"), m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(!m_NewStatus.m_bB1Inposition)
		{
//			strErr.Format(_T("C1InposErr : %f, %f"), m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}

		if(m_NewStatus.m_nB2ActualPos != m_lWritePos[AXIS_C2])
			return FALSE;

		if(!m_NewStatus.m_bB2Inposition)
			return FALSE;

		break;
	case 5:
		if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
		{
//			strErr.Format(_T("X Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>2) // y
		{
//			strErr.Format(_T("Y Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bXInposition)
		{
//			strErr.Format(_T("XInposErr : %f, %f"), m_NewStatus.m_nXActualPos, m_lWritePos[AXIS_X]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bYInposition)
		{
//			strErr.Format(_T("YInposErr : %f, %f"), m_NewStatus.m_nYActualPos, m_lWritePos[AXIS_Y]);
//			WriteLog(strErr);
			return FALSE;
		}
		if(abs(m_NewStatus.m_nZ1ActualPos - m_lWritePos[AXIS_Z1])>2)
		{
//			strErr.Format(_T("Z1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(abs(m_NewStatus.m_nZ2ActualPos - m_lWritePos[AXIS_Z2])>2)
		{
//			strErr.Format(_T("Z2 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ1Inposition)
		{
//			strErr.Format(_T("Z1InposErr : %f, %f"), m_NewStatus.m_nZ1ActualPos, m_lWritePos[AXIS_Z1]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bZ2Inposition)
		{
//			strErr.Format(_T("Z2InposErr : %f, %f"), m_NewStatus.m_nZ2ActualPos, m_lWritePos[AXIS_Z2]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(m_NewStatus.m_nM1ActualPos != m_lWritePos[AXIS_M])
		{
//			strErr.Format(_T("M1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(m_NewStatus.m_nB1ActualPos != m_lWritePos[AXIS_C])
		{
//			strErr.Format(_T("C1 Compare Err : (%f, %f)"), 
//				m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bM1Inposition)
		{
//			strErr.Format(_T("M1InposErr : %f, %f"), m_NewStatus.m_nM1ActualPos, m_lWritePos[AXIS_M]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(!m_NewStatus.m_bB1Inposition)
		{
//			strErr.Format(_T("C1InposErr : %f, %f"), m_NewStatus.m_nC1ActualPos, m_lWritePos[AXIS_C]);
//			WriteLog(strErr);
			return FALSE;
		}
		
		if(m_NewStatus.m_nB2ActualPos != m_lWritePos[AXIS_C2])
			return FALSE;
		
		if(!m_NewStatus.m_bB2Inposition)
			return FALSE;
		break;
	case 6:
		if(abs(m_NewStatus.m_nZ1ActualPos - m_lWritePos[AXIS_Z1])>2)
			return FALSE;
		
		if(!m_NewStatus.m_bZ1Inposition)
			return FALSE;
		break;
	case 7:
		if(abs(m_NewStatus.m_nZ2ActualPos - m_lWritePos[AXIS_Z2])>2)
			return FALSE;
		
		if(!m_NewStatus.m_bZ2Inposition)
			return FALSE;
		break;
	}
	
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLCinCartPos()
{
	return m_NewStatus.m_bLCInCartPosition;
}

BOOL DeviceUMacKunsan8::IsLCinLoadPos()
{
	return m_NewStatus.m_bLCInUnloadPosition;
}

BOOL DeviceUMacKunsan8::IsLCinOriginPos()
{
	return m_NewStatus.m_bLCInOriginPosition;
}

BOOL DeviceUMacKunsan8::IsLCinReadyPos()
{
	return m_NewStatus.m_bLCInReadyPosition;
}

BOOL DeviceUMacKunsan8::IsLCinAlignPos()
{
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsUCinAlignPos()
{
	return FALSE;
}

BOOL DeviceUMacKunsan8::IsUCinCartPos()
{
	return m_NewStatus.m_bUCInCartPosition;
//	return TRUE;
}

BOOL DeviceUMacKunsan8::IsUCinUnloadPos()
{
	return m_NewStatus.m_bUCInLoadPosition;
//	return TRUE;
}

BOOL DeviceUMacKunsan8::IsUCinOriginPos()
{
	return m_NewStatus.m_bUCInOriginPosition;
//	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLP1P1Up()
{
	if(m_NewStatus.m_bLoaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick1Pad1Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLP1P2Up()
{
	if(m_NewStatus.m_bLoaderPick1Pad2Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick1Pad2Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLP2P1Up()
{
	if(m_NewStatus.m_bLoaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick2Pad1Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLP2P2Up()
{
	if(m_NewStatus.m_bLoaderPick2Pad2Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick2Pad2Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsULP1P1Up()
{
	if(m_NewStatus.m_bUnloaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick1Pad1Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsULP1P2Up()
{
	if(m_NewStatus.m_bUnloaderPick1Pad2Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick1Pad2Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsULP2P1Up()
{
	if(m_NewStatus.m_bUnloaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick2Pad1Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsULP2P2Up()
{
	if(m_NewStatus.m_bUnloaderPick2Pad2Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick2Pad2Down)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLoaderAlignTableForward()
{
	if(m_NewStatus.m_bLoaderAlignTblForward)
		return TRUE;
	else if(m_NewStatus.m_bLoaderAlignTblBackward)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsUnloaderAlignTableForward()
{
	if(m_NewStatus.m_bUnloaderAlignTblForward)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderAlignTblBackward)
		return FALSE;
	
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLoaderCartClamp()
{
	if(m_NewStatus.m_bLoaderCartClampUp)
		return FALSE;
	else if(m_NewStatus.m_bLoaderCartClampDown)
		return TRUE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsAlignSheetTableForward()
{
	if(m_NewStatus.m_bLoaderAlignShtTblForward)
		return TRUE;
	else if(m_NewStatus.m_bLoaderAlignShtTblBackward)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsAlignGuideForward()
{
	if(m_NewStatus.m_bLoaderAlignGuideForward)
		return TRUE;
	else if(m_NewStatus.m_bLoaderAlignGuideBackward)
		return FALSE;

	return TRUE;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker1Vacuum()
{
	BOOL bResult;
	bResult = m_NewStatus.m_bLoaderPicker1Vacuum1;
//	bResult = bResult & m_NewStatus.m_bLoaderPicker1Vacuum2;
	return bResult;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker2Vacuum()
{
	BOOL bResult;
	bResult = m_NewStatus.m_bLoaderPicker2Vacuum1;
//	bResult = bResult & m_NewStatus.m_bLoaderPicker2Vacuum2;
	return bResult;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker1Blow()
{
	return TRUE; //m_NewStatus.m_bLoaderPicker1Vacuum2;
}

BOOL DeviceUMacKunsan8::IsLoaderPicker2Blow()
{
	return TRUE; //m_NewStatus.m_bLoaderPicker2Vacuum2;
}

BOOL DeviceUMacKunsan8::IsUnloaderCartClamp()
{
	if(m_NewStatus.m_bUnloaderCartClampUp)
		return FALSE;
	else if(m_NewStatus.m_bUnloaderCartClampDown)
		return TRUE;
	
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker1Vacuum()
{
	BOOL bResult;
	bResult = m_NewStatus.m_bUnloaderPicker1Vacuum1;
//	bResult = bResult & m_NewStatus.m_bUnloaderPicker1Vacuum2;
	return bResult;
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker2Vacuum()
{
	BOOL bResult;
	bResult = m_NewStatus.m_bUnloaderPicker2Vacuum1;
//	bResult = bResult & m_NewStatus.m_bUnloaderPicker2Vacuum2;
	return bResult;
}

BOOL DeviceUMacKunsan8::IsUnloaderNGBoxForward()
{
	return TRUE; //m_NewStatus.m_bUnloaderPicker1Vacuum2;
}
BOOL DeviceUMacKunsan8::IsUnloaderNGBoxBackward()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker1Blow()
{
	return TRUE; //m_NewStatus.m_bUnloaderPicker1Vacuum2;
}

BOOL DeviceUMacKunsan8::IsUnloaderPicker2Blow()
{
	return TRUE; //m_NewStatus.m_bUnloaderPicker2Vacuum2;
}

BOOL DeviceUMacKunsan8::IsLoadCartNoPCB()
{
	if(m_NewStatus.m_bLoaderElvSheetDetector)
		return FALSE;
	else
		return TRUE;
}

BOOL DeviceUMacKunsan8::SendLoadCartNoPCB()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::TableCalibration(BOOL bAxisX)
{
	BOOL bResult;
	if(bAxisX)
		bResult = MotionControlDLL_WriteOutputIOBit(3, 14, 1);
	else
		bResult = MotionControlDLL_WriteOutputIOBit(3, 15, 1);

	return bResult;
}

BOOL DeviceUMacKunsan8::IsSafetyMode()
{
	return m_NewStatus.m_bSafteyMode;
}

BOOL DeviceUMacKunsan8::TableLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610B0, 6);
}

BOOL DeviceUMacKunsan8::TableUnloadPos(BOOL b1st)
{
	if(b1st)
		return MotionControlDLL_WriteOutputDWord(0x610B0, 7);
	else
		return MotionControlDLL_WriteOutputDWord(0x610B0, 8);
}

BOOL DeviceUMacKunsan8::GetCurrentTableClamp(BOOL b1st, BOOL bClamp)
{
	if(b1st)
	{
		if(bClamp)
			return m_NewStatus.m_bTableClamp1Down;
		else
			return m_NewStatus.m_bTableClamp1Up;
	}
	else
	{
		if(bClamp)
			return m_NewStatus.m_bTableClamp2Down;
		else
			return m_NewStatus.m_bTableClamp2Up;
	}
}

BOOL DeviceUMacKunsan8::TableClamp(BOOL bClamp, double dLimitY, BOOL bLeft)
{
	BOOL bRet = TRUE;
	if(bClamp)
	{
		if(bLeft)
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 4, TRUE); //MotionControlDLL_WriteOutputDWord(0x610B8, 0);
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 5, FALSE); //MotionControlDLL_WriteOutputDWord(0x610B7, 1);
		}
		else
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 6, TRUE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 7, FALSE);
		}
	}
	else
	{
		if(m_NewStatus.m_nYActualPos > dLimitY * 1000.0)
		{
			ErrMessage(IDS_ERR_UNCLAMP_IMPOSSIBLE);
			return FALSE;
		}

		if(bLeft)
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 4, FALSE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 5, TRUE); 
		}
		else
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 6, FALSE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 7, TRUE);
		}
	}
	return bRet;
}

BOOL DeviceUMacKunsan8::WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff)
{
	return MotionControlDLL_WriteOutputIOBit(nAddr, nBit, bOnOff);
}

BOOL DeviceUMacKunsan8::WriteOutputDWord(UINT nAddr, DWORD dwVal)
{
	return MotionControlDLL_WriteOutputDWord(nAddr, dwVal);
}

BOOL DeviceUMacKunsan8::GetCurrentMotorSol()
{
	return TRUE; //m_NewStatus.m_bTableVacuumBypassSol1;
}

BOOL DeviceUMacKunsan8::IsHandlerReady()
{
	return 1;// m_NewStatus.m_bHandlerReady;
}

BOOL DeviceUMacKunsan8::IsHandlerAlarm()
{
	return 0;// m_NewStatus.m_bHandlerAlarm;	
}

BOOL DeviceUMacKunsan8::IsHandlerLotEnd()
{
	return 1;// m_NewStatus.m_bHandlerLotEnd;
}

BOOL DeviceUMacKunsan8::IsHandler1stTableExist()
{
	return 1;// m_NewStatus.m_bHandler1stTableExist;
}

BOOL DeviceUMacKunsan8::IsHandler2ndTableExist()
{
	return 1;// m_NewStatus.m_bHandler2ndTableExist;
}

BOOL DeviceUMacKunsan8::IsHandlerLoadReady()
{
	return 1;// m_NewStatus.m_bHandlerLoadReady;
}

BOOL DeviceUMacKunsan8::IsHandlerLoadEnd()
{
	return 1;// m_NewStatus.m_bHandlerLoadEnd;	
}

BOOL DeviceUMacKunsan8::IsHandlerLoadAlarm()
{
	return 1;// m_NewStatus.m_bHandlerLoadAlarm;	
}

BOOL DeviceUMacKunsan8::IsHandlerUnloadReady()
{
	return 1;// m_NewStatus.m_bHandlerUnloadReady;	
}

BOOL DeviceUMacKunsan8::IsHandlerUnloadEnd()
{
	return 1;// m_NewStatus.m_bHandlerUnloadEnd;	
}

BOOL DeviceUMacKunsan8::IsHandlerUnloadAlarm()
{
	return 1;// m_NewStatus.m_bHandlerUnloadAlarm;	
}

BOOL DeviceUMacKunsan8::MainReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 0, bOn);
}

BOOL DeviceUMacKunsan8::MainAlarm(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 1, bOn);
}

BOOL DeviceUMacKunsan8::MainStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 2, bOn);
}

BOOL DeviceUMacKunsan8::MainStop(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 3, bOn);
}

BOOL DeviceUMacKunsan8::MainReset(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 4, bOn);
}

BOOL DeviceUMacKunsan8::MainUseTable(int nUseTable)
{
	BOOL bRet = MotionControlDLL_WriteOutputIOBit(6, 5, nUseTable & 0x01);
	bRet = bRet & MotionControlDLL_WriteOutputIOBit(6, 6, (nUseTable >> 1) & 0x01);
	return 1;// bRet;
}

BOOL DeviceUMacKunsan8::MainLoadReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 7, bOn);
}

BOOL DeviceUMacKunsan8::MainLoadEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 8, bOn);
}

BOOL DeviceUMacKunsan8::MainUnloadReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 9, bOn);
}

BOOL DeviceUMacKunsan8::MainUnloadEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 10, bOn);
}

BOOL DeviceUMacKunsan8::MainPCBExist(int nPCBExist)
{
	BOOL bRet = MotionControlDLL_WriteOutputIOBit(6, 11, nPCBExist & 0x01);
	bRet = bRet & MotionControlDLL_WriteOutputIOBit(6, 12, (nPCBExist >> 1) & 0x01);
	return 1;// bRet;
}

BOOL DeviceUMacKunsan8::MainLotEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 13, bOn);
}

BOOL DeviceUMacKunsan8::MainLoadStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 14, bOn);
}

BOOL DeviceUMacKunsan8::MainUnloadStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 15, bOn);
}

BOOL DeviceUMacKunsan8::DustSuctionControl(BOOL bLeft, BOOL bUp, double dMin, double dMax)
{
	if(!gSystemINI.m_sHardWare.nDustTableUse)
		return TRUE;

	BOOL bResult;
	if(bLeft)
	{
		if(bUp)
		{
			bResult = MotionControlDLL_WriteOutputDWord(0x610BB, 1);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BC, 0);
		}
		else
		{
			if(m_NewStatus.m_nXActualPos < dMin * 1000.0 || 
				m_NewStatus.m_nXActualPos > dMax * 1000.0)
			{
				ErrMessage(IDS_ERR_DUSTSUCTION_DOWN);
				return FALSE;
			}

			bResult = MotionControlDLL_WriteOutputDWord(0x610BB, 0);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BC, 1);
		}
	}
	else
	{
		if(bUp)
		{
			bResult = MotionControlDLL_WriteOutputDWord(0x610BD, 1);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BE, 0);
		}
		else
		{
			if(m_NewStatus.m_nXActualPos < dMin * 1000.0 || 
				m_NewStatus.m_nXActualPos > dMax * 1000.0)
			{
				ErrMessage(IDS_ERR_DUSTSUCTION_DOWN);
				return FALSE;
			}
			
			bResult = MotionControlDLL_WriteOutputDWord(0x610BD, 0);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BE, 1);
		}
	}
	return bResult;
}

BOOL DeviceUMacKunsan8::WriteLoadUnload(int nAdd, BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, nAdd, bOn);
}

double DeviceUMacKunsan8::GetMPosition(int nIndex)
{
	if(nIndex < 0 || nIndex > 9)
		return 0;
	
	return m_dMaskPosition[nIndex];
}

BOOL DeviceUMacKunsan8::ScannerPower(BOOL bOn)
{
	return MotionControlDLL_WriteOutputIOBit(9, 15, bOn); // PLC��û,��ȣ����
}

BOOL DeviceUMacKunsan8::SetAOMPowerON(BOOL bAomPoweron)
{
	return 	MotionControlDLL_WriteOutputIOBit(9, 12, bAomPoweron);
}

BOOL DeviceUMacKunsan8::CheckAOMFault()
{
	return m_NewStatus.m_bAOMAlarm && m_NewStatus.m_bAOMPowerOn; // 0 : Fault signal
}

BOOL DeviceUMacKunsan8::GetCurrentScannerPower()
{
	return m_NewStatus.m_bScannerOn;
}

BOOL DeviceUMacKunsan8::GetCurrentAOMPower()
{
	return m_NewStatus.m_bAOMPowerOn;
}

// null �Լ�
BOOL DeviceUMacKunsan8::LoaderPCBReset()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::UnLoaderPCBReset()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::TableVacuumSelect(BOOL bOn)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::SetLoaderUnloaderPickerPos(double dLoaderCartPos, double dLoaderCartPos2, double dLoaderLoadPos, double dLoaderLoadPos2, double dLoaderAlignPos, double dUnloaderCartPos, double dUnloaderUnloadPos, double dUnloaderUnloadPos2, double dUnloaderAlignPos)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61113, GetIntPosition(dLoaderCartPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61114, GetIntPosition(dLoaderLoadPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111C, GetIntPosition(dUnloaderCartPos, AXIS_UL_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111B, GetIntPosition(dUnloaderUnloadPos, AXIS_UL_CARRIER));

	return bResult;
//	return TRUE;
}

void DeviceUMacKunsan8::SetFixedMaskPos(double dPos)
{
//	m_dFixedMaskPos = dPos;	
}

BOOL DeviceUMacKunsan8::GetBeamPathStatus(BOOL bUp)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::GetTopHatStatus(BOOL bUp)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
//	bResult = bResult & DownloadPosition(AXIS_A1, dA1);
//	bResult = bResult & DownloadPosition(AXIS_A2, dA2);
	
	return bResult;
}

BOOL DeviceUMacKunsan8::MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));// &
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	//	m_nMaskPos = nMaskPos;
	//	m_nMaskPos2 = nMaskPos2;
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));// &
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveAMC2(double dPosA1, double dPosA2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, BOOL bTophat)	//2011517
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	
	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));// &
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveAMC2(double dPosA1, double dPosA2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat)	//2011517
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));// &
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MotorMoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);//m_dMaskPosition[nPosM]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	//2011520
//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2); 
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) & //C1
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));// &
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::GetScannerStatus()
{
	return m_NewStatus.m_bScannerOn;
}

BOOL DeviceUMacKunsan8::GetAOMStatus()
{
	return m_NewStatus.m_bAOMPowerOn;
}

BOOL DeviceUMacKunsan8::IsHoodOK(BOOL bOpen)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::HoodOpen(BOOL bOpen)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsHandlerPartError(BOOL bLoader)
{
	return FALSE;
}

BOOL DeviceUMacKunsan8::GetResetSWStatus()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::GetAOMAlarm()
{
	return m_NewStatus.m_bAOMAlarm;
}

BOOL DeviceUMacKunsan8::GetCurrentSuctionMotor()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::GetCurrentAcrylSuction(BOOL b1st)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::SetLimitYPos(double dPos)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::UnloaderCarrierAlignPos()
{
	return  TRUE;
}

BOOL DeviceUMacKunsan8::UnloaderNGBoxForward()
{
	return  TRUE;
}

BOOL DeviceUMacKunsan8::UnloaderNGBoxBackward()
{
	return  TRUE;
}

BOOL DeviceUMacKunsan8::SetAlarmTolLed(BOOL bOn)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::LoaderCarrierCartPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 2); //return TRUE;
}

BOOL DeviceUMacKunsan8::LoaderCarrierCartPos2()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsBMMotorHomeEnd()
{
	if(m_NewStatus.m_bM1InitialEnd && !m_NewStatus.m_bM1Initializing &&
		m_NewStatus.m_bB1InitialEnd && !m_NewStatus.m_bB1Initializing &&
		m_NewStatus.m_bB2InitialEnd && !m_NewStatus.m_bB2Initializing)
		return TRUE;

	return FALSE;
}

BOOL DeviceUMacKunsan8::NoUseClamp(BOOL bNoUse)
{
	return WriteOutputIOBIt(0, 11, bNoUse);
}
BOOL DeviceUMacKunsan8::MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);//m_dMaskPosition[nPosM]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	//2011520
	//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2); 
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) & //C1
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));// &
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);//m_dMaskPosition[nPosM]);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);

	//2011520
	//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2); 

	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) & //C1
			MotionControlDLL_WriteOutputDWord(0x610B5, 2));// &
	}
	return FALSE;	
}

BOOL DeviceUMacKunsan8::MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	//	m_nMaskPos = nMaskPos;
	//	m_nMaskPos2 = nMaskPos2;
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));// &
	}
	return FALSE;
}

BOOL DeviceUMacKunsan8::MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	//	m_nMaskPos = nMaskPos;
	//	m_nMaskPos2 = nMaskPos2;
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	//	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);

	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));// &
	}
	return FALSE;
}
BOOL DeviceUMacKunsan8::MotorMoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	//	bResult = bResult & DownloadPosition(AXIS_A1, dA1);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dA2);
	
	return bResult;
}
BOOL DeviceUMacKunsan8::MotorMoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	//	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	//	bResult = bResult & DownloadPosition(AXIS_A1, dA1);
	//	bResult = bResult & DownloadPosition(AXIS_A2, dA2);

	return bResult;
}
BOOL DeviceUMacKunsan8::Disconnect()
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::Connect(int nPortNo, long lBaudrate)
{
	return TRUE;
}

BOOL DeviceUMacKunsan8::IsOrigin(int nAxis)
{
#ifdef __SERVO_MOTOR__
	return Servo_IsOrigin(nAxis);	
#endif
	return TRUE;
}
BOOL DeviceUMacKunsan8::GetChillerRun()
{
	return m_NewStatus.m_bChillerOnCheck;
}
BOOL DeviceUMacKunsan8::GetLPCStatus()
{
	return TRUE;
}