// HEocard.cpp: implementation of the HEocard class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HEocard.h"
#include "..\sysdef.h"
#include "..\Model\DSystemINI.h"
#include "BicubicInterpolation.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dprocessini.h"
#include "math.h"
#include  "..\model\DProject.h"
#include "..\model\DProcessINI.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DShotTableINI.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define ASC_AXIS_SIZE			65
#define ROUND_0_FFFF(signedValue)	( (signedValue)<0 ? 0 : ((signedValue)&0xffff) )

//extern HINSTANCE g_hDllDeviceCom;

#define FIRST_PANEL_OFFSET	1
#define SECOND_PANEL_OFFSET	2
#define DELTA_PANEL_OFFSET	3
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HEocard::HEocard()
{
	m_pDriver = NULL;

	m_pEocard5 = NULL;
	if(gSystemINI.m_sHardWare.nEocardType == ETS5_TYPE)
	{
		#ifdef __USEAOD__	
			#ifdef __USE_DUALBAND_EOCARD__
				#ifndef __NEW_STRUCTURE__
					m_pEocard5 = new HEocard5Pusan1Dualband();
				#else
					m_pEocard5 = new HEocard5Pusan1DualbandNew();
				#endif
			#else
					m_pEocard5 = new HEocard5Pusan1();
			#endif
		#else
			m_pEocard5 = new HEocard5();
		#endif
	}
	else
	{
		m_pM1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
		m_pM2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
		m_pS1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
		m_pS2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];



		memset(m_pM1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
		memset(m_pM2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
		memset(m_pS1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
		memset(m_pS2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);

		m_b4Beam		= FALSE;
		m_nSP			= 20;
		m_nApertureMode = STEP_ORIGIN_MODE;
		m_nBurstShotNo	= 3000;

		InitCard();
	}

	m_Calibration = NULL;
	m_SlaveCalibration = NULL;
	m_Calibration = new CBicubicInterpolation;
	m_SlaveCalibration = new CBicubicInterpolation;
	m_Calibration->SetMaster(TRUE);
	m_SlaveCalibration->SetMaster(FALSE);

	m_Calibration->SetMatrixToZero();
	m_SlaveCalibration->SetMatrixToZero();
	
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	LoadLaserCalibrationFile(strCalPath);
}

HEocard::~HEocard()
{
	if(m_pEocard5)
		delete m_pEocard5;
	else
	{
		if(m_pDriver)
			delete m_pDriver;

		delete[] m_pM1Asc;
		delete[] m_pM2Asc;
		delete[] m_pS1Asc;
		delete[] m_pS2Asc;
	}

	if(m_Calibration)
	{
		delete m_Calibration;
		m_Calibration = NULL;
	}
	
	if(m_SlaveCalibration)
	{
		delete m_SlaveCalibration;
		m_SlaveCalibration = NULL;
	}
}

BOOL HEocard::InitCard()
{
	m_pDriver = new IEODriverDLPortIO();
	m_pDriver->SetBaseAddress(FIRST_EO_CARD_ADDRESS);

	m_pDriver->Init8255();

	FParameter Param;
	m_pDriver->SetParameter(&Param, TRUE);

	return TRUE;
}

//BOOL HEocard::SetParameter(FParameter *pParam, double dAOMOffset, int nMask)
//{
//	if(m_pEocard5)
//		return m_pEocard5->SetParameter(pParam, dAOMOffset, nMask);
BOOL HEocard::SetParameter(FParameter *pParam, int nMask, double dAOMOffset1, double dAOMOffset2,int ShotIndex, double dOnOffset1 , double dOnOffset2 )
{
	if(m_pEocard5)
		return m_pEocard5->SetParameter(pParam, nMask, dAOMOffset1,dAOMOffset2,ShotIndex, dOnOffset1, dOnOffset2);//20160627

	BOOL bResult = m_pDriver->SetParameter(pParam);
	if(bResult)
	{
		bResult = SetMinCycleTime(pParam->CycleTime * 1000);
		if(bResult)
		{
			bResult = SetMinShotTime(pParam->MinShotTime);
			if(bResult)
				return SetRunMode(FALSE, pParam->DrawStepPeriod, 2 /* line mode */, 1 /* not use */, ALL_DOWN);
			else
				return FALSE;
		}
		return FALSE;
	}
	else
		return FALSE;
}

BOOL HEocard::SetMinCycleTime(int us)
{
	if(m_pEocard5)
		return m_pEocard5->SetMinCycleTime(us);

	return m_pDriver->SetMinCycleTime(us);
}

BOOL HEocard::SetSelfLineDivide(BOOL bOn)
{
	if(m_pEocard5)
		return m_pEocard5->SetSelfLineDivide(bOn);

	return m_pDriver->SetSelfLineDivide(bOn);
}

BOOL HEocard::SetMinShotTime(int us)
{
	if(m_pEocard5)
		return m_pEocard5->SetMinShotTime(us);

	return m_pDriver->SetMinShotTime(us);
}

void HEocard::jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->jump(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
		return;
	}

	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = nTempY;
		}
		break;
	default : 
		break;
	}

	m_pDriver->jump(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
}

void HEocard::mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->mark(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
		return;
	}

	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = nTempY;
		}
		break;
	default : 
		break;
	} 

	m_pDriver->mark(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
}

BOOL HEocard::MoveDrillCenterPos()
{
	if(m_pEocard5)
		return m_pEocard5->MoveDrillCenterPos();
	
	return m_pDriver->MoveDrillCenterPos();
}

BOOL HEocard::ApertureDataReset(int nToolNo)
{
	return m_pDriver->ApertureDataReset(nToolNo);
}

BOOL HEocard::DownloadAperture(int nToolNo, int nX, int nY, int nAction)
{
	return m_pDriver->DownloadAperture(nToolNo, nX, nY, nAction);
}

BOOL HEocard::DownloadShotData4(unsigned short x,
										  unsigned short y,
										  unsigned short xS,
										  unsigned short yS,
										  unsigned short x_2,
										  unsigned short y_2,
										  unsigned short xS_2,
										  unsigned short yS_2,
										  BOOL bApplyCalibrationMaster,
										  BOOL bApplyCalibrationSlave,
										  BOOL bApplyCalibrationMaster2,
										  BOOL bApplyCalibrationSlave2,
										  int nTCode)
{
	if(m_pEocard5)
		return FALSE; // have to add

	y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2; 
	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; y_2 = FIELD_LSB - y_2; yS_2 = FIELD_LSB - yS_2;
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; x_2 = FIELD_LSB - x_2; xS_2 = FIELD_LSB - xS_2;
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = FIELD_LSB - nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = FIELD_LSB - nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = FIELD_LSB - nTempX; yS_2 = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;

			nTempX = y_2; nTempY = x_2;
			x_2 = nTempX; y_2 = nTempY;

			nTempX = yS_2; nTempY = xS_2;
			xS_2 = nTempX; yS_2 = nTempY;
		}
		break;
	default : 
		break;
	} 
	return m_pDriver->DownloadShotData4(x, y, xS, yS, 
							 x_2, y_2, xS_2, yS_2,
							 bApplyCalibrationMaster,
							 bApplyCalibrationSlave,
							 bApplyCalibrationMaster2,
							 bApplyCalibrationSlave2,
							 nTCode);
}

BOOL HEocard::DownloadShotDataDummy(unsigned short x,
									  unsigned short y,
									  unsigned short xS,
									  unsigned short yS,
									  BOOL bApplyCalibrationMaster,
									  BOOL bApplyCalibrationSlave,
									  int nTCode)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadShotDataDummy(x, y, xS, yS, 
							 bApplyCalibrationMaster,
							 bApplyCalibrationSlave,
							 nTCode);
	return TRUE;
}

BOOL HEocard::DownloadShotData2( unsigned short x,
								  unsigned short y,
								  unsigned short xS,
								  unsigned short yS,
								  BOOL bApplyCalibrationMaster,
								  BOOL bApplyCalibrationSlave,
								  int nTCode,
								  int nShotFilePosForLPCX,
								  int nShotFilePosForLPCY)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadShotData2(x, y, xS, yS, 
							 bApplyCalibrationMaster,
							 bApplyCalibrationSlave,
							 nTCode,
							 nShotFilePosForLPCX,
							 nShotFilePosForLPCY);

	y = FIELD_LSB - y; yS = FIELD_LSB - yS; 
	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; 
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; 
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS; 
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS; 
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;
		}
		break;
	default : 
		break;
	} 

	if(m_pEocard5)
		return m_pEocard5->DownloadShotData2(x, y, xS, yS, 
							 bApplyCalibrationMaster,
							 bApplyCalibrationSlave,
							 nTCode,
							 nShotFilePosForLPCX,
							 nShotFilePosForLPCY);

	return m_pDriver->DownloadShotData2(x, y, xS, yS, 
							 bApplyCalibrationMaster,
							 bApplyCalibrationSlave,
							 nTCode);
}

BOOL HEocard::ShotDataReset()
{
	if(m_pEocard5)
		return m_pEocard5->ShotDataReset();

	return m_pDriver->ShotDataReset();
}

BOOL HEocard::SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode)
{
	if(m_pEocard5)
		return m_pEocard5->SetRunMode(b4Beam, nSP, nApertureMode, nBurstShotNo, nDownmode);

	BOOL bVal;
	if(nDownmode == DSP_ONLY)
	{
		bVal = m_pDriver->SetRunMode(m_b4Beam, m_nSP, m_nApertureMode, m_nBurstShotNo);
	}
	if(nDownmode == DSP_CONST_ONLY)
	{
		bVal = m_pDriver->SetRunMode(m_b4Beam, 20, m_nApertureMode, m_nBurstShotNo);
	}
	else if(nDownmode == ALL_DOWN)
	{
		bVal = m_pDriver->SetRunMode(b4Beam, nSP, nApertureMode, nBurstShotNo);
		m_b4Beam		= b4Beam;
		m_nSP			= nSP;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}
	else
	{
		bVal = m_pDriver->SetRunMode(b4Beam, 20, nApertureMode, nBurstShotNo); // 20 ������ �����ϵ��� ����
		m_b4Beam		= b4Beam;
		m_nSP			= nSP;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}
	return bVal;
}

BOOL HEocard::DownloadTcode(TCODE_INFO *pToolInfo)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadTcode(pToolInfo);

	return m_pDriver->DownloadTcode(pToolInfo);
}

void HEocard::EStop()
{
	if(m_pEocard5)
	{
		m_pEocard5->EStop();
		return;
	}

	m_pDriver->EStop();
}

void HEocard::PauseMark()
{
	if(m_pEocard5)
	{
//		m_pEocard5->PauseMark();
		return;
	}

	m_pDriver->PauseMark();
}

void HEocard::ReStartMark()
{
	if(m_pEocard5)
	{
//		m_pEocard5->RestartMark();
		return;
	}

	m_pDriver->RestartMark();
}

BOOL HEocard::FieldStart(BOOL bDryRun)
{
	if(m_pEocard5)
	{
		return m_pEocard5->FieldStart(bDryRun);
	}

	m_pDriver->FieldStart(bDryRun);
	return TRUE;
}

BOOL HEocard::StatusOK(int nStatus)
{
	if(m_pEocard5)
	{
		return m_pEocard5->StatusOK(nStatus);
	}

	return m_pDriver->StatusOK(nStatus);
}

BOOL HEocard::SetMoveProfileLength(int nIndex, int nLength)
{
	if(m_pEocard5)
		return TRUE; // no use

	return m_pDriver->SetMoveProfileLength(nIndex, nLength);
}

BOOL HEocard::MoveProfileReset(int nIndex)
{
	if(m_pEocard5)
		return TRUE; // no use

	if(nIndex == -1)
	{
		for(int i = 0; i < MAX_PROFILE_NUM; i++)
		{
			if(!m_pDriver->MoveProfileReset(i))
				return FALSE;
		}
		return TRUE;
	}
	else
		return m_pDriver->MoveProfileReset(nIndex);
}

BOOL HEocard::DownloadProfile(int nIndex, int nValue)
{
	if(m_pEocard5)
		return TRUE; // no use

	return m_pDriver->DownloadProfile(nIndex, nValue);
}

BOOL HEocard::DownloadProfileJumpDelay(int nIndex, int nValue)
{
	if(m_pEocard5)
		return TRUE; // no use

	return m_pDriver->DownloadProfileJumpDelay(nIndex, nValue);
}

int HEocard::ReadHoleCount()
{
	if(m_pEocard5)
		return m_pEocard5->ReadHoleCount();

	return m_pDriver->ReadHoleCount();
}

BOOL HEocard::ShotCountReset()
{
	if(m_pEocard5)
		return TRUE; // no use

	return m_pDriver->ShotCountReset();
}

void HEocard::DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
								 int xS, int yS, BOOL bS1ApplyCal,
								 int x_2, int y_2, BOOL bM2ApplyCal,
								 int xS_2, int yS_2, BOOL bS2ApplyCal, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->DrillMove(bMark, x, y, bM1ApplyCal,
								 xS, yS, bS1ApplyCal,
								 x_2, y_2, bM2ApplyCal,
								 xS_2, yS_2, bS2ApplyCal, bWaitEnd);
		return;
	}

	if(bM1ApplyCal)
		GetApplyCalPos(x, y, MASTER_1);

	if(bS1ApplyCal)
		GetApplyCalPos(xS, yS, SLAVE_1);

	if(bM2ApplyCal)
		GetApplyCalPos(x_2, y_2, MASTER_2);

	if(bS2ApplyCal)
		GetApplyCalPos(xS_2, yS_2, SLAVE_2);

	if(bMark)
		m_pDriver->Drillmark(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
	else
		m_pDriver->Drilljump(x, y, xS, yS, x_2, y_2, xS_2, yS_2, bWaitEnd);
}

void HEocard::DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->DrillMoveDump(bMark, x, y, bMaster, bWaitEnd);
		return;
	}

	int x1, y1, x2, y2;
	x1 = x2 = x;
	y1 = y2 = y;
	if(bMaster)
	{
		GetApplyCalPos(x1, y1, MASTER_1);
		GetApplyCalPos(x2, y2, MASTER_2); 
	}
	else
	{
		GetApplyCalPos(x1, y1, SLAVE_1);
		GetApplyCalPos(x2, y2, SLAVE_2); 
	}
	m_pDriver->DrillMove(bMark, x1, y1, x2, y2, bMaster, bWaitEnd);
}

void HEocard::GetApplyCalPos(int &nX, int &nY, int nScannerNo)
{
	int nRefX, nRefY, nDiffX, nDiffY;
	BOOL bXChange = FALSE, bYChange = FALSE;
	nRefX = nDiffX = nX;
	nRefY = nDiffY = nY;

	if(nX < 0)
	{
		nRefX = 0;
		nDiffX = nRefX - nX;
		bXChange = TRUE;
	}
	if(nX > FIELD_LSB)
	{
		nRefX = FIELD_LSB;
		nDiffX = FIELD_LSB + nRefX - nX;
		bXChange = TRUE;
	}

	if(nY < 0)
	{
		nRefY = 0;
		nDiffY = nRefY - nY;
		bYChange = TRUE;
	}
	if(nY > FIELD_LSB)
	{
		nRefY = FIELD_LSB;
		nDiffY = FIELD_LSB + nRefY - nY;
		bYChange = TRUE;
	}

	if(bXChange || bYChange) // 0 ~ 65535 ����� ��� (��迡���� aperture �����Ҷ� �߻�, �ַ� ��ĳ�� ����������)
	{
		GetASCPos(nRefX, nRefY, nScannerNo);
		GetASCPos(nDiffX, nDiffY, nScannerNo);

		if(bXChange)
			nX = nRefX + nRefX - nDiffX;
		else
			nX = nRefX;
		if(bYChange)
			nY = nRefY + nRefY - nDiffY;
		else
			nY = nRefY;
	}
	else
	{
		GetASCPos(nX, nY, nScannerNo);
	}
}

void HEocard::GetASCPos(int &nX, int &nY, int nScannerNo)
{
	DOUBLE_POINT* pOffsetData;
	unsigned int i, j;
	int n_x, n_y;
	int a0, a1, a2, b0, b1, b2, c0;

	if(nScannerNo == MASTER_1) pOffsetData = m_pM1Asc;
	else if(nScannerNo == MASTER_2) pOffsetData = m_pM2Asc;
	else if(nScannerNo == SLAVE_1) pOffsetData = m_pS1Asc;
	else pOffsetData = m_pS2Asc;

	i = ((unsigned int)nX >> 10);	// ������ 1024�� ��
	j = ((unsigned int)nY >> 10);	// ������ 1024�� ��
	
	n_x = nX - (i<<10);				// ������ 1024�� ������
	n_y = nY - (j<<10);				// ������ 1024�� ������
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dX);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dX);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dX);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dX);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nX;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nX = ROUND_0_FFFF(c0);		// ���Ѱ� ó��
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dY);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dY);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dY);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dY);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nY;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nY = ROUND_0_FFFF(c0);		// ���Ѱ� ó��

}

BOOL HEocard::LoadCalibrationFile(char *strM1path, char *strS1path, char *strM2path, char *strS2path)
{
	if(m_pEocard5)
		return m_pEocard5->LoadCalibrationFile(strM1path, strS1path, strM2path, strS2path);

	DOUBLE_POINT* pOffsetData;
	unsigned int index;
	int k, i, j;
	float data;
	char buf[256];	
	FILE* fp;
	fp = NULL;
	errno_t err;
	for(int kk = 0; kk < 4; kk++)
	{
		if(kk == MASTER_1) 
		{
			pOffsetData = m_pM1Asc;
			if(strM1path == NULL)
				continue;
			err = fopen_s(&fp, strM1path,_T("r"));	
		}
		else if(kk == MASTER_2) 
		{
			pOffsetData = m_pM2Asc;
			if(strM2path == NULL)
				continue;
			err = fopen_s(&fp, strM2path,_T("rt"));
		}
		else if(kk == SLAVE_1) 
		{
			pOffsetData = m_pS1Asc;
			if(strS1path == NULL)
				continue;
			err = fopen_s(&fp, strS1path,_T("rt"));
		}
		else 
		{
			pOffsetData = m_pS2Asc;
			if(strS2path == NULL)
				continue;
			err = fopen_s(&fp, strS2path,_T("rt"));
		}

		if(NULL != err)
			return FALSE;
		
		fgets(buf, sizeof(buf), fp);	
		for (k=0; k < 2; k++) 
		{
			for  (j=0; j<65; j++) 
			{
				for (i=0; i<65; i++)   
				{
					switch(k) {
					case  0:
						fscanf(fp, _T("%f"), &data);
						pOffsetData[i * ASC_AXIS_SIZE + j].dY  = data;
						break;
					case  1:
						fscanf(fp, _T("%f"), &data);
						pOffsetData[i * ASC_AXIS_SIZE + j].dX  = data;
						break;
					default:  break;
					}
				}//  for (i)
			}//  for (j)
		} //  for (k)	
		fclose(fp);
		
		for  (j=0; j<65; j++) 
		{
			for (i=0; i<65; i++) 
			{
				if(kk < 2)
				{
					index = (kk) << 14;
					index += (unsigned int)(32768 + j + i*128);
					m_pDriver->writePort(index, (WORD)(pOffsetData[i * ASC_AXIS_SIZE + j].dX + HALF_LSB), (WORD)(pOffsetData[i * ASC_AXIS_SIZE + j].dY + HALF_LSB));	
				}
				else
				{
					index = (kk - 2) << 14;
					index += (unsigned int)(j + i*128);
					m_pDriver->DownloadASCData((WORD)(pOffsetData[i * ASC_AXIS_SIZE + j].dX + HALF_LSB), (WORD)(pOffsetData[i * ASC_AXIS_SIZE + j].dY + HALF_LSB), index);	
					
				}
			}
		}
	}

	return TRUE;
}

void HEocard::CO2LaserEnable(BOOL bEnable)
{
	if(m_pEocard5)
	{
		m_pEocard5->CO2LaserEnable(bEnable);
		return;
	}

	m_pDriver->CO2LaserEnable(bEnable);
}

void HEocard::CO2LaserMainShutter(BOOL bOn)
{
	if(m_pEocard5)
	{
		m_pEocard5->CO2LaserMainShutter(bOn);
		return;
	}
	m_pDriver->CO2LaserMainShutter(bOn);
}

BOOL HEocard::GetParameter(FParameter *Para)
{
	if(m_pEocard5)
		return m_pEocard5->GetParameter(Para);

	return m_pDriver->GetParameter(Para);
}

BOOL HEocard::Create()
{
	SetSelfLineDivide(gSystemINI.m_sSystemDevice.nSelfLineDivide);
	return TRUE;
}

void HEocard::Destroy()
{

}

BOOL HEocard::Initialize()
{
	return TRUE;
}

void HEocard::RunConfig()
{
//	CDlgCalibration dlgCalibration;
//	dlgCalibration.SetEOCard(this);
//	dlgCalibration.DoModal();
}

BOOL HEocard::DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadTCode(nToolNo, nFreq, nBurstShot, nTotalShot, bUseAperture);

	return m_pDriver->DownloadTCode(nToolNo, nFreq, nBurstShot, nTotalShot, bUseAperture);
}

BOOL HEocard::DownloadDutyAOM(unsigned int nToolNo, unsigned int nShotIndex, double dDuty, double dAOMDelay, double dAOMDuty)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadDutyAOM(nToolNo, nShotIndex, dDuty, dAOMDelay, dAOMDuty);

	return m_pDriver->DownloadDuty(nToolNo, nShotIndex, dDuty);
}

void HEocard::jump(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->jump(x, y, xS, yS, bWaitEnd);
		return;
	}

	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS;
			y = FIELD_LSB - y; yS = FIELD_LSB - yS;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS;
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS;
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;
		}
		break;
	default : 
		break;
	} 

	m_pDriver->jump(x, y, xS, yS, x, y, xS, yS, bWaitEnd);
}

void HEocard::mark(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(m_pEocard5)
	{
		m_pEocard5->mark(x, y, xS, yS, bWaitEnd);
		return;
	}

	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS;
			y = FIELD_LSB - y; yS = FIELD_LSB - yS;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; yS = FIELD_LSB - yS;
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; xS = FIELD_LSB - xS;
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = FIELD_LSB - nTempX; yS = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;

			nTempX = yS; nTempY = xS;
			xS = nTempX; yS = nTempY;
		}
		break;
	default : 
		break;
	} 

	m_pDriver->mark(x, y, xS, yS, x, y, xS, yS, bWaitEnd);
}

BOOL HEocard::IsDSPBusy()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->IsDSPBusy();
	
	return (m_pDriver->readStatus() & 0x03);
#else
	return 0;
#endif
}
BOOL HEocard::ResetScannerStatusErrorCount()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->ResetScannerStatusErrorCount();
#endif
	return TRUE;
}

BOOL HEocard::IsDrillTimeOut()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->IsDrillTimeOut();
	
	return (m_pDriver->readStatus() & 0x03);
#else
	return 0;
#endif
}
void HEocard::MakeInpositionTable()
{
#ifndef __TEST__
	if(m_pEocard5)
		m_pEocard5->MakeInpositionTable();
#else
#endif
}

BOOL HEocard::IsMotorFault()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->IsMotorFault();
	
	return (m_pDriver->readStatus() & 0x03);
#else
	return 0;
#endif
}
BOOL HEocard::IsScannerCableError()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->IsScannerCableError();
#endif
	return 0;

}
BOOL HEocard::DownloadShotData(unsigned short x,
										 unsigned short y,
										 BOOL bIsMaster,
										 BOOL bApplyCalibration,
										 int nTCode)
{
	y = FIELD_LSB - y; 
	int nType = gSystemINI.m_sHardWare.nScannerAxisType;
	int nTempX, nTempY;
	switch( nType )
	{
	case PX_PY : 
		{
			x = FIELD_LSB - x;
			y = FIELD_LSB - y;
		}
		break;
	case NX_PY : 
		{
			y = FIELD_LSB - y; 
		}
		break;
	case PX_NY : 
		{
			x = FIELD_LSB - x; 
		}
		break;
	case NX_NY : 
		break;
	case PY_PX : //------
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = FIELD_LSB - nTempY;
		}
		break;
	case NY_PX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = FIELD_LSB - nTempY;
		}
		break;
	case PY_NX : 
		{
			nTempX = y; nTempY = x;
			x = FIELD_LSB - nTempX; y = nTempY;
		}
		break;
	case NY_NX : 
		{
			nTempX = y; nTempY = x;
			x = nTempX; y = nTempY;
		}
		break;
	default : 
		break;
	} 

	if(m_pEocard5)
		return FALSE; // no use m_pEocard5->DownloadShotData(x, y, bIsMaster, bApplyCalibration, nTCode);

	return m_pDriver->DownloadShotData(x, y, bIsMaster, bApplyCalibration, nTCode);
}

void HEocard::SetDumperPosition(USHORT usDumpMX, USHORT usDumpMY, USHORT usDumpSX, USHORT usDumpSY)
{
	if(m_pEocard5)
		return; // no use

	m_pDriver->SetDumperPosition(usDumpMX, usDumpMY, usDumpSX, usDumpSY);
}

void HEocard::GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY)
{
	if(m_pEocard5)
		return; // no use

	m_pDriver->GetDumperPosition(usDumpMX, usDumpMY, usDumpSX, usDumpSY);
}

BOOL HEocard::LaserOnOff(BOOL bOn)
{
	if(m_pEocard5)
		return m_pEocard5->LaserOnOff(bOn);

	return m_pDriver->LaserOnOff(bOn);
}

BOOL HEocard::jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(m_pEocard5)
		return m_pEocard5->jumpOne(x, y, bIsMaster, bWaitEnd);

	return m_pDriver->jumpOne(x, y, bIsMaster, bWaitEnd);
}

void HEocard::MoveToCenter()
{
	if(m_pEocard5)
	{
		m_pEocard5->MoveToCenter();
		return;
	}

	jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
}

BOOL HEocard::ResetSubToolForAllTool()
{
	if(m_pEocard5)
		return m_pEocard5->ResetSubToolForAllTool();

	return TRUE;
}

BOOL HEocard::DownloadOneSubTool(int nTool, SUBTOOLDATA subTool, BOOL bSetPowerLevel, BOOL bMakeLPCTable)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadOneSubTool(nTool, subTool, bSetPowerLevel, bMakeLPCTable);

	BOOL bResult;
	FParameter Para;
	m_pDriver->GetParameter(&Para);
	int nMaskDutyOffset = gSystemINI.m_sSystemCollimator.nDutyOffset[subTool.nMask];
	if(subTool.nToolType == MARKING_TYPE)
	{
		Para.DrawStep = (unsigned short)subTool.dDrawStep;
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; // Mark default
		Para.StepPeriod = subTool.nJumpStepPeriod;
		Para.CornerDelay = subTool.nCornerDelay;
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0] * 100 + nMaskDutyOffset; // unit 0.01% (0 index ���)
		Para.FPSDelay = subTool.nFPS;
		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, 2 /* line mode */, 1 /* not use */, EXCEPT_DSP); // marker use only DSP.
		if(bResult) bResult = bResult & m_pDriver->SetParameter(&Para);
#ifdef __TEST__
		bResult = TRUE;
#endif		
		return bResult;
	}
	else if(subTool.nToolType == SHOT_DRILL_TYPE)
	{
		// Para.DrawStep = subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		// Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		// Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = Para.LaserOnDelay; 
		Para.Frequency = subTool.nFrequency;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		Para.FPSDelay = subTool.nFPS;
		Para.MinShotTime = gSystemINI.m_sSystemDevice.nMinShotTime;
		Para.CycleTime = gSystemINI.m_sSystemDevice.nMinCycleTime;
		if(gSystemINI.m_sSystemDevice.nShotDrillType == SHOT_DRILL_ORIGIN)
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_ORIGIN_MODE, subTool.nApertureBurst, EXCEPT_DSP); 
		else
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_DIVIDE_MODE, subTool.nApertureBurst, EXCEPT_DSP); 

		if(bResult) bResult = bResult & m_pDriver->SetParameter(&Para);
		if(bResult) bResult = bResult & m_pDriver->SetMinShotTime(Para.MinShotTime);
		if(bResult) bResult = bResult & m_pDriver->SetMinCycleTime(Para.CycleTime * 1000);
		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 
														subTool.nBurstShot, 
														subTool.nTotalShot,
														subTool.bUseAperture );
		for(int i = 0; i < subTool.nTotalShot; i++)
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
				gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				if(bResult) bResult = bResult & m_pDriver->DownloadDuty(nTool, i, 50); // 50%  : UV�� duty ��� ����.
			}
			else
			{
				if(bResult) bResult = bResult & m_pDriver->DownloadDuty(nTool, i, subTool.dShotDuty[i] + nMaskDutyOffset/100.0);
			}
		}
#ifdef __TEST__
		bResult = TRUE;
#endif
		CString str;
		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
#ifdef __TEST__
			bResult = TRUE;
#endif
		}
//		str.Format(_T("%s", subTool.cMoveProfileFilePath);
//		if(bResult) bResult = bResult & DownloadProfileFile(str);
		
		return bResult;
	}
	else if(subTool.nToolType == LINE_DRILL_TYPE || subTool.nToolType == BARCODE_TYPE)
	{
		if(gSystemINI.m_sSystemDevice.nSelfLineDivide)
			Para.DrawStep = (unsigned short)subTool.dDrawStep; 
		else
			Para.DrawStep = 65535; // subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0] * 100 + nMaskDutyOffset; // unit 0.01% (0 index ���)

		Para.FPSDelay = subTool.nFPS;
		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, UV_LINE_MODE, 1 /* Line drill not use */, EXCEPT_DSP); 
		if(bResult) bResult = bResult & m_pDriver->SetParameter(&Para);
		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 1, 1, subTool.bUseAperture ); // Total shot �׻� 1
#ifdef __TEST__
		bResult = TRUE;
#endif
		CString str;
		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
#ifdef __TEST__
			bResult = TRUE;
#endif
		}

		return bResult;
	}
	else if(subTool.nToolType == FLYING_TYPE)
	{
		Para.LaserOnDelay = 0;
		Para.LaserOffDelay = 0;
		Para.FPSDelay = subTool.nFPS;
		Para.Frequency = subTool.nFrequency;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0]* 100 + nMaskDutyOffset; // unit 0.01% (0 index ���)

		bResult = TRUE; // SetRunMode(FALSE, Para.DrawStepPeriod, UV_LINE_MODE, 1 /* Line drill not use */); : �߿��� �ϼ��Ǹ� �ؾ���
		if(bResult) bResult = bResult & m_pDriver->SetParameter(&Para);
#ifdef __TEST__
		bResult = TRUE;
#endif		
		return bResult;
	}
	else
		return FALSE;

	return TRUE;
}

BOOL HEocard::DownloadOneAperture(CString str, int nTool)
{
	if(m_pEocard5)
		return m_pEocard5->DownloadOneAperture(str, nTool);

	if(!ApertureDataReset(nTool))
		return FALSE;
	m_MarkingData.RemoveAll();
	MARKING_DATA markingData;
	
	char szBuf[256];
	CString strRead;
	strRead.Format(_T(""));
	CString strXPos, strYPos;
	strXPos.Format(_T("")); strYPos.Format(_T(""));
	int nchar = 0;
	
	errno_t err;
	FILE* fp;
	err = fopen_s(&fp, str, _T("r"));
	if(err != NULL)
	{
		return FALSE;
	}
	
	while(!feof(fp))
	{
		fgets(szBuf, 255, fp);
		strRead = (CString) szBuf;
		strRead.TrimLeft();
		strRead.TrimRight();
		if(strRead.GetAt(0) == _T('P') && strRead.GetAt(2) == _T(';'))
		{
			if(strRead.GetAt(1) == _T('D') || strRead.GetAt(1) == _T('U'))
			{
				if(strRead.Find(_T(',')) == -1)
				{
					break;
				}
				else
				{
					for(nchar = 3; nchar < strRead.Find(_T(',')); ++nchar)
						strXPos += strRead.GetAt(nchar);
					for(nchar = strRead.Find(_T(','))+1; nchar < strRead.GetLength()-1; ++nchar)
						strYPos += strRead.GetAt(nchar);
					
					if(strRead.GetAt(1) == _T('D'))
						markingData.nAction = MARK_DRAW;
					else
						markingData.nAction = MARK_JUMP;
					markingData.nPoint.x = (int) (atof(strXPos) * 65535 / (gSystemINI.m_sSystemDevice.dFieldSize.x*1000));
					markingData.nPoint.y = (int) (atof(strYPos) * 65535 / (gSystemINI.m_sSystemDevice.dFieldSize.y*1000));	
					m_MarkingData.Add(markingData);
					
					if(!DownloadAperture(nTool, markingData.nPoint.x, markingData.nPoint.y, markingData.nAction))
					{
						ApertureDataReset(nTool);
						fclose(fp);
						return FALSE;
					}
					strXPos.Format(_T(""));
					strYPos.Format(_T(""));							
				}						 
			}			
		}
	}
	fclose(fp);
	return TRUE;
}

BOOL HEocard::DownloadShotDrillScannerParam(int nJumpDelayPlus) // nJumpDelay 1 = 1 X Draw step Period
{
	if(m_pEocard5)
		return m_pEocard5->DownloadShotDrillScannerParam(nJumpDelayPlus);

	return TRUE;
}

BOOL HEocard::SetFunction(USHORT Value)
{
	if(m_pEocard5)
		return m_pEocard5->SetFunction(Value);

	return m_pDriver->SetFunction(Value);
}

USHORT HEocard::GetFunction()
{
	if(m_pEocard5)
		return m_pEocard5->GetFunction();

	return m_pDriver->GetFunction();
}

BOOL HEocard::GetStatus(WORD* pStat) const
{
	if(m_pEocard5)
		return m_pEocard5->GetStatus(pStat);

	return m_pDriver->GetStatus(pStat);
}

BOOL HEocard::GetAperturePos(int nIndex, int& nX, int& nY, int& nAction)
{
	if(nIndex >= m_MarkingData.GetSize())
		return FALSE;

	MARKING_DATA data = m_MarkingData.GetAt(nIndex);
	nX = data.nPoint.x;
	nY = data.nPoint.y;
	nAction =  data.nAction;
	return TRUE;
}

BOOL HEocard::markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(m_pEocard5)
		return m_pEocard5->markOne(x, y, bIsMaster, bWaitEnd);

	return m_pDriver->markOne(x, y, bIsMaster, bWaitEnd);
}

BOOL HEocard::SetQuantaParam(int nFPK, int nCurrent)
{
	if(m_pEocard5)
		return m_pEocard5->SetQuantaParam(nFPK, nCurrent);

	return m_pDriver->SetQuantaParam(nFPK, nCurrent);
}

BOOL HEocard::FlyingModeEnable(BOOL bEnable)
{
	if(m_pEocard5)
		return m_pEocard5->FlyingModeEnable(bEnable);

	return m_pDriver->FlyingModeEnable(bEnable);
}

BOOL HEocard::FieldPreStart(int nShotNo)
{
	if(m_pEocard5)
		return m_pEocard5->FieldPreStart(nShotNo);
	else
		return TRUE;
}

void HEocard::ReloadDevice()
{
	if(m_pEocard5)
		m_pEocard5->ReloadDevice();
	else
		return;
}

BOOL HEocard::DownloadAOMProfile(int nTool, int nSubTool, CString strPath, int nMask)
{
//	if(m_pEocard5)
//		return m_pEocard5->DownloadAOMProfile(nTool, nSubTool, strPath, 0, 0, 0, 0, 0, 0, nMask);
//	else
		return TRUE;
}

BOOL HEocard::IsFireCntOK(int& nDownCnt, int& nReadCnt)
{
	if(m_pEocard5)
		return m_pEocard5->IsFireCntOK(nDownCnt, nReadCnt);
	else
		return TRUE;
}

BOOL HEocard::DummyFieldStart(int nShotNo, BOOL bDryRun)
{
	if(m_pEocard5)
		return m_pEocard5->DummyFieldStart(nShotNo, bDryRun);
	else
		return TRUE;
}

BOOL HEocard::DummyStopAndDataShotStart(BOOL bDryRun)
{
	if(m_pEocard5)
		return m_pEocard5->DummyStopAndDataShotStart(bDryRun);
	else
		return TRUE;
}

BOOL HEocard::DummyParamSet(BOOL bPowervia)
{
	if(m_pEocard5)
		return m_pEocard5->DummyParamSet(bPowervia);
	else
		return TRUE;
}

BOOL HEocard::StandbyParamSet()
{
	if(m_pEocard5)
		return m_pEocard5->StandbyParamSet();
	else
		return TRUE;
}

BOOL HEocard::DrillStandbyShotStart(BOOL bStart, BOOL bUserStop)
{
	if(m_pEocard5)
		return m_pEocard5->DrillStandbyShotStart(bStart, bUserStop);
	else
		return TRUE;
}
BOOL HEocard::DrillStandbyShotStartHole(BOOL bStart)
{
#ifdef __3RDAOD__
	if(m_pEocard5)
		return m_pEocard5->StandbyParamSet();
#endif
	return TRUE;
}
int HEocard::IsStannbyShotRun()
{
	if(m_pEocard5)
		return m_pEocard5->IsStannbyShotRun();
	else
		return TRUE;
}

BOOL HEocard::SubDownloadReset(int nIndex)
{
	if(m_pEocard5)
	{
		return m_pEocard5->SubDownloadReset(nIndex);
	}
	else
		return TRUE;
}

BOOL HEocard::SubDownloadStop()
{
	if(m_pEocard5)
	{
		return m_pEocard5->SubDownloadStop();
	}
	else
		return TRUE;
}

BOOL HEocard::SubCallStart(int nIndex, BOOL bDryrun)
{
	if(m_pEocard5)
	{
		return m_pEocard5->SubCallStart(nIndex, bDryrun);
	}
	else
		return TRUE;
}

BOOL HEocard::StartMarkDummy()
{
	if(m_pEocard5)
		return m_pEocard5->StartMarkDummy();
	else
		return TRUE;
}

BOOL HEocard::EndMarkDummy()
{
	if(m_pEocard5)
		return m_pEocard5->EndMarkDummy();
	else
		return TRUE;
}

BOOL HEocard::SetParameterCavityDuty(BOOL bShortLine)
{
	if(m_pEocard5)
		return m_pEocard5->SetParameterCavityDuty(bShortLine);
	else
		return TRUE;
}

double HEocard::GetDummyFreeStart()
{
	if(m_pEocard5)
		return m_pEocard5->GetDummyFreeStart();
	else 
		return 0;
}

void HEocard::LoadLaserCalibrationFile(CString strPath)
{
	if(!UpdateLaserCalibrationFile(strPath , TRUE))
	{
#ifndef __TEST__
			if(gSystemINI.m_sHardWare.bLaserCalAlarm)
			{
				int nResult;
				CString strString;
				CString strError;
//				strString.LoadString(IDS_ERR_NO_FILE);
				strError.Format(_T("File open fail : LaserM.Table"));
				do 
				{
					nResult = ::AfxMessageBox(strError, MB_OK);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strError));
				} while(nResult != IDOK);
			}
#endif
	}
	if(!UpdateLaserCalibrationFile(strPath, FALSE))
	{
#ifndef __TEST__
			if(gSystemINI.m_sHardWare.bLaserCalAlarm)
			{
				int nResult;
				CString strString;
				CString strError;
				strError.Format(_T("File open fail : LaserS.Table"));
				do 
				{
					nResult = ::AfxMessageBox(strError, MB_OK);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strError));
				} while(nResult != IDOK);
			}
#endif
	}
//	m_Calibration->LoadCalibration(strPath + _T("MLaser.Cal"));
//	m_SlaveCalibration->LoadCalibration(strPath + _T("SLaser.Cal"));
}

void HEocard::GetLaserOffset(double dX, double dY, double &dXOffset, double &dYOffset, BYTE cFlag)
{
	double dXOff=0, dYOff=0, dXOff2=0, dYOff2=0;
	
	if(cFlag == FIRST_PANEL_OFFSET)
	{
		m_Calibration->GetCalibrationOffset(dX, dY, dXOff, dYOff);
//		m_Calibration->GetCalibrationOffset(gProcessINI.m_sProcessScannerCal.dMasterCalTablePosX,
//											gProcessINI.m_sProcessScannerCal.dMasterCalTablePosY, 
//											dXOff2, dYOff2);
		dXOffset = (int((dXOff - dXOff2)*100000))/100000.0;
		dYOffset = (int((dYOff - dYOff2)*100000))/100000.0;
	}
	else if(cFlag == SECOND_PANEL_OFFSET)
	{
		m_SlaveCalibration->GetCalibrationOffset(dX, dY, dXOff, dYOff);
//		m_SlaveCalibration->GetCalibrationOffset(gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX,
//												 gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY, 
//												 dXOff2, dYOff2);
		dXOffset = (int((dXOff - dXOff2)*100000))/100000.0;
		dYOffset = (int((dYOff - dYOff2)*100000))/100000.0;
	}
//	else
//	{
//		dXOffset = (int((dXOff2 - dXOff)*100000))/100000.0;
//		dYOffset = (int((dYOff2 - dYOff)*100000))/100000.0;
//	}
}

BOOL HEocard::UpdateLaserCalibrationFile(CString strPath, BOOL b1stPanel)
{
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	TCHAR *szNext;
	FILE* fp = NULL;
	CString strFileName;
	if(b1stPanel)
		strFileName = strPath + _T("LaserM.Table");
	else
		strFileName = strPath + _T("LaserS.Table");
	
	if (NULL == fopen_s(&fp, strFileName, _T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return FALSE;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return FALSE;
		}
		END_CATCH

		double dX = 0.0, dY = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 2000.0 || dYPos < 0.0 || dYPos > 2000.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dX = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dY = atof(token);

				if (fabs(dX) > 1.0 || fabs(dY) > 1.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = dY;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		if(b1stPanel)
			m_Calibration->UpdateCalibration(calHead, FALSE);
		else
			m_SlaveCalibration->UpdateCalibration(calHead, FALSE);
		
		delete [] dpOffset;

		return TRUE;
	}
	 return FALSE;
}

BOOL HEocard::SetApplyCalibrationFile(int nBeam, BOOL bOn)
{
	if(m_pEocard5)
		return m_pEocard5->SetApplyCalibrationFile(nBeam,bOn);
	else 
		return TRUE;
}

BOOL HEocard::GetApplyCalibrationFile(int nBeam)
{
	return TRUE;

	if(m_pEocard5)
		return m_pEocard5->GetApplyCalibrationFile(nBeam);
	else 
		return TRUE;
}

BOOL HEocard::SetVoltage(double d1st, double d2nd)
{
	if(m_pEocard5)
		return m_pEocard5->SetVoltage(d1st, d2nd);
	else 
		return TRUE;
}

BOOL HEocard::ChangeScannerAxis()
{
	if(m_pEocard5)
		return m_pEocard5->ChangeScannerAxis();
	else 
		return TRUE;
}

void HEocard::UpdateLPCCalibrationFile(CString strPath)
{
	if(m_pEocard5)
	{
		m_pEocard5->UpdateLPCCalibrationFile(strPath);
	}
}

#ifndef __LPC_FOR_3RD_AOD__
	TDrill_LPCMonitor* HEocard::GetLPCResult()
	{
		if(m_pEocard5)
		{
	#ifdef __CUNGJU__
			return m_pEocard5->GetLPCResult();
	#else
			return NULL;
	#endif
		}
		else
		{
			return NULL;
		}
	}
#else
	TLpc_Buffer* HEocard::GetLPCResult()
	{
		if(m_pEocard5)
		{
			return m_pEocard5->GetLPCResult();
		}
		else
		{
			return NULL;
		}
	}
#endif

CPoint HEocard::GetDownHoleFirePos(int nIndex)
{
	CPoint cPoint;
	cPoint.x = cPoint.y = INT_MAX;
	if(m_pEocard5)
	{
		return m_pEocard5->GetDownHoleFirePos(nIndex);
	}
	return cPoint;
}

BOOL HEocard::SetLPCDataReadReady()
{
	if(m_pEocard5)
	{
		return m_pEocard5->SetLPCDataReadReady();
	}
	return TRUE;
}

BOOL HEocard::SetMasterSlave(BOOL bMaster)
{
	if(m_pEocard5)
	{
		#ifdef __USE_DUALBAND_EOCARD__
			return m_pEocard5->SetMasterSlave(bMaster);
		#endif
		return TRUE;
	}
	else 
		return TRUE;
}

BOOL HEocard::SetFieldSizeToEocard()
{
	if(m_pEocard5)
	{
		#ifdef __USE_DUALBAND_EOCARD__
				return m_pEocard5->SetFieldSizeToEocard();
		#endif
		return TRUE;
	}
	else 
		return TRUE;
}

BOOL HEocard::SetScannerErrorLevel(double dWarning_mm, double dAlarm_mm)
{
	if(m_pEocard5)
	{
#ifdef __USE_DUALBAND_EOCARD__
		return m_pEocard5->SetScannerErrorLevel(dWarning_mm, dAlarm_mm);
#endif
		return TRUE;
	}
	else 
		return TRUE;
}

BOOL HEocard::ResetScannerPosErrorCount()
{
	if(m_pEocard5)
	{
#ifdef __USE_DUALBAND_EOCARD__
		return m_pEocard5->ResetScannerPosErrorCount();
#endif
		return TRUE;
	}
	else 
		return TRUE;
}

BOOL HEocard::GetScannerError(int *nWarningNo, int *nAlarmNo, int *nMaxValue, int* nInposMissNo)
{
	for(int i = 0; i < 4; i++)
	{
		nWarningNo[i] = nAlarmNo[i] = nMaxValue[i] = nInposMissNo[i] = 0;
	}
	if(m_pEocard5)
	{
#ifdef __USE_DUALBAND_EOCARD__
		return m_pEocard5->GetScannerError(nWarningNo, nAlarmNo, nMaxValue, nInposMissNo);
#endif
		return TRUE;
	}
	else 
		return TRUE;
}

//																			check ����
// __3RDAOD__		__USE_DUALBAND_EOCARD__			dummy on			(recipe duty & recipe max. freq),  ( system standby duty & system standby freq)
//													dummy off			(recipe duty & recipe max. freq) 
// __3RDAOD__		no __USE_DUALBAND_EOCARD__		dummy on			�ش� ��� ����
//													dummy off			�ش� ��� ����

// no __3RDAOD__	__USE_DUALBAND_EOCARD__			dummy on			(recipe duty & recipe max. freq),  ( system standby duty & recipe max. freq), ( system standby duty & system standby freq)
//													dummy off			(recipe duty & recipe max. freq)
// no __3RDAOD__	no __USE_DUALBAND_EOCARD__		dummy on			( system standby duty & system standby freq), (recipe duty & system max. freq), ( system standby duty & system max. freq)
//													dummy off			( recipe duty & nMinShotTime)

BOOL HEocard::CheckLaserDutyLimit()
{
	double dUseLimitPer = (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100.; 
	double dShotDutyLimit;
	BOOL bDummy = (BOOL)GetDummyFreeStart();
	if( !bDummy || !gSystemINI.m_sHardWare.nUseFirstOrder || gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_NO_USE) // no use dummy free 
	{
		double dMinShotTimeFreq_us = (double)gSystemINI.m_sSystemDevice.nMinShotTime;
		dShotDutyLimit = dMinShotTimeFreq_us * dUseLimitPer;

		if(!CheckShotDutyLimitDummyOff(dShotDutyLimit))
			return FALSE;
	}
	else
	{
		// dummy free duty & shot data �� 
		if(!CheckShotDutyLimitDummyOn())
			return FALSE;
	}
	return TRUE;
}

BOOL HEocard::CheckShotDutyLimitDummyOn()
{
	CString strSequenceLog;
	double dLimit;
	double dShotDutyLimit;
	double dUseLimitPer = (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100.;
#ifdef __3RDAOD__
	#ifdef __USE_DUALBAND_EOCARD__
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1) // ( system standby duty & system standby freq)
		{ 
			dShotDutyLimit = (1000000./(double)gSystemINI.m_sSystemDump.nStandbyInterval) * dUseLimitPer;
		
			if(gSystemINI.m_sSystemDump.nStandbyDuty > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and standby freq. 1 and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
		else
		{
			dShotDutyLimit = 1000000./(double)gSystemINI.m_sSystemDump.nStandbyInterval2 * dUseLimitPer;  

			if(gSystemINI.m_sSystemDump.nStandbyDuty2 > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and standby freq. 2 and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
	#endif
#else
	#ifdef __USE_DUALBAND_EOCARD__
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1) // ( system standby duty & system standby freq)
		{ 
			dShotDutyLimit = (1000000./(double)gSystemINI.m_sSystemDump.nStandbyInterval) * dUseLimitPer;
		
			if(gSystemINI.m_sSystemDump.nStandbyDuty > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and max. freq. 1 and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
		else
		{
			dShotDutyLimit = 1000000./(double)gSystemINI.m_sSystemDump.nStandbyInterval2 * dUseLimitPer;  

			if(gSystemINI.m_sSystemDump.nStandbyDuty2 > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and max. freq. 2 and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
	#else
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1) // ( system standby duty & system standby freq) or  ( system standby duty & system max. freq)
		{ 
			double dFreq =  (double)gSystemINI.m_sSystemDump.nStandbyMaxFreq;
			if(gSystemINI.m_sSystemDump.nStandbyInterval > gSystemINI.m_sSystemDump.nStandbyMaxFreq)
				 dFreq =  (double)gSystemINI.m_sSystemDump.nStandbyInterval;

			dShotDutyLimit = (1000000./dFreq) * dUseLimitPer;
		
			if(gSystemINI.m_sSystemDump.nStandbyDuty > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and (standby freq. or max. freq. 1) and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
		else
		{
			double dFreq =  (double)gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
			if(gSystemINI.m_sSystemDump.nStandbyInterval2 > gSystemINI.m_sSystemDump.nStandbyMaxFreq2)
				 dFreq =  (double)gSystemINI.m_sSystemDump.nStandbyInterval2;

			dShotDutyLimit = (1000000./dFreq) * dUseLimitPer;

			if(gSystemINI.m_sSystemDump.nStandbyDuty2 > dShotDutyLimit)
			{
				strSequenceLog.Format(_T("Laser duty Limit Over : Check standby duty and (standby freq. or max. freq. 2) and (Process.ini : DUTY LIMIT)"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
		}
	#endif
#endif

	double dMaskDutyOffset; 
	double dPowerDutyOffset;

	double dTotalDuty;
	SUBTOOLDATA subTool;
	POSITION pos;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		
		pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		int nSubToolIndex = 0;
		
		while(pos)
		{
			nSubToolIndex++;
			subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
		
			dMaskDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
			dPowerDutyOffset = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];

			int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];

			double dVoltage1 = gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex];
			double dVoltage2 = gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex];

			subTool.nToolType = gShotTableINI.m_sShotGroupTable.nToolType[nShotIndex];
			subTool.nCornerDelay= gShotTableINI.m_sShotGroupTable.nConerDelay[nShotIndex];
			subTool.nJumpDelay= gShotTableINI.m_sShotGroupTable.nJumpDelay[nShotIndex];
			subTool.nLineDelay= gShotTableINI.m_sShotGroupTable.nLineDelay[nShotIndex];
			subTool.nLaserOnDelay= gShotTableINI.m_sShotGroupTable.nLaserOnDelay[nShotIndex];
			subTool.nLaserOffDelay= gShotTableINI.m_sShotGroupTable.nLaserOffDelay[nShotIndex];


			subTool.nFrequency= gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
			subTool.dShotDuty[0]= gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.dShotAOMDelay[0]= gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dAOMWait_M[0];
			subTool.dShotAOMDuty[0]= gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.bUseAperture = gShotTableINI.m_sShotGroupTable.bUseAperture[nShotIndex];
			strcpy(subTool.cFilePath,gShotTableINI.m_sShotGroupTable.strAperturePath[nShotIndex]);
			subTool.nBurstShot = gShotTableINI.m_sShotGroupTable.nBurstShotCount[nShotIndex];
			subTool.nTotalShot = gShotTableINI.m_sShotGroupTable.nTotalShotCount[nShotIndex];

			for(int i = 0; i < subTool.nTotalShot; i++)
			{
				subTool.dShotMaxFreq[i] = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
				subTool.dShotMinFreq[i] = gShotTableINI.m_sShotGroupTable.nShotMinFrequency[nShotIndex];
				subTool.dShotDuty[i] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];
			}

			for(int k = 0 ; k < subTool.nTotalShot; k++)
			{
#ifdef __3RDAOD__
	#ifdef __USE_DUALBAND_EOCARD__ // (recipe duty & recipe max. freq)
				dTotalDuty = ( subTool.dShotDuty[k] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[k] + subTool.dShotDutyOffsetS[k]);
				dLimit = (1000000./(double)subTool.dShotMaxFreq[k]) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;

				if( dTotalDuty > dLimit || 1 > dTotalDuty)
				{
					strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f) and Tool max. freq.) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;
				}
	#endif
#else
	#ifdef __USE_DUALBAND_EOCARD__ // (recipe duty & recipe max. freq),  ( system standby duty & recipe max. freq)
				dTotalDuty = ( subTool.dShotDuty[k] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[k] + subTool.dShotDutyOffsetS[k]);
				dLimit = (1000000./(double)subTool.dShotMaxFreq[k]) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;

				if( dTotalDuty > dLimit || 1 > dTotalDuty)
				{
					strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f) and Tool max. freq.) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;
				}

				if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
					dTotalDuty =(double)gSystemINI.m_sSystemDump.nStandbyDuty;
				else
					dTotalDuty =(double)gSystemINI.m_sSystemDump.nStandbyDuty2;

				if( dTotalDuty > dLimit || 1 > dTotalDuty)
				{
					strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f) and standby freq.1 2) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;	
				}
	#else							
				//  (recipe duty & system max. freq)
				dTotalDuty = ( subTool.dShotDuty[k] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[k] + subTool.dShotDutyOffsetS[k]);

				if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
					dLimit = (1000000./(double)gSystemINI.m_sSystemDump.nStandbyMaxFreq) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;
				else
					dLimit = (1000000./(double)gSystemINI.m_sSystemDump.nStandbyMaxFreq2) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;
			
				if( dTotalDuty > dLimit || 1 > dTotalDuty)
				{
					strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f) and standby max. freq.1 2) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;
				}
	#endif
#endif
			}
		}
	}

	return TRUE;

}

BOOL HEocard::CheckShotDutyLimitDummyOff(double dLimit)
{
	double dMaskDutyOffset; 
	double dPowerDutyOffset;
	double dTotalDuty;
	SUBTOOLDATA subTool;
	POSITION pos;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		
		pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		int nSubToolIndex = 0;
		
		while(pos)
		{
			nSubToolIndex++;
			subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
		
			dMaskDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
			dPowerDutyOffset = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];

			for(int k = 0 ; k < subTool.nTotalShot; k++)
			{
				dTotalDuty = ( subTool.dShotDuty[k] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[k] + subTool.dShotDutyOffsetS[k]);

				#ifdef __USE_DUALBAND_EOCARD__
					dLimit = (1000000./(double)subTool.dShotMaxFreq[k]) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;
				#endif
				
				if( dTotalDuty > dLimit || 1 > dTotalDuty)
				{
					CString strSequenceLog;
					#ifdef __USE_DUALBAND_EOCARD__
						strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f) and (Min. shot time) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					#else
						strSequenceLog.Format(_T("Laser duty Limit Over : Check (Tool %d --> SubTool %d --> Shot No %d --> duty %.1f and Max. freq.) and (Process.ini : DUTY LIMIT)"), 
												i, nSubToolIndex, k, subTool.dShotDuty[k]);
					#endif
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;
				}
			}
		}
	}

	return TRUE;

}

BOOL HEocard::GetLPCErrorCount(int& nMinError, int& nMaxError)
{
	return TRUE;
}

BOOL HEocard::IsDrillTimeOutType()
{
#ifndef __TEST__
	if(m_pEocard5)
		return m_pEocard5->IsDrillTimeOutType();

	return 0;
#else
	return 0;
#endif
}

BOOL HEocard::GetAOMStatus(WORD* pStat) const
{
	if(m_pEocard5)
		return m_pEocard5->GetAOMStatus(pStat);

	return m_pDriver->GetStatus(pStat);
}