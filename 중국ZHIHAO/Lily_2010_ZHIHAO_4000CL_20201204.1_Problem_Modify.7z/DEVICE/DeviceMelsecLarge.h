// DeviceMelsecLarge.h: interface for the DeviceMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
#include "MMelsecFx.h"
#include "..\actqj71e71tcp3.h"
#include "..\ui\DlgMelsecOCX.h"

const int HANDLER_AXIS_MAX = 0x02;	

#define OCX_READ_MELSEC_SIZE 50

struct PLC_BIT_SIGNAL_FX
{
	//R1050
	WORD	bInputLoadBasket;				// 0 : R1050
	WORD	bOutputLoadBasket;				// 1 : R1051
	WORD	bInputUnlodBasket;				// 2 : R1052
	WORD	bOutputUnloadBasket;			// 3 : R1053
	WORD	bChangeDirection;				// 4 : R1054
	WORD	bDummyR1054;					// 
	WORD	wLoaderPos[2];					// 6 ~ 7 : R1056  
	WORD	wUnloaderPos[2];				// 8 ~ 9 : R1058 

	//R1060
	BYTE	bEStopAlarm:1;						// 0 : R1060.0
	BYTE	bPLCBATAlarm:1;						// 1 : R1060.1
	BYTE	bAirDownAlarm:1;					// 2 : R1060.2
	BYTE	bDoorOpenAlarm:1;					// 3 : R1060.3
	BYTE	bAxis1DriveAlarm:1;					// 4 : R1060.4
	BYTE	bAxis2DriveAlarm:1;					// 5 : R1060.5
	BYTE	bAxis3DriveAlarm:1;					// 6 : R1060.6
	BYTE	bAxis1ControlAlarm:1;				// 7 : R1060.7
	BYTE	bAxis2ControlAlarm:1;				// 8 : R1060.8
	BYTE	bAxis3ControlAlarm:1;				// 9 : R1060.9 
	BYTE	bLoadLeftPicker1UpDownCYLAlarm:1;	// 10 : R1060.A
	BYTE	bLoadLeftPicker2UpDownCYLAlarm:1;	// 11 : R1060.B
	BYTE	bLoadLeftPickerVacuumAlarm:1;		// 12 : R1060.C
	BYTE	bLoadRightPicker1UpDownCYLAlarm:1;	// 13 : R1060.D
	BYTE	bLoadRightPicker2UpDownCYLAlarm:1;	// 14 : R1060.E
	BYTE	bLoadRightPickerVacuumAlam:1;		// 15 : R1060.F

	//R1061
	BYTE	bLoadUnloadCollisionAlarm:1;		// 0 : R1061.0 
	BYTE	bTwoDetectionAlarm:1;				// 1 : R1061.1
	BYTE	bLAlignTableForBackAlarm:1;			// 2 : R1061.2
	BYTE	bLAlign1LeftAlarm:1;				// 3 : R1061.3
	BYTE	bLAlign1FrontAlarm:1;				// 4 : R1061.4
	BYTE	bLAlignPalteAlarm:1;				// 5 : R1061.5
	BYTE	bLAlignROnOffAlarm:1;				// 6 : R1061.6
	BYTE	bLCardLockAlarm:1;					// 7 : R1061.7
	BYTE	bLLifterAlarm:1;					// 8 : R1061.8
	BYTE	bDummyR1061_9:1;					// 9
	BYTE	bLNGTableForBackAlarm:1;			// 10 : R1061.A
	BYTE	bLPaperTableForBackAlarm:1;			// 11 : R1061.B
	BYTE	bTwoDetectionCylinderAlarm:1;		// 12 : R1061.C
	BYTE	bDummyR1061_13:1;					// 13
	BYTE	bUnloadLeftPicker1UpDownCYLAlarm:1;	// 14 : R1061.E
	BYTE	bUnloadLeftPicker2UpDownCYLAlarm:1;	// 15 : R1061.F

	// R1062
	BYTE	bUnloadLeftPickerVacuumAlarm:1;		// 0 : R1062.0
	BYTE	bUnloadRightPicker1UpDownCYLAlarm:1;// 1 : R1062.1
	BYTE	bUnloadRightPicker2UpDownCYLAlarm:1;// 2 : R1062.2
	BYTE	bUnloadRightPickerVacuumAlam:1;		// 3 : R1062.3
	BYTE	bDummyR1062_4:1;					// 4 
	BYTE	bDummyR1062_5:1;					// 5
	BYTE	bUAlignTableForBackAlarm:1;			// 6 : R1062.6
	BYTE	bUAlign1LeftAlarm:1;				// 7 : R1062.7
	BYTE	bUAlign1FrontAlarm:1;				// 8 : R1062.8
	BYTE	bUAlignPalteAlarm:1;				// 9 : R1062.9
	BYTE	bUAlignROnOffAlarm:1;				// 10 : R1062.A
	BYTE	bUCardLockAlarm:1;					// 11 : R1062.B
	BYTE	bULifterAlarm:1;					// 12 : R1062.C
	BYTE	bDummyR1062_13:1;					// 13
	BYTE	bUNGTableForBackAlarm:1;			// 14 : R1061.E
	BYTE	bUPaperTableForBackAlarm:1;			// 15 : R1061.F

	// R1063
	BYTE	bTurnTableForBackAlarm:1;			// 0 : R1063.0
	BYTE	bTurnTableUpDownAlarm:1;			// 1 : R1063.1
	BYTE	bTurnTableVacuumAlarm:1;			// 2 : R1063.2
	BYTE	bLoadLeftPickerPCBAlarm:1;			// 3 : R1063.3
	BYTE	bLoadRightPickerPCBAlarm:1;			// 4 : R1063.4 
	BYTE	bUnloadLeftPickerPCBAlarm:1;		// 5 : R1063.5
	BYTE	bUnloadRightPickerPCBAlarm:1;		// 6 : R1063.6
	BYTE	bLoadPosAlarm:1;					// 7 : R1063.7 
	BYTE	bUnloadPosAlarm:1;					// 8 : R1063.8
	BYTE	bLoadBoxNoExist:1;					// 9 
	BYTE	bUnloadBoxNoExist:1;				// 10
	BYTE	bNoUsePaperLoadPaper:1;				// 11
	BYTE	bNoUsePaperUnloadPaper:1;			// 12
	BYTE	bPaperNoExist:1;					// 13
	BYTE	bPaperBoxFull:1;					// 14
	BYTE	NGBoxFull:1;						// 15

	WORD    wDummyR1064_1069[6];

	WORD	bLoadSafePos;						// R1070
	WORD	bUnloadSafePos;						// R1071
	WORD	bLdElvPCBExist;						// R1072
	WORD	bStartMode;							// R1073
	WORD	bPCBDownDanger;						// R1074
	WORD	bAlignTablePCBExist;				// R1075
};

struct PLC_BIT_SIGNAL_ALARM
{
	//R1050
	WORD	bInputLoadBasket;				// 0 : R1050
	WORD	bOutputLoadBasket;				// 1 : R1051
	WORD	bInputUnlodBasket;				// 2 : R1052
	WORD	bOutputUnloadBasket;			// 3 : R1053
	WORD	bChangeDirection;				// 4 : R1054
	WORD	bDummyR1054;					// 
	WORD	wLoaderPos[2];					// 6 ~ 7 : R1056  
	WORD	wUnloaderPos[2];				// 8 ~ 9 : R1058 

	//R1060
	BYTE	bEStopAlarm:1;						// 0 : R1060.0
	BYTE	bPLCBATAlarm:1;						// 1 : R1060.1
	BYTE	bAirDownAlarm:1;					// 2 : R1060.2
	BYTE	bDoorOpenAlarm:1;					// 3 : R1060.3
	BYTE	bAxis1LoadXAlarm:1;					// 4 : R1060.4
	BYTE	bAxis2LoadZLAlarm:1;				// 5 : R1060.5
	BYTE	bAxis3LoadZRAlarm:1;				// 6 : R1060.6
	BYTE	bAxis4UnloadXAlarm:1;				// 7 : R1060.7
	BYTE	bAxis5UnloadZLAlarm:1;				// 8 : R1060.8
	BYTE	bAxis6UnloadZRAlarm:1;				// 9 : R1060.9 
	BYTE	bAxis7LoadAlign1Alarm:1;			// 10 : R1060.A
	BYTE	bAxis8LoadAlign2Alarm:1;			// 11 : R1060.B
	BYTE	bAxis9LoadAlign3Alarm:1;			// 12 : R1060.C
	BYTE	bAxis10LoadAlign4Alarm:1;			// 13 : R1060.D
	BYTE	bAxis11UnloadAlign1Alarm:1;			// 14 : R1060.E
	BYTE	bAxis12UnloadAlign2Alarm:1;			// 15 : R1060.F

	//R1061
	BYTE	bAxis13UnloadAlign3Alarm:1;			// 0 : R1061.0 
	BYTE	bAxis14UnloadAlign4Alarm:1;			// 1 : R1061.1
	BYTE	bLoadHomeAlarm:1;					// 2 : R1061.2
	BYTE	bLoadLeftExistAlarm:1;				// 3 : R1061.3
	BYTE	bLoadRightExistAlarm:1;				// 4 : R1061.4
	BYTE	bLoadAlignExistAlarm:1;				// 5 : R1061.5
	BYTE	bUnloadHomeAlarm:1;					// 6 : R1061.6
	BYTE	bUnloadLeftExistAlarm:1;			// 7 : R1061.7
	BYTE	bUnloadRightExistAlarm:1;			// 8 : R1061.8
	BYTE	bUnloadAlignExistAlarm:1;			// 9 : R1061.9
	BYTE	bDummyR1061_10:1;					// 10 : 
	BYTE	bDummyR1061_11:1;					// 11 : 
	BYTE	bLoadIonizer1Alarm:1;				// 12 : R1061.C
	BYTE	bLoadIonizer2Alarm:1;				// 13 : R1061.D
	BYTE	bUnloadIonizer1Alarm:1;				// 14 : R1061.E
	BYTE	bUnloadIonizer21Alarm:1;				// 15 : R1061.F

	// R1062
	BYTE	bLoadMainPCBDropAlarm:1;				// 0 : R1062.0
	BYTE	bUnloadMainPCBDropAlarm:1;			// 1 : R1062.1
	BYTE	bDummyR1062_2:1;				// 2 : R1062.2
	BYTE	bDummyR1062_3:1;				// 3 : R1062.3
	BYTE	bDummyR1062_4:1;					// 4 :
	BYTE	bDummyR1062_5:1;					// 5 :
	BYTE	bDummyR1062_6:1;					// 6 : 
	BYTE	bDummyR1062_7:1;					// 7 : 
	BYTE	bLoadLeftSuctionAlarm:1;			// 8 : R1062.8
	BYTE	bLoadRightSuctionAlarm:1;			// 9 : R1062.9
	BYTE	bLoad2PCBAlarm:1;					// 10 : R1062.A
	BYTE	bLoadLeftPCBSizeAlarm:1;			// 11 : R1062.B
	BYTE	bLoadRightPCBSizeAlarm:1;			// 12 : R1062.C
	BYTE	bLoadLeftPCBExistAlarm:1;			// 13 : R1062.D
	BYTE	bLoadrightCBExistAlarm:1;			// 14 : R1061.E
	BYTE	bDummyR1062_15:1;					// 15 : 

	// R1063
	BYTE	bUnloadLeftSuctionAlarm:1;			// 0 : R1063.0
	BYTE	bUnloadRightSuctionAlarm:1;			// 1 : R1063.1
	BYTE	bUnload2PCBAlarm:1;					// 2 : R1063.2
	BYTE	bUnloadLeftPCBSizeAlarm:1;			// 3 : R1063.3
	BYTE	bUnloadRightPCBSizeAlarm:1;			// 4 : R1063.4 
	BYTE	bUnloadLeftPCBExistAlarm:1;			// 5 : R1063.5
	BYTE	bUnloadrightCBExistAlarm:1;			// 6 : R1063.6
	BYTE	bDummyR1063_7:1;					// 7 : R1063.7
	BYTE	bLoadAlignSuctionAlarm:1;			// 8 : R1063.8
	BYTE	bLoadAlignExistnAlarm:1;			// 9 : R1063.9
	BYTE	bLoadAlignLeftForwardAlarm:1;		// 10 : R1063.A
	BYTE	bLoadAlignLeftBackwardAlarm:1;		// 11 : R1063.B
	BYTE	bLoadAlignRightForwardAlarm:1;		// 12 : R1063.C
	BYTE	bLoadAlignRightBackwardAlarm:1;		// 13 : R1063.D
	BYTE	bDummyR1063_14:1;					// 14
	BYTE	bDummyR1063_15:1;					// 15

	// R1064
	BYTE	bUnloadAlignSuctionAlarm:1;			// 0 : R1064.0
	BYTE	bUnloadAlignExistnAlarm:1;			// 1 : R1064.1
	BYTE	bUnloadAlignLeftForwardAlarm:1;		// 2 : R1064.2
	BYTE	bUnloadAlignLeftBackwardAlarm:1;	// 3 : R1064.3
	BYTE	bUnloadAlignRightForwardAlarm:1;		// 4 : R1064.4 
	BYTE	bUnloadAlignRightBackwardAlarm:1;	// 5 : R1064.5
	BYTE	bDummyR1064_6:1;					// 6 : 
	BYTE	bDummyR1064_7:1;					// 7 : 
	BYTE	bLoadPaperNoAlarm:1;				// 8 : R1064.8
	BYTE	bLoadPaperFULLAlarm:1;				// 9 : R1064.9
	BYTE	bLoadPaperTableForwardAlarm:1;		// 10 : R1064.A
	BYTE	bLoadPaperTableBackwardAlarm:1;		// 11 : R1064.B
	BYTE	bDummyR1064_12:1;					// 12 : 
	BYTE	bDummyR1064_13:1;					// 13 : 
	BYTE	bLoadPaperNoUseExistAlarm:1;		// 14 : R1064.E
	BYTE	bDummyR1064_15:1;					// 15 : 

	// R1065
	BYTE	bUnloadPaperNoAlarm:1;				// 0 : R1065.0
	BYTE	bUnloadPaperFULLAlarm:1;				// 1 : R1065.1
	BYTE	bUnloadPaperTableForwardAlarm:1;		// 2 : R1065.2
	BYTE	bUnloadPaperTableBackwardAlarm:1;		// 3 : R1065.3
	BYTE	bDummyR1065_4:1;					// 4 :  
	BYTE	bDummyR1065_5:1;					// 5 : 
	BYTE	bUnloadPaperNoUseExistAlarm:1;		// 6 : R1065.6
	BYTE	bDummyR1065_7:1;					// 7 : 
	BYTE	bLoadBoxNoExistAlarm:1;				// 8 : R1065.8
	BYTE	bLoadBoxDropAlarm:1;				// 9 : R1065.9
	BYTE	bLoadLiftUpAlarm:1;					// 10 : R1065.A
	BYTE	bLoadLiftDownAlarm:1;				// 11 : R1065.B
	BYTE	bLoadCartLockAlarm:1;				// 12 : R1065.C
	BYTE	bLoadCartUnlockAlarm:1;				// 13 : R1065.D
	BYTE	bDummyR1065_14:1;					// 14 : 
	BYTE	bDummyR1065_15:1;					// 15 : 

	//R1066
	BYTE	bUnloadBoxNoExistAlarm:1;				// 0 : R1066.0
	BYTE	bUnloadBoxDropAlarm:1;				// 1 : R1066.1
	BYTE	bUnloadLiftUpAlarm:1;					// 2 : R1066.2
	BYTE	bUnloadLiftDownAlarm:1;				// 3 : R1066.3
	BYTE	bUnloadCartLockAlarm:1;				// 4 : R1066.4
	BYTE	bUnloadCartUnlockAlarm:1;				// 5 : R1066.5
	BYTE	bUnloadLiftMiddlePosAlarm:1;			// 6 : R1066.6
	BYTE	bDummyR1066_7:1;					// 7 : 
	BYTE	bDummyR1066_8:1;					// 8 : 
	BYTE	bDummyR1066_9:1;					// 9 : 
	BYTE	bDummyR1066_10:1;					// 10 : 
	BYTE	bDummyR1066_11:1;					// 11 : 
	BYTE	bDummyR1066_12:1;					// 12 : 
	BYTE	bDummyR1066_13:1;					// 13 : 
	BYTE	bDummyR1066_14:1;					// 14 : 
	BYTE	bDummyR1066_15:1;					// 15 : 

	//R!067
	BYTE	bTurnPCBExistAlarm:1;				// 0 : R1067.0
	BYTE	bTurnSuctionAlarm:1;				// 1 : R1067.1
	BYTE	bTurnPCBSizeAlarm:1;				// 2 : R1067.2
	BYTE	bTurnPCBDropAlarm:1;				// 3 : R1067.3
	BYTE	bTurnUnitForwardAlarm:1;			// 4 : R1067.4
	BYTE	bTurnUnitBackwardAlarm:1;			// 5 : R1067.5
	BYTE	bTurnUnitTurnAlarm:1;				// 6 : R1067.6
	BYTE	bTurnUnitReturnAlarm:1;				// 7 : R1067.7
	BYTE	bTurnUnitUpAlarm:1;					// 8 : R1067.8
	BYTE	bTurnUnitdownAlarm:1;				// 9 : R1067.9
	BYTE	bDummyR1067_10:1;					// 10 : 
	BYTE	bDummyR1067_11:1;					// 11 : 
	BYTE	bDummyR1067_12:1;					// 12 : 
	BYTE	bDummyR1067_13:1;					// 13 : 
	BYTE	bDummyR1067_14:1;					// 14 : 
	BYTE	bDummyR1067_15:1;					// 15 : 

	WORD    wDummyR1068_1069[2];

	WORD	bLoadSafePos;						// R1070
	WORD	bUnloadSafePos;						// R1071
	WORD	bLdElvPCBExist;						// R1072
	WORD	bStartMode;							// R1073
	WORD	bPCBDownDanger;						// R1074
	WORD	bAlignTablePCBExist;				// R1075
};


class DeviceMelsecLarge : public CWnd  
{
public:
	static  UINT ThreadStatus(LPVOID pParam);
	static UINT ThreadInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceMelsecLarge();
	virtual ~DeviceMelsecLarge();

protected:
	CWinThread*		m_thdStatus;
	int				m_nAxisMax;
	LONG			m_lErrorHandlerMain;
	LONG			m_lErrorHandlerLoader;
	LONG			m_lErrorHandlerUnloader;
	LONG			m_lErrorHandlerEtc1;
	LONG			m_lStatusBasket;


	LONG			m_lErrorHandler1060;
	LONG			m_lErrorHandler1061;
	LONG			m_lErrorHandler1062;
	LONG			m_lErrorHandler1063;
	LONG			m_lErrorHandler1064;
	LONG			m_lErrorHandler1065;
	LONG			m_lErrorHandler1066;
	LONG			m_lErrorHandler1067;

public:
	BOOL SetNoUseSuction(BOOL bNoUse);
	BOOL SetLoaderCartPCB(BOOL bNoUse);
	BOOL SetSafetyMode(int bNoUse);
	BOOL Set2DBarcodeTrigger();
	BOOL SetVibration(int nCount);
	BOOL SetNGPanel(int nNG);
	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetPCBSize(BOOL bLarge);
	BOOL SetTrunPanel(BOOL bTurn);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetUnloadBasketSignal(BOOL bIn);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetReverseDirection();
	BYTE GetBasketIn();
	

	BOOL CheckMelsecConnect();
	void ReadStautsOther();
	BOOL IsUPVacuum(BOOL b1st, BOOL bOn);
	BOOL IsLPVacuum(BOOL b1st, BOOL bOn);
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL IsHandlerPaperTransPCBExist(BOOL bLoader);
	BOOL IsHandlerPartError(BOOL bLoader);

	int GetWritePos(int nAxis);
	int GetCurrentPos(int nAxis);
	void GetBitSiganl(PLC_BIT_SIGNAL_FX* pData);
	int GetAxisMax();
	CString MakeRCode(int nCode);
	MMelsecFx*		m_pMelsec;

	BOOL IsHandlerBusy(int nAxis);
	BOOL IsHandlerStop(int nAxis);	

	BOOL IsReady(int nAxis = -1);
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);

	void ReadStatus(BOOL bFirst);
	void ReadBasket();
	void ReadPosition();
	void ReadErrorHandlerMain();
	void ReadErrorHandlerLoader();
	void ReadErrorHandlerUnloader();
	void ReadErrorHandlerEtc1();

	void ReadErrorHandler1060();
	void ReadErrorHandler1061();
	void ReadErrorHandler1062();
	void ReadErrorHandler1063();
	void ReadErrorHandler1064();
	void ReadErrorHandler1065();
	void ReadErrorHandler1066();
	void ReadErrorHandler1067();
	
	LONG GetCurrentError(ERRORCOMMAND nError);

	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE);
	BOOL IsAlignerPCBExist();
	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsResetSwitch();
	BOOL IsSystemDoorBypass(BOOL bLoader);
	BOOL IsAnyMotorRun();
	BOOL IsLoadCartNoPCB();
	BOOL SendLoadCartNoPCB();

	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);

	BOOL LoaderAlign();
	BOOL LoaderLoading();
	BOOL UnloadUnloading();
	BOOL LoaderInit();
	BOOL UnloaderInit();
	BOOL LoaderAlignLoading();
	
	BOOL MainReset(BOOL bOn);
	BOOL UnloaderPCBReset();
	BOOL LoaderPCBReset();

	BOOL LoaderCarrierElvPos();
	BOOL LoaderCarrierTablePos();
	BOOL UnloaderCarrierElvPos();
	BOOL UnloaderCarrierTablePos();

	BOOL LoaderPickerUpPos(int nNum);
	BOOL UnloaderPickerUpPos(int nNum);

	BOOL UseRoll(BOOL bUse);
	BOOL UsePaper(BOOL bUse);

	// no use func
	BOOL LoaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL UnloaderClampForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderTableForward();
	BOOL UnloaderTableBackward();
	BOOL IsLoaderAlignTableForward();
	BOOL IsUnloaderAlignTableForward();
	BOOL IsLoaderCartClamp();
	BOOL IsAlignSheetTableForward();
	BOOL IsAlignGuideForward();
	BOOL IsUnloaderCartClamp();
	BOOL IsUnloaderNGBoxForward();
	BOOL IsUnloaderNGBoxBackward();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL IsStartMode();
	BOOL m_bStatusStop; // Thread Stop Signal
	PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
	
	PLC_BIT_SIGNAL_FX	m_NewPLCBitSignal;
	PLC_BIT_SIGNAL_FX	m_OldPLCBitSignal;

	PLC_BIT_SIGNAL_ALARM m_NewPLCBitSignalAlarm;

	long			m_lWritePos[HANDLER_AXIS_MAX];
	BOOL			m_bIsInPosition[HANDLER_AXIS_MAX];
	double			m_dScale[HANDLER_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;

	int				m_nInPositionCount;
	int				m_nInPositionError;

	int				m_nInposTimeCount;
	int				m_nPosition[2]; //load unload pos
	BOOL			m_bConnect;
	BOOL			m_bWriteLog;

	CDlgMelsecOCX*	theMelsecDlg;

	short	m_nLoader_ReadPLCSignal[OCX_READ_MELSEC_SIZE];

};

#endif // !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
