// MMelsec.h: interface for the MMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MMELSEC_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_)
#define AFX_MMELSEC_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#pragma comment(lib, "ws2_32.lib")

//#include <winsock2.h>

const int MAXBUFSIZE = 256;
#define MAX_DATA_SIZE		512

const WORD  CMD_TOTAL_READ		= 0x401;
const WORD  CMD_RANDOM_READ		= 0x403;
const WORD  CMD_TOTAL_WRITE		= 0x1401;

const WORD  SUBCMD_BIT			= 0x0001;
const WORD  SUBCMD_WORD			= 0x0000;

const BYTE  INTERNALRELAY		= 0x90;
const BYTE  DATAREGISTER		= 0xA8;

#define BASE_READ_ADDRESS		1500
#define BASE_WRITE_ADDRESS		1000
#define REC_DATA_DEVICE_NO_POS	4
#define REC_DATA_HEAD_LENG		6
#define EXCEPT_CHAR_LENG		9
#define SIZE_WAIT_TIME			2

struct QSEND_HEADER
{
	BYTE	cSubHeader1;			// sub-header no
	BYTE	cSubHeader2;			// sub-header no
	BYTE	cNetworkNo;
	BYTE	cPLCNo;
	BYTE	wModuleIONo[2];		// demanding module I/O No
	BYTE	cModuleNo;			// demanding module No
	BYTE	wDataLength[2];		// demanding data length
	BYTE	wCPUWaitTime[2];		// CPU Waiting time
};

struct QREC_HEADER
{
	BYTE	cSubHeader1;			// sub-header no
	BYTE	cSubHeader2;			// sub-header no
	BYTE	cNetworkNo;
	BYTE	cPLCNo;
	BYTE	wModuleIONo[2];		// demanding module I/O No
	BYTE	cModuleNo;			// demanding module No
	BYTE	wDataLength[2];		// demanding data length
	BYTE	wEndCode[2];			// End code
};

struct QSEND_DATA
{
	QSEND_HEADER	sHeader;				// QSEND_HEADER
	BYTE			cData[MAX_DATA_SIZE];	// real data
};

struct QREC_DATA
{
	QREC_HEADER		sHeader;				// QSEND_HEADER
	BYTE			cData[MAX_DATA_SIZE];	// real data
};


class MMelsec  
{
public:
	MMelsec();
	virtual ~MMelsec();
	
	// Operations
public :
	BOOL WriteMemsbyWord(WORD *wData, WORD wAddress, BYTE cMemoryKind, WORD nSize);
	BOOL WriteBitMembyBits(BYTE *cData, WORD wAddress, WORD nSize);
	BOOL ReadBitMembyBits(BYTE *cData, WORD wAddress, WORD nSize);
	BOOL ReadMemsbyWord(WORD* wData, WORD wAddress, BYTE cMemoryKind, WORD nSize);
	void InitCommand();
	BOOL			Create();
	BOOL			InitWinSock();
	BOOL			Connect();
	void			CloseWinSock();
	
	int				SendMsg(char* pData, int nDataSize);
	int				RecvMsg(char* pData, int nDataSize);
	
	void			ShowErrMsg(CString strMsg);
	
	BOOL			IsConnect();
	
	int				GetCommErrorCount()		{ return m_nCommErrorCount; }
	
	//Attributes
protected :
	QSEND_DATA		m_qSendData;
	QREC_DATA		m_qRecieveData;

	CRITICAL_SECTION	m_CritSocket;
	SOCKET			m_hLocalSocket;
	
	USHORT			m_nDestPortNo;
	CString			m_strDestAddr;
	SOCKADDR_IN		m_sDestAddr;
	
	USHORT			m_nLocalPortNo;
	CString			m_strLocalAddr;
	SOCKADDR_IN		m_sLocalAddr;
	
	int				m_nCommErrorCount;

	int				m_nTimeOut;
};

#endif // !defined(AFX_MMELSEC_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_)
