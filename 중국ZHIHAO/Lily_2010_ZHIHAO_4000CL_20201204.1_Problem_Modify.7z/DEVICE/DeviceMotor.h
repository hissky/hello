// DeviceMotor.h: interface for the DeviceMotor class.
//////////////////////////////////////////////////////
#if !defined(AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_)
#define AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define FIRST_PANEL_OFFSET	1
#define SECOND_PANEL_OFFSET	2
#define DELTA_PANEL_OFFSET	3

#define TOWER_GREEN		1
#define TOWER_YELLOW	2
#define TOWER_RED		4

enum { INDEX_LEFT_VAC_SOL=0,			// table ����
		CHUCK_CLAMP_SOL = 2,			// chuck clamp on/off
		SHUTTER_OPEN_CLOSE_SOL = 4,		// �ε� ����
		SUCTION_MOTOR_ON,				// dust suction power on
		FLUORESCENT_LAMP,				// ������
		START_SW_LAMP,					// start ��ư ����
		STOP_SW_LAMP,					// stop ��ư ����
	    TOWER_LAMP_GREEN,				
	    TOWER_LAMP_YELLOW, 
	    TOWER_LAMP_RED, 
	    BUZZER,
		AIR_BLOWER,						// 5�� �Ѱ� air �ѱ�
		BRUSH_MOTOR_ON,					// brush motor ȸ��
		BRUSH_SOL,						// brush down/up
		LASER_MARKING_START,			// do not need
		RESET_SW_LAMP = 25};			// reset ��ư ����


#ifdef __PUSAN1__	
	class DeviceUMacPusan1;
	#include "DeviceUMacPusan1.h"
#endif
	
#ifdef __PUSAN2__ 
	class DeviceUMacPusan2;
	#include "DeviceUMacPusan2.h"
#endif

#ifdef __KUNSAN_6__	
	class DeviceUMacKunsan6;
	#include "DeviceUMacKunsan6.h"
#endif
	
#ifdef __KUNSAN_8__	
	class DeviceUMacKunsan8;
	#include "DeviceUMacKunsan8.h"
#endif
	
#ifdef __PUSAN_OLD_17__
	class DeviceUMac;
	#include "DeviceUMac.h"
#endif
	
#ifdef __PUSAN_OLD_32__
	class DeviceUMac;
	#include "DeviceUMac.h"
#endif

#ifdef __PUSAN_LDD__
	class DeviceUMacPusan1;
	#include "DeviceUMacPusan1.h"
#endif

#ifdef __KUNSAN_1__	
	class DeviceUMacKunsan1;
	#include "DeviceUMacKunsan1.h"
#endif

#ifdef __OSAN_LG__
	class DeviceUMacOsan;
	#include "DeviceUmacOsan.h"
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__
	class DeviceUMacLarge;
	class DeviceMelsecLarge;
	#include "DeviceUmacLarge.h"
	#include "DeviceMelsecLarge.h"
#else
	class DeviceMelsecOsan;
	#include "DeviceMelsecOsan.h"
#endif


class DevicePMac;
#include "DevicePMac.h"

class CDevMCCDaq;
class CDevVoltage;
class CDevTemperCompen;
class CDevHumidity;
class CDevChiller;
class CSysUMAC;
class DeviceComiZoa;
class CComiDaq;
class CComiMotion;

class CCalibration;
class CZCalibration;

struct CALHEAD;

class TCalibration;
struct CALDATA;

class DeviceMotor
{
public:
	DeviceMotor();
	virtual ~DeviceMotor();

public:

	BOOL SetNoUseLoadUnload(BOOL bNoUse);
	BOOL GetLPCStatus();
	BOOL SetNoUseSuction(BOOL bNoUse);
	BOOL Set2DBarcodeTrigger();
	BYTE GetBasketIn();
	BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd);
	BYTE GetUnloadPickerDownOK();
	BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd);
	BYTE GetLoadPickerDownOK();
	BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL IsStartMode();
	BOOL IsAlignReady();
	BOOL IsUnloadReady();
	void SetTemeratureLimits();
	void	ReadAddressTemperatureComp();
	void	GetTemperatureForAllCh (double* dTemper);
	void	GetTCTemperature (double& d1stTemper, double& d2ndTemper);
	void	GetSBTemperature (double& d1stTemper, double& d2ndTemper);
	BOOL UiAlivePulse(BOOL bOn);
	BOOL MoveLaserBeamPath(BOOL bUp);
	BOOL GetAOMAlarm();
	BOOL IsResetSwitch();
	BOOL IsHandlerPartError(BOOL bLoader);
	BOOL IsHoodOK(BOOL bOpen);
	BOOL HoodOpen(BOOL bOpen);
	BOOL GetScannerStatus();
	BOOL GetAOMStatus();
	BOOL SetError(BOOL bError);
	BOOL SetAOMPowerON(BOOL bOn);
	BOOL ScannerPower(BOOL bOn);
	BOOL IsAnyError();
	/* Table IO Control -------------------------------------------------- */
	BOOL InPositionIO2(int nAxis);
	BOOL InPositionIO(int nAxis);
	BOOL SetMoveIO(int nMoveAxis);
	BOOL IsCmdPosOK();
	BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	/* Table IO Control end ---------------------------------------------- */
	BOOL MotorMoveXY(double dPosX, double dPosY, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	BOOL MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	
	BOOL InitMotor(CComiMotion* pMotion, CComiDaq* pDaq); 
	BOOL DestroyMotor();

	// Purpose		: �ڵ����
	BOOL	SetAxis(int nAxis, SAXISINFO pSet);
	BOOL	GetAxis(int nAxis, SAXISINFO& pGet);

	BOOL	SetAxisMax(int nAxisMax);

	double	GetMoveSpeed(int nAxis);

public:

	#ifdef __KUNSAN_SAMSUNG_LARGE__
		PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
	#else
		PLC_BIT_SIGNAL GetMelsecIOStuct();
	#endif
	
	BOOL GetReverseReady();
	BOOL GetChillerRun();
	BOOL SetNGPanel(int nNG);
	int	GetDustSuctionValue();
	int	GetTableVauumValue(BOOL b1st);
	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetPCBSize(BOOL bSmall);
	BOOL SetTrunPanel(BOOL bTurn);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetUnloadBasketSignal(BOOL bIn);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetReverseDirection();

	void DisconnectAnyDevice(int nType);
	void ConnectAnyDevice(int nType); // 0 : chiller 1: thermo-hyprometer
	void ReadTemperatureComp();
	void GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint);
	void GetVoltage(double& dV, double& dA,double& dKw);
	double GetVolateSubData(int nIndex);
	double GetChillerTemp();
	BOOL GetAOMTime();
	BOOL IsHandlerReady(int nAxis);
	BOOL CheckMelsecConnect();
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	BOOL IsHandlerPaperTransPCBExist(BOOL bLoader);
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL UsePaper(BOOL bUse);
	BOOL UseRoll(BOOL bUse);
	BOOL UnloaderPicker3Init();
	BOOL LoaderPicker3Init();
	BOOL IsHandlerDoorBypass(BOOL bLoader);
	BOOL IsHandlerInitEnd(int nAxis);
	BOOL IsHandlerStop(int nAxis);
	BOOL IsHandlerBusy(int nAxis);
	BOOL IsOrigin(int nAxis);
	BOOL Connect(int nPortNo, long lBaudrate);
	BOOL Disconnect();
	BOOL MoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2);
	BOOL MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2);
	BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);
	BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);

	BOOL NoUseClamp(BOOL bNoUse);
	BOOL IsBMMotorHomeEnd();
	BOOL SetOutportTableVacuum(BOOL bUseBTable);
	BOOL LoaderCarrierCartPos();
	BOOL LoaderCarrierCartPos2();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL SetLimitYPos(double dPos);
	BOOL GetCurrentSuctionMotor();
	BOOL MoveTophatShutter(BOOL bUp);
	void SetFixedMaskPos(double dPos);
	void Set2DTableCompOffset();
	BOOL IsDustCollectorOn();
	BOOL IsIonizerAirOn();
	void GetTowerLampBuzzer(int &nColor, BOOL & bBuzzer);
	void IonizerOn(BOOL bOn);
	void SetTowerLampBuzzer(int nColor, BOOL bBuzzer);
	void SetDustSuction(BOOL bOn);
	double	m_dXLimitM;
	double	m_dXLimitP;
	double	m_dYLimitM;
	double	m_dYLimitP;

	void ReadTableLimit();
	double GetMPosition(int nIndex);
	double GetMoveAccel(int nAxis);
	// comizoa
	BOOL GetSystemAir();
	BOOL GetChuckStatus(BOOL bClamp);
	BOOL GetLoadingShutterStatus(BOOL bOpen);
	BOOL GetStartSW();
	BOOL GetStopSW();
	BOOL GetResetSW();
	BOOL GetBrushStatus(BOOL bUp);
	BOOL IsFrontDoorOpen();
	BOOL IsLeftDoorOpen();
	BOOL IsRear1DoorOpen();
	BOOL IsRear2DoorOpen();
	BOOL IsRightDoorOpen();
	// comizoa

	BOOL WriteOutPort(int nAdd, BOOL bOn);
	BOOL WriteLoadUnload(int nAdd, BOOL bOn);
	void	SetAxisSpeed(int nAxis, double dSpeed);
	void	SetOriginalSpeed();
	BOOL	DownloadAxisInfo();
	BOOL	DownloadAutoSetting();
	BOOL	SetAutoSetting(SAUTOSETTING sAutoSetting);
	BOOL	SetAxisInfo(SAXISINFO* sAxisInfo);
	
	void	SetMotorType(int nType)		{ m_nMotorType = nType; }
	int		GetMotorType()				{ return m_nMotorType; }
	
	void	SetCalType(int nCalType)	{ m_nCalType = nCalType; }
	int		GetCalType()				{ return m_nCalType; }
	
	void	SetUseDualPanel(int nDual)	{ m_nUseDualPanel = nDual; }
	int		GetUseDualPanel()			{ return m_nUseDualPanel; }

	void SetCurrentCycle(BYTE cCycle);
	void UpdateZCalibrationFile(CALHEAD& calHead, BOOL bFirst);
	void LoadZCalibrationFile(CString strPath, BOOL bFirst);
	void GetZMoveOffset(double dX, double dY, double &dOffset, BOOL bFirst);
	UINT IsScannerFault();

	void UpdateTCalibrationFile(CALDATA& calData);
	void LoadTCalibrationFile(CString strPath);
	void GetTMoveOffset(double dPos, double &dOffset);

	BOOL	Initialize();

	BOOL	SetOrigin(int nAxis = -1);

	double	GetPosition(int nAxis, BOOL b1stPanel = TRUE);
	
	BOOL	GetPosition(int nAxis, double& dPosition, BOOL b1stPanel = TRUE);

	BOOL	GetRawPosition(int nAxis, double& dPosition);

	void	GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag);
	void	UpdateCalibrationFile(CString strPath);

	BOOL	MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);

	BOOL	SetLimitZ(); // yhchung 061024 Set Limit Axis-Z
	BOOL	SetVibration(); // Vibration Count & Delay

	BOOL	MoveXY(double dPosX, double dPosY, BOOL b1stPanel = TRUE, BOOL bMoveFire = FALSE, BOOL bPass = FALSE);
	BOOL	MoveZ(double dPosZ1, BOOL bRawMove = FALSE);
	BOOL	MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove = FALSE);
	
	BOOL	MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);	
	
	BOOL	MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE, BOOL bTophat = FALSE);

	BOOL	MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE);

	BOOL	MoveMC(double dMaskPos, double dPosC);

	BOOL	MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat = FALSE);
	BOOL	MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2,double dPosA, double dPosA2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE, BOOL bTophat = FALSE);
	

	BOOL	MotorShutterAll(BOOL bOpenMaster = TRUE, BOOL bOpenSlave = TRUE);

	// Load Command
	BOOL	LoaderElvOriginPos();
	BOOL	LoaderElvLoadPos();
	BOOL	LoaderCarrierAlignPos();
	BOOL	LoaderCarrierAlignPos2();
	BOOL	LoaderCarrierLoadPos();
	BOOL	LoaderPicker1Init();
	BOOL	LoaderPicker1Align();
	BOOL	LoaderPicker1Load();
	BOOL	LoaderPicker1P2();
	BOOL	LoaderPicker2Init();
	BOOL	LoaderPicker2Align();
	BOOL	LoaderPicker2Load();
	BOOL	LoaderPicker2P2();
	BOOL	LoaderClampForward();
	BOOL	LoaderClampBackward();
	BOOL	LoaderVacuum1On();
	BOOL	LoaderVacuum1Off();
	BOOL	LoaderVacuum2On();
	BOOL	LoaderVacuum2Off();
	BOOL	LoaderBlow1On();
	BOOL	LoaderBlow1Off();
	BOOL	LoaderBlow2On();
	BOOL	LoaderBlow2Off();
	BOOL	LoaderTableForward();
	BOOL	LoaderTableBackward();
	BOOL	LoaderAlignXForward();
	BOOL	LoaderAlignXBackward();
	BOOL	LoaderAlignYForward();
	BOOL	LoaderAlignYBackward();
	BOOL	IsLoaderPicker1PCBExist();
	BOOL	IsLoaderPicker2PCBExist();
	BOOL	IsAlignerPCBExist();
	BOOL	IsULAlignerPCBExist();
	BOOL	IsLoader1Error();
	BOOL	IsLoader2Error();
	BOOL	IsAlignerError();
	BOOL	IsULAlignerError();
	BOOL	Loader1PCBExist(BOOL bOn);
	BOOL	Loader2PCBExist(BOOL bOn);
	BOOL	AlignTablePCBExist(BOOL bOn);
	BOOL	ULAlignTablePCBExist(BOOL bOn);
	BOOL	LoaderPickerPad(int nPicker, int nPad, BOOL bUp);
	BOOL	TablePCBReset();
	BOOL	LoaderPCBReset();
	BOOL	UnLoaderPCBReset();
	BOOL	TableCalibration(BOOL bAxisX);

	BOOL	TableClamp(BOOL bClamp, BOOL bLeft = TRUE);
	BOOL	GetCurrentMotorSol();
	BOOL	SendLoadCartNoPCB();

	BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff);
	BOOL WriteOutputDWord(UINT nAddr, DWORD dwVal);

	// UnLoad Command
	BOOL	UnloaderElvOriginPos();
	BOOL	UnloaderElvUnloadPos();
	BOOL	UnloaderCarrierTablePos();
	BOOL	UnloaderCarrierUnloadPos();
	BOOL	UnloaderCarrierAlignPos();
	BOOL	UnloaderPicker1Init();
	BOOL	UnloaderPicker1Table();
	BOOL	UnloaderPicker1Unload();
	BOOL	UnloaderPicker1P2();
	BOOL	UnloaderPicker2Init();
	BOOL	UnloaderPicker2Table();
	BOOL	UnloaderPicker2Unload();
	BOOL	UnloaderPicker2P2();
	BOOL	UnloaderClampForward();
	BOOL	UnloaderClampBackward();
	BOOL	UnloaderVacuum1On();
	BOOL	UnloaderVacuum1Off();
	BOOL	UnloaderVacuum2On();
	BOOL	UnloaderVacuum2Off();
	BOOL	UnloaderBlow1On();
	BOOL	UnloaderBlow1Off();
	BOOL	UnloaderBlow2On();
	BOOL	UnloaderBlow2Off();
	BOOL	UnloaderTableForward();
	BOOL	UnloaderTableBackward();
	BOOL	IsUnloaderPicker1PCBExist();
	BOOL	IsUnloaderPicker2PCBExist();
	BOOL	IsUnloader1Error();
	BOOL	IsUnloader2Error();
	BOOL	Unloader1PCBExist(BOOL bOn);
	BOOL	Unloader2PCBExist(BOOL bOn);
	BOOL	UnloadTablePCBExist(BOOL bOn);
	BOOL	UnloaderPickerPad(int nPicker, int nPad, BOOL bUp);

	BOOL	IsTable1PCBExist();
	BOOL	IsTable2PCBExist();
	BOOL	IsTable1Error();
	BOOL	IsTable2Error();

	BOOL	IsLCinCartPos();
	BOOL	IsLCinCartPos2();
	BOOL	IsLCinLoadPos();
	BOOL	IsLCinOriginPos();
	BOOL	IsLCinReadyPos();
	BOOL	IsUCinCartPos();
	BOOL	IsUCinUnloadPos();
	BOOL	IsUCinOriginPos();
	BOOL	IsLCinAlignPos();
	BOOL	IsLCinAlignPos2();
	BOOL	IsUCinAlignPos();
	
	BOOL	IsLP1P1Up();
	BOOL	IsLP1P2Up();
	BOOL	IsLP2P1Up();
	BOOL	IsLP2P2Up();
	BOOL	IsULP1P1Up();
	BOOL	IsULP1P2Up();
	BOOL	IsULP2P1Up();
	BOOL	IsULP2P2Up();
	BOOL	IsLoaderAlignTableForward();
	BOOL	IsUnloaderAlignTableForward();
	BOOL	IsLoaderCartClamp();
	BOOL	IsAlignSheetTableForward();
	BOOL	IsAlignGuideForward();
	BOOL	IsLoaderPicker1Vacuum();
	BOOL	IsLoaderPicker2Vacuum();
	BOOL	IsLoaderPicker1Blow();
	BOOL	IsLoaderPicker2Blow();
	BOOL	IsUnloaderCartClamp();
	BOOL	IsUnloaderPicker1Vacuum();
	BOOL	IsUnloaderPicker2Vacuum();
	BOOL	IsUnloaderPicker1Blow();
	BOOL	IsUnloaderPicker2Blow();
	BOOL	IsUnloaderNGBoxForward();
	BOOL	IsUnloaderNGBoxBackward();

	BOOL	Stop(int nAxis = -1);
	BOOL	InPositionStop();

	BOOL	IsLoadCartNoPCB();

	LONG	GetCurrentError(ERRORCOMMAND nError);
	BYTE	GetCurrentMode();
	BYTE	GetCurrentEMStop();
	BYTE	GetCurrentShutter1();
	BYTE	GetCurrentShutter2();
	BYTE	GetCurrentPowerMeter();
	BYTE	GetCurrentSuction();
	BOOL	GetCurrentAcrylSuction(BOOL b1st);
	BYTE	GetCurrentLoadDetect(int nUsePanel);
	BYTE	GetCurrentUnloadDetect();
	BYTE	GetExternalLaser();
	BOOL	GetCurrentHeight(BOOL bFirst, BOOL bDown);
	BOOL	GetCurrentVacuumMotor(BOOL b1st);
	int		GetMainAirValue();
	BOOL	IsLaserSystemWarning();
	BOOL	IsLaserOverTempFault();
	BOOL	SetOutPort(BYTE nPortNo, WORD wOnOff, BOOL bAbs=TRUE);

	int		IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	int		IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);

	BOOL	IsAnyMotorRun();
	
	BOOL	Table1VacuumMotor(BOOL bOn);
	BOOL	Table2VacuumMotor(BOOL bOn);

	BOOL TableVacuumSelect(BOOL bOn);

	BOOL	IsMotorStop(BOOL bFlag = TRUE);
	BOOL	IsReady(int nAxis = -1);

	BOOL IsFlowWater();
	BOOL IsTowerBuzzer();

	BOOL IsLaserKeyOn();
	BOOL IsFluorescentLampOn();

	void SetResetCmd();

// Add - Door Safety
	BOOL IsSystemDoorBypass();
	BOOL IsMainDoorStop();
	BOOL IsOpticsDoorStop();
	BOOL SetLoaderCartPCB(BOOL bNoUse);	
	BOOL SetSafetyMode(int nSafety);
	BOOL IsMainDoorOpen();
	BOOL IsLoaderDoorOpen();
	BOOL IsUnLoaderDoorOpen();
	BOOL IsOpticsDoorOpen();

	BOOL IsSafetyMode();

	BOOL	HandlerOperation(int nHadnlerOperationID, BOOL bAction=TRUE);
	BOOL	IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait=TRUE);

	BOOL	TableLoadPos();
	BOOL	TableUnloadPos(BOOL b1st = TRUE);
	
	BOOL	GetCurrentTableClamp(BOOL b1st, BOOL bClamp);

	BOOL	IsHandlerReady();
	BOOL	IsHandlerAlarm();
	BOOL	IsHandlerLotEnd();
	BOOL	IsHandler1stTableExist();
	BOOL	IsHandler2ndTableExist();
	BOOL	IsHandlerLoadReady();
	BOOL	IsHandlerLoadEnd();
	BOOL	IsHandlerLoadAlarm();
	BOOL	IsHandlerUnloadReady();
	BOOL	IsHandlerUnloadEnd();
	BOOL	IsHandlerUnloadAlarm();

	BOOL	MainReady(BOOL bOn = TRUE);
	BOOL	MainAlarm(BOOL bOn = TRUE);
	BOOL	MainStart(BOOL bOn = TRUE);
	BOOL	MainStop(BOOL bOn = TRUE);
	BOOL	MainReset(BOOL bOn = TRUE);
	BOOL	MainUseTable(int nUseTable = 3);
	BOOL	MainLoadReady(BOOL bOn = TRUE);
	BOOL	MainLoadEnd(BOOL bOn = TRUE);
	BOOL	MainUnloadReady(BOOL bOn = TRUE);
	BOOL	MainUnloadEnd(BOOL bOn = TRUE);
	BOOL	MainPCBExist(int nPCBExist = 3);
	BOOL	MainLotEnd(BOOL bOn = TRUE);
	BOOL	MainLoadStart(BOOL bOn = TRUE);
	BOOL	MainUnloadStart(BOOL bOn = TRUE);

	BOOL	DustSuctionControl(BOOL bLeft, BOOL bUp);

	BOOL	DustSuctionError();
	int		GetInpositionError();

	BOOL	SetAlarmTolLed(BOOL bOn);
	int		GetWaterFlow1Value();
	int		GetWaterFlow2Value();
	int		GetAOMWaterFlow1Value();
	int		GetAOMWaterFlow2Value();
	void	ReadAllError(int* pnVal);
	
	BOOL	SetWaterFlow1Value(double dVal);
	BOOL	SetWaterFlow2Value(double dVal);
	BOOL	SetMainAirValue(double dVal);
	BOOL	SetDustSuctionValue(double dVal);
	BOOL	SetTableVauumValue(BOOL b1st, double dVal);
	BOOL	GetMotorConnect(int nType);

protected:
	BOOL	IsAxisOver(int nAxis, CString strMessage);
	BOOL	IsValidAxisPosition(int nAxis, double& dPosition, int nMoveMode = 0, BOOL bPass = FALSE);
//	BOOL	IsValidAxisPosition(int nAxis, int& nPosition, int nMoveMode = 0, BOOL bPass = FALSE);
	void	ShowWarning(int nAxis, BOOL bIsMax);

	void	LoadCalibrationFile(CString strPath);

protected:
	BOOL			m_bReverse;
	BOOL			m_bAnyError;
	BOOL			m_bOldMelsecConnect;
	BOOL			m_bReadStatus;	
	int				m_nMotorType;
	int				m_nCalType;
	int				m_nUseDualPanel;
	volatile int	m_nAutoDataMax;				// ����� ������ ����
	int				m_nInpositionError;	
	SAXISINFO		m_pSetting[MOTOR_AXIS_MAX];				// ���ͼ��������� ����

	SAUTOSETTING	m_sAutoSetting;
	BOOL			m_bUmacConnect;
	BOOL			m_bMelsecConnect;
	double	m_dDestinationPos[30]; // ������ ũ��
	double	m_dCalibrationOffset[30];
	double	m_dSlaveCalibrationOffset[30];
	CCalibration*	m_Calibration;
	CCalibration*	m_SlaveCalibration;
	CZCalibration*  m_ZCalInfo1;
	CZCalibration*  m_ZCalInfo2;
	TCalibration*	m_TCalInfo;
	CDevChiller*	m_Chiller;
	CDevHumidity*	m_Humidity;
#ifdef __MCCDAQ_USE_FOR_TEMPERATURE__
	CDevMCCDaq* m_TemperatureMeasure;
#else
	CDevTemperCompen* m_TemperatureMeasure;
#endif

	CDevVoltage* m_Voltage;

#ifdef __PUSAN1__	
	DeviceUMacPusan1*	m_clsMotor;						// Umac class
#endif
	
#ifdef __PUSAN2__ 
	DeviceUMacPusan2*	m_clsMotor;
#endif

#ifdef __KUNSAN_6__	
	DeviceUMacKunsan6*	m_clsMotor;	
#endif

#ifdef __KUNSAN_8__	
	DeviceUMacKunsan8*	m_clsMotor;	
#endif
	
#ifdef __PUSAN_OLD_17__
	DeviceUMac*			m_clsMotor;
#endif

#ifdef __PUSAN_OLD_32__
	DeviceUMac*			m_clsMotor;
#endif

#ifdef __PUSAN_LDD__
	DeviceUMacPusan1*	m_clsMotor;				
#endif

#ifdef __KUNSAN_1__	
	DeviceUMacKunsan1*	m_clsMotor;	
#endif

#ifdef __OSAN_LG__
	DeviceUMacOsan*		m_clsMotor;
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	DeviceUMacLarge*	m_clsMotor;
#endif

	;

	DeviceComiZoa*  m_pComizorMotor;				// comizoa class
	DevicePMac*		m_clsPmacMotor;
	CSysUMAC*		m_clsUmacProgram;

#ifdef __KUNSAN_SAMSUNG_LARGE__
	DeviceMelsecLarge*	m_clsMelsec;
#else
	DeviceMelsecOsan*	m_clsMelsec;
#endif
	

public:
	int ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel);
	// Inposition Fail Axis No
};

#endif // !defined(AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_)
