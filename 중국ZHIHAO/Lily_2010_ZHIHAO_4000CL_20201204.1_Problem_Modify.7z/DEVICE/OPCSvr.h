//{{AFX_INCLUDES()
#include "evopcx.h"
//}}AFX_INCLUDES
#include "resource.h"
#include <sql.h>
#include <sqlext.h>
#include "..\UI\DlgMessageBox.h"
//#include "..\pattern_common.h"

#if !defined(AFX_OPCSVR_H__EA387407_1D3B_4EE0_9A54_B5BB88BCEE2B__INCLUDED_)
#define AFX_OPCSVR_H__EA387407_1D3B_4EE0_9A54_B5BB88BCEE2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OPCSvr.h : header file
//

typedef struct tagST_CTRL_ITEM
{
	long nIndex;
	long nTagType;
	double dValue;
	char cValue[1024];
}ST_CTRL_ITEM;


typedef long (__stdcall *lUpdateTagMessage)(long TagNum, LPCTSTR strValue, long lQuality);
typedef long (*InitOPC)();//(char* szModuleName);
typedef long (*UnInitOPC)();
typedef long (__stdcall *GetControl)(ST_CTRL_ITEM *ctrl);
/*
typedef long (__stdcall *Pt_UpdateTagStringByName)(long TagNum, LPCTSTR strValue, long lQuality);
typedef long (*Pt_InitOpc)();
typedef long (*Pt_UnInitOpc)();
typedef long (__stdcall *Pt_GetControl)(ST_CTRL_ITEM *ctrl);
*/
typedef struct tag_OPC_PARAM
{
	double dChillerTemp[2];
	double dScannerTemp[2];
	double dPowerMeasure[2];
	double dPowerTarget[2];
	double dPowerTargetMin[2];
	double dPowerTargetMax[2];
	double dVacuum[2];
	double dHeight[2];
	double dScale[2];
	int nMainTool;
	int nSubTool;
	int nToolType;
	int nBeamPath;
	int nDrillMethord;
	int nFreq;
	int nOnDelay;
	int nOffDelay;
	int nDrawSpeed;
	int nJumpSpeed;
	int nConnerDelay;
	int nJumpDelay;
	int LineDelay;
	char szAperture[128];
	double dLengthTol[2];
	double dHeadOffset[2][2][2];
	int nDummyType;
	int nShotFreq[15];
	double dShotDuty[15];
	double dSetChillerTemp[2];
	double dSetVacuum[2];
	double dMainAir;
	double dSetMainAir;
	double dDustSuction;
	double dSetDustSuction;
	double dWaterFlow[2];
	double dSetWaterFlow[2];
	double dTemp;
	double dHumidity;
	double dVoltage; //����
	double dCurrent; //���� 
	double dPower; //����

	double dAOMWaterFlow[2];
	int nAOMError[2];

	int nSubToolCount;
	int nSwitchUpdateTime[7]; //swtiching �������� ���� �ð� 
	int nConnectCount[3]; // 0 : server , 1: umac, 2: melsec  
	CPoint nScannerValue[2];//20190130
	double dRFValue[2];

}OPCPARAM;

 typedef struct tag_OPC_INI
 {
	 int nIndex;
	 char szCode[20];
 }OPCINI;
extern OPCPARAM gOPCParam;
/////////////////////////////////////////////////////////////////////////////
// COPCSvr dialog
class CDlgMessageBox;
class COPCSvr : public CDialog
{
// Construction
public:
	void SaveLog(CString strTag);
	void GetOPCTag(int nIndex, char* pTag);
	void ReadOPCINI();
	void ResetRecvSignal();
	void SetAIType(int nType);
	int	 GetAIType();
	BOOL GetPNLCheck();
	int	 GetRMSType();
	void SetPNLCheck(BOOL bCheck);
	void SetRMSType(int nType);
	bool IsFileExist(const CString &strFileName);
	void GetDiagonostics();
	BOOL SearchTagItem(int nErrorCode, CString& strTagItem);
	void DBDisconnect();
	BOOL DBConnect();
	BOOL Init();
	void DeleteFromRegistry();
	void SetUpdateRate(long lUpdateRate);
	BOOL UpdateTag(long nIndex, LPCTSTR szData);
	BOOL GetTagMessage(long nIndex, LPCTSTR szData, BOOL bAddTime = FALSE);
	long CreateTag(LPCTSTR szName, LPCTSTR szDesc, LPCTSTR szData);
	BOOL OpenTagFile(LPCTSTR szFile);
	CString GetRecipeValue(CString RecipeID);
	void DownLoadRecipe(CString RecipeValue);
	void DeleteRecipeFromEES(CString RecipeID);
	void UploadRecipeList();
	void Initialize();
	void CreateActiveX();
	BOOL ParseHeaderItem(CString strRead, CString strHeaderItem, CString &strValue);
	CEVOpcX* GetOPC();
	CString BstrToCString(BSTR bstr);
	void TerminalMessage(CString strTerminalMessage);
	void ModifyLossMessage(CString strModifyMessage, int nIndex);
	void ParsingStatusMessage(CString strStatusMessage);
	void ParsingBasketMessage(CString strBasketMessage);
	void ParsingLossMessage(CString strLossMessage);
	void ParsingInOutAlarmMessage(CString strInOutAlarm);
	void ParsingDispatchData(int nIndex, CString strDispatch);
	void ParsingHandlerAlarm(long nIndex, LPCTSTR szValue);
	BOOL GetConnection1();
	BOOL GetConnection2();
	void ParsingRecipeMessage(int nType, int nIndex, CString strRecipeMessage);
	void MessageLoop();

	COPCSvr(CWnd* pParent = NULL);   // standard constructor

	CString m_strLossError;
	CString m_strLossPass;
	CString m_strLossResult;
	CString m_strStatus;
	CString m_strStatusCode;
	CString m_strRecipeCreate;
	CString m_strRecipeDelete;
	CString m_strRecipeUpdate;
	CString	m_strRecipeValidation;
	CString m_strRecipeUpload;
	CString m_strRecipeDownLoad;
	CString m_strRecipeIDCreate;
	CString m_strRecipeDeleteFromEES;
	CString m_strRecipeMessage;
	CString m_strRecipePass;
	CString m_strRecipeTag;
	CString m_strRecipeID;
	CString m_strRecipeParam;
	CString m_strRecipePrj;
	CString m_strRecipeStatus;
	CString m_strRecipeLayer;
	CString m_strLayUpCode;
	CString m_strMaterialGroup;
	CString m_strMaterialMaker;
	CString m_strMaterialKind;
	CString m_strMaterialThick;
	CString m_strTrimFinalThick;
	CString m_strNextPnProcess;
	CString m_strCurrentProcess;
	CString m_strPPGThick;

	CString m_strCompLaserFile;
	CString m_strSoldLaserFile;
	CString m_strCompRecipeFile;
	CString m_strSoldRecipeFile;

	CString m_strDongbakThick;
	int m_nRecipeIndex;
	int m_nRecipeCount;
	CString m_strBasket;
	CString m_strData1;
	CString m_strData2;
	CString m_strMESCancel;
	CString m_RMSReturnData;
	CString m_strMessage;
	CString m_strAlarmCode;
	CString m_strAlarmMessage;
	CString m_strDispatchResult;
	CString m_strDispatchErr;
	CString m_strDispatchMessage;
	CString m_strDispatchMessage2;
	CString m_strDispatchLot2;
	BOOL	m_bConnection1;
	BOOL	m_bConnection2;
	HINSTANCE hDll;
	CWinThread* m_pThread;
	BOOL	m_bEndThread;
	ST_CTRL_ITEM m_CtrlItem;
	int		m_nRMSType;
	BOOL	m_bPNLCheck;
	int		m_nAIType; // 0 :com 1: sol 2 : both
	BOOL	m_bRecv;
	OPCINI	m_stOPCINI[800];

	CString m_strCopperThick;
	CString m_strProcessCode;
	CString m_strBackwardLevel;
	CString m_strCustomerCode;
	CString m_strPrevProcessCode;

	lUpdateTagMessage pUpdateTagMessage;
	
	InitOPC pInitOPC;

	UnInitOPC pUnInitOPC;

	GetControl pGetControl;
	CDlgMessageBox m_dlgMessageBox;
	/*
	Pt_UpdateTagStringByName pUpdateTagMessage;
	Pt_InitOpc pInitOPC;
	Pt_UnInitOpc pUnInitOPC;
	Pt_GetControl pGetControl;
	*/
	

// Dialog Data
	//{{AFX_DATA(COPCSvr)
	enum { IDD = IDD_OPC_SERVER };
	CEVOpcX	m_OpcCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COPCSvr)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CEVOpcX*	m_pOPC;
	SQLHENV		m_hEnv;
	SQLHDBC		m_hDbc;
	SQLHSTMT	m_hStmt;
	CString		m_strWorkingDir;
	CRITICAL_SECTION		m_CritLog;
	// Generated message map functions
	//{{AFX_MSG(COPCSvr)
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	afx_msg void OnControlStringEvopcxctrl(long nIndex, LPCTSTR szValue, long FAR* lResult);
	afx_msg LRESULT OnWriteOPCLog(WPARAM wParam, LPARAM lParam = NULL);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPCSVR_H__EA387407_1D3B_4EE0_9A54_B5BB88BCEE2B__INCLUDED_)
