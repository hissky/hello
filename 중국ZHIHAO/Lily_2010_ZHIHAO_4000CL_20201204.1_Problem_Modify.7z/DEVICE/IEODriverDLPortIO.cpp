// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "IEODriverDLPortIO.h"
#include "Dlportio.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include "..\Model\DSystemINI.h"

// #define __TEST

#define DSP_PEN_UP		(1)
#define DSP_PEN_DOWN	(2)
#define DSP_MOVE		(0)

// 3 ~ 13 - Laser & Scanner Parameter
#define CMD_PARA_DS					3
#define CMD_PARA_JS					4
#define CMD_PARA_SP					5
#define CMD_PARA_CD					6
#define CMD_PARA_JD					7
#define CMD_PARA_LD					8
#define CMD_PARA_LOND				9
#define CMD_PARA_LOFFD				10
#define CMD_PARA_DUTY				11
#define CMD_PARA_FREQ				12
#define CMD_PARA_FPS				13

#define DSP_RESET		(14)
#define DSP_PAUSE		(16)
#define DSP_RESTART		(17)
#define DSP_MCL_JUMP	(22)
#define DSP_MCL_MARK	(23)
#define DSP_CMD_LASER_CTRL			28
#define DSP_MCL_SHOT  	(30)

#define CMD_CAL_DATA34				101
#define CMD_PARA_FREQ32				410
#define CMD_PARA_FINE_DUTY			411

// 450 ~ 500 - Drilling			// 2008-09-30 bllee
#define CMD_DRILL_HOLE_DOWN				450
#define CMD_DRILL_HOLE_RESET			451
#define CMD_DRILL_SHOT_CNT_INIT			452
#define CMD_DRILL_CYCLE_TIME			453
#define CMD_DRILL_STEP_PROFILE_RESET	454
#define CMD_DRILL_ACCEL_DOWN			455
#define CMD_DRILL_DIS_LEVEL				456
#define CMD_DRILL_PROFILE_JD_DOWN		457
#define CMD_DRILL_T_CODE_VALUE			458
#define CMD_DRILL_FIELD_START			459
#define CMD_DRILL_APERTURE_DATA_RESET	460
#define CMD_DRILL_APERTURE_DOWN			461
#define CMD_DRILL_MIN_SHOT_TIME			462
#define CMD_FLYING_START				463
#define CMD_FLYING_STOP					464

// new Drill cmd
#define CMD_DRILL_MODE_DOWN				480
#define CMD_DRILL_JUMP					481
#define CMD_DRILL_MARK					482
#define CMD_DRILL_MOVE_CENTER			483
#define CMD_SET_SELF_LINE_DIVIDE		484

#define PORT_A	(0x2)
#define PORT_B	(0x4)
#define PORT_C	(0x6)
#define PORT_D	(0x8)
#define PORT_E	(0xa)
#define PORT_F	(0xc)
#define PORT_G	(0xe)
#define PORT_H	(0x14)
#define PORT_I	(0x16)
#define PORT_J	(0x18)

#define CW_8255	0x323
#define A_8255	0x320
#define B_8255	0x321
#define C_8255	0x322

#define READ_PORT 0x344

#define CMD_SET_BEAM_NUMBER	(100)

#define GET_INVERSE(wordData)		(((wordData & 0xFFFF000) >> 16) + ((wordData & 0x0000FFFF) << 16))

//##ModelId=4034007E015D
IEODriverDLPortIO::IEODriverDLPortIO()
{
	// ToDo: Add your specialized code here and/or call the base class
	m_nBaseAdd = FIRST_EO_CARD_ADDRESS;
#ifdef __TEST
	m_bInitialized = FALSE;
#else
	m_bInitialized = TRUE;
#endif

	m_cCO2Laser = 0xFF;

	m_usDumpMX = HALF_LSB;
	m_usDumpMY = FIELD_LSB;
	m_usDumpSX = HALF_LSB;
	m_usDumpSY = 0;

	m_usCurMX = HALF_LSB;
	m_usCurMY = HALF_LSB;
	m_usCurSX = HALF_LSB;
	m_usCurSY = HALF_LSB;
}

//##ModelId=4034007E015E
IEODriverDLPortIO::~IEODriverDLPortIO()
{
	// ToDo: Add your specialized code here and/or call the base class
}



//##ModelId=4034007E014A
bool IEODriverDLPortIO::readIFCard( ULONG port, ULONG& data, const char type)
{
//	return	IEODriver::readIFCard(port, data, type);
    
	switch (type)
    {
		case _T('B'):
		case _T('b'):
			data = DlPortReadPortUchar(port);
			break;

		case _T('W'):
		case _T('w'):
			data = DlPortReadPortUshort(port);
			break;

		case _T('D'):
		case _T('d'):
			data = DlPortReadPortUlong(port);
			break;

		default:
			ErrMessage(_T("Eocard data type fail"));
			return false;
	}
	
	return true;
}

//##ModelId=4034007E0158
bool IEODriverDLPortIO::writeIFCard(const ULONG port, const ULONG data, const char type)
{
	
//	return IEODriver::writeIFCard(port, data, type);
	
	switch (type)
    {
	case _T('B'):
	case _T('b'):
		DlPortWritePortUchar(port, (UCHAR)data);
		break;

	case _T('W'):
	case _T('w'):
		DlPortWritePortUshort(port, (USHORT)data);
		break;

	case _T('D'):
	case _T('d'):
		DlPortWritePortUlong(port, data);
		break;

	default:
		return false;
	}
	return true;
}

BOOL IEODriverDLPortIO::writePort(WORD PortA, WORD PortB, WORD PortC, WORD PortD, bool WaitFlag, int EOCardIndex, bool progress)
{
	if (!m_bInitialized) 
		return TRUE;
	
	if (PortA == DSP_RESET)
	{
		write(m_nBaseAdd + PORT_A, PortA,_T('w'));
		return TRUE;
	}
		
	if (WaitFlag)
	{
		StatusOK(QUEUEFULL);
	}
	
	write(m_nBaseAdd + PORT_D, PortD, _T('w'));
	write(m_nBaseAdd + PORT_C, PortC, _T('w'));
	write(m_nBaseAdd + PORT_B, PortB, _T('w'));	
	write(m_nBaseAdd + PORT_A, PortA, _T('w')); 
	
	return TRUE;
}

BOOL IEODriverDLPortIO::DownloadASCData(WORD  PortX  , WORD  PortY, WORD  PortIndex, bool  WaitFlag,  int EOCardIndex, bool progress)
{
	return writePort(CMD_CAL_DATA34, PortX, PortY, PortIndex, WaitFlag, EOCardIndex, progress);
}

BOOL IEODriverDLPortIO::writePortDWord(WORD PortA, DWORD PortB, DWORD PortC, DWORD PortD, DWORD PortE, bool bWaitFlag)
{
	if (!m_bInitialized) 
		return TRUE;
	
	if (bWaitFlag)
	{
		StatusOK(QUEUEFULL);
	}
	
	write(m_nBaseAdd + PORT_H, PortE, _T('d'));
	write(m_nBaseAdd + PORT_F, PortD, _T('d'));	
	write(m_nBaseAdd + PORT_D, PortC, _T('d'));
	write(m_nBaseAdd + PORT_B, PortB, _T('d'));	
	write(m_nBaseAdd + PORT_A, PortA, _T('w')); 
	
	return TRUE;
}

BOOL IEODriverDLPortIO::writePortMove(WORD command,  BOOL bWaitEnd, WORD posX, WORD posY, WORD posSX, WORD posSY, WORD posX_2, WORD posY_2, WORD posSX_2, WORD posSY_2, WORD TcodeInfo)
{
	if (!m_bInitialized) 
		return TRUE;
	
	StatusOK(QUEUEFULL);

	write(m_nBaseAdd + PORT_J, TcodeInfo, _T('w'));
	write(m_nBaseAdd + PORT_I, posSY_2, _T('w'));
	write(m_nBaseAdd + PORT_H, posSX_2, _T('w'));
	write(m_nBaseAdd + PORT_G, posY_2,  _T('w'));
	write(m_nBaseAdd + PORT_F, posX_2,  _T('w'));	
	write(m_nBaseAdd + PORT_E, posSY,   _T('w'));
	write(m_nBaseAdd + PORT_D, posSX,   _T('w'));
	write(m_nBaseAdd + PORT_C, posY,    _T('w'));
	write(m_nBaseAdd + PORT_B, posX,    _T('w'));	
	write(m_nBaseAdd + PORT_A, command, _T('w')); 

	if(bWaitEnd)
		StatusOK(IDLE);

	return true;	
}

BOOL IEODriverDLPortIO::write(const ULONG port, const ULONG data, const char type)
{
	return writeIFCard(port, data, type);
}

void IEODriverDLPortIO::SetBaseAddress(UINT nBase)
{
	m_nBaseAdd = nBase;
}

WORD IEODriverDLPortIO::readStatus()
{
	if ( !m_bInitialized) 
		return IDLE;
	
	ULONG data;
	if(!readIFCard(m_nBaseAdd, data)) 
		return 0;
	
	return (((WORD)data) & 0x07); // 0000 0111
}

BOOL IEODriverDLPortIO::StatusOK(int nStatus)
{
#ifndef __TEST__
	if(nStatus == QUEUEFULL || nStatus == BUSY) // wait until QueueFull or Busy is unlocked
	{
		while ( (readStatus() & nStatus) == nStatus) 
		{
			Sleep(0);
		}
	}
	else
	{
		while ( (readStatus() & 0x03) != nStatus) // wait until Idle
		{
			Sleep(0);
		}
	}
#endif
	return TRUE;
}

BOOL IEODriverDLPortIO::LaserOnOff(BOOL bOn)
{
	if (!m_bInitialized)
		return TRUE;

	StatusOK(IDLE);
	
	if(bOn)
		writePort(DSP_PEN_DOWN);
	else
		writePort(DSP_PEN_UP);

	return TRUE;
}

void IEODriverDLPortIO::EStop()
{
	writePort(DSP_RESET);
	writePort(DSP_RESET);
}

void IEODriverDLPortIO::PauseMark()
{
	writePort(DSP_PAUSE);
}

void IEODriverDLPortIO::RestartMark()
{
	writePort(DSP_RESTART);
}

void IEODriverDLPortIO::jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	m_usCurMX = x;
	m_usCurMY = y;
	m_usCurSX = xS;
	m_usCurSY = yS;
	writePortMove(DSP_MCL_JUMP, bWaitEnd, x, y, xS, yS, x_2, y_2, xS_2, yS_2);
}

void IEODriverDLPortIO::mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	m_usCurMX = x;
	m_usCurMY = y;
	m_usCurSX = xS;
	m_usCurSY = yS;
	writePortMove(DSP_MCL_MARK, bWaitEnd, x, y, xS, yS, x_2, y_2, xS_2, yS_2);
}

void IEODriverDLPortIO::Drilljump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	writePortMove(CMD_DRILL_JUMP, bWaitEnd, x, y, xS, yS, x_2, y_2, xS_2, yS_2);
}

void IEODriverDLPortIO::Drillmark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	writePortMove(CMD_DRILL_MARK, bWaitEnd, x, y, xS, yS, x_2, y_2, xS_2, yS_2);
}

void IEODriverDLPortIO::MarkShot(int count)
{
	writePort(DSP_MCL_SHOT, count);
}

BOOL IEODriverDLPortIO::SetParameter(FParameter *pParam, BOOL bUpdate)
{
	if (bUpdate || m_Parameter.DrawStep != pParam->DrawStep)
	{
		if (!writePort(CMD_PARA_DS, pParam->DrawStep))
			return FALSE;
		m_Parameter.DrawStep = pParam->DrawStep;
	}

	if (bUpdate || m_Parameter.JumpStep != pParam->JumpStep)
	{
		if (!writePort(CMD_PARA_JS, pParam->JumpStep))
			return FALSE;
		m_Parameter.JumpStep = pParam->JumpStep;
	}

	if (bUpdate || m_Parameter.StepPeriod != pParam->StepPeriod)
	{
		if (!writePort(CMD_PARA_SP, pParam->StepPeriod))
			return FALSE;
		m_Parameter.StepPeriod = pParam->StepPeriod;
	}

	if (bUpdate || m_Parameter.CornerDelay != pParam->CornerDelay)
	{
		if (!writePort(CMD_PARA_CD, pParam->CornerDelay))
			return FALSE;
		m_Parameter.CornerDelay = pParam->CornerDelay;
	}

	if (bUpdate || m_Parameter.JumpDelay != pParam->JumpDelay)
	{
		if (!writePort(CMD_PARA_JD, pParam->JumpDelay))
			return FALSE;
		m_Parameter.JumpDelay = pParam->JumpDelay;
	}

	if (bUpdate || m_Parameter.LineDelay != pParam->LineDelay)
	{
		if (!writePort(CMD_PARA_LD, pParam->LineDelay))
			return FALSE;
		m_Parameter.LineDelay = pParam->LineDelay;
	}

	if (bUpdate || m_Parameter.LaserOnDelay != pParam->LaserOnDelay)
	{
		if (!writePort(CMD_PARA_LOND, pParam->LaserOnDelay))
			return FALSE;
		m_Parameter.LaserOnDelay = pParam->LaserOnDelay;
	}

	if (bUpdate || m_Parameter.LaserOffDelay != pParam->LaserOffDelay)
	{
		if (!writePort(CMD_PARA_LOFFD, pParam->LaserOffDelay))
			return FALSE;
		m_Parameter.LaserOffDelay = pParam->LaserOffDelay;
	}

	if (bUpdate || m_Parameter.FPSDelay != pParam->FPSDelay)
	{
		if (!writePort(CMD_PARA_FPS, pParam->FPSDelay))
			return FALSE;
		m_Parameter.FPSDelay = pParam->FPSDelay;
	}

	if (bUpdate || m_Parameter.dDuty != pParam->dDuty)
	{
		if (!writePort(CMD_PARA_FINE_DUTY, (unsigned short)(pParam->dDuty/* * 100 */))) 
			return FALSE;
		m_Parameter.dDuty = pParam->dDuty;
	}

	if (bUpdate || m_Parameter.Frequency != pParam->Frequency)
	{
		if (!writePortDWord(CMD_PARA_FREQ32, GET_INVERSE(pParam->Frequency)))
			return FALSE;
		m_Parameter.Frequency = pParam->Frequency;
	}

	m_Parameter.DrawStepPeriod = pParam->DrawStepPeriod;
	return TRUE;
}

BOOL IEODriverDLPortIO::GetParameter(FParameter *pParam)
{
	pParam->DrawStep		= m_Parameter.DrawStep;
	pParam->JumpStep		= m_Parameter.JumpStep;
	pParam->StepPeriod		= m_Parameter.StepPeriod;
	pParam->CornerDelay		= m_Parameter.CornerDelay;
	pParam->JumpDelay		= m_Parameter.JumpDelay;
	pParam->LineDelay		= m_Parameter.LineDelay;
	pParam->LaserOnDelay	= m_Parameter.LaserOnDelay;
	pParam->LaserOffDelay	= m_Parameter.LaserOffDelay;
	pParam->FPSDelay		= m_Parameter.FPSDelay;
	pParam->dDuty			= m_Parameter.dDuty;
	pParam->Frequency		= m_Parameter.Frequency;
	pParam->DrawStepPeriod	= m_Parameter.DrawStepPeriod;

	return TRUE;
}

BOOL IEODriverDLPortIO::DownloadShotData4(unsigned short usMasterX,
										 unsigned short usMasterY,
										 unsigned short usSlaveX,
										 unsigned short usSlaveY,
										 unsigned short usMasterX2,
										 unsigned short usMasterY2,
										 unsigned short usSlaveX2,
										 unsigned short usSlaveY2,
										 BOOL bApplyCalibrationMaster,
										 BOOL bApplyCalibrationSlave,
										 BOOL bApplyCalibrationMaster2,
										 BOOL bApplyCalibrationSlave2,
										 int nTCode)
{
	WORD TInfo = 0;								// 1111 (M2Cal, S2Cal, MCal, SCal) 0000 (Tcode) 
	TInfo = (!bApplyCalibrationMaster2);
	TInfo = TInfo << 1;
	TInfo = TInfo + (!bApplyCalibrationSlave2);
	TInfo = TInfo << 1;
	TInfo = TInfo + (!bApplyCalibrationMaster);
	TInfo = TInfo << 1;
	TInfo = TInfo + (!bApplyCalibrationSlave);
	TInfo = TInfo << 8;
	
	if(!bApplyCalibrationMaster) // 20070730
	{
		usMasterX = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
		usMasterY = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	}
	
	if(!bApplyCalibrationSlave)
	{
		usSlaveX = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
		usSlaveY = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper2.y;
	}
	/*
	if(!bApplyCalibrationMaster) // 20070730
	{
	usMasterX2 = (unsigned short)gSystemINI.m_sSystemDevice.nPtBeanDumper3.x;
	usMasterY2 = (unsigned short)gSystemINI.m_sSystemDevice.nPtBeanDumper3.y;
	}
	
	  if(!bApplyCalibrationSlave)
	  {
	  usSlaveX2 = (unsigned short)gSystemINI.m_sSystemDevice.nPtBeanDumper4.x;
	  usSlaveY2 = (unsigned short)gSystemINI.m_sSystemDevice.nPtBeanDumper4.y;
	  }
	*/

	if(nTCode > MAX_TCODE_2BEAM || nTCode < 0) // 
		return FALSE;

	TInfo = TInfo + nTCode;
	
	return writePortMove(CMD_DRILL_HOLE_DOWN, FALSE, usMasterX, usMasterY, usSlaveX, usSlaveY, usMasterX2, usMasterY2, usSlaveX2, usSlaveY2, TInfo);
}

BOOL IEODriverDLPortIO::DownloadShotData2( unsigned short usMasterX,
										   unsigned short usMasterY,
										   unsigned short usSlaveX,
										   unsigned short usSlaveY,
										   BOOL bApplyCalibrationMaster,
										   BOOL bApplyCalibrationSlave,
										   int nTCode)
{
	WORD TInfo = 0;								// 0011(MCal, SCal) 0000(Tcode) 
	TInfo = (!bApplyCalibrationMaster);
	TInfo = TInfo << 1;
	TInfo = TInfo + (!bApplyCalibrationSlave);
	TInfo = TInfo << 8;

	if(!bApplyCalibrationMaster) // 20070730
	{
		usMasterX = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
		usMasterY = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	}
	
	if(!bApplyCalibrationSlave)
	{
		usSlaveX = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
		usSlaveY = (unsigned short)gSystemINI.m_sSystemDump.nPtBeanDumper2.y;
	}

	if(nTCode > MAX_TCODE_2BEAM || nTCode < 0) // 
		return FALSE;
	
	TInfo = TInfo + nTCode;
	
	return writePortMove(CMD_DRILL_HOLE_DOWN, FALSE, usMasterX, usMasterY, usSlaveX, usSlaveY, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, TInfo);
}


BOOL IEODriverDLPortIO::ShotDataReset()
{
	return writePort(CMD_DRILL_HOLE_RESET);
}

BOOL IEODriverDLPortIO::ShotCountReset()
{
	return writePort(CMD_DRILL_SHOT_CNT_INIT);
}

BOOL IEODriverDLPortIO::MoveProfileReset(int nIndex)
{
	if(nIndex >= MAX_PROFILE_NUM || nIndex < 0)
		return FALSE;
	
	return writePort(CMD_DRILL_STEP_PROFILE_RESET, nIndex);
}

BOOL IEODriverDLPortIO::DownloadProfile(int nIndex, int nValue)
{
	if(nIndex >= MAX_PROFILE_NUM || nIndex < 0)
		return FALSE;
	
	return writePortDWord(CMD_DRILL_ACCEL_DOWN, nIndex, nValue + 32768);
}

BOOL IEODriverDLPortIO::SetMoveProfileLength(int nIndex, int nLength)
{
	if(nIndex >= MAX_PROFILE_NUM || nIndex < 0)
		return FALSE;
	
	return writePortDWord(CMD_DRILL_DIS_LEVEL, nIndex, nLength);
}

BOOL IEODriverDLPortIO::DownloadProfileJumpDelay(int nIndex, int nValue)
{
	if(nIndex >= MAX_PROFILE_NUM || nIndex < 0)
		return FALSE;
	
	return writePortDWord(CMD_DRILL_PROFILE_JD_DOWN, nIndex, nValue);
}

BOOL IEODriverDLPortIO::DownloadTcode(TCODE_INFO *pToolInfo)
{
	DWORD nInfo = 0;
	if(pToolInfo->nToolNo >= MAX_TCODE_2BEAM || pToolInfo->nToolNo < 0)
		return FALSE;
	if(pToolInfo->nUseDutyNo > MAXSHOTCNT || pToolInfo->nUseDutyNo < 0)
		return FALSE;

	for(DWORD i = 0; i < pToolInfo->nUseDutyNo; i++)
	{
		if(!writePortDWord(CMD_DRILL_T_CODE_VALUE, pToolInfo->nToolNo, i, 0, (UINT)(pToolInfo->dDuty[i] * 100)))	
			return FALSE;
	}

	nInfo = pToolInfo->bUseAperture;
	nInfo = nInfo << 8;
	nInfo = nInfo + pToolInfo->nTotalShot;
	nInfo = nInfo << 8;
	nInfo = nInfo + pToolInfo->nBurstShot;
	return writePortDWord(CMD_DRILL_T_CODE_VALUE, pToolInfo->nToolNo, MAXSHOTCNT, pToolInfo->nFreq, nInfo);
}

BOOL IEODriverDLPortIO::FieldStart(BOOL bDryRun)
{
	return writePort(CMD_DRILL_FIELD_START, bDryRun);
}

BOOL IEODriverDLPortIO::ApertureDataReset(int nToolNo)
{
	if(nToolNo >= MAX_TCODE_2BEAM || nToolNo < 0)
		return FALSE;
	
	return writePort(CMD_DRILL_APERTURE_DATA_RESET, nToolNo);
}

BOOL IEODriverDLPortIO::DownloadAperture(int nToolNo, int nX, int nY, int nAction)
{
	DWORD nPOS = 0;
	if(nToolNo >= MAX_TCODE_2BEAM || nToolNo < 0)
		return FALSE;

	nPOS = nY + 32768;
	nPOS = nPOS << 16;
	nPOS = nPOS + (nX + 32768);
	
	return writePortDWord(CMD_DRILL_APERTURE_DOWN, nToolNo, nPOS, nAction);
}

BOOL IEODriverDLPortIO::SetMinShotTime(int us)
{
	if(us < 10)
		return FALSE;
	return writePortDWord(CMD_DRILL_MIN_SHOT_TIME, us);
}

BOOL IEODriverDLPortIO::SetMinCycleTime(int us)
{
	if(us < 10)
		return FALSE;
	return writePortDWord(CMD_DRILL_CYCLE_TIME, us);
}

BOOL IEODriverDLPortIO::SetSelfLineDivide(BOOL bOn)
{
	return writePortDWord(CMD_SET_SELF_LINE_DIVIDE, bOn);
}

BOOL IEODriverDLPortIO::SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo)
{
	DWORD nVal = 0;
	nVal = ((nSP & 0xFF) << 16) + ((nApertureMode & 0xFF) << 8) + (b4Beam & 0xFF);

	return writePortDWord(CMD_DRILL_MODE_DOWN, nVal, nBurstShotNo);
}

BOOL IEODriverDLPortIO::MoveDrillCenterPos()
{
	return writePort(CMD_DRILL_MOVE_CENTER);
}

ULONG IEODriverDLPortIO::ReadHoleCount()
{
	ULONG nVal = 0;
	readIFCard(READ_PORT, nVal, _T('d'));
	return nVal;
}

void IEODriverDLPortIO::Init8255()
{
	writeIFCard(CW_8255, 0x91, _T('b'));
	ResetCO2Laser();
	
}

void IEODriverDLPortIO::ResetCO2Laser()
{
	m_cCO2Laser = 0xFF;
	writeIFCard(B_8255, m_cCO2Laser, _T('b'));
}

void IEODriverDLPortIO::CO2LaserEnable(BOOL bEnable)
{
	if(bEnable)
		m_cCO2Laser = m_cCO2Laser & 0xFA;
	else
		m_cCO2Laser = m_cCO2Laser | 0x05;

	writeIFCard(B_8255, m_cCO2Laser, _T('b'));
}

void IEODriverDLPortIO::CO2LaserMainShutter(BOOL bOn)
{
	if(bOn)
		m_cCO2Laser = m_cCO2Laser & 0xFD;
	else
		m_cCO2Laser = m_cCO2Laser | 0x02;

	writeIFCard(B_8255, m_cCO2Laser, _T('b'));
}

BOOL IEODriverDLPortIO::DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture)
{
	DWORD nInfo = 0;
	if(nToolNo >= MAX_TCODE_2BEAM || nToolNo < 0)
		return FALSE;

	nInfo = bUseAperture;
	nInfo = nInfo << 8;
	nInfo = nInfo + nTotalShot;
	nInfo = nInfo << 8;
	nInfo = nInfo + nBurstShot;
	return writePortDWord(CMD_DRILL_T_CODE_VALUE, nToolNo, MAXSHOTCNT, nFreq, nInfo);
}

BOOL IEODriverDLPortIO::DownloadDuty(unsigned int nToolNo, unsigned int nShotIndex, double dDuty)
{
	if(nToolNo >= MAX_TCODE_2BEAM || nToolNo < 0)
		return FALSE;
	if(nShotIndex >= MAXSHOTCNT || nShotIndex < 0)
		return FALSE;
	
	if(!writePortDWord(CMD_DRILL_T_CODE_VALUE, nToolNo, nShotIndex, 0, (UINT)(dDuty * 100)))	
		return FALSE;
	
	return TRUE;
}

BOOL IEODriverDLPortIO::DownloadShotData(unsigned short usX,
										 unsigned short usY,
										 BOOL bIsMaster,
										 BOOL bApplyCalibration,
										 int nTCode)
{
	if(bIsMaster == FALSE)
	{
		return DownloadShotData2(m_usDumpMX, m_usDumpMY, usX, usY,
							FALSE, bApplyCalibration, nTCode);
	}
	else
	{
		return DownloadShotData2(usX, usY, m_usDumpSX, m_usDumpSY,
			bApplyCalibration, FALSE, nTCode);
	}
}

void IEODriverDLPortIO::SetDumperPosition(USHORT usDumpMX, USHORT usDumpMY, USHORT usDumpSX, USHORT usDumpSY)
{
	m_usDumpMX = usDumpMX;
	m_usDumpMY = usDumpMY;
	m_usDumpSX = usDumpSX;
	m_usDumpSY = usDumpSY;
}

void IEODriverDLPortIO::GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY)
{
	usDumpMX = m_usDumpMX;
	usDumpMY = m_usDumpMY;
	usDumpSX = m_usDumpSX;
	usDumpSY = m_usDumpSY;
}

BOOL IEODriverDLPortIO::jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(bIsMaster == FALSE)
	{
		jump(m_usCurMX, m_usCurMY, x, y, m_usCurMX, m_usCurMY, x, y, bWaitEnd);
	}
	else
	{
		jump(x, y, m_usCurSX, m_usCurSY, x, y, m_usCurSX, m_usCurSY, bWaitEnd);
	}
	return TRUE;
}

BOOL IEODriverDLPortIO::markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(bIsMaster == FALSE)
	{
		mark(m_usCurMX, m_usCurMY, x, y, m_usCurMX, m_usCurMY, x, y, bWaitEnd);
	}
	else
	{
		mark(x, y, m_usCurSX, m_usCurSY, x, y, m_usCurSX, m_usCurSY, bWaitEnd);
	}
	return TRUE;
}

void IEODriverDLPortIO::DrillMove(BOOL bMark, int x1, int y1, int x2, int y2, BOOL bMaster, BOOL bWaitEnd)
{
	if(bMark)
	{
		if(bMaster)
			writePortMove(CMD_DRILL_MARK, bWaitEnd, x1, y1, m_usDumpSX, m_usDumpSY, x2, y2, m_usDumpSX, m_usDumpSY);
		else
			writePortMove(CMD_DRILL_MARK, bWaitEnd, m_usDumpMX, m_usDumpMY, x1, y1, m_usDumpMX, m_usDumpMY, x2, y2);
	}
	else
	{
		if(bMaster)
			writePortMove(CMD_DRILL_JUMP, bWaitEnd, x1, y1, m_usDumpSX, m_usDumpSY, x2, y2, m_usDumpSX, m_usDumpSY);
		else
			writePortMove(CMD_DRILL_JUMP, bWaitEnd, m_usDumpMX, m_usDumpMY, x1, y1, m_usDumpMX, m_usDumpMY, x2, y2);
	}
}

unsigned short IEODriverDLPortIO::GetFunction()
{
	return (m_usFunction);
}

BOOL IEODriverDLPortIO::SetFunction(unsigned short usValue)
{
	m_usFunction = usValue;
	
	unsigned char ucValue = static_cast<unsigned char>(usValue);
	
	DlPortWritePortUchar(B_8255, ucValue);
	
	return TRUE;
}

BOOL IEODriverDLPortIO::GetStatus(WORD* pStat) const
{
	*pStat = DlPortReadPortUshort(A_8255);
	
	return TRUE;
}

BOOL IEODriverDLPortIO::SetQuantaParam(int nFPK, int nCurrent)
{
	writePortMove(DSP_CMD_LASER_CTRL, TRUE, nCurrent, nFPK, 0, 0, 0, 0, 0, 0);
	return TRUE;
}

BOOL IEODriverDLPortIO::FlyingModeEnable(BOOL bEnable)
{
	if(bEnable)
		return writePortDWord(CMD_FLYING_START, 0);
	else
		return writePortDWord(CMD_FLYING_STOP, 0);
}
