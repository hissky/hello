// HVision.cpp: implementation of the HVision class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "..\easydrillerDlg.h"
#include "HVision.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\alarmmsg.h"
#include "..\UI\DlgVisionProView.h"
#include "..\model\dProcessini.h"
#include "VProData.h"
#include "..\ui\PaneManualControl.h"
#include "..\ui\PaneManualControlVision.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

volatile __int64 HVision::m_n64Count = 0;

#define DISPLAY_PATTERN	8
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HVision::HVision()
{
	m_clsLamp = NULL;
	m_pOmi = NULL;
	m_pMatrox = NULL;
	m_pMatroxTCP = NULL;
	m_nCamNo = 0;
	m_p2D = NULL;
	m_p2DUnload = NULL;
	m_VisionLamp = NULL;
	m_VisionLamp2 = NULL;
}

HVision::~HVision()
{
	if(m_pOmi != NULL)
	{
		delete m_pOmi;
		m_pOmi = NULL;
	}

	if(m_pMatrox != NULL)
	{
		delete m_pMatrox;
		m_pMatrox = NULL;
	}

	if(m_pMatroxTCP != NULL)
	{
		delete m_pMatroxTCP;
		m_pMatroxTCP = NULL;
	}

	if(m_clsLamp != NULL)
	{
		delete m_clsLamp;
		m_clsLamp = NULL;
	}

	if(m_p2D != NULL)
	{
		delete m_p2D;
		m_p2D = NULL;
	}
	if(m_p2DUnload != NULL)
	{
		delete m_p2DUnload;
		m_p2DUnload = NULL;
	}

	if (m_VisionLamp != NULL)
	{
		delete m_VisionLamp;
		m_VisionLamp = NULL;
	}

	if (m_VisionLamp2 != NULL)
	{
		delete m_VisionLamp2;
		m_VisionLamp2 = NULL;
	}
}

BOOL HVision::Initialize()
{
	SetCalTansData();
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		m_pOmi = new HVisionOmi;
#ifndef __TEST__
		if( FALSE == m_pOmi->LoadOmiProject( gEasyDrillerINI.m_clsDirPath.GetSystemDir() ) )
			ErrMsgDlg(STDGNALM1004);
#endif

		m_pOmi->InitOmiVision();
		m_pVisionHandle = m_pOmi->m_pVisionHndle;
		m_pOmi->SetPixel( 0, gSystemINI.m_sSystemDevice.d1stHighPixel );
		m_pOmi->SetPixel( 1, gSystemINI.m_sSystemDevice.d1stLowPixel );
		m_pOmi->SetPixel( 2, gSystemINI.m_sSystemDevice.d2ndHighPixel );
		m_pOmi->SetPixel( 3, gSystemINI.m_sSystemDevice.d2ndLowPixel );
		m_pOmi->TransformPixel();
		m_pOmi->CalPixelDistance();

		if(m_clsLamp == NULL)
		{
			TRY
			{
				m_clsLamp = new MVisionLamp();
			}
			CATCH (CMemoryException, e)
			{
				e->ReportError();
				e->Delete();
				return FALSE;
			}
			END_CATCH

			if(gSystemINI.m_sHardWare.nUseLampRS232)
			{
				m_clsLamp->SetComPort(gSystemINI.m_sSystemDevice.nLampComport);
#ifndef __TEST__
				m_clsLamp->ConectComPort();
#endif
			}
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		m_pMatrox = new HVisionMatrox;
		
		m_pMatrox->InitMatroxVision();
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		CString str;
		//str.Format(_T("Sony XC-HR70 1020x766 IntDrv CCF"));
	 	str.Format(_T("%s"), gSystemINI.m_sSystemDevice.szVisionModelID/*"Sony XC-ST50CE 760x574 IntDrv CCF"*/); //û�� ���  ���� 20111212
		gVPro.m_ImageWidth = gSystemINI.m_sSystemDevice.nCameraPixelX;
		gVPro.m_ImageHeight = gSystemINI.m_sSystemDevice.nCameraPixelY;
//		str.Format(_T("Sony XC-HR70 1020x768 IntDrv (rapid-reset, shutter-sw-EDONPISHAII) CCF"));
		BOOL bRet = gVPro.InitVision( 0, str, 0 );

		for ( int i = 0; i < CREATEVP; i++ )
		{
			gVPro.m_ScaleP[i] = 1.2;	//�ִ� ������
			gVPro.m_ScaleN[i] = 0.8;	//�ּ� ������
			gVPro.m_dAngle[i] = 20. / 180. * PI;
			gVPro.m_dXYRatio[i] = 0.2; 

			gVPro.m_ActScore[i] = gProcessINI.m_sProcessFidFind.dAcceptEdgeScore; //0.6;	//Accept Score
			if( i == MODEL_RECT )
				gVPro.m_ShapeTypeNoData[i] = MODEL_RECT;	
			else if( i == MODEL_CROSS ) 
				gVPro.m_ShapeTypeNoData[i] = MODEL_CROSS;
			else if( i >= MODEL_PATTERN)
				gVPro.m_ShapeTypeNoData[i] = MODEL_PATTERN;
			else 
				gVPro.m_ShapeTypeNoData[i] = MODEL_CIRCLE;

			gVPro.m_ShapePolarityData[i] = 2;	//Polarity	
			gVPro.m_SizeA[i] = 0.1;
			gVPro.m_SizeB[i] = 0.0;
			gVPro.m_SizeC[i] = 0.0;
			gVPro.m_ShapeTrainBool[i] = 0;

		}

		for(int j = 0; j< CAM_TOT_COUNT; j++)
		{
			gVPro.m_BrightData[j] = 0.5;
			gVPro.m_ContrastData[j] = 0.5;
			gVPro.m_CalibData[j] = 0.276;
			gVPro.m_SearchAreacx[j] = gSystemINI.m_sSystemDevice.nCameraPixelX/2;
			gVPro.m_SearchAreacy[j] = gSystemINI.m_sSystemDevice.nCameraPixelY/2;
			gVPro.m_SearchAreacw[j] = gSystemINI.m_sSystemDevice.nCameraPixelX;
			gVPro.m_SearchAreach[j] = gSystemINI.m_sSystemDevice.nCameraPixelY;
		}

		gVPro.m_ShapeTypeNo = MODEL_CIRCLE;
		
		gVPro.m_ShapeCenterA = 50;

		gVPro.CreatePMAlignTool(CREATEVP); 
		gVPro.TransformPixel();
		gVPro.CalPixelDistance();
#endif

		if (m_VisionLamp == NULL)
		{
			TRY
			{
				m_VisionLamp = new CDevVisionController();
			}
			CATCH (CMemoryException, e)
			{
				e->ReportError();
				e->Delete();
				return FALSE;
			}
			END_CATCH

			if(gSystemINI.m_sHardWare.nUseLampRS232)
			{
				m_VisionLamp->SetParameter(gSystemINI.m_sSystemDevice.sVisionLampPort.nPortNo,
					gSystemINI.m_sSystemDevice.sVisionLampPort.nBaudRate,
					gSystemINI.m_sSystemDevice.sVisionLampPort.nParity,
					gSystemINI.m_sSystemDevice.sVisionLampPort.nDataBits,
					gSystemINI.m_sSystemDevice.sVisionLampPort.nStopBits,
					gSystemINI.m_sSystemDevice.sVisionLampPort.nFlowControl);

				if (!m_VisionLamp->PortOpened())
				{
					if (!m_VisionLamp->Create())
					{
						ErrMessage(_T("Vision Lamp Connect Failure"));
					}
				}
			}
		}
#ifdef __OSAN_LG_2013__
		if (m_VisionLamp2 == NULL)
		{
			TRY
			{
				m_VisionLamp2 = new CDevVisionController();
			}
			CATCH (CMemoryException, e)
			{
				e->ReportError();
				e->Delete();
				return FALSE;
			}
			END_CATCH

				if(gSystemINI.m_sHardWare.nUseLampRS232)
				{
					m_VisionLamp2->SetParameter(gSystemINI.m_sSystemDevice.sVisionLampPort2.nPortNo,
						gSystemINI.m_sSystemDevice.sVisionLampPort2.nBaudRate,
						gSystemINI.m_sSystemDevice.sVisionLampPort2.nParity,
						gSystemINI.m_sSystemDevice.sVisionLampPort2.nDataBits,
						gSystemINI.m_sSystemDevice.sVisionLampPort2.nStopBits,
						gSystemINI.m_sSystemDevice.sVisionLampPort2.nFlowControl);

					if (!m_VisionLamp2->PortOpened())
					{
						if (!m_VisionLamp2->Create())
						{
							ErrMessage(_T("Vision Lamp2 Connect Failure"));
						}
					}
				}
		}
#endif
	}
	else
	{
		m_pMatroxTCP = new HVisionTCP;
		m_pMatroxTCP->InitMatroxTCP();
	}

#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_p2D = new HVision2DBarcode;
	m_p2D->Connect(TRUE);

	m_p2DUnload = new HVision2DBarcode;
	m_p2DUnload->Connect(FALSE);

#endif
	return TRUE;
}

void HVision::SetOmiView(int nCamNo, COmiView *pView)
{
	if(m_pOmi)
	{
		m_pOmi->SetOmiView(nCamNo, pView);
	}
}

BOOL HVision::LoadProject(CString strDir)
{
	if(m_pOmi)
	{
		return m_pOmi->LoadOmiProject(strDir);
	}
	if(m_pMatrox)
	{
		m_pMatrox->LoadJobFile(strDir);
	}
	if(m_pMatroxTCP)
	{
		return m_pMatroxTCP->LoadJobFile(strDir);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{

#ifdef USE_VISION_PRO
		return gVPro.LoadProject( strDir );	
#endif	
	}

	return TRUE;
}

void HVision::SaveProject(CString strPath)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.SaveProject( strPath );
#endif
	}
}
void HVision::OnConnectView()
{
	if(m_pOmi)
	{
		m_pOmi->OnConnectView();	
	}
}

void HVision::OnCamChange(int nCamNo)
{
	if(m_pOmi)
	{
		m_pOmi->OnCamChange(nCamNo);
	}
	if(m_pMatrox)
	{
		m_pMatrox->OnCamChange(nCamNo);
	}
	if(m_pMatroxTCP)
	{
		m_nCamNo = nCamNo;
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
//		gVPro.m_pAcqFifoTool[nCamNo].put_Brightness(1);
		gVPro.ChangeCam(nCamNo);
		gVPro.Acquire(nCamNo, nCamNo, true);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowSelectCamera(nCamNo);
#endif
	}
}

void HVision::OnAcquire(int nCamNo) // refresh vision
{
	if(m_pOmi)
	{
		m_pOmi->OnAcquire(nCamNo);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if(nCamNo < 0 || nCamNo >= 4)
			return;
#ifdef USE_VISION_PRO
		gVPro.Acquire(nCamNo, nCamNo, true);
#endif
	}
}

void HVision::OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness)
{
	if(m_pOmi)
	{
		m_pOmi->OnContrastAndBrightness(nCamNo, dContrast, dBrightness);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.m_BrightData[nCamNo] = dBrightness;
		gVPro.m_ContrastData[nCamNo] = dContrast;
#endif
	}
}

void HVision::OnContrast(int nCamNo, double dContrast)
{
	if(m_pOmi)
	{
		m_pOmi->OnContrast(nCamNo, dContrast);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.m_ContrastData[nCamNo] = dContrast;
#endif
	}
}

void HVision::OnBrightness(int nCamNo, double dBrightness)
{
	if(m_pOmi)
	{
		m_pOmi->OnBrightness(nCamNo, dBrightness);	
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.m_BrightData[nCamNo] = dBrightness;
#endif
	}
}

void HVision::SaveImg(int nCamNo, CString strFilePathName)
{
	if(m_pOmi)
	{
		m_pOmi->SaveImg(nCamNo, strFilePathName);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.SaveImg(nCamNo, strFilePathName);
#endif
	}
}

void HVision::OnLive(int nCamNo, BOOL bIsLive)
{
	if(m_pOmi)
	{
#ifdef __PUSAN_LDD__
		return;
#endif
		m_pOmi->OnLive(nCamNo, bIsLive);
	}
	if(m_pMatrox)
	{
		m_pMatrox->OnLive(bIsLive);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.LiveImage( nCamNo, nCamNo, bIsLive );
#endif
	}
}

void HVision::OnApplyVisionParameter(int nID, int nCamNo, VISION_INFO sVisionInfo)
{
	if(m_pOmi)
	{
		m_pOmi->OnApplyVisionParameter(nCamNo, sVisionInfo);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO

		CString strTemp;
		if(CompareVPro(nID, nCamNo, sVisionInfo) == TRUE)//������ �����ϸ� Return
		{
			strTemp.Format("CompareVPro Skip , ID %d \n",nID);
			TRACE(strTemp);
			return;
		}
		strTemp.Format("CompareVPro Pass , ID %d \n",nID);
		TRACE(strTemp);


		SetSelIndex(nID);
		
		if(sVisionInfo.nPolarity == 0)
			gVPro.m_ShapePolarity = 1;	
		else if(sVisionInfo.nPolarity == 1)
			gVPro.m_ShapePolarity = -1;
		else
			gVPro.m_ShapePolarity = 0;
		
		gVPro.m_ShapeTypeNo = sVisionInfo.nModelType; 
		
		gVPro.m_ShapeTypeNoData[nID] = sVisionInfo.nModelType;
		
		gVPro.m_ScaleP[nID] = 1.0 + sVisionInfo.dScoreSize / 100.0;
		gVPro.m_ScaleN[nID] = 1.0 - sVisionInfo.dScoreSize / 100.0;
		gVPro.m_SizeA[nID] = sVisionInfo.dSizeA;//m_dDiameter;
		gVPro.m_SizeB[nID] = sVisionInfo.dSizeB;//m_dDiameter;
		gVPro.m_SizeC[nID] = sVisionInfo.dSizeC;//m_dDiameter;
		gVPro.m_dXYRatio[nID] = sVisionInfo.dAspectRatio / 100.0;
		gVPro.m_dAngle[nID] = sVisionInfo.dScoreAngle * PI / 180.0;

		for(int i = 0; i < 4; i++)
		{
			gVPro.m_BrightData[i] = sVisionInfo.dBrightness[i];
			gVPro.m_ContrastData[i] = sVisionInfo.dContrast[i];
		}
	    CopyToVProTemp(1,nCamNo);
		gVPro_Temp[nCamNo].m_bApplyParamFlag = 0;
		
		//110604 ejpark : PMToolTrain()���� Train Region�� ���� ������ �ֹǷ� 
		//	������ ��� ������ ������ Train �ϰ� ��   
		BOOL bRes;
		if(gVPro.m_ShapeTypeNo < MODEL_PATTERN)
			bRes = gVPro.PMToolTrain(nID, nCamNo, true, TRUE );
		else
			;//bRes = gVPro.PMToolTrain(nID,nCamNo, false, TRUE );
#endif
	}
}
BOOL HVision::CompareVPro(int nID, int nCamNo, VISION_INFO sVisionInfo)
{

	if(gVPro_Temp[nCamNo].m_bApplyParamFlag == 1)
		return FALSE;


	int nShapePolarity = 0;

	if(sVisionInfo.nPolarity == 0)
		nShapePolarity = 1;	
	else if(sVisionInfo.nPolarity == 1)
		nShapePolarity = -1;
	else
		nShapePolarity = 0;


	if(gVPro_Temp[nCamNo].m_ShapePolarity != nShapePolarity)
		return FALSE;

	if(gVPro_Temp[nCamNo].m_ShapeTypeNo != sVisionInfo.nModelType)
		return FALSE;

	if(gVPro_Temp[nCamNo].m_ShapeTypeNoData[nID] != sVisionInfo.nModelType)
		return FALSE;


	if(gVPro_Temp[nCamNo].m_ShapeTypeNoData[nID] != sVisionInfo.nModelType)
		return FALSE;

	double dScaleP = 1.0 + sVisionInfo.dScoreSize / 100.0;
	double dScaleN = 1.0 - sVisionInfo.dScoreSize / 100.0;

	if(fabs(gVPro_Temp[nCamNo].m_ScaleP[nID] - dScaleP) > 0.00001)
		return FALSE;
	if(fabs(gVPro_Temp[nCamNo].m_ScaleN[nID] - dScaleN) > 0.00001)
		return FALSE;


	if(fabs(gVPro_Temp[nCamNo].m_SizeA[nID] - sVisionInfo.dSizeA) > 0.00001)
		return FALSE;
	if(fabs(gVPro_Temp[nCamNo].m_SizeB[nID] - sVisionInfo.dSizeB) > 0.00001)
		return FALSE;
	if(fabs(gVPro_Temp[nCamNo].m_SizeC[nID] - sVisionInfo.dSizeC) > 0.00001)
		return FALSE;

	double dXYRatio = sVisionInfo.dAspectRatio / 100.0;
	double dAngle = sVisionInfo.dScoreAngle * PI / 180.0;
	
	if(fabs(gVPro_Temp[nCamNo].m_dXYRatio[nID] - dXYRatio) > 0.00001)
		return FALSE;
	if(fabs(gVPro_Temp[nCamNo].m_dAngle[nID] - dAngle) > 0.00001)
		return FALSE;



	for(int i = 0; i < 4; i++)
	{

		if(fabs(gVPro_Temp[nCamNo].m_BrightData[i] - sVisionInfo.dBrightness[i]) > 0.00001)
			return FALSE;

		if(fabs(gVPro_Temp[nCamNo].m_ContrastData[i] - sVisionInfo.dContrast[i]) > 0.00001)
			return FALSE;
	}


	for(int j = 0; j < 4 ; j++) // 110527 yhchung �켱 4����.
	{
		for(int i = 0; i < MAX_CAMERA ; i++) // 110527 yhchung �켱 4����.
		{
			if(fabs(gVPro_Temp[j].m_SearchAreacx[i] - gVPro.m_SearchAreacx[i]) > 0.00001)
				return FALSE;
			if(fabs(gVPro_Temp[j].m_SearchAreacy[i] - gVPro.m_SearchAreacy[i]) > 0.00001)
				return FALSE;

			if(fabs(gVPro_Temp[j].m_SearchAreacw[i] - gVPro.m_SearchAreacw[i]) > 0.00001)
				return FALSE;
			if(fabs(gVPro_Temp[j].m_SearchAreach[i] - gVPro.m_SearchAreach[i]) > 0.00001)
				return FALSE;
		}
	}



	return TRUE;
}



void HVision::CopyToVProTemp(int nID, int nCamNo)
{


	gVPro_Temp[nCamNo].m_ShapePolarity = gVPro.m_ShapePolarity;


	gVPro_Temp[nCamNo].m_ShapeTypeNo = gVPro.m_ShapeTypeNo;

	gVPro_Temp[nCamNo].m_ShapeTypeNoData[nID] = gVPro.m_ShapeTypeNoData[nID];

	gVPro_Temp[nCamNo].m_ShapeTypeNoData[nID] = gVPro.m_ShapeTypeNoData[nID];

	gVPro_Temp[nCamNo].m_ScaleP[nID] = gVPro.m_ScaleP[nID];

	gVPro_Temp[nCamNo].m_ScaleN[nID] = gVPro.m_ScaleN[nID];



	gVPro_Temp[nCamNo].m_SizeA[nID] = gVPro.m_SizeA[nID];

	gVPro_Temp[nCamNo].m_SizeB[nID] = gVPro.m_SizeB[nID];

	gVPro_Temp[nCamNo].m_SizeC[nID] = gVPro.m_SizeC[nID];



	gVPro_Temp[nCamNo].m_dXYRatio[nID] = gVPro.m_dXYRatio[nID];

	gVPro_Temp[nCamNo].m_dAngle[nID] = gVPro.m_dAngle[nID];


	for(int i = 0; i < 4; i++)
	{
		gVPro_Temp[nCamNo].m_BrightData[i] = gVPro.m_BrightData[i];
		gVPro_Temp[nCamNo].m_ContrastData[i] = gVPro.m_ContrastData[i];
	}

	for(int j = 0; j < 4 ; j++) // 110527 yhchung �켱 4����.
	{
		for(int i = 0; i < MAX_CAMERA ; i++) // 110527 yhchung �켱 4����.
		{
			gVPro_Temp[j].m_SearchAreacx[i] = gVPro.m_SearchAreacx[i];
			gVPro_Temp[j].m_SearchAreacy[i] = gVPro.m_SearchAreacy[i];
			gVPro_Temp[j].m_SearchAreacw[i] = gVPro.m_SearchAreacw[i];
			gVPro_Temp[j].m_SearchAreach[i] = gVPro.m_SearchAreach[i];
		}
	}

}



void HVision::SetApplyParamFlagForVPro()
{
	for(int ii = 0; ii < CAM_TOT_COUNT; ii++)
     	gVPro_Temp[ii].m_bApplyParamFlag = 1;
}
void HVision::OnApplyVisionParam(int nID,  int nCamNo, SVISIONINFO sVisionInfo)
{
	if(m_pOmi)
	{
		m_pOmi->OnApplyVisionParam(nCamNo, sVisionInfo);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		if(sVisionInfo.nPolarity == 0)
			gVPro.m_ShapePolarity = 1;	
		else if(sVisionInfo.nPolarity == 1)
			gVPro.m_ShapePolarity = -1;
		else
			gVPro.m_ShapePolarity = 0;
		
		gVPro.m_ShapeTypeNo = sVisionInfo.nModelType; // 1;
		gVPro.m_ShapeTypeNoData[nID] = sVisionInfo.nModelType;// 1;
		
		gVPro.m_ScaleP[nID] = 1.0 + sVisionInfo.dScoreSize / 100.0;
		gVPro.m_ScaleN[nID] = 1.0 - sVisionInfo.dScoreSize / 100.0;
		gVPro.m_SizeA[nID] = sVisionInfo.dSizeA;//m_dDiameter;
		gVPro.m_SizeB[nID] = sVisionInfo.dSizeB;//m_dDiameter;
		gVPro.m_SizeC[nID] = sVisionInfo.dSizeC;//m_dDiameter;
		gVPro.m_dXYRatio[nID] = sVisionInfo.dAspectRatio / 100.0;
		gVPro.m_dAngle[nID] = sVisionInfo.dScoreAngle * PI / 180.0;
		gVPro.m_nThreshold[nID] = sVisionInfo.nThreshold;

		for(int i = 0; i < 4; i++)
		{
			gVPro.m_BrightData[i] = sVisionInfo.dBrightness[i];
			gVPro.m_ContrastData[i] = sVisionInfo.dContrast[i];
		}
	   CopyToVProTemp(1,nCamNo);
		gVPro_Temp[nCamNo].m_bApplyParamFlag = 0;
		if(nID < MODEL_PATTERN)
			gVPro.PMToolTrain( nID, nCamNo, TRUE );
		else
			gVPro.PMToolTrain( nID, nCamNo, FALSE);
#endif
	}

}

void HVision::UpdateMinMax(double dSizeA, double dSizeB, double dSizeC)
{
	if(m_pOmi)
	{
		m_pOmi->UpdateMinMax(dSizeA, dSizeB, dSizeC);
	}
}

int HVision::On2DRead(int nCamNo, int nIndex, CString& strMsg, CString& strBarcodeResult , BOOL bFindPattern, int nPatternNo)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		OnLive( nCamNo, FALSE);
		OnAcquire(nCamNo);
		// ��� ��?		
		//		gVPro.ClearInteractiveGraphics(nCamNo);

#ifndef __TEST__
		//		gVPro.LogicProcess(nCamNo, nCamNo, 178, 0, FALSE);
#endif
		gProcess.m_ResultData[nCamNo].dx = gProcess.m_ResultData[nCamNo].dy = gProcess.m_ResultData[nCamNo].dCaliDist = 0;

		BOOL bRes;
		int nResult = 0;
		CString strBarcodeResult;
		if(gVPro.m_ShapeTypeNo < MODEL_PATTERN)
			bRes = gVPro.Barcode2DTrain(0, nCamNo, true, TRUE );
		if(bRes)
		{
			nResult = gVPro.Barcode2DFind( nCamNo, 0, true,strBarcodeResult);

			double dx, dy;
			if(nResult)
			{
				ResultCalTrans[nCamNo].TransformPoint(gProcess.m_ResultData[nCamNo].dx, gProcess.m_ResultData[nCamNo].dy, dx, dy);
				gProcess.m_ResultData[nCamNo].dx = dx;
				gProcess.m_ResultData[nCamNo].dy = dy;
			}

			strMsg.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), gProcess.m_ResultData[nCamNo].dx, 
				gProcess.m_ResultData[nCamNo].dy,
				gProcess.m_ResultData[nCamNo].dCaliDist);
			return nResult;
		}
		else
		{
			strMsg.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), gProcess.m_ResultData[nCamNo].dx, 
				gProcess.m_ResultData[nCamNo].dy,
				gProcess.m_ResultData[nCamNo].dCaliDist);
			return nResult;
		}
		
#endif
	}

	return TRUE;
}
int HVision::OnFindFiducial(int nCamNo, int nIndex, CString& strMsg, BOOL bFindPattern, int nPatternNo)
{
	if(m_pOmi)
	{
		// result cal�� �Ʒ� visionPro ó�� �����ؾ���.
		return m_pOmi->OnFindFiducial(nCamNo, strMsg);
	}
	if(m_pMatrox)
	{
		return m_pMatrox->OnFindFiducial(nIndex, strMsg);
	}
	if(m_pMatroxTCP)
	{
		char pChar[255];
		BOOL bResult = m_pMatroxTCP->GetRealPos(NULL, nCamNo, nIndex /* Trigger Index */, pChar);
		strMsg.Format(_T("%s"), pChar);
		return bResult;
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		OnLive( nCamNo, FALSE);
		OnAcquire(nCamNo);
// ��� ��?		
//		gVPro.ClearInteractiveGraphics(nCamNo);
		
#ifndef __TEST__
//		gVPro.LogicProcess(nCamNo, nCamNo, 178, 0, FALSE);
#endif
		gProcess.m_ResultData[nCamNo].dx = gProcess.m_ResultData[nCamNo].dy = gProcess.m_ResultData[nCamNo].dCaliDist = 0;
		int nResult;
		if (nIndex >= MODEL_PATTERN)
			nResult = gVPro.PMToolFind( nCamNo, nIndex, true, false );
		else
			nResult = gVPro.PMToolFind( nCamNo, nIndex, true, true );
		
		double dx, dy;
		if(nResult)
		{
			ResultCalTrans[nCamNo].TransformPoint(gProcess.m_ResultData[nCamNo].dx, gProcess.m_ResultData[nCamNo].dy, dx, dy);
			gProcess.m_ResultData[nCamNo].dx = dx;
			gProcess.m_ResultData[nCamNo].dy = dy;
		}
		
		strMsg.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), gProcess.m_ResultData[nCamNo].dx, 
			gProcess.m_ResultData[nCamNo].dy,
			gProcess.m_ResultData[nCamNo].dCaliDist);
		return nResult;
#endif
	}
	
	return TRUE;
}

BOOL HVision::OnFindHole(int nCamNo, int nIndex, CString& strMsg)
{
	if(m_pMatrox)
	{
		return m_pMatrox->OnFindHole(nIndex, strMsg);
	}
	if(m_pMatroxTCP)
	{
		char pChar[255];
		BOOL bResult = m_pMatroxTCP->GetRealPos(NULL, nCamNo, nIndex /* Trigger Index */, pChar);
		strMsg.Format(_T("%s"), pChar);
		return bResult;
	}

	return TRUE;
}

void HVision::OnLightAll(int nCamNo, int nCoaxial, int nRing)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		m_pOmi->OnLightAll(nCamNo, nCoaxial, nRing);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		switch( nCamNo )
		{
		case 0 :
//			m_VisionLamp->LampOut(_T("1"), nCoaxial);
//			m_VisionLamp->LampOut(_T("3"), nRing);
			m_VisionLamp->LampOut(_T("3"), nCoaxial);
			m_VisionLamp->LampOut(_T("4"), nRing);
			break;
		case 1 :
//			m_VisionLamp->LampOut(_T("2"), nCoaxial);
//			m_VisionLamp->LampOut(_T("4"), nRing);
			m_VisionLamp->LampOut(_T("1"), nCoaxial);
			m_VisionLamp->LampOut(_T("2"), nRing);
			break;
		case 2 :
//			m_VisionLamp->LampOut(_T("7"), nCoaxial);
//			m_VisionLamp->LampOut(_T("5"), nRing);
			m_VisionLamp->LampOut(_T("3"), nCoaxial);
			m_VisionLamp->LampOut(_T("4"), nRing);
			break;
		case 3 :
//			m_VisionLamp->LampOut(_T("8"), nCoaxial);
//			m_VisionLamp->LampOut(_T("A"), nRing);
			m_VisionLamp->LampOut(_T("1"), nCoaxial);
			m_VisionLamp->LampOut(_T("2"), nRing);
			break;
		}
	}
}

void HVision::GetLampValue(int nCamNo, CString &strCoaxial, CString &strRing)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return;


	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		switch( nCamNo )
		{
		case 0 :
// 			strCoaxial = m_VisionLamp->GetLampValue(_T("1"));
// 			strRing = m_VisionLamp->GetLampValue(_T("3"));
			strCoaxial = m_VisionLamp->GetLampValue(_T("3"));
 			strRing = m_VisionLamp->GetLampValue(_T("4"));
			break;
		case 1 :
			strCoaxial = m_VisionLamp->GetLampValue(_T("1"));
			strRing = m_VisionLamp->GetLampValue(_T("2"));
			break;
		case 2 :
			strCoaxial = m_VisionLamp->GetLampValue(_T("3"));
			strRing = m_VisionLamp->GetLampValue(_T("4"));
			break;
		case 3 :
			strCoaxial = m_VisionLamp->GetLampValue(_T("1"));
			strRing = m_VisionLamp->GetLampValue(_T("2"));
			break;
		}
	}
}

void HVision::OnLight(int nCamNo, int nType, int nVal)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		m_pOmi->OnLightAll(nCamNo, nType, nVal);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		switch( nCamNo )
		{
		case 0 :
// 			if(nType == 0)
// 				m_VisionLamp->LampOut(_T("1"), nVal);
// 			else
// 				m_VisionLamp->LampOut(_T("3"), nVal);
			if(nType == 0)
				m_VisionLamp->LampOut(_T("3"), nVal);
			else
				m_VisionLamp->LampOut(_T("4"), nVal);
			break;
		case 1 :
// 			if(nType == 0)
// 				m_VisionLamp->LampOut(_T("2"), nVal);
// 			else
// 				m_VisionLamp->LampOut(_T("4"), nVal);
			if(nType == 0)
				m_VisionLamp->LampOut(_T("3"), nVal);
			else
				m_VisionLamp->LampOut(_T("4"), nVal);
			break;
		case 2 :
// 			if(nType == 0)
// 				m_VisionLamp->LampOut(_T("7"), nVal);
// 			else
// 				m_VisionLamp->LampOut(_T("9"), nVal);
			if(nType == 0)
				m_VisionLamp->LampOut(_T("1"), nVal);
			else
				m_VisionLamp->LampOut(_T("2"), nVal);

			break;
		case 3 :
// 			if(nType == 0)
// 				m_VisionLamp->LampOut(_T("8"), nVal);
// 			else
// 				m_VisionLamp->LampOut(_T("A"), nVal);
			if(nType == 0)
				m_VisionLamp->LampOut(_T("1"), nVal);
			else
				m_VisionLamp->LampOut(_T("2"), nVal);
			break;
		}
	}
	
}

void HVision::SetVisionZoom(int nCamNo, int nZoom)
{
	if(m_pOmi)
	{
		m_pOmi->SetVisionZoom(nCamNo, nZoom);
	}
}

void HVision::SetPixel(int nCamNo, DPOINT dPixel)
{
	if(m_pOmi)
	{
		m_pOmi->SetPixel(nCamNo, dPixel);	
	}
}

int HVision::GetRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pChar, BOOL bFindPattern)
{
	if(m_pOmi)
	{
		double dSize;
		return m_pOmi->GetRealPos(rPos, nCam, bRefresh, dSize, pChar);	
	}
	if(m_pMatrox)
	{
		// nCam : Index, bRefresh : Trigger or TriggerAgc
		return m_pMatrox->GetRealPos(rPos, nIndex, bRefresh, pChar);
	}
	if(m_pMatroxTCP)
	{
		// nCam : Index, bRefresh : Trigger or TriggerAgc
		return m_pMatroxTCP->GetRealPos(rPos, nCam, nIndex /* Trigger Index */, pChar);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		CString strMess;
		int nReturn; // = OnFindFiducial(nCam, nIndex, strMess);
		if(gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			nReturn = TRUE;
			gProcess.m_ResultData[nCam].dx = gProcess.m_ResultData[nCam].dy = 0.0;
			strMess.Format(_T("X : 0.000, Y : 0.000, (0.000)"));
		}
		else
		{
			nReturn = OnFindFiducial(nCam, nIndex, strMess);
		}
		rPos->x = gProcess.m_ResultData[nCam].dx;
		rPos->y = gProcess.m_ResultData[nCam].dy;
		
#ifdef __TEST__
		if(gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			nReturn = TRUE;
			gProcess.m_ResultData[nCam].dx = gProcess.m_ResultData[nCam].dy = 0.0;
			strMess.Format(_T("X : 0.000, Y : 0.000, (0.000)"));
		}
		else
		{
			for(__int64 i = 0; i < m_n64Count; i++)
				rand();
			
			double dMax = 2.0 * rand() / static_cast<double>(RAND_MAX);
			rPos->x = gProcess.m_ResultData[nCam].dx = dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX) / 1000.;
			rPos->y = gProcess.m_ResultData[nCam].dy = dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX) / 1000.;
			m_n64Count += static_cast<__int64>(3);
			
			nReturn = TRUE;
			
			strMess.Format(_T("X : %.3f, Y : %.3f, (0.0)"), rPos->x, rPos->y);
		}
#endif
		
		if(pChar != NULL)
			memcpy(pChar, strMess, strMess.GetLength()+1);
		
		return nReturn;
#endif
	}

	return TRUE;
}

void HVision::ShowArea(int nShow, int nPatternNo, int nCam)
{
	if(m_pOmi)
	{
		m_pOmi->ShowArea(nShow);	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.PMToolShowSearchRegion( nPatternNo, nShow, nCam);
#endif
	}
}

void HVision::SetInspectionArea(int nSize, int nCam)
{
	if(m_pOmi)
	{
		m_pOmi->SetInspectionArea(nSize);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		if (nSize == -1 || nSize < 2 || nSize > gVPro.m_ImageWidth - 2)
		{
			for(int i = 0; i < MAX_CAMERA ; i++) // 110527 yhchung �켱 4����.
			{
				gVPro.m_SearchAreacx[i] = gVPro.m_ImageWidth/2; // Inspection area�� center��
				gVPro.m_SearchAreacy[i] = gVPro.m_ImageHeight/2; // Inspection area�� center��
				gVPro.m_SearchAreacw[i] = gVPro.m_ImageWidth - 10; // Inspection area�� ũ��
				gVPro.m_SearchAreach[i] = gVPro.m_ImageHeight - 10; // Inspection area�� ũ��
				gVPro.PMToolSetSearchAllRegion(i);
			}
		}
		else
		{
			for(int i = 0; i < MAX_CAMERA; i++) // 110527 yhchung �켱 4����.
			{
				gVPro.m_SearchAreacx[i] = gVPro.m_ImageWidth/2; 
				gVPro.m_SearchAreacy[i] = gVPro.m_ImageHeight/2; 
				gVPro.m_SearchAreacw[i] = nSize; 
				gVPro.m_SearchAreach[i] = nSize; 
				gVPro.PMToolSetSearchAllRegion(i);

				// 110607 ���� ó�� ���� �ٲ�
				//gVPro.PMToolShowSearchRegion( i, TRUE, nCam );
				//gVPro.PMToolSetSearchRegion( i, nCam, TRUE );
			}
		}
//		gVPro.PMToolSetSearchRegion( 0 );	//�� ���� ���
//		gVPro.ClearInteractiveGraphics(0);
//		gVPro.ClearInteractiveGraphics(1);
//		gVPro.ClearInteractiveGraphics(2);
//		gVPro.ClearInteractiveGraphics(3);

#endif
	}
}

void HVision::SetInspectionAreaPercent(double nPercent, int nCam)
{
	if(m_pOmi)
	{
		m_pOmi->SetInspectionArea(nPercent * SCREEN_PIXEL_X / 100);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		double nSize = nPercent * gVPro.m_ImageWidth / 100; 
		if (nSize == -1 || nSize < 2 || nSize > gVPro.m_ImageWidth - 2)
		{
			for(int i = 0; i < MAX_CAMERA ; i++) // 110527 yhchung �켱 4����.
			{
				gVPro.m_SearchAreacx[i] = gVPro.m_ImageWidth/2; // Inspection area�� center��
				gVPro.m_SearchAreacy[i] = gVPro.m_ImageHeight/2; // Inspection area�� center��
				gVPro.m_SearchAreacw[i] = gVPro.m_ImageWidth - 10; // Inspection area�� ũ��
				gVPro.m_SearchAreach[i] = gVPro.m_ImageHeight - 10; // Inspection area�� ũ��
				gVPro.PMToolSetSearchAllRegion(i);
			}
		}
		else
		{
			for(int i = 0; i < MAX_CAMERA; i++) // 110527 yhchung �켱 4����.
			{
				gVPro.m_SearchAreacx[i] = gVPro.m_ImageWidth/2; 
				gVPro.m_SearchAreacy[i] = gVPro.m_ImageHeight/2; 
				gVPro.m_SearchAreacw[i] = nSize; 
				gVPro.m_SearchAreach[i] = nSize; 
				gVPro.PMToolSetSearchAllRegion(i);
			}
		}
#endif
	}
}

void HVision::SetViewHandle(HWND* pHwnd)
{
	if(m_pMatrox)
	{
		m_pMatrox->SetViewHandle(pHwnd);
	}
}

void HVision::ShowVisionDialog(BOOL bShow)
{
	if(m_pMatrox)
	{
		m_pMatrox->ShowVisionDialog(bShow);
	}
}

void HVision::SetInspectArea(DPOINT dpStart, DPOINT dpEnd)
{
	if(m_pMatrox)
	{
		m_pMatrox->SetInspectArea(dpStart, dpEnd);
	}
}

void HVision::SetLevel(BOOL bSuperUser)
{
	if(m_pMatrox)
	{
		m_pMatrox->SetLevel(bSuperUser);
	}
}

void HVision::ConnectPatternUI(int nDisplay, CWnd *pWnd)
{
#ifdef USE_VISION_PRO
	if(nDisplay == DISPLAYB)
		gVPro.SetDisplayWindow( DISPLAYB, pWnd );
	else if(nDisplay == DISPLAYA)
		gVPro.SetDisplayWindow( DISPLAYA, pWnd);
#endif
}

void HVision::SetCalTansData()
{
/*	ResultCalTrans[HIGH_1ST_CAM].SetNumPoint(4);
	ResultCalTrans[HIGH_1ST_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d1stHighLeftBottomOffset.x , -gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d1stHighLeftBottomOffset.y, 0);
	ResultCalTrans[HIGH_1ST_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dHighValPos.x , -gSystemINI.m_sSystemDevice.dHighValPos.y, 0);
	ResultCalTrans[HIGH_1ST_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d1stHighRightBottomOffset.x , -gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d1stHighRightBottomOffset.y, 1);
	ResultCalTrans[HIGH_1ST_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dHighValPos.x , -gSystemINI.m_sSystemDevice.dHighValPos.y, 1);
	ResultCalTrans[HIGH_1ST_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d1stHighRightTopOffset.x , gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d1stHighRightTopOffset.y, 2);
	ResultCalTrans[HIGH_1ST_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dHighValPos.x , gSystemINI.m_sSystemDevice.dHighValPos.y, 2);
	ResultCalTrans[HIGH_1ST_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d1stHighLeftTopOffset.x , gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d1stHighLeftTopOffset.y, 3);
	ResultCalTrans[HIGH_1ST_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dHighValPos.x , gSystemINI.m_sSystemDevice.dHighValPos.y, 3);
	ResultCalTrans[HIGH_1ST_CAM].Transform();

	ResultCalTrans[LOW_1ST_CAM].SetNumPoint(4);
	ResultCalTrans[LOW_1ST_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d1stLowLeftBottomOffset.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d1stLowLeftBottomOffset.y, 0);
	ResultCalTrans[LOW_1ST_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y, 0);
	ResultCalTrans[LOW_1ST_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d1stLowRightBottomOffset.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d1stLowRightBottomOffset.y, 1);
	ResultCalTrans[LOW_1ST_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dLowCalPos.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y, 1);
	ResultCalTrans[LOW_1ST_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d1stLowRightTopOffset.x , gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d1stLowRightTopOffset.y, 2);
	ResultCalTrans[LOW_1ST_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dLowCalPos.x , gSystemINI.m_sSystemDevice.dLowCalPos.y, 2);
	ResultCalTrans[LOW_1ST_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d1stLowLeftTopOffset.x , gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d1stLowLeftTopOffset.y, 3);
	ResultCalTrans[LOW_1ST_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x , gSystemINI.m_sSystemDevice.dLowCalPos.y, 3);
	ResultCalTrans[LOW_1ST_CAM].Transform();

	ResultCalTrans[HIGH_2ND_CAM].SetNumPoint(4);
	ResultCalTrans[HIGH_2ND_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d2ndHighLeftBottomOffset.x , -gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d2ndHighLeftBottomOffset.y, 0);
	ResultCalTrans[HIGH_2ND_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dHighValPos.x , -gSystemINI.m_sSystemDevice.dHighValPos.y, 0);
	ResultCalTrans[HIGH_2ND_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d2ndHighRightBottomOffset.x , -gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d2ndHighRightBottomOffset.y, 1);
	ResultCalTrans[HIGH_2ND_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dHighValPos.x , -gSystemINI.m_sSystemDevice.dHighValPos.y, 1);
	ResultCalTrans[HIGH_2ND_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d2ndHighRightTopOffset.x , gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d2ndHighRightTopOffset.y, 2);
	ResultCalTrans[HIGH_2ND_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dHighValPos.x , gSystemINI.m_sSystemDevice.dHighValPos.y, 2);
	ResultCalTrans[HIGH_2ND_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dHighValPos.x + gSystemINI.m_sSystemDevice.d2ndHighLeftTopOffset.x , gSystemINI.m_sSystemDevice.dHighValPos.y + gSystemINI.m_sSystemDevice.d2ndHighLeftTopOffset.y, 3);
	ResultCalTrans[HIGH_2ND_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dHighValPos.x , gSystemINI.m_sSystemDevice.dHighValPos.y, 3);
	ResultCalTrans[HIGH_2ND_CAM].Transform();

	ResultCalTrans[LOW_2ND_CAM].SetNumPoint(4);
	ResultCalTrans[LOW_2ND_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d2ndLowLeftBottomOffset.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d2ndLowLeftBottomOffset.y, 0);
	ResultCalTrans[LOW_2ND_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y, 0);
	ResultCalTrans[LOW_2ND_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d2ndLowRightBottomOffset.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d2ndLowRightBottomOffset.y, 1);
	ResultCalTrans[LOW_2ND_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dLowCalPos.x , -gSystemINI.m_sSystemDevice.dLowCalPos.y, 1);
	ResultCalTrans[LOW_2ND_CAM].SetReferencePoint( gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d2ndLowRightTopOffset.x , gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d2ndLowRightTopOffset.y, 2);
	ResultCalTrans[LOW_2ND_CAM].SetTransformedPoint( gSystemINI.m_sSystemDevice.dLowCalPos.x , gSystemINI.m_sSystemDevice.dLowCalPos.y, 2);
	ResultCalTrans[LOW_2ND_CAM].SetReferencePoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x + gSystemINI.m_sSystemDevice.d2ndLowLeftTopOffset.x , gSystemINI.m_sSystemDevice.dLowCalPos.y + gSystemINI.m_sSystemDevice.d2ndLowLeftTopOffset.y, 3);
	ResultCalTrans[LOW_2ND_CAM].SetTransformedPoint( -gSystemINI.m_sSystemDevice.dLowCalPos.x , gSystemINI.m_sSystemDevice.dLowCalPos.y, 3);
	ResultCalTrans[LOW_2ND_CAM].Transform();
*/
}

void HVision::SetAcceptScore(double dVal)
{
#ifdef USE_VISION_PRO
	for ( int i = 0; i < CREATEVP; i++ )
		gVPro.m_ActScore[i] = dVal; //Accept Score
#endif
}



BOOL HVision::GetTrained(int nNum)
{
#ifdef USE_VISION_PRO
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		return gVPro.GetTrained(nNum); //Pattern No
#endif
	return FALSE;
}
void HVision::ShowTrainRegion(int nNum, int nCamNo)
{
#ifdef USE_VISION_PRO
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		gVPro.ClearInteractiveGraphics(nCamNo);
		
	}
#endif

}

void HVision::DisplayTrainedImage(int nPatternNo)
{
#ifdef USE_VISION_PRO	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		gVPro.DisplayTrainedPatten(nPatternNo);
	}
#endif
}

void HVision::SetSelIndex(int nIndex)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.m_nSelIndexNo = nIndex;
		
		if(gVPro.m_nSelIndexNo == 1)
			gVPro.m_ShapeTypeNo  = MODEL_CIRCLE;
		else if(gVPro.m_nSelIndexNo == 2)
			gVPro.m_ShapeTypeNo  = MODEL_CROSS;
		else if(gVPro.m_nSelIndexNo == 5)
			gVPro.m_ShapeTypeNo  = MODEL_RECT;
		else if(gVPro.m_nSelIndexNo >= 7)
			gVPro.m_ShapeTypeNo  = MODEL_PATTERN;
#endif
	}
}

void HVision::GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		if(nSel < MODEL_PATTERN )
		{
			pVisionInfo->dSizeA = gVPro.m_SizeA[nSel];
			pVisionInfo->dSizeB = gVPro.m_SizeB[nSel];
			pVisionInfo->dSizeC = gVPro.m_SizeC[nSel];
		}
		else
		{
			pVisionInfo->dSizeA = 0;
			pVisionInfo->dSizeB = 0;
			pVisionInfo->dSizeB = 0;
		}
		
		
		pVisionInfo->dContrast[nCamNo] = gVPro.m_ContrastData[nCamNo];
		pVisionInfo->dBrightness[nCamNo] = gVPro.m_BrightData[nCamNo]; 
		pVisionInfo->nBlob[nCamNo] = gVPro.m_nBlob[nCamNo];
		pVisionInfo->dScoreSize = (gVPro.m_ScaleP[nSel] - 1.0) * 100  ;
		pVisionInfo->dScoreAngle = gVPro.m_dAngle[nSel] * 180 / PI;
		pVisionInfo->dAspectRatio = gVPro.m_dXYRatio[nSel] * 100;

		if(gVPro.m_ShapePolarity == 1)
			pVisionInfo->nPolarity = 0;
		else if(gVPro.m_ShapePolarity == -1)
			pVisionInfo->nPolarity = 1;
		else 
			pVisionInfo->nPolarity = 0;
#endif
	}
}

void HVision::SetShapeType(int nNum)
{
#ifdef USE_VISION_PRO
	gVPro.m_ShapeTypeNo = nNum;
#endif
}

void HVision::SetSearchRegion(int nCam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
//		gVPro.SetSearchRegion(nCam);
	}
}

BOOL HVision::SetTrainRegion(int nID, int nCam)
{

	BOOL bRes = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		bRes =	gVPro.SetTrainRegion(nID, nCam);
//		gVPro.ClearInteractiveGraphics(nCam);
#endif
	}
	return bRes;
}

BOOL HVision::SetSearchRegion_All()
{
	return TRUE;
//	return gVPro.SetSearchRegion_All();
}

BOOL HVision::GetTrainRegion(int nCam)
{
	return TRUE;
//	return gVPro.GetTrainRegion(nCam);
}

BOOL HVision::GrabImage(int nPattern, int nCam)
{
#ifdef USE_VISION_PRO
	return gVPro.GrabImage(nPattern, nCam);
#endif
	return TRUE;
}

void HVision::PMToolShowTrainRegion(int nPatternNo, int nCam)
{
#ifdef USE_VISION_PRO
	gVPro.PMToolShowTrainRegion(nPatternNo, nCam);
#endif
}

void HVision::ClearInteractiveGraphics(int nCam)
{
#ifdef USE_VISION_PRO
	gVPro.ClearInteractiveGraphics(nCam);
#endif
}	

void HVision::TransformPixel()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.TransformPixel();
		gVPro.CalPixelDistance();
#endif
	}
	if(m_pOmi)
	{
		m_pOmi->TransformPixel();	
		m_pOmi->CalPixelDistance();
	}
}

int HVision::GetNoGrabRealPos(DPOINT *rPos, int nCam, int nIndex, BOOL bRefresh, char *pChar, double& dFoundSize)
{
	if(m_pOmi)
	{
		return m_pOmi->GetRealPos(rPos, nCam, bRefresh, dFoundSize, pChar );	
	}
	if(m_pMatrox)
	{
		// nCam : Index, bRefresh : Trigger or TriggerAgc
		return m_pMatrox->GetRealPos(rPos, nIndex, bRefresh, pChar);
	}
	if(m_pMatroxTCP)
	{
		// nCam : Index, bRefresh : Trigger or TriggerAgc
		return m_pMatroxTCP->GetRealPos(rPos, nCam, nIndex /* Trigger Index */, pChar);
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
	#ifdef USE_VISION_PRO
		CString strMess;
		int nReturn; // = OnFindFiducial(nCam, nIndex, strMess);
		if(gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			nReturn = 1;
			gProcess.m_ResultData[nCam].dx = gProcess.m_ResultData[nCam].dy = 0.0;
			strMess.Format(_T("X : 0.000, Y : 0.000, (0.000)"));
		}
		else
		{
#ifndef __TEST__
			nReturn = OnFindFiducialNoGrab(nCam, nIndex, strMess);
#endif
		}
		rPos->x = gProcess.m_ResultData[nCam].dx;
		rPos->y = gProcess.m_ResultData[nCam].dy;
		dFoundSize = gProcess.m_ResultData[nCam].dCaliDist;
		
#ifdef __TEST__
		if(gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			nReturn = 1;
			gProcess.m_ResultData[nCam].dx = gProcess.m_ResultData[nCam].dy = 0.0;
			strMess.Format(_T("X : 0.000, Y : 0.000, (0.000)"));
		}
		else
		{
			for(__int64 i = 0; i < m_n64Count; i++)
				rand();
			
			double dMax = 2.0 * rand() / static_cast<double>(RAND_MAX);
			rPos->x = gProcess.m_ResultData[nCam].dx = dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX) / 1000. * 10;
			rPos->y = gProcess.m_ResultData[nCam].dy = dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX) / 1000. * 10;
			m_n64Count += static_cast<__int64>(3);
			
			nReturn = 1;
			
			strMess.Format(_T("X : %.3f, Y : %.3f, (0.0)"), rPos->x, rPos->y);
		}
#endif
		
		if(pChar != NULL)
			memcpy(pChar, strMess, strMess.GetLength()+1);
		
		return nReturn;
#endif
	}
	
	return TRUE;
}

int HVision::OnFindFiducialNoGrab(int nCamNo, int nIndex, CString &strMsg)
{
	if(m_pOmi)
	{
		// result cal�� �Ʒ� visionPro ó�� �����ؾ���.
		return m_pOmi->OnFindFiducial(nCamNo, strMsg);
	}
	if(m_pMatrox)
	{
		return m_pMatrox->OnFindFiducial(nIndex, strMsg);
	}
	if(m_pMatroxTCP)
	{
		char pChar[255];
		BOOL bResult = m_pMatroxTCP->GetRealPos(NULL, nCamNo, nIndex /* Trigger Index */, pChar);
		strMsg.Format(_T("%s"), pChar);
		return bResult;
	}
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gProcess.m_ResultData[nCamNo].dx = gProcess.m_ResultData[nCamNo].dy = gProcess.m_ResultData[nCamNo].dCaliDist = 0;
		int nResult;

//		gVPro.LogicProcess(nCamNo, nCamNo, 178, 0, FALSE);

		if (nIndex >= MODEL_PATTERN)
			nResult = gVPro.PMToolFind( nCamNo, nIndex, true, false );
		else
			nResult = gVPro.PMToolFind( nCamNo, nIndex, true, true );
		
		double dx, dy;
		if(nResult)
		{
			ResultCalTrans[nCamNo].TransformPoint(gProcess.m_ResultData[nCamNo].dx, gProcess.m_ResultData[nCamNo].dy, dx, dy);
			gProcess.m_ResultData[nCamNo].dx = dx;
			gProcess.m_ResultData[nCamNo].dy = dy;

			strMsg.Format(_T("X : %.3f, Y : %.3f, (%.3f)"), gProcess.m_ResultData[nCamNo].dx, 
				gProcess.m_ResultData[nCamNo].dy,
				gProcess.m_ResultData[nCamNo].dCaliDist);
		}
		else
		{
			strMsg.Format(_T("Searching Fail"));
		}
		
		return nResult;
#endif

	}
	
	return TRUE;
}

void HVision::SetThreshold(int nCamNo, int nIndex, int nThreshold)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.m_nThreshold[nIndex] = nThreshold;
//		gVPro.LogicProcess(nCamNo, nCamNo, nIndex, 1, TRUE);
#endif
	}
}

void HVision::InitVisionPixelData(int nCam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.InitVisionPixelData(nCam);
#endif
	}
	else
	{
		if(m_pOmi)
		{
			m_pOmi->InitVisionPixelData(nCam);
		}
	}
}

void HVision::InitDistancePerPixel()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.InitDistancePerPixel();
#endif
	}
	else
	{
		if(m_pOmi)
		{
			m_pOmi->InitDistancePerPixel();
		}
	}
}

void HVision::ConnectOmiVision()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		if(m_pOmi)
			m_pOmi->ConnectOmiVision();
	}
}
void HVision::SetBlobValue(int nWhiteBlob)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		gVPro.SetBlobValue(nWhiteBlob);
#endif
	}
	
}
BOOL HVision::CheckOmiHandle()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		if(m_pOmi)
			m_pOmi->CheckOmiHandle();
	}
	return TRUE;

}	
void HVision::Get2DBarcode(char* szResult, BOOL bLoad)
{
#ifdef __TEST__
	strcpy(szResult, _T("NO!!!!!"));
	return;
#endif
	if( bLoad )
	{
		if(m_p2D != NULL)
			m_p2D->GetResult(szResult);
		else
			strcpy(szResult, "");
	}
	else
	{
		if(m_p2DUnload != NULL)
			m_p2DUnload->GetResult(szResult);
		else
			strcpy(szResult, "");	
	}
}

void HVision::UseRemoteControl(BOOL bRemote)
{
	m_VisionLamp->UseRemoteControl(bRemote);
#ifdef __OSAN_LG_2013__
	m_VisionLamp2->UseRemoteControl(bRemote);
#endif
}