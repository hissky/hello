#if !defined(AFX_DLGVISIONPROVIEW_H__912ADC42_739E_4530_B0AD_6195BE9D0BC9__INCLUDED_)
#define AFX_DLGVISIONPROVIEW_H__912ADC42_739E_4530_B0AD_6195BE9D0BC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgVisionProView.h : header file

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionProView dialog
class CPaneHV1;
class CPaneHV2;
class CPaneLV1;
class CPaneLV2;

class CDlgVisionProView : public CDialog
{
// Construction
public:
	void ReSize(CRect rc);
	BOOL m_bTopMost;
	int	 m_nCamNo;
	void InitTabControl();
	void ShowSelectCamera(int nCamNo);
	void SetPanelNo(int nNo);
	CDlgVisionProView(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgVisionProView)
	enum { IDD = IDD_DLG_VISION_PRO_DLG };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgVisionProView)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CPaneHV1*	m_pHighVision1;
	CPaneHV2*	m_pHighVision2;
	CPaneLV1*	m_pLowVision1;
	CPaneLV2*	m_pLowVision2;
	BOOL		m_bInit;
	// Generated message map functions
	//{{AFX_MSG(CDlgVisionProView)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnMove(int x, int y);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGVISIONPROVIEW_H__912ADC42_739E_4530_B0AD_6195BE9D0BC9__INCLUDED_)
