#if !defined(AFX_DLGINPUTLOT_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
#define AFX_DLGINPUTLOT_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputLot.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLot dialog

class CDlgInputLot : public CDialog
{
// Construction
public:
	CDlgInputLot(CWnd* pParent = NULL);   // standard constructor

	void		InitControl();
	void		SetInputLot(int nLot)	{ m_nInputLot = nLot; }
	int			GetInputLot()			{ return m_nInputLot; }
	void		SetStartNo(int nStartNo)	{ m_nStartNo = nStartNo; }
	int			GetStartNo()			{ return m_nStartNo; }

// Dialog Data
	//{{AFX_DATA(CDlgInputLot)
	enum { IDD = IDD_DLG_INPUT_LOT };
	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnCancel;
	CColorEdit	m_edtStartNo;
	CColorEdit	m_edtInputLot;
	BOOL		m_bLotCountSetting;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputLot)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	int				m_nInputLot;
	int				m_nStartNo;

	// Generated message map functions
	//{{AFX_MSG(CDlgInputLot)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTLOT_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
