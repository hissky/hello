#if !defined(AFX_PANEMANUALCONTROLMOTOR_H__A22474C2_620F_4E3D_937A_0819409101EB__INCLUDED_)
#define AFX_PANEMANUALCONTROLMOTOR_H__A22474C2_620F_4E3D_937A_0819409101EB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlMotor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotor form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButton.h"
#include "UEasyButtonEx.h"

class CPaneManualControlMotor : public CFormView
{
protected:
	CPaneManualControlMotor();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlMotor)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlMotor)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_MOTOR };
	CColorStatic	m_stcPosC;
	CColorStatic	m_stcPosC2;
	CColorStatic	m_stcPosM;
	CColorStatic	m_stcPosM2;
	CColorStatic	m_stcSpeedM;
	CColorStatic	m_stcSpeedM2;
	CColorStatic	m_stcSpeedC;
	CColorStatic	m_stcSpeedC2;
	CColorStatic	m_stcSpeedZ2;
	CColorStatic	m_stcSpeedZ1;
	CColorStatic	m_stcSpeedY;
	CColorStatic	m_stcSpeedX;
	CColorStatic	m_stcPosZ2;
	CColorStatic	m_stcPosZ1;
	CColorStatic	m_stcPosY;
	CColorStatic	m_stcPosX;
	UEasyButtonEx	m_btnUnloaderHoming;
	UEasyButtonEx	m_btnLoaderHoming;
	UEasyButtonEx	m_btnMotorHoming;
	UEasyButtonEx	m_btnUnloadingPos;
	UEasyButtonEx	m_btnLoadingPos;
	UEasyButtonEx	m_chkSlaveOn;
	UEasyButtonEx	m_chkMasterOn;
	UEasyButtonEx	m_chkSlaveAcrylOn;
	UEasyButtonEx	m_chkMasterAcrylOn;
	UEasyButtonEx	m_chkVacuumMotorOn;
	UEasyButtonEx	m_chkSafetyOn;
	UEasyButtonEx	m_chkMasterAcrOn;
	UEasyButtonEx	m_chkSlaveAcrOn;
	UEasyButtonEx	m_chkDoorBypass;
	UEasyButtonEx	m_btnUnloaderUnload;
	UEasyButtonEx	m_btnLoaderLoad;
	UEasyButtonEx	m_btnLoaderAlign;
	UEasyButtonEx	m_btnLoaderAlignLoad;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnMove2;
	UEasyButtonEx	m_btnMoveInpos;
	UEasyButtonEx	m_btnMPG;
	UEasyButtonEx	m_btnReject;
	UEasyButtonEx	m_btnUnloaderReject;
	UEasyButtonEx	m_btnLoaderReject;
	UEasyButtonEx	m_btnAllReject;
	UEasyButtonEx	m_chkTableClamp1;
	UEasyButtonEx	m_chkTableClamp2;


	CColorEdit	m_edtTargetZ2;
	CColorEdit	m_edtTargetZ1;
	CColorEdit	m_edtTargetY;
	CColorEdit	m_edtTargetM;
	CColorEdit	m_edtTargetC;
	CColorEdit	m_edtTargetX;
	CColorEdit	m_edtTargetZ4;
	CColorEdit	m_edtTargetZ3;
	CColorEdit	m_edtTargetY2;
	CColorEdit	m_edtTargetM2;
	CColorEdit	m_edtTargetC2;
	CColorEdit	m_edtTargetX2;
	CColorEdit	m_edtTargetC3;
	CColorEdit	m_edtTargetC4;
	CColorEdit	m_edtTargetM3;
	CColorEdit	m_edtTargetM4;

	//2011519
	CColorStatic	m_stcPosA;
	CColorStatic	m_stcPosA2;
	CColorStatic	m_stcSpeedA;
	CColorStatic	m_stcSpeedA2;

	CColorEdit	m_edtTargetA;
	CColorEdit	m_edtTargetA2;
	CColorEdit	m_edtTargetA3;
	CColorEdit	m_edtTargetA4;

	CColorEdit	m_edtRep;
	int		m_nAbs;
	BOOL	m_bTargetX;
	BOOL	m_bTargetY;
	BOOL	m_bTargetZ1;
	BOOL	m_bTargetZ2;
	BOOL	m_bTargetC;
	BOOL	m_bTargetC2;
	BOOL	m_bTargetM;
	BOOL	m_bTargetM2;
	BOOL	m_bTargetA;	//2011519
	BOOL	m_bTargetA2;
	int		m_nMasterSlave;
	//}}AFX_DATA

// Attributes
public:
	int				m_nMPGMode;
	BOOL			m_bTableMotor;
// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntBtn;
	CFont			m_fntEdit;

	UINT			m_nTimerID;

	BOOL			m_bMasterSuction;
	BOOL			m_bSlaveSuction;
	BOOL			m_bAcrylMasterSuction;
	BOOL			m_bAcrylSlaveSuction;


	//2011520
	BOOL			m_bVacuumMotor;
	BOOL			m_bSafetyMode;
	BOOL			m_bDoorBypass;

	BOOL			m_bTableClamp1;
	BOOL			m_bTableClamp2;
	BOOL			m_bStop;

	//2011524
	int m_nRadioVacuumTable;
	
	int m_nVacuumType;

// Operations
public:
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	int GetMPGMode();
	void MessageLoop();
	BOOL WaitHandler(int nCmd);
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();

	void			EnableAllBtn(BOOL bEnable);

	double			GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs=TRUE, BOOL bUse=TRUE);
	void			DispStatus();
	void			DispVelocity();
	void			SetTableSuction(BOOL bTable, BOOL bAcryl);

	void			InitTimer();
	void			DestroyTimer();

	void			SetAuthorityByLevel(int nLevel);

	//2011520
	void			ClearMsterTableVacumm();



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlMotor)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlMotor();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlMotor)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonMove();
	afx_msg void OnButtonMove2();
	afx_msg void OnButtonMoveInpos();
	afx_msg void OnButtonStop();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonLoaderAlign();
	afx_msg void OnButtonLoaderAlignLoad();
	afx_msg void OnButtonLoaderLoad();
	afx_msg void OnCheckMasterOn();
	afx_msg void OnCheckSlaveOn();
	afx_msg void OnCheckAcrylMasterOn();
	afx_msg void OnCheckAcrylSlaveOn();
	afx_msg void OnCheckVacuumMotorOn();
	afx_msg void OnCheckSafetyOn();
	afx_msg void OnCheckDoorBypass();
	afx_msg void OnCheckTableClamp1();
	afx_msg void OnCheckTableClamp2();
	afx_msg void OnButtonPosLoading();
	afx_msg void OnButtonPosUnloading();
	afx_msg void OnButtonUnloaderUnload();
	afx_msg void OnButtonMotorHoming();
	afx_msg void OnButtonLoaderHoming();
	afx_msg void OnButtonUnloaderHoming();
	afx_msg void OnButtonMPG();
	afx_msg void OnButtonReject();
	afx_msg void OnButtonLoaderReject();
	afx_msg void OnButtonUnloaderReject();
	afx_msg void OnButtonAllReject();
	afx_msg void OnRadioTable1A();
	afx_msg void OnRadioTable1B();	
	afx_msg void OnRadioTable1C();
	afx_msg void OnRadioTable1D();
	afx_msg void OnCheckMasterAcrylicOn();
	afx_msg void OnCheckSlaveAcrylicOn();
	afx_msg void OnRadioUnloadM();
	afx_msg void OnRadioUnloadS();
	afx_msg void OnRadioUnloadMs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLMOTOR_H__A22474C2_620F_4E3D_937A_0819409101EB__INCLUDED_)
