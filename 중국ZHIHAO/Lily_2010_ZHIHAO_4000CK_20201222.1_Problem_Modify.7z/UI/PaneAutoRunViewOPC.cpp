// D:\Source\2010_ver\Lily_2010\UI\PaneAutoRunViewOPC.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "PaneAutoRunViewOPC.h"
#include "CDlgOpcLossInput.h"
#include "EasyDrillerDlg.h"
#include "..\MODEL\DProcessINI.h"
#include "DlgSchedualeInfo.h"
#include "EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "..\MODEL\DSystemINI.h"
// CPaneAutoRunViewOPC

IMPLEMENT_DYNCREATE(CPaneAutoRunViewOPC, CFormView)

CPaneAutoRunViewOPC::CPaneAutoRunViewOPC()
	: CFormView(CPaneAutoRunViewOPC::IDD)
{
	m_nTimer = -1;
	m_nRMSType = 0;
	m_nSelectIndex = -1;
	m_bPNLCheck = TRUE;
	m_bStartReverseInfo = FALSE;
}

CPaneAutoRunViewOPC::~CPaneAutoRunViewOPC()
{
}

void CPaneAutoRunViewOPC::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewOPC)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_STATIC_USERID_VAL, m_stcUserName);
	DDX_Control(pDX, IDC_STATIC_BASKET_ID, m_stcBasketID);
	DDX_Control(pDX, IDC_STATIC_EES_STATUS_VAL, m_stcStatus);
	DDX_Control(pDX, IDC_STATIC_LOT, m_stcConnect1);
	DDX_Control(pDX, IDC_STATIC_LOT2, m_stcConnect2);
	DDX_Control(pDX, IDC_BUTTON_LOSS_INPUT, m_btnLoss);
	DDX_Control(pDX, IDC_BUTTON_RMS_ON_AI, m_chkRMSOnAI);
	DDX_Control(pDX, IDC_BUTTON_RMS_ON, m_chkRMSOn);
	DDX_Control(pDX, IDC_BUTTON_RMS_OFF, m_chkRMSOff);
	DDX_Control(pDX, IDC_BUTTON_PANEL_CHECK_ON2, m_chkPNLCheckOn);
	DDX_Control(pDX, IDC_BUTTON_PANEL_CHECK_OFF2, m_chkPNLCheckOff);
	DDX_Control(pDX, IDC_BUTTON_CURRENT_LOT, m_chkCurrentFire);
	DDX_Control(pDX, IDC_BUTTON_PRE, m_chkPreFire);
	DDX_Control(pDX, IDC_BUTTON_RE, m_chkPostFire);
	DDX_Control(pDX, IDC_LIST_PROJECT, m_listProject);
	DDX_Control(pDX, IDC_BUTTON_SCHUDLE, m_btnSchedule); 
	DDX_Control(pDX, IDC_BUTTON_TEST_FIRE, m_chkTestFire);
	DDX_Control(pDX, IDC_BUTTON_COM, m_chkAICom);
	DDX_Control(pDX, IDC_BUTTON_SOL, m_chkAISol); 
	DDX_Control(pDX, IDC_BUTTON_BOTH, m_chkAIBoth);

	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneAutoRunViewOPC, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_LOSS_INPUT, &CPaneAutoRunViewOPC::OnBnClickedButtonLossInput)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_RMS_ON_AI, &CPaneAutoRunViewOPC::OnBnClickedButtonRmsOnAi)
	ON_BN_CLICKED(IDC_BUTTON_RMS_ON, &CPaneAutoRunViewOPC::OnBnClickedButtonRmsOn)
	ON_BN_CLICKED(IDC_BUTTON_RMS_OFF, &CPaneAutoRunViewOPC::OnBnClickedButtonRmsOff)
	ON_BN_CLICKED(IDC_BUTTON_PANEL_CHECK_ON, &CPaneAutoRunViewOPC::OnBnClickedButtonPanelCheckOn)
	ON_BN_CLICKED(IDC_BUTTON_PANEL_CHECK_OFF, &CPaneAutoRunViewOPC::OnBnClickedButtonPanelCheckOff)
	ON_BN_CLICKED(IDC_BUTTON_CURRENT_LOT, &CPaneAutoRunViewOPC::OnBnClickedButtonCurrentLot)
	ON_BN_CLICKED(IDC_BUTTON_PRE, &CPaneAutoRunViewOPC::OnBnClickedButtonPre)
	ON_BN_CLICKED(IDC_BUTTON_RE, &CPaneAutoRunViewOPC::OnBnClickedButtonRe)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_LIST_PROJECT, &CPaneAutoRunViewOPC::OnClickListProject)
	ON_BN_CLICKED(IDC_BUTTON_SCHUDLE, &CPaneAutoRunViewOPC::OnBnClickedButtonSchudle)
	ON_BN_CLICKED(IDC_BUTTON_TEST_FIRE, &CPaneAutoRunViewOPC::OnBnClickedButtonTestFire)
	ON_BN_CLICKED(IDC_BUTTON_COM, &CPaneAutoRunViewOPC::OnBnClickedButtonCom)
	ON_BN_CLICKED(IDC_BUTTON_SOL, &CPaneAutoRunViewOPC::OnBnClickedButtonSol)
	ON_BN_CLICKED(IDC_BUTTON_BOTH, &CPaneAutoRunViewOPC::OnBnClickedButtonBoth)
	ON_EN_UPDATE(IDC_EDIT_BOX, &CPaneAutoRunViewOPC::OnEnUpdateEditBox)
END_MESSAGE_MAP()


// CPaneAutoRunViewOPC �����Դϴ�.

#ifdef _DEBUG
void CPaneAutoRunViewOPC::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPaneAutoRunViewOPC::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPaneAutoRunViewOPC �޽��� ó�����Դϴ�.


void CPaneAutoRunViewOPC::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	InitStatic();
	InitListControl();
	InitBtnControl();
	InitTimer();

}

void CPaneAutoRunViewOPC::InitListControl()
{
	m_fntList.CreatePointFont(90, "Arial Bold");

	m_listProject.SetFont( &m_fntList );
	m_listProject.SetExtendedStyle(m_listProject.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);

	m_listProject.DeleteAllItems();

	m_listProject.InsertColumn(0, _T(" Status "), LVCFMT_CENTER, 90);
	m_listProject.InsertColumn(1, _T(" Project "), LVCFMT_CENTER, 110);
	m_listProject.InsertColumn(2, _T(" Basket ID "), LVCFMT_CENTER, 110);
	m_listProject.InsertColumn(3, _T(" Lot ID "), LVCFMT_CENTER, 110);
	m_listProject.InsertColumn(4, _T(" Input PNL "), LVCFMT_CENTER, 85);
	m_listProject.InsertColumn(5, _T(" Fired PNL "), LVCFMT_CENTER, 85);
	m_listProject.InsertColumn(6, _T(" NG PNL "), LVCFMT_CENTER, 70);
	m_listProject.InsertColumn(7, _T(" Remain PNL "), LVCFMT_CENTER, 90);
	m_listProject.InsertColumn(8, _T(" Section "), LVCFMT_CENTER, 120);
	m_listProject.InsertColumn(9, _T(" Panel "), LVCFMT_CENTER, 80);

	m_editwnd.Create(WS_CHILD | ES_NOHIDESEL | ES_AUTOHSCROLL | WS_VISIBLE | ES_NUMBER, CRect(0,0,0,0), CWnd::FromHandle(m_listProject.m_hWnd), IDC_EDIT_BOX);
	m_editwnd.SetFont(GetFont(), FALSE);
	m_editwnd.SetMargins(4,4);
	SetWindowLong(m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);
}

void CPaneAutoRunViewOPC::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	GetDlgItem(IDC_STATIC_USERID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_GROUP_BASKET_ID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_EES_STATUS)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_NG_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_INFO2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_LEFT1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_LEFT2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_LEFT3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_LEFT4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_LEFT5)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_NG_RIGHT1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_RIGHT2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_RIGHT3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_RIGHT4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NG_RIGHT5)->SetFont( &m_fntStatic );


	m_stcStatus.SetFont( &m_fntStatic );
	m_stcStatus.SetForeColor( VALUE_FORE_COLOR );
	m_stcStatus.SetBackColor( VALUE_BACK_COLOR );

	m_stcUserName.SetFont( &m_fntStatic );
	m_stcUserName.SetForeColor( VALUE_FORE_COLOR );
	m_stcUserName.SetBackColor( VALUE_BACK_COLOR );

	m_stcBasketID.SetFont( &m_fntStatic );
	m_stcBasketID.SetForeColor( VALUE_FORE_COLOR );
	m_stcBasketID.SetBackColor( VALUE_BACK_COLOR );

	m_stcConnect1.SetFont( &m_fntStatic );
	m_stcConnect1.SetForeColor( VALUE_FORE_COLOR );
	m_stcConnect1.SetBackColor( VALUE_BACK_COLOR );

	m_stcConnect2.SetFont( &m_fntStatic );
	m_stcConnect2.SetForeColor( VALUE_FORE_COLOR );
	m_stcConnect2.SetBackColor( VALUE_BACK_COLOR );
}

void CPaneAutoRunViewOPC::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	// Loss Input
	m_btnLoss.SetFont( &m_fntBtn );
	m_btnLoss.SetFlat( FALSE );
	m_btnLoss.EnableBallonToolTip();
	m_btnLoss.SetToolTipText( _T("Loss Input") );
	m_btnLoss.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoss.SetBtnCursor(IDC_HAND_1);

	// Project Schedule
	m_btnSchedule.SetFont( &m_fntBtn );
	m_btnSchedule.SetFlat( FALSE );
	m_btnSchedule.EnableBallonToolTip();
	m_btnSchedule.SetToolTipText( _T("Set Project Sechdule") );
	m_btnSchedule.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSchedule.SetBtnCursor(IDC_HAND_1);
	m_btnSchedule.ShowWindow(SW_HIDE);

	// RMS On AI
	m_chkRMSOnAI.SetFont( &m_fntBtn );
	m_chkRMSOnAI.SetImageOrg( 10, 3 );
	m_chkRMSOnAI.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRMSOnAI.EnableBallonToolTip();
	m_chkRMSOnAI.SetToolTipText( _T("Master On") );
	m_chkRMSOnAI.SetBtnCursor(IDC_HAND_1);
	m_chkRMSOnAI.SetCheck(TRUE);

	// RMS On 
	m_chkRMSOn.SetFont( &m_fntBtn );
	m_chkRMSOn.SetImageOrg( 10, 3 );
	m_chkRMSOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRMSOn.EnableBallonToolTip();
	m_chkRMSOn.SetToolTipText( _T("Master On") );
	m_chkRMSOn.SetBtnCursor(IDC_HAND_1);

	// RMS Off
	m_chkRMSOff.SetFont( &m_fntBtn );
	m_chkRMSOff.SetImageOrg( 10, 3 );
	m_chkRMSOff.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRMSOff.EnableBallonToolTip();
	m_chkRMSOff.SetToolTipText( _T("Master On") );
	m_chkRMSOff.SetBtnCursor(IDC_HAND_1);

	// Check On
	m_chkPNLCheckOn.SetFont( &m_fntBtn );
	m_chkPNLCheckOn.SetImageOrg( 10, 3 );
	m_chkPNLCheckOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPNLCheckOn.EnableBallonToolTip();
	m_chkPNLCheckOn.SetToolTipText( _T("Master On") );
	m_chkPNLCheckOn.SetBtnCursor(IDC_HAND_1);

	// Check Off
	m_chkPNLCheckOff.SetFont( &m_fntBtn );
	m_chkPNLCheckOff.SetImageOrg( 10, 3 );
	m_chkPNLCheckOff.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPNLCheckOff.EnableBallonToolTip();
	m_chkPNLCheckOff.SetToolTipText( _T("Master On") );
	m_chkPNLCheckOff.SetBtnCursor(IDC_HAND_1);

	// Current Fire
	m_chkCurrentFire.SetFont( &m_fntBtn );
	m_chkCurrentFire.SetImageOrg( 10, 3 );
	m_chkCurrentFire.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkCurrentFire.EnableBallonToolTip();
	m_chkCurrentFire.SetToolTipText( _T("Master On") );
	m_chkCurrentFire.SetBtnCursor(IDC_HAND_1);
	m_chkCurrentFire.EnableWindow(FALSE);
	// Pre Fire
	m_chkPreFire.SetFont( &m_fntBtn );
	m_chkPreFire.SetImageOrg( 10, 3 );
	m_chkPreFire.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPreFire.EnableBallonToolTip();
	m_chkPreFire.SetToolTipText( _T("Master On") );
	m_chkPreFire.SetBtnCursor(IDC_HAND_1);
	m_chkPreFire.EnableWindow(FALSE);

	// post Fire
	m_chkPostFire.SetFont( &m_fntBtn );
	m_chkPostFire.SetImageOrg( 10, 3 );
	m_chkPostFire.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPostFire.EnableBallonToolTip();
	m_chkPostFire.SetToolTipText( _T("Master On") );
	m_chkPostFire.SetBtnCursor(IDC_HAND_1);
	m_chkPostFire.EnableWindow(FALSE);

	m_chkTestFire.SetFont( &m_fntBtn );
	m_chkTestFire.SetImageOrg( 10, 3 );
	m_chkTestFire.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkTestFire.EnableBallonToolTip();
	m_chkTestFire.SetToolTipText( _T("Test Fire") );
	m_chkTestFire.SetBtnCursor(IDC_HAND_1);

	m_chkAISol.SetFont( &m_fntBtn );
	m_chkAISol.SetImageOrg( 10, 3 );
	m_chkAISol.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAISol.EnableBallonToolTip();
	m_chkAISol.SetToolTipText( _T("AI Sol Type" ) );
	m_chkAISol.SetBtnCursor(IDC_HAND_1);

	m_chkAICom.SetFont( &m_fntBtn );
	m_chkAICom.SetImageOrg( 10, 3 );
	m_chkAICom.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAICom.EnableBallonToolTip();
	m_chkAICom.SetToolTipText( _T("AI Com Type") );
	m_chkAICom.SetBtnCursor(IDC_HAND_1);

	m_chkAIBoth.SetFont( &m_fntBtn );
	m_chkAIBoth.SetImageOrg( 10, 3 );
	m_chkAIBoth.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAIBoth.EnableBallonToolTip();
	m_chkAIBoth.SetToolTipText( _T("AI Both Type") );
	m_chkAIBoth.SetBtnCursor(IDC_HAND_1);

}

void CPaneAutoRunViewOPC::OnBnClickedButtonLossInput()
{
	CDlgOpcLossInput dlg;
	dlg.DoModal();
}


void CPaneAutoRunViewOPC::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
		ChangeDisplay();

	CFormView::OnTimer(nIDEvent);
}
void CPaneAutoRunViewOPC::ChangeDisplay()
{
	CString strTemp ;
#ifndef __NO_USE_OPC__	
	BOOL bVal1, bVal2;
	bVal1 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetConnection1();
	bVal2 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetConnection2();

	if(bVal1)
		m_stcConnect1.SetBackColor( GREEN_COLOR );
	else
		m_stcConnect1.SetBackColor( RED_COLOR );
	
	if(bVal2)
		m_stcConnect2.SetBackColor( GREEN_COLOR );
	else
		m_stcConnect2.SetBackColor( RED_COLOR );

	 strTemp = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strStatusCode;
	 int nCode = atoi((LPCTSTR)strTemp);
	
	 switch(nCode/1000)
	 {
	 case 1:
		 m_stcStatus.SetBackColor(RGB(0, 255, 0)); break;
	 case 2:
		 m_stcStatus.SetBackColor(RGB(255,255,0)); break;
	 case 3:
		 m_stcStatus.SetBackColor(RGB(61,188,250)); break;
	 case 4:
		 m_stcStatus.SetBackColor(RGB(255,128,255)); break;
	 case 5:
		 m_stcStatus.SetBackColor(RGB(255,0,0)); break;
	 case 6:
		 m_stcStatus.SetBackColor(RGB(192,192,192)); break;
	 }
	 strTemp = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strStatus;
	m_stcStatus.SetWindowText(strTemp);


#endif

	strTemp.Format(_T("%s"), gDProject.m_strUserID);
	m_stcUserName.SetWindowText(strTemp);
}
void CPaneAutoRunViewOPC::InitTimer()
{
	if(m_nTimer == -1)
		m_nTimer = SetTimer(1987, 500, NULL);
}
void CPaneAutoRunViewOPC::DestroyTimer()
{
	if(m_nTimer != -1)
	{
		KillTimer(m_nTimer);
		m_nTimer = -1;
	}
}

void CPaneAutoRunViewOPC::OnBnClickedButtonRmsOnAi()
{
	// TODO: Add your control notification handler code here
	if(m_chkRMSOnAI.GetCheck())
	{
		if(m_nRMSType != 0)
		{
			if(ErrMessage(_T("If you change RMS status to RMS ON(AI)"), MB_YESNO) == IDNO)
			{	
				if(m_nRMSType == 1)
				{
					m_chkRMSOnAI.SetCheck(FALSE);
					m_chkRMSOn.SetCheck(TRUE);
					m_chkRMSOff.SetCheck(FALSE);
				}
				else
				{
					m_chkRMSOnAI.SetCheck(FALSE);
					m_chkRMSOn.SetCheck(FALSE);
					m_chkRMSOff.SetCheck(TRUE);
				}
				GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
				m_stcBasketID.ShowWindow(SW_HIDE);
			}
			else
			{
				GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_SHOW);
				m_stcBasketID.ShowWindow(SW_SHOW);
			}

		}
		m_chkCurrentFire.EnableWindow(FALSE);
		m_chkPreFire.EnableWindow(FALSE);
		m_chkPostFire.EnableWindow(FALSE);
		m_chkRMSOn.SetCheck(FALSE);
		m_chkRMSOff.SetCheck(FALSE);
		m_nRMSType = 0;
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetRMSType(m_nRMSType);
#endif
		m_chkAIBoth.ShowWindow(SW_SHOW);
		m_chkAISol.ShowWindow(SW_SHOW);
		m_chkAICom.ShowWindow(SW_SHOW);
		m_btnSchedule.ShowWindow(SW_HIDE);
	}
	else
	{
		if(m_nRMSType == 0)
			m_chkRMSOnAI.SetCheck(TRUE);

		GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_SHOW);
		m_stcBasketID.ShowWindow(SW_SHOW);
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonRmsOn()
{
	// TODO: Add your control notification handler code here	
	if(m_chkRMSOn.GetCheck())
	{
		if(m_nRMSType != 1)
		{
			if(ErrMessage(_T("If you change RMS status to RMS ON"), MB_YESNO) == IDNO)
			{
				
				if(m_nRMSType == 0)
				{
					m_chkRMSOnAI.SetCheck(TRUE);
					m_chkRMSOn.SetCheck(FALSE);
					m_chkRMSOff.SetCheck(FALSE);
				}
				else
				{
					m_chkRMSOnAI.SetCheck(FALSE);
					m_chkRMSOn.SetCheck(FALSE);
					m_chkRMSOff.SetCheck(TRUE);
				}
				GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
				m_stcBasketID.ShowWindow(SW_HIDE);
			}
		}
		m_chkCurrentFire.EnableWindow(FALSE);
		m_chkPreFire.EnableWindow(FALSE);
		m_chkPostFire.EnableWindow(FALSE);
		m_chkRMSOnAI.SetCheck(FALSE);
		m_chkRMSOff.SetCheck(FALSE);
		m_nRMSType = 1;
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetRMSType(m_nRMSType);
#endif
		
		m_chkAIBoth.ShowWindow(SW_HIDE);
		m_chkAISol.ShowWindow(SW_HIDE);
		m_chkAICom.ShowWindow(SW_HIDE);
		m_btnSchedule.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
		m_stcBasketID.ShowWindow(SW_HIDE);
	}
	else
	{
		if(m_nRMSType == 1)
			m_chkRMSOn.SetCheck(TRUE);
		GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
		m_stcBasketID.ShowWindow(SW_HIDE);
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonRmsOff()
{
	// TODO: Add your control notification handler code here
	if(m_chkRMSOff.GetCheck())
	{
		if(m_nRMSType != 2)
		{
			if(ErrMessage(_T("If you change RMS status to RMS OFF"), MB_YESNO) == IDNO)
			{
				
				if(m_nRMSType == 0)
				{
					m_chkRMSOnAI.SetCheck(TRUE);
					m_chkRMSOn.SetCheck(FALSE);
					m_chkRMSOff.SetCheck(FALSE);
				}
				else
				{
					m_chkRMSOnAI.SetCheck(FALSE);
					m_chkRMSOn.SetCheck(TRUE);
					m_chkRMSOff.SetCheck(FALSE);
				}
			}
		}

		m_chkCurrentFire.EnableWindow(TRUE);
		m_chkPreFire.EnableWindow(TRUE);
		m_chkPostFire.EnableWindow(TRUE);
		m_chkRMSOnAI.SetCheck(FALSE);
		m_chkRMSOn.SetCheck(FALSE);
		m_nRMSType = 2;
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetRMSType(m_nRMSType);
#endif
		
		m_chkAIBoth.ShowWindow(SW_HIDE);
		m_chkAISol.ShowWindow(SW_HIDE);
		m_chkAICom.ShowWindow(SW_HIDE);
		m_btnSchedule.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
		m_stcBasketID.ShowWindow(SW_HIDE);
	}
	else
	{
		if(m_nRMSType == 2)
			m_chkRMSOff.SetCheck(TRUE);
		GetDlgItem(IDC_GROUP_BASKET_ID)->ShowWindow(SW_HIDE);
		m_stcBasketID.ShowWindow(SW_HIDE);
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonPanelCheckOn()
{
	// TODO: Add your control notification handler code here
	if(m_chkPNLCheckOn.GetCheck())
	{
		m_chkPNLCheckOff.SetCheck(FALSE);
		m_bPNLCheck = TRUE;
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetPNLCheck(m_bPNLCheck);
#endif
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonPanelCheckOff()
{
	// TODO: Add your control notification handler code here
	if(m_chkPNLCheckOff.GetCheck())
	{
		m_chkPNLCheckOn.SetCheck(FALSE);
		m_bPNLCheck = FALSE;
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetPNLCheck(m_bPNLCheck);
#endif
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonCurrentLot()
{
	// TODO: Add your control notification handler code here
	if(m_chkCurrentFire.GetCheck())
	{
		/*if(gLotInfo.nStatus[m_nSelectIndex] == STATUS_END)
		{
			m_chkCurrentFire.SetCheck(FALSE);
			return;
		}
		if(m_nSelectIndex > 0 && gLotInfo.nStatus[m_nSelectIndex-1] == STATUS_WAIT)
		{
			m_chkCurrentFire.SetCheck(FALSE);
			return;
		}
		*/
		//count compare
		m_chkPreFire.SetCheck(FALSE);
		m_chkPostFire.SetCheck(FALSE);
		gLotInfo.nFireType[m_nSelectIndex] = FIRE_LOT;
		InsertList();
	}

}


void CPaneAutoRunViewOPC::OnBnClickedButtonPre()
{
	// TODO: Add your control notification handler code here
	if(m_chkPreFire.GetCheck())
	{
		/*if(gLotInfo.nStatus[m_nSelectIndex] == STATUS_END)
		{
			m_chkPreFire.SetCheck(FALSE);
			return;
		}
		if(m_nSelectIndex > 0 && gLotInfo.nStatus[m_nSelectIndex-1] == STATUS_WAIT)
		{
			m_chkPreFire.SetCheck(FALSE);
			return;
		}
		*/
		m_chkCurrentFire.SetCheck(FALSE);
		m_chkPostFire.SetCheck(FALSE);
		gLotInfo.nFireType[m_nSelectIndex] = FIRE_PRE;
		InsertList();
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonRe()
{
	// TODO: Add your control notification handler code here
	if(m_chkPostFire.GetCheck())
	{
		/*if(gLotInfo.nStatus[m_nSelectIndex] == STATUS_END)
		{
			m_chkPostFire.SetCheck(FALSE);
			return;
		}
		if(m_nSelectIndex > 0 && gLotInfo.nStatus[m_nSelectIndex-1] == STATUS_WAIT)
		{
			m_chkPostFire.SetCheck(FALSE);
			return;
		}
		*/
		m_chkPreFire.SetCheck(FALSE);
		m_chkCurrentFire.SetCheck(FALSE);
		gLotInfo.nFireType[m_nSelectIndex] = FIRE_RE;
		InsertList();
	}
}


void CPaneAutoRunViewOPC::OnDestroy()
{
	CFormView::OnDestroy();
	DestroyTimer();
	// TODO: Add your message handler code here
}
void CPaneAutoRunViewOPC::InsertList(BOOL bClear)
{
	CString strData, strStatus, strProject, strBasketID, strLotID, strInput, strFired, strRemain, strSection, strPanel, strNG;
	CString strTemp;
	int nCount = 0, nIndex;
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	
	m_listProject.DeleteAllItems();
	int nLeftNG = 0, nRightNG = 0, nSumInput = 0;
	int nLeftID, nRightID;
	nLeftID = IDC_STATIC_NG_LEFT1;
	nRightID = IDC_STATIC_NG_RIGHT1;
	 
	int nAddList = 0;
	for(int i = 0; i< gLotInfo.nLastIndex ; i++)
	{
		lvItem.iItem = i;
		lvItem.iSubItem = 0;
		strData = _T("");
		lvItem.pszText = (LPSTR)(LPCSTR)strData;
		m_listProject.InsertItem(&lvItem);

		if(strcmp(gLotInfo.szPrj[i], "" ) == 0 ||strcmp(gLotInfo.szPrj[i], " " ) == 0 )
		{
			m_listProject.SetItemText(nAddList, 0, _T("--"));
			m_listProject.SetItemText(nAddList, 1, _T("--"));
			m_listProject.SetItemText(nAddList, 2, _T("--"));
			m_listProject.SetItemText(nAddList, 3, _T("--"));
			m_listProject.SetItemText(nAddList, 4, _T("--"));
			m_listProject.SetItemText(nAddList, 5, _T("--"));
			m_listProject.SetItemText(nAddList, 6, _T("--"));
			m_listProject.SetItemText(nAddList, 7, _T("--"));
			m_listProject.SetItemText(nAddList, 8, _T("--"));
			m_listProject.SetItemText(nAddList, 9, _T("--"));
			nAddList++;
			continue;
		}
		
	
		if(gLotInfo.nStatus[i] == STATUS_WAIT)
			strStatus.Format(_T("Wait"));
		else if(gLotInfo.nStatus[i] == STATUS_PROGRESS)
			strStatus.Format(_T("Progress"));
		else if(gLotInfo.nStatus[i] == STATUS_END)
			strStatus.Format(_T("End"));

		strProject.Format(_T("%s"), gLotInfo.szPrj[i]);
		nIndex = strProject.ReverseFind('\\');
		strProject = strProject.Mid(nIndex+1);
		nIndex = strProject.ReverseFind('.');
		strProject = strProject.Left(nIndex);

		strBasketID.Format(_T("%s"), gLotInfo.szBasketID[i]);
		strLotID.Format(_T("%s"), gLotInfo.szLotID[i]);
		strInput.Format(_T("%d"), gLotInfo.nLotCount[i]);
		strFired.Format(_T("%d"), gLotInfo.nFiredLotCount[i]);
		int nBeforeNG = 0;
		if(i %2 == 1)
			nBeforeNG = gLotInfo.nNGLotCount[i -1];
		strRemain.Format(_T("%d"),gLotInfo.nLotCount[i] - ( gLotInfo.nFiredLotCount[i] + gLotInfo.nNGLotCount[i] + nBeforeNG));
		strNG.Format(_T("%d"), gLotInfo.nNGLotCount[i]);
		if(gLotInfo.nFireType[i] == FIRE_LOT)
			strSection.Format(_T("LotFire"));
		else if(gLotInfo.nFireType[i] == FIRE_PRE)
			strSection.Format(_T("PreFire"));
		else if(gLotInfo.nFireType[i] == FIRE_RE)
			strSection.Format(_T("ReFire"));

		if(gLotInfo.nComSol[i] == 2)
		{
			strPanel.Format(_T("Both_COMP"));
		}
		else if(gLotInfo.nComSol[i] == 3)
		{
			strPanel.Format(_T("Both_SOLD"));
		}
		else
		{
			if(gLotInfo.nComSol[i] == 0)
				strPanel.Format(_T("COMP"));
			else
				strPanel.Format(_T("SOLD"));
		}

		m_listProject.SetItemText(nAddList, 0, strStatus);
		m_listProject.SetItemText(nAddList, 1, strProject);
		m_listProject.SetItemText(nAddList, 2, strBasketID);
		m_listProject.SetItemText(nAddList, 3, strLotID);
		m_listProject.SetItemText(nAddList, 4, strInput);
		m_listProject.SetItemText(nAddList, 5, strFired);
		m_listProject.SetItemText(nAddList, 6, strNG);
		m_listProject.SetItemText(nAddList, 7, strRemain);
		m_listProject.SetItemText(nAddList, 8, strSection);
		m_listProject.SetItemText(nAddList, 9, strPanel);

		if(gLotInfo.nNGLotCount[i] > 0)
		{
			if(i%2 == 0)
			{
				strTemp.Format(_T("%s : %d"), strLotID, gLotInfo.nNGLotCount[i]);
				GetDlgItem(nLeftID+nLeftNG)->SetWindowText(strTemp);
				nLeftNG++;
			}
			else
			{
				strTemp.Format(_T("%s : %d"), strLotID, gLotInfo.nNGLotCount[i]);
				GetDlgItem(nRightID+nRightNG)->SetWindowText(strTemp);
				nRightNG++;
			}
			
		}
		nSumInput += gLotInfo.nLotCount[i];
		nAddList++;
	}

	if(bClear)
	{
		int nLeftNG = nRightNG = 0;
	
		for(int i = 0 ; i< 5; i++)
		{
			strTemp.Format(_T(" "));
			GetDlgItem(nLeftID+i)->SetWindowText(strTemp);

			strTemp.Format(_T(" "));
			GetDlgItem(nRightID+i)->SetWindowText(strTemp);
		}
	}

	int nMarking = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLotMarkStartNo;
	strData.Format(_T("%d (%d) PNL"), nSumInput, nMarking);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_btnLotInput.SetWindowText( (LPCTSTR)strData );
}



void CPaneAutoRunViewOPC::OnClickListProject(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: Add your control notification handler code here
	CRect rectCell;
	int nIndex = m_listProject.GetSelectionMark();
	if(nIndex == -1 || pNMItemActivate->iItem == -1)
	{
		InsertList();
		m_editwnd.ShowWindow(SW_HIDE);
		return;
	}
	
	m_nSelectIndex = nIndex;

	if(pNMItemActivate->iSubItem == 4)
	{
		CString str=m_listProject.GetItemText(pNMItemActivate->iItem, pNMItemActivate->iSubItem);
		if(strcmp(str, _T("--")) == 0)
			return;
		m_editwnd.ShowWindow(SW_SHOW);
		m_editwnd.SetWindowText(str);
		m_listProject.GetSubItemRect(pNMItemActivate->iItem, pNMItemActivate->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.SetWindowPos(NULL, rectCell.left, rectCell.top, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top + 2, SWP_NOZORDER|SWP_SHOWWINDOW);
		m_editwnd.SetFocus();
		m_editwnd.SetSel(0, -1);
	}
	else
	{
		InsertList();
		m_editwnd.ShowWindow(SW_HIDE);
	}
	switch(gLotInfo.nFireType[nIndex])
	{
	case FIRE_LOT : m_chkCurrentFire.SetCheck(TRUE); OnBnClickedButtonCurrentLot(); break; 
	case FIRE_RE :	m_chkPostFire.SetCheck(TRUE);OnBnClickedButtonRe(); break; 
	case FIRE_PRE : m_chkPreFire.SetCheck(TRUE);OnBnClickedButtonPre(); break;
	}
	*pResult = 0;
}

void CPaneAutoRunViewOPC::EnableControl(BOOL bEnable)
{
	m_btnSchedule.EnableWindow(bEnable);
	m_btnLoss.EnableWindow(bEnable);
	m_chkRMSOnAI.EnableWindow(bEnable);
	m_chkRMSOn.EnableWindow(bEnable);
	m_chkRMSOff.EnableWindow(bEnable);
	m_chkPNLCheckOn.EnableWindow(bEnable);
	m_chkPNLCheckOff.EnableWindow(bEnable);
	m_chkCurrentFire.EnableWindow(bEnable);
	m_chkPreFire.EnableWindow(bEnable);
	m_chkPostFire.EnableWindow(bEnable);
	
}

void CPaneAutoRunViewOPC::OnBnClickedButtonSchudle()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if((strcmp(gLotInfo.szPrj[0],"" ) == 0|| strcmp(gLotInfo.szPrj[0]," " ) == 0 )&&
			(strcmp(gLotInfo.szLotID[0],"" ) == 0|| strcmp(gLotInfo.szLotID[0]," " ) == 0 ))
		{
			memset(gLotInfo.szLotID, 0 , sizeof(gLotInfo.szLotID));
			strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
			strcpy_s(gLotInfo.szPrj[0], gDProject.m_szProjectName); 
		}
	}
	CDlgScheduleInfo dlg;
	dlg.SetCurrentFiredCount(gLotInfo.nTotalFireCount);
	if( IDOK != dlg.DoModal() )
		return;

	gLotInfo.nLastIndex = dlg.m_nLastIndex;

	strcpy_s(gLotInfo.szLotID[0], dlg.m_strLotInfo);
	strcpy_s(gLotInfo.szLotID[1], dlg.m_strLotInfo2);
	strcpy_s(gLotInfo.szLotID[2], dlg.m_strLotInfo3);
	strcpy_s(gLotInfo.szLotID[3], dlg.m_strLotInfo4);
	strcpy_s(gLotInfo.szLotID[4], dlg.m_strLotInfo5);
	strcpy_s(gLotInfo.szLotID[5], dlg.m_strLotInfo6);
	strcpy_s(gLotInfo.szLotID[6], dlg.m_strLotInfo7);
	strcpy_s(gLotInfo.szLotID[7], dlg.m_strLotInfo8);
	strcpy_s(gLotInfo.szLotID[8], dlg.m_strLotInfo9);
	strcpy_s(gLotInfo.szLotID[9], dlg.m_strLotInfo10);

	gLotInfo.nLotCount[0] = dlg.m_nNo;
	gLotInfo.nLotCount[1] = dlg.m_nNo2;
	gLotInfo.nLotCount[2] = dlg.m_nNo3;
	gLotInfo.nLotCount[3] = dlg.m_nNo4;
	gLotInfo.nLotCount[4] = dlg.m_nNo5;
	gLotInfo.nLotCount[5] = dlg.m_nNo6;
	gLotInfo.nLotCount[6] = dlg.m_nNo7;
	gLotInfo.nLotCount[7] = dlg.m_nNo8;
	gLotInfo.nLotCount[8] = dlg.m_nNo9;
	gLotInfo.nLotCount[9] = dlg.m_nNo10;

	gLotInfo.bMESOK[0] = dlg.m_bMes;
	gLotInfo.bMESOK[1] = dlg.m_bMes2;
	gLotInfo.bMESOK[2] = dlg.m_bMes3;
	gLotInfo.bMESOK[3] = dlg.m_bMes4;
	gLotInfo.bMESOK[4] = dlg.m_bMes5;
	gLotInfo.bMESOK[5] = dlg.m_bMes6;
	gLotInfo.bMESOK[6] = dlg.m_bMes7;
	gLotInfo.bMESOK[7] = dlg.m_bMes8;
	gLotInfo.bMESOK[8] = dlg.m_bMes9;
	gLotInfo.bMESOK[9] = dlg.m_bMes10;

	gLotInfo.nComSol[0] = dlg.m_nComSol;
	gLotInfo.nComSol[1] = dlg.m_nComSol2;
	gLotInfo.nComSol[2] = dlg.m_nComSol3;
	gLotInfo.nComSol[3] = dlg.m_nComSol4;
	gLotInfo.nComSol[4] = dlg.m_nComSol5;
	gLotInfo.nComSol[5] = dlg.m_nComSol6;
	gLotInfo.nComSol[6] = dlg.m_nComSol7;
	gLotInfo.nComSol[7] = dlg.m_nComSol8;
	gLotInfo.nComSol[8] = dlg.m_nComSol9;
	gLotInfo.nComSol[9] = dlg.m_nComSol10;

	gLotInfo.bUseMES = dlg.m_bUseMES;

	strcpy_s(gLotInfo.szFilmNo[0], dlg.m_strFilmNo);
	strcpy_s(gLotInfo.szFilmNo[1], dlg.m_strFilmNo2);
	strcpy_s(gLotInfo.szFilmNo[2], dlg.m_strFilmNo3);
	strcpy_s(gLotInfo.szFilmNo[3], dlg.m_strFilmNo4);
	strcpy_s(gLotInfo.szFilmNo[4], dlg.m_strFilmNo5);
	strcpy_s(gLotInfo.szFilmNo[5], dlg.m_strFilmNo6);
	strcpy_s(gLotInfo.szFilmNo[6], dlg.m_strFilmNo7);
	strcpy_s(gLotInfo.szFilmNo[7], dlg.m_strFilmNo8);
	strcpy_s(gLotInfo.szFilmNo[8], dlg.m_strFilmNo9);
	strcpy_s(gLotInfo.szFilmNo[9], dlg.m_strFilmNo10);

	strcpy_s(gLotInfo.szProcessCode[0], dlg.m_strProcessCode);
	strcpy_s(gLotInfo.szProcessCode[1], dlg.m_strProcessCode2);
	strcpy_s(gLotInfo.szProcessCode[2], dlg.m_strProcessCode3);
	strcpy_s(gLotInfo.szProcessCode[3], dlg.m_strProcessCode4);
	strcpy_s(gLotInfo.szProcessCode[4], dlg.m_strProcessCode5);
	strcpy_s(gLotInfo.szProcessCode[5], dlg.m_strProcessCode6);
	strcpy_s(gLotInfo.szProcessCode[6], dlg.m_strProcessCode7);
	strcpy_s(gLotInfo.szProcessCode[7], dlg.m_strProcessCode8);
	strcpy_s(gLotInfo.szProcessCode[8], dlg.m_strProcessCode9);
	strcpy_s(gLotInfo.szProcessCode[9], dlg.m_strProcessCode10);

	strcpy_s(gLotInfo.szPrj[0], dlg.m_strPrj1);
	strcpy_s(gLotInfo.szPrj[1], dlg.m_strPrj2);
	strcpy_s(gLotInfo.szPrj[2], dlg.m_strPrj3);
	strcpy_s(gLotInfo.szPrj[3], dlg.m_strPrj4);
	strcpy_s(gLotInfo.szPrj[4], dlg.m_strPrj5);
	strcpy_s(gLotInfo.szPrj[5], dlg.m_strPrj6);
	strcpy_s(gLotInfo.szPrj[6], dlg.m_strPrj7);
	strcpy_s(gLotInfo.szPrj[7], dlg.m_strPrj8);
	strcpy_s(gLotInfo.szPrj[8], dlg.m_strPrj9);
	strcpy_s(gLotInfo.szPrj[9], dlg.m_strPrj10);

	gLotInfo.nFireType[0] = dlg.m_nFireType;
	gLotInfo.nFireType[1] = dlg.m_nFireType2;
	gLotInfo.nFireType[2] = dlg.m_nFireType3;
	gLotInfo.nFireType[3] = dlg.m_nFireType4;
	gLotInfo.nFireType[4] = dlg.m_nFireType5;
	gLotInfo.nFireType[5] = dlg.m_nFireType6;
	gLotInfo.nFireType[6] = dlg.m_nFireType7;
	gLotInfo.nFireType[7] = dlg.m_nFireType8;
	gLotInfo.nFireType[8] = dlg.m_nFireType9;
	gLotInfo.nFireType[9] = dlg.m_nFireType10;

	CString strMsg, strErr, strTemp;
	int nLen;
	int nSumInput = 0;
	for(int k = 0; k< gLotInfo.nLastIndex; k++)
	{
		nLen = 	strlen(gLotInfo.szLotID[k]);
		if(nLen <= 0)
			continue;

		strTemp.Format(_T("#%d : %s\t %d\t %s|"), k+1, gLotInfo.szLotID[k], gLotInfo.nLotCount[k], gLotInfo.szPrj[k]);
		strErr += strTemp;
		nSumInput += gLotInfo.nLotCount[k];
	}
	strMsg.Format(_T("Lot ���� �Է�"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );	

	CString strData;
	int nMarking = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLotMarkStartNo;
	strData.Format(_T("%d (%d) PNL"), nSumInput, nMarking);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_btnLotInput.SetWindowText( (LPCTSTR)strData );

	InsertList();		
}
void CPaneAutoRunViewOPC::SetStartDirectionInfo(BOOL bReverse)
{
	m_bStartReverseInfo = bReverse;
}


BOOL CPaneAutoRunViewOPC::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	return TRUE;
}


void CPaneAutoRunViewOPC::OnBnClickedButtonTestFire()
{
	CString strMode = _T("");
	
	if(m_chkTestFire.GetCheck())
	{
		strMode.Format(_T("H0004"));
		m_chkTestFire.SetWindowText(_T("Test Fire On"));
	}
	else
	{
		strMode.Format(_T("clear"));
		m_chkTestFire.SetWindowText(_T("Test Fire Off"));
	}
#ifndef __NO_USE_OPC__
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError = _T("");
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossPass = _T("");
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossResult = _T("");
	CString strLossError = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	
	CTime EventTime = CTime::GetCurrentTime();
	CString strTime, strLotID, strLotID2, strPrj1, strPrj2;
	strTime.Format("%04d%02d%02d%02d%02d%02d",
		EventTime.GetYear(), EventTime.GetMonth(), EventTime.GetDay(),
		EventTime.GetHour(), EventTime.GetMinute(), EventTime.GetSecond());
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->GetCurrentLotID(strLotID, strLotID2, strPrj1, strPrj2);
	CString strUserID = gDProject.m_strUserID;
//	CString strComment;
//	GetDlgItem(IDC_EDT_COMMENT)->GetWindowText(strComment);
	
	CString strOPC = _T("");
	strOPC.Format("%s;%s;%s;%s;%s;%s", "000", strMode, strTime, strUserID , "", strLotID);
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 9, reinterpret_cast<LPARAM>(&strOPC));	//643 ����->TC �� �������� ���� : L_000_000000_01
/*
	int nCount = 0;
	CString strGetLoss = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	
	CTime StartTime = CTime::GetCurrentTime();
	CTime EndTime;
	
	while(strcmp(strLossError, strGetLoss) == 0)
	{
		EndTime = CTime::GetCurrentTime();
		Sleep(1);
		
		if(EndTime - StartTime > 5)
		{
			ErrMessage(_T("OPC TimeOut"));
			break;
		}
		strGetLoss = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	}
	CString strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossPass;
	
#ifdef __TEST__
	strPass.Format(_T("pass"));
#endif
	strPass.MakeUpper();

	if(strcmp(strPass, "PASS") == 0)
	{
		ErrMessage(_T("���� �ڵ� ���� �Ϸ�"));
	}
	else
	{
		ErrMessage(_T("���� �ڵ� ���� ����"));
	}

	GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
	GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(TRUE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(TRUE);
	
	GetDlgItem(IDC_EDT_LOSS_RESULT)->SetWindowText(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossResult);
	*/
#endif
}


void CPaneAutoRunViewOPC::OnBnClickedButtonCom()
{
// TODO: Add your control notification handler code here
	if(m_chkAICom.GetCheck())
	{
		if(m_nAIType != 0)
		{
			if(ErrMessage(_T("If you change panel info to COMP"), MB_YESNO) == IDNO)
			{
				if(m_nAIType == 1)
				{
					m_chkAICom.SetCheck(FALSE);
					m_chkAISol.SetCheck(TRUE);
					m_chkAIBoth.SetCheck(FALSE);
				}
				else
				{
					m_chkAICom.SetCheck(FALSE);
					m_chkAISol.SetCheck(FALSE);
					m_chkAIBoth.SetCheck(TRUE);
				}
			}
		}

		m_nAIType = 0;
		m_chkAIBoth.SetCheck(FALSE);
		m_chkAISol.SetCheck(FALSE);
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetAIType(m_nAIType);
#endif
	}
	else
	{
		if(m_nAIType == 0)
			m_chkAICom.SetCheck(TRUE);
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonSol()
{
	if(m_chkAISol.GetCheck())
	{
		if(m_nAIType != 1)
		{
			if(ErrMessage(_T("If you change panel info to SOLD"), MB_YESNO) == IDNO)
			{
				if(m_nAIType == 0)
				{
					m_chkAICom.SetCheck(TRUE);
					m_chkAISol.SetCheck(FALSE);
					m_chkAIBoth.SetCheck(FALSE);
				}
				else
				{
					m_chkAICom.SetCheck(FALSE);
					m_chkAISol.SetCheck(FALSE);
					m_chkAIBoth.SetCheck(TRUE);
				}
			}
		}

		m_nAIType = 1;
		m_chkAIBoth.SetCheck(FALSE);
		m_chkAICom.SetCheck(FALSE);
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetAIType(m_nAIType);
#endif
	}
	else
	{
		if(m_nAIType == 1)
			m_chkAISol.SetCheck(TRUE);
	}
}


void CPaneAutoRunViewOPC::OnBnClickedButtonBoth()
{
	if(m_chkAIBoth.GetCheck())
	{
		if(m_nAIType != 2)
		{
			if(ErrMessage(_T("If you change panel info to COMP and SOLD"), MB_YESNO) == IDNO)
			{
				if(m_nAIType == 0)
				{
					m_chkAICom.SetCheck(TRUE);
					m_chkAISol.SetCheck(FALSE);
					m_chkAIBoth.SetCheck(FALSE);
				}
				else
				{
					m_chkAICom.SetCheck(FALSE);
					m_chkAISol.SetCheck(TRUE);
					m_chkAIBoth.SetCheck(FALSE);
				}
			}
		}
		m_nAIType = 2;
		m_chkAISol.SetCheck(FALSE);
		m_chkAICom.SetCheck(FALSE);
#ifndef __NO_USE_OPC__
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->SetAIType(m_nAIType);
#endif
	}
	else
	{
		if(m_nAIType == 2)
			m_chkAIBoth.SetCheck(TRUE);
	}
}


BOOL CPaneAutoRunViewOPC::PreTranslateMessage(MSG* pMsg)
{

	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Scal_Result) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}

	int nID = ::GetDlgCtrlID(pMsg->hwnd);
	if(nID == ::GetDlgCtrlID(m_editwnd.m_hWnd))
	{
		CString strCount = _T("");
		m_editwnd.GetWindowText(strCount);
		if(gLotInfo.nComSol[m_nSelectIndex] == 2)
		{
			gLotInfo.nLotCount[m_nSelectIndex] = atoi(strCount);
			gLotInfo.nLotCount[m_nSelectIndex + 1] = atoi(strCount);
		}
		else if(gLotInfo.nComSol[m_nSelectIndex] == 3)
		{
			gLotInfo.nLotCount[m_nSelectIndex] = atoi(strCount);
			gLotInfo.nLotCount[m_nSelectIndex - 1] = atoi(strCount);
		}
		else
		{
			gLotInfo.nLotCount[m_nSelectIndex] = atoi(strCount);
		}
		
		if(pMsg->wParam == VK_RETURN)
		{
			m_editwnd.ShowWindow(SW_HIDE);
			InsertList();
		}
		if(pMsg->wParam == VK_ESCAPE)
		{
			CString str=m_listProject.GetItemText(m_nSelectIndex, 4);
			if(gLotInfo.nComSol[m_nSelectIndex] == 2)
			{
				gLotInfo.nLotCount[m_nSelectIndex] = atoi(str);
				gLotInfo.nLotCount[m_nSelectIndex + 1] = atoi(str);
			}
			else if(gLotInfo.nComSol[m_nSelectIndex] == 3)
			{
				gLotInfo.nLotCount[m_nSelectIndex] = atoi(str);
				gLotInfo.nLotCount[m_nSelectIndex - 1] = atoi(str);
			}
			else
			{
				gLotInfo.nLotCount[m_nSelectIndex] = atoi(str);
			}
			m_editwnd.ShowWindow(SW_HIDE);
			InsertList();
		}
	}
	
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneAutoRunViewOPC::OnEnUpdateEditBox()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.

	// TODO:  Add your control notification handler code here
	CString strCount = _T("");
	m_editwnd.GetWindowText(strCount);
	gLotInfo.nLotCount[m_nSelectIndex] = atoi(strCount);
	InsertList();
}
