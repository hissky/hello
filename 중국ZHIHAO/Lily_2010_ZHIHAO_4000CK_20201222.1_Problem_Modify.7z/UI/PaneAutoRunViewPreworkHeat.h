#if !defined(AFX_PANEAUTORUNVIEWPREWORKHEAT_H__AEDCB62F_C0C4_4F6C_A968_2D94DF8EE710__INCLUDED_)
#define AFX_PANEAUTORUNVIEWPREWORKHEAT_H__AEDCB62F_C0C4_4F6C_A968_2D94DF8EE710__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewPreworkHeat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkHeat form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
class CPaneAutoRunViewPreworkHeat : public CFormView
{
protected:
	CPaneAutoRunViewPreworkHeat();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewPreworkHeat)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewPreworkHeat)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_PREWORK_PREHEAT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;

	BOOL m_bPreheat;
// Operations
public:
	void ActiveStaticForKeyboardError();
	void ChangeDisplay();

	void InitStatic();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewPreworkHeat)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewPreworkHeat();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewPreworkHeat)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWPREWORKHEAT_H__AEDCB62F_C0C4_4F6C_A968_2D94DF8EE710__INCLUDED_)
