#if !defined(AFX_PANEMANUALCONTROLSCANNERCALIBRATION_H__BF743DC6_800B_4B88_A26A_AFC28563F041__INCLUDED_)
#define AFX_PANEMANUALCONTROLSCANNERCALIBRATION_H__BF743DC6_800B_4B88_A26A_AFC28563F041__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlScannerCalibration.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibration form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UeasyButton.h"
#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\device\CalibrationPath.h"
#include "..\device\hvisionomi.h"
#include "..\Model\ToolcodeList.h"
#include "..\device\alAGC.h"
#include "..\device\CorrectTime.h"
#include "MODEL\DPoint.h"	// Added by ClassView


class CPaneManualControlScannerCalibration;
struct AUTOCALTHREADPARAM
{
	CPaneManualControlScannerCalibration*	pParent;
	HANDLE									pHandle[3];
};

class CPaneManualControlScannerCalibration : public CFormView
{
protected:
	CPaneManualControlScannerCalibration();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlScannerCalibration)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlScannerCalibration)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_SCANNER_CAL };
	CComboBox	m_cmbUseVision;
	CColorEdit	m_edtContrast;
	CColorEdit	m_edtBrightness;
	CColorEdit	m_edtRing;
	CColorEdit	m_edtCoaxial;
//	CColorEdit	m_edtRing2;
//	CColorEdit	m_edtCoaxial2;
	CColorEdit	m_edtSize;
	CColorEdit	m_edtAngle;
	CColorEdit	m_edtAspectRatio;
	CColorEdit	m_edtModelOrientation;
	CColorEdit	m_edtModelSize;
	CColorEdit	m_edtManualYPos;
	CColorEdit	m_edtManualXPos;
	CColorEdit	m_edtGridXNo;
	CColorEdit	m_edtGridYNo;
	CColorEdit	m_edtGridGap;
	CColorEdit	m_edtManual2ndThickness;
	CColorEdit	m_edtManual1stThickness;
	CColorEdit	m_edtAutoYPos;
	CColorEdit	m_edtAutoXPos;
	CColorEdit	m_edtAuto1stThickness;
	CColorEdit	m_edtAuto2ndThickness;
	CColorEdit	m_edtVisionZOffset;
	CColorEdit	m_edtPath;
	CColorEdit	m_edtShotNo;
	CColorEdit	m_edtDuty;
	CColorEdit	m_edtAOMDelay;
	CColorEdit	m_edtAOMDuty;
	UEasyButtonEx	m_chkInspArea;
	UEasyButtonEx	m_chkSkipCheckBoard;
	CComboBox	m_cmbManualHead;
	CComboBox	m_cmbManualDivision;
	CComboBox	m_cmbAutoHead;
	CComboBox	m_cmbAutoDivision;
	CListBox	m_lboxResult;
	UEasyButtonEx	m_btnChangeBoard;
	UEasyButtonEx	m_btnCalStop;
	UEasyButtonEx	m_btnCalStart;
	UEasyButtonEx	m_btnCalStartAuto;
	UEasyButtonEx	m_btnVisionOffsetVerify;
	UEasyButtonEx	m_btnVisionOffsetVerifyNext;
	UEasyButtonEx	m_btnApplyBeamPath;
	UEasyButton		m_btnLive;
	UEasyButtonEx	m_btnTrain;
	UEasyButtonEx	m_btnTest;
	UEasyButtonEx   m_btnJobFile;
	UEasyButtonEx	m_btnTrigger;
	UEasyButtonEx	m_btnTriggerAgc;
	UEasyButtonEx	m_btnShowDialog;
	UEasyButtonEx	m_btnLaserCalibration;
	UEasyButtonEx	m_btnApplyLaserCalibration;
	CColorStatic	m_stcVisionResult;
	int		m_nPolarity;
	CComboBox	m_cmbTool;
	CSliderCtrl     m_SliderCoaxial;
	CSliderCtrl     m_SliderRing;
	//}}AFX_DATA

// Attributes
public:
	BOOL			m_bIsLive;
	CString			m_strPath;
	double			m_dMaxOffsetMasterX;
	double			m_dMaxOffsetMasterY;
	double			m_dMaxOffsetSlaveX;
	double			m_dMaxOffsetSlaveY;
	double			m_dMaxOffsetMasterR;
	double			m_dMaxOffsetSlaveR;
	int m_nTimerID;
	BOOL			m_bGetHeadOffset;
	int				m_nUserLevel;
	int				m_nRemote;
// Attributes
protected:
	SVISIONINFO		m_sVisionInfo;
	CFont			m_fntBtn;
	CFont			m_fntBtn3;
	CFont			m_fntEdit;
	CFont			m_fntEdit2;
	CFont			m_fntStatic;
	CFont			m_fntStatic2;
	CFont			m_fntListBox;
	CFont			m_fntCombo;
	CFont			m_fntBtn2;

	int				m_nCoaxial[4];
	int				m_nRing[4];
	double			m_dContrast[4];
	double			m_dBrightness[4];


// Operations
public:
	void ChangeFindCamera(emHEAD emHead);
	BOOL CreateTableCompenFile(FILE* fp, FILE* fpTable, emHEAD emHead);
	void GetTableMovePosForTableCompen(double& dX, double& dY, int nXIndex, int nYIndex, int nSubXIndex, int nSubYIndex, emHEAD emHead);
	int  GetCAmNumInfo(BOOL& bUseLowCam, emHEAD emHead);
	BOOL GetOffsetFromVisionData(double dMoveX, double dMoveY, int nCountX, int nCountY, HANDLE* pHandle, BOOL bUseLowCam, emHEAD em1st, emHEAD em2nd, bool bSave, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2);
	void GetTableMovePosForSCal(double& dX, double& dY, int nXIndex, int nYIndex, emHEAD emHead);
	int GetOffsetFromVisionData(int nXIndex, int nYIndex, emHEAD emHead, HANDLE* pHandle, int nCam, bool bSave, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1);
	BOOL DrillStartCmd(SUBTOOLDATA ToolData);
	BOOL WaitOneFireProcess(HANDLE* pHandle);
	BOOL ReaseFileAndMem(CFile* pFileOri, CFile* pFileResult, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2);
	void NotifyError(int nAlarmNo, BOOL bDisplayErr = TRUE, CString strMsg = _T(""), BOOL bWindowMsg = TRUE);

public:
	void HeadChangeVerify();
	CDPoint GetNextStepIndex(int nStepNo);
	void SaveSCalResult(BOOL bApplyed);
	void SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
						int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
						int ndiff, int nJobType);
	BOOL InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave);
	void GetLaserParam(SUBTOOLDATA& subToolResult);
	BOOL DownloadASC();
	void ChangeLaserParam(int nIndex);
	void SetToolComboBox();
	BOOL m_bDryRunCheck;
	void SetAuthorityByLevel(int nLevel);
	void			ChangeControl(BOOL bUse);
	void			SetControlToData();
	void			SetProcessScannerCal(SPROCESSSCANNERCAL sProcessScannerCal);
	void			GetProcessScannerCal(SPROCESSSCANNERCAL* pProcessScannerCal);
	void			DispProcessScannerCal();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitListBoxControl();
	void			InitComboControl();
	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			OnMoveVisionView();
	void			SetValue(int nNumber);
	void			SetVisionInfo(void);
	void			SetAutoProcessMode(void);
	void			SetAutoCalibration();
	double			GetCalStartY(void);
	double			GetCalStartX(void);
	double			GetCalThick(void);
	double			GetCalThick2nd(void);
	double			GetPulseWidth(void);
	int				GetDivision(void);
	int				GetSelectedHead();
	int				GetMaskNo();
	BOOL			GetAutoProcessMode();
	void			EnableCalibrationWindow(BOOL bIsEnable);
	void			WriteCalibrationStopEvent(BOOL bFinish = FALSE);
	void			EnableAutoCalibrationResource(BOOL bEnable = TRUE);
	void			MakeThreadClear();
	void			CalculateAutoStartPosition(void);
	BOOL			ChangeMask(void);
	BOOL			CheckMotorPositionValidity();
	BOOL			IsOutOfAxisValidity(int nAxis, double dVal);
	void			CameraChange(int nCam);
	void			ApplyVisionParam(int nCam);

	int				GetUseTool();

	BOOL			CalibrationStart();

	void			WaitingThreadEnd();

	void			MessageLoop();
	void			InitSlideControl();

	CCalibrationPath* GetMasterPath()	{return &m_CalMasterPath;};
	CCalibrationPath* GetSlavePath()	{return &m_CalSlavePath;};

	void			ResetLive();
	BOOL			GetIsLive()		{ return m_bIsLive; }

	SPROCESSSCANNERCAL m_sProcessScannerCal;

	BOOL	m_bAutoCalStop;
	BOOL	m_bAutoPause;
	
	int		m_nCountAuto;
	int		m_nAutoProcessRepeat;
	BOOL	m_bIsAutoProcessMode;
	BOOL	m_bAutoCalibration;
	BOOL	m_bIsSkipBoardCheck;
	BOOL	m_bIsSuction;
	double	m_dCalculateStartXAuto;
	double	m_dCalculateStartYAuto;
	double	m_dOffsetStartXAuto;
	double	m_dOffsetStartYAuto;
	BOOL	m_bRestart;
	int		m_nGridMode;
	int		m_nVerifyPosIndex;
	BOOL	m_bLastPosSCalVerify;
	double	m_dFoundSize;
	CCalibrationPath m_CalMasterPath;
	CCalibrationPath m_CalSlavePath;
	CalAGC m_calAGCMaster;
	CalAGC m_calAGCSlave;
	CWinThread*			m_pThread;
	static volatile AUTOCALTHREADPARAM	m_ThreadParam;

	BOOL	ValidateValue();

	TCHAR myResultChar[255];
	DPOINT dpRealPos;

	int		m_nGridXNo;
	int		m_nGridYNo;
	int		m_nGridSize;
	BOOL	m_bOKMaster;
	BOOL	m_bOKSlave;
	CCorrectTime	m_StandbyTime;
	CDPoint	m_dOffsetM;
	CDPoint	m_dOffsetS;
	int		m_nStartCam;

	double m_dScal1stTemper;
	double m_dScal2ndTemper;
	double m_dScal1stSBTemper;
	double m_dScal2ndSBTemper;
	double m_dScalAllTemper[10];
	BOOL m_bFullCoolingAGC;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlScannerCalibration)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlScannerCalibration();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlScannerCalibration)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonLive();
	afx_msg void OnButtonTest();
	afx_msg void OnButtonTrain();
	afx_msg void OnButtonCalStartAuto();
	afx_msg void OnButtonCalStart();
	afx_msg void OnButtonCalStop();
	afx_msg void OnDestroy();
	afx_msg void OnSelchangeComboUseVision();
	afx_msg void OnSelchangeComboUseTool();
	afx_msg void OnKillfocusEdit();
	afx_msg void OnBtnChangeBoard();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT CalibrationThreadRestart(WPARAM, LPARAM);
	afx_msg LRESULT ModalDlgCalResult(WPARAM, LPARAM);
	afx_msg LRESULT MessageQuit(WPARAM wParam, LPARAM);
	afx_msg void OnInspectionArea();
	afx_msg LRESULT OnCalibrationStart(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg void OnButtonTrigger();
	afx_msg void OnButtonTriggerAgc();
	afx_msg void OnButtonJobFileOpen();
	afx_msg void OnButtonShowDialog();
	afx_msg LRESULT ChangeVisionParam(WPARAM wParam, LPARAM lPatam);
	afx_msg LRESULT GetVisionResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetVisionLamp(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButtonXGetTime();
	afx_msg void OnButtonYGetTime();
	afx_msg void OnButtonApplyBeampath();
	afx_msg void OnCheckSkipBoard();
	afx_msg LRESULT GetGrabVisionResult(WPARAM wParam, LPARAM lParam);
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonOffsetVerify();
	afx_msg void OnBnClickedButtonOffsetVerifyNext();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnEnKillfocusEditAutoXPos();
	afx_msg void OnEnKillfocusEditAutoYPos();
	afx_msg void OnRadioRemote();
	afx_msg void OnRadioManual();
	afx_msg void OnEnKillfocusEdit1stThick();
	afx_msg void OnEnKillfocusEdit2ndThick();
	afx_msg void OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult);
};

UINT CalibrationThread(LPVOID pParam);
bool FireCalibrationHole(AUTOCALTHREADPARAM* pAuto, int nSelectHead, double dXTablePos, double dYTablePos, bool bFire = true, bool bGetOffset = false);

bool FindPreviousShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd);
bool FindPreviousShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead = emMaster);

bool FindCurrentShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos1 = NULL, DPOINT* pdOffset1 = NULL, bool* pSuccess1 = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);
bool FindCurrentShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead = emMaster, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);

bool FindShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, bool bSave = true, DPOINT* pdPos1 = NULL, DPOINT* pdOffset1 = NULL, bool* pSuccess1 = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);
bool FindShot(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead = emMaster, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);

bool FindShotForScannerTableCompen(AUTOCALTHREADPARAM* pAuto, double dZ1, double dZ2, emHEAD emHead = emMaster, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);

bool GetHeadOffset(AUTOCALTHREADPARAM* pAuto, emHEAD em1st, emHEAD em2nd);
/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_PANEMANUALCONTROLSCANNERCALIBRATION_H__BF743DC6_800B_4B88_A26A_AFC28563F041__INCLUDED_)
