// PaneLogManagerLog.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerLog.h"
#include "..\Model\DEasyDrillerIni.h"
#include <share.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLog

IMPLEMENT_DYNCREATE(CPaneLogManagerLog, CFormView)

CPaneLogManagerLog::CPaneLogManagerLog()
	: CFormView(CPaneLogManagerLog::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerLog)
	m_nLogType = 0;
	m_strSearch = _T("");
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();
	//}}AFX_DATA_INIT
	m_pThread		= NULL;
	m_pHandle[0]	= INVALID_HANDLE_VALUE;	// Thread Start event
	m_pHandle[1]	= INVALID_HANDLE_VALUE;	// Thread Stop event
	m_pHandle[2]	= INVALID_HANDLE_VALUE;	// Thread Finished event
	m_bIsView		= TRUE;

	lstrcpy(m_lpszColumnHead[0], " Date ");
	lstrcpy(m_lpszColumnHead[1], " Time ");
	lstrcpy(m_lpszColumnHead[2], " Message ");
}

CPaneLogManagerLog::~CPaneLogManagerLog()
{
}

void CPaneLogManagerLog::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerLog)
	DDX_Control(pDX, IDC_BUTTON_SEARCH, m_btnSearch);
	DDX_Control(pDX, IDC_LIST_LOG, m_listLog);
	DDX_Control(pDX, IDC_EDIT_SEARCH, m_edtSearch);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_CATEGORY, m_cmbCategory);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSave);
	DDX_CBIndex(pDX, IDC_COMBO_CATEGORY, m_nLogType);
	DDX_Text(pDX, IDC_EDIT_SEARCH, m_strSearch);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerLog, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerLog)
	ON_NOTIFY(NM_CLICK, IDC_LIST_LOG, OnClickListLog)
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLog diagnostics

#ifdef _DEBUG
void CPaneLogManagerLog::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerLog::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLog message handlers

void CPaneLogManagerLog::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitListControl();
	InitEditControl();
	InitEtcControl();
}

BOOL CPaneLogManagerLog::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneLogManagerLog::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	// Save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

	// Search
	m_btnSearch.SetFont( &m_fntBtn );
	m_btnSearch.SetFlat( FALSE );
	m_btnSearch.EnableBallonToolTip();
	m_btnSearch.SetToolTipText( _T("Search") );
	m_btnSearch.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSearch.SetBtnCursor(IDC_HAND_1);

	// Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);
	m_btnStop.EnableWindow( FALSE );
}

void CPaneLogManagerLog::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ERR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DETAIL_INFO)->SetFont( &m_fntStatic );
}

void CPaneLogManagerLog::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");

	m_listLog.SetFont( &m_fntList );
	m_listLog.SetExtendedStyle(m_listLog.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);

	m_ImageList.DeleteImageList();
	m_ImageList.Create(IDB_SMALL_TYPE, 16, 1, RGB(0, 0, 0));

	m_listLog.DeleteAllItems();
	m_listLog.SetImageList( &m_ImageList, LVSIL_SMALL );

	m_listLog.InsertColumn(0, _T("E/I"), LVCFMT_CENTER, 160);
	m_listLog.InsertColumn(1, _T(m_lpszColumnHead[0]), LVCFMT_CENTER, 100);
	m_listLog.InsertColumn(2, _T(m_lpszColumnHead[1]), LVCFMT_CENTER, 100);
	m_listLog.InsertColumn(3, _T(m_lpszColumnHead[2]), LVCFMT_LEFT, 590);
	m_listLog.InsertColumn(4, _T(" "), LVCFMT_CENTER, 20);
}

void CPaneLogManagerLog::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtSearch.SetFont( &m_fntEdit );
	m_edtSearch.SetReceivedFlag( 5 ); // Alpha-Nemeric
}

void CPaneLogManagerLog::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");

	m_cmbCategory.SetFont( &m_fntEtc );
	m_cmbCategory.SetCurSel( 0 );

	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );
}

void CPaneLogManagerLog::OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowDetailInformation();
	
	*pResult = 0;
}

void CPaneLogManagerLog::ShowDetailInformation()
{
	int nSel = m_listLog.GetSelectionMark();
	if(-1 == nSel)
		return;

	CString strCaption;
	strCaption.Format(_T("Detail Log\n"));
	
	CString strText(m_listLog.GetItemText(nSel, 2));
	strText += _T("\r\n");
	strText += m_listLog.GetItemText(nSel, 3);
	
	CString strDetail = m_strLogDetailArray.ElementAt(nSel);
	if (strDetail.IsEmpty())
		return;
	strDetail += _T("      ");
	strDetail.Insert(0, _T("\r\n\r\n"));
	strDetail.Insert(0, strText);
	strDetail += _T("      ");
	
	MessageBox(strCaption + strDetail);
}

void CPaneLogManagerLog::LoadFromCurrentDate()
{
	CTime CurTime = CTime::GetCurrentTime();

	m_listLog.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();
	LoadFromFile( GetLogFile(CurTime) );
}

CString CPaneLogManagerLog::GetLogFile(CTime& cTime)
{
	CString strProcessLog;
	strProcessLog.Format( "%s" , gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
	CString strLogFile(strProcessLog);
	strLogFile += _T("Log");
	strLogFile += cTime.Format(_T("%Y%m%d"));
	
	return strLogFile;
}

void CPaneLogManagerLog::LoadFromFile(CString strFileName, CString strSearch)
{
	if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		return;

//	::WaitForSingleObject( g_hLogFile, INFINITE );
//	::ResetEvent(g_hLogFile);

	FILE* fp;

	fp = _fsopen((LPCTSTR)strFileName, _T("r"), _SH_DENYNO);
//	if (NULL != fopen_s(&fp, (LPCTSTR)strFileName, _T("r")))
	if(fp == NULL)
	{
		::SetEvent(g_hLogFile);
		return;
	}

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;
	CString strDate, strTime, strMes, strDetail, strTemp, strKind;
	bool bFind = false;
	for(int nStart = m_listLog.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLogFile);
			return;
		}

		if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// �����α״� 'E', �׳��� 'I'
		{
			if (feof(fp))
				break;
			else
				continue;
		}

		if (m_nLogType > 3)	// ������ ����
		{
			if (token[0] == _T('I'))
				continue;
		}

		TCHAR chStart = token[0];

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLogFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ��¥
			continue;

		strDate = token;
		strDate.TrimLeft();
		strDate.TrimRight();

//		int nLen = strDate.GetLength();
//		int nPos = strDate.Find('/') + 1;
//		strDate = strDate.Right(nLen - nPos);
//		m_ctrlLogList.SetItemText(n, 1, strDate);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLogFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ð�
			continue;

		strTime = token;
		strTime.TrimLeft();
		strTime.TrimRight();

//		m_ctrlLogList.SetItemText(n, 2, strTime);

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Kind
			continue;

		strTemp = token;
		strTemp.TrimLeft();
		strTemp.TrimRight();

		BOOL bNewLog = TRUE;
		if(0 == strTemp.CompareNoCase("Auto Drill"))
		{
			strKind.Format(_T("%c-%s"), chStart, strTemp);
			if(!(m_nLogType == 0 || m_nLogType == 1 || m_nLogType == 4))
				continue;
		}
		else if(0 == strTemp.CompareNoCase("Manual Drill"))
		{
			if(!(m_nLogType == 0 || m_nLogType == 2 || m_nLogType == 5))
				continue;
			strKind.Format(_T("%c-%s"), chStart, strTemp);
		}
		else if(0 == strTemp.CompareNoCase("None Drill"))
		{
			if(!(m_nLogType == 0 || m_nLogType == 3 || m_nLogType == 6))
				continue;
			strKind.Format(_T("%c-%s"), chStart, strTemp);
		}
		else
		{
			bNewLog = FALSE;
			strKind = chStart;
			strMes = strTemp;
		}

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLogFile);
			return;
		}
		
		if(bNewLog)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �޼��� ����
				continue;
			strMes = token;
			strMes.TrimLeft();
			strMes.TrimRight();
		}
		
		if (!strSearch.IsEmpty())
		{
			if (NULL == StrStrI((LPCTSTR)strMes, (LPCTSTR)strSearch))
				bFind = false;
			else
				bFind = true;
		}
//		m_ctrlLogList.SetItemText(n, 3, strMes);

		strDetail.Empty();
		while(1)
		{
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				::SetEvent(g_hLogFile);
				return;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	// ���� ����...
			{
				if (strSearch.IsEmpty() || bFind == true)
				{
					int n = m_listLog.InsertItem(nStart, _T(""));
//					if (chStart == _T('E'))
//						m_listLog.SetItem(n, 0, LVIF_IMAGE, NULL, 2, 0, 0, 0);
//					else
//						m_listLog.SetItem(n, 0, LVIF_IMAGE, NULL, 0, 0, 0, 0);

					m_listLog.SetItemText(n, 0, strKind);

					m_listLog.SetItemText(n, 1, strDate);
					m_listLog.SetItemText(n, 2, strTime);
					m_listLog.SetItemText(n, 3, strMes);
					if (!strDetail.IsEmpty())
						m_listLog.SetItem(n, 4, LVIF_IMAGE, NULL, 9, 0, 0, 0);
					
					m_strLogDetailArray.Add(strDetail);
				}
				else
				{
					if (NULL == StrStrI((LPCTSTR)strDetail, (LPCTSTR)strSearch))
					{
//						m_ctrlLogList.DeleteItem(n);
						nStart--;
					}
					else
					{
						int n = m_listLog.InsertItem(nStart, _T(""));
//						if (chStart == _T('E'))
//							m_listLog.SetItem(n, 0, LVIF_IMAGE, NULL, 2, 0, 0, 0);
//						else
//							m_listLog.SetItem(n, 0, LVIF_IMAGE, NULL, 0, 0, 0, 0);

						m_listLog.SetItemText(n, 0, strKind);

						m_listLog.SetItemText(n, 1, strDate);
						m_listLog.SetItemText(n, 2, strTime);
						m_listLog.SetItemText(n, 3, strMes);
						if (!strDetail.IsEmpty())
							m_listLog.SetItem(n, 4, LVIF_IMAGE, NULL, 9, 0, 0, 0);

						m_strLogDetailArray.Add(strDetail);
					}
				}
				break;
			}

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				::SetEvent(g_hLogFile);
				return;
			}

			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			if (!strTemp.IsEmpty())
			{
				if (!strDetail.IsEmpty())
					strDetail += _T("\r\n");
				strDetail += strTemp;
			}
		}
	}

	fclose(fp);
	::SetEvent(g_hLogFile);
}

void CPaneLogManagerLog::UpdateSaveButton()
{
	if (0 == m_listLog.GetItemCount())
		m_btnSave.EnableWindow( FALSE );
	else
		m_btnSave.EnableWindow( TRUE );
}

void CPaneLogManagerLog::OnButtonView() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);
	m_listLog.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();

	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event

	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	m_bIsView = TRUE;
	m_pThread = ::AfxBeginThread(ViewLogThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}

	::SetEvent(m_pHandle[0]);
	::Sleep(20);

	EnableNormalButton(FALSE);
}

void CPaneLogManagerLog::MakeThreadClear()
{
	m_pThread = NULL;
	if (m_pHandle[0] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[0]);
	if (m_pHandle[1] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[1]);
	if (m_pHandle[2] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[2]);
	m_pHandle[0] = m_pHandle[1]	= m_pHandle[2] = INVALID_HANDLE_VALUE;
}

void CPaneLogManagerLog::EnableNormalButton(BOOL bEnable)
{
	m_btnView.EnableWindow( bEnable );
	m_btnSearch.EnableWindow( bEnable );
	m_btnSave.EnableWindow( bEnable );
	m_btnStop.EnableWindow( !bEnable );
}

UINT CPaneLogManagerLog::ViewLogThread(LPVOID lpVoid)
{
	CPaneLogManagerLog* pDlg = static_cast<CPaneLogManagerLog*>(lpVoid);
	DWORD dwRetCode = ::WaitForMultipleObjects(3, const_cast<HANDLE*>(pDlg->m_pHandle), FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pDlg->m_pHandle[0]);
	else
	{
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	CString strSearch;
	if (pDlg->m_bIsView)
		strSearch.Empty();
	else
		strSearch = pDlg->m_strSearch;

//	if (pDlg->m_ctStart > pDlg->m_ctEnd)
//	{
//		pDlg->m_ctStart = pDlg->m_ctEnd;
//		pDlg->UpdateData(FALSE);
//	}

	int nStartYear = pDlg->m_ctStart.GetYear();
	int nEndYear = pDlg->m_ctEnd.GetYear();
	int nStartMonth = pDlg->m_ctStart.GetMonth();
	int nEndMonth = pDlg->m_ctEnd.GetMonth();
	int nStartDay = pDlg->m_ctStart.GetDay();
	int nEndDay = pDlg->m_ctEnd.GetDay();

	if (nStartYear == nEndYear && nStartMonth == nEndMonth)
	{
		for (int i = nStartDay; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}
	else if (nStartYear == nEndYear)
	{
		for (int i = nStartMonth; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j, nLastDayOfMonth = pDlg->GetDays(nEndYear, i);
			if (i == nStartMonth)
				j = nStartDay;
			else
				j = 1;

			for (; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
			}
		}

		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}
	else
	{
		for (int i = nStartYear; i < nEndYear; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j;
			if (i == nStartYear)
				j = nStartMonth;
			else
				j = 1;

			for (; j <= 12; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				int k, nLastDayOfMonth = pDlg->GetDays(i, j);
				if (j == nStartMonth)
					k = nStartDay;
				else
					k = 1;

				for (; k <= nLastDayOfMonth; k++)
				{
					if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						::SetEvent(pDlg->m_pHandle[2]);
						return 0L;
					}

					CTime cTime(i, j, k, 0, 0, 0);
					pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
				}
			}
		}

		for(int i =  1; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int nLastDayOfMonth = pDlg->GetDays(nEndMonth, i);
			for (int j = 1; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
			}
		}

		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}

	if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
	{
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	::SetEvent(pDlg->m_pHandle[2]);
	pDlg->PostMessage(WM_COMMAND, IDC_BUTTON_STOP);
	return 1L;
}

int CPaneLogManagerLog::GetDays(int nYear, int nMonth)
{
	switch (nMonth)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		return 31;
	case 4:
	case 6:
	case 9:
	case 11:
		return 30;
	case 2:
		if (nYear % 4 == 0)
		{
			if (nYear % 100 == 0)
			{
				if (nYear % 400 == 0)
					return 29;
				else
					return 28;
			}
			else
				return 29;
		}
		else
			return 28;
	default:
		return 31;
	}
}

void CPaneLogManagerLog::OnButtonSave() 
{
	UpdateData(TRUE);
	
	if (0 == m_listLog.GetItemCount())
		return;
	
	TCHAR szFilter[] = _T("Log File(*.txt)|*.txt||");
	CFileDialog filedlg(FALSE, _T("txt"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	
//	filedlg.m_ofn.lpstrInitialDir = _T("C:\\");
	
	if(IDOK == filedlg.DoModal())
	{
		CString strSaveAsProjectFileName = filedlg.GetPathName();
		WriteLogFile(strSaveAsProjectFileName);
	}
	else
		return;	
}

void CPaneLogManagerLog::WriteLogFile(CString& strSaveFileName)
{
	CStdioFile cFile;

	if (FALSE == cFile.Open(strSaveFileName, CFile::modeCreate | CFile::modeWrite))
	{
		ErrMessage(IDS_CREATE_FILE_ERR, MB_ICONERROR);
		return;
	}

	TRY
	{
		CString strLine;
		strLine.Format(_T("%10s\t%8s\t%60s\t%s\n"),
			m_lpszColumnHead[0], m_lpszColumnHead[1],
			m_lpszColumnHead[2], _T("          Detail"));
		cFile.WriteString(strLine);

		CString strDetail;
		int nMax = m_listLog.GetItemCount();
		for (int i = 0, nFind; i < nMax; i++)
		{
			strDetail = m_strLogDetailArray.GetAt(i);
			while (1)
			{
				nFind = strDetail.Find(_T("\r\n"));
				if (nFind == -1)
					break;

				strDetail.Delete(nFind);
				strDetail.SetAt(nFind, _T(' '));
			}			
			
			strLine.Format(_T("%10s\t%8s\t%60s\t%s\n"),
				m_listLog.GetItemText(i, 1), m_listLog.GetItemText(i, 2),
				m_listLog.GetItemText(i, 3), strDetail);
			cFile.WriteString(strLine);
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH

	cFile.Close();
}

void CPaneLogManagerLog::OnButtonSearch() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);

	if (m_strSearch.IsEmpty())
		return;

	m_listLog.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();

	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event

	m_bIsView = FALSE;
	m_pThread = ::AfxBeginThread(ViewLogThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}

	::SetEvent(m_pHandle[0]);
	::Sleep(20);

	EnableNormalButton(FALSE);
}

void CPaneLogManagerLog::OnButtonStop() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);

//		if (::WaitForSingleObject(m_pHandle[2], INFINITE) == WAIT_OBJECT_0)
		if (::WaitForSingleObject(m_pHandle[2], 100) == WAIT_OBJECT_0)
		{
			MakeThreadClear();
			EnableNormalButton(TRUE);
		}
	}

	UpdateSaveButton();
}

void CPaneLogManagerLog::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}
