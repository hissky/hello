// DlgVisionView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\Model\DSystemINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionView dialog


CDlgVisionView::CDlgVisionView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVisionView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgVisionView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nPanelNo = 0;
}


void CDlgVisionView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgVisionView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgVisionView, CDialog)
	//{{AFX_MSG_MAP(CDlgVisionView)
	ON_WM_NCHITTEST()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionView message handlers

BOOL CDlgVisionView::OnInitDialog() 
{
	CDialog::OnInitDialog();

	COmiView* pView = NULL;
	HVision* pVision = gDeviceFactory.GetVision();

	pView = (COmiView*)GetDlgItem(IDC_OMIVIEWCTRL1_CAM1);
	pVision->SetOmiView( 0, pView );

	pView = (COmiView*)GetDlgItem(IDC_OMIVIEWCTRL1_CAM2);
	pVision->SetOmiView( 1, pView );

	pView = (COmiView*)GetDlgItem(IDC_OMIVIEWCTRL1_CAM3);
	pVision->SetOmiView( 2, pView );

	pView = (COmiView*)GetDlgItem(IDC_OMIVIEWCTRL1_CAM4);
	pVision->SetOmiView( 3, pView );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CDlgVisionView::OnNcHitTest(CPoint point) 
{
	if( TABLE_CAL_VISION_VIEW == m_nPanelNo )
	{
		TRACE("OnNcHitTest()\n");
		UINT nHitTest = CDialog::OnNcHitTest(point);
		return (nHitTest == HTCLIENT) ? HTCAPTION : nHitTest;
	}
	
	return CDialog::OnNcHitTest(point);
}

BOOL CDlgVisionView::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

void CDlgVisionView::SetPanelNo(int nNo)
{
	m_nPanelNo = nNo;
}
