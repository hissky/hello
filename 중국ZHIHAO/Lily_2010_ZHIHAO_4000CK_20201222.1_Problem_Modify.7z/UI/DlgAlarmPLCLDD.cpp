// DlgAlarmPLC.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAlarmPLCLDD.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLC dialog


CDlgAlarmPLCLDD::CDlgAlarmPLCLDD(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAlarmPLCLDD::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAlarmPLC)
		// NOTE: the ClassWizard will add member initialization here
	m_bOnTimer = FALSE;
	m_nMsg = 0;
	m_nTimerID = 0;
	//}}AFX_DATA_INIT
}


void CDlgAlarmPLCLDD::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAlarmPLC)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_ALARM, m_ctrlListMsg);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAlarmPLCLDD, CDialog)
	//{{AFX_MSG_MAP(CDlgAlarmPLC)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLC message handlers


BOOL CDlgAlarmPLCLDD::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	m_ctrlListMsg.SetExtendedStyle(m_ctrlListMsg.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY | LVS_EX_GRIDLINES);
	InitListCtrl();
	m_lErrorNew = m_lErrorOld = 0;
	m_nTimerID = SetTimer(1212, 500, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAlarmPLCLDD::InitListCtrl()
{
	m_ctrlListMsg.DeleteAllItems();
	
	m_ctrlListMsg.DeleteColumn(0);
	
	TCHAR* ColumnHeadText = _T("Message");
	
	int ColumnHeadSize = 300;
	
	//  List control�� Column ����
	m_ctrlListMsg.InsertColumn(0, _T(""), LVCFMT_CENTER, 1);
	LV_COLUMN lvcolumn;

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	lvcolumn.pszText = ColumnHeadText;
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = ColumnHeadSize;
	m_ctrlListMsg.InsertColumn(1, &lvcolumn);

	AddItems();
}

void CDlgAlarmPLCLDD::AddItems()
{
	m_ctrlListMsg.DeleteAllItems();
	
	for(int i=0; i<20; i++)
	{
		m_ctrlListMsg.InsertItem(i, _T(""));

//		m_strMsg[i].Format(_T("msg #%d"), i+1);

		_stprintf_s(m_szText, "%s", m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCLDD::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bOnTimer == TRUE)
	{
		CDialog::OnTimer(nIDEvent);
		return;
	}
	m_bOnTimer = TRUE;

	UpdateMsg();
	
	m_bOnTimer = FALSE;
	CDialog::OnTimer(nIDEvent);
}

void CDlgAlarmPLCLDD::UpdateMsg()
{
	m_nMsg = 0;

	BOOL bChange = FALSE;

	for(int j=0; j<20; j++)
		m_strMsg[j] = _T("");

	m_lErrorIoNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_IO);
	if (m_lErrorIoNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorIoNew;
		GetIoErrorMsg();
	}
	
	m_lErrorLoadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD);
	if (m_lErrorLoadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoadNew;
		if(m_nMsg < 20)
			GetLoadErrorMsg();
	}
	
	m_lErrorLoad2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD2);
	if (m_lErrorLoad2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad2New;
		if(m_nMsg < 20)
			GetLoad2ErrorMsg();
	}

	m_lErrorLoad3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD3);
	if (m_lErrorLoad3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad3New;
		if(m_nMsg < 20)
			GetLoad3ErrorMsg();
	}
	
	m_lErrorUnloadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD);
	if (m_lErrorUnloadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnloadNew;
		if(m_nMsg < 20)
			GetUnloadErrorMsg();
	}

	m_lErrorUnload2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD2);
	if (m_lErrorUnload2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload2New;
		if(m_nMsg < 20)
			GetUnload2ErrorMsg();
	}

	m_lErrorUnload3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD3);
	if (m_lErrorUnload3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload3New;
		if(m_nMsg < 20)
			GetUnload3ErrorMsg();
	}
		
	m_lErrorTableLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLELIMIT);
	if (m_lErrorTableLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableLimitNew;
		if(m_nMsg < 20)
			GetTableLimitErrorMsg();
	}
	
	m_lErrorOtherLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERLIMIT);
	if (m_lErrorOtherLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOtherLimitNew;
		if(m_nMsg < 20)
			GetOtherLimitErrorMsg();
	}
	
	m_lErrorLaserNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LASER);
	if (m_lErrorLaserNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLaserNew;
		if(m_nMsg < 20)
			GetLaserErrorMsg();
	}

	m_lErrorOthersNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS);
	if (m_lErrorOthersNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthersNew;
		if(m_nMsg < 20)
			GetOthersErrorMsg();
	}

	m_lErrorOthers2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS2);
	if (m_lErrorOthers2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers2New;
		if(m_nMsg < 20)
			GetOthers2ErrorMsg();
	}

	m_lErrorOthers3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS3);
	if (m_lErrorOthers3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers3New;
		if(m_nMsg < 20)
			GetOthers3ErrorMsg();
	}

	m_lErrorOthers4New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS4);
	if (m_lErrorOthers4New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers4New;
		if(m_nMsg < 20)
			GetOthers4ErrorMsg();
	}

	m_lErrorTableNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLE);
	if (m_lErrorTableNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableNew;
		if(m_nMsg < 20)
			GetTableErrorMsg();
	}
	
	if(m_nMsg < 1 && !bChange && m_lErrorNew == m_lErrorOld) 
		return;
	
	m_lErrorOld = m_lErrorNew;
	m_lErrorNew = 0;
	
	for(int i=0; i<20; i++)
	{
		lstrcpy(m_szText, (LPCTSTR)m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCLDD::GetIoErrorMsg()
{
#ifdef __CUNGJU_JASMINE_OLD__
	if(m_lErrorIoNew & 0x0001) // em stop
	{	
		m_strMsg[m_nMsg++] = "[MB6100] EM Stop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0002) // Dust Suction Error
	{
		m_strMsg[m_nMsg++] = "[MB50808] Dust Suction Error";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0004) // main station initial error
	{
		m_strMsg[m_nMsg++] = "[MB6102] Main InitErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0008) // pc signal alive error
	{
		m_strMsg[m_nMsg++] = "[MB6103] PC Signal AliveErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0040) // LaserPower Off
	{
		m_strMsg[m_nMsg++] = "[MB6107] LaserPower Off";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0080) // MainAir Error
	{
		m_strMsg[m_nMsg++] = "[MB6108] MainAir Error";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0010) // HeightSensor Up Error
	{
		m_strMsg[m_nMsg++] = "[MB6132] HeightSensor UpErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0020) // HeightSensor Down Error
	{
		m_strMsg[m_nMsg++] = "[MB6133] HeightSensor DownErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0400) // LoaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6207] LoaderDoor Open";
		if(m_nMsg > 19) return;
	}
/*	if(m_lErrorIoNew & 0x0800) // UnloaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6307] UnloaderDoor Open";
		if(m_nMsg > 19) return;
	}
	
	if(m_lErrorIoNew & 0x1000) // Shutter1 open error
	{
		m_strMsg[m_nMsg++] = "[MB6128] 1stShutter OpenErr";
		if(m_nMsg > 19) return;
	}
	*/
	if(m_lErrorIoNew & 0x2000) // Shutter1 close error
	{
		m_strMsg[m_nMsg++] = "[MB6129] 1stShutter CloseErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x4000) // Shutter2 open error
	{
		m_strMsg[m_nMsg++] = "[MB6130] 2ndShutter OpenErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x8000) // Shutter2 close error
	{
		m_strMsg[m_nMsg++] = "[MB6131] 2ndShutter CloseErr";
		if(m_nMsg > 19) return;
	}
#else
	if(m_lErrorIoNew & 0x0001) // em stop
	{	
		m_strMsg[m_nMsg++] = "[MB6100] EM Stop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0002) // Dust Suction Error
	{
		m_strMsg[m_nMsg++] = "[MB50808] Dust Suction Error";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0004) // main station initial error
	{
		m_strMsg[m_nMsg++] = "[MB6102] Main InitErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0008) // pc signal alive error
	{
		m_strMsg[m_nMsg++] = "[MB6103] PC Signal AliveErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0020) // Rear Door Open
	{
		m_strMsg[m_nMsg++] = "[MB6105] RearDoor Open";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0040) // LaserPower Off
	{
		m_strMsg[m_nMsg++] = "[MB6107] LaserPower Off";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0080) // MainAir Error
	{
		m_strMsg[m_nMsg++] = "[MB6108] MainAir Error";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x0400) // LoaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6207] LoaderDoor Open";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x2000) // Shutter1 close error
	{
		m_strMsg[m_nMsg++] = "[MB6129] 1stShutter CloseErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x4000) // Shutter2 open error
	{
		m_strMsg[m_nMsg++] = "[MB6130] 2ndShutter OpenErr";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorIoNew & 0x8000) // Shutter2 close error
	{
		m_strMsg[m_nMsg++] = "[MB6131] 2ndShutter CloseErr";
		if(m_nMsg > 19) return;
	}
#endif
}

void CDlgAlarmPLCLDD::GetLoadErrorMsg()
{
	if (m_lErrorLoadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6263] Loader Stop Err";
		if(m_nMsg > 19) return;
	}
	if (m_lErrorLoadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6262] Loader Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[5210] LoadCart No PCB";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6201] L-Picker1 PCB Exist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6202] L-Picker1 PCB NonExist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6203] L-Picker2 PCB Exist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6204]L-Picker2 PCB NonExist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6200] Loader Init Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6206] L-AlignTable PCB NonExist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6205] L-AlignTable PCB Exist";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6216] L-Picker1 Pad1 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6217] L-Picker1 Pad1 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6218] L-Picker1 Pad2 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6219] L-Picker1 Pad2 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6220] L-Picker1 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6221] L-Picker1 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetLoad2ErrorMsg()
{
	if(m_lErrorLoad2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6222] L-Picker1 Blow On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6223] L-Picker2 Pad1 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6224] L-Picker2 Pad1 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6225] L-Picker2 Pad2 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6226] L-Picker2 Pad2 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6227] L-Picker2 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6228] L-Picker2 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6229] L-Picker2 Blow On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6232] L-Cart Clamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6233] L-Cart Unclamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6234] L-AlignSheetTable Forward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6235] L-AlignSheetTable Backward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6236] L-AlignGuide Forward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6237] L-AlignGuide Backward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6238] L-AlignTable Left Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6239] L-AlignTable Right Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetLoad3ErrorMsg()
{
	if(m_lErrorLoad3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6240] L-Elevator LoadPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6241] L-Elevator OriginPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6242] L-Elevator Sensor Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6245] LC CartPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6246] LC LoadPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6247] LC Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6248] LC Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6249] LC FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6250] LC OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6253] LC Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6208] L-Picker1 PCB Ready Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorLoad3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6209] L-Picker2 PCB Ready Err";
		if(m_nMsg > 19) return;
	}
//ejpark
	if(m_lErrorLoad3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6243] Loader Cart Detect Sensor Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetUnloadErrorMsg()
{
	if(m_lErrorUnloadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6363] Unloader Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6362] Unloader Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6305] U-Table PCB Exist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6306] U-Table PCB NonExist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6302] U-Picker1 PCB NonExist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6301] U-Picker1 PCB Exist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6304] U-Picker2 PCB NonExist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6303] U-Picker2 PCB Exist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6316] U-Picker1 Pad1 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6317] U-Picker1 Pad1 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6318] U-Picker1 Pad2 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6319] U-Picker1 Pad2 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6320] U-Picker1 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6321] U-Picker1 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6322] U-Picker1 Blow On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnloadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6323] U-Picker2 Pad1 Up Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetUnload2ErrorMsg()
{
	if(m_lErrorUnload2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6324] U-Picker2 Pad1 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6325] U-Picker2 Pad2 Up Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6326] U-Picker2 Pad2 Down Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6327] U-Picker2 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6328] U-Picker2 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6329]U-Picker2 Blow On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6332] U-Cart Clamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6333] U-Cart Unclamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6338] U-AlignTable Left Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6339] U-AlignTable Right Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6340] U-Elevator LoadPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6341] U-Elevator OriginPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6342] U-Elevator Sensor Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6345] UC UnloadPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6346] UC CartPos Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6347] UC Motion Param Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetUnload3ErrorMsg()
{
	if(m_lErrorUnload3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6348] UC Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6349] UC FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6350] UC OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6353] UC Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6308] U-Picker1 PCB Ready Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6309] U-Picker2 PCB Ready Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorUnload3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6330] Unloader Init Err";
		if(m_nMsg > 19) return;
	}
// ejpark 
	if(m_lErrorUnload3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6343] Unloader Cart Detect Sensor Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetTableLimitErrorMsg()
{
	if(m_lErrorTableLimitNew & 0x0001) // X+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6003] X (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0002) // X- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6004] X (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0004) // Y+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6011] Y (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0008) // Y- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6012] Y (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0040) // Z1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6019] Z1 (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0080) // Z1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6020] Z1 (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0100) // Z2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6027] Z2 (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableLimitNew & 0x0200) // Z2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6028] Z2 (-)Limit";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetOtherLimitErrorMsg()
{
	if(m_lErrorOtherLimitNew & 0x0001) // C1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6043] C (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0002) // C1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6044] C (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0004) // P1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6251] LC (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0008) // P1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6252] LC (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0010) // C2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6059] C2 (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0020) // C2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6060] C2 (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0040) // P2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6351] UC (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0080) // P2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6352] UC (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0100) // M1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6035] M (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0200) // M1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6036] M (-)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0400) // M2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6051] M2 (+)Limit";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOtherLimitNew & 0x0800) // M2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6052] M2 (-)Limit";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetLaserErrorMsg()
{
	if(m_lErrorLaserNew & 0x0001) // Chiller Alarm
	{
		m_strMsg[m_nMsg++] = "[MB5425] Chiller On Error";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetTableErrorMsg()
{
	if(m_lErrorTableNew & 0x0001) // xy move danger error
	{
		m_strMsg[m_nMsg++] = "[MB6109] XY Move Danger";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0002) // xy stop error
	{
		m_strMsg[m_nMsg++] = "[MB6143] XY Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0004) // X Fault
	{
		m_strMsg[m_nMsg++] = "[MB6000] X Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0008) // X Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6001] X FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0010) // X Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6002] X OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0020) // X Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6005] X Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0040) // Y Fault
	{
		m_strMsg[m_nMsg++] = "[MB6008] Y Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0080) // Y Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6009] Y FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0100) // Y Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6010] Y OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0200) // Y Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6013] Y Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0400) // Z1 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6016] Z1 Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x0800) // Z1 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6017] Z1 FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x1000) // Z1 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6018] Z1 OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x2000) // Z1 Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6021] Z1 Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x4000) // Z2 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6024] Z2 Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorTableNew & 0x8000) // Z2 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6025] Z2 FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetOthersErrorMsg()
{
	if(m_lErrorOthersNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6120] VacuumMotor1 On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6121] VacuumMotor1 Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6122] VacuumMotor2 On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6123] VacuumMotor2 Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6124] Table1 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6125] Table1 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6126] Table2 Vacuum On Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6127] Table2 Vacuum Off Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6134]PowerDetector Sensor Forward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6135] PowerDetector Sensor Backward Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6137] X Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6138] Y Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6140]XY Load Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6139] XY Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6141]XY Unload Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthersNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6142] XY Unload Position Err";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetOthers2ErrorMsg()
{
	if(m_lErrorOthers2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6157]XY Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6158] Z1 Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6159] Z2 Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6160] M Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6161] C Motion Param Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6162] Table Clamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6163] Table Unclamp Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6033] M FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6034] M OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6037] M Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6040] C Fault";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6041] C FatalFollowing Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6042] C OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6045] C Homing TimeOver";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetOthers3ErrorMsg()
{
	if(m_lErrorOthers3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6144] Z1 Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6145] Z1 Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6146] Z2 Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6147] Z2 Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6148] M Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6149] M Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6150] C Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6151] C Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6152] M2 Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6153]M2 Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6154] C2 Position Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6155] C2 Stop Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6106] MPG On";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6026] Z2 OpenLoop";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6029] Z2 Homing TimeOver";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers3New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6032] M Fault";
		if(m_nMsg > 19) return;
	}
}

void CDlgAlarmPLCLDD::GetOthers4ErrorMsg()
{
//	if(m_lErrorOthers4New & 0x0001)
//	{
//		m_strMsg[m_nMsg++] = "[MB6110] PC Alarm";
//		if(m_nMsg > 19) return;
//	}

//ejpark 
	if(m_lErrorOthers4New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6112] 1stTable PCB Exist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers4New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6113] 1stTable PCB NotExist Err";
		if(m_nMsg > 19) return;
	}
	
	if(m_lErrorOthers4New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6114] 2ndTable PCB Exist Err";
		if(m_nMsg > 19) return;
	}
	if(m_lErrorOthers4New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6115] 2ndTable PCB NotExist Err";
		if(m_nMsg > 19) return;
	}

}

void CDlgAlarmPLCLDD::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}
