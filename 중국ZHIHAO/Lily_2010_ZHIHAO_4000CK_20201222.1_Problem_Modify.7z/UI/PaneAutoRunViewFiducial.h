#if !defined(AFX_PANEAUTORUNVIEWFIDUCIAL_H__EB91DD39_C201_445B_84A2_561B436ABB72__INCLUDED_)
#define AFX_PANEAUTORUNVIEWFIDUCIAL_H__EB91DD39_C201_445B_84A2_561B436ABB72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewFiducial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewFiducial form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif
#include "LedButton.h"
#include "UEasyButtonEx.h"
class CPaneAutoRunViewFiducial : public CFormView
{
protected:
	CPaneAutoRunViewFiducial();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewFiducial)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewFiducial)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_FIDUCIAL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont	m_fntStatic;
	CFont	m_fntListBox;
	CFont	m_fntBtn;
	CListBox m_lboxResult;
	CListCtrl m_listFiducial;
	CLedButton m_ledScale;
	UEasyButtonEx m_btnMode;
	
	BOOL m_bDrawMode;
	int	m_nSelPanel;
	BOOL m_bShowVision;
	int m_nTimer;
	BOOL m_bDrawMoveStart;
	CPoint m_ptMoveStart;
	BOOL m_bShow;
// Operations
public:
	void DestroyTimer();
	void InitTimer();
	CRect GetVisionWindowRect();
	void DrawFiducial(int nPanelNo);
	void RemoveList();
	void ChangeFidList(int nPanelNo);
	void InsertFidResult(int nLotNo);
	void InitBtnControl();
	void InitListControl();
	void ChangeDisplay();
	void DisconnectView();
	void ConnectView();
	void InitStatic();
	void OnMoveVisionView();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewFiducial)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewFiducial();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewFiducial)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeListResult();
	afx_msg void OnButtonMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnPaint();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWFIDUCIAL_H__EB91DD39_C201_445B_84A2_561B436ABB72__INCLUDED_)
