// PaneSysSetupTophat.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupTophat.h"
#include "..\model\DSystemINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTophat

IMPLEMENT_DYNCREATE(CPaneSysSetupTophat, CFormView)

CPaneSysSetupTophat::CPaneSysSetupTophat()
	: CFormView(CPaneSysSetupTophat::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupTophat)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	memset( &m_sSystemTophat, 0, sizeof(m_sSystemTophat) );
}

CPaneSysSetupTophat::~CPaneSysSetupTophat()
{
}

void CPaneSysSetupTophat::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupTophat)
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_0, m_edtMaskSize0);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_1, m_edtMaskSize1);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_2, m_edtMaskSize2);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_3, m_edtMaskSize3);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_4, m_edtMaskSize4);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_5, m_edtMaskSize5);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_6, m_edtMaskSize6);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_7, m_edtMaskSize7);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_8, m_edtMaskSize8);
	DDX_Control(pDX, IDC_EDIT_MASK_SIZE_9, m_edtMaskSize9);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_0, m_edtBeamSize0);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_1, m_edtBeamSize1);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_2, m_edtBeamSize2);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_3, m_edtBeamSize3);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_4, m_edtBeamSize4);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_5, m_edtBeamSize5);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_6, m_edtBeamSize6);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_7, m_edtBeamSize7);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_8, m_edtBeamSize8);
	DDX_Control(pDX, IDC_EDIT_BEAM_SIZE_9, m_edtBeamSize9);
	DDX_Control(pDX, IDC_EDIT_POS_0, m_edtPos0);
	DDX_Control(pDX, IDC_EDIT_POS_1, m_edtPos1);
	DDX_Control(pDX, IDC_EDIT_POS_2, m_edtPos2);
	DDX_Control(pDX, IDC_EDIT_POS_3, m_edtPos3);
	DDX_Control(pDX, IDC_EDIT_POS_4, m_edtPos4);
	DDX_Control(pDX, IDC_EDIT_POS_5, m_edtPos5);
	DDX_Control(pDX, IDC_EDIT_POS_6, m_edtPos6);
	DDX_Control(pDX, IDC_EDIT_POS_7, m_edtPos7);
	DDX_Control(pDX, IDC_EDIT_POS_8, m_edtPos8);
	DDX_Control(pDX, IDC_EDIT_POS_9, m_edtPos9);
	DDX_Control(pDX, IDC_EDIT_POS2_0, m_edtPos0_2);
	DDX_Control(pDX, IDC_EDIT_POS2_1, m_edtPos1_2);
	DDX_Control(pDX, IDC_EDIT_POS2_2, m_edtPos2_2);
	DDX_Control(pDX, IDC_EDIT_POS2_3, m_edtPos3_2);
	DDX_Control(pDX, IDC_EDIT_POS2_4, m_edtPos4_2);
	DDX_Control(pDX, IDC_EDIT_POS2_5, m_edtPos5_2);
	DDX_Control(pDX, IDC_EDIT_POS2_6, m_edtPos6_2);
	DDX_Control(pDX, IDC_EDIT_POS2_7, m_edtPos7_2);
	DDX_Control(pDX, IDC_EDIT_POS2_8, m_edtPos8_2);
	DDX_Control(pDX, IDC_EDIT_POS2_9, m_edtPos9_2);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_0, m_edtMaskPos0);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_1, m_edtMaskPos1);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_2, m_edtMaskPos2);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_3, m_edtMaskPos3);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_4, m_edtMaskPos4);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_5, m_edtMaskPos5);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_6, m_edtMaskPos6);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_7, m_edtMaskPos7);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_8, m_edtMaskPos8);
	DDX_Control(pDX, IDC_EDIT_MASK2_POS_9, m_edtMaskPos9);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_0, m_edtMaskDuty0);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_1, m_edtMaskDuty1);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_2, m_edtMaskDuty2);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_3, m_edtMaskDuty3);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_4, m_edtMaskDuty4);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_5, m_edtMaskDuty5);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_6, m_edtMaskDuty6);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_7, m_edtMaskDuty7);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_8, m_edtMaskDuty8);
	DDX_Control(pDX, IDC_EDIT_MASK_DUTY_9, m_edtMaskDuty9);
	
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_0, m_edtMaskAOMDelay0);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_1, m_edtMaskAOMDelay1);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_2, m_edtMaskAOMDelay2);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_3, m_edtMaskAOMDelay3);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_4, m_edtMaskAOMDelay4);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_5, m_edtMaskAOMDelay5);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_6, m_edtMaskAOMDelay6);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_7, m_edtMaskAOMDelay7);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_8, m_edtMaskAOMDelay8);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_9, m_edtMaskAOMDelay9);
	
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_0, m_edtMaskAOMDuty0);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_1, m_edtMaskAOMDuty1);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_2, m_edtMaskAOMDuty2);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_3, m_edtMaskAOMDuty3);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_4, m_edtMaskAOMDuty4);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_5, m_edtMaskAOMDuty5);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_6, m_edtMaskAOMDuty6);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_7, m_edtMaskAOMDuty7);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_8, m_edtMaskAOMDuty8);
	DDX_Control(pDX, IDC_EDIT_MASK_AOM_DUTY_9, m_edtMaskAOMDuty9);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_10, m_edtPowerDuty0);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_11, m_edtPowerDuty1);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_12, m_edtPowerDuty2);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_13, m_edtPowerDuty3);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_14, m_edtPowerDuty4);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_15, m_edtPowerDuty5);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_16, m_edtPowerDuty6);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_17, m_edtPowerDuty7);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_18, m_edtPowerDuty8);
	DDX_Control(pDX, IDC_EDIT_POWER_DUTY_19, m_edtPowerDuty9);
	
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_0, m_edtPowerFreq0);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_1, m_edtPowerFreq1);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_2, m_edtPowerFreq2);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_3, m_edtPowerFreq3);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_4, m_edtPowerFreq4);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_5, m_edtPowerFreq5);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_6, m_edtPowerFreq6);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_7, m_edtPowerFreq7);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_8, m_edtPowerFreq8);
	DDX_Control(pDX, IDC_EDIT_POWER_FREQ_9, m_edtPowerFreq9);
	
	DDX_Control(pDX, IDC_EDIT_POWER_A1_0, m_edtPowerA1_0);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_10, m_edtPowerA1_1);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_2, m_edtPowerA1_2);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_3, m_edtPowerA1_3);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_4, m_edtPowerA1_4);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_5, m_edtPowerA1_5);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_6, m_edtPowerA1_6);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_7, m_edtPowerA1_7);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_8, m_edtPowerA1_8);
	DDX_Control(pDX, IDC_EDIT_POWER_A1_9, m_edtPowerA1_9);
	
	DDX_Control(pDX, IDC_EDIT_POWER_A2_0, m_edtPowerA2_0);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_1, m_edtPowerA2_1);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_2, m_edtPowerA2_2);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_3, m_edtPowerA2_3);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_4, m_edtPowerA2_4);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_5, m_edtPowerA2_5);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_6, m_edtPowerA2_6);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_7, m_edtPowerA2_7);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_8, m_edtPowerA2_8);
	DDX_Control(pDX, IDC_EDIT_POWER_A2_9, m_edtPowerA2_9);

	DDX_Control(pDX, IDC_EDIT_MEMO_0, m_edtMemo_0);
	DDX_Control(pDX, IDC_EDIT_MEMO_1, m_edtMemo_1);
	DDX_Control(pDX, IDC_EDIT_MEMO_2, m_edtMemo_2);
	DDX_Control(pDX, IDC_EDIT_MEMO_3, m_edtMemo_3);
	DDX_Control(pDX, IDC_EDIT_MEMO_4, m_edtMemo_4);
	DDX_Control(pDX, IDC_EDIT_MEMO_5, m_edtMemo_5);
	DDX_Control(pDX, IDC_EDIT_MEMO_6, m_edtMemo_6);
	DDX_Control(pDX, IDC_EDIT_MEMO_7, m_edtMemo_7);
	DDX_Control(pDX, IDC_EDIT_MEMO_8, m_edtMemo_8);
	DDX_Control(pDX, IDC_EDIT_MEMO_9, m_edtMemo_9);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupTophat, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupTophat)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTophat diagnostics

#ifdef _DEBUG
void CPaneSysSetupTophat::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupTophat::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTophat message handlers

void CPaneSysSetupTophat::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
}

BOOL CPaneSysSetupTophat::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneSysSetupTophat::InitBtnControl()
{

}

void CPaneSysSetupTophat::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));
	m_fntStatic2.CreatePointFont(100,_T("Arial Bold"));
	
	GetDlgItem(IDC_STATIC_POS_SETTING)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_NO_0)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_5)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_6)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_7)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_8)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NO_9)->SetFont( &m_fntStatic );
			
	GetDlgItem(IDC_STATIC_MASK_DUTY)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_MASK_BEAM_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_COMPENSATION2)->SetFont( &m_fntStatic2 );

	// MEMO
	GetDlgItem(IDC_STATIC_MEMO)->SetFont( &m_fntStatic2 );
}

void CPaneSysSetupTophat::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130,_T("Arial Bold"));
	m_fntEdit2.CreatePointFont(110,_T("Arial Bold"));

	// Mask Size
	m_edtMaskSize0.SetFont( &m_fntEdit );
	m_edtMaskSize0.SetReceivedFlag( 3 );
	m_edtMaskSize0.SetWindowText( _T("0.0") );

	m_edtMaskSize1.SetFont( &m_fntEdit );
	m_edtMaskSize1.SetReceivedFlag( 3 );
	m_edtMaskSize1.SetWindowText( _T("0.0") );

	m_edtMaskSize2.SetFont( &m_fntEdit );
	m_edtMaskSize2.SetReceivedFlag( 3 );
	m_edtMaskSize2.SetWindowText( _T("0.0") );

	m_edtMaskSize3.SetFont( &m_fntEdit );
	m_edtMaskSize3.SetReceivedFlag( 3 );
	m_edtMaskSize3.SetWindowText( _T("0.0") );

	m_edtMaskSize4.SetFont( &m_fntEdit );
	m_edtMaskSize4.SetReceivedFlag( 3 );
	m_edtMaskSize4.SetWindowText( _T("0.0") );

	m_edtMaskSize5.SetFont( &m_fntEdit );
	m_edtMaskSize5.SetReceivedFlag( 3 );
	m_edtMaskSize5.SetWindowText( _T("0.0") );

	m_edtMaskSize6.SetFont( &m_fntEdit );
	m_edtMaskSize6.SetReceivedFlag( 3 );
	m_edtMaskSize6.SetWindowText( _T("0.0") );

	m_edtMaskSize7.SetFont( &m_fntEdit );
	m_edtMaskSize7.SetReceivedFlag( 3 );
	m_edtMaskSize7.SetWindowText( _T("0.0") );

	m_edtMaskSize8.SetFont( &m_fntEdit );
	m_edtMaskSize8.SetReceivedFlag( 3 );
	m_edtMaskSize8.SetWindowText( _T("0.0") );

	m_edtMaskSize9.SetFont( &m_fntEdit );
	m_edtMaskSize9.SetReceivedFlag( 3 );
	m_edtMaskSize9.SetWindowText( _T("0.0") );

	// Beam Size
	m_edtBeamSize0.SetFont( &m_fntEdit );
	m_edtBeamSize0.SetReceivedFlag( 1 );
	m_edtBeamSize0.SetWindowText( _T("0") );

	m_edtBeamSize1.SetFont( &m_fntEdit );
	m_edtBeamSize1.SetReceivedFlag( 1 );
	m_edtBeamSize1.SetWindowText( _T("0") );

	m_edtBeamSize2.SetFont( &m_fntEdit );
	m_edtBeamSize2.SetReceivedFlag( 1 );
	m_edtBeamSize2.SetWindowText( _T("0") );

	m_edtBeamSize3.SetFont( &m_fntEdit );
	m_edtBeamSize3.SetReceivedFlag( 1 );
	m_edtBeamSize3.SetWindowText( _T("0") );

	m_edtBeamSize4.SetFont( &m_fntEdit );
	m_edtBeamSize4.SetReceivedFlag( 1 );
	m_edtBeamSize4.SetWindowText( _T("0") );

	m_edtBeamSize5.SetFont( &m_fntEdit );
	m_edtBeamSize5.SetReceivedFlag( 1 );
	m_edtBeamSize5.SetWindowText( _T("0") );

	m_edtBeamSize6.SetFont( &m_fntEdit );
	m_edtBeamSize6.SetReceivedFlag( 1 );
	m_edtBeamSize6.SetWindowText( _T("0") );

	m_edtBeamSize7.SetFont( &m_fntEdit );
	m_edtBeamSize7.SetReceivedFlag( 1 );
	m_edtBeamSize7.SetWindowText( _T("0") );

	m_edtBeamSize8.SetFont( &m_fntEdit );
	m_edtBeamSize8.SetReceivedFlag( 1 );
	m_edtBeamSize8.SetWindowText( _T("0") );

	m_edtBeamSize9.SetFont( &m_fntEdit );
	m_edtBeamSize9.SetReceivedFlag( 1 );
	m_edtBeamSize9.SetWindowText( _T("0") );

	// Position
	m_edtPos0.SetFont( &m_fntEdit );
	m_edtPos0.SetReceivedFlag( 3 );
	m_edtPos0.SetWindowText( _T("0.0") );

	m_edtPos1.SetFont( &m_fntEdit );
	m_edtPos1.SetReceivedFlag( 3 );
	m_edtPos1.SetWindowText( _T("0.0") );

	m_edtPos2.SetFont( &m_fntEdit );
	m_edtPos2.SetReceivedFlag( 3 );
	m_edtPos2.SetWindowText( _T("0.0") );

	m_edtPos3.SetFont( &m_fntEdit );
	m_edtPos3.SetReceivedFlag( 3 );
	m_edtPos3.SetWindowText( _T("0.0") );

	m_edtPos4.SetFont( &m_fntEdit );
	m_edtPos4.SetReceivedFlag( 3 );
	m_edtPos4.SetWindowText( _T("0.0") );

	m_edtPos5.SetFont( &m_fntEdit );
	m_edtPos5.SetReceivedFlag( 3 );
	m_edtPos5.SetWindowText( _T("0.0") );

	m_edtPos6.SetFont( &m_fntEdit );
	m_edtPos6.SetReceivedFlag( 3 );
	m_edtPos6.SetWindowText( _T("0.0") );

	m_edtPos7.SetFont( &m_fntEdit );
	m_edtPos7.SetReceivedFlag( 3 );
	m_edtPos7.SetWindowText( _T("0.0") );

	m_edtPos8.SetFont( &m_fntEdit );
	m_edtPos8.SetReceivedFlag( 3 );
	m_edtPos8.SetWindowText( _T("0.0") );

	m_edtPos9.SetFont( &m_fntEdit );
	m_edtPos9.SetReceivedFlag( 3 );
	m_edtPos9.SetWindowText( _T("0.0") );

	// Position2 
	m_edtPos0_2.SetFont( &m_fntEdit );
	m_edtPos0_2.SetReceivedFlag( 3 );
	m_edtPos0_2.SetWindowText( _T("0.0") );
	
	m_edtPos1_2.SetFont( &m_fntEdit );
	m_edtPos1_2.SetReceivedFlag( 3 );
	m_edtPos1_2.SetWindowText( _T("0.0") );
	
	m_edtPos2_2.SetFont( &m_fntEdit );
	m_edtPos2_2.SetReceivedFlag( 3 );
	m_edtPos2_2.SetWindowText( _T("0.0") );
	
	m_edtPos3_2.SetFont( &m_fntEdit );
	m_edtPos3_2.SetReceivedFlag( 3 );
	m_edtPos3_2.SetWindowText( _T("0.0") );
	
	m_edtPos4_2.SetFont( &m_fntEdit );
	m_edtPos4_2.SetReceivedFlag( 3 );
	m_edtPos4_2.SetWindowText( _T("0.0") );
	
	m_edtPos5_2.SetFont( &m_fntEdit );
	m_edtPos5_2.SetReceivedFlag( 3 );
	m_edtPos5_2.SetWindowText( _T("0.0") );
	
	m_edtPos6_2.SetFont( &m_fntEdit );
	m_edtPos6_2.SetReceivedFlag( 3 );
	m_edtPos6_2.SetWindowText( _T("0.0") );
	
	m_edtPos7_2.SetFont( &m_fntEdit );
	m_edtPos7_2.SetReceivedFlag( 3 );
	m_edtPos7_2.SetWindowText( _T("0.0") );
	
	m_edtPos8_2.SetFont( &m_fntEdit );
	m_edtPos8_2.SetReceivedFlag( 3 );
	m_edtPos8_2.SetWindowText( _T("0.0") );
	
	m_edtPos9_2.SetFont( &m_fntEdit );
	m_edtPos9_2.SetReceivedFlag( 3 );
	m_edtPos9_2.SetWindowText( _T("0.0") );

	// Mask Position
	m_edtMaskPos0.SetFont( &m_fntEdit );
	m_edtMaskPos0.SetReceivedFlag( 3 );
	m_edtMaskPos0.SetWindowText( _T("0.0") );

	m_edtMaskPos1.SetFont( &m_fntEdit );
	m_edtMaskPos1.SetReceivedFlag( 3 );
	m_edtMaskPos1.SetWindowText( _T("0.0") );

	m_edtMaskPos2.SetFont( &m_fntEdit );
	m_edtMaskPos2.SetReceivedFlag( 3 );
	m_edtMaskPos2.SetWindowText( _T("0.0") );

	m_edtMaskPos3.SetFont( &m_fntEdit );
	m_edtMaskPos3.SetReceivedFlag( 3 );
	m_edtMaskPos3.SetWindowText( _T("0.0") );

	m_edtMaskPos4.SetFont( &m_fntEdit );
	m_edtMaskPos4.SetReceivedFlag( 3 );
	m_edtMaskPos4.SetWindowText( _T("0.0") );

	m_edtMaskPos5.SetFont( &m_fntEdit );
	m_edtMaskPos5.SetReceivedFlag( 3 );
	m_edtMaskPos5.SetWindowText( _T("0.0") );

	m_edtMaskPos6.SetFont( &m_fntEdit );
	m_edtMaskPos6.SetReceivedFlag( 3 );
	m_edtMaskPos6.SetWindowText( _T("0.0") );

	m_edtMaskPos7.SetFont( &m_fntEdit );
	m_edtMaskPos7.SetReceivedFlag( 3 );
	m_edtMaskPos7.SetWindowText( _T("0.0") );

	m_edtMaskPos8.SetFont( &m_fntEdit );
	m_edtMaskPos8.SetReceivedFlag( 3 );
	m_edtMaskPos8.SetWindowText( _T("0.0") );

	m_edtMaskPos9.SetFont( &m_fntEdit );
	m_edtMaskPos9.SetReceivedFlag( 3 );
	m_edtMaskPos9.SetWindowText( _T("0.0") );

	// Mask DUty
	m_edtMaskDuty0.SetFont( &m_fntEdit );
	m_edtMaskDuty0.SetReceivedFlag( 3 );
	m_edtMaskDuty0.SetWindowText( _T("0") );
	
	m_edtMaskDuty1.SetFont( &m_fntEdit );
	m_edtMaskDuty1.SetReceivedFlag( 3 );
	m_edtMaskDuty1.SetWindowText( _T("0") );

	m_edtMaskDuty2.SetFont( &m_fntEdit );
	m_edtMaskDuty2.SetReceivedFlag( 3 );
	m_edtMaskDuty2.SetWindowText( _T("0") );

	m_edtMaskDuty3.SetFont( &m_fntEdit );
	m_edtMaskDuty3.SetReceivedFlag( 3 );
	m_edtMaskDuty3.SetWindowText( _T("0") );

	m_edtMaskDuty4.SetFont( &m_fntEdit );
	m_edtMaskDuty4.SetReceivedFlag( 3 );
	m_edtMaskDuty4.SetWindowText( _T("0") );

	m_edtMaskDuty5.SetFont( &m_fntEdit );
	m_edtMaskDuty5.SetReceivedFlag( 3 );
	m_edtMaskDuty5.SetWindowText( _T("0") );

	m_edtMaskDuty6.SetFont( &m_fntEdit );
	m_edtMaskDuty6.SetReceivedFlag( 3 );
	m_edtMaskDuty6.SetWindowText( _T("0") );

	m_edtMaskDuty7.SetFont( &m_fntEdit );
	m_edtMaskDuty7.SetReceivedFlag( 3 );
	m_edtMaskDuty7.SetWindowText( _T("0") );

	m_edtMaskDuty8.SetFont( &m_fntEdit );
	m_edtMaskDuty8.SetReceivedFlag( 3 );
	m_edtMaskDuty8.SetWindowText( _T("0") );

	m_edtMaskDuty9.SetFont( &m_fntEdit );
	m_edtMaskDuty9.SetReceivedFlag( 3 );
	m_edtMaskDuty9.SetWindowText( _T("0") );

	// Mask AOM delay
	m_edtMaskAOMDelay0.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay0.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay0.SetWindowText( _T("0") );
	
	m_edtMaskAOMDelay1.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay1.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay1.SetWindowText( _T("0") );

	m_edtMaskAOMDelay2.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay2.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay2.SetWindowText( _T("0") );

	m_edtMaskAOMDelay3.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay3.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay3.SetWindowText( _T("0") );

	m_edtMaskAOMDelay4.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay4.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay4.SetWindowText( _T("0") );

	m_edtMaskAOMDelay5.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay5.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay5.SetWindowText( _T("0") );

	m_edtMaskAOMDelay6.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay6.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay6.SetWindowText( _T("0") );

	m_edtMaskAOMDelay7.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay7.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay7.SetWindowText( _T("0") );

	m_edtMaskAOMDelay8.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay8.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay8.SetWindowText( _T("0") );

	m_edtMaskAOMDelay9.SetFont( &m_fntEdit );
	m_edtMaskAOMDelay9.SetReceivedFlag( 3 );
	m_edtMaskAOMDelay9.SetWindowText( _T("0") );

	// Mask AOM duty
	m_edtMaskAOMDuty0.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty0.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty0.SetWindowText( _T("0") );
	
	m_edtMaskAOMDuty1.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty1.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty1.SetWindowText( _T("0") );

	m_edtMaskAOMDuty2.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty2.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty2.SetWindowText( _T("0") );

	m_edtMaskAOMDuty3.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty3.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty3.SetWindowText( _T("0") );

	m_edtMaskAOMDuty4.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty4.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty4.SetWindowText( _T("0") );

	m_edtMaskAOMDuty5.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty5.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty5.SetWindowText( _T("0") );

	m_edtMaskAOMDuty6.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty6.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty6.SetWindowText( _T("0") );

	m_edtMaskAOMDuty7.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty7.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty7.SetWindowText( _T("0") );

	m_edtMaskAOMDuty8.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty8.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty8.SetWindowText( _T("0") );

	m_edtMaskAOMDuty9.SetFont( &m_fntEdit );
	m_edtMaskAOMDuty9.SetReceivedFlag( 3 );
	m_edtMaskAOMDuty9.SetWindowText( _T("0") );

		//Power Duty
	m_edtPowerDuty0.SetFont( &m_fntEdit );
	m_edtPowerDuty0.SetReceivedFlag( 3 );
	m_edtPowerDuty0.SetWindowText( _T("0.0") );

	m_edtPowerDuty1.SetFont( &m_fntEdit );
	m_edtPowerDuty1.SetReceivedFlag( 3 );
	m_edtPowerDuty1.SetWindowText( _T("0.0") );

	m_edtPowerDuty2.SetFont( &m_fntEdit );
	m_edtPowerDuty2.SetReceivedFlag( 3 );
	m_edtPowerDuty2.SetWindowText( _T("0.0") );

	m_edtPowerDuty3.SetFont( &m_fntEdit );
	m_edtPowerDuty3.SetReceivedFlag( 3 );
	m_edtPowerDuty3.SetWindowText( _T("0.0") );

	m_edtPowerDuty4.SetFont( &m_fntEdit );
	m_edtPowerDuty4.SetReceivedFlag( 3 );
	m_edtPowerDuty4.SetWindowText( _T("0.0") );

	m_edtPowerDuty5.SetFont( &m_fntEdit );
	m_edtPowerDuty5.SetReceivedFlag( 3 );
	m_edtPowerDuty5.SetWindowText( _T("0.0") );

	m_edtPowerDuty6.SetFont( &m_fntEdit );
	m_edtPowerDuty6.SetReceivedFlag( 3 );
	m_edtPowerDuty6.SetWindowText( _T("0.0") );

	m_edtPowerDuty7.SetFont( &m_fntEdit );
	m_edtPowerDuty7.SetReceivedFlag( 3 );
	m_edtPowerDuty7.SetWindowText( _T("0.0") );

	m_edtPowerDuty8.SetFont( &m_fntEdit );
	m_edtPowerDuty8.SetReceivedFlag( 3 );
	m_edtPowerDuty8.SetWindowText( _T("0.0") );

	m_edtPowerDuty9.SetFont( &m_fntEdit );
	m_edtPowerDuty9.SetReceivedFlag( 3 );
	m_edtPowerDuty9.SetWindowText( _T("0.0") );

	//Power Freq
	m_edtPowerFreq0.SetFont( &m_fntEdit );
	m_edtPowerFreq0.SetReceivedFlag( 1 );
	m_edtPowerFreq0.SetWindowText( _T("0") );

	m_edtPowerFreq1.SetFont( &m_fntEdit );
	m_edtPowerFreq1.SetReceivedFlag( 1 );
	m_edtPowerFreq1.SetWindowText( _T("0") );

	m_edtPowerFreq2.SetFont( &m_fntEdit );
	m_edtPowerFreq2.SetReceivedFlag( 1 );
	m_edtPowerFreq2.SetWindowText( _T("0") );

	m_edtPowerFreq3.SetFont( &m_fntEdit );
	m_edtPowerFreq3.SetReceivedFlag( 1 );
	m_edtPowerFreq3.SetWindowText( _T("0") );

	m_edtPowerFreq4.SetFont( &m_fntEdit );
	m_edtPowerFreq4.SetReceivedFlag( 1 );
	m_edtPowerFreq4.SetWindowText( _T("0") );

	m_edtPowerFreq5.SetFont( &m_fntEdit );
	m_edtPowerFreq5.SetReceivedFlag( 1 );
	m_edtPowerFreq5.SetWindowText( _T("0") );

	m_edtPowerFreq6.SetFont( &m_fntEdit );
	m_edtPowerFreq6.SetReceivedFlag( 1 );
	m_edtPowerFreq6.SetWindowText( _T("0") );

	m_edtPowerFreq7.SetFont( &m_fntEdit );
	m_edtPowerFreq7.SetReceivedFlag( 1 );
	m_edtPowerFreq7.SetWindowText( _T("0") );

	m_edtPowerFreq8.SetFont( &m_fntEdit );
	m_edtPowerFreq8.SetReceivedFlag( 1 );
	m_edtPowerFreq8.SetWindowText( _T("0") );

	m_edtPowerFreq9.SetFont( &m_fntEdit );
	m_edtPowerFreq9.SetReceivedFlag( 1 );
	m_edtPowerFreq9.SetWindowText( _T("0") );

	//Power A1
	m_edtPowerA1_0.SetFont( &m_fntEdit );
	m_edtPowerA1_0.SetReceivedFlag( 1 );
	m_edtPowerA1_0.SetWindowText( _T("0") );

	m_edtPowerA1_1.SetFont( &m_fntEdit );
	m_edtPowerA1_1.SetReceivedFlag( 1 );
	m_edtPowerA1_1.SetWindowText( _T("0") );

	m_edtPowerA1_2.SetFont( &m_fntEdit );
	m_edtPowerA1_2.SetReceivedFlag( 1 );
	m_edtPowerA1_2.SetWindowText( _T("0") );

	m_edtPowerA1_3.SetFont( &m_fntEdit );
	m_edtPowerA1_3.SetReceivedFlag( 1 );
	m_edtPowerA1_3.SetWindowText( _T("0") );

	m_edtPowerA1_4.SetFont( &m_fntEdit );
	m_edtPowerA1_4.SetReceivedFlag( 1 );
	m_edtPowerA1_4.SetWindowText( _T("0") );

	m_edtPowerA1_5.SetFont( &m_fntEdit );
	m_edtPowerA1_5.SetReceivedFlag( 1 );
	m_edtPowerA1_5.SetWindowText( _T("0") );

	m_edtPowerA1_6.SetFont( &m_fntEdit );
	m_edtPowerA1_6.SetReceivedFlag( 1 );
	m_edtPowerA1_6.SetWindowText( _T("0") );

	m_edtPowerA1_7.SetFont( &m_fntEdit );
	m_edtPowerA1_7.SetReceivedFlag( 1 );
	m_edtPowerA1_7.SetWindowText( _T("0") );

	m_edtPowerA1_8.SetFont( &m_fntEdit );
	m_edtPowerA1_8.SetReceivedFlag( 1 );
	m_edtPowerA1_8.SetWindowText( _T("0") );

	m_edtPowerA1_9.SetFont( &m_fntEdit );
	m_edtPowerA1_9.SetReceivedFlag( 1 );
	m_edtPowerA1_9.SetWindowText( _T("0") );

	//Power A2
	m_edtPowerA2_0.SetFont( &m_fntEdit );
	m_edtPowerA2_0.SetReceivedFlag( 1 );
	m_edtPowerA2_0.SetWindowText( _T("0") );
	
	m_edtPowerA2_1.SetFont( &m_fntEdit );
	m_edtPowerA2_1.SetReceivedFlag( 1 );
	m_edtPowerA2_1.SetWindowText( _T("0") );
	
	m_edtPowerA2_2.SetFont( &m_fntEdit );
	m_edtPowerA2_2.SetReceivedFlag( 1 );
	m_edtPowerA2_2.SetWindowText( _T("0") );
	
	m_edtPowerA2_3.SetFont( &m_fntEdit );
	m_edtPowerA2_3.SetReceivedFlag( 1 );
	m_edtPowerA2_3.SetWindowText( _T("0") );
	
	m_edtPowerA2_4.SetFont( &m_fntEdit );
	m_edtPowerA2_4.SetReceivedFlag( 1 );
	m_edtPowerA2_4.SetWindowText( _T("0") );
	
	m_edtPowerA2_5.SetFont( &m_fntEdit );
	m_edtPowerA2_5.SetReceivedFlag( 1 );
	m_edtPowerA2_5.SetWindowText( _T("0") );
	
	m_edtPowerA2_6.SetFont( &m_fntEdit );
	m_edtPowerA2_6.SetReceivedFlag( 1 );
	m_edtPowerA2_6.SetWindowText( _T("0") );
	
	m_edtPowerA2_7.SetFont( &m_fntEdit );
	m_edtPowerA2_7.SetReceivedFlag( 1 );
	m_edtPowerA2_7.SetWindowText( _T("0") );
	
	m_edtPowerA2_8.SetFont( &m_fntEdit );
	m_edtPowerA2_8.SetReceivedFlag( 1 );
	m_edtPowerA2_8.SetWindowText( _T("0") );
	
	m_edtPowerA2_9.SetFont( &m_fntEdit );
	m_edtPowerA2_9.SetReceivedFlag( 1 );
	m_edtPowerA2_9.SetWindowText( _T("0") );

	// Memo
	m_edtMemo_0.SetFont( &m_fntEdit2 );
	m_edtMemo_0.SetForeColor( BLACK_COLOR );
	m_edtMemo_0.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_1.SetFont( &m_fntEdit2 );
	m_edtMemo_1.SetForeColor( BLACK_COLOR );
	m_edtMemo_1.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_2.SetFont( &m_fntEdit2 );
	m_edtMemo_2.SetForeColor( BLACK_COLOR );
	m_edtMemo_2.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_3.SetFont( &m_fntEdit2 );
	m_edtMemo_3.SetForeColor( BLACK_COLOR );
	m_edtMemo_3.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_4.SetFont( &m_fntEdit2 );
	m_edtMemo_4.SetForeColor( BLACK_COLOR );
	m_edtMemo_4.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_5.SetFont( &m_fntEdit2 );
	m_edtMemo_5.SetForeColor( BLACK_COLOR );
	m_edtMemo_5.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_6.SetFont( &m_fntEdit2 );
	m_edtMemo_6.SetForeColor( BLACK_COLOR );
	m_edtMemo_6.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_7.SetFont( &m_fntEdit2 );
	m_edtMemo_7.SetForeColor( BLACK_COLOR );
	m_edtMemo_7.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_8.SetFont( &m_fntEdit2 );
	m_edtMemo_8.SetForeColor( BLACK_COLOR );
	m_edtMemo_8.SetBackColor( WHITE_COLOR );
	
	m_edtMemo_9.SetFont( &m_fntEdit2 );
	m_edtMemo_9.SetForeColor( BLACK_COLOR );
	m_edtMemo_9.SetBackColor( WHITE_COLOR );
}

void CPaneSysSetupTophat::SetSystemTophat( SSYSTEMTOPHAT sSystemTophat )
{
	memcpy( &m_sSystemTophat, &sSystemTophat, sizeof(m_sSystemTophat) );
	
	DispSystemTophat();

}

void CPaneSysSetupTophat::GetSystemTophat(SSYSTEMTOPHAT* sSystemTophat)
{
	memcpy( sSystemTophat, &m_sSystemTophat, sizeof(m_sSystemTophat) );	
}

void CPaneSysSetupTophat::DispSystemTophat()
{
	CString strData;
	
	// 0
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[0].dPositon);
	m_edtPos0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[0].dPositon);
	m_edtPos0_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[0]);
	m_edtMaskPos0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[0] / 100.0);
	m_edtMaskDuty0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[0] / 100.0);
	m_edtMaskAOMDelay0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[0] / 100.0);
	m_edtMaskAOMDuty0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[0]);
	m_edtMaskSize0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[0]);
	m_edtBeamSize0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[0]);
	m_edtPowerDuty0.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[0]);
	m_edtPowerFreq0.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[0]);
	m_edtPowerA1_0.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[0]);
	m_edtPowerA2_0.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[0].szMemo);
	m_edtMemo_0.SetWindowText( (LPCTSTR)strData );

	// 1
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[1].dPositon);
	m_edtPos1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[1].dPositon);
	m_edtPos1_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[1]);
	m_edtMaskPos1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[1] / 100.0);
	m_edtMaskDuty1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[1] / 100.0);
	m_edtMaskAOMDelay1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[1] / 100.0);
	m_edtMaskAOMDuty1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[1]);
	m_edtMaskSize1.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[1]);
	m_edtBeamSize1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[1]);
	m_edtPowerDuty1.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[1]);
	m_edtPowerFreq1.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[1]);
	m_edtPowerA1_1.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[1]);
	m_edtPowerA2_1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[1].szMemo);
	m_edtMemo_1.SetWindowText( (LPCTSTR)strData );

	// 2
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[2].dPositon);
	m_edtPos2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[2].dPositon);
	m_edtPos2_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[2]);
	m_edtMaskPos2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[2] / 100.0);
	m_edtMaskDuty2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[2] / 100.0);
	m_edtMaskAOMDelay2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[2] / 100.0);
	m_edtMaskAOMDuty2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[2]);
	m_edtMaskSize2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[2]);
	m_edtBeamSize2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[2]);
	m_edtPowerDuty2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[2]);
	m_edtPowerFreq2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[2]);
	m_edtPowerA1_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[2]);
	m_edtPowerA2_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[2].szMemo);
	m_edtMemo_2.SetWindowText( (LPCTSTR)strData );

	// 3
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[3].dPositon);
	m_edtPos3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[3].dPositon);
	m_edtPos3_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[3]);
	m_edtMaskPos3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[3] / 100.0);
	m_edtMaskDuty3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[3] / 100.0);
	m_edtMaskAOMDelay3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[3] / 100.0);
	m_edtMaskAOMDuty3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[3]);
	m_edtMaskSize3.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[3]);
	m_edtBeamSize3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[3]);
	m_edtPowerDuty3.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[3]);
	m_edtPowerFreq3.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[3]);
	m_edtPowerA1_3.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[3]);
	m_edtPowerA2_3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[3].szMemo);
	m_edtMemo_3.SetWindowText( (LPCTSTR)strData );

	// 4
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[4].dPositon);
	m_edtPos4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[4].dPositon);
	m_edtPos4_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[4]);
	m_edtMaskPos4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[4] / 100.0);
	m_edtMaskDuty4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[4] / 100.0);
	m_edtMaskAOMDelay4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[4] / 100.0);
	m_edtMaskAOMDuty4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[4]);
	m_edtMaskSize4.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[4]);
	m_edtBeamSize4.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[4]);
	m_edtPowerDuty4.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[4]);
	m_edtPowerFreq4.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[4]);
	m_edtPowerA1_4.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[4]);
	m_edtPowerA2_4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[4].szMemo);
	m_edtMemo_4.SetWindowText( (LPCTSTR)strData );

	// 5
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[5].dPositon);
	m_edtPos5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[5].dPositon);
	m_edtPos5_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[5]);
	m_edtMaskPos5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[5] / 100.0);
	m_edtMaskDuty5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[5] / 100.0);
	m_edtMaskAOMDelay5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[5] / 100.0);
	m_edtMaskAOMDuty5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[5]);
	m_edtMaskSize5.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[5]);
	m_edtBeamSize5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[5]);
	m_edtPowerDuty5.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[5]);
	m_edtPowerFreq5.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[5]);
	m_edtPowerA1_5.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[5]);
	m_edtPowerA2_5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[5].szMemo);
	m_edtMemo_5.SetWindowText( (LPCTSTR)strData );

	// 6
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[6].dPositon);
	m_edtPos6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[6].dPositon);
	m_edtPos6_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[6]);
	m_edtMaskPos6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[6] / 100.0);
	m_edtMaskDuty6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[6] / 100.0);
	m_edtMaskAOMDelay6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[6] / 100.0);
	m_edtMaskAOMDuty6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[6]);
	m_edtMaskSize6.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[6]);
	m_edtBeamSize6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[6]);
	m_edtPowerDuty6.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[6]);
	m_edtPowerFreq6.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[6]);
	m_edtPowerA1_6.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[6]);
	m_edtPowerA2_6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[6].szMemo);
	m_edtMemo_6.SetWindowText( (LPCTSTR)strData );

	// 7
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[7].dPositon);
	m_edtPos7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[7].dPositon);
	m_edtPos7_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[7]);
	m_edtMaskPos7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[7] / 100.0);
	m_edtMaskDuty7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[7] / 100.0);
	m_edtMaskAOMDelay7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[7] / 100.0);
	m_edtMaskAOMDuty7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[7]);
	m_edtMaskSize7.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[7]);
	m_edtBeamSize7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[7]);
	m_edtPowerDuty7.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[7]);
	m_edtPowerFreq7.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[7]);
	m_edtPowerA1_7.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[7]);
	m_edtPowerA2_7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[7].szMemo);
	m_edtMemo_7.SetWindowText( (LPCTSTR)strData );

	// 8
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[8].dPositon);
	m_edtPos8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[8].dPositon);
	m_edtPos8_2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[8]);
	m_edtMaskPos8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[8] / 100.0);
	m_edtMaskDuty8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[8] / 100.0);
	m_edtMaskAOMDelay8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[8] / 100.0);
	m_edtMaskAOMDuty8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[8]);
	m_edtMaskSize8.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[8]);
	m_edtBeamSize8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[8]);
	m_edtPowerDuty8.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[8]);
	m_edtPowerFreq8.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[8]);
	m_edtPowerA1_8.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[8]);
	m_edtPowerA2_8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%s"), m_sSystemTophat.sMemo[8].szMemo);
	m_edtMemo_8.SetWindowText( (LPCTSTR)strData );

	// 9
	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos[9].dPositon);
	m_edtPos9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.sCollimatorPos2[9].dPositon);
	m_edtPos9_2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.0f"), m_sSystemTophat.dMaskPosition[9]);
	m_edtMaskPos9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nDutyOffset[9] / 100.0);
	m_edtMaskDuty9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDelayOffset[9] / 100.0);
	m_edtMaskAOMDelay9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemTophat.nAOMDutyOffset[9] / 100.0);
	m_edtMaskAOMDuty9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dMaskSize[9]);
	m_edtMaskSize9.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dBeamSize[9]);
	m_edtBeamSize9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemTophat.dPowerDuty[9]);
	m_edtPowerDuty9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%d"), m_sSystemTophat.nPowerFreq[9]);
	m_edtPowerFreq9.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator1[9]);
	m_edtPowerA1_9.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.0f"), m_sSystemTophat.dAttenuator2[9]);
	m_edtPowerA2_9.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%s"), m_sSystemTophat.sMemo[9].szMemo);
	m_edtMemo_9.SetWindowText( (LPCTSTR)strData );
}

void CPaneSysSetupTophat::OnApply()
{
	CString strData;
	
	// 0
	m_edtPos0.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[0].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos0_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[0].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos0.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[0] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty0.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[0] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay0.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[0] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty0.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[0] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize0.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[0] = atof( (LPSTR)(LPCTSTR)strData);

	m_edtBeamSize0.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[0] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty0.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[0] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq0.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[0] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_0.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[0] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_0.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[0] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_0.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[0].szMemo, 1024, _T("%s"), strData );

	// 1
	m_edtPos1.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[1].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos1_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[1].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos1.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[1] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty1.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[1] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay1.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[1] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty1.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[1] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize1.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[1] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize1.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[1] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty1.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[1] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq1.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[1] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_1.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[1] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_1.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[1] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_1.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[1].szMemo, 1024, _T("%s"), strData );

	// 2
	m_edtPos2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[2].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos2_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[2].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos2.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[2] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty2.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[2] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay2.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[2] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty2.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[2] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize2.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[2] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize2.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[2] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty2.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[2] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq2.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[2] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_2.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[2] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_2.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[2] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_2.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[2].szMemo, 1024, _T("%s"), strData );

	// 3
	m_edtPos3.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[3].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos3_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[3].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos3.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[3] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty3.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[3] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay3.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[3] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty3.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[3] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize3.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[3] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize3.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[3] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty3.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[3] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq3.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[3] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_3.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[3] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_3.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[3] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_3.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[3].szMemo, 1024, _T("%s"), strData );

	// 4
	m_edtPos4.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[4].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos4_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[4].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos4.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[4] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty4.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[4] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay4.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[4] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty4.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[4] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize4.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[4] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize4.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[4] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty4.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[4] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq4.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[4] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_4.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[4] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_4.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[4] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_4.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[4].szMemo,1024, _T("%s"), strData );

	// 5
	m_edtPos5.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[5].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos5_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[5].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos5.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[5] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty5.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[5] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay5.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[5] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty5.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[5] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize5.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[5] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize5.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[5] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty5.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[5] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq5.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[5] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_5.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[5] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_5.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[5] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_5.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[5].szMemo, 1024, _T("%s"), strData );

	// 6
	m_edtPos6.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[6].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos6_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[6].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos6.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[6] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty6.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[6] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay6.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[6] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty6.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[6] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize6.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[6] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize6.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[6] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty6.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[6] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq6.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[6] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_6.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[6] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_6.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[6] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_6.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[6].szMemo, _T("%s"), strData );

	// 7
	m_edtPos7.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[7].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos7_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[7].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos7.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[7] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty7.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[7] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay7.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[7] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty7.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[7] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize7.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[7] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize7.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[7] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty7.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[7] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq7.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[7] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_7.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[7] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_7.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[7] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_7.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[7].szMemo, 1024, _T("%s"), strData );

	// 8
	m_edtPos8.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[8].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos8_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[8].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos8.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[8] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty8.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[8] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay8.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[8] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty8.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[8] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize8.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[8] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize8.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[8] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty8.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[8] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerFreq8.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[8] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_8.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[8] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_8.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[8] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_8.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[8].szMemo, 0124, _T("%s"), strData );

	// 9
	m_edtPos9.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos[9].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPos9_2.GetWindowText( strData );
	m_sSystemTophat.sCollimatorPos2[9].dPositon = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskPos9.GetWindowText( strData );
	m_sSystemTophat.dMaskPosition[9] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMaskDuty9.GetWindowText( strData );
	m_sSystemTophat.nDutyOffset[9] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDelay9.GetWindowText( strData );
	m_sSystemTophat.nAOMDelayOffset[9] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskAOMDuty9.GetWindowText( strData );
	m_sSystemTophat.nAOMDutyOffset[9] = (int)(atof( (LPSTR)(LPCTSTR)strData ) * 100);

	m_edtMaskSize9.GetWindowText( strData );
	m_sSystemTophat.dMaskSize[9] = atof( (LPSTR)(LPCTSTR)strData);
	
	m_edtBeamSize9.GetWindowText( strData );
	m_sSystemTophat.dBeamSize[9] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerDuty9.GetWindowText( strData );
	m_sSystemTophat.dPowerDuty[9] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPowerFreq9.GetWindowText( strData );
	m_sSystemTophat.nPowerFreq[9] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA1_9.GetWindowText( strData );
	m_sSystemTophat.dAttenuator1[9] = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtPowerA2_9.GetWindowText( strData );
	m_sSystemTophat.dAttenuator2[9] = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtMemo_9.GetWindowText( strData );
	_stprintf_s( m_sSystemTophat.sMemo[9].szMemo, 1024, _T("%s"), strData );
}

CString CPaneSysSetupTophat::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	
	// 0
	for(int i = 0; i < 10; i++)
	{
		if(m_sSystemTophat.sCollimatorPos[i].dPositon != gSystemINI.m_sSystemTophat.sCollimatorPos[i].dPositon ||
			m_sSystemTophat.sCollimatorPos2[i].dPositon != gSystemINI.m_sSystemTophat.sCollimatorPos2[i].dPositon ||
			m_sSystemTophat.dMaskPosition[i] != gSystemINI.m_sSystemTophat.dMaskPosition[i] ||
			m_sSystemTophat.nDutyOffset[i] != gSystemINI.m_sSystemTophat.nDutyOffset[i] ||
			m_sSystemTophat.dPowerDuty[i] != gSystemINI.m_sSystemTophat.dPowerDuty[i] ||
			m_sSystemTophat.nPowerFreq[i] != gSystemINI.m_sSystemTophat.nPowerFreq[i] ||
			m_sSystemTophat.dAttenuator1[i] != gSystemINI.m_sSystemTophat.dAttenuator1[i] ||
			m_sSystemTophat.dAttenuator2[i] != gSystemINI.m_sSystemTophat.dAttenuator2[i])
		{
			strTemp.Format(_T("| %d : ( %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.0f, %.0f "), 
				i,
				m_sSystemTophat.sCollimatorPos[i].dPositon,
				m_sSystemTophat.sCollimatorPos2[i].dPositon,
				m_sSystemTophat.dMaskPosition[i],
				m_sSystemTophat.nDutyOffset[i]/100.0,
				m_sSystemTophat.dPowerDuty[i],
				m_sSystemTophat.nPowerFreq[i],
				m_sSystemTophat.dAttenuator1[i],
				m_sSystemTophat.dAttenuator2[i]);
			strMessage += strTemp;
		}
	}
	
	strTemp.Format(_T(" )"));
	strMessage += strTemp;
	
	return strMessage;
}

void CPaneSysSetupTophat::OnDestroy() 
{
	CFormView::OnDestroy();
	m_fntStatic.DeleteObject();
	m_fntStatic2.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntBtn.DeleteObject();	
}

HBRUSH CPaneSysSetupTophat::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_POS_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MASK_DUTY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MASK_BEAM_SIZE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POWER_COMPENSATION2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MEMO)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
