// DlgVisionPixelSet.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgVisionPixelSet.h"
#include "..\model\dsystemini.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionPixelSet dialog


CDlgVisionPixelSet::CDlgVisionPixelSet(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVisionPixelSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgVisionPixelSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	for(int i = 0; i < MAX_CAMERA; i++)
	{
		for(int j = 0 ; j < 4; j++ ) //position
		{
			m_dOriPos[i][j].x = 0;
			m_dOriPos[i][j].y = 0;
			m_dTransPos[i][j].x = 0;
			m_dTransPos[i][j].y = 0;

			if(j == 1)
			{
				m_dOriPos[i][j].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
				m_dTransPos[i][j].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
			}
			if(j == 2)
			{
				m_dOriPos[i][j].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
				m_dTransPos[i][j].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
			}
			if(j == 3)
			{
				m_dOriPos[i][j].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
				m_dTransPos[i][j].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
				m_dOriPos[i][j].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
				m_dTransPos[i][j].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
			}
		}
	}
	m_nCamNo = 0;
}


void CDlgVisionPixelSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgVisionPixelSet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_EDIT_1_POS_X1, m_edtPos1X1);
	DDX_Control(pDX, IDC_EDIT_1_POS_Y1, m_edtPos1Y1);
	DDX_Control(pDX, IDC_EDIT_1_POS_X2, m_edtPos1X2);
	DDX_Control(pDX, IDC_EDIT_1_POS_Y2, m_edtPos1Y2);
	DDX_Control(pDX, IDC_EDIT_2_POS_X1, m_edtPos2X1);
	DDX_Control(pDX, IDC_EDIT_2_POS_Y1, m_edtPos2Y1);
	DDX_Control(pDX, IDC_EDIT_2_POS_X2, m_edtPos2X2);
	DDX_Control(pDX, IDC_EDIT_2_POS_Y2, m_edtPos2Y2);
	DDX_Control(pDX, IDC_EDIT_3_POS_X1, m_edtPos3X1);
	DDX_Control(pDX, IDC_EDIT_3_POS_Y1, m_edtPos3Y1);
	DDX_Control(pDX, IDC_EDIT_3_POS_X2, m_edtPos3X2);
	DDX_Control(pDX, IDC_EDIT_3_POS_Y2, m_edtPos3Y2);
	DDX_Control(pDX, IDC_EDIT_4_POS_X1, m_edtPos4X1);
	DDX_Control(pDX, IDC_EDIT_4_POS_Y1, m_edtPos4Y1);
	DDX_Control(pDX, IDC_EDIT_4_POS_X2, m_edtPos4X2);
	DDX_Control(pDX, IDC_EDIT_4_POS_Y2, m_edtPos4Y2);
	DDX_Control(pDX, IDC_BUTTON_UPDATE1, m_btnUpdate);
	DDX_Control(pDX, IDC_BUTTON_INIT, m_btnInit);
	DDX_Control(pDX, IDOK, m_btnApply);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_COMBO_CAM, m_cmbCam);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgVisionPixelSet, CDialog)
	//{{AFX_MSG_MAP(CDlgVisionPixelSet)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE1, OnButtonUpdate)
	ON_BN_CLICKED(IDC_BUTTON_INIT, OnButtonInit)
	ON_CBN_EDITCHANGE(IDC_COMBO_CAM, OnEditchangeComboCam)
	ON_CBN_SELCHANGE(IDC_COMBO_CAM, OnSelchangeComboCam)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionPixelSet message handlers

BOOL CDlgVisionPixelSet::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();

	DispPosData();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgVisionPixelSet::InitBtnControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnInit.SetFont( &m_fntBtn );
	m_btnInit.SetFlat( FALSE );
	m_btnInit.SetImageOrg( 8, 3 );
	m_btnInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInit.EnableBallonToolTip();
	m_btnInit.SetToolTipText( _T("Initialize") );
	m_btnInit.SetBtnCursor(IDC_HAND_1);

	m_btnUpdate.SetFont( &m_fntBtn );
	m_btnUpdate.SetFlat( FALSE );
	m_btnUpdate.SetImageOrg( 8, 3 );
	m_btnUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdate.EnableBallonToolTip();
	m_btnUpdate.SetToolTipText( _T("Update") );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);

	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.SetImageOrg( 8, 3 );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetImageOrg( 8, 3 );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	m_cmbCam.SetFont( &m_fntBtn );
	m_cmbCam.SetCurSel(0);
	

}

void CDlgVisionPixelSet::InitEditControl()
{
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtPos1X1.SetFont( &m_fntEdit );
	m_edtPos1X1.SetForeColor( BLACK_COLOR );
	m_edtPos1X1.SetBackColor( WHITE_COLOR );
	m_edtPos1X1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos1X1.SetWindowText( "0" ); 

	m_edtPos1Y1.SetFont( &m_fntEdit );
	m_edtPos1Y1.SetForeColor( BLACK_COLOR );
	m_edtPos1Y1.SetBackColor( WHITE_COLOR );
	m_edtPos1Y1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos1Y1.SetWindowText( "0" ); 

	m_edtPos1X2.SetFont( &m_fntEdit );
	m_edtPos1X2.SetForeColor( BLACK_COLOR );
	m_edtPos1X2.SetBackColor( WHITE_COLOR );
	m_edtPos1X2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos1X2.SetWindowText( "0" ); 

	m_edtPos1Y2.SetFont( &m_fntEdit );
	m_edtPos1Y2.SetForeColor( BLACK_COLOR );
	m_edtPos1Y2.SetBackColor( WHITE_COLOR );
	m_edtPos1Y2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos1Y2.SetWindowText( "0" ); 

	m_edtPos2X1.SetFont( &m_fntEdit );
	m_edtPos2X1.SetForeColor( BLACK_COLOR );
	m_edtPos2X1.SetBackColor( WHITE_COLOR );
	m_edtPos2X1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos2X1.SetWindowText( "0" ); 
	
	m_edtPos2Y1.SetFont( &m_fntEdit );
	m_edtPos2Y1.SetForeColor( BLACK_COLOR );
	m_edtPos2Y1.SetBackColor( WHITE_COLOR );
	m_edtPos2Y1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos2Y1.SetWindowText( "0" ); 
	
	m_edtPos2X2.SetFont( &m_fntEdit );
	m_edtPos2X2.SetForeColor( BLACK_COLOR );
	m_edtPos2X2.SetBackColor( WHITE_COLOR );
	m_edtPos2X2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos2X2.SetWindowText( "0" ); 
	
	m_edtPos2Y2.SetFont( &m_fntEdit );
	m_edtPos2Y2.SetForeColor( BLACK_COLOR );
	m_edtPos2Y2.SetBackColor( WHITE_COLOR );
	m_edtPos2Y2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos2Y2.SetWindowText( "0" ); 

	m_edtPos3X1.SetFont( &m_fntEdit );
	m_edtPos3X1.SetForeColor( BLACK_COLOR );
	m_edtPos3X1.SetBackColor( WHITE_COLOR );
	m_edtPos3X1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos3X1.SetWindowText( "0" ); 
	
	m_edtPos3Y1.SetFont( &m_fntEdit );
	m_edtPos3Y1.SetForeColor( BLACK_COLOR );
	m_edtPos3Y1.SetBackColor( WHITE_COLOR );
	m_edtPos3Y1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos3Y1.SetWindowText( "0" ); 
	
	m_edtPos3X2.SetFont( &m_fntEdit );
	m_edtPos3X2.SetForeColor( BLACK_COLOR );
	m_edtPos3X2.SetBackColor( WHITE_COLOR );
	m_edtPos3X2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos3X2.SetWindowText( "0" ); 
	
	m_edtPos3Y2.SetFont( &m_fntEdit );
	m_edtPos3Y2.SetForeColor( BLACK_COLOR );
	m_edtPos3Y2.SetBackColor( WHITE_COLOR );
	m_edtPos3Y2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos3Y2.SetWindowText( "0" ); 

	m_edtPos4X1.SetFont( &m_fntEdit );
	m_edtPos4X1.SetForeColor( BLACK_COLOR );
	m_edtPos4X1.SetBackColor( WHITE_COLOR );
	m_edtPos4X1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos4X1.SetWindowText( "0" ); 
	
	m_edtPos4Y1.SetFont( &m_fntEdit );
	m_edtPos4Y1.SetForeColor( BLACK_COLOR );
	m_edtPos4Y1.SetBackColor( WHITE_COLOR );
	m_edtPos4Y1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos4Y1.SetWindowText( "0" ); 
	
	m_edtPos4X2.SetFont( &m_fntEdit );
	m_edtPos4X2.SetForeColor( BLACK_COLOR );
	m_edtPos4X2.SetBackColor( WHITE_COLOR );
	m_edtPos4X2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos4X2.SetWindowText( "0" ); 
	
	m_edtPos4Y2.SetFont( &m_fntEdit );
	m_edtPos4Y2.SetForeColor( BLACK_COLOR );
	m_edtPos4Y2.SetBackColor( WHITE_COLOR );
	m_edtPos4Y2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPos4Y2.SetWindowText( "0" ); 


}

void CDlgVisionPixelSet::InitStaticControl()
{
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_CAM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_X1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Y1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Y2)->SetFont( &m_fntStatic );
}

void CDlgVisionPixelSet::SetData(DPOINT* OriPos, DPOINT* TransPos)
{
 	memcpy(&m_dOriPos, OriPos, sizeof(m_dOriPos));
	memcpy(&m_dTransPos, TransPos, sizeof(m_dTransPos));
}

void CDlgVisionPixelSet::GetData(DPOINT *pOriPos, DPOINT *pTransPos)
{
	memcpy(pOriPos, &m_dOriPos, sizeof(m_dOriPos));
	memcpy(pTransPos, &m_dTransPos, sizeof(m_dTransPos));
}

void CDlgVisionPixelSet::DispPosData()
{
	int nCam = m_nCamNo;//m_cmbCam.GetCurSel();
	CString str;
	
	str.Format(_T("%.2f"), m_dOriPos[nCam][0].x);
	m_edtPos1X1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][0].y);
	m_edtPos1Y1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][1].x);
	m_edtPos2X1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][1].y);
	m_edtPos2Y1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][2].x);
	m_edtPos3X1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][2].y);
	m_edtPos3Y1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][3].x);
	m_edtPos4X1.SetWindowText(str);

	str.Format(_T("%.2f"), m_dOriPos[nCam][3].y);
	m_edtPos4Y1.SetWindowText(str);


	str.Format(_T("%.2f"), m_dTransPos[nCam][0].x);
	m_edtPos1X2.SetWindowText(str);

	str.Format(_T("%.2f"), m_dTransPos[nCam][0].y);
	m_edtPos1Y2.SetWindowText(str);

	str.Format(_T("%.2f"), m_dTransPos[nCam][1].x);
	m_edtPos2X2.SetWindowText(str);
	
	str.Format(_T("%.2f"), m_dTransPos[nCam][1].y);
	m_edtPos2Y2.SetWindowText(str);

	str.Format(_T("%.2f"), m_dTransPos[nCam][2].x);
	m_edtPos3X2.SetWindowText(str);
	
	str.Format(_T("%.2f"), m_dTransPos[nCam][2].y);
	m_edtPos3Y2.SetWindowText(str);

	str.Format(_T("%.2f"), m_dTransPos[nCam][3].x);
	m_edtPos4X2.SetWindowText(str);
	
	str.Format(_T("%.2f"), m_dTransPos[nCam][3].y);
	m_edtPos4Y2.SetWindowText(str);
}

void CDlgVisionPixelSet::OnButtonUpdate() 
{
	// TODO: Add your control notification handler code here
	int nCam = m_cmbCam.GetCurSel();
	CString str;

	m_edtPos1X1.GetWindowText(str);
	m_dOriPos[nCam][0].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos1Y1.GetWindowText(str);
	m_dOriPos[nCam][0].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos2X1.GetWindowText(str);
	m_dOriPos[nCam][1].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos2Y1.GetWindowText(str);
	m_dOriPos[nCam][1].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos3X1.GetWindowText(str);
	m_dOriPos[nCam][2].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos3Y1.GetWindowText(str);
	m_dOriPos[nCam][2].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos4X1.GetWindowText(str);
	m_dOriPos[nCam][3].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos4Y1.GetWindowText(str);
	m_dOriPos[nCam][3].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos1X2.GetWindowText(str);
	m_dTransPos[nCam][0].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos1Y2.GetWindowText(str);
	m_dTransPos[nCam][0].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos2X2.GetWindowText(str);
	m_dTransPos[nCam][1].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos2Y2.GetWindowText(str);
	m_dTransPos[nCam][1].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos3X2.GetWindowText(str);
	m_dTransPos[nCam][2].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos3Y2.GetWindowText(str);
	m_dTransPos[nCam][2].y = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos4X2.GetWindowText(str);
	m_dTransPos[nCam][3].x = atof((LPSTR)(LPCTSTR)str);
	
	m_edtPos4Y2.GetWindowText(str);
	m_dTransPos[nCam][3].y = atof((LPSTR)(LPCTSTR)str);
	
}

void CDlgVisionPixelSet::OnButtonInit()
{
	CString strX, strY;
	strX.Format(_T("%d"), gSystemINI.m_sSystemDevice.nCameraPixelX);
	strY.Format(_T("%d"), gSystemINI.m_sSystemDevice.nCameraPixelY);
	for(int nCam = 0; nCam < 4; nCam++)
	{
		m_edtPos1X1.SetWindowText("0");
		m_dOriPos[nCam][0].x = 0;
		m_edtPos1Y1.SetWindowText("0");
		m_dOriPos[nCam][0].y = 0;
		
		m_edtPos2X1.SetWindowText(strX);
		m_dOriPos[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
		m_edtPos2Y1.SetWindowText("0");
		m_dOriPos[nCam][1].y = 0;
		
		m_edtPos3X1.SetWindowText("0");
		m_dOriPos[nCam][2].x = 0;
		m_edtPos3Y1.SetWindowText(strY);
		m_dOriPos[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
		
		m_edtPos4X1.SetWindowText(strX);
		m_dOriPos[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
		m_edtPos4Y1.SetWindowText(strY);
		m_dOriPos[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;

		//
		m_edtPos1X2.SetWindowText("0");
		m_dTransPos[nCam][0].x = 0;
		m_edtPos1Y2.SetWindowText("0");
		m_dTransPos[nCam][0].y = 0;
		
		m_edtPos2X2.SetWindowText(strX);
		m_dTransPos[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
		m_edtPos2Y2.SetWindowText("0");
		m_dTransPos[nCam][1].y = 0;
		
		m_edtPos3X2.SetWindowText("0");
		m_dTransPos[nCam][2].x = 0;
		m_edtPos3Y2.SetWindowText(strY);
		m_dTransPos[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
		
		m_edtPos4X2.SetWindowText(strX);
		m_dTransPos[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX;
		m_edtPos4Y2.SetWindowText(strY);
		m_dTransPos[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	}
}

BOOL CDlgVisionPixelSet::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreCreateWindow(cs);
}

void CDlgVisionPixelSet::OnEditchangeComboCam() 
{
	// TODO: Add your control notification handler code here
}

void CDlgVisionPixelSet::OnSelchangeComboCam() 
{
	// TODO: Add your control notification handler code here
	m_nCamNo = m_cmbCam.GetCurSel();
	DispPosData();
}


BOOL CDlgVisionPixelSet::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_PixelSet) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
