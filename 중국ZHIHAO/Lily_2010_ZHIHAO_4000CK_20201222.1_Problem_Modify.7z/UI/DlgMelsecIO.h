#pragma once
#include "afxwin.h"
#include "..\UI\ColorStatic.h"

// CDlgMelsecIO ��ȭ �����Դϴ�.

class CDlgMelsecIO : public CDialog
{
	DECLARE_DYNAMIC(CDlgMelsecIO)

public:
	CDlgMelsecIO(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgMelsecIO();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_MELSEC_INOUT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();

	void ChangeDisplay();
	void InitStatic();


	CColorStatic m_stc1050;
	CColorStatic m_stc1051;
	CColorStatic m_stc1052;
	CColorStatic m_stc1053;
	CColorStatic m_stc1054;
	CColorStatic m_stc1056;
	CColorStatic m_stc1057;
	CColorStatic m_stc1060_0;
	CColorStatic m_stc1060_1;
	CColorStatic m_stc1060_10;
	CColorStatic m_stc1060_11;
	CColorStatic m_stc1060_12;
	CColorStatic m_stc1060_13;
	CColorStatic m_stc1060_14;
	CColorStatic m_stc1060_15;
	CColorStatic m_stc1060_2;
	CColorStatic m_stc1060_3;
	CColorStatic m_stc1060_4;
	CColorStatic m_stc1060_5;
	CColorStatic m_stc1060_6;
	CColorStatic m_stc1060_7;
	CColorStatic m_stc1060_8;
	CColorStatic m_stc1060_9;
	CColorStatic m_stc1061_0;
	CColorStatic m_stc1061_10;
	CColorStatic m_stc1061_11;
	CColorStatic m_stc1061_14;
	CColorStatic m_stc1061_15;
	CColorStatic m_stc1061_2;
	CColorStatic m_stc1061_3;
	CColorStatic m_stc1061_4;
	CColorStatic m_stc1061_5;
	CColorStatic m_stc1061_6;
	CColorStatic m_stc1061_7;
	CColorStatic m_stc1061_8;
	CColorStatic m_stc1062_0;
	CColorStatic m_stc1062_1;
	CColorStatic m_stc1062_10;
	CColorStatic m_stc1062_11;
	CColorStatic m_stc1062_12;
	CColorStatic m_stc1062_14;
	CColorStatic m_stc1062_15;
	CColorStatic m_stc1062_2;
	CColorStatic m_stc1062_3;
	CColorStatic m_stc1062_6;
	CColorStatic m_stc1062_7;
	CColorStatic m_stc1062_8;
	CColorStatic m_stc1062_9;
	CColorStatic m_stc1063_0;
	CColorStatic m_stc1063_1;
	CColorStatic m_stc1063_10;
	CColorStatic m_stc1063_11;
	CColorStatic m_stc1063_12;
	CColorStatic m_stc1063_13;
	CColorStatic m_stc1063_14;
	CColorStatic m_stc1063_15;
	CColorStatic m_stc1063_2;
	CColorStatic m_stc1063_3;
	CColorStatic m_stc1063_4;
	CColorStatic m_stc1063_5;
	CColorStatic m_stc1063_6;
	CColorStatic m_stc1063_7;
	CColorStatic m_stc1063_8;
	CColorStatic m_stc1063_9;
	CColorStatic m_stc1070;
	CColorStatic m_stc1071;
	CColorStatic m_stc1072;
	CColorStatic m_stc1073;
	CColorStatic m_stc1074;
	CColorStatic m_stc5432;
	CColorStatic m_stc5433;
	CColorStatic m_stc5434;
	CColorStatic m_stc5435;
	CColorStatic m_stc5436;
	CColorStatic m_stc5437;
	CColorStatic m_stc5438;
	CColorStatic m_stc5439;
	CColorStatic m_stc5440;
	CColorStatic m_stc5441;
	CColorStatic m_stc5442;
	CColorStatic m_stc5443;
	CColorStatic m_stc5444;
	CColorStatic m_stc5445;
	CColorStatic m_stc5446;
	CColorStatic m_stc5447;
	CColorStatic m_stc5448;
	CColorStatic m_stc5449;
	CColorStatic m_stc5450;
	CColorStatic m_stc5451;

	int	m_nTimer;
	afx_msg void OnPaint();
};
