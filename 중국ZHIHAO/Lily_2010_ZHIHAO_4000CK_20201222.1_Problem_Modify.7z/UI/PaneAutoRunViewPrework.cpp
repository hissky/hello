// PaneAutoRunViewPrework.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewPrework.h"
#include "PaneAutoRunViewPreworkHeat.h"
#include "PaneAutoRunViewPreworkPower.h"
#include "PaneAutoRunViewPreworkScanner.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT TIMER_DOING_PREWORK = 1001;
/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPrework

IMPLEMENT_DYNCREATE(CPaneAutoRunViewPrework, CFormView)

CPaneAutoRunViewPrework::CPaneAutoRunViewPrework()
	: CFormView(CPaneAutoRunViewPrework::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewPrework)
		// NOTE: the ClassWizard will add member initialization here
	m_nTimer = 0;
	m_bDoPreheat = FALSE;
	m_bDoScanner = FALSE;
	m_bDoPower = FALSE;
	m_bDoDrill = FALSE;
	m_bPreheat = TRUE;
	m_bScanner = TRUE;
	m_bPower = TRUE;
	m_bChangeDisplay = FALSE;
	//}}AFX_DATA_INIT
}

CPaneAutoRunViewPrework::~CPaneAutoRunViewPrework()
{
}

void CPaneAutoRunViewPrework::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewPrework)
	DDX_Control(pDX, IDC_TAB_PREWORK, m_tabPrework);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewPrework, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewPrework)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_NOTIFY(NM_CLICK, IDC_TAB_PREWORK, OnClickTabPrework)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPrework diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewPrework::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewPrework::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPrework message handlers

void CPaneAutoRunViewPrework::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitTabControl();
	InitTimer();
}
void CPaneAutoRunViewPrework::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_PROCESS)->SetFont( &m_fntStatic );
}

void CPaneAutoRunViewPrework::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(110, "Arial Bold");
	
	BOOL bRet = 0;
	
	m_tabPrework.SetFont( &m_fntTab );
	
	bRet = m_tabPrework.AddPane( _T(" PreHeat "), RUNTIME_CLASS(CPaneAutoRunViewPreworkHeat) );
	if( FALSE != bRet )
	{
		m_pPreHeat	= static_cast<CPaneAutoRunViewPreworkHeat*>(m_tabPrework.GetPane(0));
		m_pPreHeat->OnInitialUpdate();
	}
	
	bRet = m_tabPrework.AddPane( _T(" Power "), RUNTIME_CLASS(CPaneAutoRunViewPreworkPower) );
	if( FALSE != bRet )
	{
		m_pPower = static_cast<CPaneAutoRunViewPreworkPower*>(m_tabPrework.GetPane(1));
		m_pPower->OnInitialUpdate();
	}

	bRet = m_tabPrework.AddPane( _T(" Scanner "), RUNTIME_CLASS(CPaneAutoRunViewPreworkScanner) );
	if( FALSE != bRet )
	{
		m_pScanner = static_cast<CPaneAutoRunViewPreworkScanner*>(m_tabPrework.GetPane(2));
		m_pScanner->OnInitialUpdate();
	}

	m_tabPrework.ShowPane(0);
	m_pPreHeat->ChangeDisplay();
}

BOOL CPaneAutoRunViewPrework::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
void CPaneAutoRunViewPrework::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
	{
		m_bChangeDisplay = !m_bChangeDisplay;
		DrawDoingPrework();
		
	}
	CFormView::OnTimer(nIDEvent);
}

void CPaneAutoRunViewPrework::InitTimer()
{
	if(!m_nTimer)
		m_nTimer = SetTimer(TIMER_DOING_PREWORK, 500, NULL);
}

void CPaneAutoRunViewPrework::DestroyTimer()
{
	if(m_nTimer)
	{
		KillTimer(m_nTimer);
		m_nTimer = 0;
	}
}
void CPaneAutoRunViewPrework::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	DrawChart();
}

void CPaneAutoRunViewPrework::DrawChart()
{
	CClientDC dc(GetDlgItem(IDC_STC_PREWORK_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_PREWORK_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	int nPenSize;
	nPenSize = 2;
	
	CPen pen;
	CPen penLine;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(38, 125, 232));
	pOldPen = BufferDC.SelectObject(&pen);
	
	penLine.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 0));

	cBr2.CreateSolidBrush(RGB(255, 255, 255));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	/////////////Draw Flow Chart 
	int nStartLeft = 100;
	int nStartTop = 20;
	int nRectWidth = 170;
	int nRectHeight = 40;
	int nRoundScore = 10;
	int nLine = 20;


	int nLineStartPointX =  nStartLeft + nRectWidth/2;
	int nLineStartPointY = nStartTop + nRectHeight;
	int nLineEndPointX = nLineStartPointX;
	int nLineEndPointY = nLineStartPointY + nLine;

	CPoint ptTemp;	
	//Start
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
	
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "Start Process");
	BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
	BufferDC.LineTo(nLineEndPointX, nLineEndPointY);

		if(m_bPower && m_bPreheat)
		{
			//Power -> preheat line 
			BufferDC.MoveTo(nLineStartPointX, nLineStartPointY + nLine/2);
			BufferDC.LineTo(nLineStartPointX + nRectWidth/2 + 20, nLineStartPointY + nLine/2);
		

			ptTemp.x = nLineStartPointX + nRectWidth/2 + 20;
			ptTemp.y =  nLineStartPointY + nLine/2;
		
			BufferDC.MoveTo(nLineStartPointX, nLineStartPointY + nLine/2);
			BufferDC.LineTo(nLineStartPointX+5, nLineStartPointY + nLine/2 + 3);
			BufferDC.LineTo(nLineStartPointX+5, nLineStartPointY + nLine/2 - 3);
			BufferDC.LineTo(nLineStartPointX, nLineStartPointY + nLine/2);
		}
	
	//PreHeat
	if(m_bPreheat)
	{
		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;
		
		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "PreHeating");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
	}

	//Power Measurement 
	if(m_bPower)
	{
		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;

		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20, nStartTop + 10, "Power Measurement");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
		
		if(m_bPreheat)
		{	//Power -> preheat line
			BufferDC.MoveTo(nStartLeft + nRectWidth, nStartTop + 15);
			BufferDC.LineTo(nStartLeft + nRectWidth + 20, nStartTop + 15);
			BufferDC.LineTo(ptTemp.x, ptTemp.y);
		}
	}
	//Scanner Calibration
	if(m_bScanner)
	{
		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);

		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;
		
		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20, nStartTop + 10, "Scanner Calibration");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
	}

	//Drill
	nStartTop = nLineEndPointY;
	pOldPen = BufferDC.SelectObject(&pen);
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
	
	nLineStartPointY = nStartTop + nRectHeight;
	nLineEndPointY = nLineStartPointY + nLine;
	
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.TextOut(nStartLeft + 20 + 40, nStartTop + 10, "Drilling");
	BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
	BufferDC.LineTo(nLineEndPointX, nLineEndPointY);

	//End 
	nStartTop = nLineEndPointY;
	pOldPen = BufferDC.SelectObject(&pen);
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "End Process");
	//End Flow Chart

	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
}

void CPaneAutoRunViewPrework::DrawDoingPrework()
{
	CClientDC dc(GetDlgItem(IDC_STC_PREWORK_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_PREWORK_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	int nPenSize;
	nPenSize = 2;
	
	CPen pen;
	CPen penLine;
	CPen* pOldPen;
	CBrush cBr2, cBrDoing;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(38, 125, 232));
	pOldPen = BufferDC.SelectObject(&pen);
	
	penLine.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 0));

	cBrDoing.CreateSolidBrush(RGB(89,172,255));
	cBr2.CreateSolidBrush(RGB(255, 255, 255));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	/////////////Draw Flow Chart 
	int nStartLeft = 100;
	int nStartTop = 20;
	int nRectWidth = 170;
	int nRectHeight = 40;
	int nRoundScore = 10;
	int nLine = 20;


	int nLineStartPointX =  nStartLeft + nRectWidth/2;
	int nLineStartPointY = nStartTop + nRectHeight;
	int nLineEndPointX = nLineStartPointX;
	int nLineEndPointY = nLineStartPointY + nLine;

	CPoint ptTemp;

	//��뿩�ο� ���� �������� 
	//Start
	pOldBrush = BufferDC.SelectObject(&cBr2);
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);	
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "Start Process");
	BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
	BufferDC.LineTo(nLineEndPointX, nLineEndPointY);

	//Power -> preheat line
	if(m_bPower && m_bPreheat)
	{ 
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY + nLine/2);
		BufferDC.LineTo(nLineStartPointX + nRectWidth/2 + 20, nLineStartPointY + nLine/2);
	
	
		ptTemp.x = nLineStartPointX + nRectWidth/2 + 20;
		ptTemp.y =  nLineStartPointY + nLine/2;
	
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY + nLine/2);
		BufferDC.LineTo(nLineStartPointX+5, nLineStartPointY + nLine/2 + 3);
		BufferDC.LineTo(nLineStartPointX+5, nLineStartPointY + nLine/2 - 3);
		BufferDC.LineTo(nLineStartPointX, nLineStartPointY + nLine/2);
	}
	//PreHeat
	if(m_bPreheat)
	{
		if(m_bDoPreheat && !m_bDoPower && !m_bDoScanner && !m_bDoDrill && m_bChangeDisplay)
		{
			pOldBrush = BufferDC.SelectObject(&cBrDoing);	
			BufferDC.SetTextColor(RGB(255,255,255));
			BufferDC.SetBkColor(RGB(89,172,255));
		}
		else
		{
			pOldBrush = BufferDC.SelectObject(&cBr2);
			BufferDC.SetTextColor(RGB(0,0,0));
			BufferDC.SetBkColor(RGB(255,255,255));
		}
		
		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;
		
		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "PreHeating");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
	}

	//Power Measurement 
	if(m_bPower)
	{
		if(!m_bDoPreheat && m_bDoPower && !m_bDoScanner  && !m_bDoDrill && m_bChangeDisplay)
		{
			pOldBrush = BufferDC.SelectObject(&cBrDoing);	
			BufferDC.SetTextColor(RGB(255,255,255));
			BufferDC.SetBkColor(RGB(89,172,255));
		}
		else
		{
			pOldBrush = BufferDC.SelectObject(&cBr2);
			BufferDC.SetTextColor(RGB(0,0,0));
			BufferDC.SetBkColor(RGB(255,255,255));
		}
			
		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;

		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20, nStartTop + 10, "Power Measurement");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
			
		//Power -> preheat line
		if(m_bPreheat)
		{
			BufferDC.MoveTo(nStartLeft + nRectWidth, nStartTop + 15);
			BufferDC.LineTo(nStartLeft + nRectWidth + 20, nStartTop + 15);
			BufferDC.LineTo(ptTemp.x, ptTemp.y);
		}
	}

	//Scanner Calibration
	if(m_bScanner)
	{
		if(!m_bDoPreheat && !m_bDoPower && m_bDoScanner && !m_bDoDrill  && m_bChangeDisplay)
		{
			pOldBrush = BufferDC.SelectObject(&cBrDoing);	
			BufferDC.SetTextColor(RGB(255,255,255));
			BufferDC.SetBkColor(RGB(89,172,255));
		}
		else
		{
			pOldBrush = BufferDC.SelectObject(&cBr2);
			BufferDC.SetTextColor(RGB(0,0,0));
			BufferDC.SetBkColor(RGB(255,255,255));
		}

		nStartTop = nLineEndPointY;
		pOldPen = BufferDC.SelectObject(&pen);
		BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);

		nLineStartPointY = nStartTop + nRectHeight;
		nLineEndPointY = nLineStartPointY + nLine;
		
		pOldPen = BufferDC.SelectObject(&penLine);
		BufferDC.TextOut(nStartLeft + 20, nStartTop + 10, "Scanner Calibration");
		BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
		BufferDC.LineTo(nLineEndPointX, nLineEndPointY);
	}

	//Drill
	if(!m_bDoPreheat && !m_bDoPower && !m_bDoScanner && m_bDoDrill  && m_bChangeDisplay)
	{
		pOldBrush = BufferDC.SelectObject(&cBrDoing);	
		BufferDC.SetTextColor(RGB(255,255,255));
		BufferDC.SetBkColor(RGB(89,172,255));
	}
	else
	{
		pOldBrush = BufferDC.SelectObject(&cBr2);
		BufferDC.SetTextColor(RGB(0,0,0));
		BufferDC.SetBkColor(RGB(255,255,255));
	}
	
	nStartTop = nLineEndPointY;
	pOldPen = BufferDC.SelectObject(&pen);
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
	
	nLineStartPointY = nStartTop + nRectHeight;
	nLineEndPointY = nLineStartPointY + nLine;
	
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.TextOut(nStartLeft + 20 + 40, nStartTop + 10, "Drilling");
	BufferDC.MoveTo(nLineStartPointX, nLineStartPointY);
	BufferDC.LineTo(nLineEndPointX, nLineEndPointY);

	//End 
	pOldBrush = BufferDC.SelectObject(&cBr2);
	nStartTop = nLineEndPointY;
	pOldPen = BufferDC.SelectObject(&pen);
	BufferDC.RoundRect(nStartLeft, nStartTop, nStartLeft + nRectWidth, nStartTop + nRectHeight, nRoundScore, nRoundScore);
	pOldPen = BufferDC.SelectObject(&penLine);
	BufferDC.SetTextColor(RGB(0,0,0));
	BufferDC.SetBkColor(RGB(255,255,255));
	BufferDC.TextOut(nStartLeft + 20 + 30, nStartTop + 10, "End Process");
	//End Flow Chart

	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);

}



HBRUSH CPaneAutoRunViewPrework::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_PROCESS)->GetSafeHwnd() == pWnd->m_hWnd  )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewPrework::OnClickTabPrework(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	int nSel = m_tabPrework.GetCurSel();

	switch (nSel)
	{
	case 0 : //preheat
		m_pPreHeat->ChangeDisplay();
		break;
	case 1 : //power
		m_pPower->ChangeDisplay();
		break;
	case 2 : //scanner
		m_pScanner->ChangeDisplay();
		break;
	}
	*pResult = 0;
}

void CPaneAutoRunViewPrework::ChangeView(int nChangePane)
{
	switch(nChangePane)
	{
	case VIEW_PREHEAT :
		m_pPreHeat->ChangeDisplay();
		m_tabPrework.ShowPane(0);
		break;
	case VIEW_POWER :
		m_pPower->ChangeDisplay();
		m_tabPrework.ShowPane(1);
		break;
	case VIEW_SCANNER :
		m_pScanner->ChangeDisplay();
		m_tabPrework.ShowPane(2);
		break;
	}
}


void CPaneAutoRunViewPrework::SetPreworkStatus(BOOL bPreHeat, BOOL bPower, BOOL bScanner, BOOL bDrill)
{
	m_bDoPreheat = bPreHeat;
	m_bDoPower = bPower;
	m_bDoScanner = bScanner;
	m_bDoDrill = bDrill;
}

void CPaneAutoRunViewPrework::SetPreworkInfo(BOOL bPreheat, BOOL bPower, BOOL bScanner)
{
	m_bPreheat = bPreheat;
	m_bPower = bPower;
	m_bScanner = bScanner;
	
	DrawChart();
}

void CPaneAutoRunViewPrework::ActiveStaticForKeyboardError()
{
	m_pPreHeat->ActiveStaticForKeyboardError();
}
