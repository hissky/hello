#pragma once



// CPaneSysSetupAttenTable �� ���Դϴ�.

class CPaneSysSetupAttenTable : public CFormView
{
	DECLARE_DYNCREATE(CPaneSysSetupAttenTable)

protected:
	CPaneSysSetupAttenTable();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CPaneSysSetupAttenTable();

public:
	void	EnableAllButton(BOOL bEnable);
	virtual void OnInitialUpdate();
	void InitEditControl();
	void InitBtnControl();
	void InitStaticControl();
	void InitListControl();
	void InitCmbControl();
	void SetToolComboBox();
	BOOL CheckStatus();
	BOOL MakeAttenTableProcess();
	BOOL MakeAttenTable();
	BOOL ChangeBeamPath(BOOL bHead, int nRepeat);
	BOOL UpdateNewParam();
	void CheckInpositionError(int nAxis, BOOL bShow);
	void GetBeamPathLaserInfo(SUBTOOLDATA &subTool);
	void InsertResult(int nRepeatCount);

	CFont m_fntStatic;
	CFont m_fntEdit;
	CFont m_fntList;
	CFont m_fntBtn;
	CFont m_fntCombo;

	UEasyButtonEx m_btnStart;
	UEasyButtonEx m_btnStop;
	CComboBox m_cmbHead;
	CComboBox m_cmbBeamPath;
	CColorEdit m_edtEnd;
	CColorEdit m_edtStart;
	CColorEdit m_edtStep;
	CListCtrl m_ListResult;

	int m_nBeamPath;
	double m_dStartPos;
	double m_dEndPos;
	double m_dStep;
	int m_nHead;
	CWinThread*  m_pRunThread;
	BOOL m_bStop;
	BOOL m_bUserDummyOn;
	int m_nErrID;
	int m_nRepeatCount;
	int m_nAttPos[500];
	double m_dResult[2][500];


public:
	enum { IDD = IDD_DLG_SYS_SETUP_ATT_TABLE };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
};


