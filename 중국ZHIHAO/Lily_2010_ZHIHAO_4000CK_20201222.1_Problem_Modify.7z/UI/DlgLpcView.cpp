// DlgLpcView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgLpcView.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\DeviceMotor.h"
#include "PaneRecipeGenFiducialNew.h"
#include "..\device\HMotor.h"
#include "..\alarmmsg.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\EasyDrillerDlg.h"
#include "DlgAddFiducial.h"
#include "..\DEVICE\HEocard.h"
#include "PaneRecipeGen.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT UM_CHANGE_VISION_PARAM	= WM_APP + 51;
const UINT UM_VISION_FIND			= WM_APP + 52;
const UINT UM_VISION_ROI_SET		= WM_APP + 53;
const UINT UM_VISION_FIND_NOGRAP	= WM_APP + 56;
const UINT UM_VISION_ROI_SET_UM		= WM_APP + 57;
const UINT UM_VISION_LAMP			= WM_APP + 58;

/////////////////////////////////////////////////////////////////////////////
// CDlgLpcView dialog


CDlgLpcView::CDlgLpcView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLpcView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLpcView)
		// NOTE: the ClassWizard will add member initialization here

//	m_pRecipeGenData = NULL;
//	m_pProject = &gDProject;
	m_pProject			= NULL;
	m_bDrawMoveStart	= FALSE;
	m_bSearch			= FALSE;
	m_bFirstSearch		= TRUE;
	m_bPrevStart		= TRUE;
	m_bNextStart		= TRUE;
	m_bDisunifyMode		= FALSE;
	m_bViewerMoveMode	= TRUE;
	m_bSelect			= FALSE;
	m_bSelectFire		= FALSE;

	m_nTimer1 = -1;

	//}}AFX_DATA_INIT
}


void CDlgLpcView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLpcView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_STATIC_VIEW, m_stcView);
	DDX_Control(pDX, IDC_EDIT_PATH, m_edtPAth);
	DDX_Control(pDX, IDC_BUTTON_OPEN, m_btnOpen);
	DDX_Control(pDX, IDC_BUTTON_ERROR_SELECT, m_btnErrorSelect);
	DDX_Control(pDX, IDC_BUTTON_SELECT_VIEW, m_btnSelectView);
	DDX_Control(pDX, IDC_BUTTON_PREV, m_btnPrev);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_NEXT, m_btnNext);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLpcView, CDialog)
	//{{AFX_MSG_MAP(CDlgLpcView)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_MOUSEWHEEL()
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONUP()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN, &CDlgLpcView::OnButtonFileOpen)
	ON_BN_CLICKED(IDC_BUTTON_ERROR_SELECT, &CDlgLpcView::OnButtonErrorSelect)
	ON_BN_CLICKED(IDC_BUTTON_SELECT_VIEW, &CDlgLpcView::OnBUttonSelectView)
	ON_BN_CLICKED(IDC_BUTTON_PREV, &CDlgLpcView::OnButtonPrev)
	ON_BN_CLICKED(IDC_BUTTON_START, &CDlgLpcView::OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_NEXT, &CDlgLpcView::OnButtonNext)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLpcView message handlers

BOOL CDlgLpcView::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitEditControl();
	InitBtnControl();
	InitStaticControl();

	CRect rect;
	GetWindowRect(rect);
	m_siExtendSize = rect.Size();

//	GetDlgItem(IDC_STATIC_NORMAL)->GetWindowRect(rect);
//	m_siNormalSize.cx = rect.right + 10;
//	m_siNormalSize.cy = m_siExtendSize.cy;

	m_nTimer1 = SetTimer(100, 500, NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgLpcView::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");

	m_edtPAth.SetFont( &m_fntEdit );
//	m_edtPAth.SetForeColor( BLACK_COLOR );
//	m_edtPAth.SetBackColor( WHITE_COLOR );
	m_edtPAth.SetReceivedFlag( 3 );
	m_edtPAth.SetWindowText( _T("") );
	
}

void CDlgLpcView::InitStaticControl()
{
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_MOVE)->SetFont( &m_fntStatic );
}

void CDlgLpcView::InitBtnControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnOpen.SetFont( &m_fntBtn );
	m_btnOpen.SetFlat( FALSE );
	m_btnOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpen.EnableBallonToolTip();
	m_btnOpen.SetToolTipText( _T("Position Add") );
	m_btnOpen.SetBtnCursor( IDC_HAND_1 );

	m_btnErrorSelect.SetFont( &m_fntBtn );
	m_btnErrorSelect.SetFlat( FALSE );
	m_btnErrorSelect.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnErrorSelect.EnableBallonToolTip();
	m_btnErrorSelect.SetToolTipText( _T("Position Add") );
	m_btnErrorSelect.SetBtnCursor( IDC_HAND_1 );
	m_btnErrorSelect.SetWindowText(_T("LPC Error Select"));

	m_btnSelectView.SetFont( &m_fntBtn );
	m_btnSelectView.SetFlat( FALSE );
	m_btnSelectView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSelectView.EnableBallonToolTip();
	m_btnSelectView.SetToolTipText( _T("Position Add") );
	m_btnSelectView.SetBtnCursor( IDC_HAND_1 );

	m_btnPrev.SetFont( &m_fntBtn );
	m_btnPrev.SetFlat( FALSE );
	m_btnPrev.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPrev.EnableBallonToolTip();
	m_btnPrev.SetToolTipText( _T("Position Add") );
	m_btnPrev.SetBtnCursor( IDC_HAND_1 );

	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Position Add") );
	m_btnStart.SetBtnCursor( IDC_HAND_1 );

	m_btnNext.SetFont( &m_fntBtn );
	m_btnNext.SetFlat( FALSE );
	m_btnNext.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNext.EnableBallonToolTip();
	m_btnNext.SetToolTipText( _T("Position Add") );
	m_btnNext.SetBtnCursor( IDC_HAND_1 );
}

void CDlgLpcView::OnButtonFileOpen()
{
	CString strFilePath;
	
	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt)|*.txt|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, _T("*.txt"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = _T("D:\\ViaHole\\LPCLog\\");

	if(IDOK != dlg.DoModal())
	{
		SetFocus();
		return;
	} 
	strFilePath.Format(_T("%s"), dlg.GetPathName());
	if(!m_pProject->LoadLPCData(strFilePath))
		ErrMessage(_T("LPC Data Loading Failure"));
	m_edtPAth.SetWindowText(strFilePath);
	DrawData();
	m_nCount = 0;
	m_nErrorMaxCnt = GetErrorCount();
}

void CDlgLpcView::OnButtonErrorSelect()
{
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	POSITION pos, posData;
	CString strResult;

	BOOL bNoSearch = TRUE;

	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	if( !m_bSelect )
	{
   		for(int i = nToolStart; i < nToolEnd; i++)
		{
			pos = m_pProject->m_Areas[i].GetHeadPosition();
			while (pos) 
			{
				pAreaInfo = m_pProject->m_Areas[i].GetNext(pos);
				for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
				{
					posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
					while(posData)
					{
						pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
						if( (m_pProject->m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&  pHole->pOrigin->nLPCError == 1) )
						{
							bNoSearch = FALSE;
							pHole->bSelect = TRUE;
						}
						else
							pHole->bSelect = FALSE;
					}

					posData = pAreaInfo->m_FireLines[j].GetHeadPosition();
				
					while(posData)
					{
						pLine = pAreaInfo->m_FireLines[j].GetNext(posData);
					
						if(	(m_pProject->m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&	pLine->pOrigin->nLPCError == 1) )
						{
							bNoSearch = FALSE;
							pLine->bSelect = TRUE;	
						}
						else
							pHole->bSelect = FALSE;
					}
				}
			}
		}
		m_bSelect = TRUE;
		m_btnErrorSelect.SetWindowText(_T("LPC Error Clear"));
	}
	else if( m_bSelect) 
	{
		for(int i = nToolStart; i < nToolEnd; i++)
		{
			pos = m_pProject->m_Areas[i].GetHeadPosition();
			while (pos) 
			{
				pAreaInfo = m_pProject->m_Areas[i].GetNext(pos);
				for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
				{
					posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
					while(posData)
					{
						pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
						if( (m_pProject->m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&  pHole->pOrigin->nLPCError == 1) )
						{
							bNoSearch = FALSE;
							pHole->bSelect = FALSE;
						}
					}

					posData = pAreaInfo->m_FireLines[j].GetHeadPosition();
				
					while(posData)
					{
						pLine = pAreaInfo->m_FireLines[j].GetNext(posData);
					
						if(	(m_pProject->m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&	pLine->pOrigin->nLPCError == 1) )
						{
							bNoSearch = FALSE;
							pLine->bSelect = FALSE;			
						}
					}
				}
			}
		}
		m_btnErrorSelect.SetWindowText(_T("LPC Error Select"));
		m_bSelect = FALSE;
	}
	Invalidate(FALSE);
	if(bNoSearch)
		ErrMessage(_T("There are no LPC Error holes"));

}

void CDlgLpcView::OnButtonPrev()
{
	m_nCount--;
	if(m_nCount < 0)
	{
		m_nCount++;
		ErrMessage(_T("There is no previous hole."));
		return;
	}
	MoveToDataPos();
	return;
}
void CDlgLpcView::OnButtonStart()
{
	m_nCount = 0;
	MoveToDataPos();
	return;
}
void CDlgLpcView::OnButtonNext()
{
	m_nCount++;
	if(m_nCount >= m_nErrorMaxCnt)
	{
		m_nCount--;
		ErrMessage(_T("There is no next hole."));
		return;
	}
	MoveToDataPos();
	return;
}
BOOL CDlgLpcView::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_nTimer1 != -1)
	{
		KillTimer(100);
		m_nTimer1 = -1;
	}

	return CDialog::DestroyWindow();
}

void CDlgLpcView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer1)
		DispStatus();

	CDialog::OnTimer(nIDEvent);
}

void CDlgLpcView::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CDlgLpcView::DispStatus()
{
	;
}

HBRUSH CDlgLpcView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_VIEW)->GetSafeHwnd() == pWnd->m_hWnd )
			pDC->SetTextColor( RGB(0, 0, 255 ) );
		
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgLpcView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here
	DrawData();
	// Do not call CFormView::OnPaint() for painting messages
}

void CDlgLpcView::InitialDrawRatio()
{
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect,3);
}

void CDlgLpcView::SetProject(DProject *pProject)
{
	m_pProject = pProject;

	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect,3);

	Invalidate(FALSE);
}

void CDlgLpcView::DrawData()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);

//	

	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	//	SetDCCoord(&BufferDC);
	
	int nPenSize;
	nPenSize = 3;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
	if(m_pProject)
	{
		m_pProject->Draw(&BufferDC, cRect, FALSE, 3);
		m_pProject->DrawToolInfo(&BufferDC, cRect);
		m_pProject->DrawLPCErrorInfo(&BufferDC, cRect);
	}
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
}

void CDlgLpcView::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}

BOOL CDlgLpcView::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(LPCView) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
 		{
			case 77:	// M
			case 109:	// m : mode change : select mode <-> viwer move mode
//				if(m_nUserLevel < 1) // Operator Level������ ��� ���Ѵ�
//					return TRUE;

//				if(m_pProject->m_nDataLoadStep < FIELD_DIVIED) // FieldDivide �������� flag ��ȭ ���Ѵ�
//					return TRUE;

				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
					return TRUE;

				if(m_bViewerMoveMode)
					m_bViewerMoveMode = FALSE;
				else
					m_bViewerMoveMode = TRUE;
				return TRUE;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CDlgLpcView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			m_pProject->SetDrawRect(tempP, 1, 3);
		else
			m_pProject->SetDrawRect(tempP, -1, 3);
		
		Invalidate(FALSE);
	}
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

void CDlgLpcView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));

	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		if(IsPickToolVisible(tempP))
			return;
		/*
		if(IsCheckSelectViewMode(tempP))
			return;
		if(IsCheckPathViewMode(tempP))
			return;*/
	}
	else
		return;
	
	if(IsPickUnit(tempP)) // ���õ� unit�� �̵���ų��
	{
		m_bDrawMoveStart = FALSE;
		m_bUnitMoveStart = TRUE;
		m_ptMoveStart = tempP;
		m_ptTotalMove.x = m_ptTotalMove.y = 0;
	}
	else
	{
		m_bDrawMoveStart = TRUE;
		m_bUnitMoveStart = FALSE;
		m_ptMoveStart = tempP;
		m_ptDrawStart = tempP;
		
		if(!m_bViewerMoveMode)
		{
			DrawSelectionRect(&dc, m_ptDrawStart, m_ptDrawStart);
		}
	}

	
	CDialog::OnLButtonDown(nFlags, point);
	/*
		// TODO: Add your message handler code here and/or call default
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
//		if(IsPickToolVisible(tempP))
//			return;

		GetDlgItem(IDC_STATIC_VIEW)->SetFocus();
	}
	else
		return;

	m_ptDrawStart = tempP;
	m_ptMoveStart = tempP;
	m_bDrawMoveStart = TRUE;
	
	if(!m_bViewerMoveMode)
	{
		DrawSelectionRect(&dc, m_ptDrawStart, m_ptDrawStart);
	}
	CDialog::OnLButtonDown(nFlags, point);*/
}

void CDlgLpcView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	
	// TODO: Add your message handler code here and/or call default
/*
	if(m_bSetMainFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->SetFiducial(nIndex, FALSE); // MainFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}
*/

	if(m_bResetOneMainFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->ResetOneFiducial(nIndex, FALSE); // MainFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}

/*
	if(m_bSetSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->SetFiducial(nIndex, TRUE); // SubFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}
*/

	if(m_bResetOneSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->ResetOneFiducial(nIndex, TRUE); // SubFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}

	if(m_bAddSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->AddSubFiducial(nIndex); 
				m_pProject->ReCalRect();
				Invalidate(FALSE);
			}
			else
			{
				CDlgAddFiducial dlg;
				if(nIndex != -1) // do not find in hole data
				{
					tempP = m_pProject->GetFilePos(tempP);
				}
				dlg.SetData(tempP.x, tempP.y);
				if(dlg.DoModal() == IDOK)
				{
					tempP.x = (LONG)((dlg.m_dX + 0.0002) * 1000);
					tempP.y = (LONG)((dlg.m_dY + 0.0002) * 1000);
					
					// 091230
					CPoint ptTrans;
					ptTrans = m_pProject->GetNoAxisChangePos(tempP);
					//
					
					m_pProject->AddSubFiducial(tempP);
				}
				else
				{
					m_bAddSubFidMode = FALSE;
					m_bDrawMoveStart = FALSE;

					m_bSetMainFidMode = FALSE;
					m_bResetOneMainFidMode = FALSE;
					m_bSetSubFidMode = FALSE;
					m_bResetOneSubFidMode = FALSE;
					return;
				}
				
				m_pProject->ReCalRect();
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;

		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;
		return;
	}

	if(m_bDrawMoveStart)
	{
		m_bDrawMoveStart = FALSE;

		if(m_pProject == NULL)
			return;

		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);

		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			ChangePosInfo(tempP); // display current file position

			if(!m_bViewerMoveMode)
			{
				if(tempP == m_ptDrawStart)
					m_pProject->SelectGlyph(tempP,3);
				else
				{
					if(m_bDisunifyMode)
					{
						if(m_pProject->DisunifyUnit(m_ptDrawStart, tempP))
						{
							Invalidate(FALSE);
							return;
						}
					}
					else
					{
						BOOL bSelectUnit = FALSE;
						if(m_ptDrawStart.x > tempP.x)
							bSelectUnit = TRUE;

						m_pProject->SelectGlyphWithRect(m_ptDrawStart, tempP, bSelectUnit);
					}
				}

				DrawSelectionRect(&dc, m_ptDrawStart, tempP);
			}

			Invalidate(FALSE);
		}
		else
			return;
	}
	if(m_bUnitMoveStart)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			ChangePosInfo(tempP); // display current file position
		}
		m_pProject->AddMoveUnitsToUndoList();
		m_pProject->ReCalRect();
		m_pProject->SetProjectStatusToExcellOpen();
		m_bUnitMoveStart = FALSE;
		Invalidate(FALSE);
	}

	CDialog::OnLButtonUp(nFlags, point);
}

void CDlgLpcView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_pProject == NULL)
		return;

	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));

	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;

			ChangePosInfo(endP); // display current file position
			
			if(m_ptMoveStart != tempP)
			{
				if(m_bViewerMoveMode)
				{
					m_ptMoveStart = endP;
					m_pProject->SetDrawRect(tempP, 0, 3);
					Invalidate(FALSE);
				}
				else
				{
					DrawSelectionRect(&dc, m_ptDrawStart, m_ptMoveStart);
					m_ptMoveStart = endP;
					DrawSelectionRect(&dc, m_ptDrawStart, m_ptMoveStart);
				}

			}
		}
	}
	/*
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	
	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;
			
			if(m_ptMoveStart != tempP)
			{
				m_ptMoveStart = endP;
				m_pProject->SetDrawRect(tempP, 0, 3);
				Invalidate(FALSE);
			}
		}
	}
	CDialog::OnMouseMove(nFlags, point);*/
}

BOOL CDlgLpcView::IsPickToolVisible(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;

	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);

	int nYstart = 5, nEndY;
	int nStartX, nEndX;
	nStartX = cRect.right - 60;
	nEndX = cRect.right - 5;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_pProject->m_pToolCode[i]->m_bUseTool)
		{
			nEndY = nYstart + 18;
			if(ptPick.x <= nEndX && ptPick.x >= nStartX &&
				ptPick.y <=nEndY && ptPick.y >= nYstart)
			{
				if(m_pProject->m_pToolCode[i]->m_bVisible && i != 0)
				{
					m_pProject->m_pToolCode[i]->m_bVisible = FALSE;
					gDProject.m_pToolCode[i]->m_bVisible = FALSE; // apply click ���� ����
				}
				else
				{
					m_pProject->m_pToolCode[i]->m_bVisible = TRUE;
					gDProject.m_pToolCode[i]->m_bVisible = TRUE; // apply click ���� ����
				}
				Invalidate(FALSE);
				return TRUE;
			}

			nYstart += 20;
		}
	}

	return FALSE;
}

BOOL CDlgLpcView::IsCheckSelectViewMode(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;

	if(ptPick.x <= 130 && ptPick.x >= 5 &&
		ptPick.y <=43 && ptPick.y >= 25)
	{
		if((m_pProject->m_nDataLoadStep & 0x0b) < FIELD_DIVIED) // 20091029
		{
			ErrMessage(IDS_DATA_FIELD_DIVIDE);
		}
		else
		{
			m_pProject->ChangeDrawMode();
			Invalidate(FALSE);
		}
		return TRUE;
	}
	
	return FALSE;
}

BOOL CDlgLpcView::IsCheckPathViewMode(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;
	
	if(ptPick.x <= 130 && ptPick.x >= 5 &&
		ptPick.y <=63 && ptPick.y >= 45)
	{
		m_pProject->ChangePathDrawMode();
		Invalidate(FALSE);
		return TRUE;
	}
	
	return FALSE;
}

BOOL CDlgLpcView::IsPickUnit(CPoint ptPoint)
{
	if(m_pProject == NULL)
		return FALSE;
	if(m_pProject->IsPickUnit(ptPoint, 3))
		return TRUE;
	else
		return FALSE;
}

void CDlgLpcView::DrawSelectionRect(CDC *pDC)
{
	CRect rectRect(m_ptDrawRectBack1, m_ptDrawRectBack2);
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CDlgLpcView::DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2)
{
	CPoint ptStart;
	CPoint ptEnd;
	
	if(ptPoint1.x < ptPoint2.x)
	{
		ptStart.x = ptPoint1.x;
		ptEnd.x = ptPoint2.x;
	}
	else
	{
		ptStart.x = ptPoint2.x;
		ptEnd.x = ptPoint1.x;
	}
	
	if(ptPoint1.y < ptPoint2.y)
	{
		ptStart.y = ptPoint1.y;
		ptEnd.y = ptPoint2.y;
	}
	else
	{
		ptStart.y = ptPoint2.y;
		ptEnd.y = ptPoint1.y;
	}
	
	CRect rectRect(ptStart, ptEnd);

	m_ptDrawRectBack1 = ptStart;
	m_ptDrawRectBack2 = ptEnd;
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CDlgLpcView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_pProject == NULL)
		return;

	m_ptFidPosition.x = INT_MAX;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);

	BOOL bSelectField = FALSE;
	BOOL bSelectUnit = FALSE;
	BOOL bNoPoint = FALSE;
	m_nFieldIndex = -1;
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;

		m_ptFidPos = tempP;

		if(IsPickUnit(tempP)) // ���õ� unit�� ������ ���콺 ��ư 
		{
			bSelectUnit = TRUE;
			bSelectField = TRUE;
		}
	}
	else
		return;
	
/*	CMenu pMenu, *pSubMenu;
	pMenu.LoadMenu(IDR_MENU_CONTEXT);

	if(bSelectUnit)
	{
		pSubMenu = pMenu.GetSubMenu(3);
		pSubMenu->EnableMenuItem(IMD_ARRAY_COPY, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_ADD_SUBFID, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_DEL_SUBFIDALL, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_DISUNIFY_UNIT, MF_ENABLED);

		if(m_pProject->m_Glyphs.IsMultiSelected())
		{
			pSubMenu->EnableMenuItem(IMD_MERGE_UNIT, MF_ENABLED);
		}
		else
		{
			pSubMenu->EnableMenuItem(IMD_MERGE_UNIT, MF_GRAYED);
		}
	}
	else
	{
		if(m_bShowSortIndex)
		{
			pSubMenu = pMenu.GetSubMenu(2);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIELD_ONE, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIDBLOCK, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIELD, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_AREA_OFFSET, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_COPY_FIELD, MF_ENABLED);

			if(m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX) > 4)
			{
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_START, MF_ENABLED);
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_CLEAR, MF_ENABLED);
			}
			else
			{
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_START, MF_GRAYED);
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_CLEAR, MF_GRAYED);
			}

			CString strSubMenu =_T("");
			CMenu* pPopup = pSubMenu->GetSubMenu(3);
			for(int i = 1; i <= gDProject.m_nMaxFidBlock; i++)
			{
				strSubMenu.Format("Fiducial Block %d", i);
				pPopup->InsertMenu(i,MF_POPUP, IDM_SELECT_FIDBLOCK_0 + i, (LPCTSTR)strSubMenu);
			}
			for(int i = 0; i <= gDProject.m_nMaxFidBlock; i++)
			{
				if(m_bSelectFidBlock[i])
					pPopup->CheckMenuItem(IDM_SELECT_FIDBLOCK_0 + i, MF_CHECKED);
				else
					pPopup->CheckMenuItem(IDM_SELECT_FIDBLOCK_0 + i, MF_UNCHECKED);
			}
		}
		else
			return;
	}
	pSubMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point.x, point.y, this);
	*/
	CDialog::OnRButtonUp(nFlags, point);
}

void CDlgLpcView::ChangePosInfo(CPoint ptPick)
{
	if(m_pProject == NULL)
		return;

	CPoint umPoint;
	umPoint = m_pProject->GetFilePos(ptPick);

}

BOOL CDlgLpcView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bDisunifyMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HRESIZE));
		return TRUE;
	}
	if(m_bViewerMoveMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HAND_RELEASE));
		return TRUE;
	}
	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}
void CDlgLpcView::OnBUttonSelectView() 
{
	// TODO: Add your control notification handler code here
//	if(m_bAutoRun)
//		return;

//	if(IsDrilling())
//	{
		// Drilling
//		ErrMsgDlg(STDGNALM202);
//		return;
//	}

	m_bSelectFire = !m_bSelectFire;
//	m_ledSelectFire.Depress(!m_bSelectFire);
	m_pProject->m_bSelectDrawMode = m_bSelectFire;

//	ChangeProjectInfo(TRUE);
//	Invalidate(FALSE);
//	m_pData->Invalidate(FALSE);
	DrawData();
}

void CDlgLpcView::MoveToDataPos()
{
	CPaneRecipeGenFiducialNew* pRun = static_cast<CPaneRecipeGenFiducialNew*>(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_tabRecipe.GetPane(3));
	
// static_cast

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	int nTool;
	
	BOOL b1stPanel = TRUE;
	double dX, dY, dZ;
	pRun->m_nCameraNo  = pRun->m_cmbCameraSelect.GetCurSel();
	if(pRun->m_nCameraNo == LOW_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
	}
	else if(pRun->m_nCameraNo == HIGH_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
	}
	else if(pRun->m_nCameraNo == LOW_2ND_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
		b1stPanel = FALSE;
	}
	else
	{
		dX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
		b1stPanel = FALSE;
	}

	CString szPath;
	szPath.Format(_T("%sLPCErrorHoleFindOffset.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
	FILE* fileStream;
	errno_t err;
	err = fopen_s(&fileStream, szPath, "w+");

	if(err != NULL)
	{
		ErrMessage(IDS_ERR_HOLE_FIND);	
	}

	double dMoveX, dMoveY;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	POSITION pos, posData;
	CString strResult;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dLaserOffsetX, dLaserOffsetY;

	BOOL bNoSearch = TRUE;

	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	int nCount = 0;

	for(int i = nToolStart; i < nToolEnd; i++)
	{
		pos = m_pProject->m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_pProject->m_Areas[i].GetNext(pos);
			if(m_pProject->m_nSeparation == USE_DUAL)
			{
				pMotor->GetAxisMoveOffset(pAreaInfo->m_dTableX/1000., pAreaInfo->m_dTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
				dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
				dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
			}
			else
			{
				dPanelOffsetX = 0;
				dPanelOffsetY = 0;
			}
			if(b1stPanel)
				gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000, pAreaInfo->m_dTableY/1000, dLaserOffsetX, dLaserOffsetY, FIRST_PANEL_OFFSET);
			else
				gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000, pAreaInfo->m_dTableY/1000, dLaserOffsetX, dLaserOffsetY, SECOND_PANEL_OFFSET);
			//------
			for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
			{
				posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
				while(posData)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
					nTool = m_pProject->m_ToolSumInfo[pHole->pOrigin->nToolNo].nRealToolNo;
					
					
					if( pHole->pOrigin->nLPCError && m_nCount == nCount)
					{
						bNoSearch = FALSE;
						m_bFirstSearch = FALSE; 
						m_ptOldHolePos.x = pHole->pOrigin->npPos.x;
						m_ptOldHolePos.y = pHole->pOrigin->npPos.x;
						
						if(b1stPanel)
						{
							dMoveX = (pAreaInfo->m_dTableX - (pHole->dpLSBPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dX - dLaserOffsetX;
							dMoveY = (pAreaInfo->m_dTableY - (pHole->dpLSBPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dY - dLaserOffsetY;
						}
						else
						{
							dMoveX = (pAreaInfo->m_dTableX - dPanelOffsetX - (pHole->dpLSBPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dX - dLaserOffsetX;
							dMoveY = (pAreaInfo->m_dTableY - dPanelOffsetY - (pHole->dpLSBPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dY - dLaserOffsetY;
						}

						if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, dZ, dZ, b1stPanel))
						{
							CString strString, strMsg;
							strString.LoadString(IDS_ERR_MOVE_MOTOR);
							strMsg.Format(strString, "X,Y,Z");
							ErrMessage(strMsg);
							if(err == NULL)
								fclose(fileStream);
							return;
						}
						if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
						{
							ErrMessage(_T("Inposition Error"));
							if(err == NULL)
								fclose(fileStream);
							return;
						}
						
						if(pRun->m_nCameraNo % 2 == 0)
							::Sleep(100);
						
						if(!pRun->SendMessage(UM_VISION_FIND, pRun->m_nCameraNo,  MODEL_CIRCLE))
						{
							pRun->m_visionResult.x = 0;
							pRun->m_visionResult.y = 0;
						}
						
						strResult.Format(_T("%s"), pRun->m_ResultChar);
						pRun->DPHoleInfo(strResult);
						if(err == NULL)
						{
							fprintf(fileStream, "Table Cmd (%.3f, %.3f), Offset (%.3f, %.3f)\n", dMoveX, dMoveY, pRun->m_visionResult.x, pRun->m_visionResult.y);
						}
						
						pHole->pOrigin->bCurrnetLPCError = TRUE;
						nCount++;
					}
					else if( pHole->pOrigin->nLPCError && m_nCount != nCount)
					{
						pHole->pOrigin->bCurrnetLPCError = FALSE;
						nCount++;
					}
				}
			}
		}
	}
	if(err == NULL)
		fclose(fileStream);
	if(bNoSearch)
		ErrMessage(_T("There are no LPC Error holes"));
	DrawData();
}

int CDlgLpcView::GetErrorCount()
{
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;

	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	int nCount = 0;

	for(int i = nToolStart; i < nToolEnd; i++)
	{
		POSITION pos = m_pProject->m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_pProject->m_Areas[i].GetNext(pos);
			for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
			{
				POSITION posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
				while(posData)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
					if( pHole->pOrigin->nLPCError)
						nCount++;
				}
			}
		}
	}
	return nCount;
}