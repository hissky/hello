#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUT_H__26C11B55_6850_48F3_B562_6F91FFB44050__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUT_H__26C11B55_6850_48F3_B562_6F91FFB44050__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInput.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInput form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class	CPaneManualControlIOMonitorInputSub1;
class	CPaneManualControlIOMonitorInputSub2;
class	CPaneManualControlIOMonitorInputSub3;
class	CPaneManualControlIOMonitorInputSub4;

class CPaneManualControlIOMonitorInput : public CFormView
{
protected:
	CPaneManualControlIOMonitorInput();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInput)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInput)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT };
	USimpleTab	m_tabManualControl;
	//}}AFX_DATA

// Attributes
public:
	CPaneManualControlIOMonitorInputSub1* m_pSub1;
	CPaneManualControlIOMonitorInputSub2* m_pSub2;
	CPaneManualControlIOMonitorInputSub3* m_pSub3;
	CPaneManualControlIOMonitorInputSub4* m_pSub4;

// Operations
public:
	void		InitTabControl();
	void		ShowTabPane(int nPaneNo);
	int			GetTabCurSel();
	
	void		ChangeSubPane();
	void		KillSubTimer();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInput)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInput();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	
	int			m_nPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInput)
	afx_msg void OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUT_H__26C11B55_6850_48F3_B562_6F91FFB44050__INCLUDED_)
