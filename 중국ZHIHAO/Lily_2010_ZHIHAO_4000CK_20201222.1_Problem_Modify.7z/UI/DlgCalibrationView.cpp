// DlgCalibrationView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgCalibrationView.h"
#include "NAxis.h"

#include <cmath>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCalibrationViewView dialog

const int ViewSize	= 520;
const int GridSize	= 8; // 8*65 = 520 Size Width and Height Display

CDlgCalibrationView::CDlgCalibrationView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCalibrationView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCalibrationViewView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pMGCView = NULL;
	m_dXAxisSlope=0;
	m_dYAxisSlope=0;
	m_dXIntercept=0;
	m_dYIntercept=0;
	m_dYAxisXVaule=0;
	m_dXAxisYVaule=0;
	m_dXIntersection=0;
	m_dYIntersection=0;
	m_bIsparallelYAxis=false;
	m_bIsparallelXAxis=false;
	m_dFieldSizeX=50;
	m_dFieldSizeY=50;
	m_nSelect =0;
}


void CDlgCalibrationView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCalibrationViewView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCalibrationView, CDialog)
	//{{AFX_MSG_MAP(CDlgCalibrationViewView)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_LAYOUT, OnLayOut)
	ON_BN_CLICKED(IDC_XDEVIATION, OnXDeviation)
	ON_BN_CLICKED(IDC_YDEVIATION, OnYDeviation)
	ON_BN_CLICKED(IDC_DISDEVIATION, OnDisDeviation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCalibrationViewView message handlers

void CDlgCalibrationView::OnCancel() 
{
	CDialog::OnCancel();
}

void CDlgCalibrationView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	dc.SetViewportOrg(m_canvasRect.CenterPoint());
	int cx = m_canvasRect.Width();
	int cy = m_canvasRect.Height();
	dc.FillSolidRect(-cx/2, -cy/2, cx, cy, 0);
	switch(m_nSelect)
	{
	case 0:
		DrawBasisRect(&dc);
		DrawCalibration(&dc);
		break;
	case 1:
		DrawColorRef(&dc);
		DrawXDevGrid(&dc);
		break;
	case 2:
		DrawColorRef(&dc);
		DrawYDevGrid(&dc);
		break;
	case 3:
		DrawColorRef(&dc);
		DrawDistanceGrid(&dc);
		break;
	}

	// Do not call CDialog::OnPaint() for painting messages
}

void CDlgCalibrationView::SetDlgFont()
{
	m_btnFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_LAYOUT)->SetFont(&m_btnFont);
	GetDlgItem(IDC_XDEVIATION)->SetFont(&m_btnFont);
	GetDlgItem(IDC_YDEVIATION)->SetFont(&m_btnFont);
	GetDlgItem(IDC_DISDEVIATION)->SetFont(&m_btnFont);
	GetDlgItem(IDCANCEL)->SetFont(&m_btnFont);
}

BOOL CDlgCalibrationView::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SetDlgFont();
	
	GetDlgItem(IDC_CANVAS)->GetWindowRect(&m_canvasRect);
	ScreenToClient(&m_canvasRect);
	SetColorBand();
	CalcuLeastSquare();
	CalcuBeforeCal();
	return TRUE;	
}

void CDlgCalibrationView::CalcuBeforeCal()
{
	for(int i =0; i<Hole_Num; i++)
	{
		m_nXBottomData[i] = -m_dFieldSizeX/2+m_dFieldSizeX/(Hole_Num-1)*i-m_pMGCView->m_nXAscFileData[i][0]*m_dFieldSizeX/MAXLSB;
		m_nYBottomData[i] =-m_dFieldSizeY/2-m_pMGCView->m_nYAscFileData[i][0]*m_dFieldSizeY/MAXLSB;
		m_nXTopData[i] = -m_dFieldSizeX/2+m_dFieldSizeX/(Hole_Num-1)*i-m_pMGCView->m_nXAscFileData[i][(Hole_Num-1)]*m_dFieldSizeX/MAXLSB;
		m_nYTopData[i] = m_dFieldSizeY/2-m_pMGCView->m_nYAscFileData[i][(Hole_Num-1)]*m_dFieldSizeY/MAXLSB;
		m_nXLeftData[i] = -m_dFieldSizeX/2-m_pMGCView->m_nXAscFileData[0][i]*m_dFieldSizeX/MAXLSB;
		m_nYLeftData[i] = -m_dFieldSizeY/2+m_dFieldSizeY/(Hole_Num-1)*i-m_pMGCView->m_nYAscFileData[0][i]*m_dFieldSizeY/MAXLSB;
		m_nXRightData[i] = m_dFieldSizeX/2-m_pMGCView->m_nXAscFileData[(Hole_Num-1)][i]*m_dFieldSizeX/MAXLSB;
		m_nYRightData[i] = -m_dFieldSizeY/2+m_dFieldSizeY/(Hole_Num-1)*i-m_pMGCView->m_nYAscFileData[(Hole_Num-1)][i]*m_dFieldSizeY/MAXLSB;
	}
}

void CDlgCalibrationView::DrawBasisRect(CDC *pDC)
{
	CPen pen, *oldpen;
	pen.CreatePen(PS_SOLID, 2, RGB(128,128,128));
	oldpen = pDC->SelectObject(&pen);
	pDC->SetTextColor(RGB(128,255,0));
	pDC->MoveTo(-ViewSize/2, -ViewSize/2);
	pDC->LineTo(-ViewSize/2, ViewSize/2);
	pDC->LineTo(ViewSize/2, ViewSize/2);
	pDC->LineTo(ViewSize/2, -ViewSize/2);
	pDC->LineTo(-ViewSize/2, -ViewSize/2);
	pDC->MoveTo(0,-ViewSize/2-50);
	pDC->LineTo(0,ViewSize/2+50);
	pDC->MoveTo(-ViewSize/2-50,0);
	pDC->LineTo(ViewSize/2+50,0);
	pDC->SelectObject(oldpen);
}

void CDlgCalibrationView::CalcuLeastSquare()
{
	double X_nXAscData[Hole_Num];
	double X_nYAscData[Hole_Num];
	double Y_nXAscData[Hole_Num];
	double Y_nYAscData[Hole_Num];
	m_dXAxisSlope = 0, m_dYAxisSlope =0;
	m_dXIntercept = 0, m_dYIntercept =0;
	for(int i =0; i< Hole_Num; i++)
	{
		X_nXAscData[i] = -m_dFieldSizeX/2+m_dFieldSizeX/(Hole_Num-1)*i
			+m_pMGCView->m_nXAscFileData[i][(Hole_Num-1)/2]*m_dFieldSizeX/MAXLSB;
		X_nYAscData[i] = +m_pMGCView->m_nYAscFileData[i][(Hole_Num-1)/2]*m_dFieldSizeY/MAXLSB;
		Y_nXAscData[i] = +m_pMGCView->m_nXAscFileData[(Hole_Num-1)/2][i]*m_dFieldSizeX/MAXLSB;
		Y_nYAscData[i] = -m_dFieldSizeY/2+m_dFieldSizeY/(Hole_Num-1)*i
			+m_pMGCView->m_nYAscFileData[(Hole_Num-1)/2][i]*m_dFieldSizeY/MAXLSB;
	}
	double XC_XY = 0, YC_XY =0;
	double XC_XX = 0, YC_XX =0;
	double XC_X = 0, YC_X = 0;
	double XC_Y = 0, YC_Y = 0;
	for(int j=0; j< Hole_Num; j++)
	{
		//X���� ������ - LeastSquare method ��� - ����� ���� 
		XC_XY += X_nXAscData[j]*X_nYAscData[j];
		XC_XX += X_nXAscData[j]*X_nXAscData[j];
		XC_X += X_nXAscData[j];
		XC_Y += X_nYAscData[j];
		//Y���� ������ - LeastSquare method ��� - ����� ����
		YC_XY += Y_nXAscData[j]*Y_nYAscData[j];
		YC_XX += Y_nXAscData[j]*Y_nXAscData[j];
		YC_X += Y_nXAscData[j];
		YC_Y += Y_nYAscData[j];
	}
	//����� Y ����
	//X�࿡ ������ ������ ���� ���� ó��
	if((Hole_Num*XC_XY-XC_X*XC_Y)==0)
	{
		m_bIsparallelXAxis = true;
		for(int y=0; y<Hole_Num; y++)
		{
			m_dXAxisYVaule += X_nYAscData[y];
		}
		m_dXAxisYVaule = m_dXAxisYVaule/Hole_Num;
	}
	else
	{
		m_bIsparallelXAxis = false;
		m_dXAxisSlope = (Hole_Num*XC_XY-XC_X*XC_Y)/(Hole_Num*XC_XX-XC_X*XC_X);
		m_dXIntercept = (XC_Y-m_dXAxisSlope*XC_X)/Hole_Num;
	}

	//Y�࿡ ������ ������ ���� ���� ó��
	if((Hole_Num*YC_XX - YC_X*YC_X)==0)
	{
		m_bIsparallelYAxis = true;
		for(int x=0; x<Hole_Num; x++)
		{
			m_dYAxisXVaule += Y_nXAscData[x];
		}
		m_dYAxisXVaule = m_dYAxisXVaule/Hole_Num;
	}
	else
	{
		m_bIsparallelYAxis = false;
		m_dYAxisSlope = (Hole_Num*YC_XY-YC_X*YC_Y)/(Hole_Num*YC_XX-YC_X*YC_X);
		m_dYIntercept = (YC_Y-m_dYAxisSlope*YC_X)/Hole_Num;
	}
	//������ ȭ�� ������ �°� ����
	double Xtemp_Intercept = m_dXIntercept*ViewSize/m_dFieldSizeY;
	double Ytemp_Intercept = m_dYIntercept*ViewSize/m_dFieldSizeY;

	if(m_bIsparallelYAxis)
	{
		
		m_dXIntersection = m_dYAxisXVaule;
		m_dYIntersection = m_dXAxisSlope*m_dYAxisXVaule+m_dXIntercept;
	}
	else
	{
		m_dXIntersection = -(m_dXIntercept - m_dYIntercept)/(m_dXAxisSlope-m_dYAxisSlope);
		m_dYIntersection = m_dXIntersection*m_dXAxisSlope+m_dXIntercept;
	}
	if(m_bIsparallelYAxis)
	{
		m_ptYAxis_1.x = (long)(m_dYAxisXVaule*ViewSize/m_dFieldSizeX);
		m_ptYAxis_1.y = ViewSize/2;
		m_ptYAxis_2.x = (long)(m_dYAxisXVaule*ViewSize/m_dFieldSizeY);
		m_ptYAxis_2.y = -ViewSize/2;
	}
	if(m_bIsparallelXAxis)
	{
		m_ptXAxis_1.y = (long)(m_dXAxisYVaule*ViewSize/m_dFieldSizeX);
		m_ptXAxis_1.x = ViewSize/2;
		m_ptXAxis_2.y = (long)(m_dXAxisYVaule*ViewSize/m_dFieldSizeY);
		m_ptXAxis_2.x = -ViewSize/2;
	}
	if(m_bIsparallelYAxis==false || m_bIsparallelXAxis==false)
	{
		m_ptXAxis_1.x = ViewSize/2;
		m_ptYAxis_1.y = ViewSize/2;
		m_ptXAxis_2.x = -ViewSize/2;
		m_ptYAxis_2.y = -ViewSize/2;
		m_ptXAxis_1.y = (long)(m_dXAxisSlope*ViewSize/2 + Xtemp_Intercept);
		m_ptXAxis_2.y = (long)(m_dXAxisSlope*(-ViewSize/2) + Xtemp_Intercept);
		m_ptYAxis_1.x = (long)((ViewSize/2- Ytemp_Intercept)/m_dYAxisSlope);
		m_ptYAxis_2.x = (long)((-ViewSize/2- Ytemp_Intercept)/m_dYAxisSlope);
	}
}

void CDlgCalibrationView::DrawCalibration(CDC *pDC)
{
	int j = 0;
	CPoint Top[Hole_Num],Bottom[Hole_Num],Left[Hole_Num],Right[Hole_Num];
	double X_Intersection =0;
	double Y_Intersection =0;
	double X_Intercept =0;
	double Y_Intercept =0;
	double XAxis_Slope =0;
	double YAxis_Slope =0;
	double XAxis_theta =0;
	double YAxis_theta =0;
	CPoint XAxis_pt1;
	CPoint XAxis_pt2;
	CPoint YAxis_pt1;
	CPoint YAxis_pt2;

	switch(m_nAxis)
	{
		case NAxis::axis_0:
			for(j=0; j<Hole_Num ; j++)
			{
				Left[j].x = (int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].y = (int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].x = (int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].y = (int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].x = (int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].y = (int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].x = (int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].y = (int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =m_dXIntersection;
			 Y_Intersection =m_dYIntersection;
			 X_Intercept =m_dXIntercept;
			 Y_Intercept =m_dYIntercept;
			 XAxis_Slope =m_dXAxisSlope;
			 YAxis_Slope =m_dYAxisSlope;
			 XAxis_pt1.x = m_ptXAxis_1.x;
			 XAxis_pt1.y = m_ptXAxis_1.y;
			 XAxis_pt2.x = m_ptXAxis_2.x;
			 XAxis_pt2.y = m_ptXAxis_2.y;
			 YAxis_pt1.x = m_ptYAxis_1.x;
			 YAxis_pt1.y = m_ptYAxis_1.y;
			 YAxis_pt2.x = m_ptYAxis_2.x;
			 YAxis_pt2.y = m_ptYAxis_2.y;
			break;
			
		case NAxis::axis_90:	//90 �ð� �������� ȸ���� ��(X -> Y, Y-> -X)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].y = -(int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].x = (int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].y = -(int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].x = (int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].y = -(int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].x = (int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].y= -(int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].x = (int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =m_dYIntersection;
			 Y_Intersection =-m_dXIntersection;
			 X_Intercept =m_dXIntercept/m_dXAxisSlope;
			 Y_Intercept =m_dYIntercept/m_dYAxisSlope;
			 XAxis_Slope =(-1)/m_dXAxisSlope;
			 YAxis_Slope =(-1)/m_dYAxisSlope;
			 XAxis_pt1.y = -m_ptXAxis_1.x;
			 XAxis_pt1.x = m_ptXAxis_1.y;
			 XAxis_pt2.y = -m_ptXAxis_2.x;
			 XAxis_pt2.x = m_ptXAxis_2.y;
			 YAxis_pt1.y = -m_ptYAxis_1.x;
			 YAxis_pt1.x = m_ptYAxis_1.y;
			 YAxis_pt2.y = -m_ptYAxis_2.x;
			 YAxis_pt2.x = m_ptYAxis_2.y;
			break;
			
		case NAxis::axis_180:	//180 �ð� �������� ȸ���� ��(X -> -X, Y-> -Y)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].x = -(int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].y = -(int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].x = -(int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].y = -(int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].x = -(int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].y = -(int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].x = -(int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].y = -(int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =-m_dXIntersection;
			 Y_Intersection =-m_dYIntersection;
			 X_Intercept =-m_dXIntercept;
			 Y_Intercept =-m_dYIntercept;
			 XAxis_Slope =m_dXAxisSlope;
			 YAxis_Slope =m_dYAxisSlope;
			 XAxis_pt1.x = -m_ptXAxis_1.x;
			 XAxis_pt1.y = -m_ptXAxis_1.y;
			 XAxis_pt2.x = -m_ptXAxis_2.x;
			 XAxis_pt2.y = -m_ptXAxis_2.y;
			 YAxis_pt1.x = -m_ptYAxis_1.x;
			 YAxis_pt1.y = -m_ptYAxis_1.y;
			 YAxis_pt2.x = -m_ptYAxis_2.x;
			 YAxis_pt2.y = -m_ptYAxis_2.y;
			break;

		case NAxis::axis_270:	//270 �ð� �������� ȸ���� ��(X -> -Y, Y-> X)
			for(j=0; j<Hole_Num ; j++)
			{
				Left[j].y = (int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].x = -(int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].y = (int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].x = -(int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].y = (int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].x = -(int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].y = (int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].x = -(int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =-m_dYIntersection;
			 Y_Intersection =m_dXIntersection;
			 X_Intercept =-m_dXIntercept/m_dXAxisSlope;
			 Y_Intercept =-m_dYIntercept/m_dYAxisSlope;
			 XAxis_Slope =(-1)/m_dXAxisSlope;
			 YAxis_Slope =(-1)/m_dYAxisSlope;
			 XAxis_pt1.y = m_ptXAxis_1.x;
			 XAxis_pt1.x = -m_ptXAxis_1.y;
			 XAxis_pt2.y = m_ptXAxis_2.x;
			 XAxis_pt2.x = -m_ptXAxis_2.y;
			 YAxis_pt1.y = m_ptYAxis_1.x;
			 YAxis_pt1.x = -m_ptYAxis_1.y;
			 YAxis_pt2.y = m_ptYAxis_2.x;
			 YAxis_pt2.x = -m_ptYAxis_2.y;
			break;

		case NAxis::axis_left_0:// (X -> Y, Y-> X)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].y = (int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].x = (int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].y = (int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].x = (int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].y = (int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].x = (int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].y = (int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].x = (int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =m_dYIntersection;
			 Y_Intersection =m_dXIntersection;
			 X_Intercept =-m_dXIntercept/m_dXAxisSlope;
			 Y_Intercept =-m_dYIntercept/m_dYAxisSlope;
			 XAxis_Slope =1/m_dXAxisSlope;
			 YAxis_Slope =1/m_dYAxisSlope;
			 XAxis_pt1.y = m_ptXAxis_1.x;
			 XAxis_pt1.x = m_ptXAxis_1.y;
			 XAxis_pt2.y = m_ptXAxis_2.x;
			 XAxis_pt2.x = m_ptXAxis_2.y;
			 YAxis_pt1.y = m_ptYAxis_1.x;
			 YAxis_pt1.x = m_ptYAxis_1.y;
			 YAxis_pt2.y = m_ptYAxis_2.x;
			 YAxis_pt2.x = m_ptYAxis_2.y;
			break;

		case NAxis::axis_left_90:// (X -> X, Y-> -Y)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].x = (int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].y = -(int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].x = (int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].y = -(int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].x = (int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].y = -(int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].x = (int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].y = -(int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =m_dXIntersection;
			 Y_Intersection =-m_dYIntersection;
			 X_Intercept =-m_dXIntercept;
			 Y_Intercept =-m_dYIntercept;
			 XAxis_Slope =-m_dXAxisSlope;
			 YAxis_Slope =-m_dYAxisSlope;
			 XAxis_pt1.x = m_ptXAxis_1.x;
			 XAxis_pt1.y = -m_ptXAxis_1.y;
			 XAxis_pt2.x = m_ptXAxis_2.x;
			 XAxis_pt2.y = -m_ptXAxis_2.y;
			 YAxis_pt1.x = m_ptYAxis_1.x;
			 YAxis_pt1.y = -m_ptYAxis_1.y;
			 YAxis_pt2.x = m_ptYAxis_2.x;
			 YAxis_pt2.y = -m_ptYAxis_2.y;
			break;

		case NAxis::axis_left_180:// (X -> -Y, Y-> -X)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].y = -(int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].x = -(int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].y = -(int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].x = -(int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].y = -(int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].x = -(int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].y = -(int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].x = -(int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =-m_dXIntersection;
			 Y_Intersection =-m_dYIntersection;
			 X_Intercept =m_dXIntercept/m_dXAxisSlope;
			 Y_Intercept =m_dYIntercept/m_dYAxisSlope;
			 XAxis_Slope =1/m_dXAxisSlope;
			 YAxis_Slope =1/m_dYAxisSlope;
			 XAxis_pt1.y = -m_ptXAxis_1.x;
			 XAxis_pt1.x = -m_ptXAxis_1.y;
			 XAxis_pt2.y = -m_ptXAxis_2.x;
			 XAxis_pt2.x = -m_ptXAxis_2.y;
			 YAxis_pt1.y = -m_ptYAxis_1.x;
			 YAxis_pt1.x = -m_ptYAxis_1.y;
			 YAxis_pt2.y = -m_ptYAxis_2.x;
			 YAxis_pt2.x = -m_ptYAxis_2.y;
			break;

		case NAxis::axis_left_270:// (X -> -X, Y-> Y)
		for(j=0; j<Hole_Num ; j++)
			{
				Left[j].x = -(int)(m_nXLeftData[j]*ViewSize/m_dFieldSizeX);
				Left[j].y = (int)(m_nYLeftData[j]*ViewSize/m_dFieldSizeY);
				Bottom[j].x = -(int)(m_nXBottomData[j]*ViewSize/m_dFieldSizeX);
				Bottom[j].y = (int)(m_nYBottomData[j]*ViewSize/m_dFieldSizeY);
				Top[j].x = -(int)(m_nXTopData[j]*ViewSize/m_dFieldSizeX);
				Top[j].y = (int)(m_nYTopData[j]*ViewSize/m_dFieldSizeY);
				Right[j].x = -(int)(m_nXRightData[j]*ViewSize/m_dFieldSizeX);
				Right[j].y = (int)(m_nYRightData[j]*ViewSize/m_dFieldSizeY);
			}
			 X_Intersection =-m_dXIntersection;
			 Y_Intersection =m_dYIntersection;
			 X_Intercept =m_dXIntercept;
			 Y_Intercept =m_dYIntercept;
			 XAxis_Slope =-m_dXAxisSlope;
			 YAxis_Slope =-m_dYAxisSlope;
			 XAxis_pt1.x = -m_ptXAxis_1.x;
			 XAxis_pt1.y = m_ptXAxis_1.y;
			 XAxis_pt2.x = -m_ptXAxis_2.x;
			 XAxis_pt2.y = m_ptXAxis_2.y;
			 YAxis_pt1.x = -m_ptYAxis_1.x;
			 YAxis_pt1.y = m_ptYAxis_1.y;
			 YAxis_pt2.x = -m_ptYAxis_2.x;
			 YAxis_pt2.y = m_ptYAxis_2.y;	
			break;
	}
	XAxis_theta =atan(XAxis_Slope)*180/3.141592;
	YAxis_theta =atan(YAxis_Slope)*180/3.141592;
	if(XAxis_theta<0)
	{
		XAxis_theta = 180+XAxis_theta;
	}
	if(YAxis_theta <0)
	{
		YAxis_theta = 180+YAxis_theta;
	}
	CPen pen, *oldpen;
	pen.CreatePen(PS_DOT, 1, RGB(255,255,0));
	oldpen = pDC->SelectObject(&pen);
	// Calibration Line Display
	pDC->MoveTo(Left[0].x, -Left[0].y);
	for(int j = 1 ; j< Hole_Num ; j++)
	{
		pDC->LineTo(Left[j].x, -Left[j].y);
	}
	for(j=1; j< Hole_Num ; j++)
	{
		pDC->LineTo(Top[j].x, -Top[j].y);
	}
	pDC->MoveTo(Bottom[0].x, -Bottom[0].y);
	for(j=0; j <Hole_Num; j++)
	{
		pDC->LineTo(Bottom[j].x, -Bottom[j].y);
	}
	for(j=0; j <Hole_Num ; j++)
	{
		pDC->LineTo(Right[j].x, -Right[j].y);
	}
	////////////////////////////////////////////
	pDC->SelectObject(oldpen);
	pen.DeleteObject();
	pen.CreatePen(PS_SOLID,1,RGB(255,255,255));
	oldpen = pDC->SelectObject(&pen);
	pDC->SetTextColor(RGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	CString strLeastInfo,strLeastInfo2;
	// �� ������ ���� Display
	strLeastInfo = "-=Intersection of two Reference Line=-";
	pDC->TextOut(-245,80,strLeastInfo);
	strLeastInfo.Format(_T("+ X = %.3fmm"),X_Intersection);
	pDC->TextOut(-170,100,strLeastInfo);
	strLeastInfo.Format(_T("+ Y = %.3fmm"),Y_Intersection);
	pDC->TextOut(-170,120,strLeastInfo);
	/////////////////////////////////////////
	// �� ������ Information Display
	if(fabs(XAxis_Slope) > fabs(YAxis_Slope))
	{
		strLeastInfo = "-= Y Axis Reference Line =-";
		strLeastInfo2 = "-= X Axis Reference Line =-";
	}
	else
	{
		strLeastInfo = "-= X Axis Reference Line =-";
		strLeastInfo2 = "-= Y Axis Reference Line =-";
	}
	pDC->TextOut(40,80,strLeastInfo);
	if(m_bIsparallelXAxis)
	{
		strLeastInfo.Format(_T("+ Y Value =%.3f"),m_dXAxisYVaule);
		pDC->TextOut(50,100,strLeastInfo);
		strLeastInfo = "+ Parallel with X Axis";
		pDC->TextOut(50, 120,strLeastInfo);
		XAxis_theta = 0;
	}
	else
	{
		strLeastInfo.Format(_T("+ Slope = %.3f"),XAxis_Slope);
		pDC->TextOut(50,100,strLeastInfo);
		strLeastInfo.Format(_T("+ Intercept Point = %.3fmm"),X_Intercept);
		pDC->TextOut(50,120,strLeastInfo);
	}
	pDC->TextOut(40,-120,strLeastInfo2);
	if(m_bIsparallelYAxis)
	{
		strLeastInfo.Format(_T("+ X Value =%.3f"),m_dYAxisXVaule);
		pDC->TextOut(50,-80,strLeastInfo);
		strLeastInfo = "+ Parallel with Y Axis";
		pDC->TextOut(50, -100,strLeastInfo);
		YAxis_theta = 90;
		
	}
	else
	{
		strLeastInfo.Format(_T("+ Slope = %.3f"),YAxis_Slope);
		pDC->TextOut(50,-100,strLeastInfo);
		strLeastInfo.Format(_T("+ Intercept Point = %.3fmm"),Y_Intercept);
		pDC->TextOut(50,-80,strLeastInfo);
	}
	strLeastInfo.Format(_T("+ Angle = %.3f"),XAxis_theta);
	pDC->TextOut(50,140,strLeastInfo);
	strLeastInfo.Format(_T("+ Angle = %.3f"),YAxis_theta);
	pDC->TextOut(50,-60,strLeastInfo);
	/////////////////////////////////////////////
	pDC->SelectObject(oldpen);
	pen.DeleteObject();
	pen.CreatePen(PS_SOLID,1,RGB(255,0,255));
	oldpen = pDC->SelectObject(&pen);
	// Reference Line Display
	pDC->MoveTo(XAxis_pt1.x, -XAxis_pt1.y);
	pDC->LineTo(XAxis_pt2.x, -XAxis_pt2.y);
	pDC->MoveTo(YAxis_pt1.x, -YAxis_pt1.y);
	pDC->LineTo(YAxis_pt2.x, -YAxis_pt2.y);
	pDC->SelectObject(oldpen);
	pen.DeleteObject();
}

void CDlgCalibrationView::DrawXDevGrid(CDC *pDC)
{
	int colorindex;
	int xsize = m_canvasRect.Width()/2;
	int ysize = m_canvasRect.Height()/2;
	int x =0;
	int y=0;
	int nMaxTemp = 0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for(y =Hole_Num-1; y>=0; y--)
		{
			for(x=0; x<Hole_Num; x++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_90:
		for(x =0; x<Hole_Num; x++)
		{
			for(y=0; y<Hole_Num; y++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
	  nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
	  break;
		
	case NAxis::axis_180:

		for(y =0; y<Hole_Num; y++)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_270:

		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_left_0:
		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=0; y<Hole_Num; y++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_left_90:
		for(y =0; y<Hole_Num; y++)
		{
			for(x=0; x<Hole_Num; x++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_left_180:
		for(x =0; x>=0; x++)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_left_270:
		for(y =Hole_Num-1; y>=0; y--)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	}

	pDC->SetTextColor(RGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	CString str;
	str.Format(_T("%d [LSB]"),nMaxTemp);
	pDC->TextOut(-xsize+10,-ysize+45,str);
	str.Format(_T("%d [LSB]"),-nMaxTemp);
	pDC->TextOut(xsize-85,ysize-45,str);
	str = "0 [LSB]";
	pDC->TextOut(xsize-55,-ysize+45,str);
	pDC->TextOut(-xsize+10,ysize-45,str);
}

void CDlgCalibrationView::DrawYDevGrid(CDC *pDC)
{
	int colorindex;
	int xsize = m_canvasRect.Width()/2;
	int ysize = m_canvasRect.Height()/2;
	int nMaxTemp=0;
	int x = 0;
	int y = 0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for(y =Hole_Num-1; y>=0; y--)
		{
			for(x=0; x<Hole_Num; x++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_90:
		for(x =0; x<Hole_Num; x++)
		{
			for(y=0; y<Hole_Num; y++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
	  nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
	  break;
		
	case NAxis::axis_180:

		for(y =0; y<Hole_Num; y++)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_270:

		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_left_0:
		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=0; y<Hole_Num; y++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_left_90:
		for(y =0; y<Hole_Num; y++)
		{
			for(x=0; x<Hole_Num; x++)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	case NAxis::axis_left_180:
		for(x =0; x>=0; x++)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nXAscFileData[x][y],m_nXMax,m_nXMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nXMin),abs(m_nXMax)));
		break;
	case NAxis::axis_left_270:
		for(y =Hole_Num-1; y>=0; y--)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				colorindex = ExtractColorIndex(m_pMGCView->m_nYAscFileData[x][y],m_nYMax,m_nYMin);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		nMaxTemp = int(max(abs(m_nYMin),abs(m_nYMax)));
		break;
	}

	pDC->SetTextColor(RGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	CString str;
	str.Format(_T("%d [LSB]"),nMaxTemp);
	pDC->TextOut(-xsize+10,-ysize+45,str);
	str.Format(_T("%d [LSB]"),-nMaxTemp);
	pDC->TextOut(xsize-85,ysize-45,str);
	str = "0 [LSB]";
	pDC->TextOut(xsize-55,-ysize+45,str);
	pDC->TextOut(-xsize+10,ysize-45,str);
}

void CDlgCalibrationView::DrawDistanceGrid(CDC *pDC)
{
	int colorindex;
	double distance;
	double xpow =0 , ypow =0;
	int xsize = m_canvasRect.Width()/2;
	int ysize = m_canvasRect.Height()/2;
	int x =0;
	int y=0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for( y =Hole_Num-1; y>=0; y--)
		{
			for( x=0; x<Hole_Num; x++)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
			}
		}
		break;
	case NAxis::axis_90:

		for(x =0; x<Hole_Num; x++)
		{
			for(y=0; y<Hole_Num; y++)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
			}
		}
		break;
	case NAxis::axis_180:

		for(y =0; y<Hole_Num; y++)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
			}
		}
		break;
	case NAxis::axis_270:

		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
			}
		}
		break;
	case NAxis::axis_left_0:
		for(x =Hole_Num-1; x>=0; x--)
		{
			for(y=0; y<Hole_Num; y++)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+y*GridSize ,-ViewSize/2+(Hole_Num-1-x)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		break;
	case NAxis::axis_left_90:
		for(y =0; y<Hole_Num; y++)
		{
			for(x=0; x<Hole_Num; x++)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+x*GridSize ,-ViewSize/2+y*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		break;
	case NAxis::axis_left_180:
		for(x =0; x>=0; x++)
		{
			for(y=Hole_Num-1; y>=0; y--)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-y)*GridSize ,-ViewSize/2+x*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		break;
	case NAxis::axis_left_270:
		for(y =Hole_Num-1; y>=0; y--)
		{
			for(x=Hole_Num-1; x>=0; x--)
			{
				xpow = pow((double)m_pMGCView->m_nXAscFileData[x][y],2);
				ypow = pow((double)m_pMGCView->m_nYAscFileData[x][y],2);
				distance = sqrt(xpow+ypow);
				colorindex = ExtractColorIndex((int)(distance),m_nDistanceMax,0);
				pDC->FillSolidRect(-ViewSize/2+(Hole_Num-1-x)*GridSize ,-ViewSize/2+(Hole_Num-1-y)*GridSize, GridSize, GridSize, m_colorBand[colorindex]);
				
			}
		}
		break;
	}

	pDC->SetTextColor(RGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	CString str;
	str.Format(_T("%d [LSB]"),m_nDistanceMax);
	pDC->TextOut(-xsize+10,-ysize+45,str);
	str = "0 [LSB]";
	pDC->TextOut(-xsize+10,ysize-45,str);
}

void CDlgCalibrationView::OnLayOut() 
{
	m_nSelect =0;
	Invalidate(TRUE);	
}

void CDlgCalibrationView::OnXDeviation() 
{
	m_nSelect =1;
	Invalidate(TRUE);
}

void CDlgCalibrationView::OnYDeviation() 
{
	m_nSelect =2;
	Invalidate(TRUE);
}

void CDlgCalibrationView::OnDisDeviation() 
{
	m_nSelect =3;
	Invalidate(TRUE);
}

void CDlgCalibrationView::SetColorBand()
{
	int i = 0, r = 255, g = 0, b = 0;
	
	for(i =  0; 256 > i; ++i, ++g)
		m_colorBand[i] = RGB(r, g, b);
	ASSERT (256 == g);
	
	r = 255, g = 255;
	for (; i < 512; ++i, --r)
		m_colorBand[i] = RGB(r, g, b);
	ASSERT (-1 == r);
	
	r = 0, g = 255, b = 0;
	for (; i < 768; ++i, ++b)
		m_colorBand[i] = RGB(r, g, b);
	ASSERT (256 == b);
	
	b = 255;
	for (; i < 1024; ++i, --g)
		m_colorBand[i] = RGB(r, g, b);
	ASSERT (-1 == g);
}

int CDlgCalibrationView::ExtractColorIndex(int value, int Max, int Min)
{
	double NormValue = (double)max(abs(Min),Max);
	
	int index = 512; // 0 == value
	
	if (0 < value)
		
		index = 512 - (int)(511 * value/NormValue) - 1;
	
	else if (0 > value)
		
		index = 512 + (int)(511* (-value)/NormValue);
	
	else
		
		index = 512;
	
	index = min(1023, max(0, index));
	
	return index;
}

void CDlgCalibrationView::DrawColorRef(CDC *pDC)
{
	int x = m_canvasRect.Width()/2;
	int y = m_canvasRect.Height()/2;
	for(int i =0; i< 512; i++)
	{
		pDC->FillSolidRect(-x+10, -y+i+67,10,1,m_colorBand[i]);
	}
	if(!(m_nSelect==3))
	{
		for(int j=512; j<1024;j++)
		{
			pDC->FillSolidRect(x-20, -y+(j-512)+67, 10,1,m_colorBand[j]);
		}
	}
}
