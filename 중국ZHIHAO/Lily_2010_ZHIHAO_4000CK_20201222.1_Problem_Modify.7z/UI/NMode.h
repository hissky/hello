#ifndef __NMode
#define __NMode
namespace NMode
{
	enum enumMode { modeSelection, modeZoom , modeZoomIn, modeZoomOut, modeViewDrag};
};
#endif // __NMode
