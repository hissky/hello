// ProtocolCommand.h: interface for the ProtocolCommand class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROTOCOLCOMMAND_H__E14958A4_9C42_4B06_928D_1AC45A2F701E__INCLUDED_)
#define AFX_PROTOCOLCOMMAND_H__E14958A4_9C42_4B06_928D_1AC45A2F701E__INCLUDED_

#include "Queue.h"	// Added by ClassView

#if _MSC_VER > 1000

#pragma once
#endif // _MSC_VER > 1000

#define DISABLE				0
#define ENABLE				1

#define PROTOCOL_COMMAND_MASK		0xE0
#define PROTOCOL_START_FRAME			0x20
#define PROTOCOL_END_FRAME			0xC0
#define PROTOCOL_COMMAND_BYTE		0x40
#define PROTOCOL_DATA_BYTE			0x60

#define PROTOCOL_COMMAND_SAVE		0x00
#define PROTOCOL_COMMAND_ONTIME		0x01
#define PROTOCOL_COMMAND_DELAY		0x02
#define PROTOCOL_COMMAND_HOLD		0x03
#define PROTOCOL_COMMAND_TRGRF_EN	0x04
#define PROTOCOL_COMMAND_PWMCTRL		0x05
#define PROTOCOL_COMMAND_SWONOFF0	0x06
#define PROTOCOL_COMMAND_SWONOFF1	0x07
#define PROTOCOL_COMMAND_DAC			0x08
#define PROTOCOL_COMMAND_ADC			0x09
#define PROTOCOL_COMMAND_READ		0x0A
#define PROTOCOL_COMMAND_ERROR		0x0B
#define PROTOCOL_COMMAND_PIO			0x0C
#define PROTOCOL_COMMAND_RESERVED1	0x0D
#define PROTOCOL_COMMAND_RESERVED2	0x0E
#define PROTOCOL_COMMAND_BAUD		0x0F

typedef struct{
	TCHAR ucStartFrame;
	TCHAR ucCommand;
	TCHAR ucData[4];
	TCHAR ucEndFrame;
} PROTOCOL;

typedef struct{
	TCHAR ucPwmData[8];
} PIO_STATUS;

typedef struct{
	TCHAR ucEnable;			//Enable
	TCHAR	ucEdge;				//Edge
	TCHAR	ucTriggerIntr;
	USHORT	usDelayTime[4];
	USHORT	usHoldTime[4];
	USHORT	usOnTime[4];
} TRG_STATUS;

typedef struct{
	TCHAR 	ucPwmData[8];
} PWM_STATUS;

typedef struct{
	TCHAR 	ucSwitch[4];
} SWITCH_STATUS;

typedef struct{
	TCHAR 	ucDAC[3];
} DAC_STATUS;

typedef struct{
	TCHAR	ucPwmData[8];
} ADC_STATUS;

class ProtocolCommand  
{
public:
	int m_nBaudRate;
	int DecodeCommand(TCHAR *pch);
	PROTOCOL BaudRateControl(int num);
	PROTOCOL ReadCommand();
	PROTOCOL SaveCommand();
	PROTOCOL TriggerOnTime(TCHAR channel,UINT time);
	PROTOCOL TriggerHold(char channel,UINT time);
	PROTOCOL TriggerTime(TCHAR channel,TCHAR command,UINT time);
	PROTOCOL TriggerDelay(TCHAR channel,UINT time);
	PROTOCOL TriggerStatus(TCHAR ucrf,TCHAR ucen);
	PROTOCOL DACCtrl(TCHAR channel,TCHAR dacdata);
	PROTOCOL SwitchCtrl(BOOL bhl,UINT switchdata);
	PROTOCOL PwmDataCtrl(UCHAR channel,UCHAR pwm);
	PROTOCOL m_Protocol;
	PIO_STATUS m_PioStatus;
	TRG_STATUS m_TriggerStatus;
	PWM_STATUS m_PwmStatus;
	SWITCH_STATUS m_SwitchStatus;
	DAC_STATUS m_DacStatus;
	ADC_STATUS m_AdcStatus;
	ProtocolCommand();
	virtual ~ProtocolCommand();

};

#define WM_COMM_READ (WM_USER+1)

#define ASCII_LF	0x0a
#define ASCII_CR	0x0d
#define ASCII_XON	0x11
#define ASCII_XOFF	0x13

class CCommThread  
{
public:
	HWND m_hCommWnd;
	DWORD ReadComm(BYTE *pBuff,DWORD nToRead);
	DWORD WriteComm(BYTE *pBuff,DWORD nToWrite);
	void ClosePort();
	BOOL OpenPort(CString sPortName,DWORD dwBaud,WORD wPortID,HWND pWnd);
	HANDLE m_hComm;
	CString m_sPortName;
	BOOL m_bConnected;
	OVERLAPPED m_osRead,m_osWrite;
	HANDLE m_hThreadWatchComm;
	WORD m_wPortID;
	CQueue m_QueueRead;
	CCommThread();
	virtual ~CCommThread();
};

DWORD ThreadWatchComm(CCommThread* pComm);

#endif // !defined(AFX_PROTOCOLCOMMAND_H__E14958A4_9C42_4B06_928D_1AC45A2F701E__INCLUDED_)
