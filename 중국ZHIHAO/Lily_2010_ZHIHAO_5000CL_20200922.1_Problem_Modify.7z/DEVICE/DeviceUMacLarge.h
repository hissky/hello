// DeviceUMacLarge.h: interface for the DeviceUMacPusan2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEUMACLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEUMACLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//Block 1 
	//$61000
	UINT m_b61000_1:1;					// 0
	UINT m_bMainRunReady:1;				// 1 
	UINT m_b61000_2:1;					// 2
	UINT m_b61000_3:1;			// 3
	UINT m_b61000_4:3;				// 4~6
	UINT m_bMPGMode:1;					// 7
	UINT m_bDoorBypassStatus:2;				// 8 ~ 9 
	UINT m_bDoorLockOnStatus:1;		// 10
	//20170828 ��������
	UINT m_bLDUDSideDoorClose:1;			// 11
	UINT m_bAnalogLogrecodingstart:1;			// 12

	UINT m_bMainInitialEnd:1;			// 13
	UINT m_bMainInitializing:1;			// 14
	UINT m_bMainStationAlarm:17;		// 15 ~ 31

	//$61001
	UINT m_bXInitialEnd:1;				// 0
	UINT m_bXInitializing:1;			// 1 
	UINT m_bYInitialEnd:1;				// 2
	UINT m_bYInitializing:1;			// 3
	UINT m_bZ1InitialEnd:1;				// 4
	UINT m_bZ1Initializing:1;			// 5 
	UINT m_bZ2InitialEnd:1;				// 6
	UINT m_bZ2Initializing:1;			// 7
	UINT m_b61001_1:2;				// 8~9
	UINT m_bUseVacBStatus:1;				// 10
	UINT m_b61001_2:21;				// 11~31


	//$61002
	UINT m_bXInposition:1;				// 0
	UINT m_bXRun:1;						// 1
	UINT m_bYInposition:1;				// 2
	UINT m_bYRun:1;						// 3
	UINT m_bZ1Inposition:1;				// 4
	UINT m_bZ1Run:1;					// 5
	UINT m_bZ2Inposition:1;				// 6
	UINT m_bZ2Run:1;					// 7
	UINT m_b61002_1:24;				// 8~31


	//$61003
	UINT m_bXInTargetPosition:1;		// 0
	UINT m_bYInTargetPosition:2;		// 1 ~ 2
//	UINT m_bXYInRemovePosition:1;		// 2
	UINT m_bXYInLoadPosition:1;			// 3
	UINT m_bXYInUnload1Position:1;		// 4
	UINT m_bXYInUnload2Position:1;		// 5
	UINT m_bZ1InTargetPosition:1;		// 6
	UINT m_bZ2InTargetPosition:1;		// 7

	UINT m_b61003_1:24;		// 8 ~ 31
	

	//$61004 ~ $6100B

	//$61004
	UINT m_bLoaderRunReady:1;			// 0
	UINT m_bLoaderAlignTablePCBExist:1;	// 1
	UINT m_bLoaderAlignReady:1;			// 2
	UINT m_bLoaderAligning:1;			// 3
	UINT m_bLoaderAlignEnd:1;			// 4
	UINT m_bPCBLoading:1;				// 5
	UINT m_bPCBLoadEnd:1;				// 6
	UINT m_bPCBLoadRequestReady:1;		// 7
	UINT m_bLoaderPicker1PCBExist:1;	// 8
	UINT m_bLoaderPicker2PCBExist:1;	// 9
	UINT m_bLoaderCartNoPCB:3;			// 10 ~ 12
	UINT m_bLoaderInitialEnd:1;			// 13
	UINT m_bLoaderInitialing:1;			// 14
	UINT m_bLoaderAlarm:17;				// 15 ~ 31

	//$61005
	UINT m_bLCInitialEnd:1;				// 0
	UINT m_bLCInitialing:1;				// 1
	UINT m_bLCInposition:1;				// 2
	UINT m_bLCRun:1;					// 3
	UINT m_bLCInCartPosition:1;			// 4
	UINT m_bLCInUnloadPosition:1;		// 5
	UINT m_bLCInAlignPosition:1;		// 6
	UINT m_bLCInOriginPosition:1;       // 7 
	UINT m_bLCInReadyPosition:24;		// 8 ~ 31

	int m_61006Space[2];

	//$61008
	UINT m_bUnloaderRunReady:1;			// 0
	UINT m_bUnloaderAlignTablePCBExist:1;// 1
	UINT m_bSpare61008:1;				// 2	
	UINT m_bPCBUnloadReady:1;			// 3
	UINT m_bPCBUnloading:1;				// 4
	UINT m_bPCBUnloadEnd:1;				// 5
	UINT m_bSpare61008_2:2;				// 6,7
//	UINT m_bPCBLoadRequest:1;			// 7
	UINT m_bUnloader1PCBExist:1;		// 8
	UINT m_bUnloader2PCBExist:1;		// 9
	UINT m_bUnloaderCartFull:1;			// 10
	UINT m_bSpare61008_3:2;				// 11,12
	UINT m_bUnloaderInitialEnd:1;		// 13
	UINT m_bUnloaderInitialing:1;		// 14
	UINT m_bUnloaderAlarm:1;			// 15
	UINT m_bSpare61008_4:16;			// 16 ~ 31

	//$61009
//	int m_61009Space;

	UINT m_bUCInitialEnd:1;				// 0
	UINT m_bUCInitialing:1;				// 1
	UINT m_bUCInposition:1;				// 2
	UINT m_bUCRun:1;					// 3
	UINT m_bUCInLoadPosition:1;			// 4
	UINT m_bUCInCartPosition:1;			// 5
	UINT m_bUCInAlignPosition:1;		// 6
	UINT m_bUCInOriginPosition:25;		// 7 ~ 31

	//$6100A ~ $6100B
	int m_6100ASpace[2];

	//$6100C
	UINT m_bEMStopSW:1;					// 0
	UINT m_bLaserPowerOn:1;				// 1
	UINT m_bServoPowerOn:1;				// 2
	UINT m_bRingBlowerRunStatus:1;// 3
	UINT m_bRingBlowerOverCurrent_Alarm:1;	// 4
	UINT m_bRingBlowerOverTemp_Alarm:1;					// 5
	UINT m_b6100C_1:1;				// 6
	UINT m_b6100C_2:1;				// 7
	UINT m_bResetSW:1;				// 8
	UINT m_b6100C_3:1;		// 9
	UINT m_bMasterTableVacuumAIndicator:1;				// 10
	UINT m_bMasterTableVacuumBIndicator:1;				// 11
	UINT m_bMasterTableVacuumCIndicator:1;	// 12
	UINT m_bSlaveTableVacuumAIndicator:1;				// 13
	UINT m_bSlaveTableVacuumBIndicator:1;		// 14
	UINT m_bSlaveTableVacuumCIndicator:17;		// 15 ~ 31

	//$6100D
	UINT m_bFrontDoor1CloseSignal:1;			//0  ( 0 = OPEN, 1 = CLOSE)
	UINT m_bFrontDoor2CloseSignal:1;			//1  ( 0 = OPEN, 1 = CLOSE)
	UINT m_bLoaderDoorCloseSignal:1;			//2  ( 0 = OPEN, 1 = CLOSE)
	UINT m_bUnloaderDoorCloseSignal:1;			//3  ( 0 = OPEN, 1 = CLOSE)
	/*//20170828 ��������
	UINT m_b6100DTemp:8;			// 5~12
	UINT m_bChillerCH1RunStatusSignal:1;			// 13
	UINT m_bChillerCH1TempFault_Signal:1;			// 14
	UINT m_bChillerCH2RunStatusSignal:1;			// 15
	UINT m_bChillerCH2TempFault_Signal:17;		// 16 ~ 31
	*/
	UINT m_b6100DTemp:2;			// 4~5
	UINT m_bLightCurtainOn:2;			// 6~7
	UINT m_bChillerCH1RunStatusSignal:1;			// 8
	UINT m_bChillerCH1TempFault_Signal:1;			// 9
	UINT m_bChillerCH1FlowSignal:1;			// 10
	UINT m_bChillerCH1PresureSignal:1;			// 11

	UINT m_bChillerCH2RunStatusSignal:1;			// 12
	UINT m_bChillerCH2TempFault_Signal:1;		// 13
	UINT m_bChillerCH2FlowSignal:1;			// 14
	UINT m_bChillerCH2PresureSignal:17;			// 15~31


	//$6100E
	UINT m_bLaserWaterFlowSensor:1;				// 0
	UINT m_bHeadWaterFlow1Sensor:1;			// 1
	UINT m_bHeadWaterFlow2Sensor:1;			// 2
	UINT m_bStartSwitch:1;		// 3
	UINT m_bStopSwitch:1;			// 4
	UINT m_bSpare6100E:1;			// 5
	UINT m_bInitalizeSwitch:1;			// 6
	UINT m_bManualModeSwitch:1;			// 7
	UINT m_bAutoModeSwitch:1;			// 8
	UINT m_bExternalLaserShotSwitch:1;			// 9
	//UINT m_bFrontDoorSwitch:1;		// 10//20170828 ��������
	UINT m_b6100E_10:1;		// 10
	UINT m_bRearDoorSwitch:1;			// 11
	UINT m_bMainAirPressureSwitch:1;			// 12
	UINT m_bAutomaticLubricatorY1_Fault:1;// 13
	UINT m_bAutomaticLubricatorY2_Fault:1;// 14
	UINT m_bAutomaticLubricatorX_Fault:17;		// 15 ~ 31


	//$6100F
	UINT m_bLaserMasterShutterExtend:1;	// 0
	UINT m_bLaserMasterShutterRetract:1;	// 1
	UINT m_bLaserSlaveShutterExtend:1;// 2
	UINT m_bLaserSlaveShutterRetract:1;// 3	
	UINT m_bMasterHeightSensorUpCheck:1;	// 4
	UINT m_bMasterHeightSensorDownCheck:1;	// 5
	UINT m_bSlaveHeightSensorUpCheck:1;		// 6 
	UINT m_bSlaveHeightSensorDownCheck:1;		// 7 
	UINT m_b6100F_1:1;		// 8
	UINT m_b6100F_2:1;		// 9
	UINT m_bMPGAxisSelect1:1;   // 10
	UINT m_bMPGAxisSelect2:1;			// 11
	UINT m_bMPGAxisSelect3:1;			// 12
	UINT m_bMPGFeedSelect1:1;// 13
	UINT m_bMPGFeedSelect2:1;// 14
	UINT m_bFrontLowerDoorClose:17;		// 15~31  ( 0 = OPEN, 1 = CLOSE )



	//$61010
	UINT m_bTable1PCBClampSensor:1;		// 0
	UINT m_bTable1PCBUlclampSensor:1;		// 1
	UINT m_bTable2PCBClampSensor:1;			// 2
	UINT m_bTable2PCBUlclampSensor:1;			// 3
	UINT m_bLaserPowerDetectorExtendInput:1;	// 4
	UINT m_bLaserPowerDetectorRetractInput:1;	// 5
	UINT m_bOpticWaterLeakSensor:1;		// 6
	UINT m_bDustCollectorVacuumIndicator:1;	// 7
	UINT m_bSuctionHoodShutterOpenSensor:1;		// 8
	UINT m_bSuctionHoodShutterCloseSensor:1;	// 9
	UINT m_bTable1_1VacuumSuctionValveOn:1;	// 10
	UINT m_bTable1_1VacuumSuctionValveOff:1;		// 11
	UINT m_bTable1_2VacuumSuctionValveOn:1;	// 12
	UINT m_bTable1_2VacuumSuctionValveOff:1;		// 13
	UINT m_bTable2_1VacuumSuctionValveOn:1;	// 14
	UINT m_bTable2_1VacuumSuctionValveOff:17;		// 15~31



	//$61011
	UINT m_bTable2_2VacuumSuctionValveOn:1;		// 0
	UINT m_bTable2_2VacuumSuctionValveOff:1;		// 1
	UINT m_bGasDetectAlarm_IO:1;			// 2 //20170828 �ߺ�, ���ǹٶ�
	UINT m_bLaserSystemWarning:1;				//3
	UINT m_bLaserWaterFlowFault:1;			// 4
	UINT m_bLaserOverTempFault:1;				// 5

	UINT m_bAOM_NA_BeamPass1CylFw:1;			// 6 //20170828 ��������
	UINT m_bAOM_NA_BeamPass1CylBw:1;			// 7
	UINT m_bAOM_NA_BeamPass2CylFw:1;			// 8
	UINT m_bAOM_NA_BeamPass2CylBw:1;			// 9
	UINT m_bAOM_Use_BeamPass1CylUp:1;			// 10
	UINT m_bAOM_Use_BeamPass1CylDown:1;			// 11
	UINT m_bAOM_Use_BeamPass2CylFw:1;			// 12
	UINT m_bAOM_Use_BeamPass2CylBw:1;			// 13
	UINT m_bAOM_Use_BeamPass3CylFw:1;			// 14
	UINT m_bAOM_Use_BeamPass3CylBw:17;			// 15 ~ 31

	//int m_61013Space[2];//$61012~//$61013

	//$61012
	UINT m_bMelsecReady:1;				// 0
	UINT m_bMelsecAlarmOn:1;			// 1
	UINT m_bMelsecAlarmOff:1;			// 2
	UINT m_bMelsecDoNotTableMove:1;		// 3
	UINT m_bMelsecAlignReady:1;			// 4
	UINT m_bMelsecAlignRun:1;			// 5
	UINT m_bMelsecAlignEnd:1;			// 6
	UINT m_bMelsecLoadReady:1;			// 7
	UINT m_bMelsecLoadRun:1;			// 8
	UINT m_bMelsecLoadEnd:1;			// 9
	UINT m_bMelsecUnloadReady:1;		// 10
	UINT m_bMelsecUnloadRun:1;			// 11
	UINT m_bMelsecUnloadEnd:1;			// 12
	UINT m_bMelsecLoadPicker1PCBExist:1;// 13
	UINT m_bMelsecLoadPicker2PCBExist:1;// 14
	UINT m_bMelsecLoadingAble:17;		// 15 ~ 31

	//$61013
	UINT m_bMelsecLoadPicker1Down:1;	// 0
	UINT m_bMelsecLoadPicker2Down:1;	// 1
	UINT m_bMelsecUnloaderPicker1Down:1;// 2
	UINT m_bMelsecUnloaderPicker2Down:1;// 3	
	UINT m_bLoaderAlignTblForward:1;	// 4
	UINT m_bLoaderAlignTblBackward:1;	// 5
	UINT m_bLoaderPick1Detector:1;		// 6 
	UINT m_bLoaderPick2Detector:1;		// 7 
	UINT m_bLoaderPicker1Vacuum1:1;		// 8
	UINT m_bLoaderPicker2Vacuum1:1;		// 9
	UINT m_bLoaserAlignTablePCBSen:1;   // 10
	UINT m_bLoaderPickerVibratorDown:21;// 11 ~ 31

	//$61014
	UINT m_b61014_1:8;				// 0~7
	UINT m_bChillerCH1RemoteOnSignal:1;					// 8
	UINT m_bChillerCH2RemoteOnSignal:1;		// 9
	UINT m_b61014_2:1;			//10~ 12
	UINT m_bDoorInterlockBypassSen:1;	// 13 no use
	UINT m_b61014_3:20;		// 14 ~ 31

	//$61015
	UINT m_bRingBlowerRemoteRun:1;		// 0
	UINT m_bRingBlowerVacuumPowerHigh:1;			// 1
	UINT m_bRingBlowerVacuumPowerMedium:1;		// 2
	UINT m_bRingBlowerVacuumPowerLow:1;		// 3
	UINT m_bRingBlowerSolValveOn:1;	// 4
	UINT m_b61015_1:2;				// 5~6
	UINT m_bAOMPowerRemoteOnOff:1;		// 7
	UINT m_bTable1VacuumPumpSol:1;		// 8
	UINT m_bTable2VacuumPumpSol:1;		// 9
	UINT m_b61015_2:22;		// 10~31


	//$61016

	UINT m_bResetSwitchLamp:1;		// 0
	UINT m_bInitalizeSwitchLamp:1;		// 1
	UINT m_bManualModeSwitchLamp:1;			// 2
	UINT m_bAutoModeSwitchLamp:1;			// 3
	UINT m_bSignalTowerREDLamp:1;	// 4
	UINT m_bSignalTowerYellowLamp:1;// 5
	UINT m_bSignalTowerGreenLamp:1;	// 6
	UINT m_b61016_1:1;// 7
	UINT m_bMPGLamp:1;		// 8
	UINT m_bExternalLaserShotSwitchLamp:1;		// 9
	UINT m_bFlourcentLampOn:1;		// 10
	UINT m_bFrontDoorLockSol:1;		// 11
	UINT m_bRearDoorLockSol:1;		// 12
	UINT m_bDoorInterlockBypass:1;		// 13
	UINT m_bStartModeSwitchLamp:1;		// 14
	UINT m_bStopModeSwitchLamp:17;		// 15 ~ 31

	//$61017
	UINT m_bDoorInterlockLamp:1;		// 0
	UINT m_bBuzzerCh1:1;		// 1
	UINT m_bBuzzerCh2:1;			// 2
	UINT m_bBuzzerCh3:1;			// 3
	UINT m_bBuzzerCh4:1;	// 4
	UINT m_b61017_1:1;// 5
	UINT m_bLaserMasterShutterCylinder1ExtendSol:1;	// 6
	UINT m_bLaserMasterShutterCylinder1RetractSol:1;// 7
	UINT m_bLaserSlaveShutterCylinder2ExtendSol:1;	// 8
	UINT m_bLaserSlaveShutterCylinder2RetractSol:1;// 9
	UINT m_bHeightSensor1UpDownSol:1;		// 10
	UINT m_bHeightSensor2UpDownSol:1;		// 11
	UINT m_bLaserBeamPassMasterUpSol:1;		// 12
	UINT m_bLaserBeamPassMasterDownSol:1;		// 13
	UINT m_bLaserBeamPassSlaveUpSol:1;		// 14
	UINT m_bLaserBeamPassSlaveDownSol:17;		// 15 ~ 31

	//$61018
	UINT m_b61018_1:2;			// 0~1
	UINT m_bSuctionHoodAirOpenCloseSol:1;				// 2
	UINT m_b61018_2:2;			// 3~4
	UINT m_bSuctionHoodAirBlowerSol:1;	// 5
	UINT m_bMaskBlowerSol:1;		// 6
	//UINT m_bOpticBlowerSol:1;	// 7 //20170828 ��������
	UINT m_b61018_7:1;	// 7


	UINT m_bAOM_NA_BeamPass1CylFWD:1;		// 8//20170828 ��������
	UINT m_bAOM_NA_BeamPass1CylBWD:1;		// 9
	UINT m_bAOM_NA_BeamPass2CylFWD:1;		// 10
	UINT m_bAOM_NA_BeamPass2CylBWD:1;		// 11
	UINT m_bAOM_USE_BeamPass1CylFWD:1;		// 12
	UINT m_bAOM_USE_BeamPass1CylBWD:1;		// 13
	UINT m_bAOM_USE_BeamPass2CylFWD:1;		// 14
	UINT m_bAOM_USE_BeamPass2CylBWD:17;		// 15

	//$61019
	UINT m_bAOM_USE_BeamPass3CylFWD:1;		// 0
	UINT m_bAOM_USE_BeamPass3CylBWD:1;		// 1
	UINT m_bScannerPowerRemoteOnOff:1;			// 2
	UINT m_b61019_3:1;			// 3
	UINT m_bLaserEthernetControlBit:1;	// 4
	UINT m_bLaserShutterControlBit:1;// 5
	UINT m_b61019_4:2;	// 6~7
	UINT m_bLaserPowerDetectorExtendOutput:1;	// 8
	UINT m_bLaserPowerDetectorRetractOutput:1;// 9
	UINT m_bTable1_1VacuumSuctionValveOnOff:1;		// 10
	UINT m_bTable1_2VacuumSuctionValveOnOff:1;		// 11
	UINT m_bTable2_1VacuumSuctionValveOnOff:1;		// 12
	UINT m_bTable2_2VacuumSuctionValveOnOff:1;		// 13
	UINT m_bTable1PCBClampUnclampSol:1;		// 14
	UINT m_bTable2PCBClampUnclampSol:17;		// 15 ~ 31
	

	//$6101A ~ $6101F 
	int m_6102BSpare[6];




	//ErrorWoard
	//$61020
	UINT m_bXFault:1;						// 0
	UINT m_bXFollowError:1;					// 1
	UINT m_bXOpenLoop:1;					// 2
	UINT m_bXPositiveLimitOver:1;			// 3
	UINT m_bXNegativeLimitOver:1;			// 4
	UINT m_bXHomeTimeOver:1;				// 5
	UINT m_b61020_1:1;					// 6
	UINT m_b61020_2:1;				// 7
	UINT m_bYFault:1;						// 8
	UINT m_bYFollowError:1;					// 9
	UINT m_bYOpenLoop:1;					// 10
	UINT m_bYPositiveLimitOver:1;			// 11
	UINT m_bYNegativeLimitOver:1;			// 12
	UINT m_bYHomeTimeOver:1;				// 13 
	UINT m_b61020_3:18;				// 14 ~ 31

	//$61021
	UINT m_bZ1Fault:1;						// 0
	UINT m_bZ1FollowError:1;				// 1
	UINT m_bZ1OpenLoop:1;					// 2
	UINT m_bZ1PositiveLimitOver:1;			// 3
	UINT m_bZ1NegativeLimitOver:1;			// 4
	UINT m_bZ1HomeTimeOver:3;				// 5 ~ 7
	UINT m_bZ2Fault:1;						// 8
	UINT m_bZ2FollowError:1;				// 9
	UINT m_bZ2OpenLoop:1;					// 10
	UINT m_bZ2PositiveLimitOver:1;			// 11
	UINT m_bZ2NegativeLimitOver:1;			// 12
	UINT m_bZ2HomeTimeOver:19;				// 13 ~ 31



	//$61022
	UINT m_bAutomaticLubricatorY1Fault:1;				//0
	UINT m_bAutomaticLubricatorY2Fault:1;						// 1
	UINT m_bAutomaticLubricatorXFault:1;				// 2

	UINT m_bMasterTableVacuumSuction1_1OnError:1;				// 3
	UINT m_bMasterTableVacuumSuction1_1OffError:1;				// 4
	UINT m_bMasterTableVacuumSuction1_2OnError:1;				// 5
	UINT m_bMasterTableVacuumSuction1_2OffError:1;				// 6

	UINT m_bSlaveTableVacuumSuction1_1OnError:1;				// 7
	UINT m_bSlaveTableVacuumSuction1_1OffError:1;				// 8
	UINT m_bSlaveTableVacuumSuction1_2OnError:1;				// 9
	UINT m_bSlaveTableVacuumSuction1_2OffError:1;				// 10
	UINT m_b61022_1:21;		// 11 ~ 31  no use

	//$61023 
	UINT m_bChillerCH1TempFaultError:1;				// 0
	UINT m_bChillerCH1FlowFaultError:1;				// 1
	UINT m_bChillerCH1PressureFaultError:1;			// 2
	UINT m_bChillerCH2TempFaultError:1;				// 3
	UINT m_bChillerCH2FlowFaultError:1;				// 4
	UINT m_bChillerCH2PressureFaultError:1;			// 5
	UINT m_b61023_6:26;				// 6~31

	//$61024
	UINT m_bEmergencyStopAlarm:1;				// 0
	UINT m_bServoPowerOffAlarm:1;				// 1
	UINT m_bMainStationInitialError:1;			// 2 
	UINT m_bLightCurtainAlarm:1;				// 3
	UINT m_bFrontDoorOpenAlarm:1;				// 4
	UINT m_bRearDoorOpenAlarm:1;				// 5
	UINT m_bMPGOnAlarm:1;						// 6
	UINT m_bLaserPowerOffAlarm:1;				// 7
	UINT m_bMainAirAlarm:1;						// 8
	UINT m_bXYMoveDangerError:1;				// 9
	UINT m_bPCError:1;							// 10
	UINT m_bRingBlowerOverCurrentAlarm:1;			// 11
	UINT m_bRingBlowerOverTempAlarm:1;			// 12
	UINT m_b61024_13:1;			// 13   
	UINT m_b61024_14:1;			// 14
	UINT m_bGasDetectAlarm:1;							// 15
	UINT m_b61024_2:16;		// 16 ~ 31  no use

	//$61025
	UINT m_bSuctionHoodAirOpenError:1;			// 0	
	UINT m_bSuctionHoodAirCloseError:1;			// 1 

	UINT m_bAOM_NA_BeamPass1CylUpError:1;			// 2//20170828 ��������
	UINT m_bAOM_NA_BeamPass1CylDownError:1;			// 3
	UINT m_bAOM_NA_BeamPass2CylUpError:1;			// 4
	UINT m_bAOM_NA_BeamPass2CylDownError:1;			// 5

	UINT m_bHeightSensor2UpError:1;				// 6
	UINT m_bHeightSensor2DownError:1;			// 7
	UINT m_b1stTableVacuumOnError:1;			// 8
	UINT m_b1stTableVacuumOffError:1;			// 9
	UINT m_b2ndTableVacuumOnError:1;			// 10
	UINT m_b2ndTableVacuumOffError:1;			// 11
	UINT m_b1stShutterCylinderOpenError:1;		// 12
	UINT m_b1stShutterCylinderCloseError:1;		// 13
	UINT m_b2ndShutterCylinderOpenError:1;		// 14
	UINT m_b2ndShutterCylinderCloseError:17;	// 15 ~ 31

	//$61026
	UINT m_bMainVacuumError_1:1;				// 0
	UINT m_bWaterLeakageError_1:1;				// 1
	UINT m_bPowerDetectorShutterForwardError:1;	// 2
	UINT m_bPowerDetectorShutterBackwardError:1;// 3 

	UINT m_bAOM_USE_BeamPass1CylUpError:1;				// 4
	UINT m_bAOM_USE_BeamPass1CylDownError:1;					// 5
	UINT m_bAOM_USE_BeamPass2CylUpError:1;				// 6
	UINT m_bAOM_USE_BeamPass2CylDownError:1;					// 7
	/*
	UINT m_bBeamPassUpErr:1;				// 4 //20170828 ��������
	UINT m_bBeamPassDownErr:1;					// 5
	UINT m_bBeamPass2UpErr:1;				// 6
	UINT m_bBeamPass2DownErr:1;					// 7
	*/
	UINT m_bTableClampUpError:1;				// 8
	UINT m_bTableClampDownError:1;				// 9
	UINT m_bTableClamp2UpError:1;				// 10
	UINT m_bTableClamp2DownError:1;				// 11

	UINT m_bLaserSystemWarningError  :1;						//12
	UINT m_bLaserWaterFlowFaultError:1;						//13
	UINT m_bLaserOverTempFaultError :1;						//14
	UINT m_bWaterFlowError:1;					// 15
	UINT m_b61026_2:16;						//16-31

//	UINT m_bLaserSystemWarning:1;				// 12			//20130603������ bskim (PLC Ȯ��)	
//	UINT m_bLaserWaterFlowFault:1;				// 13			//20130603������ bskim (PLC Ȯ��)
//	UINT m_bLaserOverTempFaultErr:18;				// 14 ~ 31	//20130603������ bskim (PLC Ȯ��)

	//$61027
	UINT m_bXYStopError:1;						// 0
	UINT m_bZ1StopError:1;						// 1
	UINT m_bZ2StopError:1;						// 2
	UINT m_bMasterClampUpError:1;						// 3
	UINT m_bMasterClampDownError:1;						// 4
	UINT m_bSlaveClampUpError:1;						// 5
	UINT m_bSlaveClampDownError:1;						// 6
	//20170828 ��������
	UINT m_bAOM_USE_BeamPass3CylUpError:1;				// 7
	UINT m_bAOM_USE_BeamPass3CylDownError:1;					// 8

	UINT m_bXYMotionParamError:1;				// 9
	UINT m_bZ1MotionParamError:1;				// 10
	UINT m_bZ2MotionParamError:1;				// 11

	UINT m_bChillerError:1;				// 12
	UINT m_bMelsecError:1;				// 13
	UINT m_bMelsecUmacCommunicationerror:1;				// 14

	UINT m_b61027_1:17;				// 12 ~ 31



	int m_61028Space[13];//$61028~$61034

	//$61035
	UINT m_bChillerEMOAlarm:1;			// 0	
	UINT m_bRingBlowerRunError:1;			// 1 
	UINT m_bHeightSensor1UpError :1;			// 2//20170828 ��������
	UINT m_bHeightSensor1DownError       :1;			// 3
	UINT m_bLaserMasterBeamPassUpError:1;			// 4
	UINT m_bLaserMasterBeamPassDownError:1;			// 5
	UINT m_bLaserSlaveBeamPassUpError:1;				// 6
	UINT m_bLaserSlaveBeamPassDownError:25;			// 7~31




	//$61036 ~ $6103F
	int m_61036Space[10];

	//$61040 ~ $61041
	int m_nXCommandPos;
	int m_nXActualPos;

	//$61042 ~ $61047
	int m_61042Spare[6];

	//$61048 ~ $61049
	int m_nYCommandPos;
	int m_nYActualPos;

	//$6104A ~ $6104D
	int m_nJogMoveOpticTargetPos_BET[4];

	//$6104E ~ $6104F
	int m_6104ASpare[2];

	//$61050 ~ $61051
	int m_nZ1CommandPos;
	int m_nZ1ActualPos;
	
	//$61052 ~ $61053
	int m_nJogMoveOpticTargetPos_Mask[2];

	//$61054 ~ $61055
	int m_nJogMoveOpticTargetAxis ;
	int m_nJogMoveFlag ;//20160525

	
	//$61056 ~ $61057
	int m_61052Spare[2];

	//$61058 ~ $61059
	int m_nZ2CommandPos;
	int m_nZ2ActualPos;
	
	//$6105A ~ $6105F
	int m_6105ASpare[6];
	
	//$61060 ~ $6106B
	int m_Output1_1;
	int m_Output1_2;
	int m_Output2_1;
	int m_Output2_2;
	int m_Output3_1;
	int m_Output3_2;
	int m_Input1_1;
	int m_Input1_2;
	int m_Input2_1;
	int m_Input2_2;
	int m_Input3_1;
	int m_Input3_2;
	//$6106C ~ $6106F
	int m_61060Spare[4];
	
	//$61070 ~ $6107F
	int m_61070Spare[16];







	//$61080 ~ $6108A
	int m_61080SFastInpos[11];


	//$6108B ~ $61092 
	int m_61090Spare_1[8];

	//$61093
	int m_61090Spare_2;	
	
	//$61094 ~ $6109E
	int m_nLaserWaterFlowSensor ;
	int m_nHeadWaterFlow1Sensor ;
	int m_nHeadWaterFlow2Sensor ;
	int m_nMainAir;
	int m_nDustSuction;
	int m_nMasterTableVacuumA;
	int m_nMasterTableVacuumB;
	int m_nMasterTableVacuumC;
	int m_nSlaveTableVacuumA;
	int m_nSlaveTableVacuumB;
	int m_nSlaveTableVacuumC;
	//$6109F
	int m_n6109ESpare;
	} DpramReadPosition7;

	
	typedef struct {
		///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
		//Block 1 
		//$61000
		int m_nXPos;
		int m_nYPos;
		int m_nZ1Pos;
		int m_nZ2Pos;

		int m_nSparePos[3];


		int m_nXPosInpos;
		int m_nYPosInpos;
		int m_nZ1PosInpos;
		int m_nZ2PosInpos;

		int m_nSpareInpos[7];

	} InposRam7;

typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//Block 1 
	//$61000
	// PLC->PC Input #1	Equipment		$61000
	int m_bHomingEQP;					// 0
} DpramWritePosition;

#define  PCB_NONE		0x00
#define  PCB_ALIGN		0x01
#define  PCB_LOADER		0x02

class DeviceUMacLarge : public CWnd  
{
public:
	static  UINT ThreadUMacStatus(LPVOID pParam);
	static UINT ThreadUMacInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceUMacLarge();
	virtual ~DeviceUMacLarge();

	/* Table IO Control -------------------------------------------------- */
	BOOL SetMoveIO(int nMoveAxis);
	BOOL IsCmdPosOK();
	BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE);
	int InPositionIO(int nAxis);
	/* Table IO Control end ---------------------------------------------- */

protected:
	int				m_nNoPCBCount;
	CWinThread*		m_thdStatus;
	CWinThread*		m_thdInPosition;		// Window Thread Inposition
	double			m_dMaskPosition[BEAMPATH_COUNT];
	double			m_dMaskPosition2[BEAMPATH_COUNT];
	int				m_nAxisMax;
	int				m_nMaskPos;
	int				m_nMaskPos2;
	LONG			m_lErrorIo;
	LONG			m_lErrorLoad;
	LONG			m_lErrorLoad2;
	LONG			m_lErrorLoad3;
	LONG			m_lErrorUnload;
	LONG			m_lErrorUnload2;
	LONG			m_lErrorUnload3;
	LONG			m_lErrorAligner;
	LONG			m_lErrorTableLimit;
	LONG			m_lErrorOtherLimit;
	LONG			m_lErrorTable;
	LONG			m_lErrorLaser;
	LONG			m_lErrorOthers;
	LONG			m_lErrorOthers2;
	LONG			m_lErrorOthers3;
	LONG			m_lErrorOthers4;
	LONG			m_lErrorOthers5;
	LONG			m_lErrorOthers6;
	BOOL			m_bCheckInposition;
	
	LONG			m_lStatusIO1;
	LONG			m_lStatusIO2;
	LONG			m_lStatusIO3;
	LONG			m_lStatusIO4;

	LONG			m_lStatusIO5;
	LONG			m_lStatusIO6;
	LONG			m_lStatusIO7;
	LONG			m_lStatusIO8;

	LONG			m_lStatusMelsec; //UMAC <-> Melsec 

public:

	void DownloadOpticAxisPosToPLC();
	void JogMoveOpticAxis();
	BOOL IsMoveOpticAxis(int nNo,int &nMoveAxisNo,int nTargetPos_um);//20160525
	int GetTargetPos_Optic(int nNo);//20160525
	BOOL IsHavePLCError();//20160525
	BOOL IsRingblowerPower(int nMode);//20160602
	BOOL IsRingblowerSolValve();//20160602

	BOOL IsServo_Enable(int nAxis); 
	BOOL IsInitialSWOn(); 

	void ReadAllError(int* pnVal);
	BOOL SetNoUseLoadUnload(BOOL bNoUse);
	BOOL SetNoUseTableClamp(BOOL bNoUse);
	BOOL SetNoUseChiller(BOOL bNoUse);
	BOOL GetLPCStatus();
	BOOL GetReverseReady();
	BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd);
	BYTE GetUnloadPickerDownOK();
	BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd);
	BYTE GetLoadPickerDownOK();
	BOOL GetTableBUse();
	BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetChillerRun();
	int ChangeMotorPosition(double dXPos, double dYPos);
	BOOL SetNextTATS(int nAxis, long nTA, long nTS);
	BOOL SetPreTATS(int nAxis, long nTA, long nTS);
	BOOL IsOrigin(int nAxis);
	BOOL MotorMoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2);
	BOOL MotorMoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2);
	BOOL SetServoOnOff(int nAxis, BOOL bOn);
	BOOL Connect(int nPortNo, long lBaudrate);
	BOOL Disconnect();
	BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL bTophat);
	BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bTophat);


	BOOL MotorMoveMC3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2);
	BOOL MotorMoveMCA3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2);
	BOOL MoveZMCA3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMC3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat , BOOL bTophat);
	BOOL MotorMoveXYZMCA3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2,double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bTophat);

	BOOL DoMoveTableClamp(BOOL b1stOn,BOOL b2ndOn);//20160623
	BOOL NoUseClamp(BOOL bNoUse);
	BOOL IsBMMotorHomeEnd();
	BOOL IsHandlerPartError(BOOL bLoader);
	BOOL GetTopHatStatus(BOOL bUp);
	BOOL SetOutportTableVacuum(BOOL bUseBTable);
	BOOL GetAOMAlarm();
	BOOL GetAOMStatus();
	BOOL SetAOMPowerON(BOOL bOn);
	BOOL HoodOpen(BOOL bOpen);
	BOOL IsHoodOK(BOOL bOpen);
	BOOL GetBeamPathStatus(BOOL bShortPath, BOOL bAom);
	BOOL GetResetSWStatus();


	BOOL AOMNABeamPassUpDown(BOOL bUp);
	BOOL AOMNABeamPassUpDown2(BOOL bUp);
	BOOL AOMUseBeamPassUpDown(BOOL bUp);
	BOOL AOMUseBeamPassUpDown2(BOOL bUp);
	BOOL AOMUseBeamPassUpDown3(BOOL bUp);

	BOOL GetAOMNABeamPassUpDown(BOOL bUp);
	BOOL GetAOMNABeamPassUpDown2(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown2(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown3(BOOL bUp);



	BOOL GetManualSWStatus();
	BOOL GetAutoSWStatus();
	BOOL GetStartSWStatus();
	BOOL GetStopSWStatus();

	BOOL GetScannerStatus();
	BOOL UnloaderCarrierAlignPos();
	BOOL LoaderCarrierCartPos();
	BOOL LoaderCarrierCartPos2();
	BOOL SetLimitYPos(double dPos);
	BOOL GetCurrentSuctionMotor();
	BOOL ScannerPower(BOOL bOn);
	BOOL MoveTophatShutter(BOOL bUp);
	void SetFixedMaskPos(double dPos);
	double GetMPosition(int nIndex);
	BOOL WriteLoadUnload(int nAdd, BOOL bOn);
	void SetResetCmd();
	void SetInitialCmd();
	BOOL IsFluorescentLampOn();
	BOOL IsOpticsDoorStop();
	BOOL IsMainDoorStop();
	BOOL IsSystemDoorBypass();
	BOOL IsDoorLockOnStatus();

	BOOL IsAutomaticLubricatorRemoteOn();
	BOOL IsOpticBlowerOn();
	BOOL IsMaskBlowerOn();

	UINT IsScannerFault();
	BOOL IsFlowWater();
	BOOL IsTowerBuzzer();
	BOOL IsLaserSystemWarning();
	BOOL IsLaserOverTempFault();
	BOOL IsReady(int nAxis = -1);
	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE, BOOL bWait = TRUE);
	BOOL IsAnyMotorRun();
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsInPositionThread(int nAxis, BYTE nCommand);
	void ReadPosition();
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff, BOOL bUseAom);
	BOOL GetCurrentHeight(BOOL bFirst, BOOL bDown);
	BOOL GetCurrentVacuumMotor(BOOL b1st);
	BYTE GetExternalLaser();
	BYTE GetCurrentSuction();
	BOOL GetCurrentSuctionOutput();
	BOOL GetCurrentAcrylSuction(BOOL b1st);
	BYTE GetCurrentUnloadDetect();
	BYTE GetCurrentLoadDetect();
	BYTE GetCurrentShutter2();
	BYTE GetCurrentShutter1();
	BYTE GetCurrentPowerMeter();
	BYTE GetCurrentEMStop();
	void SetCurrentCycle(BYTE cCycle);
	BYTE GetCurrentMode();
	BOOL GetCurrentAutoStatus();
	void	ReadErrorIo();
	void	ReadErrorLoad1();
	void	ReadErrorLoad2();
	void	ReadErrorLoad3();
	void	ReadErrorUnload1();
	void	ReadErrorUnload2();
	void	ReadErrorUnload3();
	void	ReadErrorAligner();
	void	ReadErrorTableLimit();
	void	ReadErrorOtherLimit();
	void	ReadErrorTable();
	void	ReadErrorLaser();
	void	ReadErrorOthers();
	void	ReadErrorOthers2();
	void	ReadErrorOthers3();
	void	ReadErrorOthers4();
	void	ReadErrorOthers5();
	void	ReadErrorOthers6();
	void	ReadStatusIO1();
	void	ReadStatusIO2();
	void	ReadStatusIO3();
	void	ReadStatusIO4();

	void	ReadStatusIO5();
	void	ReadStatusIO6();
	void	ReadStatusIO7();
	void	ReadStatusIO8();

	void	ReadStatusMelsec();
	LONG GetCurrentError(ERRORCOMMAND nError);
	BOOL Stop(int nAxis = -1);

	BOOL IsLoadCartNoPCB();
		
	BOOL SetDrillStatus(BOOL bDrilling);
	BOOL LoaderLoading(BOOL bOn);
	BOOL LoaderAlign(BOOL bOn);
	BOOL LoaderOrigin();
	BOOL LoaderElvOriginPos();
	BOOL LoaderElvLoadPos();
	BOOL LoaderCarrierAlignPos();
	BOOL LoaderCarrierAlignPos2();
	BOOL LoaderCarrierLoadPos();
	BOOL LoaderPicker1Init();
	BOOL LoaderPicker1Align();
	BOOL LoaderPicker1Load();
	BOOL LoaderPicker1P2();
	BOOL LoaderPicker2Init();
	BOOL LoaderPicker2Align();
	BOOL LoaderPicker2Load();
	BOOL LoaderPicker2P2();
	BOOL LoaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderVacuum1On();
	BOOL LoaderVacuum1Off();
	BOOL LoaderVacuum2On();
	BOOL LoaderVacuum2Off();
	BOOL LoaderBlow1On();
	BOOL LoaderBlow1Off();
	BOOL LoaderBlow2On();
	BOOL LoaderBlow2Off();
	BOOL LoaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsAlignerPCBExist();
	BOOL IsULAlignerPCBExist();
	BOOL IsLoader1Error();
	BOOL IsLoader2Error();
	BOOL IsAlignerError();
	BOOL IsULAlignerError();
	BOOL TablePCBReset();
	BOOL LoaderPCBReset();
	BOOL UnLoaderPCBReset();
	BOOL Loader1PCBExist(BOOL bOn);
	BOOL Loader2PCBExist(BOOL bOn);
	BOOL SendLoadCartNoPCB();
	BOOL AlignTablePCBExist(BOOL bOn);
	BOOL ULAlignTablePCBExist(BOOL bOn);
	BOOL LoaderPickerPad(int nPicker, int nPad, BOOL bUp);

	BOOL TableCalibration(BOOL bAxisX);

	BOOL TableClamp(BOOL bClamp, double dLimitY, BOOL bLeft);

	BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff);
	BOOL WriteOutputDWord(UINT nAddr, DWORD dwVal);

	BOOL TableLoadPos();
	BOOL TableUnloadPos(BOOL b1st = TRUE);

	BOOL GetCurrentTableClamp(BOOL b1st, BOOL bClamp);

	BOOL GetCurrentMotorSol();

	BOOL UnloadUnloading(BOOL bOn);
	BOOL UnloadOrigin();
	BOOL UnloaderElvOriginPos();
	BOOL UnloaderElvUnloadPos();
	BOOL UnloaderCarrierTablePos();
	BOOL UnloaderCarrierUnloadPos();
	BOOL UnloaderPicker1Init();
	BOOL UnloaderPicker1Table();
	BOOL UnloaderPicker1Unload();
	BOOL UnloaderPicker1P2();
	BOOL UnloaderPicker2Init();
	BOOL UnloaderPicker2Table();
	BOOL UnloaderPicker2Unload();
	BOOL UnloaderPicker2P2();
	BOOL UnloaderClampForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderVacuum1On();
	BOOL UnloaderVacuum1Off();
	BOOL UnloaderVacuum2On();
	BOOL UnloaderVacuum2Off();
	BOOL UnloaderBlow1On();
	BOOL UnloaderBlow1Off();
	BOOL UnloaderBlow2On();
	BOOL UnloaderBlow2Off();
	BOOL UnloaderTableForward();
	BOOL UnloaderTableBackward();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsUnloader1Error();
	BOOL IsUnloader2Error();
	BOOL Unloader1PCBExist(BOOL bOn);
	BOOL Unloader2PCBExist(BOOL bOn);
	BOOL UnloadTablePCBExist(BOOL bOn);
	BOOL UnloaderPickerPad(int nPicker, int nPad, BOOL bUp);

	BOOL Table1VacuumMotor(BOOL bOn);
	BOOL Table2VacuumMotor(BOOL bOn);

	BOOL TableVacuumSelect(BOOL bOn);

	BOOL IsTable1PCBExist();
	BOOL IsTable2PCBExist();
	BOOL IsTable1Error();
	BOOL IsTable2Error();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	

	BOOL MotorShutterAll(BOOL bOpenMaster = TRUE, BOOL bOpenSlave = TRUE);
	BOOL DownloadPosition(int nAxis, double dPosition);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetOrigin(int nAxis = -1);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);
	BOOL SetLimitZ(double dPosZ1Low, double dPosZ1High, double dPosZ2Low, double dPosZ2High, double dXMin, double dXMax);
	BOOL SetVibration(int nCount, double dDelay, int nLPTime); // Vibration Count & Delay
	BOOL SetOriginSpeed(long lSpeed[]);
	BOOL SetOriginSpeed(int nAxis, long lSpeed);
	BOOL SetSpeed(long lSpeed[]);
	BOOL SetSpeed(int nAxis, long lSpeed);
	BOOL SetOffset(double dOffset[]);
	BOOL SetOffset(int nAxis, double dOffset);
	void ReadStatus(BOOL bFirst);
	BOOL			m_bStatusStop;			// Thread Stop Signal
	void SetScale(int nAxis, double dScale);

	BOOL SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y);
	BOOL SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y, double dLoaderX2, double dLoaderY2);
	BOOL SetLoaderUnloaderPickerPos(double dLoaderCartPos, double dLoaderCartPos2, double dLoaderLoadPos, double dLoaderLoadPos2, double dLoaderAlignPos, double dUnloaderCartPos, double dUnloaderUnloadPos, double dUnloaderUnloadPos2, double dUnloaderAlignPos);
	
	BOOL	MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2,  double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL    MotorMoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bTophat);
	BOOL	MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL	MotorMoveAMC2(double dPosA1, double dPosA2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, BOOL bTophat);
	BOOL	MotorMoveAMC2(double dPosA1, double dPosA2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat);
	
	BOOL	MotorMoveAxis(int nAxis, double dPosition);
	BOOL	MotorMoveXY(double dPosX, double dPosY);
	BOOL	MotorMoveZ(double dPosZ1);
	BOOL	MotorMoveZ(double dPosZ1, double dPosZ2);
	BOOL	MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2);
	BOOL	MotorMoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MotorMoveM(int nMaskPos);
	BOOL	MotorMoveM(double dMaskPos);
	BOOL	MotorMoveMC(double dMaskPos, double dPosC);
	BOOL	MotorMoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat = FALSE);
	BOOL	IsLCinCartPos();
	BOOL	IsLCinCartPos2();
	BOOL	IsLCinLoadPos();
	BOOL	IsLCinOriginPos();
	BOOL	IsLCinReadyPos();
	BOOL	IsUCinCartPos();
	BOOL	IsUCinUnloadPos();
	BOOL	IsUCinOriginPos();
	BOOL	IsLCinAlignPos();
	BOOL	IsUCinAlignPos();
	BOOL	IsLP1P1Up();
	BOOL	IsLP1P2Up();
	BOOL	IsLP2P1Up();
	BOOL	IsLP2P2Up();
	BOOL	IsULP1P1Up();
	BOOL	IsULP1P2Up();
	BOOL	IsULP2P1Up();
	BOOL	IsULP2P2Up();
	BOOL	IsLoaderAlignTableForward();
	BOOL	IsUnloaderAlignTableForward();
	BOOL	IsTableUnloadPosition();
	BOOL	IsLoaderCartClamp();
	BOOL	IsAlignSheetTableForward();
	BOOL	IsAlignGuideForward();
	BOOL	IsLoaderPicker1Vacuum();
	BOOL	IsLoaderPicker2Vacuum();
	BOOL	IsLoaderPicker1Blow();
	BOOL	IsLoaderPicker2Blow();
	BOOL	IsUnloaderCartClamp();
	BOOL	IsUnloaderPicker1Vacuum();
	BOOL	IsUnloaderPicker2Vacuum();
	BOOL	IsUnloaderPicker1Blow();
	BOOL	IsUnloaderPicker2Blow();
	BOOL	IsUnloaderNGBoxForward();
	BOOL	IsUnloaderNGBoxBackward();
	

	BOOL	IsSafetyMode();

	BOOL	IsLaserKeyOn();
	
	DpramReadPosition7 m_OldStatus;
	DpramReadPosition7 m_NewStatus;
	long			m_lWritePos[MOTOR_AXIS_MAX];
	BOOL			m_bIsInPosition[MOTOR_AXIS_MAX];
	double			m_dScale[MOTOR_AXIS_MAX];
	long			m_lSpeed[MOTOR_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;
	BOOL			m_bPositionStop;		// Thread Stop Signal
	int				m_nInPositionCount;
	BYTE			m_cCycleStart;
	int				m_nInPositionError;
	double			m_dFixedMaskPos;
	BOOL			m_bConnect;	
	BYTE			m_nPort;
	BOOL			m_bShowErrMsg; 
	BOOL			m_bOldM1;
	BOOL			m_bOldM2;
	BOOL			m_bOldM3;
	BOOL			m_bOldM4;
	BOOL			m_bOldBet1;
	BOOL			m_bOldBet2;
	BOOL			m_bOldRot;
	BOOL			m_bOldTopHat;

	BOOL			m_bReadStatus;
	BOOL	IsHandlerReady();
	BOOL	IsHandlerAlarm();
	BOOL	IsHandlerLotEnd();
	BOOL	IsHandler1stTableExist();
	BOOL	IsHandler2ndTableExist();
	BOOL	IsHandlerLoadReady();
	BOOL	IsHandlerLoadEnd();
	BOOL	IsHandlerLoadAlarm();
	BOOL	IsHandlerUnloadReady();
	BOOL	IsHandlerUnloadEnd();
	BOOL	IsHandlerUnloadAlarm();
	BOOL IsServoConnect();
	BOOL	MainReady(BOOL bOn);
	BOOL	MainAlarm(BOOL bOn);
	BOOL	MainStart(BOOL bOn);
	BOOL	MainStop(BOOL bOn);
	BOOL	MainReset(BOOL bOn);
	BOOL	MainUseTable(int nUseTable);
	BOOL	MainLoadReady(BOOL bOn);
	BOOL	MainLoadEnd(BOOL bOn);
	BOOL	MainUnloadReady(BOOL bOn);
	BOOL	MainUnloadEnd(BOOL bOn);
	BOOL	MainPCBExist(int nPCBExist);
	BOOL	MainLotEnd(BOOL bOn);
	BOOL	MainLoadStart(BOOL bOn);
	BOOL	MainUnloadStart(BOOL bOn);

	BOOL	DustSuctionControl(BOOL bLeft, BOOL bUp, double dMin, double dMax);

	BOOL	SetAlarmTolLed(BOOL bOn);
	int     GetLaserWaterFlowValue();
	int		GetWaterFlow1Value();
	int		GetWaterFlow2Value();

	int		GetMainAirValue();
	int		GetDustSuctionValue();

	int		GetTableVauumValue(BOOL b1st,int nIndex = 0);
	void	GetAllTableVauumValue(int &nMa,int &nMb,int &nMc,int &nSa,int &nSb,int &nSc);
	void	GetOutputStatus(int &Out1,int &Out2,int &Out3,int &Out4,int &Out5,int &Out6);
	void	GetInputStatus(int &In1,int &In2,int &In3,int &In4,int &In5,int &In6);

	BOOL	SetWaterFlow1Value(double dVal);
	BOOL	SetWaterFlow2Value(double dVal);
	BOOL	SetMainAirValue(double dVal);
	BOOL	SetDustSuctionValue(double dVal);
	BOOL	SetTableVauumValue(BOOL b1st, double dVal);
	BOOL	IsMainDoorOpen();
	BOOL	IsHandlerDoorOpen();
	BOOL SetSuctionHoodAirBlowerSol(BOOL bOn);
	BOOL SetMaskSol(BOOL bOn);

	BOOL SetAutomaticLubricatorY1Remote(BOOL bOn);
	BOOL SetAutomaticLubricatorY2Remote(BOOL bOn);
	BOOL SetAutomaticLubricatorRemote(BOOL bOn);
	BOOL SetLaserOn(BOOL bOn);

	BOOL SetAOM1MirrorFWDSol(BOOL bOn);
	BOOL SetAOM1MirrorBWDSol(BOOL bOn);
	BOOL SetAOM2MirrorFWDSol(BOOL bOn);
	BOOL SetAOM2MirrorBWDSol(BOOL bOn);

	BOOL SetLampOn(BOOL bOn);

	BOOL IsAnalogLogRecodingStart();
};

#endif // !defined(AFX_DEVICEUMACLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
