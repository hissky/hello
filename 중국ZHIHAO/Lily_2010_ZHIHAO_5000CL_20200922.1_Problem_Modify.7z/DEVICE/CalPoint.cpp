// CalPoint.cpp : implementation file
//

#include "stdafx.h"
#include "CalPoint.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalPoint

CCalPoint::CCalPoint()
{
	PosX=0;
	PosY=0;
}

CCalPoint::~CCalPoint()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CCalPoint, CObject)
	//{{AFX_MSG_MAP(CCalPoint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CCalPoint member functions
CCalPoint CCalPoint::operator =(CCalPoint Data)
{
	PosX=Data.PosX;
	PosY=Data.PosY;

	return *this;
}

CCalPoint CCalPoint::operator +=(CCalPoint Data)
{
	PosX+=Data.PosX;
	PosY+=Data.PosY;
	return *this;
}

CCalPoint CCalPoint::operator +(CCalPoint Data)
{
	CCalPoint temp;
	temp.PosX=PosX+Data.PosX;
	temp.PosY=PosY+Data.PosY;

	return temp;
}


CCalPoint::CCalPoint(const CCalPoint& Data)
{
	PosX=Data.PosX;
	PosY=Data.PosY;
}


CCalPoint CCalPoint::operator =(const int a)
{
	PosX=a;
	PosY=a;

	return *this;
}
