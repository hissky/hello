// DeviceMelsecOsan.cpp: implementation of the DeviceMelsecOsan class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "DeviceMelsecOsan.h"
#include "math.h"
#include "time.h"
#include "..\alarmmsg.h"
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\model\DProcessINI.h"
#include "..\model\ProcessINIFile.h"
#include "..\model\DSystemINI.h"
#include "..\model\SystemINIFile.h"
#include "..\EasyDrillerDlg.h"

#define READ_MELSEC_BASE	 1500

#define WRITE_COMMAND_BASE	 1010
#define WRITE_INTERFACE_BASE 1020
#define WRITE_ROLL_BASE		 1030
#define WRITE_TABLE_BASE	 1031
#define WRITE_PAPER_BASE	 1033
#define WRITE_REJECT_BASE	 1040
#define WRITE_LC_MOVING_BASE 1100
#define WRITE_LP_MOVING_BASE 1110
#define WRITE_UC_MOVING_BASE 1140
#define WRITE_UP_MOVING_BASE 1150
#define WRITE_LA_BASE		 1200
#define WRITE_UA_BASE		 1212
#define TIME_MELSEC_STATUS	50
#define MOTOR_SCALE			1000.0

UINT DeviceMelsecOsan::ThreadStatus(LPVOID pParam)
{
	DeviceMelsecOsan *pMelsec = (DeviceMelsecOsan *)pParam;
	BOOL bFirst = TRUE;
	
	do
	{
#ifndef __TEST__
		Sleep(TIME_MELSEC_STATUS);
#endif
		// read
		pMelsec->ReadStatus(bFirst);

		if(bFirst)
			bFirst = FALSE;
		
	} while(!pMelsec->m_bStatusStop);
	return TRUE;
}

UINT DeviceMelsecOsan::ThreadInPosition(LPVOID pParam)
{
	DeviceMelsecOsan *pMelsec = (DeviceMelsecOsan *)pParam;
	
	pMelsec->m_bCommandStop = false;
	do
	{
#ifndef __TEST__
		Sleep(TIME_MELSEC_STATUS);
#endif
			switch(pMelsec->m_nInPositionCommand)
			{
			case COMMAND_INPOSITION :		// ���� ����
				if(pMelsec->IsMoveEnd(pMelsec->m_nInPositionAxis))
					pMelsec->m_nIsInPosition = TRUE;
				break;
			case COMMAND_INORIGIN	:		// ���� ����
				if(pMelsec->IsMotorOrigin(pMelsec->m_nInPositionAxis))
					pMelsec->m_nIsInPosition = TRUE;
				break;
			}
		
		if(pMelsec->m_nIsInPosition == TRUE)
			pMelsec->m_pStopTime.StartTime();

		pMelsec->m_nInposTimeCount++;

		if(pMelsec->m_nInposTimeCount > MAX_STOPOVER_TIME * 10) // 25 sec
			pMelsec->m_nIsInPosition = -1;
		
	} while(!pMelsec->m_bPositionStop);
	return TRUE;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DeviceMelsecOsan::DeviceMelsecOsan()
{
	m_thdStatus			= NULL;
	m_thdInPosition		= NULL;
	m_bStatusStop		= FALSE;
	m_nIsInPosition		= FALSE;
	m_bPositionStop		= FALSE;
	m_nInPositionCount	= 0;
	m_pMelsec			= NULL;
	m_pMelsec			= new MMelsec();

	m_lErrorHandlerMain	= 0;
	m_lErrorHandlerLoader = 0;
	m_lErrorHandlerUnloader = 0;
	m_lErrorHandlerEtc1 = 0;
	m_lErrorHandlerEtc2 = 0;
	m_lStatusHandlerLoader = 0;
	m_lStatusHandlerUnloader = 0;

	for(BYTE nAxis = 0; nAxis < HANDLER_AXIS_MAX; nAxis++)
	{
		m_lWritePos[nAxis] = 0;			// �̵��� ��ġ
		m_bIsInPosition[nAxis] = FALSE;
		m_dScale[nAxis] = MOTOR_SCALE;
	}

	SetAxisMax(HANDLER_AXIS_MAX);

	m_nInposTimeCount = 0;
}

DeviceMelsecOsan::~DeviceMelsecOsan()
{
	m_bStatusStop = TRUE;
	m_bPositionStop = TRUE;

	if(m_thdStatus != NULL)		// Thread ����
		WaitForSingleObject(m_thdStatus->m_hThread, INFINITE);
	m_thdStatus = NULL;

	if(m_thdInPosition != NULL)
	{
		m_thdInPosition->ResumeThread();
		WaitForSingleObject(m_thdInPosition->m_hThread, INFINITE);
	}

	if(m_pMelsec)
	{
		delete m_pMelsec;
		m_pMelsec = NULL;
	}
}

BOOL DeviceMelsecOsan::Initialize()
{
	BOOL bResult = m_pMelsec->Create();

	if(bResult)
	{
		if(m_thdStatus == NULL)		// Thread  Ȱ��ȭ
		{
			m_thdStatus = ::AfxBeginThread(ThreadStatus, this);
		}

		if(m_thdInPosition == NULL)
		{
			m_thdInPosition = ::AfxBeginThread(ThreadInPosition, this);
			m_thdInPosition->SuspendThread();
		}
	}

	return bResult;
}

void DeviceMelsecOsan::ReadStatus(BOOL bFirst)
{
	m_pMelsec->ReadMemsbyWord((WORD*)(&m_NewPLCBitSignal), READ_MELSEC_BASE, INTERNALRELAY, sizeof(PLC_BIT_SIGNAL)/2); // size is word-size
	m_pMelsec->ReadMemsbyWord((WORD*)(&m_NewPositionInfo), READ_MELSEC_BASE, DATAREGISTER, sizeof(POSITION_INFO)/2);

//	ReadPosition();
	ReadErrorHandlerMain();
	ReadErrorHandlerLoader();
	ReadErrorHandlerUnloader();
	ReadErrorHandlerEtc1();
	ReadErrorHandlerEtc2();
	ReadStatusHandlerLoader();
	ReadStatusHandlerUnloader();
	ReadStautsOther();
	if(bFirst)
	{
		memcpy(&m_OldPLCBitSignal, &m_NewPLCBitSignal, sizeof(PLC_BIT_SIGNAL));
		memcpy(&m_OldPositionInfo, &m_NewPositionInfo, sizeof(POSITION_INFO));
	}
}

DWORD DeviceMelsecOsan::GetIntPosition(double dPos, int nAxis)
{
	DWORD nResult = (DWORD)((dPos + 0.5 / m_dScale[nAxis]) * m_dScale[nAxis]);
	return nResult;
}

BOOL DeviceMelsecOsan::SetAxisMax(int nAxisMax)
{
	m_nAxisMax = nAxisMax;
	return TRUE;
}

BOOL DeviceMelsecOsan::GetPosition(int nAxis, double &dPosition) // real position
{
	switch(nAxis)
	{
	case HANDLER_LC:
		dPosition = m_NewPositionInfo.nLCCurrentPos / m_dScale[nAxis];
		break;
	case HANDLER_LP1:
		dPosition = m_NewPositionInfo.nLP1CurrentPos / m_dScale[nAxis];
		break;
	case HANDLER_LP2:
		dPosition = m_NewPositionInfo.nLP2CurrentPos / m_dScale[nAxis];
		break;
//	case HANDLER_LP3:
//		dPosition = m_NewPositionInfo.nLP3CurrentPos / m_dScale[nAxis];
//		break;
	case HANDLER_UC:
		dPosition = m_NewPositionInfo.nUCCurrentPos / m_dScale[nAxis];
		break;
	case HANDLER_UP1:
		dPosition = m_NewPositionInfo.nUP1CurrentPos / m_dScale[nAxis];
		break;
	case HANDLER_UP2:
		dPosition = m_NewPositionInfo.nUP2CurrentPos / m_dScale[nAxis];
		break;
//	case HANDLER_UP3:
//		dPosition = m_NewPositionInfo.nUP3CurrentPos / m_dScale[nAxis];
//		break;
	default:
		return FALSE;
	}

	return TRUE;
}

LONG DeviceMelsecOsan::GetCurrentError(ERRORCOMMAND nError)
{
	switch(nError)
	{
	case ERROR_HANDLER_MAIN	:
		return m_lErrorHandlerMain;
	case ERROR_HANDLER_LOADER	:
		return m_lErrorHandlerLoader;
	case ERROR_HANDLER_UNLOADER	:
		return m_lErrorHandlerUnloader;
	case ERROR_HANDLER_ETC1	:
		return m_lErrorHandlerEtc1;
	case ERROR_HANDLER_ETC2	:
		return m_lErrorHandlerEtc2;
	case STATUS_HANDLER_LOADER:
		return m_lStatusHandlerLoader;
	case STATUS_HANDLER_UNLOADER:
		return m_lStatusHandlerUnloader;
	}
	return 0;
}

void DeviceMelsecOsan::ReadErrorHandlerMain()
{
	m_lErrorHandlerMain = 0;

	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrPlcCPU)			? 0x00000002 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrPLCLowBattery)	? 0x00000004 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrPLCFuse)			? 0x00000008 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrQD75Unit1)		? 0x00000010 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrCOMLed)			? 0x00000020 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrWDT)				? 0x00000040 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrQD75Unit2)		? 0x00000080 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrUdFull)			? 0x00000100 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrMotorPowerOff)	? 0x00000200 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrMotorPowerOn)		? 0x00000400 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrLdUdAirOff)		? 0x00000800 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrEmergencyOn)		? 0x00001000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrLdUdTimeOver)		? 0x00002000 : 0x00000000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrLdDoorInterlock)	? 0x00004000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrUdDoorInterlock)	? 0x00008000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrLdNoBasket)		? 0x00010000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrUdNoBasket)		? 0x00020000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrLdPartInitial)	? 0x00040000 : 0x00000000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bErrUdPartInitial)	? 0x00080000 : 0x00000000;
}

void DeviceMelsecOsan::ReadStautsOther()
{
	m_lStautsOther = 0;
	m_lStautsOther += (m_NewPLCBitSignal.bMelsecConnect)		? 0x00000001 : 0x00000000;
}

void DeviceMelsecOsan::ReadErrorHandlerLoader()
{
	m_lErrorHandlerLoader = 0;

	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCOriginTimeOver)	? 0x00000001 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCMoving)			? 0x00000002 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCPosData)			? 0x00000004 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCAlarm)			? 0x00000008 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCPlusLimit)		? 0x00000010 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLCMinusLimit)		? 0x00000020 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1OriginTimeOver)	? 0x00000040 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1Moving)			? 0x00000080 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1PosData)			? 0x00000100 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1Alarm)			? 0x00000200 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1PlusLimit)		? 0x00000400 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP1MinusLimit)		? 0x00000800 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2OriginTimeOver)	? 0x00001000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2Moving)			? 0x00002000 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2PosData)			? 0x00004000 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2Alarm)			? 0x00008000 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2PlusLimit)		? 0x00010000 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP2MinusLimit)		? 0x00020000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3OriginTimeOver)	? 0x00040000 : 0x00000000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3Moving)			? 0x00080000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3PosData)			? 0x00100000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3Alarm)			? 0x00200000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3PlusLimit)		? 0x00400000 : 0x00000000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bErrLP3MinusLimit)		? 0x00800000 : 0x00000000; 
}

void DeviceMelsecOsan::ReadErrorHandlerUnloader()
{
	m_lErrorHandlerUnloader = 0;
	
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCOriginTimeOver)		? 0x00000001 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCMoving)				? 0x00000002 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCPosData)			? 0x00000004 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCAlarm)				? 0x00000008 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCPlusLimit)			? 0x00000010 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUCMinusLimit)			? 0x00000020 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1OriginTimeOver)	? 0x00000040 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1Moving)			? 0x00000080 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1PosData)			? 0x00000100 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1Alarm)				? 0x00000200 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1PlusLimit)			? 0x00000400 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP1MinusLimit)		? 0x00000800 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2OriginTimeOver)	? 0x00001000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2Moving)			? 0x00002000 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2PosData)			? 0x00004000 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2Alarm)				? 0x00008000 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2PlusLimit)			? 0x00010000 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP2MinusLimit)		? 0x00020000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3OriginTimeOver)	? 0x00040000 : 0x00000000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3Moving)			? 0x00080000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3PosData)			? 0x00100000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3Alarm)				? 0x00200000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3PlusLimit)			? 0x00400000 : 0x00000000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bErrUP3MinusLimit)		? 0x00800000 : 0x00000000; 
}

void DeviceMelsecOsan::ReadErrorHandlerEtc1()
{
	m_lErrorHandlerEtc1 = 0;
	
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdElvHoming)			? 0x00000001 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdElvLoading)			? 0x00000002 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdElvAlarm)			? 0x00000004 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdElvPlusLimit)		? 0x00000008 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdElvMinusLimit)		? 0x00000010 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdElvHoming)			? 0x00000020 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdElvLoading)			? 0x00000040 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdElvAlarm)			? 0x00000080 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdElvPlusLimit)		? 0x00000100 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdElvMinusLimit)		? 0x00000200 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdPaperTransFwdBwd)	? 0x00000400 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdPCBTransFwdBwd)		? 0x00000800 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdAlignSheetFwdBwd)	? 0x00001000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdAlignGuideFwdBwd)	? 0x00002000 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdCartClampUpDown)	? 0x00004000 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP1Vacuum)			? 0x00008000 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP2Vacuum)			? 0x00010000 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP3Vacuum)			? 0x00020000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdPaperTransFwdBwd)	? 0x00040000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdPCBTransFwdBwd)		? 0x00080000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdCartClampUpDown)	? 0x00100000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUP1Vacuum)			? 0x00200000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUP2Vacuum)			? 0x00400000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUP3Vacuum)			? 0x00800000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdCartDetectSensor)	? 0x01000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUdCartDetectSensor)	? 0x02000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP1Status)			? 0x04000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP2Status)			? 0x08000000 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLP3Status)			? 0x10000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdPCBTableStatus)		? 0x20000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrLdPaperTableStatus)	? 0x40000000 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bErrUP1Status)			? 0x80000000 : 0x00000000;
}

void DeviceMelsecOsan::ReadErrorHandlerEtc2()
{
	m_lErrorHandlerEtc2 = 0;
	
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrUP2Status)			? 0x00000001 : 0x00000000;
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrUP3Status)			? 0x00000002 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrUdPCBTableStatus)		? 0x00000004 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrUdPaperTableStatus)	? 0x00000008 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrLEstopPCBDrop)		? 0x00000010 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrULEstopPCBDrop)		? 0x00000020 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bLdBasketPaperFull)		? 0x00000040 : 0x00000000; 
	m_lErrorHandlerEtc2 += (m_NewPLCBitSignal.bErrUdElvPCBFull)			? 0x00000080 : 0x00000000; 
}

void DeviceMelsecOsan::ReadStatusHandlerLoader()
{
	m_lStatusHandlerLoader = 0;

//	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPaperTransFwd)		? 0x00000001 : 0x00000000;
//	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPaperTransBwd)		? 0x00000002 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPCBTransFwd)		? 0x00000004 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPCBTransBwd)		? 0x00000008 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdAlignSheetFwd)		? 0x00000010 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdAlignSheetBwd)		? 0x00000020 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdAlignGuideFwd)		? 0x00000040 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdAlignGuideBwd)		? 0x00000080 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdCartClampUp)		? 0x00000100 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdCartClampDown)		? 0x00000200 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick1VacOn)			? 0x00000400 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick1VacOff)		? 0x00000800 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick2VacOn)			? 0x00001000 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick2VacOff)		? 0x00002000 : 0x00000000;
//	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick3VacOn)			? 0x00004000 : 0x00000000;
//	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLdPick3VacOff)		? 0x00008000 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLCinElvPos)			? 0x00010000 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLCinTablePos)			? 0x00020000 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLP1inUpPos)			? 0x00040000 : 0x00000000;
	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLP2inUpPos)			? 0x00080000 : 0x00000000;
//	m_lStatusHandlerLoader += (m_NewPLCBitSignal.bLP3inUpPos)			? 0x00100000 : 0x00000000;
}

void DeviceMelsecOsan::ReadStatusHandlerUnloader()
{
	m_lStatusHandlerUnloader = 0;

//	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPaperTransFwd)	? 0x00000001 : 0x00000000;
//	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPaperTransBwd)	? 0x00000002 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPCBTransFwd)		? 0x00000004 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPCBTransBwd)		? 0x00000008 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdCartClampUp)		? 0x00000010 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdCartClampDown)	? 0x00000020 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick1VacOn)		? 0x00000040 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick1VacOff)		? 0x00000080 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick2VacOn)		? 0x00000100 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick2VacOff)		? 0x00000200 : 0x00000000;
//	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick3VacOn)		? 0x00000400 : 0x00000000;
//	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUdPick3VacOff)		? 0x00000800 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUCinElvPos)			? 0x00001000 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUCinTablePos)		? 0x00002000 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUP1inUpPos)			? 0x00004000 : 0x00000000;
	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUP2inUpPos)			? 0x00008000 : 0x00000000;
//	m_lStatusHandlerUnloader += (m_NewPLCBitSignal.bUP3inUpPos)			? 0x00010000 : 0x00000000;
}

BOOL DeviceMelsecOsan::IsMotorStop(BOOL bFlag)
{
	if (bFlag == FALSE)
		m_bCommandStop = FALSE;
	
	return m_bCommandStop;
}

void DeviceMelsecOsan::ReadPosition()
{
	m_nInPositionError = 0;
/*
	if(m_NewPositionInfo.nLCCurrentPos != m_lWritePos[HANDLER_LC])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 1;
		return;
	}

	if(m_NewPositionInfo.nLP1CurrentPos != m_lWritePos[HANDLER_LP1])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 2;
		return;
	}

	if(m_NewPositionInfo.nLP2CurrentPos != m_lWritePos[HANDLER_LP2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 3;
		return;
	}

	if(m_NewPositionInfo.nLP3CurrentPos != m_lWritePos[HANDLER_LP3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 4;
		return;
	}

	if(m_NewPositionInfo.nUCCurrentPos != m_lWritePos[HANDLER_UC])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 5;
		return;
	}

	if(m_NewPositionInfo.nUP1CurrentPos != m_lWritePos[HANDLER_UP1])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 6;
		return;
	}
	
	if(m_NewPositionInfo.nUP2CurrentPos != m_lWritePos[HANDLER_UP2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 7;
		return;
	}
	
	if(m_NewPositionInfo.nUP3CurrentPos != m_lWritePos[HANDLER_UP3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 8;
		return;
	}
*/
	m_bCommandStop = TRUE;
}

BOOL DeviceMelsecOsan::IsInPositionThread(int nAxis, BYTE nCommand)
{
//	TRACE("InPosition Start  1\n");

	if(nCommand == COMMAND_INPOSITION) // in case x, y, p 
	{
		if(IsMoveEnd(nAxis))
			return TRUE;
	}

	if(m_thdInPosition != NULL && m_nInPositionCount <= 0)
	{
		m_pStopTime.Pause();
		m_pStopTime.StartTime();
		m_nInposTimeCount = 0;

		m_nIsInPosition = FALSE;
		m_nInPositionCommand= nCommand;
		m_nInPositionCount = m_thdInPosition->ResumeThread();
		do
		{
			PeekMessage();
#ifndef __TEST__
			Sleep(TIME_MELSEC_STATUS);
#endif
			if(m_nIsInPosition != FALSE)
			{
				m_nInPositionCount = m_thdInPosition->SuspendThread();
				break;
			}
		} while (!m_bPositionStop);

		if (m_nIsInPosition == -1)
		{
			switch(m_nInPositionError)
			{
				case 1:
					//ErrMsgDlg(STDGNALM);
					break;
				case 2:
					//ErrMsgDlg(STDGNALM);
					break;
				case 3:
					//ErrMsgDlg(STDGNALM);
					break;
				case 4:
					//ErrMsgDlg(STDGNALM);
					break;
				case 5:
					//ErrMsgDlg(STDGNALM);
					break;
				case 6:
					//ErrMsgDlg(STDGNALM);
					break;
				case 7:
					//ErrMsgDlg(STDGNALM);
					break;
				case 8:
					//ErrMsgDlg(STDGNALM);
					break;
			}
		}
		else if (m_nIsInPosition == -2) // not use
			ErrMessage(_T("Socket time error !!!"));
		else if (m_nIsInPosition == -3) // user stop
			m_nIsInPosition = TRUE;

		return m_nIsInPosition;
	}
	TRACE(_T("InPos Thread Error\n"));
	return FALSE;
}

BOOL DeviceMelsecOsan::IsMoveEnd(int nAxis)
{
	if(nAxis == -1)
	{
//		if( abs(m_NewPositionInfo.nLCCurrentPos - m_lWritePos[HANDLER_LC] < 5) && m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
		if(m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 1;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP1CurrentPos - m_lWritePos[HANDLER_LP1] < 5) && m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
		if(m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 2;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP2CurrentPos - m_lWritePos[HANDLER_LP2] < 5) && m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
		if(m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 3;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP3CurrentPos - m_lWritePos[HANDLER_LP3] < 5) && m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
/*		if(m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 4;
			return FALSE;
		}
*/
//		if( abs(m_NewPositionInfo.nUCCurrentPos - m_lWritePos[HANDLER_UC] < 5) && m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
		if(m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 5;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nUP1CurrentPos - m_lWritePos[HANDLER_UP1] < 5) && m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
		if(m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 6;
			return FALSE;
		}
		
//		if( abs(m_NewPositionInfo.nUP2CurrentPos - m_lWritePos[HANDLER_UP2] < 5) && m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
		if(m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 7;
			return FALSE;
		}
		
//		if( abs(m_NewPositionInfo.nUP3CurrentPos - m_lWritePos[HANDLER_UP3] < 5) && m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
/*		if(m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 8;
			return FALSE;
		}
*/
		return TRUE;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
//			if( abs(m_NewPositionInfo.nLCCurrentPos - m_lWritePos[HANDLER_LC] < 5) && m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
			if(m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
			{
				return TRUE;
			}
			break;
		case HANDLER_LP1:
//			if( abs(m_NewPositionInfo.nLP1CurrentPos - m_lWritePos[HANDLER_LP1] < 5) && m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
			if(m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
			{
				return TRUE;
			}
			break;
		case HANDLER_LP2:
//			if( abs(m_NewPositionInfo.nLP2CurrentPos - m_lWritePos[HANDLER_LP2] < 5) && m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
			if(m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
			{
				return TRUE;
			}
			break;
//		case HANDLER_LP3:
//			if( abs(m_NewPositionInfo.nLP3CurrentPos - m_lWritePos[HANDLER_LP3] < 5) && m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
//			if(m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
//			{
//				return TRUE;
//			}
//			break;
		case HANDLER_UC:
//			if( abs(m_NewPositionInfo.nUCCurrentPos - m_lWritePos[HANDLER_UC] < 5) && m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
			if(m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
			{
				return TRUE;
			}
			break;
		case HANDLER_UP1:
//			if( abs(m_NewPositionInfo.nUP1CurrentPos - m_lWritePos[HANDLER_UP1] < 5) && m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
			if(m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
			{
				return TRUE;
			}
			break;
		case HANDLER_UP2:
//			if( abs(m_NewPositionInfo.nUP2CurrentPos - m_lWritePos[HANDLER_UP2] < 5) && m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
			if(m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
			{
				return TRUE;
			}
			break;
//		case HANDLER_UP3:
//			if( abs(m_NewPositionInfo.nUP3CurrentPos - m_lWritePos[HANDLER_UP3] < 5) && m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
//			if(m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
//			{
//				return TRUE;
//			}
//			break;
		}
	}

	m_nInPositionError = nAxis + 1;
	return FALSE;
}

BOOL DeviceMelsecOsan::IsHandlerBusy(int nAxis)
{
	BOOL bRet = TRUE;
	switch(nAxis)
	{
	case HANDLER_LC:
		bRet = m_NewPLCBitSignal.bLCBusy;
		break;
	case HANDLER_LP1:
		bRet = m_NewPLCBitSignal.bLP1Busy;
		break;
	case HANDLER_LP2:
		bRet = m_NewPLCBitSignal.bLP2Busy;
		break;
//	case HANDLER_LP3:
//		bRet = m_NewPLCBitSignal.bLP3Busy;
//		break;
	case HANDLER_UC:
		bRet = m_NewPLCBitSignal.bUCBusy;
		break;
	case HANDLER_UP1:
		bRet = m_NewPLCBitSignal.bUP1Busy;
		break;
	case HANDLER_UP2:
		bRet = m_NewPLCBitSignal.bUP2Busy;
		break;
//	case HANDLER_UP3:
//		bRet = m_NewPLCBitSignal.bUP3Busy;
//		break;
	}
	return bRet;
}

BOOL DeviceMelsecOsan::IsHandlerStop(int nAxis)
{
	BOOL bRet = TRUE;
	switch(nAxis)
	{
	case HANDLER_LC:
		bRet = m_NewPLCBitSignal.bLCStop;
		break;
	case HANDLER_LP1:
		bRet = m_NewPLCBitSignal.bLP1Stop;
		break;
	case HANDLER_LP2:
		bRet = m_NewPLCBitSignal.bLP2Stop;
		break;
//	case HANDLER_LP3:
//		bRet = m_NewPLCBitSignal.bLP3Stop;
//		break;
	case HANDLER_UC:
		bRet = m_NewPLCBitSignal.bUCStop;
		break;
	case HANDLER_UP1:
		bRet = m_NewPLCBitSignal.bUP1Stop;
		break;
	case HANDLER_UP2:
		bRet = m_NewPLCBitSignal.bUP2Stop;
		break;
//	case HANDLER_UP3:
//		bRet = m_NewPLCBitSignal.bUP3Stop;
//		break;
	}
	return bRet;
}

BOOL DeviceMelsecOsan::IsMotorOrigin(int nAxis)
{
	BOOL bRet = TRUE;
	if(nAxis == -1)
	{
		bRet = m_NewPLCBitSignal.bLCInitialEnd & m_NewPLCBitSignal.bLP1InitialEnd & m_NewPLCBitSignal.bLP2InitialEnd &
			m_NewPLCBitSignal.bUCInitialEnd & m_NewPLCBitSignal.bUP1InitialEnd & m_NewPLCBitSignal.bUP2InitialEnd;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
			bRet = m_NewPLCBitSignal.bLCInitialEnd;
			break;
		case HANDLER_LP1:
			bRet = m_NewPLCBitSignal.bLP1InitialEnd;
			break;
		case HANDLER_LP2:
			bRet = m_NewPLCBitSignal.bLP2InitialEnd;
			break;
//		case HANDLER_LP3:
//			bRet = m_NewPLCBitSignal.bLP3InitialEnd;
//			break;
		case HANDLER_UC:
			bRet = m_NewPLCBitSignal.bUCInitialEnd;
			break;
		case HANDLER_UP1:
			bRet = m_NewPLCBitSignal.bUP1InitialEnd;
			break;
		case HANDLER_UP2:
			bRet = m_NewPLCBitSignal.bUP2InitialEnd;
			break;
//		case HANDLER_UP3:
//			bRet = m_NewPLCBitSignal.bUP3InitialEnd;
//			break;
		}
	}
	return bRet;
}

BOOL DeviceMelsecOsan::PeekMessage()
{
	MSG msg;
	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}
	return FALSE;
}

BOOL DeviceMelsecOsan::InPositionStop()
{
	m_nIsInPosition = -3;
	return TRUE;
}

int DeviceMelsecOsan::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INPOSITION);
	}
	return IsMoveEnd(nAxis);
}

int DeviceMelsecOsan::IsInOrigin(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INORIGIN);
	}
	return IsMotorOrigin(nAxis);
}

BOOL DeviceMelsecOsan::IsReady(int nAxis)
{
	BOOL bRet = TRUE;
	if(nAxis == -1)
	{
		bRet = m_NewPLCBitSignal.bLCReady & m_NewPLCBitSignal.bLP1Ready & m_NewPLCBitSignal.bLP2Ready /*& m_NewPLCBitSignal.bLP3Ready*/ &
			m_NewPLCBitSignal.bUCReady & m_NewPLCBitSignal.bUP1Ready & m_NewPLCBitSignal.bUP2Ready;// & m_NewPLCBitSignal.bUP3Ready;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
			bRet = m_NewPLCBitSignal.bLCReady;
			break;
		case HANDLER_LP1:
			bRet = m_NewPLCBitSignal.bLP1Ready;
			break;
		case HANDLER_LP2:
			bRet = m_NewPLCBitSignal.bLP2Ready;
			break;
//		case HANDLER_LP3:
//			bRet = m_NewPLCBitSignal.bLP3Ready;
//			break;
		case HANDLER_UC:
			bRet = m_NewPLCBitSignal.bUCReady;
			break;
		case HANDLER_UP1:
			bRet = m_NewPLCBitSignal.bUP1Ready;
			break;
		case HANDLER_UP2:
			bRet = m_NewPLCBitSignal.bUP2Ready;
			break;
//		case HANDLER_UP3:
//			bRet = m_NewPLCBitSignal.bUP3Ready;
//			break;
		}
	}

	return bRet;
}

int DeviceMelsecOsan::GetAxisMax()
{
	return m_nAxisMax;
}

void DeviceMelsecOsan::GetBitSiganl(PLC_BIT_SIGNAL *pData)
{
	memcpy(pData, &m_NewPLCBitSignal, sizeof(PLC_BIT_SIGNAL));
}

int DeviceMelsecOsan::GetCurrentPos(int nAxis)
{
	if(nAxis == HANDLER_LC)
		return m_NewPositionInfo.nLCCurrentPos;
	if(nAxis == HANDLER_LP1)
		return m_NewPositionInfo.nLP1CurrentPos;
	if(nAxis == HANDLER_LP2)
		return m_NewPositionInfo.nLP2CurrentPos;
//	if(nAxis == HANDLER_LP3)
//		return m_NewPositionInfo.nLP3CurrentPos;
	if(nAxis == HANDLER_UC)
		return m_NewPositionInfo.nUCCurrentPos;
	if(nAxis == HANDLER_UP1)
		return m_NewPositionInfo.nUP1CurrentPos;
	if(nAxis == HANDLER_UP2)
		return m_NewPositionInfo.nUP2CurrentPos;
//	if(nAxis == HANDLER_UP3)
//		return m_NewPositionInfo.nUP3CurrentPos;
	return 0;
}

int DeviceMelsecOsan::GetWritePos(int nAxis)
{
	return m_lWritePos[nAxis];
}

BOOL DeviceMelsecOsan::IsUnloadertoLoadStart()
{
	return m_NewPLCBitSignal.bLoadRequestReady;
}

BOOL DeviceMelsecOsan::IsAligner(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bAlignEnd;
	}
	else
	{
		return m_NewPLCBitSignal.bAlignRun;
	}
}

BOOL DeviceMelsecOsan::IsUnload(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bUnloadEnd;	
	}
	else
	{
		return m_NewPLCBitSignal.bUnloadRun;
	}
}

BOOL DeviceMelsecOsan::IsLoader(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bLoadEnd;
	}
	else
	{
		return m_NewPLCBitSignal.bLoadRun;
	}
}

BOOL DeviceMelsecOsan::IsLoaderPicker1PCBExist()
{
	if(m_NewPLCBitSignal.bLP1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecOsan::IsLoaderPicker2PCBExist()
{
	if(m_NewPLCBitSignal.bLP2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecOsan::IsUnloaderPicker1PCBExist()
{
	if(m_NewPLCBitSignal.bUP1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecOsan::IsUnloaderPicker2PCBExist()
{
	if(m_NewPLCBitSignal.bUP2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecOsan::IsResetSwitch()
{
	return m_NewPLCBitSignal.bSystemReset;
}

BOOL DeviceMelsecOsan::IsSystemDoorBypass(BOOL bLoader)
{
//	if(bLoader)
		return m_NewPLCBitSignal.bLoaderInterlockBypass;
//	else
//		return m_NewPLCBitSignal.bUnloaderInterlockBypass;
}

BOOL DeviceMelsecOsan::IsAnyMotorRun()
{
	return (m_NewPLCBitSignal.bLCBusy | m_NewPLCBitSignal.bLP1Busy | m_NewPLCBitSignal.bLP2Busy |/* m_NewPLCBitSignal.bLP3Busy |*/
		m_NewPLCBitSignal.bUCBusy | m_NewPLCBitSignal.bUP1Busy | m_NewPLCBitSignal.bUP2Busy /*| m_NewPLCBitSignal.bUP3Busy*/);
}

BOOL DeviceMelsecOsan::IsLoadCartNoPCB()
{
	if(m_NewPLCBitSignal.bLdElvPCBExist)
		return FALSE;
	else
		return TRUE;
}

BOOL DeviceMelsecOsan::LoaderAlign()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderLoading()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloadUnloading()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 2, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderInit()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 3, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderInit()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 4, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderAlignLoading()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 5, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::SetOutPort(BYTE nPortNo, WORD wOnOff)
{
	BOOL bResult = TRUE;
	BYTE cVal;
	if(wOnOff)	cVal = 0x10;
	else		cVal = 0x01;

	switch(nPortNo)
	{
	case PORT_ALARM	:
		bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE, 1); // 1 bits
		return bResult;
		break;
	case PORT_SYSTEM_DOOR_BYPASS:
		bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE + 1, 1);
		return bResult;
		break;
	case PORT_PCB_SINGLE	:
		if((wOnOff >> 1) & 0x01)	
			cVal = 0x10;
		else
			cVal = 0x01;
		bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal, WRITE_TABLE_BASE, 1); // Left Unuse

		if(wOnOff & 0x01)
			cVal = 0x10;
		else
			cVal = 0x01;
		bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_TABLE_BASE + 1, 1); // Right Unuse

		return bResult;
		break;
	}

	return TRUE;
}

BOOL DeviceMelsecOsan::MainReset(BOOL bOn)
{
	BOOL bResult = TRUE;
	BYTE cVal;

	if(bOn)	cVal = 0x10;
	else	cVal = 0x01;

	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE + 2, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderPCBReset()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_REJECT_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderPCBReset()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_REJECT_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderCarrierElvPos()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LC_MOVING_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderCarrierTablePos()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LC_MOVING_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderCarrierElvPos()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UC_MOVING_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderCarrierTablePos()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UC_MOVING_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderPickerUpPos(int nNum)
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;

	nNum = nNum - 1;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + (nNum*10), 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderPickerUpPos(int nNum)
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;

	nNum = nNum - 1;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + (nNum*10), 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UseRoll(BOOL bUse)
{
	BOOL bResult = TRUE;
	BYTE cVal;
	
	if(!bUse)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_ROLL_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UsePaper(BOOL bUse)
{
	BOOL bResult = TRUE;
	BYTE cVal;
	
	if(!bUse)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_PAPER_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::IsHandlerTablePCBExist(BOOL bLoader)
{
	if(bLoader)
		return m_NewPLCBitSignal.bLdTablePCBExist;
	else
		return m_NewPLCBitSignal.bUdTablePCBExist;
}

BOOL DeviceMelsecOsan::IsHandlerPaperTransPCBExist(BOOL bLoader)
{
	return TRUE;
/*	if(bLoader)
		return m_NewPLCBitSignal.bLdPaperTransPCBExist;
	else
		return m_NewPLCBitSignal.bUdPaperTransPCBExist;
		*/
}

BOOL DeviceMelsecOsan::IsHandlerPartError(BOOL bLoader)
{
	if(bLoader)
		return m_NewPLCBitSignal.bLoadPartError;
	else
		return m_NewPLCBitSignal.bUnloadPartError;
}

BOOL DeviceMelsecOsan::SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn)
{
	BOOL bResult = TRUE;
	BYTE cVal, cVal2;

	if(bOn)
	{
		cVal = 0x10;
		cVal2 = 0x01;
	}
	else
	{
		cVal = 0x01;
		cVal2 = 0x10;
	}
	if(bLoader)//�δ� 
	{
		if(b1st)
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + 1, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_LP_MOVING_BASE + 2, 1); // 1 bits
		}
		else
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + 11, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_LP_MOVING_BASE + 12, 1); // 1 bits
		}
	}
	else//���δ� 
	{
		if(b1st)
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + 1, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_UP_MOVING_BASE + 2, 1); // 1 bits
		}
		else
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + 11, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_UP_MOVING_BASE + 12, 1); // 1 bits
		}
	}

	return bResult;
}

BOOL DeviceMelsecOsan::IsLPVacuum(BOOL b1st, BOOL bOn)
{
	if(b1st)
	{
		if(bOn)
			return m_NewPLCBitSignal.bLdPick1VacOn;
		else
			return m_NewPLCBitSignal.bLdPick1VacOff;
	}
	else
	{
		if(bOn)
			return m_NewPLCBitSignal.bLdPick2VacOn;
		else
			return m_NewPLCBitSignal.bLdPick2VacOff;
	}
}

BOOL DeviceMelsecOsan::IsUPVacuum(BOOL b1st, BOOL bOn)
{
	if(b1st)
	{
		if(bOn)
			return m_NewPLCBitSignal.bUdPick1VacOn;
		else
			return m_NewPLCBitSignal.bUdPick1VacOff;
	}
	else
	{
		if(bOn)
			return m_NewPLCBitSignal.bUdPick2VacOn;
		else
			return m_NewPLCBitSignal.bUdPick2VacOff;
	}
}

BOOL DeviceMelsecOsan::CheckMelsecConnect()
{
	return m_NewPLCBitSignal.bMelsecConnect;
}

BOOL DeviceMelsecOsan::LoaderTableForward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderTableBackward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderTableForward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UA_BASE, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderTableBackward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UA_BASE + 1, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderClampForward()
{
	//�ϰ� - Ŭ���� 
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 7, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderClampBackward()
{
	//��� - ��Ŭ���� 
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 6, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderClampForward()
{
	//�ϰ� - Ŭ���� 
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UA_BASE + 3, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::UnloaderClampBackward()
{
	//��� - ��Ŭ���� 
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UA_BASE + 2, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderAlignXForward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 2, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderAlignXBackward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 3, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderAlignYForward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 4, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::LoaderAlignYBackward()
{
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LA_BASE + 5, 1); // 1 bits
	return bResult;
}

BOOL DeviceMelsecOsan::IsLoaderCartClamp()
{
	return m_NewPLCBitSignal.bLdCartClampDown;
}

BOOL DeviceMelsecOsan::IsUnloaderCartClamp()
{
	return m_NewPLCBitSignal.bUdCartClampDown;
}

BOOL DeviceMelsecOsan::IsAlignSheetTableForward()
{
	return m_NewPLCBitSignal.bLdAlignSheetFwd;
}

BOOL DeviceMelsecOsan::IsAlignGuideForward()
{
	return m_NewPLCBitSignal.bLdAlignGuideFwd;
}

BOOL DeviceMelsecOsan::IsUnloaderAlignTableForward()
{
	return m_NewPLCBitSignal.bUdPCBTransBwd;
}

BOOL DeviceMelsecOsan::IsLoaderAlignTableForward()
{
	return m_NewPLCBitSignal.bLdPCBTransBwd;
}

BOOL DeviceMelsecOsan::IsUnloaderNGBoxForward()
{
	return TRUE;
}

BOOL DeviceMelsecOsan::IsUnloaderNGBoxBackward()
{
	return TRUE;
}

BOOL DeviceMelsecOsan::UnloaderNGBoxForward()
{
	return TRUE;
}
BOOL DeviceMelsecOsan::UnloaderNGBoxBackward()
{
	return TRUE;
}
PLC_BIT_SIGNAL DeviceMelsecOsan::GetMelsecIOStuct()
{
	return m_NewPLCBitSignal;
}
