#if !defined(AFX_DLGMOTORMOVE_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_)
#define AFX_DLGMOTORMOVE_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgMotorMove.h : header file
//
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButton.h"
#include "UEasyButtonEx.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgMotorMove dialog

class CDlgMotorMove : public CDialog
{
// Construction
public:
	void SetDisplayOn(BOOL bOn);
	void SetTableSuction();
	void DispStatus();
	double GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse);
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	CDlgMotorMove(CWnd* pParent = NULL);   // standard constructor

	CColorStatic	m_stcPosC;
	CColorStatic	m_stcPosC2;
	CColorStatic	m_stcPosM;
	CColorStatic	m_stcPosM2;
	CColorStatic	m_stcPosM3;

	CColorStatic	m_stcPosM4;
	CColorStatic	m_stcPosRot;
	CColorStatic	m_stcPosTopHat;

	CColorStatic	m_stcPosZ2;
	CColorStatic	m_stcPosZ1;
	CColorStatic	m_stcPosY;
	CColorStatic	m_stcPosX;
	CColorStatic	m_stcPosA1;
	CColorStatic	m_stcPosA2;

	CColorStatic	m_stcPosLP1;
	CColorStatic	m_stcPosLP2;
	CColorStatic	m_stcPosUP1;
	CColorStatic	m_stcPosUP2;

	CColorEdit	m_edtTargetY;
	CColorEdit	m_edtTargetX;
	CColorEdit	m_edtTargetZ2;
	CColorEdit	m_edtTargetZ1;
	CColorEdit	m_edtTargetC;
	CColorEdit	m_edtTargetC2;
	CColorEdit	m_edtTargetM;
	CColorEdit	m_edtTargetM2;
	CColorEdit	m_edtTargetM3;
	CColorEdit	m_edtTargetM4;
	CColorEdit	m_edtTargetRot;
	CColorEdit	m_edtTargetTopHat;
	CColorEdit	m_edtTargetA1;
	CColorEdit	m_edtTargetA2;
	CColorEdit	m_edtTargetLP1;
	CColorEdit	m_edtTargetLP2;
	CColorEdit	m_edtTargetUP1;
	CColorEdit	m_edtTargetUP2;
	UEasyButtonEx	m_btnMotorHoming;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnExtend;
	UEasyButtonEx	m_btnLoad;
	UEasyButtonEx	m_btnUnload;
	UEasyButtonEx	m_btnManualPos;
	UEasyButtonEx	m_btnNear1;
	UEasyButtonEx	m_btnNear2;
	UEasyButtonEx	m_btnReject;
	UEasyButtonEx	m_chkVacuum1;
	UEasyButtonEx	m_chkVacuum2;
	UEasyButtonEx	m_chkClamp1;
	UEasyButtonEx	m_chkClamp2;
	UEasyButtonEx	m_chkVacuumMotorOn;


	int		m_nTimer1;

	int		m_nAbs;
	BOOL	m_bTargetX;
	BOOL	m_bTargetY;
	BOOL	m_bTargetZ1;
	BOOL	m_bTargetZ2;
	BOOL	m_bTargetC;
	BOOL	m_bTargetC2;
	BOOL	m_bTargetM;
	BOOL	m_bTargetM2;
	BOOL	m_bTargetM3;

	BOOL	m_bTargetM4;
	BOOL	m_bTargetRot;
	BOOL	m_bTargetTopHat;

	BOOL	m_bTargetLP1;
	BOOL	m_bTargetLP2;
	BOOL	m_bTargetUP1;
	BOOL	m_bTargetUP2;

	BOOL	m_bTargetA1;
	BOOL	m_bTargetA2;

	BOOL	m_bMotor;
	BOOL	m_bSuction1;
	BOOL	m_bSuction2;
	BOOL	m_bClamp1;
	BOOL	m_bClamp2;
	BOOL	m_bExtend;

	BOOL m_bDisplayOn;

	CSize	m_siNormalSize;
	CSize	m_siExtendSize;
	CFont			m_fntStatic;
	CFont			m_fntBtn;
	CFont			m_fntEdit;
// Dialog Data
	//{{AFX_DATA(CDlgMotorMove)
	enum { IDD = IDD_DLG_MOTOR_MOVE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


	void EnableAllBtn(BOOL bUse);
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgMotorMove)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgMotorMove)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonMove();
	afx_msg void OnButtonHoming();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheckMotor();
	afx_msg void OnBnClickedCheckMasterOn();
	afx_msg void OnBnClickedCheckSlaveOn();
	afx_msg void OnBnClickedCheckTableClamp1();
	afx_msg void OnBnClickedCheckTableClamp2();
	afx_msg void OnBnClickedButtonPosLoading();
	afx_msg void OnBnClickedButtonPosUnloading();
	afx_msg void OnBnClickedButtonManualScalPositionMove();
	afx_msg void OnBnClickedButtonNear1();
	afx_msg void OnBnClickedButtonNear2();
	afx_msg void OnBnClickedButtonAllReject();
	afx_msg void OnBnClickedButtonExtend();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMOTORMOVE_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_)
