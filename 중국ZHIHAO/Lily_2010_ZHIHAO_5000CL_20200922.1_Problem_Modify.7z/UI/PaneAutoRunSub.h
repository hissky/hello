#if !defined(AFX_PANEAUTORUNSUB_H__136C5533_122F_46D3_BA3F_EA907B5AFEB5__INCLUDED_)
#define AFX_PANEAUTORUNSUB_H__136C5533_122F_46D3_BA3F_EA907B5AFEB5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneAutoRunSub : public CFormView
{
protected:
	CPaneAutoRunSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunSub)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunSub)
	enum { IDD = IDD_DLG_AUTO_RUN_SUB };
	UEasyButtonEx	m_btnDustSuction;
	UEasyButtonEx	m_btnFiducialSetting;
	UEasyButtonEx	m_btnRecipeGen;
	UEasyButtonEx	m_btnMoveScaleLog;
	UEasyButtonEx	m_btnDrillDisplay;
	UEasyButtonEx	m_btnDrillOneCycleStop;
	UEasyButtonEx	m_btnDrillPause;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnStart;
	UEasyButtonEx	m_btnBack;
	UEasyButtonEx	m_btnIdle;

	UEasyButtonEx	m_btnOpenBeampath;
	UEasyButtonEx	m_btnOpenShot;

	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void SetOneCycleStopText(BOOL bStop);
	void		InitBtnControl();

	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()				{ return m_nBackPaneNo; }

	void		EnableButton(BOOL bStart, BOOL bOne, BOOL bPause, BOOL bStop, BOOL bRun);

	void SetAuthorityByLevel(int nLevel);
	int				m_nUserLevel;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	CFont		m_fntBtn2;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunSub)
	afx_msg void OnButtonBack();
	afx_msg void OnButtonRecipeGen();
	afx_msg void OnButtonMoveScaleLog();
	afx_msg void OnButtonDrillDisplay();
	afx_msg void OnButtonFiducialSetting();
	afx_msg void OnButtonDustSuction();
	afx_msg void OnButtonDrillOnecycleStop();
	afx_msg void OnDestroy();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonPause();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonIdle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonOpenBeampathTable();
	afx_msg void OnBnClickedButtonOpenShotTable();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNSUB_H__136C5533_122F_46D3_BA3F_EA907B5AFEB5__INCLUDED_)
