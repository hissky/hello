#if !defined(AFX_DLGPOWERSUPPLYQUANTA_H__EB909239_FEC7_4500_9480_6C559F8D2AD9__INCLUDED_)
#define AFX_DLGPOWERSUPPLYQUANTA_H__EB909239_FEC7_4500_9480_6C559F8D2AD9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPowerSupplyQuanta.h : header file
//

#include "Led.h"
#include "ColorStatic.h"
#include "ColorEdit.h"
//#include "Device\enumPowerSupplyType.h"
//#include "Device\enumLaserScanner.h"
#include "..\Device\HLaserQuanta.h"
#include "UI\UnitEdit.h"
//#include "Log.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgPowerSupplyQuanta dialog

class HLaserQuanta;
class CDlgPowerParameter;

class CDlgPowerSupplyQuanta : public CDialog
{
// Construction
public:
	int m_nLaserNo;//hhwang 090210
	CDlgPowerSupplyQuanta(HLaserQuanta* pPowerSupply, CWnd* pParent = NULL);   // standard constructor

	COLORREF m_BackColor;
	COLORREF m_ForeColor;


	void setPowerSupply(HLaserQuanta* pPower) { m_pPowerSupply = pPower; }
	HLaserQuanta* getPowerSupply() { return m_pPowerSupply; }
// Dialog Data
	//{{AFX_DATA(CDlgPowerSupplyQuanta)
	enum { IDD = IDD_POWER_SUPPLY_QUANTA };
		CColorStatic	m_edtChiller;
	CLed	m_btnWarmUP;
	CLed	m_btnTherMistor;
	CLed	m_btnSystemOK;
	CLed	m_btnRfPwrOn;
	CLed	m_btnRflp;
	CLed	m_btnOverTemp;
	CLed	m_btnLdDriveOK;
	CLed	m_btnEnableFB;
	CLed	m_btnChiller;
	CLed	m_btnHighPower;
	CLed	m_btnVswr;
	CLed	m_btnInterLock;
	CLed	m_btnPL15VERR;
	CLed	m_btnMI15VERR;
	CColorStatic	m_edtPower;
	CColorStatic	m_edtShutter;
	CColorStatic	m_edtErrorCheck;
	CLed			m_btnSystemReady;
	int		m_ncount;
	CString	m_strLampTime;
	int		m_iLaserSel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPowerSupplyQuanta)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CDlgPowerParameter* m_pDlgPowerParameter;
	HLaserQuanta* m_pPowerSupply;
//	CFont m_Font;

	void initControls();
	void updateStatus();
//	void setControls(BOOL bEnable);
	
	// Generated message map functions
	//{{AFX_MSG(CDlgPowerSupplyQuanta)
	virtual BOOL OnInitDialog();
	afx_msg void OnPower();
	afx_msg void OnShutter();
	afx_msg void OnErrorcheck();
	afx_msg void OnCancel();
	afx_msg void OnOK();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButton1();
	afx_msg void OnButtonSetttingLampTime();
	afx_msg void OnLaser1();
	afx_msg void OnLaser2();
	//hhwang 090210
	afx_msg void OnButtonChiller();
	afx_msg void OnButtonGuide();
	//end hhwang
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPOWERSUPPLYQUANTA_H__EB909239_FEC7_4500_9480_6C559F8D2AD9__INCLUDED_)
