#if !defined(AFX_PANESYSSETUPTHETACAL_H__90CB4ED8_D07F_4313_B28D_B43220CA9AFE__INCLUDED_)
#define AFX_PANESYSSETUPTHETACAL_H__90CB4ED8_D07F_4313_B28D_B43220CA9AFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupThetaCal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupThetaCal form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\model\dpoint.h"
#include "..\Device\Calibration.h"
#include "..\Device\TCalibration.h"

class CDlgVisionOnly;

class CPaneSysSetupThetaCal : public CFormView
{
protected:
	CPaneSysSetupThetaCal();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupThetaCal)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupThetaCal)
	enum { IDD = IDD_DLG_SYS_SETUP_THETA_CAL };
		// NOTE: the ClassWizard will add data members here
	CColorStatic	m_stcRangeMin;
	CColorStatic	m_stcRangeMax;
	CColorEdit		m_edtPos1X;
	CColorEdit		m_edtPos1Y;
	CColorEdit		m_edtPos2X;
	CColorEdit		m_edtPos2Y;
	CColorEdit		m_edtInterval;
	CColorEdit		m_edtTheta;
	UEasyButtonEx	m_btnGetPos1;
	UEasyButtonEx	m_btnGetPos2;
	UEasyButtonEx	m_btnStart;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnProof;
	UEasyButtonEx	m_btnTheta;
	CListBox		m_lboxResult;
	CComboBox	m_cmbUseVision;
	//}}AFX_DATA

// Attributes
public:
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntListBox;
	CFont			m_fntCombo;

	BOOL			m_bStop;
	BOOL			m_bFinish;
	
	BOOL			m_bStartCal;
	BOOL			m_bStartProof;

	CALDATA			m_CalData;
	
// Operations
public:
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitListBoxControl();
	void			InitComboControl();

	void			AddList(CString strList);
	void			MessageLoop();
	
	void			SetButtonControl(BOOL bStart, BOOL bStop, BOOL bApply, BOOL bProof);

	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			OnMoveVisionView();

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

	void GetTheta(DPOINT dpA, DPOINT dpB, double& dDegree, double& dTheta);
	void RotatePT(double* nx, double* ny, double tx, double ty, double cx, double cy, double q);

	BOOL MoveT(double dPos);
	BOOL MoveTable(double dPosX, double dPosY);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupThetaCal)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupThetaCal();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupThetaCal)
		// NOTE - the ClassWizard will add and remove member functions here.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonStart();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonApply();
	afx_msg void OnButtonProof();
	afx_msg void OnButtonGetPos1();
	afx_msg void OnButtonGetPos2();
	afx_msg void OnDestroy();
	afx_msg void OnSelchangeComboUseVision();
	afx_msg void OnButtonTheta();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPTHETACAL_H__90CB4ED8_D07F_4313_B28D_B43220CA9AFE__INCLUDED_)
