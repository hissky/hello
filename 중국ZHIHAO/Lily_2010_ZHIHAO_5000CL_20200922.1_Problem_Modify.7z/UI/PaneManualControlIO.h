#if !defined(AFX_PANEMANUALCONTROLIO_H__67CC18DE_24F0_48A2_8E9D_332415BC1A22__INCLUDED_)
#define AFX_PANEMANUALCONTROLIO_H__67CC18DE_24F0_48A2_8E9D_332415BC1A22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIO.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIO form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"



	class CPaneManualControlIOMonitorInputSub1Pusan1;
#ifdef __PUSAN2__ 

	class CPaneManualControlIOMonitorOutputSub1Pusan1;
	class CPaneManualControlIOMonitorOutputSub2Pusan2;
#else
	class CPaneManualControlIOMonitorOutputSub1Large;
	class CPaneManualControlIOMonitorOutputSub2Pusan2;
#endif

	class CPaneManualControlIOMonitorInputSub2;
	class CPaneManualControlIOMonitorInputSub3;
	class CPaneManualControlIOMonitorInputSub4;

class CPaneManualControlIOMonitorNullSub;


class CPaneManualControlIO : public CFormView
{
protected:
	CPaneManualControlIO();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIO)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIO)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO };
	USimpleTab	m_tabManualControl;
	//}}AFX_DATA

// Attributes
public:
	HWND	m_hIOMonitor;
	CPaneManualControlIOMonitorNullSub* m_pSubNull;

	CPaneManualControlIOMonitorInputSub2* m_pSubInput2;
	CPaneManualControlIOMonitorInputSub3* m_pSubInput3;
	CPaneManualControlIOMonitorInputSub4* m_pSubInput4;
	

	CPaneManualControlIOMonitorInputSub1Pusan1* m_pSubInput1;
#ifdef __PUSAN2__ 

	CPaneManualControlIOMonitorOutputSub1Pusan1* m_pSubOutput1;
	CPaneManualControlIOMonitorOutputSub2Pusan2* m_pSubOutput2;
#else
	CPaneManualControlIOMonitorOutputSub1Large* m_pSubOutput1;
	CPaneManualControlIOMonitorOutputSub2Pusan2* m_pSubOutput2;
#endif
// Operations
public:
	void		InitTabControl();
	void		ShowTabPane(int nPaneNo);
	int			GetTabCurSel();	

	void		ChangeSubPane();
	void		KillSubTimer();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIO)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIO();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	
	int			m_nPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIO)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIO_H__67CC18DE_24F0_48A2_8E9D_332415BC1A22__INCLUDED_)
