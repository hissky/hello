// DlgPowerSupplyQuanta.cpp : implementation file
//

#include "stdafx.h"
#include "..\easyDriller.h"
#include "DlgPowerSupplyQuanta.h"
//#include "Device\IPowerQuanta.h"
//#include "MainFrm.h"
//#include "Device\IPowerContext.h"
//#include "Device\IOptionContext.h"
//#include "Device\ILSContext.h"//hhwang 090210
#include "DlgSettingLampTime.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPowerSupplyQuanta dialog

#define ID_TIMER_POWERSUPPLY_QUANTA			13
#define INTERVAL_TIMER_POWERSUPPLY_QUANTA	1000 //ms

CDlgPowerSupplyQuanta::CDlgPowerSupplyQuanta(HLaserQuanta* pPowerSupply, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPowerSupplyQuanta::IDD, pParent)
{
	ASSERT(NULL != pPowerSupply);
	m_pPowerSupply			= pPowerSupply;
	m_pDlgPowerParameter	= NULL;
	m_BackColor				= RGB(255, 255, 190);
	m_ForeColor				= RGB(0, 0, 0);
	//{{AFX_DATA_INIT(CDlgPowerSupplyQuanta)
	m_ncount = 0;
	m_strLampTime = _T("");
	m_iLaserSel = 0;
	//}}AFX_DATA_INIT
	m_nLaserNo = m_iLaserSel;//hhwang 090210
}


void CDlgPowerSupplyQuanta::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPowerSupplyQuanta)
	//hhwang 090210
	DDX_Control(pDX, IDC_STATIC_CHILLER, m_edtChiller);
	DDX_Control(pDX, IDC_LED_WARMUP, m_btnWarmUP);
	DDX_Control(pDX, IDC_LED_THERMISTOR, m_btnTherMistor);
	DDX_Control(pDX, IDC_LED_SYSTEMOK, m_btnSystemOK);
	DDX_Control(pDX, IDC_LED_RFPWRON, m_btnRfPwrOn);
	DDX_Control(pDX, IDC_LED_RFLP, m_btnRflp);
	DDX_Control(pDX, IDC_LED_OVERTEMP, m_btnOverTemp);
	DDX_Control(pDX, IDC_LED_LDDRIVEOK, m_btnLdDriveOK);
	DDX_Control(pDX, IDC_LED_ENABLEFB, m_btnEnableFB);
	DDX_Control(pDX, IDC_LED_CHILLER, m_btnChiller);
	DDX_Control(pDX, IDC_LED_HIGHPOWER, m_btnHighPower);
	DDX_Control(pDX, IDC_LED_VSWR, m_btnVswr);
	DDX_Control(pDX, IDC_LED_INTERLOCK, m_btnInterLock);
	//end hhwang
	DDX_Control(pDX, IDC_LED_PL15VERR, m_btnPL15VERR);
	DDX_Control(pDX, IDC_LED_MI15VERR, m_btnMI15VERR);
	DDX_Control(pDX, IDC_STATIC_POWER, m_edtPower);
	DDX_Control(pDX, IDC_STATIC_SHUTTER, m_edtShutter);
	DDX_Control(pDX, IDC_STATIC_ERRORCHECK, m_edtErrorCheck);
	DDX_Control(pDX, IDC_STATIC_SYSTEM_READY, m_btnSystemReady);
	DDX_Text(pDX, IDC_EDIT2010, m_ncount);
	DDX_Text(pDX, IDC_STATIC_LAMP_TIME, m_strLampTime);
	DDX_Radio(pDX, IDC_LASER1, m_iLaserSel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPowerSupplyQuanta, CDialog)
	//{{AFX_MSG_MAP(CDlgPowerSupplyQuanta)
	ON_BN_CLICKED(IDC_BUTTON_POWER, OnPower)
	ON_BN_CLICKED(IDC_BUTTON_SHUTTER, OnShutter)
	ON_BN_CLICKED(IDC_BUTTON_ERRORCHECK, OnErrorcheck)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON_SETTTING_LAMP_TIME, OnButtonSetttingLampTime)
	ON_BN_CLICKED(IDC_LASER1, OnLaser1)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDC_LASER2, OnLaser2)
	//hhwang 090210
	ON_BN_CLICKED(IDC_BUTTON_CHILLER, OnButtonChiller)
	ON_BN_CLICKED(IDC_BUTTON_GUIDE, OnButtonGuide)
	//end hhwang
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPowerSupplyQuanta message handlers

BOOL CDlgPowerSupplyQuanta::OnInitDialog() 
{
	CDialog::OnInitDialog();
//KBSong
//	m_Font.CreateFont(20, 0, 0, 0, FW_BOLD, TRUE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, _T("ANY"));
//	GetDlgItem(IDC_STATIC_POWER)->SetFont(&m_Font);
//	GetDlgItem(IDC_STATIC_SHUTTER)->SetFont(&m_Font);
//	GetDlgItem(IDC_STATIC_ERRORCHECK)->SetFont(&m_Font);
//	GetDlgItem(IDC_STATIC_CHILLER)->SetFont(&m_Font);
	
	//hhwang 090210
	
//	CEasyMarkerApp* pApp = (CEasyMarkerApp*)AfxGetApp();
	
//	ILSContext* pLSContext = pApp->getDeviceInfo()->getLSContext();
	int nLaserCnt = 1;

	if(nLaserCnt == 1)
	{
		GetDlgItem(IDC_LASER2)->EnableWindow(FALSE);
	}

	//chiller feedbacj enable check
//	if(m_pPowerSupply->getContext()->isChillerEnabled() == FALSE)
//	{
//		GetDlgItem(IDC_BUTTON_CHILLER)->EnableWindow(FALSE);
//	}
	
	//end hhwang

	//added by bdwoo 2007.09.20 New Type YVO4
/*	IOptionContext* OptiContext = ((CEasyMarkerApp*)AfxGetApp())->getDeviceInfo()->getOptionContext();	
	if(!OptiContext->m_nYVO4_Use_Shutter)
	{
		GetDlgItem(IDC_STATIC_SHUTTER_MAIN)->ShowWindow(FALSE);
		GetDlgItem(IDC_STATIC_SHUTTER)->ShowWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SHUTTER)->ShowWindow(FALSE);
	}
*/
	initControls();
	SetTimer(ID_TIMER_POWERSUPPLY_QUANTA, INTERVAL_TIMER_POWERSUPPLY_QUANTA, NULL);
	
//	UpdateData(FALSE);
	return TRUE;
}

void CDlgPowerSupplyQuanta::initControls()
{
	m_edtPower.SetForeColor(m_ForeColor);
	m_edtPower.SetBackColor(m_BackColor);
	m_edtShutter.SetForeColor(m_ForeColor);
	m_edtShutter.SetBackColor(m_BackColor);
	m_edtErrorCheck.SetForeColor(m_ForeColor);
	m_edtErrorCheck.SetBackColor(m_BackColor);
	//hhwang 090210
	m_edtChiller.SetForeColor(m_ForeColor);
	m_edtChiller.SetBackColor(m_BackColor);
	//end hhwang
}

void CDlgPowerSupplyQuanta::updateStatus()
{
	int nRedColor = CLed::LED_COLOR_RED;
	int nGreenColor = CLed::LED_COLOR_GREEN;
	int nOnMode = CLed::LED_ON;

	m_pPowerSupply->getStatusfromScanner();

	if(m_pPowerSupply->getPowerStatus() == POWER_ON)
	{
		GetDlgItem(IDC_STATIC_POWER)->SetWindowText(_T("ON"));
		GetDlgItem(IDC_BUTTON_POWER)->SetWindowText(_T("Power Off"));

		int nHour = int(m_pPowerSupply->getLampTime() / 3600);
		int nMinute = int((m_pPowerSupply->getLampTime() - nHour * 3600) / 60);
		int nSecond = int(m_pPowerSupply->getLampTime() - nHour * 3600 - nMinute * 60);
		m_strLampTime.Format(_T("%02d:%02d:%02d (h:m:s)"), nHour, nMinute, nSecond);
		GetDlgItem(IDC_STATIC_LAMP_TIME)->SetWindowText(m_strLampTime);
		//UpdateData(FALSE);	//hhwang 090210
	}
	else
	{
		GetDlgItem(IDC_STATIC_POWER)->SetWindowText(_T("OFF"));
		GetDlgItem(IDC_BUTTON_POWER)->SetWindowText(_T("Power On"));
	}

	//added by bdwoo 2007.09.20 New Type YVO4
//	IOptionContext* OptiContext = ((CEasyMarkerApp*)AfxGetApp())->getDeviceInfo()->getOptionContext();	
//	if(OptiContext->m_nYVO4_Use_Shutter)
	{
		if(m_pPowerSupply->isShutterOpen())
		{
			GetDlgItem(IDC_STATIC_SHUTTER)->SetWindowText(_T("Open"));
			GetDlgItem(IDC_BUTTON_SHUTTER)->SetWindowText(_T("Shutter Close"));
		}
		else
		{
			GetDlgItem(IDC_STATIC_SHUTTER)->SetWindowText(_T("Close"));
			GetDlgItem(IDC_BUTTON_SHUTTER)->SetWindowText(_T("Shutter Open"));
		}
	}

	if(m_pPowerSupply->isErrorIgnore())
	{
		GetDlgItem(IDC_STATIC_ERRORCHECK)->SetWindowText(_T("Ignore"));
		GetDlgItem(IDC_BUTTON_ERRORCHECK)->SetWindowText(_T("Error Check"));
	}
	else
	{
		GetDlgItem(IDC_STATIC_ERRORCHECK)->SetWindowText(_T("Check"));
		GetDlgItem(IDC_BUTTON_ERRORCHECK)->SetWindowText(_T("Error Ignore"));
	}

	//Power On/Off Button�� ������ ���� ���� check�� ���� �ʴ´�.
/*	if(OptiContext->m_nCompanyCode == COMPANY_CODE_HP)
	{
		
		if(m_pPowerSupply->isSystemReady())
		{
			m_btnSystemReady.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		}
		else
		{
			m_btnSystemReady.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
			if(m_pPowerSupply->m_bIsPowerOnStatus)
			{
				m_pPowerSupply->setPowerOff(0);
				m_pPowerSupply->m_bIsPowerOnStatus = FALSE;
				m_pPowerSupply->setShutterCloseProc();//hhwang 090210
			}
		}	
		
	}
	else if( OptiContext->m_nCompanyCode == COMPANY_CODE_HP_SPECIAL )
*/	{		
		
		if(m_pPowerSupply->isSystemReady())
		{
			m_btnSystemReady.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
			m_pPowerSupply->m_bIsPowerOnStatus = TRUE;
			m_pPowerSupply->setPowerStatus(POWER_ON);			
		}
		else
		{
			m_btnSystemReady.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
			Sleep(400);
			if(m_pPowerSupply->m_bIsPowerOnStatus)
			{
				m_pPowerSupply->setPowerStatus(POWER_OFF);
				m_pPowerSupply->m_bIsPowerOnStatus = FALSE;
				m_pPowerSupply->setShutterCloseProc();
			}
		}
//		if(m_pPowerSupply->getContext()->isChillerEnabled() == TRUE)//hhwang 090210
		{
			if(m_pPowerSupply->m_bIsPowerOnStatus)
			{
				GetDlgItem(IDC_BUTTON_SHUTTER)->EnableWindow(TRUE);
				GetDlgItem(IDC_BUTTON_CHILLER)->EnableWindow(FALSE);
			}
			else
			{
				GetDlgItem(IDC_BUTTON_SHUTTER)->EnableWindow(FALSE);
				GetDlgItem(IDC_BUTTON_CHILLER)->EnableWindow(TRUE);	
			}
		}
	}

	if(m_pPowerSupply->isMinus15VError())
		m_btnMI15VERR.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
	else
		m_btnMI15VERR.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);

	if(m_pPowerSupply->isPlus15VError())
		m_btnPL15VERR.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
	else
		m_btnPL15VERR.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
	
	//hhwang 090210
//	if(m_pPowerSupply->getContext()->isChillerEnabled() == TRUE)
	{
		if(m_pPowerSupply->m_bIsPowerOnStatus || (m_pPowerSupply->isRfPwrOn()))//over temp event -> power off & chiller off
		{
			if(m_pPowerSupply->isOverTemp() == FALSE) 
			{
				
				m_pPowerSupply->setPowerOff(0);
				Sleep(1000);
				m_pPowerSupply->setChillerOffProc();
//				ErrMessage(_T("OverTemparature!.. Power/RF OFF!"));
			}
		}
		
		if((m_pPowerSupply->isRfPwrOn()))
		{
			GetDlgItem(IDC_BUTTON_POWER)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_CHILLER)->SetWindowText(_T("ON"));
			GetDlgItem(IDC_BUTTON_CHILLER)->SetWindowText(_T("OFF"));
		}
		else
		{
			GetDlgItem(IDC_BUTTON_POWER)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_CHILLER)->SetWindowText(_T("OFF"));
			GetDlgItem(IDC_BUTTON_CHILLER)->SetWindowText(_T("ON"));
		}
	}

	if(m_pPowerSupply->isInterLock())
		m_btnInterLock.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
	else
		m_btnInterLock.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
	
	//0x320 error check
//	if(m_pPowerSupply->getContext()->isChillerEnabled() == TRUE)
	{
		if(m_pPowerSupply->isRfPwrOn())		
			m_btnRfPwrOn.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnRfPwrOn.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isRfLP())
			m_btnRflp.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnRflp.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);

		if(m_pPowerSupply->isChiller())		
			m_btnChiller.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnChiller.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isHighPower())
			m_btnHighPower.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnHighPower.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isVswr())
			m_btnVswr.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnVswr.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		
		//0x322 error check
		if(m_pPowerSupply->isTherMistor())		
			m_btnTherMistor.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnTherMistor.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isWarmUp())
			m_btnWarmUP.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnWarmUP.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		
		if(m_pPowerSupply->isSystemOk())
			m_btnSystemOK.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnSystemOK.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isLdDriveOk())		
			m_btnLdDriveOK.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnLdDriveOK.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		
		if(m_pPowerSupply->isOverTemp())
			m_btnOverTemp.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnOverTemp.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		if(m_pPowerSupply->isEnableFB())
			m_btnEnableFB.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_btnEnableFB.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		
	}
/*	else
	{
		m_btnChiller.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnHighPower.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnVswr.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);

		m_btnTherMistor.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnWarmUP.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnSystemOK.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnLdDriveOK.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);

		m_btnOverTemp.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnEnableFB.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnRfPwrOn.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		m_btnRflp.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
	}
*/	if(m_pPowerSupply->isGuideBeam())
	{
		GetDlgItem(IDC_BUTTON_GUIDE)->SetWindowText(_T("Guide On"));
	}
	else
	{
		GetDlgItem(IDC_BUTTON_GUIDE)->SetWindowText(_T("Guide Off"));
	}
	//end hhwang
}

void CDlgPowerSupplyQuanta::OnPower()
{
	
//	IOptionContext* OptiContext = ((CEasyMarkerApp*)AfxGetApp())->getDeviceInfo()->getOptionContext();
	
	if(m_pPowerSupply->getPowerStatus() == POWER_ON)
	{
		m_pPowerSupply->setPowerOff(0);
	}
	else
	{
		//2006.11.14 HP ����� �̻����� systemready�� ������� �ʴ� �ű� ��� ����.
		//�̹� ���ϵ� ������ ���� �κ� ����� ���� COMPANY CODE Optionó�� 
		//COMPANY_CODE_HP = default HP
		//COMPANY_CODE_HP2 = special HP
/*		if(OptiContext->m_nCompanyCode == COMPANY_CODE_HP)
		{
			if(m_pPowerSupply->isSystemReady())
			{
				m_pPowerSupply->setPowerOn(0);
			}
			else
			{
				ErrMessage(_T("Laser System is Not Ready"));
				return;
			}
		}
		else if( OptiContext->m_nCompanyCode == COMPANY_CODE_HP_SPECIAL )
*/		{
			m_pPowerSupply->setPowerOn(0);
		}
	}
}

void CDlgPowerSupplyQuanta::OnShutter()
{
	if(m_pPowerSupply->isShutterOpen())
	{
		m_pPowerSupply->setShutterCloseProc();
		GetDlgItem(IDC_STATIC_SHUTTER)->SetWindowText(_T("Close"));
		GetDlgItem(IDC_BUTTON_SHUTTER)->SetWindowText(_T("Shutter Open"));
	}
	else
	{
		m_pPowerSupply->setShutterOpenProc();
		GetDlgItem(IDC_STATIC_SHUTTER)->SetWindowText(_T("Open"));
		GetDlgItem(IDC_BUTTON_SHUTTER)->SetWindowText(_T("Shutter Close"));
	}
}

void CDlgPowerSupplyQuanta::OnErrorcheck()
{
	if(!m_pPowerSupply->isErrorIgnore())
	{
		GetDlgItem(IDC_STATIC_ERRORCHECK)->SetWindowText(_T("Ignore"));
		GetDlgItem(IDC_BUTTON_ERRORCHECK)->SetWindowText(_T("Error Check"));
		m_pPowerSupply->setErrorIgnore(true);
	}
	else
	{
		GetDlgItem(IDC_STATIC_ERRORCHECK)->SetWindowText(_T("Check"));
		GetDlgItem(IDC_BUTTON_ERRORCHECK)->SetWindowText(_T("Error Ignore"));
		m_pPowerSupply->setErrorIgnore(false);
	}
}

void CDlgPowerSupplyQuanta::OnCancel()
{
//	m_Font.DeleteObject();
	KillTimer(ID_TIMER_POWERSUPPLY_QUANTA);
	CDialog::OnCancel();
}

void CDlgPowerSupplyQuanta::OnOK()
{
//	m_Font.DeleteObject();
	KillTimer(ID_TIMER_POWERSUPPLY_QUANTA);
	CDialog::OnOK();
}

void CDlgPowerSupplyQuanta::OnTimer(UINT nIDEvent)
{
	if(ID_TIMER_POWERSUPPLY_QUANTA == nIDEvent)
	{
		ASSERT(NULL != m_pPowerSupply);
		updateStatus();
	}
}

void CDlgPowerSupplyQuanta::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	for(int a = 0 ; a < m_ncount ; a++)
	{
		m_pPowerSupply->TestPuls();
		Sleep(100);		
	}
	
}

void CDlgPowerSupplyQuanta::OnButtonSetttingLampTime() 
{
	// TODO: Add your control notification handler code here
	CDlgSettingLampTime dlgSetLampTime;
	dlgSetLampTime.setPowerDevice(m_pPowerSupply);
	dlgSetLampTime.DoModal();		
}

void CDlgPowerSupplyQuanta::OnLaser1() 
{
	// TODO: Add your control notification handler code here
//	IDevice* pDevice = ((CEasyMarkerApp*)AfxGetApp())->getDevice();
//	m_pPowerSupply = (HLaserQuanta*)pDevice->getPowerSupply(0);
	m_nLaserNo = 0;	//hhwang 090210	
}

void CDlgPowerSupplyQuanta::OnLaser2() 
{
	// TODO: Add your control notification handler code here
//	IDevice* pDevice = ((CEasyMarkerApp*)AfxGetApp())->getDevice();
//	m_pPowerSupply = (HLaserQuanta*)pDevice->getPowerSupply(1);
//	m_nLaserNo = 1;	//hhwang 090210	
}
//090210 hhwang 
void CDlgPowerSupplyQuanta::OnButtonChiller() 
{
	// TODO: Add your control notification handler code here
	if(!(m_pPowerSupply->isRfPwrOn()))
	{
		m_pPowerSupply->setChillerOnProc();
		GetDlgItem(IDC_STATIC_CHILLER)->SetWindowText(_T("ON"));
		GetDlgItem(IDC_BUTTON_CHILLER)->SetWindowText(_T("OFF"));
	}
	else
	{
		m_pPowerSupply->setChillerOffProc();
		GetDlgItem(IDC_STATIC_CHILLER)->SetWindowText(_T("OFF"));
		GetDlgItem(IDC_BUTTON_CHILLER)->SetWindowText(_T("ON"));
	}
}

void CDlgPowerSupplyQuanta::OnButtonGuide() 
{
	// TODO: Add your control notification handler code here
	m_pPowerSupply->actionCommand();
}
//end hhwang 