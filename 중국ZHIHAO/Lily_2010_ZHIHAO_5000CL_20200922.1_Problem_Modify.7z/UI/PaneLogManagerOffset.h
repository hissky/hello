// PaneLogManagerOffset.h: interface for the CPaneLogManagerJobTime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PANELOGMANAGEROFFSET_H__DF175814_7BF6_46CE_B461_E2FC88441805__INCLUDED_)
#define AFX_PANELOGMANAGEROFFSET_H__DF175814_7BF6_46CE_B461_E2FC88441805__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManagerOffset.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PaneLogManagerOffset form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "resource.h"

class CPaneLogManagerOffset : public CFormView
{
protected:
	CPaneLogManagerOffset();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManagerOffset)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManagerOffset)
	enum { IDD = IDD_DLG_LOG_MANAGER_OFFSET };
	CDateTimeCtrl m_dtcStart;
	CDateTimeCtrl m_dtcEnd;
	
	CTime m_ctStart;
	CTime m_ctEnd;

	CListCtrl	  m_listFiducialScale;
	UEasyButtonEx	m_btnView;
	UEasyButtonEx	m_btnSave;
	CColorEdit	m_edtHourStart;
	CColorEdit	m_edtHourEnd;
	CColorEdit	m_edtLotID;
	CComboBox	m_cmbHead;
	int		m_nSelectHead;
	//}}AFX_DATA

// Attributes
public:
	BOOL	m_bDataAdd;
	int m_nStartHour;
	int m_nEndHour;
	BOOL CheckHour();
	void MakeFileString(int nYear, int nMonth);
	void FillList();
	void UpdateTime();
	void InitEtcControl();
	void InitListControl();
	void InitStaticControl();
	void InitBtnControl();
	void InitEditControl();

	void ShowBackGround();
	void ShowDetailInformation();
	void WriteLogFile(CString& strSaveFileName);


	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntList;
	CFont		m_fntEtc;

	int			m_nTimerID;

	BOOL		m_bShow;
	BOOL		m_bOnTimer;
	
	CImageList	m_ImageList;
	TCHAR		m_lpszColumnHead[14][20];
	TCHAR		m_lpszColumnHead2[8][20];

	double		m_dMax;
	double		m_dMin;

	CStringArray	m_strLogDetailArray;

	CString m_strFilePath;
	CString m_strPrjName;

	CFont		m_fntEdit;

	int			m_nTotalTime[5];
	int			m_nSumTime[5];
	int			m_nOldYear;
	int			m_nOldMon;
	int			m_nOldDay;
	CString		m_strDate;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManagerOffset)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManagerOffset();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManagerOffset)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();	
    afx_msg void OnButtonView();
	afx_msg void OnButtonSave();
	afx_msg void OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_PANELOGMANAGEROFFSET_H__DF175814_7BF6_46CE_B461_E2FC88441805__INCLUDED_)
