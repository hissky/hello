// PaneManualDrillSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualDrillSub.h"
#include "..\model\DProject.h"
#include "..\Model\DSystemINI.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\device\devicemotor.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dprocessini.h"
#include "math.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "PaneAutoRun.h"
#include "..\device\HMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT UM_CHANGE_VISION_PARAM4	= WM_APP + 21;
const UINT UM_VISION_FIND3			= WM_APP + 31;
const UINT UM_VISION_ROI_SET		= WM_APP + 32;

UINT HoleFindThread2(LPVOID pParam)
{
	CPaneManualDrillSub* pRun = (CPaneManualDrillSub*)pParam;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	BOOL bSelectMode = FALSE;
	int nTool;
	if(gDProject.IsThereSelectData())
		bSelectMode = TRUE;
	
	BOOL b1stPanel = TRUE;
	double dX, dY;

	if(pRun->m_nCameraNo == LOW_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else if(pRun->m_nCameraNo == HIGH_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	}
	else if(pRun->m_nCameraNo == LOW_2ND_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		b1stPanel = FALSE;
	}
	else
	{
		dX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		b1stPanel = FALSE;
	}

	CString szPath;
	szPath.Format(_T("%sHoleFindOffset.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
	FILE* fileStream;
	errno_t err;
	err = fopen_s(&fileStream, szPath, "w+");

	if(err != NULL)
	{
		ErrMessage(IDS_ERR_HOLE_FIND);	
	}

	double dMoveX, dMoveY;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	POSITION pos, posData;
	CString strResult;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;

	BOOL bNoSearch = TRUE;

	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;

	if(pRun->m_nFidKind == DEFAULT_FID_INDEX) // default �������� ã�� ������ ���� skiving�̶�� 
	{
		if(gDProject.m_bSkivingMode) //gDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) != 0) // use skiving
		{
			nToolStart = ADDED_FID_TOOL;
			nToolEnd = ADDED_FID_TOOL + 1;
		}
	}

	for(int i = nToolStart; i < nToolEnd; i++)
	{
		pos = gDProject.m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = gDProject.m_Areas[i].GetNext(pos);
			if(gDProject.m_nSeparation == USE_DUAL)
			{
				pMotor->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
				dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
				dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
			}
			else
			{
				dPanelOffsetX = 0;
				dPanelOffsetY = 0;
			}
			//------
			for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
			{
				posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
				while(posData)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
					if(i == ADDED_FID_TOOL) // skiving data
						nTool = ADDED_FID_TOOL;
					else
						nTool = gDProject.m_ToolSumInfo[pHole->pOrigin->nToolNo].nRealToolNo;
					
					if( i == ADDED_FID_TOOL || 
						(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&
//						(!bSelectMode || (bSelectMode && pHole->pOrigin->bSelect))) )
						(!bSelectMode || (bSelectMode && pHole->bSelect))) )
					{
						bNoSearch = FALSE;
						
						if(b1stPanel)
						{
							dMoveX = (pAreaInfo->m_nTableX - (pHole->npPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - (pHole->npPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dY;
						}
						else
						{
							dMoveX = (pAreaInfo->m_nTableX - dPanelOffsetX - (pHole->npPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - dPanelOffsetY - (pHole->npPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dY;
						}

						if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
						{
							pRun->m_pHoleFindThread = NULL;
							CString strString, strMsg;
							strString.LoadString(IDS_ERR_MOVE_MOTOR);
							strMsg.Format(strString, "X,Y,Z");
							ErrMessage(strMsg);
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}
						if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
						{
							pRun->m_pHoleFindThread = NULL;
							ErrMessage(_T("Inposition Error"));
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}

						if(pRun->m_nCameraNo % 2 == 0)
							::Sleep(100);

						if(!pRun->SendMessage(UM_VISION_FIND3, pRun->m_nCameraNo,  MODEL_CIRCLE))
//						if(!pVision->GetRealPos(&visionResult, pRun->m_nCameraNo, 6, TRUE, myResultChar))
						{
							pRun->visionResult.x = 0;
							pRun->visionResult.y = 0;
						}

						strResult.Format(_T("%s"), pRun->myResultChar);
						if(pRun->m_pVisionTab)
							pRun->m_pVisionTab->DPHoleInfo(strResult);
						if(err == NULL)
						{
							fprintf(fileStream, "Table Cmd (%.3f, %.3f), Offset (%.3f, %.3f)\n", dMoveX, dMoveY, pRun->visionResult.x, pRun->visionResult.y);
						}
					}
					if(pRun->m_bStop)
					{
						pRun->m_pHoleFindThread = NULL;
						if(err == NULL)
							fclose(fileStream);
						pRun->ButtonEnable(TRUE);
						return 1U;
					}
				}

				posData = pAreaInfo->m_FireLines[j].GetHeadPosition();
				
				while(posData)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(posData);
					
					if(	(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&
//						(!bSelectMode || (bSelectMode && pLine->pOrigin->bSelect))) )
						(!bSelectMode || (bSelectMode && pLine->bSelect))) )
					{
						bNoSearch = FALSE;

						if(b1stPanel)
						{
							dMoveX = (pAreaInfo->m_nTableX - (pLine->npFidSPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - (pLine->npFidSPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
						}
						else
						{
							dMoveX = (pAreaInfo->m_nTableX - (pLine->npFidSPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - (pLine->npFidSPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
						}
						
						if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
						{
							pRun->m_pHoleFindThread = NULL;
							CString strString, strMsg;
							strString.LoadString(IDS_ERR_MOVE_MOTOR);
							strMsg.Format(strString, "X,Y,Z");
							ErrMessage(strMsg);
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}
						if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
						{
							pRun->m_pHoleFindThread = NULL;
							ErrMessage(_T("Inposition Error"));
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}

						if(pRun->m_nCameraNo % 2 == 0)
							::Sleep(100);

						int nIndexNo = 6;
						if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
							nIndexNo = 4;

						if(!pRun->SendMessage(UM_VISION_FIND3, pRun->m_nCameraNo, MODEL_CIRCLE))
//						if(!pVision->GetRealPos(&visionResult, pRun->m_nCameraNo, nIndexNo, TRUE, myResultChar))
						{
							pRun->visionResult.x = 0;
							pRun->visionResult.y = 0;
						}
/*						
						if(b1stPanel)
						{
							dMoveX = pLine->npFidEPos1.x + dX;
							dMoveY = pLine->npFidEPos1.y + dY;
						}
						else
						{
							dMoveX = pLine->npFidEPos2.x + dX;
							dMoveY = pLine->npFidEPos2.y + dY;
						}
*/
				
						if(b1stPanel)
						{
							dMoveX = (pAreaInfo->m_nTableX - (pLine->npFidEPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - (pLine->npFidEPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
						}
						else
						{
							dMoveX = (pAreaInfo->m_nTableX - (pLine->npFidEPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
							dMoveY = (pAreaInfo->m_nTableY - (pLine->npFidEPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
						}

						if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
						{
							pRun->m_pHoleFindThread = NULL;
							CString strString, strMsg;
							strString.LoadString(IDS_ERR_MOVE_MOTOR);
							strMsg.Format(strString, "X,Y,Z");
							ErrMessage(strMsg);
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}
						if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
						{
							pRun->m_pHoleFindThread = NULL;
							ErrMessage(_T("Inposition Error"));
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}

						if(pRun->m_nCameraNo % 2 == 0)
							::Sleep(100);

						nIndexNo = 6;
						if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
							nIndexNo = 4;

						if(!pRun->SendMessage(UM_VISION_FIND3, pRun->m_nCameraNo, MODEL_CIRCLE))
//						if(!pVision->GetRealPos(&visionResult, pRun->m_nCameraNo, nIndexNo, TRUE, myResultChar))
						{
							pRun->visionResult.x = 0;
							pRun->visionResult.y = 0;
						}
					}

					if(pRun->m_bStop)
					{
						pRun->m_pHoleFindThread = NULL;
						if(err == NULL)
							fclose(fileStream);
						pRun->ButtonEnable(TRUE);
						return 1U;
					}
				}
			}
		}
	}

	if(bNoSearch)
		ErrMessage(_T("There are no holes"));
	
	if(err == NULL)
		fclose(fileStream);
	pRun->m_pHoleFindThread = NULL;
	pRun->ButtonEnable(TRUE);
	return 1U;
}

UINT FidFindThread2(LPVOID pParam)
{
	CPaneManualDrillSub* pRun = (CPaneManualDrillSub*)pParam;

	BOOL b1stOK, b2ndOK;
	if(pRun->FindFiducial())
	{
		if(IDYES == ErrMessage(IDS_APPLY_FID, MB_ICONQUESTION|MB_YESNO))
		{
			int nError;
			if(gSystemINI.m_sSystemDevice.nFiducialFindType == 0)
				nError = gDProject.ApplyFidDataToShot(pRun->m_nFidKind, FIND_ALL_FID, USE_DUAL, b1stOK, b2ndOK);
			else if(gSystemINI.m_sSystemDevice.nFiducialFindType == 1)
				nError = gDProject.ApplyFidDataToShot_MultiFiducial(pRun->m_nFidKind, FIND_ALL_FID, FALSE, -1, USE_DUAL, b1stOK, b2ndOK);
			else if(gSystemINI.m_sSystemDevice.nFiducialFindType == 2)
				nError = gDProject.ApplyFidDataToShot_Coarse(pRun->m_nFidKind, FIND_ALL_FID, USE_DUAL, b1stOK, b2ndOK);
			if(nError == TABLE_MOVE_ERROR)
			{
				ErrMessage(IDS_ERR_APPLY_FID1);
			}
			else if(nError == MISSHOT_ERROR)
			{
				ErrMessage(IDS_ERR_APPLY_FID2);
			}
			else if(nError == FIDUCIAL_TRANS_ERROR)
			{
				ErrMessage(IDS_ERR_APPLY_FID3);	
			}
			else if(nError == OUT_TABLE_FIRE)
			{
				ErrMessage(IDS_ERR_APPLY_FID4);
			}
			else
			{
				gDProject.m_nDataLoadStep = APPLY_FID;
			}
		}
	}

	pRun->m_pFindFidThread = NULL;
	pRun->ButtonEnable(TRUE);
	return 1U;
}
/////////////////////////////////////////////////////////////////////////////
// CPaneManualDrillSub

IMPLEMENT_DYNCREATE(CPaneManualDrillSub, CFormView)

CPaneManualDrillSub::CPaneManualDrillSub()
	: CFormView(CPaneManualDrillSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualDrillSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo		= 0;
	m_pFindFidThread = NULL;
	m_pHoleFindThread = NULL;
	m_nCameraNo = 0;
	m_pVisionTab = NULL;
	m_dZPos = 1;
}

CPaneManualDrillSub::~CPaneManualDrillSub()
{
}

void CPaneManualDrillSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualDrillSub)
	DDX_Control(pDX, IDC_BUTTON_SET_REF, m_btnSetRef);
	DDX_Control(pDX, IDC_BUTTON_MOVE_REF, m_btnMoveRef);
	DDX_Control(pDX, IDC_BUTTON_INSPECTION_STOP, m_btnInspectionStop);
	DDX_Control(pDX, IDC_BUTTON_INSPECTION_START, m_btnInspectionStart);
	DDX_Control(pDX, IDC_BUTTON_FIND_FIDUCIAL, m_btnFindFiducial);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	DDX_Control(pDX, IDC_BUTTON_APPLY_REF, m_btnApplyRef);
	DDX_Control(pDX, IDC_BTN_GO_FIDUCIAL, m_btnGoFiducial);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualDrillSub, CFormView)
	//{{AFX_MSG_MAP(CPaneManualDrillSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_MOVE_REF, OnButtonMoveRef)
	ON_BN_CLICKED(IDC_BUTTON_SET_REF, OnButtonSetRef)
	ON_BN_CLICKED(IDC_BUTTON_FIND_FIDUCIAL, OnButtonFindFiducial)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_REF, OnButtonApplyRef)
	ON_BN_CLICKED(IDC_BUTTON_INSPECTION_START, OnButtonInspectionStart)
	ON_BN_CLICKED(IDC_BUTTON_INSPECTION_STOP, OnButtonInspectionStop)
	ON_MESSAGE(UM_VISION_FIND3, GetVisionResult)
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	ON_BN_CLICKED(IDC_BTN_GO_FIDUCIAL, OnBtnGoFiducial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualDrillSub diagnostics

#ifdef _DEBUG
void CPaneManualDrillSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualDrillSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualDrillSub message handlers

void CPaneManualDrillSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneManualDrillSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(130, "Arial Bold");

	// Move Reference Position
	m_btnMoveRef.SetFont( &m_fntBtn2 );
	m_btnMoveRef.SetFlat( FALSE );
	m_btnMoveRef.SetImageOrg( 10, 3 );
	m_btnMoveRef.SetIcon( IDI_MOVEREF );
	m_btnMoveRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveRef.EnableBallonToolTip();
	m_btnMoveRef.SetToolTipText( _T("Move Reference Position") );
	m_btnMoveRef.SetBtnCursor( IDC_HAND_1 );

	// Set Reference Position
	m_btnSetRef.SetFont( &m_fntBtn2 );
	m_btnSetRef.SetFlat( FALSE );
	m_btnSetRef.SetImageOrg( 10, 3 );
	m_btnSetRef.SetIcon( IDI_SETREF, 32, 32 );
	m_btnSetRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetRef.EnableBallonToolTip();
	m_btnSetRef.SetToolTipText( _T("Set Reference Position") );
	m_btnSetRef.SetBtnCursor( IDC_HAND_1 );

	// Find Fiducial
	m_btnFindFiducial.SetFont( &m_fntBtn2 );
	m_btnFindFiducial.SetFlat( FALSE );
	m_btnFindFiducial.SetImageOrg( 10, 3 );
	m_btnFindFiducial.SetIcon( IDI_FINDFIDUCIAL, 32, 32 );
	m_btnFindFiducial.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFindFiducial.EnableBallonToolTip();
	m_btnFindFiducial.SetToolTipText( _T("Find Fiducial Mark") );
	m_btnFindFiducial.SetBtnCursor( IDC_HAND_1 );

	// Apply Reference Position
	m_btnApplyRef.SetFont( &m_fntBtn2 );
	m_btnApplyRef.SetFlat( FALSE );
	m_btnApplyRef.SetImageOrg( 10, 3 );
	m_btnApplyRef.SetIcon( IDI_APPLYREF, 32, 32 );
	m_btnApplyRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyRef.EnableBallonToolTip();
	m_btnApplyRef.SetToolTipText( _T("Apply Reference Position") );
	m_btnApplyRef.SetBtnCursor( IDC_HAND_1 );

	// Drill Inspection Start
	m_btnInspectionStart.SetFont( &m_fntBtn2 );
	m_btnInspectionStart.SetFlat( FALSE );
	m_btnInspectionStart.SetImageOrg( 10, 3 );
	m_btnInspectionStart.SetIcon( IDI_FINDFIDUCIAL, 32, 32 );
	m_btnInspectionStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInspectionStart.EnableBallonToolTip();
	m_btnInspectionStart.SetToolTipText( _T("Inspection Start") );
	m_btnInspectionStart.SetBtnCursor( IDC_HAND_1 );

	// Drill Inspection Stop
	m_btnInspectionStop.SetFont( &m_fntBtn2 );
	m_btnInspectionStop.SetFlat( FALSE );
	m_btnInspectionStop.SetImageOrg( 10, 3 );
	m_btnInspectionStop.SetIcon( IDI_STOP, 32, 32 );
	m_btnInspectionStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInspectionStop.EnableBallonToolTip();
	m_btnInspectionStop.SetToolTipText( _T("Inspection Stop") );
	m_btnInspectionStop.SetBtnCursor( IDC_HAND_1 );

	// Go Fiducial
	m_btnGoFiducial.SetFont( &m_fntBtn );
	m_btnGoFiducial.SetFlat( FALSE );
	m_btnGoFiducial.SetImageOrg( 10, 3 );
	m_btnGoFiducial.SetIcon( IDI_PROCESSSETUP, 48, 48 );
	m_btnGoFiducial.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGoFiducial.EnableBallonToolTip();
	m_btnGoFiducial.SetToolTipText( _T("Move ProcessSetup - Fiducial") );
	m_btnGoFiducial.SetBtnCursor( IDC_HAND_1 );

	// Back
	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
}

void CPaneManualDrillSub::OnButtonBack() 
{
	if(IsVisionWorking())
	{
		ErrMsgDlg(STDGNALM203);
		return;
	}
	
	// 110621
/*	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus() && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bLaser && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bInit)
	{
//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
		{		
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = TRUE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
		}
	}
*/
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->SendMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneManualDrillSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualDrillSub::SetVisionTab(CPaneManualControlVision *pVision)
{
	m_pVisionTab = pVision;
}

void CPaneManualDrillSub::OnButtonMoveRef() 
{
	// TODO: Add your control notification handler code here
//	WPARAM wParam = FIDUCIAL_SETTING;
//	::AfxGetMainWnd()->SendMessage( CHANGE_PANE, wParam, DRILL );
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
//		HWND hTarget = ::FindWindow(NULL, "Vision Teaching");
//		if(hTarget)
//		{
//			gDeviceFactory.GetVision()->ShowVisionDialog(FALSE);
//		}
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();
		
		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();
		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}

	m_nCameraNo = m_pVisionTab->GetCameraNo();
	if(m_nCameraNo < 0 || m_nCameraNo > 3)
	{
		ErrMessage(IDS_ERR_SELECT_CAMERA);
		return;
	}

	BOOL b1stPanel = TRUE;
	if(gDProject.m_nSeparation == USE_1ST)
	{
		if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(gDProject.m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}

	int nCameraNo = m_nCameraNo;

	if(m_pVisionTab)
	{
		//m_pVisionTab->VisionSetting(DEFAULT_FID_INDEX);
		
		// �׳� VisionTab������� �Ϸ��� ���� ������ ���
		// �̰��� ProcessOption�� ���� Recipe�� 0��Fid ������ ����� ���� ����
		m_pVisionTab->VisionParameterSetting(DEFAULT_FID_INDEX, 0); 

	}

	CString strResult;
	TCHAR myResultChar[512] = {0,};

	double dZ1 = 0, dZ2 = 0, dX, dY;
/*
	if(!(gDProject.m_nDataLoadStep & SET_FID_ORIGIN ))
	{
		dX = gProcessINI.m_sProcessFidFind.dRefPosX + gDProject.m_dRefFidOffsetX;
		dY = gProcessINI.m_sProcessFidFind.dRefPosY + gDProject.m_dRefFidOffsetY;

		nFindMethod = FIND_ALL_FID;

		int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
		LPFIDDATA pFidData;

		for(int j = 0; j < nCnt; j++) // fid ������ŭ ã��
		{
			::Sleep(1);

			pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, j);

			if(!(pFidData->nFidType & FID_PRIMARY))
				continue;
			
			if(pFidData->nFidType & FID_VERIFY)
				continue;

			nIsFidFind = gDProject.m_Glyphs.GetUseFidFindStatus(DEFAULT_FID_INDEX, j);
			if(nFindMethod != FIND_ALL_FID && (nIsFidFind & nFindMethod) == 0)
				continue;

			break;
		}

		if( pFidData->nCam == LOW_CAM || pFidData->nCam == LOW_TO_HIGH_CAM )
		{
			// Parameter �����ϴ� �κ�
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
			{
				dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
				nCam = LOW_1ST_CAM;
			}
			if(gDProject.m_nSeparation == USE_2ND)
			{
				dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
				b1stPanel = FALSE;
				nCam = LOW_2ND_CAM;
			}
		}
		else
		{
			// Parameter �����ϴ� �κ�
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
			{
				dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
				nCam = HIGH_1ST_CAM;
			}
			if(gDProject.m_nSeparation == USE_2ND)
			{
				dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
				b1stPanel = FALSE;
				nCam = HIGH_2ND_CAM;
			}
		}

		double dCamOffsetX = 0, dCamOffsetY = 0;

		//cal distance cam 
		switch(nCam)
		{
		case HIGH_1ST_CAM : 
			dCamOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 			
			break;
		case LOW_2ND_CAM :
			dCamOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
			break;
		case HIGH_2ND_CAM :
			dCamOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
			break;
		}

		dX += dCamOffsetX;
		dY += dCamOffsetY;
	}
	else
*/
	{
		
		if(nCameraNo == LOW_1ST_CAM)
		{
			dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
			dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
			dX = gDProject.m_dRefPosX + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dY = gDProject.m_dRefPosY + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else if(nCameraNo == HIGH_1ST_CAM)
		{
			dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
			dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
			dX = gDProject.m_dRefPosX + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dY = gDProject.m_dRefPosY + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}
		else if(nCameraNo == LOW_2ND_CAM)
		{
			dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
			dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
			dX = gDProject.m_dRefPosX + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dY = gDProject.m_dRefPosY + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		}
		else
		{
			dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
			dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
			dX = gDProject.m_dRefPosX + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dY = gDProject.m_dRefPosY + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
	}

	HVision* pVision = gDeviceFactory.GetVision();
	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, b1stPanel))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "X,Y,Z");
		ErrMessage(strMsg);
		return;
	}

	this->SendMessage(UM_VISION_ROI_SET, -1, m_nCameraNo);

	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Inposition Error"));
		return;
	}

	DPOINT visionResult;

	int nIndexNo  = 6;
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		nIndexNo = 4;	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);
		nIndexNo = pFidData->sVisInfo.nModelType;
	}

	if(!pVision->GetRealPos(&visionResult, nCameraNo, nIndexNo, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	strResult.Format(_T("%s"), myResultChar);

	if(m_pVisionTab)
		m_pVisionTab->DPHoleInfo(strResult);

//	pVision->OnAcquire(m_nCameraNo);
	
}

void CPaneManualDrillSub::OnButtonSetRef() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
//		HWND hTarget = ::FindWindow(NULL, "Vision Teaching");
//		if(hTarget)
//		{
//			gDeviceFactory.GetVision()->ShowVisionDialog(FALSE);
//		}
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();

		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();
		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}
	
	CString strResult;
	m_nCameraNo = m_pVisionTab->GetCameraNo();
	if(m_nCameraNo < 0 || m_nCameraNo > 3)
	{
		ErrMessage(IDS_ERR_SELECT_CAMERA);
		return;
	}
	
	BOOL b1stPanel = TRUE;
	if(gDProject.m_nSeparation == USE_1ST)
	{
		if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(gDProject.m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}

	HVision* pVision = gDeviceFactory.GetVision();
	double dX, dY;
	pMotor->GetPosition(AXIS_X, dX, b1stPanel);
	pMotor->GetPosition(AXIS_Y, dY, b1stPanel);

#ifdef __TEST__
	dX = 606.298;
	dY = 735.099;
#endif

	int nCameraNo = m_nCameraNo;

	if(m_pVisionTab)
	{
		//m_pVisionTab->VisionSetting(DEFAULT_FID_INDEX);
		
		// �׳� VisionTab������� �Ϸ��� ���� ������ ���
		// �̰��� ProcessOption�� ���� Recipe�� 0��Fid ������ ����� ���� ����
		m_pVisionTab->VisionParameterSetting(DEFAULT_FID_INDEX, 0); 
	}

	DPOINT visionResult;

	int nIndexNo  = 6;
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		nIndexNo = 4;
	}	
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);
		nIndexNo = pFidData->sVisInfo.nModelType;
	}
	
	if(!pVision->GetRealPos(&visionResult, nCameraNo, nIndexNo, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	strResult.Format(_T("%s"), myResultChar);

	if(nCameraNo == LOW_1ST_CAM)
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - visionResult.y;
	}
	else if(nCameraNo == HIGH_1ST_CAM)
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - visionResult.y;
	}
	else if(nCameraNo == LOW_2ND_CAM)
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - visionResult.y;
	}
	else
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - visionResult.y;
	}

	if(m_pVisionTab)
		m_pVisionTab->DPHoleInfo(strResult);

	gDProject.ResetFidOffset();
	gDProject.m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, TRUE);

	m_nFidKind = DEFAULT_FID_INDEX;
//	if(gDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) > 0)
//	{
//		if(IDYES == ErrMessage(_T("Skiving Fiducial -> click [Yes]. Mechanical Fiducial -> click [No]."), MB_ICONQUESTION|MB_YESNO))
//			m_nFidKind = ADDED_FID_INDEX;
//	}

	int nDualMode = USE_1ST;
	if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		nDualMode = USE_2ND;

	BOOL b1stOK, b2ndOK;
	int nError = gDProject.ApplyFidDataToShot(m_nFidKind, FIND_ALL_FID, nDualMode, b1stOK, b2ndOK);
	if(nError == TABLE_MOVE_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID1);
	}
	else if(nError == MISSHOT_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID2);
	}
	else if(nError == OUT_TABLE_FIRE)
	{
		ErrMessage(IDS_ERR_APPLY_FID4);
	}
	else if(nError == FIDUCIAL_TRANS_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID3);
	}
//	gDProject.m_nDataLoadStep = (gDProject.m_nDataLoadStep & 0x03) + SET_FID_ORIGIN; // 20091029
	gDProject.m_nDataLoadStep = FIELD_DIVIED + SET_FID_ORIGIN; // 091117
}

void CPaneManualDrillSub::OnButtonFindFiducial() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
//		HWND hTarget = ::FindWindow(NULL, "Vision Teaching");
//		if(hTarget)
//		{
//			gDeviceFactory.GetVision()->ShowVisionDialog(FALSE);
//		}
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();

		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();
		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);
	}
	
//	WPARAM wParam = FIDUCIAL_SETTING;
//	::AfxGetMainWnd()->SendMessage( CHANGE_PANE, wParam, DRILL );

	m_nCameraNo = m_pVisionTab->GetCameraNo();
	if(m_nCameraNo < 0 || m_nCameraNo > 3)
	{
		ErrMessage(IDS_ERR_SELECT_CAMERA);
		return;
	}

	if(!(gDProject.m_nDataLoadStep & SET_FID_ORIGIN)) // 20091029
	{
		ErrMessage(IDS_SET_ORIGIN);
		return;
	}

	BOOL b1stPanel = TRUE;
	if(gDProject.m_nSeparation == USE_1ST)
	{
		if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(gDProject.m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}

	m_nFidKind = DEFAULT_FID_INDEX;

	if(gDProject.m_bSkivingMode) //gDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) > 0)
	{
		if(IDYES == ErrMessage(IDS_SKIVING_VISION, MB_ICONQUESTION|MB_YESNO))
			m_nFidKind = ADDED_FID_INDEX;
	}
	
	double dZ, dZOffset = 0;
	if(m_nFidKind == ADDED_FID_INDEX)
		dZOffset = gDProject.m_dSkivingThickOffset;
	if(m_nCameraNo == LOW_1ST_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick + dZOffset;
	}
	else if(m_nCameraNo == HIGH_1ST_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + dZOffset;
	}
	else if(m_nCameraNo == LOW_2ND_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2 + dZOffset;
	}
	else
	{
		dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + dZOffset;
	}
	
	m_dZPos = dZ;
	
/*	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	HVision* pVision = gDeviceFactory.GetVision();
	if(!pMotor->MoveZ(dZ, dZ, b1stPanel))
	{
		return;
	}
	if(!pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		return;
	}
*/
	ButtonEnable(FALSE);

//	if(m_pVisionTab)
//		m_pVisionTab->VisionSetting(m_nFidKind);

	this->SendMessage(UM_VISION_ROI_SET, -1, m_nCameraNo);
	
	m_pFindFidThread = ::AfxBeginThread(FidFindThread2, this, THREAD_PRIORITY_NORMAL);
	m_bStop = FALSE;
	
}

void CPaneManualDrillSub::OnButtonApplyRef() 
{
	// TODO: Add your control notification handler code here
}

void CPaneManualDrillSub::OnButtonInspectionStart() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
//		HWND hTarget = ::FindWindow(NULL, "Vision Teaching");
//		if(hTarget)
//		{
//			gDeviceFactory.GetVision()->ShowVisionDialog(FALSE);
//		}
		((CEasyDrillerDlg*)::AfxGetMainWnd())->OnResetLive();
	}
	
//	WPARAM wParam = FIDUCIAL_SETTING;
//	::AfxGetMainWnd()->SendMessage( CHANGE_PANE, wParam, DRILL );
	
	m_nCameraNo = m_pVisionTab->GetCameraNo();
	if(m_nCameraNo < 0 || m_nCameraNo > 3)
	{
		ErrMessage(IDS_ERR_SELECT_CAMERA);
		return;
	}

	if(!(gDProject.m_nDataLoadStep & SET_FID_ORIGIN)) // 20091029
	{
		ErrMessage(IDS_SET_ORIGIN);
		return;
	}
	
	BOOL b1stPanel = TRUE;
	if(gDProject.m_nSeparation == USE_1ST)
	{
		if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(gDProject.m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}

	double dZ;
	if(m_nCameraNo == LOW_1ST_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
	}
	else if(m_nCameraNo == HIGH_1ST_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
	}
	else if(m_nCameraNo == LOW_2ND_CAM)
	{
		dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
	}
	else
	{
		dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
	}

	m_dZPos = dZ;
	
	ButtonEnable(FALSE);
	
	m_pHoleFindThread = ::AfxBeginThread(HoleFindThread2, this, THREAD_PRIORITY_NORMAL);
	m_bStop = FALSE;
}

void CPaneManualDrillSub::OnButtonInspectionStop() 
{
	// TODO: Add your control notification handler code here
	m_bStop = TRUE;
	if(m_pHoleFindThread)
	{
		WaitForSingleObject(m_pHoleFindThread, INFINITE);
		m_pHoleFindThread = NULL;
	}
	if(m_pFindFidThread)
	{
		WaitForSingleObject(m_pFindFidThread, INFINITE);
		m_pFindFidThread = NULL;
	}
}

BOOL CPaneManualDrillSub::FindFiducial()
{
	gDProject.m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX);

	HVision* pVision = gDeviceFactory.GetVision();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dStepX, dStepY, dFinalMoveX, dFinalMoveY, dZ1, dZ2, dHeadOffsetX, dHeadOffsetY, dManualX, dManualY, dx, dy;
	double dRefX, dRefY; // ������ ������ file ��ǥ
	BOOL	b1stPanel, bHighCam, b1stFound;
	CPoint nFidFilePos, IndexP, tempOffset;
	CDPoint dOffsetP;
	DPOINT	visionResult;
	C2DTransform myTrans;
	CString strResult;
	int nCameraNo, nIndexNo;
	double dZ, dZOffset = 0;

	pMotor->GetPosition(AXIS_Z1, dZ1);		// ���� ��ġ : �̵��� �ʿ� ������ ������ġ�� �����ϱ� ����
	pMotor->GetPosition(AXIS_Z2, dZ2, FALSE);
	gDProject.m_Glyphs.GetRefPosition(dRefX, dRefY); // mm ����. ������ ������ fid�� ���� ��ǥ(default_fid ���� �ɼ� �ִ�)

	dManualX = dManualY = 0.0;	
	
	// vision x, y offset
	if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == LOW_2ND_CAM)
	{
		if(m_nCameraNo == LOW_1ST_CAM)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			b1stPanel = TRUE;
			dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick + dZOffset;
	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
			b1stPanel = FALSE;
			dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2 + dZOffset;
		
		}
		dStepX = gProcessINI.m_sProcessFidFind.dMoveLowVision.x;
		dStepY = gProcessINI.m_sProcessFidFind.dMoveLowVision.y;
		bHighCam = FALSE;
	}
	else
	{
		if(m_nCameraNo == HIGH_1ST_CAM)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			b1stPanel = TRUE;
			dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + dZOffset;
		
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
			b1stPanel = FALSE;
			dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + dZOffset;
			
		}
		dStepX = gProcessINI.m_sProcessFidFind.dMoveHighVision.x;
		dStepY = gProcessINI.m_sProcessFidFind.dMoveHighVision.y;
		bHighCam = TRUE;
	}
	nCameraNo = m_nCameraNo;

	// vision model setting, height, vision x, y offset end
	
	LPFIDDATA pFidData;

	if(m_nFidKind == ADDED_FID_INDEX)
		dZOffset = gDProject.m_dSkivingThickOffset;
	
	myTrans.SetNumPoint(2);

	int nFidRank = 0;
	if(gDProject.m_bSkivingMode)
	{
		if(m_nFidKind == ADDED_FID_INDEX)
			nFidRank = FID_SECONDARY;
		else
			nFidRank = FID_PRIMARY;
	}

	int nUseCnt = 0;
	for(int j = 0; j < gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, 0); j++) // fid ������ŭ ã��
	{
		::Sleep(5);
		
		// 110523 Recipe�� ������ Fiducial�� Parameter�� ����
		// Camera �����ϴ� �κ�
		pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, j);
		if(nFidRank != 0) // skiving project���� mechanical fid
		{
			if(!(pFidData->nFidType & nFidRank))
				continue;
		}
		
		if(pFidData->nFidType & FID_VERIFY)
			continue;
		
/*
		if(pFidData->nCam == HIGH_CAM)
		{
			if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
				b1stPanel = TRUE;
				dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + dZOffset;
				nCameraNo = HIGH_1ST_CAM;
			}
			else
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
				b1stPanel = FALSE;
				dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + dZOffset;
				nCameraNo = HIGH_2ND_CAM;
			}

			bHighCam = TRUE;
		}
		else
		{
			if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
				b1stPanel = TRUE;
				dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick + dZOffset;
				nCameraNo = LOW_1ST_CAM;
			}
			else
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
				b1stPanel = FALSE;
				dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2 + dZOffset;
				nCameraNo = LOW_2ND_CAM;
			}
			dStepX = gProcessINI.m_sProcessFidFind.dMoveLowVision.x;
			dStepY = gProcessINI.m_sProcessFidFind.dMoveLowVision.y;
			bHighCam = FALSE;
		}
	*/
		m_dZPos = dZ;
		
		// Parameter �����ϴ� �κ�
		m_pVisionTab->SendMessage(UM_CHANGE_VISION_PARAM4, DEFAULT_FID_INDEX, j);
		
		nFidFilePos = gDProject.m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, j); //um
		dOffsetP = gDProject.m_Glyphs.GetUseFidOffset(DEFAULT_FID_INDEX, j, b1stPanel); // mm. ���� �̹� ã�Ҵ� ��ġ�� ������ 0,0
		b1stFound = FALSE;					// ���� fiducial�� ã�Ҵ��� �Ǵ� --> false : return false.

		if(nUseCnt >= 2) // �ι�° ����� ã������ ���� ����� ã�� ��ġ�� �� ��Ȯ�ϹǷ� �� ��ƾ�� �ȵ�� ����.
		{
			if(nUseCnt == 2)
				myTrans.Transform();
			myTrans.TransformPoint(nFidFilePos.x, nFidFilePos.y, dx, dy);
			dOffsetP.x = (dx - nFidFilePos.x) / 1000;
			dOffsetP.y = (dy - nFidFilePos.y) / 1000;
		}

		for(int k = 0; k < gProcessINI.m_sProcessFidFind.nFidTotalRetrial; k++)
		{
			// Table move
			IndexP = GetNextStepIndex(k);

			dFinalMoveX = gDProject.m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
						  - (nFidFilePos.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
						  - IndexP.x * dStepX 					// retry fid x step
						  - dOffsetP.x 							// ���� ã�Ҵ� offset
						  + dHeadOffsetX;
			dFinalMoveY = gDProject.m_dRefPosY 
						  - (nFidFilePos.y / 1000.0 - dRefY) 	
						  - IndexP.y * dStepY 					
						  - dOffsetP.y 						
						  + dHeadOffsetY;

			if(!pMotor->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, m_dZPos + pFidData->dOffsetZ, m_dZPos + pFidData->dOffsetZ, b1stPanel))
			{
				CString strString, strMsg;
				strString.LoadString(IDS_ERR_MOVE_MOTOR);
				strMsg.Format(strString, "X,Y,Z");
				ErrMessage(strMsg);
				return FALSE;
			}
			if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				ErrMessage(_T("Inposition Error"));
				return FALSE;
			}

			if(nCameraNo % 2 == 0)
				::Sleep(100);
			
			// find Fid - vision

			nIndexNo  = j+6;
			if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
				nIndexNo = j;
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			{
				nIndexNo = pFidData->sVisInfo.nModelType;
			}
			if(gProcessINI.m_sProcessSystem.bUseManualFidSet) // ����ã��
			{
				this->SendMessage(UM_VISION_FIND3, nCameraNo, nIndexNo);
//				pVision->GetRealPos(&visionResult, m_nCameraNo, nIndexNo, TRUE, myResultChar);

				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
#ifdef USE_VISION_PRO
					visionResult.x = gProcess.m_ResultData[nCameraNo].dx;
					visionResult.y = gProcess.m_ResultData[nCameraNo].dy;
#endif
				}
				
				//pVision->OnLive(nCameraNo, TRUE);
				::AfxGetMainWnd()->SendMessage(VISION_LIVE, nCameraNo, TRUE);
				
				ErrMessage(IDS_MANUALFID_CENTER);
				
				while (TRUE)
				{
					if(gDeviceFactory.GetMotor()->GetCurrentMode() != MODE_MPG)
						break;
					ErrMessage(IDS_MANUALFID_OFF);
				}
				
				//pVision->OnLive(nCameraNo, FALSE);
				::AfxGetMainWnd()->SendMessage(VISION_LIVE, nCameraNo, FALSE);
				
				gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dManualX);
				gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dManualY);
			}

			if(b1stFound = this->SendMessage(UM_VISION_FIND3, nCameraNo, nIndexNo))
//			if(b1stFound = pVision->GetRealPos(&visionResult, m_nCameraNo, nIndexNo, TRUE, myResultChar))
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					#ifdef USE_VISION_PRO
						visionResult.x = gProcess.m_ResultData[nCameraNo].dx;
						visionResult.y = gProcess.m_ResultData[nCameraNo].dy;
					#endif
				}

				if(gProcessINI.m_sProcessSystem.bUseManualFidSet)
				{
					gDProject.m_Glyphs.SetUseFidOffset(DEFAULT_FID_INDEX, j, b1stPanel, 
						IndexP.x * dStepX + dOffsetP.x + visionResult.x + (dFinalMoveX - dManualX), 
						IndexP.y * dStepY + dOffsetP.y + visionResult.y + (dFinalMoveY - dManualY));
				}
				else
				{
					gDProject.m_Glyphs.SetUseFidOffset(DEFAULT_FID_INDEX, j, b1stPanel, 
										IndexP.x * dStepX + dOffsetP.x + visionResult.x, 
										IndexP.y * dStepY + dOffsetP.y + visionResult.y);
				}
				strResult.Format(_T("%s"), myResultChar);
				if(m_pVisionTab)
					m_pVisionTab->DPHoleInfo(strResult);

				if(nUseCnt < 2)
				{
					tempOffset = gDProject.m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, j, b1stPanel);
					myTrans.SetReferencePoint(nFidFilePos.x, nFidFilePos.y, nUseCnt);
					myTrans.SetTransformedPoint(nFidFilePos.x + tempOffset.x, nFidFilePos.y + tempOffset.y, nUseCnt);
				}
			}
			else if(gProcessINI.m_sProcessSystem.bUseManualFidSet)
			{
				ErrMessage(IDS_MANUALFID_APPLY);
				
				gDProject.m_Glyphs.SetUseFidOffset(DEFAULT_FID_INDEX, j, b1stPanel,
					IndexP.x * dStepX + dOffsetP.x + (dFinalMoveX - dManualX),
					IndexP.y * dStepY + dOffsetP.y + (dFinalMoveY - dManualY));

				strResult.Format(_T("%s"), myResultChar);
				if(m_pVisionTab)
					m_pVisionTab->DPHoleInfo(strResult);
				
				if(nUseCnt < 2)
				{
					tempOffset = gDProject.m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, j, b1stPanel);
					myTrans.SetReferencePoint(nFidFilePos.x, nFidFilePos.y, nUseCnt);
					myTrans.SetTransformedPoint(nFidFilePos.x + tempOffset.x, nFidFilePos.y + tempOffset.y, nUseCnt);
				}
				b1stFound = TRUE;
			}

			if(m_bStop)
			{
				return FALSE;
			}
			
			if(b1stFound)
				break;
		}

		gDProject.m_Glyphs.SetFidAcquireRet(DEFAULT_FID_INDEX, j, b1stFound, !b1stPanel); // 1stPanel
		gDProject.m_Glyphs.SetFidAcquireRet(DEFAULT_FID_INDEX, j, b1stFound, b1stPanel); // 2ndPanel �Ѵ� ����

		if(!b1stFound)
		{
			ErrMessage(IDS_NO_FIDUCIAL);
			return FALSE;
		}

		nUseCnt++;
	}

	// check fid is OK
//	if(!CheckFoundFidValid(m_nFidKind))
//	{
//		ErrMessage(IDS_FIDUCIAL_DATA);
//		return FALSE;
//	}

	return TRUE;
}

CPoint CPaneManualDrillSub::GetNextStepIndex(int nStepNo)
{
	CPoint pos(0,0);
	if(nStepNo == 0)
		return pos;
	int num = (int)sqrt((double)nStepNo) + 2;
	
	for(int j = 1; j< num; j++)
	{
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.x++;
			else pos.x--;
			if(nStepNo == 0) return pos;
		}
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.y++;
			else pos.y--;
			if(nStepNo == 0) return pos;
		}
	}
	return pos;
}

BOOL CPaneManualDrillSub::CheckFoundFidValid(int nFidKind)
{
/*	CDPoint dpMOffset1, dpMOffset2, dpSOffset1, dpSOffset2;
	CDPoint dp1, dp2;
	double dLeng, dx, dy, dLengRef;

	int nFidRank = 0;
	int nTotalCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	int nCnt = nTotalCnt;
	int nStart;

	if(gDProject.m_bSkivingMode)
	{
		if(nFidKind == DEFAULT_FID_INDEX)
			nFidRank = FID_PRIMARY;
		else
			nFidRank = FID_SECONDARY;
	}
	else
		nCnt = nCnt - 1;
	
	int nTotalPrimary = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_PRIMARY);
	int nTotalSecondary = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_SECONDARY);
	
	int nPrimary = 0, nSecondary = 0;
	int nPrimary2 = 0, nSecondary2 = 0;

	LPFIDDATA pFidData, pFidData2;

	for(int i = 0; i < nCnt; i++)
	{
		pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);		
		
		if(nFidRank == FID_PRIMARY)
		{
			if(!(pFidData->nFidType & FID_PRIMARY))
				continue;

			if(pFidData->nFidType & FID_VERIFY)
				continue;
			
			nPrimary++;
			if(nPrimary + 1 == nTotalPrimary)
				break;
		}
		else if(nFidRank == FID_SECONDARY)
		{
			if(!(pFidData->nFidType & FID_SECONDARY))
				continue;

			if(pFidData->nFidType & FID_VERIFY)
				continue;
			
			nSecondary++;
			if(nSecondary + 1 == nTotalSecondary)
				break;
		}

		if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
		{
			dpMOffset1 = gDProject.m_Glyphs.GetUseFidOffset(nFidKind, i, TRUE);
			dp1		= gDProject.m_Glyphs.GetUseFidPoint(nFidKind, i);
		}
		else 
		{
			dpSOffset1 = gDProject.m_Glyphs.GetUseFidOffset(nFidKind, i, FALSE);
			dp1		= gDProject.m_Glyphs.GetUseFidPoint(nFidKind, i);
		}

		if(gDProject.m_bSkivingMode)
			nStart = i;
		else
			nStart = i + 1;
		
		nPrimary2 = nSecondary2 = 0;
		for(int j = nStart; j < nTotalCnt; j++)
		{
			pFidData2 = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, j);
			
			if(nFidRank == FID_PRIMARY)
			{
				if(!(pFidData2->nFidType & FID_PRIMARY))
					continue;

				if(pFidData2->nFidType & FID_VERIFY)
					continue;
				
				nPrimary2++;
				if(nPrimary2 <= nPrimary)
					continue;
			}
			else if(nFidRank == FID_SECONDARY)
			{
				if(!(pFidData2->nFidType & FID_SECONDARY))
					continue;

				if(pFidData2->nFidType & FID_VERIFY)
					continue;
				
				nSecondary2++;
				if(nSecondary2 <= nSecondary)
					continue;
			}
			
			dp2		= gDProject.m_Glyphs.GetUseFidPoint(DEFAULT_FID_INDEX, j);
			dLengRef = sqrt( (dp1.x - dp2.x)*(dp1.x - dp2.x) + (dp1.y - dp2.y) * (dp1.y - dp2.y));
			if(m_nCameraNo == LOW_1ST_CAM || m_nCameraNo == HIGH_1ST_CAM)
			{
				dpMOffset2 = gDProject.m_Glyphs.GetUseFidOffset(DEFAULT_FID_INDEX, j, TRUE);
				dx = dp1.x - dp2.x + dpMOffset1.x - dpMOffset2.x;
				dy = dp1.y - dp2.y + dpMOffset1.y - dpMOffset2.y;
			}
			else
			{
				dpSOffset2 = gDProject.m_Glyphs.GetUseFidOffset(DEFAULT_FID_INDEX, j, FALSE);
				dx = dp1.x - dp2.x + dpSOffset1.x - dpSOffset2.x;
				dy = dp1.y - dp2.y + dpSOffset1.y - dpSOffset2.y;
			}
			dLeng = sqrt(dx*dx + dy*dy);
			if(fabs(dLeng - dLengRef) > gProcessINI.m_sProcessFidFind.dPCBLenTolerance)
				return FALSE;
		}
	}
*/	return TRUE;
}

BOOL CPaneManualDrillSub::ButtonEnable(BOOL bEnable)
{
	GetDlgItem(IDC_BUTTON_MOVE_REF)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SET_REF)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_FIND_FIDUCIAL)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_INSPECTION_START)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_BACK)->EnableWindow(bEnable);
	if(m_pVisionTab)
		m_pVisionTab->EnableButton(bEnable);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
	return TRUE;
}

void CPaneManualDrillSub::ShowHoleFind(BOOL bShow)
{
	if(bShow)
	{
		GetDlgItem(IDC_BUTTON_FIND_FIDUCIAL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_INSPECTION_START)->ShowWindow(SW_SHOW);
	}
	else
	{
		GetDlgItem(IDC_BUTTON_FIND_FIDUCIAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_INSPECTION_START)->ShowWindow(SW_HIDE);
	}
}

BOOL CPaneManualDrillSub::IsVisionWorking()
{
	if(m_pHoleFindThread || m_pFindFidThread)
		return TRUE;
	else
		return FALSE;
}

LRESULT CPaneManualDrillSub::GetVisionResult(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		return pVision->GetRealPos(&visionResult, wParam, lParam, TRUE, myResultChar);
	}
	return 1L;
}

LRESULT CPaneManualDrillSub::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}

void CPaneManualDrillSub::OnBtnGoFiducial() 
{
	WPARAM wParam = PROCESS_SETUP;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 4 ); // Fiducial Tab
}

BOOL CPaneManualDrillSub::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_SUB) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
