// PaneSubMotorPosition.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSubMotorPosition.h"
#include "..\EasyDrillerDlg.h"
#include "..\device\hdevicefactory.h"
#include "..\device\DeviceMotor.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HLaserAttenuator.h"
#include "..\device\HMotor.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPosition

IMPLEMENT_DYNCREATE(CPaneSubMotorPosition, CFormView)

CPaneSubMotorPosition::CPaneSubMotorPosition()
	: CFormView(CPaneSubMotorPosition::IDD)
{
	//{{AFX_DATA_INIT(CPaneSubMotorPosition)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

CPaneSubMotorPosition::~CPaneSubMotorPosition()
{
}

void CPaneSubMotorPosition::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSubMotorPosition)
	DDX_Control(pDX, IDC_STATIC_POS_X_VALUE, m_stcPosX);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VALUE, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VALUE, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Z2_VALUE, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE3, m_stcPosM2);
	DDX_Control(pDX, IDC_STATIC_POS_C_VALUE, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_LC_VALUE, m_stcPosLC);
	DDX_Control(pDX, IDC_STATIC_POS_UC_VALUE, m_stcPosUC);
	DDX_Control(pDX, IDC_STATIC_POS_C_VALUE3, m_stcPosC2);

	//2011524
	DDX_Control(pDX, IDC_STATIC_POSA_VALUE, m_stcPos1A);
	DDX_Control(pDX, IDC_STATIC_POSA2_VALUE, m_stcPos2A);


	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSubMotorPosition, CFormView)
	//{{AFX_MSG_MAP(CPaneSubMotorPosition)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPosition diagnostics

#ifdef _DEBUG
void CPaneSubMotorPosition::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSubMotorPosition::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPosition message handlers

void CPaneSubMotorPosition::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();

	InitTimer();

#ifdef __KUNSAN_1__
	GetDlgItem(IDC_STATIC_POS_C)->SetWindowText("C1");
	GetDlgItem(IDC_STATIC_POS_C3)->SetWindowText("C2");
	GetDlgItem(IDC_STATIC_POS_M_VALUE3)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATIC_POS_M3)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATIC_POS_C_VALUE3)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATIC_POS_C3)->EnableWindow(FALSE);
#endif
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		m_stcPosZ2.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
		m_stcPosZ2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			GetDlgItem(IDC_STATIC_POS_Z1)->EnableWindow(FALSE);
			m_stcPosZ1.EnableWindow(FALSE);
		}

	}
	if(gSystemINI.m_sHardWare.nLaserType != LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(TRUE);
			m_stcPosZ2.EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_POS_Z2)->SetWindowText("T");
			m_stcPosZ2.ShowWindow(SW_SHOW);
		}
		else
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
			m_stcPosZ2.ShowWindow(SW_HIDE);
		}
			
		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);
	}
}

void CPaneSubMotorPosition::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");
	m_fntStatic2.CreatePointFont(110, "Arial Bold");
	
	// Position
	GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->SetFont( &m_fntStatic2 );

	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_LC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_UC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_C3)->SetFont( &m_fntStatic );

	//2011524
	GetDlgItem(IDC_STATIC_POSA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POSA2)->SetFont( &m_fntStatic );

	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM2.SetFont( &m_fntStatic );
	m_stcPosM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC2.SetFont( &m_fntStatic );
	m_stcPosC2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosLC.SetFont( &m_fntStatic );
	m_stcPosLC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosLC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosUC.SetFont( &m_fntStatic );
	m_stcPosUC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosUC.SetBackColor( VALUE_BACK_COLOR );

	//2011524
	m_stcPos1A.SetFont( &m_fntStatic );
	m_stcPos1A.SetForeColor( VALUE_FORE_COLOR );
	m_stcPos1A.SetBackColor( VALUE_BACK_COLOR );


	m_stcPos2A.SetFont( &m_fntStatic );
	m_stcPos2A.SetForeColor( VALUE_FORE_COLOR );
	m_stcPos2A.SetBackColor( VALUE_BACK_COLOR );


	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_STATIC_POS_M)->SetWindowText("A1");
		GetDlgItem(IDC_STATIC_POS_C)->SetWindowText("A2");
	}
}

HBRUSH CPaneSubMotorPosition::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSubMotorPosition::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dPos = 0;
	int nPos = 0;
	CString strData;
	strData.GetBuffer(256);
	// X
	pMotor->GetRawPosition( AXIS_X, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );
	
	// Y
	pMotor->GetRawPosition( AXIS_Y, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );
	
	// Z1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z1, dPos );

	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );
	
	// Z2
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z2, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );
	
	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M, dPos );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );

	// M2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M2, dPos );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM2.SetWindowText( (LPCTSTR)strData );
	
	// C
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_C, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosC.SetWindowText( (LPCTSTR)strData );

	//C2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_C2, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosC2.SetWindowText( (LPCTSTR)strData );

#ifdef __KUNSAN_1__
	// L.C
	pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos/1000);
	m_stcPosLC.SetWindowText( (LPCTSTR)strData );
	
	// U.C
	pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos/1000);
	m_stcPosUC.SetWindowText( (LPCTSTR)strData );
#else
	// L.C
	pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosLC.SetWindowText( (LPCTSTR)strData );
	
	// U.C
	pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosUC.SetWindowText( (LPCTSTR)strData );
#endif


	//A1
	pMotor->GetRawPosition( AXIS_A1, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPos1A.SetWindowText( (LPCTSTR)strData );

	//A2
	pMotor->GetRawPosition( AXIS_A2, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPos2A.SetWindowText( (LPCTSTR)strData );

	m_bTimer = FALSE;
	strData.ReleaseBuffer();
}

void CPaneSubMotorPosition::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	if(!m_bTimer)
		DispStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneSubMotorPosition::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_bTimer = FALSE;
		m_nTimerID = SetTimer(999, 500, NULL);
	}
}

void CPaneSubMotorPosition::DestroyTimer()
{
	if(m_nTimerID)
	{
		m_bTimer = TRUE;
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneSubMotorPosition::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	m_fntStatic.DeleteObject();
	m_fntStatic2.DeleteObject();
}
