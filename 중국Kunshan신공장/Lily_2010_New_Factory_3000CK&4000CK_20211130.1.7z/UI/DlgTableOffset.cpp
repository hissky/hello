// DlgTableOffset.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgTableOffset.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgTableOffset dialog


CDlgTableOffset::CDlgTableOffset(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTableOffset::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgTableOffset)
		// NOTE: the ClassWizard will add member initialization here
	m_dOffsetX = 0.0;
	m_dOffsetY = 0.0;
	m_nIndex;
	//}}AFX_DATA_INIT
}

BOOL CDlgTableOffset::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	CString str;
	str.Format(_T(" #%d Area "), m_nIndex);
	GetDlgItem(IDC_STATIC_GROUP_TABLE_OFFSET)->SetWindowText(str);
	
	return TRUE;
}

void CDlgTableOffset::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgTableOffset)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Text(pDX, IDC_EDIT_TABLE_OFFSET_X, m_dOffsetX);
	DDX_Text(pDX, IDC_EDIT_TABLE_OFFSET_Y, m_dOffsetY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgTableOffset, CDialog)
	//{{AFX_MSG_MAP(CDlgTableOffset)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgTableOffset message handlers

void CDlgTableOffset::SetTableOffset(int nIndex, double dX, double dY)
{
	m_dOffsetX = dX;
	m_dOffsetY = dY;
	m_nIndex = nIndex;
}

void CDlgTableOffset::GetTableOffset(double& dX, double& dY)
{
	dX = m_dOffsetX;
	dY = m_dOffsetY;
}