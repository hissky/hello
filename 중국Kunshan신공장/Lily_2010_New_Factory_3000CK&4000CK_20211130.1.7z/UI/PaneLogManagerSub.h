#if !defined(AFX_PANELOGMANAGERSUB_H__D38D710A_51D4_4E0C_B068_ACE2C905D54E__INCLUDED_)
#define AFX_PANELOGMANAGERSUB_H__D38D710A_51D4_4E0C_B068_ACE2C905D54E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManagerSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneLogManagerSub : public CFormView
{
protected:
	CPaneLogManagerSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManagerSub)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManagerSub)
	enum { IDD = IDD_DLG_LOG_MANAGER_SUB };
	UEasyButtonEx	m_btnBack;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		InitBtnControl();
	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManagerSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManagerSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;

	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManagerSub)
	afx_msg void OnButtonBack();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELOGMANAGERSUB_H__D38D710A_51D4_4E0C_B068_ACE2C905D54E__INCLUDED_)
