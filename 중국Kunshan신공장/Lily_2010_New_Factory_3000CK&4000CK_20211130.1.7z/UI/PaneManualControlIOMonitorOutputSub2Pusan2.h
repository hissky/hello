#if !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB2PUSAN2_H__D4180CA3_BA37_494E_955F_8CB07BE3A79E__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB2PUSAN2_H__D4180CA3_BA37_494E_955F_8CB07BE3A79E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorOutputSub2Pusan2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Pusan2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
class CPaneManualControlIOMonitorOutputSub2Pusan2 : public CFormView
{
protected:
	CPaneManualControlIOMonitorOutputSub2Pusan2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorOutputSub2Pusan2)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorOutputSub2Pusan2)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_OUTPUT_SUB2_PUSAN2 };
	UEasyButtonEx m_btnLoadCarr1OriPos;
	UEasyButtonEx m_btnLoadCarr1AlignPos;
	UEasyButtonEx m_btnLoadCarr1TablePos;
	UEasyButtonEx m_btnLoadCarr1CartPos;
	UEasyButtonEx m_btnLoadCarr2OriPos;
	UEasyButtonEx m_btnLoadCarr2AlignPos;
	UEasyButtonEx m_btnLoadCarr2TablePos;
	UEasyButtonEx m_btnLoadCarr2CartPos;
	UEasyButtonEx m_btnLoadCarr1SuctionOn;
	UEasyButtonEx m_btnLoadCarr1SuctionOff;
	UEasyButtonEx m_btnLoadCarr2SuctionOn;
	UEasyButtonEx m_btnLoadCarr2SuctionOff;
	UEasyButtonEx m_btnLoadClamp;
	UEasyButtonEx m_btnLoadUnclamp;
	UEasyButtonEx m_btnLoadTableFwd;
	UEasyButtonEx m_btnLoadTableBwd;
	UEasyButtonEx m_btnLoadAlignFwd;
	UEasyButtonEx m_btnLoadAlignBwd;
	UEasyButtonEx m_btnLoadSheetTableFwd;
	UEasyButtonEx m_btnLoadSheetTableBwd;
	UEasyButtonEx m_btnUnloadCarr1OriPos;
	UEasyButtonEx m_btnUnloadCarr1AlignPos;
	UEasyButtonEx m_btnUnloadCarr1TablePos;
	UEasyButtonEx m_btnUnloadCarr1CartPos;
	UEasyButtonEx m_btnUnloadCarr2OriPos;
	UEasyButtonEx m_btnUnloadCarr2AlignPos;
	UEasyButtonEx m_btnUnloadCarr2TablePos;
	UEasyButtonEx m_btnUnloadCarr2CartPos;
	UEasyButtonEx m_btnUnloadCarr1SuctionOn;
	UEasyButtonEx m_btnUnloadCarr1SuctionOff;
	UEasyButtonEx m_btnUnloadCarr2SuctionOn;
	UEasyButtonEx m_btnUnloadCarr2SuctionOff;
	UEasyButtonEx m_btnNGBoxFwd;
	UEasyButtonEx m_btnNGBoxBwd;
	
	UEasyButtonEx m_btnUnloadClamp;
	UEasyButtonEx m_btnUnloadUnclamp;
	UEasyButtonEx m_btnUnloadTableFwd;
	UEasyButtonEx m_btnUnloadTableBwd;	
	UEasyButtonEx m_btnUnloadElvUnloadPos;
	UEasyButtonEx m_btnUnloadElvOriPos;
	UEasyButtonEx m_btnLoadElvLoadPos;
	UEasyButtonEx m_btnLoadElvOriPos;
	UEasyButtonEx m_btnLoadCarrCartPos;
	UEasyButtonEx m_btnLoadCarrCartPos2;
	UEasyButtonEx m_btnLoadCarrTablePos;
	UEasyButtonEx m_btnLoadCarrAlignPos;
	UEasyButtonEx m_btnLoadCarrAlignPos2;
	UEasyButtonEx m_btnUnloadCarrCartPos;
	UEasyButtonEx m_btnUnloadCarrTablePos;
	UEasyButtonEx m_btnUnloadCarrAlignPos;
	UEasyButtonEx m_btnResetLoader1;
	UEasyButtonEx m_btnResetLoader2;
	UEasyButtonEx m_btnResetLoaderTable;
	UEasyButtonEx m_btnResetUnLoader1;
	UEasyButtonEx m_btnResetUnLoader2;
	UEasyButtonEx m_btnResetUnLoaderTable;
	UEasyButtonEx m_btnResetTable1;
	UEasyButtonEx m_btnResetTable2;
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntBtn;

// Operations
public:
	void UpdateStatus();
	void InitBtnControl();

	void InitTimer();
	void DestroyTimer();
	
	int m_nTimerID;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif
	BOOL	m_bStatusLoader1;
	BOOL	m_bStatusLoader2;
	BOOL	m_bStatusUnloader1;
	BOOL	m_bStatusUnloader2;
	BOOL	m_bStatusTable1;
	BOOL	m_bStatusTable2;
	BOOL	m_bStatusAligner;
	BOOL	m_bStatusAligner2;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorOutputSub2Pusan2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorOutputSub2Pusan2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorOutputSub2Pusan2)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonLoaderPicker1OriPos();
	afx_msg void OnButtonLoaderPicker1AlignPos();
	afx_msg void OnButtonLoaderPicker1TablePos();
	afx_msg void OnButtonLoaderPicker1CartPos();
	afx_msg void OnButtonLoaderPicker2OriPos();
	afx_msg void OnButtonLoaderPicker2AlignPos();
	afx_msg void OnButtonLoaderPicker2TablePos();
	afx_msg void OnButtonLoaderPicker2CartPos();
	afx_msg void OnButtonLoaderPicker1SuctionOn();
	afx_msg void OnButtonLoaderPicker1SuctionOff();
	afx_msg void OnButtonLoaderPicker2SuctionOn();
	afx_msg void OnButtonLoaderPicker2SuctionOff();
	afx_msg void OnButtonLoaderClamp();
	afx_msg void OnButtonLoaderUnclamp();
	afx_msg void OnButtonLoaderTableForward();
	afx_msg void OnButtonLoaderTableBackward();
	afx_msg void OnButtonLoaderAlignForward();
	afx_msg void OnButtonLoaderAlignBackward();
	afx_msg void OnButtonLoaderSheetTableForward();
	afx_msg void OnButtonLoaderSheetTableBackward();
	afx_msg void OnButtonUnloaderPicker1OriPos();
	afx_msg void OnButtonUnloaderPicker1AlignPos();
	afx_msg void OnButtonUnloaderPicker1TablePos();
	afx_msg void OnButtonUnloaderPicker1CartPos();
	afx_msg void OnButtonUnloaderPicker2OriPos();
	afx_msg void OnButtonUnloaderPicker2AlignPos();
	afx_msg void OnButtonUnloaderPicker2TablePos();
	afx_msg void OnButtonUnloaderPicker2CartPos();
	afx_msg void OnButtonUnloaderPicker1SuctionOn();
	afx_msg void OnButtonUnloaderPicker1SuctionOff();
	afx_msg void OnButtonUnloaderPicker2SuctionOn();
	afx_msg void OnButtonUnloaderPicker2SuctionOff();
	afx_msg void OnButtonUnloaderClamp();
	afx_msg void OnButtonUnloaderUnclamp();
	afx_msg void OnButtonUnloaderTableForward();
	afx_msg void OnButtonUnloaderTableBackward();
	afx_msg void OnButtonOutputUnloaderElvLoadPos();
	afx_msg void OnButtonOutputUnloaderElvOriPos();
	afx_msg void OnButtonOutputLoaderElvLoadPos();
	afx_msg void OnButtonOutputLoaderElvOriPos();
	afx_msg void OnButtonOutputUnloaderCarrCartPos();
	afx_msg void OnButtonOutputUnloaderCarrAlignPos();
	afx_msg void OnButtonOutputUnloaderCarrTablePos();
	afx_msg void OnButtonOutputLoaderCarrTablePos();
	afx_msg void OnButtonOutputLoaderCarrAlignPos();
	afx_msg void OnButtonOutputLoaderCarrAlignPos2();
	afx_msg void OnButtonOutputLoaderCarrCartPos();
	afx_msg void OnButtonOutputLoaderCarrCartPos2();
	afx_msg void OnButtonOutputResetUnloader1();
	afx_msg void OnButtonOutputResetUnloader2();
	afx_msg void OnButtonOutputResetLoader1();
	afx_msg void OnButtonOutputResetLoader2();
	afx_msg void OnButtonOutputResetUnloaderTable();
	afx_msg void OnButtonOutputResetLoaderTable();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonNgboxForward();
	afx_msg void OnBnClickedButtonNgboxBackward();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB2PUSAN2_H__D4180CA3_BA37_494E_955F_8CB07BE3A79E__INCLUDED_)
