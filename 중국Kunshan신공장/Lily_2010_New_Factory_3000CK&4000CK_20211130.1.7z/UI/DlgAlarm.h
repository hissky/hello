#if !defined(AFX_DLGALARM_H__0537625C_DAD9_4C91_ACF1_CC4A5C4DAC28__INCLUDED_)
#define AFX_DLGALARM_H__0537625C_DAD9_4C91_ACF1_CC4A5C4DAC28__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlarm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarm dialog

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CDlgAlarm : public CDialog
{
// Construction
public:
	CDlgAlarm(CWnd* pParent = NULL);   // standard constructor

	void		InitBtnControl();
	void		InitStaticControl();
	void		InitEditControl();

	void		ResizeWindow();
	void		OffsetItem(UINT nID, int x, int y);

	void		SetErrMsg(CString strErrCode, CString strErrReason=_T(""), CString strErrSolution=_T(""), CString strPlus = _T(""));
	void		SetErrMsg(TCHAR* pErrCode, TCHAR* pErrReason=NULL, TCHAR* pErrSolution=NULL, CString strPlus = _T(""));
	
	CFont		m_edtFont;

// Dialog Data
	//{{AFX_DATA(CDlgAlarm)
	enum { IDD = IDD_DLG_ALARM };
//	CColorEdit	m_edtErrSol;
//	CColorEdit	m_edtErrReason;
	CColorEdit	m_edtErrCode;
	UEasyButtonEx	m_btnClose;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAlarm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntEdit;

	CString		m_strErrCode;
	CString		m_strErrReason;
	CString		m_strErrSolution;

	// Generated message map functions
	//{{AFX_MSG(CDlgAlarm)
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg BOOL DestroyWindow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALARM_H__0537625C_DAD9_4C91_ACF1_CC4A5C4DAC28__INCLUDED_)
