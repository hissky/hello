// ProcessINIFile.h: interface for the CProcessINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSINIFILE_H__6925D856_AABC_4514_A0D9_425E8557EEA2__INCLUDED_)
#define AFX_PROCESSINIFILE_H__6925D856_AABC_4514_A0D9_425E8557EEA2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DProcessINI;

class CProcessINIFile  
{
public:
	CProcessINIFile();
	virtual ~CProcessINIFile();

	BOOL	OpenProcessINIFile(CString strFilePath, DProcessINI& clsProcessINI);
	BOOL	ParsingLaserScanner(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingAutoSetting(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingOption(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingSystem(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingFidFind(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingScannerCal(CStdioFile& sFile, DProcessINI& clsProcessINI);
	BOOL	ParsingPowerMeasure(CStdioFile& sFile, DProcessINI& clsProcessINI);

	BOOL	SaveProcessINIFile(CString strFilePath, DProcessINI clsProcessINI);
	BOOL	SaveLaserScanner(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SaveAutoSetting(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SaveOption(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SaveSystem(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SaveFidFind(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SaveScannerCal(CStdioFile& sFile, DProcessINI clsProcessINI);
	BOOL	SavePowerMeasure(CStdioFile& sFile, DProcessINI clsProcessINI);

	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_PROCESSINIFILE_H__6925D856_AABC_4514_A0D9_425E8557EEA2__INCLUDED_)
