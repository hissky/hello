// DAutoManualScaleINI.cpp: implementation of the DAutoManualScaleINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DAutoManualScaleINI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DAutoManualScaleINI gAutoManualScaleINI;

DAutoManualScaleINI::DAutoManualScaleINI()
{
	memset( &m_sAutoManualScale, 0, sizeof(m_sAutoManualScale) );

	for(int i= 0; i<AUTO_MANUAL_SCALE_COUNT; i++)
		m_sAutoManualScale.nInfoId[i] = i;
}

DAutoManualScaleINI::~DAutoManualScaleINI()
{

}
