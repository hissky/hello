// DAutoManualScaleINI.h: interface for the DAutoManualScaleINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAutoManualScaleINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)
#define AFX_DAutoManualScaleINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DAutoManualScaleINI  
{
public:
	DAutoManualScaleINI();
	virtual ~DAutoManualScaleINI();

	SAUTOMANUALSCALE		m_sAutoManualScale;

};

extern DAutoManualScaleINI gAutoManualScaleINI;

#endif // !defined(AFX_DAutoManualScaleINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)
