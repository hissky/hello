// GlobalVariable.h: interface for the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)
#define AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\model\ToolCodeList.h"
#include "..\model\RefuseList.h"
#define		SECRET_KEY		'@'

#include "..\Device\CorrectTime.h"


struct COGNIX_VISION_RESULT {
	   BOOL bUse;
       CDPoint dOffsetReuslt_Pixcel;
	   CDPoint dOffsetReuslt_mm;
	   CDPoint dScaleResult;
	   double dScaleGap;
	   CDPoint dHoleSize;
	   double dScoreValue;
	   BOOL bSizeCheck;
	   BOOL bRatioCheck;
	   BOOL bFinalSuccess;

	   int nHoleOriginIndex;
	   int nHoleSortIndex;
};

class GlobalVariable  
{
public:
	void SetPath();
	GlobalVariable();
	virtual ~GlobalVariable();
	void Initialize();

	SGLOBALVARIABLE		m_sGlobal;
	CToolCodeList* m_pToolCode[MAX_TOOL_NO];

	CString m_strPath;
	int m_nVersion;

	BOOL SaveGlobalTool();
	BOOL LoadGlobalTool();
	void Serialize(CArchiveMark& ar, int nVersion, int nMode = 0);

	CRefuseList* m_pRefuse;
	int m_nSelectArea;
	CString m_strPath2;
	int m_nVersion2;
	int m_nJobMode;
	int m_nJobModeOld;
	BOOL SaveRefuseList();
	BOOL LoadRefuseList();
	BOOL m_bMarkingCavity;
	void SaveTableCalLog(BOOL b1st);

	BOOL m_bStartEasyDrillerDlg;
	BOOL m_bUseSkiveAutoSetting;

	BOOL m_bNoUseVisionCompen;

	BOOL m_bFirstPulseCheckFlag[BEAMPATH_COUNT];
	void InitFirstPulseCheckFlag();

	SSHOTGROUPTABLE		m_sgShotGroupTable;
	SSHOTGROUPTABLE		m_sgTempShotGroupTable;
	SAUTOMANUALSCALE		m_sgAutoManualScaleTable;

	double m_dGlobal_FidScaleX[2];
	double m_dGlobal_FidScaleY[2];

	void InitCognixResult();
	void SetLineUpValue_int(int nOrder,int * nArray,int nSize);
	void SetLineUpValue_double(int nOrder,double * dArray,int nSize);

	COGNIX_VISION_RESULT	m_CognixTemp[100];
	COGNIX_VISION_RESULT	m_CognixFinalResult[4];

	BOOL m_bLPCRangeReset;
	BOOL m_bExsitPreLPCTable;
	BOOL m_bDoingPreHeat;

	double GetLMDuty_us(int nFrq ,double dDutyPercent);//20160627
	void GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax);
	BOOL m_bShowBlockOnly;
	BOOL m_bShowNoBlockOnly;
	BOOL m_bShowSelectAreaOnly;
	BOOL m_bShowSelectFidBlockOnly;
	int m_nSelectFidBlock;
	BOOL m_bUseSkiveVisionOption;

	BOOL m_bShowBlockNo;

	BOOL m_bShowOCRContents;
	BOOL m_bShowOCRDetail;
	BOOL m_bHideTool;

	CCorrectTime CognexTactTime1;
	CCorrectTime CognexTactTime2;

	int m_nTempFieldNum;

};

extern GlobalVariable gVariable;

#endif // !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)
