// 1DBarCode.cpp: implementation of the C1DBarCode class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "EasyDrillerDlg.h"
#include "1DBarCode.h"
//#include "UI\UnitLength.h"
//#include "EasyMarkerError.h"
#include "DProject.h"



#include "1DAdd\\Barcode.h"//added by hhwang 08.04.17

#include "sysdef.h"
//#include "TECBCEnum.h"//added by hhwang 08.04.17

#include <direct.h>
//////////////
/*
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

  #include <math.h>
*/
#include <cmath>
#include "deasydrillerini.h"

/////////////////////////////



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MARKINGTYPE_LINE			0
#define MARKINGTYPE_BOXANDLINE		1
#define MARKINGTYPE_BOXANDBOX		2
#define MARKINGTYPE_DOT				3
#define BMP_DOT_PIXEL_SIZE 200
#define MINDIM 16
#define DEFIMGWIDTH  512  /* Default image buffer size */
#define DEFIMGLENGTH 480

enum { MATRIX_24_24 =0,MATRIX_22_22, MATRIX_16_16, MATRIX_12_26, MATRIX_DEFALUT };
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//##ModelId=3E410B2301C5
C1DBarCode::C1DBarCode()
{
	//	m_pGlyph=NULL;//jjh 1D Skip
	
}

//##ModelId=3E410B2301C6
C1DBarCode::~C1DBarCode()
{
	
}
/*
//##ModelId=3E410B2301B6
void C1DBarCode::setGlyphBarcode(GlyphBarcode1D *gPlt)
{
m_pGlyph=gPlt;
}

  //##ModelId=3E410B2301B5
  GlyphBarcode1D* C1DBarCode::getGlyphBarcode()
  {
  return m_pGlyph;
  }
*/
//##ModelId=3E410B2301A5
bool C1DBarCode::MakeBarcode_LineMarking_1D()
{
	//HJLee - 2009.7.16. - TBarcode�� �̿��� ��ƾ���� ���Ӱ� ��ü
	t_BarCode* pBC; 
	BCAlloc(&pBC); 
	// Adjust symbology 
	
	//2010.02.10.
	// License here for TBarcode9
	BCLicenseMe("Mem: EO Technics Co., Ltd KR-431 062", eLicKindDeveloper, 1, "9E965AF2783393D244418D25CFFFF00F", eLicProd1D);
	
	//Barcode type - �߰��ϰ� ���� ���ڵ尡 ������, "TECBCEnum.h�� �����Ͽ� �Ʒ��� �߰��Ͻ� �˴ϴ�.
	int nBarcodeType;
	switch(gDProject.pstBarcode_LineMarking->m_nBarcodeType)
	{
	case BARCODE_INTERLEAED2OF5:	nBarcodeType = eBC_2OF5IL;		break;
	case BARCODE_CODE39:			nBarcodeType = eBC_3OF9A;		break;
	case BARCODE_EAN8:				nBarcodeType = eBC_EAN8;		break;
	case BARCODE_EAN13:				nBarcodeType = eBC_EAN13;		break;
	case BARCODE_EAN128:			nBarcodeType = eBC_EAN128;		break;
	case BARCODE_CODE128:			nBarcodeType = eBC_Code128;		break;
	case BARCODE_UPCA:				nBarcodeType = eBC_UPCA;		break;
	case BARCODE_UPCE:				nBarcodeType = eBC_UPCE;		break;
	case BARCODE_CODABAR_2DIGIT:	nBarcodeType = eBC_CodaBar2;	break;
		
	case BARCODE_POSTNET5:			nBarcodeType = eBC_USPSPostNet5;	break;
	case BARCODE_POSTNET6:			nBarcodeType = eBC_USPSPostNet6;	break;
	case BARCODE_POSTNET8:			nBarcodeType = eBC_USPSPostNet9;	break;
	case BARCODE_POSTNET10:			nBarcodeType = eBC_USPSPostNet10;	break;
	case BARCODE_POSTNET11:			nBarcodeType = eBC_USPSPostNet11;	break;
	case BARCODE_POSTNET12:			nBarcodeType = eBC_USPSPostNet12;	break;
		
	case BARCODE_MSI_PLESSEY:		nBarcodeType = eBC_MSI;			break;
	case BARCODE_CODE93:			nBarcodeType = eBC_9OF3;		break;
	case BARCODE_UCC128:			nBarcodeType = eBC_UCC128;		break;
	case BARCODE_CODE128A:			nBarcodeType = eBC_Code128A;	break;
	case BARCODE_CODE128B:			nBarcodeType = eBC_Code128B;	break;
	case BARCODE_CODE128C:			nBarcodeType = eBC_Code128C;	break;
	case BARCODE_ITF14:				nBarcodeType = eBC_ITF14;		break;
	case BARCODE_GS1128:			nBarcodeType = eBC_GS1_128;		break;
	default:						nBarcodeType = eBC_2OF5IL;		break;
	}
	//Barcode type - ������� switch ~ case
	
	BCSetBCType(pBC, static_cast <e_BarCType>(nBarcodeType));
	
	CString strContents;
	
	strContents.Format("%s",gDProject.pstBarcode_LineMarking->chContents);
	
	BCSetText(pBC, strContents, strContents.GetLength()); 
	// Set font height for the human readable text 
	LOGFONTA* pLF = BCGetLogFont(pBC);
	pLF->lfHeight = gDProject.pstBarcode_LineMarking->m_nTextSize * -1; 
	strcpy(pLF->lfFaceName, "Arial");
	
	// Find out wrong characters (check if data can be encoded) (optional) 
	ERRCODE eCode = BCCheck(pBC) ;
	
	if (eCode != 0) 
	{ 
		// your error handling 
	} 
	// Calculate check-digits (optional) 
	eCode = BCCalcCD(pBC); 
	
	//text (���ڸ� �����ų� ���ų�? ���ڸ� ���� �Ұų�?)
	eCode = BCSetPrintText(pBC, gDProject.pstBarcode_LineMarking->m_bText, FALSE);
	
	// Create barcode pattern (bars, spaces) 
	eCode = BCCreate(pBC);
	
	double lTotalCount = BCGetCountModules(pBC);
	int nRow = (int)(BCGetCountRows(pBC));
	//BCGetCountCol
	int nCol = (int)(lTotalCount / nRow);
	
	nCol = int(gDProject.pstBarcode_LineMarking->m_dBarWidth * 20);//nCol * 20;
	nRow = int(gDProject.pstBarcode_LineMarking->m_dBarHeight * 10);//nCol / 3;
	
	//CString strBarcodePath(_T("C:\\EasyMarker\\Data\\barcode.bmp"));
	CString filepath;
	CString directory;
	//::GetAppDirectory(APPDIR_EASYMARKER, filepath);
	//	filepath = "C:\\Data\\barcode.bmp";
	
	//directory.Format(_T("%s\\%s"), filepath, "Data");
    //filepath.Format(_T("%s\\%s"), directory, "barcode.bmp");
	
	
	
	directory.Format("C:\\Data\\");
    filepath.Format("C:\\Data\\barcode.bmp");
	
	
	mkdir(directory);
	
	//nCol = 509;
	//nRow = 167;
	int dpi = 300;
	//2010.06.04 �Ʒ� Row�� 2�� ������. ���� ������ �𸣰���
	eCode = BCSaveImage(pBC, filepath, eIMBmp, nCol, nRow*2, dpi, dpi);
	
	double dSpotSize = 0.050;
	
	// HJKim - � ��쿡 ������ Col���� ���� Pixel�� �о 
	// �ʿ���� Vector�� ���� �ּ� ó�� 
	//	if (nCol % 4 != 0)
	//		nCol += (4 - (nCol % 4));
	
	double fXYRatio = MakePLTDotFromBmp_1D(filepath, nCol, nRow);
	////////////	
	
	////////////////////
	// Release memory / free barcode structure 
	BCFree(pBC); 	
	return TRUE;
	//HJLee - 2009.7.16.
	
}

bool C1DBarCode::MakeBarcode_LineMarking_2D(bool bOldVer)
{
	//HJLee - 2009.7.16. - TBarcode�� �̿��� ��ƾ���� ���Ӱ� ��ü
	CString str;
	t_BarCode* pBC; 
	BCAlloc(&pBC); 
	// Adjust symbology 
	
	//2010.02.10.
	// License here for TBarcode9
	BCLicenseMe("Mem: EO Technics Co., Ltd KR-431 062", eLicKindDeveloper, 1, "9E965AF2783393A23441FD25CF8FF07F", eLicProd2D);
	
	//BCLicenseMe("Mem: EO Technics Co., Ltd KR-431 062", eLicKindDeveloper, 1, "9E965AF2783393A23441FD25CF8FF07F", eLicProd2D);

	//Barcode type - �߰��ϰ� ���� ���ڵ尡 ������, "TECBCEnum.h�� �����Ͽ� �Ʒ��� �߰��Ͻ� �˴ϴ�.
	int nBarcodeType = 71;
	
	//Barcode type - ������� switch ~ case
	ERRCODE eCode = BCAlloc (&pBC);
	eCode = BCSetBCType(pBC, static_cast <e_BarCType>(71));
	
	CString strContents;
	strContents.Format("%s",gDProject.pstBarcode_LineMarking->chContents);
	BCSetText(pBC, strContents, strContents.GetLength()); 
	
	// Find out wrong characters (check if data can be encoded) (optional) 
	
	if (eCode != 0) 
	{
		str = "BCSetText Err";
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str), reinterpret_cast<WPARAM>(&str));
		return false;
	}
		// Calculate check-digits (optional) 
	eCode = BCCalcCD(pBC); 
	if (eCode != 0) 
		return false;
	// Create barcode pattern (bars, spaces) 
	eCode = BCSet_DM_Format(pBC, eDMPr_Default); 
	
	
	int nApplyMatrix = 0;
	
	switch(0/*gDProject.m_nBarMfatrix*/)
	{
	case MATRIX_24_24: 
		nApplyMatrix = 8;
		break;

	case MATRIX_22_22: 
		nApplyMatrix = 7;
		break;
		
	case MATRIX_16_16: 
		nApplyMatrix = 4;
		break;
	case MATRIX_12_26: 
		nApplyMatrix = 27;
		break;
	case MATRIX_DEFALUT: 
		nApplyMatrix = 0;
		break;
		
		}

	eCode = BCSet_DM_Size(pBC, static_cast <e_DMSizes>(nApplyMatrix));
	
	
	
	
	eCode = BCCreate(pBC);
	if (eCode != 0) 
	{
		str = "BCCreate Err";
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str), reinterpret_cast<WPARAM>(&str));
		return false;
	}
	double lTotalCount = BCGetCountModules(pBC);
	
	int nRow = (int)(BCGetCountRows(pBC));
	//BCGetCountCol
	int nCol = (int)(lTotalCount / nRow);
	
	double dTemp = 0;
	/*
	if(bOldVer == true)
	{
	dTemp = gDProject.pstBarcode_LineMarking->m_dBarWidth / nRow; //375 //m_dBarWidth ���� um
	dTemp = dTemp / gDProject.pstBarcode_LineMarking->m_dBeamWidth; // 100%
	dTemp = dTemp * (gDProject.pstBarcode_LineMarking->m_nMarkingDensity /100.);
	gDProject.pstBarcode_LineMarking->m_nBarLineNum = (int)dTemp;
	
	  }
	*/
	
	//CString strBarcodePath(_T("C:\\EasyMarker\\Data\\barcode.bmp"));
	CString filepath;
	CString directory;
	directory.Format("C:\\Data\\");
    filepath.Format("C:\\Data\\barcode.bmp");
	mkdir(directory);
	
	//	int nSize = int(m_pGlyph->m_dMatrixSize / 1000. + 0.5);
	//	eCode = BCSaveImage(pBC, filepath, eIMBmp, nSize * 100, nSize * 100, 600, 600);
//eCode = BCSaveImage(pBC, filepath, eIMBmp, nCol * 200, nRow * 200, 600, 600);//����
	eCode = BCSaveImage(pBC, filepath, eIMBmp, nCol * 20, nRow * 20, 600, 600);

	//eCode = BCSaveImage(pBC, filepath, eIMBmp, nCol * 100, nRow * 100, 600, 600);//����
	if (eCode != 0) 
	{
		AfxMessageBox("���ڵ� ���� ����");
		str = "BCSaveImage Err";
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str), reinterpret_cast<WPARAM>(&str));
		return false;
	}
	double fXYRatio = MakePLTDotFromBmp_2D(directory, nCol, nRow);
	// Release memory / free barcode structure 
	BCFree(pBC); 	
	return TRUE;
}


bool C1DBarCode::MakeBarcode_LineMarking_2D_New(bool bOldVer)
{
	t_BarCode* pBC2D;				
					
//	BCLicenseMe("dpiX LLC, CO-80916 - James Botkin", eLicKindSingle, 1, "D9DFB5E4692A76676A989D46B07D9D95", eLicProd2D);				
				
	BCLicenseMe("Mem: EO Technics Co., Ltd KR-431 062", eLicKindDeveloper, 1, "9E965AF2783393A23441FD25CF8FF07F", eLicProd2D);

	ERRCODE eCode = BCAlloc (&pBC2D);				
					
	int nRow = 0;				
	int nCol = 0;				
					
	CString strPath;				
	strPath.Format(_T("%sTemp\\Ecc200Temp.bmp"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
					
	if(eCode == S_OK)				
	{		
		CString strContents;							
		strContents.Format(_T("%s"),gDProject.pstBarcode_LineMarking->chContents);							


		eCode = BCSetText (pBC2D, strContents, strContents.GetLength());			
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
		eCode = BCSetBCType(pBC2D, static_cast <e_BarCType>(71));			
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
		eCode = BCSetCDMethod(pBC2D, eCDStandard);			
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
		eCode = BCSetModWidth(pBC2D, _T(""));			
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
		eCode = BCCheck	(pBC2D);		
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
		eCode = BCCalcCD(pBC2D);			
		if(eCode != 0)			
		{			
//			ShowErrorMsg(eCode);		
			return 0;		
		}			
					
	//	enum { MATRIX_24_24 =0, MATRIX_16_16, MATRIX_12_26, MATRIX_DEFALUT };			
					
					
					
		int nApplyMatrix = 0;			
					
		switch(0/*gDProject.m_nBarMatrix*/)			
		{			
	case MATRIX_24_24: 
		nApplyMatrix = 8;
		break;
		
	case MATRIX_22_22: 
		nApplyMatrix = 7;
		break;	
		case MATRIX_16_16: 			
			nApplyMatrix = 4;		
			break;		
		case MATRIX_12_26: 			
			nApplyMatrix = 27;		
			break;		
		case MATRIX_DEFALUT: 			
			nApplyMatrix = 0;		
			break;		
					
		}			
					
		if(71 == eBC_DataMatrix)			
		{			
//			if(pGlyphBarcode->m_nRectangleMode)		
//				eCode = BCSet_DM_Rectangular(pBC2D, TRUE);	
			//eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(pGlyphBarcode->m_nColRow));		
			//eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(4)); // 16x16		// sslee Barcode  Matrix Size..........////
		eCode = BCSet_DM_Size(pBC2D, static_cast <e_DMSizes>(nApplyMatrix)); // 24x24		//jjh 45�� ���� ���� 	
		}			
					
		eCode = BCCreate(pBC2D);			
		if(eCode != 0)			
		{			
			//			ShowErrorMsg(eCode);		
			return 0;		
		}			
		
		double lTotalCount = BCGetCountModules(pBC2D);			
		
		nRow = (int)(BCGetCountRows(pBC2D));			
		nCol = (int)(lTotalCount / nRow );			
		
		eCode = BCSaveImage (pBC2D, strPath, eIMBmp, nCol * 20, nRow* 20, 600, 600);			
		if(eCode != 0)			
		{	
			eCode = BCSaveImage (pBC2D, strPath, eIMBmp, nCol * 20, nRow* 20, 600, 600);			
			if(eCode != 0)	
			{
				AfxMessageBox("���ڵ� ���� ����");					
				return 0;	
			}
		}			
	}				
	BCFree (pBC2D);				

	double fXYRatio = MakePLTDotFromBmp_2D_New(strPath, nCol, nRow);
	
	return TRUE;
}






BOOL C1DBarCode::MakePLTDotFromBmp_1D(CString strImagePath, int nCol, int nRow)
{
	
	
	POSITION pos;		
	
	LPBLINE pLine, pChangeLine;		
	
	
	
	////
	
	imgdes SImage, DImage;
	BITMAPINFOHEADER bdat;
	int rrcode = 0;
	memset(&SImage, 0, sizeof(imgdes));
	memset(&DImage, 0, sizeof(imgdes));
	memset(&bdat, 0, sizeof(BITMAPINFOHEADER));
	
	double dDotRatio		= 1;//gDProject.pstBarcode_LineMarking->m_dDotRatio / 1000.;
	int nLineNum			= 1;//gDProject.pstBarcode_LineMarking->m_nBarLineNum;
	BOOL bMakeL				= FALSE;//BarcodeAttribute.m_bBCMakeL;		// Quiet Zone
	BOOL bHorizontalLine	= FALSE;//BarcodeAttribute.m_bBCHorizontalLine;
	BOOL nZigzagType		= FALSE;//BarcodeAttribute.m_nBCZigzagType;
	
	CString filepath;
	CString directory;
	//::GetAppDirectory(APPDIR_EASYMARKER, filepath);
	filepath = "C:\\";
	
	directory.Format(_T("%s\\%s"), filepath, "Data");
	filepath.Format(_T("%s\\%s"), directory, "barcode.bmp");
	
	//	directory.Format("C:\\Data\\");
	//  filepath.Format("C:\\Data\\barcode.bmp");
	
	if((rrcode = bmpinfo(filepath, &bdat)) == NO_ERROR)
	{
		int bitcount = bdat.biBitCount;
		if((rrcode=Resiz_Imgbuf(&SImage, (int)bdat.biWidth, (int)bdat.biHeight, bitcount)) == NO_ERROR)
			loadbmp(filepath, &SImage);
	}
	
	if(gDProject.pstBarcode_LineMarking->m_bInverseMarking)
	{
		bMakeL = TRUE;
		negative(&SImage, &SImage);
	}
	
	filepath.Format(_T("%s\\%s"), directory, "barcode2.bmp");
	if((rrcode = Resiz_Imgbuf(&DImage, (int)SImage.bmh->biWidth,(int)SImage.bmh->biHeight, 8)) == NO_ERROR)
	{
		if (convert1bitto8bit(&SImage, &DImage) == NO_ERROR)
		{
			freeimage(&SImage);
			copyimgdes(&DImage, &SImage);
			
			savebmp(filepath, &DImage, 0);
			freeimage(&DImage);
		}
	}
	HANDLE fd = CreateFile(filepath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(fd < 0)
		return FALSE;
	BITMAPFILEHEADER bmpHeader;
	DWORD size, len;
	if(!ReadFile(fd, (LPSTR)&bmpHeader, sizeof(bmpHeader), &len, NULL))
		return FALSE;
	size = bmpHeader.bfSize - sizeof(bmpHeader);
	LPSTR tDib = new char[size];
	memset(tDib, 0, size);
	if(!ReadFile(fd, tDib, size, &len, NULL))
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	if(len != size)
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	CloseHandle(fd);
	
	LPBITMAPINFO pBitmapInfo = (LPBITMAPINFO)tDib;
	LPSTR m_pDib = (tDib + *(LPDWORD)tDib + 256 * sizeof(RGBQUAD));
	//	gDProject.pstBarcode_LineMarking->addPoint(0, 0, MARK_JUMP);//jjh 1D Skip
	
	int nX = 0;
	int nY = 0;
	int iX = 0;
	int nLine = 0;
	unsigned char result1;
	int nDx = pBitmapInfo->bmiHeader.biWidth;
	int nDy = pBitmapInfo->bmiHeader.biHeight;
	double dSizeX = gDProject.pstBarcode_LineMarking->m_dBarWidth;
	double dSizeY = gDProject.pstBarcode_LineMarking->m_dBarHeight;
	double dSpotSize = 0.050;
	double dRectLen = nDx / nCol / dDotRatio;
	double dGap = dRectLen / (nLineNum + 1);
	
	if(nLineNum < 1)
		nLineNum = 1;
	double dLineGap = dRectLen / nLineNum;
	
	int nChain = 0;
	int* nArray = new int[max(nCol, nRow) + 2];
	memset(nArray, 0, sizeof(int) * (max(nCol, nRow) + 2));
	
	int nPosX = 0;
	int nPosY = 0;
	int nOldPosX = 0;
	int nOldPosY = 0;
	int nMinGap = 50;
	
	int nMinX = 0;
	int nMaxX = -100;
	int nMinY = 0;
	int nMaxY = 0;
	
	double dZoomX = 100.;
	double dZoomY = 100.;
	int  nBarLineGap = gDProject.pstBarcode_LineMarking->m_nBarLineGap; 
	int nDensity = gDProject.pstBarcode_LineMarking->m_nMarkingDensity;
	
	// HJKim - Modify 1D Barcode - Start
	double dBarLineGap = (double)(gDProject.pstBarcode_LineMarking->m_nBarLineGap / 1000.);
	bool bFlag = false;
	int nStartPixel, nEndPixel;
	bool bFirst = true;
	int x;
	for( x= 0; x < nCol; x++)
	{
		
		
		
		
		
		int nNum = x;//(x * nRow) + y;
		result1 = m_pDib[nNum];
		TRACE("%d, %d\n", x, result1);
		
		nMaxX = (nMaxX + 100);			
		
		if(result1 == 0 && bFlag == false)
		{
			nStartPixel = nNum ;	// ������ pixel ������  
			bFlag = true;				
		}
		else if(result1 != 0)
		{
			if(bFlag == true)
			{
				nEndPixel = nNum;			
				
				int nBarWidth = nEndPixel - nStartPixel ;	// �� Bar�� width
				
				double dLineGap = dBarLineGap * 10;	// 
				
				int nTotalLineCnt = int(ceil(nBarWidth / dLineGap));
				
				double dPercent = gDProject.pstBarcode_LineMarking->m_nMarkingDensity;
				double dSpace = (nBarWidth * (100 - dPercent )) / 100 / 2;
				
				double dRealWidth = nBarWidth * dPercent / 100;
				double dRealLineGap = dRealWidth / (nTotalLineCnt);			
				
				for(int i = 0 ; i < nTotalLineCnt; i++)
				{
					
					
					if(gDProject.pstBarcode_LineMarking->m_bInverseMarking && bFirst)
					{
						
						
						pChangeLine = new BLINE;		
						pChangeLine->npStartPos.x=0;
						pChangeLine->npStartPos.y=0;
						pChangeLine->npEndPos.x=0;
						pChangeLine->npEndPos.y=0;
						
						// Inverse�� ��� �պκ� Hatching���� ��ŷ�ϱ� ���� 
						int nStartX, nStartY, nEndX, nEndY;
						
						nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
						nPosY = 0;						
						nStartX = nPosX;
						nStartY = nPosY;
						
						if(nMinX > nPosX) nMinX = nPosX;
						if(nMinY > nPosY) nMinY = nPosY;
						if(nMaxY < nPosY) nMaxY = nPosY;
						
						nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
						nPosY = int((gDProject.pstBarcode_LineMarking->m_dBarHeight * 10) * 100);
						
						nEndX = nPosX;
						nEndY = nPosY;
						
						if(nMinX > nPosX) nMinX = nPosX;
						if(nMinY > nPosY) nMinY = nPosY;
						if(nMaxY < nPosY) nMaxY = nPosY;
						
						// front
						int nInverseWidth = 40 ;												
						int nInverseLineCnt = int(ceil(nInverseWidth / dLineGap));
						
						double dRealInverseWidth  = nInverseWidth * dPercent / 100;
						double dRealInverseLineGap = dRealInverseWidth / (nInverseLineCnt);		
						
						for(int f = -nInverseLineCnt; f <= -1; f++)
						{							
							nPosX = int(nMinX + (dRealInverseLineGap * 100 * f));
							nPosY = nMinY;
							//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_JUMP);//jjh 1D Skip
							
							pChangeLine->npStartPos.x =(int)nPosX; ///		
							pChangeLine->npStartPos.y =(int)nPosY; 				
							
							
							nPosX = nPosX;
							nPosY = nMaxY;
							pChangeLine->npEndPos.x = (int)nPosX;	///	
							pChangeLine->npEndPos.y = (int)nPosY ;	
							
							
							m_LineData.AddTail(pChangeLine);	
							
							//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_DRAW);//jjh 1D Skip
						}
						
						bFirst = false;
						
						//	gDProject.pstBarcode_LineMarking->addPoint(nStartX, nStartY, MARK_JUMP);	//jjh 1D Skip
						//	gDProject.pstBarcode_LineMarking->addPoint(nEndX, nEndY, MARK_DRAW);//jjh 1D Skip
						
						pChangeLine->npStartPos.x =(int)nStartX; ///		
						pChangeLine->npStartPos.y =(int)nStartY; 	
						pChangeLine->npEndPos.x = (int)nEndX;	
						pChangeLine->npEndPos.y = (int)nEndY;	
						m_LineData.AddTail(pChangeLine);
						
					}
					else
					{
						
						pChangeLine = new BLINE;		
						pChangeLine->npStartPos.x=0;
						pChangeLine->npStartPos.y=0;
						pChangeLine->npEndPos.x=0;
						pChangeLine->npEndPos.y=0;
						
						
						nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
						nPosY = 0;
						
						//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_JUMP);	//jjh 1D Skip					
						
						pChangeLine->npStartPos.x =(int)nPosX; ///		
						pChangeLine->npStartPos.y =(int)nPosY; 	
						
						nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
						nPosY = int((gDProject.pstBarcode_LineMarking->m_dBarHeight * 10) * 100);
						//		gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_DRAW);//jjh 1D Skip
						
						pChangeLine->npEndPos.x = (int)nPosX;	///	
						pChangeLine->npEndPos.y = (int)nPosY ;						
						
						m_LineData.AddTail(pChangeLine);
						
						//delete pChangeLine;
						
						//	int count =GetDataCount(0);
						
						if(nMinX > nPosX) nMinX = nPosX;
						//	if(nMaxX < nPosX) nMaxX = nPosX;
						if(nMinY > nPosY) nMinY = nPosY;
						if(nMaxY < nPosY) nMaxY = nPosY;
						
						if(x == nCol - 1)
							nMaxX = nPosX;
					}
					
					
				}
				
				nStartPixel = -1;
				bFlag = false;	
				
				
			}
		}
		
		
		
	}
	
	
	/*
	int count =GetDataCount(0);
	int nBarX1, nBarY1, nBarX2, nBarY2, nBarHoleNo, nTotalBarHoleNo = 0;
	
	  for(int a=0; a<count; a++)
	  {
	  if(!GetNextPoint(0, nBarX1, nBarY1, nBarX2, nBarY2))
	  {
	  
		return FALSE;
		}
		else
		{
		CString strPos1;
		strPos1.Format("%d��° Before X: %d , Y:%d \n " ,a,nBarX1,nBarY1);
		TRACE(strPos1);
		}
		}
		*/
		
		
		if(nStartPixel != -1)
		{		
			int nBarWidth = nCol - nStartPixel ;	// �� Bar�� width
			
			double dLineGap = dBarLineGap * 10;	// 
			
			int nTotalLineCnt = int(ceil(nBarWidth / dLineGap));
			
			double dPercent = gDProject.pstBarcode_LineMarking->m_nMarkingDensity;
			double dSpace = (nBarWidth * (100 - dPercent )) / 100 / 2;
			
			double dRealWidth = nBarWidth * dPercent / 100;
			double dRealLineGap = dRealWidth / (nTotalLineCnt);			
			
			for(int i = 0 ; i < nTotalLineCnt; i++)
			{
				if(gDProject.pstBarcode_LineMarking->m_bInverseMarking && bFirst)
				{
					
					pChangeLine = new BLINE;		
					pChangeLine->npStartPos.x=0;
					pChangeLine->npStartPos.y=0;
					pChangeLine->npEndPos.x=0;
					pChangeLine->npEndPos.y=0;
					
					// Inverse�� ��� �պκ� Hatching���� ��ŷ�ϱ� ���� 
					int nStartX, nStartY, nEndX, nEndY;
					
					nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
					nPosY = 0;						
					nStartX = nPosX;
					nStartY = nPosY;
					
					if(nMinX > nPosX) nMinX = nPosX;
					if(nMinY > nPosY) nMinY = nPosY;
					if(nMaxY < nPosY) nMaxY = nPosY;
					
					nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
					nPosY = int((gDProject.pstBarcode_LineMarking->m_dBarHeight * 10) * 100);
					
					nEndX = nPosX;
					nEndY = nPosY;
					
					if(nMinX > nPosX) nMinX = nPosX;
					if(nMinY > nPosY) nMinY = nPosY;
					if(nMaxY < nPosY) nMaxY = nPosY;
					
					// front
					int nInverseWidth = 40 ;												
					int nInverseLineCnt = int(ceil(nInverseWidth / dLineGap));
					
					double dRealInverseWidth  = nInverseWidth * dPercent / 100;
					double dRealInverseLineGap = dRealInverseWidth / (nInverseLineCnt);		
					
					for(int f = -nInverseLineCnt; f <= -1; f++)
					{							
						nPosX = int(nMinX + (dRealInverseLineGap * 100 * f));
						nPosY = nMinY;
						//					gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_JUMP);//jjh 1D Skip
						
						pChangeLine->npStartPos.x =(int)nPosX; ///		
						pChangeLine->npStartPos.y =(int)nPosY; 	
						
						nPosX = nPosX;
						nPosY = nMaxY;
						//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_DRAW);//jjh 1D Skip
						
						pChangeLine->npEndPos.x = (int)nPosX;	///	
						pChangeLine->npEndPos.y = (int)nPosY ;						
						
						m_LineData.AddTail(pChangeLine);
						
					}
					
					bFirst = false;
					
					//	gDProject.pstBarcode_LineMarking->addPoint(nStartX, nStartY, MARK_JUMP);	//jjh 1D Skip
					//	gDProject.pstBarcode_LineMarking->addPoint(nEndX, nEndY, MARK_DRAW);
					
					pChangeLine->npStartPos.x =(int)nStartX; ///		
					pChangeLine->npStartPos.y =(int)nStartY; 	
					pChangeLine->npEndPos.x = (int)nEndX;	
					pChangeLine->npEndPos.y = (int)nEndY;	
					m_LineData.AddTail(pChangeLine);
					
				}
				else
				{
					
					pChangeLine = new BLINE;		
					pChangeLine->npStartPos.x=0;
					pChangeLine->npStartPos.y=0;
					pChangeLine->npEndPos.x=0;
					pChangeLine->npEndPos.y=0;
					
					nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
					nPosY = 0;
					
					//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_JUMP);		//jjh 1D Skip				
					
					pChangeLine->npStartPos.x =(int)nPosX; ///		
					pChangeLine->npStartPos.y =(int)nPosY; 	
					
					nPosX = int((nStartPixel + dSpace + (dRealLineGap * i)) * 100);
					nPosY = int((gDProject.pstBarcode_LineMarking->m_dBarHeight * 10) * 100);
					//	gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_DRAW);//jjh 1D Skip
					
					pChangeLine->npEndPos.x = (int)nPosX;	///	
					pChangeLine->npEndPos.y = (int)nPosY ;
					m_LineData.AddTail(pChangeLine);
					
					if(nMinX > nPosX) nMinX = nPosX;
					//	if(nMaxX < nPosX) nMaxX = nPosX;
					if(nMinY > nPosY) nMinY = nPosY;
					if(nMaxY < nPosY) nMaxY = nPosY;
					
					if(x == nCol - 1)
						nMaxX = nPosX;
				}
		}
	}
	
	if(gDProject.pstBarcode_LineMarking->m_bInverseMarking)
	{
	}
	else
	{
		if(nPosX < nMaxX)
		{
			//			gDProject.pstBarcode_LineMarking->addPoint(nMaxX, 0, MARK_JUMP);//jjh 1D Skip
		}
	}
	
	if(gDProject.pstBarcode_LineMarking->m_bInverseMarking)
	{
		//rear
		int nInverseWidth = 40 ;
		double dLineGap = dBarLineGap * 10;
								
		int nInverseLineCnt = int(ceil(nInverseWidth / dLineGap));
		double dPercent = gDProject.pstBarcode_LineMarking->m_nMarkingDensity;
		
		double dRealInverseWidth  = nInverseWidth * dPercent / 100;
		double dRealInverseLineGap = dRealInverseWidth / (nInverseLineCnt);		
		
		for(int r = 1; r <= nInverseLineCnt; r++)
		{
			nPosX = int(nMaxX + (dRealInverseLineGap * 100 * r));
			nPosY = nMinY;
			//		gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_JUMP);//jjh 1D Skip
			
			pChangeLine->npStartPos.x =(int)nPosX; ///		
			pChangeLine->npStartPos.y =(int)nPosY; 	
			
			
			
			nPosX = nPosX;
			nPosY = int(nMaxY);
			//		gDProject.pstBarcode_LineMarking->addPoint(nPosX, nPosY, MARK_DRAW);//jjh 1D Skip
			
			pChangeLine->npEndPos.x = (int)nPosX;	
			pChangeLine->npEndPos.y = (int)nPosY;
			
			m_LineData.AddTail(pChangeLine);
			
		}
	}
	
	//delete pChangeLine;//
	
	
	
	delete[] nArray;
	delete []tDib;
	tDib = NULL;
	m_pDib = NULL;
	return TRUE;
}
#define ZERO_POINT_FIVE 0.5
BOOL C1DBarCode::MakePLTDotFromBmp_2D(CString strImagePath, int nCol, int nRow)
{
	
	
	POSITION pos;		
	
	LPBLINE pLine, pChangeLine;		
	
	
	
	////
	
	imgdes SImage, DImage;
	BITMAPINFOHEADER bdat;
	int rrcode = 0;
	memset(&SImage, 0, sizeof(imgdes));
	memset(&DImage, 0, sizeof(imgdes));
	memset(&bdat, 0, sizeof(BITMAPINFOHEADER));
	
	double dDotRatio		= 1;//gDProject.pstBarcode_LineMarking->m_dDotRatio / 1000.;
	int nLineNum			=  gDProject.pstBarcode_LineMarking->m_nBarLineNum;
	BOOL bReverse = 0;
	BOOL bMakeL = 0;		// Quiet Zone
	BOOL bHorizontalLine	= gDProject.pstBarcode_LineMarking->m_bHorizontal;//BarcodeAttribute.m_bBCHorizontalLine;
	BOOL nZigzagType		= 0;//BarcodeAttribute.m_nBCZigzagType;

	

	CString filepath;
	CString directory;
	//::GetAppDirectory(APPDIR_EASYMARKER, filepath);
	filepath = "C:\\";
	
	directory.Format(_T("%s\\%s"), filepath, "Data");
	filepath.Format(_T("%s\\%s"), directory, "barcode.bmp");
	
	//	directory.Format("C:\\Data\\");
	//  filepath.Format("C:\\Data\\barcode.bmp");
	
	if((rrcode = bmpinfo(filepath, &bdat)) == NO_ERROR)
	{
		int bitcount = bdat.biBitCount;
		if((rrcode=Resiz_Imgbuf(&SImage, (int)bdat.biWidth, (int)bdat.biHeight, bitcount)) == NO_ERROR)
			loadbmp(filepath, &SImage);
	}
	
	if(gDProject.pstBarcode_LineMarking->m_bInverseMarking)
	{
		bMakeL = TRUE;
		negative(&SImage, &SImage);
	}
	
	filepath.Format(_T("%s\\%s"), directory, "barcode2.bmp");
	if((rrcode = Resiz_Imgbuf(&DImage, (int)SImage.bmh->biWidth,(int)SImage.bmh->biHeight, 8)) == NO_ERROR)
	{
		if (convert1bitto8bit(&SImage, &DImage) == NO_ERROR)
		{
			freeimage(&SImage);
			copyimgdes(&DImage, &SImage);
			
			savebmp(filepath, &DImage, 0);
			freeimage(&DImage);
		}
	}
	HANDLE fd = CreateFile(filepath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(fd < 0)
		return FALSE;
	BITMAPFILEHEADER bmpHeader;
	DWORD size, len;
	if(!ReadFile(fd, (LPSTR)&bmpHeader, sizeof(bmpHeader), &len, NULL))
		return FALSE;
	size = bmpHeader.bfSize - sizeof(bmpHeader);
	LPSTR tDib = new char[size];
	memset(tDib, 0, size);
	if(!ReadFile(fd, tDib, size, &len, NULL))
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	if(len != size)
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	CloseHandle(fd);
	
				LPBITMAPINFO pBitmapInfo = (LPBITMAPINFO)tDib;											
				
				LPSTR m_pDib = (tDib + *(LPDWORD)tDib + 256 * sizeof(RGBQUAD));											
				
				CStdioFile File;											
				CString OutStr;											
				
				filepath.Format(_T("%s\\%s"), strImagePath, "barcode.plt");											
				if (!File.Open(filepath, CFile::modeCreate|CFile::modeWrite|CFile::typeText))											
				{											
					AfxMessageBox("Unable To Open Image File!");										
					return FALSE;										
				}											
				
				POINT nPos;											
				DPOINT dZoom;											
				OutStr.Format("PU; PA0,0;\n");											
				File.WriteString(OutStr);											
				//	m_pGlyph->addPoint(0, 0, MARK_JUMP);	
				/*
				pChangeLine = new BLINE;		
				pChangeLine->npStartPos.x=0;
				pChangeLine->npStartPos.y=0;
				pChangeLine->npEndPos.x=0;
				pChangeLine->npEndPos.y=0;
                m_LineData.AddTail(pChangeLine);
				*/											
				double dRatioString = 0.;
				
				CString strContents;
				
				strContents.Format("%s",gDProject.pstBarcode_LineMarking->chContents);
				
				strContents.GetLength();											
				
				//	gDProject.pstBarcode_LineMarking->m_dMatrixSize = 	gDProject.pstBarcode_LineMarking->m_dBarWidth  * 0.8333;
				
				gDProject.pstBarcode_LineMarking->m_dMatrixSize = 	gDProject.pstBarcode_LineMarking->m_dBarWidth;
				
				double nMatrixSizeTimes = gDProject.pstBarcode_LineMarking->m_dMatrixSize / 10000;											
				dZoom.x = 5. * nMatrixSizeTimes;											
				dZoom.y = 5. * nMatrixSizeTimes;											
				
				//	dZoom.x = 1.;											
				//	dZoom.y = 1.;											
				
				/*if(m_pGlyph->m_nBarcodeType == BARCODE2D_QRCODE)											
				{											
				dZoom.x = dZoom.x / 2.;										
				dZoom.y = dZoom.y / 2.;										
				}*/											
				
				int nX = 0;											
				int nY = 0;											
				int iX = 0;											
				int nLine = 0;											
				unsigned char result1;											
				int nDx = pBitmapInfo->bmiHeader.biWidth;											
				int nDy = pBitmapInfo->bmiHeader.biHeight;											
				
				
				dZoom.x = gDProject.pstBarcode_LineMarking->m_dMatrixSize/nDx;											
				//dZoom.y = gDProject.pstBarcode_LineMarking->m_dMatrixSize/nDy;
				dZoom.y = dZoom.x;
				double dRectLen = nDx / nCol / dDotRatio;											
				double dGap = dRectLen / (nLineNum);// + 1);											
				
				if(nLineNum < 1)											
					nLineNum = 1;										
				double dLineGap = dRectLen / nLineNum;											
				
				//	double dRectLenOrg = dRectLen;											
				//	double dRectLenX, dRectLenY;											
				
				int nChain = 0, nNextX, nNextY;											
				int* nArray = new int[max(nCol, nRow) + 2];		// add by skchoi 2009.06.16									
				memset(nArray, 0, sizeof(int) * (max(nCol, nRow) + 2));											
				
				if(gDProject.pstBarcode_LineMarking->m_bHorizontal		// Horizontal Line									
					|| gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_BOXANDBOX/* || m_pGlyph->m_nBarcodeType == MARKINGTYPE_DOT*/)	// HJKim - 2D Dot									
				{											
					
					for(int y = -1; y <= nRow; y++)										
					{										
						nChain = 0;									
						
						for(int x = -1; x <= nCol; x++)									
						{									
							int nXp, nYp;								
							nXp = (int)((double)nDx / (double)nCol * (double)x + (double)nDx/(double)nCol/2. + 0.5);								
							nYp = (int)((double)nDy / (double)nRow * (double)y + (double)nDy/(double)nRow/2. + 0.5);								
							
							nX = (int)(nDx / nCol * x + nDx/nCol/2);								
							nY = (int)(nDy / nRow * y + nDy/nRow/2);								
							
							if(x < 0 || x >= nCol || y < 0 || y >= nRow)								
							{								
								if(bMakeL)							
								{							
									result1 = 0;						
								}							
								else							
								{							
									result1 = 255;						
								}							
							}								
							else								
							{								
								result1 = m_pDib[nDx * nYp + nXp];							
							}								
							
							//				if(x < 0)								
							//				{								
							//					nX -= (int)dRectLenOrg;							
							//					dRectLenX = dRectLenOrg * 2;							
							//				}								
							//				else								
							//				{								
							//					dRectLenX = dRectLenOrg;							
							//				}								
							//				dRectLenX = dRectLenOrg;								
							//				dRectLenY = dRectLenOrg;								
							
							if(result1 == 0)								
							{	
								
								
								
								
								
								switch (gDProject.pstBarcode_LineMarking->m_nBarcodeType)							
								{							
								case MARKINGTYPE_LINE:		// LINE					
									nChain++;						
									nArray[x + 1] = 1;						
									
									if(x >= nCol || (!bMakeL && x + 1 >= nCol) || dDotRatio != 1.0)						
									{						
										result1 = 255;					
									}						
									else if(y < 0 || y >= nRow || (bMakeL && x + 1 >= nCol))						
									{						
										result1 = 0;					
									}						
									else						
									{						
										nNextX = (int)((double)nDx / (double)nCol * ((double)x + 1.0) + (double)nDx/(double)nCol/2.0 + 0.5);					
										nNextY = (int)((double)nDy / (double)nRow * (double)y + (double)nDy/(double)nRow/2.0 + 0.5);					
										
										result1 = m_pDib[nDx * nNextY + nNextX];					
									}						
									
									//						if(result1 != 0 && nZigzagType != 2)						
									if((result1 != 0 && nZigzagType != 2) || nZigzagType == 3)						
									{						
										for(nLine = 0; nLine < nLineNum; nLine++)					
										{					
											//								if(nLine % 2 == 0 || nZigzagType == 1)				
											if(nLine % 2 == 0 || nZigzagType == 1 || nZigzagType == 3)				
											{				
												//TMP									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLenX * (nChain /*- 0.5*/)), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 				
												
												
												//TMP									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLenX / 2.0), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
											}				
											else				
											{				
												//TMP									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLenX / 2.0), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
												
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												
												//TMP									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLenX * (nChain/* - 0.5*/)), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
											}				
										}					
										nChain = 0;					
									}						
									break;	
									/*
									case MARKINGTYPE_BOXANDLINE:		// BOX (+LINE)					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);						
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;						
									case MARKINGTYPE_BOXANDBOX:		// BOX (+BOX)					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);						
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									double dTempRectLen = (dRectLen / (nLineNum+1)) * (nLine+1);					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;						
									case MARKINGTYPE_DOT:		// DOT					
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;	
									*/
								}
								
							}								
							else								
							{								
								nArray[x + 1] = 0;							
							}								
						}									
						
						if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_LINE && nZigzagType == 2)		// add by skchoi 2009.06.16							
						{									
							for(nLine = 0; nLine < nLineNum; nLine++)								
							{								
								nChain = 0;							
								if(nLine % 2 == 0)							
								{							
									for(int x = -1; x <= nCol; x++)						
									{						
										if(nArray[x + 1])					
										{					
											nChain++;				
											
											if(x == nCol)				
											{				
												nX = (int)(nDx / nCol * (x + 0.5));			
												nY = (int)(nDy / nRow * (y + 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 	
												
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);	
												nChain = 0;			
											}				
										}					
										else					
										{					
											if(nChain >= 1)				
											{				
												nX = (int)(nDx / nCol * (x - 0.5));			
												nY = (int)(nDy / nRow * (y + 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
												
												nChain = 0;			
											}				
										}					
									}						
								}							
								else							
								{							
									for(int x = nCol; x >= -1; x--)						
									{						
										
										if(nArray[x + 1])					
										{					
											nChain++;				
											
											if(x == -1)				
											{				
												nX = (int)(nDx / nCol * (x + 0.5));			
												nY = (int)(nDy / nRow * (y - 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen * (nChain - 0.5)), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);		
												nChain = 0;			
											}				
										}					
										else					
										{					
											if(nChain >= 1)				
											{				
												nX = (int)(nDx / nCol * (x + 1.5));			
												nY = (int)(nDy / nRow * (y - 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen * (nChain - 0.5)), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
												
												nChain = 0;			
											}				
										}					
									}						
								}							
							}								
						}									
						
					}										
				}											
				else	//���� 										
				{											
					int nInverse = 0;	// HJKim - 2D Dot									
					
					if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_DOT)										
					{	
					/*
					for(int x = -1; x <= nCol; x++)									
					{									
					nInverse++;								
					
					  //	for(int y = -1; y <= nRow; y++)							
					  for(int k = -1; k < nRow; k++)								
					  {								
					  int y;							
					  
						if(nInverse %2 == 0)							
						y = k;						
						else 							
						y = ((nRow - 1)  - k);						
						
						  nX = (int)(nDx / nCol * x + nDx/nCol/2);							
						  nY = (int)(nDy / nRow * y + nDy/nRow/2);							
						  
							if(x < 0 || x >= nCol || y < 0 || y >= nRow)							
							{							
							if(bMakeL)						
							{						
							result1 = 0;					
							}						
							else						
							{						
							result1 = 255;					
							}						
							}							
							else							
							{							
							result1 = m_pDib[nDx * nY + nX];						
							}							
							if(result1 == 0)							
							{							
							if(nInverse %2 != 0)						
							{						
							//	for (nLine = 0; nLine<nLineNum; nLine++)				
							for (nLine = (nLineNum - 1); nLine >= 0; nLine--)					
							{					
							OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
							OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
							}					
							}						
							else						
							{						
							for (nLine = 0; nLine<nLineNum; nLine++)					
							{					
							OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
							OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
							}					
							}						
							}							
							}								
							}	
						*/
					}										
					else										
					{										
						for(int x = -1; x <= nCol; x++)									
						{									
							nChain = 0;								
							
							for(int y = -1; y <= nRow; y++)								
							{								
								nX = (int)(nDx / nCol * x + nDx/nCol/2);							
								nY = (int)(nDy / nRow * y + nDy/nRow/2);							
								
								if(x < 0 || x >= nCol || y < 0 || y >= nRow)							
								{							
									if(bMakeL)						
									{						
										result1 = 0;					
									}						
									else						
									{						
										result1 = 255;					
									}						
								}							
								else							
								{							
									result1 = m_pDib[nDx * nY + nX];						
								}							
								if(result1 == 0)							
								{							
									switch (gDProject.pstBarcode_LineMarking->m_nBarcodeType)						
									{						
									case MARKINGTYPE_LINE:		// LINE				
										nChain++;					
										nArray[y + 1] = 1;					
										
										if(y >= nRow || (!bMakeL && y + 1 >= nRow) || dDotRatio != 1.0)					
										{					
											result1 = 255;				
										}					
										else if(x < 0 || x >= nCol || (bMakeL && y + 1 >= nRow))					
										{					
											result1 = 0;				
										}					
										else					
										{					
											nNextX = (int)(nDx / nCol * x + nDx/nCol/2);				
											nNextY = (int)(nDy / nRow * (y + 1) + nDy/nRow/2);				
											result1 = m_pDib[nDx * nNextY + nNextX];				
										}					
										
										//						if(result1 != 0 && nZigzagType != 2)					
										if((result1 != 0 && nZigzagType != 2) || nZigzagType == 3)		// add by skchoi 2009.07.08			
										{					
											for(nLine = 0; nLine < nLineNum; nLine++)				
											{				
												//								if(nLine % 2 == 0 || nZigzagType == 1)			
												if(nLine % 2 == 0 || nZigzagType == 1 || nZigzagType == 3)		// add by skchoi 2009.07.08	
												{			
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 				
													
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
													
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
												}			
												else			
												{			
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
													
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													
												}			
											}				
											nChain = 0;				
										}					
										break;		
										/*
										case MARKINGTYPE_BOXANDLINE:		// BOX (+LINE)				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dGap * (nLine+1)), nPos.y = (int)(nY - dRectLen / 2.0));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dGap * (nLine+1)), nPos.y = (int)(nY + dRectLen / 2.0));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;					
										case MARKINGTYPE_BOXANDBOX:		// BOX (+BOX)				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										double dTempRectLen = (dRectLen / (nLineNum+1)) * (nLine+1);				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;					
										case MARKINGTYPE_DOT:		// DOT				
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;	
										*/
									}	
									
								}							
								else							
								{							
									nArray[y + 1] = 0;						
								}							
							}								
							
							if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_LINE && nZigzagType == 2)		// add by skchoi 2009.06.16						
							{								
								for(nLine = 0; nLine < nLineNum; nLine++)							
								{							
									nChain = 0;						
									if(nLine % 2 == 0)						
									{						
										for(int y = -1; y <= nRow; y++)					
										{					
											if(nArray[y + 1])				
											{				
												nChain++;			
												
												if(y == nRow)			
												{			
													nX = (int)(nDx / nCol * (x + 0.5));		
													nY = (int)(nDy / nRow * (y + 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													nChain = 0;		
												}			
											}				
											else				
											{				
												if(nChain >= 1)			
												{			
													nX = (int)(nDx / nCol * (x + 0.5));		
													nY = (int)(nDy / nRow * (y - 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													nChain = 0;		
												}			
											}				
										}					
									}						
									else						
									{						
										for(int y = nRow; y >= -1; y--)					
										{					
											if(nArray[y + 1])				
											{				
												nChain++;			
												
												if(y == -1)			
												{			
													nX = (int)(nDx / nCol * (x - 0.5));		
													nY = (int)(nDy / nRow * (y + 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);	
													nChain = 0;		
												}			
											}				
											else				
											{				
												if(nChain >= 1)			
												{			
													nX = (int)(nDx / nCol * (x - 0.5));		
													nY = (int)(nDy / nRow * (y + 1.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);	
													nChain = 0;		
												}			
											}				
										}					
									}						
								}							
							}								
						}									
						
					}										
				}											
				
				OutStr.Format("PU; PA%d,%d;\n", nPos.x = nDx, nPos.y = nDy);											
				File.WriteString(OutStr);											
				
				delete[] nArray;											
				
				delete []tDib;											
				tDib = NULL;											
				m_pDib = NULL;											
				
				File.Close();											
				return TRUE;											
				
}


BOOL C1DBarCode::MakePLTDotFromBmp_2D_New(CString strImagePath, int nCol, int nRow)
{
	
	
	POSITION pos;		
	
	LPBLINE pLine, pChangeLine;		
	
	
	
	////
	
	imgdes SImage, DImage;
	BITMAPINFOHEADER bdat;
	int rrcode = 0;
	memset(&SImage, 0, sizeof(imgdes));
	memset(&DImage, 0, sizeof(imgdes));
	memset(&bdat, 0, sizeof(BITMAPINFOHEADER));
	
	double dDotRatio		= 1;//gDProject.pstBarcode_LineMarking->m_dDotRatio / 1000.;
	int nLineNum			=  gDProject.pstBarcode_LineMarking->m_nBarLineNum;
	BOOL bReverse = 0;
	BOOL bMakeL = 0;		// Quiet Zone
	BOOL bHorizontalLine	= gDProject.pstBarcode_LineMarking->m_bHorizontal;//BarcodeAttribute.m_bBCHorizontalLine;
	BOOL nZigzagType		= 0;//BarcodeAttribute.m_nBCZigzagType;

	

	CString filepath;
	CString directory;
	//::GetAppDirectory(APPDIR_EASYMARKER, filepath);
	filepath = "C:\\";
	
//	directory.Format(_T("%s\\%s"), filepath, "Data");
//	filepath.Format(_T("%s\\%s"), directory, "barcode.bmp");
	
	filepath.Format("%sTemp\\Ecc200Temp.bmp", gEasyDrillerINI.m_clsDirPath.GetRootDir());				
			

	//	directory.Format("C:\\Data\\");
	//  filepath.Format("C:\\Data\\barcode.bmp");
	
	if((rrcode = bmpinfo(filepath, &bdat)) == NO_ERROR)
	{
		int bitcount = bdat.biBitCount;
		if((rrcode=Resiz_Imgbuf(&SImage, (int)bdat.biWidth, (int)bdat.biHeight, bitcount)) == NO_ERROR)
			loadbmp(filepath, &SImage);
	}
	
	if(gDProject.pstBarcode_LineMarking->m_bInverseMarking)
	{
		bMakeL = TRUE;
		negative(&SImage, &SImage);
	}
	
//	filepath.Format(_T("%s\\%s"), directory, "barcode2.bmp");

	filepath.Format("%sTemp\\Ecc200Temp2.bmp", gEasyDrillerINI.m_clsDirPath.GetRootDir());
	if((rrcode = Resiz_Imgbuf(&DImage, (int)SImage.bmh->biWidth,(int)SImage.bmh->biHeight, 8)) == NO_ERROR)
	{
		if (convert1bitto8bit(&SImage, &DImage) == NO_ERROR)
		{
			freeimage(&SImage);
			copyimgdes(&DImage, &SImage);
			
			savebmp(filepath, &DImage, 0);
			freeimage(&DImage);
		}
	}
	HANDLE fd = CreateFile(filepath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(fd < 0)
		return FALSE;
	BITMAPFILEHEADER bmpHeader;
	DWORD size, len;
	if(!ReadFile(fd, (LPSTR)&bmpHeader, sizeof(bmpHeader), &len, NULL))
		return FALSE;
	size = bmpHeader.bfSize - sizeof(bmpHeader);
	LPSTR tDib = new char[size];
	memset(tDib, 0, size);
	if(!ReadFile(fd, tDib, size, &len, NULL))
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	if(len != size)
	{
		delete []tDib;
		tDib = NULL;
		return FALSE;
	}
	CloseHandle(fd);
	
				LPBITMAPINFO pBitmapInfo = (LPBITMAPINFO)tDib;											
				
				LPSTR m_pDib = (tDib + *(LPDWORD)tDib + 256 * sizeof(RGBQUAD));											
				
				CStdioFile File;											
				CString OutStr;											
				
			//	filepath.Format(_T("%s\\%s"), strImagePath, "barcode.plt");	
				
				filepath.Format("%sTemp\\barcode.plt", gEasyDrillerINI.m_clsDirPath.GetRootDir());

				if (!File.Open(filepath, CFile::modeCreate|CFile::modeWrite|CFile::typeText))											
				{											
					AfxMessageBox("Unable To Open Image File!");										
					return FALSE;										
				}											
				
				POINT nPos;											
				DPOINT dZoom;											
				OutStr.Format("PU; PA0,0;\n");											
				File.WriteString(OutStr);											
				//	m_pGlyph->addPoint(0, 0, MARK_JUMP);	
				/*
				pChangeLine = new BLINE;		
				pChangeLine->npStartPos.x=0;
				pChangeLine->npStartPos.y=0;
				pChangeLine->npEndPos.x=0;
				pChangeLine->npEndPos.y=0;
                m_LineData.AddTail(pChangeLine);
				*/											
				double dRatioString = 0.;
				
				CString strContents;
				
				strContents.Format("%s",gDProject.pstBarcode_LineMarking->chContents);
				
				strContents.GetLength();											
				
				//	gDProject.pstBarcode_LineMarking->m_dMatrixSize = 	gDProject.pstBarcode_LineMarking->m_dBarWidth  * 0.8333;
				
				gDProject.pstBarcode_LineMarking->m_dMatrixSize = 	gDProject.pstBarcode_LineMarking->m_dBarWidth;
				
				double nMatrixSizeTimes = gDProject.pstBarcode_LineMarking->m_dMatrixSize / 10000;											
				dZoom.x = 5. * nMatrixSizeTimes;											
				dZoom.y = 5. * nMatrixSizeTimes;											
				
				//	dZoom.x = 1.;											
				//	dZoom.y = 1.;											
				
				/*if(m_pGlyph->m_nBarcodeType == BARCODE2D_QRCODE)											
				{											
				dZoom.x = dZoom.x / 2.;										
				dZoom.y = dZoom.y / 2.;										
				}*/											
				
				int nX = 0;											
				int nY = 0;											
				int iX = 0;											
				int nLine = 0;											
				unsigned char result1;											
				int nDx = pBitmapInfo->bmiHeader.biWidth;											
				int nDy = pBitmapInfo->bmiHeader.biHeight;											
				
				
				dZoom.x = gDProject.pstBarcode_LineMarking->m_dMatrixSize/nDx;											
				//dZoom.y = gDProject.pstBarcode_LineMarking->m_dMatrixSize/nDy;
				dZoom.y = dZoom.x;
				double dRectLen = nDx / nCol / dDotRatio;											
				double dGap = dRectLen / (nLineNum);// + 1);											
				
				if(nLineNum < 1)											
					nLineNum = 1;										
				double dLineGap = dRectLen / nLineNum;											
				
				//	double dRectLenOrg = dRectLen;											
				//	double dRectLenX, dRectLenY;											
				
				int nChain = 0, nNextX, nNextY;											
				int* nArray = new int[max(nCol, nRow) + 2];		// add by skchoi 2009.06.16									
				memset(nArray, 0, sizeof(int) * (max(nCol, nRow) + 2));											
				
				if(gDProject.pstBarcode_LineMarking->m_bHorizontal		// Horizontal Line									
					|| gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_BOXANDBOX/* || m_pGlyph->m_nBarcodeType == MARKINGTYPE_DOT*/)	// HJKim - 2D Dot									
				{											
					
					for(int y = -1; y <= nRow; y++)										
					{										
						nChain = 0;									
						
						for(int x = -1; x <= nCol; x++)									
						{									
							int nXp, nYp;								
							nXp = (int)((double)nDx / (double)nCol * (double)x + (double)nDx/(double)nCol/2. + 0.5);								
							nYp = (int)((double)nDy / (double)nRow * (double)y + (double)nDy/(double)nRow/2. + 0.5);								
							
							nX = (int)(nDx / nCol * x + nDx/nCol/2);								
							nY = (int)(nDy / nRow * y + nDy/nRow/2);								
							
							if(x < 0 || x >= nCol || y < 0 || y >= nRow)								
							{								
								if(bMakeL)							
								{							
									result1 = 0;						
								}							
								else							
								{							
									result1 = 255;						
								}							
							}								
							else								
							{								
								result1 = m_pDib[nDx * nYp + nXp];							
							}								
							
							//				if(x < 0)								
							//				{								
							//					nX -= (int)dRectLenOrg;							
							//					dRectLenX = dRectLenOrg * 2;							
							//				}								
							//				else								
							//				{								
							//					dRectLenX = dRectLenOrg;							
							//				}								
							//				dRectLenX = dRectLenOrg;								
							//				dRectLenY = dRectLenOrg;								
							
							if(result1 == 0)								
							{	
								
								
								
								
								
								switch (gDProject.pstBarcode_LineMarking->m_nBarcodeType)							
								{							
								case MARKINGTYPE_LINE:		// LINE					
									nChain++;						
									nArray[x + 1] = 1;						
									
									if(x >= nCol || (!bMakeL && x + 1 >= nCol) || dDotRatio != 1.0)						
									{						
										result1 = 255;					
									}						
									else if(y < 0 || y >= nRow || (bMakeL && x + 1 >= nCol))						
									{						
										result1 = 0;					
									}						
									else						
									{						
										nNextX = (int)((double)nDx / (double)nCol * ((double)x + 1.0) + (double)nDx/(double)nCol/2.0 + 0.5);					
										nNextY = (int)((double)nDy / (double)nRow * (double)y + (double)nDy/(double)nRow/2.0 + 0.5);					
										
										result1 = m_pDib[nDx * nNextY + nNextX];					
									}						
									
									//						if(result1 != 0 && nZigzagType != 2)						
									if((result1 != 0 && nZigzagType != 2) || nZigzagType == 3)						
									{						
										for(nLine = 0; nLine < nLineNum; nLine++)					
										{					
											//								if(nLine % 2 == 0 || nZigzagType == 1)				
											if(nLine % 2 == 0 || nZigzagType == 1 || nZigzagType == 3)				
											{				
												//TMP									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLenX * (nChain /*- 0.5*/)), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 				
												
												
												//TMP									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLenX / 2.0), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
											}				
											else				
											{				
												//TMP									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLenX / 2.0), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
												
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												
												//TMP									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLenX * (nChain/* - 0.5*/)), nPos.y = (int)(nY - dRectLenY / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
											}				
										}					
										nChain = 0;					
									}						
									break;	
									/*
									case MARKINGTYPE_BOXANDLINE:		// BOX (+LINE)					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);						
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;						
									case MARKINGTYPE_BOXANDBOX:		// BOX (+BOX)					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);						
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));						
									File.WriteString(OutStr);						
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);						
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									double dTempRectLen = (dRectLen / (nLineNum+1)) * (nLine+1);					
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;						
									case MARKINGTYPE_DOT:		// DOT					
									for (nLine = 0; nLine<nLineNum; nLine++)						
									{						
									OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
									OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));					
									File.WriteString(OutStr);					
									m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
									}						
									break;	
									*/
								}
								
							}								
							else								
							{								
								nArray[x + 1] = 0;							
							}								
						}									
						
						if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_LINE && nZigzagType == 2)		// add by skchoi 2009.06.16							
						{									
							for(nLine = 0; nLine < nLineNum; nLine++)								
							{								
								nChain = 0;							
								if(nLine % 2 == 0)							
								{							
									for(int x = -1; x <= nCol; x++)						
									{						
										if(nArray[x + 1])					
										{					
											nChain++;				
											
											if(x == nCol)				
											{				
												nX = (int)(nDx / nCol * (x + 0.5));			
												nY = (int)(nDy / nRow * (y + 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 	
												
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);	
												nChain = 0;			
											}				
										}					
										else					
										{					
											if(nChain >= 1)				
											{				
												nX = (int)(nDx / nCol * (x - 0.5));			
												nY = (int)(nDy / nRow * (y + 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen * (nChain - 0.5)), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
												
												nChain = 0;			
											}				
										}					
									}						
								}							
								else							
								{							
									for(int x = nCol; x >= -1; x--)						
									{						
										
										if(nArray[x + 1])					
										{					
											nChain++;				
											
											if(x == -1)				
											{				
												nX = (int)(nDx / nCol * (x + 0.5));			
												nY = (int)(nDy / nRow * (y - 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen * (nChain - 0.5)), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);			
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);		
												nChain = 0;			
											}				
										}					
										else					
										{					
											if(nChain >= 1)				
											{				
												nX = (int)(nDx / nCol * (x + 1.5));			
												nY = (int)(nDy / nRow * (y - 0.5));			
												
												OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen * (nChain - 0.5)), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
												
												pChangeLine = new BLINE;		
												pChangeLine->npStartPos.x=0;
												pChangeLine->npStartPos.y=0;
												pChangeLine->npEndPos.x=0;
												pChangeLine->npEndPos.y=0;
												
												pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
												pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
												OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)));			
												File.WriteString(OutStr);			
												//m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
												pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
												pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
												
												m_LineData.AddTail(pChangeLine);
												
												nChain = 0;			
											}				
										}					
									}						
								}							
							}								
						}									
						
					}										
				}											
				else	//���� 										
				{											
					int nInverse = 0;	// HJKim - 2D Dot									
					
					if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_DOT)										
					{	
					/*
					for(int x = -1; x <= nCol; x++)									
					{									
					nInverse++;								
					
					  //	for(int y = -1; y <= nRow; y++)							
					  for(int k = -1; k < nRow; k++)								
					  {								
					  int y;							
					  
						if(nInverse %2 == 0)							
						y = k;						
						else 							
						y = ((nRow - 1)  - k);						
						
						  nX = (int)(nDx / nCol * x + nDx/nCol/2);							
						  nY = (int)(nDy / nRow * y + nDy/nRow/2);							
						  
							if(x < 0 || x >= nCol || y < 0 || y >= nRow)							
							{							
							if(bMakeL)						
							{						
							result1 = 0;					
							}						
							else						
							{						
							result1 = 255;					
							}						
							}							
							else							
							{							
							result1 = m_pDib[nDx * nY + nX];						
							}							
							if(result1 == 0)							
							{							
							if(nInverse %2 != 0)						
							{						
							//	for (nLine = 0; nLine<nLineNum; nLine++)				
							for (nLine = (nLineNum - 1); nLine >= 0; nLine--)					
							{					
							OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
							OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
							}					
							}						
							else						
							{						
							for (nLine = 0; nLine<nLineNum; nLine++)					
							{					
							OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
							OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
							File.WriteString(OutStr);				
							m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
							}					
							}						
							}							
							}								
							}	
						*/
					}										
					else										
					{										
						for(int x = -1; x <= nCol; x++)									
						{									
							nChain = 0;								
							
							for(int y = -1; y <= nRow; y++)								
							{								
								nX = (int)(nDx / nCol * x + nDx/nCol/2);							
								nY = (int)(nDy / nRow * y + nDy/nRow/2);							
								
								if(x < 0 || x >= nCol || y < 0 || y >= nRow)							
								{							
									if(bMakeL)						
									{						
										result1 = 0;					
									}						
									else						
									{						
										result1 = 255;					
									}						
								}							
								else							
								{							
									result1 = m_pDib[nDx * nY + nX];						
								}							
								if(result1 == 0)							
								{							
									switch (gDProject.pstBarcode_LineMarking->m_nBarcodeType)						
									{						
									case MARKINGTYPE_LINE:		// LINE				
										nChain++;					
										nArray[y + 1] = 1;					
										
										if(y >= nRow || (!bMakeL && y + 1 >= nRow) || dDotRatio != 1.0)					
										{					
											result1 = 255;				
										}					
										else if(x < 0 || x >= nCol || (bMakeL && y + 1 >= nRow))					
										{					
											result1 = 0;				
										}					
										else					
										{					
											nNextX = (int)(nDx / nCol * x + nDx/nCol/2);				
											nNextY = (int)(nDy / nRow * (y + 1) + nDy/nRow/2);				
											result1 = m_pDib[nDx * nNextY + nNextX];				
										}					
										
										//						if(result1 != 0 && nZigzagType != 2)					
										if((result1 != 0 && nZigzagType != 2) || nZigzagType == 3)		// add by skchoi 2009.07.08			
										{					
											for(nLine = 0; nLine < nLineNum; nLine++)				
											{				
												//								if(nLine % 2 == 0 || nZigzagType == 1)			
												if(nLine % 2 == 0 || nZigzagType == 1 || nZigzagType == 3)		// add by skchoi 2009.07.08	
												{			
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 				
													
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
													
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
												}			
												else			
												{			
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);	
													
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													
												}			
											}				
											nChain = 0;				
										}					
										break;		
										/*
										case MARKINGTYPE_BOXANDLINE:		// BOX (+LINE)				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dGap * (nLine+1)), nPos.y = (int)(nY - dRectLen / 2.0));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dGap * (nLine+1)), nPos.y = (int)(nY + dRectLen / 2.0));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;					
										case MARKINGTYPE_BOXANDBOX:		// BOX (+BOX)				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);					
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY + dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0), nPos.y = (int)(nY - dRectLen / 2.0));					
										File.WriteString(OutStr);					
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);					
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										double dTempRectLen = (dRectLen / (nLineNum+1)) * (nLine+1);				
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX + dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY + dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										OutStr.Format("PA%d,%d;\n", nPos.x = (int)((nX - dTempRectLen / 2.0) + 0.5), nPos.y = (int)((nY - dTempRectLen / 2.0) + 0.5));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;					
										case MARKINGTYPE_DOT:		// DOT				
										for (nLine = 0; nLine<nLineNum; nLine++)					
										{					
										OutStr.Format("PU; PA%d,%d;\n", nPos.x = nX, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);				
										OutStr.Format("PD; PA%d,%d;\n", nPos.x = nX+1, nPos.y = (int)(nY - dRectLen / 2.0 + dGap * (nLine+1)));				
										File.WriteString(OutStr);				
										m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);				
										}					
										break;	
										*/
									}	
									
								}							
								else							
								{							
									nArray[y + 1] = 0;						
								}							
							}								
							
							if(gDProject.pstBarcode_LineMarking->m_nBarcodeType == MARKINGTYPE_LINE && nZigzagType == 2)		// add by skchoi 2009.06.16						
							{								
								for(nLine = 0; nLine < nLineNum; nLine++)							
								{							
									nChain = 0;						
									if(nLine % 2 == 0)						
									{						
										for(int y = -1; y <= nRow; y++)					
										{					
											if(nArray[y + 1])				
											{				
												nChain++;			
												
												if(y == nRow)			
												{			
													nX = (int)(nDx / nCol * (x + 0.5));		
													nY = (int)(nDy / nRow * (y + 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													nChain = 0;		
												}			
											}				
											else				
											{				
												if(nChain >= 1)			
												{			
													nX = (int)(nDx / nCol * (x + 0.5));		
													nY = (int)(nDy / nRow * (y - 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX - dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen / 2.0));		
													File.WriteString(OutStr);		
													
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);
													nChain = 0;		
												}			
											}				
										}					
									}						
									else						
									{						
										for(int y = nRow; y >= -1; y--)					
										{					
											if(nArray[y + 1])				
											{				
												nChain++;			
												
												if(y == -1)			
												{			
													nX = (int)(nDx / nCol * (x - 0.5));		
													nY = (int)(nDy / nRow * (y + 0.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);	
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);	
													nChain = 0;		
												}			
											}				
											else				
											{				
												if(nChain >= 1)			
												{			
													nX = (int)(nDx / nCol * (x - 0.5));		
													nY = (int)(nDy / nRow * (y + 1.5));		
													
													OutStr.Format("PU; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY + dRectLen * (nChain - 0.5)));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_JUMP);
													
													pChangeLine = new BLINE;		
													pChangeLine->npStartPos.x=0;
													pChangeLine->npStartPos.y=0;
													pChangeLine->npEndPos.x=0;
													pChangeLine->npEndPos.y=0;
													
													pChangeLine->npStartPos.x =int(nPos.x * dZoom.x); ///		
													pChangeLine->npStartPos.y =int(nPos.y * dZoom.y); 
													
													OutStr.Format("PD; PA%d,%d;\n", nPos.x = (int)(nX + dRectLen / 2.0 + dLineGap * (nLine + ZERO_POINT_FIVE)), nPos.y = (int)(nY - dRectLen / 2.0));		
													File.WriteString(OutStr);		
													//	m_pGlyph->addPoint(int(nPos.x * dZoom.x), int(nPos.y * dZoom.y), MARK_DRAW);		
													pChangeLine->npEndPos.x = int(nPos.x * dZoom.x);	///	
													pChangeLine->npEndPos.y = int(nPos.y * dZoom.y);	
													
													m_LineData.AddTail(pChangeLine);	
													nChain = 0;		
												}			
											}				
										}					
									}						
								}							
							}								
						}									
						
					}										
				}											
				
				OutStr.Format("PU; PA%d,%d;\n", nPos.x = nDx, nPos.y = nDy);											
				File.WriteString(OutStr);											
				
				delete[] nArray;											
				
				delete []tDib;											
				tDib = NULL;											
				m_pDib = NULL;											
				
				File.Close();											
				return TRUE;											
				
}
int C1DBarCode::Resiz_Imgbuf(imgdes *image, int width, int length, int bppixel)
{
	int rcode;
	int DefImgBppixel = 8;
	
	if (image->bmh != 0)
		freeimage(image);
	
	if(width < MINDIM)
		width = MINDIM;
	if(length < MINDIM)
		length = MINDIM;
	
	if((rcode = allocimage(image, width, length, bppixel)) != NO_ERROR)
		allocimage(image, DEFIMGWIDTH, DEFIMGLENGTH, DefImgBppixel);
	
	return(rcode);
}



BOOL C1DBarCode::GetBarcodeLineMarkingData(int nRefMode, int umFieldSize, BOOL bFlipX, BOOL bFilpY, int nRotate)
{
	
	RemoveResultData();	
	
	m_nLeft = INT_MAX;
	m_nRight = -INT_MAX;
	m_nBottom = INT_MAX;
	m_nTop = -INT_MAX;
	m_nUmFieldSize = umFieldSize;
	
	//bFilpY = TRUE;
#ifdef __USE_1D_MARKING__
	
	if (!MakeBarcode_LineMarking_1D())
		return FALSE;
#else
	//DWORD dwStartTime = timeGetTime();
	if (!MakeBarcode_LineMarking_2D(TRUE))
		return FALSE;


//	if (!MakeBarcode_LineMarking_2D_New(TRUE))
	//	return FALSE;

	//DWORD dwEndTime = timeGetTime();
	
//	int nTemp = dwEndTime - dwStartTime;
	
	//CString str;
	//	str.Format("���ڵ� 1ea �ҿ� �ð� :%03f sec \n",nTemp/1000.);
	//	                TRACE(str);

//	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str), reinterpret_cast<WPARAM>(&str));
#endif
	
	ChangeAxis(bFlipX, bFilpY, nRotate);
	
	RepositionData(nRefMode);
	
	
	return TRUE;
}
int C1DBarCode::GetDataCount(BOOL bDot)		
{		
	m_pos = m_LineData.GetHeadPosition();

//#ifdef __TEST2__
/*
	LPBLINE  pLine;	
	while(m_pos)
	{
		 pLine = m_LineData.GetNext(m_pos);

		   TRACE( "%d %d\n", pLine->npStartPos.x,pLine->npStartPos.y);
           TRACE( "%d %d\n", pLine->npEndPos.x,pLine->npEndPos.y);
	}
       m_pos = m_LineData.GetHeadPosition();
*/
//#endif

	return m_LineData.GetCount();
	
}		
BOOL C1DBarCode::GetNextPoint(BOOL bDot, int &nX, int &nY, int &nX2, int &nY2)			
{			
	if(m_pos == NULL)		
		return FALSE;	
	
	LPBLINE pLine;	
	pLine = m_LineData.GetNext(m_pos);	
	
	nX = 65535 * pLine->npStartPos.x / m_nUmFieldSize;	
	nY = 65535 * pLine->npStartPos.y / m_nUmFieldSize;	
	nX2 = 65535 * pLine->npEndPos.x / m_nUmFieldSize;	
	nY2 = 65535 * pLine->npEndPos.y / m_nUmFieldSize;	
	
	return TRUE;		
}
void C1DBarCode::ChangeAxis(BOOL bFilpX, BOOL bFilpY, int nRotate)
{
	int nX, nY, nResultX, nResultY;
	double cosTheta, sinTheta;
	LPBLINE pLine;
	POSITION pos;
	
	m_nLeft = INT_MAX;
	m_nRight = -INT_MAX;
	m_nBottom = INT_MAX;
	m_nTop = -INT_MAX;
	
	cosTheta = cos(nRotate * M_PI / 180.);
	sinTheta = sin(nRotate * M_PI / 180.);
	
	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		if(bFilpX)
			nX = -pLine->npStartPos.x;
		else
			nX = pLine->npStartPos.x;
		if(bFilpY)
			nY = -pLine->npStartPos.y;
		else
			nY = pLine->npStartPos.y;
		
		nResultX = (int)(cosTheta*(nX) - sinTheta*(nY));
		nResultY = (int)(sinTheta*(nX) + cosTheta*(nY));
		
		pLine->npStartPos.x = nResultX;
		pLine->npStartPos.y = nResultY;
		
		if(bFilpX)
			nX = -pLine->npEndPos.x;
		else
			nX = pLine->npEndPos.x;
		if(bFilpY)
			nY = -pLine->npEndPos.y;
		else
			nY = pLine->npEndPos.y;
		
		nResultX = (int)(cosTheta*(nX) - sinTheta*(nY));
		nResultY = (int)(sinTheta*(nX) + cosTheta*(nY));
		
		pLine->npEndPos.x = nResultX;
		pLine->npEndPos.y = nResultY;
		
		if(pLine->npStartPos.x < m_nLeft)	m_nLeft = pLine->npStartPos.x;
		if(pLine->npStartPos.x > m_nRight)	m_nRight = pLine->npStartPos.x;
		if(pLine->npEndPos.x < m_nLeft)		m_nLeft = pLine->npEndPos.x;
		if(pLine->npEndPos.x > m_nRight)	m_nRight = pLine->npEndPos.x;
		
		if(pLine->npStartPos.y < m_nBottom)	m_nBottom = pLine->npStartPos.y;
		if(pLine->npStartPos.y > m_nTop)	m_nTop = pLine->npStartPos.y;
		if(pLine->npEndPos.y < m_nBottom)	m_nBottom = pLine->npEndPos.y;
		if(pLine->npEndPos.y > m_nTop)		m_nTop = pLine->npEndPos.y;
	}
	
	
}			
void C1DBarCode::RepositionData(int nMode)
{
	int nX, nY;
	if(nMode == 0)
	{
		nX = -m_nLeft;
		nY = -m_nTop;
	}
	else if(nMode == 1)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -m_nTop;
	}
	else if(nMode == 2)
	{
		nX = -m_nRight;
		nY = -m_nTop;
	}
	else if(nMode == 3)
	{
		nX = -m_nLeft;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 4)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 5)
	{
		nX = -m_nRight;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 6)
	{
		nX = -m_nLeft;
		nY = -m_nBottom;
	}
	else if(nMode == 7)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -m_nBottom;
	}
	else if(nMode == 8)
	{
		nX = -m_nRight;
		nY = -m_nBottom;
	}
	//-----
	LPBLINE pLine;
	POSITION pos;
	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		pLine->npStartPos.x +=nX;
		pLine->npStartPos.y +=nY;
		pLine->npEndPos.x +=nX;
		pLine->npEndPos.y +=nY;
	}
	
	
}
void C1DBarCode::RemoveResultData()
{
	LPBLINE pLine;
	POSITION pos;
	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		delete pLine;
		pLine = NULL;
	}
	m_LineData.RemoveAll();
	
	
}