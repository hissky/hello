// HOLECONVERTDATA.cpp: implementation of the HOLECONVERTDATA class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HOLECONVERTDATA.h"

//HANDLE HOLECONVERTDATA::s_hHeapCvt = NULL;
//UINT   HOLECONVERTDATA::s_uNumAllocsInHeapCvt = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HOLECONVERTDATA::HOLECONVERTDATA()
{
	dpLSBPos1.x = dpLSBPos1.y = 0;
	dpLSBPos2.x = dpLSBPos2.y = 0;
	bSelect = FALSE;
	bDistanceSortingFinish = FALSE;
	bPreHoleFind = FALSE;
	bPostHoleFind = FALSE;
	m_pblockPosList = NULL;
	pPreHoleFindPosList = NULL;
	pPostHoleFindPosList = NULL;


//	nUnitIndex = -1;
	bFindHole = FALSE;
}
/*
void* HOLECONVERTDATA::operator new(size_t nSize)
{
	if(NULL == s_hHeapCvt)
	{
		s_hHeapCvt = HeapCreate(0 , 4*64*1024, 0);
		if(NULL == s_hHeapCvt)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeapCvt, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeapCvt++;
	}
	return p;
}

void HOLECONVERTDATA::operator delete(void *p)
{
	if(HeapFree(s_hHeapCvt, 0, p)) {
		s_uNumAllocsInHeapCvt--;
	}
	
	if(0 == s_uNumAllocsInHeapCvt)
	{
		if(HeapDestroy(s_hHeapCvt)) {
			s_hHeapCvt = NULL;
		}
	}
}

void* HOLECONVERTDATA::operator new(size_t nSize, LPCSTR lpszFileName, int nLine)
{
	//////////////////////////////////
	// MJ Choi - Modify GlyphLine New
	//////////////////////////////////
	
	if(NULL == s_hHeapCvt)
	{
		s_hHeapCvt = HeapCreate(0 , 4*64*1024, 0);
		if(NULL == s_hHeapCvt)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeapCvt, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeapCvt++;
	}
	return p;
}

void HOLECONVERTDATA::operator delete(void* p, LPCSTR lpszFileName, int nLine)
{
	if(HeapFree(s_hHeapCvt, 0, p)) {
		s_uNumAllocsInHeapCvt--;
	}
	
	if(0 == s_uNumAllocsInHeapCvt)
	{
		if(HeapDestroy(s_hHeapCvt)) {
			s_hHeapCvt = NULL;
		}
	}
}
*/

FireHoleList::FireHoleList()
{
	m_nCount = 0;
	m_nAddCount = 0;
	m_pHeadHoleConvertData = NULL;
	m_pTailHoleConvertData = NULL;
}

FireHoleList::~FireHoleList()
{
	RemoveAll();
}

int FireHoleList::GetCount()
{
	return m_nCount;
}

POSITION FireHoleList::GetHeadPosition()
{
	if(m_nCount == 0)
		return NULL;
	return ((POSITION)m_pHeadHoleConvertData);
}

LPFIREHOLE FireHoleList::GetNext(POSITION &pos)
{
	if(m_nCount == 0)
		return NULL;

	LPFIREHOLE pData = (LPFIREHOLE)pos;
	pos = (POSITION)(pData->pNext);
	return pData;
}

LPFIREHOLE FireHoleList::AddTail(HOLECONVERTDATA dData)
{
	LPFireHOLEDATAUNIT pHoleUnit;
	int nArray, nIndex;
	nArray = m_nAddCount/MAX_UNIT_NO;
	nIndex = m_nAddCount%MAX_UNIT_NO;
	if(nIndex == 0)
	{
		pHoleUnit = new FireHOLEDATAUNIT;
		m_List.Add(pHoleUnit);
	}
	else
		pHoleUnit =  m_List.GetAt(nArray);

	memcpy(&pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount], &dData, sizeof(HOLECONVERTDATA));
	dData.m_pblockPosList = NULL;
//	pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pblockPosList = NULL;
	if(m_pHeadHoleConvertData == NULL)
	{
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pBefore = NULL;
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pNext = NULL;
		m_pHeadHoleConvertData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
		m_pTailHoleConvertData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
	}
	else
	{
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pBefore = m_pTailHoleConvertData;
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pNext = NULL;
		m_pTailHoleConvertData->pNext = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
		m_pTailHoleConvertData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
	}

	pHoleUnit->m_nUnitCount++;
	m_nCount++;
	m_nAddCount++;

	return m_pTailHoleConvertData;
}

void FireHoleList::RemoveAll()
{
	m_nCount = 0;
	m_nAddCount = 0;
	m_pHeadHoleConvertData = NULL;
	m_pTailHoleConvertData = NULL;

	LPFireHOLEDATAUNIT pHoleUnit;
	int nUnitCount = m_List.GetCount();
	for(int i = 0; i < nUnitCount; i++)
	{
		pHoleUnit =  m_List.GetAt(i);
//		pHoleUnit->m_HoleUnitList[i].RemoveAllPreHoleFindData(TRUE);
		delete pHoleUnit;
	}
	m_List.RemoveAll();
}

void FireHoleList::RemoveAt(POSITION pos)
{
	if(pos == NULL)
		return;

	LPFIREHOLE pData = (LPFIREHOLE)pos;

	if(pData->pBefore)
	{
		(pData->pBefore)->pNext = pData->pNext;
		if(pData->pNext)
		{
			(pData->pNext)->pBefore = pData->pBefore;
		}
		else
		{
			m_pTailHoleConvertData = pData->pBefore;
		}
	}
	else
	{
		if(pData->pNext)
		{
			m_pHeadHoleConvertData = pData->pNext;
			m_pHeadHoleConvertData->pBefore = NULL;
		}
		else
		{
			m_pHeadHoleConvertData = m_pTailHoleConvertData = NULL;
		}
	}
	m_nCount--;
}
