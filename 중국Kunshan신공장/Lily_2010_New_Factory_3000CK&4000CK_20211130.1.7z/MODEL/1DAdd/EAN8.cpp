// EAN13.cpp: implementation of the CEAN8 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "easymarker.h"

#include "EAN8.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEAN8::CEAN8()
{
	m_nSymbology = EAN8;
	list.RemoveAll();
	numList.RemoveAll();
}

CEAN8::CEAN8(int nSymbology)
{
	m_nSymbology = nSymbology;
}


CEAN8::~CEAN8()
{

}

void CEAN8::LoadData(CString csMessage, double dNarrowBar, double dFinalHeight, long nGuardbarHeight, int nStartingXPixel, int nStartingYPixel, double dRatio)
{
	m_nGuardbarHeight = nGuardbarHeight;

	//standardize the message
	int nLen = csMessage.GetLength();
	int nNumberOfAdditionZero = m_nSymbology == EAN8 ? 7 - nLen : 2 - nLen;//CHECK

	if (nNumberOfAdditionZero > 0)
	{ // missing some numbers
		for (int i = 0 ; i < nNumberOfAdditionZero ; i ++)
			csMessage = '0' + csMessage ;// just adding zeros at the head of message
	}
	else if (nNumberOfAdditionZero < 0)
	{ 
		if (m_nSymbology == EAN8)
				csMessage.Delete(3,-nNumberOfAdditionZero);
		else
				csMessage.Delete(6,-nNumberOfAdditionZero);
	}
		
	CBarcode::LoadData(csMessage,dNarrowBar,dFinalHeight,nStartingXPixel,nStartingYPixel,dRatio);
}

// hjlee
long CEAN8::CalculateCheckSumDigit()
{ 
	int i, nLen, nSum = 0, nItem;
	int even = 0, odd = 0;
	nLen = m_csMessage.GetLength();

	for (i = 0 ; i < nLen ; i++)
	{
		if(i%2 == 0)
		{
			nItem = (int)m_csMessage.GetAt(i) - 48;
			odd += nItem;
		}
		else
		{
			nItem = (int)m_csMessage.GetAt(i) - 48;
			even += nItem;
		}
	}
	nSum = odd * 3 + even; //* 3;//modify hhwang 08.05.19

	nSum %= 10;
	if(nSum == 0) return 0;
	return (10 - nSum);
}


CString CEAN8::RetrieveSystemNumberPattern(int iSystemNumber /* = 0 */, int iNumber)
{
	CString strCharPattern;
	if (iSystemNumber == 0){
		switch (iNumber){
			case 0: 
				strCharPattern = "EEEOOO"; 
				break;
			case 1: 
				strCharPattern = "EEOEOO"; 
				break;
			case 2: 
				strCharPattern = "EEOOEO"; 
				break;
			case 3: 
				strCharPattern = "EEOOOE"; 
				break;
			case 4: 
				strCharPattern = "EOEEOO"; 
				break;
			case 5:
				strCharPattern = "EOOEEO"; 
				break;
			case 6: 
				strCharPattern = "EOOOEE"; 
				break;
			case 7:
				strCharPattern = "EOEOEO"; 
				break;
			case 8: 
				strCharPattern = "EOEOOE"; 
				break;
			case 9: 
				strCharPattern = "EOOEOE"; 
				break;
		}
	}
	else{
		switch(iNumber){
			case 0: 
				strCharPattern = "OOOEEE"; 
				break;
			case 1: 
				strCharPattern = "OOEOEE"; 
				break;
			case 2: 
				strCharPattern = "OOEEOE"; 
				break;
			case 3: 
				strCharPattern = "OOEEEO"; 
				break;
			case 4: 
				strCharPattern = "OEOOEE"; 
				break;
			case 5: 
				strCharPattern = "OEEOOE"; 
				break;
			case 6: 
				strCharPattern = "OEEEOO"; 
				break;
			case 7: 
				strCharPattern = "OEOEOE"; 
				break;
			case 8: 
				strCharPattern = "OEOEEO"; 
				break;
			case 9: 
				strCharPattern = "OEEOEO"; 
				break;
		}
	}
	return strCharPattern;
}


CString CEAN8::RetrieveLeftOddParityPattern(int iNumber)
{
	CString strCharPattern;

	switch(iNumber){
		case 0: 
			strCharPattern = "sssbbsb"; 
			break;
		case 1: 
			strCharPattern = "ssbbssb";
			break;
		case 2: 
			strCharPattern = "ssbssbb"; 
			break;
		case 3: 
			strCharPattern = "sbbbbsb"; 
			break; 
		case 4: 
			strCharPattern = "sbsssbb"; 
			break; 
		case 5: 
			strCharPattern = "sbbsssb"; 
			break;
		case 6:
			strCharPattern = "sbsbbbb";
			break;
		case 7:
			strCharPattern = "sbbbsbb"; 
			break;
		case 8:
			strCharPattern = "sbbsbbb";
			break; 
		case 9:
			strCharPattern = "sssbsbb"; 
			break;
	}
	return strCharPattern;
}


CString CEAN8::RetrieveLeftEvenParityPattern(int iNumber)
{
	CString strCharPattern;
	
	switch(iNumber){
		case 0: 
			strCharPattern = "sbssbbb";
			break;
		case 1: 
			strCharPattern = "sbbssbb";
			break; 
		case 2:
			strCharPattern = "ssbbsbb";
			break; 
		case 3: 
			strCharPattern = "sbssssb";
			break;
		case 4:
			strCharPattern = "ssbbbsb";
			break;
		case 5:
			strCharPattern = "sbbbssb";
			break;
		case 6: 
			strCharPattern = "ssssbsb";
			break; 
		case 7: 
			strCharPattern = "ssbsssb";
			break;
		case 8: 
			strCharPattern = "sssbssb"; 
			break;
		case 9:
			strCharPattern = "ssbsbbb";
			break;
	}
	return strCharPattern;
}



CString CEAN8::RetrieveLeftPattern(int iNumber)
{
	CString strCharPattern;
	
	switch(iNumber){
		case 0: 
			strCharPattern = "sssbbsb";
			break; 
		case 1:
			strCharPattern = "ssbbssb";
			break; 
		case 2: 
			strCharPattern = "ssbssbb";
			break; 
		case 3:
			strCharPattern = "sbbbbsb"; 
			break; 
		case 4:
			strCharPattern = "sbsssbb"; 
			break; 
		case 5:
			strCharPattern = "sbbsssb";
			break; 
		case 6: 
			strCharPattern = "sbsbbbb";
			break; 
		case 7: 
			strCharPattern = "sbbbsbb";
			break; 
		case 8:
			strCharPattern = "sbbsbbb";
			break; 
		case 9: 
			strCharPattern = "sssbsbb"; 
			break;
	}

	return strCharPattern;
}


CString CEAN8::RetrieveRightPattern(int iNumber)
{
	CString strCharPattern;
	
	switch(iNumber){
		case 0: 
			strCharPattern = "bbbssbs";
			break; 
		case 1:
			strCharPattern = "bbssbbs";
			break; 
		case 2: 
			strCharPattern = "bbsbbss";
			break; 
		case 3:
			strCharPattern = "bssssbs"; 
			break; 
		case 4:
			strCharPattern = "bsbbbss"; 
			break; 
		case 5:
			strCharPattern = "bssbbbs";
			break; 
		case 6: 
			strCharPattern = "bsbssss";
			break; 
		case 7: 
			strCharPattern = "bsssbss";
			break; 
		case 8:
			strCharPattern = "bssbsss";
			break; 
		case 9: 
			strCharPattern = "bbbsbss"; 
			break;
	}

	return strCharPattern;
}

void CEAN8::DrawPattern(CString csPattern)
{
	int			i,nXPixel,nYPixel;
	CDC			oDC;

	// attach to the device context
	oDC.Attach(m_hDC);

	// initialize X pixel value
	nXPixel = m_nStartingXPixel;

	for (i=0;i<csPattern.GetLength();i++)
	{		
		// X value for loop
		for (nXPixel=m_nStartingXPixel;nXPixel<m_nStartingXPixel+m_nNarrowBarPixelWidth;nXPixel++)
		{	
			// Y value for loop
			CString str;
			
			if (csPattern.GetAt(i)=='b')
			{
				str.Format("PU");
				list.AddTail(str);
				str.Format("PA%d,%d;\n\r",nXPixel,0);
				list.AddTail(str);
				str.Format("PD%d,%d\n\r",nXPixel,400);
				list.AddTail(str);
			}			

			for (nYPixel=m_nStartingYPixel;nYPixel<m_nStartingYPixel+m_nPixelHeight+m_nGuardbarHeight;nYPixel++)
			{
				// if this is a bar
				if (csPattern.GetAt(i)=='b')
				{
					
					oDC.SetPixel(nXPixel,nYPixel,COLORBLACK);
					
				
				}
				else
					oDC.SetPixelV(nXPixel,nYPixel,COLORWHITE);
			}
		}	
		// advance the starting position
		m_nStartingXPixel+= m_nNarrowBarPixelWidth;
	}

	int count = 0;
	int count1 = 0;
	CString str;
	for (i=0;i<csPattern.GetLength();i++)
	{
		
		if (csPattern.GetAt(i)=='b')
		{
			if(count1 != 0)
			{
				str.Format("W%d",count1);
				numList.AddTail(str);				
				count1 = 0;
			}
			count++;
		}
		else
		{
			if(count != 0)
			{
				str.Format("%d",count);
				numList.AddTail(str);
				count = 0;
			}
			count1++;
		}
	}

	if(count1 != 0)
	{
		str.Format("W%d",count1);
		numList.AddTail(str);				
		count1 = 0;
	}

	if(count != 0)
	{
		str.Format("%d",count);
		numList.AddTail(str);
		count = 0;
	}

	// detach from the device context
	oDC.Detach();
	
	return;

}

void CEAN8::DrawEAN8()
{
	int i, tmpGuardBarHeight;
	
	DrawPattern("sssssssss"); // draw quite zone	
	DrawPattern("bsb"); // draw lead

	//hjlee DrawPattern(RetrieveLeftPattern((int)m_csMessage.GetAt(0)-48)); // draw number system
	DrawPattern(RetrieveLeftPattern((int)m_csMessage.GetAt(0)-48));//added by hhwang 08.05.19
	//StructureOfEAN8((int)m_csMessage.GetAt(0)-48);
	
	tmpGuardBarHeight = m_nGuardbarHeight;
	m_nGuardbarHeight = 0;

	for (i = 1 ; i <= 3 ; i++)// draw manufacturer code
		//DrawPattern(RetrieveLeftPattern((int)m_csMessage.GetAt(i)-48));
		DrawPattern(RetrieveLeftPattern((int)m_csMessage.GetAt(i)-48));//added by hhwang 08.05.19

	m_nGuardbarHeight = tmpGuardBarHeight;

	DrawPattern("sbsbs"); // draw separator bars

	tmpGuardBarHeight = m_nGuardbarHeight;
	m_nGuardbarHeight = 0;

	for (i = 4 ; i < 7 ; i ++) // draw product code
		DrawPattern(RetrieveRightPattern((int)m_csMessage.GetAt(i)-48));

	m_nGuardbarHeight = tmpGuardBarHeight;
	DrawPattern(RetrieveRightPattern(CalculateCheckSumDigit())); //draw check sum digits
 
	
	DrawPattern("bsb"); // draw trailer bars
	DrawPattern("sssssssss"); // draw quite zone 

	CStdioFile InI;
	CString write;
	DeleteFile("C:\\EasyMarker\\Logo\\test.plt");
	Sleep(100);
	InI.Open("C:\\EasyMarker\\Logo\\test.plt",CFile::modeCreate|CFile::modeWrite );
	
	POSITION pos;
	pos = list.GetHeadPosition();
	while (pos)
	{
		write = list.GetNext(pos);
		InI.WriteString(write);
	}
	InI.Close();

}

void CEAN8::DrawUPCE()
{
	
	int i,nCheckDigit, nSystemNumber, tmpGuardBarHeight;

	nSystemNumber = (int)m_csMessage.GetAt(0)-48;
	nCheckDigit = CalculateCheckSumDigit();
	
	CString strSystemNumberPattern = RetrieveSystemNumberPattern(nSystemNumber,nCheckDigit);

	DrawPattern("sssssssss"); // draw quite zone	
	DrawPattern("bsb"); // draw lead
	
	tmpGuardBarHeight = m_nGuardbarHeight;
	m_nGuardbarHeight = 0;
	
	for (i = 1 ; i < 7 ; i ++){
		if (strSystemNumberPattern[i-1] == 'O')
			DrawPattern(RetrieveLeftOddParityPattern((int)m_csMessage.GetAt(i)-48));

		if (strSystemNumberPattern[i-1] == 'E')
			DrawPattern(RetrieveLeftEvenParityPattern((int)m_csMessage.GetAt(i)-48));
	}

	m_nGuardbarHeight = tmpGuardBarHeight;

	DrawPattern("sbsbs"); // draw separator bars
	DrawPattern("b"); // draw trailer bars
	DrawPattern("sssssssss"); // draw quite zone 

}


void CEAN8::DrawBitmap()
{
//hjlee	if (m_nSymbology == EAN13)
		DrawEAN8();
//hjlee	else
//hjlee		DrawUPCE();
}

void CEAN8::BitmapToClipboard()
{
}

void CEAN8::StructureOfEAN8(int iNo)
{
	switch(iNo)
	{
	case 0 : m_strStructure = "LLLLLL"; break;
	case 1 : m_strStructure = "LLGLGG"; break;
	case 2 : m_strStructure = "LLGGLG"; break;
	case 3 : m_strStructure = "LLGGGL"; break;
	case 4 : m_strStructure = "LGLLGG"; break;
	case 5 : m_strStructure = "LGGLLG"; break;
	case 6 : m_strStructure = "LGGGLL"; break;
	case 7 : m_strStructure = "LGLGLG"; break;
	case 8 : m_strStructure = "LGLGGL"; break;
	case 9 : m_strStructure = "LGGLGL"; break;
	}
}

CString CEAN8::EncodingDigit(int iNo, int iCnt)
{
	CString str;
	switch(iNo)
	{
		case 0 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sssbbsb" : "sbssbbb"; break;
		case 1 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "ssbbssb" : "sbbssbb"; break;
		case 2 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "ssbssbb" : "ssbbsbb"; break;
		case 3 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbbbbsb" : "sbssssb"; break;
		case 4 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbsssbb" : "ssbbbsb"; break;
		case 5 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbbsssb" : "sbbbssb"; break;
		case 6 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbsbbbb" : "ssssbsb"; break;
		case 7 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbbbsbb" : "ssbsssb"; break;
		case 8 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sbbsbbb" : "sssbssb"; break;
		case 9 : str = (m_strStructure.GetAt(iCnt-1) == 'L') ? "sssbsbb" : "ssbsbbb"; break;
	}
	return str;
}
