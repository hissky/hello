// DAreaInfo.cpp: implementation of the DAreaInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "DAreaInfo.h"
#include "DProject.h"
#include "..\UI\ColorComboEx.h"
#include "DProject.h"
#include "..\UI\PaneAutoRun.h"
#include "..\UI\PaneRecipeGen.h"//20200901
#include "..\UI\PaneRecipeGenData.h"
#include "HOLEDATA.h"
#include "dprocessini.h"
#include "DSystemINI.h"
#include "DBeamPathINI.h"
#include "DShotTableINI.h"
#include "2DBarcode.h"
#include "DTextData.h"
#include "..\model\GlobalVariable.h"
#include "math.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DAreaInfo::DAreaInfo()
{
	// 20130419 fiducial ������, block �� ���� �����ϱ� ����
	m_cColorFid[0] = m_cColorFid[25] = 0xFFFF00;
	m_cColorFid[1] = m_cColorFid[26] = 0xFF0000;
	m_cColorFid[2] = m_cColorFid[27] = 0x008000;
	m_cColorFid[3] = m_cColorFid[28] = 0x00FF00;
	m_cColorFid[4] = m_cColorFid[29] = 0x00A5FF;
	m_cColorFid[5] = m_cColorFid[30] = 0x000080;
	m_cColorFid[6] = m_cColorFid[31] = 0x2A2AA5;
	m_cColorFid[7] = m_cColorFid[32] = 0x5C5CCD;
	m_cColorFid[8] = m_cColorFid[33] = 0x7280FA;
	m_cColorFid[9] = m_cColorFid[34] = 0x00D7FF;
	m_cColorFid[10] = m_cColorFid[35] = 0x8CB4D2;
	m_cColorFid[11] = m_cColorFid[36] = 0x8CE6F0;
	m_cColorFid[12] = m_cColorFid[37] = 0x808000;
	m_cColorFid[13] = m_cColorFid[38] = 0x800080;
	m_cColorFid[14] = m_cColorFid[39] = 0xA09E5F;
	m_cColorFid[15] = m_cColorFid[40] = 0x3CA4DC;
	m_cColorFid[16] = m_cColorFid[41] = 0xC0C0C0;
	m_cColorFid[17] = m_cColorFid[42] = 0x800000;
	m_cColorFid[18] = m_cColorFid[43] = 0xDDA0DD;
	m_cColorFid[19] = m_cColorFid[44] = 0xEE82EE;
	m_cColorFid[20] = m_cColorFid[45] = 0x578B2E;
	m_cColorFid[21] = m_cColorFid[46] = 0xA0A000;
	m_cColorFid[22] = m_cColorFid[47] = 0xA9A9A9;
	m_cColorFid[23] = m_cColorFid[48] = 0x82004B;
	m_cColorFid[24] = m_cColorFid[49] = 0x808080;

	m_nRefNo = 0;
	m_nSortIndex = 0;

	m_dTableOffsetX = 0.0;
	m_dTableOffsetY = 0.0;
	
	m_bCheckIndex = FALSE;
	
	m_d1stAngle = 0;
	m_d2ndAngle = 0;
	m_nFidBlock = -1;
//	m_pcField = new BYTE[4097 * 4097];
}

DAreaInfo::~DAreaInfo()
{
	m_nRefNo--;
	//if(m_nRefNo <= 0)
	{
		ClearData();
	}
//	if(m_pcField)
//	{
//		delete [] m_pcField;
//		m_pcField = NULL;
//	}
}

BOOL DAreaInfo::IsInData(CPoint pt, int nFidIndex)
{
	if(pt.x < m_nMinX) return FALSE;
	if(pt.x > m_nMaxX) return FALSE;
	if(pt.y < m_nMinY) return FALSE;
	if(pt.y > m_nMaxY) return FALSE;

//	LPFIREHOLE pHole = new HOLECONVERTDATA;
//	pHole->pOrigin = (HOLEDATA*)nFidIndex; // Index --> save
//	pHole->bSelect = FALSE;
//	m_FireHoles[ADDED_FID_TOOL].AddTail(pHole);

	HOLECONVERTDATA dHole;
	dHole.pOrigin = (HOLEDATA*)nFidIndex; // Index --> save
	dHole.bSelect = FALSE;
	m_FireHoles[ADDED_FID_TOOL].AddTail(dHole);
	return TRUE;
}
// 20161111
BOOL DAreaInfo::IsInData(LPHOLEDATA pOrigin, int nMinX, int nMaxX, int nMinY, int nMaxY, int nRealTooNo, int nUnitNo)
{
	if(nMinX > m_nMaxX || nMinX < m_nMinX) return FALSE;
	if(nMaxX > m_nMaxX || nMaxX < m_nMinX) return FALSE;
	if(nMinY > m_nMaxY || nMinY < m_nMinY) return FALSE;
	if(nMaxY > m_nMaxY || nMaxY < m_nMinY) return FALSE;

	return IsInData(pOrigin, nRealTooNo, nUnitNo);
}
BOOL DAreaInfo::IsInData(LPHOLEDATA pOriginHole, int nRealTooNo, int nUnitNo)
{
	if(pOriginHole->npPos.x < m_nMinX) return FALSE;
	if(pOriginHole->npPos.x > m_nMaxX) return FALSE;
	if(pOriginHole->npPos.y < m_nMinY) return FALSE;
	if(pOriginHole->npPos.y > m_nMaxY) return FALSE;

//	LPFIREHOLE pHole = new HOLECONVERTDATA;
//	pHole->pOrigin = pOriginHole;
//	pHole->bSelect = FALSE;
//	pHole->pOrigin->nUnitIndex = nUnitNo;
//	m_FireHoles[nRealTooNo].AddTail(pHole);

	HOLECONVERTDATA dHole;
	dHole.pOrigin = pOriginHole;
	dHole.bSelect = FALSE;
	dHole.pOrigin->nUnitIndex = nUnitNo;
	m_nFidBlock = pOriginHole->nFidBlock;
	m_FireHoles[nRealTooNo].AddTail(dHole);
	return TRUE;
}

// ����� �̻��ؼ� �������� �����ų� ������ ������ ��쿡�� return False, �׿� return true
BOOL DAreaInfo::IsInData(LPLINEDATA pOriginLine, int nMinX, int nMaxX, int nMinY, int nMaxY, int nToolType, int nRealTooNo, int nUnitNo)
{


	if(nMinX > m_nMaxX) return FALSE;
	if(nMaxX < m_nMinX) return FALSE;
	if(nMinY > m_nMaxY) return FALSE;
	if(nMaxY < m_nMinY) return FALSE;

	if(nMaxX - nMinX <= 3 && nMinY != nMaxY)
	{
		nMaxX = nMinX;
		if(nMinY <= m_nMinY) nMinY = m_nMinY;
		if(nMaxY >= m_nMaxY) nMaxY = m_nMaxY;
		if(nMinY >= nMaxY) return FALSE;
		if(pOriginLine->npStartPos.y > pOriginLine->npEndPos.y)
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.y = nMaxY;
			pLine->npStartPos.x = nMaxX;
			pLine->npEndPos.y = nMinY;
			pLine->npEndPos.x = nMaxX;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
		else
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.y = nMinY;
			pLine->npStartPos.x = nMaxX;
			pLine->npEndPos.y = nMaxY;
			pLine->npEndPos.x = nMaxX;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
	}
	else if(nMaxY - nMinY <= 3 && nMinX != nMaxX)
	{
		nMaxY = nMinY;
		if(nMinX <= m_nMinX) nMinX = m_nMinX;
		if(nMaxX >= m_nMaxX) nMaxX = m_nMaxX;
		if(nMinX >= nMaxX) return FALSE;
		if(pOriginLine->npStartPos.x > pOriginLine->npEndPos.x)
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.x = nMaxX;
			pLine->npStartPos.y = nMaxY;
			pLine->npEndPos.x = nMinX;
			pLine->npEndPos.y = nMaxY;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
		else
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.x = nMinX;
			pLine->npStartPos.y = nMaxY;
			pLine->npEndPos.x = nMaxX;
			pLine->npEndPos.y = nMaxY;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
	}
	else
	{
		double a, b, x1, x2, y1, y2;
		int nStartX, nStartY, nEndX, nEndY;
//		if((m_nMaxX - m_nMinX) > (m_nMaxY - m_nMinY))	// y = ax + b
//		{
			a = (double)(pOriginLine->npStartPos.y - pOriginLine->npEndPos.y) / 
				(double)(pOriginLine->npStartPos.x - pOriginLine->npEndPos.x);
			b = pOriginLine->npStartPos.y - a * pOriginLine->npStartPos.x;
			y1 = a * m_nMinX + b;
			y2 = a * m_nMaxX + b;
			x1 = (m_nMinY - b) / a;
			x2 = (m_nMaxY - b) / a;
			if(a>0)
			{
				if(y1 < m_nMaxY && y1 >= m_nMinY)
				{
					nStartX = m_nMinX; nStartY = (int)y1;
				}
				else if(x1 < m_nMaxX && x1 >= m_nMinX)
				{
					nStartX = (int)x1; nStartY = m_nMinY;
				}
				else
					return FALSE;

				if(x2 < m_nMinX || y2 < m_nMinY) return FALSE;
				if(x2 <= m_nMaxX)
				{
					nEndX = (int)x2; nEndY = m_nMaxY;
				}
				else if(y2 <= m_nMaxY)
				{
					nEndX = m_nMaxX; nEndY = (int)y2;
				}
				else
					return FALSE;
			}
			else
			{
				if(y1 <= m_nMaxY && y1 > m_nMinY)
				{
					nStartX = m_nMinX; nStartY = (int)y1;
				}
				else if(x2 < m_nMaxX && x2 >= m_nMinX)
				{
					nStartX = (int)x2; nStartY = m_nMaxY;
				}
				else
					return FALSE;
				
				if(x1 < m_nMinX || y2 > m_nMaxY) return FALSE;
				if(x1 <= m_nMaxX)
				{
					nEndX = (int)x1; nEndY = m_nMinY;
				}
				else if(y2 >= m_nMinY)
				{
					nEndX = m_nMaxX; nEndY = (int)y2;
				}
				else
					return FALSE;
			}
			if(pOriginLine->npStartPos.x > pOriginLine->npEndPos.x)
			{
				LPFIRELINE	pLine = new LINE_CONVERT_DATA;
				pLine->pOrigin = pOriginLine;
				if(pOriginLine->npStartPos.x < nEndX)
				{
					pLine->npStartPos.x = pOriginLine->npStartPos.x;
					pLine->npStartPos.y = pOriginLine->npStartPos.y;
				}
				else
				{
					pLine->npStartPos.x = nEndX;
					pLine->npStartPos.y = nEndY;
				}
				if(pOriginLine->npEndPos.x > nStartX)
				{
					pLine->npEndPos.x = pOriginLine->npEndPos.x;
					pLine->npEndPos.y = pOriginLine->npEndPos.y;
				}
				else
				{
					pLine->npEndPos.x = nStartX;
					pLine->npEndPos.y = nStartY;
				}
				pLine->bSelect = FALSE;
				pLine->pOrigin->nUnitIndex = nUnitNo;
				m_FireLines[nRealTooNo].AddTail(pLine);
			}
			else
			{
				LPFIRELINE	pLine = new LINE_CONVERT_DATA;
				pLine->pOrigin = pOriginLine;
				if(pOriginLine->npStartPos.x > nStartX)
				{
					pLine->npStartPos.x = pOriginLine->npStartPos.x;
					pLine->npStartPos.y = pOriginLine->npStartPos.y;
				}
				else
				{
					pLine->npStartPos.x = nStartX;
					pLine->npStartPos.y = nStartY;
				}
				if(pOriginLine->npEndPos.x < nEndX)
				{
					pLine->npEndPos.x = pOriginLine->npEndPos.x;
					pLine->npEndPos.y = pOriginLine->npEndPos.y;
				}
				else
				{
					pLine->npEndPos.x = nEndX;
					pLine->npEndPos.y = nEndY;
				}
				pLine->bSelect = FALSE;
				pLine->pOrigin->nUnitIndex = nUnitNo;
				m_FireLines[nRealTooNo].AddTail(pLine);
			}
/*		}
		else											// x = ay + b
		{
			a = (double)(pOriginLine->npStartPos.y - pOriginLine->npEndPos.y) / 
				(double)(pOriginLine->npStartPos.x - pOriginLine->npEndPos.x);
			b = pOriginLine->npStartPos.x - a * pOriginLine->npStartPos.y;
		}
*/
	}
	return TRUE;
}

void DAreaInfo::Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList **pToolCodes, int nSkipNo, int nMode, BOOL bDrawPath, BOOL bShowIndex,int nFidPane, BOOL bShowHoleIndex, int &nHolecount, BlockList* pBlocks)
{

	if(gVariable.m_bShowSelectAreaOnly && gVariable.m_nSelectArea != -1)
	{
		if(gVariable.m_nSelectArea != m_nSortIndex)
			return;
	}
	
	if(m_nFireStatus == DONE_FIRE || m_nFireStatus == DOING_FIRE)
	{
		CBrush cBr2;
		CBrush *pBrushOld;
		if(m_nFireStatus == DONE_FIRE)
			cBr2.CreateSolidBrush(RGB(0, 0, 200));
		else
			cBr2.CreateSolidBrush(RGB(255, 0, 0));

		pBrushOld = pDC->SelectObject(&cBr2);
		
		int nX1, nX2, nY1, nY2;
		GetXY(nMode, m_nMinX, m_nMinY, nX1, nY1, dDrawStartX, dDrawStartY, dScale);
		GetXY(nMode, m_nMaxX, m_nMaxY, nX2, nY2, dDrawStartX, dDrawStartY, dScale);
		CRect rect;
		if(nX1 > nX2)
		{
			rect.left = nX2; rect.right = nX1;
		}
		else
		{
			rect.left = nX1; rect.right = nX2;
		}
		
		if(nY1 > nY2)
		{
			rect.bottom = nY1; rect.top = nY2;
		}
		else
		{
			rect.bottom = nY2; rect.top = nY1;
		}
		
		pDC->Rectangle(rect);
		pDC->SelectObject(pBrushOld);
		return;
	}
	
	int nPenSize, nOldPenSize, nCount;
	BOOL bSkip = FALSE;
	BOOL bDraw = FALSE;
	int nOldToolNo = -1;
	
	int nDrawEndX, nDrawEndY, nDrawStartX, nDrawStartY;
	nDrawStartX = (int)dDrawStartX;
	nDrawStartY = (int)dDrawStartY;
	nDrawEndX = (int)(dDrawStartX + dScale * rc.Width());
	nDrawEndY = (int)(dDrawStartY - dScale * rc.Height());

	int nX, nY;

	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor, OldColor = RGB(255, 255, 255);

	POSITION pos;
	LPFIREHOLE pHole;

	nCount = 0;
	nOldPenSize = 1;
	CString strHoleCount = _T("");
	int nCheckCount = 0;
	for(int i = ADDED_FID_TOOL+1; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			nHolecount++;
			if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
			{
//				nCount++;
				continue;
			}
		
			if(gVariable.m_bShowSelectFidBlockOnly && gVariable.m_nSelectFidBlock != -1)
			{
				if(gVariable.m_nSelectFidBlock != pHole->pOrigin->nFidBlock)
					continue;
			}
		
			if(!bDraw) 
				bDraw = TRUE;

			nCount = rand();

			if(nCount % nSkipNo && pHole->pOrigin->nBlockName2 == 0 && pHole->pOrigin->nLPCError != 1  && pHole->pOrigin->nLPCError != 2 && pHole->pOrigin->bCurrnetLPCError != 1)
			{
			//	continue;//TempTempTemp
			}


			if(nOldToolNo != pHole->pOrigin->nToolNo) // tool�� ���ϸ�
			{
				nCount = 0; // tool �� �ٲ� ��� ó�� ���� �׻� drawing
				nPenSize = (int)((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pHole->pOrigin->nToolNo;
			}

			if(pHole->pOrigin->nLPCError == 1 || pHole->pOrigin->nLPCError == 2)
			{
				nPenSize = (int)((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolSize/dScale *2); 
				nPenSize = max(nPenSize, 7);
			}
			else
			{
				nPenSize = (int)((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
			}


//			nCount++;
			if(pHole->pOrigin->nBlockName2 == 0)
			GetXY(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
//			nX = static_cast<int>((pHole->pOrigin->npPos.x - dDrawStartX) / dScale);
//			nY = static_cast<int>((dDrawStartY - (pHole->pOrigin->npPos.y)) / dScale);

//			if(pHole->pOrigin->bSelect)
			if(pHole->bSelect)
				pColor = RGB(0, 0, 0);
			else
				pColor = GetRGB((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolColor);
			
			if(nFidPane == 3)
			{
				if(pHole->pOrigin->nLPCError == 1)
				{
					pColor = RGB(0,0,255);
					gDProject.m_Glyphs.DisplayAreaEllipse(pDC, nX, nY, nPenSize, pColor);
				}
				else if(pHole->pOrigin->nLPCError ==2)
				{
					pColor = RGB(255,0,0);
					gDProject.m_Glyphs.DisplayAreaEllipse(pDC, nX, nY, nPenSize, pColor);
				}
				if(pHole->pOrigin->bCurrnetLPCError == 1)
				{	
					pColor = RGB(160,70,255);
					gDProject.m_Glyphs.DisplayAreaEllipse(pDC, nX, nY, nPenSize, pColor);
				}
			}

			if(pHole->pOrigin->nBlockName2 == 0)
			{
				nCount++;

				if(nCount % nSkipNo)
				{
					continue;
				}
			}


			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}

			if(pHole->pOrigin->nBlockName2 > 0)
			{

				if(!gVariable.m_bShowNoBlockOnly)
				{
					DisplayBlockDots(pDC, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,	pHole->pOrigin->nBlockName2, pColor, nMode, dDrawStartX, dDrawStartY, nDrawEndX, nDrawEndY, dScale, pBlocks,
						FALSE, pOldPen, &pen, nPenSize, nSkipNo);
				}



				GetXY(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
				CString strIndex;
				strIndex.GetBuffer(256);
				strIndex.Format(_T("%d") ,  pHole->pOrigin->nBlockName2);
				strIndex.ReleaseBuffer();

				if(gVariable.m_bShowBlockNo) 
				{
					pDC->SetTextColor(RGB(125, 125, 125));
					pDC->SetBkColor(0x101010);
					pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, strIndex, NULL);
				}


				nCheckCount++;



			}
			else
			{

				if(!gVariable.m_bShowBlockOnly)
				{
					pDC->MoveTo(nX, nY);
					pDC->LineTo(nX, nY);
				}

				if(bShowHoleIndex)
				{
					strHoleCount.Format(_T("%d"), nHolecount);
					pDC->SetTextColor(RGB(0, 0, 0));
					pDC->SetBkColor(0xffffff);
					pDC->TextOut(nX, nY, strHoleCount);
				}
			}




			int m_nHoleCount = m_FireHoles[i].GetCount();
			
			if((gVariable.m_bShowOCRContents || gVariable.m_bShowOCRDetail) && m_nHoleCount < 100)
			{
				SUBTOOLDATA subData;
				gDProject.GetSubTool(pHole->pOrigin->nToolNo, 0, subData);
				int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subData.nMask];


				if(gShotTableINI.m_sShotGroupTable.nToolType[nShotIndex] == TEXT_TYPE)
				{
					CString strContents;

					CDPoint ptMaster;
					CDPoint ptSlave;

					int nIndex = pHole->pOrigin->nHoleContentsIndex;

			
					//if(nIndex > 0 && nIndex <= OCR_FORMAT_SERIAL)
						strContents = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetMarkingContents_UseIndex( pHole,  pHole->pOrigin->nToolNo,  ptMaster,  ptSlave,  TRUE, FALSE, TRUE);
					//else 
						//strContents = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetMarkingContentsNew( pHole,  pHole->pOrigin->nToolNo,  ptMaster,  ptSlave,  TRUE, FALSE, TRUE);

				
					if(gVariable.m_bShowOCRContents)
					{
						//strHoleCount.Format(_T("Index %d :  %s"),pHole->pOrigin->nHoleContentsIndex, strContents);
						strHoleCount.Format(_T(" %s"), strContents);;
						pDC->SetTextColor(RGB(0, 0, 0));
						pDC->SetBkColor(0xffffff);
						pDC->TextOut(nX, nY, strHoleCount);
					}
					else if(gVariable.m_bShowOCRDetail )
					{
						int nAngle = subData.nRotate;

						if(pHole->pOrigin->bRotate)
						{
							nAngle += 90;
						}
						nAngle = nAngle % 360;
					
						int nRotateInfo = 0;//20200901
						if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pDataLoad->m_pProject != NULL)
							nRotateInfo = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pDataLoad->m_pProject->m_nRotateInfo;


						gTextDataTemp.GetTextData(strContents, /*gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->m_nMarkingSize,*/ gSystemINI.m_sSystemDevice.nTextFontSize,
							gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->m_nTextHolePitch, 
							TRUE, gSystemINI.m_sSystemDevice.nTextRefMode, (int)(gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0),
							subData.bFlipX, subData.bFlipY, 
							nAngle, gSystemINI.m_sSystemDevice.dTextGap, 
							nRotateInfo, gSystemINI.m_sSystemDevice.bUseInnerOCRFont); 
						


						int nTextHoleNo = gTextDataTemp.GetDataCount(TRUE);
						if(nTextHoleNo == 0)
						{
							//AfxMessageBox("Make Text Alarm");
						}

						for(int j = 0; j < nTextHoleNo; j++)	
						{
							int nBarX1, nBarY1, nBarX2, nBarY2;
							nBarX1 = nBarY1 = nBarX2 = nBarY2 = 0;

							CDPoint tempPos, tempPos2;

							if(!gTextDataTemp.GetNextPoint(TRUE, nBarX1, nBarY1, nBarX2, nBarY2))
							{
								//AfxMessageBox("Make Text Alarm");
								break;
							}


							double dBarX1, dBarY1, dBarX2, dBarY2;
							dBarX1 = dBarY1 = dBarX2 = dBarY2 = 0.;

							dBarX1 = nBarX1 * (gSystemINI.m_sSystemDevice.dFieldSize.x / 65535);
							dBarY1 = -nBarY1 * (gSystemINI.m_sSystemDevice.dFieldSize.x / 65535);
							dBarX2 = nBarX2 * (gSystemINI.m_sSystemDevice.dFieldSize.x / 65535);
							dBarY2 = -nBarY2 * (gSystemINI.m_sSystemDevice.dFieldSize.x / 65535);



							//TRACE("%.3f %.3f %.3f %.3f \n",dBarX1,dBarY1,dBarX2,dBarY2);


							double dOffset2 = 1000/dScale;

							tempPos.x = nX + (dBarX1  * dOffset2);
							tempPos.y = nY + (dBarY1 * dOffset2);
							tempPos2.x = nX + (dBarX2 * dOffset2);
							tempPos2.y = nY + (dBarY2 * dOffset2);



							//TRACE("%.3f %.3f %.3f %.3f \n",tempPos.x,tempPos.y,tempPos2.x,tempPos2.y);

							CPen barPen;
							CPen *pOldPen3;

							barPen.CreatePen(PS_SOLID, nPenSize/20, pColor);
							pOldPen3 = pDC->SelectObject(&barPen);

							pDC->Ellipse(tempPos.x-1, tempPos.y-1, tempPos.x+1, tempPos.y+1);

							pDC->SelectObject(pOldPen3);
							barPen.DeleteObject();
						}
					}
					


				}


			}

			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX, nY);


		}



		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}

	double dAngle, cosTheta, sinTheta;
	CPoint ptEndBlockP;
	POINT ptr[3];
	int nTempX, nTempY, nArrowSize = (int)(50 / dScale);
	BOOL bOldDataDraw = FALSE, bNowDataDraw;
	if(bDrawPath)
	{
		BOOL bStartHole = TRUE;
		pColor = RGB(255, 0, 0);
		pen.CreatePen(PS_SOLID, 3, pColor);
		pOldPen = pDC->SelectObject(&pen);
		for(int i = ADDED_FID_TOOL+1; i < MAX_TOOL_NO; i++)
		{
			pos = m_FireHoles[i].GetHeadPosition();
			while (pos) 
			{
				pHole = m_FireHoles[i].GetNext(pos);
				
				if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					continue;
				}

				bNowDataDraw = IsDrawData(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nDrawStartX, nDrawStartY, nDrawEndX, nDrawEndY, pHole->pOrigin->nBlockName2);
				GetXY(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);

				if(bStartHole)
				{
					pDC->MoveTo(nX + 10, nY + 10);
					pDC->LineTo(nX - 10, nY - 10);
					pDC->MoveTo(nX + 10, nY - 10);
					pDC->LineTo(nX - 10, nY + 10);
					pDC->MoveTo(nX, nY);
					bStartHole = FALSE;

					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
					pColor = RGB(0, 0, 200);
					pen.CreatePen(PS_DOT, 4, pColor);
					pOldPen = pDC->SelectObject(&pen);

					nTempX = nX; 
					nTempY = nY;
				}
				if(!bNowDataDraw && !bOldDataDraw)
				{
					if(bStartHole)
						bStartHole = FALSE;
					nTempX = nX; 
					nTempY = nY;
					pDC->MoveTo(nX, nY);
					bOldDataDraw = bNowDataDraw; continue;
				}
				bOldDataDraw = bNowDataDraw;

				// Draw path in block
				if(pHole->pOrigin->nBlockName2 != 0)
				{
					ptEndBlockP = DisplayPathInBlock(pDC, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,	pHole->pOrigin->nBlockName2, pColor, 
						nMode, dDrawStartX, dDrawStartY, nDrawEndX, nDrawEndY, dScale, pBlocks);
					nTempX = ptEndBlockP.x; 
					nTempY = ptEndBlockP.y;
				}
				else
				{
					//					if(m_nPathAnimateDelay)
					//						::Sleep(m_nPathAnimateDelay);
					if(!bStartHole)
					{
						dAngle = atan2((double)(nY - nTempY), (double)(nX - nTempX) );
						ptr[0].x = nX;
						ptr[0].y = nY;
						cosTheta = cos(dAngle);
						sinTheta = sin(dAngle);
						ptr[1].x = (long)( nX + ( cosTheta* -nArrowSize - sinTheta* nArrowSize) );
						ptr[1].y = (long)( nY + ( sinTheta* -nArrowSize + cosTheta* nArrowSize) );

						ptr[2].x = (long)( nX + ( cosTheta* -nArrowSize - sinTheta* -nArrowSize) );
						ptr[2].y = (long)( nY + ( sinTheta* -nArrowSize + cosTheta* -nArrowSize) );

						pDC->LineTo(nX, nY);
						pDC->Polygon(ptr,3);

						nTempX = nX; 
						nTempY = nY;
					} 
				}
				if(bStartHole)
					bStartHole = FALSE;
			}
		}
		pDC->SelectObject(pOldPen);
		pen.DeleteObject();
		pOldPen = NULL;
	}

	// draw line
	LPFIRELINE pLine;
	double dLength, dDivideX, dDivideY;
	int nDivideCount;
	int nShotPosX, nShotPosY;

	if(bDrawPath && gProcessINI.m_sProcessSystem.bLineToShotFireMode)
	{
		for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
		{
			pos = m_FireLines[i].GetHeadPosition();
			while (pos) 
			{
				pLine = m_FireLines[i].GetNext(pos);

				if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					continue;
				}

				if(gDProject.m_nTotalLine > 10000)
				{
					nCount = rand();
					if(dScale < 200)
						nSkipNo = 1;
					else
						nSkipNo = 10;
	 				if(nCount % nSkipNo)
	 				{
	 					//				nCount++;
	 					continue;
	 				}
				}

				if(!bDraw) 
					bDraw = TRUE;

				dLength = sqrt((double)(pLine->npEndPos.x - pLine->npStartPos.x) * (pLine->npEndPos.x - pLine->npStartPos.x) +
									(double)(pLine->npEndPos.y - pLine->npStartPos.y) * (pLine->npEndPos.y - pLine->npStartPos.y));
				if((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolSize  <= 0)
					continue;

				nDivideCount = (int)(0.5 + dLength / (*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolSize) ;
				if(!gProcessINI.m_sProcessSystem.bLineToShotSameLength)
				{
					dDivideX =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npEndPos.x - pLine->npStartPos.x) / dLength; // ������ ũ�Ⱑ �ٸ� �� �ִ�.
					dDivideY =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npEndPos.y - pLine->npStartPos.y) / dLength;
				}
				else
				{
					dDivideX =  (double)(pLine->npEndPos.x - pLine->npStartPos.x) / nDivideCount; // ��ʹ��
					dDivideY =  (double)(pLine->npEndPos.y - pLine->npStartPos.y) / nDivideCount;
				}

				for(int nDivNo = 0; nDivNo <= nDivideCount; nDivNo++)
				{
					if(nDivNo == nDivideCount)
					{
						nShotPosX =  pLine->npEndPos.x;
						nShotPosY =  pLine->npEndPos.y;
					}
					else
					{
						nShotPosX = (int)(pLine->npStartPos.x + dDivideX*nDivNo);
						nShotPosY = (int)(pLine->npStartPos.y + dDivideY*nDivNo);
					}
//					nIndexX = nMasterLSBX >> 4;
//					nIndexY = nMasterLSBY >> 4;
//					if(m_pcField[nIndexX * 4096 + nIndexY] == 0)
					{
						GetXY(nMode, nShotPosX, nShotPosY, nX, nY, dDrawStartX, dDrawStartY, dScale);
						if(nOldToolNo != pLine->pOrigin->nToolNo) // tool�� ���ϸ�
						{
							nPenSize = (int)((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
							nPenSize = max(nPenSize, 3);
							nOldToolNo = pLine->pOrigin->nToolNo;
						}
						if(pLine->bSelect)
							pColor = RGB(0, 0, 0);
						else
							pColor = GetRGB((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolColor);

						if (OldColor != pColor || nOldPenSize != nPenSize)
						{
							if (pOldPen != NULL)
							{
								pDC->SelectObject(pOldPen);
								pen.DeleteObject();
								pOldPen = NULL;
							}
							pen.CreatePen(PS_SOLID, nPenSize, pColor);
							pOldPen = pDC->SelectObject(&pen);
							nOldPenSize = nPenSize;
							OldColor = pColor;
						}
						pDC->MoveTo(nX, nY);
						pDC->LineTo(nX, nY);

//						m_pcField[nIndexX * 4096 + nIndexY] = 1;
					}
				}
			}
			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
				pOldPen = NULL;
			}
		}
	}
	else
	{
		for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
		{
			pos = m_FireLines[i].GetHeadPosition();
			while (pos) 
			{
				pLine = m_FireLines[i].GetNext(pos);

				if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					continue;
				}
				if(gDProject.m_nTotalLine > 10000)
				{
					nCount = rand();
					if(dScale < 200)
						nSkipNo = 1;
					else
						nSkipNo = 10;
	 				if(nCount % nSkipNo)
	 				{
	 					//				nCount++;
	 					continue;
	 				}
				}
				if(!bDraw) 
					bDraw = TRUE;
			
 				GetXY(nMode, pLine->npStartPos.x, pLine->npStartPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//			nX = static_cast<int>((pLine->npStartPos.x - dDrawStartX) / dScale);
	//			nY = static_cast<int>((dDrawStartY - (pLine->npStartPos.y)) / dScale);
			
				if(nOldToolNo != pLine->pOrigin->nToolNo) // tool�� ���ϸ�
				{
					nPenSize = (int)((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
					nPenSize = max(nPenSize, 3);
					nOldToolNo = pLine->pOrigin->nToolNo;
				}
			
	//			if(pLine->pOrigin->bSelect)
				if(pLine->bSelect)
					pColor = RGB(0, 0, 0);
				else
					pColor = GetRGB((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolColor);

				if (OldColor != pColor || nOldPenSize != nPenSize)
				{
					if (pOldPen != NULL)
					{
						pDC->SelectObject(pOldPen);
						pen.DeleteObject();
						pOldPen = NULL;
					}
					pen.CreatePen(PS_SOLID, nPenSize, pColor);
					pOldPen = pDC->SelectObject(&pen);
					nOldPenSize = nPenSize;
					OldColor = pColor;
				}
			
				pDC->MoveTo(nX, nY);
				GetXY(nMode, pLine->npEndPos.x, pLine->npEndPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//			nX = static_cast<int>((pLine->npEndPos.x - dDrawStartX) / dScale);
	//			nY = static_cast<int>((dDrawStartY - (pLine->npEndPos.y)) / dScale);
				pDC->LineTo(nX, nY);
			}
			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
				pOldPen = NULL;
			}
		}
	}

	if(bDraw) 
	{
		if(m_nFidBlock == -1)
			pColor = RGB(128, 128, 128);
		else
			pColor = m_cColorFid[m_nFidBlock];
		pen.CreatePen(PS_SOLID, 1, pColor);
		pOldPen = pDC->SelectObject(&pen);

		GetXY(nMode, m_nMinX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->MoveTo(nX, nY);
		m_nFieldMinX = nX - 7;
		m_nFieldMinY = nY - 7;

		GetXY(nMode, m_nMaxX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->LineTo(nX, nY);

		GetXY(nMode, m_nMaxX, m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMaxY)) / dScale);
		pDC->LineTo(nX, nY);
		m_nFieldMaxX = nX - 7;
		m_nFieldMaxY = nY - 7;
		
		GetXY(nMode, m_nMinX, m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMaxY)) / dScale);
		pDC->LineTo(nX, nY);

		GetXY(nMode, m_nMinX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->LineTo(nX, nY);
		
		if(bShowIndex)
		{
			CString strIndex;
			if(m_nSortIndex < 10)
				strIndex.Format(_T("  %d"), m_nSortIndex);
			else
				strIndex.Format(_T("%d"), m_nSortIndex);
			
			pDC->SetTextColor(RGB(255, 255, 255));
			
			if(m_bCheckIndex)
				pDC->SetBkColor(0x00ffff);
			else
				pDC->SetBkColor(0x578B2E);

			pDC->ExtTextOut( (int)((m_nFieldMinX + m_nFieldMaxX)/2.0), (int)((m_nFieldMinY + m_nFieldMaxY)/2.0), ETO_CLIPPED, NULL, strIndex, NULL);
		}

		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}
}






void DAreaInfo::DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList **pToolCodes, int nSkipNo, int nMode, BOOL bDrawPath, BOOL bShowIndex, BOOL bShowHoleIndex, int &nHolecount, BlockList* pBlocks)
{

	if(gVariable.m_bShowSelectAreaOnly && gVariable.m_nSelectArea != -1)
	{
		if(gVariable.m_nSelectArea != m_nSortIndex)
			return;
	}

	if(m_nFireStatus == DONE_FIRE || m_nFireStatus == DOING_FIRE)
	{
		CBrush cBr2;
		CBrush *pBrushOld;
		if(m_nFireStatus == DONE_FIRE)
			cBr2.CreateSolidBrush(RGB(0, 0, 200));
		else
			cBr2.CreateSolidBrush(RGB(255, 0, 0));

		pBrushOld = pDC->SelectObject(&cBr2);
		
		int nX1, nX2, nY1, nY2;
		GetXY(nMode, m_nMinX, m_nMinY, nX1, nY1, dDrawStartX, dDrawStartY, dScale);
		GetXY(nMode, m_nMaxX, m_nMaxY, nX2, nY2, dDrawStartX, dDrawStartY, dScale);
		CRect rect;
		if(nX1 > nX2)
		{
			rect.left = nX2; rect.right = nX1;
		}
		else
		{
			rect.left = nX1; rect.right = nX2;
		}
		
		if(nY1 > nY2)
		{
			rect.bottom = nY1; rect.top = nY2;
		}
		else
		{
			rect.bottom = nY2; rect.top = nY1;
		}
		
		pDC->Rectangle(rect);
		pDC->SelectObject(pBrushOld);
		return;
	}

	int nDrawEndX, nDrawEndY, nDrawStartX, nDrawStartY;
	nDrawStartX = (int)dDrawStartX;
	nDrawStartY = (int)dDrawStartY;
	nDrawEndX = (int)(dDrawStartX + dScale * rc.Width());
	nDrawEndY = (int)(dDrawStartY - dScale * rc.Height());
	
	int nPenSize, nOldPenSize, nCount;
	BOOL bSkip = FALSE;
	BOOL bDraw = FALSE;
	int nOldToolNo = -1;
	
	int nX, nY;

	nCount = 0;
	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor, OldColor = RGB(255, 255, 255);

	POSITION pos;
	LPFIREHOLE pHole;
	CString strHoleCount;
	nOldPenSize = 1;
	
	int nSelectedHole = gDProject.m_nSelectFireHole;


	for(int i = ADDED_FID_TOOL+1; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
	//	int nSelectedHole = GetSelectedHoleCount(i);
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			
			nHolecount++;

//			if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible || pHole->pOrigin->bSelect == FALSE) // visible �ƴϸ�
			if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible || pHole->bSelect == FALSE) // visible �ƴϸ�
			{
				continue;
			}
		
			if(gVariable.m_bShowSelectFidBlockOnly && gVariable.m_nSelectFidBlock != -1)
			{
				if(gVariable.m_nSelectFidBlock != pHole->pOrigin->nFidBlock)
					continue;
			}
		
			if(!bDraw) 
				bDraw = TRUE;
#ifndef __TEST__
			if(nSelectedHole > 50000)
			{
				nCount = rand();
				if(nCount % nSkipNo)
				{
					//				nCount++;
					continue;
				}
			}
#endif
			if(nOldToolNo != pHole->pOrigin->nToolNo) // tool�� ���ϸ�
			{
				nPenSize = (int)((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pHole->pOrigin->nToolNo;
			}

			GetXY(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
//			nX = static_cast<int>((pHole->pOrigin->npPos.x - dDrawStartX) / dScale);
//			nY = static_cast<int>((dDrawStartY - (pHole->pOrigin->npPos.y)) / dScale);

//			if(pHole->pOrigin->bSelect)
			if(pHole->bSelect)
				pColor = RGB(0, 0, 0);
			else
				pColor = GetRGB((*(pToolCodes + pHole->pOrigin->nToolNo))->m_nToolColor);
			
			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}

			if(pHole->pOrigin->nBlockName2 > 0)
			{
			
				if(!gVariable.m_bShowNoBlockOnly)
				{
				    DisplayBlockDots(pDC, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,	pHole->pOrigin->nBlockName2, pColor, nMode, dDrawStartX, dDrawStartY, nDrawEndX, nDrawEndY, dScale, pBlocks,
				    FALSE, pOldPen, &pen, nPenSize, nSkipNo);
				}
			
			}
			else
			{
			
				if(!gVariable.m_bShowBlockOnly)
				{
					pDC->MoveTo(nX, nY);
					pDC->LineTo(nX, nY);
				}
				

			if(bShowHoleIndex)
			{
				strHoleCount.Format(_T("%d"), nHolecount);
				pDC->SetTextColor(RGB(0, 0, 0));
				pDC->SetBkColor(0xffffff);
				pDC->TextOut(nX, nY, strHoleCount);
			}
			}
		
		}

		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}

	if(bDrawPath)
	{
		BOOL bStartHole = TRUE;
		pColor = RGB(255, 0, 0);
		pen.CreatePen(PS_SOLID, 3, pColor);
		pOldPen = pDC->SelectObject(&pen);
		for(int i = ADDED_FID_TOOL+1; i < MAX_TOOL_NO; i++)
		{
			pos = m_FireHoles[i].GetHeadPosition();
			while (pos) 
			{
				pHole = m_FireHoles[i].GetNext(pos);
				
//				if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible || pHole->pOrigin->bSelect == FALSE) // visible �ƴϸ�
				if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible || pHole->bSelect == FALSE) // visible �ƴϸ�
				{
					continue;
				}
				
				GetXY(nMode, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
				
				if(bStartHole)
				{
					pDC->MoveTo(nX + 10, nY + 10);
					pDC->LineTo(nX - 10, nY - 10);
					pDC->MoveTo(nX + 10, nY - 10);
					pDC->LineTo(nX - 10, nY + 10);
					pDC->MoveTo(nX, nY);
					bStartHole = FALSE;
					
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
					pColor = RGB(200, 200, 200);
					pen.CreatePen(PS_DOT, 1, pColor);
					pOldPen = pDC->SelectObject(&pen);
					
				}
				else
					pDC->LineTo(nX, nY);
				
			}
		}
		pDC->SelectObject(pOldPen);
		pen.DeleteObject();
		pOldPen = NULL;
	}

	// draw line
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);

//			if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible || pLine->pOrigin->bSelect == FALSE) // visible �ƴϸ�
			if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible || pLine->bSelect == FALSE) // visible �ƴϸ�
			{
				continue;
			}

				if(gDProject.m_nTotalLine > 10000)
				{
					nCount = rand();
					if(dScale < 200)
						nSkipNo = 1;
					else
						nSkipNo = 10;
	 				if(nCount % nSkipNo)
	 				{
	 					//				nCount++;
	 					continue;
	 				}
				}

			if(!bDraw) 
				bDraw = TRUE;
			
			GetXY(nMode, pLine->npStartPos.x, pLine->npStartPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
//			nX = static_cast<int>((pLine->npStartPos.x - dDrawStartX) / dScale);
//			nY = static_cast<int>((dDrawStartY - (pLine->npStartPos.y)) / dScale);
			
			if(nOldToolNo != pLine->pOrigin->nToolNo) // tool�� ���ϸ�
			{
				nPenSize = (int)((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolSize/dScale); //(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pLine->pOrigin->nToolNo;
			}
			
//			if(pLine->pOrigin->bSelect)
			if(pLine->bSelect)
				pColor = RGB(0, 0, 0);
			else
				pColor = GetRGB((*(pToolCodes + pLine->pOrigin->nToolNo))->m_nToolColor);

			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}
			
			pDC->MoveTo(nX, nY);
			GetXY(nMode, pLine->npEndPos.x, pLine->npEndPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
//			nX = static_cast<int>((pLine->npEndPos.x - dDrawStartX) / dScale);
//			nY = static_cast<int>((dDrawStartY - (pLine->npEndPos.y)) / dScale);
			pDC->LineTo(nX, nY);
		}
		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}

	if(bDraw) 
	{
		pColor = RGB(128, 128, 128);
		pen.CreatePen(PS_SOLID, 1, pColor);
		pOldPen = pDC->SelectObject(&pen);

		GetXY(nMode, m_nMinX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->MoveTo(nX, nY);
		m_nFieldMinX = nX - 7;
		m_nFieldMinY = nY - 7;

		GetXY(nMode, m_nMaxX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->LineTo(nX, nY);

		GetXY(nMode, m_nMaxX, m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMaxY)) / dScale);
		pDC->LineTo(nX, nY);
		m_nFieldMaxX = nX - 7;
		m_nFieldMaxY = nY - 7;
		
		GetXY(nMode, m_nMinX, m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMaxY)) / dScale);
		pDC->LineTo(nX, nY);

		GetXY(nMode, m_nMinX, m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_nMinY)) / dScale);
		pDC->LineTo(nX, nY);

		if(bShowIndex)
		{
			CString strIndex;
			if(m_nSortIndex < 10)
				strIndex.Format(_T("  %d"), m_nSortIndex);
			else
				strIndex.Format(_T("%d"), m_nSortIndex);

			pDC->SetTextColor(RGB(255, 255, 255));
			
			if(m_bCheckIndex)
				pDC->SetBkColor(0x00ffff);
			else
				pDC->SetBkColor(0x578B2E);

			pDC->ExtTextOut( (int)((m_nFieldMinX + m_nFieldMaxX)/2.0), (int)((m_nFieldMinY + m_nFieldMaxY)/2.0), ETO_CLIPPED, NULL, strIndex, NULL);
		}

		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}
}

BOOL DAreaInfo::IsEmpty()
{
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{	
		if(m_FireHoles[i].GetCount() != 0 || m_FireLines[i].GetCount() != 0)
			return FALSE;
	}
	return TRUE;
}

BOOL DAreaInfo::IsThereSelectData()
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
//			if(pHole->pOrigin->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
			if(pHole->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
				return TRUE;
		}
	}

	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
//			if(pLine->pOrigin->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
			if(pLine->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
				return TRUE;
		}
	}
	return FALSE;
}

BOOL DAreaInfo::IsThereData()
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			if(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
				return TRUE;
		}
	}
	
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			if(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
				return TRUE;
		}
	}
	return FALSE;
}

int DAreaInfo::GetFirstToolNo(BOOL bSelectOnly, BOOL bAuto) // autorun�� �ƴҶ� 
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
//					if(pHole->pOrigin->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
					if(pHole->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
						return pHole->pOrigin->nToolNo;
				}
				else
				{
					if(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
						return pHole->pOrigin->nToolNo;
				}

			}
			else
				return pHole->pOrigin->nToolNo;
		}
	}
	
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
//					if(pLine->pOrigin->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
					if(pLine->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
						return pLine->pOrigin->nToolNo;
				}
				else
				{
					if(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
						return pLine->pOrigin->nToolNo;
				}
			}
			else
				return pLine->pOrigin->nToolNo;
		}
	}
	return -1;
}

BOOL DAreaInfo::IsThereSkivingData(int nIndex, BOOL bSelectMode)
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	pos = m_FireHoles[ADDED_FID_TOOL].GetHeadPosition();
	while (pos) 
	{
		pHole = m_FireHoles[ADDED_FID_TOOL].GetNext(pos);
		if((int)(pHole->pOrigin) == nIndex)
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DAreaInfo::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("AreaInfo\n");
			ar << _T("CenterX = ") << m_dCenterX << _T("\n");
			ar << _T("CenterY = ") << m_dCenterY << _T("\n");
			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");
			ar << _T("Sort = ") << m_nSortIndex << _T("\n");

			POSITION pos;
			LPFIREHOLE pHole;
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar << _T("Tool = ") << i << _T("\n");
				ar << _T("HoleCount = ") << m_FireHoles[i].GetCount() << _T("\n");
				pos = m_FireHoles[i].GetHeadPosition();
				while (pos) 
				{
					pHole = m_FireHoles[i].GetNext(pos);
					ar << _T("= ") << (int)(pHole->pOrigin) << _T("\n");
					if(i != 0)
					{
						ar << _T("= ") << pHole->pOrigin->nToolNo << _T("\n");
						ar << _T("= ") << pHole->pOrigin->npPos.x << _T("\n");
						ar << _T("= ") << pHole->pOrigin->npPos.y << _T("\n");
						ar << _T("= ") << pHole->pOrigin->nUnitIndex << _T("\n");
						ar << _T("= ") << pHole->pOrigin->bRotate << _T("\n");


						if(nVersion >= 10037)
						{
						   ar << _T("= ") << pHole->pOrigin->nHoleContentsIndex << _T("\n");

						   str.Format(_T("%s"), pHole->pOrigin->m_szHoleContents);
						   ar << str << _T("\n");
						}
						
						if(nVersion > 10007)
						{
							for(int m=0; m<4; m++)
							{
								for(int n=0; n<2; n++)
								{
									ar << _T("= ") << pHole->pOrigin->nFidIndex[m][n] << _T("\n");
								}
							}
						}
						if(nVersion > 10012)
							ar << _T("= ") << pHole->pOrigin->nFidBlock << _T("\n");
						if(nVersion >= 10028) //2015.12.10
							ar << _T("= ") << pHole->pOrigin->nArrayNo << _T("\n");
						ar << _T("= ") << pHole->pOrigin->nBlockName2 << "\n";
					}
				}
			}

			LPFIRELINE pLine;
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar << _T("Tool = ") << i << _T("\n");
				ar << _T("LineCount = ") << m_FireLines[i].GetCount() << _T("\n");
				pos = m_FireLines[i].GetHeadPosition();
				while (pos) 
				{
					pLine = m_FireLines[i].GetNext(pos);
					ar << _T("= ") << (int)(pLine->pOrigin) << _T("\n");
					ar << _T("= ") << pLine->pOrigin->nToolNo << _T("\n");
					ar << _T("= ") << pLine->pOrigin->npStartPos.x << _T("\n");
					ar << _T("= ") << pLine->pOrigin->npStartPos.y << _T("\n");
					ar << _T("= ") << pLine->pOrigin->npEndPos.x << _T("\n");
					ar << _T("= ") << pLine->pOrigin->npEndPos.y << _T("\n");
					ar << _T("= ") << pLine->pOrigin->nUnitIndex << _T("\n");
					ar << _T("= ") << pLine->npStartPos.x << _T("\n");
					ar << _T("= ") << pLine->npStartPos.y << _T("\n");
					ar << _T("= ") << pLine->npEndPos.x << _T("\n");
					ar << _T("= ") << pLine->npEndPos.y << _T("\n");
					
					if(nVersion > 10007)
					{
						for(int m=0; m<4; m++)
						{
							for(int n=0; n<2; n++)
							{
								ar << _T("= ") << pLine->pOrigin->nFidIndex[m][n] << _T("\n");
							}
						}
					}
					if(nVersion > 10012)
							ar << _T("= ") << pLine->pOrigin->nFidBlock << _T("\n");
					
				}
			}

			if(nVersion > 10000)
			{
				ar << _T("OffsetX = ") << m_dTableOffsetX << _T("\n");
				ar << _T("OffsetY = ") << m_dTableOffsetY << _T("\n");
				
				LPFID_INDEX pFid;
				ar << _T("FidCount = ") << m_FidIndex.GetCount() << _T("\n");
				pos = m_FidIndex.GetHeadPosition();
				while (pos)
				{
					pFid = m_FidIndex.GetNext(pos);
					ar << _T("= ") << pFid->nIndex << _T("\n");
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DAreaInfo::LoadFile10000(CArchiveMark &ar, int nVersion, GlyphExcellon* pExcellon)
{
	CString str;
	int nTool, nIndex;
	int nOrigin;
	int nCount;
	int nNotUseData;
	MemoryInfo tempMInfo;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> str;
			ar >> m_dCenterX;
			ar >> m_dCenterY;
			ar >> m_nMinX;
			ar >> m_nMinY;
			ar >> m_nMaxX;
			ar >> m_nMaxY;
			ar >> m_nSortIndex;

			HOLECONVERTDATA dHole;
			HOLEDATA OriHole;
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar >> nTool;
				ar >> nCount;
				for(int j = 0; j < nCount; j++)
				{
				//	dHole = new HOLECONVERTDATA;
					ar >> nOrigin;
					if(nTool != 0)
					{
		
						ar >> OriHole.nToolNo;
						ar >> OriHole.npPos.x;
						ar >> OriHole.npPos.y;
#ifdef __PUSAN_LDD__
						if(nVersion <= 10017)
#else
						if(nVersion < 10002)
#endif
						{
							OriHole.nUnitIndex = 0;
						}
						else
						{
							ar >> OriHole.nUnitIndex;
						}

						if(nVersion >= 10015)
							ar >> OriHole.bRotate;
						else
							OriHole.bRotate = 0;

						if(nVersion >= 10037)
						{
							ar >> OriHole.nHoleContentsIndex;

							ar >> str;
							strcpy_s(OriHole.m_szHoleContents, str);
						}
						else
						{
							OriHole.nHoleContentsIndex = 0;
							strcpy_s(OriHole.m_szHoleContents, _T(""));
						}


						if(nVersion > 10007)
						{
							for(int m=0; m<4; m++)
							{
								for(int n=0; n<2; n++)
								{
									ar >> OriHole.nFidIndex[m][n];
								}
							}
						}
						if(nVersion > 10012)
							ar >> OriHole.nFidBlock;
						else
							OriHole.nFidBlock = 0;

						if(nVersion >= 10031) //2015.12.10
							ar >> OriHole.nArrayNo;
						else
							OriHole.nArrayNo = 1;
                         
						 ar >> OriHole.nBlockName2;
					}
//					pOriHole.bSelect = FALSE;
					dHole.bSelect = FALSE;
					if(nTool != 0)
					{
						OriHole.nRefNo = 1;
						
						dHole.pOrigin = pExcellon->AddHoleData(OriHole, OriHole.nUnitIndex);
					}
					else
						dHole.pOrigin = (HOLEDATA*)nOrigin;
					m_FireHoles[nTool].AddTail(dHole);
				}
			}

			LPFIRELINE pLine;
			LPLINEDATA pOriLine; 
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar >> nTool;
				ar >> nCount;
				for(int j = 0; j < nCount; j++)
				{
					pLine = new LINE_CONVERT_DATA;
					ar >> nOrigin;
					if(IsNewData(nOrigin, pExcellon, nIndex))
					{
						pOriLine = new LINEDATA;
						ar >> pOriLine->nToolNo;
						ar >> pOriLine->npStartPos.x;
						ar >> pOriLine->npStartPos.y;
						ar >> pOriLine->npEndPos.x;
						ar >> pOriLine->npEndPos.y;
						if(nVersion < 10002)
						{
							pOriLine->nUnitIndex = 0;
						}
						else
						{
							ar >> pOriLine->nUnitIndex;
						}
//						pOriLine->bSelect = FALSE;
						pOriLine->nRefNo = 1;
						pExcellon->AddLineData(pOriLine, pOriLine->nUnitIndex);
						pLine->pOrigin = pOriLine;
						tempMInfo.nOrigin = nOrigin;
						tempMInfo.pData = pOriLine;
						pExcellon->m_FileMemoryInfo.InsertAt(nIndex, tempMInfo);
					}
					else
					{
						tempMInfo = pExcellon->m_FileMemoryInfo.GetAt(nIndex);
						if(tempMInfo.nOrigin != nOrigin)
						{
							CString strString, strMsg;
							strString.LoadString(IDS_ERR_FILE_FORMAT);
							strMsg.Format(strString, "Line Divide data");
							ErrMessage(strMsg);
							delete pLine;
							return FALSE;
						}
						pLine->pOrigin = tempMInfo.pData;
						ar >> nNotUseData;
						ar >> nNotUseData;
						ar >> nNotUseData;
						ar >> nNotUseData;
						ar >> nNotUseData;
						if(nVersion < 10002)
						{
							pLine->pOrigin->nUnitIndex = 0;
						}
						else
						{
							ar >> nNotUseData;
						}
					}
					ar >> pLine->npStartPos.x;
					ar >> pLine->npStartPos.y;
					ar >> pLine->npEndPos.x;
					ar >> pLine->npEndPos.y;
					pLine->bSelect = FALSE;

					if(nVersion > 10007)
					{
						for(int m=0; m<4; m++)
						{
							for(int n=0; n<2; n++)
							{
								ar >> pLine->pOrigin->nFidIndex[m][n];
							}
						}
					}
					if(nVersion > 10012)
						ar >> pLine->pOrigin->nFidBlock;
					else
						pLine->pOrigin->nFidBlock = 0;

					m_FireLines[nTool].AddTail(pLine);
				}
			}
#ifndef __PUSAN_LDD__
			if(nVersion > 10000)
#else
			if(nVersion >= 10018)
#endif
			{
				ar >> m_dTableOffsetX;
				ar >> m_dTableOffsetY;
				
				LPFID_INDEX pFid;
				ar >> nCount;
				for(int i = 0; i<nCount; i++)
				{
					pFid = new FIDUCIAL_INDEX;
					ar >> pFid->nIndex;
					m_FidIndex.AddTail(pFid);
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

void DAreaInfo::ClearData()
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			pHole->RemoveAllBlockData();
			pHole->m_pblockPosList = NULL;
			//delete pHole;
		}
		m_FireHoles[i].RemoveAll();
	}
	
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			delete pLine;
		}
		m_FireLines[i].RemoveAll();
	}

	LPFID_INDEX pFid;
	
	pos = m_FidIndex.GetHeadPosition();
	while (pos) 
	{
		pFid = m_FidIndex.GetNext(pos);
		delete pFid;
	}
	
	m_FidIndex.RemoveAll();
}

void DAreaInfo::ClearBlockData()
{

	//TRACE("DAreaInfo::ClearBlockData Index %d \n",m_nSortIndex);
return;
	POSITION pos;
	LPFIREHOLE pHole;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			pHole->RemoveAllBlockData();
			pHole->m_pblockPosList = NULL;
		}

	}
}

BOOL DAreaInfo::IsNewData(int nOrigin, GlyphExcellon *pExcellon, int& nIndex)
{
	MemoryInfo tempMInfo;
	int nSize = pExcellon->m_FileMemoryInfo.GetSize();
	int nStart, nEnd, nHalf;
	if(nSize == 0)
	{
		nIndex = 0;
		return TRUE;
	}
	nStart = 0;
	nEnd = nSize -1;

	while (TRUE)
	{
		nHalf = (nEnd + nStart) / 2;
		tempMInfo = pExcellon->m_FileMemoryInfo.GetAt(nHalf);
		if(tempMInfo.nOrigin == nOrigin)
		{
			nIndex = nHalf;
			return FALSE;
		}
		else if(nOrigin < tempMInfo.nOrigin)
		{
			if(nStart == nEnd)
			{
				nIndex = nStart;
				return TRUE; 
			}
			nEnd = nHalf;
		}
		else
		{
			if(nStart == nEnd)
			{
				nIndex = nEnd + 1;
				return TRUE; 
			}
			if(nStart + 1 == nEnd)
			{
				tempMInfo = pExcellon->m_FileMemoryInfo.GetAt(nEnd);
				if(nOrigin == tempMInfo.nOrigin)
				{
					nIndex = nEnd;
					return FALSE;
				}
				else if(nOrigin < tempMInfo.nOrigin)
				{
					nIndex = nEnd;
					return TRUE;
				}
				else
				{
					nIndex = nEnd + 1;
					return TRUE; 
				}
			}
			nStart = nHalf;
		}
	}

	return TRUE;
}


void DAreaInfo::GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY, double dStartX, double dStartY, double dScale)
{
	if(nMode == X_Y)
	{
		nTransX = static_cast<int>((nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nY)) / dScale);
	}
	else if(nMode == MX_Y)
	{
		nTransX = static_cast<int>((-nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nY)) / dScale);
	}
	else if(nMode == X_MY)
	{
		nTransX = static_cast<int>((nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nY)) / dScale);
	}
	else if(nMode == MX_MY)
	{
		nTransX = static_cast<int>((-nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nY)) / dScale);
	}
	else if(nMode == Y_X)
	{
		nTransX = static_cast<int>((nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nX)) / dScale);
	}
	else if(nMode == MY_X)
	{
		nTransX = static_cast<int>((-nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nX)) / dScale);
	}
	else if(nMode == Y_MX)
	{
		nTransX = static_cast<int>((nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nX)) / dScale);
	}
	else
	{
		nTransX = static_cast<int>((-nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nX)) / dScale);
	}
}

void DAreaInfo::ChangeDataWithAxis(int nMode)
{
	int nX1, nX2, nY1, nY2;
	GetXY(nMode, m_nMinX, m_nMinY, nX1, nY1);
	GetXY(nMode, m_nMaxX, m_nMaxY, nX2, nY2);
	if(nX1 > nX2)
	{
		m_nMinX = nX2; m_nMaxX = nX1;
	}
	else
	{
		m_nMinX = nX1; m_nMaxX = nX2;
	}
	if(nY1 > nY2)
	{
		m_nMinY = nY2; m_nMaxY = nY1;
	}
	else
	{
		m_nMinY = nY1; m_nMaxY = nY2;
	}

	double dX1,dY1;
	GetXY_Use_vm(nMode, m_dCenterX, m_dCenterY, dX1, dY1);
	m_dCenterX = dX1;
	m_dCenterY = dY1;
	
	POSITION pos;
	LPFIRELINE pLine;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			GetXY(nMode, pLine->npStartPos.x, pLine->npStartPos.y, nX1, nY1);
			pLine->npStartPos.x = nX1;
			pLine->npStartPos.y = nY1;
			GetXY(nMode, pLine->npEndPos.x, pLine->npEndPos.y, nX1, nY1);
			pLine->npEndPos.x = nX1;
			pLine->npEndPos.y = nY1;
		}
	}
}

void DAreaInfo::GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY)
{
	if(nMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(nMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(nMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(nMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(nMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(nMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(nMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}
}

void DAreaInfo::GetXY_Use_vm(int nMode, double dX, double dY, double &dTransX, double &dTransY)
{
	if(nMode == X_Y)
	{
		dTransX = dX;
		dTransY = dY;
	}
	else if(nMode == MX_Y)
	{
		dTransX = -dX;
		dTransY = dY;
	}
	else if(nMode == X_MY)
	{
		dTransX = dX;
		dTransY = -dY;
	}
	else if(nMode == MX_MY)
	{
		dTransX = -dX;
		dTransY = -dY;
	}
	else if(nMode == Y_X)
	{
		dTransX = dY;
		dTransY = dX;
	}
	else if(nMode == MY_X)
	{
		dTransX = -dY;
		dTransY = dX;
	}
	else if(nMode == Y_MX)
	{
		dTransX = dY;
		dTransY = -dX;
	}
	else
	{
		dTransX = -dY;
		dTransY = -dX;
	}
}
void DAreaInfo::DrawDoingFire(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, int nMode)
{
	int nX1, nX2, nY1, nY2;
	GetXY(nMode, m_nMinX, m_nMinY, nX1, nY1, dDrawStartX, dDrawStartY, dScale);
	GetXY(nMode, m_nMaxX, m_nMaxY, nX2, nY2, dDrawStartX, dDrawStartY, dScale);
	CRect rect;
	if(nX1 > nX2)
	{
		rect.left = nX2; rect.right = nX1;
	}
	else
	{
		rect.left = nX1; rect.right = nX2;
	}

	if(nY1 > nY2)
	{
		rect.bottom = nY1; rect.top = nY2;
	}
	else
	{
		rect.bottom = nY2; rect.top = nY1;
	}

	pDC->Rectangle(rect);
}

BOOL DAreaInfo::IsFieldNumber(CPoint pt, int nTolerence, int nMode, double dDrawStartX, double dDrawStartY, double dScale)
{
	int nX, nY;
	GetXY(nMode, pt.x, pt.y, nX, nY, dDrawStartX, dDrawStartY, dScale);

	int nMinX = min(m_nFieldMinX, m_nFieldMaxX) + 7;
	int nMaxX = max(m_nFieldMinX, m_nFieldMaxX) + 7;
	int nCenterMinX = (int)((nMinX + nMaxX)/2.0 - 10);
	int nCenterMaxX = (int)((nMinX + nMaxX)/2.0 + 10);
	int nMinY = min(m_nFieldMinY, m_nFieldMaxY) + 7;
	int nMaxY = max(m_nFieldMinY, m_nFieldMaxY) + 7;
	int nCenterMinY = (int)((nMinY + nMaxY)/2.0 - 10);
	int nCenterMaxY = (int)((nMinY + nMaxY)/2.0 + 10);

	if(nX > nCenterMinX && nX < nCenterMaxX && nY > nCenterMinY && nY < nCenterMaxY)
		return TRUE;
	
	return FALSE;
}

void DAreaInfo::SetSelectFidBlock(int nFidBlock, BOOL bSelect)
{
	POSITION pos;
	LPFIREHOLE pHole;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);	
			if(pHole->pOrigin->nFidBlock == nFidBlock)
				pHole->bSelect = bSelect;
		}
	}

	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			if(pLine->pOrigin->nFidBlock == nFidBlock)
				pLine->bSelect = bSelect;
		}
	}
}
void DAreaInfo::SetSelectData(BOOL bSelect)
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);	
//			pHole->pOrigin->bSelect = bSelect;
			pHole->bSelect = bSelect;
		}
	}

	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
//			pLine->pOrigin->bSelect = bSelect;
			pLine->bSelect = bSelect;
		}
	}

}

BOOL DAreaInfo::IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView, GlyphExcellon* pGlyph)
{
	if(m_nMaxX < point.x) return FALSE;
	if(m_nMinX > point.x) return FALSE;
	if(m_nMaxY < point.y) return FALSE;
	if(m_nMinY > point.y) return FALSE;
	
	LPFIREHOLE pHole;
	POSITION pos;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			
			if(i != 0)
			{
				if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					continue;
				}
				
				if(bSelectOnlyView && !pHole->bSelect)
					continue;
				
				if (point.x < pHole->pOrigin->npPos.x - nTolerence ||
					point.x > pHole->pOrigin->npPos.x + nTolerence ||
					point.y < pHole->pOrigin->npPos.y - nTolerence ||
					point.y > pHole->pOrigin->npPos.y + nTolerence)
					continue;
				else
				{
					if(pHole->bSelect)
						pHole->bSelect = FALSE;
					else
						pHole->bSelect = TRUE;
				}
			}
			/* Skiving�� Fiducial�� ���� select���� ����..
			else
			{
				int nIndex;
				CPoint npData;
				nIndex = (int)(pHole->pOrigin);
				npData = pGlyph->GetUseFidIntPoint(ADDED_FID_INDEX, nIndex);
				if (point.x < npData.x - nTolerence ||
					point.x > npData.x + nTolerence ||
					point.y < npData.y - nTolerence ||
					point.y > npData.y + nTolerence)
					continue;
				else
				{
					if(pGlyph->GetUseFidSelect(ADDED_FID_INDEX, nIndex))
					{
						pGlyph->SetUseFidSelect(ADDED_FID_INDEX, nIndex, FALSE);
						gDProject.m_Glyphs.SetUseFidSelect(ADDED_FID_INDEX, nIndex, FALSE); // apply click ���� ����
					}
					else
					{
						pGlyph->SetUseFidSelect(ADDED_FID_INDEX, nIndex, TRUE);
						gDProject.m_Glyphs.SetUseFidSelect(ADDED_FID_INDEX, nIndex, TRUE);
					}
				}
			}
			*/
		}
	}
	
	int a, b, c;
	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			
			if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
			{
				continue;
			}
			
			if(bSelectOnlyView && !pLine->bSelect)
				continue;
			
			if (point.x < min(pLine->npStartPos.x, pLine->npEndPos.x) - nTolerence ||
				point.x > max(pLine->npStartPos.x, pLine->npEndPos.x) + nTolerence ||
				point.y < min(pLine->npStartPos.y, pLine->npEndPos.y) - nTolerence ||
				point.y > max(pLine->npStartPos.y, pLine->npEndPos.y) + nTolerence)
				continue;
			
			a = pLine->npStartPos.y - pLine->npEndPos.y;
			b = pLine->npEndPos.x - pLine->npStartPos.x;
			c = pLine->npStartPos.x*pLine->npEndPos.y - pLine->npStartPos.y*pLine->npEndPos.x;
			
			if(pow((double)nTolerence, 2)*(pow((double)a, 2) + pow((double)b, 2)) >= pow((double)a*point.x + b*point.y + c, 2))
			{
				if(pLine->bSelect)
					pLine->bSelect = FALSE;
				else
					pLine->bSelect = TRUE;
			}
		}
	}
	return FALSE;
}

BOOL DAreaInfo::IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView, GlyphExcellon* pGlyph)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;

	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;
	
	LPFIREHOLE pHole;
	POSITION pos;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);

			if(i != 0)
			{
				if(!(*(pToolCodes + pHole->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					continue;
				}

				if(bSelectOnlyView && !pHole->bSelect)
					continue;
				if (point1.x <= pHole->pOrigin->npPos.x && pHole->pOrigin->npPos.x <= point2.x &&
					point1.y <= pHole->pOrigin->npPos.y && pHole->pOrigin->npPos.y <= point2.y)
				{
					if(pHole->bSelect)
						pHole->bSelect = FALSE;
					else
						pHole->bSelect = TRUE;
				}
			}
			/* Skiving�� Fiducial�� ���� select���� ����..
			else
			{
				int nIndex;
				CPoint npData;	
				nIndex = (int)(pHole->pOrigin);
				npData = pGlyph->GetUseFidIntPoint(ADDED_FID_INDEX, nIndex);
				if (point1.x <= npData.x && npData.x <= point2.x &&
					point1.y <= npData.y && npData.y <= point2.y)
				{
					if(pGlyph->GetUseFidSelect(ADDED_FID_INDEX, nIndex))
					{
						pGlyph->SetUseFidSelect(ADDED_FID_INDEX, nIndex, FALSE);
						gDProject.m_Glyphs.SetUseFidSelect(ADDED_FID_INDEX, nIndex, FALSE); // apply click ���� ����
					}
					else
					{
						pGlyph->SetUseFidSelect(ADDED_FID_INDEX, nIndex, TRUE);
						gDProject.m_Glyphs.SetUseFidSelect(ADDED_FID_INDEX, nIndex, TRUE);
					}
				}
			}
			*/
		}
	}
	
	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			
			if(!(*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
			{
				continue;
			}
			
			if(bSelectOnlyView && !pLine->bSelect)
				continue;

			if (point1.x <= pLine->npStartPos.x && pLine->npStartPos.x <= point2.x &&
				point1.y <= pLine->npStartPos.y && pLine->npStartPos.y <= point2.y &&
				point1.x <= pLine->npEndPos.x && pLine->npEndPos.x <= point2.x &&
				point1.y <= pLine->npEndPos.y && pLine->npEndPos.y <= point2.y)
			{
				if(pLine->bSelect)
					pLine->bSelect = FALSE;
				else
					pLine->bSelect = TRUE;
			}
		}
	}

	return FALSE;
}

void DAreaInfo::UnSelectAll()
{
	LPFIREHOLE pData;
	POSITION pos, oldpos;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		
		while (pos) 
		{
			pData = m_FireHoles[i].GetNext(pos);
		
  			if(pData->bSelect)
				pData->bSelect = FALSE;

			oldpos = pos;
		}
	}
	
	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			if(pLine->bSelect)
				pLine->bSelect = FALSE;
		}
	}
}

void DAreaInfo::SetTableOffset(double dX, double dY)
{
	m_dTableOffsetX = dX;
	m_dTableOffsetY = dY;
}

void DAreaInfo::GetTableOffset(double& dX, double& dY)
{
	dX = m_dTableOffsetX;
	dY = m_dTableOffsetY;
}

BOOL DAreaInfo::AddFiducialIndex(int nFidIndex)
{
	if(nFidIndex < 0 || nFidIndex > MAX_FID_NO)
		return FALSE;
	
	if(m_FidIndex.GetCount() >= 4)
		return FALSE;
	
	LPFID_INDEX pFid;
	POSITION pos = m_FidIndex.GetHeadPosition();
	while(pos)
	{
		pFid = m_FidIndex.GetNext(pos);
		
		if(nFidIndex == pFid->nIndex)
			return FALSE;
	}
	pFid = new FIDUCIAL_INDEX;
	pFid->nIndex = nFidIndex;
	m_FidIndex.AddTail(pFid);
	return TRUE;
}

BOOL DAreaInfo::DeleteFiducialIndex(int nFidIndex)
{
	if(nFidIndex < 0 || nFidIndex > MAX_FID_NO)
		return FALSE;
	
	if(m_FidIndex.GetCount() < 3)
		return FALSE;
	
	LPFID_INDEX pFid;
	POSITION pos = m_FidIndex.GetHeadPosition();
	while(pos)
	{
		pFid = m_FidIndex.GetAt(pos);
		if(nFidIndex == pFid->nIndex)
		{
			m_FidIndex.RemoveAt(pos);
			return TRUE;
		}
		m_FidIndex.GetNext(pos);
	}
	return FALSE;
}

void DAreaInfo::ClearFiducialIndex()
{
	LPFID_INDEX pFid;
	POSITION pos = m_FidIndex.GetHeadPosition();
	while (pos) 
	{
		pFid = m_FidIndex.GetNext(pos);
		delete pFid;
	}
	m_FidIndex.RemoveAll();
}

BOOL DAreaInfo::IsThereSameUnit(LPDUNIT pUnit)
{
	LPDUNIT pSaveUnit;
	POSITION pos = m_Units.GetHeadPosition();
	while (pos) 
	{
		pSaveUnit = m_Units.GetNext(pos);
		if(pUnit == pSaveUnit)
			return TRUE;
	}
	return FALSE;
}

int DAreaInfo::GetUnitForFidCal(int nFidMethod, CToolCodeList** pToolCodes)
{
	LPFIREHOLE pData;
	POSITION pos;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pData = m_FireHoles[i].GetNext(pos);
			if(nFidMethod == FIND_ALL_FID)
				return pData->pOrigin->nUnitIndex;
			else if(nFidMethod == FIND_SELECT_ONLY)
			{
				if(pData->bSelect && (*(pToolCodes + pData->pOrigin->nToolNo))->m_bVisible)
					return pData->pOrigin->nUnitIndex;
			}
			else
			{
				if((*(pToolCodes + pData->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					return pData->pOrigin->nUnitIndex;
				}
			}
		}
	}
	
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);
			if(nFidMethod == FIND_ALL_FID)
				return pLine->pOrigin->nUnitIndex;
			else if(nFidMethod == FIND_SELECT_ONLY)
			{
				if(pLine->bSelect && (*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible)
					return pLine->pOrigin->nUnitIndex;
			}
			else
			{
				if((*(pToolCodes + pLine->pOrigin->nToolNo))->m_bVisible) // visible �ƴϸ�
				{
					return pLine->pOrigin->nUnitIndex;
				}
			}
		}
	}
	return -1; // there is no Unit
}

BOOL DAreaInfo::IsInData2(LPLINEDATA pOriginLine, int nMinX, int nMaxX, int nMinY, int nMaxY, int nToolType, int nRealTooNo, int nUnitNo, int &nXLineBigger, int &nYLineBigger)
{
	if(nMinX > m_nMaxX) return FALSE;
	if(nMaxX < m_nMinX) return FALSE;
	if(nMinY > m_nMaxY) return FALSE;
	if(nMaxY < m_nMinY) return FALSE;

	if(nMinX < m_nMinX) return FALSE;
	if(nMaxX > m_nMaxX) 
	{
		nXLineBigger++;
		return FALSE;
	}
	if(nMinY < m_nMinY) return FALSE;
	if(nMaxY > m_nMaxY) 
	{
		nYLineBigger++;
		return FALSE;
	}

	if(nToolType == emFlying)
	{
		if((pOriginLine->npStartPos.x >= m_nMinX && pOriginLine->npStartPos.x <= m_nMaxX &&
		    pOriginLine->npStartPos.y >= m_nMinY && pOriginLine->npStartPos.y <= m_nMaxY) ||
		   (pOriginLine->npEndPos.x >= m_nMinX && pOriginLine->npEndPos.x <= m_nMaxX &&
			pOriginLine->npEndPos.y >= m_nMinY && pOriginLine->npEndPos.y <= m_nMaxY))
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos = pOriginLine->npStartPos;
			pLine->npEndPos = pOriginLine->npEndPos;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
			return TRUE;
		}
		else
			return FALSE;
	}

	if(nMaxX - nMinX == 0)
	{
		if(nMinY <= m_nMinY) nMinY = m_nMinY;
		if(nMaxY >= m_nMaxY) nMaxY = m_nMaxY;
		if(nMinY >= nMaxY) return FALSE;
		if(pOriginLine->npStartPos.y > pOriginLine->npEndPos.y)
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.y = nMaxY;
			pLine->npStartPos.x = nMinX;
			pLine->npEndPos.y = nMinY;
			pLine->npEndPos.x = nMinX;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
		else
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.y = nMinY;
			pLine->npStartPos.x = nMinX;
			pLine->npEndPos.y = nMaxY;
			pLine->npEndPos.x = nMinX;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
	}
	else if(nMaxY - nMinY == 0)
	{
		if(nMinX <= m_nMinX) nMinX = m_nMinX;
		if(nMaxX >= m_nMaxX) nMaxX = m_nMaxX;
		if(nMinX >= nMaxX) return FALSE;
		if(pOriginLine->npStartPos.x > pOriginLine->npEndPos.x)
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.x = nMaxX;
			pLine->npStartPos.y = nMinY;
			pLine->npEndPos.x = nMinX;
			pLine->npEndPos.y = nMinY;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
		else
		{
			LPFIRELINE	pLine = new LINE_CONVERT_DATA;
			pLine->pOrigin = pOriginLine;
			pLine->npStartPos.x = nMinX;
			pLine->npStartPos.y = nMinY;
			pLine->npEndPos.x = nMaxX;
			pLine->npEndPos.y = nMinY;
			pLine->bSelect = FALSE;
			pLine->pOrigin->nUnitIndex = nUnitNo;
			m_FireLines[nRealTooNo].AddTail(pLine);
		}
	}
	else
	{
		double a, b, x1, x2, y1, y2;
		int nStartX, nStartY, nEndX, nEndY;
//		if((m_nMaxX - m_nMinX) > (m_nMaxY - m_nMinY))	// y = ax + b
//		{
			a = (double)(pOriginLine->npStartPos.y - pOriginLine->npEndPos.y) / 
				(double)(pOriginLine->npStartPos.x - pOriginLine->npEndPos.x);
			b = pOriginLine->npStartPos.y - a * pOriginLine->npStartPos.x;
			y1 = a * m_nMinX + b;
			y2 = a * m_nMaxX + b;
			x1 = (m_nMinY - b) / a;
			x2 = (m_nMaxY - b) / a;
			if(a>0)
			{
				if(y1 < m_nMaxY && y1 >= m_nMinY)
				{
					nStartX = m_nMinX; nStartY = (int)y1;
				}
				else if(x1 < m_nMaxX && x1 >= m_nMinX)
				{
					nStartX = (int)x1; nStartY = m_nMinY;
				}
				else
					return FALSE;

				if(x2 < m_nMinX || y2 < m_nMinY) return FALSE;
				if(x2 <= m_nMaxX)
				{
					nEndX = (int)x2; nEndY = m_nMaxY;
				}
				else if(y2 <= m_nMaxY)
				{
					nEndX = m_nMaxX; nEndY = (int)y2;
				}
				else
					return FALSE;
			}
			else
			{
				if(y1 <= m_nMaxY && y1 > m_nMinY)
				{
					nStartX = m_nMinX; nStartY = (int)y1;
				}
				else if(x2 < m_nMaxX && x2 >= m_nMinX)
				{
					nStartX = (int)x2; nStartY = m_nMaxY;
				}
				else
					return FALSE;
				
				if(x1 < m_nMinX || y2 > m_nMaxY) return FALSE;
				if(x1 <= m_nMaxX)
				{
					nEndX = (int)x1; nEndY = m_nMinY;
				}
				else if(y2 >= m_nMinY)
				{
					nEndX = m_nMaxX; nEndY = (int)y2;
				}
				else
					return FALSE;
			}
			if(pOriginLine->npStartPos.x > pOriginLine->npEndPos.x)
			{
				LPFIRELINE	pLine = new LINE_CONVERT_DATA;
				pLine->pOrigin = pOriginLine;
				if(pOriginLine->npStartPos.x < nEndX)
				{
					pLine->npStartPos.x = pOriginLine->npStartPos.x;
					pLine->npStartPos.y = pOriginLine->npStartPos.y;
				}
				else
				{
					pLine->npStartPos.x = nEndX;
					pLine->npStartPos.y = nEndY;
				}
				if(pOriginLine->npEndPos.x > nStartX)
				{
					pLine->npEndPos.x = pOriginLine->npEndPos.x;
					pLine->npEndPos.y = pOriginLine->npEndPos.y;
				}
				else
				{
					pLine->npEndPos.x = nStartX;
					pLine->npEndPos.y = nStartY;
				}
				pLine->bSelect = FALSE;
				pLine->pOrigin->nUnitIndex = nUnitNo;
				m_FireLines[nRealTooNo].AddTail(pLine);
			}
			else
			{
				LPFIRELINE	pLine = new LINE_CONVERT_DATA;
				pLine->pOrigin = pOriginLine;
				if(pOriginLine->npStartPos.x > nStartX)
				{
					pLine->npStartPos.x = pOriginLine->npStartPos.x;
					pLine->npStartPos.y = pOriginLine->npStartPos.y;
				}
				else
				{
					pLine->npStartPos.x = nStartX;
					pLine->npStartPos.y = nStartY;
				}
				if(pOriginLine->npEndPos.x < nEndX)
				{
					pLine->npEndPos.x = pOriginLine->npEndPos.x;
					pLine->npEndPos.y = pOriginLine->npEndPos.y;
				}
				else
				{
					pLine->npEndPos.x = nEndX;
					pLine->npEndPos.y = nEndY;
				}
				pLine->bSelect = FALSE;
				pLine->pOrigin->nUnitIndex = nUnitNo;
				m_FireLines[nRealTooNo].AddTail(pLine);
			}
/*		}
		else											// x = ay + b
		{
			a = (double)(pOriginLine->npStartPos.y - pOriginLine->npEndPos.y) / 
				(double)(pOriginLine->npStartPos.x - pOriginLine->npEndPos.x);
			b = pOriginLine->npStartPos.x - a * pOriginLine->npStartPos.y;
		}
*/
	}
	return TRUE;
}

BOOL DAreaInfo::IsThereSameBlockData(int nFidBlock,int nSkipBlock)
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	BOOL bPass = FALSE;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = m_FireHoles[i].GetNext(pos);
			

			if(nFidBlock == -1 && nSkipBlock != pHole->pOrigin->nFidBlock)
				bPass = TRUE;
			
			//if(pHole->pOrigin->nFidBlock == nFidBlock || nFidBlock == -1)
				if(pHole->pOrigin->nFidBlock == nFidBlock || bPass)
				return TRUE;
		}
	}
	
	LPFIRELINE pLine;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = m_FireLines[i].GetNext(pos);

			if(nFidBlock == -1 && nSkipBlock != pLine->pOrigin->nFidBlock)
				bPass = TRUE;

			//if(pLine->pOrigin->nFidBlock == nFidBlock || nFidBlock == -1)
			if(pLine->pOrigin->nFidBlock == nFidBlock || bPass)
				return TRUE;
		}
	}
	return FALSE;
}

void DAreaInfo::FieldCopy(DAreaInfo *pAreaInfo, GlyphExcellon *pExcellon, double dX, double dY, int nCount)
{
	//member copy 
	m_bCheckIndex = pAreaInfo->m_bCheckIndex;
	m_dCenterX = pAreaInfo->m_dCenterX + dX;
	m_dCenterY = pAreaInfo->m_dCenterY + dY;
	m_nFidBlock = pAreaInfo->m_nFidBlock;
	m_dFidChangeCenterX = pAreaInfo->m_dFidChangeCenterX;
	m_dFidChangeCenterY = pAreaInfo->m_dFidChangeCenterY;
	m_nFieldMaxX = pAreaInfo->m_nFieldMaxX + (int)dX;
	m_nFieldMaxY = pAreaInfo->m_nFieldMaxY + (int)dY;
	m_nFieldMinX = pAreaInfo->m_nFieldMinX + (int)dX;
	m_nFieldMinY = pAreaInfo->m_nFieldMinY + (int)dY;
	m_nMaxX = pAreaInfo->m_nMaxX;
	m_nMaxY = pAreaInfo->m_nMaxY;
	m_nMinX = pAreaInfo->m_nMinX;
	m_nMinY = pAreaInfo->m_nMinY;
	m_nRefNo = pAreaInfo->m_nRefNo;
	m_nSortIndex = nCount; //���߿� �ٽ� sort 
	m_dTableX = pAreaInfo->m_dTableX + dX ;
	m_dTableY = pAreaInfo->m_dTableY + dY;
	m_nFireStatus = NO_FIRE;
	m_d1stAngle = pAreaInfo->m_d1stAngle;
	m_d2ndAngle = pAreaInfo->m_d2ndAngle;
	m_dTableOffsetX = pAreaInfo->m_dTableOffsetX;
	m_dTableOffsetY = pAreaInfo->m_dTableOffsetY;

	ClearData();
	//hole copy
	POSITION pos,posUnit;
	LPFIREHOLE pHole; //firehole

	LPDUNIT pUnit;
	
	int	nUnitNo = 0;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while (pos)
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
		
				HOLECONVERTDATA copyHole;
			copyHole.bSelect = FALSE;
			copyHole.dpLSBPos1.x = pHole->dpLSBPos1.x + dX;
			copyHole.dpLSBPos1.y = pHole->dpLSBPos1.y + dY;
			copyHole.dpLSBPos2.x = pHole->dpLSBPos2.x + dX;
			copyHole.dpLSBPos2.y = pHole->dpLSBPos2.y + dY;
			
			nUnitNo = 0;
			posUnit = pExcellon->m_Units.GetHeadPosition();	
			while(posUnit)
			{
				pUnit = pExcellon->m_Units.GetNext(posUnit);
				if(pHole->pOrigin->nUnitIndex == nUnitNo)
				{
					HOLEDATA OriHole;
					
					OriHole.bRotate		= pHole->pOrigin->bRotate;
		            OriHole.nHoleContentsIndex		= pHole->pOrigin->nHoleContentsIndex;
					strcpy_s(OriHole.m_szHoleContents, pHole->pOrigin->m_szHoleContents);
					OriHole.bSelect		= pHole->pOrigin->bSelect;
					OriHole.nFidBlock	= pHole->pOrigin->nFidBlock;
					OriHole.npPos.x		= pHole->pOrigin->npPos.x + (LONG)dX;
					OriHole.npPos.y		= pHole->pOrigin->npPos.y + (LONG)dY;
					OriHole.nRefNo		= pHole->pOrigin->nRefNo;
					OriHole.nToolNo		= pHole->pOrigin->nToolNo;
					OriHole.nUnitIndex	= pHole->pOrigin->nUnitIndex;
					OriHole.nBlockName2= pHole->pOrigin->nBlockName2;
					OriHole.cIsPattern= pHole->pOrigin->cIsPattern;

					copyHole.pOrigin = pUnit->m_HoleData.AddTail(OriHole);
//					copyHole->pOrigin = pOriHole;
				}
				nUnitNo++;

			}
			m_FireHoles[i].AddTail(copyHole);
		}
	}

	// line copy 
	LPFIRELINE pLine;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
		
			LPFIRELINE	copyLine = new LINE_CONVERT_DATA;
					
			copyLine->npStartPos.x = pLine->npStartPos.x + (LONG)dX ;
			copyLine->npStartPos.y = pLine->npStartPos.y + (LONG)dY;
			copyLine->npEndPos.x = pLine->npEndPos.x + (LONG)dX;
			copyLine->npEndPos.y = pLine->npEndPos.y + (LONG)dY;
			copyLine->bSelect = FALSE;
		
			nUnitNo = 0;
			posUnit = pExcellon->m_Units.GetHeadPosition();	
			while(posUnit)
			{
				pUnit = pExcellon->m_Units.GetNext(posUnit);
				if(pLine->pOrigin->nUnitIndex == nUnitNo)
				{
					LPLINEDATA pOriLine = new LINEDATA;

					pOriLine->bDivideDone	= pLine->pOrigin->bDivideDone;
					pOriLine->bSelect		= pLine->pOrigin->bSelect;
					pOriLine->nFidBlock	= pLine->pOrigin->nFidBlock;
					memcpy(pOriLine->nFidIndex, pLine->pOrigin->nFidIndex, sizeof(pLine->pOrigin->nFidIndex));
					pOriLine->npEndPos.x		= pLine->pOrigin->npEndPos.x + (LONG)dX;
					pOriLine->npEndPos.y		= pLine->pOrigin->npEndPos.y + (LONG)dY;
					pOriLine->npStartPos.x	= pLine->pOrigin->npStartPos.x + (LONG)dX;
					pOriLine->npStartPos.y	= pLine->pOrigin->npStartPos.y + (LONG)dY;
					pOriLine->nRefNo		= pLine->pOrigin->nRefNo;
					pOriLine->nToolNo		= pLine->pOrigin->nToolNo;
					pOriLine->nUnitIndex	= pLine->pOrigin->nUnitIndex;
					
					pUnit->m_LineData.AddTail(pOriLine);
					copyLine->pOrigin = pOriLine;
					
				}
				nUnitNo++;
			}
		
			m_FireLines[i].AddTail(copyLine);
		}
	}

}

int DAreaInfo::GetSelectedHoleCount(int nTool)
{
	int nSeletedHoleCount = 0;
	POSITION pos;
	LPFIREHOLE pHole;
	pos = m_FireHoles[nTool].GetHeadPosition();
	while (pos) 
	{
		pHole = m_FireHoles[nTool].GetNext(pos);

		if(pHole->bSelect == TRUE) // visible �ƴϸ�
		{
			nSeletedHoleCount++;
		}
	}
	return nSeletedHoleCount;
}


CPoint DAreaInfo::DisplayBlockDots(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, BlockList* pBlocks,
	BOOL bDrawPath, CPen* pOldPen, CPen* pCurPen, int nPenSize, int nSkipNo)
{
	

	CPoint ptReturnP;
	int nTempX, nTempY, nCount;
	GetXY(nMode, x, y, nTempX, nTempY, dStartX, dStartY, dScale);
	ptReturnP.x = nTempX; ptReturnP.y = nTempY;
	POSITION pos = pBlocks->GetHeadPosition();
	LPDBLOCK pBlock, pFoundBlock = NULL;
	while(pos)
	{
		pBlock = pBlocks->GetNext(pos);
		if(pBlock->m_nBlockName == nBlockName)
		{
			pFoundBlock = pBlock;
			break;
		}
	}
	if(pFoundBlock)
	{
		CPoint ptStart, ptEnd, ptSumPosStart, ptSumPosEnd;
		ptStart.x = pBlock->m_nMinX + x; ptStart.y = pBlock->m_nMinY + y;
		ptEnd.x = pBlock->m_nMaxX + x; ptEnd.y = pBlock->m_nMaxY + y;
		if(!IsDrawData(nMode, ptStart, ptEnd, (int)dStartX, (int)dStartY, (int)dEndX, (int)dEndY, 0))
			return ptReturnP;
		int nX, nY, nX2, nY2, nOldX, nOldY;
		int nArrowSize = (int)(50 / dScale);
		double dAngle, cosTheta, sinTheta;
		POINT ptr[3];
		GetXY(nMode, ptStart.x, ptStart.y, nX, nY, dStartX, dStartY, dScale);
		GetXY(nMode, ptEnd.x,  ptEnd.y, nX2, nY2, dStartX, dStartY, dScale);
	
		int nGapX = nX2 - nX;
		int nGapY = nY2 - nY;

		if(nX2 - nX < 10 || nY - nY2 < 10)
		{
			//pDC->Rectangle(nX, nY2, nX2, nY);
			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX, nY);
			return ptReturnP;//20161114
		}
	
		LPHOLEDATA pHole;
		pos = pBlock->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pBlock->m_HoleData.GetNext(pos);
			nCount = rand();
			if(nCount % nSkipNo)
				continue;
			GetXY(nMode, pHole->npPos.x + x, pHole->npPos.y + y, nX, nY, dStartX, dStartY, dScale);
				pDC->MoveTo(nX, nY);
				pDC->LineTo(nX, nY);
		}

	}
	return ptReturnP;
}


BOOL DAreaInfo::IsDrawData(int nMode, int nX, int nY, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName)
{
	if(nBlockName != 0)
		return TRUE;

	int nTransX, nTransY;

	if(nMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(nMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(nMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(nMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(nMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(nMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(nMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}

	if(nTransX < nStartX) 
		return FALSE;
	if(nTransX > nEndX) 
		return FALSE;
	if(nTransY < nEndY) 
		return FALSE;
	if(nTransY > nStartY) 
		return FALSE;

	return TRUE;
}

BOOL DAreaInfo::IsDrawData(int nMode, CPoint ptStart, CPoint ptEnd, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName)
{
	if(nBlockName != 0)
		return TRUE;

	int nTransX, nTransY, nTransX2, nTransY2;

	if(nMode == X_Y)
	{
		nTransX = ptStart.x;		nTransY = ptStart.y;
		nTransX2 = ptEnd.x;		nTransY2 = ptEnd.y;
	}
	else if(nMode == MX_Y)
	{
		nTransX = - ptStart.x;		nTransY = ptStart.y;
		nTransX2 = - ptEnd.x;		nTransY2 = ptEnd.y;
	}
	else if(nMode == X_MY)
	{
		nTransX =  ptStart.x;		nTransY = -ptStart.y;
		nTransX2 =  ptEnd.x;		nTransY2 = -ptEnd.y;
	}
	else if(nMode == MX_MY)
	{
		nTransX = - ptStart.x;		nTransY = -ptStart.y;
		nTransX2 = - ptEnd.x;		nTransY2 = -ptEnd.y;
	}
	else if(nMode == Y_X)
	{
		nTransX = ptStart.y;		nTransY =  ptStart.x;
		nTransX2 = ptEnd.y;		nTransY2 =  ptEnd.x;
	}
	else if(nMode == MY_X)
	{
		nTransX = -ptStart.y;		nTransY =  ptStart.x;
		nTransX2 = -ptEnd.y;		nTransY2 =  ptEnd.x;
	}
	else if(nMode == Y_MX)
	{
		nTransX = ptStart.y;		nTransY = - ptStart.x;
		nTransX2 = ptEnd.y;		nTransY2 = - ptEnd.x;
	}
	else
	{
		nTransX = -ptStart.y;		nTransY = - ptStart.x;
		nTransX2 = -ptEnd.y;		nTransY2 = - ptEnd.x;
	}

	int nMinX, nMinY, nMaxX, nMaxY;
	nMinX = min(nTransX, nTransX2);
	nMaxX = max(nTransX, nTransX2);
	nMinY = min(nTransY, nTransY2);
	nMaxY = max(nTransY, nTransY2);

	if(nMaxX < nStartX) 
		return FALSE;
	if(nMinX > nEndX) 
		return FALSE;
	if(nMaxY < nEndY) 
		return FALSE;
	if(nMinY > nStartY) 
		return FALSE;

	return TRUE;
}



CPoint DAreaInfo::DisplayPathInBlock(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, BlockList* pBlocks)
{
	CPoint ptReturnP;
	int nTempX, nTempY;
	GetXY(nMode, x, y, nTempX, nTempY, dStartX, dStartY, dScale);
	ptReturnP.x = nTempX; ptReturnP.y = nTempY;
	POSITION pos = pBlocks->GetHeadPosition();
	LPDBLOCK pBlock, pFoundBlock = NULL;
	while(pos)
	{
		pBlock = pBlocks->GetNext(pos);
		if(pBlock->m_nBlockName == nBlockName)
		{
			pFoundBlock = pBlock;
			break;
		}
	}
	if(pFoundBlock)
	{
		CPoint ptStart, ptEnd;
		ptStart.x = pBlock->m_nMinX + x; ptStart.y = pBlock->m_nMinY + y;
		ptEnd.x = pBlock->m_nMaxX + x; ptEnd.y = pBlock->m_nMaxY + y;
		if(!IsDrawData(nMode, ptStart, ptEnd, (int)dStartX, (int)dStartY, (int)dEndX, (int)dEndY, 0))
			return ptReturnP;
		int nX, nY, nX2, nY2;
		int nArrowSize = (int)(50 / dScale);
		double dAngle, cosTheta, sinTheta;
		POINT ptr[3];
		GetXY(nMode, ptStart.x, ptStart.y, nX, nY, dStartX, dStartY, dScale);
		GetXY(nMode, ptEnd.x,  ptEnd.y, nX2, nY2, dStartX, dStartY, dScale);
		if(nX2 - nX < 10 || nY - nY2 < 10)
			return ptReturnP;

		LPHOLEDATA pHole;
		pos = pBlock->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pBlock->m_HoleData.GetNext(pos);
			GetXY(nMode, pHole->npPos.x + x, pHole->npPos.y + y, nX, nY, dStartX, dStartY, dScale);
			if(nX != nTempX || nY != nTempY)
			{
				dAngle = atan2((double)(nY - nTempY), (double)(nX - nTempX) );
				ptr[0].x = nX;
				ptr[0].y = nY;
				cosTheta = cos(dAngle);
				sinTheta = sin(dAngle);
				ptr[1].x = (long)( nX + ( cosTheta* -nArrowSize - sinTheta* nArrowSize) );
				ptr[1].y = (long)( nY + ( sinTheta* -nArrowSize + cosTheta* nArrowSize) );

				ptr[2].x = (long)( nX + ( cosTheta* -nArrowSize - sinTheta* -nArrowSize) );
				ptr[2].y = (long)( nY + ( sinTheta* -nArrowSize + cosTheta* -nArrowSize) );

				pDC->LineTo(nX, nY);
				pDC->Polygon(ptr,3);

				nTempX = nX; 
				nTempY = nY;
				if(IsDrawData(nMode,  pHole->npPos.x + x, pHole->npPos.y + y, (int)dStartX, (int)dStartY, (int)dEndX, (int)dEndY, 0))
				{
					//					if(m_nPathAnimateDelay)
					//						::Sleep(m_nPathAnimateDelay);
				}
			}
			ptReturnP.x = nTempX;
			ptReturnP.y = nTempY;
		}
	}
	return ptReturnP;
}
void DAreaInfo::CopyArea(DAreaInfo* pOriArea, DUnit *pUnit)
{
	m_dCenterX = pOriArea->m_dCenterX;
	m_dCenterY = pOriArea->m_dCenterY;
	m_nMinX = pOriArea->m_nMinX;
	m_nMinY = pOriArea->m_nMinY;
	m_nMaxX = pOriArea->m_nMaxX;
	m_nMaxY = pOriArea->m_nMaxY;
	m_nFidBlock = pOriArea->m_nFidBlock;
	m_nSortIndex = pOriArea->m_nSortIndex;


	m_dTableX = pOriArea->m_dTableX;
	m_dTableY = pOriArea->m_dTableY;

	m_dFidChangeCenterX = pOriArea->m_dFidChangeCenterX;
	m_dFidChangeCenterY = pOriArea->m_dFidChangeCenterY;

	POSITION pos;
	LPFIREHOLE pHole;

	HOLEDATA OriHole, *pOriHole = NULL;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		pos = pOriArea->m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			HOLECONVERTDATA fireHole;
			pHole = pOriArea->m_FireHoles[i].GetNext(pos);


			if(pUnit)
			{
				pOriHole = pUnit->m_HoleData.AddTail(*pHole->pOrigin);
			}

			memcpy(&fireHole, pHole, sizeof(HOLECONVERTDATA));
			if(pOriHole != NULL)
				fireHole.pOrigin = pOriHole;




			if(pHole->m_pblockPosList && pHole->m_pblockPosList->GetCount())
			{
				fireHole.m_pblockPosList = new CBlockFidPosList();
				fireHole.m_pblockPosList->MakeMemory(pHole->m_pblockPosList->GetCount());

				BLOCK_FIDPOS* pOrigholeFidData;
				BLOCK_FIDPOS* pholeFidData;

				pOrigholeFidData = pHole->m_pblockPosList->GetNext(0);
				pholeFidData = fireHole.m_pblockPosList->GetNext(0);
				memcpy(pholeFidData, pOrigholeFidData, sizeof(BLOCK_FIDPOS) *pHole->m_pblockPosList->GetCount() );
			}
			else
				fireHole.m_pblockPosList = NULL;

			m_FireHoles[i].AddTail(fireHole);
			fireHole.m_pblockPosList = NULL;
		}
	}

	LPFIRELINE pLine, pNewLine;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		pos = pOriArea->m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = pOriArea->m_FireLines[i].GetNext(pos);
			pLine->pOrigin->nRefNo++;
			pNewLine = new LINE_CONVERT_DATA;
			memcpy(pNewLine, pLine, sizeof(LINE_CONVERT_DATA));
			m_FireLines[i].AddTail(pNewLine);
		}
	}

	m_dTableOffsetX = pOriArea->m_dTableOffsetX;
	m_dTableOffsetY = pOriArea->m_dTableOffsetY;

	LPFID_INDEX pFid, pOriFid;
	pos = pOriArea->m_FidIndex.GetHeadPosition();
	while (pos) 
	{
		pOriFid = pOriArea->m_FidIndex.GetNext(pos);
		pFid = new FIDUCIAL_INDEX;
		memcpy(pFid, pOriFid, sizeof(FIDUCIAL_INDEX));
		m_FidIndex.AddTail(pFid);
	}
}