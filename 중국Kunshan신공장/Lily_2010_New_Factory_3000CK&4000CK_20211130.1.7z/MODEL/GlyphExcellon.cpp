// GlyphExcellon.cpp: implementation of the GlyphExcellon class.
//
//////////////////////////////////////////////////////////////////////



#include "stdafx.h"
#include "..\easydriller.h"
#include "GlyphExcellon.h"
#include "dsystemini.h"
#include "math.h"
#include "..\UI\ColorComboEx.h"
#include "DUodoRedo.h"
#include "DEasyDrillerINI.h"
#include "..\UI\PaneAutoRun.h"
#include "DProcessINI.h"
#include "TSP.h"
#include "..\ui\ProgressWnd.h"
#include "GlobalVariable.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define DEFAULT_FID_INDEX	0
#define ADDED_FID_INDEX		1

#define MID_FIDUCIAL 0
#define MULTI_FIDUCIAL 1
#define COARSE_FIDUCIAL 2

// 20130419 fiducial ������, block �� ���� �����ϱ� ����
#define COLOR_REF_FID					0x0000FF // ref fid
#define COLOR_SKIVING_FID				0xFF00FF // skiving fid
#define COLOR_VERFIY_FID				0x00FFFF // verify fid
#define COLOR_SELECTED_FID				0x000000 // selected fid
#define COLOR_COARSE_FID				0xCBC0FF

IMPLEMENT_SERIAL(GlyphExcellon, Glyph, 1)
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GlyphExcellon::GlyphExcellon():Glyph()
{
	// 20130419 fiducial ������, block �� ���� �����ϱ� ����
	m_cColorFid[0] = m_cColorFid[25] = 0xFFFF00;
	m_cColorFid[1] = m_cColorFid[26] = 0xFF0000;
	m_cColorFid[2] = m_cColorFid[27] = 0x008000;
	m_cColorFid[3] = m_cColorFid[28] = 0x00FF00;
	m_cColorFid[4] = m_cColorFid[29] = 0x00A5FF;
	m_cColorFid[5] = m_cColorFid[30] = 0x000080;
	m_cColorFid[6] = m_cColorFid[31] = 0x2A2AA5;
	m_cColorFid[7] = m_cColorFid[32] = 0x5C5CCD;
	m_cColorFid[8] = m_cColorFid[33] = 0x7280FA;
	m_cColorFid[9] = m_cColorFid[34] = 0x00D7FF;
	m_cColorFid[10] = m_cColorFid[35] = 0x8CB4D2;
	m_cColorFid[11] = m_cColorFid[36] = 0x8CE6F0;
	m_cColorFid[12] = m_cColorFid[37] = 0x808000;
	m_cColorFid[13] = m_cColorFid[38] = 0x800080;
	m_cColorFid[14] = m_cColorFid[39] = 0xA09E5F;
	m_cColorFid[15] = m_cColorFid[40] = 0x3CA4DC;
	m_cColorFid[16] = m_cColorFid[41] = 0xC0C0C0;
	m_cColorFid[17] = m_cColorFid[42] = 0x800000;
	m_cColorFid[18] = m_cColorFid[43] = 0xDDA0DD;
	m_cColorFid[19] = m_cColorFid[44] = 0xEE82EE;
	m_cColorFid[20] = m_cColorFid[45] = 0x578B2E;
	m_cColorFid[21] = m_cColorFid[46] = 0xA0A000;
	m_cColorFid[22] = m_cColorFid[47] = 0xA9A9A9;
	m_cColorFid[23] = m_cColorFid[48] = 0x82004B;
	m_cColorFid[24] = m_cColorFid[49] = 0x808080;

	m_FiducialData[DEFAULT_FID_INDEX].nRef = 0;
	m_FiducialData[ADDED_FID_INDEX].nRef = 0;
	m_bShowSelectionFid = FALSE;
//	m_bSelectionPlus = FALSE;
	m_nFidIndex = -1;
	m_Units.RemoveAll();


	m_HoleFindData.nCam = 1;
	m_HoleFindData.sVisInfo.nModelType = 1;
	m_HoleFindData.sVisInfo.nPolarity = 0;
	m_HoleFindData.sVisInfo.dSizeA = 0.1;
	m_HoleFindData.sVisInfo.dSizeB = 0;
	m_HoleFindData.sVisInfo.dSizeC = 0;
	
	m_HoleFindData.sVisInfo.dScoreAngle = 10;
	m_HoleFindData.sVisInfo.dScoreSize = 10;
	m_HoleFindData.sVisInfo.dAspectRatio = 20;
	m_HoleFindData.sVisInfo.nThreshold = 0;
	
	for(int i=0; i<4; i++)
	{
		m_HoleFindData.sVisInfo.nCoaxial[i] = 30;
		m_HoleFindData.sVisInfo.nRing[i] = 80;
	m_HoleFindData.sVisInfo.nIR[i] = 0;
		m_HoleFindData.sVisInfo.dContrast[i] = 0.3;
		m_HoleFindData.sVisInfo.dBrightness[i] = 0.3;
	}
}

GlyphExcellon::~GlyphExcellon()
{
	RemoveAllUnit();
	RemoveAllBlock();
	
	m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
	m_FiducialData[ADDED_FID_INDEX].RemoveFidData();
}

void GlyphExcellon::operator=( GlyphExcellon& myExcellon )
{
	m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
	m_FiducialData[ADDED_FID_INDEX].RemoveFidData();

	LPFIDDATA pFidData, pFidNew;
	POSITION pos = myExcellon.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = myExcellon.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		pFidNew = new FID_DATA;
		memcpy(pFidNew, pFidData, sizeof(FID_DATA));
		m_FiducialData[DEFAULT_FID_INDEX].AddFidData(pFidNew);
	}

	pos = myExcellon.m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = myExcellon.m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		pFidNew = new FID_DATA;
		memcpy(pFidNew, pFidData, sizeof(FID_DATA));
		m_FiducialData[ADDED_FID_INDEX].AddFidData(pFidNew);
	}

	m_FiducialData[DEFAULT_FID_INDEX].nRef = myExcellon.m_FiducialData[DEFAULT_FID_INDEX].nRef;
	m_FiducialData[ADDED_FID_INDEX].nRef = myExcellon.m_FiducialData[ADDED_FID_INDEX].nRef;
	
	m_HoleFindData.nCam = myExcellon.m_HoleFindData.nCam;
	m_HoleFindData.sVisInfo.nModelType = myExcellon.m_HoleFindData.sVisInfo.nModelType;
	m_HoleFindData.sVisInfo.nPolarity =  myExcellon.m_HoleFindData.sVisInfo.nPolarity;
	m_HoleFindData.sVisInfo.dSizeA =  myExcellon.m_HoleFindData.sVisInfo.dSizeA;
	m_HoleFindData.sVisInfo.dSizeB =  myExcellon.m_HoleFindData.sVisInfo.dSizeB;
	m_HoleFindData.sVisInfo.dSizeC =  myExcellon.m_HoleFindData.sVisInfo.dSizeC;
	
	m_HoleFindData.sVisInfo.dScoreAngle =  myExcellon.m_HoleFindData.sVisInfo.dScoreAngle;
	m_HoleFindData.sVisInfo.dScoreSize =  myExcellon.m_HoleFindData.sVisInfo.dScoreSize;
	m_HoleFindData.sVisInfo.dAspectRatio =  myExcellon.m_HoleFindData.sVisInfo.dAspectRatio;
	m_HoleFindData.sVisInfo.nThreshold =  myExcellon.m_HoleFindData.sVisInfo.nThreshold;
	
	for(int i=0; i<4; i++)
	{
		m_HoleFindData.sVisInfo.nCoaxial[i] = myExcellon.m_HoleFindData.sVisInfo.nCoaxial[i];
		m_HoleFindData.sVisInfo.nRing[i] =  myExcellon.m_HoleFindData.sVisInfo.nRing[i];
		m_HoleFindData.sVisInfo.nIR[i] = myExcellon.m_HoleFindData.sVisInfo.nIR[i];
		m_HoleFindData.sVisInfo.dContrast[i] =  myExcellon.m_HoleFindData.sVisInfo.dContrast[i];
		m_HoleFindData.sVisInfo.dBrightness[i] =  myExcellon.m_HoleFindData.sVisInfo.dBrightness[i];
	}


	RemoveAllUnit();

	LPDUNIT pUnit, pUnitNew;
	pos = myExcellon.m_Units.GetHeadPosition();
	while (pos) 
	{
		pUnitNew = new DUnit;
		pUnit = myExcellon.m_Units.GetNext(pos);
		pUnitNew->Copy(pUnit);
		m_Units.AddTail(pUnitNew);
	}

	RemoveAllBlock();
	LPDBLOCK pBlock, pBlockNew;
	pos = myExcellon.m_Blocks.GetHeadPosition();
	while (pos) 
	{
		pBlockNew = new DBlock;
		pBlock = myExcellon.m_Blocks.GetNext(pos);
		pBlockNew->Copy(pBlock);
		m_Blocks.AddTail(pBlockNew);
	}

	m_nMaxX = myExcellon.m_nMaxX;
	m_nMinX = myExcellon.m_nMinX;
	m_nMaxY = myExcellon.m_nMaxY;
	m_nMinY = myExcellon.m_nMinY;

	m_bShowSelectionFid = FALSE;
//	m_bSelectionPlus = FALSE;
}

void GlyphExcellon::DrawFiducialOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList **pToolCodes, int nMode, BOOL bDrawSortIndex, BOOL bSelectMode, int nStartFidBlock, int m_nMaxFidBlock, double dScaleMin, double dScaleMax, BOOL bResult, int nPanelNo)
{
	int nPenSize = (int)(ceil(500 / dScale)); // 500um  ũ��
	nPenSize = max(nPenSize, 7);
	int nX, nY;
		
	CPoint npDis[2][MAX_FID_BLOCK][4]; 
	
	int nFidIndex[MAX_FID_BLOCK];

	memset(nFidIndex, 0, sizeof(nFidIndex));
	memset(npDis, 0, sizeof(npDis));

	LPFIDDATA pFidData;
	POSITION pos;

	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0;
	int nSortIndex;
	BOOL bFound = FALSE;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		bFound = m_FiducialData[DEFAULT_FID_INDEX].IsFidFound(nPanelNo, pFidData->npPosition);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y,
			nX, nY, dDrawStartX, dDrawStartY, dScale);


		if(gVariable.m_bShowSelectFidBlockOnly && gVariable.m_nSelectFidBlock != -1)
		{
			if(gVariable.m_nSelectFidBlock != pFidData->nFidBlock)
				continue;
		}


		//if(pFidData->nFidBlock != 0)
			//continue; //CheckCheck

		nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, m_nFidIndex);
		
		// 20130419 fiducial ������, block �� ���� �����ϱ� ����
		if( (pFidData->bSelected && ((pFidData->nFidType & FID_DRILL) || m_bShowSelectionFid)) || (m_nFidIndex != -1 && i == nSortIndex) )
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SELECTED_FID);
		}
		else if(IsSelectedFid(i) || IsUseFidInArea(i, FALSE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(50, 50, 255));
		}
		else if(IsUseFidInArea(i, TRUE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200));
		}
		else
		{
			if(FID_FILE_NOT_USE == pFidData->cType)
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(100, 0, 0)); // not use ������
				else
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200)); // not use
			}
			else
			{
				if(!bFound && nPanelNo != -1)
				{
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(225, 225, 225));
				}
				else
				{
					if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
						DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(255, 50, 50)); //(COLORREF)COLOR_REF_FID); // Ref fid
					else
					{
						if(pFidData->nFidBlock == 0)
						{
							if(pFidData->nFidType & FID_DRILL)
								DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SKIVING_FID);
							else if(pFidData->nFidType & FID_VERIFY)
								DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_VERFIY_FID);
							else if(pFidData->nFidType == FID_SECONDARY + FID_FIND)
								DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_COARSE_FID);
							else
								DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);

						}
						else
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);
					}
				}
			}
		}

		if(FID_FILE_NOT_USE != pFidData->cType)
		{
			for(int k = 0; k < m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount(); k++)
			{
				nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, k);
				if(nSortIndex == i)
				{
					CString strIndex;
					strIndex.GetBuffer(256);
					
						if(gVariable.m_bShowSelectFidBlockOnly && gVariable.m_nSelectFidBlock != -1)
						{
							if(pFidData->nFidType & FID_PRIMARY)
								strIndex.Format(_T("%s%d(B:%d)"),_T("P"), pFidData->nFindIndex+1, pFidData->nFidBlock);
							else if(pFidData->nFidType & FID_SECONDARY)
								strIndex.Format(_T("%s%d(B:%d)"),_T("S"), pFidData->nFindIndex+1, pFidData->nFidBlock);
						}
						else
						{
							if(pFidData->nFidType & FID_PRIMARY)
								strIndex.Format(_T("%s%d(B:%d)"),_T("P"), k+1, pFidData->nFidBlock);
							else if(pFidData->nFidType & FID_SECONDARY)
								strIndex.Format(_T("%s%d(B:%d)"),_T("S"), k+1, pFidData->nFidBlock);
						}



					strIndex.ReleaseBuffer();
					pDC->SetTextColor(RGB(255, 255, 255));
					pDC->SetBkColor(0x101010);
					pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, strIndex, NULL);
					if(nFidIndex[pFidData->nFidBlock] >= 0 && nFidIndex[pFidData->nFidBlock] < 4)
					{
						if(pFidData->nFidType& FID_FIND) 
						{
							npDis[0][pFidData->nFidBlock][nFidIndex[pFidData->nFidBlock]].x = nX;
							npDis[0][pFidData->nFidBlock][nFidIndex[pFidData->nFidBlock]++].y = nY;
						}
						else if(pFidData->nFidType & FID_DRILL)
						{
							npDis[1][pFidData->nFidBlock][nFidIndex[pFidData->nFidBlock]].x = nX;
							npDis[1][pFidData->nFidBlock][nFidIndex[pFidData->nFidBlock]++].y = nY;
						}
					}
					break;
				}
			}
		}
		i++;
	}
	
	CPen* pOldPen = NULL;
	nPenSize = 1;
	
	int nFidCount = 0;
	int nAddProperty = 0, nDelProperty = 0;
	int nTotal = 0;
	double dCenX = 0, dCenY = 0;
	CPoint npTemp[4];
	BOOL bExist[4];
	int nFidNo;
	for(int e = 0; e < 2 ; e ++)
	{
		if(e == 0)
		{
			 nAddProperty = FID_FIND;
			 nDelProperty = FID_VERIFY;
		}
		else
		{
			nAddProperty = FID_DRILL;
		}

		for(int i = nStartFidBlock; i <= m_nMaxFidBlock; i++)
		{

			nFidCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, i);
		
			CPen pen;
			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldPen);
				if(pen.m_hObject != NULL)
					pen.DeleteObject();
				pOldPen = NULL;
			}
			pen.CreatePen(PS_DASHDOTDOT, nPenSize, m_cColorFid[i]);

			pOldPen = pDC->SelectObject(&pen);

			//3  2 
			//0  1 
			nTotal = 0;
			dCenX = dCenY =  0; 
			for(int q = 0; q < nFidCount ; q++)
			{
				dCenX += npDis[e][i][q].x;
				dCenY += npDis[e][i][q].y;
				nTotal++;
			}
			if(nTotal > 0)
			{
				dCenX /= nTotal;
				dCenY /= nTotal;
			}
			memset(npTemp, 0 , sizeof(npTemp));
			memset(bExist, FALSE, sizeof(bExist));
			for(int j = 0; j< nFidCount; j++)
			{
				if(npDis[e][i][j].x < dCenX && npDis[e][i][j].y < dCenY)
				{
					bExist[0] = TRUE;
					npTemp[0] = npDis[e][i][j];
				}
				if(npDis[e][i][j].x > dCenX && npDis[e][i][j].y < dCenY)
				{
					bExist[1] = TRUE;
					npTemp[1] = npDis[e][i][j];
				}
				if(npDis[e][i][j].x < dCenX && npDis[e][i][j].y > dCenY)
				{
					bExist[3] = TRUE;
					npTemp[3] = npDis[e][i][j];
				}
				if(npDis[e][i][j].x > dCenX && npDis[e][i][j].y > dCenY)
				{
					bExist[2] = TRUE;
					npTemp[2] = npDis[e][i][j];
				}
			}
		
			nFidNo = 0;
			for(int k = 0; k < 4; k++)
			{
				if(!bExist[k])
					continue;

				pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, nFidNo++, nAddProperty, nDelProperty, i);

				if(bResult && pFidData)
				{

					LPFIDRESULT pResult = m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(nPanelNo, pFidData->npPosition, pFidData->nFidBlock);
					if(pResult == NULL)
						continue;

					GetXY(nMode, pResult->npScaleDPPos.x, pResult->npScaleDPPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);

					pDC->SetTextColor(RGB(0, 0, 0));
					pDC->SetBkColor(RGB(255, 255, 255));

					CString str;
					str.GetBuffer(256);

					if(pResult->dScale < dScaleMin ||
						pResult->dScale > dScaleMax )
					{
						pDC->SetTextColor(RGB(255, 50, 50));
						pDC->SetBkColor(RGB(255, 255, 255));

						if(fabs(pResult->dScale) < 200)
						{
							str.Format(_T("%3.2f%%"), pResult->dScale);
							pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, str, NULL);
						}
					}
					else
					{
						pDC->SetTextColor(m_cColorFid[i]);
						pDC->SetBkColor(RGB(255, 255, 255));

						if(fabs(pResult->dScale) < 200)
						{
							str.Format(_T("%3.2f%%"), pResult->dScale);
							pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, str, NULL);
						}
					}
					str.ReleaseBuffer();

					if(k == 3)
					{
						if(bExist[k] && bExist[0]) 
						{
							pDC->MoveTo(npTemp[k]);
							pDC->LineTo(npTemp[0]);
						}
					}
					else
					{
						if(bExist[k] && bExist[k+1]) 
						{
							pDC->MoveTo(npTemp[k]);
							pDC->LineTo(npTemp[k+1]);
						}
					}
				}
			}
			pen.DeleteObject();
		}
	}
	if (pOldPen != NULL)
	{
		pDC->SelectObject(pOldPen);
		pOldPen = NULL;
	}
	
}

void GlyphExcellon::Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawSortIndex)
{
	int nDrawEndX, nDrawEndY, nDrawStartX, nDrawStartY;
	int nPenSize, nOldPenSize, nCount;
	int nOldToolNo = -1;


	nDrawStartX = (int)dDrawStartX;
	nDrawStartY = (int)dDrawStartY;
	nDrawEndX = (int)(dDrawStartX + dScale * rc.Width());
	nDrawEndY = (int)(dDrawStartY - dScale * rc.Height());
	
	nPenSize = (int)(ceil(500 / dScale)); // 500um  ũ��
	nPenSize = max(nPenSize, 7);
	int nX, nY;

	// fiducial
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0, nSortIndex;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y,
			nX, nY, dDrawStartX, dDrawStartY, dScale);

	//	if(pFidData->nFidBlock != 0)//CheckCheck
		//	continue;

		nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, m_nFidIndex);
		
		// 20130419 fiducial ������, block �� ���� �����ϱ� ����
		if( (pFidData->bSelected && ((pFidData->nFidType & FID_DRILL) || m_bShowSelectionFid)) || (m_nFidIndex != -1 && i == nSortIndex) )
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SELECTED_FID);
		}
		else if(IsSelectedFid(i) || IsUseFidInArea(i, FALSE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(50, 50, 255));
		}
		else if(IsUseFidInArea(i, TRUE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200));
		}
		else
		{
			if(FID_FILE_NOT_USE == pFidData->cType)
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(100, 0, 0)); // not use ������
				else
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200)); // not use
			}
			else
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_REF_FID); // Ref fid
				else
				{
					if(pFidData->nFidBlock == 0)
					{
						if(pFidData->nFidType & FID_DRILL)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SKIVING_FID);
						else if(pFidData->nFidType & FID_VERIFY)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_VERFIY_FID);
						else if(pFidData->nFidType == FID_SECONDARY + FID_FIND)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_COARSE_FID);
						else
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);
							
					}
					else
						DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);
				}
			}
		}
		if(FID_FILE_NOT_USE != pFidData->cType)
		{
			for(int k = 0; k < m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount(); k++)
			{
				nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, k);
				if(nSortIndex == i)
				{
					CString strIndex;
					if(pFidData->nFidType & FID_PRIMARY)
						strIndex.Format(_T("%s%d(B:%d)"),_T("P"), k+1, pFidData->nFidBlock);
					else if(pFidData->nFidType & FID_SECONDARY)
						strIndex.Format(_T("%s%d(B:%d)"),_T("S"), k+1, pFidData->nFidBlock);
					pDC->SetTextColor(RGB(255, 255, 255));
					pDC->SetBkColor(0x101010);
					pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, strIndex, NULL);
					break;
				}
			}
		}
		i++;
	}

	i = 0;
	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y,
			nX, nY, dDrawStartX, dDrawStartY, dScale);
//		nX = static_cast<int>((m_FidData[ADDED_FID_INDEX].npPosition[i].x - dDrawStartX) / dScale);
//		nY = static_cast<int>((dDrawStartY - (m_FidData[ADDED_FID_INDEX].npPosition[i].y)) / dScale);

		nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if( (pFidData->bSelected && m_bShowSelectionFid) || (m_nFidIndex != -1 && i == nSortIndex) )
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 0, 0));
		}
		else if(IsSelectedFid(i) || IsUseFidInArea(i, FALSE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(50, 50, 255));
		}
		else if(IsUseFidInArea(i, TRUE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200));
		}
		else
		{
			if(FID_FILE_NOT_USE == pFidData->cType)
				DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(180, 180, 255)); // not use
			else
			{
				if(pFidData->bSelect)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 0, 0));
				else
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 100, 200));
			}
		}
		i++;
	}

	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor, OldColor = RGB(255, 255, 255);

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);

		pos = pUnit->m_HoleData.GetHeadPosition();
		LPHOLEDATA pData;

		nCount = 0;
		nOldPenSize = 1;
		
		while (pos) 
		{
			pData = pUnit->m_HoleData.GetNext(pos);

	//		if(pData->npPos.x == 93730 && pData->npPos.y == 270610)
	//		{
	//			int djhfskdj = 1;
	//		}
			
			if(!(*(pToolCodes + pData->nToolNo))->m_bVisible) // visible �ƴϸ�
			{
	//			nCount++;
				continue;
			}
			
		//	if(pData->nFidBlock != 0)//CheckCheck
			//	continue;
	
			nCount = rand();

			if(nCount % nSkipNo && pData->nBlockName2 == 0)
			{
				continue;;
			}
			if(!IsDrawData(nMode, pData->npPos.x, pData->npPos.y, nDrawStartX, nDrawStartY, nDrawEndX, nDrawEndY, pData->nBlockName2))
				continue;

			if(nOldToolNo != pData->nToolNo) // tool�� ���ϸ�
			{
				nCount = 0;
				nPenSize = (int)((*(pToolCodes + pData->nToolNo))->m_nToolSize/dScale) ;//(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pData->nToolNo;
			}


			
			if(!m_bShowSelectionFid)
			{
				pColor = GetRGB((*(pToolCodes + pData->nToolNo))->m_nToolColor);
			}
			else
			{
				if(pData->bSelect)
					pColor = RGB(0, 0, 0);
				else
					pColor = GetRGB((*(pToolCodes + pData->nToolNo))->m_nToolColor);
			}
			
			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}
			
			if(pData->nBlockName2 > 0)
				DisplayBlockDots(pDC, pData->npPos.x, pData->npPos.y,	pData->nBlockName2, pColor, nMode, dDrawStartX, dDrawStartY, nDrawEndX, nDrawEndY, dScale, nSkipNo);
			else
				
			{
				GetXY(nMode, pData->npPos.x, pData->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
				DisplayAreaDot(pDC, nX, nY,	pColor);
			}
		}

		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}

		// draw line
		pos = pUnit->m_LineData.GetHeadPosition();
		LPLINEDATA pLineData;
		
		while (pos) 
		{
			pLineData = pUnit->m_LineData.GetNext(pos);

			if(!(*(pToolCodes + pLineData->nToolNo))->m_bVisible) // visible �ƴϸ�
			{
				nCount++;
				continue;
			}
			
			GetXY(nMode, pLineData->npStartPos.x, pLineData->npStartPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//		nX = static_cast<int>((pLineData->npStartPos.x - dDrawStartX) / dScale);
	//		nY = static_cast<int>((dDrawStartY - (pLineData->npStartPos.y)) / dScale);
			
			if(nOldToolNo != pLineData->nToolNo) // tool�� ���ϸ�
			{
				nPenSize = (int)((*(pToolCodes + pLineData->nToolNo))->m_nToolSize/dScale) ;//(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pLineData->nToolNo;
			}
			
	//		if(pLineData->bSelect)
	//			pColor = RGB(0, 0, 0);
	//		else
				pColor = GetRGB((*(pToolCodes + pLineData->nToolNo))->m_nToolColor);

			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}
			
			pDC->MoveTo(nX, nY);

			GetXY(nMode, pLineData->npEndPos.x, pLineData->npEndPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//		nX = static_cast<int>((pLineData->npEndPos.x - dDrawStartX) / dScale);
	//		nY = static_cast<int>((dDrawStartY - (pLineData->npEndPos.y)) / dScale);
			pDC->LineTo(nX, nY);
		}
		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}
}

void GlyphExcellon::DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawSortIndex)
{	
	int nDrawEndX, nDrawEndY, nDrawStartX, nDrawStartY;
	int nPenSize, nOldPenSize;
	int nOldToolNo = -1;

	nDrawStartX = (int)dDrawStartX;
	nDrawStartY = (int)dDrawStartY;
	nDrawEndX = (int)(dDrawStartX + dScale * rc.Width());
	nDrawEndY = (int)(dDrawStartY - dScale * rc.Height());
	
	nPenSize = (int)(ceil(500 / dScale)); // 500um  ũ��
	nPenSize = max(nPenSize, 7);
	int nX, nY;

	// fiducial
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0, nSortIndex;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y,
			nX, nY, dDrawStartX, dDrawStartY, dScale);

		nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, m_nFidIndex);
		
		// 20130419 fiducial ������, block �� ���� �����ϱ� ����
		if( (pFidData->bSelected && ((pFidData->nFidType & FID_DRILL) || m_bShowSelectionFid)) || (m_nFidIndex != -1 && i == nSortIndex) )
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SELECTED_FID);
		}
		else if(IsSelectedFid(i) || IsUseFidInArea(i, FALSE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(50, 50, 255));
		}
		else if(IsUseFidInArea(i, TRUE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200));
		}
		else
		{
			if(FID_FILE_NOT_USE == pFidData->cType)
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(100, 0, 0)); // not use ������
				else
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200)); // not use
			}
			else
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_REF_FID); // Ref fid
				else
				{
					if(pFidData->nFidBlock == 0)
					{
						if(pFidData->nFidType & FID_DRILL)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_SKIVING_FID);
						else if(pFidData->nFidType & FID_VERIFY)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_VERFIY_FID);
						else if(pFidData->nFidType == FID_SECONDARY + FID_FIND)
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, (COLORREF)COLOR_COARSE_FID);
						else
							DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);
							
					}
					else
						DisplayAreaEllipse(pDC, nX, nY, nPenSize, m_cColorFid[pFidData->nFidBlock]);
				}
			}
		}
		if(FID_FILE_NOT_USE != pFidData->cType)
		{
			for(int k = 0; k < m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount(); k++)
			{
				nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, k);
				if(nSortIndex == i)
				{
					CString strIndex;
					if(pFidData->nFidType & FID_PRIMARY)
						strIndex.Format(_T("%s%d(B:%d)"),_T("P"), k+1, pFidData->nFidBlock);
					else if(pFidData->nFidType & FID_SECONDARY)
						strIndex.Format(_T("%s%d(B:%d)"),_T("S"), k+1, pFidData->nFidBlock);
					pDC->SetTextColor(RGB(255, 255, 255));
					pDC->SetBkColor(0x101010);
					pDC->ExtTextOut( nX, nY, ETO_CLIPPED, NULL, strIndex, NULL);
					break;
				}
			}
		}
		i++;
	}

	i = 0;
	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y,
			nX, nY, dDrawStartX, dDrawStartY, dScale);
		
		nSortIndex = GetUseFidRealIndex(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if( (pFidData->bSelected && m_bShowSelectionFid) || (m_nFidIndex != -1 && i == nSortIndex) )
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 0, 0));
		}
		else if(IsSelectedFid(i) || IsUseFidInArea(i, FALSE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(50, 50, 255));
		}
		else if(IsUseFidInArea(i, TRUE))
		{
			DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(200, 200, 200));
		}
		else
		{
			if(FID_FILE_NOT_USE == pFidData->cType)
				DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(180, 180, 255)); // not use
			else
			{
				if(pFidData->bSelect)
					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 0, 0));
//				else
//					DisplayAreaEllipse(pDC, nX, nY, nPenSize, RGB(0, 100, 200));
			}
		}
		i++;
	}

	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor, OldColor = RGB(255, 255, 255);

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		pos = pUnit->m_HoleData.GetHeadPosition();
		LPHOLEDATA pData;

		nOldPenSize = 1;
		
		while (pos) 
		{
			pData = pUnit->m_HoleData.GetNext(pos);

			if(!(*(pToolCodes + pData->nToolNo))->m_bVisible) // || pData->bSelect == FALSE) // visible �ƴϸ�
			{
				continue;
			}

			if(nOldToolNo != pData->nToolNo) // tool�� ���ϸ�
			{
				nPenSize = (int)((*(pToolCodes + pData->nToolNo))->m_nToolSize/dScale) ;//(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pData->nToolNo;
			}

			if(!IsDrawData(nMode, pData->npPos.x, pData->npPos.y, nDrawStartX, nDrawStartY, nDrawEndX, nDrawEndY, pData->nBlockName2))
				continue;

			GetXY(nMode, pData->npPos.x, pData->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//		nX = static_cast<int>((pData->npPos.x - dDrawStartX) / dScale);
	//		nY = static_cast<int>((dDrawStartY - (pData->npPos.y)) / dScale);

	//		if(pData->bSelect)
	//			pColor = RGB(0, 0, 0);
	//		else
				pColor = GetRGB((*(pToolCodes + pData->nToolNo))->m_nToolColor);
			
			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}

			if(pData->nBlockName2 > 0)
				DisplayBlockDots(pDC, pData->npPos.x, pData->npPos.y,	pData->nBlockName2, pColor, nMode, dDrawStartX, dDrawStartY, nDrawEndX, nDrawEndY, dScale, 1);
			else
			{
				GetXY(nMode, pData->npPos.x, pData->npPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
		
				DisplayAreaDot(pDC, nX, nY,	pColor);
			}
		}

		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}

		// draw line
		pos = pUnit->m_LineData.GetHeadPosition();
		LPLINEDATA pLineData;
		
		while (pos) 
		{
			pLineData = pUnit->m_LineData.GetNext(pos);

			if(!(*(pToolCodes + pLineData->nToolNo))->m_bVisible) // || pLineData->bSelect == FALSE) // visible �ƴϸ�
			{
				continue;
			}
			
			GetXY(nMode, pLineData->npStartPos.x, pLineData->npStartPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//		nX = static_cast<int>((pLineData->npStartPos.x - dDrawStartX) / dScale);
	//		nY = static_cast<int>((dDrawStartY - (pLineData->npStartPos.y)) / dScale);
			
			if(nOldToolNo != pLineData->nToolNo) // tool�� ���ϸ�
			{
				nPenSize = (int)((*(pToolCodes + pLineData->nToolNo))->m_nToolSize/dScale) ;//(int)(ceil(100 / dScale)); // 500um  ũ��
				nPenSize = max(nPenSize, 3);
				nOldToolNo = pLineData->nToolNo;
			}
			
	//		if(pLineData->bSelect)
	//			pColor = RGB(0, 0, 0);
	//		else
				pColor = GetRGB((*(pToolCodes + pLineData->nToolNo))->m_nToolColor);

			if (OldColor != pColor || nOldPenSize != nPenSize)
			{
				if (pOldPen != NULL)
				{
					pDC->SelectObject(pOldPen);
					pen.DeleteObject();
					pOldPen = NULL;
				}
				pen.CreatePen(PS_SOLID, nPenSize, pColor);
				pOldPen = pDC->SelectObject(&pen);
				nOldPenSize = nPenSize;
				OldColor = pColor;
			}
			
			pDC->MoveTo(nX, nY);

			GetXY(nMode, pLineData->npEndPos.x, pLineData->npEndPos.y, nX, nY, dDrawStartX, dDrawStartY, dScale);
	//		nX = static_cast<int>((pLineData->npEndPos.x - dDrawStartX) / dScale);
	//		nY = static_cast<int>((dDrawStartY - (pLineData->npEndPos.y)) / dScale);
			pDC->LineTo(nX, nY);
		}
		if (pOldPen != NULL)
		{
			pDC->SelectObject(pOldPen);
			pen.DeleteObject();
			pOldPen = NULL;
		}
	}
}

void GlyphExcellon::DisplayAreaEllipse(CDC *pDC, int x, int y, int nSize, COLORREF pColor)
{
	CPen cFidPen(PS_SOLID, nSize, pColor);
	CPen* pOldPen = pDC->SelectObject(&cFidPen);
	pDC->Ellipse(x - nSize, y - nSize, x + nSize, y + nSize);
	pDC->SelectObject(pOldPen);
}

void GlyphExcellon::DisplayAreaDot(CDC *pDC, int x, int y, COLORREF pColor)
{
	pDC->MoveTo(x, y);
	pDC->LineTo(x, y);
}

BOOL GlyphExcellon::IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->IsSelect(point, nTolerence, pToolCodes, bSelectOnlyView))
			return TRUE;
	}
	return FALSE;
}
BOOL GlyphExcellon::IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->IsSelect(point1, point2, pToolCodes, bSelectOnlyView))
		{
			pUnit->SetSelect();
		}
	}
	return FALSE;
}

int GlyphExcellon::SelectData(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	int nSelectionHole = 0, nSelectionFid = 0;
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->SelectData(point1, point2, pToolCodes, bSelectOnlyView))//, m_bSelectionPlus))
		{
			nSelectionHole++;
		}
	}

	LPFIDDATA pFidData;
	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		if(point1.x <= pFidData->npPosition.x && pFidData->npPosition.x <= point2.x &&
			point1.y <= pFidData->npPosition.y && pFidData->npPosition.y <= point2.y)
		{
			if(pFidData->bSelected) // && !m_bSelectionPlus) // bSelectionPlus�� ������� ������Ų�� (���� �ʿ��ϸ� �ּ� Ǯ��)
				pFidData->bSelected = FALSE;
			else
			{
				nSelectionFid++;
				pFidData->bSelected = TRUE;
			}
		}
//		else
//		{
//			if(!m_bSelectionPlus)
//				pFidData->bSelected = FALSE;
//		}
	}

	pos = m_Units.GetHeadPosition();
	pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->IsAnySelectedData(pToolCodes, bSelectOnlyView)) // ���õ� �����Ͱ� �ִ��� Ȯ��
		{
			nSelectionHole++;
			break;
		}
	}
	
	if(nSelectionHole == 0 && nSelectionFid == 0)// && !m_bSelectionPlus)
		return -1;
	else if(nSelectionHole == 0 && nSelectionFid > 0)
		return 0;
	else if(nSelectionHole > 0 && nSelectionFid == 0)
		return 1;
	else
		return 2;
}
void GlyphExcellon::Flip(BOOL bX)
{
//	if(!m_bSelect)
//		return;
	if(bX)
	{
		LPFIDDATA pFidData;
		POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
			pFidData->npPosition.x = m_nMaxX + m_nMinX - pFidData->npPosition.x;
		}

		pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
			pFidData->npPosition.x = m_nMaxX + m_nMinX - pFidData->npPosition.x;
		}
	}
	else
	{
		LPFIDDATA pFidData;
		POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
			pFidData->npPosition.y = m_nMaxY + m_nMinY - pFidData->npPosition.y;
		}
		
		pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
			pFidData->npPosition.y = m_nMaxY + m_nMinY - pFidData->npPosition.y;
		}
	}

	SortFiducial(DEFAULT_FID_INDEX);
	SortFiducial(ADDED_FID_INDEX);
	
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->Flip(bX, m_nMinX, m_nMaxX, m_nMinY, m_nMaxY);
	}

	LPDBLOCK pBlock;
	pos = m_Blocks.GetHeadPosition();
	while (pos) 
	{
		pBlock = m_Blocks.GetNext(pos);
		pBlock->Flip(bX, m_nMinX, m_nMaxX, m_nMinY, m_nMaxY);
	}
}

void GlyphExcellon::Rotate(double dDeg)
{
//	if(!m_bSelect)
//		return;

	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->Rotate(dDeg, m_nMinX, m_nMaxX, m_nMinY, m_nMaxY);
	}

	LPDBLOCK pBlock;
	pos = m_Blocks.GetHeadPosition();
	while (pos) 
	{
		pBlock = m_Blocks.GetNext(pos);
		pBlock->Rotate(dDeg, m_nMinX, m_nMaxX, m_nMinY, m_nMaxY);
	}
	
	CPoint nCenterP;
	int nX;
	double cosTheta, sinTheta;
	
	nCenterP.x = (m_nMaxX + m_nMinX) / 2;
	nCenterP.y = (m_nMaxY + m_nMinY) / 2;
	
	dDeg = dDeg * M_PI / 180; // deg to rad
	cosTheta = cos(dDeg);
	sinTheta = sin(dDeg);
	
	// fiducial
	LPFIDDATA pFidData;
	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		nX = (int)(cosTheta*(pFidData->npPosition.x - nCenterP.x) - sinTheta*(pFidData->npPosition.y - nCenterP.y) + nCenterP.x);
		pFidData->npPosition.y = (int)(sinTheta*(pFidData->npPosition.x - nCenterP.x) + cosTheta*(pFidData->npPosition.y - nCenterP.y) + nCenterP.y);
		pFidData->npPosition.x = nX;

		if(m_nMaxX < pFidData->npPosition.x) m_nMaxX = pFidData->npPosition.x;
		if(m_nMinX > pFidData->npPosition.x) m_nMinX = pFidData->npPosition.x;
		if(m_nMaxY < pFidData->npPosition.y) m_nMaxY = pFidData->npPosition.y;
		if(m_nMinY > pFidData->npPosition.y) m_nMinY = pFidData->npPosition.y;
	}

	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		nX = (int)(cosTheta*(pFidData->npPosition.x - nCenterP.x) - sinTheta*(pFidData->npPosition.y - nCenterP.y) + nCenterP.x);
		pFidData->npPosition.y = (int)(sinTheta*(pFidData->npPosition.x - nCenterP.x) + cosTheta*(pFidData->npPosition.y - nCenterP.y) + nCenterP.y);
		pFidData->npPosition.x = nX;
		
		if(m_nMaxX < pFidData->npPosition.x) m_nMaxX = pFidData->npPosition.x;
		if(m_nMinX > pFidData->npPosition.x) m_nMinX = pFidData->npPosition.x;
		if(m_nMaxY < pFidData->npPosition.y) m_nMaxY = pFidData->npPosition.y;
		if(m_nMinY > pFidData->npPosition.y) m_nMinY = pFidData->npPosition.y;
	}

	SortFiducial(DEFAULT_FID_INDEX);
	SortFiducial(ADDED_FID_INDEX);
}

BOOL GlyphExcellon::IsFidHoleGet(BOOL &bFidList, CPoint& pt, int nTolerence, BOOL &bSkiving)
{
	// fiducial
	bSkiving = FALSE;
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
			continue;
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE)
				bFidList = FALSE;
			else
				bFidList = TRUE;

			pt = pFidData->npPosition;
			return TRUE;
		}
	}
	
	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);

		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
			continue;
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE)
				bFidList = FALSE;
			else
				bFidList = TRUE;
			
			bSkiving = TRUE;
			pt = pFidData->npPosition;
			return TRUE;
		}
	}

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		LPHOLEDATA pHole;
		pos = pUnit->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pUnit->m_HoleData.GetNext(pos);
			
			if (pt.x < pHole->npPos.x - nTolerence ||
				pt.x > pHole->npPos.x + nTolerence ||
				pt.y < pHole->npPos.y - nTolerence ||
				pt.y > pHole->npPos.y + nTolerence)
				continue;
			else
			{
				bFidList = FALSE;
				//return TRUE;//20161122

				pt = pHole->npPos;
				return TRUE;//20161122
			}
		}
	}
	return FALSE;
}

BOOL GlyphExcellon::AddFiducial(CPoint pt, int nTolerence, int nFidKind)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	POSITION pos2;
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);

		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
			continue;
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
			{
				pFidData->cType = FID_FILE_USE;
				SortFiducial(nFidKind);
				return TRUE;
			}
		}
	}

	if(DEFAULT_FID_INDEX != nFidKind) // skiving
		return FALSE;

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
	
		LPHOLEDATA pHole;
		pos = pUnit->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pUnit->m_HoleData.GetNext(pos);
			
			
			if (pt.x < pHole->npPos.x - nTolerence ||
				pt.x > pHole->npPos.x + nTolerence ||
				pt.y < pHole->npPos.y - nTolerence ||
				pt.y > pHole->npPos.y + nTolerence)
				continue;
			else
			{
				pFidData = NULL;
				pos2 = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
				while(pos2)
				{
					pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos2);
					if(pFidData->cType == FID_FILE_NOT_USE)
						break;
					else
						pFidData = NULL;
				}
				if(pFidData == NULL)
				{
					pFidData = new FID_DATA;
					memset(pFidData, 0, sizeof(FID_DATA));
					pFidData->cType = FID_FILE_USE;
					pFidData->npPosition = pHole->npPos;
					pFidData->nFindIndex = m_FiducialData[nFidKind].m_PositionData.GetCount();
					m_FiducialData[nFidKind].AddFidData(pFidData);
				}
				else
				{
					pFidData->cType = FID_FILE_USE;
					pFidData->npPosition = pHole->npPos;
				}

				SortFiducial(nFidKind);
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL GlyphExcellon::AddRandomFiducial(CPoint pt)
{
	LPFIDDATA pFidData;
	pFidData = new FID_DATA;
	memset(pFidData, 0, sizeof(FID_DATA));
	pFidData->cType = FID_FILE_USE;
	pFidData->npPosition = pt;
	pFidData->nFindIndex = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount();
	m_FiducialData[DEFAULT_FID_INDEX].AddFidData(pFidData);
	SortFiducial(DEFAULT_FID_INDEX);

	return TRUE;
}

BOOL GlyphExcellon::AddSubFiducial(CPoint pt)
{
	LPFIDDATA pFidData;
	pFidData = new FID_DATA;
	memset(pFidData, 0, sizeof(FID_DATA));
	pFidData->cType = FID_FILE_USE;
	pFidData->npPosition = pt;
	pFidData->nFindIndex = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount();
	m_FiducialData[DEFAULT_FID_INDEX].AddFidData(pFidData);
	SortFiducial(DEFAULT_FID_INDEX);

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int* pIndex;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			pIndex = new int;
			*pIndex = m_FiducialData[DEFAULT_FID_INDEX].nRef - 1;
			pUnit->m_SubFidIndexData.AddTail(pIndex);
		}
	}
	
	return TRUE;
}

BOOL GlyphExcellon::DelFiducial(CPoint pt, int nTolerence)
{
	int nCount = 0, nCount2 = 0;
	LPFIDDATA pFidData;
	int nFidType;

	int i = 0;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
		{
			i++;
			continue;
		}
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
				continue;
			else if(pFidData->cType == FID_FILE_USE) // file open origin fid
			{
				if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i) // ref fiducial ���� ����
					return FALSE;
				nFidType = pFidData->nFidType;
				break;
			}
		}
	}

	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE && nFidType == pFidData->nFidType) // ���� type �� ����
			nCount++;
	}

	if(nCount > 2 || nFidType & FID_VERIFY) // fiducial �ּ� 2���� �׻� �־����. or verify�� ������ ���� ����
	{
		int i = 0;
		pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
			if (pt.x < pFidData->npPosition.x - nTolerence ||
				pt.x > pFidData->npPosition.x + nTolerence ||
				pt.y < pFidData->npPosition.y - nTolerence ||
				pt.y > pFidData->npPosition.y + nTolerence)
			{
				i++;
				continue;
			}
			else
			{
				if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
					continue;
				else if(pFidData->cType == FID_FILE_USE) // file open origin fid
				{
					if(m_FiducialData[DEFAULT_FID_INDEX].nRef == i) // ref fiducial ���� ����
						return FALSE;
					
					pFidData->cType = FID_FILE_NOT_USE;
					RemoveAllSubFiducial(i);
					SortFiducial(DEFAULT_FID_INDEX);					
					return TRUE;
				}
			}
			i++;
		}
	}
	
/*	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE)
			nCount2++;
	}

	if(nCount2 > 2) // fiducial �ּ� 2���� �׻� �־����.
	{
		pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
			if (pt.x < pFidData->npPosition.x - nTolerence ||
				pt.x > pFidData->npPosition.x + nTolerence ||
				pt.y < pFidData->npPosition.y - nTolerence ||
				pt.y > pFidData->npPosition.y + nTolerence)
				continue;
			else
			{
				if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
					continue;
				else if(pFidData->cType == FID_FILE_USE) // file open origin fid
				{
					pFidData->cType = FID_FILE_NOT_USE;
					SortFiducial(ADDED_FID_INDEX);
					return TRUE;
				}
			}
		}
	}
*/	return FALSE;
}

BOOL GlyphExcellon::SetRefFidLeftBottom(int nAxisMode)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	
	int nCount = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount();

	double dFidX[MAX_FIDUCIAL], dFidY[MAX_FIDUCIAL];
	for(int i = 0; i < MAX_FIDUCIAL; i++)
	{
		dFidX[i] = dFidY[i] = DBL_MAX;
	}



	int CountPrj = 0;
	int nFirst = 0;

	int i = 0;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		if(pFidData->cType != FID_FILE_NOT_USE)
		{


			if(pFidData->nFidType & FID_PRIMARY)
			{
				nFirst = i;
				CountPrj++;
			}

			if(nAxisMode == X_Y)
			{
				dFidX[i] = pFidData->npPosition.x;
				dFidY[i++] = pFidData->npPosition.y;
			}
			else if(nAxisMode == MX_Y)
			{
				dFidX[i] = pFidData->npPosition.x * (-1);
				dFidY[i++] = pFidData->npPosition.y;
			}
			else if(nAxisMode == X_MY)
			{
				dFidX[i] = pFidData->npPosition.x;
				dFidY[i++] = pFidData->npPosition.y * (-1);
			}
			else if(nAxisMode == MX_MY)
			{
				dFidX[i] = pFidData->npPosition.x * (-1);
				dFidY[i++] = pFidData->npPosition.y * (-1);
			}
			else if(nAxisMode == Y_X)
			{
				dFidX[i] = pFidData->npPosition.y;
				dFidY[i++] = pFidData->npPosition.x;
			}
			else if(nAxisMode == MY_X)
			{
				dFidX[i] = pFidData->npPosition.y * (-1);
				dFidY[i++] = pFidData->npPosition.x;
			}
			else if(nAxisMode == Y_MX)
			{
				dFidX[i] = pFidData->npPosition.y;
				dFidY[i++] = pFidData->npPosition.x * (-1);
			}
			else
			{
				dFidX[i] = pFidData->npPosition.y * (-1);
				dFidY[i++] = pFidData->npPosition.x * (-1);
			}
		}
	}

	double dCenterX, dCenterY;
	double dMaxX = -DBL_MAX, dMaxY = -DBL_MAX, dMinX = DBL_MAX, dMinY = DBL_MAX;

	for(int j=0; j<nCount; j++)
	{
		if(dFidX[j] > dMaxX)
			dMaxX = dFidX[j];

		if(dFidY[j] > dMaxY)
			dMaxY = dFidY[j];

		if(dFidX[j] < dMinX)
			dMinX = dFidX[j];

		if(dFidY[j] < dMinY)
			dMinY = dFidY[j];
	}

	int nIndex = 0;

	dCenterX = (dMaxX + dMinX) / 2.0;
	dCenterY = (dMaxY + dMinY) / 2.0;

	for(int j=0; j<nCount; j++)
	{
		if(dFidX[j] < dCenterX && dFidY[j] < dCenterY)
		{
			nIndex = j;
			break;
		}
	}
	if(CountPrj >= 3)
	    m_FiducialData[DEFAULT_FID_INDEX].nRef = nIndex;
	else
		m_FiducialData[DEFAULT_FID_INDEX].nRef = nFirst;
		

	SortFiducial(DEFAULT_FID_INDEX);

	return FALSE;
}

void GlyphExcellon::ApplyManualScale(CDPoint dManualScale)
{

	POSITION pos;
	CDPoint dPoint[100];
	CDPoint dCenter;
	CDPoint dTrans[100];


	LPFIDDATA pFidData;
	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();

	dCenter.x = 0;
	dCenter.y = 0;

	int nCount = 0;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		if(pFidData->nFidBlock == 0 && !(pFidData->nFidType & FID_DRILL))
		{
			dPoint[nCount].x = pFidData->npPosition.x;
			dPoint[nCount].y = pFidData->npPosition.y;

			TRACE("%d %d %d \n",nCount,pFidData->npPosition.x,pFidData->npPosition.y);

			dCenter.x += pFidData->npPosition.x;
			dCenter.y += pFidData->npPosition.y;
			nCount++;
		}
	}

	if(nCount != 4)
		return;

	dCenter.x /= 4.0; 
	dCenter.y /= 4.0; 

	TRACE("Average: %.3f, %.3f\n",dCenter.x,dCenter.y);



	C2DTransform m_Trans;
	m_Trans.SetNumPoint(4);

	for(int i = 0; i < 4; i++)
	{
		dTrans[i].x = dCenter.x - ((dCenter.x - dPoint[i].x) * dManualScale.x /100.);
		dTrans[i].y = dCenter.y - ((dCenter.y - dPoint[i].y) * dManualScale.y /100.);

		//TRACE("Trans: %.3f, %.3f Origin: %.3f, %.3f\n",dTrans[i].x,dTrans[i].y,dPoint[i].x,dPoint[i].y);

		m_Trans.SetReferencePoint( dPoint[i].x , dPoint[i].y , i);
		m_Trans.SetTransformedPoint( dTrans[i].x , dTrans[i].y , i);
	}
	m_Trans.Transform();



	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();


	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		double dResultX = 0;
		double dResultY = 0;

		m_Trans.TransformPoint((double)pFidData->npPosition.x, (double)pFidData->npPosition.y, dResultX, dResultY);

		//	TRACE("Trans: %.3f, %.3f Origin: %d, %d\n",dResultX,dResultY,pFidData->npPosition.x,pFidData->npPosition.y);

		pFidData->npPosition.x = (int)dResultX;
		pFidData->npPosition.y = (int)dResultY;

		int nX = (int)dResultX;
		int nY = (int)dResultY;
		if(nX > m_nMaxX)
			m_nMaxX = nX;
		if(nX < m_nMinX)
			m_nMinX = nX;	
		if(nY > m_nMaxY)
			m_nMaxY = nY;
		if(nY < m_nMinY)
			m_nMinY = nY;

	}


	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();


	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);

		double dResultX = 0;
		double dResultY = 0;

		m_Trans.TransformPoint((double)pFidData->npPosition.x, (double)pFidData->npPosition.y, dResultX, dResultY);

		//	TRACE("Trans: %.3f, %.3f Origin: %d, %d\n",dResultX,dResultY,pFidData->npPosition.x,pFidData->npPosition.y);

		pFidData->npPosition.x = (int)dResultX;
		pFidData->npPosition.y = (int)dResultY;


		int nX = (int)dResultX;
		int nY = (int)dResultY;
		if(nX > m_nMaxX)
			m_nMaxX = nX;
		if(nX < m_nMinX)
			m_nMinX = nX;	
		if(nY > m_nMaxY)
			m_nMaxY = nY;
		if(nY < m_nMinY)
			m_nMinY = nY;
	}


	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		LPHOLEDATA pHole;
		pos = pUnit->m_HoleData.GetHeadPosition();

		while (pos) 
		{
			pHole = pUnit->m_HoleData.GetNext(pos);

			double dResultX = 0;
			double dResultY = 0;

			m_Trans.TransformPoint((double)pHole->npPos.x, (double)pHole->npPos.y, dResultX, dResultY);

			//TRACE("Trans: %.3f, %.3f Origin: %d, %d\n",dResultX,dResultY,pHole->npPos.x,pHole->npPos.y);

			pHole->npPos.x = (int)dResultX;
			pHole->npPos.y = (int)dResultY;


			int nX = (int)dResultX;
			int nY = (int)dResultY;
			if(nX > m_nMaxX)
				m_nMaxX = nX;
			if(nX < m_nMinX)
				m_nMinX = nX;	
			if(nY > m_nMaxY)
				m_nMaxY = nY;
			if(nY < m_nMinY)
				m_nMinY = nY;
		}
	}

}

BOOL GlyphExcellon::OnSetRefFid(CPoint pt, int nTolerence)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
		{
			i++;
			continue;
		}
		else
		{
			if(pFidData->cType != FID_FILE_NOT_USE && !(pFidData->nFidType & FID_SECONDARY)) // ������ ���̸�
			{
				m_FiducialData[DEFAULT_FID_INDEX].nRef = i;
				SortFiducial(DEFAULT_FID_INDEX);
				return TRUE;
			}
		}
		i++;
	}
	return FALSE;
}

int GlyphExcellon::GetFiducialIndex(CPoint pt, int nTolerance)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (pt.x < pFidData->npPosition.x - nTolerance ||
			pt.x > pFidData->npPosition.x + nTolerance ||
			pt.y < pFidData->npPosition.y - nTolerance ||
			pt.y > pFidData->npPosition.y + nTolerance)
			continue;
		else
		{
			if(pFidData->cType != FID_FILE_NOT_USE) // ������ ���̸�
			{
				return i;
			}
		}
		i++;
	}
	return -1;
}

void GlyphExcellon::SetDisplayFidIndex(int nIndex, BOOL bClear)
{

}

int GlyphExcellon::GetFidCount(int nFidKind)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return 0;

	return m_FiducialData[nFidKind].m_PositionData.GetCount();
}

CPoint GlyphExcellon::GetFidPoint(int nFidKind, int nIndex)
{
	CPoint pt(0,0);

	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return pt;


	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		if(i == nIndex)
		{
			pt.x = pFidData->npPosition.x;
			pt.y = pFidData->npPosition.y;
			return pt;
		}
		i++;
	}
	return pt;
}

int GlyphExcellon::GetUseFidCount(int nFidKind, int nFidRank)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return 0;
	
	int nCount = 0;
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);

		if(nFidRank == 0)
		{
			if(pFidData->cType != FID_FILE_NOT_USE)
				nCount++;
		}
		else
		{
			if(pFidData->cType != FID_FILE_NOT_USE && (pFidData->nFidType & nFidRank) && !(pFidData->nFidType & FID_VERIFY))
				nCount++;
		}
	}

	return nCount;
}

CPoint GlyphExcellon::GetUseFidIntPoint(int nFidKind, int nIndex)
{
	CPoint pt(0,0);
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return pt;

	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return pt;
	
	nIndex = pFidData->nFindIndex; // sorted data
	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	if(pFidData == NULL)
		return pt;

	pt.x = pFidData->npPosition.x;
	pt.y = pFidData->npPosition.y;
	return pt;
}

CPoint GlyphExcellon::GetFidIntPoint(int nFidKind, int nIndex)
{
	CPoint pt(0,0);
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return pt;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return pt;
	
	pt.x = pFidData->npPosition.x;
	pt.y = pFidData->npPosition.y;
	return pt;
}

int GlyphExcellon::GetUseFidFindStatus(int nFidKind, int nIndex)
{
	int nVal = 0;
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return nVal;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return nVal;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return nVal;
	
	return pFidData->bCheckIndex;
}
int GlyphExcellon::GetFidBlockStatus(int nFidKind, int nIndex)
{
	int nVal = 0;
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return nVal;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return nVal;
	
	return pFidData->nFidBlock;
}
int GlyphExcellon::GetFidFindStatus(int nFidKind, int nIndex)
{
	int nVal = 0;
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return nVal;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return nVal;
	
	return pFidData->bCheckIndex;
}

BOOL GlyphExcellon::SortFiducial4UnderPrimary(int nFidKind, int nCountPrimary, int nCountSecondary)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return FALSE;

	LPFIDDATA pFidData;
	POSITION pos;
	
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE)
		{
			if(pFidData->nFidType & FID_PRIMARY)
			{
				m_FiducialData[nFidKind].AddFidData(pFidData);
			}
		}
	}
	return TRUE;
}

BOOL GlyphExcellon::SortFiducial4UnderSecondary(int nFidKind, int nCountPrimary, int nCountSecondary)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return FALSE;

	int nDifferX, nDifferY;
	double dDiffer, dDifferOld = DBL_MAX;
	LPFIDDATA pFidData, pFidDataPrimary, pSecondStartFidData = NULL;
	POSITION pos;

	pos = m_FiducialData[nFidKind].m_PositionData.GetTailPosition();
	if(pos)
		pFidDataPrimary = m_FiducialData[nFidKind].m_PositionData.GetPrev(pos);
	else
	{
		pos = m_CopyFidData.m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
			if(pFidData->cType != FID_FILE_NOT_USE)
			{
				if(pFidData->nFidType & FID_SECONDARY)
				{
					m_FiducialData[nFidKind].AddFidData(pFidData);
				}
			}
		}
		return TRUE;
	}
	
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->nFidType & FID_SECONDARY)
		{
			nDifferX = abs(pFidDataPrimary->npPosition.x - pFidData->npPosition.x) / 1000;
			nDifferY = abs(pFidDataPrimary->npPosition.y - pFidData->npPosition.y) / 1000;
			
			dDiffer = sqrt((double)((nDifferX*nDifferX) + (nDifferY*nDifferY)));
			
			if(dDiffer < dDifferOld)
			{
				pSecondStartFidData = pFidData;
				dDifferOld = dDiffer;
			}
		}
	}

	if(pSecondStartFidData)
		m_FiducialData[nFidKind].AddFidData(pSecondStartFidData);

	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE)
		{
			if(pFidData->nFidType & FID_SECONDARY && pFidData != pSecondStartFidData)
			{
				m_FiducialData[nFidKind].AddFidData(pFidData);
			}
		}
	}
	return TRUE;
}

BOOL GlyphExcellon::SortFiducial(int nFidKind)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return FALSE;
	
	int nCount = 0;
	int nCountPri = 0;
	BOOL bUsePrimary = FALSE;
	int nCountSec = 0;
	BOOL bUseSecondary = FALSE;
	LPFIDDATA pFidData;

	m_CopyFidData.m_PositionData.RemoveAll();
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		m_CopyFidData.AddFidData(pFidData);
		if(pFidData->cType != FID_FILE_NOT_USE)
		{
			nCount++;
			if(pFidData->nFidType & FID_PRIMARY)
			{
				nCountPri++;
				bUsePrimary = TRUE;
			}
			else if(pFidData->nFidType & FID_SECONDARY)
			{
				nCountSec++;
				bUseSecondary = TRUE;
			}
		}
	}

	m_FiducialData[nFidKind].m_PositionData.RemoveAll();
  	for(int nSortCnt = 0; nSortCnt < 2; nSortCnt++)
	{
		int nEachCnt = 0;
		BOOL bPrimarySorting = FALSE;
		BOOL bSecondarySorting = FALSE;
		if(nSortCnt == 0 && bUsePrimary)	// nSortCnt �� 0�̰� bUsePrimary �̸� Primary sorting
		{
			bPrimarySorting = TRUE;
			bSecondarySorting = FALSE;
			nEachCnt = nCountPri;
			if(nEachCnt < 2)
			{
				pos = m_CopyFidData.m_PositionData.GetHeadPosition();
				while(pos)
				{
					pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
					if(pFidData->cType != FID_FILE_NOT_USE && (pFidData->nFidType & FID_PRIMARY))
						m_FiducialData[nFidKind].AddFidData(pFidData);
				}
			}
		}
		else if(nSortCnt == 1 && bUseSecondary)	//nSortCnt �� 1�̰� bUseSecondary �̸� Secondary sorting
		{
			bPrimarySorting = FALSE;
			bSecondarySorting = TRUE;
			nEachCnt = nCountSec;
			if(nEachCnt < 2)
			{
				pos = m_CopyFidData.m_PositionData.GetHeadPosition();
				while(pos)
				{
					pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
					if(pFidData->cType != FID_FILE_NOT_USE && (pFidData->nFidType & FID_SECONDARY))
						m_FiducialData[nFidKind].AddFidData(pFidData);
				}
			}
		}
		else 
			continue;

		if(nEachCnt < 2)
			continue;

		if(nEachCnt < 4) // 4�� ���ϸ�
		{
			BOOL bResult;
			if(bPrimarySorting)
				bResult = SortFiducial4UnderPrimary(nFidKind, nCountPri, nCountSec);
			else if(bSecondarySorting)
				bResult = SortFiducial4UnderSecondary(nFidKind, nCountPri, nCountSec);
			if(!bResult)
			{
				m_FiducialData[nFidKind].m_PositionData.RemoveAll();
				pos = m_CopyFidData.m_PositionData.GetHeadPosition();
				while(pos)
				{
					pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
					m_FiducialData[nFidKind].AddFidData(pFidData);
				}
				return FALSE;
			}
		}
		else
		{
			BOOL bResult;
			if(bPrimarySorting)
				bResult = SortFiducialPrimary(nFidKind, nCountPri, nCountSec);
			else if(bSecondarySorting)
				bResult = SortFiducialSecondary(nFidKind, nCountPri, nCountSec);
			if(!bResult)
			{
				m_FiducialData[nFidKind].m_PositionData.RemoveAll();
				pos = m_CopyFidData.m_PositionData.GetHeadPosition();
				while(pos)
				{
					pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
					m_FiducialData[nFidKind].AddFidData(pFidData);
				}
				return FALSE;
			}
		}
	}
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType == FID_FILE_NOT_USE)
			m_FiducialData[nFidKind].AddFidData(pFidData);
	}
	m_CopyFidData.m_PositionData.RemoveAll();

	return TRUE;
}

BOOL GlyphExcellon::SortFiducialPrimary(int nFidKind, int nCountPrimary, int nCountSecondary)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return FALSE;
	
	int nCount = 0;
	int nCountPri = 0;
	LPFIDDATA pFidData;
	POSITION pos;
	BOOL bFindSetFid = FALSE;

	FILE *fp = NULL;
	CString strFileName;
	FID_SORT_DATA* pFidInfoList = NULL;

	CStdioFile f;
	CString readString;
	readString.GetBuffer(80);
	CString lexString;
	int i, nSortIndex;

	pFidInfoList = new FID_SORT_DATA[nCountPrimary];
	memset(pFidInfoList, NULL, sizeof(FID_SORT_DATA) * nCountPrimary);

	nCount = 0;
	i = 0;
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if((pFidData->nFidType & FID_PRIMARY) && pFidData->cType != FID_FILE_NOT_USE && m_FiducialData[nFidKind].nRef == i) // ref�� �׻� ó�� ��
		{
			pFidInfoList[0].pFidData = pFidData;
			pFidInfoList[0].bUsed = FALSE;
			pFidInfoList[0].nSortIndex = 0;
			pFidInfoList[0].nOriginIndex = nCount;
			bFindSetFid = TRUE;
			break;
		}
		nCount++;
		i++;
	}

	if(bFindSetFid)
		nCount = 1;
	else
		nCount = 0;
	i = 0;
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE && m_FiducialData[nFidKind].nRef != i  && pFidData->nFidType & FID_PRIMARY) // not ref and used fid
		{
			pFidInfoList[nCount].pFidData = pFidData;
			pFidInfoList[nCount].bUsed = FALSE;
			pFidInfoList[nCount].nSortIndex = nCount;
			pFidInfoList[nCount].nOriginIndex = i;
			if(!bFindSetFid)
				m_FiducialData[nFidKind].nRef = nCount;
			nCount++;
		}
		i++;	
	}

	m_FiducialData[nFidKind].nRef = 0; 

	int nIndex = 0;

	TSP sortTSP;
	sortTSP.SetRunParam(TRUE, 7, 2 | 128 | 1024, 0, 1.0, 1.0,FALSE,0);
	sortTSP.ResetSortData();
	sortTSP.SetSortCount(nCount);
	
	for(int i = 0; i < nCount; i++)
	{
		sortTSP.AddHole(pFidInfoList[i].pFidData->npPosition.x, 
						pFidInfoList[i].pFidData->npPosition.y);
	}

	if(sortTSP.RunTSP()) // fail 
	{
		TRACE( _T("CreateProcess failed: Fid Area Sort."));
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
		return FALSE;
	}

	for(int j = 0; j < nCount; j++)
	{
		nSortIndex = sortTSP.m_pSortHoles[j].nIndex;
		pFidInfoList[nSortIndex].bUsed = TRUE;
		pFidInfoList[j].nSortIndex = nSortIndex;
	}

		
	BOOL bIsValid = TRUE;
	for(int j =  0; j < nCount; j++)
	{
		if(pFidInfoList[j].bUsed == FALSE)
		{
			bIsValid = FALSE;
			break;
		}
	}
	//check valid sort end : bIsValid
	if(bIsValid)
	{
		for(int j =  0; j < nCount; j++)
		{
			m_CopyFidData.SetFidIndex(j, pFidInfoList[pFidInfoList[j].nSortIndex].nOriginIndex);
		}

		DFidData tempFidData;
		for(int j =  0; j < nCount; j++)
		{
			if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
				break;
			
			LPFIDDATA pFidData = m_CopyFidData.GetFidData(j);
			
			if(pFidData == NULL)
			{
				if(pFidInfoList)
				{
					delete [] pFidInfoList;
					pFidInfoList = NULL;
				}
				return FALSE;
			}
			
			pFidData = m_CopyFidData.GetFidData(pFidData->nFindIndex);
			m_FiducialData[nFidKind].AddFidData(pFidData);
//			tempFidData.AddFidData(pFidData);
		}
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
	}
	else
	{
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
		return FALSE;
	}

	return TRUE;
}


BOOL GlyphExcellon::SortFiducialSecondary(int nFidKind, int nCountPrimary, int nCountSecondary)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return FALSE;
	
	int nCount = 0;
	int nCountSec = 0;
	LPFIDDATA pFidData, pFidDataPrimary;
	POSITION pos;

	FILE *fp = NULL;
	CString strFileName;
	FID_SORT_DATA* pFidInfoList = NULL;

	CStdioFile f;
	CString readString;
	readString.GetBuffer(80);
	CString lexString;
	int i, nSortIndex, nDifferX, nDifferY;
	double dDiffer, dDifferOld;
	dDifferOld = DBL_MAX;

	pFidInfoList = new FID_SORT_DATA[nCountSecondary];
	memset(pFidInfoList, NULL, sizeof(FID_SORT_DATA) * nCountSecondary);

	pos = m_FiducialData[nFidKind].m_PositionData.GetTailPosition();
	if(pos)
		pFidDataPrimary = m_FiducialData[nFidKind].m_PositionData.GetPrev(pos);
	else
	{
		pos = m_CopyFidData.m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
			if(pFidData->cType != FID_FILE_NOT_USE)
			{
				if(pFidData->nFidType & FID_SECONDARY)
				{
					m_FiducialData[nFidKind].AddFidData(pFidData);
				}
			}
		}
		return TRUE;
	}
	
	nCount = 0;
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE  && pFidData->nFidType & FID_SECONDARY)
		{
			nDifferX = abs(pFidDataPrimary->npPosition.x - pFidData->npPosition.x) / 1000;
			nDifferY = abs(pFidDataPrimary->npPosition.y - pFidData->npPosition.y) / 1000;
			
			dDiffer = sqrt((double)((nDifferX*nDifferX) + (nDifferY*nDifferY)));
			
			if(dDiffer <= dDifferOld)
			{
				pFidInfoList[0].pFidData = pFidData;
				pFidInfoList[0].bUsed = FALSE;
				pFidInfoList[0].nSortIndex = 0;
				pFidInfoList[0].nOriginIndex = nCount;
				dDifferOld = dDiffer;
			}
		}
		nCount++;
	}

	nCount = 1;

	i = 0;
	pos = m_CopyFidData.m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_CopyFidData.m_PositionData.GetNext(pos);
		if(pFidData->cType != FID_FILE_NOT_USE  && pFidInfoList[0].nOriginIndex != i && pFidData->nFidType & FID_SECONDARY) // not ref and used fid
		{
			pFidInfoList[nCount].pFidData = pFidData;
			pFidInfoList[nCount].bUsed = FALSE;
			pFidInfoList[nCount].nSortIndex = nCount;
			pFidInfoList[nCount].nOriginIndex = i;
			nCount++;
		}
		i++;	
	}

	int nIndex = 0;

	TSP sortTSP;
	sortTSP.ResetSortData();
	sortTSP.SetRunParam(TRUE, 7, 2 | 128 | 1024, 0, 1.0, 1.0,FALSE,0);
	sortTSP.SetSortCount(nCount);
		
	for(int i = 0; i < nCount; i++)
	{
		sortTSP.AddHole(pFidInfoList[i].pFidData->npPosition.x, 
						pFidInfoList[i].pFidData->npPosition.y);
	}

	if(sortTSP.RunTSP()) // fail
	{
		TRACE( _T("CreateProcess failed: Fid Area Sort."));
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
		return FALSE;
	}

	for(int j = 0; j < nCount; j++)
	{
		nSortIndex = sortTSP.m_pSortHoles[j].nIndex;
		pFidInfoList[nSortIndex].bUsed = TRUE;
		pFidInfoList[j].nSortIndex = nSortIndex;
	}

		
	BOOL bIsValid = TRUE;
	for(int j =  0; j < nCount; j++)
	{
		if(pFidInfoList[j].bUsed == FALSE)
		{
			bIsValid = FALSE;
			break;
		}
	}
	//check valid sort end : bIsValid
	if(bIsValid)
	{
		for(int j =  0; j < nCount; j++)
		{
			m_CopyFidData.SetFidIndex(j, pFidInfoList[pFidInfoList[j].nSortIndex].nOriginIndex);
		}

		DFidData tempFidData;
		for(int j =  0; j < nCount; j++)
		{
			if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
				break;
			
			LPFIDDATA pFidData = m_CopyFidData.GetFidData(j);
			
			if(pFidData == NULL)
			{
				if(pFidInfoList)
				{
					delete [] pFidInfoList;
					pFidInfoList = NULL;
				}
				return FALSE;
			}
			
			pFidData = m_CopyFidData.GetFidData(pFidData->nFindIndex);
			m_FiducialData[nFidKind].AddFidData(pFidData);
//			tempFidData.AddFidData(pFidData);
		}
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
	}
	else 
	{
		if(pFidInfoList)
		{
			delete [] pFidInfoList;
			pFidInfoList = NULL;
		}
		return FALSE;
	}

	return TRUE;
}

BOOL GlyphExcellon::GetIsDelPoint(int nFidKind, int nIndex)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return TRUE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);

	if(pFidData == NULL)
		return TRUE;

	if( pFidData->cType == FID_FILE_NOT_USE)
		return TRUE;
	
	return FALSE;
}

void GlyphExcellon::GetRefPosition(double &dx, double &dy)
{
	int nRef = m_FiducialData[DEFAULT_FID_INDEX].nRef;
	LPFIDDATA pFidData = m_FiducialData[DEFAULT_FID_INDEX].GetFidData(nRef);

	//dx = pFidData->npPosition.x / 1000. + 0.00001;
	//dy = pFidData->npPosition.y / 1000. + 0.00001;

	dx = pFidData->npPosition.x / 1000. ;
	dy = pFidData->npPosition.y / 1000. ;
}

CDPoint GlyphExcellon::GetUseFidOffset(int nFidKind, int nIndex, BOOL b1stPanel)
{
	CDPoint offset;
	offset.x = offset.y = 0;
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return offset;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);

	if(pFidData == NULL)
		return offset;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return offset;
	
	if(b1stPanel)
	{
		offset.x = pFidData->dpTransPosition1.x / 1000. + 0.00001;
		offset.y = pFidData->dpTransPosition1.y / 1000. + 0.00001;
	}
	else
	{
		offset.x = pFidData->dpTransPosition2.x / 1000. + 0.00001;
		offset.y = pFidData->dpTransPosition2.y / 1000. + 0.00001;
	}
	return offset;
}

BOOL GlyphExcellon::SetUseFidOffset(int nFidKind, int nIndex, BOOL b1stPanel, double dx, double dy)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return FALSE;
	
	if(b1stPanel)
	{
		pFidData->dpTransPosition1.x = ((dx ) * 1000.);
		pFidData->dpTransPosition1.y = ((dy ) * 1000.);
	}
	else
	{
		pFidData->dpTransPosition2.x = ((dx ) * 1000.);
		pFidData->dpTransPosition2.y = ((dy ) * 1000.);
	}
	return TRUE;
}

CDPoint GlyphExcellon::GetUseFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel)
{
	CDPoint offset;
	offset.x = offset.y = 0;
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return offset;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return offset;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return offset;
	
	if(b1stPanel)
	{
		offset.x = pFidData->dpTransPosition1.x;
		offset.y = pFidData->dpTransPosition1.y;
	}
	else
	{
		offset.x = pFidData->dpTransPosition2.x;
		offset.y = pFidData->dpTransPosition2.y;
	}
	return offset;
}

CDPoint GlyphExcellon::GetFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel)
{
	CDPoint offset;
	offset.x = offset.y = 0;
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return offset;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return offset;
	
	if(b1stPanel)
	{
		offset.x = pFidData->dpTransPosition1.x;
		offset.y = pFidData->dpTransPosition1.y;
	}
	else
	{
		offset.x = pFidData->dpTransPosition2.x;
		offset.y = pFidData->dpTransPosition2.y;
	}
	return offset;
}

BOOL GlyphExcellon::SetFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel, double dx, double dy)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;

	if(b1stPanel)
	{
		pFidData->dpTransPosition1.x = dx;
		pFidData->dpTransPosition1.y = dy;
	}
	else
	{
		pFidData->dpTransPosition2.x = dx;
		pFidData->dpTransPosition2.y = dy;
	}
	return TRUE;
}

int GlyphExcellon::GetUseFidRealIndex(int nFidKind, int nIndex)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return -1;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return -1;
	
//	nIndex = pFidData->nFindIndex; // sorted data
	
	return nIndex;
}

BOOL GlyphExcellon::LoadFileFid10000(CArchiveMark &ar, int nVersion, SVISIONINFO pVisionInfo[])
{
	CString str;
	int nTemp;
	int	nSaveIndex;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> nTemp;
			nSaveIndex = nTemp;
			ar >> m_FiducialData[DEFAULT_FID_INDEX].nRef;

			m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();


			if(nVersion < 10002)

			{
				nTemp = 10; // old Max fid no 10 : MAX_FID_NO;
			}
			
			
			for(int i = 0; i < nTemp; i++)
			{

				LPFIDDATA pFidData = new FID_DATA;
				ar >> pFidData->cType;
				ar >> pFidData->nFindIndex;
				ar >> pFidData->npPosition.x;
				ar >> pFidData->npPosition.y;

				ar >> pFidData->dpTransPosition1.x;
				ar >> pFidData->dpTransPosition1.y;
				ar >> pFidData->dpTransPosition2.x;
				ar >> pFidData->dpTransPosition2.y;

				pFidData->bCheckIndex = FALSE;
				pFidData->bSelect = FALSE;
				pFidData->bSelected = FALSE;


				if(nVersion > 10007) // version 10008

				{
					ar >> pFidData->nCam;
					ar >> pFidData->nFidType;
					ar >> pFidData->nToolNo;
					ar >> pFidData->dOffsetZ;

					pFidData->bCheckScaleLimit = TRUE;
					if(nVersion >= 10024)
						ar >> pFidData->bCheckScaleLimit;
					
					pFidData->bUseSkiveVisionOption = FALSE;
					if(nVersion >= 10038)
						ar >> pFidData->bUseSkiveVisionOption;

					ar >> pFidData->sVisInfo.nModelType;
					ar >> pFidData->sVisInfo.dSizeA;
					ar >> pFidData->sVisInfo.dSizeB;
					ar >> pFidData->sVisInfo.dSizeC;
					ar >> pFidData->sVisInfo.nPolarity;
					ar >> pFidData->sVisInfo.dScoreSize;
					ar >> pFidData->sVisInfo.dScoreAngle;
					ar >> pFidData->sVisInfo.dAspectRatio;
					if(nVersion >= 10012)
					{
						ar >> pFidData->sVisInfo.nThreshold;
					}
					else 
					{
						pFidData->sVisInfo.nThreshold = 0;
					}

					if(nVersion >= 10013)
					{
						ar >> pFidData->nFidBlock;
					}
					else
					{
						pFidData->nFidBlock = 0;
					}

					for(int i=0; i<4; i++)
					{
						ar >> str;
						ar >> pFidData->sVisInfo.nCoaxial[i];
						ar >> pFidData->sVisInfo.nRing[i];
						if(nVersion >= 10028)
							ar >>  pFidData->sVisInfo.nIR[i];
//						pFidData->sVisInfo.nCoaxial[i] = 0;
//						pFidData->sVisInfo.nRing[i] = 255;
//						pFidData->sVisInfo.nIR[i] = 50;
						ar >> pFidData->sVisInfo.dBrightness[i];
						ar >> pFidData->sVisInfo.dContrast[i];
					}
				}


				m_FiducialData[DEFAULT_FID_INDEX].AddFidData(pFidData);
			}
			
			if(nVersion < 10008)
			{
				ar >> nTemp;
				nSaveIndex = nTemp;
				ar >> m_FiducialData[ADDED_FID_INDEX].nRef;

				m_FiducialData[ADDED_FID_INDEX].RemoveFidData();


				if(nVersion < 10002)

				{
					nTemp = 10; // old Max fid no 10 : MAX_FID_NO;
				}
				
				for(int i = 0; i < nTemp; i++)
				{
					LPFIDDATA pFidData = new FID_DATA;
					ar >> pFidData->cType;
					ar >> pFidData->nFindIndex;
					ar >> pFidData->npPosition.x;
					ar >> pFidData->npPosition.y;

					ar >> pFidData->dpTransPosition1.x;
					ar >> pFidData->dpTransPosition1.y;
					ar >> pFidData->dpTransPosition2.x;
					ar >> pFidData->dpTransPosition2.y;

					pFidData->bCheckIndex = FALSE;
					pFidData->bSelect = FALSE;
					pFidData->bSelected = FALSE;


					m_FiducialData[ADDED_FID_INDEX].AddFidData(pFidData);
				}
			}

			if(nVersion >= 10019)
			{
				if(nVersion >= 10020)
					ar >> m_HoleFindData.nCam;
				else
					m_HoleFindData.nCam = 1;

				ar >> m_HoleFindData.sVisInfo.nModelType;
				ar >> m_HoleFindData.sVisInfo.dSizeA;
				ar >> m_HoleFindData.sVisInfo.dSizeB;
				ar >> m_HoleFindData.sVisInfo.dSizeC;
				ar >> m_HoleFindData.sVisInfo.nPolarity;
				ar >> m_HoleFindData.sVisInfo.dScoreSize;
				ar >> m_HoleFindData.sVisInfo.dScoreAngle;
				ar >> m_HoleFindData.sVisInfo.dAspectRatio;
									
				for(int i=0; i<4; i++)
				{
					ar >>  m_HoleFindData.sVisInfo.nCoaxial[i];
					ar >>  m_HoleFindData.sVisInfo.nRing[i];
					if(nVersion >= 10028)
						ar >>  m_HoleFindData.sVisInfo.nIR[i];
					ar >>  m_HoleFindData.sVisInfo.dBrightness[i];
					ar >>  m_HoleFindData.sVisInfo.dContrast[i];
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL GlyphExcellon::SaveFileFid10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("= ") << m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount() << _T("\n");
			ar << _T("= ") << m_FiducialData[DEFAULT_FID_INDEX].nRef << _T("\n");
			
			LPFIDDATA pFidData;
			POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
			while(pos)
			{
				pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
				ar << _T("= ") << pFidData->cType << _T("\n");
				ar << _T("= ") << pFidData->nFindIndex << _T("\n");
				ar << _T("= ") << pFidData->npPosition.x << _T("\n");
				ar << _T("= ") << pFidData->npPosition.y << _T("\n");
				ar << _T("= ") << pFidData->dpTransPosition1.x << _T("\n");
				ar << _T("= ") << pFidData->dpTransPosition1.y << _T("\n");
				ar << _T("= ") << pFidData->dpTransPosition2.x << _T("\n");
				ar << _T("= ") << pFidData->dpTransPosition2.y << _T("\n");
				if(nVersion > 10007) // version 10008
				{
					ar << _T("Cam = ") << pFidData->nCam << _T("\n");
					ar << _T("FidType = ") << pFidData->nFidType << _T("\n");
					ar << _T("ToolNo = ") << pFidData->nToolNo << _T("\n");
					ar << _T("OffsetZ = ") << pFidData->dOffsetZ << _T("\n");
					ar << _T("UseScaleLimit = ") << pFidData->bCheckScaleLimit << _T("\n");
					
					if(nVersion >= 10038)
					  ar << _T("UseSkiveVisionOption = ") << pFidData->bUseSkiveVisionOption << _T("\n");

					ar << _T("ModelType = ") << pFidData->sVisInfo.nModelType << _T("\n");
					ar << _T("SizeA = ") << pFidData->sVisInfo.dSizeA << _T("\n");
					ar << _T("SizeB = ") << pFidData->sVisInfo.dSizeB << _T("\n");
					ar << _T("SizeC = ") << pFidData->sVisInfo.dSizeC << _T("\n");
					ar << _T("Polarity = ") << pFidData->sVisInfo.nPolarity << _T("\n");
					ar << _T("MaxSize = ") << pFidData->sVisInfo.dScoreSize << _T("\n");
					ar << _T("MaxAngle = ") << pFidData->sVisInfo.dScoreAngle << _T("\n");
					ar << _T("AspectRatio = ") << pFidData->sVisInfo.dAspectRatio << _T("\n");
					if(nVersion >= 10012)
					{
						ar << _T("Threshold = ") << pFidData->sVisInfo.nThreshold <<_T("\n");
					}
					if(nVersion >= 10013)
					{
						ar << _T("Fiducial Block = ")<< pFidData->nFidBlock <<_T("\n");
					}
					for(int i=0; i<4; i++)
					{
						str.Format(_T("Cam %d\n"), i);
						ar << str;
						ar << _T("Coaxial = ") << pFidData->sVisInfo.nCoaxial[i] << _T("\n");
						ar << _T("Ring = ") << pFidData->sVisInfo.nRing[i] << _T("\n");
						ar << _T("IR = ") << pFidData->sVisInfo.nIR[i] << _T("\n");
						ar << _T("Brightness = ") << pFidData->sVisInfo.dBrightness[i] << _T("\n");
						ar << _T("Contrast = ") << pFidData->sVisInfo.dContrast[i] << _T("\n");
					}
				}
			}
			
			if(nVersion < 10008)
			{
				ar << _T("= ") << m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetCount() << _T("\n");
				ar << _T("= ") << m_FiducialData[ADDED_FID_INDEX].nRef << _T("\n");

				pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
				while(pos)
				{
					pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
					ar << _T("= ") << pFidData->cType << _T("\n");
					ar << _T("= ") << pFidData->nFindIndex << _T("\n");
					ar << _T("= ") << pFidData->npPosition.x << _T("\n");
					ar << _T("= ") << pFidData->npPosition.y << _T("\n");
					ar << _T("= ") << pFidData->dpTransPosition1.x << _T("\n");
					ar << _T("= ") << pFidData->dpTransPosition1.y << _T("\n");
					ar << _T("= ") << pFidData->dpTransPosition2.x << _T("\n");
					ar << _T("= ") << pFidData->dpTransPosition2.y << _T("\n");
				}
			}
			ar << _T("= ") << m_HoleFindData.nCam << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.nModelType << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dSizeA << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dSizeB << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dSizeC << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.nPolarity << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dScoreSize << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dScoreAngle << _T("\n");
			ar << _T("= ") << m_HoleFindData.sVisInfo.dAspectRatio << _T("\n");
			
			for(int i=0; i<4; i++)
			{
				ar << _T("= ") << m_HoleFindData.sVisInfo.nCoaxial[i] << _T("\n");
				ar << _T("= ") << m_HoleFindData.sVisInfo.nRing[i] << _T("\n");
				ar << _T("= ") << m_HoleFindData.sVisInfo.nIR[i] << _T("\n");
				ar << _T("= ") << m_HoleFindData.sVisInfo.dBrightness[i] << _T("\n");
				ar << _T("= ") << m_HoleFindData.sVisInfo.dContrast[i] << _T("\n");
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL GlyphExcellon::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> str;

			if(nVersion < 10035)
				nCount = 0;
			else
				ar >> nCount;

			LPDBLOCK pBlock;
			for(int i = 0; i < nCount; i++)
			{
				pBlock = new DBlock;
				pBlock->LoadFile10000(ar, nVersion);
				m_Blocks.AddTail(pBlock);
			}

			if(nVersion < 10002)
			{
				nCount = 1;
			}
			else
			{
				ar >> nCount;
			}

			LPDUNIT pUnit;
			for(int i = 0; i < nCount; i++)
			{
				pUnit = new DUnit;
				pUnit->LoadFile10000(ar, nVersion);
				m_Units.AddTail(pUnit);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL GlyphExcellon::LoadFileUnit10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> str;

			if(nVersion < 10035)
				nCount = 0;
			else
				ar >> nCount;

			LPDBLOCK pBlock;
			for(int i = 0; i < nCount; i++)
			{
				pBlock = new DBlock;
				pBlock->LoadFile10000(ar, nVersion);
				m_Blocks.AddTail(pBlock);
			}

			if(nVersion < 10002)
			{
				nCount = 1;
			}
			else
			{
				ar >> nCount;
			}
			
			LPDUNIT pUnit;
			for(int i = 0; i < nCount; i++)
			{
				pUnit = new DUnit;
				pUnit->LoadFileRect10000(ar, nVersion);
				m_Units.AddTail(pUnit);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL GlyphExcellon::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("OriginData\n");

			ar << "BlockNo = " << m_Blocks.GetCount() << "\n"; // ver 10002
			POSITION posBlock;
			LPDBLOCK pBlock;
			posBlock = m_Blocks.GetHeadPosition();
			while(posBlock)
			{
				pBlock = m_Blocks.GetNext(posBlock);
				pBlock->SaveFile10000(ar, nVersion);
			}

			ar << _T("UnitNo = ") << m_Units.GetCount() << _T("\n"); // ver 10002
			POSITION posUnit;
			LPDUNIT pUnit;
			posUnit = m_Units.GetHeadPosition();
			while(posUnit)
			{
				pUnit = m_Units.GetNext(posUnit);
				pUnit->SaveFile10000(ar, nVersion);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL GlyphExcellon::SaveFileUnit10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("OriginData\n");

			ar << "BlockNo = " << m_Blocks.GetCount() << "\n"; // ver 10002
			POSITION posBlock;
			LPDBLOCK pBlock;
			posBlock = m_Blocks.GetHeadPosition();
			while(posBlock)
			{
				pBlock = m_Blocks.GetNext(posBlock);
				pBlock->SaveFile10000(ar, nVersion);
			}

			ar << _T("UnitNo = ") << m_Units.GetCount() << _T("\n"); // ver 10002
			POSITION posUnit;
			LPDUNIT pUnit;
			posUnit = m_Units.GetHeadPosition();
			while(posUnit)
			{
				pUnit = m_Units.GetNext(posUnit);
				pUnit->SaveFileRect10000(ar, nVersion);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

void GlyphExcellon::GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY, double dStartX, double dStartY, double dScale)
{
	if(nMode == X_Y)
	{
		nTransX = static_cast<int>((nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nY)) / dScale);
	}
	else if(nMode == MX_Y)
	{
		nTransX = static_cast<int>((-nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nY)) / dScale);
	}
	else if(nMode == X_MY)
	{
		nTransX = static_cast<int>((nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nY)) / dScale);
	}
	else if(nMode == MX_MY)
	{
		nTransX = static_cast<int>((-nX - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nY)) / dScale);
	}
	else if(nMode == Y_X)
	{
		nTransX = static_cast<int>((nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nX)) / dScale);
	}
	else if(nMode == MY_X)
	{
		nTransX = static_cast<int>((-nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY - (nX)) / dScale);
	}
	else if(nMode == Y_MX)
	{
		nTransX = static_cast<int>((nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nX)) / dScale);
	}
	else
	{
		nTransX = static_cast<int>((-nY - dStartX) / dScale);
		nTransY = static_cast<int>((dStartY + (nX)) / dScale);
	}
}

BOOL GlyphExcellon::IsDrawData(int nMode, int nX, int nY, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName)
{
	int nTransX, nTransY;
	
	if(nMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(nMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(nMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(nMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(nMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(nMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(nMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}

	if(nTransX < nStartX) 
		return FALSE;
	if(nTransX > nEndX) 
		return FALSE;
	if(nTransY < nEndY) 
		return FALSE;
	if(nTransY > nStartY) 
		return FALSE;

	return TRUE;
}

void GlyphExcellon::ChangeDataWithAxis(int nMode)
{
	int nX1, nX2, nY1, nY2;
	GetXY(nMode, m_nMinX, m_nMinY, nX1, nY1);
	GetXY(nMode, m_nMaxX, m_nMaxY, nX2, nY2);
	if(nX1 > nX2)
	{
		m_nMinX = nX2; m_nMaxX = nX1;
	}
	else
	{
		m_nMinX = nX1; m_nMaxX = nX2;
	}
	if(nY1 > nY2)
	{
		m_nMinY = nY2; m_nMaxY = nY1;
	}
	else
	{
		m_nMinY = nY1; m_nMaxY = nY2;
	}

	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y, nX1, nY1);
		pFidData->npPosition.x = nX1;
		pFidData->npPosition.y = nY1;
	}

	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		GetXY(nMode, pFidData->npPosition.x, pFidData->npPosition.y, nX1, nY1);
		pFidData->npPosition.x = nX1;
		pFidData->npPosition.y = nY1;
	}

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		
		int nX1, nX2, nY1, nY2;
		GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMinY, nX1, nY1);
		GetXY(nMode, pUnit->m_nMaxX, pUnit->m_nMaxY, nX2, nY2);
		if(nX1 > nX2)
		{
			pUnit->m_nMinX = nX2; pUnit->m_nMaxX = nX1;
		}
		else
		{
			pUnit->m_nMinX = nX1; pUnit->m_nMaxX = nX2;
		}
		if(nY1 > nY2)
		{
			pUnit->m_nMinY = nY2; pUnit->m_nMaxY = nY1;
		}
		else
		{
			pUnit->m_nMinY = nY1; pUnit->m_nMaxY = nY2;
		}

		LPHOLEDATA pOriHole;
		pos = pUnit->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pOriHole = pUnit->m_HoleData.GetNext(pos);
			GetXY(nMode, pOriHole->npPos.x, pOriHole->npPos.y, nX1, nY1);
			pOriHole->npPos.x = nX1;
			pOriHole->npPos.y = nY1;
		}
		
		LPLINEDATA pOriginLine;
		pos = pUnit->m_LineData.GetHeadPosition();
		while (pos) 
		{
			pOriginLine = pUnit->m_LineData.GetNext(pos);
			GetXY(nMode, pOriginLine->npStartPos.x, pOriginLine->npStartPos.y, nX1, nY1);
			pOriginLine->npStartPos.x = nX1;
			pOriginLine->npStartPos.y = nY1;
			GetXY(nMode, pOriginLine->npEndPos.x, pOriginLine->npEndPos.y, nX1, nY1);
			pOriginLine->npEndPos.x = nX1;
			pOriginLine->npEndPos.y = nY1;
		}
	}
	POSITION posBlock = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	while(posBlock)
	{
		pBlock = m_Blocks.GetNext(posBlock);
		
		int nX1, nX2, nY1, nY2;
		GetXY(nMode, pBlock->m_nMinX, pBlock->m_nMinY, nX1, nY1);
		GetXY(nMode, pBlock->m_nMaxX, pBlock->m_nMaxY, nX2, nY2);
		if(nX1 > nX2)
		{
			pBlock->m_nMinX = nX2; pBlock->m_nMaxX = nX1;
		}
		else
		{
			pBlock->m_nMinX = nX1; pBlock->m_nMaxX = nX2;
		}
		if(nY1 > nY2)
		{
			pBlock->m_nMinY = nY2; pBlock->m_nMaxY = nY1;
		}
		else
		{
			pBlock->m_nMinY = nY1; pBlock->m_nMaxY = nY2;
		}

		LPHOLEDATA pOriHole;
		pos = pBlock->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pOriHole = pBlock->m_HoleData.GetNext(pos);
			GetXY(nMode, pOriHole->npPos.x, pOriHole->npPos.y, nX1, nY1);
			pOriHole->npPos.x = nX1;
			pOriHole->npPos.y = nY1;
		}
		}
}

void GlyphExcellon::GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY)
{
	if(nMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(nMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(nMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(nMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(nMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(nMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(nMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}
}



void GlyphExcellon::ResetFidOffset()
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->dpTransPosition1.x = 0;
		pFidData->dpTransPosition1.y = 0;
		pFidData->dpTransPosition2.x = 0;
		pFidData->dpTransPosition2.y = 0;
		pFidData->npTablePos1.x = pFidData->npTablePos1.y = 0;		// 20130312
		pFidData->npTablePos2.x = pFidData->npTablePos2.y = 0;
	}

	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->dpTransPosition1.x = 0;
		pFidData->dpTransPosition1.y = 0;
		pFidData->dpTransPosition2.x = 0;
		pFidData->dpTransPosition2.y = 0;
		pFidData->npTablePos1.x = pFidData->npTablePos1.y = 0;		// 20130312
		pFidData->npTablePos2.x = pFidData->npTablePos2.y = 0;
	}
}

CDPoint GlyphExcellon::GetUseFidPoint(int nFidKind, int nIndex)
{
	CDPoint pt(0,0);
	
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return pt;

	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return pt;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
//	if(pFidData == NULL)
//		return pt;
	
	pt.x = pFidData->npPosition.x/1000. + 0.00001;
	pt.y = pFidData->npPosition.y/1000. + 0.00001;
	return pt;
}

HOLEDATA* GlyphExcellon::AddHoleData(HOLEDATA dataHole, int nUnitNo)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int i = 0;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(i == nUnitNo)
		{
			return pUnit->m_HoleData.AddTail(dataHole);
		}
		i++;
	}
	return FALSE;
}

BOOL GlyphExcellon::AddLineData(LINEDATA* pLine, int nUnitNo)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int i = 0;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(i == nUnitNo)
		{
			pUnit->m_LineData.AddTail(pLine);
			return TRUE;
		}
		i++;
	}
	return FALSE;
}

void GlyphExcellon::RemoveAllHoleData()
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int i = 0;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->ReMoveAllHoleData();
	}
}

void GlyphExcellon::ReMoveAllLineData()
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int i = 0;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->ReMoveAllLineData();
	}
}

BOOL GlyphExcellon::IsDotData(int nTool)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->IsDotData(nTool))
			return TRUE;
	}
	return FALSE;
}

BOOL GlyphExcellon::IsLineData(int nTool)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		if(pUnit->IsLineData(nTool))
			return TRUE;
	}
	return FALSE;
}

int GlyphExcellon::GetTotalHoleCount()
{
	int nCount = 0;
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	LPDBLOCK pBlock;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		POSITION posHole = pUnit->m_HoleData.GetHeadPosition();
		LPHOLEDATA pData;
		while (posHole) 
		{
			pData = pUnit->m_HoleData.GetNext(posHole);
			if(pData->nBlockName2 == 0)
				nCount++;
			else
			{
				pBlock = GetBlock(pData->nBlockName2);
				nCount += pBlock->m_HoleData.GetCount();
			}
		}
	}
	return nCount;
}

void GlyphExcellon::RemoveAllUnit()
{
	CProgressWnd wndProgress(NULL, _T("Delete Unit"), TRUE);
	wndProgress.GoModal();
	wndProgress.SetRange(0,0);
	wndProgress.SetText(_T("Data Delete"));
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		delete pUnit;
	}
	m_Units.RemoveAll();
}

void GlyphExcellon::DrawUnit(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList **pToolCodes, int nMode)
{
	int nDrawStartX, nDrawStartY;
	int nX, nY, nRectSize = 3;
	int nCount = 0;
	COLORREF pColor;
	CPen pen;
	CPen* pOldPen;
	
	nDrawStartX = (int)dDrawStartX;
	nDrawStartY = (int)dDrawStartY;

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);

		if(pUnit->m_bSelect)
		{
			pColor = RGB(0, 0, 200);
			pen.CreatePen(PS_DOT, 1, pColor);
			pOldPen = pDC->SelectObject(&pen);

			GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->MoveTo(nX, nY);
			
			GetXY(nMode, pUnit->m_nMaxX, pUnit->m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->LineTo(nX, nY);
			
			GetXY(nMode, pUnit->m_nMaxX, pUnit->m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->LineTo(nX, nY);
			
			GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->LineTo(nX, nY);
			
			GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->LineTo(nX, nY);

			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
				pOldPen = NULL;
			}

			CBrush cBr, cBr2;
			CBrush* pOldBrush;

			if(nCount == 0)
			{
				pColor = RGB(200, 0, 0);
				cBr.CreateSolidBrush(RGB(200, 0, 0));
				pOldBrush = pDC->SelectObject(&cBr);
			}
			else
			{
				pColor = RGB(0, 0, 200);
				cBr.CreateSolidBrush(RGB(0, 0, 200));
				pOldBrush = pDC->SelectObject(&cBr);
			}

			pen.CreatePen(PS_SOLID, 1, pColor);
			pOldPen = pDC->SelectObject(&pen);
			GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->Rectangle(nX - nRectSize, nY + nRectSize, nX + nRectSize, nY - nRectSize);

			if(nCount == 0)
			{
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
				pColor = RGB(0, 0, 200);

				pen.CreatePen(PS_SOLID, 1, pColor);
				pOldPen = pDC->SelectObject(&pen);

				pDC->SelectObject(pOldBrush);
				cBr2.CreateSolidBrush(RGB(0, 0, 200));
				pOldBrush = pDC->SelectObject(&cBr2);
			}
			GetXY(nMode, pUnit->m_nMaxX, pUnit->m_nMinY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->Rectangle(nX - nRectSize, nY - nRectSize, nX + nRectSize, nY + nRectSize);
			
			GetXY(nMode, pUnit->m_nMaxX, pUnit->m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->Rectangle(nX - nRectSize, nY - nRectSize, nX + nRectSize, nY + nRectSize);
			
			GetXY(nMode, pUnit->m_nMinX, pUnit->m_nMaxY, nX, nY, dDrawStartX, dDrawStartY, dScale);
			pDC->Rectangle(nX - nRectSize, nY - nRectSize, nX + nRectSize, nY + nRectSize);
		
			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldBrush);
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
				pOldPen = NULL;
			}

			nCount++;
		}
	}
	
}

BOOL GlyphExcellon::MoveUnit(int nDirection)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	BOOL bMove = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			if(nDirection == MOVE_LEFT)
				pUnit->Move(-1, 0);
			else if(nDirection == MOVE_RIGHT)
				pUnit->Move(1, 0);
			else if(nDirection == MOVE_UP)
				pUnit->Move(0, 1);
			else
				pUnit->Move(0, -1);

			bMove = TRUE;
		}
	}
	return bMove;
}

BOOL GlyphExcellon::MoveUnit(int nX, int nY)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	BOOL bMove = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			pUnit->Move(nX, nY);
			bMove = TRUE;
		}
	}
	return bMove;
}

BOOL GlyphExcellon::IsPickUnit(CPoint ptPoint, int nTol)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int nStartX, nEndX, nStartY, nEndY;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			nStartX	= pUnit->m_nMinX - nTol;
			nEndX	= pUnit->m_nMaxX + nTol;
			nStartY	= pUnit->m_nMinY - nTol;
			nEndY	= pUnit->m_nMinY + nTol;

			if(ptPoint.x >= nStartX && ptPoint.x <= nEndX &&
				ptPoint.y >= nStartY && ptPoint.y <= nEndY)
				return TRUE;

			nStartX	= pUnit->m_nMinX - nTol;
			nEndX	= pUnit->m_nMaxX + nTol;
			nStartY	= pUnit->m_nMaxY - nTol;
			nEndY	= pUnit->m_nMaxY + nTol;
			
			if(ptPoint.x >= nStartX && ptPoint.x <= nEndX &&
				ptPoint.y >= nStartY && ptPoint.y <= nEndY)
				return TRUE;

			nStartX	= pUnit->m_nMinX - nTol;
			nEndX	= pUnit->m_nMinX + nTol;
			nStartY	= pUnit->m_nMinY - nTol;
			nEndY	= pUnit->m_nMaxY + nTol;
			
			if(ptPoint.x >= nStartX && ptPoint.x <= nEndX &&
				ptPoint.y >= nStartY && ptPoint.y <= nEndY)
				return TRUE;

			nStartX	= pUnit->m_nMaxX - nTol;
			nEndX	= pUnit->m_nMaxX + nTol;
			nStartY	= pUnit->m_nMinY - nTol;
			nEndY	= pUnit->m_nMaxY + nTol;
			
			if(ptPoint.x >= nStartX && ptPoint.x <= nEndX &&
				ptPoint.y >= nStartY && ptPoint.y <= nEndY)
				return TRUE;

		}
	}
	return FALSE;
}

void GlyphExcellon::UnSelectAllUnit()
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		pUnit->m_bSelect = FALSE;
	}
}

BOOL GlyphExcellon::DeleteSelectUnit()
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posBefore = posUnit;
	LPDUNIT pUnit;
	BOOL bDel = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			gDUndoRedo.AddGlyphtoList(pUnit);
//			delete pUnit;
			m_Units.RemoveAt(posBefore);
			bDel = TRUE;
		}
		posBefore = posUnit;
	}
	if(bDel)
	{
		gDUndoRedo.DelGlyph();
	}
	return bDel;
}

void GlyphExcellon::ArrayCopy(int nCopyType, int nShape, int nR, int &nCOffsetX, int &nCOffsetY, int nX, int nY)
{
	UnitList tempUnitList;
	int nCalOffsetX, nCalOffsetY;
	int nRCenterX, nRCenterY;
	int nXSIndex, nXEIndex, nYSIndex, nYEIndex;
	double dR, dR2;

	if(nCopyType == 0) // circle
	{
		nX = abs(nX);
		nY = abs(nY);
		dR2 = sqrt(1.0 * nR * nR);
		POSITION posUnit = m_Units.GetHeadPosition();
		LPDUNIT pUnit, pNewUnit;
		while(posUnit)
		{
			pUnit = m_Units.GetNext(posUnit);
			if(pUnit->m_bSelect)
			{
				nRCenterX = pUnit->m_nMinX + nCOffsetX;
				nRCenterY = pUnit->m_nMinY + nCOffsetY;

				nXSIndex = (int)((pUnit->m_nMinX + nR - nRCenterX) / nX) + 2;
				nYSIndex = (int)((pUnit->m_nMinY + nR - nRCenterY) / nY) + 2;

				nXEIndex = (int)((nR + nRCenterX - pUnit->m_nMaxX) / nX) + 2;
				nYEIndex = (int)((nR + nRCenterY - pUnit->m_nMaxY) / nY) + 2;
				for(int i = -nXSIndex; i <= nXEIndex; i++)
				{
					for(int j = -nYSIndex; j <= nYEIndex; j++)
					{
						if(i == 0 && j == 0)
							continue;
						if(j % 2 == 0 || nShape == 0) // not zigzag
							nCalOffsetX = i * nX;
						else
							nCalOffsetX = i * nX + nX/ 2;
						
						nCalOffsetY = j * nY;

						dR = sqrt(1.0*(pUnit->m_nMinX + nCalOffsetX - nRCenterX)*
							(pUnit->m_nMinX + nCalOffsetX - nRCenterX) + 
							1.0*(pUnit->m_nMinY + nCalOffsetY - nRCenterY)*
							(pUnit->m_nMinY + nCalOffsetY - nRCenterY));
						if(dR > dR2)
							continue;

						dR = sqrt(1.0*(pUnit->m_nMaxX + nCalOffsetX - nRCenterX)*
							(pUnit->m_nMaxX + nCalOffsetX - nRCenterX) + 
							1.0*(pUnit->m_nMinY + nCalOffsetY - nRCenterY)*
							(pUnit->m_nMinY + nCalOffsetY - nRCenterY));
						if(dR > dR2)
							continue;

						dR = sqrt(1.0*(pUnit->m_nMinX + nCalOffsetX - nRCenterX)*
							(pUnit->m_nMinX + nCalOffsetX - nRCenterX) + 
							1.0*(pUnit->m_nMaxY + nCalOffsetY - nRCenterY)*
							(pUnit->m_nMaxY + nCalOffsetY - nRCenterY));
						if(dR > dR2)
							continue;

						dR = sqrt(1.0*(pUnit->m_nMaxX + nCalOffsetX - nRCenterX)*
							(pUnit->m_nMaxX + nCalOffsetX - nRCenterX) + 
							1.0*(pUnit->m_nMaxY + nCalOffsetY - nRCenterY)*
							(pUnit->m_nMaxY + nCalOffsetY - nRCenterY));
						if(dR > dR2)
							continue;

						pNewUnit = new DUnit;
						pNewUnit->m_bSelect = TRUE;
						pNewUnit->Copy(pUnit, nCalOffsetX, nCalOffsetY);
						tempUnitList.AddTail(pNewUnit);
					}
				}
			}
		}
		nCOffsetX = nRCenterX;
		nCOffsetY = nRCenterY;
	}
	else
	{
		POSITION posUnit = m_Units.GetHeadPosition();
		LPDUNIT pUnit, pNewUnit;
		while(posUnit)
		{
			pUnit = m_Units.GetNext(posUnit);
			if(pUnit->m_bSelect)
			{
				for(int i = 0; i < nCOffsetX; i++)
				{
					for(int j = 0; j < nCOffsetY; j++)
					{
						if(i == 0 && j == 0)
							continue;
						if(j % 2 == 0 || nShape == 0) // not zigzag
							nCalOffsetX = i * nX;
						else
							nCalOffsetX = i * nX + nX/ 2;

						nCalOffsetY = j * nY;
						pNewUnit = new DUnit;
						pNewUnit->m_bSelect = TRUE;
						pNewUnit->Copy(pUnit, nCalOffsetX, nCalOffsetY);
						tempUnitList.AddTail(pNewUnit);
					}
				}
			}
		}
	}

	LPDUNIT pUnit;
	POSITION pos = tempUnitList.GetHeadPosition();
	while(pos)
	{
		pUnit =tempUnitList.GetNext(pos);
		m_Units.AddTail(pUnit);
		gDUndoRedo.AddGlyphtoList(pUnit);
	}
	gDUndoRedo.AddGlyph();
	tempUnitList.RemoveAll();
}

void GlyphExcellon::RemoveAllSubFiducial(int nIndex)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid, posFidBefore;
	LPDUNIT pUnit;
	int* pIndex;
	BOOL bDel = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
		posFidBefore = posFid;
		while(posFid)
		{
			pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
			if(*pIndex == nIndex)
			{
				pUnit->m_SubFidIndexData.RemoveAt(posFidBefore);
				delete pIndex;
			}
			posFidBefore = posFid;
		}
	}
}

void GlyphExcellon::MoveFiducial(CPoint pt, CPoint ptMove, int nTolerence)
{
	int nCount = 0, nCount2 = 0;
	LPFIDDATA pFidData;
	POSITION pos;

	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
		{
			continue;
		}
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
				continue;
			else if(pFidData->cType == FID_FILE_USE) // file open origin fid
			{
				pFidData->npPosition = ptMove;
				SortFiducial(DEFAULT_FID_INDEX);
				return;
			}
		}
	}

	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
			continue;
		else
		{
			if(pFidData->cType == FID_FILE_NOT_USE) // ������ ���̸�
				continue;
			else if(pFidData->cType == FID_FILE_USE) // file open origin fid
			{
				pFidData->npPosition = ptMove;
				SortFiducial(ADDED_FID_INDEX);
				return;
			}
		}
	}
	return;
}

void GlyphExcellon::AddMoveUnitsToUndoList()
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			gDUndoRedo.AddGlyphtoList(pUnit);
		}
	}
}

BOOL GlyphExcellon::GetUnitPos(CPoint& ptPoint)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			ptPoint.x = pUnit->m_nMinX;
			ptPoint.y = pUnit->m_nMinY;
			return TRUE;
		}

	}
	return FALSE;
}

BOOL GlyphExcellon::IsMultiSelected()
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int nCount = 0;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			nCount++;
			if(nCount>1)
				return TRUE;
		}
		
	}
	return FALSE;
}

void GlyphExcellon::MergeUnit()
{
	POSITION posBefore, posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit, pUnitSum;
	int nCount = 0;
	posBefore = posUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			nCount++;
			if(nCount == 1)
			{
				pUnitSum = pUnit;
			}
			else
			{
				pUnitSum->Merge(pUnit);
				delete pUnit;
				m_Units.RemoveAt(posBefore);
			}
		}
		posBefore = posUnit;
	}
}

BOOL GlyphExcellon::DisunifyUnit(CPoint pt1, CPoint pt2)
{
	POSITION posBefore, posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit, pUnitNew;
	UnitList tempList;
	int nCount = 0;
	BOOL bDisunify = FALSE;
	posBefore = posUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			pUnitNew = new DUnit;
			pUnitNew->Copy(pUnit);
			pUnit->DelInRect(pt1, pt2, FALSE);
			pUnitNew->DelInRect(pt1, pt2, TRUE);
			if(pUnitNew->IsAnyData())
			{
				pUnit->ReCalRect(&m_Blocks);
				pUnitNew->ReCalRect(&m_Blocks);
				pUnitNew->m_bSelect = TRUE;
				tempList.AddTail(pUnitNew);
			}
			else
			{
				delete pUnitNew;
			}
		}
		posBefore = posUnit;
	}

	posUnit = tempList.GetHeadPosition();
	while(posUnit)
	{
		bDisunify = TRUE;
		pUnit = tempList.GetNext(posUnit);
		m_Units.AddTail(pUnit);
	}
	tempList.RemoveAll();

	return bDisunify;
}

void GlyphExcellon::ReCalRect(BOOL bFidContain)
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->ReCalRect(&m_Blocks);
		if(m_nMinX > pUnit->m_nMinX)
			m_nMinX = pUnit->m_nMinX;
		if(m_nMaxX < pUnit->m_nMaxX)
			m_nMaxX = pUnit->m_nMaxX;
		if(m_nMinY > pUnit->m_nMinY)
			m_nMinY = pUnit->m_nMinY;
		if(m_nMaxY < pUnit->m_nMaxY)
			m_nMaxY = pUnit->m_nMaxY;
	}
	
	// fiducial
	if(bFidContain)
	{
		LPFIDDATA pFidData;
		pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while(pos)
		{
			pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		if(m_nMaxX < pFidData->npPosition.x) m_nMaxX = pFidData->npPosition.x;
		if(m_nMinX > pFidData->npPosition.x) m_nMinX = pFidData->npPosition.x;
		if(m_nMaxY < pFidData->npPosition.y) m_nMaxY = pFidData->npPosition.y;
		if(m_nMinY > pFidData->npPosition.y) m_nMinY = pFidData->npPosition.y;
	}
	
	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		
			if(m_nMaxX < pFidData->npPosition.x) m_nMaxX = pFidData->npPosition.x;
			if(m_nMinX > pFidData->npPosition.x) m_nMinX = pFidData->npPosition.x;
			if(m_nMaxY < pFidData->npPosition.y) m_nMaxY = pFidData->npPosition.y;
			if(m_nMinY > pFidData->npPosition.y) m_nMinY = pFidData->npPosition.y;
		}
	}
}

int GlyphExcellon::IsThereFid(CPoint &pt, int nTolerence)
{
	int nCount = 0;
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		if (pt.x < pFidData->npPosition.x - nTolerence ||
			pt.x > pFidData->npPosition.x + nTolerence ||
			pt.y < pFidData->npPosition.y - nTolerence ||
			pt.y > pFidData->npPosition.y + nTolerence)
		{
			nCount++;
			continue;
		}
		else
		{
			if(pFidData->cType != FID_FILE_NOT_USE)
			{
				return nCount;
			}
		}
		nCount++;
	}
	
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		LPHOLEDATA pHole;
		pos = pUnit->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pUnit->m_HoleData.GetNext(pos);
			
			if (pt.x < pHole->npPos.x - nTolerence ||
				pt.x > pHole->npPos.x + nTolerence ||
				pt.y < pHole->npPos.y - nTolerence ||
				pt.y > pHole->npPos.y + nTolerence)
			{
				nCount++;
				continue;
			}
			else
			{
				pt.x = pHole->npPos.x;
				pt.y = pHole->npPos.y;
				return -1;
			}
		}
	}
	return -2;
}

BOOL GlyphExcellon::AddSubFiducial(int nIndex)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid;
	LPDUNIT pUnit;
	int* pIndex;
	BOOL bIsThere, bAdd = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			bIsThere = FALSE;
			posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
			while(posFid)
			{
				pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
				if(*pIndex == nIndex)
				{
					bIsThere = TRUE;
					break;
				}
			}
			if(!bIsThere)
			{
				pIndex = new int;
				*pIndex = nIndex;
				pUnit->m_SubFidIndexData.AddTail(pIndex);
				bAdd = TRUE;
			}
		}
	}
	return bAdd;
}

BOOL GlyphExcellon::IsUseFidInArea(int nIndex, BOOL bSubFid)
{
	if(m_bShowSelectionFid)
	{
		POSITION pos = m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		while(pos)
		{
			pUnit = m_Units.GetNext(pos);
			if(pUnit->IsUseFidInArea(nIndex, bSubFid))
				return TRUE;
		}
	}
	return FALSE;
}

BOOL GlyphExcellon::IsSelectedFid(int nIndex)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid;
	LPDUNIT pUnit;
	int* pIndex;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
			while(posFid)
			{
				pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
				if(*pIndex == nIndex)
				{
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL GlyphExcellon::RemoveSelectUnitAllSubFiducial()
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid;
	LPDUNIT pUnit;
	int* pIndex;
	BOOL bDel = FALSE;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(pUnit->m_bSelect)
		{
			posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
			while(posFid)
			{
				pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
				delete pIndex;
				bDel = TRUE;
			}
			pUnit->m_SubFidIndexData.RemoveAll();
		}
	}
	return bDel;
}

BOOL GlyphExcellon::IsValidFiducial()
{
	//mechanical
	LPFIDDATA pFidData;
	int nFidCount[MAX_FID_BLOCK];
	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);
	int nCnt = GetUseFidCount(DEFAULT_FID_INDEX, FID_PRIMARY + FID_FIND, FID_VERIFY, -1);
	for(int i = 0; i < nCnt; i++) 
	{
		pFidData = GetUsedFiducialData(DEFAULT_FID_INDEX, i, FID_PRIMARY + FID_FIND, FID_VERIFY, -1);
		nFidCount[pFidData->nFidBlock]++;
	}
	for(int i = 0; i < MAX_FID_BLOCK; i++) // index�� �ٸ� ����� ���� ��Ƽ� ���� üũ
	{
		if((nFidCount[i] > 0 && nFidCount[i] < 2) || nFidCount[i] > 4)
		{
			ErrMessage(_T("Differ in Mechanical Fiducial Count"));
			return FALSE;
		}
	}
	
	//course
	int nCntCourse = GetUseFidCount(DEFAULT_FID_INDEX, FID_SECONDARY + FID_FIND, FID_VERIFY, -1);
	// skiving
	int nCntSkiving = GetUseFidCount(DEFAULT_FID_INDEX, FID_SECONDARY + FID_DRILL, FID_VERIFY, -1);
	
	if(nCnt > 4 && (nCntCourse || nCntSkiving)) // multi fid �鼭 course, skiving �ִٸ� ���� ����.
	{
		ErrMessage(_T("Multi-Mechanical Fiducial : Can't use course or skiving Fiducial"));
		return FALSE;
	}
	
	if(nCntCourse && nCntSkiving) // course�� skiving ����� �Բ� ������¡ ����
	{
		ErrMessage(_T("Can't use course and skiving Fiducial in same project"));
		return FALSE;
	}
	
	if(nCntCourse)
	{
		if(nCntCourse < 3 || nCntCourse > 4)
		{
			ErrMessage(_T("Course Fiducial : Need 3~4 Fiducial"));
			return FALSE;
		}
		if(nCnt < 3 || nCnt > 4) // �ݵ�� mechanical �� �־�� �Ѵ�
		{
			ErrMessage(_T("Course Fiducial : Need 3~4 Mechanical Fiducial"));
			return FALSE; 
		}
	}
	
	if(nCntSkiving)
	{
		if(nCntSkiving < 3 || nCntSkiving > 4)
		{
			ErrMessage(_T("Skiving Fiducial : Need 3~4 Fiducial"));
			return FALSE;
		}
// 		if(nCnt < 3 || nCnt > 4) // �ݵ�� mechanical �� �־�� �Ѵ�
// 		{
// 			ErrMessage(_T("Skiving Fiducial : Need 3~4 Mechanical Fiducial"));
// 			return FALSE; 
// 		}
	}

/*	if(GetUseFidCount(DEFAULT_FID_INDEX) < 2)
		return FALSE;

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int nCount;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		nCount = pUnit->m_SubFidIndexData.GetCount();

		if(!gProcessINI.m_sProcessSystem.bNoDivideUnit)
		{
			if(nCount > 0 )
			{
				pUnit->m_bSelect = TRUE;
				return FALSE; // unit�� area ������ ��쿡�� sub-fid ���� �� �ִ�.
			}
//			if(GetUseFidCount(DEFAULT_FID_INDEX) > 4) // sub-fid�� �ƴѰ�� �θ� fid 2~4�� ���̿��� �Ѵ�.
//				return FALSE;
		}
		else
		{
			if(nCount == 0)
			{
				pUnit->m_bSelect = TRUE;
				return FALSE; // sub-fid�� �������� ��� unit�� sub-fid�� ������ �Ѵ�.
			}
			if(nCount < 2 || nCount > 4) // sub-fid�� 2 ~ 4�� �־�� �Ѵ�.
			{
				pUnit->m_bSelect = TRUE;
				return FALSE;
			}
		}
	}
*/	
	return TRUE;
}

void GlyphExcellon::ResetFindFidList()
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->bCheckIndex = 0;
	}
}

void GlyphExcellon::ChangeFindFidList(int* nVal)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid;
	LPDUNIT pUnit;
	int* pIndex;
	int i = 0, nCount;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		
		nCount = pUnit->m_SubFidIndexData.GetCount();
		if(nCount > 0)
		{
			posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
			while(posFid)
			{
				pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
				ChangeOneFindFid(*pIndex, nVal[i]);
				return;
			}
		}
		else
		{
			ChangeAllFindFid(nVal[i]);
			return;
		}
		
		i++;
	}
	return;
}

void GlyphExcellon::ChangeAllFindFid(int nVal)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->bCheckIndex = pFidData->bCheckIndex | nVal;
	}
}

void GlyphExcellon::ChangeOneFindFid(int nFidIndex, int nVal)
{
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if(i == nFidIndex)
			pFidData->bCheckIndex = pFidData->bCheckIndex | nVal;
		i++;
	}
}

BOOL GlyphExcellon::TransformAllFidCal(int nFidKind, BOOL b1st, BOOL b2nd, int nFindMethod)
{
/*
	POSITION posUnit = m_Units.GetHeadPosition();
	POSITION posFid;
	LPDUNIT pUnit;
	int* pIndex;
	int nCount, i, nFidFindStatus;
	CPoint npFile, npOffset;

	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		pUnit->m_bTransOK = FALSE;
		
		nCount = pUnit->m_SubFidIndexData.GetCount();
		if(nCount > 0)
		{
			if(b1st)
			{
				pUnit->m_1stTrans.SetNumPoint(nCount);
				posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
				i = 0;
				while(posFid)
				{
					nFidFindStatus = GetFidFindStatus(nFidKind, i);
					if(nFindMethod != FIND_ALL_FID && (nFidFindStatus & nFindMethod) == 0)
						return FALSE;
					pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
					npFile = GetFidIntPoint(nFidKind, *pIndex);
					npOffset = GetFidIntOffset(nFidKind, *pIndex, TRUE);
//					npFile = GetFidIntPoint(nFidKind, i);
//					npOffset = GetFidIntOffset(nFidKind, i, TRUE);
					pUnit->m_1stTrans.SetReferencePoint(npFile.x, npFile.y, i);
					pUnit->m_1stTrans.SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, i);
					i++;
				}
//				i++;
				pUnit->m_1stTrans.Transform();
				pUnit->m_bTransOK = TRUE;
			}
			if(b2nd)
			{
				pUnit->m_2ndTrans.SetNumPoint(nCount);
				posFid = pUnit->m_SubFidIndexData.GetHeadPosition();
				i = 0;
				while(posFid)
				{
					nFidFindStatus = GetFidFindStatus(nFidKind, i);
					if(nFindMethod != FIND_ALL_FID && (nFidFindStatus & nFindMethod) == 0)
						return FALSE;
					pIndex = pUnit->m_SubFidIndexData.GetNext(posFid);
					npFile = GetFidIntPoint(nFidKind, *pIndex);
					npOffset = GetFidIntOffset(nFidKind, *pIndex, FALSE);
//					npFile = GetFidIntPoint(nFidKind, i);
//					npOffset = GetFidIntOffset(nFidKind, i, FALSE);
					pUnit->m_2ndTrans.SetReferencePoint(npFile.x, npFile.y, i);
					pUnit->m_2ndTrans.SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, i);
					i++;
				}
//				i++;
				pUnit->m_2ndTrans.Transform();
				pUnit->m_bTransOK = TRUE;
			}
		}
		else
		{
			if(b1st)
			{
				pUnit->m_1stTrans.SetNumPoint(GetUseFidCount(nFidKind));
				for(int i = 0; i < GetUseFidCount(nFidKind); i++)
				{
					nFidFindStatus = GetFidFindStatus(nFidKind, i);
					if(nFindMethod != FIND_ALL_FID && (nFidFindStatus & nFindMethod) == 0)
						return FALSE;
					npFile = GetUseFidIntPoint(nFidKind, i);
					npOffset = GetUseFidIntOffset(nFidKind, i, TRUE);
					pUnit->m_1stTrans.SetReferencePoint(npFile.x, npFile.y, i);
					pUnit->m_1stTrans.SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, i);
				}
				pUnit->m_1stTrans.Transform();
				pUnit->m_bTransOK = TRUE;
			}
			
			if(b2nd)
			{
				pUnit->m_2ndTrans.SetNumPoint(GetUseFidCount(nFidKind));
				for(int i = 0; i < GetUseFidCount(nFidKind); i++)
				{
					nFidFindStatus = GetFidFindStatus(nFidKind, i);
					if(nFindMethod != FIND_ALL_FID && (nFidFindStatus & nFindMethod) == 0)
						return FALSE;
					npFile = GetUseFidIntPoint(nFidKind, i);
					npOffset = GetUseFidIntOffset(nFidKind, i, FALSE);
					pUnit->m_2ndTrans.SetReferencePoint(npFile.x, npFile.y, i);
					pUnit->m_2ndTrans.SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, i);
				}
				pUnit->m_2ndTrans.Transform();
				pUnit->m_bTransOK = TRUE;
			}
		}
	}
*/
	return TRUE;
}

DUnit* GlyphExcellon::GetUnit(int nIndex)
{
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	int nCount = 0;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		if(nCount == nIndex)
			return pUnit;
		nCount++;
	}
	return NULL;
}

BOOL GlyphExcellon::IsValidTool(DUnit *pNewUnit)
{
	int nToolType[MAX_TOOL_NO];
	memset(nToolType, NULL, sizeof(int) *MAX_TOOL_NO );

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		
		POSITION pos = pUnit->m_HoleData.GetHeadPosition();
		LPHOLEDATA pData;
		while (pos) 
		{
			pData = pUnit->m_HoleData.GetNext(pos);
			nToolType[pData->nToolNo] = 1;
		}
		
		LPLINEDATA pLine;
		pos = pUnit->m_LineData.GetHeadPosition();
		while (pos) 
		{
			pLine = pUnit->m_LineData.GetNext(pos);
			nToolType[pLine->nToolNo] = 2;
		}
	}
	int nCountCheck = 0;
	POSITION pos = pNewUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = pNewUnit->m_HoleData.GetNext(pos);
		if(nToolType[pData->nToolNo] == 2)
			return FALSE;
		else
			nToolType[pData->nToolNo] = 1;
		nCountCheck++;
	}
	
	LPLINEDATA pLine;
	pos = pNewUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pNewUnit->m_LineData.GetNext(pos);
		if(nToolType[pLine->nToolNo] == 1)
			return FALSE;
		else
			nToolType[pLine->nToolNo] = 2;
	}
	return TRUE;
}

BOOL GlyphExcellon::GetRefFidPos(int &nX, int &nY) //20091029
{
	int nRef = m_FiducialData[DEFAULT_FID_INDEX].nRef;
	LPFIDDATA pFidData = m_FiducialData[DEFAULT_FID_INDEX].GetFidData(nRef);
	
	if(pFidData == NULL)
		return FALSE;

	nX = pFidData->npPosition.x;
	nY = pFidData->npPosition.y;
	return TRUE;
}

BOOL GlyphExcellon::SetUseFidSelect(int nFidKind, int nIndex, BOOL bSelect)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return FALSE;
	
	pFidData->bSelect = bSelect;
	return TRUE;
}

void GlyphExcellon::UnSelectAllFid()
{
	// fiducial
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->bSelect = FALSE;
		pFidData->bSelected = FALSE;
	}
	
	pos = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[ADDED_FID_INDEX].m_PositionData.GetNext(pos);
		pFidData->bSelect = FALSE;
		pFidData->bSelected = FALSE;
	}
}

BOOL GlyphExcellon::GetUseFidSelect(int nFidKind, int nIndex)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return FALSE;
	
	return pFidData->bSelect;
}

void GlyphExcellon::UnSelectAllData()
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->UnSelectData();
	}
}

void GlyphExcellon::SetFiducial(int nIndex, BOOL bSubFid)
{
	int i=0;
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	
	// ���� 4�� �̻� �����ߴ��� ����..
	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		if(pFidData->bSelected)
			i++;
	}

	if(i>4)
	{
		ErrMessage("Data must be able to Select Maximum 4 Fiducial\nSelect 4 Fiducial after Reset");
		return;
	}


	// ���� 4�� �̻� �����ߴ��� ���� ���� �����Ѵ�
	i=0;
	pos = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		if(pFidData->bSelected)
		{
			POSITION pos2 = m_Units.GetHeadPosition();
			LPDUNIT pUnit;
			while(pos2)
			{
				pUnit = m_Units.GetNext(pos2);
				pUnit->SetFiducial(i, bSubFid);
			}
		}
		i++;
	}
}

void GlyphExcellon::ResetOneFiducial(int nIndex, BOOL bSubFid)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->ResetOneFiducial(nIndex, bSubFid);
	}
}

void GlyphExcellon::ResetAllFiducial(BOOL bSubFid)
{
	POSITION pos = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(pos)
	{
		pUnit = m_Units.GetNext(pos);
		pUnit->ResetAllFiducial(bSubFid);
	}
}

BOOL GlyphExcellon::ResetFidAcquireRet(int nFidKind, BOOL bAcquire)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		pFidData->bAcquire[0] = bAcquire;
		pFidData->bAcquire[1] = bAcquire;
	}
	
	return TRUE;
}

BOOL GlyphExcellon::GetFidAcquireRet(int nFidKind, int nIndex, BOOL b2ndPanel, int nFidRank)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return FALSE;

	if(pFidData->bAcquire[b2ndPanel])
	{
		if(nFidRank != 0 && !(pFidData->nFidType & nFidRank))
			return FALSE;

		if(pFidData->nFidType & FID_VERIFY)
			return FALSE;

		return TRUE;
	}
	
	return FALSE;
}

BOOL GlyphExcellon::SetFidAcquireRet(int nFidKind, int nIndex, BOOL bAcquire, BOOL b2ndPanel)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return FALSE;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return FALSE;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
//	if(pFidData == NULL)
//		return FALSE;
	
	pFidData->bAcquire[b2ndPanel] = bAcquire;
	
	return TRUE;
}

LPFIDDATA GlyphExcellon::GetFiducialData(int nFidKind, int nIndex)
{
	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return NULL;
	
	LPFIDDATA pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	if(pFidData == NULL)
		return NULL;
	
//	nIndex = pFidData->nFindIndex; // sorted data
//	pFidData = m_FiducialData[nFidKind].GetFidData(nIndex);
	
	return pFidData;
}

BOOL GlyphExcellon::GetBigFidIndex(int* nIndexFid, int nFidKind, BOOL b1st, int nFidRank)
{
	BOOL bRet = FALSE;
	LPFIDDATA tempFidData, pFidData;

	int nMinX = INT_MAX, nMinY = INT_MAX;
	int nMaxX = -INT_MAX, nMaxY = -INT_MAX;

	for(int i=0; i< GetUseFidCount(nFidKind); i++)
	{
		tempFidData = GetFiducialData(nFidKind, i);

		if(!(tempFidData->nFidType & nFidRank))
			continue;

		if(tempFidData->nFidType & FID_VERIFY)
			continue;
		
		if(tempFidData->npPosition.x < nMinX) nMinX = tempFidData->npPosition.x;
		if(tempFidData->npPosition.x > nMaxX) nMaxX = tempFidData->npPosition.x;
		if(tempFidData->npPosition.y < nMinY) nMinY = tempFidData->npPosition.y;
		if(tempFidData->npPosition.y > nMaxY) nMaxY = tempFidData->npPosition.y;
	}
	
	// ��� fid �������� center��
	CPoint npCenter;
	npCenter.x = (long)((nMaxX + nMinX) / 2.0);
	npCenter.y = (long)((nMaxY + nMinY) / 2.0);

	int nLeft = 0, nRight = 0, nCnt = 0;
	int* nIndexLeft;
	nIndexLeft = new int [MAX_FID_NO];
	int* nIndexRight;
	nIndexRight = new int [MAX_FID_NO];

	for(int i = 0; i< GetUseFidCount(nFidKind); i++)
	{		
		pFidData = GetFiducialData(nFidKind, i);
		if( (b1st && !pFidData->bAcquire[0]) || (!b1st && !pFidData->bAcquire[1]))
			continue;

		if(nFidRank != 0)
		{
			if(!(pFidData->nFidType & nFidRank))
				continue;
		}

		 if(pFidData->nFidType & FID_VERIFY)
			 continue;

		if(pFidData->npPosition.x < npCenter.x)
		{
			nIndexLeft[nLeft] = i;
			nLeft++;
			nCnt++;
		}
		if(pFidData->npPosition.x > npCenter.x)
		{
			nIndexRight[nRight] = i;
			nRight++;
			nCnt++;
		}
	}

	if(nLeft < 1 || nRight < 1 || nCnt < 3)
	{
		if(nIndexLeft)
		{
			delete nIndexLeft;
			nIndexLeft = NULL;
		}
		
		if(nIndexRight)
		{
			delete nIndexRight;
			nIndexRight = NULL;
		}

		return FALSE;
	}
	else
		bRet = TRUE;

	int nLongIndex[2];
	double dDistX, dDistY, dDistance;
	double dDistMax = -DBL_MAX;
	LPFIDDATA pLongData;

	if(nCnt >= 4)
	{	
		nCnt = 0;

		if(nLeft > 2)
		{
			for(int i=0; i<nLeft; i++)
			{
				pFidData = GetFiducialData(nFidKind, nIndexLeft[i]);

				dDistX = abs(npCenter.x - pFidData->npPosition.x);
				dDistY = abs(npCenter.y - pFidData->npPosition.y);
				dDistance = sqrt(dDistX * dDistX + dDistY * dDistY);

				if(dDistance > dDistMax)
				{
					dDistMax = dDistance;
					nLongIndex[0] = nIndexLeft[i];
					pLongData = pFidData;
				}
			}

			dDistMax = -DBL_MAX;
			for(int i = 0; i<nLeft; i++)
			{
				pFidData = GetFiducialData(nFidKind, nIndexLeft[i]);

				if(pLongData == pFidData)
					continue;
				
				dDistX = abs(npCenter.x - pFidData->npPosition.x);
				dDistY = abs(npCenter.y - pFidData->npPosition.y);
				dDistance = sqrt(dDistX * dDistX + dDistY * dDistY);
				
				if(dDistance > dDistMax)
				{
					dDistMax = dDistance;
					nLongIndex[1] = nIndexLeft[i];
				}
			}

			for(int i = 0; i<2; i++)
			{
				pFidData = GetFiducialData(nFidKind, nLongIndex[i]);
				nIndexFid[nCnt++] = nLongIndex[i];
			}
		}
		else
		{
			for(int i=0; i<nLeft; i++)
			{
				nIndexFid[nCnt++] = nIndexLeft[i];
			}
		}

		if(nRight > 2)
		{
			dDistMax = -DBL_MAX;
			
			for(int i=0; i<nRight; i++)
			{
				pFidData = GetFiducialData(nFidKind, nIndexRight[i]);

				dDistX = abs(npCenter.x - pFidData->npPosition.x);
				dDistY = abs(npCenter.y - pFidData->npPosition.y);
				dDistance = sqrt(dDistX * dDistX + dDistY * dDistY);

				if(dDistance > dDistMax)
				{
					dDistMax = dDistance;
					nLongIndex[0] = nIndexRight[i];
					pLongData = pFidData;
				}
			}
			
			dDistMax = -DBL_MAX;
			for(int i = 0; i<nRight; i++)
			{
				pFidData = GetFiducialData(nFidKind, nIndexRight[i]);

				if(pLongData == pFidData)
					continue;
				
				dDistX = abs(npCenter.x - pFidData->npPosition.x);
				dDistY = abs(npCenter.y - pFidData->npPosition.y);
				dDistance = sqrt(dDistX * dDistX + dDistY * dDistY);
				
				if(dDistance > dDistMax)
				{
					dDistMax = dDistance;
					nLongIndex[1] = nIndexRight[i];
				}
			}
			
			for(int i = 0; i<2; i++)
			{
				pFidData = GetFiducialData(nFidKind, nLongIndex[i]);
				nIndexFid[nCnt++] = nLongIndex[i];
			}
		}
		else
		{
			for(int i=0; i<nRight; i++)
			{
				nIndexFid[nCnt++] = nIndexRight[i];
			}
		}
	}

	if(nIndexLeft)
	{
		delete nIndexLeft;
		nIndexLeft = NULL;
	}

	if(nIndexRight)
	{
		delete nIndexRight;
		nIndexRight = NULL;
	}
	
	return bRet;
}

// nFidRank Ÿ�԰� ��ġ�ϴ� ���߿� ã�����͸� apply�� ����ϱ� ���ؼ�
BOOL GlyphExcellon::GetFidIndex(int* nIndexFid, int nFidKind, BOOL b1st, int nFidRank)
{
	LPFIDDATA pFidData;
	int nCnt = 0;

	for(int i=0; i< GetUseFidCount(nFidKind); i++)
	{		
		pFidData = GetFiducialData(nFidKind, i);
		if( (b1st && !pFidData->bAcquire[0]) || (!b1st && !pFidData->bAcquire[1]))
			continue;

		if(nFidRank != 0)
		{
			if(!(pFidData->nFidType & nFidRank))
				continue;
		}

		 if(pFidData->nFidType & FID_VERIFY)
			 continue;

		 nIndexFid[nCnt++] = i;
	}

	if(nCnt >= 2)
		return TRUE;
	else
		return FALSE;
}

int GlyphExcellon::GetUseFidCount(int nFidKind, int nAddProp, int nDelProp, int nFidBlock)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return 0;
	
	int nCount = 0;
	LPFIDDATA pFidData;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		
		if(pFidData->cType != FID_FILE_NOT_USE &&
			(pFidData->nFidType & nAddProp) == nAddProp &&
			(pFidData->nFidType & nDelProp) == 0)
		{
			if(nFidBlock == -1 || nFidBlock == pFidData->nFidBlock)
				nCount++;
		}
	}
	
	return nCount;
}

LPFIDDATA GlyphExcellon::GetUsedFiducialData(int nFidKind, int nIndex, int nAddProp, int nDelProp, int nFidBlock)
{
	if(nFidKind < 0 || nFidKind > MAX_FID_KIND_NO)
		return 0;
	
	int nCount = 0;
	LPFIDDATA pFidData = NULL;
	POSITION pos = m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		
		if(pFidData->cType != FID_FILE_NOT_USE &&
			(pFidData->nFidType & nAddProp) == nAddProp &&
			(pFidData->nFidType & nDelProp) == 0)
		{
			if(nFidBlock == -1 || nFidBlock == pFidData->nFidBlock)
			{
				if(nCount == nIndex)
					return pFidData;
				nCount++;
			}
		}
	}
	return NULL;
}


BOOL GlyphExcellon::MakeUnitsForContinuousLine(DUnit* pUnit)
{
	m_Units.AddTail(pUnit); //20210716
	return TRUE;
//	CCorrectTime myTime;
	int nMeetLineLimit = 3;
	if(pUnit->m_HoleData.GetCount())
	{
		m_Units.AddTail(pUnit);
		return TRUE;
	}
	else
	{
		DUnit* pNewUnit = NULL;
		CPoint npStartPos, npEndPos;
		LPLINEDATA pLine;
		POSITION pos, posBefore;

//		double dTime, dOldTime = 0;
//		myTime.StartTime();
//		int nAddCount = 0;
		while(TRUE)
		{
			posBefore = pos = pUnit->m_LineData.GetHeadPosition();
			if(!pos)
				break;

			npStartPos.x = INT_MAX;
			pNewUnit = new DUnit;
			while (pos) 
			{
				pLine = pUnit->m_LineData.GetNext(pos);
				if(npStartPos.x == INT_MAX)
				{
					npStartPos = pLine->npStartPos;
					npEndPos = pLine->npEndPos;
					pNewUnit->m_LineData.AddTail(pLine);
					pUnit->m_LineData.RemoveAt(posBefore);
				}
				else
				{
					if(abs(npEndPos.x - pLine->npStartPos.x) < nMeetLineLimit && 
						abs(npEndPos.y - pLine->npStartPos.y) < nMeetLineLimit) // end --> new start ����
					{
						pLine->npStartPos = npEndPos;
						npEndPos = pLine->npEndPos;
						pNewUnit->m_LineData.AddTail(pLine);
						pUnit->m_LineData.RemoveAt(posBefore);
					}
					else if(abs(npEndPos.x - pLine->npEndPos.x) < nMeetLineLimit && 
							abs(npEndPos.y - pLine->npEndPos.y) < nMeetLineLimit) // end --> new end ���� : ���� ���� ��ȯ �ʿ�
					{
						pLine->npEndPos = pLine->npStartPos;
						pLine->npStartPos = npEndPos;
						npEndPos = pLine->npEndPos;
						pNewUnit->m_LineData.AddTail(pLine);
						pUnit->m_LineData.RemoveAt(posBefore);
					}
					else if(abs(npStartPos.x - pLine->npEndPos.x) < nMeetLineLimit && 
						abs(npStartPos.y - pLine->npEndPos.y) < nMeetLineLimit) // new end --> start ����
					{
						pLine->npEndPos = npStartPos;
						npStartPos = pLine->npStartPos;
						pNewUnit->m_LineData.AddHead(pLine);
						pUnit->m_LineData.RemoveAt(posBefore);
					}
					else if(abs(npStartPos.x - pLine->npStartPos.x) < nMeetLineLimit && 
							abs(npStartPos.y - pLine->npStartPos.y) < nMeetLineLimit) // new satart --> start ���� : ���� ���� ��ȯ �ʿ�
					{
						pLine->npStartPos = pLine->npEndPos;
						pLine->npEndPos = npStartPos;
						npStartPos = pLine->npStartPos;
						pNewUnit->m_LineData.AddHead(pLine);
						pUnit->m_LineData.RemoveAt(posBefore);
					}
					else 
						break;
				}
				posBefore = pos;
			}
			if(pNewUnit)
			{
				pNewUnit->ReCalRect(&m_Blocks);
				m_Units.AddTail(pNewUnit);
				
//				nAddCount++;
//				if(nAddCount % 100 == 0)
//				{
//					dTime = myTime.PresentTime();
//					TRACE("%d\t%.6f\t%d\n", nAddCount, dTime - dOldTime, pUnit->m_LineData.GetCount());
//					dOldTime = dTime;
//				}
			}
		}

		delete pUnit;
		pUnit = NULL;
		return TRUE;
	}
}
void GlyphExcellon::DisplayBlockDots(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, int nSkipNo)
{
	int nCount;
	POSITION pos = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock, pFoundBlock = NULL;
	while(pos)
	{
		pBlock = m_Blocks.GetNext(pos);
		if(pBlock->m_nBlockName == nBlockName)
		{
			pFoundBlock = pBlock;
			break;
		}
	}
	if(pFoundBlock)
	{
		CPoint ptStart, ptEnd;
		ptStart.x = pBlock->m_nMinX + x; ptStart.y = pBlock->m_nMinY + y;
		ptEnd.x = pBlock->m_nMaxX + x; ptEnd.y = pBlock->m_nMaxY + y;
		if(!IsDrawData(nMode, ptStart, ptEnd, (int)dStartX, (int)dStartY, (int)dEndX, (int)dEndY, 0))
			return;
		int nX = 0, nY = 0, nX2 = 0, nY2 = 0, nOldX = 0, nOldY = 0;
		GetXY(nMode, ptStart.x, ptStart.y, nX, nY, dStartX, dStartY, dScale);
		GetXY(nMode, ptEnd.x,  ptEnd.y, nX2, nY2, dStartX, dStartY, dScale);
	/*
		if(nX2 - nX < 10 || nY - nY2 < 10)
		{
			//pDC->Rectangle(nX, nY, nX + 10, nY + 10);
			DisplayAreaDot(pDC, nX, nY,	pColor);
			return;//20161114
		}
		*/
		LPHOLEDATA pHole;
		pos = pBlock->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pBlock->m_HoleData.GetNext(pos);
			nCount = rand();
			if(nCount % nSkipNo)
				continue;

			GetXY(nMode, pHole->npPos.x + x, pHole->npPos.y + y, nX, nY, dStartX, dStartY, dScale);
			DisplayAreaDot(pDC, nX, nY,	pColor);
			
		}

	}
}

LPDBLOCK GlyphExcellon::GetBlock(int nBlockName)
{
	if(nBlockName <= 0)
		return NULL;

	POSITION pos = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	while(pos)
	{
		pBlock = m_Blocks.GetNext(pos);
		if(pBlock->m_nBlockName == nBlockName)
			return pBlock;
	}
	return NULL;
}

int GlyphExcellon::GetSameBlockIndex(DBlock* pBlock, double& dDistX, double& dDistY)
{
	POSITION pos = m_Blocks.GetHeadPosition();
	LPDBLOCK pOriginBlock;
	while(pos)
	{
		pOriginBlock = m_Blocks.GetNext(pos);
		if(pOriginBlock->GetSameBlockIndex(pBlock, dDistX, dDistY))
			return pOriginBlock->m_nBlockName;
	}
	return -1; // not found
}

int GlyphExcellon::GetHoleDataBlockCount(int nBlockName)
{
	POSITION pos = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	while(pos)
	{
		pBlock = m_Blocks.GetNext(pos);
		if(pBlock->m_nBlockName == nBlockName)
			return pBlock->m_HoleData.GetCount();
	}
	return 0;
}


void GlyphExcellon::RemoveAllBlock()
{
	POSITION pos = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	while(pos)
	{
		pBlock = m_Blocks.GetNext(pos);
		delete pBlock;
	}
	m_Blocks.RemoveAll();
}





void GlyphExcellon::BlockFirstPositionToZero()
{
	POSITION posBlock = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	CPoint ptOffset;
	while(posBlock)
	{
		pBlock = m_Blocks.GetNext(posBlock);
		ptOffset = pBlock->BlockFirstPositionToZero();

		POSITION posUnit = m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		while(posUnit)
		{
			pUnit = m_Units.GetNext(posUnit);
			pUnit->BlockFirstPositionToZero(ptOffset, pBlock->m_nBlockName);
		}
	}
	ReCalRect(TRUE);
}

void GlyphExcellon::SortOriginBlockHole()
{
	POSITION posBlock = m_Blocks.GetHeadPosition();
	LPDBLOCK pBlock;
	CPoint ptOffset;
	while(posBlock)
	{
		pBlock = m_Blocks.GetNext(posBlock);
		pBlock->SortOriginBlockHole();
	}
}

BOOL GlyphExcellon::IsDrawData(int nMode, CPoint ptStart, CPoint ptEnd, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName)
{
	if(nBlockName != 0)
		return TRUE;
	int nTransX, nTransY, nTransX2, nTransY2;
	
	if(nMode == X_Y)
	{
		nTransX = ptStart.x;		nTransY = ptStart.y;
		nTransX2 = ptEnd.x;		nTransY2 = ptEnd.y;
	}
	else if(nMode == MX_Y)
	{
		nTransX = - ptStart.x;		nTransY = ptStart.y;
		nTransX2 = - ptEnd.x;		nTransY2 = ptEnd.y;
	}
	else if(nMode == X_MY)
	{
		nTransX =  ptStart.x;		nTransY = -ptStart.y;
		nTransX2 =  ptEnd.x;		nTransY2 = -ptEnd.y;
	}
	else if(nMode == MX_MY)
	{
		nTransX = - ptStart.x;		nTransY = -ptStart.y;
		nTransX2 = - ptEnd.x;		nTransY2 = -ptEnd.y;
	}
	else if(nMode == Y_X)
	{
		nTransX = ptStart.y;		nTransY =  ptStart.x;
		nTransX2 = ptEnd.y;		nTransY2 =  ptEnd.x;
	}
	else if(nMode == MY_X)
	{
		nTransX = -ptStart.y;		nTransY =  ptStart.x;
		nTransX2 = -ptEnd.y;		nTransY2 =  ptEnd.x;
	}
	else if(nMode == Y_MX)
	{
		nTransX = ptStart.y;		nTransY = - ptStart.x;
		nTransX2 = ptEnd.y;		nTransY2 = - ptEnd.x;
	}
	else
	{
		nTransX = -ptStart.y;		nTransY = - ptStart.x;
		nTransX2 = -ptEnd.y;		nTransY2 = - ptEnd.x;
	}

	int nMinX, nMinY, nMaxX, nMaxY;
	nMinX = min(nTransX, nTransX2);
	nMaxX = max(nTransX, nTransX2);
	nMinY = min(nTransY, nTransY2);
	nMaxY = max(nTransY, nTransY2);

	if(nMaxX < nStartX) 
		return FALSE;
	if(nMinX > nEndX) 
		return FALSE;
	if(nMaxY < nEndY) 
		return FALSE;
	if(nMinY > nStartY) 
		return FALSE;

	return TRUE;
}

void GlyphExcellon::SetBlockInfoToToolInfo(CToolCodeList** pToolCodes)
{
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		pToolCodes[i]->m_bContainBlockData = FALSE;
		pToolCodes[i]->m_nTempToolIsHole = FALSE;
	}

	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);
		pUnit->SetBlockInfoToToolInfo(pToolCodes);
	}
}
void GlyphExcellon::GetProjectMinMaxValue(double &MinX, double &MaxX, double &MinY, double &MaxY)
{

	double dHoleMinX = 9999.999;
	double dHoleMinY = 9999.999;
	double dHoleMaxX = -9999.999;
	double dHoleMaxY = -9999.999;

	double dLineMinX = 9999.999;
	double dLineMinY = 9999.999;
	double dLineMaxX = -9999.999;
	double dLineMaxY = -9999.999;



	BOOL IsFirst = TRUE;


	POSITION pos;
	POSITION posUnit = m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Units.GetNext(posUnit);

		pos = pUnit->m_HoleData.GetHeadPosition();
		LPHOLEDATA pData;



		while (pos) 
		{
			pData = pUnit->m_HoleData.GetNext(pos);

			if(!(gDProject.m_pToolCode[pData->nToolNo]->m_bUseTool && gDProject.m_pToolCode[pData->nToolNo]->m_bVisible))
				continue;

			if(IsFirst)
			{
				dHoleMinX = pData->npPos.x;
				dHoleMinY = pData->npPos.y;
				dHoleMaxX = pData->npPos.x;
				dHoleMaxY = pData->npPos.y;
				IsFirst = FALSE;
				continue;
			}

			if(pData->npPos.x < dHoleMinX)
				dHoleMinX = pData->npPos.x ;

			if(pData->npPos.x > dHoleMaxX)
				dHoleMaxX = pData->npPos.x ;

			if(pData->npPos.y < dHoleMinY)
				dHoleMinY = pData->npPos.y ;

			if(pData->npPos.y > dHoleMaxY)
				dHoleMaxY = pData->npPos.y ;

		}



		// draw line
		IsFirst = TRUE;
		pos = pUnit->m_LineData.GetHeadPosition();
		LPLINEDATA pLineData;

		while (pos) 
		{
			pLineData = pUnit->m_LineData.GetNext(pos);


			if(!(gDProject.m_pToolCode[pLineData->nToolNo]->m_bUseTool && gDProject.m_pToolCode[pLineData->nToolNo]->m_bVisible))
				continue;

			if(IsFirst)
			{
				if(pLineData->npStartPos.x > pLineData->npEndPos.x)
				{
					dLineMinX = pLineData->npEndPos.x;
					dLineMaxX = pLineData->npStartPos.x;
				}
				else
				{	dLineMinX = pLineData->npStartPos.x;
				dLineMaxX = pLineData->npEndPos.x;
				}

				if(pLineData->npStartPos.y > pLineData->npEndPos.y)
				{
					dLineMinY = pLineData->npEndPos.y;
					dLineMaxY = pLineData->npStartPos.y;
				}
				else
				{	dLineMinY = pLineData->npStartPos.y;
				dLineMaxY = pLineData->npEndPos.y;
				}
				IsFirst = FALSE;
				continue;
			}

			if( pLineData->npStartPos.x < dLineMinX)
				dLineMinX = pLineData->npStartPos.x;

			if( pLineData->npEndPos.x < dLineMinX)
				dLineMinX = pLineData->npEndPos.x;

			if( pLineData->npStartPos.x > dLineMaxX)
				dLineMaxX = pLineData->npStartPos.x;

			if( pLineData->npEndPos.x > dLineMaxX)
				dLineMaxX = pLineData->npEndPos.x;



			if( pLineData->npStartPos.y < dLineMinY)
				dLineMinY = pLineData->npStartPos.y;

			if( pLineData->npEndPos.y < dLineMinY)
				dLineMinY = pLineData->npEndPos.y;

			if( pLineData->npStartPos.y > dLineMaxY)
				dLineMaxY = pLineData->npStartPos.y;

			if( pLineData->npEndPos.y > dLineMaxY)
				dLineMaxY = pLineData->npEndPos.y;
		}

	}


	if(dHoleMinX > dLineMinX)
		MinX = dLineMinX;
	else
		MinX = dHoleMinX;

	if(dHoleMaxX > dLineMaxX)
		MaxX = dHoleMaxX;
	else
		MaxX = dLineMaxX;

	if(dHoleMinY > dLineMinY)
		MinY = dLineMinY;
	else
		MinY = dHoleMinY;

	if(dHoleMaxY > dLineMaxY)
		MaxY = dHoleMaxY;
	else
		MaxY = dLineMaxY;

}