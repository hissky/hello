// HDeviceFactory.cpp: implementation of the HDeviceFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HDeviceFactory.h"
#include "HMotorMP920.h"
#include "DeviceMotor.h"
#include "HVision.h"
#include "HHeightSensor.h"
#include "..\alarmmsg.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "HEocard.h"
#include "..\model\ScannerCompensation.h"
#include "HLaser.h"
#include "HLaserAttenuator.h"
#include "..\model\DBeampathINI.h"
#include "..\ui\ProgressWnd.h"
#include"..\MODEL\DTemperCompensation.h"
#include"..\MODEL\DPowerAttenCompensation.h"
//#include "comimotion.h"
//#include "comidaq.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HDeviceFactory gDeviceFactory;

HDeviceFactory::HDeviceFactory()
{
	m_pMotor			= NULL;
	m_pVision			= NULL;
	m_pHeightSensor		= NULL;
	m_pEocard			= NULL;
	m_pLaser			= NULL;
	m_pAttenuator		= NULL;
	m_p1stTemperCompen = NULL;
	m_p2ndTemperCompen = NULL;
	m_pPwrAttenCompen = NULL;
}

HDeviceFactory::~HDeviceFactory()
{

}

BOOL HDeviceFactory::InitializeDevice(CComiMotion* pMotion, CComiDaq* pDaq)
{
	CProgressWnd wndProgress(NULL, _T("Device initialize"), TRUE);
	wndProgress.GoModal();
	wndProgress.SetRange(0, 0);
	wndProgress.SetText(_T("initializing"));
	BOOL bRet = FALSE;

	// Init Motor
	wndProgress.SetText(_T("Motor initializing"));
#ifdef __MP920_MOTOR__
	m_pMotor = new HMotorMP920;
#else
	m_pMotor = new DeviceMotor;
#endif

	// Set Calibration Type
	m_pMotor->SetCalType( gEasyDrillerINI.m_clsHwOption.GetCalibrationType() );
	// Set Motor Type
	m_pMotor->SetMotorType( gEasyDrillerINI.m_clsHwOption.GetMotorType() );
	// Set Use Dual Panel
	m_pMotor->SetUseDualPanel( gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() );
#ifndef __MP920_MOTOR__
	if( FALSE == m_pMotor->InitMotor(pMotion, pDaq) )
#else
	if( FALSE == m_pMotor->InitMotor() )
#endif
		ErrMessage(_T("Fail Motor Initializing"));//ErrMsgDlg(STDGNALM1003);
	else
	{
		// Set Fixed Mask Position 
		m_pMotor->SetFixedMaskPos( gBeamPathINI.m_sBeampath.nFixedMask );
		// Set Auto Setting
		m_pMotor->SetAutoSetting( gProcessINI.m_sProcessAutoSetting );

		// Set Axis Info
		m_pMotor->SetAxisInfo( gSystemINI.m_sAxisInfo );

		// Download Axis Info
		m_pMotor->DownloadAxisInfo();

		// Download Auto Setting
		m_pMotor->DownloadAutoSetting();
		
		// Vacuum Low LImit
//		m_pMotor->SetTableVacuumLimit(gSystemINI.m_sSystemVacuum.dTable1Vacuum, gSystemINI.m_sSystemVacuum.dTable2Vacuum);
	}
#ifndef __MP920_MOTOR__
	m_pMotor->SetOutPort(PORT_MPG_MODE, 0);
	m_pMotor->SetOutPort(PORT_MODE_SELECT, 1);
	m_pMotor->SetOutPort(PORT_ALARM, 0);
	m_pMotor->SetOutPort(PORT_AUTO_MPG, FALSE);
	m_pMotor->MainStop();
	m_pMotor->MainReady(FALSE);
	m_pMotor->SetLimitYPos(gProcessINI.m_sProcessAutoSetting.dUnclampLimitY);

	if(gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock == TRUE)
		m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, FALSE);
	else
		m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, TRUE);
	
	if(gProcessINI.m_sProcessSystem.bDryRun == TRUE)
		m_pMotor->SetOutPort(PORT_LASER_BYPASS, TRUE);
	else
		m_pMotor->SetOutPort(PORT_LASER_BYPASS, FALSE);

	m_pMotor->SetUseNGBox(!gProcessINI.m_sProcessSystem.bNoUseNGBox);
	m_pMotor->SetUsePaperBox(!gProcessINI.m_sProcessSystem.bNoUsePaper);
	m_pMotor->SetReverseDirection(FALSE);
	m_pMotor->SetTrunPanel(gProcessINI.m_sProcessSystem.bUseTurnPanel);
	m_pMotor->SetNoUseLoadUnload(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader);
#else
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_HEIGHT_SENSOR, FALSE, TRUE);
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0, TRUE);
	
	if(gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock == TRUE)
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_SYSTEM_DOOR_BYPASS, FALSE);
	else
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_SYSTEM_DOOR_BYPASS, TRUE);
	
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_DRILL_START, 0, TRUE);
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	
	m_pMotor->SetWaterFlow1Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting1);
	m_pMotor->SetWaterFlow2Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting2);
	m_pMotor->SetMainAirValue(gSystemINI.m_sSystemDevice.dMainAirSetting);
	m_pMotor->SetDustSuctionValue(gSystemINI.m_sSystemDevice.dDustSuctionSetting);
	m_pMotor->SetTableVauumValue(TRUE, gSystemINI.m_sSystemDevice.dTableVacuumSetting1);
	m_pMotor->SetTableVauumValue(FALSE, gSystemINI.m_sSystemDevice.dTableVacuumSetting2);
#endif
#ifndef __PUSAN_OLD_17__
	m_pMotor->SetOutportTableVacuum(0); // Table vacuum type A
#endif
	wndProgress.SetText(_T("Height Sensor initializing"));

	m_pMotor->HandlerOperation(UI_DIRLL_STATUS_SET, FALSE);
	m_pMotor->SetAlarmTolLed(FALSE);
	// Init Height Sensor
	m_pHeightSensor = new HHeightSensor;
	m_pHeightSensor->SetSensorID(0, (LPSTR)(LPCTSTR)gSystemINI.m_sSystemDevice.sz1stHeightSensorID );
	m_pHeightSensor->SetSensorID(1, (LPSTR)(LPCTSTR)gSystemINI.m_sSystemDevice.sz2ndHeightSensorID );
	m_pHeightSensor->InitHeightSensor();

	wndProgress.SetText(_T("EOcard initializing"));

	// init eocard
	m_pEocard = new HEocard();
	m_pEocard->Create();
	
	if(!m_pEocard->DrillStandbyShotStart(FALSE))
	{
		ErrMessage(_T("Check EOCard Status\n Can't Setting DummyShot Mode"));
		return FALSE;
	}
	if(!m_pEocard->FlyingModeEnable(FALSE))
	{
		ErrMessage(IDS_ERR_EOCARD);
		return FALSE;
	}

	m_pEocard->ResetScannerStatusErrorCount();

	wndProgress.SetText(_T("Laser initializing"));
			// init laser
	m_pLaser = new HLaser();
	m_pLaser->Create();

	CString strMaster, strSlave;
	char sz1stFile[255], sz2ndFile[255];
	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[0]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[0]);
	lstrcpy(sz1stFile, strMaster);
	lstrcpy(sz2ndFile, strSlave);
	
	if(!m_pEocard->LoadCalibrationFile(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, _T("ASC"));
		ErrMessage(strMsg);

		CString strTemp;
		strTemp.Format(_T("%s or %s"), sz1stFile, sz2ndFile);
		strMsg.Format(strString, strTemp);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
//		return FALSE;
#endif
	}
	
	if(!m_pEocard->DownloadShotDrillScannerParam())
	{
#ifndef __TEST__
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, gEasyDrillerINI.m_clsDirPath.GetScannerProfileFilePath());
		ErrMessage(strMsg);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));

//		return FALSE;
#endif
	}

	if(!gDeviceFactory.GetEocard()->DummyParamSet())
	{
#ifndef __TEST__
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Dump Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Error : Dummy shot parameter download Failure"));
#endif
	}

	if(!gDeviceFactory.GetEocard()->StandbyParamSet())
	{
#ifndef __TEST__
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Standby Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Error : Standby shot parameter download Failure"));
#endif
	}
	
	gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE);
	
	
	if(!gScannerCompensation.OpenData())
	{
#ifndef __TEST__
//		while(1)
//		{
//			if(IDOK == ErrMessage(_T("�� ������ Scanner compensation ���������� scannerGrid.cal ������ �������� �ʾ� �������� ������ �߻��� �� �ֽ��ϴ�.")))
//				break;
//		}
#endif
	}

	m_pAttenuator = new HLaserAttenuator();
#ifndef __TEST__
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(!m_pAttenuator->Initialize(m_pMotor))
		{
			ErrMessage(_T("Attenuator InitFailure"));
			CString str;
			str.Format(_T("Attenuator InitFailure"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
			return FALSE;
		}
	}
#endif
	wndProgress.SetText(_T("Vision initializing"));
	// Init Vision
	m_pVision = new HVision;
	if(!m_pVision->Initialize())
	{
		return FALSE;
	}	

	m_p1stTemperCompen = new DTemperCompensation;
	CString strFile;
	strFile.Format(_T("%s\\Temper.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	if(!m_p1stTemperCompen->LoadTemperCompenFile(strFile))
	{
		if(gSystemINI.m_sHardWare.bTemperCompConnect == 0)
		{
			m_p1stTemperCompen->m_bNoCalReturn = TRUE;
			CString str;
			str.Format(_T("Temperature Compensation Off - no use hardware"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
		}

		if(gProcessINI.m_sProcessOption.bTemperCompensationMode && gSystemINI.m_sHardWare.bTemperCompConnect)
		{
			ErrMessage(_T("Temperature Compensation File Open Error. Please check the Temper.Table file."));
		}
		CString str;
		str.Format(_T("Temperature Compensation File Open Error"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	}

	m_p2ndTemperCompen = new DTemperCompensation;
	strFile.Format(_T("%s\\TemperS.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	if(!m_p2ndTemperCompen->LoadTemperCompenFile(strFile))
	{
		if(gSystemINI.m_sHardWare.bTemperCompConnect == 0)
		{
			m_p2ndTemperCompen->m_bNoCalReturn = TRUE;
			CString str;
			str.Format(_T("Temperature Compensation Off - no use hardware"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
		}

		if(gProcessINI.m_sProcessOption.bTemperCompensationMode && gSystemINI.m_sHardWare.bTemperCompConnect)
		{
			ErrMessage(_T("Temperature Compensation File Open Error. Please check the TemperS.Table file."));
		}
		CString str;
		str.Format(_T("Temperature Compensation File Open Error"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	}

	m_pPwrAttenCompen = new DPowerAttenCompensation;
	m_pPwrAttenCompen->LoadFile(0);
	m_pPwrAttenCompen->LoadFile(1);

	return TRUE;
}

#ifdef __MP920_MOTOR__
HMotor* HDeviceFactory::GetMotor()
{
	return m_pMotor;
}
#else
DeviceMotor* HDeviceFactory::GetMotor()
{
	return m_pMotor;
}
#endif

HVision* HDeviceFactory::GetVision()
{
	return m_pVision;
}

HHeightSensor* HDeviceFactory::GetHeightSensor()
{
	return m_pHeightSensor;
}

HEocard* HDeviceFactory::GetEocard()
{
	return m_pEocard;
}

HLaser* HDeviceFactory::GetLaser()
{
	return m_pLaser;
}

HLaserAttenuator* HDeviceFactory::GetAttenuator()
{
	return m_pAttenuator;
}

DTemperCompensation* HDeviceFactory::Get1stTemperCompen()
{
	return m_p1stTemperCompen;
}

DTemperCompensation* HDeviceFactory::Get2ndTemperCompen()
{
	return m_p2ndTemperCompen;
}

DPowerAttenCompensation* HDeviceFactory::GetPwrAttenCompen()
{
	return m_pPwrAttenCompen;
}

void HDeviceFactory::DestroyDevice()
{
	if( NULL != m_pMotor )
	{
		m_pMotor->MainStop();
		m_pMotor->MainReady(FALSE);
//		m_pMotor->ScannerPower(FALSE);
		m_pMotor->WriteOutputIOBIt(1, 6, FALSE);
		m_pMotor->DestroyMotor();

		delete m_pMotor;
		m_pMotor = NULL;
	}

	if( NULL != m_pVision )
	{
		delete m_pVision;
		m_pVision = NULL;
	}

	if( NULL != m_pHeightSensor )
	{
		delete m_pHeightSensor;
		m_pHeightSensor = NULL;
	}

	if( NULL != m_pLaser )
	{
		delete m_pLaser;
		m_pLaser = NULL;
	}

	if( NULL != m_pEocard )
	{
		delete m_pEocard;
		m_pEocard = NULL;
	}
	
	if( NULL != m_pAttenuator)
	{
		delete m_pAttenuator;
		m_pAttenuator = NULL;
	}

	if( NULL != m_p1stTemperCompen)
	{
		delete m_p1stTemperCompen;
		m_p1stTemperCompen = NULL;
	}
	if( NULL != m_p2ndTemperCompen)
	{
		delete m_p2ndTemperCompen;
		m_p2ndTemperCompen = NULL;
	}

	if(NULL != m_pPwrAttenCompen)
	{
		delete m_pPwrAttenCompen;
		m_pPwrAttenCompen = NULL;
	}
}


