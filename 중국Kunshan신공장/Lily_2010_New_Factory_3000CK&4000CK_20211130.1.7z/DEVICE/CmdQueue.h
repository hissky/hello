// CmdQueue.h: interface for the CCmdQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CMDQUEUE_H__8EB8D2FF_BFBE_4CA6_9A32_8A17D011112A__INCLUDED_)
#define AFX_CMDQUEUE_H__8EB8D2FF_BFBE_4CA6_9A32_8A17D011112A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DOnlineCmdData ;

class CCmdQueue  
{
// Constructor
public:
	CCmdQueue();
	virtual ~CCmdQueue();

// Operation
public:
	BOOL			AddOnlineCmd(char* szCmd);
	BOOL			AddDPRamFloatData(int nSize, DWORD dwOffset, float* pfMemData);
	BOOL			AddDPRamDWORDData(int nSize, DWORD dwOffset, DWORD* pMemData, BOOL bRead=FALSE, int nDataType=0);
	BOOL			DeleteQueue(int nIndex=0);
	BOOL			DeleteAllQueue();
	DOnlineCmdData*	GetOnlineCmdData();
	BOOL			IsEmptyQueue();

// Attribute
protected:
	// Command Array
	CPtrArray	m_ptrCmdArray;
	// UMAC Critical Section
	CRITICAL_SECTION		m_Crit;
};

#endif // !defined(AFX_CMDQUEUE_H__8EB8D2FF_BFBE_4CA6_9A32_8A17D011112A__INCLUDED_)
