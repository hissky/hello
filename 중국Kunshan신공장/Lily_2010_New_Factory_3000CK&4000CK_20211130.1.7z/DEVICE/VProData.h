#if !defined(AFX_VPRODATA_H__A45F9710_0BD5_4465_991F_D11B2CDB0ED5__INCLUDED_)
#define AFX_VPRODATA_H__A45F9710_0BD5_4465_991F_D11B2CDB0ED5__INCLUDED_

#include "..\model\2DTransform.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VProData.h : header file
//

#define	CAM1			0
#define	CAM2			1
#define	CAM3			2
#define	CAM4			3

#define	DISPLAY1		0
#define	DISPLAY2		1
#define	DISPLAY3		2
#define	DISPLAY4		3

#define CREATEVP		15	//VisionPro ���� ���� ����


#define PI					3.1415926535897932
#define RtoD				180/PI		
#define DtoR				PI/180

#ifdef __USE_COGNEX_7_LIB__
#define CAM_TOT_COUNT		4   // �� ī�޶��
#else
#define CAM_TOT_COUNT		4   // �� ī�޶��
#endif
#define MAX_PMALIGN			4	// �۾� PMTOOL ����.



#define ResolutionX		760
#define ResolutionY		574


/*------------------------------
	���� ����ϴ� ������ �����̴�.`
	����� eRectangle�� �����ϴ�.
------------------------------*/
enum enum_PMPatternShapeType {
	eRectangle = 0,
	eCircle = 1,
	eRectangleAffine = 2,
	eEllipse = 3,
	ePolygon = 4,
	eCross = 5
};

/*------------------------------
	���� ����ϴ� ����� �����̴�.
	����� eTrainMethodUserWindow�� �����ϴ�.
------------------------------*/
enum enum_PMPatternTrainMethod {
	eTrainMethodUserWindow = 0,
	eTrainMethodBlob = 1,
	eTrainMethodEdge = 2
};

/////////////////////////////////////////////////////////////////////////////
// VProData window

class VProData : public CWnd
{
// Construction
public:
	VProData();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(VProData)
	//}}AFX_VIRTUAL

// Implementation
public:
	bool SaveImg(int iDisplayNo, CString lpszFileName);
	void InitDistancePerPixel();
	void InitVisionPixelData(int nCam);
	//BOOL LogicProcess(int nCam, int nImage, int nIndex, int nLogicPlrt, bool bDisplay);
	void CalPixelDistance();
	void TransformPixel();
	BOOL PMToolSetSearchAllRegion(int nID);
	void GetSearchRegion(int nID, double &cx, double &cy, double &cw, double &ch);
	void GetTrainRegion(int nID, double& cx, double& cy, double& cw, double& ch);
	BOOL GrabImage(int nID, int nCam);
	BOOL SetTrainRegion(int nID, int nCam);
	void DisplayTrainedPatten(int nPattern);
	BOOL GetTrained(int nPattern);

	BOOL m_bROIShow;
	void PMAlignToolAddToolGroup_Shape(int nID);
	
#ifdef USE_VISION_PRO
	CComPtr<ICogToolGroup>		m_pToolGroup;			//	Tool group
#ifdef __USE_COGNEX_7_LIB__
	CComPtr<ICogFrameGrabber>	m_pCogFrameGrabber;		//	Image Acquisition tools
#else
	CComPtr<ICogFrameGrabber>	m_pCogFrameGrabber[4];	
#endif
	CComPtr<ICogAcqFifo>		m_pAcqFifo[4];
	CComPtr<ICogAcqFifoTool>	m_pAcqFifoTool[4];
	CComPtr<ICogImage>			m_pImg[4];
	CComPtr<ICogDisplay>		m_pDisplay[6];				//	Display Tool  : cam 4 + display 2
//	CComPtr<ICogAcqBrightness>	m_pBrightness[4];
//	CComPtr<ICogAcqContrast>	m_pContrast[4];
	
	CComPtr<ICogPMAlignTool>	pCogPMAlignTool[CREATEVP];	// Pattern ��.
//	CComPtr<ICogPMAlignTool>	pCogPMAlignTool2[CREATEVP - MAX_PMALIGN];	// Shape ��.
#endif
	BOOL IsSkipCam(int nCam);
	void SetBlobValue(int nWhiteBlob);
	bool LoadImage( CString lpszFileName, bool bDisplay, int DisplayNo );
	bool PMToolTrain( int nID, int nCam, bool patternFlag, BOOL bApplyParam = FALSE); 
	bool LoadData( CString lpszFileName );
	bool SaveData( CString lpszFileName );
	bool LoadProject( CString lpszFileName );
	bool SaveProject( CString lpszFileName );
	bool LoadVPro( CString lpszFileName );
	bool SaveVPro( CString lpszFileName );
//	void PatternDisplay( int iPMToolNo, int iCamNo, bool bFit );
	int PMToolFind( int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag, BOOL bCoarseLimitChange = FALSE);

	void ClearInteractiveGraphics(int iDisplayNo);
	void ShowUserWindow(int nID,  BOOL bShow = true, enum_PMPatternShapeType nType = eRectangle );
	void SetUserWindow( double cx, double cy, double w, double h );
	void PMToolShowSearchRegion( int nID, BOOL bShow = TRUE,  int nCam= 0);
	bool GetUserWindow(int nID, BSTR strName, double *cx, double *cy, double *w, double *h );
	bool PMToolSetSearchRegion( int nID , int nCam = 0, BOOL bNoView = FALSE);
	void PMAlignToolAddToolGroup( int nID );
	void AllocPMAlignTool( int nCount );
	void CreatePMAlignTool( int nCount );
	void CheckPMAlignToolInstance( int nID );
	void CheckPMAlignToolInstanceShape(int nID);
	void PMToolShowTrainRegion( int nID, int nCam );
	bool SetDisplayWindow( int iCamNo, CWnd *pCWnd );
	void SetCameraPort( int nCameraPort = 0 );
	int SetCameraPortNo( int nCameraPort );
#ifdef __USE_COGNEX_7_LIB__
	bool InitVision( int nBoardNum = 0, CString lpszVideoFormat = _T("Sony XC-ST50CE 760x574 IntDrv CCF"), int nCameraPort = 0 );
#else
	bool InitVision64Bit( int nBoardNum = 0, CString lpszVideoFormat = _T("Sony XC-ST50CE 760x574 IntDrv CCF"), int nCameraPort = 0 );
#endif
	void ImageDisplay( int iCamNo, bool bFit = false );
	bool Acquire( int iDisplayNo, int iCamNo, bool bDisplay = false );
	void LiveImage( int iDisplay, int iCamNo, BOOL bStart );

	int			m_ShapeTypeNo, m_ShapePolarity;
	int			m_ShapeTypeNoData[CREATEVP], m_ShapePolarityData[CREATEVP], m_ShapeTrainBool[CREATEVP] ;
	bool		m_AutoOrgSetup;
	CString		m_ShapeCentertmpA, m_Disttmp;
	int			m_ShapeCenterA, m_Dist;

	int			m_AAreaBool[CREATEVP];
	double		m_TrainAreacx[CREATEVP], m_TrainAreacy[CREATEVP], m_TrainAreacw[CREATEVP], m_TrainAreach[CREATEVP], m_TrainAreacpx[CREATEVP], m_TrainAreacpy[CREATEVP];
	double		m_SearchAreacx[MAX_CAMERA], m_SearchAreacy[MAX_CAMERA], m_SearchAreacw[MAX_CAMERA], m_SearchAreach[MAX_CAMERA];

	double		m_ScaleP[CREATEVP], m_ScaleN[CREATEVP], m_ActScore[CREATEVP];
	double		m_SizeA[CREATEVP];
	double		m_SizeB[CREATEVP];
	double		m_SizeC[CREATEVP];
	double		m_BrightData[MAX_CAMERA], m_ContrastData[MAX_CAMERA];
	double		m_CalibData[MAX_CAMERA];
	double		m_dAngle[CREATEVP];
	double		m_dXYRatio[CREATEVP];
	int			m_nThreshold[CREATEVP];
	int			m_nBlob[CREATEVP];


	BOOL			m_bApplyParamFlag;



	bool		m_bAArea;
	int		m_nSelIndexNo; 
	virtual ~VProData();
	
	int m_nCamNo;
	long	m_ImageWidth, m_ImageHeight;

	void ChangeCam(int nCamNo);
	C2DTransform	m_2DTrans[4]; //cam number
	DPOINT			m_dCamPixel[4];
	//DPOINT			m_dLowPixel;
	bool	m_bInitBoard;	
	// Generated message map functions
protected:
	//{{AFX_MSG(VProData)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
			//	���� ���� �ʱ�ȭ ����
	HRESULT m_hr;

	double  m_UserWindowCX, m_UserWindowCY, m_UserWindowW, m_UserWindowH, m_UserWindowRotate;
	long	m_UserWindowSize;
	int		m_UserWindowShapeType;
	int		m_nPMAlignToolCount;

public:
	
};

/////////////////////////////////////////////////////////////////////////////
/****************************************************/
//	Ini File ���� �Լ�

void	IniDoubleToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, double Data );
double	IniDoubleFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default );
void	IniIntToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, int Data );
int		IniIntFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default );
void	IniLongToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, long Data );
long	IniLongFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default );
void	IniStringToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Data );
CString	IniStringFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default );

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VPRODATA_H__A45F9710_0BD5_4465_991F_D11B2CDB0ED5__INCLUDED_)
