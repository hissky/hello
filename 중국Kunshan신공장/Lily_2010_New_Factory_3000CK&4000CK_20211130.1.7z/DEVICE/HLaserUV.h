// HLaserUV.h: interface for the HLaserUV class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASERUV_H__A9FF13ED_2711_4DCB_8CDA_903EE30C69E9__INCLUDED_)
#define AFX_HLASERUV_H__A9FF13ED_2711_4DCB_8CDA_903EE30C69E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HLaserUV  
{
public:
	int GetTriggerMode();// 20090629 Front Mode error
	HLaserUV();
	virtual ~HLaserUV();

	void Initialize();
	BOOL IsTempReady();
	void OpenPowerDlg();
	BOOL IsPowerOn();
	BOOL IsShutterOpen();
	BOOL IsPulseOpen();
	BOOL ChangeAviaDiodeCurrent(double dDiodeCurrent, long lFreq, int nThermalTrack = -1);
	void PowerOn(BOOL bFlag);
	void ShutterOpen(BOOL bFlag);
	void PulseOpen(BOOL bFlag);
};

#endif // !defined(AFX_HLASERUV_H__A9FF13ED_2711_4DCB_8CDA_903EE30C69E9__INCLUDED_)
