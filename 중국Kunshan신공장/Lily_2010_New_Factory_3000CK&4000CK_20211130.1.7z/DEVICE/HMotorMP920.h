// HMotorMP920.h: interface for the HMotorMP920 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HMOTORMP920_H__F9CC34DB_447A_4ADE_8E92_4AC1921E573A__INCLUDED_)
#define AFX_HMOTORMP920_H__F9CC34DB_447A_4ADE_8E92_4AC1921E573A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HMotor.h"
#include "CorrectTime.h"
#include "TCalibration.h"
#define FIRST_PANEL_OFFSET	1
#define SECOND_PANEL_OFFSET	2
#define DELTA_PANEL_OFFSET	3

class HMotorMP920 : public HMotor  
{
public:
	HMotorMP920();
	virtual ~HMotorMP920();

// Operation
public :
	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetUnloadBasketSignal(BOOL bIn); 
	int	 GetInpositionError();	
	BOOL UnloaderPicker3Init();
	BOOL LoaderPicker3Init();
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL UseRoll(BOOL bUse);
	BOOL IsHandlerInitEnd(int nAxis);
	BOOL IsHandlerStop(int nAxis);
	BOOL IsHandlerBusy(int nAxis);
	BOOL IsHandlerReady(int nAxis);
	BOOL IsHandlerDoorBypass(BOOL bLoader);
	BOOL IsResetSwitch();
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	double GetMPosition(int nIndex);
	double GetMoveAccel(int nAxis);

	void UpdateTCalibrationFile(CALDATA &calData);
	BOOL IsHandlerUnloadAlarm();
	BOOL IsHandlerUnloadEnd();
	BOOL IsHandlerUnloadReady();
	BOOL IsHandlerLoadAlarm();
	BOOL IsHandlerLoadEnd();
	BOOL IsHandlerLoadReady();
	BOOL IsHandler2ndTableExist();
	BOOL IsHandler1stTableExist();
	BOOL IsHandlerLotEnd();
	BOOL IsHandlerAlarm();
	BOOL IsHandlerReady();
	BOOL LoaderPCBReset();
	BOOL UnLoaderPCBReset();
	BOOL GetAOMAlarm();
	BOOL TableVacuumSelect(BOOL bOn);
	BOOL IsUCinAlignPos();
	BOOL IsLCinAlignPos();
	BOOL UnloaderTableBackward();
	BOOL UnloaderTableForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderClampForward();
	BOOL UnloaderVacuum2Off();
	BOOL UnloaderVacuum2On();
	BOOL UnloaderVacuum1Off();
	BOOL UnloaderVacuum1On();
	BOOL UnloaderPicker2Unload();
	BOOL UnloaderPicker2P2();
	BOOL UnloaderPicker2Table();
	BOOL UnloaderPicker2Init();
	BOOL UnloaderPicker1Unload();
	BOOL UnloaderPicker1P2();
	BOOL UnloaderPicker1Table();
	BOOL UnloaderPicker1Init();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL LoaderTableBackward();
	BOOL LoaderTableForward();
	BOOL LoaderClampBackward();
	BOOL LoaderClampForward();
	BOOL LoaderVacuum2Off();
	BOOL LoaderVacuum2On();
	BOOL LoaderVacuum1Off();
	BOOL LoaderVacuum1On();
	BOOL LoaderPicker2Load();
	BOOL LoaderPicker2P2();
	BOOL LoaderPicker2Align();
	BOOL LoaderPicker2Init();
	BOOL LoaderPicker1Load();
	BOOL LoaderPicker1P2();
	BOOL LoaderPicker1Align();
	BOOL LoaderPicker1Init();
	BOOL IsUnloaderAlignTableForward();
	BOOL IsUnloaderCartClamp();
	BOOL IsULP2P2Up();
	BOOL IsULP1P2Up();
	BOOL IsLP2P2Up();
	BOOL IsLP1P2Up();
	BOOL WriteOutPort(int nAdd, BOOL bOn);
	BOOL UnloaderCarrierAlignPos();
	BOOL UnloaderElvOriginPos();
	BOOL UnloaderElvUnloadPos();
	BOOL LoaderElvOriginPos();
	BOOL LoaderElvLoadPos();
	BOOL Table2VacuumMotor(BOOL bOn);
	BOOL IsUnloaderPicker2Vacuum();
	BOOL IsUnloaderPicker1Vacuum();
	BOOL IsULP2P1Up();
	BOOL IsULP1P1Up();
	BOOL IsAlignSheetTableForward();
	BOOL IsAlignGuideForward();
	BOOL IsLoaderAlignTableForward();
	BOOL IsLoaderPicker2Vacuum();
	BOOL IsLoaderPicker1Vacuum();
	BOOL IsLoaderCartClamp();
	BOOL IsLP2P1Up();
	BOOL IsLP1P1Up();
	BOOL TablePCBReset();
	BOOL ULAlignTablePCBExist(BOOL bOn);
	BOOL Unloader2PCBExist(BOOL bOn);
	BOOL Unloader1PCBExist(BOOL bOn);
	BOOL AlignTablePCBExist(BOOL bOn);
	BOOL Loader2PCBExist(BOOL bOn);
	BOOL Loader1PCBExist(BOOL bOn);
	BOOL GetCurrentMotorSol();
	BOOL IsUCinUnloadPos();
	BOOL IsLCinLoadPos();
	BOOL IsUCinCartPos();
	BOOL IsLCinCartPos();
	BOOL IsULAlignerPCBExist();
	BOOL GetStopSW();
	BOOL GetStartSW();
	BOOL GetResetSW();
	BOOL IsAlignerPCBExist();
	BOOL GetBrushStatus(BOOL bUp);
	BOOL IsRightDoorOpen();
	BOOL IsRear2DoorOpen();
	BOOL IsRear1DoorOpen();
	BOOL IsLeftDoorOpen();
	BOOL IsFrontDoorOpen();
	BOOL GetLoadingShutterStatus(BOOL bOpen);
	BOOL GetSystemAir();
	BOOL GetChuckStatus(BOOL bClamp);
	BYTE GetCurrentPowerMeter();
	BOOL Table1VacuumMotor(BOOL bOn);
	BOOL LoaderCarrierCartPos();
	BOOL UnloaderCarrierUnloadPos();
	BOOL LoaderCarrierAlignPos();
	BOOL UnloaderCarrierTablePos();
	BOOL LoaderCarrierLoadPos();
	void UpdateZCalibrationFile(CALHEAD& calHead, BOOL bFirst);
	BOOL IsFluorescentLampOn();
	BOOL GetCurrentEMStop();
	BOOL GetCurrentHeight(BOOL bFirst, BOOL bDown);
	void SetFixedMaskPos(double dPos);
	void SetOriginalSpeed();
	void SetAxisSpeed(int nAxis, long nSpeed);
	BOOL Stop(int nAxis);
	BOOL SetLimitYPos(double dPos);
	
	BOOL SetOutportTableVacuum(BOOL bUseBTable);
	BOOL IsReady(int nAxis = -1);
	BOOL MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE);
	BOOL MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	BOOL MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	BOOL MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove = FALSE);
	BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE);
	BOOL MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat = FALSE);
	
	BOOL MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode, BOOL bPass  = FALSE);
	BOOL MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE);
	BOOL MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE);
	BOOL MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMCA2(double dPosZ1, double dPosZ2, double dPosM1, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE);
	BOOL GetRawPosition(int nAxis, double& dPosition);
	BOOL GetCurrentAcrylSuction(BOOL b1st);
	BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff);
	BOOL SetMoveIO(int nMoveAxis);
	BOOL MainReady(BOOL bOn = TRUE);
	BOOL MainStop(BOOL bOn = TRUE);
	BOOL IsHoodOK(BOOL bOpen);
	BOOL MoveLaserBeamPath(BOOL bUp);
	BOOL MoveTophatShutter(BOOL bUp);
	BOOL HoodOpen(BOOL bOpen);
	BOOL DustSuctionControl(BOOL bLeft, BOOL bUp);
	BOOL IonizerOn(BOOL bOn);
	BOOL SetTowerLampBuzzer(int nColor, BOOL bBuzzer);
	BOOL IsHandlerPartError(BOOL bLoader);
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL GetCurrentSuctionMotor();
	BOOL IsTable2PCBExist();
	BOOL IsTable1PCBExist();
	BOOL GetScannerStatus();
	BOOL GetAOMStatus();
	BOOL IsLoadCartNoPCB();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsLoaderPicker1PCBExist();
	BOOL SetAOMPowerON(BOOL bOn);
	BOOL ScannerPower(BOOL bOn);
	BOOL GetCurrentLoadDetect(int nUsePanel);
	BOOL InPositionIO(int nAxis);
	BOOL IsAnyError();
	BOOL SetError(BOOL bError);
	BOOL MainReset(BOOL bOn);
	BOOL MotorShutterAll(BOOL bMaster, BOOL bSlave);
	BYTE GetCurrentShutter2();
	BYTE GetCurrentShutter1();
	BOOL IsBMMotorHomeEnd();
	BOOL		InitMotor();
	void		DestroyMotor();

	// Table Clamp
	BOOL	TableClamp(BOOL bClamp, BOOL bLeft = TRUE);
	BOOL	GetCurrentTableClamp(BOOL b1st, BOOL bClamp);

	// Thread Stop Flag
	BOOL	GetThreadStopFlag()				{ return m_bThreadStop; }
	void	SetThreadStopFlag(BOOL bFlag)	{ m_bThreadStop = bFlag; }

	// Period
	void	SetPeriod(int nPeriod)			{ m_nPeriod = nPeriod; }
	UINT	GetPeriod()						{ return m_nPeriod; }

	// Read Input Data
	void	ReadArrayData();
	void	ReadPosition();
	void	ReadStatus();
	void	ReadLoadUnload();
	void	ReadInput();
	void	ReadError();
	void	ReadErrorIo();
	void	ReadErrorLoading();
	void	ReadErrorUnloading();
	void	ReadErrorAligner();
	void	ReadErrorTableLimit();
	void	ReadErrorOtherLimit();
	void	ReadErrorTable();
	void	ReadErrorLaser();
	void	ReadServo();

	// Motor Speed, Offset
	BOOL	ReadAutoSetting();
	BOOL	WriteAutoSetting();
	BOOL	SetOffset(int nAxisNo, double dOffset, double dScale);
	BOOL	SetSpeed(int nAxisNo, long nSpeed);
	BOOL	SetOriginSpeed(int nAxisNo, long nSpeed);
	BOOL	SetMaskPosition(double dMaskPosition[], double dMaskPosition2[]);
	BOOL	SetAutoSetting(SAUTOSETTING sAutoSetting);
	void	SetScale(int nAxis, double dScale);

	// Check Motor Status
	BOOL	PeekMessage();
	BOOL	IsMotor(int nAxis, BOOL bMotor[]);
	BOOL	IsMotorEnd(int nAxis);
	int		IsInPositionThread(int nAxis, BYTE bCmd);
	void	InPositionStop();
	void	CheckMotorInPosition();
	BOOL	IsInPosition(int nAxis=-1, BOOL bWait=TRUE);
	BOOL	IsInOrigin(int naxis, BOOL bWait=TRUE);

	// MoveCommand
	BOOL	MotorMove();

	// Just Download Posisition
	BOOL	MotorMoveMC_W(double m, double c);
	BOOL	MotorMoveMC_W(int nMaskIndex, double c);
	BOOL	MoveMC_W(double m, double c);
	BOOL	MoveMC_W(int nMaskIndex, double c);
	
	BOOL	MotorMoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);

	BOOL	MoveZMC_W(double z1, double z2, int nMaskIndex, double c);
	BOOL	MoveZMC_W(double z1, double z2, double m, double c);

	// Dual Panel
	BOOL	MoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveZ1Z2(double z1, double z2, BOOL bRawMove=FALSE);

	BOOL	MotorMoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveZ1Z2(double z1, double z2, BOOL bRawMove=FALSE);
	
	// Single Panel
	BOOL	MoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveXYZM(double x, double y, double z, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveXYZ(double x, double y, double z, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveZ(double z, BOOL bRawMove=FALSE);

	BOOL	MotorMoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveXYZM(double x, double y, double z, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveXYZ(double x, double y, double z, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveZ(double z, BOOL bRawMove=FALSE);

	BOOL	MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);

	// Common
	BOOL	SetLimitZ();
	BOOL	SetLoaderUnloaderPos(double dLoadX, double dLoadY, double UnloadX, double UnloadY);
	BOOL	SetLoaderUnloaderPos2(double dLoadX, double dLoadY);
	BOOL	MoveXY(double x, double y, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MoveMC(double m, double c);
	BOOL	MoveMC(int nMaskIndex, double c);
	BOOL	MoveM(double m);
	BOOL	MoveM(int nMaskIndex);
	BOOL	StopMotor(int nAxis=-1);
	BOOL	DownloadAxisInfo();
	BOOL	DownloadAutoSetting();

	BOOL	MotorMoveXY(double x, double y, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE);
	BOOL	MotorMoveMC(double m, double c);
	BOOL	MotorMoveMC(int nMaskIndex, double c);
	BOOL	MotorMoveM(double m);
	BOOL	MotorMoveM(int nMaskIndex);

	// Motor(Stage) Movement
	BOOL	SetShutter(BOOL bMaster=TRUE, BOOL bSlave=TRUE);
	BOOL	SetOrigin(int nAxis=-1);
	BOOL	IsValidAxisPosition(int nAxisNo, double dPos);
	BOOL	GetAxisScale(int nAxis, double* pScale);
	void	WriteMode(BYTE* pData, int& nCount);
	void	WriteMode2(BYTE* pData, int& nCount);
	void	WritePosition(BYTE* pData, int nAxisNo, double dPos);
	void	WriteCurrentPos(BYTE* pData, int& nCount);
	BOOL	SetOutPort(DWORD dwOffset, DWORD dwOnOff, BOOL bAbs=TRUE);

	// Handler Operation
	BOOL	HandlerOperation(int nHadnlerOperationID, BOOL bAction=TRUE);
	BOOL	WriteLoadCommand(LOADERCOMMAND wLoaderCmd);
	BOOL	WriteUnloadCommand(UNLOADERCOMMAND wUnloaderCmd);
	BOOL	WriteLoadReadyReset(BOOL bDrill);
	BOOL	IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait=TRUE);

	// Motor Speed & Position
	double	GetPosition(int nAxisNo, BOOL b1stPanel = TRUE);
	double	GetMoveSpeed(int nAxisNo);

	BOOL	GetPosition(int nAxisNo, double &dPosition, BOOL b1stPanel = TRUE);

	// Table Calibration
	void	CreateTableCalibration();
	void	LoadCalibrationFile(CString strPath);
	void	UpdateCalibrationFile(CString strPath);
	void	GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag);

	// Auto Mode
	BOOL	AutoSaveInit();
	BOOL	AutoSaveXY(double dPosX, double dPosY);
	BOOL	AutoSaveZ(double dPosZ);
	BOOL	AutoSaveZ(double dPosZ1, double dPosZ2);
	BOOL	AutoNext(int nCount);
	int		GetAutoDataMax();

	// Get Machine Status
	long	GetCurrentError(ERRORCOMMAND nError);
	int		GetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag=FALSE);
	int		GetCurrentMode();
	BOOL	IsSafetyMode();
	BOOL	SetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag=FALSE);
	int		IsStatus(ISSTATUS nStatus, BOOL bFlag=FALSE);

	BYTE GetCurrentSuction();
	BOOL FireMoveXY(double dX, double dY, double dSFX, double dEFX, int nSpeed, int nLaserOnDelay, int nLaserOffDelay);
	BOOL	SetAxisInfo(SAXISINFO* sAxisInfo);
	BOOL SetAlarmTolLed(BOOL bOn);
	BOOL SendLoadCartNoPCB();
	int ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel);
	int	m_nInPositionError;
	BOOL SetWaterFlow1Value(double dVal);
	BOOL SetWaterFlow2Value(double dVal);
	BOOL SetMainAirValue(double dVal);
	BOOL SetDustSuctionValue(double dVal);
	BOOL SetTableVauumValue(BOOL b1st, double dVal);
	BOOL Set2DBarcodeTrigger();
	BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat);
	BOOL GetChillerRun();
	BOOL GetLPCStatus();
	BYTE GetBasketIn();
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd);
	BOOL IsStartMode();
	BOOL MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2);
	BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	void ReadAddressTemperatureComp();
	void ReadTemperatureComp();
	BOOL GetReverseDirection();
	void ReadAllError(int* pnVal);
	BOOL GetReverseReady();
	void DisconnectAnyDevice(int nType);
	void ConnectAnyDevice(int nType); // 0 : chiller 1: thermo-hyprometer
	BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);
	BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL IsUnloaderNGBoxForward();
	BOOL IsUnloaderNGBoxBackward();
	BOOL IsLCinCartPos2();
	BOOL IsLCinAlignPos2();
	BOOL LoaderCarrierAlignPos2();
	BOOL LoaderCarrierCartPos2();
	BOOL IsOrigin(int nAxis);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL IsMainDoorStop();
	void GetTemperatureForAllCh (double* dTemper);
	void GetTCTemperature (double& d1stTemper, double& d2ndTemper);
	void GetSBTemperature (double& d1stTemper, double& d2ndTemper);
	int	GetMainAirValue();
	double GetChillerTemp();
	int	GetWaterFlow1Value();
	int	GetWaterFlow2Value();
	double GetVolateSubData(int nIndex);
	void GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint);
	void GetVoltage(double& dV, double& dA,double& dKw);

#ifdef __KUNSAN_SAMSUNG_LARGE__
	PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
#else
	PLC_BIT_SIGNAL GetMelsecIOStuct();
#endif

	// Attributes
protected :
	CWinThread*	m_pMotorThread;
	BOOL		m_bThreadStop;
	UINT		m_nPeriod;

	WORD	m_wRegData[REG_DATA_MAX];
	long	m_nWritePos[MOTOR_AXIS_MAX];

	CCorrectTime	m_clsTimer;

	BOOL	m_bIsInPosition[MOTOR_AXIS_MAX];
	int		m_nInPositionAxis;

	BYTE	m_bInPositionCmd;
	int		m_nInPositionStatus;

	MP920DATA*		m_lpDataNew;				// MP920 Data New
	MP920DATA*		m_lpDataOld;				// MP920 Data Old

	BOOL	m_bInitCalibration;

	long	m_nOriginOffset[MOTOR_AXIS_MAX];
	long	m_nWorkSpeed[MOTOR_AXIS_MAX];
	long	m_nOriginSpeed[MOTOR_AXIS_MAX];

	double	m_dMaskPosition[MOTOR_MASK_MAX];
	double	m_dDestinationPos[MOTOR_AXIS_MAX];
	
	double	m_dMaskPosition2[MOTOR_MASK_MAX];
	double	m_dDestinationPos2[MOTOR_AXIS_MAX];

	double	m_dCalibrationOffset[MOTOR_AXIS_MAX];
	double	m_dSlaveCalibrationOffset[MOTOR_AXIS_MAX];

	SAUTOSETTING	m_sAutoSetting;

	CCalibration*	m_Calibration;
	CCalibration*	m_SlaveCalibration;

	int m_nCalType;
	SAXISINFO		m_pSetting[MOTOR_AXIS_MAX];				// ���ͼ��������� ����
	SAUTODATA*		m_pAutoData;
};

#endif // !defined(AFX_HMOTORMP920_H__F9CC34DB_447A_4ADE_8E92_4AC1921E573A__INCLUDED_)
