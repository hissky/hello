// MonoCubicInterpolation.h: interface for the CMonoCubicInterpolation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MONOCUBICINTERPOLATION_H__4535EB09_89D2_4631_81FF_DEB3FF89A4A9__INCLUDED_)
#define AFX_MONOCUBICINTERPOLATION_H__4535EB09_89D2_4631_81FF_DEB3FF89A4A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

class CMonoCubicInterpolation : public CCalibration  
{
public:
	void GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	void DeleteMemory();
	void MonoCubicY();
	void MonoCubicX();

	double her11(double t);
	double her10(double t);
	double her01(double t);
	double her00(double t);

	DPOINT *m_d1, *m_d2, *m_d3, *m_d4;
	int m_nXStart, m_nXEnd, m_nYStart, m_nYEnd;

	void UpdateWholeCalibration();
	CMonoCubicInterpolation();
	virtual ~CMonoCubicInterpolation();

};

#endif // !defined(AFX_MONOCUBICINTERPOLATION_H__4535EB09_89D2_4631_81FF_DEB3FF89A4A9__INCLUDED_)
