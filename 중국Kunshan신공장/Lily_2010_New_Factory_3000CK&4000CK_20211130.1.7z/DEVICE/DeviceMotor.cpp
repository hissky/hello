// DeviceMotor.cpp: implementation of the DeviceMotor class.
////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\easydriller.h"
#include "DeviceMotor.h"
#include "BiLinear.h"
#include "BicubicInterpolation.h"
//#include "BicubicSpline.h"
#include "ZCalibration.h"
#include "TCalibration.h"
#include <cmath>
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemINI.h"
#include "..\Model\DProcessINI.h"
#include "..\model\DProject.h"
#include "..\alarmmsg.h"
//#include "DeviceComiZoa.h"
//#include "comidaq.h"
//#include "comimotion.h"
#include "SysUMAC.h"
#include "DHandlerInput.h"
#include "DevChiller.h"
#include "DevHumidity.h"
#include "DevTemperCompen.h"
#include "DevVoltage.h"
#include "DevMCCDaq.h"
#include "DevVisionController.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Disable C4100 : unreferenced formal parameter warning
#pragma warning(disable : 4100)

const char WHOLE_TABLE_CALIBRATION_FILE[] = _T("xy.calibration");
const char WHOLE_TABLE_CALIBRATION_FILE_SLAVE[] = _T("xy.Scalibration");

//////////////////////////
// Constructor
DeviceMotor::DeviceMotor()
{
	m_nAutoDataMax	= 0;
	m_bAnyError = FALSE;
	m_clsMotor	= NULL;
	m_clsPmacMotor = NULL;
	m_clsUmacProgram = NULL;
	m_clsMelsec = NULL;
	m_Chiller = NULL;
//	m_pComizorMotor = NULL;
	m_Calibration = NULL;
	m_SlaveCalibration = NULL;
	m_ZCalInfo1 = NULL;
	m_ZCalInfo2 = NULL;
	m_TCalInfo = NULL;
	m_nInpositionError = ALL_AXIS_OK;
	memset( &m_pSetting, 0, sizeof(m_pSetting) );
	memset( &m_sAutoSetting, 0, sizeof(m_sAutoSetting) );

	memset(m_dDestinationPos, 0, sizeof(double) * MOTOR_AXIS_MAX);
	memset(m_dCalibrationOffset, 0, sizeof(double) * MOTOR_AXIS_MAX);
	memset(m_dSlaveCalibrationOffset, 0, sizeof(double) * MOTOR_AXIS_MAX);
	m_bOldMelsecConnect = FALSE;
	m_bReverse = FALSE;
}

///////////////////////////
// Destructor
DeviceMotor::~DeviceMotor()
{
}

//////////////////////////
// Constructor
BOOL DeviceMotor::InitMotor(CComiMotion* pMotion, CComiDaq* pDaq)
{
	if(m_nMotorType == MOTOR_UMAC)
	{
		if(m_clsMotor == NULL)
		{
			TRACE(_T("Umac Opening\n"));
			TRY
			{
				#ifdef __PUSAN1__	
					m_clsMotor = new DeviceUMacPusan1;
				#endif
								
				#ifdef __PUSAN2__ 
					m_clsMotor = new DeviceUMacPusan2;
				#endif

				#ifdef __KUNSAN_6__	
					m_clsMotor = new DeviceUMacKunsan6;
				#endif
					
				#ifdef __KUNSAN_8__	
					m_clsMotor = new DeviceUMacKunsan8;
				#endif
								
				#ifdef __PUSAN_OLD_17__
					m_clsMotor = new DeviceUMac;
				#endif
					
				#ifdef __PUSAN_OLD_32__
					m_clsMotor = new DeviceUMac;
				#endif

				#ifdef __KUNSAN_1__	
					m_clsMotor = new DeviceUMacKunsan1;
				#endif

				#ifdef __OSAN_LG__
					m_clsMotor = new DeviceUMacOsan;
				#endif

				#ifdef __KUNSAN_SAMSUNG_LARGE__
					m_clsMotor = new DeviceUMacLarge;
				#endif
			}

			CATCH (CMemoryException, e)
			{
				e->ReportError();
				e->Delete();
				return FALSE;
			}
			END_CATCH

			#ifndef __TEST__
				if(m_clsMotor->Initialize() == FALSE)
				{
					ErrMessage(_T("UMac Open Error !!!"));
					delete m_clsMotor;
					m_clsMotor = NULL;
					return FALSE;
				}
			#endif
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(m_clsPmacMotor == NULL)
		{
			TRACE(_T("Pmac Opening\n"));
			TRY
			{
				m_clsPmacMotor = new DevicePMac;
			}
			CATCH (CMemoryException, e)
			{
				e->ReportError();
				e->Delete();
				return FALSE;
			}
			END_CATCH
				
			#ifndef __TEST__
				if(m_clsPmacMotor->Initialize() == FALSE)
				{
					ErrMessage(_T("PMac Open Error !!!"));
					delete m_clsPmacMotor;
					m_clsPmacMotor = NULL;
					return FALSE;
				}
			#endif
		}
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(m_pComizorMotor == NULL)
		{
			TRACE(_T("ComiZoa Opening\n"));
			m_pComizorMotor = new DeviceComiZoa;
			
#ifndef __TEST__
			if(m_pComizorMotor->Initialize(pMotion, pDaq) == FALSE)
			{
				ErrMessage(_T("ComiZoa Open Error !!!"));
				delete m_pComizorMotor;
				m_pComizorMotor = NULL;
			}
#endif
		}
*/
	}
	else if( m_nMotorType == MOTOR_UMAC_PROGRAM )
	{
		m_clsUmacProgram = new CSysUMAC;
#ifndef __TEST__
		if(m_clsUmacProgram->InitializeUMAC() == FALSE)
		{
			ErrMessage("_T(Umac Open Error !!!");
			delete m_clsUmacProgram;
			m_clsUmacProgram = NULL;
			return FALSE;
		}
		else
		{
			m_clsUmacProgram->StartUMACThread();
			SetTowerLampBuzzer(TOWER_GREEN, FALSE);
			Set2DTableCompOffset();
		}
#endif
	}

#ifdef __ADD_MELSEC_MOTOR__
	if(m_clsMelsec == NULL)
	{
		TRACE(_T("Melsec Opening\n"));
		TRY
		{
		#ifdef __KUNSAN_SAMSUNG_LARGE__
			m_clsMelsec = new DeviceMelsecLarge;
		#else
			m_clsMelsec = new DeviceMelsecOsan;
		#endif
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();
			return FALSE;
		}
		END_CATCH
			
	#ifndef __TEST__
 			if(m_clsMelsec->Initialize() == FALSE)
			{
				ErrMessage(_T("Melsec Open Error !!!"));
				delete m_clsMelsec;
				m_clsMelsec = NULL;
			//	return FALSE;
			}
	#endif
	}
#endif

	TRY
	{
		if (m_nCalType == 1)
		{
			m_Calibration = new CBicubicInterpolation;
			m_SlaveCalibration = new CBicubicInterpolation;
		}
		else
		{
			m_Calibration = new CBiLinear;
			m_SlaveCalibration = new CBiLinear;
		}
		m_Calibration->SetMaster(TRUE);
		m_SlaveCalibration->SetMaster(FALSE);
		
		m_ZCalInfo1 = new CZCalibration;
		m_ZCalInfo2 = new CZCalibration;
		
		m_TCalInfo = new TCalibration;
		m_Chiller = new CDevChiller;
		m_Humidity = new CDevHumidity;
#ifdef __MCCDAQ_USE_FOR_TEMPERATURE__
		m_TemperatureMeasure = new CDevMCCDaq;
#else
		m_TemperatureMeasure = new CDevTemperCompen;
#endif
		m_Voltage = new CDevVoltage;
#ifndef __TEST__
 		ConnectAnyDevice(-1);
#endif
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
		
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	LoadCalibrationFile(strCalPath);
	LoadZCalibrationFile(strCalPath, TRUE);
	LoadZCalibrationFile(strCalPath, FALSE);
	LoadTCalibrationFile(strCalPath);

	ReadTableLimit();

	return TRUE;
}

///////////////////////////
// Destructor
BOOL DeviceMotor::DestroyMotor()
{
	if(m_Calibration)
	{
		delete m_Calibration;
		m_Calibration = NULL;
	}

	if(m_SlaveCalibration)
	{
		delete m_SlaveCalibration;
		m_SlaveCalibration = NULL;
	}

	if(m_ZCalInfo1)
	{
		delete m_ZCalInfo1;
		m_ZCalInfo1 = NULL;
	}
	if(m_ZCalInfo2)
	{
		delete m_ZCalInfo2;
		m_ZCalInfo2 = NULL;
	} 
	
	if(m_TCalInfo)
	{
		delete m_TCalInfo;
		m_TCalInfo = NULL;
	}
	
	if(m_clsMotor)
	{
		delete m_clsMotor;
		m_clsMotor = NULL;
	}

	if(m_clsPmacMotor)
	{
		delete m_clsPmacMotor;
		m_clsPmacMotor = NULL;
	}
	if(m_Chiller)
	{
		delete m_Chiller;
		m_Chiller = NULL;
	}
	if(m_Humidity)
	{
		delete m_Humidity;
		m_Humidity = NULL;
	}
	if(m_TemperatureMeasure)
	{
		delete m_TemperatureMeasure;
		m_TemperatureMeasure = NULL;
	}
	if(m_Voltage)
	{
		delete m_Voltage;
		m_Voltage = NULL;
	}
/*
	if(m_pComizorMotor)
	{
		delete m_pComizorMotor;
		m_pComizorMotor = NULL;
	}
*/
	if(m_clsUmacProgram)
	{
		SetTowerLampBuzzer(NULL, FALSE);
		m_clsUmacProgram->DestroyUMAC();
		delete m_clsUmacProgram;
		m_clsUmacProgram = NULL;
	}
	
#ifdef __ADD_MELSEC_MOTOR__
	if(m_clsMelsec)
	{
		delete m_clsMelsec;
		m_clsMelsec = NULL;
	}
#endif

	return TRUE;
}

///////////////////////////////////////////////////////////
// ����� Ȯ��
BOOL DeviceMotor::IsAxisOver(int nAxis, CString strMessage)
{
	int nMaxAxis = MOTOR_AXIS_MAX;
	if(m_nMotorType == MOTOR_COMIZOA)
		nMaxAxis = COMI_AXIS_MAX; // X, Y
	else if(m_nMotorType == MOTOR_PMAC)
		nMaxAxis = PMAC_AXIS_MAX; // X, Y, Z

	if(nAxis >= nMaxAxis)
	{
//		TRACE(_T("Fuction:[%s] Axis:[%d]\n"), strMessage, nAxis);
		return FALSE;
	}
	else
		return TRUE;
}

///////////////////////////////////////////////////////
// �ະ ����
BOOL DeviceMotor::SetAxis(int nAxis, SAXISINFO pSet)
{
	if(!IsAxisOver(nAxis, _T("SetAxis")))
		return FALSE;

	m_pSetting[nAxis] = pSet;
	return TRUE;
}

////////////////////////////////////////////////////////
// �ະ �б�
BOOL DeviceMotor::GetAxis(int nAxis, SAXISINFO& pGet)
{
	if(!IsAxisOver(nAxis, _T("GetAxis")))
		return FALSE;

	pGet = m_pSetting[nAxis];
	return TRUE;
}

//////////////////////////////////////////
// �۾� �ִ��� ����
BOOL DeviceMotor::SetAxisMax(int nAxisMax)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->SetAxisMax(nAxisMax);

	return TRUE;
#endif
}

///////////////////////////////////////////////////
// �ӵ� �б�
double DeviceMotor::GetMoveSpeed(int nAxis)
{
	return m_pSetting[nAxis].dTableFeedRate;
}

//////////////////////////////
// Motor�� �ʱ�ȭ
BOOL DeviceMotor::Initialize()
{
#ifdef __TEST__
	return TRUE;
#else
	BOOL bRet = TRUE;
	if(m_nMotorType == MOTOR_UMAC)
	{
		bRet = m_clsMotor->Initialize();
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->Initialize();
#endif
	}
	else if(m_nMotorType == MOTOR_PMAC)
		bRet = m_clsPmacMotor->Initialize();

	return bRet;
#endif
}

//////////////////////////////////////
// ������ ������ ����
BOOL DeviceMotor::SetOrigin(int nAxis)
{
	if(!IsAxisOver(nAxis, _T("SetOrigin")))
		return FALSE;
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		double dy;
		m_clsMotor->GetPosition(AXIS_Y, dy);

		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			if(dy > m_sAutoSetting.dUnclampLimitY && m_clsMotor->GetCurrentTableClamp(TRUE, FALSE) )
			{
				ErrMessage(IDS_ERR_UNCLAMP_HOME);
				return FALSE;
			}
		}
		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			if(dy > m_sAutoSetting.dUnclampLimitY && m_clsMotor->GetCurrentTableClamp(FALSE, FALSE) )
			{
				ErrMessage(IDS_ERR_UNCLAMP_HOME);
				return FALSE;
			}
		}
	
		for(int nNo = 0; nNo < MOTOR_AXIS_MAX; nNo++)
			m_clsMotor->SetOffset(nNo, m_pSetting[nNo].dTableAcceleration);
		
		return m_clsMotor->SetOrigin(nAxis);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		for(int nNo = 0; nNo < COMI_AXIS_MAX; nNo++)
			if(!m_pComizorMotor->SetOriginSpeed(nNo, long(m_pSetting[nNo].dTableSCurve)))
				return FALSE;
			
			return m_pComizorMotor->SetOrigin(nAxis);
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		m_clsUmacProgram->InitializeMotor(nAxis);
		return TRUE;
	}
	else
		return TRUE;
	
	return TRUE;
#endif
}

//////////////////////////////////////////
// ������ ��ġ �б�
double DeviceMotor::GetPosition(int nAxis, BOOL b1stPanel)
{
	double dPosition = 123.456;
	if(!IsAxisOver(nAxis, _T("GetPosition")))
		return dPosition;
	
#ifdef __TEST__
	return dPosition;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		m_clsMotor->GetPosition(nAxis, dPosition);
		if (nAxis == AXIS_X || nAxis == AXIS_Y)
		{
			double dx, dy;
			if(!m_clsMotor->GetPosition(AXIS_X, dx) || !m_clsMotor->GetPosition(AXIS_Y, dy))
				return FALSE;
			if(b1stPanel)
			{
				GetAxisMoveOffset(dx, dy, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
				dPosition -= m_dCalibrationOffset[nAxis];
			}
			else
			{
				GetAxisMoveOffset(dx, dy, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
				dPosition -= m_dSlaveCalibrationOffset[nAxis];
			}
		}
		if(nAxis == AXIS_Z1 || nAxis == AXIS_Z2)
		{
			double dX = GetPosition(AXIS_X);
			double dY = GetPosition(AXIS_Y);
			if(nAxis == AXIS_Z1)
			{
				GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z1], TRUE);
				dPosition -= m_dCalibrationOffset[AXIS_Z1];
			}
			else
			{
				GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z2], FALSE);
				dPosition -= m_dCalibrationOffset[AXIS_Z2];
			}
		}
		if(nAxis == AXIS_L_CARRIER || nAxis == AXIS_UL_CARRIER)
		{
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
				m_clsMelsec->GetPosition(nAxis, dPosition);
#endif
		}
		return dPosition;
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(nAxis >= PMAC_AXIS_MAX)
			return 0;
		
		m_clsPmacMotor->GetPosition(nAxis, dPosition);
		return dPosition;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(nAxis >= COMI_AXIS_MAX)
			return 0;
		
		m_pComizorMotor->GetMotorFeedPosition(nAxis, &dPosition);
		return dPosition;
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return m_clsUmacProgram->GetPosition(nAxis);
	}

	return dPosition;
#endif
}
///////////////////////////////////////////////////////////
// ������ ��ġ �б�
BOOL DeviceMotor::GetPosition(int nAxis, double& dPosition, BOOL b1stPanel)
{
	dPosition = 423.456;
	if(!IsAxisOver(nAxis, _T("GetPosition")))
		return FALSE;
	
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if(nAxis <= AXIS_UL_CARRIER)
		{
			if (m_clsMotor->GetPosition(nAxis, dPosition))
			{
				if (nAxis == AXIS_X || nAxis == AXIS_Y)
				{
					double dx, dy;
					if(!m_clsMotor->GetPosition(AXIS_X, dx) || !m_clsMotor->GetPosition(AXIS_Y, dy))
						return FALSE;
					
					if(b1stPanel)
					{
						GetAxisMoveOffset(dx, dy, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
						dPosition -= m_dCalibrationOffset[nAxis];
					}
					else
					{
						GetAxisMoveOffset(dx, dy, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
						dPosition -= m_dSlaveCalibrationOffset[nAxis];
					}
				}

				if(nAxis == AXIS_Z1 || nAxis == AXIS_Z2)
				{
					double dX = GetPosition(AXIS_X);
					double dY = GetPosition(AXIS_Y);
					if(nAxis == AXIS_Z1)
					{
						GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z1], TRUE);
						dPosition -= m_dCalibrationOffset[AXIS_Z1];
					}
					else
					{
						GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z2], FALSE);
						dPosition -= m_dCalibrationOffset[AXIS_Z2];
					}
				}
				
				return TRUE;
			}
			else
				return FALSE;
		}
		else
		{
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
			{
				if(m_clsMelsec->GetPosition(nAxis, dPosition))
					return TRUE;
				else
					return FALSE;
			}
			else
				return FALSE;
#endif
		}
	
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(nAxis >= PMAC_AXIS_MAX)
		{
			dPosition = 0;
			return TRUE;
		}

		return m_clsPmacMotor->GetPosition(nAxis, dPosition);
			return TRUE;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(nAxis >= COMI_AXIS_MAX)
		{
			dPosition = 0;
			return TRUE;
		}
		
		return m_pComizorMotor->GetMotorFeedPosition(nAxis, &dPosition);
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		dPosition = m_clsUmacProgram->GetPosition(nAxis);
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::GetRawPosition(int nAxis, double& dPosition)
{
	if(!IsAxisOver(nAxis, _T("GetPosition")))
		return FALSE;
	BOOL bRes = TRUE;
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if(nAxis < MOTOR_AXIS_MAX)
		{
			if(nAxis == AXIS_L_CARRIER || nAxis == AXIS_UL_CARRIER)
			{
#ifdef __ADD_MELSEC_MOTOR__
				if(nAxis == AXIS_L_CARRIER)
					nAxis = HANDLER_LC;
				else
					nAxis = HANDLER_UC;
				if(m_clsMelsec)
				{
					if(m_clsMelsec->GetPosition(nAxis, dPosition))
						bRes =  TRUE;
					else
						bRes = FALSE;
				}
#else
				if (m_clsMotor->GetPosition(nAxis, dPosition))
					bRes = TRUE;
				else
					bRes = FALSE;
#endif
			}
			else
			{

				if (m_clsMotor->GetPosition(nAxis, dPosition))
					bRes = TRUE;
				else
					bRes = FALSE;
			}
		}
		else
		{
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
			{
				if(m_clsMelsec->GetPosition(nAxis, dPosition))
					bRes = TRUE;
				else
					bRes = FALSE;
			}
#endif
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(nAxis >= PMAC_AXIS_MAX)
		{
			dPosition = 0;
			bRes = TRUE;
		}

		return m_clsPmacMotor->GetPosition(nAxis, dPosition);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(nAxis >= COMI_AXIS_MAX)
		{
			dPosition = 0;
			return TRUE;
		}
		
		return m_pComizorMotor->GetMotorFeedPosition(nAxis, &dPosition);
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		dPosition =  m_clsUmacProgram->GetPosition(nAxis);
	}

	return bRes;
#endif
}

////////////////////////////////////////////////////////////
// ������ �̵�

void DeviceMotor::ShowWarning(int nAxis, BOOL bIsMax)
{
	switch (nAxis)
	{
	case AXIS_X:
		if (bIsMax)
			ErrMsgDlg(STDGNALM728);
		else
			ErrMsgDlg(STDGNALM736);
		break;
	case AXIS_Y:
		if (bIsMax)
			ErrMsgDlg(STDGNALM729);
		else
			ErrMsgDlg(STDGNALM737);
		break;
	case AXIS_Z1:
		if (bIsMax)
			ErrMsgDlg(STDGNALM730);
		else
			ErrMsgDlg(STDGNALM738);
		break;
	case AXIS_Z2:
		if (bIsMax)
			ErrMsgDlg(STDGNALM731);
		else
			ErrMsgDlg(STDGNALM739);
		break;
	case AXIS_M:
		if (bIsMax)
			ErrMsgDlg(STDGNALM732);
		else
			ErrMsgDlg(STDGNALM740);
		break;
	case AXIS_C:
		if (bIsMax)
			ErrMsgDlg(STDGNALM735);
		else
			ErrMsgDlg(STDGNALM743);
		break;
	case AXIS_L_CARRIER:
//		if (bIsMax)
//			ErrMsgDlg(STDGNALM759);
//		else
//			ErrMsgDlg(STDGNALM760);
		break;
	case AXIS_UL_CARRIER:
//		if (bIsMax)
//			ErrMsgDlg(STDGNALM761);
//		else
//			ErrMsgDlg(STDGNALM762);
		break;
#ifdef __SECOND_OPTICS
	case AXIS_C2:
//		if (bIsMax)
//			ErrMsgDlg(STDGNALM755);
//		else
//			ErrMsgDlg(STDGNALM756);
		break;
	case AXIS_M2:
//		if (bIsMax)
//			ErrMsgDlg(STDGNALM757);
//		else
//			ErrMsgDlg(STDGNALM758);
		break;
#endif
	default:
		break;
	}
}

BOOL DeviceMotor::IsValidAxisPosition(int nAxis, double& dPosition, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else

#ifndef __SECOND_OPTICS
	if(nAxis == AXIS_C2 || nAxis == AXIS_M2)
		return TRUE;
#endif
	if(nAxis >= MOTOR_AXIS_MAX)
		return TRUE;

	if(m_nMotorType == MOTOR_UMAC)
	{
		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			if( nAxis == AXIS_Y	&& dPosition > m_sAutoSetting.dUnclampLimitY && m_clsMotor->GetCurrentTableClamp(TRUE, FALSE) )
			{
				if(MODE_AUTO != GetCurrentMode()) 
					ErrMessage(IDS_ERR_UNCLAMP_TABLE);
				return FALSE;
			}
		}
		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			if( nAxis == AXIS_Y	&& dPosition > m_sAutoSetting.dUnclampLimitY && m_clsMotor->GetCurrentTableClamp(FALSE, FALSE) )
			{
				if(MODE_AUTO != GetCurrentMode())
					ErrMessage(IDS_ERR_UNCLAMP_TABLE);
				return FALSE;
			}
		}
		
		// HeightSensor
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 0)
		{
			if( (nAxis == AXIS_X || nAxis == AXIS_Y) && m_clsMotor->GetCurrentHeight(TRUE, TRUE) )
			{
				ErrMessage(IDS_ERR_HEIGHT);
				return FALSE;
			}
		}
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1)
		{
			if( (nAxis == AXIS_X || nAxis == AXIS_Y) && m_clsMotor->GetCurrentHeight(FALSE, TRUE) )
			{
				ErrMessage(IDS_ERR_HEIGHT);
				return FALSE;
			}
		}
#ifndef __PUSAN_OLD_17__

	#ifndef __SERVO_MOTOR__
			if(nAxis == AXIS_M2)
				return TRUE;
	#endif
#endif
		// 090805 shutter üũ
		if( !bPass && (nAxis == AXIS_X || nAxis == AXIS_Y)) // && (GetCurrentShutter1() != 2 || GetCurrentShutter2() != 2) )
		{
			if(nMoveMode == AUTORUN_MOVE) // JUST_MOVE : �̵���, AUTORUN_MOVE : �ǰ��� �̵�, AUTORUN_MOVE : �ǰ����� laser ��� �̵�
			{
			/*	if(nAxis == AXIS_X && (dPosition > m_dXLimitP || dPosition < m_dXLimitM + 25))
				{
					ErrMessage(IDS_ERR_OUT_OF_TABLE);
					return FALSE;
				}
				else if(nAxis == AXIS_Y && (dPosition > m_dYLimitP || dPosition < m_dYLimitM + 25))
				{
					ErrMessage(IDS_ERR_OUT_OF_TABLE);
					return FALSE;
				}
				*/
			}
			else if(nMoveMode == SHOT_MOVE)
			{
				if(nAxis == AXIS_X && (dPosition > m_dXLimitP - 25 || dPosition < m_dXLimitM + 25))
				{
					if(MODE_AUTO != GetCurrentMode())
						ErrMessage(IDS_ERR_OUT_OF_TABLE);
					return FALSE;
				}
				else if(nAxis == AXIS_Y && (dPosition > m_dYLimitP - 25 || dPosition < m_dYLimitM + 25))
				{
					if(MODE_AUTO != GetCurrentMode())
						ErrMessage(IDS_ERR_OUT_OF_TABLE);
					return FALSE;
				}
			}
			else
			{
				if((GetCurrentShutter1() != 2 || GetCurrentShutter2() != 2) )
				{
					if(MODE_AUTO != GetCurrentMode())
						ErrMessage(IDS_ERR_SHUTTER_TABLE);
					return FALSE;
				}
			}
		}

		if (dPosition < m_pSetting[nAxis].dLimitMinus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, FALSE);
			dPosition = m_pSetting[nAxis].dLimitMinus;
			return FALSE;
		}
		else if (dPosition > m_pSetting[nAxis].dLimitPlus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, TRUE);
			dPosition = m_pSetting[nAxis].dLimitPlus;
			return FALSE;
		}
		else
			return TRUE;
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(nAxis >= PMAC_AXIS_MAX)
			return TRUE;

		if (dPosition < m_pSetting[nAxis].dLimitMinus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, FALSE);
			dPosition = m_pSetting[nAxis].dLimitMinus;
			return FALSE;
		}
		else if (dPosition > m_pSetting[nAxis].dLimitPlus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, TRUE);
			dPosition = m_pSetting[nAxis].dLimitPlus;
			return FALSE;
		}
		else
			return TRUE;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(nAxis >= COMI_AXIS_MAX)
			return TRUE;
		if (dPosition < m_pSetting[nAxis].dLimitMinus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, FALSE);
			dPosition = m_pSetting[nAxis].dLimitMinus;
			return FALSE;
		}
		else if (dPosition > m_pSetting[nAxis].dLimitPlus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, TRUE);
			dPosition = m_pSetting[nAxis].dLimitPlus;
			return FALSE;
		}
		else
			return TRUE;
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(nAxis >= PMAC_AXIS_MAX)
			return TRUE;
		
		if (dPosition < m_pSetting[nAxis].dLimitMinus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, FALSE);
			dPosition = m_pSetting[nAxis].dLimitMinus;
			return FALSE;
		}
		else if (dPosition > m_pSetting[nAxis].dLimitPlus)
		{
			TRACE(_T("AXIS : %d, Val = %G\n"), nAxis, dPosition);
			ShowWarning(nAxis, TRUE);
			dPosition = m_pSetting[nAxis].dLimitPlus;
			return FALSE;
		}
		else
			return TRUE;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel, BOOL bZCalUse, int nMoveMode, BOOL bPass)
{
	if (!IsAxisOver(nAxis, _T("MotorMoveAxis")))
		return FALSE;

#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(nAxis, dPosition, nMoveMode, bPass))
		{
			return FALSE;
		}

		m_dDestinationPos[nAxis] = dPosition;

		if (nAxis == AXIS_X)
		{
			double dY = GetPosition(AXIS_Y, b1stPanel);
			GetAxisMoveOffset(dPosition, dY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetAxisMoveOffset(dPosition, dY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			if(b1stPanel)
				return m_clsMotor->MotorMoveXY(dPosition + m_dCalibrationOffset[nAxis], dY + m_dCalibrationOffset[AXIS_Y]);
			else
				return m_clsMotor->MotorMoveXY(dPosition + m_dSlaveCalibrationOffset[nAxis], dY + m_dSlaveCalibrationOffset[AXIS_Y]);
		}
		else if (nAxis == AXIS_Y)
		{
			double dX = GetPosition(AXIS_X, b1stPanel);
			GetAxisMoveOffset(dX, dPosition, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetAxisMoveOffset(dX, dPosition, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			if(b1stPanel)
				return m_clsMotor->MotorMoveXY(dX + m_dCalibrationOffset[AXIS_X], dPosition + m_dCalibrationOffset[nAxis]);
			else
				return m_clsMotor->MotorMoveXY(dX + m_dSlaveCalibrationOffset[AXIS_X], dPosition + m_dSlaveCalibrationOffset[nAxis]);
		}
		else if (nAxis == AXIS_Z1 || nAxis == AXIS_Z2)
		{
			double dX = GetPosition(AXIS_X, b1stPanel);
			double dY = GetPosition(AXIS_Y, b1stPanel);
			if(nAxis == AXIS_Z1)
				GetZMoveOffset(dX, dY, m_dCalibrationOffset[nAxis], TRUE);
			else
				GetZMoveOffset(dX, dY, m_dCalibrationOffset[nAxis], FALSE);

			if(!bZCalUse)
				m_dCalibrationOffset[nAxis] = 0;

			return m_clsMotor->MotorMoveAxis(nAxis, dPosition + m_dCalibrationOffset[nAxis]);
		}
		else
		{
			m_dCalibrationOffset[nAxis] = 0.0;
			return m_clsMotor->MotorMoveAxis(nAxis, dPosition + m_dCalibrationOffset[nAxis]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if(nAxis >= PMAC_AXIS_MAX)
			return TRUE;

		if (!IsValidAxisPosition(nAxis, dPosition, nMoveMode, bPass))
		{
			return FALSE;
		}
		
		m_dDestinationPos[nAxis] = dPosition;

		return m_clsPmacMotor->MotorMoveAxis(nAxis, dPosition);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if(nAxis >= COMI_AXIS_MAX)
			return TRUE;
		if (!IsValidAxisPosition(nAxis, dPosition))
		{
			return FALSE;
		}
		if(!m_pComizorMotor->SetSpeed(nAxis, long(m_pSetting[nAxis].dTableFeedRate)))
			return FALSE;
		
		m_dDestinationPos[nAxis] = dPosition;
		
		return m_pComizorMotor->MotorMoveAxis(nAxis, dPosition);
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::SetVibration()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
	#ifdef __PUSAN1__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay, gSystemINI.m_sSystemDevice.nVibrationLPTime);
	#endif

	#ifdef __PUSAN2__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay, gSystemINI.m_sSystemDevice.nVibrationLPTime);
	#endif

	#ifdef __PUSAN_OLD_32__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay, gSystemINI.m_sSystemDevice.nVibrationLPTime);
	#endif

	#ifdef __KUNSAN_1__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay);
	#endif

	#ifdef __OSAN_LG__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay);
	#endif
	
	#ifdef __KUNSAN_8__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay);
	#endif

	#ifdef __KUNSAN_6__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay);//, gSystemINI.m_sSystemDevice.dVibrationDelay);
	#endif

	#ifdef __PUSAN_OLD_17__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay, gSystemINI.m_sSystemDevice.nVibrationLPTime);
	#endif

	#ifdef __PUSAN_LDD__
		if(m_clsMotor)
			return m_clsMotor->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount, gSystemINI.m_sSystemDevice.dVibrationDelay, gSystemINI.m_sSystemDevice.dVibrationDelay);
	#endif

	#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(m_clsMelsec)
			return m_clsMelsec->SetVibration(gSystemINI.m_sSystemDevice.nVibrationCount);
	#endif
	}

		return TRUE;
#endif
}

BOOL DeviceMotor::SetLimitZ() // yhchung 061024 Set Limit Axis-Z
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->SetLimitZ(m_pSetting[AXIS_Z1].dLimitMinus * 1000, m_pSetting[AXIS_Z1].dLimitPlus * 1000, m_pSetting[AXIS_Z2].dLimitMinus * 1000, m_pSetting[AXIS_Z2].dLimitPlus * 1000,
		m_pSetting[AXIS_X].dLimitMinus * 1000, m_pSetting[AXIS_X].dLimitPlus);

	return TRUE;
#endif
}

/////////////////////////////////////////////////////////
// X, Y�� �̵�
BOOL DeviceMotor::MoveXY(double dPosX, double dPosY, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
		{
			return FALSE;
		}

		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;

		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			return m_clsMotor->MotorMoveXY(dPosX + m_dCalibrationOffset[AXIS_X], dPosY + m_dCalibrationOffset[AXIS_Y]);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			return m_clsMotor->MotorMoveXY(dPosX + m_dSlaveCalibrationOffset[AXIS_X], dPosY + m_dSlaveCalibrationOffset[AXIS_Y]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
		{
			return FALSE;
		}

		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;

		return m_clsPmacMotor->MotorMoveXY(dPosX, dPosY);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		if (!IsValidAxisPosition(AXIS_X, dPosX) || !IsValidAxisPosition(AXIS_Y, dPosY))
		{
			return FALSE;
		}
		
		if(!m_pComizorMotor->SetSpeed(AXIS_X, long(m_pSetting[AXIS_X].dTableFeedRate)))
			return FALSE;
		if(!m_pComizorMotor->SetSpeed(AXIS_Y, long(m_pSetting[AXIS_Y].dTableFeedRate)))
			return FALSE;
		
		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		
		return m_pComizorMotor->MotorMoveXY(dPosX, dPosY);
*/
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MotorMoveXY(dPosX, dPosY, b1stPanel);
	}

	return TRUE;
#endif
}

////////////////////////////////////////////////////////////////////////
// X, Y, Z1, Z2, M, C�� �̵�
BOOL DeviceMotor::MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	BOOL bRet  = FALSE;
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass))
			return FALSE;
		if ( !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
			return FALSE;
		if(!IsValidAxisPosition(AXIS_Z1, dPosZ1) )
			return FALSE;
		if( !IsValidAxisPosition(AXIS_Z2, dPosZ2))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_M, dPosM) )
			return FALSE;
		if( !IsValidAxisPosition(AXIS_M2, dPosM2) )
			return FALSE;
		if(!IsValidAxisPosition(AXIS_C, dPosC))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;

		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dCalibrationOffset[AXIS_Z1] = 0.0;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;
		m_dCalibrationOffset[AXIS_Z2] = 0.0;
		m_dDestinationPos[AXIS_M] = dPosM;
		m_dDestinationPos[AXIS_C] = dPosC;	
		m_dCalibrationOffset[AXIS_M] = 0.0;
		m_dCalibrationOffset[AXIS_C] = 0.0;

		m_dDestinationPos[AXIS_M2] = dPosM2;
		m_dDestinationPos[AXIS_C2] = dPosC2;	
		m_dCalibrationOffset[AXIS_M2] = 0.0;
		m_dCalibrationOffset[AXIS_C2] = 0.0;
		
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dCalibrationOffset[AXIS_X],
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,
				dPosC, dPosC2, bTophat);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dSlaveCalibrationOffset[AXIS_X],
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,
				dPosC, dPosC2, bTophat);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MotorMoveXYZ(dPosX, dPosY, dPosZ1, dPosZ1, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MoveXY(dPosX, dPosY);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MoveXYZ(dPosX, dPosY, dPosZ1, dPosZ1, b1stPanel);
	}

	return TRUE;
#endif
}

//////////////////////////////////////////////////////////
// Z1�� �̵�
BOOL DeviceMotor::MoveZ(double dPosZ1, BOOL bRawMove)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1))
		{
			return FALSE;
		}
		
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		
		if (bRawMove)
			m_dCalibrationOffset[AXIS_Z1] = 0.0;
		else
		{
			double dX = GetPosition(AXIS_X);
			double dY = GetPosition(AXIS_Y);
			GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z1], TRUE);
		}
		
		return m_clsMotor->MotorMoveZ(dPosZ1 + m_dCalibrationOffset[AXIS_Z1]);
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1))
		{
			return FALSE;
		}
		
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		
		return m_clsPmacMotor->MotorMoveZ(dPosZ1);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
/*		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1))
		{
			return FALSE;
		}

		int nRet = 0;
		
		// M-Variable Definition
		// m8005->DP:$60905 ;Z(mm)
		// m8006->DP:$60906 ;FEEDRATE(mm/s)
		
		// P-Variable Comment
		// p8000 -> Motion Status. 0 : FINISH, 1 : EXECUTION, 2 : IDLE
		
		DWORD	dwMap[2];
		char	szBuf[255];
		UINT	offset;
		int		nSize = sizeof(dwMap);
		
		memset(dwMap, 0, nSize);
		memset(szBuf, 0, 255);
		
		strcpy_s(szBuf, _T("905"));
		offset = (UINT)HextoNum(szBuf)*4;
		
		// Z
		dwMap[0] = (DWORD)( dPosZ1 * STAGE_Z_FACTOR );
		
		// FeedRate
		dwMap[1] = gSystemINI.m_sAxisInfo[AXIS_Z].dTableFeedRate; // 25;
		
		// Insert Queue
		m_clsUmacProgram->m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap );
		
		// Coordinate 1, Motion Program 105
		m_clsUmacProgram->StartMotion( 1, 105 );
		
		// Reset Start Motion Event Object
		m_clsUmacProgram->SetStartMotion(1);
		m_clsUmacProgram->m_EvtStartMotion.ResetEvent();
		
		DWORD dwFlag = ::WaitForSingleObject( m_clsUmacProgram->m_EvtStartMotion.m_hObject, 3000 );
		
		if( WAIT_OBJECT_0 != dwFlag )
		{
			return FALSE;
		}
		
		if( m_clsUmacProgram->GetStartMotion() != 0 )
		{
			return FALSE;
		}
		
		// Start UMAC Timer
		m_clsUmacProgram->m_clsTimer.Start();
		
		// Set Check Motion Status
		m_clsUmacProgram->SetCheckMotionStatus(TRUE);
		
		// Reset Motion Error
		m_clsUmacProgram->SetMotionError( FALSE );
		
		// Reset Motion Event Object
		m_clsUmacProgram->m_EvtMotion.ResetEvent();
*/	}

	return TRUE;
#endif
}

//////////////////////////////////////////////////////////
// Z1, Z2�� �̵�
BOOL DeviceMotor::MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
		{
			return FALSE;
		}

		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;

		if(bRawMove)
		{
			m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0.0;
		}
		else
		{
			double dX = GetPosition(AXIS_X);
			double dY = GetPosition(AXIS_Y);
			GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dX, dY, m_dCalibrationOffset[AXIS_Z2], FALSE);
		}
		
		return m_clsMotor->MotorMoveZ(dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
							dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return m_clsPmacMotor->MotorMoveZ(dPosZ1);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MoveZ(dPosZ1);
	}

	return TRUE;
#endif
}

////////////////////////////////////////////////////////////////////////////////////////
// X, Y, Z1, Z2�� �̵�
BOOL DeviceMotor::MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, BOOL bZCalUse, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass)
			|| !IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
		{
			return FALSE;
		}

		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;

		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZ(dPosX + m_dCalibrationOffset[AXIS_X],
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZ(dPosX + m_dSlaveCalibrationOffset[AXIS_X],
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return m_clsPmacMotor->MotorMoveXYZ(dPosX, dPosY, dPosZ1);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MoveXY(dPosX, dPosY);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if( !MotorMoveAxis(AXIS_Z1, dPosZ1, b1stPanel) )
			return FALSE;
		if( !InPositionIO(AXIS_Z1) )
			return FALSE;
		
		if( !MotorMoveXY(dPosX, dPosY, b1stPanel) )
			return FALSE;
	}

	return TRUE;
#endif
}


BOOL DeviceMotor::MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
			return FALSE;

		if (!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_C, dPosC))
			return FALSE;
		
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;
		
		m_dCalibrationOffset[AXIS_M] = 0.0;
		
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dCalibrationOffset[AXIS_C] = 0.0;

		double dPosX = GetPosition(AXIS_X);
		double dPosY = GetPosition(AXIS_Y);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
		if(!bZCalUse)
		{
			m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0;
		}
		
		return m_clsMotor->MotorMoveZMC2(dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
			dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
			dMaskPos, dPosC, bTophat);
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MoveZ(dPosZ1);	
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MotorMoveAxis(AXIS_Z1, dPosZ1, TRUE);
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::MoveMC(double dMaskPos, double dPosC)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_C, dPosC))
			return FALSE;
		
		m_dDestinationPos[AXIS_M] = dMaskPos;
		m_dCalibrationOffset[AXIS_M] = 0.0;
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dCalibrationOffset[AXIS_C] = 0.0;

		return m_clsMotor->MotorMoveMC(dMaskPos, dPosC);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return TRUE; // MoveM(dMaskPos);
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			!IsValidAxisPosition(AXIS_M2, dMaskPos2) || !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;
		
		m_dDestinationPos[AXIS_M] = dMaskPos;
		m_dDestinationPos[AXIS_M2] = dMaskPos2;
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_C] = 0.0;
		m_dCalibrationOffset[AXIS_M2] = m_dCalibrationOffset[AXIS_C2] = 0.0;
		
		return m_clsMotor->MotorMoveMC2DownOnly((int)dMaskPos, (int)dMaskPos2, dPosC, dPosC2, bTophat);
	}

	return TRUE;
#endif
}

/////////////////////////////////////////////////////////////////////////////////////
// Purpose		: Shutter On Off
BOOL DeviceMotor::MotorShutterAll(BOOL bOpenMaster/*TRUE*/, BOOL bOpenSlave/*TRUE*/)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->MotorShutterAll(bOpenMaster, bOpenSlave);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
/*
		m_pComizorMotor->SetSutter(bOpenMaster, bOpenSlave);
		return m_pComizorMotor->WriteOutPort(SHUTTER_OPEN_CLOSE_SOL, bOpenMaster);
*/
	}

	return TRUE;
		
#endif
}

/////////////////////////////////
// ������ ����
BOOL DeviceMotor::Stop(int nAxis)
{
	if(!IsAxisOver(nAxis, _T("Stop")))
		return FALSE;
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->Stop(nAxis);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->Stop(nAxis);
	}

	return TRUE;
#endif
}

//////////////////////////////////////////////////////
// Error ���ϱ�
LONG DeviceMotor::GetCurrentError(ERRORCOMMAND nError)
{
#ifndef __TEST__
	LONG nRet;
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifndef __OSAN_LG__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		#ifdef __ADD_MELSEC_MOTOR__
			if(nError > STATUS_HANDLER_UNLOADER)
				return m_clsMotor->GetCurrentError(nError);
			else
			{
				if(m_clsMelsec)
					return m_clsMelsec->GetCurrentError(nError);
			}
		#else
				return m_clsMotor->GetCurrentError(nError);
		#endif
	#else
		return m_clsMotor->GetCurrentError(nError);
	#endif
#else

	#ifdef __ADD_MELSEC_MOTOR__
		if(nError > STATUS_HANDLER_UNLOADER)
			nRet = m_clsMotor->GetCurrentError(nError);
		else
		{
			if(m_clsMelsec)
				nRet = m_clsMelsec->GetCurrentError(nError);
		}
	#else
		nRet = m_clsMotor->GetCurrentError(nError);
	#endif
		
		if(nRet != 0)
		{
			if(nError != STATUS_IO1 && nError != STATUS_IO2 &&
				nError != STATUS_IO3 && nError != STATUS_IO4 &&
				nError != STATUS_IO5 && !(nError == ERROR_LOAD && (nRet == 0x0004)))
			{
				if(nError == ERROR_OTHERS && nRet == 0x10000)
				{
					if(GetAOMTime() && !gProcessINI.m_sProcessSystem.bNoUseAOMAlarm)
						m_bAnyError = TRUE;
				}
				else
				{
					if(nError != STATUS_HANDLER_LOADER && nError != STATUS_HANDLER_UNLOADER)
						m_bAnyError = TRUE;
				}
			}
		}
		
		return nRet;
#endif
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentError(nError);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return m_clsUmacProgram->GetCurrentError(nError);
	}

	return 0;
#else
	return 0;
#endif
}

/////////////////////////////////////////////////////////
// Motor ���� ��� ���ϱ�[Off=0, MPG=1, Home=2, Manual=3, Auto=4]
BYTE DeviceMotor::GetCurrentMode()
{
#ifdef __TEST__
	return MODE_MANUAL;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentMode();
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(gHandlerInput.IsMPG())
			return MODE_MPG;
		else
			return MODE_MANUAL;
	}
	
	return MODE_MANUAL;
#endif
}

////////////////////////////////////
// ���� EMStop[1 = On, 0 = Off]
BYTE DeviceMotor::GetCurrentEMStop()
{
#ifdef __TEST__
	return FALSE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentEMStop();
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentEMStop();
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_sSysSensor.bEmergencySwitch;
	}

	return 0;
}

BYTE DeviceMotor::GetCurrentPowerMeter()
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentPowerMeter();
	
	return FALSE;
}

///////////////////////////////////////
// Purpose		: High Speed Shutter #1
// [1 = Open, 2 = Close 3 = Center]
BYTE DeviceMotor::GetCurrentShutter1()
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentShutter1();
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentShutter1();
	}

	return 1;
}

///////////////////////////////////////
// Purpose		: High Speed Shutter #2
// [1 = Open, 2 = Close 3 = Center]
BYTE DeviceMotor::GetCurrentShutter2()
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentShutter2();
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentShutter2();
	}

	return 1;
}

///////////////////////////////////////
// Purpose		: PCB Detect
BYTE DeviceMotor::GetCurrentLoadDetect(int nUsePanel)
{
#ifdef __TEST__
	return PCB_LOADER;
#else
	#ifdef __NO_LOADER
		return PCB_LOADER;
	#else
		#ifdef __ADD_MELSEC_MOTOR__
			#ifdef __KUNSAN_SAMSUNG_LARGE___
					return m_clsMotor->GetCurrentLoadDetect();
			#else
//				return m_clsMotor->GetCurrentLoadDetect(); // 0819 ejtest
				BOOL bLP1 = m_clsMelsec->IsLoaderPicker1PCBExist();
				BOOL bLP2 = m_clsMelsec->IsLoaderPicker2PCBExist();
				BOOL bAlignRun = m_clsMelsec->IsAligner(FALSE);
				BOOL bAlignEnd = m_clsMelsec->IsAligner(TRUE);
			
				if(nUsePanel == 0)
				{
					if(!bLP1 || !bLP2)
						return PCB_NONE;
					else if(bAlignRun)
						return PCB_ALIGN;
					else if(bAlignEnd)
						return PCB_LOADER;
				}
				else if(nUsePanel == 1)
				{
					if(!bLP1)
						return PCB_NONE;
					else if(bAlignRun)
						return PCB_ALIGN;
					else if(bAlignEnd)
						return PCB_LOADER;
				}
				else
				{
					if(!bLP2)
						return PCB_NONE;
					else if(bAlignRun)
						return PCB_ALIGN;
					else if(bAlignEnd)
						return PCB_LOADER;
				}
#			endif
		#else
			if(m_nMotorType == MOTOR_UMAC)
				return m_clsMotor->GetCurrentLoadDetect();
		#endif

		return PCB_LOADER;
	#endif
#endif
}

///////////////////////////////////////
// Purpose		: PCB Detect
BYTE DeviceMotor::GetCurrentUnloadDetect()
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentUnloadDetect();
	
	return 0;
}

/////////////////////////////////////
// Purpose		: Suction
BYTE DeviceMotor::GetCurrentSuction()
{
#ifdef __TEST__
	if(gDProject.m_nSeparation == USE_DUAL)
		return 3;
	else if(gDProject.m_nSeparation == USE_1ST)
		return 1;
	else if(gDProject.m_nSeparation == USE_2ND)
		return 2;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentSuction();
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentSuction();
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(gHandlerInput.m_sSysSensor.bTableVacuumSensor)
		{
			if(gDProject.m_nSeparation == USE_DUAL)
				return 3;
			else if(gDProject.m_nSeparation == USE_1ST)
				return 1;
			else if(gDProject.m_nSeparation == USE_2ND)
				return 2;
		}
		else
			return 0;
	}

	return 3;
}


BYTE DeviceMotor::GetExternalLaser()
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetExternalLaser();
	
	return FALSE;
}
//////////////////////////////////////////////////////
// Purpose		: Height Sensor ����
BOOL DeviceMotor::GetCurrentHeight(BOOL bFirst, BOOL bDown)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentHeight(bFirst, bDown);

	return TRUE;
#endif
}


BOOL DeviceMotor::GetCurrentVacuumMotor(BOOL b1st)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentVacuumMotor(b1st);
	
	return TRUE;
#endif
}

///////////////////////////////////////////////////////
// MP920 IO���� ����
BOOL DeviceMotor::SetOutPort(BYTE nPortNo, WORD wOnOff, BOOL bAbs)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;

		bRet = m_clsMotor->SetOutPort(nPortNo, wOnOff);
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->SetOutPort(nPortNo, wOnOff);
#endif
		return bRet;
	}
	else if(m_nMotorType == MOTOR_PMAC)
		return m_clsPmacMotor->SetOutPort(nPortNo, wOnOff);
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		char szCmd[20] = {0, };
		if(nPortNo == PORT_TABLE_SUCTION)
		{
			if(wOnOff != 0) // on
			{
				sprintf_s(szCmd, 20, _T("m4040=1"));
				m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
				sprintf_s(szCmd, 20, _T("m4041=0"));
				m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
			}
			else
			{
				sprintf_s(szCmd, 20, _T("m4041=1"));
				m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
				sprintf_s(szCmd, 20, _T("m4040=0"));
				m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
			}
		}
		if(nPortNo == PORT_SYSTEM_DOOR_BYPASS)
		{
			if(wOnOff != 0) // on
				sprintf_s(szCmd, 20, _T("m4048=1"));
			else
				sprintf_s(szCmd, 20, _T("m4048=0"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
		if(nPortNo == PORT_LAMP)
		{
			if(wOnOff != 0) // on
				sprintf_s(szCmd, 20, _T("m4050=1"));
			else
				sprintf_s(szCmd, 20, _T("m4050=0"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
		if(nPortNo == PORT_FROMT_DOOR_LOCK)
		{
			if(wOnOff != 0) // lock
				sprintf_s(szCmd, 20, _T("m4044=1"));
			else
				sprintf_s(szCmd, 20, _T("m4044=0"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
		if(nPortNo == PORT_LOAD_DOOR_LOCK)
		{
			if(wOnOff != 0) // lock
				sprintf_s(szCmd, 20, _T("m4045=1"));
			else
				sprintf_s(szCmd, 20, _T("m4045=0"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
	}

	return TRUE;
#endif
}

//////////////////////////////////
// Motor ���� ���� ����
BOOL DeviceMotor::InPositionStop()
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->InPositionStop();
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->InPositionStop();
#endif
		return bRet;
	}

	return TRUE;
#else
	return TRUE;
#endif
}

/////////////////////////////////////////////////
// Motor ���� ����
BOOL DeviceMotor::IsMotorStop(BOOL bFlag/*TRUE*/)
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->IsMotorStop(bFlag);
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->IsMotorStop(bFlag);
#endif
		return bRet;
	}

	return TRUE;
#else
	return TRUE;
#endif
}

////////////////////////////////////////////////////////////
// Motor Inposition ����
int DeviceMotor::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		if(nAxis == -1 || nAxis <= AXIS_UL_CARRIER)
			bRet = m_clsMotor->IsInPosition(nAxis, bWait);
#ifdef __ADD_MELSEC_MOTOR__
		if(nAxis == -1 || nAxis > AXIS_UL_CARRIER)
		{
			if(m_clsMelsec)
				bRet = bRet & m_clsMelsec->IsInPosition(nAxis, bWait);
		}
#endif
		return bRet;
	}
	else if(m_nMotorType == MOTOR_PMAC)
		return m_clsPmacMotor->IsInPosition(nAxis, bWait);
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->IsInPosition(nAxis, bWait);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(nAxis == -1)
			return InPositionIO(AXIS_X + AXIS_Y + AXIS_Z1);
		else
			return InPositionIO(nAxis);
	}

	return TRUE;
#else
	return TRUE;
#endif
}

//////////////////////////////////////////////////////////
// Motor ���� ����
int DeviceMotor::IsInOrigin(int nAxis, BOOL bWait/*TRUE*/)
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		if(nAxis == -1 || nAxis <= AXIS_UL_CARRIER)
			bRet = m_clsMotor->IsInOrigin(nAxis, bWait);
#ifdef __ADD_MELSEC_MOTOR__
		if(nAxis == -1 || nAxis > AXIS_UL_CARRIER)
		{
			if(m_clsMelsec)
				bRet = bRet & m_clsMelsec->IsInOrigin(nAxis, bWait);
		}
#endif
		return bRet;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->IsInOrigin(nAxis, bWait);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_clsPCOutput.m_bOnlyStageInitReq;
	}

	return TRUE;
#else
	return TRUE;
#endif
}

//////////////////////////////////////////////////////////
// Motor All Stop
BOOL DeviceMotor::IsAnyMotorRun()
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->IsAnyMotorRun();
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->IsAnyMotorRun();
#endif
		return bRet;
	}

	return FALSE;
#endif
}

////////////////////////////////////
// Motor �غ����
BOOL DeviceMotor::IsReady(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
 	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->IsReady(nAxis);
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->IsReady(nAxis);
#endif
		return bRet;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->IsReady(nAxis);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_clsPCOutput.m_sStageIF.bStageReady;
	}

	return TRUE;
#endif
}

void DeviceMotor::GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag)
{
	// reference of reference is undefined. so this stupid-like handling
	double dXOff = 0 , dYOff = 0, dXOff2 = 0, dYOff2 = 0;
	if(m_Calibration != NULL)
		m_Calibration->GetCalibrationOffset(dX, dY, dXOff, dYOff);
	if(m_SlaveCalibration != NULL)
		m_SlaveCalibration->GetCalibrationOffset(dX, dY, dXOff2, dYOff2);
	if(cFlag == FIRST_PANEL_OFFSET)
	{
		dXOffset = (int(dXOff*100000))/100000.0;
		dYOffset = (int(dYOff*100000))/100000.0;
	}
	else if(cFlag == SECOND_PANEL_OFFSET)
	{
		dXOffset = (int(dXOff2*100000))/100000.0;
		dYOffset = (int(dYOff2*100000))/100000.0;
	}
	else
	{
		dXOffset = (int((dXOff2 - dXOff)*100000))/100000.0;
		dYOffset = (int((dYOff2 - dYOff)*100000))/100000.0;
	}
}

void DeviceMotor::GetZMoveOffset(double dX, double dY, double& dOffset, BOOL bFirst)
{
	if(bFirst)
	{
		if(m_ZCalInfo1)
			m_ZCalInfo1->GetCalibrationOffset(dX, dY, dOffset);
	}
	else
	{
		if(m_ZCalInfo2)
			m_ZCalInfo2->GetCalibrationOffset(dX, dY, dOffset);
	}
}

void DeviceMotor::GetTMoveOffset(double dPos, double& dOffset)
{
	m_TCalInfo->GetCalibrationOffset(dPos, dOffset);
}

void DeviceMotor::LoadTCalibrationFile(CString strPath)
{
	m_TCalInfo->LoadData(strPath);
}

void DeviceMotor::LoadCalibrationFile(CString strPath)
{
	CString strFileName;
	strFileName.Format(_T("%sxy.calibration"), strPath);
	m_Calibration->LoadCalibration(strFileName);
	
	strFileName.Format(_T("%sxy.Scalibration"), strPath);
	m_SlaveCalibration->LoadCalibration(strFileName);
}

void DeviceMotor::LoadZCalibrationFile(CString strPath, BOOL bFirst)
{
	if(bFirst)
	{
		m_ZCalInfo1->LoadData(strPath, bFirst);
	}
	else
	{
		m_ZCalInfo2->LoadData(strPath, bFirst);
	}
}

void DeviceMotor::UpdateTCalibrationFile(CALDATA &calData)
{
	m_TCalInfo->UpdateCalibration(calData);
	m_TCalInfo->SaveCalibration();
}

void DeviceMotor::UpdateZCalibrationFile(CALHEAD &calHead, BOOL bFirst)
{
	if(bFirst)
	{
		m_ZCalInfo1->UpdateCalibration(calHead);
		m_ZCalInfo1->SaveCalibration(bFirst);
	}
	else
	{
		m_ZCalInfo2->UpdateCalibration(calHead);
		m_ZCalInfo2->SaveCalibration(bFirst);
	}
}

void DeviceMotor::UpdateCalibrationFile(CString strPath)
{
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	TCHAR *szNext;
	FILE* fp = NULL;
	CString strFileName(strPath + TABLE_CALIBRATION_FILE);
	
	if (NULL == fopen_s(&fp, strFileName, "rb"))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return;
		}
		END_CATCH

		double dX = 0.0, dY = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1100.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dX = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dY = atof(token);

				if (fabs(dX) > 1.0 || fabs(dY) > 1.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = dY;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		m_Calibration->UpdateCalibration(calHead);
		delete [] dpOffset;
	}
}

BOOL DeviceMotor::IsFlowWater()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsFlowWater();

	return 0;
#endif
}

UINT DeviceMotor::IsScannerFault()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsScannerFault();

	return 0;
#endif
}

// Add - Door Safety
BOOL DeviceMotor::IsSystemDoorBypass()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->IsSystemDoorBypass();
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->IsSystemDoorBypass(TRUE);
#endif
		return bRet;
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
		return !gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock;
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
		return gHandlerInput.m_clsPCOutput.m_bDoorByPass;

	return TRUE;
#endif
}

BOOL DeviceMotor::IsMainDoorStop()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsMainDoorStop();

	return 0;
#endif
}

BOOL DeviceMotor::IsOpticsDoorStop()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsOpticsDoorStop();

	return 0;
#endif
}

void DeviceMotor::SetCurrentCycle(BYTE cCycle)
{
#ifdef __TEST__
	return;
#else
	if(m_nMotorType == MOTOR_UMAC)
		m_clsMotor->SetCurrentCycle(cCycle);

	return;
#endif
}

BOOL DeviceMotor::LoaderElvOriginPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderElvOriginPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderElvLoadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderElvLoadPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderCarrierAlignPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->LoaderCarrierElvPos();
#else
		bRet = m_clsMotor->LoaderCarrierAlignPos();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderCarrierAlignPos2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		bRet = m_clsMelsec->LoaderCarrierElvPos();
#elif defined __OSAN_LG_2013__
		bRet = m_clsMotor->LoaderCarrierAlignPos2();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderCarrierLoadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->LoaderCarrierTablePos();
#else
		bRet = m_clsMotor->LoaderCarrierLoadPos();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderElvOriginPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderElvOriginPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderElvUnloadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderElvUnloadPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderCarrierTablePos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->UnloaderCarrierTablePos();
#else
		bRet = m_clsMotor->UnloaderCarrierTablePos();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderCarrierUnloadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->UnloaderCarrierElvPos();
#else
		bRet = m_clsMotor->UnloaderCarrierUnloadPos();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker1Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderPickerUpPos(1);
#else
		return m_clsMotor->LoaderPicker1Init();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker1Align()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker1Align();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker1Load()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker1Load();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker1P2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker1P2();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker2Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderPickerUpPos(2);
#else
		return m_clsMotor->LoaderPicker2Init();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker2Align()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker2Align();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker2Load()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker2Load();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker2P2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPicker2P2();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderClampForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderClampForward();
#else
		return m_clsMotor->LoaderClampForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderClampBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderClampBackward();
#else
		return m_clsMotor->LoaderClampBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderVacuum1On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderVacuum1On();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderVacuum1Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderVacuum1Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderVacuum2On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderVacuum2On();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderVacuum2Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderVacuum2Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderBlow1On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderBlow1On();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderBlow1Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderBlow1Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderBlow2On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderBlow2On();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderBlow2Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderBlow2Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderTableForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderTableForward();
#else
		return m_clsMotor->LoaderTableForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderTableBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderTableBackward();
#else
		return m_clsMotor->LoaderTableBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderAlignXForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderAlignXForward();
#else
		return m_clsMotor->LoaderAlignXForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderAlignXBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderAlignXBackward();
#else
		return m_clsMotor->LoaderAlignXBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderAlignYForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderAlignYForward();
#else
		return m_clsMotor->LoaderAlignYForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderAlignYBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderAlignYBackward();
#else
		return m_clsMotor->LoaderAlignYBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker1Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderPickerUpPos(1);
#else
		return m_clsMotor->UnloaderPicker1Init();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker1Table()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker1Table();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker1Unload()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker1Unload();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker1P2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker1P2();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker2Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderPickerUpPos(2);
#else
		return m_clsMotor->UnloaderPicker2Init();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker2Table()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker2Table();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker2Unload()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker2Unload();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker2P2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPicker2P2();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderClampForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderClampForward();
#else
		return m_clsMotor->UnloaderClampForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderClampBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderClampBackward();
#else
		return m_clsMotor->UnloaderClampBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderVacuum1On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderVacuum1On();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderVacuum1Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderVacuum1Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderVacuum2On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderVacuum2On();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderVacuum2Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderVacuum2Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderBlow1On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderBlow1On();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderBlow1Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderBlow1Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderBlow2On()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderBlow2On();
	
	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderBlow2Off()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderBlow2Off();

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderTableForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderTableForward();
#else
		return m_clsMotor->UnloaderTableForward();
#endif
	}
	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderTableBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderTableBackward();
#else
		return m_clsMotor->UnloaderTableBackward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsFluorescentLampOn()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsFluorescentLampOn();
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
		return gHandlerInput.m_sSysSensor.bMainLampOn;

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderPicker1PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__

	#ifdef __KUNSAN_SAMSUNG_LARGE__
			return m_clsMotor->IsLoaderPicker1PCBExist();
	#else
		if(m_clsMelsec)
			return m_clsMelsec->IsLoaderPicker1PCBExist();
	#endif
#else
		return m_clsMotor->IsLoaderPicker1PCBExist();
#endif
	}

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsLoaderPicker2PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->IsLoaderPicker2PCBExist();
#else
		if(m_clsMelsec)
			return m_clsMelsec->IsLoaderPicker2PCBExist();
#endif
#else
		return m_clsMotor->IsLoaderPicker2PCBExist();
#endif
	}

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsAlignerPCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsAlignerPCBExist();

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsULAlignerPCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULAlignerPCBExist();

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsLoader1Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLoader1Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoader2Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLoader2Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsAlignerError()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsAlignerError();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsULAlignerError()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULAlignerError();

	return TRUE;
#endif
}


BOOL DeviceMotor::IsUnloaderPicker1PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderPicker1PCBExist();
#else
		return m_clsMotor->IsUnloaderPicker1PCBExist();
#endif
	}

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsUnloaderPicker2PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderPicker2PCBExist();
#else
		return m_clsMotor->IsUnloaderPicker2PCBExist();
#endif
	}

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsUnloader1Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUnloader1Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloader2Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUnloader2Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsTable1PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsTable1PCBExist();

	return TRUE;
#endif	
}

BOOL DeviceMotor::IsTable2PCBExist()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsTable2PCBExist();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsTable1Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsTable1Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsTable2Error()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsTable2Error();

	return TRUE;
#endif
}

BOOL DeviceMotor::TablePCBReset()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TablePCBReset();

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPCBReset()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->LoaderPCBReset();
#else
		bRet = m_clsMotor->LoaderPCBReset();
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::UnLoaderPCBReset()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->UnloaderPCBReset();
#else
		bRet = m_clsMotor->UnLoaderPCBReset();
#endif
		return bRet;
	}

	
	return TRUE;
#endif
}

BOOL DeviceMotor::Loader1PCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderPCBReset();
#else
		return m_clsMotor->Loader1PCBExist(bOn);
#endif
	}


	return TRUE;
#endif
}

BOOL DeviceMotor::Loader2PCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderPCBReset();
#else
		return m_clsMotor->Loader2PCBExist(bOn);
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::AlignTablePCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->AlignTablePCBExist(bOn);

	return TRUE;
#endif
}

BOOL DeviceMotor::ULAlignTablePCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->ULAlignTablePCBExist(bOn);

	return TRUE;
#endif
}


BOOL DeviceMotor::Unloader1PCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderPCBReset();
#else
		return m_clsMotor->Unloader1PCBExist(bOn);
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::Unloader2PCBExist(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderPCBReset();
#else
		return m_clsMotor->Unloader2PCBExist(bOn);
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::Table1VacuumMotor(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->Table1VacuumMotor(bOn);

	return TRUE;
#endif
}

BOOL DeviceMotor::TableVacuumSelect(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TableVacuumSelect(bOn);
	
	return TRUE;
#endif
}

BOOL DeviceMotor::Table2VacuumMotor(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->Table2VacuumMotor(bOn);

	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->LoaderPickerPad(nPicker, nPad, bUp);

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->UnloaderPickerPad(nPicker, nPad, bUp);

	return TRUE;
#endif
}

void DeviceMotor::SetResetCmd()
{
#ifdef __TEST__
	return;
#else
	if(m_nMotorType == MOTOR_UMAC)
		m_clsMotor->SetResetCmd();
#endif
}

BOOL DeviceMotor::MotorMoveXY(double dPosX, double dPosY, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
		{
			return FALSE;
		}
		
		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			return m_clsMotor->MotorMoveXY(dPosX + m_dCalibrationOffset[AXIS_X], dPosY + m_dCalibrationOffset[AXIS_Y]);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			return m_clsMotor->MotorMoveXY(dPosX + m_dSlaveCalibrationOffset[AXIS_X], dPosY + m_dSlaveCalibrationOffset[AXIS_Y]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
		{
			return FALSE;
		}

		return m_clsPmacMotor->MotorMoveXY(dPosX, dPosY);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MotorMoveXY(dPosX, dPosY, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX) || !IsValidAxisPosition(AXIS_Y, dPosY))
		{
			return FALSE;
		}
		int nRet = 0;
		
		// M-Variable Definition
		// m8000->DP:$60900 ;X(mm)
		// m8001->DP:$60901 ;Y(mm)
		// m8002->DP:$60902 ;FEEDRATE(mm/s)
		
		// P-Variable Comment
		// p8000 -> Motion Status. 0 : FINISH, 1 : EXECUTION, 2 : IDLE
		
		DWORD	dwMap[3];
		char	szBuf[255];
		UINT	offset;
		int		nSize = sizeof(dwMap);
		
		memset(dwMap, 0, nSize);
		memset(szBuf, 0, 255);
		
		strcpy_s(szBuf, _T("900"));
		offset = (UINT)HextoNum(szBuf)*4;
		
		// X
		dwMap[0] = (DWORD)( (575 - dPosX) * STAGE_X_FACTOR );
		
		// Y
		dwMap[1] = (DWORD)( (400 - dPosY) * STAGE_Y_FACTOR );
		
		// FeedRate
		dwMap[2] = (DWORD)gSystemINI.m_sAxisInfo[AXIS_X].dTableFeedRate; // 25; // (DWORD)gRecipeData.m_sCutting.nMoveSpeed;
		
		// Insert Queue
		m_clsUmacProgram->m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap );
		
		// Coordinate 1, Motion Program 103
		m_clsUmacProgram->StartMotion( 1, 103 );
		
		// Reset Start Motion Event Object
		m_clsUmacProgram->SetStartMotion(1);
		m_clsUmacProgram->m_EvtStartMotion.ResetEvent();
		
		DWORD dwFlag = ::WaitForSingleObject( m_clsUmacProgram->m_EvtStartMotion.m_hObject, 3000 );
		
		if( WAIT_OBJECT_0 != dwFlag )
		{
			return FALSE;
		}
		
		if( m_clsUmacProgram->GetStartMotion() != 0 )
		{
			return FALSE;
		}
		
		// Start UMAC Timer
		m_clsUmacProgram->m_clsTimer.Start();
		
		// Set Check Motion Status
		m_clsUmacProgram->SetCheckMotionStatus(TRUE);
		
		// Reset Motion Error
		m_clsUmacProgram->SetMotionError( FALSE );
		
		// Reset Motion Event Obje ct
		m_clsUmacProgram->m_EvtMotion.ResetEvent();
		
		return TRUE;
	}
	else
		return TRUE;
#endif
}

BOOL DeviceMotor::MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
	
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass) ||
			!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
		{
			return FALSE;
		}
		
		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;

		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
//			if(!bZCalUse)
			{
				m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0;
			}
			return m_clsMotor->MotorMoveXYZ(
				dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
//			if(!bZCalUse)
			{
				m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0;
			}
			return m_clsMotor->MotorMoveXYZ(
				dPosX + m_dSlaveCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MotorMoveXY(dPosX, dPosY, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MotorMoveXY(dPosX, dPosY, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MoveXYZ(dPosX, dPosY, dPosZ1, dPosZ2, b1stPanel);
	}
	else
		return TRUE;
#endif
}

BOOL DeviceMotor::MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode, BOOL bPass)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) || !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass) ||
			!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
		{
			return FALSE;
		}

		m_dDestinationPos[AXIS_X] = dPosX;
		m_dDestinationPos[AXIS_Y] = dPosY;
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;
		
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZDownOnly(
				dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZDownOnly(
				dPosX + m_dSlaveCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2]);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MotorMoveXYZ(dPosX, dPosY, dPosZ1, dPosZ1, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MotorMoveXY(dPosX, dPosY, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MoveXYZ(dPosX, dPosY, dPosZ1, dPosZ2, b1stPanel);
	}
	else
	{
		return TRUE;
	}
#endif
}

BOOL DeviceMotor::IsCmdPosOK()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsCmdPosOK();

	return TRUE;
#endif
}

BOOL DeviceMotor::SetMoveIO(int nMoveAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->SetMoveIO(nMoveAxis);

	return TRUE;
#endif
}

BOOL DeviceMotor::InPositionIO2(int nAxis)
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->InPositionIO(nAxis);
	}	
	return TRUE;
#else
	return TRUE;
#endif
}

BOOL DeviceMotor::InPositionIO(int nAxis)
{
	m_nInpositionError = ALL_AXIS_OK;
#ifndef __TEST__
	int nResult = ALL_AXIS_OK;

	if(m_nMotorType == MOTOR_UMAC)
	{
		CCorrectTime	MyTestTime;
		MyTestTime.StartTime();
		double dWaitTime = 0.0;
		
		CString strTime;
		m_clsMotor->m_bReadStatus = FALSE;

		while(TRUE)
		{
			nResult = m_clsMotor->InPositionIO(nAxis);
			if(nResult == ALL_AXIS_OK)
			{
				m_clsMotor->m_bReadStatus = TRUE;
				return TRUE;
			}
			::Sleep(10);
			
			dWaitTime = MyTestTime.PresentTime();
			if(nResult == IND_C1 || nResult == IND_C2) //if bet -> need more time
			{
				if(dWaitTime > 40) // 24 sec time out
				{
					m_nInpositionError = nResult;
					m_clsMotor->m_bReadStatus = TRUE;
					return FALSE;
				}
			}
			else
			{
				if(dWaitTime > 10) // 24 sec time out
				{
					m_nInpositionError = nResult;
					m_clsMotor->m_bReadStatus = TRUE;
					return FALSE;
				}
			}
		}
	}	
	else if(m_nMotorType == MOTOR_PMAC)
	{
		CCorrectTime	MyTestTime;
		MyTestTime.StartTime();
		double dWaitTime = 0.0;
		
		CString strTime;
		
		while(TRUE)
		{
			::Sleep(0);

			nResult = m_clsPmacMotor->InPositionIO(nAxis);
			if(nResult == ALL_AXIS_OK) 
			{
				return TRUE;
			}
			else
			{
				dWaitTime = MyTestTime.PresentTime();
				if(dWaitTime > 20) // 20 sec time out
				{
					m_nInpositionError = nResult;
					return FALSE;
				}
			}
		}	
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->IsInPosition(nAxis);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		// Until Motion finish, Hold here
		// If can't occur motion event duing 25 secs, Occur time out.
		if(m_clsUmacProgram->GetCheckMotionStatus())
		{
			BOOL bRet;
			DWORD dwFlag = ::WaitForSingleObject( m_clsUmacProgram->m_EvtMotion.m_hObject, 25000 );
			
			// Reset Check Motion Status
			m_clsUmacProgram->SetCheckMotionStatus(FALSE);
			
			if( WAIT_OBJECT_0 == dwFlag )
				bRet = TRUE;
			else 
				bRet = FALSE;
			
			if( TRUE == m_clsUmacProgram->GetMotionError() )
				bRet = FALSE;
			
			return bRet;
		}
		else
			return TRUE;
	}

	return TRUE;
#else
	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinCartPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinCartPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinCartPos2()
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __OSAN_LG_2013__
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinCartPos2();
#endif
	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinLoadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinLoadPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinOriginPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinOriginPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinReadyPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinReadyPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinAlignPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinAlignPos();
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsLCinAlignPos2()
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __OSAN_LG_2013__
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLCinAlignPos2();
#endif
	return TRUE;

#endif
}

BOOL DeviceMotor::IsUCinAlignPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUCinAlignPos();
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsUCinCartPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUCinCartPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUCinUnloadPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUCinUnloadPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUCinOriginPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUCinOriginPos();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLP1P1Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLP1P1Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLP1P2Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLP1P2Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLP2P1Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLP2P1Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLP2P2Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLP2P2Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsULP1P1Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULP1P1Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsULP1P2Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULP1P2Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsULP2P1Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULP2P1Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsULP2P2Up()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsULP2P2Up();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderAlignTableForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsLoaderAlignTableForward();
#else
		return m_clsMotor->IsLoaderAlignTableForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderAlignTableForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderAlignTableForward();
#else
		return m_clsMotor->IsUnloaderAlignTableForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderCartClamp()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsLoaderCartClamp();
#else
		return m_clsMotor->IsLoaderCartClamp();
#endif
		
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsAlignSheetTableForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsAlignSheetTableForward();
#else
		return m_clsMotor->IsAlignSheetTableForward();
#endif
	}
	return TRUE;
#endif
}

BOOL DeviceMotor::IsAlignGuideForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsAlignGuideForward();
#else
		return m_clsMotor->IsAlignGuideForward();
#endif	
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderPicker1Vacuum()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsLPVacuum(TRUE, TRUE);
#else
		return m_clsMotor->IsLoaderPicker1Vacuum();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderPicker2Vacuum()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsLPVacuum(FALSE, TRUE);
#else
		return m_clsMotor->IsLoaderPicker2Vacuum();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderPicker1Blow()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLoaderPicker1Blow();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoaderPicker2Blow()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLoaderPicker2Blow();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderCartClamp()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderCartClamp();
#else
		return m_clsMotor->IsUnloaderCartClamp();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderPicker1Vacuum()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUPVacuum(TRUE, TRUE);
#else
		return m_clsMotor->IsUnloaderPicker1Vacuum();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderPicker2Vacuum()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUPVacuum(FALSE, TRUE);
#else
		return m_clsMotor->IsUnloaderPicker2Vacuum();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderNGBoxForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderNGBoxForward();
#else
		return m_clsMotor->IsUnloaderNGBoxForward();
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderNGBoxBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsUnloaderNGBoxBackward();
#else
		return m_clsMotor->IsUnloaderNGBoxBackward();
#endif
	}

	return TRUE;
#endif
}


BOOL DeviceMotor::IsUnloaderPicker1Blow()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUnloaderPicker1Blow();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsUnloaderPicker2Blow()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsUnloaderPicker2Blow();

	return TRUE;
#endif
}

BOOL DeviceMotor::IsLoadCartNoPCB()
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsLoadCartNoPCB();
#else
		return m_clsMotor->IsLoadCartNoPCB();
#endif
	}

	return FALSE;
#endif
}

BOOL DeviceMotor::SendLoadCartNoPCB()
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->SendLoadCartNoPCB();
	
	return FALSE;
#endif
}

BOOL DeviceMotor::TableCalibration(BOOL bAxisX)
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TableCalibration(bAxisX);

	return FALSE;
#endif
}

BOOL DeviceMotor::IsSafetyMode()
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsSafetyMode();

	return FALSE;
#endif
}

BOOL DeviceMotor::HandlerOperation(int nHandlerOperationID, BOOL bAction)
{
#ifdef __TEST__
	return TRUE;
#endif

#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(bAction == FALSE)
	{
		if(nHandlerOperationID != UI_DIRLL_STATUS_SET)
			return TRUE;
	}
#endif

 	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = 0;
		CString strFile,strLog;
		switch( nHandlerOperationID )
		{
		case UI_DIRLL_STATUS_SET:
#ifdef __ADD_MELSEC_MOTOR__
			bRet = TRUE;
#else
			bRet = m_clsMotor->SetDrillStatus(bAction);
#endif
			break;
		case HANDLER_LOADER_ALIGN :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
			bRet = m_clsMotor->LoaderAlign(bAction);
	#else
			if(IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE))
			{

				strFile.Format(_T("AutorunTrace"));
				strLog.Format(_T("Skip Align Cmd - Already Signal On"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

				return TRUE;
			}
			if(m_clsMelsec)
				bRet = m_clsMelsec->LoaderAlign();
	#endif
#else
			bRet = m_clsMotor->LoaderAlign();
#endif
			break;
		case HANDLER_LOADER_LOAD :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
			bRet = m_clsMotor->LoaderLoading(bAction);
	#else
			if(m_clsMelsec)
				bRet = m_clsMelsec->LoaderLoading();
	#endif
#else
			bRet = m_clsMotor->LoaderLoading();
#endif
			break;
		case HANDLER_LOADER_HOMING :
#ifdef __ADD_MELSEC_MOTOR__
			bRet = TRUE;
#else
			bRet = m_clsMotor->LoaderOrigin();
#endif
			break;
		case HANDLER_UNLOADER_UNLOAD :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
			bRet = m_clsMotor->UnloadUnloading(bAction);
	#else
			if(m_clsMelsec)
				bRet = m_clsMelsec->UnloadUnloading();
	#endif
#else
			bRet = m_clsMotor->UnloadUnloading();
#endif
			break;
		case HANDLER_UNLOADER_HOMING :
#ifdef __ADD_MELSEC_MOTOR__
			bRet = TRUE;
#else
			bRet = m_clsMotor->UnloadOrigin();
#endif
			break;
		case HANDLER_LOADER_INIT :
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
				bRet = m_clsMelsec->LoaderInit();
#else
			bRet = TRUE;
#endif
			break;
		case HANDLER_UNLOADER_INIT :
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
				bRet = m_clsMelsec->UnloaderInit();
#else
			bRet = TRUE;
#endif
			break;
		case HANDLER_LOADER_ALIGN_LOAD :
#ifdef __ADD_MELSEC_MOTOR__
			if(m_clsMelsec)
				bRet = m_clsMelsec->LoaderAlignLoading();
#else
			bRet = TRUE;
#endif
			break;
		default :
			bRet = FALSE;
		}
		
		return bRet;
	}

	return TRUE;
}

BOOL DeviceMotor::IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait)
{
#ifdef __TEST__
	return FALSE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = 0;
		
		switch( nHandlerOperationID )
		{
		case HANDLER_LOADER_ALIGN :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
			return m_clsMotor->IsAligner(bStop, bWait);	
	#else
			if(m_clsMelsec)
				return m_clsMelsec->IsAligner(bStop); 
	#endif
#else
			return m_clsMotor->IsAligner(bStop, bWait);
#endif
			break;
		case HANDLER_LOADER_LOAD :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__	
			return m_clsMotor->IsLoader(bStop, bWait);
	#else
			if(m_clsMelsec)
				return m_clsMelsec->IsLoader(bStop);
	#endif
#else
			return m_clsMotor->IsLoader(bStop, bWait);
#endif
			break;
		case HANDLER_UNLOADER_UNLOAD :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__	
		return m_clsMotor->IsUnload(bStop, bWait);	
	#else
		if(m_clsMelsec)
			return m_clsMelsec->IsUnload(bStop);
	#endif
#else
			return m_clsMotor->IsUnload(bStop, bWait);
#endif		
			break;
		case HANDLER_UNLOADER_TO_LOAD_START :
#ifdef __ADD_MELSEC_MOTOR__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
			return m_clsMotor->IsUnloadertoLoadStart();
	#else
			if(m_clsMelsec)
				return m_clsMelsec->IsUnloadertoLoadStart();
	#endif
#else
			return m_clsMotor->IsUnloadertoLoadStart();
#endif
			break;
		case HANDLER_LOAD_PICKER_DOWN :
#ifdef __KUNSAN_SAMSUNG_LARGE__
			return m_clsMotor->GetLoadPickerDownOK();
#else
			return TRUE;
#endif
			break;
		case HANDLER_UNLOAD_PICKER_DOWN : 
#ifdef __KUNSAN_SAMSUNG_LARGE__
			return m_clsMotor->GetUnloadPickerDownOK();
#else
			return TRUE;
#endif
			break; 
		default :
			bRet = FALSE;
			break;
		}
		
		return bRet;
	}

	return TRUE;
}

BOOL DeviceMotor::TableLoadPos()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TableLoadPos();

	return TRUE;
}

BOOL DeviceMotor::TableUnloadPos(BOOL b1st)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TableUnloadPos(b1st);

	return TRUE;
}

BOOL DeviceMotor::SetAutoSetting(SAUTOSETTING sAutoSetting)
{
	memcpy( &m_sAutoSetting, &sAutoSetting, sizeof(m_sAutoSetting) );
	
	return TRUE;
}

BOOL DeviceMotor::SetAxisInfo(SAXISINFO* sAxisInfo)
{
	memcpy( &m_pSetting, sAxisInfo, sizeof(m_pSetting) );
	
	return TRUE;
}

BOOL DeviceMotor::DownloadAxisInfo()
{
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = FALSE;
		
		for(int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			m_clsMotor->SetOffset( i, m_pSetting[i].dTableAcceleration );
			m_clsMotor->SetSpeed( i, long(m_pSetting[i].dTableFeedRate) );
			m_clsMotor->SetOriginSpeed( i, long(m_pSetting[i].dTableSCurve) );
#ifdef __PUSAN2__
			m_clsMotor->SetPreTATS(i, long(m_pSetting[i].dTableAccelerationPre), long(m_pSetting[i].dTableSCurvePre));
			m_clsMotor->SetNextTATS(i, long(m_pSetting[i].dTableAccelerationNext), long(m_pSetting[i].dTableSCurveNext));
#endif
			m_clsMotor->SetScale( i, m_pSetting[i].dScale );
		}
		
		SetLimitZ();
		SetVibration();
		
		bRet = TRUE;
		
		return bRet;
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		BOOL bRet = FALSE;
		
		for(int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
		{
			m_clsMotor->SetSpeed( i, long(m_pSetting[i].dTableFeedRate) );
		}
	}

	return TRUE;
}

BOOL DeviceMotor::DownloadAutoSetting()
{
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = FALSE;
#ifndef __OSAN_LG__
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		bRet = m_clsMotor->SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
			m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000.,
			m_sAutoSetting.dUnloadPosX2 * 1000., m_sAutoSetting.dUnloadPosY2 * 1000.,
			m_sAutoSetting.dLoadPosX2 * 1000., m_sAutoSetting.dLoadPosY2 * 1000.);
	#else
			bRet = m_clsMotor->SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
			m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000.,
			m_sAutoSetting.dLoadPosX2 * 1000., m_sAutoSetting.dLoadPosY2 * 1000.);
	#endif
		
		bRet = bRet & m_clsMotor->SetLoaderUnloaderPickerPos(m_sAutoSetting.dLoaderCartPos * 1000, m_sAutoSetting.dLoaderCartPos2 * 1000,
			m_sAutoSetting.dLoaderLoadPos * 1000, m_sAutoSetting.dLoaderLoadPos2 * 1000, m_sAutoSetting.dLoaderAlignPos * 1000,
			m_sAutoSetting.dUnloaderCartPos * 1000, m_sAutoSetting.dUnloaderUnloadPos * 1000, m_sAutoSetting.dUnloaderUnloadPos2 * 1000,
			m_sAutoSetting.dUnloaderAlignPos * 1000);
		return bRet;
#else
		bRet = m_clsMotor->SetLoaderUnloaderPos( m_sAutoSetting.dLoadPosX * 1000., m_sAutoSetting.dLoadPosY * 1000.,
			m_sAutoSetting.dUnloadPosX * 1000., m_sAutoSetting.dUnloadPosY * 1000.,
			m_sAutoSetting.dLoadPosX2 * 1000., m_sAutoSetting.dLoadPosY2 * 1000.,
			m_sAutoSetting.dUnclampLimitY * 1000.);
		
		bRet = bRet & m_clsMotor->SetLoaderUnloaderPickerPos(m_sAutoSetting.dLoaderCartPos * 1000, 
			m_sAutoSetting.dLoaderLoadPos * 1000, 
			m_sAutoSetting.dUnloaderCartPos * 1000, m_sAutoSetting.dUnloaderUnloadPos * 1000);
		return bRet;
#endif
	}

	return TRUE;
}

void DeviceMotor::SetAxisSpeed(int nAxis, double dSpeed)
{
	if(m_nMotorType == MOTOR_UMAC)
		m_clsMotor->SetSpeed(nAxis, long(dSpeed));

	return;
}

void DeviceMotor::SetOriginalSpeed()
{
	if(m_nMotorType == MOTOR_UMAC)
	{
		for(int i=0; i<MOTOR_AXIS_MAX; i++)
			m_clsMotor->SetSpeed(i, long(m_pSetting[i].dTableFeedRate));
	}

	return;
}

BOOL DeviceMotor::GetCurrentTableClamp(BOOL b1st, BOOL bClamp)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentTableClamp(b1st, bClamp);

	return TRUE;
}

BOOL DeviceMotor::TableClamp(BOOL bClamp, BOOL bLeft)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->TableClamp(bClamp, m_sAutoSetting.dUnclampLimitY, bLeft);

	return TRUE;
}

BOOL DeviceMotor::WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->WriteOutputIOBIt(nAddr, nBit, bOnOff);
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{

	}

	return TRUE;
}

BOOL DeviceMotor::WriteOutputDWord(UINT nAddr, DWORD dwVal)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->WriteOutputDWord(nAddr, dwVal);

	return TRUE;
}

BOOL DeviceMotor::GetCurrentMotorSol()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetCurrentMotorSol();
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
//		return m_pComizorMotor->GetCurrentMotorSol();
	}
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_sSysSensor.bTableVacuumOnSol;
	}

	return TRUE;
}

BOOL DeviceMotor::IsHandlerReady()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->IsHandlerReady();
	}
	return TRUE;
}
BOOL DeviceMotor::IsHandlerReady(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->IsReady(nAxis);
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsHandlerBusy(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->IsHandlerBusy(nAxis);
#endif
		return bRet;
	}
	
	return TRUE;
#endif	
}

BOOL DeviceMotor::IsHandlerStop(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->IsHandlerStop(nAxis);
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsHandlerInitEnd(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->IsMotorOrigin(nAxis);
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsHandlerAlarm()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerAlarm();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerLotEnd()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerLotEnd();

	return TRUE;
}

BOOL DeviceMotor::IsHandler1stTableExist()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandler1stTableExist();

	return TRUE;
}

BOOL DeviceMotor::IsHandler2ndTableExist()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandler2ndTableExist();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerLoadReady()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerLoadReady();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerLoadEnd()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerLoadEnd();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerLoadAlarm()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerLoadAlarm();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerUnloadReady()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerUnloadReady();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerUnloadEnd()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerUnloadEnd();

	return TRUE;
}

BOOL DeviceMotor::IsHandlerUnloadAlarm()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsHandlerUnloadAlarm();

	return TRUE;
}

BOOL DeviceMotor::MainReady(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainReady(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainAlarm(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainAlarm(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainStart(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainStart(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainStop(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainStop(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainReset(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
#ifdef __OSAN_LG__
	if(bOn)
	{
		m_bAnyError = FALSE;
		TRACE(_T("m_bAnyError False\r\n"));
	}
#endif
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->MainReset(bOn);
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = bRet & m_clsMelsec->MainReset(bOn);
#endif
		return bRet;
	}
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		char szCmd[20] = {0, };
		sprintf_s(szCmd, 20, _T("m4002=1")); // Alarm reset request
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
	}

	return TRUE;
}

BOOL DeviceMotor::MainUseTable(int nUseTable)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
	{
		int nCmd = 0;
		if(nUseTable != 3)
			nCmd = nUseTable;

		return m_clsMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
	}

	return TRUE;
}

BOOL DeviceMotor::MainLoadReady(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainLoadReady(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainLoadEnd(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainLoadEnd(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainUnloadReady(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainUnloadReady(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainUnloadEnd(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainUnloadEnd(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainPCBExist(int nPCBExist)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainPCBExist(nPCBExist);

	return TRUE;
}

BOOL DeviceMotor::MainLotEnd(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainLotEnd(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainLoadStart(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainLoadStart(bOn);

	return TRUE;
}

BOOL DeviceMotor::MainUnloadStart(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->MainUnloadStart(bOn);

	return TRUE;
}

BOOL DeviceMotor::DustSuctionControl(BOOL bLeft, BOOL bUp)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->DustSuctionControl(bLeft, bUp, m_sAutoSetting.dDustSuctionMin, m_sAutoSetting.dDustSuctionMax);

	char szCmd[20] = {0, };
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(bUp)
			sprintf_s(szCmd, 20, _T("m4049=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4049=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
	}
	return TRUE;
}

BOOL DeviceMotor::WriteLoadUnload(int nAdd, BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->WriteLoadUnload(nAdd, bOn);

	return TRUE;
}

BOOL DeviceMotor::WriteOutPort(int nAdd, BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->WriteOutPort(nAdd, bOn);
	return TRUE;
}

BOOL DeviceMotor::GetSystemAir()
{
#ifdef __TEST__
	return TRUE;
#endif
	
//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetSystemAir();
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_sSysSensor.bSystemAirPressure;
	}

	return TRUE;
}

BOOL DeviceMotor::GetChuckStatus(BOOL bClamp)
{
#ifdef __TEST__
	return TRUE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetChuckStatus(bClamp);

	return TRUE;
}

BOOL DeviceMotor::GetLoadingShutterStatus(BOOL bOpen)
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetLoadingShutterStatus(bOpen);

	return TRUE;
}

BOOL DeviceMotor::GetStartSW()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetStartSW();

	return TRUE;
}

BOOL DeviceMotor::GetStopSW()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetStopSW();

	return TRUE;
}

BOOL DeviceMotor::GetResetSW()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetResetSW();

	return TRUE;
}

BOOL DeviceMotor::GetBrushStatus(BOOL bUp)
{
#ifdef __TEST__
	return TRUE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->GetBrushStatus(bUp);

	return TRUE;
}

BOOL DeviceMotor::IsFrontDoorOpen()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->IsFrontDoorOpen();

	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return !gHandlerInput.m_sSysSensor.bFrontDoorLockSol;
	}

	return TRUE;
}

BOOL DeviceMotor::IsLeftDoorOpen()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->IsLeftDoorOpen();

	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return !gHandlerInput.m_sSysSensor.bLoadingDoorLockSol;
	}

	return TRUE;
}

BOOL DeviceMotor::IsRear1DoorOpen()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->IsRear1DoorOpen();

	return TRUE;
}

BOOL DeviceMotor::IsRear2DoorOpen()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->IsRear2DoorOpen();

	return TRUE;
}

BOOL DeviceMotor::IsRightDoorOpen()
{
#ifdef __TEST__
	return FALSE;
#endif

//	if(m_nMotorType == MOTOR_COMIZOA)
//		return m_pComizorMotor->IsRightDoorOpen();

	return TRUE;
}

double DeviceMotor::GetMoveAccel(int nAxis)
{
	return m_pSetting[nAxis].dTableAcceleration;
}

double DeviceMotor::GetMPosition(int nIndex)
{
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->GetMPosition(nIndex);
	
	return 0;
}

void DeviceMotor::ReadTableLimit()
{
	m_dXLimitM = 500;
	m_dXLimitP = 500;
	m_dYLimitM = 500;
	m_dYLimitP = 500;

	CString strCalPath;
	strCalPath.Format(_T("%sTableLimit.dat"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	FILE* fileStream;
	TRY
	{
		errno_t err = fopen_s(&fileStream, strCalPath, "r");
		if(err != NULL)
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_OPEN);
			strMsg.Format(strString, _T("TableLimit.dat"));
			ErrMessage(strMsg);
			return;		
		}
		CString str = _T("");
		
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dXLimitM = atof(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dXLimitP = atof(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dYLimitM = atof(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dYLimitP = atof(str);
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("TableLimit.dat"));
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	return;
}

void DeviceMotor::SetDustSuction(BOOL bOn)
{
#ifdef __TEST__
	return ;
#endif
	
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		char szCmd[20] = {0, };
		if(bOn)
		{
			sprintf_s(szCmd, 20, _T("m6013=130"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
			
			sprintf_s(szCmd, 20, _T("m6012=1"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
		else
		{
			sprintf_s(szCmd, 20, _T("m6013=131"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
			
			sprintf_s(szCmd, 20, _T("m6012=1"));
			m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		}
	}
	
	return;
}

void DeviceMotor::SetTowerLampBuzzer(int nColor, BOOL bBuzzer)
{
#ifdef __TEST__
	return ;
#endif
	char szCmd[20] = {0, };
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(nColor & TOWER_RED)
			sprintf_s(szCmd, 20, _T("m4036=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4036=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);

		if(nColor & TOWER_GREEN)
			sprintf_s(szCmd, 20, _T("m4038=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4038=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);

		if(nColor & TOWER_YELLOW)
			sprintf_s(szCmd, 20, _T("m4037=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4037=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);

		if(bBuzzer)
			sprintf_s(szCmd, 20, _T("m4039=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4039=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);

	}
}

void DeviceMotor::IonizerOn(BOOL bOn)
{
#ifdef __TEST__
	return ;
#endif
	char szCmd[20] = {0, };
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(bOn)
			sprintf_s(szCmd, 20, _T("m4042=1")); 
		else
			sprintf_s(szCmd, 20, _T("m4042=0"));
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
	}
}

void DeviceMotor::GetTowerLampBuzzer(int &nColor, BOOL &bBuzzer)
{
#ifdef __TEST__
	return ;
#endif
	nColor = 0;
	bBuzzer = FALSE;
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		if(gHandlerInput.m_sSysSensor.bTowerLampRedOn)
			nColor |= TOWER_RED;

		if(gHandlerInput.m_sSysSensor.bTowerLampGreenOn)
			nColor |= TOWER_GREEN;

		if(gHandlerInput.m_sSysSensor.bTowerLampYellowOn)
			nColor |= TOWER_YELLOW;

		if(gHandlerInput.m_sSysSensor.bTowerLampBuzzerOn)
			bBuzzer = TRUE;
		
	}
}

BOOL DeviceMotor::IsIonizerAirOn()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_sSysSensor.bIonizerAirBlowerSol;
	}
	return TRUE;
}

BOOL DeviceMotor::IsDustCollectorOn()
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return gHandlerInput.m_sSysSensor.bDustCollectorOn;
	}
	return TRUE;
}

void DeviceMotor::Set2DTableCompOffset()
{
#ifdef __TEST__
	return;
#endif
	if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		char szCmd[20] = {0, };
		sprintf_s(szCmd, 20, _T("m4504=%d"), (int)(gSystemINI.m_sSystemDevice.d2DCompTableOffset.x * 1000)); // X position compare
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
		sprintf_s(szCmd, 20, _T("m4505=%d"), (int)(gSystemINI.m_sSystemDevice.d2DCompTableOffset.y * 1000)); // Laser Fire Enable
		m_clsUmacProgram->m_clsCmdQueue.AddOnlineCmd(szCmd);
	}
}

void DeviceMotor::SetFixedMaskPos(double dPos)
{
//#ifdef __TEST__
//	return;
//#endif
	if(m_nMotorType == MOTOR_UMAC)
		m_clsMotor->SetFixedMaskPos(dPos);
}

BOOL DeviceMotor::MoveLaserBeamPath(BOOL bUp)
{
#ifndef __TEST__

#ifdef __PUSAN_OLD_17__
	return TRUE;
#endif

#ifdef __PUSAN_OLD_32__
	return TRUE;
#endif

#ifdef __KUNSAN_6__
	return TRUE;
#endif

#ifdef __KUNSAN_8__
	return TRUE;
#endif
	
#ifdef __KUNSAN_1__
	return TRUE;
#endif
#ifdef __KUNSAN_2012__
	if(gProcessINI.m_sProcessOption.bLongShortUse == FALSE)
		return TRUE;
#endif

	if(m_nMotorType == MOTOR_UMAC)
	{
		SetOutPort(PORT_LASER_BEAM_PASS, bUp);

		CCorrectTime	MyTestTime;
		MyTestTime.StartTime();
		double dWaitTime = 0.0;

		CString strTime;
		
		while(TRUE)
		{
			::Sleep(10);

			if(m_clsMotor->GetBeamPathStatus(bUp))
				return TRUE;

			dWaitTime = MyTestTime.PresentTime();
			if(dWaitTime > 200)
				return FALSE;
		}
	}

	return TRUE;
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::MoveTophatShutter(BOOL bUp)
{
#ifdef __KUNSAN_6__
	return TRUE;
#endif

#ifdef __KUNSAN_8__
	return TRUE;
#endif

#ifdef __KUNSAN_1__
	return TRUE;
#endif

#ifdef __ANSAN_KCC__
	return TRUE;
#endif
	
#ifdef __KUNSAN_2012__
		return TRUE;
#endif

#ifdef __KUNSAN_2013__
	return TRUE;
#endif

#ifdef __OSAN_LG_2013__
	return TRUE;
#endif

#ifdef __OSAN_LG__
	return TRUE;
#endif

#ifdef __JEUNGPYEONG_DNP_BGA__
	return TRUE;
#endif

#ifdef __CUNGJU_LG__
	return TRUE;
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__
	return TRUE;
#endif
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
		SetOutPort(PORT_LASER_PASS_TOP, bUp);
		
		CCorrectTime	MyTestTime;
		MyTestTime.StartTime();
		double dWaitTime = 0.0;
		
		CString strTime;
		
		while(TRUE)
		{
			::Sleep(10);
			
			if(m_clsMotor->GetTopHatStatus(bUp))
				return TRUE;
			
			dWaitTime = MyTestTime.PresentTime();
			if(dWaitTime > 20) // 2 sec time out
				return FALSE;
		}
	}
	
	return TRUE;
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			!IsValidAxisPosition(AXIS_M2, dMaskPos2) || !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;
		
		m_dDestinationPos[AXIS_M] = dMaskPos;
		m_dDestinationPos[AXIS_M2] = dMaskPos2;
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dDestinationPos[AXIS_A1] = dA1;
		m_dDestinationPos[AXIS_A2] = dA2;
		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_C] = 0.0;
		m_dCalibrationOffset[AXIS_M2] = m_dCalibrationOffset[AXIS_C2] = 0.0;
		
		return m_clsMotor->MotorMoveMCA2DownOnly(dMaskPos, dMaskPos2, dPosC, dPosC2, dA1, dA2, bTophat);
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (nMaskPos < 0 || nMaskPos >= MAXMASKNO || nMaskPos2 < 0 || nMaskPos2 >= MAXMASKNO)
		{
//			ErrMsgDlg(STDGNALM435);
			return FALSE;
		}
		
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
			return FALSE;
		
		if (!IsValidAxisPosition(AXIS_C, dPosC) || !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;
		
		if (!IsValidAxisPosition(AXIS_A1, dPosA) || !IsValidAxisPosition(AXIS_A2, dPosA2))
			return FALSE;

		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;
		m_dDestinationPos[AXIS_A1] = dPosA;
		m_dDestinationPos[AXIS_A2] = dPosA2;
		
		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_M2] = 0.0;
		
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dCalibrationOffset[AXIS_C] = 0.0;
		
		m_dCalibrationOffset[AXIS_C2] = 0.0;
		dPosC2 += m_dCalibrationOffset[AXIS_C2];
		
		double dPosX = GetPosition(AXIS_X);
		double dPosY = GetPosition(AXIS_Y);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
		if(!bZCalUse)
		{
			m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0;
		}
		
		return m_clsMotor->MoveZMCA2(dPosZ1 + m_dCalibrationOffset[AXIS_Z1], 
			dPosZ2 + m_dCalibrationOffset[AXIS_Z2],	nMaskPos, nMaskPos2, 
			dPosC, dPosC2, dPosA, dPosA2, bZCalUse, bTophat);
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MoveZ(dPosZ1);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MotorMoveAxis(AXIS_Z1, dPosZ1, TRUE);
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
//		if (nMaskPos < 0 || nMaskPos >= MAXMASKNO || nMaskPos2 < 0 || nMaskPos2 >= MAXMASKNO)
//		{
//			ErrMsgDlg(STDGNALM435);
//			return FALSE;
//		}
		
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2))
			return FALSE;
		
		if (!IsValidAxisPosition(AXIS_C, dPosC) || !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;
		
		if (!IsValidAxisPosition(AXIS_A1, dPosA) || !IsValidAxisPosition(AXIS_A2, dPosA2))
			return FALSE;
		
		m_dDestinationPos[AXIS_Z1] = dPosZ1;
		m_dDestinationPos[AXIS_Z2] = dPosZ2;
		m_dDestinationPos[AXIS_A1] = dPosA;
		m_dDestinationPos[AXIS_A2] = dPosA2;
		
		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_M2] = 0.0;
		
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dCalibrationOffset[AXIS_C] = 0.0;
		
		m_dCalibrationOffset[AXIS_C2] = 0.0;
		dPosC2 += m_dCalibrationOffset[AXIS_C2];
		
		double dPosX = GetPosition(AXIS_X);
		double dPosY = GetPosition(AXIS_Y);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
		GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
		if(!bZCalUse)
		{
			m_dCalibrationOffset[AXIS_Z1] = m_dCalibrationOffset[AXIS_Z2] = 0;
		}
		
		return m_clsMotor->MoveZMCA2(dPosZ1 + m_dCalibrationOffset[AXIS_Z1], 
			dPosZ2 + m_dCalibrationOffset[AXIS_Z2],	dMaskPos, dMaskPos2, 
			dPosC, dPosC2, dPosA, dPosA2, bZCalUse, bTophat);
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MoveZ(dPosZ1);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MotorMoveAxis(AXIS_Z1, dPosZ1, TRUE);
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2,double dPosA, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	BOOL bRet  = FALSE;
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass))
			return FALSE;
		if ( !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass))
			return FALSE;
		if(!IsValidAxisPosition(AXIS_Z1, dPosZ1) )
			return FALSE;
		if( !IsValidAxisPosition(AXIS_Z2, dPosZ2))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_M, dPosM) )
			return FALSE;
		if( !IsValidAxisPosition(AXIS_M2, dPosM2) )
			return FALSE;
		if(!IsValidAxisPosition(AXIS_C, dPosC))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_C2, dPosC2))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_A1, dPosA))
			return FALSE;
		if( !IsValidAxisPosition(AXIS_A2, dPosA2))
			return FALSE;
		
		
		m_dDestinationPos[AXIS_X]		= dPosX;
		m_dDestinationPos[AXIS_Y]		= dPosY;
		m_dDestinationPos[AXIS_Z1]		= dPosZ1;
		m_dCalibrationOffset[AXIS_Z1]	= 0.0;
		m_dDestinationPos[AXIS_Z2]		= dPosZ2;
		m_dCalibrationOffset[AXIS_Z2]	= 0.0;
		m_dDestinationPos[AXIS_M]		= dPosM;
		m_dDestinationPos[AXIS_C]		= dPosC;	
		m_dCalibrationOffset[AXIS_M]	= 0.0;
		m_dCalibrationOffset[AXIS_C]	= 0.0;
		
		m_dDestinationPos[AXIS_M2]		= 0.0;
		m_dDestinationPos[AXIS_C2]		= dPosC2;	
		m_dCalibrationOffset[AXIS_M2]	= 0.0;
		m_dCalibrationOffset[AXIS_C2]	= 0.0;
		
		m_dDestinationPos[AXIS_A1]	= dPosA;
		m_dDestinationPos[AXIS_A2]	= dPosA2;	
		
		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZMC2A(dPosX + m_dCalibrationOffset[AXIS_X],
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,
				dPosC, dPosC2,
				dPosA, dPosA2,
				bTophat);
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
			return m_clsMotor->MotorMoveXYZMC2A(dPosX + m_dSlaveCalibrationOffset[AXIS_X],
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,
				dPosC, dPosC2,
				dPosA, dPosA2,
				bTophat);
		}
	}
	else if(m_nMotorType == MOTOR_PMAC)
	{
		return MotorMoveXYZ(dPosX, dPosY, dPosZ1, dPosZ1, b1stPanel);
	}
	else if(m_nMotorType == MOTOR_COMIZOA)
	{
		return MoveXY(dPosX, dPosY);
	}
	else if(m_nMotorType == MOTOR_UMAC_PROGRAM)
	{
		return MoveXYZ(dPosX, dPosY, dPosZ1, dPosZ1, b1stPanel);
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsAnyError()
{
	return FALSE;
}

BOOL DeviceMotor::ScannerPower(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_clsMotor)
	{
		return m_clsMotor->ScannerPower(bOn);
	}
#endif
	return TRUE;

}

BOOL DeviceMotor::SetAOMPowerON(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_clsMotor)
	{
		return m_clsMotor->SetAOMPowerON(bOn);
	}
#endif
	return TRUE;
}

BOOL DeviceMotor::SetError(BOOL bError)
{
	m_bAnyError = bError;
	return TRUE;
}

BOOL DeviceMotor::GetScannerStatus()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_clsMotor)
	{
		return m_clsMotor->GetScannerStatus();
	}
#endif
	return TRUE;
}

BOOL DeviceMotor::GetAOMStatus()
{
#ifdef __TEST__
	return TRUE;
#else 
	#ifdef __3RDAOD__
		return TRUE;
	#else
		if(m_clsMotor)
		{
			return m_clsMotor->GetAOMStatus();
		}	
	#endif
#endif
	return TRUE;
}

BOOL DeviceMotor::HoodOpen(BOOL bOpen)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_clsMotor)
	{
		return m_clsMotor->HoodOpen(bOpen);
	}
#endif
	return TRUE;
}

BOOL DeviceMotor::IsHoodOK(BOOL bOpen)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_clsMotor)
	{
		BOOL bRet = TRUE;
		int nCount = 0;
		while(TRUE)
		{
			Sleep(20);
			bRet =  m_clsMotor->IsHoodOK(bOpen);
			if(bRet)
				break;
			
			if(nCount > 50)
			{
				bRet = FALSE;
				break;
			}
			nCount++;
		}
		return bRet;
	}
#endif
	return TRUE;
}

BOOL DeviceMotor::IsHandlerPartError(BOOL bLoader)
{
#ifdef __TEST__
	return FALSE;
#endif
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsHandlerPartError(bLoader);
#else
		return m_clsMotor->IsHandlerPartError(bLoader);
#endif
	}
	return TRUE;
}

BOOL DeviceMotor::IsResetSwitch()
{
#ifdef __TEST__
	return FALSE;
#endif

	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet1 = FALSE, bRet2 = FALSE;
#ifndef __OSAN_LG__
		bRet1 = m_clsMotor->GetResetSWStatus();
#else
		bRet1 = m_clsMotor->IsResetSwitch();
#endif

#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet2 = m_clsMelsec->IsResetSwitch();
#endif
		return (bRet1 | bRet2);
	}
	return FALSE;
}

BOOL DeviceMotor::GetAOMAlarm()
{
#ifdef __TEST__
	return FALSE;
#else
	if(m_clsMotor)
	{
		return m_clsMotor->GetAOMAlarm();
	}
#endif
	return FALSE;
}

BOOL DeviceMotor::GetCurrentSuctionMotor()
{
#ifdef __TEST__
	return TRUE;
#endif

	if(m_clsMotor)
		return	m_clsMotor->GetCurrentSuctionMotor();
	return TRUE;
}

BOOL DeviceMotor::GetCurrentAcrylSuction(BOOL b1st)
{
#ifdef __TEST__
	if(gDProject.m_nSeparation == USE_DUAL)
		return TRUE;
	else if(gDProject.m_nSeparation == USE_1ST)
	{
		if(b1st)
			return TRUE;
		else
			return FALSE;
	}
	else if(gDProject.m_nSeparation == USE_2ND)
	{
		if(b1st)
			return FALSE;
		else 
			return TRUE;
	}
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->GetCurrentAcrylSuction(b1st);
	}
#endif
	return TRUE;
}

BOOL DeviceMotor::SetLimitYPos(double dPos)
{
#ifdef __TEST__
	return TRUE;
#endif
	if(m_clsMotor)
	{
#ifndef __OSAN_LG__
		return	m_clsMotor->SetLimitYPos(dPos);
#endif
	}
	return FALSE;
}

BOOL DeviceMotor::UnloaderCarrierAlignPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifndef __OSAN_LG__
		bRet = m_clsMotor->UnloaderCarrierAlignPos();
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::SetAlarmTolLed(BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
		bRet = m_clsMotor->SetAlarmTolLed(bOn);
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderCarrierCartPos()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;

#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->LoaderCarrierElvPos();
#else
	#ifndef __OSAN_LG__
		bRet = m_clsMotor->LoaderCarrierCartPos();
	#else
		bRet = m_clsMotor->LoaderCarrierAlignPos();
	#endif
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderCarrierCartPos2()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __OSAN_LG_2013__
		bRet = m_clsMotor->LoaderCarrierCartPos2();
#else
	#ifdef __ADD_MELSEC_MOTOR__
		bRet = m_clsMelsec->LoaderCarrierElvPos();
	#else
		bRet = m_clsMotor->LoaderCarrierAlignPos();
	#endif
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderNGBoxForward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;

#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->UnloaderNGBoxForward();
#else
		bRet = m_clsMotor->UnloaderNGBoxForward();
#endif
		return bRet;
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderNGBoxBackward()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;

#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->UnloaderNGBoxBackward();
#else
		bRet = m_clsMotor->UnloaderNGBoxBackward();
#endif
		return bRet;
	}

	return TRUE;
#endif
}


BOOL DeviceMotor::SetOutportTableVacuum(BOOL bUseBTable)
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __PUSAN1__
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->SetOutportTableVacuum(bUseBTable);
	}
#endif
#ifdef __PUSAN2__
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->SetOutportTableVacuum(bUseBTable);
	}
#endif

	return TRUE;
#endif
}

BOOL DeviceMotor::IsBMMotorHomeEnd()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		return m_clsMotor->IsBMMotorHomeEnd();
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::NoUseClamp(BOOL bNoUse)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifndef __OSAN_LG__
		return m_clsMotor->NoUseClamp(bNoUse);
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) ||  !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass) ||
			!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2) ||
			!IsValidAxisPosition(AXIS_M, dPosM) || !IsValidAxisPosition(AXIS_M2, dPosM2) || 
			!IsValidAxisPosition(AXIS_M3, dPosM3) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			 !IsValidAxisPosition(AXIS_C2, dPosC2))
			 return FALSE;

		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
#ifdef __SERVO_MOTOR__
			return m_clsMotor->MotorMoveXYZMC3(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2], 
				dPosM, dPosM2, dPosM3, dPosC, dPosC2, bTophat);
#else
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
#ifdef __SERVO_MOTOR__
			return m_clsMotor->MotorMoveXYZMC3(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dSlaveCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2], 
				dPosM, dPosM2, dPosM3, dPosC, dPosC2, bTophat);
#else
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dSlaveCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
		}

#ifdef __SERVO_MOTOR__
		return m_clsMotor->MotorMoveXYZMC3(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosC, dPosC2, bTophat);
#else
		return m_clsMotor->MotorMoveXYZMC2(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_X, dPosX, nMoveMode, bPass) ||  !IsValidAxisPosition(AXIS_Y, dPosY, nMoveMode, bPass) ||
			!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2) ||
			!IsValidAxisPosition(AXIS_M, dPosM) || !IsValidAxisPosition(AXIS_M2, dPosM2) || 
			!IsValidAxisPosition(AXIS_M3, dPosM3) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			 !IsValidAxisPosition(AXIS_C2, dPosC2) || !IsValidAxisPosition(AXIS_A1, dPosA1) || !IsValidAxisPosition(AXIS_A2, dPosA2) )
			 return FALSE;

		if(b1stPanel)
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
#ifdef __SERVO_MOTOR__
			return m_clsMotor->MotorMoveXYZMCA3(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2], 
				dPosM, dPosM2, dPosM3, dPosC, dPosC2, dPosA1, dPosA2, bTophat);
#else
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
		}
		else
		{
			GetAxisMoveOffset(dPosX, dPosY, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z1], TRUE);
			GetZMoveOffset(dPosX, dPosY, m_dCalibrationOffset[AXIS_Z2], FALSE);
#ifdef __SERVO_MOTOR__
			return m_clsMotor->MotorMoveXYZMC3(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dSlaveCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2], 
				dPosM, dPosM2, dPosM3, dPosC, dPosC2, bTophat);
#else
			return m_clsMotor->MotorMoveXYZMC2(dPosX + m_dCalibrationOffset[AXIS_X], 
				dPosY + m_dSlaveCalibrationOffset[AXIS_Y],
				dPosZ1 + m_dSlaveCalibrationOffset[AXIS_Z1],
				dPosZ2 + m_dCalibrationOffset[AXIS_Z2],
				dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
		}

#ifdef __SERVO_MOTOR__
		return m_clsMotor->MotorMoveXYZMC3(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosC, dPosC2, bTophat);
#else
		return m_clsMotor->MotorMoveXYZMC2(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2,  dPosC, dPosC2, bTophat);
#endif
	}
	
	return TRUE;
#endif
}
BOOL DeviceMotor::MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2) ||
			!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_M2, dMaskPos2) || 
			!IsValidAxisPosition(AXIS_M3, dMaskPos3) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			 !IsValidAxisPosition(AXIS_C2, dPosC2) )
			 return FALSE;

#ifdef __SERVO_MOTOR__
		return m_clsMotor->MoveZMC3(dPosZ1, dPosZ2,  dMaskPos, dMaskPos2, dMaskPos3, dPosC, dPosC2, bZCalUse, bTophat);
#else
		return m_clsMotor->MoveZMCA2(dPosZ1, dPosZ2,  dMaskPos, dMaskPos2, dPosC, dPosC2, 0, 0, bZCalUse, bTophat);
#endif
	}
	
	return TRUE;
#endif
}
BOOL DeviceMotor::MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		if (!IsValidAxisPosition(AXIS_Z1, dPosZ1) || !IsValidAxisPosition(AXIS_Z2, dPosZ2) ||
			!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_M2, dMaskPos2) || 
			!IsValidAxisPosition(AXIS_M3, dMaskPos3) || !IsValidAxisPosition(AXIS_C, dPosC) ||
			 !IsValidAxisPosition(AXIS_C2, dPosC2) || !IsValidAxisPosition(AXIS_A1, dPosA1) || !IsValidAxisPosition(AXIS_A2, dPosA2) )
			 return FALSE;

#ifdef __SERVO_MOTOR__
		return m_clsMotor->MoveZMCA3(dPosZ1, dPosZ2,  dMaskPos, dMaskPos2, dMaskPos3, dPosC, dPosC2, dPosA1, dPosA2, bZCalUse, bTophat);
#else
		return m_clsMotor->MoveZMCA2(dPosZ1, dPosZ2,  dMaskPos, dMaskPos2, dPosC, dPosC2, 0, 0, bZCalUse, bTophat);
#endif
	}

	return TRUE;
#endif
}
BOOL DeviceMotor::MoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		
		if (!IsValidAxisPosition(AXIS_C, dPosC) || !IsValidAxisPosition(AXIS_C2, dPosC2) ||
			!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_M2, dMaskPos2) || 
			!IsValidAxisPosition(AXIS_M3, dMaskPos3))
			return FALSE;
		
		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_M2] = m_dCalibrationOffset[AXIS_M3] = 0.0;
		m_dCalibrationOffset[AXIS_C] = m_dCalibrationOffset[AXIS_C2] = 0.0;
		
		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dDestinationPos[AXIS_M] = dMaskPos;
		m_dDestinationPos[AXIS_M2] = dMaskPos2;
		m_dDestinationPos[AXIS_M3] = dMaskPos3;
#ifdef __SERVO_MOTOR__
		return m_clsMotor->MotorMoveMC3DownOnly(dMaskPos, dMaskPos2, dMaskPos3, dPosC, dPosC2);
#else
		return m_clsMotor->MotorMoveMC2DownOnly(dMaskPos, dMaskPos2, dPosC, dPosC2);
#endif
	}
	
	return TRUE;
#endif
}
BOOL DeviceMotor::MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{

		if (!IsValidAxisPosition(AXIS_C, dPosC) || !IsValidAxisPosition(AXIS_C2, dPosC2) ||
			!IsValidAxisPosition(AXIS_A1, dPosA) || !IsValidAxisPosition(AXIS_A2, dPosA2) ||
			!IsValidAxisPosition(AXIS_M, dMaskPos) || !IsValidAxisPosition(AXIS_M2, dMaskPos2) || 
			!IsValidAxisPosition(AXIS_M3, dMaskPos3))
			return FALSE;

		m_dCalibrationOffset[AXIS_M] = m_dCalibrationOffset[AXIS_M2] = m_dCalibrationOffset[AXIS_M3] = 0.0;
		m_dCalibrationOffset[AXIS_C] = m_dCalibrationOffset[AXIS_C2] = 0.0;
		m_dCalibrationOffset[AXIS_A1] = m_dCalibrationOffset[AXIS_A2] = 0.0;

		m_dDestinationPos[AXIS_C] = dPosC;
		m_dDestinationPos[AXIS_C2] = dPosC2;
		m_dDestinationPos[AXIS_A1] = dPosA;
		m_dDestinationPos[AXIS_A2] = dPosA2;
		m_dDestinationPos[AXIS_M] = dMaskPos;
		m_dDestinationPos[AXIS_M2] = dMaskPos2;
		m_dDestinationPos[AXIS_M3] = dMaskPos3;
#ifdef __SERVO_MOTOR__
		return m_clsMotor->MotorMoveMCA3DownOnly(dMaskPos, dMaskPos2, dMaskPos3, dPosC, dPosC2, dPosA, dPosA2);
#else
		return m_clsMotor->MotorMoveMC2DownOnly(dMaskPos, dMaskPos2, dPosC, dPosC2);
#endif
	}

	return TRUE;
#endif
}

BOOL DeviceMotor::Disconnect()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __SERVO_MOTOR__
		return m_clsMotor->Disconnect();
#else
		return TRUE;
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::Connect(int nPortNo, long lBaudrate)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __SERVO_MOTOR__
		return m_clsMotor->Connect(nPortNo, lBaudrate);
#else
		return TRUE;
#endif
	}
#endif	
	return TRUE;
}
BOOL DeviceMotor::IsOrigin(int nAxis)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __SERVO_MOTOR__
	#ifndef __OSAN_LG__
		return m_clsMotor->IsOrigin(nAxis);
	#endif
#else
		return TRUE;
#endif
	}
#endif	
	return TRUE;
}



BOOL DeviceMotor::IsHandlerDoorBypass(BOOL bLoader)
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
		BOOL bRet = TRUE;
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			bRet = m_clsMelsec->IsSystemDoorBypass(bLoader);
#endif
		return bRet;
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::LoaderPicker3Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->LoaderPickerUpPos(3);
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::UnloaderPicker3Init()
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->UnloaderPickerUpPos(3);
#else
		//		return m_clsMotor->UnloaderPicker3Init();
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::UseRoll(BOOL bUse)
{
#ifdef __TEST__
	return TRUE;
#endif
	
#ifdef __ADD_MELSEC_MOTOR__
	if(m_clsMelsec)
		return m_clsMelsec->UseRoll(bUse);
#endif
	return TRUE;
}

BOOL DeviceMotor::UsePaper(BOOL bUse)
{
#ifdef __TEST__
	return TRUE;
#endif
	
#ifdef __ADD_MELSEC_MOTOR__
	if(m_clsMelsec)
		return m_clsMelsec->UsePaper(bUse);
#endif
	return TRUE;
}

BOOL DeviceMotor::IsHandlerTablePCBExist(BOOL bLoader)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsHandlerTablePCBExist(bLoader);
#else
		return TRUE;
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::IsHandlerPaperTransPCBExist(BOOL bLoader)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->IsHandlerPaperTransPCBExist(bLoader);
#else
		return TRUE;
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __ADD_MELSEC_MOTOR__
		if(m_clsMelsec)
			return m_clsMelsec->SetPickerVacuum(bLoader, b1st, bOn);
#else
		return TRUE;
#endif
	}
	
	return TRUE;
#endif
}

BOOL DeviceMotor::CheckMelsecConnect()
{
#ifdef __TEST__
	m_bOldMelsecConnect = !m_bOldMelsecConnect;
	return m_bOldMelsecConnect;
#else
#ifdef __ADD_MELSEC_MOTOR__
	if(m_clsMelsec)
		return m_clsMelsec->CheckMelsecConnect();
#endif
	return TRUE;
#endif
}


BOOL DeviceMotor::GetAOMTime()
{
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
#ifdef __OSAN_LG__
		return m_clsMotor->GetAOMTime();
#else
		return TRUE;
#endif
	}
#endif
	return TRUE;
}

int DeviceMotor::ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel)
{
	return FALSE;
#ifndef __TEST__
	if(m_nMotorType == MOTOR_UMAC)
	{
	#ifdef __PUSAN2__
		if(b1stPanel)
		{
			GetAxisMoveOffset(dXPos, dYPos, m_dCalibrationOffset[AXIS_X], m_dCalibrationOffset[AXIS_Y], FIRST_PANEL_OFFSET);
			return m_clsMotor->ChangeMotorPosition(dXPos + m_dCalibrationOffset[AXIS_X], dYPos + m_dCalibrationOffset[AXIS_Y]);
		}
		else
		{
			GetAxisMoveOffset(dXPos, dYPos, m_dSlaveCalibrationOffset[AXIS_X], m_dSlaveCalibrationOffset[AXIS_Y], SECOND_PANEL_OFFSET);
			return m_clsMotor->ChangeMotorPosition(dXPos + m_dSlaveCalibrationOffset[AXIS_X], dYPos + m_dSlaveCalibrationOffset[AXIS_Y]);
		}
			
	#else
			return FALSE;
	#endif
	}
#endif
	return FALSE;
}
int DeviceMotor::GetInpositionError()
{
	return m_nInpositionError;
}
BOOL DeviceMotor::UiAlivePulse(BOOL bOn)
{

#ifdef __TEST__
	return TRUE;
#else
	if(m_nMotorType == MOTOR_COMIZOA)
		return TRUE;
	else
	{
#ifdef __CUNGJU_JASMINE_NEW__
		return m_clsMotor->UiAlivePulse(bOn);
#else
		return TRUE;
#endif
	}
#endif
}

int DeviceMotor::GetWaterFlow1Value()
{

#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_COMIZOA)
		return 0;
	else
	{
#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->GetWaterFlow1Value();
#endif

#ifdef __OSAN_LG_2013__
		return m_clsMotor->GetWaterFlow1Value();
#endif
		return 0;

	}
#endif
}

void DeviceMotor::ReadAllError(int* pnVal)
{
#ifdef __TEST__
	return;
#else
	if(m_nMotorType == MOTOR_COMIZOA)
		return;
	else
	{
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_clsMotor->ReadAllError(pnVal);
#endif

#ifdef __OSAN_LG_2013__
		m_clsMotor->ReadAllError(pnVal);
#endif
		return;

	}
#endif
}

int DeviceMotor::GetWaterFlow2Value()
{

#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_COMIZOA)
		return 0;
	else
	{
#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->GetWaterFlow1Value();
#endif

#ifdef __OSAN_LG_2013__
		return m_clsMotor->GetWaterFlow2Value();
#else
		return 0;
#endif
	}
#endif
}
void DeviceMotor::ConnectAnyDevice(int nType)
{
	if(nType == -1)
	{
		if(gSystemINI.m_sHardWare.bChillerConnect && !gSystemINI.m_sHardWare.bLinkRS485)
		{
			m_Chiller->SetParameter(gSystemINI.m_sSystemDevice.sChillerPort.nPortNo,
								gSystemINI.m_sSystemDevice.sChillerPort.nBaudRate, 
								gSystemINI.m_sSystemDevice.sChillerPort.nParity, 
								gSystemINI.m_sSystemDevice.sChillerPort.nDataBits, 
								gSystemINI.m_sSystemDevice.sChillerPort.nStopBits,
								gSystemINI.m_sSystemDevice.sChillerPort.nFlowControl);

			if (!m_Chiller->PortOpened())
			{
				if(!m_Chiller->Create())
				{
					ErrMessage(_T("Chiller Connect Failure"));
				}
			}
		}
		if(gSystemINI.m_sHardWare.bHumidityConnect && !gSystemINI.m_sHardWare.bLinkRS485)
		{
			m_Humidity->SetParameter(gSystemINI.m_sSystemDevice.sHumidityPort.nPortNo,
								gSystemINI.m_sSystemDevice.sHumidityPort.nBaudRate, 
								gSystemINI.m_sSystemDevice.sHumidityPort.nParity, 
								gSystemINI.m_sSystemDevice.sHumidityPort.nDataBits,
								gSystemINI.m_sSystemDevice.sHumidityPort.nStopBits, 
								gSystemINI.m_sSystemDevice.sHumidityPort.nFlowControl);

			if (!m_Humidity->PortOpened())
			{
				if(!m_Humidity->Create())
				{
					ErrMessage(_T("Thermo-Hyprometer Connect Failure"));
				}
			}
		}
		if(gSystemINI.m_sHardWare.bTemperCompConnect)
		{
			m_TemperatureMeasure->SetParameter(gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nPortNo,
				gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nBaudRate, 
				gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nParity, 
				gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nDataBits,
				gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nStopBits, 
				gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nFlowControl);

			m_TemperatureMeasure->SetChannelIndex(gProcessINI.m_sProcessOption.nTCMasterCH1, gProcessINI.m_sProcessOption.nTCMasterCH2,
																		gProcessINI.m_sProcessOption.nSBMasterCH1, gProcessINI.m_sProcessOption.nSBMasterCH2,
																		gProcessINI.m_sProcessOption.nTCSlaveCH1, gProcessINI.m_sProcessOption.nTCSlaveCH2,
																		gProcessINI.m_sProcessOption.nSBSlaveCH1, gProcessINI.m_sProcessOption.nSBSlaveCH2);

			m_TemperatureMeasure->SetTemperLimit(gProcessINI.m_sProcessOption.dTemperDifferTLimit, 
																			gProcessINI.m_sProcessOption.dTemperMinTLimit, 
																			gProcessINI.m_sProcessOption.dTemperMaxTLimit,
																			gProcessINI.m_sProcessOption.dTemperDetaTLimit);

			if (!m_TemperatureMeasure->PortOpened())
			{
				if(!m_TemperatureMeasure->Create())
				{
					ErrMessage(_T("Temperature Compensation Measure Connect Failure"));
				}
			}
		}
		if(gSystemINI.m_sHardWare.bVoltageConnect)
		{
			m_Voltage->Connect();

			int nSubCount = 0;
			if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bHumidityConnect)
				nSubCount += 2;

			if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bChillerConnect)
				nSubCount +=4;

			m_Voltage->SetSubCount(nSubCount);
		}
	}
	else if(nType == PORT_CHILLER )
	{
		if(!gSystemINI.m_sHardWare.bChillerConnect)
			return;

		if(gSystemINI.m_sHardWare.bVoltageConnect && gSystemINI.m_sHardWare.bLinkRS485 )
		{
			if(m_Voltage->IsConnected())
			{
				int nSubCount = 0;
				if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bHumidityConnect)
					nSubCount += 2;

				if(gSystemINI.m_sHardWare.bLinkRS485)
					nSubCount +=4;

				m_Voltage->SetSubCount(nSubCount);
			}
			else
			{
				m_Voltage->Connect();

				int nSubCount = 0;
				if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bHumidityConnect)
					nSubCount += 2;

				if(gSystemINI.m_sHardWare.bLinkRS485)
					nSubCount +=4;

				m_Voltage->SetSubCount(nSubCount);
			}
		}
		else
		{
			m_Chiller->SetParameter(gSystemINI.m_sSystemDevice.sChillerPort.nPortNo,
				gSystemINI.m_sSystemDevice.sChillerPort.nBaudRate, 
				gSystemINI.m_sSystemDevice.sChillerPort.nParity, 
				gSystemINI.m_sSystemDevice.sChillerPort.nDataBits, 
				gSystemINI.m_sSystemDevice.sChillerPort.nStopBits,
				gSystemINI.m_sSystemDevice.sChillerPort.nFlowControl);

			if (!m_Chiller->PortOpened())
			{
				if(!m_Chiller->Create())
				{
					ErrMessage(_T("Chiller Connect Failure"));
				}
			}
		}
	}
	else if(nType == PORT_HUMIDITY )
	{
		if(!gSystemINI.m_sHardWare.bHumidityConnect)
			return; 

		if(gSystemINI.m_sHardWare.bLinkRS485)
			return;

		m_Humidity->SetParameter(gSystemINI.m_sSystemDevice.sHumidityPort.nPortNo,
			gSystemINI.m_sSystemDevice.sHumidityPort.nBaudRate, 
			gSystemINI.m_sSystemDevice.sHumidityPort.nParity, 
			gSystemINI.m_sSystemDevice.sHumidityPort.nDataBits,
			gSystemINI.m_sSystemDevice.sHumidityPort.nStopBits, 
			gSystemINI.m_sSystemDevice.sHumidityPort.nFlowControl);

		if (!m_Humidity->PortOpened())
		{
			if(!m_Humidity->Create())
			{
				ErrMessage(_T("Thermo-Hyprometer Connect Failure"));
			}
		}
	}
	else if(nType == PORT_TEMPER_COMP )
	{
		if(!gSystemINI.m_sHardWare.bTemperCompConnect)
			return; 

		m_TemperatureMeasure->SetParameter(gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nPortNo,
			gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nBaudRate, 
			gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nParity, 
			gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nDataBits,
			gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nStopBits, 
			gSystemINI.m_sSystemDevice.sTemperatureCompenPort.nFlowControl);

		m_TemperatureMeasure->SetChannelIndex(gProcessINI.m_sProcessOption.nTCMasterCH1, gProcessINI.m_sProcessOption.nTCMasterCH2,
																		gProcessINI.m_sProcessOption.nSBMasterCH1, gProcessINI.m_sProcessOption.nSBMasterCH2,
																		gProcessINI.m_sProcessOption.nTCSlaveCH1, gProcessINI.m_sProcessOption.nTCSlaveCH2,
																		gProcessINI.m_sProcessOption.nSBSlaveCH1, gProcessINI.m_sProcessOption.nSBSlaveCH2);

		m_TemperatureMeasure->SetTemperLimit(gProcessINI.m_sProcessOption.dTemperDifferTLimit, 
																		gProcessINI.m_sProcessOption.dTemperMinTLimit, 
																		gProcessINI.m_sProcessOption.dTemperMaxTLimit,
																		gProcessINI.m_sProcessOption.dTemperDetaTLimit);

		if (!m_TemperatureMeasure->PortOpened())
		{
			if(!m_TemperatureMeasure->Create())
			{
				ErrMessage(_T("Temperature Compensation Measure Connect Failure"));
			}
		}
	}
	else if(nType == PORT_VOLTAGE)
	{
		if(!gSystemINI.m_sHardWare.bVoltageConnect)
			return; 

		m_Voltage->Connect();
		int nSubCount = 0;

		if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bHumidityConnect)
			nSubCount += 2;

		if(gSystemINI.m_sHardWare.bLinkRS485 && gSystemINI.m_sHardWare.bChillerConnect)
			nSubCount +=4;
		
			m_Voltage->SetSubCount(nSubCount);

	}

}

void DeviceMotor::SetTemeratureLimits()
{
	if(!gSystemINI.m_sHardWare.bTemperCompConnect)
			return; 
	m_TemperatureMeasure->SetTemperLimit(gProcessINI.m_sProcessOption.dTemperDifferTLimit, 
																gProcessINI.m_sProcessOption.dTemperMinTLimit, 
																gProcessINI.m_sProcessOption.dTemperMaxTLimit,
																gProcessINI.m_sProcessOption.dTemperDetaTLimit);
}

void DeviceMotor::DisconnectAnyDevice(int nType)
{
	if((!gSystemINI.m_sHardWare.bChillerConnect && nType == PORT_CHILLER) || 
		(!gSystemINI.m_sHardWare.bHumidityConnect && nType == PORT_HUMIDITY) ||
		(!gSystemINI.m_sHardWare.bTemperCompConnect && nType == PORT_TEMPER_COMP) )
		return;

	if(nType == PORT_CHILLER )
	{
		if (m_Chiller->PortOpened())
			m_Chiller->Destroy();
	}
	else if(nType == PORT_HUMIDITY )
	{
		if (m_Humidity->PortOpened())
			m_Humidity->Destroy();
	}
	else if(nType == PORT_TEMPER_COMP )
	{
		if (m_TemperatureMeasure->PortOpened())
			m_TemperatureMeasure->Destroy();
	}
}
double DeviceMotor::GetChillerTemp()
{
	if(!gSystemINI.m_sHardWare.bChillerConnect)
		return -1;

	if(!m_Chiller->IsConnect())
		return -1;

	return m_Chiller->GetChillerTemp();
}

void DeviceMotor::GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint)
{
	if(!gSystemINI.m_sHardWare.bHumidityConnect)
	{
		dHumidity = -1; 
		dTemperature = -1;
		dDewPoint = -1;
		return;
	}

	if(!m_Humidity->IsConnect())
		return;

	m_Humidity->GetHumiTempDew(dHumidity, dTemperature, dDewPoint);
}
void DeviceMotor::ReadTemperatureComp()
{
	if(!gSystemINI.m_sHardWare.bTemperCompConnect)
		return;
	m_TemperatureMeasure->ReadTemperature();
}

int DeviceMotor::GetMainAirValue()
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->GetMainAirValue();
#endif
#ifdef __OSAN_LG__
	return m_clsMotor->GetMainAirValue();
#endif
	return -1;
}

void	DeviceMotor::GetTCTemperature (double& d1stTemper, double& d2ndTemper)
{
	if(!gSystemINI.m_sHardWare.bTemperCompConnect)
	{
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
			d1stTemper = d2ndTemper = 20;
		else
			d1stTemper = d2ndTemper = -1;
		return;
	}

	d1stTemper = m_TemperatureMeasure->GetTemperature(gProcessINI.m_sProcessOption.nTCMasterCH1);
	d2ndTemper = m_TemperatureMeasure->GetTemperature(gProcessINI.m_sProcessOption.nTCSlaveCH1);
}

void	DeviceMotor::GetSBTemperature (double& d1stTemper, double& d2ndTemper)
{
	if(!gSystemINI.m_sHardWare.bTemperCompConnect)
	{
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
			d1stTemper = d2ndTemper = 20;
		else
			d1stTemper = d2ndTemper = -1;
		return;
	}
	d1stTemper = m_TemperatureMeasure->GetTemperature(gProcessINI.m_sProcessOption.nSBMasterCH1);
	d2ndTemper = m_TemperatureMeasure->GetTemperature(gProcessINI.m_sProcessOption.nSBSlaveCH1);
}

void	DeviceMotor::GetTemperatureForAllCh (double* dTemper)
{
	if(gSystemINI.m_sHardWare.bTemperCompConnect)
		m_TemperatureMeasure->GetTemperature(dTemper);
	else
	{
		for(int i = 0; i < 10; i++)
		{
			if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
				dTemper[i] = 20;
			else
				dTemper[i] = -1;
		}
	}
}

void DeviceMotor::GetVoltage(double& dV, double& dA,double& dKw)
{
	if(gSystemINI.m_sHardWare.bVoltageConnect)
		m_Voltage->GetVoltage(dV, dA, dKw);
}
double DeviceMotor::GetVolateSubData(int nIndex)
{
	if(gSystemINI.m_sHardWare.bVoltageConnect)
		return m_Voltage->GetSubData(nIndex);
	else
		return -1;
}


BOOL DeviceMotor::GetReverseDirection()
{
#ifdef __TEST__
	return m_bReverse;
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->GetReverseDirection();
#endif
	return TRUE;
}
BOOL DeviceMotor::GetLoadBasketSignal(BOOL bIn)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->GetLoadBasketSignal(bIn);
#endif
	return FALSE;
}
BOOL DeviceMotor::GetUnloadBasketSignal(BOOL bIn)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->GetUnloadBasketSignal(bIn);
#endif
	return FALSE;
}
BOOL DeviceMotor::SetReverseDirection(BOOL bChange)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	BOOL bResult = TRUE;
	m_bReverse = bChange;
	if(m_clsMelsec != NULL)
		bResult =  m_clsMelsec->SetReverseDirection(bChange);

	if(m_clsMotor != NULL)
		bResult &= m_clsMotor->SetReverseDirection(bChange);

	return bResult;
#endif
	return TRUE;
}
BOOL DeviceMotor::SetTrunPanel(BOOL bTurn)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->SetTrunPanel(bTurn);
#endif
	return TRUE;
}
BOOL DeviceMotor::SetUsePaperBox(BOOL bUse)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->SetUsePaperBox(bUse);
#endif
	return TRUE;
}
BOOL DeviceMotor::SetUseNGBox(BOOL bUse)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->SetUseNGBox(bUse);
#endif
	return TRUE;
}
BOOL DeviceMotor::SetOutputBasket(BOOL bLoad)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->SetOutputBasket(bLoad);
#endif
	return TRUE;
}
BOOL DeviceMotor::ResetBasketInfo(BOOL bLoad)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec != NULL)
		return m_clsMelsec->ResetBasketInfo(bLoad);
#endif
	return TRUE;
}

int DeviceMotor::GetDustSuctionValue()
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->GetDustSuctionValue();
#else 
	return -1;
#endif
}
int DeviceMotor::GetTableVauumValue(BOOL b1st)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->GetTableVauumValue(b1st);
#else 
	return -1;
#endif
}
BOOL DeviceMotor::SetNGPanel(int nNG)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMelsec)
		return m_clsMelsec->SetNGPanel(nNG);
	return TRUE;
#else 
	return FALSE;
#endif
}
BOOL DeviceMotor::GetChillerRun()
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->GetChillerRun();
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::SetWaterFlow1Value(double dVal)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->SetWaterFlow1Value(dVal);
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::SetWaterFlow2Value(double dVal)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->SetWaterFlow2Value(dVal);
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::SetMainAirValue(double dVal)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->SetMainAirValue(dVal);
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::SetDustSuctionValue(double dVal)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->SetDustSuctionValue(dVal);
#else
	return TRUE;
#endif
}
BOOL DeviceMotor::SetTableVauumValue(BOOL b1st, double dVal)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	return m_clsMotor->SetTableVauumValue(b1st, dVal);
#else
	return TRUE;
#endif
}

BOOL DeviceMotor::IsLaserSystemWarning()
{
#ifdef __TEST__
	return 0;
#else
	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLaserSystemWarning();

	return 0;
#endif
}

BOOL DeviceMotor::IsLaserOverTempFault()
{
#ifdef __TEST__
	return 0;
#else

	if(m_nMotorType == MOTOR_UMAC)
		return m_clsMotor->IsLaserOverTempFault();
	
	return 0;
#endif
}
void DeviceMotor::ReadAddressTemperatureComp()
{
	m_TemperatureMeasure->ReadAddress();
}
BOOL DeviceMotor::IsStartMode()
{
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(m_clsMelsec)
			return m_clsMelsec->IsStartMode();
	#else
		return TRUE;
	#endif
#endif
	return TRUE;
}
BOOL DeviceMotor::SetLoadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->SetLoadPickerDownOK(b1st, b2nd);
	#else
		return TRUE;
	#endif
#endif
}
BYTE DeviceMotor::GetLoadPickerDownOK()
{
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->GetLoadPickerDownOK();
	#else
		return TRUE;
	#endif
#endif
}
BOOL DeviceMotor::SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->SetUnloadPickerDownOK(b1st, b2nd);
	#else
		return TRUE;
	#endif
#endif
}
BYTE DeviceMotor::GetUnloadPickerDownOK()
{
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->GetUnloadPickerDownOK();
	#else
		return TRUE;
	#endif
#endif
}

BOOL DeviceMotor::SetTablePCBExist(BOOL b1st, BOOL b2nd)
{
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->SetTablePCBExist(b1st, b2nd);
	#else
		return TRUE;
	#endif
#endif
}
BOOL DeviceMotor::GetReverseReady()
{
	#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		return m_clsMotor->GetReverseReady();
	#else
		return TRUE;
	#endif
#endif
}
BYTE DeviceMotor::GetBasketIn()
{
#ifdef __TEST__
	return 0x00;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(m_clsMelsec)
			return m_clsMelsec->GetBasketIn();
	#else
		return 0x00;
	#endif
		return 0x00;
#endif
}
BOOL DeviceMotor::Set2DBarcodeTrigger()
{
#ifdef __TEST__
	return 0x03;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(m_clsMelsec)
			return m_clsMelsec->Set2DBarcodeTrigger();
	#else
		return 0x03;
	#endif
#endif
		return 0x03;
}
BOOL DeviceMotor::SetNoUseSuction(BOOL bNoUse)
{
#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(m_clsMelsec)
			return m_clsMelsec->SetNoUseSuction(bNoUse);
	#else
		return TRUE;
	#endif
#endif
		return TRUE;
}
BOOL DeviceMotor::SetNoUseLoadUnload(BOOL bNoUse)
{
	#ifdef __TEST__
	return TRUE;
#else
	#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_clsMotor)
		return m_clsMotor->SetNoUseLoadUnload(bNoUse);
	#else
		return TRUE;
	#endif
		return TRUE;
#endif
}
BOOL DeviceMotor::GetLPCStatus()
{
#ifdef __TEST__
	return TRUE;
#else
	return m_clsMotor->GetLPCStatus();
#endif
}

#ifdef __KUNSAN_SAMSUNG_LARGE__

PLC_BIT_SIGNAL_FX DeviceMotor::GetMelsecIOStuct()
{
	PLC_BIT_SIGNAL_FX pTemp;
	memset(&pTemp, 0 , sizeof(pTemp));
	#ifdef __TEST__
		return pTemp;
	#else
		if(m_clsMelsec)
			return m_clsMelsec->GetMelsecIOStuct();
	#endif
		return pTemp;
}

#else
PLC_BIT_SIGNAL DeviceMotor::GetMelsecIOStuct()
{
	PLC_BIT_SIGNAL pTemp;
	memset(&pTemp, 0 , sizeof(pTemp));
	#ifdef __TEST__
		return pTemp;
	#else
		if(m_clsMelsec)
			return m_clsMelsec->GetMelsecIOStuct();
	#endif
		return pTemp;
}
#endif

void DeviceMotor::SetDustCollectorErrorUse(BOOL bUse)
{
#ifdef __TEST__
	return;
#else
	m_clsMotor->SetDustCollectorErrorUse(bUse);
	return;
#endif
}