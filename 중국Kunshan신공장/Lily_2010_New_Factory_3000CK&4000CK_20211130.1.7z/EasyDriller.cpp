// EasyDriller.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "EasyDrillerDlg.h"
#include "InterfaceErrListModule.h"
#include "ui\DlgAlarm.h"
#include "ui\DlgAlarmMessage.h"
//#include "model\DirFile.h"
#include "model\DEasyDrillerINI.h"
#include "model\EasyDrillerINIFile.h"
#include "model\DProcessINI.h"
#include "model\ProcessINIFile.h"
#include "model\DSystemINI.h"
#include "model\SystemINIFile.h"
#include "model\PenFile.h"
#include "model\GlobalVariable.h"
#include "model\ScannerCompensation.h"
#include "alarmmsg.h"
#include "ui\paneautorun.h"
#include "model\DBeampathINI.h"
#include "model\BeamPathINIFile.h"
#include "model\DTempINI.h"
#include "model\TempINIFile.h"
#include "model\DTextData.h"
#include "MODEL\ShotTableINIFile.h"
#include "MODEL\DShotTableINI.h"
#include "MODEL\AutoManualScaleINIFile.h"
#include "MODEL\DAutoManualScaleINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef USE_VISION_PRO
	VProData		gVPro;
	VProData		gVPro_Temp[CAM_TOT_COUNT];
	ProcessData		gProcess;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEasyDrillerApp

BEGIN_MESSAGE_MAP(CEasyDrillerApp, CWinApp)
	//{{AFX_MSG_MAP(CEasyDrillerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEasyDrillerApp construction

CEasyDrillerApp::CEasyDrillerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_strWorkDir		= _T("D:\\ViaHole\\");
	gVariable.m_bStartEasyDrillerDlg = FALSE;
	m_hInstanceLanguage = NULL;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CEasyDrillerApp object

CEasyDrillerApp theApp;
CEasyDrillerDlg* theDlg;
/////////////////////////////////////////////////////////////////////////////
// CEasyDrillerApp initialization

BOOL CEasyDrillerApp::InitInstance()
{
	::CreateMutex( NULL, TRUE, m_pszExeName ) ;
	if ( GetLastError() == ERROR_ALREADY_EXISTS ) 
	{
		CWnd *pPrevWnd = CWnd::GetDesktopWindow()->GetWindow(GW_CHILD) ;
		while( pPrevWnd )
		{
			if ( ::GetProp( pPrevWnd -> GetSafeHwnd(), m_pszExeName ) ) 
			{
				if ( pPrevWnd -> IsIconic() )
					pPrevWnd->ShowWindow( SW_RESTORE ) ;
				pPrevWnd->SetForegroundWindow() ;
				pPrevWnd -> GetLastActivePopup() -> SetForegroundWindow() ;

				ErrMessage(IDS_RUN);

				return FALSE ;
			}

			pPrevWnd = pPrevWnd -> GetWindow( GW_HWNDNEXT ) ;
		}

		ErrMessage(IDS_RUN);

		return FALSE ;
	}

	AfxEnableControlContainer();
	
	SetRegistryKey(_T("DrillerLily"));
	// Check Working Directory
	CheckWorkDir();

	// Check Directory INI File
	CEasyDrillerINIFile clsINI;
	CString strFilePath;

	strFilePath.Format(_T("%sEasy.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	if( FALSE == clsINI.OpenINIFile( strFilePath, gEasyDrillerINI ) )
	{
//		clsINI.SaveINIFile( strFilePath, gEasyDrillerINI );
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("Easy.ini"));
		ErrMessage(strMsg);
		return FALSE;
	}

	gEasyDrillerINI.m_clsDirPath.CheckDirectory();

	// Read Process INI File
	CProcessINIFile clsProcessINI;
	
	strFilePath.Format(_T("%sProcess.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	if( FALSE == clsProcessINI.OpenProcessINIFile( strFilePath, gProcessINI ) )
	{
//		clsProcessINI.SaveProcessINIFile( strFilePath, gProcessINI );
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("Process.ini"));
		ErrMessage(strMsg);
		return FALSE;
	}
	
	gVariable.SetPath();
	if(!gVariable.LoadGlobalTool())
	{
		CString strString, strTemp, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strTemp.Format(_T("%sGlobalTool.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
		strMsg.Format(strString, strTemp);
		ErrMessage(strMsg);
//		return FALSE;
	}
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(!gVariable.LoadRefuseList())
		{
			CString strString, strTemp, strMsg;
			strString.LoadString(IDS_ERR_FILE_OPEN);
			strTemp.Format(_T("%sRefuseList.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
			strMsg.Format(strString, strTemp);
			ErrMessage(strMsg);
		}
	}

	// Read Pen File
//	int nLen = strlen( gProcessINI.m_sProcessLaserScanner.szPenName );

//	if( 0 != nLen )
//	{
//		CPenFile clsPenFile;

//		clsPenFile.OpenPenFile( gProcessINI.m_sProcessLas erScanner.szPenName, 
//								gProcessINI.m_sProcessLaserScanner.sPenData );
//	}

	// Read System INI File
	CSystemINIFile clsSystemINI;

	strFilePath.Format(_T("%sSystem.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	if( FALSE == clsSystemINI.OpenSystemINIFile( strFilePath, gSystemINI ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("System.ini"));
		ErrMessage(strMsg);
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader = TRUE;
	}
	if(!gSystemINI.m_sHardWare.nDustTableUse)
	{
		gProcessINI.m_sProcessSystem.bNoUseDustSuction = TRUE;
	}

 
	CBeamPathINIFile clsSBeamPathINI;
	
	strFilePath.Format(_T("%sBeamPath.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	BOOL bExist = TRUE;
#ifdef __PUSAN_OLD_32__
	//�켱 ���� �˻�
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(!bExist)
	{
		clsSBeamPathINI.GetOldBeamPathData(gBeamPathINI, gSystemINI);
	}
#endif
	
#ifdef __KUNSAN_8__
	//�켱 ���� �˻�
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(!bExist)
	{
		clsSBeamPathINI.GetOldBeamPathData(gBeamPathINI, gSystemINI);
	}
#endif

#ifdef __CUNGJU_JASMINE_OLD__
	//�켱 ���� �˻�
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(!bExist)
	{
		clsSBeamPathINI.GetOldBeamPathData(gBeamPathINI, gSystemINI);
	}
#endif

	if(bExist)
	{
		if( FALSE == clsSBeamPathINI.OpenBeamPathINIFile( strFilePath, gBeamPathINI ) )
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_OPEN);
			strMsg.Format(strString, _T("BeamPath.ini"));
			ErrMessage(strMsg);
			return FALSE;
		}
	}

	
	CTempINIFile clsTempINI;
	strFilePath.Format(_T("%sTemp.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	if( FALSE == clsTempINI.OpenTempINIFile( strFilePath, gTempINI ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("Temp.ini"));
		ErrMessage(strMsg);
//		return FALSE;
	}


	CShotTableINIFile clsSShotTableINI;

	strFilePath.Format(_T("%sShotTable.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strFilePath);
	//if(!bExist)//20160625
	{
		clsSShotTableINI.GetOldShotTableData(gShotTableINI, gSystemINI);
	}


	if(bExist)
	{
		if( FALSE == clsSShotTableINI.OpenShotTableINIFile( strFilePath, gShotTableINI ) )
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_OPEN);
			strMsg.Format(strString, _T("ShotTable.ini"));
			ErrMessage(strMsg);
			//MultiMessageDlg(STDMESSAGE2, strMsg );
			return FALSE;
		}
	}

	CAutoManualScaleINIFile clsAutoManualScaleTableINI;

	strFilePath.Format(_T("%sAutoManualScaleTable.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(!bExist)//20160625
	{
		clsAutoManualScaleTableINI.GetOldAutoManualScaleData(gAutoManualScaleINI, gSystemINI);
	}


	if(bExist)
	{
		if( FALSE == clsAutoManualScaleTableINI.OpenAutoManualScaleINIFile( strFilePath, gAutoManualScaleINI ) )
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_OPEN);
			strMsg.Format(strString, _T("AutoManualScaleTable.ini"));
			ErrMessage(strMsg);
			//MultiMessageDlg(STDMESSAGE2, strMsg );
			return FALSE;
		}
	}
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.z

#ifdef _AFXDLL
//	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	{
		CString strLang;

		strLang.Format("%sLILY_CH.dll", "D:\\Viahole\\");

		m_hInstanceLanguage = LoadLibrary( (LPCTSTR)strLang );

		if( NULL != m_hInstanceLanguage )
			::AfxSetResourceHandle( m_hInstanceLanguage );
	}

	gTextData.InitCharData();
	gTextDataTemp.InitCharData();

	CEasyDrillerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();


	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CEasyDrillerApp::CheckWorkDir()
{
	TCHAR szWorkDir[255] ;

	memset(szWorkDir, 0, 255);

	::GetCurrentDirectory( 255, szWorkDir );

	if( strlen(szWorkDir) == 0 )
	{
		ErrMessage(IDS_ERR_READ_DIRECTORY);
		return;
	}

	m_strWorkDir.Format(_T("%s\\"), szWorkDir);
}

int CEasyDrillerApp::ExitInstance() 
{
	CString strFilePath;

	// Save Easy Driller INI File
/*	CEasyDrillerINIFile clsINI;

	strFilePath.Format(_T("%sEasy.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	clsINI.SaveINIFile( strFilePath, gEasyDrillerINI );

	// Save Process INI File
	CProcessINIFile clsProcessINI;
	
	strFilePath.Format(_T("%sProcess.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	clsProcessINI.SaveProcessINIFile( strFilePath, gProcessINI );

	// Save System INI File
	CSystemINIFile clsSystemINI;

	strFilePath.Format(_T("%sSystem.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	clsSystemINI.SaveSystemINIFile( strFilePath, gSystemINI );
*/	
	if( m_hInstanceLanguage )
	{
		::FreeLibrary( m_hInstanceLanguage );
		m_hInstanceLanguage = NULL;
	}
//	_CrtDumpMemoryLeaks();
	return CWinApp::ExitInstance();
}

void MessageLoopWait(UINT nWaitms/*ms*/)
{
	CCorrectTime	MyWaitTime;
	MSG				msg;
	MyWaitTime.StartTime();
	double dWaitTime = 0.0;
	while(dWaitTime * 1000 < nWaitms)
	{
		dWaitTime = MyWaitTime.PresentTime();

		if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
		{
			::TranslateMessage((LPMSG)&msg);
			::DispatchMessage((LPMSG )&msg);
		}
		::Sleep(1);
	}
	MyWaitTime.Finish();
	return;

}
int ErrMessage(CString StrMessage, UINT nType, BOOL bLog)
{
	CDlgAlarmMessage dlgAlarmMessage;
	int nResult;
	dlgAlarmMessage.m_bEasyDrillerDlgStart = gVariable.m_bStartEasyDrillerDlg;
	nResult = dlgAlarmMessage.SetErrMsg(StrMessage, nType, bLog);

	return nResult;
}

int ErrMessage(int nMessage, UINT nType , BOOL bLog)
{
	CDlgAlarmMessage dlgAlarmMessage;
	int nResult;
	CString strMessage;
	strMessage.LoadString(nMessage);
	dlgAlarmMessage.m_bEasyDrillerDlgStart = gVariable.m_bStartEasyDrillerDlg;
	nResult = dlgAlarmMessage.SetErrMsg(strMessage, nType, bLog);;

	return nResult;
}
void ErrMsgDlg(int nID, CString strPlus)
{

//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nErrMsgID = nID;
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SetFocus();
	CString strFile, strLog;
	strFile.Format(_T("ErrorID"));
	strLog.Format(_T("%d"), nID);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(nID == STDGNALM202)
		::AfxGetMainWnd()->SendMessage(UM_SET_ERR_MSG_ID, 0);
	else
		::AfxGetMainWnd()->SendMessage(UM_SET_ERR_MSG_ID, nID);


	TCHAR szErrCode[256] = {0,};
	TCHAR szErrReason[500] = {0,};
	TCHAR szErrSolution[2048] = {0,};
	
	if( FALSE != GetErrMsg(nID, szErrCode, szErrReason, szErrSolution) )
	{
		::AfxGetMainWnd()->SendMessage(UM_UPDATE_ERROR, nID, NULL);
		CDlgAlarm dlgAlarm;
		CString strCode = (CString)szErrCode;
		BOOL bError = TRUE;
		
		CString strNo;
		strNo.Format("%s (%d)",szErrCode,nID);
		lstrcpy(szErrCode,strNo);


		dlgAlarm.SetErrMsg( szErrCode, szErrReason, szErrSolution, strPlus );
		
		if(strPlus.GetLength() > 0)
		{
			CString strTemp = strCode;
			strCode.Format(strCode, strPlus);
		}
		
		if(nID == STDGNALM801)
			bError = FALSE;
		
		::AfxGetMainWnd()->SendMessage(UM_SET_ERR_MSG, reinterpret_cast<WPARAM>(&strCode), bError);
		dlgAlarm.DoModal();
		::AfxGetMainWnd()->SendMessage(UM_UPDATE_ERROR_CLEAR, nID, NULL);
		strCode = strCode + _T("_Clear");
		::AfxGetMainWnd()->SendMessage(UM_SET_ERR_MSG, reinterpret_cast<WPARAM>(&strCode), bError);
		
		//		((CEasyDrillerDlg*)::AfxGetMainWnd())->SetErrorMsg( (CString)szErrCode );
	}
}

BOOL ScanSys(CString GetStr, TCHAR strCmp[], double &fValue)
{
	CString strTarget;
	if(!ScanSys(GetStr, strCmp, strTarget))
		return FALSE;

	fValue = atof(strTarget);
	return TRUE;
}

BOOL ScanSys(CString GetStr, TCHAR strCmp[], int &Value)
{
	TCHAR Find[256], strKey[256];
	int Size;
	int data;
	GetStr.TrimLeft();
	memset(strKey, 0, 256);
	strcpy_s(strKey, strCmp);
	Size =  strlen(strKey);

	if (strncmp(GetStr, strKey, Size) == 0)
	{
		sprintf_s(Find, BUFMAX, _T("%s %%d"), strKey);
		sscanf_s(GetStr, Find, &data);
		Value = data;
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL ScanSys(CString GetStr, TCHAR strCmp[], long &Value)
{
	TCHAR Find[256], strKey[256];
	int Size;
	long data;
	GetStr.TrimLeft();
	memset(strKey, 0, 256);
	strcpy_s(strKey, strCmp);
	Size =  strlen(strKey);

	if (strncmp(GetStr, strKey, Size) == 0)
	{
		sprintf_s(Find, BUFMAX, _T("%s %%ld"), strKey);
		sscanf_s(GetStr, Find, &data);
		Value = data;
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL ScanSys(CString GetStr, TCHAR strCmp[], CString& Target)
{
	TCHAR strKey[256];
	int nSize, nNum, nGetStrLength;
	TCHAR *pData;

	nNum = 0;
	GetStr.TrimLeft();
	memset(strKey, 0, 256);
	strcpy_s(strKey, strCmp);
	nSize = strlen(strKey);
	//memset(Data, NULL, 3000);

	// CString
	if (strncmp(GetStr, strKey, nSize) == 0)
	{
		nGetStrLength = GetStr.GetLength();
		pData = new TCHAR[nGetStrLength];
		memset(pData,0,nGetStrLength);
		for (int i=nSize; i<nGetStrLength; i++)
		{
			pData[nNum] = GetStr[i];
			nNum++;
		}

		Target.Format(_T("%s"), pData);
		delete pData;
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

DWORD HextoNum(TCHAR *hex)
{
	TCHAR buf[20];
	TCHAR* pch;
	WORD num;
	
	sprintf_s(buf, 20, _T("%s"), hex);
	num = (WORD)strtol( buf, &pch, 16 ); 
	
	return(num);
}