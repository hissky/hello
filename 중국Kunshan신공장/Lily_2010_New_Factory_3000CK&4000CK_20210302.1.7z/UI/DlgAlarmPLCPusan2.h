#if !defined(AFX_DLGALARMPLCPUSAN2_H__F97FD614_B04F_4843_AA58_723C690018F4__INCLUDED_)
#define AFX_DLGALARMPLCPUSAN2_H__F97FD614_B04F_4843_AA58_723C690018F4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlarmPLCPusan2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCPusan2 dialog

class CDlgAlarmPLCPusan2 : public CDialog
{
// Construction
public:
	CDlgAlarmPLCPusan2(CWnd* pParent = NULL);   // standard constructor

	void GetIoErrorMsg();
	void GetLoadErrorMsg();
	void GetLoad2ErrorMsg();
	void GetLoad3ErrorMsg();
	void GetUnloadErrorMsg();
	void GetUnload2ErrorMsg();
	void GetUnload3ErrorMsg();
	void GetTableLimitErrorMsg();
	void GetOtherLimitErrorMsg();
	void GetLaserErrorMsg();
	void GetOthersErrorMsg();
	void GetOthers2ErrorMsg();
	void GetOthers3ErrorMsg();
	void GetOthers4ErrorMsg();
	void GetOthers5ErrorMsg();
	void GetOthers6ErrorMsg();
	void GetTableErrorMsg();
	void GetMelsecMainErrorMsg();
	void GetMelsecLoaderErrorMsg();
	void GetMelsecUnloaderErrorMsg();
	void GetMelsecEtc1ErrorMsg();
	void GetMelsecEtc2ErrorMsg();
	LONG m_lErrorIoNew;
	LONG m_lErrorLoadNew;
	LONG m_lErrorLoad2New;
	LONG m_lErrorLoad3New;
	LONG m_lErrorUnloadNew;
	LONG m_lErrorUnload2New;
	LONG m_lErrorUnload3New;
	LONG m_lErrorTableLimitNew;
	LONG m_lErrorOtherLimitNew;
	LONG m_lErrorLaserNew;
	LONG m_lErrorOthersNew;
	LONG m_lErrorOthers2New;
	LONG m_lErrorOthers3New;
	LONG m_lErrorOthers4New;
	LONG m_lErrorOthers5New;
	LONG m_lErrorOthers6New;
	LONG m_lErrorTableNew;
	LONG m_lErrorMelsecMainNew;
	LONG m_lErrorMelsecLoaderNew;
	LONG m_lErrorMelsecUnloaderNew;
	LONG m_lErrorMelsecEtc1New;
	LONG m_lErrorMelsecEtc2New;
	LONG m_lErrorNew;
	LONG m_lErrorOld;
	int m_nMsg;
	TCHAR m_szText[255];
	CString m_strMsg[30];
	BOOL m_bOnTimer;
	void UpdateMsg();
	void InitListCtrl();
	void AddItems();
	CListCtrl m_ctrlListMsg;

	int m_nTimerID;

	int m_nMaxError;

// Dialog Data
	//{{AFX_DATA(CDlgAlarmPLCPusan2)
	enum { IDD = IDD_DLG_PLC_ALARM_PUSAN2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAlarmPLCPusan1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgAlarmPLCPusan1)
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALARMPLCPUSAN2_H__F97FD614_B04F_4843_AA58_723C690018F4__INCLUDED_)
