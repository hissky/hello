// DlgLogin.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgLogin.h"
#include "..\easydrillerdlg.h"

#include "..\InterfaceUserAccountModule.h"
#include "..\model\DEasyDrillerINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLogin dialog


CDlgLogin::CDlgLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLogin::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLogin)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nLevel		= 0;
	m_bLock			 = FALSE;
	m_bMoveLock		 = FALSE;
}


void CDlgLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLogin)
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLogin, CDialog)
	//{{AFX_MSG_MAP(CDlgLogin)
	ON_WM_DESTROY()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLogin message handlers

BOOL CDlgLogin::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	
	::SetWindowPos(GetSafeHwnd(), HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);

//	ChangeDir(gEasyDrillerINI.m_clsDirPath.GetNetworkDir());

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgLogin::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnOk.SetFont( &m_fntBtn );
	m_btnOk.SetFlat( FALSE );
	m_btnOk.SetImageOrg( 8, 3 );
	m_btnOk.SetIcon( IDI_OK );
	m_btnOk.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOk.EnableBallonToolTip();
	m_btnOk.SetToolTipText( _T("Login Ok") );
	m_btnOk.SetBtnCursor(IDC_HAND_1);

	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetImageOrg( 8, 3 );
	m_btnCancel.SetIcon( IDI_CANCEL );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Login Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	if(m_bLock)
		m_btnCancel.EnableWindow(FALSE);
}

void CDlgLogin::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	GetDlgItem(IDC_EDIT_ID)->SetFont( &m_fntEdit );
	GetDlgItem(IDC_EDIT_PWD)->SetFont( &m_fntEdit );

#ifdef __TEST__
	SetDlgItemText(IDC_EDIT_ID, _T("sp") );
	SetDlgItemText(IDC_EDIT_PWD, _T("sp"));
#endif
}

void CDlgLogin::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_ID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PWD)->SetFont( &m_fntStatic );
}

void CDlgLogin::OnOK() 
{
	if( 0 == CheckUserID() )
	{
		ErrMessage(IDS_LOGIN_ERR, MB_ICONERROR);
		SetDlgItemText(IDC_EDIT_ID, _T("") );
		SetDlgItemText(IDC_EDIT_PWD, _T(""));

		GetDlgItem(IDC_EDIT_ID)->SetFocus();
	
		return;
	}
	
	CDialog::OnOK();
}

BOOL CDlgLogin::CheckUserID()
{
	CString strName, strPwd;

	GetDlgItemText(IDC_EDIT_ID, strName);
	GetDlgItemText(IDC_EDIT_PWD, strPwd);

	if( strName.IsEmpty() || strPwd.IsEmpty() )
	{
		ErrMessage(IDS_ID_PWD_EMPTY, MB_ICONERROR);
		return FALSE;
	}

	CString strLog;

	// Basic User ID
	if(0 == strName.Compare( _T("Operator") ) && 0 == strPwd.Compare( _T("Operator") ) )
	{
		m_nLevel = 0;
		strLog.Format(_T("ID : Operator ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}		
	else if(0 == strName.Compare( _T("Engineer") ) && 0 == strPwd.Compare( _T("Engineer") ) )
	{
		m_nLevel = 1;
		strLog.Format(_T("ID : Engineer ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
	else if(0 == strName.Compare( _T("EO Engineer") ) && 0 == strPwd.Compare( _T("25 Engineer!") ) )
	{
		m_nLevel = 2;
		strLog.Format(_T("ID : EO Engineer ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
	else if(0 == strName.Compare( _T("eo") ) && 0 == strPwd.Compare( _T("eo") ) ) // ��ȣ����
	{
		m_nLevel = 2;
		strLog.Format(_T("ID : eo ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
#ifndef __TEST__
#ifndef __KUNSAN_LAVIA__
	else if(0 == strName.Compare( _T("eo") ) && 0 == strPwd.Compare( _T("lily2525") ) ) // ��ȣ����
	{
		m_nLevel = 2;
		strLog.Format(_T("ID : eo ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
#endif
#else
	else if(0 == strName.Compare( _T("eo") ) && 0 == strPwd.Compare( _T("eo") ) ) // ��ȣ����
	{
		m_nLevel = 2;
		strLog.Format(_T("ID : eo ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
	else if(0 == strName.Compare( _T("sp") ) && 0 == strPwd.Compare( _T("sp") ) ) // ��ȣ����
	{
		m_nLevel = 3;
		strLog.Format(_T("ID : sp ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
	else if(0 == strName.Compare( _T("op") ) && 0 == strPwd.Compare( _T("op") ) ) // ��ȣ����
	{
		m_nLevel = 0;
		strLog.Format(_T("ID : op ���� LogIn�Ͽ����ϴ�."));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		gDProject.m_strUserID = strName;
		return TRUE;
	}
#endif

	BOOL bRet = 0;
	int nLevel = 0;

	bRet = LoginUserAccount( strName, strPwd, &nLevel );

	if( bRet )
		m_nLevel = nLevel;

	if(bRet && m_nLevel < 3)
	{
		strLog.Format(_T("ID : %s ���� LogIn�Ͽ����ϴ�."), strName);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(strLog, _T(""));
		
	}
	gDProject.m_strUserID = strName;

	return bRet;
}

BOOL CDlgLogin::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgLogin::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CDlgLogin::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(m_bLock)
		return;
	
	CDialog::OnCancel();
}

void CDlgLogin::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	if(m_bMoveLock)
		lpwndpos->flags |= SWP_NOMOVE;
	
	CDialog::OnWindowPosChanging(lpwndpos);
	// TODO: Add your message handler code here
}

void CDlgLogin::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnLButtonDown(nFlags, point);
}

void CDlgLogin::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnMouseMove(nFlags, point);
}

BOOL CDlgLogin::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_bLock)
		m_bMoveLock = TRUE;
	return CDialog::PreTranslateMessage(pMsg);
}

