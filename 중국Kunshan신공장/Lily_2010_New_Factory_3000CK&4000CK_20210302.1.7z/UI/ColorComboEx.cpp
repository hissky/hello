// ColorComboEx.cpp : implementation file
//
// Eric Zimmerman coolez@one.net

#include "stdafx.h"
#include "ColorComboEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const COLORREF COLOR_MAROON					= 0x000080;
const COLORREF COLOR_BROWN					= 0x2A2AA5;
const COLORREF COLOR_LTRED					= 0x0000FF;
const COLORREF COLOR_MAGENTA				= 0xFF00FF;
const COLORREF COLOR_ORANGE					= 0x00A5FF;
const COLORREF COLOR_PINK					= 0xCBC0FF;
const COLORREF COLOR_YELLOW					= 0x00FFFF;
const COLORREF COLOR_CYAN					= 0xFFFF00;
const COLORREF COLOR_BLUE					= 0xFF0000;
const COLORREF COLOR_GREEN					= 0x008000;
const COLORREF COLOR_LIME					= 0x00FF00;
const COLORREF COLOR_INDIANRED				= 0x5C5CCD;
const COLORREF COLOR_SALMON					= 0x7280FA;
const COLORREF COLOR_GOLD					= 0x00D7FF;
const COLORREF COLOR_TAN					= 0x8CB4D2;
const COLORREF COLOR_KHAKI					= 0x8CE6F0;
const COLORREF COLOR_TEAL					= 0x808000;
const COLORREF COLOR_PURPLE					= 0x800080;
const COLORREF COLOR_CADEBLUE				= 0xA09E5F;
const COLORREF COLOR_CRIMSON				= 0x3CA4DC;
const COLORREF COLOR_SILVER					= 0xC0C0C0;
const COLORREF COLOR_NAVY					= 0x800000;
const COLORREF COLOR_PLUM					= 0xDDA0DD;
const COLORREF COLOR_VIOLET					= 0xEE82EE;
const COLORREF COLOR_SEAGREEN				= 0x578B2E;
const COLORREF COLOR_DARKGRAY				= 0xA9A9A9;
const COLORREF COLOR_INDIGO					= 0x82004B;
const COLORREF COLOR_GOLDENROD				= 0x20A5DA;
const COLORREF COLOR_GRAY					= 0x808080;
const COLORREF COLOR_BLACK					= 0x000000;

/////////////////////////////////////////////////////////////////////////////
// CColorComboEx

CColorComboEx::CColorComboEx()
{
	TRY
	{
		m_colors.Add(COLOR_MAROON);		
		m_colors.Add(COLOR_BROWN);	
		m_colors.Add(COLOR_LTRED);
		m_colors.Add(COLOR_MAGENTA);	
		m_colors.Add(COLOR_ORANGE);
		m_colors.Add(COLOR_PINK);		
		m_colors.Add(COLOR_YELLOW);	
		m_colors.Add(COLOR_CYAN);		
		m_colors.Add(COLOR_BLUE);		
		m_colors.Add(COLOR_GREEN);	
		m_colors.Add(COLOR_LIME);
		m_colors.Add(COLOR_INDIANRED);
		m_colors.Add(COLOR_SALMON);
		m_colors.Add(COLOR_GOLD);	
		m_colors.Add(COLOR_TAN);
		m_colors.Add(COLOR_KHAKI);
		m_colors.Add(COLOR_TEAL);
		m_colors.Add(COLOR_PURPLE);
		m_colors.Add(COLOR_CADEBLUE);
		m_colors.Add(COLOR_CRIMSON);
		m_colors.Add(COLOR_SILVER);
		m_colors.Add(COLOR_NAVY);
		m_colors.Add(COLOR_PLUM);
		m_colors.Add(COLOR_VIOLET);
		m_colors.Add(COLOR_SEAGREEN);
		m_colors.Add(COLOR_DARKGRAY);
		m_colors.Add(COLOR_INDIGO);
		m_colors.Add(COLOR_GOLDENROD);
		m_colors.Add(COLOR_GRAY);
		m_colors.Add(COLOR_BLACK);	
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
}

CColorComboEx::~CColorComboEx()
{
}


BEGIN_MESSAGE_MAP(CColorComboEx, CComboBox)
	//{{AFX_MSG_MAP(CColorComboEx)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorComboEx message handlers

void CColorComboEx::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);

	CBrush brush(m_colors[lpDrawItemStruct->itemID]);
	CRect rect(&(lpDrawItemStruct->rcItem));
	rect.InflateRect(-2, -2);
	dc.FillRect(rect, &brush);
	if (lpDrawItemStruct->itemState & ODS_SELECTED)
		dc.DrawFocusRect(rect);

	CBrush frameBrush(RGB(0, 0, 0));
	dc.FrameRect(rect, &frameBrush);
	rect.InflateRect(-1, -1);
	dc.Detach();
}

void CColorComboEx::PreSubclassWindow() 
{
//	int i = 2;

	for (int nColors = 0; nColors < m_colors.GetSize(); nColors++) AddString("");

/*	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_WHITE)	i = 0;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_GRAY)	i = 1;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_BLACK)	i = 2;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_BROWN)	i = 3;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_LTRED)	i = 4;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_MAGENTA)i = 5;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_ORANGE)	i = 6;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_PINK)	i = 7;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_YELLOW)	i = 8;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_CYAN)	i = 9;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_BLUE)	i = 10;
	if (g_pProject->g_ToolData[m_iColorSel].crTool == COLOR_GREEN)	i = 11;

	SetCurSel(i);*/

	CComboBox::PreSubclassWindow();
}

DWORD GetRGB(int nIndex)
{
	switch(nIndex) {
	case 0:
		return COLOR_MAROON;
	case 1:
		return COLOR_BROWN;
	case 2:
		return COLOR_LTRED;
	case 3:
		return COLOR_MAGENTA;
	case 4:
		return COLOR_ORANGE;
	case 5:
		return COLOR_PINK;
	case 6:
		return COLOR_YELLOW;
	case 7:
		return COLOR_CYAN;
	case 8:
		return COLOR_BLUE;

	case 9:
		return COLOR_GREEN;
	case 10:
		return COLOR_LIME;
	case 11:
		return COLOR_INDIANRED;
	case 12:
		return COLOR_SALMON;
	case 13:
		return COLOR_GOLD;
	case 14:
		return COLOR_TAN;
	case 15:
		return COLOR_KHAKI;
	case 16:
		return COLOR_TEAL;
	case 17:
		return COLOR_PURPLE;
	case 18:
		return COLOR_CADEBLUE;

	case 19:
		return COLOR_CRIMSON;
	case 20:
		return COLOR_SILVER;
	case 21:
		return COLOR_NAVY;
	case 22:
		return COLOR_PLUM;
	case 23:
		return COLOR_VIOLET;
	case 24:
		return COLOR_SEAGREEN;
	case 25:
		return COLOR_DARKGRAY;
	case 26:
		return COLOR_INDIGO;
	case 27:
		return COLOR_GOLDENROD;
	case 28:
		return COLOR_GRAY;
	case 29:
		return COLOR_BLACK;
	}

	return COLOR_BLACK;
}
