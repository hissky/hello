// USimpleTab.cpp : implementation file
//

#include "stdafx.h"
#include "USimpleTab.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// USimpleTab

USimpleTab::USimpleTab()
{
	m_pCurrentPane = NULL;
	m_PaneArray.SetSize(0);

	m_clrTabBackground = ::GetSysColor(COLOR_BTNFACE);

	m_clrBorderSelected = RGB(0,0,0);
	m_clrBorderUnselected = RGB(0,0,0);

	m_clrBackSelected = RGB( 255, 251, 243 );
	m_clrBackUnselected = ::GetSysColor(COLOR_BTNFACE);

	m_clrForeSelected = RGB(0, 128, 0);
	m_clrForeUnselected = RGB(0, 0, 0);

	m_bTabChangeEnable = TRUE;
	
	m_nSkipIndex = -1;
}

USimpleTab::~USimpleTab()
{
}


BEGIN_MESSAGE_MAP(USimpleTab, CTabCtrl)
	//{{AFX_MSG_MAP(USimpleTab)
	ON_NOTIFY_REFLECT(TCN_SELCHANGE, OnSelchange)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// USimpleTab message handlers

BOOL USimpleTab::AddPane(LPCTSTR pszPaneTitle, CRuntimeClass *pRuntimeClass)
{
	CObject *pObject = pRuntimeClass->CreateObject();
	if(pObject->IsKindOf(RUNTIME_CLASS(CFormView)) == 0)
	{
		delete pObject;
		return FALSE;
	}

	int iIndex = m_PaneArray.GetSize();
	CWnd *pFormView = static_cast<CWnd *>(pObject);
	pFormView->Create(
		NULL,
		NULL,
		AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0),
		this,
		iIndex + 1,
		NULL
		);

	m_PaneArray.Add(static_cast<CFormView *>(pObject));
	m_PaneArray.FreeExtra();

	InsertItem(iIndex, pszPaneTitle);
	

	return (TRUE);
}

BOOL USimpleTab::AddPane(LPCTSTR pszPaneTitle, CFormView *pPane)
{
	if(pPane->IsKindOf(RUNTIME_CLASS(CFormView)) == 0)
	{
		return FALSE;
	}

	int iIndex = m_PaneArray.GetSize();

	m_PaneArray.Add(pPane);
	m_PaneArray.FreeExtra();

	InsertItem(iIndex, pszPaneTitle);

	return TRUE;
}

int USimpleTab::GetPaneSize()
{
	int iSize = m_PaneArray.GetSize();

	return (iSize);
}

CFormView * USimpleTab::GetPane(int iIndex)
{
	if(iIndex >= m_PaneArray.GetSize())
		return NULL;

	CFormView *pFormView = m_PaneArray.GetAt(iIndex);

	return (pFormView);
}

void USimpleTab::ShowPane(int iIndex)
{
	int nSize = m_PaneArray.GetSize();
	if(iIndex >= nSize )
		return;

	if(m_pCurrentPane != NULL)
		m_pCurrentPane->ShowWindow(SW_HIDE);

	CRect rectPane;
	GetClientRect(rectPane);
	AdjustRect(FALSE, rectPane);

	CFormView *pFormView = m_PaneArray.GetAt(iIndex);
	pFormView->MoveWindow(rectPane);
	pFormView->ShowWindow(SW_SHOW);
	m_pCurrentPane = pFormView;
	this->SetCurSel(iIndex);
}

void USimpleTab::OnSelchange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

	if(!m_bTabChangeEnable)
		return;

	int iIndex = TabCtrl_GetCurSel(this->m_hWnd);

	if(iIndex == m_nSkipIndex)
		return;

	ShowPane(iIndex);
	
	*pResult = 0;
}

void USimpleTab::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DRAWITEMSTRUCT dis;
	dis.CtlType = ODT_TAB;
	dis.CtlID = GetDlgCtrlID();
	dis.hwndItem = GetSafeHwnd();
	dis.hDC = dc.GetSafeHdc();
	dis.itemAction = ODA_DRAWENTIRE;

	CRect rectClient, rectPage;
	GetClientRect(&dis.rcItem);
	rectPage = dis.rcItem;
	dis.rcItem.top = rectPage.top;

	DrawMainBorder(&dis);

	int iTabCount = GetItemCount();
	int iSel = GetCurSel();

	if(iTabCount == 0)
		return;

	for(int iTabIndex = 0 ; iTabIndex < iTabCount ; ++iTabIndex)
	{
		if(iTabIndex == iSel)
			continue;

		dis.itemID = iTabIndex;
		dis.itemState = 0;

		GetItemRect(iTabIndex, &dis.rcItem);

		DrawItemBorder(&dis);
		DrawItemTextAndImage(&dis);
	}

	dis.itemID = iSel;
	dis.itemState = ODS_SELECTED;

	GetItemRect(iSel, &dis.rcItem);
	dis.rcItem.bottom += 2;
	dis.rcItem.top -= 2;
	
	DrawItemBorder(&dis);
	DrawItemTextAndImage(&dis);
}

void USimpleTab::DrawMainBorder(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rectMainBorder = lpDrawItemStruct->rcItem;

	pDC->FillSolidRect(rectMainBorder, m_clrTabBackground);
}

void USimpleTab::DrawItemBorder(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rect = lpDrawItemStruct->rcItem;
	CBrush *pBrushOld = NULL;
	CPen *pPenOld = NULL;

	if(lpDrawItemStruct->itemState == ODS_SELECTED)
	{
		CPen penBorder(PS_SOLID, 0, m_clrBorderSelected);
		pPenOld = pDC->SelectObject(&penBorder);

		CRect rectMainBorder;
		GetClientRect(rectMainBorder);

		pDC->FillSolidRect(rect, m_clrBackSelected);

		pDC->MoveTo(rect.left, rect.top);
		pDC->LineTo(rect.right - 1, rect.top);
		pDC->LineTo(rect.right - 1, rect.bottom - 1);
		pDC->LineTo(rectMainBorder.right - 1, rect.bottom - 1);
		pDC->LineTo(rectMainBorder.right - 1, rectMainBorder.bottom - 1);
		pDC->LineTo(rectMainBorder.left, rectMainBorder.bottom - 1);
		pDC->LineTo(rectMainBorder.left, rect.bottom - 1);
		pDC->LineTo(rect.left, rect.bottom - 1);
		pDC->LineTo(rect.left, rect.top);

		pDC->SelectObject(pPenOld);
	}
	else
	{
		CBrush brBackground(m_clrBackUnselected);
		pBrushOld = pDC->SelectObject(&brBackground);
		pPenOld = (CPen *)pDC->SelectStockObject(NULL_PEN);

		//pDC->Rectangle(rect);

		CPen penBorder(PS_SOLID, 0, m_clrBorderUnselected);
		pDC->SelectObject(&penBorder);

		pDC->MoveTo(rect.left + 1, rect.bottom);
		pDC->LineTo(rect.left + 1, rect.top);
		pDC->LineTo(rect.right - 2, rect.top);
		pDC->LineTo(rect.right - 2, rect.bottom);

		pDC->SelectObject(pBrushOld);
		pDC->SelectObject(pPenOld);
	}
}

void USimpleTab::DrawItemTextAndImage(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rectItem = lpDrawItemStruct->rcItem;
	int iTopOffset = 0;
	int iLeftOffset = 0;
	int iImageWidth = 0;

	CString strItemTitle;
	TC_ITEM tci;
	tci.mask = TCIF_IMAGE | TCIF_TEXT;
	tci.pszText = strItemTitle.GetBuffer(256);
	tci.cchTextMax = 255;
	GetItem(lpDrawItemStruct->itemID, &tci);
	strItemTitle.ReleaseBuffer();

	HIMAGELIST hImageList = (HIMAGELIST) TabCtrl_GetImageList(GetSafeHwnd());
	if(hImageList != NULL)
	{
		CImageList *pImageList = CImageList::FromHandlePermanent(hImageList);
		IMAGEINFO imageInfo;
		if(pImageList->GetImageInfo(tci.iImage, &imageInfo) != FALSE)
		{
			iTopOffset =
				(rectItem.Height() - (imageInfo.rcImage.bottom - imageInfo.rcImage.top)) / 2;
			iLeftOffset = iTopOffset;
			iImageWidth = imageInfo.rcImage.right - imageInfo.rcImage.left;

			ImageList_Draw(
				hImageList,
				tci.iImage,
				pDC->m_hDC,
				rectItem.left + iLeftOffset,
				rectItem.top + iTopOffset,
				ILD_TRANSPARENT
				);
		}
	}

	CFont *pCurrentFont = GetFont();
	CFont *pFontOld = pDC->SelectObject(pCurrentFont);

	pDC->SetBkMode(TRANSPARENT);

	if(lpDrawItemStruct->itemState == ODS_SELECTED)
	{
		pDC->SetTextColor(m_clrForeSelected);
	}
	else
	{
		pDC->SetTextColor(m_clrForeUnselected);
	}

	rectItem.left = rectItem.left + iImageWidth + iLeftOffset;

	pDC->DrawText(
		strItemTitle,
		rectItem,
		DT_CENTER | DT_VCENTER | DT_SINGLELINE
		);

	pDC->SelectObject(pFontOld);
}

void USimpleTab::TabChangeEnable(BOOL bEnable)
{
	m_bTabChangeEnable = bEnable;
}

BOOL USimpleTab::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( WM_LBUTTONDOWN == pMsg->message )
	{
		if(!m_bTabChangeEnable)
			return TRUE;
	}

	return CTabCtrl::PreTranslateMessage(pMsg);
}
