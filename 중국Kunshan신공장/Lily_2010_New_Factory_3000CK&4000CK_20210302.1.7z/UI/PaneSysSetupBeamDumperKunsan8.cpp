// PaneSysSetupBeamDumperKunsan8.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupBeamDumperKunsan8.h"
#include "..\Model\DSystemINI.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HEocard.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumperKunsan8

IMPLEMENT_DYNCREATE(CPaneSysSetupBeamDumperKunsan8, CFormView)

CPaneSysSetupBeamDumperKunsan8::CPaneSysSetupBeamDumperKunsan8()
	: CFormView(CPaneSysSetupBeamDumperKunsan8::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupBeamDumperKunsan8)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneSysSetupBeamDumperKunsan8::~CPaneSysSetupBeamDumperKunsan8()
{
}

void CPaneSysSetupBeamDumperKunsan8::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupBeamDumperKunsan8)
	DDX_Control(pDX, IDC_BUTTON_FIRE, m_btnFire);
	DDX_Control(pDX, IDC_BTN_2ND_PANEL_SHT_OPEN, m_btn2ndPanelShtOpen);
	DDX_Control(pDX, IDC_BTN_2ND_PANEL_SHT_CLOSE, m_btn2ndPanelShtClose);
	DDX_Control(pDX, IDC_BTN_1ST_PANEL_SHT_OPEN, m_btn1stPanelShtOpen);
	DDX_Control(pDX, IDC_BTN_1ST_PANEL_SHT_CLOSE, m_btn1stPanelShtClose);
	DDX_Control(pDX, IDC_BTN_MAIN_SHT_OPEN, m_btnMainShtOpen);
	DDX_Control(pDX, IDC_BTN_MAIN_SHT_CLOSE, m_btnMainShtClose);
	DDX_Control(pDX, IDC_BUTTON_MODE_SINGLE_SHOT, m_btnModeSingleShot);
	DDX_Control(pDX, IDC_BUTTON_MODE_CONTINUOUS, m_btnModeContinuous);
	DDX_Control(pDX, IDC_EDIT_2ND_PANEL_POS_Y, m_edt2ndPanelPosY);
	DDX_Control(pDX, IDC_EDIT_2ND_PANEL_POS_X, m_edt2ndPanelPosX);
	DDX_Control(pDX, IDC_EDIT_1ST_PANEL_POS_Y, m_edt1stPanelPosY);
	DDX_Control(pDX, IDC_EDIT_1ST_PANEL_POS_X, m_edt1stPanelPosX);
	DDX_Control(pDX, IDC_EDIT_MODE_PULSE_WIDTH, m_edtPulseWidth);
	DDX_Control(pDX, IDC_EDIT_DUMMY_NO, m_edtDummyShotNo);
	DDX_Control(pDX, IDC_EDIT_DUMMY_TIME, m_edtDummyInterval);
	DDX_Control(pDX, IDC_EDIT_DUMMY_FREQ, m_edtDummyFreq);
	DDX_Control(pDX, IDC_EDIT_DUMMY_DUTY, m_edtDummyDuty);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DELAY, m_edtDummyAOMDelay);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DUTY, m_edtDummyAOMDuty);
	DDX_Control(pDX, IDC_EDIT_DUMMY_NO2, m_edtDummyShotNo2);
	DDX_Control(pDX, IDC_EDIT_DUMMY_TIME2, m_edtDummyInterval2);
	DDX_Control(pDX, IDC_EDIT_DUMMY_FREQ2, m_edtDummyFreq2);
	DDX_Control(pDX, IDC_EDIT_DUMMY_DUTY2, m_edtDummyDuty2);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DELAY2, m_edtDummyAOMDelay2);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DUTY2, m_edtDummyAOMDuty2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupBeamDumperKunsan8, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupBeamDumperKunsan8)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BTN_MAIN_SHT_OPEN, OnBtnMainShtOpen)
	ON_BN_CLICKED(IDC_BTN_MAIN_SHT_CLOSE, OnBtnMainShtClose)
	ON_BN_CLICKED(IDC_BTN_1ST_PANEL_SHT_OPEN, OnBtn1stPanelShtOpen)
	ON_BN_CLICKED(IDC_BTN_1ST_PANEL_SHT_CLOSE, OnBtn1stPanelShtClose)
	ON_BN_CLICKED(IDC_BTN_2ND_PANEL_SHT_OPEN, OnBtn2ndPanelShtOpen)
	ON_BN_CLICKED(IDC_BTN_2ND_PANEL_SHT_CLOSE, OnBtn2ndPanelShtClose)
	ON_BN_CLICKED(IDC_BUTTON_MODE_CONTINUOUS, OnButtonModeContinuous)
	ON_BN_CLICKED(IDC_BUTTON_MODE_SINGLE_SHOT, OnButtonModeSingleShot)
	ON_BN_CLICKED(IDC_BUTTON_FIRE, OnButtonFire)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumperKunsan8 diagnostics

#ifdef _DEBUG
void CPaneSysSetupBeamDumperKunsan8::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupBeamDumperKunsan8::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumperKunsan8 message handlers

void CPaneSysSetupBeamDumperKunsan8::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
}

BOOL CPaneSysSetupBeamDumperKunsan8::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

HBRUSH CPaneSysSetupBeamDumperKunsan8::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_1ST_PANEL_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_PANEL_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DUMMY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DUMMY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DUMMY2)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupBeamDumperKunsan8::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Shutter
	m_btnMainShtOpen.SetFont( &m_fntBtn );
	m_btnMainShtOpen.SetRectAlign( 1 ); 
	m_btnMainShtOpen.SetToolTipText( _T("Main Shutter Open") );
	m_btnMainShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btnMainShtClose.SetFont( &m_fntBtn );
	m_btnMainShtClose.SetRectAlign( 1 ); 
	m_btnMainShtClose.SetToolTipText( _T("Main Shutter Close") );
	m_btnMainShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtOpen.SetFont( &m_fntBtn );
	m_btn1stPanelShtOpen.SetRectAlign( 1 ); 
	m_btn1stPanelShtOpen.SetToolTipText( _T("1st Panel Shutter Open") );
	m_btn1stPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtClose.SetFont( &m_fntBtn );
	m_btn1stPanelShtClose.SetRectAlign( 1 ); 
	m_btn1stPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn1stPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtOpen.SetFont( &m_fntBtn );
	m_btn2ndPanelShtOpen.SetRectAlign( 1 ); 
	m_btn2ndPanelShtOpen.SetToolTipText( _T("2nd Panel Shutter Open") );
	m_btn2ndPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtClose.SetFont( &m_fntBtn );
	m_btn2ndPanelShtClose.SetRectAlign( 1 ); 
	m_btn2ndPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn2ndPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btnFire.SetFont( &m_fntBtn );
	m_btnFire.SetRectAlign( 1 ); 
	m_btnFire.SetToolTipText( _T("Fire") );
	m_btnFire.SetBtnCursor( IDC_HAND_1 );

	// Laser Mode
	m_btnModeContinuous.SetFont( &m_fntBtn );
	m_btnModeContinuous.SetRectAlign( 1 ); 
	m_btnModeContinuous.SetToolTipText( _T("Laser Continuous Mode") );
	m_btnModeContinuous.SetBtnCursor( IDC_HAND_1 );

	m_btnModeSingleShot.SetFont( &m_fntBtn );
	m_btnModeSingleShot.SetRectAlign( 1 ); 
	m_btnModeSingleShot.SetToolTipText( _T("Laser Single Shot Mode") );
	m_btnModeSingleShot.SetBtnCursor( IDC_HAND_1 );
}

void CPaneSysSetupBeamDumperKunsan8::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(180, "Arial Bold");

	// 1st Panel Position
	m_edt1stPanelPosX.SetFont( &m_fntEdit );
	m_edt1stPanelPosX.SetForeColor( BLACK_COLOR );
	m_edt1stPanelPosX.SetBackColor( WHITE_COLOR );
	m_edt1stPanelPosX.SetReceivedFlag( 1 );
	m_edt1stPanelPosX.SetWindowText( _T("32767") );

	m_edt1stPanelPosY.SetFont( &m_fntEdit );
	m_edt1stPanelPosY.SetForeColor( BLACK_COLOR );
	m_edt1stPanelPosY.SetBackColor( WHITE_COLOR );
	m_edt1stPanelPosY.SetReceivedFlag( 1 );
	m_edt1stPanelPosY.SetWindowText( _T("65000") );

	// 2nd Panel Position
	m_edt2ndPanelPosX.SetFont( &m_fntEdit );
	m_edt2ndPanelPosX.SetForeColor( BLACK_COLOR );
	m_edt2ndPanelPosX.SetBackColor( WHITE_COLOR );
	m_edt2ndPanelPosX.SetReceivedFlag( 1 );
	m_edt2ndPanelPosX.SetWindowText( _T("32767") );

	m_edt2ndPanelPosY.SetFont( &m_fntEdit );
	m_edt2ndPanelPosY.SetForeColor( BLACK_COLOR );
	m_edt2ndPanelPosY.SetBackColor( WHITE_COLOR );
	m_edt2ndPanelPosY.SetReceivedFlag( 1 );
	m_edt2ndPanelPosY.SetWindowText( _T("65000") );

	// Laser Mode
	m_edtPulseWidth.SetFont( &m_fntEdit );
	m_edtPulseWidth.SetForeColor( BLACK_COLOR );
	m_edtPulseWidth.SetBackColor( WHITE_COLOR );
	m_edtPulseWidth.SetReceivedFlag( 3 );
	m_edtPulseWidth.SetWindowText( _T("0.1") );


	// dummy
	m_edtDummyShotNo.SetFont( &m_fntEdit );
	m_edtDummyShotNo.SetForeColor( BLACK_COLOR );
	m_edtDummyShotNo.SetBackColor( WHITE_COLOR );
	m_edtDummyShotNo.SetReceivedFlag( 1 );
	m_edtDummyShotNo.SetWindowText( _T("200") );

	m_edtDummyInterval.SetFont( &m_fntEdit );
	m_edtDummyInterval.SetForeColor( BLACK_COLOR );
	m_edtDummyInterval.SetBackColor( WHITE_COLOR );
	m_edtDummyInterval.SetReceivedFlag( 1 );
	m_edtDummyInterval.SetWindowText( _T("350") );

	m_edtDummyFreq.SetFont( &m_fntEdit );
	m_edtDummyFreq.SetForeColor( BLACK_COLOR );
	m_edtDummyFreq.SetBackColor( WHITE_COLOR );
	m_edtDummyFreq.SetReceivedFlag( 1 );
	m_edtDummyFreq.SetWindowText( _T("3000") );

	m_edtDummyDuty.SetFont( &m_fntEdit );
	m_edtDummyDuty.SetForeColor( BLACK_COLOR );
	m_edtDummyDuty.SetBackColor( WHITE_COLOR );
	m_edtDummyDuty.SetReceivedFlag( 1 );
	m_edtDummyDuty.SetWindowText( _T("67") );

	m_edtDummyAOMDelay.SetFont( &m_fntEdit );
	m_edtDummyAOMDelay.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDelay.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDelay.SetReceivedFlag( 1 );
	m_edtDummyAOMDelay.SetWindowText( _T("0") );

	m_edtDummyAOMDuty.SetFont( &m_fntEdit );
	m_edtDummyAOMDuty.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDuty.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDuty.SetReceivedFlag( 1 );
	m_edtDummyAOMDuty.SetWindowText( _T("1") );

	// dummy
	m_edtDummyShotNo2.SetFont( &m_fntEdit );
	m_edtDummyShotNo2.SetForeColor( BLACK_COLOR );
	m_edtDummyShotNo2.SetBackColor( WHITE_COLOR );
	m_edtDummyShotNo2.SetReceivedFlag( 1 );
	m_edtDummyShotNo2.SetWindowText( _T("200") );
	
	m_edtDummyInterval2.SetFont( &m_fntEdit );
	m_edtDummyInterval2.SetForeColor( BLACK_COLOR );
	m_edtDummyInterval2.SetBackColor( WHITE_COLOR );
	m_edtDummyInterval2.SetReceivedFlag( 1 );
	m_edtDummyInterval2.SetWindowText( _T("350") );
	
	m_edtDummyFreq2.SetFont( &m_fntEdit );
	m_edtDummyFreq2.SetForeColor( BLACK_COLOR );
	m_edtDummyFreq2.SetBackColor( WHITE_COLOR );
	m_edtDummyFreq2.SetReceivedFlag( 1 );
	m_edtDummyFreq2.SetWindowText( _T("3000") );
	
	m_edtDummyDuty2.SetFont( &m_fntEdit );
	m_edtDummyDuty2.SetForeColor( BLACK_COLOR );
	m_edtDummyDuty2.SetBackColor( WHITE_COLOR );
	m_edtDummyDuty2.SetReceivedFlag( 1 );
	m_edtDummyDuty2.SetWindowText( _T("67") );
	
	m_edtDummyAOMDelay2.SetFont( &m_fntEdit );
	m_edtDummyAOMDelay2.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDelay2.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDelay2.SetReceivedFlag( 1 );
	m_edtDummyAOMDelay2.SetWindowText( _T("0") );
	
	m_edtDummyAOMDuty2.SetFont( &m_fntEdit );
	m_edtDummyAOMDuty2.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDuty2.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDuty2.SetReceivedFlag( 1 );
	m_edtDummyAOMDuty2.SetWindowText( _T("1") );
}

void CPaneSysSetupBeamDumperKunsan8::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// 1st Panel Position
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS_Y)->SetFont( &m_fntStatic );

	// 2nd Panel Position
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS_Y)->SetFont( &m_fntStatic );

	// Shutter
	GetDlgItem(IDC_STATIC_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->SetFont( &m_fntStatic );

	// Laser Mode
	GetDlgItem(IDC_STATIC_LASER_MODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PULSE_WIDTH)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_DUMMY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_SHOTNO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DELAU)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DUTY)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_DUMMY2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_SHOTNO2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_TIME2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_FREQ2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_DUTY2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DELAU2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DUTY2)->SetFont( &m_fntStatic );

}

void CPaneSysSetupBeamDumperKunsan8::OnBtnMainShtOpen() 
{
	BOOL bFlag = m_btnMainShtOpen.GetClick();

	m_btnMainShtOpen.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnBtnMainShtClose() 
{
	BOOL bFlag = m_btnMainShtClose.GetClick();

	m_btnMainShtClose.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnBtn1stPanelShtOpen() 
{
	BOOL bFlag = m_btn1stPanelShtOpen.GetClick();

	m_btn1stPanelShtOpen.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnBtn1stPanelShtClose() 
{
	BOOL bFlag = m_btn1stPanelShtClose.GetClick();

	m_btn1stPanelShtClose.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnBtn2ndPanelShtOpen() 
{
	BOOL bFlag = m_btn2ndPanelShtOpen.GetClick();

	m_btn2ndPanelShtOpen.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnBtn2ndPanelShtClose() 
{
	BOOL bFlag = m_btn2ndPanelShtClose.GetClick();

	m_btn2ndPanelShtClose.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnButtonModeContinuous() 
{
	BOOL bFlag = m_btnModeContinuous.GetClick();

	m_btnModeContinuous.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnButtonModeSingleShot() 
{
	BOOL bFlag = m_btnModeSingleShot.GetClick();

	m_btnModeSingleShot.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnButtonFire() 
{
	BOOL bFlag = m_btnFire.GetClick();

	m_btnFire.SetClick( !bFlag );
}

void CPaneSysSetupBeamDumperKunsan8::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupBeamDumperKunsan8::SetBeamDumperData()
{
	CString str;
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper1.x);
	m_edt1stPanelPosX.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper1.y);
	m_edt1stPanelPosY.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper2.x);
	m_edt2ndPanelPosX.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper2.y);
	m_edt2ndPanelPosY.SetWindowText( str );

	// dummy
	str.Format(_T("%d"), m_sSystemDump.nDummyShot);
	m_edtDummyShotNo.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyInterval);
	m_edtDummyInterval.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyFreq);
	m_edtDummyFreq.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyDuty);
	m_edtDummyDuty.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDelay);
	m_edtDummyAOMDelay.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDuty);
	m_edtDummyAOMDuty.SetWindowText( str );

	
	// dummy
	str.Format(_T("%d"), m_sSystemDump.nDummyShot2);
	m_edtDummyShotNo2.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nDummyInterval2);
	m_edtDummyInterval2.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nDummyFreq2);
	m_edtDummyFreq2.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nDummyDuty2);
	m_edtDummyDuty2.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDelay2);
	m_edtDummyAOMDelay2.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDuty2);
	m_edtDummyAOMDuty2.SetWindowText( str );
}

void CPaneSysSetupBeamDumperKunsan8::OnApply()
{
	CString strData;
	
	m_edt1stPanelPosX.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper1.x = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stPanelPosY.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper1.y = atoi( (LPSTR)(LPCTSTR)strData );
	
	
	m_edt2ndPanelPosX.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper2.x = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edt2ndPanelPosY.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper2.y = atoi( (LPSTR)(LPCTSTR)strData );

	// dummy
	m_edtDummyShotNo.GetWindowText( strData );
	m_sSystemDump.nDummyShot = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyInterval.GetWindowText( strData );
	m_sSystemDump.nDummyInterval = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyFreq.GetWindowText( strData );
	m_sSystemDump.nDummyFreq = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyDuty.GetWindowText( strData );
	m_sSystemDump.nDummyDuty = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyAOMDelay.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDelay = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyAOMDuty.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDuty = atoi( (LPSTR)(LPCTSTR)strData );

	
	// dummy
	m_edtDummyShotNo2.GetWindowText( strData );
	m_sSystemDump.nDummyShot2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtDummyInterval2.GetWindowText( strData );
	m_sSystemDump.nDummyInterval2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtDummyFreq2.GetWindowText( strData );
	m_sSystemDump.nDummyFreq2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtDummyDuty2.GetWindowText( strData );
	m_sSystemDump.nDummyDuty2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtDummyAOMDelay2.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDelay2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtDummyAOMDuty2.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDuty2 = atoi( (LPSTR)(LPCTSTR)strData );

}

void CPaneSysSetupBeamDumperKunsan8::SetSystemDevice(SSYSTEMDUMP sSystemDump)
{
	memcpy( &m_sSystemDump, &sSystemDump, sizeof(m_sSystemDump) );

	SetBeamDumperData();
}

CString CPaneSysSetupBeamDumperKunsan8::GetChangeValueStr()
{
	CString strMessage, strTemp, strId1, strId2;
	strMessage.Format(_T(""));
	
	if(m_sSystemDump.nPtBeanDumper1.x != gSystemINI.m_sSystemDump.nPtBeanDumper1.x ||
		m_sSystemDump.nPtBeanDumper1.y != gSystemINI.m_sSystemDump.nPtBeanDumper1.y)
	{
		strTemp.Format(_T("| 1st Beam Dumper : ( %d, %d) "), 
			m_sSystemDump.nPtBeanDumper1.x,
			m_sSystemDump.nPtBeanDumper1.y);
		strMessage += strTemp;
	}
	
	if(m_sSystemDump.nPtBeanDumper2.x != gSystemINI.m_sSystemDump.nPtBeanDumper2.x ||
		m_sSystemDump.nPtBeanDumper2.y != gSystemINI.m_sSystemDump.nPtBeanDumper2.y)
	{
		strTemp.Format(_T("| 1st Beam Dumper : ( %d, %d) "), 
			m_sSystemDump.nPtBeanDumper2.x,
			m_sSystemDump.nPtBeanDumper2.y);
		strMessage += strTemp;
	}

	if(m_sSystemDump.nDummyShot != gSystemINI.m_sSystemDump.nDummyShot ||
		m_sSystemDump.nDummyFreq != gSystemINI.m_sSystemDump.nDummyFreq ||
		m_sSystemDump.nDummyInterval != gSystemINI.m_sSystemDump.nDummyInterval ||
		m_sSystemDump.nDummyDuty != gSystemINI.m_sSystemDump.nDummyDuty ||
		m_sSystemDump.nDummyAOMDelay != gSystemINI.m_sSystemDump.nDummyAOMDelay ||
		m_sSystemDump.nDummyAOMDuty != gSystemINI.m_sSystemDump.nDummyAOMDuty)
	{
		strTemp.Format(_T("| DummyShot (%d), Frequency (%d), Interval (%d), Duty (%d), AOMDelay (%d), AOMDuty (%d) "), 
			m_sSystemDump.nDummyShot,
			m_sSystemDump.nDummyFreq,
			m_sSystemDump.nDummyInterval,
			m_sSystemDump.nDummyDuty,
			m_sSystemDump.nDummyAOMDelay,
			m_sSystemDump.nDummyAOMDuty);
		strMessage += strTemp;
	}

	if(m_sSystemDump.nDummyShot2 != gSystemINI.m_sSystemDump.nDummyShot2 ||
		m_sSystemDump.nDummyFreq2 != gSystemINI.m_sSystemDump.nDummyFreq2 ||
		m_sSystemDump.nDummyInterval2 != gSystemINI.m_sSystemDump.nDummyInterval2 ||
		m_sSystemDump.nDummyDuty2 != gSystemINI.m_sSystemDump.nDummyDuty2 ||
		m_sSystemDump.nDummyAOMDelay2 != gSystemINI.m_sSystemDump.nDummyAOMDelay2 ||
		m_sSystemDump.nDummyAOMDuty2 != gSystemINI.m_sSystemDump.nDummyAOMDuty2)
	{
		strTemp.Format(_T("| DummyShot (%d), Frequency (%d), Interval (%d), Duty (%d), AOMDelay (%d), AOMDuty (%d) "), 
			m_sSystemDump.nDummyShot2,
			m_sSystemDump.nDummyFreq2,
			m_sSystemDump.nDummyInterval2,
			m_sSystemDump.nDummyDuty2,
			m_sSystemDump.nDummyAOMDelay2,
			m_sSystemDump.nDummyAOMDuty2);
		strMessage += strTemp;
	}

	return strMessage;
}

void CPaneSysSetupBeamDumperKunsan8::GetSystemDevice(SSYSTEMDUMP *pSystemDump)
{
	memcpy( pSystemDump, &m_sSystemDump, sizeof(m_sSystemDump) );

/*	pSystemDump->nPtBeanDumper1.x = m_sSystemDump.nPtBeanDumper1.x;
	pSystemDump->nPtBeanDumper1.y = m_sSystemDump.nPtBeanDumper1.y;
	pSystemDump->nPtBeanDumper2.x = m_sSystemDump.nPtBeanDumper2.x;
	pSystemDump->nPtBeanDumper2.y = m_sSystemDump.nPtBeanDumper2.y;

	pSystemDump->nDummyShot = m_sSystemDump.nDummyShot;
	pSystemDump->nDummyInterval = m_sSystemDump.nDummyInterval;
	pSystemDump->nDummyFreq = m_sSystemDump.nDummyFreq;
	pSystemDump->nDummyDuty = m_sSystemDump.nDummyDuty;
	pSystemDump->nDummyAOMDelay = m_sSystemDump.nDummyAOMDelay;
	pSystemDump->nDummyAOMDuty = m_sSystemDump.nDummyAOMDuty;
*/
}


BOOL CPaneSysSetupBeamDumperKunsan8::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Dumper) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
