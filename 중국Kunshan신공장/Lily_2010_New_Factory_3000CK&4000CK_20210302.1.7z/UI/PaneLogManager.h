#if !defined(AFX_PANELOGMANAGER_H__8BF94398_ACE8_4C7F_81EE_417B68B82E67__INCLUDED_)
#define AFX_PANELOGMANAGER_H__8BF94398_ACE8_4C7F_81EE_417B68B82E67__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManager.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManager form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class CPaneLogManagerLog;
class CPaneLogManagerLot;
class CPaneLogManagerLaserPower;
class CPaneLogManagerFiducialScale;
class CPaneLogManagerJobTime;
class CPaneLogManagerOffset;

class CPaneLogManager : public CFormView
{
protected:
	CPaneLogManager();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManager)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManager)
	enum { IDD = IDD_DLG_LOG_MANAGER };
	USimpleTab	m_tabLog;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		InitTabControl();

	int			m_nPaneNo;
	CPaneLogManagerLaserPower*	m_pLaserPower;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManager)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManager();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	CPaneLogManagerLog*			m_pLog;
	CPaneLogManagerLot*			m_pLot;
	
	CPaneLogManagerFiducialScale* m_pFiducialScale;
	CPaneLogManagerJobTime*		m_pJobTime;
	CPaneLogManagerOffset*		m_pOffset;

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManager)
	afx_msg void OnClickTabLogManager(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELOGMANAGER_H__8BF94398_ACE8_4C7F_81EE_417B68B82E67__INCLUDED_)
