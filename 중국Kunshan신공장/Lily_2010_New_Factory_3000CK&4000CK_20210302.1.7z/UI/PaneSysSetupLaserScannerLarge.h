#if !defined(AFX_PANESYSSETUPLASERSCANNERLARGE_H__09CA3B50_3A61_4A69_92B0_B9095F536EB0__INCLUDED_)
#define AFX_PANESYSSETUPLASERSCANNERLARGE_H__09CA3B50_3A61_4A69_92B0_B9095F536EB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupLaserScannerLarge.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerLarge form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "ColorEdit.h"

class CPaneSysSetupLaserScannerLarge : public CFormView
{
protected:
	CPaneSysSetupLaserScannerLarge();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupLaserScannerLarge)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupLaserScannerLarge)
	enum { IDD = IDD_DLG_SYS_SETUP_LASER_HOLE_LARGE };
	CColorEdit	m_edtFrequency;
	CColorEdit	m_edtCurrent;
	CColorEdit	m_edtThermalTrack;
	CColorEdit	m_edtScannerY;
	CColorEdit	m_edtScannerX;
	CColorEdit	m_edtPulseWidth;
	CColorEdit	m_edtShotNo;
	CColorEdit	m_edtAOMDelay;
	CColorEdit	m_edtAOMDuty;
	CColorEdit	m_edtAOMProfilePath;

	UEasyButton	m_btnScannerLine;
	UEasyButton	m_btnMainShtOpen;
	UEasyButton	m_btnMainShtClose;
	UEasyButton	m_btn2ndPanelShtOpen;
	UEasyButton	m_btn2ndPanelShtClose;
	UEasyButton	m_btn1stPanelShtOpen;
	UEasyButton	m_btn1stPanelShtClose;
	UEasyButton	m_btnPDetectorShtOpen;
	UEasyButton	m_btnPDetectorShtClose;
	UEasyButtonEx m_btnLaserDlgShow;
	UEasyButtonEx m_btnAttenMove;
	UEasyButtonEx m_btnAttenHome;
	UEasyButtonEx m_chkUseTophat;
	UEasyButtonEx m_chkUseShotCount;
	UEasyButtonEx m_chkBeamPass;
	UEasyButton	m_btnAOMOpen;
	UEasyButtonEx m_chkApplyAsc;


	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnMove2;
	UEasyButtonEx	m_btnManualSCalPosMove;
	UEasyButtonEx	m_btnMPG;
	CColorEdit	m_edtTargetZ2;
	CColorEdit	m_edtTargetZ1;
	CColorEdit	m_edtTargetM;
	CColorEdit	m_edtTargetM2;
	CColorEdit	m_edtTargetM3;
	CColorEdit	m_edtTargetC;
	CColorEdit  m_edtTargetA;
	CColorEdit	m_edtTargetC2;
	CColorEdit	m_edtTargetA2;

	CColorEdit	m_edtTargetZ2_2;
	CColorEdit	m_edtTargetZ1_2;
	CColorEdit	m_edtTargetC1_2;
	CColorEdit	m_edtTargetC2_2;

	UEasyButtonEx	m_btnLpcGet;
	UEasyButtonEx	m_btnLpcVerify;
	UEasyButtonEx	m_btnLpcStop;

	int		m_nAbs;
	BOOL	m_bTargetZ1;
	BOOL	m_bTargetZ2;
	BOOL	m_bTargetC;
	BOOL	m_bTargetC2;
	BOOL	m_bTargetM;
	BOOL	m_bTargetM2;
	BOOL	m_bTargetM3;
	
	//2011520
	BOOL	m_bTargetA;
	BOOL	m_bTargetA2;

	CColorEdit	m_edt1stAOMOffset;
	CColorEdit	m_edt2ndAOMOffset;
	CColorEdit	m_edtVoltage1;
	CColorEdit	m_edtVoltage2;

	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	int			m_nMPGMode;
	
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	CFont		m_fntEdit;

	BOOL		m_bMainSht;
	BOOL		m_b1stSht;
	BOOL		m_b2ndSht;

	int			m_nLaserMode;
	double		m_dPulseMax;
	double		m_dPulseMin;
	BOOL		m_bIsLaserOn;
	BOOL		m_bIsLaserOnFire;
	BOOL		m_bStopFire;
	BOOL		m_bLPCStop;
	BOOL		m_bLastSignal;
	BOOL		m_bUseButtonFire;
	BOOL		m_bScannerPos[9];
	int			m_nTimerID;

	unsigned short	m_usOldPulseWidth;
	unsigned    m_usOldFrequency;

	BOOL		m_bUseSelfShot;
	int			m_nOld2ndAOMOffset;
	int			m_nOld1stAOMOffset;
	int			m_nUserLevel;
// Operations
public:
	BOOL		SaveLPCFile(int nMinTime, int nMinDuty, int nTimeNo, int nDutyNo, double* pdValMin, double* pdValMax);
	void ResetScannerBtn();
	int GetMPGMode();
	double GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse);
	void		InitBtnControl();
	void		InitStaticControl();
	void		InitEditControl();

	void		SetShutterStatus();
	void		StopExternalLaser();
	BOOL		CheckPulseWidth();
	void		MessageLoop();
	
	BOOL		CheckParam();

	void		EnableAllButton(BOOL bEnable = TRUE);
	void		EnableButton(BOOL bUse);

	void		SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupLaserScannerLarge)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupLaserScannerLarge();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupLaserScannerLarge)
	afx_msg void OnButtonMainShtOpen();
	afx_msg void OnButtonMainShtClose();
	afx_msg void OnButton1stPanelShtOpen();
	afx_msg void OnButton1stPanelShtClose();
	afx_msg void OnButton2ndPanelShtOpen();
	afx_msg void OnButton2ndPanelShtClose();
	afx_msg void OnButtonScannerLine();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonMove();
	afx_msg void OnButtonMove2();
	afx_msg void OnButtonManualSCalPosMove();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonMpgMode();
	afx_msg void OnButtonOpenLaserDlg(); 
	afx_msg void OnButtonMoveAtten();
	afx_msg void OnButtonHomeAtten();
	afx_msg void OnButtonAomProfile();
	afx_msg void OnButtonPowerDetectorOn();
	afx_msg void OnButtonPowerDetectorOff();
	afx_msg void OnButtonPos0();
	afx_msg void OnButtonPos1();
	afx_msg void OnButtonPos2();
	afx_msg void OnButtonPos3();
	afx_msg void OnButtonPos4();
	afx_msg void OnButtonPos5();
	afx_msg void OnButtonPos6();
	afx_msg void OnButtonPos7();
	afx_msg void OnButtonPos8();
	afx_msg void OnCheckApplyAscFile();
	afx_msg void OnButtonGetLpcData();
	afx_msg void OnButLpcDist();
	afx_msg void OnButtonGetLpcStop();
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnClickedCheckSubUseTophat3();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPLASERSCANNERLARGE_H__09CA3B50_3A61_4A69_92B0_B9095F536EB0__INCLUDED_)
