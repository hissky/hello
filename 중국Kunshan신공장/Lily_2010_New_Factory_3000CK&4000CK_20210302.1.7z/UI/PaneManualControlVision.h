#if !defined(AFX_PANEMANUALCONTROLVISION_H__2554E22F_74AF_43F5_B3C6_AACC1699B170__INCLUDED_)
#define AFX_PANEMANUALCONTROLVISION_H__2554E22F_74AF_43F5_B3C6_AACC1699B170__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlVision.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlVision form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "UEasyButton.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\device\hvisionomi.h"
//#include "..\model\DProject.h"

#define EXTEND_DISPLAY	250

class CPaneManualControlVision : public CFormView
{
protected:
	CPaneManualControlVision();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlVision)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlVision)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_VISION };
	CListBox	m_lboxResult;
	CStatic	m_stcPic;
	CColorEdit	m_edtContrast;
	CColorEdit	m_edtBrightness;
	CColorEdit	m_edtRing;
	CColorEdit	m_edtIR;
	CColorEdit	m_edtCoaxial;
	CColorEdit	m_edtAspectRatio;
	CColorEdit	m_edtAngle;
	CColorEdit	m_edtSize;
	CColorEdit	m_edtOrientation;
	CColorEdit	m_edtSizeC;
	CColorEdit	m_edtSizeB;
	CColorEdit	m_edtSizeA;
	CColorEdit	m_edtPath;
	CColorEdit	m_edtThreshold;
	CColorEdit	m_edtBlob;
	CColorEdit	m_edt2DBarcodeResult;

	CColorStatic	m_stcInspResult;
	UEasyButtonEx	m_chkInspArea;
	CComboBox	m_cmbType;
	CComboBox	m_cmbCamNo;
	UEasyButtonEx	m_btnTrain;
	UEasyButtonEx	m_btnTrainRegion;
	UEasyButtonEx	m_btnTest;
	UEasyButtonEx	m_btnMore;
	UEasyButton		m_btnLive;
	UEasyButtonEx	m_btnImgSave;
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnTrigger;
	UEasyButtonEx	m_btnTriggerAgc;
	UEasyButtonEx	m_btnShowDialog;
	UEasyButtonEx	m_btnOpenProject;
	UEasyButtonEx	m_btnSaveProject;
	CColorEdit		m_edtProjectPath;
	int		m_nPolarity;
	int		m_nRemote;
	UEasyButtonEx	m_btnJobFile;
	UEasyButtonEx	m_btnInit2D;
	UEasyButtonEx	m_btnGet2D;
	UEasyButtonEx	m_btnVerify2D;
	UEasyButtonEx	m_btnTableLimitMinSetting;
	UEasyButtonEx	m_btnTableLimitMaxSetting;
	UEasyButtonEx	m_btn2DBarcode;
	UEasyButtonEx	m_btn2DBarcodeUnload;
	UEasyButtonEx	m_btnImageTest;
	UEasyButtonEx	m_btnImageLoad;
	CSliderCtrl     m_SliderCoaxial;
	CSliderCtrl     m_SliderRing;
	CSliderCtrl     m_SliderIR;
	
	//}}AFX_DATA

// Attributes
public:
	CString			m_strPath;
	BOOL			m_bSetTrainRegion;
	SVISIONINFO		m_sVisionInfo;
// Attributes
protected:
	CFont			m_fntBtn;
	CFont			m_fntBtn2;
	CFont			m_fntBtn3;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntEdit2;
	CFont			m_fntCombo;
	CFont			m_fntListBox;

	BOOL			m_bIsLive;
	int				m_nModelType;
	BOOL			m_bMore;

	CBitmap			m_imgAnnulus;
	CBitmap			m_imgCircle;
	CBitmap			m_imgCross;
	CBitmap			m_imgDiamond;
	CBitmap			m_imgDouble;
	CBitmap			m_imgRect;
	CBitmap			m_imgTriangle;
	CBitmap			m_imgUserImage;

	//FIDINFO			m_sFidInfo;
	int				m_nCoaxial[4];
	int				m_nRing[4];
	int				m_nIR[4];
//	int				m_nBlob[4];
	double			m_dContrast[4];
	double			m_dBrightness[4];
	int				m_nFidKind;
	int				m_nTimerID;
// Operations
public:
	void SetAuthorityByLevel(int nLevel);
	int m_nOldMotorMode;
	void InitTimer();
	void DestroyTimer();
	void			GetSelIndex(int& nIndex, int& nCam);
	void			GetDispParam(SVISIONINFO* pVisionInfo, int nSel, int nCamNo);
	void			ChangeDisplay(int nSel, int nCamNo);
	void			EnableButton(BOOL bEnable);
	void			DPHoleInfo(CString str);
	int				GetCameraNo();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitComboControl();
	void			InitListBoxControl();
	void			InitSlideControl();
	void			InitBitmap();
	void			SetvisionParam(VISION_INFO sVisionParam);
	void			SelectPic(int nType);
	void			SetValue(int nNumber);

	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			ResetLive();
	BOOL			GetIsLive()		{ return m_bIsLive; }
	void			OnMoveVisionView();

	BOOL			ValidateValue();
	
	void			SetVisionInfo();

	void			SetFiducial(BOOL bSetFid);

	void			VisionSetting(int nFidKind);
	int				VisionParameterSetting(int nFidKind, int nIndex);

	void			ChangeControl(BOOL bUse);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlVision)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlVision();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlVision)
	afx_msg void OnButtonApply();
	afx_msg void OnInspectionArea();
	afx_msg void OnButtonLive();
	afx_msg void OnButtonImgSave();
	afx_msg void OnSelchangeComboType();
	afx_msg void OnButtonMore();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonTest();
	afx_msg void OnButtonTrain();
	afx_msg void OnButtonImageTest();
	afx_msg void OnButtonImgaeLoad();
	afx_msg void OnSelchangeComboCamNo();
	afx_msg void OnChangeEditCoaxial();
	afx_msg void OnChangeEditContrast();
	afx_msg void OnChangeEditRing();
	afx_msg void OnChangeEditIR();
	afx_msg void OnChangeEditBrightness();
	afx_msg void OnKillfocusEdit();
	afx_msg void OnButtonJobFileOpen();
	afx_msg void OnButtonTrigger();
	afx_msg void OnButtonTriggerAgc();
	afx_msg void OnButtonShowDialog();
	afx_msg LRESULT ChangeVisionParameter(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButtonOpen();
	afx_msg void OnButtonSave();
	afx_msg void OnButtonTrainRegion();
	afx_msg void OnButtonThreshold();
	afx_msg void OnButtonGet2dpixel();
	afx_msg void OnButtonInit2dpixel();
	afx_msg void OnButtonProof2dpixcel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnTableLimitMin();
	afx_msg void OnBnClickedBtnTableLimitMax();
//	afx_msg void OnEnKillfocusEditBlob();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButton2dbarcode();
	afx_msg void OnBnClickedButton2dbarcodeUnload();
	afx_msg void OnRadioRemote();
	afx_msg void OnRadioManual();
	afx_msg void OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLVISION_H__2554E22F_74AF_43F5_B3C6_AACC1699B170__INCLUDED_)
