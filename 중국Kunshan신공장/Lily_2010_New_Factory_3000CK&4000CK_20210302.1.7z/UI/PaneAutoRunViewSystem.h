#if !defined(AFX_PANEAUTORUNVIEWSYSTEM_H__0E2D8B7C_93E1_4ED9_A722_14429447CD4B__INCLUDED_)
#define AFX_PANEAUTORUNVIEWSYSTEM_H__0E2D8B7C_93E1_4ED9_A722_14429447CD4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewSystem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewSystem form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "..\model\DSystemINI.h"

class CPaneAutoRunViewSystem : public CFormView
{
protected:
	CPaneAutoRunViewSystem();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewSystem)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewSystem)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_SYSTEM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;
	SSYSTEMDUMP m_sSystemDump;
// Operations
public:
	void SetSystemData(SSYSTEMDUMP sSystemDump);
	void ChangeDisplay();
	void InitStatic();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewSystem)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewSystem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewSystem)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
		//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWSYSTEM_H__0E2D8B7C_93E1_4ED9_A722_14429447CD4B__INCLUDED_)
