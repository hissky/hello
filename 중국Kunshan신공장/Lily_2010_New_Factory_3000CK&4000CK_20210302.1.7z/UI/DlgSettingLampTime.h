#if !defined(AFX_DLGSETTINGLAMPTIME_H__84EB1A56_2EFA_49A9_A603_C6ACC0E0F9CB__INCLUDED_)
#define AFX_DLGSETTINGLAMPTIME_H__84EB1A56_2EFA_49A9_A603_C6ACC0E0F9CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSettingLampTime.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingLampTime dialog

#include "UI\UnitEdit.h"
//#include "..\Device\HLaserQuanta.h"
class HLaserQuanta;

class CDlgSettingLampTime : public CDialog
{
// Construction
public:
	CDlgSettingLampTime(CWnd* pParent = NULL);   // standard constructor
	void setPowerDevice(HLaserQuanta* pPowerSupply);
	HLaserQuanta* getPowerDevice();
	
	void EnableEditUseTime(bool bEnable = true);
	

// Dialog Data
	//{{AFX_DATA(CDlgSettingLampTime)
	enum { IDD = IDD_POWER_LAMPTIME_SETTING };
	double	m_dAlarmTime;
	double	m_dErrorTime;
	double	m_dSetTime;

	CUnitEdit m_edtAlarmTime;
	CUnitEdit m_edtErrorTime;
	CUnitEdit m_edtSetTime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSettingLampTime)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void initControls();

	HLaserQuanta* m_pPowerSupply;
	bool m_bEnableEditUseTime;
	// Generated message map functions
	//{{AFX_MSG(CDlgSettingLampTime)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSETTINGLAMPTIME_H__84EB1A56_2EFA_49A9_A603_C6ACC0E0F9CB__INCLUDED_)
