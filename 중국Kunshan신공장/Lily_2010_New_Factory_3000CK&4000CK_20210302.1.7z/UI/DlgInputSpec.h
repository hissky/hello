#if !defined(AFX_DLGINPUTSPEC_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
#define AFX_DLGINPUTSPEC_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

// CDlgInputSpec ��ȭ �����Դϴ�.

class CDlgInputSpec : public CDialog
{

public:
	CDlgInputSpec(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.

	void		InitControl();
	void		SetInputLot(CString strSpec)	{ m_strInputSpec = strSpec; }
	CString			GetInputLot()			{ return m_strInputSpec; }


// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_INPUT_SPEC };

	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnCancel;
	CColorEdit	m_edtStartNo;
	CColorEdit	m_edtInputLot;
public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

protected:

	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CString			m_strInputSpec;
	int				m_nStartNo;

	// Generated message map functions
	//{{AFX_MSG(CDlgInputSpec)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP();

};
#endif