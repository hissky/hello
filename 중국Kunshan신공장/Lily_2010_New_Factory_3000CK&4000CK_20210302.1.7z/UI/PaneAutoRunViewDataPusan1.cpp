// PaneAutoRunViewDataPusan1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewDataPusan1.h"
#include "..\model\DProject.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HLaser.h"
#include "..\device\DeviceMotor.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#include "..\alarmmsg.h"
#include "..\Model\DProcessINI.h"
#include "PaneAutoRun.h"
#include "..\device\HMotor.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const UINT TIMER_UPDATE_DISPLAY = 1000;
/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewDataPusan1

IMPLEMENT_DYNCREATE(CPaneAutoRunViewDataPusan1, CFormView)

CPaneAutoRunViewDataPusan1::CPaneAutoRunViewDataPusan1()
	: CFormView(CPaneAutoRunViewDataPusan1::IDD)
{

	m_bMotor = FALSE;
	m_bLaser = FALSE;
	m_bEStop = FALSE;
	m_bTableSuction = FALSE;
	m_bTableSuction2 = FALSE;
	m_bVacuumMotor = FALSE;
	m_bInit = FALSE;
	m_bFluorescentLamp = FALSE;
	m_bAutoRun = FALSE;
	m_bMainPower = FALSE;
	m_bClamp = FALSE;
	m_bClamp2 = FALSE;
	m_bViewerMoveMode = TRUE;
	m_nTimer = 0;
	
	m_ptMoveStart.x = 0;
	m_ptMoveStart.y = 0;
	m_bDrawMoveStart = FALSE;
	m_ptDrawRectBack1.x = m_ptDrawRectBack1.y = 0;
	m_ptDrawRectBack2.x = m_ptDrawRectBack2.y = 0;
	m_ptDrawStart.x = m_ptDrawStart.y = 0;
	m_bDrillRun = FALSE;
}

CPaneAutoRunViewDataPusan1::~CPaneAutoRunViewDataPusan1()
{
}

void CPaneAutoRunViewDataPusan1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewDataPusan1)
	DDX_Control(pDX, IDC_BUTTON_UNLOADING, m_btnUnloading);
	DDX_Control(pDX, IDC_BUTTON_LOADING, m_btnLoading);
	DDX_Control(pDX, IDC_BUTTON_CHANGE_BOARD1, m_btnChangeBoard);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_POS, m_btnUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_UC_TABLE, m_btnUCTable);
	DDX_Control(pDX, IDC_BUTTON_UC_CART, m_btnUCCart);
	DDX_Control(pDX, IDC_BUTTON_LOAD_POS, m_btnLoadPos);
	DDX_Control(pDX, IDC_BUTTON_LC_TABLE, m_btnLCTable);
	DDX_Control(pDX, IDC_BUTTON_LC_CART, m_btnLCCart);
	DDX_Control(pDX, IDC_BUTTON_VIEW_VACUUM, m_btnVacuumViewer);
	DDX_Control(pDX, IDC_BUTTON_ALL_REJECT, m_btnAllReject);
	DDX_Control(pDX, IDC_CHECK_MAIN_POWER, m_ledMainPower);
	DDX_Control(pDX, IDC_CHECK_LASER, m_ledLaser);
	DDX_Control(pDX, IDC_CHECK_E_STOP2, m_ledEStop);
	DDX_Control(pDX, IDC_CHECK_AUTO_RUN2, m_ledAutoRun);
	DDX_Control(pDX, IDC_CHECK_MOTOR2010, m_ledMotor);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION, m_ledTableSuction);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION2, m_ledTableSuction2);
	DDX_Control(pDX, IDC_CHECK_TABLE_VACUUM_MOTOR, m_ledVacuumMotor);
	DDX_Control(pDX, IDC_CHECK_INITIALIZATION, m_ledInit);
	DDX_Control(pDX, IDC_CHECK_FLUORESCENT_LAMP, m_ledFluorescentLamp);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_ledClamp);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_ledClamp2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewDataPusan1, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewDataPusan1)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_VIEW_VACUUM, OnButtonViewVacuum)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_UC_CART, OnButtonUcCart)
	ON_BN_CLICKED(IDC_BUTTON_UC_TABLE, OnButtonUcTable)
	ON_BN_CLICKED(IDC_BUTTON_LC_TABLE, OnButtonLcTable)
	ON_BN_CLICKED(IDC_BUTTON_LC_CART, OnButtonLcCart)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_POS, OnButtonUnloadPos)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POS, OnButtonLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADING, OnButtonLoading)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADING, OnButtonUnloading)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_BOARD1, OnButtonChangeBoard1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION, OnCheckTableSuction)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION2, OnCheckTableSuction2)
	ON_BN_CLICKED(IDC_CHECK_TABLE_VACUUM_MOTOR, OnCheckVacuumMotor)
	ON_BN_CLICKED(IDC_CHECK_FLUORESCENT_LAMP, OnCheckFluorescentLamp)
	ON_BN_CLICKED(IDC_BUTTON_ALL_REJECT, OnButtonAllReject)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP1, OnCheckTableClamp)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP2, OnCheckTableClamp2)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_CANCELMODE()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewDataPusan1 diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewDataPusan1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewDataPusan1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewDataPusan1 message handlers

void CPaneAutoRunViewDataPusan1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitBtnControl();
	InitTimer();
	m_dlgVacuumViewer.Create(IDD_DLG_VACUUM_VIEWER);
	m_dlgVacuumViewer.ShowWindow(SW_HIDE);

	if(gSystemINI.m_sHardWare.bTableVacuumSelect)
		m_ledVacuumMotor.ShowWindow(SW_SHOW);
	else
		m_ledVacuumMotor.ShowWindow(SW_HIDE);

#ifdef __KUNSAN_1__
	m_ledClamp.ShowWindow(SW_HIDE);
	m_ledClamp2.ShowWindow(SW_HIDE);
	m_ledClamp.EnableWindow(FALSE);
	m_ledClamp2.EnableWindow(FALSE);
#endif
	
}

BOOL CPaneAutoRunViewDataPusan1::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

HBRUSH CPaneAutoRunViewDataPusan1::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_DEVICE_STATUS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR)->GetSafeHwnd() == pWnd->m_hWnd  ||
		GetDlgItem(IDC_STATIC_COMMAND)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0,0, 255) );

	if(GetDlgItem(IDC_STATIC_DRY_RUN)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );

	if(GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );

	if(GetDlgItem(IDC_STATIC_NO_SUCTION)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewDataPusan1::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	m_fntStaticBig.CreatePointFont(170, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_DEVICE_STATUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOTOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COMMAND)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOADER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOADER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VALUE)->SetFont( &m_fntStatic );

	
	GetDlgItem(IDC_STATIC_DRY_RUN)->SetFont( &m_fntStaticBig );
	GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->SetFont( &m_fntStaticBig );
	GetDlgItem(IDC_STATIC_NO_SUCTION)->SetFont( &m_fntStaticBig );
}

void CPaneAutoRunViewDataPusan1::InitBtnControl()
{
	m_fntBtn.CreatePointFont(90, "Arial Bold");
	
	//Unloading pos
	m_btnUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadPos.SetFlat( FALSE );
	m_btnUnloadPos.EnableBallonToolTip();
	m_btnUnloadPos.SetToolTipText( _T("Move Table to Unloading Position") );
	m_btnUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPos.SetBtnCursor(IDC_HAND_1);

	//Loading Pos
	m_btnLoadPos.SetFont( &m_fntBtn );
	m_btnLoadPos.SetFlat( FALSE );
	m_btnLoadPos.EnableBallonToolTip();
	m_btnLoadPos.SetToolTipText( _T("Move Table to Loading Position") );
	m_btnLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPos.SetBtnCursor(IDC_HAND_1);

	//Unload To Cart
	m_btnUCCart.SetFont( &m_fntBtn );
	m_btnUCCart.SetFlat( FALSE );
	m_btnUCCart.EnableBallonToolTip();
	m_btnUCCart.SetToolTipText( _T("Move Unload Carrier to Cart Position") );
	m_btnUCCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCCart.SetBtnCursor(IDC_HAND_1);

	//Unload To Table
	m_btnUCTable.SetFont( &m_fntBtn );
	m_btnUCTable.SetFlat( FALSE );
	m_btnUCTable.EnableBallonToolTip();
	m_btnUCTable.SetToolTipText( _T("Move Unload Carrier to Table Position") );
	m_btnUCTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCTable.SetBtnCursor(IDC_HAND_1);

	//Load To Table
	m_btnLCTable.SetFont( &m_fntBtn );
	m_btnLCTable.SetFlat( FALSE );
	m_btnLCTable.EnableBallonToolTip();
	m_btnLCTable.SetToolTipText( _T("Move Load Carrier to Table Position") );
	m_btnLCTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCTable.SetBtnCursor(IDC_HAND_1);

	//Load To Cart
	m_btnLCCart.SetFont( &m_fntBtn );
	m_btnLCCart.SetFlat( FALSE );
	m_btnLCCart.EnableBallonToolTip();
	m_btnLCCart.SetToolTipText( _T("Move Load Carrier to Cart Position") );
	m_btnLCCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCCart.SetBtnCursor(IDC_HAND_1);

	// Vacuum Viewer
	m_btnVacuumViewer.SetFont( &m_fntBtn );
	m_btnVacuumViewer.SetFlat( FALSE );
	m_btnVacuumViewer.EnableBallonToolTip();
	m_btnVacuumViewer.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnVacuumViewer.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumViewer.SetBtnCursor(IDC_HAND_1);

	// Vacuum Viewer
	m_btnLoading.SetFont( &m_fntBtn );
	m_btnLoading.SetFlat( FALSE );
	m_btnLoading.EnableBallonToolTip();
	m_btnLoading.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnLoading.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoading.SetBtnCursor(IDC_HAND_1);
	
	// Unloading
	m_btnUnloading.SetFont( &m_fntBtn );
	m_btnUnloading.SetFlat( FALSE );
	m_btnUnloading.EnableBallonToolTip();
	m_btnUnloading.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnUnloading.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloading.SetBtnCursor(IDC_HAND_1);
	
	// Change Board
	m_btnChangeBoard.SetFont( &m_fntBtn );
	m_btnChangeBoard.SetFlat( FALSE );
	m_btnChangeBoard.EnableBallonToolTip();
	m_btnChangeBoard.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnChangeBoard.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeBoard.SetBtnCursor(IDC_HAND_1);

	// All Reject
	m_btnAllReject.SetFont( &m_fntBtn );
	m_btnAllReject.SetFlat( FALSE );
	m_btnAllReject.EnableBallonToolTip();
	m_btnAllReject.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnAllReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAllReject.SetBtnCursor(IDC_HAND_1);


	// Motor
	m_ledMotor.SetFont( &m_fntBtn );
	m_ledMotor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMotor.Depress( TRUE );
	

	// Laser
	m_ledLaser.SetFont( &m_fntBtn );
	m_ledLaser.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaser.Depress( TRUE );
	
	// Main Power
	m_ledMainPower.SetFont( &m_fntBtn );
	m_ledMainPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainPower.Depress( TRUE );
	
	// E-Stop
	m_ledEStop.SetFont( &m_fntBtn );
	m_ledEStop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledEStop.Depress( TRUE );
	
	// Table Suction1
	m_ledTableSuction.SetFont( &m_fntBtn );
	m_ledTableSuction.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction.Depress( TRUE );
//	m_ledTableSuction.SetCursor(IDC_HAND_1);
	
	// Table Suction2
	m_ledTableSuction2.SetFont( &m_fntBtn );
	m_ledTableSuction2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction2.Depress( TRUE );
//	m_ledTableSuction2.SetBtnCursor(IDC_HAND_1);

	// Vacuum Motor
	m_ledVacuumMotor.SetFont( &m_fntBtn );
	m_ledVacuumMotor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledVacuumMotor.Depress( TRUE );
//	m_ledVacuumMotor.SetBtnCursor(IDC_HAND_1);
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		m_ledTableSuction.SetWindowText("Suction On");
		m_ledTableSuction2.SetWindowText("Suction Off");
	}
	
	// Initialization
	m_ledInit.SetFont( &m_fntBtn );
	m_ledInit.SetImage( IDB_LEDCOLOR, 15 );
	m_ledInit.Depress( TRUE );
	
	// AutoRun
	m_ledAutoRun.SetFont( &m_fntBtn );
	m_ledAutoRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAutoRun.Depress( TRUE );
		
	// Fluorescent Lamp
	m_ledFluorescentLamp.SetFont( &m_fntBtn );
	m_ledFluorescentLamp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledFluorescentLamp.Depress( TRUE );
//	m_ledFluorescentLamp.SetBtnCursor(IDC_HAND_1);

	// Clamp1
	m_ledClamp.SetFont( &m_fntBtn );
	m_ledClamp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledClamp.Depress( TRUE );
//	m_ledClamp.SetBtnCursor(IDC_HAND_1);
	
	// Clamp2
	m_ledClamp2.SetFont( &m_fntBtn );
	m_ledClamp2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledClamp2.Depress( TRUE );
//	m_ledClamp2.SetBtnCursor(IDC_HAND_1);

	if(gSystemINI.m_sHardWare.nTableClamp < 1)
	{
		m_ledClamp.ShowWindow(SW_HIDE);
		m_ledClamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp < 2)
		m_ledClamp2.ShowWindow(SW_HIDE);
}


void CPaneAutoRunViewDataPusan1::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DrawData();
	// Do not call CFormView::OnPaint() for painting messages
}
void CPaneAutoRunViewDataPusan1::DrawData()
{
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	//	SetDCCoord(&BufferDC);
	
	int nPenSize;
	nPenSize = 3;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
//	gDProject.InitialDrawRatio(cRect, 2);
	gDProject.Draw(&BufferDC, cRect, FALSE, 2);
	gDProject.DrawToolInfoRunView(&BufferDC, cRect);
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
}



void CPaneAutoRunViewDataPusan1::OnButtonViewVacuum() 
{
	// TODO: Add your control notification handler code here
/*	CRect rtPos;
	GetDlgItem(IDC_BUTTON_PRODUCT_COUNTER_CLEAR)->GetWindowRect( rtPos );
	
	CRect rcPane;
	rcPane.top		= rtPos.top;
	rcPane.left		= rtPos.left;
	rcPane.right	= rtPos.left + 360;
	rcPane.bottom	= rtPos.top + 300;
	
	m_dlgVacuumViewer.MoveWindow(rcPane);
*/	
#ifndef __MP920_MOTOR__
	m_dlgVacuumViewer.ShowWindow(SW_SHOW);
	m_dlgVacuumViewer.SetMotor(gDeviceFactory.GetMotor());
	m_dlgVacuumViewer.InitTimer();
#endif
}

void CPaneAutoRunViewDataPusan1::UpdateLed()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	// Motor
	m_bMotor = pMotor->IsReady();
	m_ledMotor.Depress( !m_bMotor );
	
	// Laser
	int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	BOOL bAOM = pMotor->GetAOMStatus(); 
	BOOL bScanner = pMotor->GetScannerStatus();

	BOOL bPower, bShutter;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		bPower = nPower;
		bShutter = nShutter;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(nPower & 0x02) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x02)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		if(nPower & 0x03) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x03)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		m_bLaser = gDeviceFactory.GetLaser()->IsFireOK();
	else
		m_bLaser = bPower & bShutter & bAOM & bScanner;

	m_ledLaser.Depress( !m_bLaser );

	m_bClamp = gDeviceFactory.GetMotor()->GetCurrentTableClamp(TRUE, TRUE);
	m_bClamp2 = gDeviceFactory.GetMotor()->GetCurrentTableClamp(FALSE, TRUE);

	m_ledClamp.Depress( !m_bClamp );
	m_ledClamp2.Depress( !m_bClamp2 );

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{	
		// Main Power
		m_bMainPower = pMotor->IsReady();
		m_ledMainPower.Depress( !m_bMainPower );
	
		// E-Stop
		m_bEStop = pMotor->GetCurrentEMStop();
		m_ledEStop.Depress( !m_bEStop );
	
		// Table Suction
		BOOL bMotor, b1st = TRUE, b2nd = TRUE;
		int nSuction1;
		nSuction1 = pMotor->GetCurrentSuction();

		bMotor = pMotor->GetCurrentSuctionMotor();
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
		{
			if((nSuction1 & 0x01) && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;
			
			if((nSuction1 & 0x02) &&bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
		}
		else
		{
			if(nSuction1 & 0x01 && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;

			if(nSuction1 & 0x02 && bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
			
	
		}

		m_bTableSuction = b1st;
		m_ledTableSuction.Depress( !m_bTableSuction );

		m_bTableSuction2 = b2nd;
		m_ledTableSuction2.Depress( !m_bTableSuction2 );

		m_bVacuumMotor = bMotor;
		m_ledVacuumMotor.Depress( !m_bVacuumMotor );
	
		// Initialization
		m_bInit = pMotor->IsInOrigin(-1, FALSE);
		m_ledInit.Depress( !m_bInit );

		// Fluorescent Lamp
		m_bFluorescentLamp = pMotor->IsFluorescentLampOn();
		m_ledFluorescentLamp.Depress( !m_bFluorescentLamp );

		// AutoRun
		BOOL m_bModeNew = pMotor->GetCurrentMode();

		if(m_bModeNew == MODE_AUTO)
			m_bAutoRun = TRUE;
		else
			m_bAutoRun = FALSE;

		m_ledAutoRun.Depress( !m_bAutoRun );

		if(gProcessINI.m_sProcessSystem.bDryRun)
			GetDlgItem(IDC_STATIC_DRY_RUN)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_DRY_RUN)->ShowWindow(SW_HIDE);

		if(gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->ShowWindow(SW_HIDE);

		if(gProcessINI.m_sProcessSystem.bNoUseSuction)
			GetDlgItem(IDC_STATIC_NO_SUCTION)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_NO_SUCTION)->ShowWindow(SW_HIDE);

	}
	
/*	CString str;
	int nValue = pMotor->GetMainAirValue();

	str.Format(_T("Main Air Value : %.1f MPa"), ((nValue - 169) / 670.0) );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VALUE)->SetWindowText(str);

  */
}

void CPaneAutoRunViewDataPusan1::InitTimer()
{
	if(!m_nTimer)
		m_nTimer = SetTimer(TIMER_UPDATE_DISPLAY, 1000, NULL);
}

void CPaneAutoRunViewDataPusan1::DestroyTimer()
{	
	if(m_nTimer)
	{
		KillTimer(m_nTimer);
		m_nTimer = 0;
	}
}

void CPaneAutoRunViewDataPusan1::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
		UpdateLed();
	CFormView::OnTimer(nIDEvent);
}

void CPaneAutoRunViewDataPusan1::OnButtonUcCart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	pMotor->UnloaderCarrierUnloadPos();
}

void CPaneAutoRunViewDataPusan1::OnButtonUcTable() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	pMotor->UnloaderCarrierTablePos();
}

void CPaneAutoRunViewDataPusan1::OnButtonLcTable() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	pMotor->LoaderCarrierLoadPos();
}

void CPaneAutoRunViewDataPusan1::OnButtonLcCart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	gDeviceFactory.GetMotor()->LoaderCarrierCartPos();
}

void CPaneAutoRunViewDataPusan1::OnButtonUnloadPos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
	{
		::ErrMsgDlg(STDGNALM438);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
	}
}

void CPaneAutoRunViewDataPusan1::OnButtonLoadPos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		::ErrMsgDlg(STDGNALM438);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
	}
}

void CPaneAutoRunViewDataPusan1::OnButtonLoading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	int nCmd;
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	if(!pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, TRUE, FALSE ))
	{
		// 110610 Start
		if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
		{
			ErrMessage(_T("Align is in progress.\r\nAlign Command Reject."));
			return;
		}
		// 110610 End
		
		if(pMotor->IsLoadCartNoPCB())
		{
			ErrMessage(_T("There is no PCB in Loader.\r\nAlign Command Reject."));
			return;
		}
		
		UpdateData(TRUE);
		
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
		
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif		
		pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
		
		::Sleep(500);
		
		//	pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, TRUE);
		
		if(!WaitHandler(HANDLER_ALIGNERSTOP))
		{
			if(pMotor->IsLoadCartNoPCB())
			{
				ErrMsgDlg(STDGNALM715);
				return;
			}
			else
			{
				ErrMsgDlg(STDGNALM721);
				return;
			}
		}
	}

	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nLoad Command Reject."));
		return;
	}

/*	if( (gDProject.m_nSeparation == USE_DUAL && (!pMotor->IsLoaderPicker1PCBExist() || !pMotor->IsLoaderPicker2PCBExist())) ||
		(gDProject.m_nSeparation == USE_1ST && !pMotor->IsLoaderPicker1PCBExist()) ||
		(gDProject.m_nSeparation == USE_2ND && !pMotor->IsLoaderPicker2PCBExist()))
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}
*/
	if( gDProject.m_nSeparation == USE_DUAL ||
		gDProject.m_nSeparation == USE_1ST  ||
		gDProject.m_nSeparation == USE_2ND)
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}

	BOOL bRes = FALSE;
	BOOL bTable1 = pMotor->IsTable1PCBExist();
	BOOL bTable2 = pMotor->IsTable2PCBExist();
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction1 = pMotor->GetCurrentSuction();
//	int nSuction2 = pMotor->GetCurrentSuction(FALSE);
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if((nSuction1 & 0x01) && bMotor) b1st = TRUE;
	if((nSuction1 & 0x02) && bMotor) b2nd = TRUE;
	
	switch(nCmd)
	{
	case 0:
		if(!bTable1 && !bTable2 && !b1st && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 1:
		if(!bTable1 && !b1st)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 2:
		if(!bTable2 && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	}

	if(!bRes)
	{
		ErrMessage(_T("There is PCB on Table.\r\nLoading Command Reject."));
		return;
	}

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif

	pMotor->HandlerOperation(HANDLER_LOADER_LOAD);

	::Sleep(500);

	if(!WaitHandler(HANDLER_LOADSTOP))
	{
		::ErrMsgDlg(STDGNALM719);
	}

}

void CPaneAutoRunViewDataPusan1::OnButtonUnloading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}

	if(pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Unloading is in progress.\r\nUnload Command Reject."));
		return;
	}
	
	UpdateData(TRUE);

	int nCmd;
/*	if( (gDProject.m_nSeparation == USE_DUAL && (!pMotor->IsUnloaderPicker1PCBExist() || !pMotor->IsUnloaderPicker2PCBExist())) ||
		(gDProject.m_nSeparation == USE_1ST && !pMotor->IsUnloaderPicker1PCBExist()) ||
		(gDProject.m_nSeparation == USE_2ND && !pMotor->IsUnloaderPicker2PCBExist()))
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}
	else
	{
		ErrMsgDlg(STDGNALM1026);
		return;
	}
	*/
	if( gDProject.m_nSeparation == USE_DUAL ||
		gDProject.m_nSeparation == USE_1ST ||
		gDProject.m_nSeparation == USE_2ND )
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD);

	::Sleep(500);


	if(!WaitHandler(HANDLER_UNLOADSTOP))
	{
		ErrMsgDlg(STDGNALM726);
		return;
	}

	BOOL bNeedUnload = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetNeedUnload();
	if(bNeedUnload)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->SetNeedUnload(FALSE);
}

void CPaneAutoRunViewDataPusan1::OnButtonChangeBoard1() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}

	UpdateData(TRUE);
	EnableControl(FALSE);
	int nCmd;
		
	// Align & Loading 
	if( (gDProject.m_nSeparation == USE_DUAL && (!pMotor->IsLoaderPicker1PCBExist() || !pMotor->IsLoaderPicker2PCBExist())) ||
		(gDProject.m_nSeparation == USE_1ST && !pMotor->IsLoaderPicker1PCBExist()) ||
		(gDProject.m_nSeparation == USE_2ND && !pMotor->IsLoaderPicker2PCBExist()))
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}


#ifdef __PUSAN_LDD__
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#else
	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#endif

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);

	::Sleep(500);

	if(!WaitHandler(HANDLER_ALIGNERSTOP))
	{
		if(pMotor->IsLoadCartNoPCB())
			ErrMsgDlg(STDGNALM715);
		else
			ErrMsgDlg(STDGNALM721);
	}
}

BOOL CPaneAutoRunViewDataPusan1::GetAutoRun()
{
	BOOL bAutoRun;
	bAutoRun = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetAutoRun();

	return bAutoRun;
}


BOOL CPaneAutoRunViewDataPusan1::WaitHandler(int nCmd)
{
	
#ifdef __TEST__
	return TRUE;
#endif
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	int nWaitTime;
	if(nCmd == HANDLER_ALIGNERSTOP)
		nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000 / 50; 
	else if(nCmd == HANDLER_LOADSTOP || nCmd == HANDLER_LOAD_PICKER_DOWN)
		nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 50; 
	else
		nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000 / 50; 
	int nCnt = 0;
	LONG lError = 0;
	do {
		::Sleep(50);
		MessageLoop();
		
		enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
			HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM,
			HANDLER_ALIGNERSTOP, HANDLER_LOADSTOP, HANDLER_UNLOADSTOP, HANDLER_UNLOAD_TO_LOADSTART};		
		
		switch(nCmd)
		{
		case HANDLER_ALIGNERSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
				return TRUE;
			
			// AlignEnd��ٸ��� �� ���Ǻ������� PLC���� ���� ������ Waiting�ߴ�
			lError = pMotor->GetCurrentError(ERROR_OTHERS2);
			if(lError & 0x8000)
				return FALSE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		case HANDLER_LOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		case HANDLER_UNLOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;

#endif
			
			break;
		case HANDLER_UNLOAD_TO_LOADSTART:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;

#endif
			break;
		}
		nCnt++;
		
		if( pMotor->IsAnyError() )
		{
			return FALSE;
		}
		
		if(nCnt > nWaitTime)
		{
			return FALSE;
		}
	} while(TRUE);
	return FALSE;
}
void CPaneAutoRunViewDataPusan1::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CPaneAutoRunViewDataPusan1::SetDrill(BOOL Drill)
{
	m_bDrillRun = !Drill;
	EnableControl(Drill);
}

void CPaneAutoRunViewDataPusan1::EnableControl(BOOL bUse)
{
	m_btnUnloading.EnableWindow(bUse);
	m_btnLoading.EnableWindow(bUse);
	m_btnChangeBoard.EnableWindow(bUse);
	m_btnUnloadPos.EnableWindow(bUse);
//	m_btnUCTable.EnableWindow(bUse);
	m_btnUCCart.EnableWindow(bUse);
	m_btnLoadPos.EnableWindow(bUse);
//	m_btnLCTable.EnableWindow(bUse);
	m_btnLCCart.EnableWindow(bUse);
	m_btnAllReject.EnableWindow(bUse);
//	m_btnVacuumViewer.EnableWindow(bUse);
	
	m_ledTableSuction.EnableWindow(bUse);
	m_ledTableSuction2.EnableWindow(bUse);
	m_ledClamp.EnableWindow(bUse);
	m_ledClamp2.EnableWindow(bUse);
	m_ledVacuumMotor.EnableWindow(bUse);
}

void CPaneAutoRunViewDataPusan1::OnCheckTableSuction() 
{
	if(m_bDrillRun)
		return;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	BOOL bSuction = pMotor->GetCurrentSuction();
#ifndef __MP920_MOTOR__

	if(bSuction & 0x01)
	{
		pMotor->WriteOutputIOBIt(2, 1, FALSE);
		pMotor->WriteOutputIOBIt(2, 0, TRUE);
	}
	else
	{
		pMotor->WriteOutputIOBIt(2, 1, TRUE);
		pMotor->WriteOutputIOBIt(2, 0, FALSE);
	}
#else
	if( FALSE == m_bTableSuction && FALSE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 0 );
	else if( TRUE == m_bTableSuction && FALSE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 1 );
	else if( FALSE == m_bTableSuction && TRUE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 2 );
	else // TRUE, TRUE
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 3 );
#endif
}

void CPaneAutoRunViewDataPusan1::OnCheckTableSuction2() 
{
	if(m_bDrillRun)
		return;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	BOOL bSuction = pMotor->GetCurrentSuction();
#ifndef __MP920_MOTOR__
	if(bSuction & 0x02)
	{
		pMotor->WriteOutputIOBIt(2, 2, FALSE);
		pMotor->WriteOutputIOBIt(2, 3, TRUE);
	}
	else
	{	
		pMotor->WriteOutputIOBIt(2, 2, TRUE);
		pMotor->WriteOutputIOBIt(2, 3, FALSE);
	}
#else
	if( FALSE == m_bTableSuction && FALSE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 0 );
	else if( TRUE == m_bTableSuction && FALSE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 1 );
	else if( FALSE == m_bTableSuction && TRUE == m_bTableSuction2 )
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 2 );
	else // TRUE, TRUE
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 3 );
#endif
}

void CPaneAutoRunViewDataPusan1::OnCheckVacuumMotor() 
{
	if(m_bDrillRun)
		return;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	if(bMotor)
	{
		pMotor->Table1VacuumMotor(FALSE);
	}
	else
	{
		pMotor->Table1VacuumMotor(TRUE);
	}
	
}


void CPaneAutoRunViewDataPusan1::OnCheckFluorescentLamp() 
{
	BOOL bOn = gDeviceFactory.GetMotor()->IsFluorescentLampOn();
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(bOn)
		pMotor->SetOutPort(PORT_LAMP, FALSE);
	else
		pMotor->SetOutPort(PORT_LAMP, TRUE);
}

void CPaneAutoRunViewDataPusan1::OnButtonAllReject() 
{
	// TODO: Add your control notification handler code here
	// 110610
	EnableControl(FALSE);
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(3000);
#endif
#ifdef __PUSAN2__
	gDeviceFactory.GetMotor()->LoaderPCBReset();
	gDeviceFactory.GetMotor()->UnLoaderPCBReset();
#endif
	EnableControl(TRUE);
}
void CPaneAutoRunViewDataPusan1::OnCheckTableClamp()
{
	if(m_bDrillRun)
		return;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	if(m_bClamp)
		pMotor->TableClamp(FALSE, TRUE);
	else
		pMotor->TableClamp(TRUE, TRUE);
}
void CPaneAutoRunViewDataPusan1::OnCheckTableClamp2()
{
	if(m_bDrillRun)
		return;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(m_bClamp2)
		pMotor->TableClamp(FALSE, FALSE);
	else
		pMotor->TableClamp(TRUE, FALSE);
}

void CPaneAutoRunViewDataPusan1::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
//		if(IsPickToolVisible(tempP))
//			return;

		GetDlgItem(IDC_STC_RUN_VIEW)->SetFocus();
	}
	else
		return;

	m_ptDrawStart = tempP;
	m_ptMoveStart = tempP;
	m_bDrawMoveStart = TRUE;
	
	if(!m_bViewerMoveMode)
	{
		DrawSelectionRect(&dc, m_ptDrawStart, m_ptDrawStart);
	}
	CFormView::OnLButtonDown(nFlags, point);
}

BOOL CPaneAutoRunViewDataPusan1::IsPickToolVisible(CPoint ptPick)
{
	
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	int nYstart = 5, nEndY;
	int nStartX, nEndX;
	nStartX = cRect.right - 60;
	nEndX = cRect.right - 5;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(gDProject.m_pToolCode[i]->m_bUseTool)
		{
			nEndY = nYstart + 18;
			if(ptPick.x <= nEndX && ptPick.x >= nStartX &&
				ptPick.y <=nEndY && ptPick.y >= nYstart)
			{
				if(gDProject.m_pToolCode[i]->m_bVisible && i != 0)
				{
					gDProject.m_pToolCode[i]->m_bVisible = FALSE; // apply click ���� ����
				}
				else
				{
					gDProject.m_pToolCode[i]->m_bVisible = TRUE; // apply click ���� ����
				}
				Invalidate(FALSE);
				return TRUE;
			}
			
			nYstart += 20;
		}
	}
	
	return FALSE;
}

BOOL CPaneAutoRunViewDataPusan1::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
		CRect cRect;
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Drill_Data) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
 		{

			case 77:	// M
			case 109:	// m : mode change : select mode <-> viwer move mode
//				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
//					return TRUE;

				if(m_bViewerMoveMode)
					m_bViewerMoveMode = FALSE;
				else
					m_bViewerMoveMode = TRUE;
				return TRUE;
			case 70 :	// F
			case 102 :  // f : show sort index

	/*			if((gDProject.m_nDataLoadStep & 0x0b) < FIELD_DIVIED) // FieldDivide �������� flag ��ȭ ���Ѵ� // 20091029
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}

				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}
				
				if(gDProject == NULL)
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}

				m_bShowSortIndex = !m_bShowSortIndex;
				ClearFiducialIndex();
				
				gDProject->ChangeViewIndex();

				Invalidate(FALSE);
*/
				return TRUE;

		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

BOOL CPaneAutoRunViewDataPusan1::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bViewerMoveMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HAND_RELEASE));
		return TRUE;
	}	
	return CFormView::OnSetCursor(pWnd, nHitTest, message);
}

void CPaneAutoRunViewDataPusan1::OnCancelMode() 
{
	CFormView::OnCancelMode();

	
}

BOOL CPaneAutoRunViewDataPusan1::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			gDProject.SetDrawRect(tempP, 1, 2);
		else
			gDProject.SetDrawRect(tempP, -1, 2);
		
		Invalidate(FALSE);
	}
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

void CPaneAutoRunViewDataPusan1::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	m_bDrawMoveStart = FALSE;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		
		Invalidate(FALSE);
	}

	CFormView::OnLButtonUp(nFlags, point);
}

void CPaneAutoRunViewDataPusan1::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;
			
			if(m_ptMoveStart != tempP)
			{
				m_ptMoveStart = endP;
				gDProject.SetDrawRect(tempP, 0, 2);
				Invalidate(FALSE);
			}
		}
	}
	CFormView::OnMouseMove(nFlags, point);
}

void CPaneAutoRunViewDataPusan1::DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2)
{
	CPoint ptStart;
	CPoint ptEnd;
	
	if(ptPoint1.x < ptPoint2.x)
	{
		ptStart.x = ptPoint1.x;
		ptEnd.x = ptPoint2.x;
	}
	else
	{
		ptStart.x = ptPoint2.x;
		ptEnd.x = ptPoint1.x;
	}
	
	if(ptPoint1.y < ptPoint2.y)
	{
		ptStart.y = ptPoint1.y;
		ptEnd.y = ptPoint2.y;
	}
	else
	{
		ptStart.y = ptPoint2.y;
		ptEnd.y = ptPoint1.y;
	}
	
	CRect rectRect(ptStart, ptEnd);
	
	m_ptDrawRectBack1 = ptStart;
	m_ptDrawRectBack2 = ptEnd;
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CPaneAutoRunViewDataPusan1::InitialDrawRatio()
{
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	gDProject.InitialDrawRatio(cRect, 2);
}
void CPaneAutoRunViewDataPusan1::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}
void CPaneAutoRunViewDataPusan1::SetFiredNGInfo(int nNG)
{
	
}