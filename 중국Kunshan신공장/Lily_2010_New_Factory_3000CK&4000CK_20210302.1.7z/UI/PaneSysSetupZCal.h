#if !defined(AFX_PANESYSSETUPZCAL_H__3934BACC_E7F5_4726_9E6E_3C4DF2947AEC__INCLUDED_)
#define AFX_PANESYSSETUPZCAL_H__3934BACC_E7F5_4726_9E6E_3C4DF2947AEC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupZCal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupZCal form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\model\dpoint.h"
#include "..\Device\Calibration.h"

class CPaneSysSetupZCal : public CFormView
{
protected:
	CPaneSysSetupZCal();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupZCal)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupZCal)
	enum { IDD = IDD_DLG_SYS_SETUP_Z_CAL };
		// NOTE: the ClassWizard will add data members here
	CColorStatic	m_stcRangeMin;
	CColorStatic	m_stcRangeMax;
	CColorEdit		m_edtGridX;
	CColorEdit		m_edtGridY;
	CColorEdit		m_edtLength;
	CColorEdit		m_edtAxisZ;
	UEasyButtonEx	m_btnTestZ;
	UEasyButtonEx	m_btnStart;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnProof;
	CListBox		m_lboxResult;
	CComboBox		m_cmbHead;
	//}}AFX_DATA

// Attributes
public:
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntListBox;

	BOOL			m_bStop;
	BOOL			m_bFinish;
	CALHEAD			m_CalHead;

// Operations
public:
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitListBoxControl();

	BOOL			GetHeightSensor(BOOL bFirst, BOOL bDown);
	void			AddList(CString strList);
	BOOL			InitStart();
	void			MessageLoop();
	void			StopProcess();
	void			ClearMem();

	void			SetButtonControl(BOOL bTest, BOOL bStart, BOOL bStop, BOOL bApply, BOOL bProof);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupZCal)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupZCal();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupZCal)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonTestZ();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonApply();
	afx_msg void OnButtonProof();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPZCAL_H__3934BACC_E7F5_4726_9E6E_3C4DF2947AEC__INCLUDED_)
