// DlgComponentTime.h: interface for the CDlgComponentTime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLGCOMPONENTTIME_H__58F75412_8394_4343_966F_B8FC08804D43__INCLUDED_)
#define AFX_DLGCOMPONENTTIME_H__58F75412_8394_4343_966F_B8FC08804D43__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


#include "UEasyButtonEx.h" 
#include "ColorEdit.h"
#include "resource.h"
#include "PaneSysSetupComponentTimeAlarm.h"
#include "easydriller.h"





class CDlgComponentTime : public CDialog
{
public:
	CDlgComponentTime();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CDlgComponentTime)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupTophat)
	enum { IDD = IDD_DLG_COMPONENT_TIME1};
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:
	
CPaneSysSetupComponentTimeAlarm *cAlarm;


	SYSTEMCOMPONENT	m_sSystemComponent;

	CListCtrl	m_lbComponent;
	void AddComponentList( CString strComponent, CString strExpiryDate, CString strSetTime, CString strUsingTime);


	UEasyButtonEx	m_btnInsert;
	UEasyButtonEx	m_btnDel;
	UEasyButtonEx	m_btnUpdate;
	UEasyButtonEx	m_btnInit;
	UEasyButtonEx	m_btnPreaccTime;

	UEasyButtonEx	m_btnAllInit;


	void	OnButtonInsert();
	void	OnButtonDel();
	void	OnButtonUpdate();
	void	OnButtonInit();
	void	OnButtonAllInit();
	void	OnButtonPreAccTime();

public:
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntListBox;
	CFont			m_fntList;

	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitProgressControl();
	void			InitListContorl();
	void			OnDestroy();
	BOOL			IsPowerOn();
	BOOL			GetScannerStatus();
	BOOL			m_bisPowerOn;
	BOOL			m_bIsScannerStatus;
	int m_nTimerID;
	BOOL			m_bOnTimer;
	CColorEdit		m_edtName;
	CColorEdit		m_edtExpireTime;
	CColorEdit		m_edtUsingTime;
	CColorEdit		m_edtStartTime;
	CColorEdit		m_edtPreAccTime;

	int				m_nPreaccTime;

	CProgressCtrl	m_Progress[50];

public:
	// Handle
	SQLHENV		m_hEnv;
	SQLHDBC		m_hDbc;
	SQLHSTMT	m_hStmt;
	CString		m_strWorkingDir;
	CString		m_strListClickDevice;
	BOOL	m_bEndThread;
	CWinThread* m_pThread;
	int m_nUnUsingTime1;
	int	m_nUnUsingTime2;


public :
	// Connect
	BOOL		DBConnect();
	
	void SetAuthorityByLevel(int nLevel);
	// Disconnect
	void		DBDisconnect();
	
	// Diagonostics
	void		GetDiagonostics();
	
	// Add New Component
	BOOL		AddNewComponent(CString strComponent, CString strExpiryDate, CString strUsingDate, CString strTime);
	
	// Remove Component
	BOOL		RemoveComponent(CString strComponent);
	BOOL		RemoveAllComponent();

	//	Update Component
	BOOL		UpdateComponent(CString strComponent, CString strExpiryDate, CString strBeforeCompnoent, CString strUsingTime, CString strStartTime);

	//	Init Component
	BOOL		InitComponent(CString strComponent,CString strExpiryDate,CString strUsingDate,CString strTime,CString strBeforeCompnoent);
	BOOL		ALLInitComponent(CString UsingDate, CString strTime);

	// display table
	BOOL		SelectComponentList();


	// Display Component
	BOOL		DisplayComponent(CString strCom, CString &strC,CString &StrE,CString &StrU,  CString &strS);		


public:


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupTophat)
public:
	

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	//}}AFX_VIRTUAL

// Implementation
public:
	int CalRemainedDate(int nIndex,  CString strExpiryDate, CString strSetTime, CString strUsingTime);
	void CreateProgress(int Index, CString strExpiryDate, CString strSetTime, CString strUsingTime);
	void SetProgress(int Index, CString strExpiryDate, CString strSetTime, CString strUsingTime);
	void ShowComponentOverDate();
	void SetComponentData();
	void SetSystemComponent(SYSTEMCOMPONENT sSystemComponent);
	void GetSystemComponent(SYSTEMCOMPONENT *pSystemComponent);
	CString GetChangeValueStr();
	void OnApply();
	int GetPreAccTime();
	BOOL GetUsingDateFromDB(CString strC, CString &strE,CString &strU,CString &strS);
	void CheckComponentOverDate();
	void UpdateUsingTime();
	BOOL UpdateDBData(CString strC, CString strE, CString strU);
	BOOL GetUpdateItemFromDB(CString strCompnoent, CString &strC, CString &strE, CString & strU,CString &strT);
	void ResizeProg();

	virtual ~CDlgComponentTime();
	virtual BOOL OnInitDialog();
#ifdef _DEBUG
//	virtual void AssertValid() const;
//	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupTophat)
	afx_msg void OnClickList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg void OnHdnEndtrackList(NMHDR *pNMHDR, LRESULT *pResult);
};

#endif // !defined(AFX_DLGCOMPONENTTIME_H__58F75412_8394_4343_966F_B8FC08804D43__INCLUDED_)


