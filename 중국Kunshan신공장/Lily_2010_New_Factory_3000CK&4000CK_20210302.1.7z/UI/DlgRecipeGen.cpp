// PaneRecipeGen.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgRecipeGen.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenDataEasy.h"
#include "PaneRecipeGenLayoutEasy.h"
#include "PaneRecipeGenDrillMethod.h"
#include "PaneRecipeGenFiducial.h"
#include "PaneRecipeGenParameter.h"
#include "PaneRecipeGenParameterNewEasy.h"
#include "PaneRecipeGenFiducialNew.h"
#include "PaneRecipeGenParameterNewNext.h"
#include "PaneAutoRun.h"

#include "PaneAutoRunViewData.h"

#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemInI.h"
#include "..\model\ExcellonReader.h"
#include "..\model\DUodoRedo.h"

#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"
#include "..\EasyDriller.h"

#include "..\device\HDeviceFactory.h"
#include "..\device\HMotor.h"
#include "..\device\DeviceMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen

IMPLEMENT_DYNAMIC(CDlgRecipeGen, CDialog)

CDlgRecipeGen::CDlgRecipeGen(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgRecipeGen::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPaneRecipeGen)
	//}}AFX_DATA_INIT
	m_pDataLoad			= NULL;
	m_pLayout			= NULL;
	m_pParamNew			= NULL;
	m_DProject			= DProject();
	m_bProjectOpen		= FALSE;

	m_nPaneNo			= 0;
}

CDlgRecipeGen::~CDlgRecipeGen()
{
}

void CDlgRecipeGen::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgRecipeGen)
	DDX_Control(pDX, IDC_STATIC_CAD_PATH, m_stcCadPath);
	DDX_Control(pDX, IDC_BUTTON_CAD_DATA, m_btnCadData);
	DDX_Control(pDX, IDC_TAB_RECIPE, m_tabRecipe);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgRecipeGen, CDialog)
	//{{AFX_MSG_MAP(CDlgRecipeGen)
	ON_BN_CLICKED(IDC_BUTTON_CAD_DATA, OnButtonCadData)
	ON_NOTIFY(NM_CLICK, IDC_TAB_RECIPE, OnClickTabRecipe)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen diagnostics



/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen message handlers
BOOL CDlgRecipeGen::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class

	return CDialog::Create(IDD, pParentWnd);
}
BOOL CDlgRecipeGen::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitTabControl();
	InitStaticControl();
	return TRUE;
}

void CDlgRecipeGen::InitBtnControl()
{
	m_fntBtn.CreatePointFont( 125, "Arial Bold");

	m_btnCadData.SetFont( &m_fntBtn );
	m_btnCadData.SetFlat( TRUE );
	m_btnCadData.SetIcon( IDI_CADOPEN );
	m_btnCadData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCadData.EnableBallonToolTip();
	m_btnCadData.SetToolTipText( _T("CAD data open") );
	m_btnCadData.SetBtnCursor( IDC_HAND_1 );
}

void CDlgRecipeGen::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");

	BOOL bRet = 0;

	m_tabRecipe.SetFont( &m_fntTab );

	bRet = m_tabRecipe.AddPane( _T(" Data Load "), RUNTIME_CLASS(CPaneRecipeGenDataEasy) );
	if( FALSE != bRet )
	{
		m_pDataLoad	= static_cast<CPaneRecipeGenDataEasy*>(m_tabRecipe.GetPane(0));
		m_pDataLoad->OnInitialUpdate();
		m_pDataLoad->SetProject(&m_DProject);
		m_pDataLoad->m_pParent = this;
	}

	bRet = m_tabRecipe.AddPane( _T(" Layout "), RUNTIME_CLASS(CPaneRecipeGenLayoutEasy) );
	if( FALSE != bRet )
	{
		m_pLayout = static_cast<CPaneRecipeGenLayoutEasy*>(m_tabRecipe.GetPane(1));
		m_pLayout->OnInitialUpdate();
	}



	bRet = m_tabRecipe.AddPane( _T(" Parameter "), RUNTIME_CLASS(CPaneRecipeGenParameterNewEasy) );
	if( FALSE != bRet )
	{
		m_pParamNew = static_cast<CPaneRecipeGenParameterNewEasy*>(m_tabRecipe.GetPane(2));
		m_pParamNew->OnInitialUpdate();
	}
	

	m_tabRecipe.ShowPane( 0 );
}

void CDlgRecipeGen::InitStaticControl()
{
	m_fntStatic.CreatePointFont( 130, "Arial Bold");

	m_stcCadPath.SetFont( &m_fntStatic );
	m_stcCadPath.SetForeColor( VALUE_FORE_COLOR );
	m_stcCadPath.SetBackColor( ::GetSysColor( COLOR_BTNFACE ) );
	GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetFont( &m_fntStatic );
}

void CDlgRecipeGen::OnButtonCadData() 
{
/*	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt)|*.txt|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, _T("*.txt"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();

	if(IDOK != dlg.DoModal())
	{
		return;
	}

	CString strPath;

	strPath.Format(_T("\t%s"), dlg.GetPathName());
	SetDlgItemText(IDC_STATIC_CAD_PATH, (LPCTSTR)strPath);
	
	ExcellonReader excelReader;
	strcpy_s(m_DProject.m_szFileName, dlg.GetPathName());
	
	m_pLayout->GetData(m_DProject);
	excelReader.Read(dlg.GetPathName(), m_DProject.m_nTZS, m_DProject.m_nInputUnit, &m_DProject);
	m_pParam->SetData(FALSE, m_DProject);
*/
}


void CDlgRecipeGen::OnClickTabRecipe(NMHDR* pNMHDR, LRESULT* pResult) 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	int nSel = m_tabRecipe.GetCurSel();

	if( nSel == m_nPaneNo )
		return;
	
	WPARAM wParam = RECIPE_GEN;
	LPARAM lParam = nSel;
	::AfxGetMainWnd()->PostMessage( CHANGE_SUB_PANE, wParam, lParam );

	m_nPaneNo = nSel;
	switch( nSel )
	{
	case 0: // GenData
		m_pDataLoad->SetFocus();
		m_pDataLoad->SetProject(&m_DProject);

		break;
	case 1 : // Layout
		m_pLayout->SetFocus();

		break;

	case 2 : // Parameter
		m_pParamNew->UpdateList(0,0);
		m_pParamNew->SetFocus();
		
		break;

	}
	
	*pResult = 0;
}

void CDlgRecipeGen::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntTab.DeleteObject();

	CDialog::OnDestroy();
}

BOOL CDlgRecipeGen::SaveProject(CString strPath)
{
	if(FALSE == m_pLayout->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}

	if(FALSE == m_pParamNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->CheckFidData())
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}

	// - A�ҡ�C ��E��c
	int nResult = m_DProject.IsValidParameter();
	
	if(nResult == NONE_SUBPARAM)
	{
		ErrMessage(IDS_DATA_NO_SUB);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == LINE_DOT_MISMATCH)
	{
		ErrMessage(IDS_DATA_MISMATCH);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == DIFF_SUB_TYPE)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BARCODE_SIZE_ERROR)
	{
		ErrMessage(IDS_DATA_BARCODE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == APERTURE_COUNT_ERROR)
	{
		ErrMessage(IDS_DATA_APERTURE_COUNT);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else
	{
	}
	
	if(!m_DProject.m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		m_pDataLoad->Invalidate(FALSE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}	
	
	int nModeCalcual = gDProject.GetChangeFieldMode(m_DProject);
	
	if((m_DProject.m_nDataLoadStep & 0x0b) >= LOAD_EXCELLON) // 20091029
	{
		if(nModeCalcual == FIELD_CHANGE)
		{
			if(!m_DProject.CheckUnitSize())
			{
				ErrMessage(IDS_DATA_UNIT_SIZE);
				return FALSE;
			}
			if(!m_DProject.PuzzleOut())
			{
				ErrMessage(IDS_DATA_CALCULATION);
				return FALSE;
			}
			m_pDataLoad->Invalidate(FALSE);
		}
		else if (nModeCalcual == FIELD_AXIS_CHANGE)
			m_DProject.PuzzleOutOnlyAxisTrans();
		else
		{
		}
	}
	//
#ifdef __KUNSAN_SAMSUNG_LARGE__
	SetDutyOffset();
#endif

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(strPath, CFile::modeWrite|CFile::modeCreate))
		{
			m_pDataLoad->SetFocus();
			return FALSE;
		}
		
		CString strMessage, strChange;
		strChange = gDProject.GetChangeValue(m_DProject);
		strMessage.Format(_T("Project�� ���� ����Ǿ����ϴ�."));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strChange));

		gDProject.ChangeMarkingParam(m_DProject, strPath);
		gDProject = m_DProject;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
		if(m_pDataLoad->m_bExcellonChange)//strcmp(gDProject.m_szFileName, "Untitle.txt") == 0)
		{
			strcpy_s(gDProject.m_szFileName, gDProject.m_szTempFileName);
			strcpy_s(m_DProject.m_szFileName, gDProject.m_szTempFileName);
		}
	
		CArchiveMark ar(&file, CArchive::store);
		gDProject.Serialize(ar, 10000);
	}
	CATCH (CException, e)
	{
		e->Delete();
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	END_CATCH

	m_pDataLoad->SetFocus();
	m_pDataLoad->m_bExcellonChange = FALSE;
	return TRUE;
}
BOOL CDlgRecipeGen::CheckSameName(CString strPath)
{
	BOOL bExist;
	CFileFind find;
	bExist = find.FindFile(strPath);
	if(bExist)
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CDlgRecipeGen::SetData()
{
	CString str;
	str.Format(_T("  %s"), gDProject.m_szFileName);
	strcpy_s(m_DProject.m_szFileName, gDProject.m_szFileName);
	SetDlgItemText(IDC_STATIC_CAD_PATH, (LPCTSTR)str);

//	int nIndex = str.ReverseFind('\\');
//	str = str.Mid(nIndex+1);
//	((CEasyDrillerDlg*)GetParent())->SetDataName( (LPCTSTR)str );

	m_DProject = gDProject;

	m_pDataLoad->SetProject(&m_DProject);
	gDUndoRedo.Initialize(&m_DProject);

	if(FALSE == m_pLayout->SetData())
		return FALSE;
	if(m_nPaneNo != 2)
		m_pParamNew->m_bConnectVision = FALSE;
	if(FALSE == m_pParamNew->SetData(m_DProject))
		return FALSE;
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(gDProject))
		return FALSE;

	m_pDataLoad->m_bExcellonChange = FALSE;
	m_pLayout->EnablePrework();
	return TRUE;
}

BOOL CDlgRecipeGen::OpenProject(CString strPath)
{
	CStdioFile file, fileSave;
	TRY
	{
		if (FALSE == file.Open(strPath, CFile::modeRead))
		{
			m_pDataLoad->SetFocus();
			return FALSE;
		}

		if (file.GetLength() < 1)
		{
			file.Close();
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		BOOL bRes = gDProject.Serialize(ar, 10000);	
		file.Close();

#ifdef __PUSAN_LDD__
		if(bRes && gDProject.m_nVersion < 10018)
		{
			::AfxGetMainWnd()->SendMessage(UM_PRJ_BACKUP_DELETE, FALSE, reinterpret_cast<LPARAM>(&strPath));
			if (fileSave.Open(strPath, CFile::modeWrite|CFile::modeCreate))
			{
				CArchiveMark arSave(&fileSave, CArchive::store);
				gDProject.Serialize(arSave, 10000);
				fileSave.Close();
			}
		}
//		else if(!bRes || gDProject.m_nVersion < 10018)
//		{
//			::AfxGetMainWnd()->SendMessage(UM_PRJ_BACKUP_DELETE, TRUE, reinterpret_cast<LPARAM>(&strPath));
//		}
#endif

#ifdef __PUSAN_OLD_32__
		if(bRes && gDProject.m_nVersion < 10018)
		{
			::AfxGetMainWnd()->SendMessage(UM_PRJ_BACKUP_DELETE, FALSE, reinterpret_cast<LPARAM>(&strPath));
//			((CEasyDrillerDlg*)::AfxGetMainWnd())->SaveProject(gDProject.m_szProjectName);
			if (fileSave.Open(strPath, CFile::modeWrite|CFile::modeCreate))
			{
				CArchiveMark arSave(&fileSave, CArchive::store);
				gDProject.Serialize(arSave, 10000);
				fileSave.Close();
			}
		}
#endif

		if(!bRes)
		{
			m_pDataLoad->SetFocus();
			m_pDataLoad->ResetProject();
//			file.Close();
			return FALSE;
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		m_pDataLoad->SetFocus();
		m_pDataLoad->ResetProject();
		return FALSE;
	}
	END_CATCH

	if(!SetData())
	{
		m_pDataLoad->SetFocus();
		m_pDataLoad->ResetProject();
//		file.Close();
		return FALSE;
	}

	m_pDataLoad->SetDrawRect();

	m_pDataLoad->SetFocus();
	m_pDataLoad->ClearFiducialIndex();

	SetWindowForSkiving(TRUE);

	gDUndoRedo.Clear();

#ifdef __KUNSAN_SAMSUNG_LARGE__
		GetDutyOffset();
#endif
	
//	file.Close();

	m_pDataLoad->m_bExcellonChange = FALSE;

	return TRUE;
}

BOOL CDlgRecipeGen::ApplyProject()
{
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->CheckFidData())
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pLayout->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pParamNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}


	int nResult = m_DProject.IsValidParameter();

	if(nResult == NONE_SUBPARAM)
	{
		ErrMessage(IDS_DATA_NO_SUB);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == LINE_DOT_MISMATCH)
	{
		ErrMessage(IDS_DATA_MISMATCH);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == DIFF_SUB_TYPE)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BARCODE_SIZE_ERROR)
	{
		ErrMessage(IDS_DATA_BARCODE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == APERTURE_COUNT_ERROR)
	{
		ErrMessage(IDS_DATA_APERTURE_COUNT);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else
	{
	}

	if(!m_DProject.m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		m_pDataLoad->Invalidate(FALSE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}	

	int nModeCalcual = gDProject.GetChangeFieldMode(m_DProject);

	if (nModeCalcual != FIELD_AXIS_CHANGE)
	{
		m_DProject.m_Glyphs.SortFiducial(DEFAULT_FID_INDEX);
		m_DProject.m_Glyphs.SortFiducial(ADDED_FID_INDEX);
	}

	if(nModeCalcual == FIELD_CHANGE)
	{
		if(!m_DProject.CheckUnitSize())
		{
			ErrMessage(IDS_DATA_UNIT_SIZE);
			return FALSE;
		}
		if(!m_DProject.PuzzleOut())
		{
			ErrMessage(IDS_DATA_CALCULATION);
			return FALSE;
		}
	}
	else if (nModeCalcual == FIELD_AXIS_CHANGE)
		m_DProject.PuzzleOutOnlyAxisTrans();





#ifdef __KUNSAN_SAMSUNG_LARGE__
		SetDutyOffset();
#endif

	CString strMessage, strChange;
	strChange = gDProject.GetChangeValue(m_DProject);
	
	if(m_pDataLoad->m_bExcellonChange)//strcmp(gDProject.m_szFileName, "Untitle.txt") == 0)
	{
		strcpy_s(m_DProject.m_szFileName, m_DProject.m_szTempFileName);
	}
	else
	{
		strcpy_s(m_DProject.m_szTempFileName, m_DProject.m_szFileName);
	}
	CString strTemp;
	strTemp.Format(_T("%s"), gDProject.m_szProjectName);
	gDProject.ChangeMarkingParam(m_DProject, strTemp);

	gDProject = m_DProject;


	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
	

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();
	
	 strTemp.Format(_T("%s"), gDProject.m_szLotId);
	//change prj �̻��
	//if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CHANGE, reinterpret_cast<LPARAM>(&strTemp)))
	//	return FALSE;

	m_pDataLoad->SetFocus();
	m_pDataLoad->m_bExcellonChange = FALSE;

	strMessage.Format(_T("Project�� ���� ����Ǿ����ϴ�."));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strChange));
	
		

	return TRUE;
}

void CDlgRecipeGen::SetFocusViewer()
{
	m_pDataLoad->SetFocus();
}

void CDlgRecipeGen::SetAuthorityByLevel(int nLevel)
{
	if(m_pDataLoad != NULL)
		m_pDataLoad->SetAuthorityByLevel(nLevel);
	
	if(m_pLayout != NULL)
		m_pLayout->SetAuthorityByLevel(nLevel);
	
	if(m_pParamNew != NULL)
		m_pParamNew->SetAuthorityByLevel(nLevel);
}

void CDlgRecipeGen::SetWindowForSkiving(BOOL bSkiving)
{
	m_pLayout->EnableSkivingHeight(bSkiving);
//	if(m_pFiducialSkiving)
//		m_pFiducialSkiving->EnableAllWindow(bSkiving);
}

void CDlgRecipeGen::SetDataLoadStep(int nStep)
{
	m_DProject.m_nDataLoadStep = nStep;
}

void CDlgRecipeGen::OnMoveVisionView()
{

}

void CDlgRecipeGen::ShowTabPane(int nPaneNo)
{
	m_nPaneNo = nPaneNo;

}

BOOL CDlgRecipeGen::SortArea()
{
	if(FALSE == ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}

	int nStartFidBlock, nEndFidBlock;
	if(m_DProject.m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; 
		nEndFidBlock = m_DProject.m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1; 
	}

	int nIndex = 0, nTempIndex;
	for(int i = nStartFidBlock; i <= nEndFidBlock; i++)
	{
		m_DProject.ResetToolSumUsedFlag();
		
		if(!gProcessINI.m_sProcessSystem.bNoSortArea)
		{
			if(!m_DProject.SortArea(i, nIndex, nTempIndex))
			{
				m_DProject.RemoveAreaList();
				return FALSE;
			}
			nIndex = nTempIndex;
		}
	}
	return TRUE;
}
void CDlgRecipeGen::GetDutyOffset()
{
	for(int i= 0; i<MAX_TOOL_NO; i++)
	{
		gDProject.m_pToolCode[i]->GetDutyOffsetfromMDB();
	}
}
	
void CDlgRecipeGen::SetDutyOffset()
{
	for(int i= 0; i<MAX_TOOL_NO; i++)
	{
		m_DProject.m_pToolCode[i]->SetDutyOffsettoMDB();
	}
}

void CDlgRecipeGen::EnableTab(BOOL bEnable)
{
	m_tabRecipe.TabChangeEnable(bEnable);
	if(!bEnable)
	m_tabRecipe.ShowPane( 0 );
}


void CDlgRecipeGen::ChangeProjectInfo(CString strTotalHoleCnt)
{
	GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetWindowText(strTotalHoleCnt);
}