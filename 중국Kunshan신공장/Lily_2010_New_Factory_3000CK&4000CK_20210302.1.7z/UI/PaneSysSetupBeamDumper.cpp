// PaneSysSetupBeamDumper.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupBeamDumper.h"
#include "..\Model\DSystemINI.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HEocard.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumper

IMPLEMENT_DYNCREATE(CPaneSysSetupBeamDumper, CFormView)

CPaneSysSetupBeamDumper::CPaneSysSetupBeamDumper()
	: CFormView(CPaneSysSetupBeamDumper::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupBeamDumper)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneSysSetupBeamDumper::~CPaneSysSetupBeamDumper()
{
}

void CPaneSysSetupBeamDumper::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupBeamDumper)
	DDX_Control(pDX, IDC_EDIT_2ND_PANEL_POS_Y, m_edt2ndPanelPosY);
	DDX_Control(pDX, IDC_EDIT_2ND_PANEL_POS_X, m_edt2ndPanelPosX);
	DDX_Control(pDX, IDC_EDIT_1ST_PANEL_POS_Y, m_edt1stPanelPosY);
	DDX_Control(pDX, IDC_EDIT_1ST_PANEL_POS_X, m_edt1stPanelPosX);
	DDX_Control(pDX, IDC_EDIT_DUMMY_NO, m_edtDummyShotNo);
	DDX_Control(pDX, IDC_EDIT_DUMMY_TIME, m_edtDummyInterval);
	DDX_Control(pDX, IDC_EDIT_DUMMY_FREQ, m_edtDummyFreq);
	DDX_Control(pDX, IDC_EDIT_DUMMY_DUTY, m_edtDummyDuty);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DELAY, m_edtDummyAOMDelay);
	DDX_Control(pDX, IDC_EDIT_DUMMY_AOM_DUTY, m_edtDummyAOMDuty);
	DDX_Control(pDX, IDC_EDIT_STANDBY_TIME, m_edtStandbyTime);
	DDX_Control(pDX, IDC_EDIT_MIN_FREQ, m_edtStandbyMinFreq);
	DDX_Control(pDX, IDC_EDIT_MAX_FREQ, m_edtStandbyMaxFreq);
	DDX_Control(pDX, IDC_EDIT_STANDBY_INTERVAL, m_edtStandbyInterval);
	DDX_Control(pDX, IDC_EDIT_STANDBY_LM, m_edtStandbyDuty);
	DDX_Control(pDX, IDC_EDIT_INPOSITION_TIME, m_edtStandbyInpositionTime);
	DDX_Control(pDX, IDC_EDIT_STANDBY_TIME2, m_edtStandbyTime2);
	DDX_Control(pDX, IDC_EDIT_MIN_FREQ2, m_edtStandbyMinFreq2);
	DDX_Control(pDX, IDC_EDIT_MAX_FREQ2, m_edtStandbyMaxFreq2);
	DDX_Control(pDX, IDC_EDIT_STANDBY_INTERVAL2, m_edtStandbyInterval2);
	DDX_Control(pDX, IDC_EDIT_STANDBY_LM2, m_edtStandbyDuty2);
	DDX_Control(pDX, IDC_EDIT_INPOSITION_TIME2, m_edtStandbyInpositionTime2);

	DDX_Radio(pDX, IDC_RADIO_DUMMY_FREE, m_nUseDummy);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupBeamDumper, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupBeamDumper)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_RADIO_DUMPER_SHOT, OnRadioDumperShot)
	ON_BN_CLICKED(IDC_RADIO_DUMMY_FREE, OnRadioDummyFree)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumper diagnostics

#ifdef _DEBUG
void CPaneSysSetupBeamDumper::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupBeamDumper::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumper message handlers

void CPaneSysSetupBeamDumper::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
}

BOOL CPaneSysSetupBeamDumper::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

HBRUSH CPaneSysSetupBeamDumper::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_1ST_PANEL_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_PANEL_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DUMMY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DUMMY3)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_MODE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_DUMMY_SEL)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupBeamDumper::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
}

void CPaneSysSetupBeamDumper::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(180, "Arial Bold");

	// 1st Panel Position
	m_edt1stPanelPosX.SetFont( &m_fntEdit );
	m_edt1stPanelPosX.SetForeColor( BLACK_COLOR );
	m_edt1stPanelPosX.SetBackColor( WHITE_COLOR );
	m_edt1stPanelPosX.SetReceivedFlag( 1 );
	m_edt1stPanelPosX.SetWindowText( _T("32767") );

	m_edt1stPanelPosY.SetFont( &m_fntEdit );
	m_edt1stPanelPosY.SetForeColor( BLACK_COLOR );
	m_edt1stPanelPosY.SetBackColor( WHITE_COLOR );
	m_edt1stPanelPosY.SetReceivedFlag( 1 );
	m_edt1stPanelPosY.SetWindowText( _T("65000") );

	// 2nd Panel Position
	m_edt2ndPanelPosX.SetFont( &m_fntEdit );
	m_edt2ndPanelPosX.SetForeColor( BLACK_COLOR );
	m_edt2ndPanelPosX.SetBackColor( WHITE_COLOR );
	m_edt2ndPanelPosX.SetReceivedFlag( 1 );
	m_edt2ndPanelPosX.SetWindowText( _T("32767") );

	m_edt2ndPanelPosY.SetFont( &m_fntEdit );
	m_edt2ndPanelPosY.SetForeColor( BLACK_COLOR );
	m_edt2ndPanelPosY.SetBackColor( WHITE_COLOR );
	m_edt2ndPanelPosY.SetReceivedFlag( 1 );
	m_edt2ndPanelPosY.SetWindowText( _T("65000") );

	// dummy
	m_edtDummyShotNo.SetFont( &m_fntEdit );
	m_edtDummyShotNo.SetForeColor( BLACK_COLOR );
	m_edtDummyShotNo.SetBackColor( WHITE_COLOR );
	m_edtDummyShotNo.SetReceivedFlag( 1 );
	m_edtDummyShotNo.SetWindowText( _T("200") );

	m_edtDummyInterval.SetFont( &m_fntEdit );
	m_edtDummyInterval.SetForeColor( BLACK_COLOR );
	m_edtDummyInterval.SetBackColor( WHITE_COLOR );
	m_edtDummyInterval.SetReceivedFlag( 1 );
	m_edtDummyInterval.SetWindowText( _T("350") );

	m_edtDummyFreq.SetFont( &m_fntEdit );
	m_edtDummyFreq.SetForeColor( BLACK_COLOR );
	m_edtDummyFreq.SetBackColor( WHITE_COLOR );
	m_edtDummyFreq.SetReceivedFlag( 1 );
	m_edtDummyFreq.SetWindowText( _T("3000") );

	m_edtDummyDuty.SetFont( &m_fntEdit );
	m_edtDummyDuty.SetForeColor( BLACK_COLOR );
	m_edtDummyDuty.SetBackColor( WHITE_COLOR );
	m_edtDummyDuty.SetReceivedFlag( 1 );
	m_edtDummyDuty.SetWindowText( _T("67") );

	m_edtDummyAOMDelay.SetFont( &m_fntEdit );
	m_edtDummyAOMDelay.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDelay.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDelay.SetReceivedFlag( 1 );
	m_edtDummyAOMDelay.SetWindowText( _T("0") );

	m_edtDummyAOMDuty.SetFont( &m_fntEdit );
	m_edtDummyAOMDuty.SetForeColor( BLACK_COLOR );
	m_edtDummyAOMDuty.SetBackColor( WHITE_COLOR );
	m_edtDummyAOMDuty.SetReceivedFlag( 1 );
	m_edtDummyAOMDuty.SetWindowText( _T("1") );

	//standby info
	m_edtStandbyTime.SetFont( &m_fntEdit );
	m_edtStandbyTime.SetForeColor( BLACK_COLOR );
	m_edtStandbyTime.SetBackColor( WHITE_COLOR );
	m_edtStandbyTime.SetReceivedFlag( 1 );
	m_edtStandbyTime.SetWindowText( _T("10") );
	
	m_edtStandbyMinFreq.SetFont( &m_fntEdit );
	m_edtStandbyMinFreq.SetForeColor( BLACK_COLOR );
	m_edtStandbyMinFreq.SetBackColor( WHITE_COLOR );
	m_edtStandbyMinFreq.SetReceivedFlag( 1 );
	m_edtStandbyMinFreq.SetWindowText( _T("500") );
	
	m_edtStandbyMaxFreq.SetFont( &m_fntEdit );
	m_edtStandbyMaxFreq.SetForeColor( BLACK_COLOR );
	m_edtStandbyMaxFreq.SetBackColor( WHITE_COLOR );
	m_edtStandbyMaxFreq.SetReceivedFlag( 1 );
	m_edtStandbyMaxFreq.SetWindowText( _T("250") );
	
	m_edtStandbyInterval.SetFont( &m_fntEdit );
	m_edtStandbyInterval.SetForeColor( BLACK_COLOR );
	m_edtStandbyInterval.SetBackColor( WHITE_COLOR );
	m_edtStandbyInterval.SetReceivedFlag( 1 );
	m_edtStandbyInterval.SetWindowText( _T("500") );
	
	m_edtStandbyDuty.SetFont( &m_fntEdit );
	m_edtStandbyDuty.SetForeColor( BLACK_COLOR );
	m_edtStandbyDuty.SetBackColor( WHITE_COLOR );
	m_edtStandbyDuty.SetReceivedFlag( 1 );
	m_edtStandbyDuty.SetWindowText( _T("15") );
	
	m_edtStandbyInpositionTime.SetFont( &m_fntEdit );
	m_edtStandbyInpositionTime.SetForeColor( BLACK_COLOR );
	m_edtStandbyInpositionTime.SetBackColor( WHITE_COLOR );
	m_edtStandbyInpositionTime.SetReceivedFlag( 1 );
	m_edtStandbyInpositionTime.SetWindowText( _T("300") );

	//standby info 2
	m_edtStandbyTime2.SetFont( &m_fntEdit );
	m_edtStandbyTime2.SetForeColor( BLACK_COLOR );
	m_edtStandbyTime2.SetBackColor( WHITE_COLOR );
	m_edtStandbyTime2.SetReceivedFlag( 1 );
	m_edtStandbyTime2.SetWindowText( _T("10") );
	
	m_edtStandbyMinFreq2.SetFont( &m_fntEdit );
	m_edtStandbyMinFreq2.SetForeColor( BLACK_COLOR );
	m_edtStandbyMinFreq2.SetBackColor( WHITE_COLOR );
	m_edtStandbyMinFreq2.SetReceivedFlag( 1 );
	m_edtStandbyMinFreq2.SetWindowText( _T("500") );
	
	m_edtStandbyMaxFreq2.SetFont( &m_fntEdit );
	m_edtStandbyMaxFreq2.SetForeColor( BLACK_COLOR );
	m_edtStandbyMaxFreq2.SetBackColor( WHITE_COLOR );
	m_edtStandbyMaxFreq2.SetReceivedFlag( 1 );
	m_edtStandbyMaxFreq2.SetWindowText( _T("250") );
	
	m_edtStandbyInterval2.SetFont( &m_fntEdit );
	m_edtStandbyInterval2.SetForeColor( BLACK_COLOR );
	m_edtStandbyInterval2.SetBackColor( WHITE_COLOR );
	m_edtStandbyInterval2.SetReceivedFlag( 1 );
	m_edtStandbyInterval2.SetWindowText( _T("500") );
	
	m_edtStandbyDuty2.SetFont( &m_fntEdit );
	m_edtStandbyDuty2.SetForeColor( BLACK_COLOR );
	m_edtStandbyDuty2.SetBackColor( WHITE_COLOR );
	m_edtStandbyDuty2.SetReceivedFlag( 1 );
	m_edtStandbyDuty2.SetWindowText( _T("15") );
	
	m_edtStandbyInpositionTime2.SetFont( &m_fntEdit );
	m_edtStandbyInpositionTime2.SetForeColor( BLACK_COLOR );
	m_edtStandbyInpositionTime2.SetBackColor( WHITE_COLOR );
	m_edtStandbyInpositionTime2.SetReceivedFlag( 1 );
	m_edtStandbyInpositionTime2.SetWindowText( _T("300") );
}

void CPaneSysSetupBeamDumper::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// 1st Panel Position
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_POS_Y)->SetFont( &m_fntStatic );

	// 2nd Panel Position
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_POS_Y)->SetFont( &m_fntStatic );

	// Laser Mode
	GetDlgItem(IDC_STATIC_DUMMY)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_DUMMY_SHOTNO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DELAU)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_AOM_DUTY)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_DUMMY3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_MINFREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_MAXFREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANBY_INTERVAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_LM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_INPOS)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_DUMMY4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_TIME2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_MINFREQ2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_MAXFREQ2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANBY_INTERVAL2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_LM2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STANDBY_INPOS2)->SetFont( &m_fntStatic );

	//dummy choose
	GetDlgItem(IDC_STATIC_DUMMY_SEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_RADIO_NO_DUMMY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_RADIO_DUMMY_FREE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_RADIO_DUMPER_SHOT)->SetFont( &m_fntStatic );
}


void CPaneSysSetupBeamDumper::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupBeamDumper::SetBeamDumperData()
{
	CString str;
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper1.x);
	m_edt1stPanelPosX.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper1.y);
	m_edt1stPanelPosY.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper2.x);
	m_edt2ndPanelPosX.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nPtBeanDumper2.y);
	m_edt2ndPanelPosY.SetWindowText( str );

	// dummy
	str.Format(_T("%d"), m_sSystemDump.nDummyShot);
	m_edtDummyShotNo.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyInterval);
	m_edtDummyInterval.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyFreq);
	m_edtDummyFreq.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyDuty);
	m_edtDummyDuty.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDelay);
	m_edtDummyAOMDelay.SetWindowText( str );

	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDuty);
	m_edtDummyAOMDuty.SetWindowText( str );

	// stardby shot 
	str.Format(_T("%d"), m_sSystemDump.nStandbyTime);
	m_edtStandbyTime.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nStandbyMinFreq);
	m_edtStandbyMinFreq.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nStandbyMaxFreq);
	m_edtStandbyMaxFreq.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nStandbyInterval);
	m_edtStandbyInterval.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nStandbyDuty);
	m_edtStandbyDuty.SetWindowText( str );
	
	str.Format(_T("%d"), m_sSystemDump.nStandbyInpositionTime);
	m_edtStandbyInpositionTime.SetWindowText( str );

	// stardby shot 2
	if(m_sSystemDump.nStandbyTime2 == -999)
		m_sSystemDump.nStandbyTime2 = m_sSystemDump.nStandbyTime;
	str.Format(_T("%d"), m_sSystemDump.nStandbyTime2);
	m_edtStandbyTime2.SetWindowText( str );
	
	if(m_sSystemDump.nStandbyMinFreq2 == -999)
		m_sSystemDump.nStandbyMinFreq2 = m_sSystemDump.nStandbyMinFreq;
	str.Format(_T("%d"), m_sSystemDump.nStandbyMinFreq2);
	m_edtStandbyMinFreq2.SetWindowText( str );

	if(m_sSystemDump.nStandbyMaxFreq2 == -999)
		m_sSystemDump.nStandbyMaxFreq2 = m_sSystemDump.nStandbyMaxFreq;
	str.Format(_T("%d"), m_sSystemDump.nStandbyMaxFreq2);
	m_edtStandbyMaxFreq2.SetWindowText( str );

	if(m_sSystemDump.nStandbyInterval2 == -999)
		m_sSystemDump.nStandbyInterval2 = m_sSystemDump.nStandbyInterval;
	str.Format(_T("%d"), m_sSystemDump.nStandbyInterval2);
	m_edtStandbyInterval2.SetWindowText( str );

	if(m_sSystemDump.nStandbyDuty2 == -999)
		m_sSystemDump.nStandbyDuty2 = m_sSystemDump.nStandbyDuty;
	str.Format(_T("%d"), m_sSystemDump.nStandbyDuty2);
	m_edtStandbyDuty2.SetWindowText( str );

	if(m_sSystemDump.nStandbyInpositionTime2 == -999)
		m_sSystemDump.nStandbyInpositionTime2 = m_sSystemDump.nStandbyInpositionTime;
	str.Format(_T("%d"), m_sSystemDump.nStandbyInpositionTime2);
	m_edtStandbyInpositionTime2.SetWindowText( str );

	switch(m_sSystemDump.nUseDummyType)
	{
	case NO_USE :
		GetDlgItem(IDC_RADIO_NO_DUMMY)->SetFocus();
		break;
	case DUMPER_SHOT :
		GetDlgItem(IDC_RADIO_DUMPER_SHOT)->SetFocus();
		break;
	case DUMMY_FREE :
		GetDlgItem(IDC_RADIO_DUMMY_FREE)->SetFocus();
		break;
	}
	m_nUseDummy = m_sSystemDump.nUseDummyType;

}

void CPaneSysSetupBeamDumper::OnApply()
{
	CString strData;
	
	m_edt1stPanelPosX.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper1.x = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stPanelPosY.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper1.y = atoi( (LPSTR)(LPCTSTR)strData );
	
	
	m_edt2ndPanelPosX.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper2.x = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edt2ndPanelPosY.GetWindowText( strData );
	m_sSystemDump.nPtBeanDumper2.y = atoi( (LPSTR)(LPCTSTR)strData );

	// dummy
	m_edtDummyShotNo.GetWindowText( strData );
	m_sSystemDump.nDummyShot = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyInterval.GetWindowText( strData );
	m_sSystemDump.nDummyInterval = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyFreq.GetWindowText( strData );
	m_sSystemDump.nDummyFreq = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyDuty.GetWindowText( strData );
	m_sSystemDump.nDummyDuty = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyAOMDelay.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDelay = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtDummyAOMDuty.GetWindowText( strData );
	m_sSystemDump.nDummyAOMDuty = atoi( (LPSTR)(LPCTSTR)strData );

	//standby shot
	m_edtStandbyTime.GetWindowText( strData );
	m_sSystemDump.nStandbyTime = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyMinFreq.GetWindowText( strData );
	m_sSystemDump.nStandbyMinFreq = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyMaxFreq.GetWindowText( strData );
	m_sSystemDump.nStandbyMaxFreq = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyInterval.GetWindowText( strData );
	m_sSystemDump.nStandbyInterval = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyDuty.GetWindowText( strData );
	m_sSystemDump.nStandbyDuty = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyInpositionTime.GetWindowText( strData );
	m_sSystemDump.nStandbyInpositionTime = atoi( (LPSTR)(LPCTSTR)strData );

	//standby shot 2
	m_edtStandbyTime2.GetWindowText( strData );
	m_sSystemDump.nStandbyTime2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyMinFreq2.GetWindowText( strData );
	m_sSystemDump.nStandbyMinFreq2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyMaxFreq2.GetWindowText( strData );
	m_sSystemDump.nStandbyMaxFreq2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyInterval2.GetWindowText( strData );
	m_sSystemDump.nStandbyInterval2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyDuty2.GetWindowText( strData );
	m_sSystemDump.nStandbyDuty2 = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtStandbyInpositionTime2.GetWindowText( strData );
	m_sSystemDump.nStandbyInpositionTime2 = atoi( (LPSTR)(LPCTSTR)strData );

	m_sSystemDump.nUseDummyType = m_nUseDummy;

}

void CPaneSysSetupBeamDumper::SetSystemDevice(SSYSTEMDUMP sSystemDump)
{
	memcpy( &m_sSystemDump, &sSystemDump, sizeof(m_sSystemDump) );

	SetBeamDumperData();
}

CString CPaneSysSetupBeamDumper::GetChangeValueStr()
{
	CString strMessage, strTemp, strId1, strId2;
	strMessage.Format(_T(""));
	
	if(m_sSystemDump.nPtBeanDumper1.x != gSystemINI.m_sSystemDump.nPtBeanDumper1.x ||
		m_sSystemDump.nPtBeanDumper1.y != gSystemINI.m_sSystemDump.nPtBeanDumper1.y)
	{
		strTemp.Format(_T("| 1st Beam Dumper : ( %d, %d) "), 
			m_sSystemDump.nPtBeanDumper1.x,
			m_sSystemDump.nPtBeanDumper1.y);
		strMessage += strTemp;
	}
	
	if(m_sSystemDump.nPtBeanDumper2.x != gSystemINI.m_sSystemDump.nPtBeanDumper2.x ||
		m_sSystemDump.nPtBeanDumper2.y != gSystemINI.m_sSystemDump.nPtBeanDumper2.y)
	{
		strTemp.Format(_T("| 1st Beam Dumper : ( %d, %d) "), 
			m_sSystemDump.nPtBeanDumper2.x,
			m_sSystemDump.nPtBeanDumper2.y);
		strMessage += strTemp;
	}

	if(m_sSystemDump.nDummyShot != gSystemINI.m_sSystemDump.nDummyShot ||
		m_sSystemDump.nDummyFreq != gSystemINI.m_sSystemDump.nDummyFreq ||
		m_sSystemDump.nDummyInterval != gSystemINI.m_sSystemDump.nDummyInterval ||
		m_sSystemDump.nDummyDuty != gSystemINI.m_sSystemDump.nDummyDuty ||
		m_sSystemDump.nDummyAOMDelay != gSystemINI.m_sSystemDump.nDummyAOMDelay ||
		m_sSystemDump.nDummyAOMDuty != gSystemINI.m_sSystemDump.nDummyAOMDuty)
	{
		strTemp.Format(_T("| DummyShot (%d), Frequency (%d), Interval (%d), Duty (%d), AOMDelay (%d), AOMDuty (%d) "), 
			m_sSystemDump.nDummyShot,
			m_sSystemDump.nDummyFreq,
			m_sSystemDump.nDummyInterval,
			m_sSystemDump.nDummyDuty,
			m_sSystemDump.nDummyAOMDelay,
			m_sSystemDump.nDummyAOMDuty);
		strMessage += strTemp;
	}
	return strMessage;
}

void CPaneSysSetupBeamDumper::GetSystemDevice(SSYSTEMDUMP *pSystemDump)
{
	memcpy( pSystemDump, &m_sSystemDump, sizeof(m_sSystemDump) );

/*	pSystemDump->nPtBeanDumper1.x = m_sSystemDump.nPtBeanDumper1.x;
	pSystemDump->nPtBeanDumper1.y = m_sSystemDump.nPtBeanDumper1.y;
	pSystemDump->nPtBeanDumper2.x = m_sSystemDump.nPtBeanDumper2.x;
	pSystemDump->nPtBeanDumper2.y = m_sSystemDump.nPtBeanDumper2.y;

	pSystemDump->nDummyShot = m_sSystemDump.nDummyShot;
	pSystemDump->nDummyInterval = m_sSystemDump.nDummyInterval;
	pSystemDump->nDummyFreq = m_sSystemDump.nDummyFreq;
	pSystemDump->nDummyDuty = m_sSystemDump.nDummyDuty;
	pSystemDump->nDummyAOMDelay = m_sSystemDump.nDummyAOMDelay;
	pSystemDump->nDummyAOMDuty = m_sSystemDump.nDummyAOMDuty;
*/
}
void CPaneSysSetupBeamDumper::OnRadioNoUse()
{
	m_nUseDummy = NO_USE;
	UpdateData(FALSE);
}
void CPaneSysSetupBeamDumper::OnRadioDumperShot()
{
	m_nUseDummy = DUMPER_SHOT;
	UpdateData(FALSE);
}
void CPaneSysSetupBeamDumper::OnRadioDummyFree()
{
	m_nUseDummy = DUMMY_FREE;
	UpdateData(FALSE);
}

BOOL CPaneSysSetupBeamDumper::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Dumper) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
