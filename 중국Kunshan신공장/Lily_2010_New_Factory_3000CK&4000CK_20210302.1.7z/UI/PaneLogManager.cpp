// PaneLogManager.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManager.h"

#include "PaneLogManagerLog.h"
#include "PaneLogManagerLot.h"
#include "PaneLogManagerLaserPower.h"
#include "PaneLogManagerFiducialScale.h"
#include "PaneLogManagerJobTime.h"
#include "PaneLogManagerOffset.h"

#include "..\model\deasydrillerini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManager

IMPLEMENT_DYNCREATE(CPaneLogManager, CFormView)

CPaneLogManager::CPaneLogManager()
	: CFormView(CPaneLogManager::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManager)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pLog			= NULL;
	m_pLot			= NULL;
	m_pLaserPower	= NULL;
	m_pOffset		= NULL;
	m_pJobTime		= NULL;
	m_nPaneNo		= 0;
}

CPaneLogManager::~CPaneLogManager()
{
}

void CPaneLogManager::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManager)
	DDX_Control(pDX, IDC_TAB_LOG, m_tabLog);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManager, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManager)
	ON_NOTIFY(NM_CLICK, IDC_TAB_LOG, OnClickTabLogManager)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManager diagnostics

#ifdef _DEBUG
void CPaneLogManager::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManager::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManager message handlers

void CPaneLogManager::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	InitTabControl();
}

void CPaneLogManager::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");

	BOOL bRet = 0;

	m_tabLog.SetFont( &m_fntTab );

	// Log
	bRet = m_tabLog.AddPane( _T(" Log "), RUNTIME_CLASS(CPaneLogManagerLog) );
	if( FALSE != bRet )
	{
		m_pLog = static_cast<CPaneLogManagerLog*>(m_tabLog.GetPane(0));
		m_pLog->OnInitialUpdate();
	}

	// Lot
	bRet = m_tabLog.AddPane( _T(" Lot "), RUNTIME_CLASS(CPaneLogManagerLot) );
	if( FALSE != bRet )
	{
		m_pLot = static_cast<CPaneLogManagerLot*>(m_tabLog.GetPane(1));
		m_pLot->OnInitialUpdate();
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure())
	{
		// Laser Power
		bRet = m_tabLog.AddPane( _T(" Laser Power "), RUNTIME_CLASS(CPaneLogManagerLaserPower) );
		if( FALSE != bRet )
		{
			m_pLaserPower = static_cast<CPaneLogManagerLaserPower*>(m_tabLog.GetPane(2));
			m_pLaserPower->OnInitialUpdate();
		}
	}

	bRet = m_tabLog.AddPane(_T(" Fiducial Scale "), RUNTIME_CLASS(CPaneLogManagerFiducialScale) );
	if(FALSE != bRet)
	{

		m_pFiducialScale = static_cast<CPaneLogManagerFiducialScale*>(m_tabLog.GetPane(3));
		m_pFiducialScale->OnInitialUpdate();
	}

	bRet = m_tabLog.AddPane(_T(" Job Time "), RUNTIME_CLASS(CPaneLogManagerJobTime) );
	if(FALSE != bRet)
	{
		
		m_pJobTime = static_cast<CPaneLogManagerJobTime*>(m_tabLog.GetPane(4));
		m_pJobTime->OnInitialUpdate();
	}

	
	bRet = m_tabLog.AddPane(_T(" Offset "), RUNTIME_CLASS(CPaneLogManagerOffset) ); 
	if(FALSE != bRet)
	{
		
		m_pOffset = static_cast<CPaneLogManagerOffset*>(m_tabLog.GetPane(5));
		m_pOffset->OnInitialUpdate();
	}

	m_tabLog.ShowPane( 0 );
}

void CPaneLogManager::OnDestroy() 
{
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneLogManager::OnClickTabLogManager(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int nSel = m_tabLog.GetCurSel();

	int nIndex = m_pLaserPower->m_cmbBeamPath.GetCurSel();
	m_pLaserPower->SetToolComboBox();
	m_pLaserPower->m_cmbBeamPath.SetCurSel(nIndex);
	switch( nSel )
	{
	case 0://log
		break;
	case 1://Lot
		break;
	case 2://Laser Power
		break;
	case 3:// Fiducial Scale
		break;
	case 4://Job Time
		break;
	case 5://Offset
		break;
	}
	m_nPaneNo = nSel;
}

