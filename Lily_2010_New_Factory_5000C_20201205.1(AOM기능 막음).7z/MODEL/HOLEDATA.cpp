// HOLEDATA.cpp: implementation of the HOLEDATA class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HOLEDATA.h"

HANDLE HOLEDATA::s_hHeap = NULL;
UINT   HOLEDATA::s_uNumAllocsInHeap = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HOLEDATA::HOLEDATA()
{
	nToolNo = -1;
	npPos.x = npPos.y = 0;
	nRefNo = 0;
	nUnitIndex = -1;
	bSelect = FALSE;
	nLPCError = FALSE;
	bCurrnetLPCError = FALSE;
	
	
	memset(&nFidIndex, -1, sizeof(nFidIndex));

	nHoleContentsIndex = OCR_FORMAT_NONE;
	memset(m_szHoleContents,0,sizeof(m_szHoleContents));
}

void* HOLEDATA::operator new(size_t nSize)
{
	if(NULL == s_hHeap)
	{
		s_hHeap = HeapCreate(0 /*HEAP_NO_SERIALIZE*/, 4*64*1024, 0);
		if(NULL == s_hHeap)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeap, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeap++;
	}
	return p;
}

void HOLEDATA::operator delete(void *p)
{
	if(HeapFree(s_hHeap, 0, p)) {
		s_uNumAllocsInHeap--;
	}
	
	if(0 == s_uNumAllocsInHeap)
	{
		if(HeapDestroy(s_hHeap)) {
			s_hHeap = NULL;
		}
	}
}

void* HOLEDATA::operator new(size_t nSize, LPCSTR lpszFileName, int nLine)
{
	//////////////////////////////////
	// MJ Choi - Modify GlyphLine New
	//////////////////////////////////
	
	if(NULL == s_hHeap)
	{
		s_hHeap = HeapCreate(0 /*HEAP_NO_SERIALIZE*/, 4*64*1024, 0);
		if(NULL == s_hHeap)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeap, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeap++;
	}
	return p;
}

void HOLEDATA::operator delete(void* p, LPCSTR lpszFileName, int nLine)
{
	if(HeapFree(s_hHeap, 0, p)) {
		s_uNumAllocsInHeap--;
	}
	
	if(0 == s_uNumAllocsInHeap)
	{
		if(HeapDestroy(s_hHeap)) {
			s_hHeap = NULL;
		}
	}
}

HoleDataList::HoleDataList()
{
	m_nCount = 0;
	m_pHeadHoleData = NULL;
	m_pTailHoleData = NULL;
}

HoleDataList::~HoleDataList()
{
	
}

int HoleDataList::GetCount()
{
	return m_nCount;
}

POSITION HoleDataList::GetHeadPosition()
{
	if(m_nCount == 0)
		return NULL;
	return ((POSITION)m_pHeadHoleData);
}

LPHOLEDATA HoleDataList::GetNext(POSITION &pos)
{
	if(m_nCount == 0)
		return NULL;

	LPHOLEDATA pData = (LPHOLEDATA)pos;
	pos = (POSITION)(pData->pNext);
	return pData;
}

void HoleDataList::AddTail(LPHOLEDATA pData)
{
	if(m_pHeadHoleData == NULL)
	{
		pData->pBefore = NULL;
		pData->pNext = NULL;
		m_pHeadHoleData = pData;
		m_pTailHoleData = pData;
	}
	else
	{
		pData->pBefore = m_pTailHoleData;
		pData->pNext = NULL;
		m_pTailHoleData->pNext = pData;
		m_pTailHoleData = pData;
	}
	m_nCount++;
}

void HoleDataList::RemoveAll()
{
	m_nCount = 0;
	m_pHeadHoleData = NULL;
	m_pTailHoleData = NULL;
}

void HoleDataList::RemoveAt(POSITION pos)
{
	if(pos == NULL)
		return;

	LPHOLEDATA pData = (LPHOLEDATA)pos;

	if(pData->pBefore)
	{
		(pData->pBefore)->pNext = pData->pNext;
		if(pData->pNext)
		{
			(pData->pNext)->pBefore = pData->pBefore;
		}
		else
		{
			m_pTailHoleData = pData->pBefore;
		}
	}
	else
	{
		if(pData->pNext)
		{
			m_pHeadHoleData = pData->pNext;
			m_pHeadHoleData->pBefore = NULL;
		}
		else
		{
			m_pHeadHoleData = m_pTailHoleData = NULL;
		}
	}
	m_nCount--;
}
