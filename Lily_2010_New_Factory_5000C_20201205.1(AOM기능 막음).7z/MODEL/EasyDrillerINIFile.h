// EasyDrillerINIFile.h: interface for the CEasyDrillerINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EASYDRILLERINIFILE_H__50ADBDEC_51D1_413A_B235_64310B7F6E85__INCLUDED_)
#define AFX_EASYDRILLERINIFILE_H__50ADBDEC_51D1_413A_B235_64310B7F6E85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DEasyDrillerINI;

class CEasyDrillerINIFile  
{
public:
	CEasyDrillerINIFile();
	virtual ~CEasyDrillerINIFile();

	BOOL	OpenINIFile(CString strFilePath, DEasyDrillerINI& clsINI);
	BOOL	ParsingHwOption(CStdioFile& sFile, DEasyDrillerINI& clsINI);
	BOOL	ParsingDirPath(CStdioFile& sFile, DEasyDrillerINI& clsINI);

	BOOL	SaveINIFile(CString strFilePath, DEasyDrillerINI clsINI);
	BOOL	SaveHwOption(CStdioFile& sFile, DEasyDrillerINI clsINI);
	BOOL	SaveDirPath(CStdioFile& sFile, DEasyDrillerINI clsINI);

	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_EASYDRILLERINIFILE_H__50ADBDEC_51D1_413A_B235_64310B7F6E85__INCLUDED_)
