// GlobalVariable.cpp: implementation of the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "GlobalVariable.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\MODEL\DProcessINI.h"
#include "DShotTableINI.h"
#include "DBeampathINI.h"
#include "DAutoManualScaleINI.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
GlobalVariable gVariable;

GlobalVariable::GlobalVariable()
{
	m_strPath.Format(_T(""));
	m_strPath2.Format(_T(""));
	memset( &m_sGlobal, 0, sizeof(m_sGlobal) );
	Initialize();
	m_bOpenProject = FALSE;
	m_strBackupLaserComp = _T("");
	m_strBackupLaserSold = _T("");
	m_strBackupRecipeComp = _T("");
	m_strBackupRecipeSold = _T("");
		m_bNoUseVisionCompen = FALSE;
	m_nGlobalDummyType = 0;
	m_bGrobalDutyOffsetCompenMode = FALSE;
	InitFirstPulseCheckFlag();

	m_bUseSkiveAutoSetting = FALSE;
	for(int i=0; i<2; i++)
	{
		m_dGlobal_FidScaleX[i] = 100;
		m_dGlobal_FidScaleY[i] = 100;
	}
}

GlobalVariable::~GlobalVariable()
{
//	SaveGlobalTool();
//	SaveRefuseList();

	for(int i=0; i<MAX_TOOL_NO; i++)
	{
		delete m_pToolCode[i];
		m_pToolCode[i] = NULL;
	}

	if(m_pRefuse != NULL)
	{
		delete m_pRefuse;
		m_pRefuse = NULL;
	}
}

void GlobalVariable::Initialize()
{
	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = new CToolCodeList;
		m_pToolCode[i]->Initialize();
		if(i < 1)
			m_pToolCode[i]->m_bUseTool = TRUE;
	}
//	LoadGlobalTool();
	
	m_pRefuse = new CRefuseList;
	m_pRefuse->Initialize();
}

BOOL GlobalVariable::SaveGlobalTool()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10033);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadGlobalTool()
{

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeRead))
		{
			return FALSE;
		}
		
//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10033);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::SaveRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeRead))
		{
			return FALSE;
		}

//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

void GlobalVariable::Serialize(CArchiveMark &ar, int nVersion, int nMode)
{

	TRY
	{
		if (ar.IsStoring())
		{	// storing code

			if(nMode == 0)
			{
				m_nVersion = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion << _T("\n");
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->SaveFile10000(ar, m_nVersion);
					}
				}
			}
			else
			{
				m_nVersion2 = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion2 << _T("\n");
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->SaveFile10000(ar, m_nVersion2);
				}
			}
		}
		else
		{	// loading code

			if(nMode == 0)
			{
				ar >> m_nVersion; 
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->LoadFile10000(ar, m_nVersion, TRUE);
					}
				}
			}
			else
			{
				ar >> m_nVersion2; 
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->LoadFile10000(ar, m_nVersion2);
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
	}
	END_CATCH
}

void GlobalVariable::SetPath()
{
	m_strPath.Format(_T("%sGlobalTool.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	m_strPath2.Format(_T("%sRefuseList.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
}

double GlobalVariable::GetLMDuty_us(int nFrq ,double dDutyPercent)//20160627
{

	double dMaxLM_us = 1/(double)nFrq * 1000000. ;

	double dTagetLM_us = dDutyPercent/100 * dMaxLM_us;

	return dTagetLM_us;
}
void GlobalVariable::GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax)
{
	//Get Min,Max Power
	double dGap = dTagetPower * dTol/100;

	dMin = dTagetPower - dGap;
	dMax = dTagetPower + dGap;
}

BOOL GlobalVariable::IsValidateTableModulationData(SBEAMPATH sBeampath , SSHOTGROUPTABLE sShotGroupTable,BOOL bPowerCompen)//20160626
{
	int nToolCount = sBeampath.nLastIndex;
	double dOntimeOffsetM[12];
	double dOntimeOffsetS[12];

	for(int k =  0; k < 12; k++)
	{
		dOntimeOffsetM[k] = 0;
		dOntimeOffsetS[k] = 0;
	}
	for(int nShotTableIndex = 0; nShotTableIndex <= sShotGroupTable.nGroupLastIndex; nShotTableIndex++)
	{
		//int nShotTableIndex = sBeampath.nSelectShot[nToolNo];

		double dMasterDutyOffset = 0;//sToolTable.dMasterDutyOffset[nToolNo];
		double dSlaveDutyOffset = 0;//sToolTable.dSlaveDutyOffset[nToolNo];

		int nPulseCount = sShotGroupTable.nTotalShotCount[nShotTableIndex];
		BOOL bUseAom = sShotGroupTable.bUseAom[nShotTableIndex];

		//---------------------------------
		for(int nPulseNo = 0; nPulseNo < nPulseCount; nPulseNo++)
		{

			if(sShotGroupTable.nTotalShotCount[nShotTableIndex] < nPulseNo)//20160628
				continue;

			if(nPulseNo != 0)//First Pulse Only
			{
				dMasterDutyOffset = 0;
				dSlaveDutyOffset = 0;
			}


			int nFrq = sShotGroupTable.nShotFrequency[nShotTableIndex];
			double dLM_us = sShotGroupTable.dShotLMDuty_us[nShotTableIndex];

			double dDutyLimit = gProcessINI.m_sProcessOption.dDutyLimit;//9;//9% Fix
			double dDutyPercent = sShotGroupTable.dShotDuty_Percent[nShotTableIndex];
			

			
			double dMaxDuty = 1/(double)nFrq * 1000000. ;    
			double dInsertDuty = dLM_us/dMaxDuty * 100.;


			//---------------------------------

			double dOnTime_M = sShotGroupTable.m_sShotParam[nShotTableIndex].dOnTime_M[nPulseNo];
			double dOnTime_S = sShotGroupTable.m_sShotParam[nShotTableIndex].dOnTime_S[nPulseNo];

			double dWait_M = sShotGroupTable.m_sShotParam[nShotTableIndex].dAOMWait_M[nPulseNo];
			double dWait_S = sShotGroupTable.m_sShotParam[nShotTableIndex].dAOMWait_S[nPulseNo];


			dOnTime_M += dMasterDutyOffset;
			dOnTime_S += dSlaveDutyOffset;

			int nAOMNoCnt1 = sShotGroupTable.m_sShotParam[nShotTableIndex].nAOMNum_M[nPulseNo];
			int nAOMNoCnt2 = sShotGroupTable.m_sShotParam[nShotTableIndex].nAOMNum_S[nPulseNo];

			for(int k = 0; k < nAOMNoCnt1; k++)
			{
				dOntimeOffsetM[k] = (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo]) / nAOMNoCnt1;
			}
			for(int k = 0; k < nAOMNoCnt2; k++)
			{
				dOntimeOffsetS[k] = (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]) / nAOMNoCnt2;
			}
			dOnTime_M += (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo]);
			dOnTime_S += (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]);
			//---------------------------------
			double dAOMSum1 =0,dAOMSum2 =0;  
			for(int nAOM1 = 0; nAOM1 < nAOMNoCnt1; nAOM1++)
			{
				if(nAOM1 == 0)
					dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_M[nAOM1] + dMasterDutyOffset + dOntimeOffsetM[nAOM1];
				else
					dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_M[nAOM1] + dOntimeOffsetM[nAOM1];

				dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_OFF_M[nAOM1];
			}

			for(int nAOM2 = 0; nAOM2 < nAOMNoCnt2; nAOM2++)
			{
				if(nAOM2 == 0)
					dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_S[nAOM2] + dSlaveDutyOffset + dOntimeOffsetS[nAOM2];
				else
					dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_S[nAOM2] + dOntimeOffsetS[nAOM2];

				dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_OFF_S[nAOM2];
			}

			CString strShow;
			CString strCR = "\n";
			//---------------------------------
			//Table Info
			CString strInfo;
			strInfo.Format(" [Tool Info] \n");
			strShow +=strInfo;
			strInfo.Format("Shot No:[%d] ,Pulse No:[%d] \n",nShotTableIndex,nPulseNo);
			strShow +=strInfo;
			strInfo.Format(" LM Offset  M:%.2f ,S:%.2f \n",dMasterDutyOffset,dSlaveDutyOffset);
			strShow +=strInfo;
			strInfo.Format(" Frquency :%d hz , LM :%.2f us \n",nFrq,dLM_us);
			strShow +=strInfo;
			strInfo.Format(" OffsetM :%.2f , OffsetS :%.2f \n",
				sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo] ,
				sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]);
			strShow +=strInfo;
			strShow +=strCR;
			//---------------------------------
			CString strIErrorInfo;
			strIErrorInfo.Format(" [Error Info] \n");
			strShow +=strIErrorInfo;
			double dDutyLimitGap = dLM_us * 0.0;//0%


			//Error1
			if(bUseAom)
			{
				if((dOnTime_M + dWait_M) - dLM_us  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [1] (OnTime+ Wait) Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us , Limit: %.2f us  ([1]OnTime: %.2f us + Wait: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_M,dWait_M);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
				//Error1
				if( (dOnTime_S + dWait_S) - dLM_us  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [2] (OnTime+ Wait) Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us, Limit: %.2f us  ([1]OnTime: %.2f us + Wait: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_S,dWait_S);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
			}
			else
			{
				if((dOnTime_M - dLM_us)  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [1] OnTime Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us , Limit: %.2f us  ([1]OnTime: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_M);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
				//Error1
				if( (dOnTime_S - dLM_us)  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [2] OnTime Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us, Limit: %.2f us  ([1]OnTime: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_S);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
			}
			
			//Error2
			double dTempDutyLimit = GetLMDuty_us(nFrq,gProcessINI.m_sProcessOption.dDutyLimit);


			if(dLM_us > dTempDutyLimit)
			{
				strIErrorInfo.Format(" LM(us) Tool High Error (%.2f us Over) \n",dTempDutyLimit);
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" Insert LM: %.2f us \n",dLM_us);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}

			//Error3
			if((int)(dOnTime_M*1000) < (int)(dAOMSum1*1000))
			{
				strIErrorInfo.Format(" AOM [1] SUM Error \n");
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" [1]OnTime: %.2f us ,AOM SUM ([1]:%.2f ) \n",dOnTime_M,dAOMSum1);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					
					ErrMessage(strShow);
				return FALSE;
			}
			//Error3
			if((int)(dOnTime_S*1000) < (int)(dAOMSum2*1000))
			{
				strIErrorInfo.Format(" AOM [2] SUM Error \n");
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" [2]OnTime: %.2f us ,AOM SUM ([2]:%.2f ) \n",dOnTime_S,dAOMSum2);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}

			//Error4

			if(dDutyLimit < dInsertDuty)
			{
				strIErrorInfo.Format(" Duty Limit Over Error \n");
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" Duty Limit: %.2f  (Insert Duty: %.2f ,LM: %.2f us)  \n",dDutyLimit,dInsertDuty,dLM_us);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}
			//-----------------------


			////Error5
			//if(dWait_M > gProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit)
			//{
			//	strIErrorInfo.Format(" Wait Time Over Error \n");
			//	strShow +=strIErrorInfo;
			//	strIErrorInfo.Format(" Wait Time Limit : %.2f  (Wait Time : %.2f us)  \n",gProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit,dWait_M);
			//	strShow +=strIErrorInfo;
			//	if(bPowerCompen)
			//		ErrMessage(_T("Power ComPen Fail"));
			//	ErrMessage(strShow);
			//	return FALSE;
			//}
		}
	}

	return TRUE;
}

BOOL GlobalVariable::IsValidateTableModulationPowerCompen(int nHeadMode,double dNewDutyOffset1,double dNewDutyOffset2,int nToolTableNo, double dNewOntimeOffset1, double dNewOntimeOffset2)
{	
	if(dNewDutyOffset1 == 0 && dNewDutyOffset2 == 0 && dNewOntimeOffset1 == 0 && dNewOntimeOffset2 == 0)
		return TRUE;

	memcpy( &m_sgShotGroupTablePower, &gShotTableINI.m_sShotGroupTable, sizeof(gShotTableINI.m_sShotGroupTable) );

	CString strEvent, strInfo;
	int nMask = nToolTableNo;

	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nToolTableNo];

	int nPulseCount = gShotTableINI.m_sShotGroupTable.nTotalShotCount[nShotIndex];


	for(int nPulseNo = 0; nPulseNo < nPulseCount; nPulseNo++)
	{
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dAOMWait_M[nPulseNo] += dNewDutyOffset1;
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dAOMWait_S[nPulseNo] += dNewDutyOffset2;
			
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dOntimeOffset_M[nPulseNo] += dNewOntimeOffset1;
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dOntimeOffset_S[nPulseNo] += dNewOntimeOffset2;
	}

	if(!IsValidateTableModulationData(gBeamPathINI.m_sBeampath, m_sgShotGroupTablePower, TRUE))
	{
		return FALSE;
	}

	return TRUE;
}

void GlobalVariable::InitFirstPulseCheckFlag()
{
	for(int ii = 0; ii < BEAMPATH_COUNT; ii++)
		m_bFirstPulseCheckFlag[ii] = FALSE;
}