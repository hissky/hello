// DShotTableINI.h: interface for the DShotTableINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSHOTTABLEINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)
#define AFX_DSHOTTABLEINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DShotTableINI  
{
public:
	DShotTableINI();
	virtual ~DShotTableINI();

	SSHOTGROUPTABLE		m_sShotGroupTable;
};

extern DShotTableINI gShotTableINI;

#endif // !defined(AFX_DSHOTTABLEINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)
