// HOLECONVERTDATA.cpp: implementation of the HOLECONVERTDATA class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HOLECONVERTDATA.h"

HANDLE HOLECONVERTDATA::s_hHeapCvt = NULL;
UINT   HOLECONVERTDATA::s_uNumAllocsInHeapCvt = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HOLECONVERTDATA::HOLECONVERTDATA()
{
	npPos1.x = npPos1.y = 0;
	npPos2.x = npPos2.y = 0;
	bSelect = FALSE;
	bDistanceSortingFinish = FALSE;
//	nUnitIndex = -1;
	bFindHole = FALSE;
}

void* HOLECONVERTDATA::operator new(size_t nSize)
{
	if(NULL == s_hHeapCvt)
	{
		s_hHeapCvt = HeapCreate(0 /*HEAP_NO_SERIALIZE*/, 4*64*1024, 0);
		if(NULL == s_hHeapCvt)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeapCvt, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeapCvt++;
	}
	return p;
}

void HOLECONVERTDATA::operator delete(void *p)
{
	if(HeapFree(s_hHeapCvt, 0, p)) {
		s_uNumAllocsInHeapCvt--;
	}
	
	if(0 == s_uNumAllocsInHeapCvt)
	{
		if(HeapDestroy(s_hHeapCvt)) {
			s_hHeapCvt = NULL;
		}
	}
}

void* HOLECONVERTDATA::operator new(size_t nSize, LPCSTR lpszFileName, int nLine)
{
	//////////////////////////////////
	// MJ Choi - Modify GlyphLine New
	//////////////////////////////////
	
	if(NULL == s_hHeapCvt)
	{
		s_hHeapCvt = HeapCreate(0 /*HEAP_NO_SERIALIZE*/, 4*64*1024, 0);
		if(NULL == s_hHeapCvt)
			return NULL;
	}
	
	void* p = HeapAlloc(s_hHeapCvt, 0, nSize);
	if(NULL != p) {
		s_uNumAllocsInHeapCvt++;
	}
	return p;
}

void HOLECONVERTDATA::operator delete(void* p, LPCSTR lpszFileName, int nLine)
{
	if(HeapFree(s_hHeapCvt, 0, p)) {
		s_uNumAllocsInHeapCvt--;
	}
	
	if(0 == s_uNumAllocsInHeapCvt)
	{
		if(HeapDestroy(s_hHeapCvt)) {
			s_hHeapCvt = NULL;
		}
	}
}

FireHoleList::FireHoleList()
{
	m_nCount = 0;
	m_pHeadHoleConvertData = NULL;
	m_pTailHoleConvertData = NULL;
}

FireHoleList::~FireHoleList()
{
	
}

int FireHoleList::GetCount()
{
	return m_nCount;
}

POSITION FireHoleList::GetHeadPosition()
{
	if(m_nCount == 0)
		return NULL;
	return ((POSITION)m_pHeadHoleConvertData);
}

POSITION FireHoleList::GetTailPosition()
{
	if(m_nCount == 0)
		return NULL;
	return ((POSITION)m_pTailHoleConvertData);
}

LPFIREHOLE FireHoleList::GetNext(POSITION &pos)
{
	if(m_nCount == 0)
		return NULL;

	LPFIREHOLE pData = (LPFIREHOLE)pos;
	pos = (POSITION)(pData->pNext);
	return pData;
}

LPFIREHOLE FireHoleList::GetPrev(POSITION &pos)
{
	if(m_nCount == 0)
		return NULL;

	LPFIREHOLE pData = (LPFIREHOLE)pos;
	pos = (POSITION)(pData->pBefore);
	return pData;
}

void FireHoleList::AddTail(LPFIREHOLE pData)
{
	if(m_pHeadHoleConvertData == NULL)
	{
		pData->pBefore = NULL;
		pData->pNext = NULL;
		m_pHeadHoleConvertData = pData;
		m_pTailHoleConvertData = pData;
	}
	else
	{
		pData->pBefore = m_pTailHoleConvertData;
		pData->pNext = NULL;
		m_pTailHoleConvertData->pNext = pData;
		m_pTailHoleConvertData = pData;
	}
	m_nCount++;
}
void FireHoleList::AddHead(LPFIREHOLE pData)
{
	if(m_pHeadHoleConvertData == NULL)
	{
		pData->pBefore = NULL;
		pData->pNext = NULL;
		m_pHeadHoleConvertData = pData;
		m_pTailHoleConvertData = pData;
	}
	else
	{
		m_pHeadHoleConvertData->pBefore = pData;
		pData->pNext  = m_pHeadHoleConvertData;
		pData->pBefore = NULL;
		m_pHeadHoleConvertData = pData;
	}
	m_nCount++;
}
void FireHoleList::RemoveAll()
{
	m_nCount = 0;
	m_pHeadHoleConvertData = NULL;
	m_pTailHoleConvertData = NULL;
}

void FireHoleList::RemoveAt(POSITION pos)
{
	if(pos == NULL)
		return;

	LPFIREHOLE pData = (LPFIREHOLE)pos;

	if(pData->pBefore)
	{
		(pData->pBefore)->pNext = pData->pNext;
		if(pData->pNext)
		{
			(pData->pNext)->pBefore = pData->pBefore;
		}
		else
		{
			m_pTailHoleConvertData = pData->pBefore;
		}
	}
	else
	{
		if(pData->pNext)
		{
			m_pHeadHoleConvertData = pData->pNext;
			m_pHeadHoleConvertData->pBefore = NULL;
		}
		else
		{
			m_pHeadHoleConvertData = m_pTailHoleConvertData = NULL;
		}
	}
	m_nCount--;
}
