#pragma once

#include "..\Device\BicubicInterpolation.h"

#define ATTEN_MAX_VAL		3600
#define ATTEN_CYCLE			900

class DPowerAttenCompensation
{
public:
	DPowerAttenCompensation(void);
	~DPowerAttenCompensation(void);
	void SetRawData(double dPowerVal);
	void SetCount(int nCount, double dDeltaAttenPos, double dStartAttenPos);
	BOOL MakeTable(BOOL b1stPanel);
	BOOL SaveFile(int n1st2ndIndex); 
	BOOL LoadFile(int n1st2ndIndex);
	BOOL IsTableOK(int n1st2ndIndex);
	int GetTagerAttenPos(int n1st2ndIndex, double dTagetPower, double dCurrentPower, int nCurrentAttenPos);

private:
	int m_nAddCount;
	int m_nCount;
	CALHEAD m_calHead;

	double m_dPowerPercent[2][ATTEN_MAX_VAL];
	int m_nStartAttenPos[2];
	int m_nEndAttenPos[2];

	BOOL m_bCompenOK[2];


};

