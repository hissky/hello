// TSP.h: interface for the TSP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TSP_H__6B588B6B_3948_4D06_81BF_F91C6225ACB4__INCLUDED_)
#define AFX_TSP_H__6B588B6B_3948_4D06_81BF_F91C6225ACB4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define DISTANCE_XY		0
#define X_Y_MAX_DIS		1


struct TSP_HOLE {
	double		dX;
	double		dY;
	int			nIndex;
};

class AFX_EXT_CLASS TSP  
{
public:
	int RunTSP();
	BOOL AddHole(double dx, double dy);
	void SetSortCount(int nCnt);
	void ResetSortData();
	BOOL m_bRunSilent;
	int m_nRepeatNo;
	int m_nEdgeWeightType;
	int m_nSortCount;
	int m_nCurCount;
	int m_nDistOption;
	double m_dXWeight;
	double m_dYWeight;
	BOOL m_bAddDist;
	TSP_HOLE*	m_pSortHoles;

	void SetRunParam(BOOL bRunSilent, int nRepeatNo, int nEdgeWeightType, int nDistOption, double dXWeight, double dYWeight, BOOL bAddDist = FALSE);
	TSP();
	virtual ~TSP();

};

#endif // !defined(AFX_TSP_H__6B588B6B_3948_4D06_81BF_F91C6225ACB4__INCLUDED_)
