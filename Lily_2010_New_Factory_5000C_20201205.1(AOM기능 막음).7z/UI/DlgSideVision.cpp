// DlgSideVision.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgSideVision.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionProView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSideVision dialog


CDlgSideVision::CDlgSideVision(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSideVision::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSideVision)
	// NOTE: the ClassWizard will add member initialization here
	m_bInit = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgSideVision::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSideVision)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSideVision, CDialog)
	//{{AFX_MSG_MAP(CDlgSideVision)
	ON_WM_MOVE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSideVision message handlers

void CDlgSideVision::GetDlgSize(CRect &rc)
{

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( &rc );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( &rc );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( &rc );
	}

}

void CDlgSideVision::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	if(!m_bInit)
		return;
	// TODO: Add your message handler code here
	CRect rtPos;
	GetDlgSize( rtPos );
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->m_bTopMost = TRUE;

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->m_bTopMost = FALSE;

}

void CDlgSideVision::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	CRect rc;
	GetWindowRect( &rc);

	int nRect[4];
	nRect[0] = rc.left + 10;
	nRect[1] = rc.right - 10;
	nRect[2] = rc.top + 10;
	nRect[3] = rc.bottom - 10;



	::AfxGetMainWnd()->SendMessage(UM_RESIZE_VISION, reinterpret_cast<WPARAM>(&nRect));
/*	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->MoveWindow( &rc );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->MoveWindow( &rc );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->MoveWindow( &rc );
	}
	*/
	// TODO: Add your message handler code here
	
}


BOOL CDlgSideVision::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_bInit = TRUE;
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSideVision::SetTopMost(BOOL bTopmost)
{
	if(bTopmost)
		::SetWindowPos(GetSafeHwnd(), HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);
	else
		::SetWindowPos(GetSafeHwnd(), HWND_NOTOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);

}
