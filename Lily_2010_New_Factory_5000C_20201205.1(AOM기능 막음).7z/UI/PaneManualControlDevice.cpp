// PaneManualControlDevice.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlDevice.h"
#include "DlgMeasuringPCBThickness.h"
#include "..\model\dprocessini.h"
#include "..\model\deasydrillerini.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\easydrillerdlg.h"
#include "..\device\HMotor.h"
#include "paneautorun.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlDevice

IMPLEMENT_DYNCREATE(CPaneManualControlDevice, CFormView)

CPaneManualControlDevice::CPaneManualControlDevice()
	: CFormView(CPaneManualControlDevice::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlDevice)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_b1stSht			= FALSE;
	m_b2ndSht			= FALSE;
	m_bPowermeter		= FALSE;
	m_bHeightSensor		= FALSE;
	m_bPowermeter2nd	= FALSE;
	m_bHeightSensor2nd	= FALSE;
}

CPaneManualControlDevice::~CPaneManualControlDevice()
{
}

void CPaneManualControlDevice::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlDevice)
	DDX_Control(pDX, IDC_STATIC_2ND_THICKNESS, m_stc2ndThickness);
	DDX_Control(pDX, IDC_STATIC_1ST_THICKNESS, m_stc1stThickness);
	DDX_Control(pDX, IDC_BUTTON_MEASURING, m_btnMeasuring);
	DDX_Control(pDX, IDC_BUTTON_POWERMETER_OPEN, m_btnPowermeterOpen);
	DDX_Control(pDX, IDC_BUTTON_POWERMETER_CLOSE, m_btnPowermeterClose);
	DDX_Control(pDX, IDC_BUTTON_POWERMETER_OPEN_2ND, m_btnPowermeterOpen2nd);
	DDX_Control(pDX, IDC_BUTTON_POWERMETER_CLOSE_2ND, m_btnPowermeterClose2nd);
	DDX_Control(pDX, IDC_BUTTON_HEIGHT_SENSOR_DOWN, m_btnHSensorDown);
	DDX_Control(pDX, IDC_BUTTON_HEIGHT_SENSOR_UP, m_btnHSensorUp);
	DDX_Control(pDX, IDC_BUTTON_HEIGHT_SENSOR_DOWN_2ND, m_btnHSensorDown2nd);
	DDX_Control(pDX, IDC_BUTTON_HEIGHT_SENSOR_UP_2ND, m_btnHSensorUp2nd);
	DDX_Control(pDX, IDC_BUTTON_2ND_SHT_OPEN, m_btn2ndShtOpen);
	DDX_Control(pDX, IDC_BUTTON_2ND_SHT_CLOSE, m_btn2ndShtClose);
	DDX_Control(pDX, IDC_BUTTON_1ST_SHT_OPEN, m_btn1stShtOpen);
	DDX_Control(pDX, IDC_BUTTON_1ST_SHT_CLOSE, m_btn1stShtClose);
	DDX_Control(pDX, IDC_BUTTON_MOVE_MASK_POS, m_btnMoveMaskPos);
	DDX_Control(pDX, IDC_BUTTON_MOVE_MASK, m_btnMoveMask);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_HOMING, m_btnUnloaderHoming);
	DDX_Control(pDX, IDC_BUTTON_LOADER_HOMING, m_btnLoaderHoming);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_HOMING, m_btnMotorHoming);
	DDX_Control(pDX, IDC_EDIT_MASK_POS, m_edtMaskPos);
	DDX_Control(pDX, IDC_COMBO_MASK, m_cmbMask);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlDevice, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlDevice)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_MEASURING, OnButtonMeasuring)
	ON_BN_CLICKED(IDC_BUTTON_1ST_SHT_OPEN, OnButton1stShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_1ST_SHT_CLOSE, OnButton1stShtClose)
	ON_BN_CLICKED(IDC_BUTTON_2ND_SHT_OPEN, OnButton2ndShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_2ND_SHT_CLOSE, OnButton2ndShtClose)
	ON_BN_CLICKED(IDC_BUTTON_POWERMETER_OPEN, OnButtonPowermeterOpen)
	ON_BN_CLICKED(IDC_BUTTON_POWERMETER_CLOSE, OnButtonPowermeterClose)
	ON_BN_CLICKED(IDC_BUTTON_POWERMETER_OPEN_2ND, OnButtonPowermeterOpen2nd)
	ON_BN_CLICKED(IDC_BUTTON_POWERMETER_CLOSE_2ND, OnButtonPowermeterClose2nd)
	ON_BN_CLICKED(IDC_BUTTON_HEIGHT_SENSOR_UP, OnButtonHeightSensorUp)
	ON_BN_CLICKED(IDC_BUTTON_HEIGHT_SENSOR_DOWN, OnButtonHeightSesnorDown)
	ON_BN_CLICKED(IDC_BUTTON_HEIGHT_SENSOR_UP_2ND, OnButtonHeightSensorUp2nd)
	ON_BN_CLICKED(IDC_BUTTON_HEIGHT_SENSOR_DOWN_2ND, OnButtonHeightSensorDown2nd)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_HOMING, OnButtonMotorHoming)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_HOMING, OnButtonLoaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_HOMING, OnButtonUnloaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_MASK, OnButtonMaskMoveNum)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_MASK_POS, OnButtonMaskMovePos)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlDevice diagnostics

#ifdef _DEBUG
void CPaneManualControlDevice::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlDevice::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlDevice message handlers

void CPaneManualControlDevice::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitComboControl();
}

BOOL CPaneManualControlDevice::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}


void CPaneManualControlDevice::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Height Sensor Measurement
	GetDlgItem(IDC_STATIC_HEIGTH_SENSOR_MEASUREMENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_1ST_THICKNESS)->SetFont( &m_fntStatic );
	m_stc1stThickness.SetFont( &m_fntStatic );
	m_stc1stThickness.SetForeColor( VALUE_FORE_COLOR );
	m_stc1stThickness.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_2ND_PANEL)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_2ND_THICKNESS)->SetFont( &m_fntStatic );
	m_stc2ndThickness.SetFont( &m_fntStatic );
	m_stc2ndThickness.SetForeColor( VALUE_FORE_COLOR );
	m_stc2ndThickness.SetBackColor( VALUE_BACK_COLOR );

	// Homing
	GetDlgItem(IDC_STATIC_HOMING)->SetFont( &m_fntStatic );

	// Mask
	GetDlgItem(IDC_STATIC_MASK)->SetFont( &m_fntStatic );

	// 1'st Panel Shutter
	GetDlgItem(IDC_STATIC_1ST_PANEL_SHUTTER)->SetFont( &m_fntStatic );

	// 2'nd Panel Shutter
	GetDlgItem(IDC_STATIC_2ND_PANEL_SHUTTER)->SetFont( &m_fntStatic );
	
	// 1'st Powermeter
	GetDlgItem(IDC_STATIC_POWERMETER)->SetFont( &m_fntStatic );

	// 2'nd Powermeter
	GetDlgItem(IDC_STATIC_POWERMETER_2ND)->SetFont( &m_fntStatic );

	// 1'st Height Sensor
	GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->SetFont( &m_fntStatic );

	// 2'nd Height Sensor
	GetDlgItem(IDC_STATIC_HEIGHT_SENSOR_2ND)->SetFont( &m_fntStatic );

	if( 1 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_stc1stThickness.EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_1ST_PANEL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->EnableWindow(FALSE);
		m_btnHSensorUp.EnableWindow(FALSE);
		m_btnHSensorDown.EnableWindow(FALSE);
		m_btnMeasuring.EnableWindow(FALSE);
	}
	if( 2 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_stc2ndThickness.EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_2ND_PANEL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR_2ND)->EnableWindow(FALSE);
		m_btnHSensorUp2nd.EnableWindow(FALSE);
		m_btnHSensorDown2nd.EnableWindow(FALSE);
	}
}

void CPaneManualControlDevice::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Height Sensor Measurement
	m_btnMeasuring.SetFont( &m_fntBtn );
	m_btnMeasuring.SetFlat( FALSE );
	m_btnMeasuring.EnableBallonToolTip();
	m_btnMeasuring.SetToolTipText( _T("Measurement") );
	m_btnMeasuring.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMeasuring.SetBtnCursor(IDC_HAND_1);

	// Homing
	m_btnMotorHoming.SetFont( &m_fntBtn );
	m_btnMotorHoming.SetFlat( FALSE );
	m_btnMotorHoming.EnableBallonToolTip();
	m_btnMotorHoming.SetToolTipText( _T("Motor Homing") );
	m_btnMotorHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMotorHoming.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderHoming.SetFont( &m_fntBtn );
	m_btnLoaderHoming.SetFlat( FALSE );
	m_btnLoaderHoming.EnableBallonToolTip();
	m_btnLoaderHoming.SetToolTipText( _T("Loader Homing") );
	m_btnLoaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderHoming.SetBtnCursor(IDC_HAND_1);

	m_btnUnloaderHoming.SetFont( &m_fntBtn );
	m_btnUnloaderHoming.SetFlat( FALSE );
	m_btnUnloaderHoming.EnableBallonToolTip();
	m_btnUnloaderHoming.SetToolTipText( _T("Unloader Homing") );
	m_btnUnloaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderHoming.SetBtnCursor(IDC_HAND_1);

	// Mask
	m_btnMoveMask.SetFont( &m_fntBtn );
	m_btnMoveMask.SetFlat( FALSE );
	m_btnMoveMask.EnableBallonToolTip();
	m_btnMoveMask.SetToolTipText( _T("Move Mask") );
	m_btnMoveMask.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveMask.SetBtnCursor(IDC_HAND_1);

	m_btnMoveMaskPos.SetFont( &m_fntBtn );
	m_btnMoveMaskPos.SetFlat( FALSE );
	m_btnMoveMaskPos.EnableBallonToolTip();
	m_btnMoveMaskPos.SetToolTipText( _T("Move Mask Position") );
	m_btnMoveMaskPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveMaskPos.SetBtnCursor(IDC_HAND_1);

	// 1'st Panel Shutter
	m_btn1stShtOpen.SetFont( &m_fntBtn );
	m_btn1stShtOpen.SetRectAlign( 1 );
	m_btn1stShtOpen.SetToolTipText( _T("1'st Panel Shutter Open") );
	m_btn1stShtOpen.SetBtnCursor(IDC_HAND_1);

	m_btn1stShtClose.SetFont( &m_fntBtn );
	m_btn1stShtClose.SetRectAlign( 1 );
	m_btn1stShtClose.SetToolTipText( _T("1'st Panel Shutter Close") );
	m_btn1stShtClose.SetBtnCursor(IDC_HAND_1);

	// 2'nd Panel Shutter
	m_btn2ndShtOpen.SetFont( &m_fntBtn );
	m_btn2ndShtOpen.SetRectAlign( 1 );
	m_btn2ndShtOpen.SetToolTipText( _T("2'nd Panel Shutter Open") );
	m_btn2ndShtOpen.SetBtnCursor(IDC_HAND_1);

	m_btn2ndShtClose.SetFont( &m_fntBtn );
	m_btn2ndShtClose.SetRectAlign( 1 );
	m_btn2ndShtClose.SetToolTipText( _T("2'nd Panel Shutter Close") );
	m_btn2ndShtClose.SetBtnCursor(IDC_HAND_1);

	// 1'st Powermeter
	m_btnPowermeterOpen.SetFont( &m_fntBtn );
	m_btnPowermeterOpen.SetRectAlign( 1 );
	m_btnPowermeterOpen.SetToolTipText( _T("1'st Powermeter Open") );
	m_btnPowermeterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnPowermeterClose.SetFont( &m_fntBtn );
	m_btnPowermeterClose.SetRectAlign( 1 );
	m_btnPowermeterClose.SetToolTipText( _T("1'st Powermeter Close") );
	m_btnPowermeterClose.SetBtnCursor(IDC_HAND_1);

	// 2'nd Powermeter
	m_btnPowermeterOpen2nd.SetFont( &m_fntBtn );
	m_btnPowermeterOpen2nd.SetRectAlign( 1 );
	m_btnPowermeterOpen2nd.SetToolTipText( _T("2'nd Powermeter Open") );
	m_btnPowermeterOpen2nd.SetBtnCursor(IDC_HAND_1);
	
	m_btnPowermeterClose2nd.SetFont( &m_fntBtn );
	m_btnPowermeterClose2nd.SetRectAlign( 1 );
	m_btnPowermeterClose2nd.SetToolTipText( _T("2'nd Powermeter Close") );
	m_btnPowermeterClose2nd.SetBtnCursor(IDC_HAND_1);

	// 1'st Height Sensor
	m_btnHSensorUp.SetFont( &m_fntBtn );
	m_btnHSensorUp.SetRectAlign( 1 );
	m_btnHSensorUp.SetToolTipText( _T("1'st Height Sensor Up") );
	m_btnHSensorUp.SetBtnCursor(IDC_HAND_1);

	m_btnHSensorDown.SetFont( &m_fntBtn );
	m_btnHSensorDown.SetRectAlign( 1 );
	m_btnHSensorDown.SetToolTipText( _T("1'st Height Sensor Down") );
	m_btnHSensorDown.SetBtnCursor(IDC_HAND_1);

	// 2'nd Height Sensor
	m_btnHSensorUp2nd.SetFont( &m_fntBtn );
	m_btnHSensorUp2nd.SetRectAlign( 1 );
	m_btnHSensorUp2nd.SetToolTipText( _T("2'nd Height Sensor Up") );
	m_btnHSensorUp2nd.SetBtnCursor(IDC_HAND_1);
	
	m_btnHSensorDown2nd.SetFont( &m_fntBtn );
	m_btnHSensorDown2nd.SetRectAlign( 1 );
	m_btnHSensorDown2nd.SetToolTipText( _T("2'nd Height Sensor Down") );
	m_btnHSensorDown2nd.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlDevice::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(160, "Arial Bold");

	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbMask.SetCurSel( 0 );
}

void CPaneManualControlDevice::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(160, "Arial Bold");

	// Mask Position
	m_edtMaskPos.SetFont( &m_fntEdit );
	m_edtMaskPos.SetReceivedFlag( 3 );
	m_edtMaskPos.SetWindowText( _T("0.0") );
}

HBRUSH CPaneManualControlDevice::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_HEIGTH_SENSOR_MEASUREMENT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HOMING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MASK)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_1ST_PANEL_SHUTTER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_PANEL_SHUTTER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POWERMETER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POWERMETER_2ND)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR_2ND)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlDevice::OnButtonMeasuring() 
{
	if( gDeviceFactory.GetMotor()->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	CDlgMeasuringPCBThickness dlg;

	dlg.SetBaseZ( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
		gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualX,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualY,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
	dlg.AutoSelectHead(0);
	dlg.SelectHead(0);
	if(dlg.DoModal() == IDOK)
	{
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 0)
		{
			double dThickness = dlg.GetHeight();
			
			CString strData;
			strData.Format(_T("%.3f"), dThickness);
			m_stc1stThickness.SetWindowText( (LPCTSTR)strData );

			if( dThickness <= 0. )
			{
				ErrMsgDlg(STDGNALM702);
			}

			if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1)
			{
				dThickness = dlg.GetHeight(FALSE);
				strData.Format(_T("%.3f"), dThickness);
				m_stc2ndThickness.SetWindowText( (LPCTSTR)strData );
				
				if( dThickness <=0. )
				{
					ErrMsgDlg(STDGNALM702);
				}
			}
		}
	}
}

void CPaneManualControlDevice::OnButton1stShtOpen() 
{
	m_b1stSht	= TRUE;

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	pDlg->ShutterMove(m_b1stSht, m_b2ndSht);

	m_btn1stShtOpen.SetClick( m_b1stSht );
	m_btn1stShtClose.SetClick( !m_b1stSht );
}

void CPaneManualControlDevice::OnButton1stShtClose() 
{
	m_b1stSht	= FALSE;

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	pDlg->ShutterMove(m_b1stSht, m_b2ndSht);

	m_btn1stShtOpen.SetClick( m_b1stSht );
	m_btn1stShtClose.SetClick( !m_b1stSht );
}

void CPaneManualControlDevice::OnButton2ndShtOpen() 
{
	m_b2ndSht	= TRUE;

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	pDlg->ShutterMove(m_b1stSht, m_b2ndSht);

	m_btn2ndShtOpen.SetClick( m_b2ndSht );
	m_btn2ndShtClose.SetClick( !m_b2ndSht );
}

void CPaneManualControlDevice::OnButton2ndShtClose() 
{
	m_b2ndSht	= FALSE;

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	pDlg->ShutterMove(m_b1stSht, m_b2ndSht);

	m_btn2ndShtOpen.SetClick( m_b2ndSht );
	m_btn2ndShtClose.SetClick( !m_b2ndSht );
}

void CPaneManualControlDevice::OnButtonPowermeterOpen() 
{
	m_bPowermeter	= TRUE;

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, TRUE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif
	m_btnPowermeterOpen.SetClick( m_bPowermeter );
	m_btnPowermeterClose.SetClick( !m_bPowermeter );
}

void CPaneManualControlDevice::OnButtonPowermeterClose() 
{
	m_bPowermeter	= FALSE;

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif

	m_btnPowermeterOpen.SetClick( m_bPowermeter );
	m_btnPowermeterClose.SetClick( !m_bPowermeter );
}

void CPaneManualControlDevice::OnButtonPowermeterOpen2nd()
{
	m_bPowermeter2nd = TRUE;

	// ���� �ʿ�
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, TRUE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif

	m_btnPowermeterOpen2nd.SetClick( m_bPowermeter2nd );
	m_btnPowermeterClose2nd.SetClick( !m_bPowermeter2nd );
}

void CPaneManualControlDevice::OnButtonPowermeterClose2nd()
{
	m_bPowermeter2nd = FALSE;

	// ���� �ʿ�
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif

	m_btnPowermeterOpen2nd.SetClick( m_bPowermeter2nd );
	m_btnPowermeterClose2nd.SetClick( !m_bPowermeter2nd );
}

void CPaneManualControlDevice::OnButtonHeightSensorUp() 
{
	m_bHeightSensor	= TRUE;

	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);

	m_btnHSensorUp.SetClick( m_bHeightSensor );
	m_btnHSensorDown.SetClick( !m_bHeightSensor );
}

void CPaneManualControlDevice::OnButtonHeightSesnorDown() 
{
	m_bHeightSensor	= FALSE;

	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);

	m_btnHSensorUp.SetClick( m_bHeightSensor );
	m_btnHSensorDown.SetClick( !m_bHeightSensor );
}

void CPaneManualControlDevice::OnButtonHeightSensorUp2nd()
{
	m_bHeightSensor2nd = TRUE;

	// ���� �ʿ�
	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);

	m_btnHSensorUp2nd.SetClick( m_bHeightSensor2nd );
	m_btnHSensorDown.SetClick( !m_bHeightSensor2nd );
}

void CPaneManualControlDevice::OnButtonHeightSensorDown2nd()
{
	m_bHeightSensor2nd = FALSE;

	// ���� �ʿ�
	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);

	m_btnHSensorUp2nd.SetClick( m_bHeightSensor2nd );
	m_btnHSensorDown2nd.SetClick( !m_bHeightSensor2nd );
}

void CPaneManualControlDevice::OnButtonMotorHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	pMotor->SetOrigin();
	
	BOOL bInOrigin = FALSE;
	BOOL bInPosition = FALSE;
	
	for( int i = 0 ; i < 600 ; i++ )
	{
#ifndef __NOUSE_MP920__
		::Sleep(100);
#endif
		
		bInOrigin = pMotor->IsInOrigin( -1, FALSE );
		bInPosition = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
		
		if( bInOrigin && bInPosition )
			break;
		
		if( 599 == i )
		{
			pMotor->IsInOrigin(-1);
			pMotor->IsInPosition(-1);
		}
	}
}

void CPaneManualControlDevice::OnButtonLoaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	pMotor->HandlerOperation(HANDLER_LOADER_HOMING);
}

void CPaneManualControlDevice::OnButtonUnloaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	pMotor->HandlerOperation(HANDLER_UNLOADER_HOMING);
}

void CPaneManualControlDevice::OnButtonMaskMoveNum()
{

}

void CPaneManualControlDevice::OnButtonMaskMovePos()
{
}

void CPaneManualControlDevice::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntCombo.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlDevice::SetDeviceStatus()
{
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
	{
		m_btn1stShtOpen.SetClick(TRUE);
		m_btn1stShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn1stShtOpen.SetClick(FALSE);
		m_btn1stShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn1stShtOpen.SetClick(FALSE);
		m_btn1stShtClose.SetClick(FALSE);
	}
	
	nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
	{
		m_btn2ndShtOpen.SetClick(TRUE);
		m_btn2ndShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn2ndShtOpen.SetClick(FALSE);
		m_btn2ndShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn2ndShtOpen.SetClick(FALSE);
		m_btn2ndShtClose.SetClick(FALSE);
	}

	nShutter = gDeviceFactory.GetMotor()->GetCurrentPowerMeter();
	if(nShutter == 1)
	{
		m_btnPowermeterOpen.SetClick(TRUE);
		m_btnPowermeterClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btnPowermeterOpen.SetClick(FALSE);
		m_btnPowermeterClose.SetClick(TRUE);
	}
	else
	{
		m_btnPowermeterOpen.SetClick(FALSE);
		m_btnPowermeterClose.SetClick(FALSE);
	}

	nShutter = gDeviceFactory.GetMotor()->GetCurrentPowerMeter();
	if(nShutter == 1)
	{
		m_btnPowermeterOpen2nd.SetClick(TRUE);
		m_btnPowermeterClose2nd.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btnPowermeterOpen2nd.SetClick(FALSE);
		m_btnPowermeterClose2nd.SetClick(TRUE);
	}
	else
	{
		m_btnPowermeterOpen2nd.SetClick(FALSE);
		m_btnPowermeterClose2nd.SetClick(FALSE);
	}

	BOOL bUp = gDeviceFactory.GetMotor()->GetCurrentHeight(TRUE, TRUE);
	if(bUp)
	{
		m_btnHSensorUp.SetClick(TRUE);
		m_btnHSensorDown.SetClick(FALSE);
	}
	else
	{
		m_btnHSensorUp.SetClick(FALSE);
		m_btnHSensorDown.SetClick(TRUE);
	}
/*
	bUp = gDeviceFactory.GetMotor()->GetCurrentHeight(FALSE, TRUE);
	if(bUp)
	{
		m_btnHSensorUp2nd.SetClick(TRUE);
		m_btnHSensorDown2nd.SetClick(FALSE);
	}
	else
	{
		m_btnHSensorUp2nd.SetClick(FALSE);
		m_btnHSensorDown2nd.SetClick(TRUE);
	}
*/
}