// DlgLaserWarmUp.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgLaserWarmUp.h"

#include "..\model\dprocessini.h"
#include "..\easydrillerdlg.h"
#include "..\device\hdevicefactory.h"
#include "..\Device\HEoCard.h"
#include "..\device\devicemotor.h"
#include "..\Device\HLaser.h"
#include "..\model\dsystemini.h"
#include "..\alarmmsg.h"
#include <math.h>
#include <direct.h>
#include "..\model\DTempINI.h"
#include "..\device\HMotor.h"
#include "..\model\DEasyDrillerINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT POWER_PREHEAT	= 2;
const double PREHEAT_MINX	= 5.0;
const double PREHEAT_MINY	= 5.0;
const double PREHEAT_MAXX	= 645.0;
const double PREHEAT_MAXY	= 645.0;

const int PREHEAT_TIME		= 5 * 60;	// 5 minutes

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserWarmUp dialog

UINT WarmupThread(LPVOID pParam)
{
	CDlgLaserWarmUp* pRunWarmUp = (CDlgLaserWarmUp*)pParam;
	BOOL bNoError = TRUE;
	while(pRunWarmUp->m_bStart)
	{
		pRunWarmUp->ScannerWarmup();

		pRunWarmUp->RunWarmup();
		::Sleep(100);

		bNoError = pRunWarmUp->BusyCheck();
		if(!bNoError)
			break;
	}
	if(!bNoError)
	{
		pRunWarmUp->m_bStart = FALSE;
		pRunWarmUp->SetStartButton(FALSE);
	}
	time_t timeNow;
	time(&timeNow);
	gTempINI.m_sTempTime.nAutoPreheatEndTime = (int)timeNow;	
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		ErrMsgDlg(STDGNALM119);
	
	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("Last PreHeat Time Save : %d"), gTempINI.m_sTempTime.nAutoPreheatEndTime);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	pRunWarmUp->m_pThread = NULL;
	return 1;
}

UINT DataBackupThread(LPVOID pParam)
{
	CDlgLaserWarmUp* pRunWarmUp = (CDlgLaserWarmUp*)pParam;

	// backup dir
	if( 0 != _chdir( _T("D:\\ViaHole_OldLog\\") ) )
		_mkdir( _T("D:\\ViaHole_OldLog\\") ); // Create 

	int Index = gProcessINI.m_sProcessFidFind.nLogSaveData;    // �Ⱓ�� ���� ��

	CString strFile, strTempFilePath;
	CTime nowTime, Createtime;     

	nowTime = CTime::GetCurrentTime();
	// ���� ��¥���� Index ��¥ ��ŭ ����
	nowTime = nowTime - CTimeSpan(Index, 0, 0, 0); // 90��

	CFileFind finder1;
	strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetBackupDir());
	BOOL bFind = finder1.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...

	pRunWarmUp->SetWindowText(_T("Laser Warm Up...Data Backup"));
	while(bFind)
	{
		if(!pRunWarmUp->m_bStart)
		{
			finder1.Close();
			pRunWarmUp->m_pThreadDataBackup = NULL;
			pRunWarmUp->SetWindowText(_T("Laser Warm Up Dialog"));
			return 1;
		}
		bFind = finder1.FindNextFile();
		if(finder1.IsDirectory())
			continue;
		else
		{
			strFile = finder1.GetFileName();
			// ���� ���� �ð��� ������
			finder1.GetLastWriteTime(Createtime);

			// ���� �ð����� Index ��¥ ���� ������ ��� ����
			if(nowTime >= Createtime)
			{
				CString strTempOrigin, strMovePath;
				strTempOrigin.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetBackupDir(), strFile);

				strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
				CopyFile(strTempOrigin, strMovePath, FALSE);

				::DeleteFile(strTempOrigin);
			}
		}
	}
	finder1.Close();

	CFileFind finder2;
	strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
	bFind = finder2.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...

	while(bFind)
	{
		if(!pRunWarmUp->m_bStart)
		{
			finder2.Close();
			pRunWarmUp->m_pThreadDataBackup = NULL;
			pRunWarmUp->SetWindowText(_T("Laser Warm Up Dialog"));
			return 1;
		}
		bFind = finder2.FindNextFile();
		if(finder2.IsDirectory())
			continue;
		else
		{
			strFile = finder2.GetFileName();
			// ���� ���� �ð��� ������
			finder2.GetLastWriteTime(Createtime);

			// ���� �ð����� Index ��¥ ���� ������ ��� ����
			if(nowTime >= Createtime)
			{
				CString strTempOrigin, strMovePath;
				strTempOrigin.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);

				strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
				CopyFile(strTempOrigin, strMovePath, FALSE);

				::DeleteFile(strTempOrigin);
			}
		}
	}
	finder2.Close();

	CFileFind finder3;
	strTempFilePath.Format(_T("%sBackup\\*"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	bFind = finder3.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...

	while(bFind)
	{
		if(!pRunWarmUp->m_bStart)
		{
			finder3.Close();
			pRunWarmUp->m_pThreadDataBackup = NULL;
			pRunWarmUp->SetWindowText(_T("Laser Warm Up Dialog"));
			return 1;
		}
		bFind = finder3.FindNextFile();
		if(finder3.IsDirectory())
			continue;
		else
		{
			strFile = finder3.GetFileName();
			// ���� ���� �ð��� ������
			finder3.GetLastWriteTime(Createtime);

			// ���� �ð����� Index ��¥ ���� ������ ��� ����
			if(nowTime >= Createtime)
			{
				CString strTempOrigin, strMovePath;
				strTempOrigin.Format(_T("%sBackup\\%s"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), strFile);

				strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
				CopyFile(strTempOrigin, strMovePath, FALSE);

				::DeleteFile(strTempOrigin);
			}
		}
	}
	finder3.Close();

	pRunWarmUp->m_pThreadDataBackup = NULL;
	pRunWarmUp->SetWindowText(_T("Laser Warm Up Dialog"));
	return 1;
}

CDlgLaserWarmUp::CDlgLaserWarmUp(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserWarmUp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLaserWarmUp)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bSetting			= FALSE;
	m_bStart			= FALSE;
	m_nPreHeatTime		= PREHEAT_TIME;
	m_bAutoMode			= FALSE;
	m_bGalvaOnly		= FALSE;
	m_nMoveIndex		= 0;
	m_nTimerID			= 0;
	m_bFirstMove		= TRUE;
	m_pThread			= NULL;
	m_pThreadDataBackup = NULL;
}


void CDlgLaserWarmUp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLaserWarmUp)
	DDX_Control(pDX, IDC_BUTTON_APPLY_SPEED, m_btnSpeedApply);
//	DDX_Control(pDX, IDC_EDIT_Z2, m_edtSpeedZ2);
//	DDX_Control(pDX, IDC_EDIT_Z1, m_edtSpeedZ1);
//	DDX_Control(pDX, IDC_EDIT_Y, m_edtSpeedY);
	DDX_Control(pDX, IDC_EDIT_X, m_edtSpeedX);
	DDX_Control(pDX, IDC_PROGRESS_WARM_UP, m_progTime);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_SETTING, m_btnSetting);

	DDX_Control(pDX, IDC_EDIT_PREHEAT_FREQUENCY, m_edtFreq);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_DUTY, m_edtDuty);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_TIME2, m_edtTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLaserWarmUp, CDialog)
	//{{AFX_MSG_MAP(CDlgLaserWarmUp)
	ON_BN_CLICKED(IDC_BUTTON_SETTING, OnButtonSetting)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_SPEED, OnButtonApply)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserWarmUp message handlers

BOOL CDlgLaserWarmUp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();

	CRect rect;
	GetWindowRect( rect );
	m_siExtendSize = rect.Size();
	GetDlgItem(IDC_STATIC_BORDER)->GetWindowRect( rect );
	ScreenToClient( rect );
	m_siNormalSize.cx	= m_siExtendSize.cx;
	m_siNormalSize.cy	= rect.bottom + 30;

	ResizeDlg( m_bSetting );

	m_pMotor = gDeviceFactory.GetMotor();
	m_pEoCard = gDeviceFactory.GetEocard();
	gDeviceFactory.GetLaser()->ShutterOpen(FALSE);

	int nCountShutter = 0;
	while(gDeviceFactory.GetLaser()->IsShutterOpen())
	{
		::Sleep(1);
		if(nCountShutter > 2000)
		{
			ErrMessage(_T("Shutter can not close\n check EOCARD"));
			return FALSE;
		}
		nCountShutter++;
	}

	m_nPreHeatTime = gProcessINI.m_sProcessCal.nPreheatTime * 60;

	int nHour = m_nPreHeatTime / 3600;
	int nMin = (m_nPreHeatTime - (nHour * 3600)) / 60;
	int nSec = m_nPreHeatTime - ((nHour * 3600) + (nMin  * 60));
	
	CString strTime;
	strTime.Format(_T("%02d:%02d:%02d"), nHour, nMin, nSec);
	SetDlgItemText(IDC_STATIC_END, strTime);

	m_progTime.SetRange32(0, m_nPreHeatTime);

	m_nShutter1 = m_pMotor->GetCurrentShutter1();
	m_nShutter2 = m_pMotor->GetCurrentShutter2();

	m_pMotor->MotorShutterAll(FALSE, FALSE);
	int nCount = 0;
#ifndef __TEST__
	int nShutter1, nShutter2;
	
	while(nCount < 50)
	{
		::Sleep(100);
		nShutter1 = m_pMotor->GetCurrentShutter1();
		nShutter2 = m_pMotor->GetCurrentShutter2();
		
		if(nShutter1 == 2 && nShutter2 == 2) // close
			break;
		if(nCount == 49)
		{
			ErrMessage(IDS_ERR_SHUTTER_CLOSE);
		}
		nCount++;
	}
#endif

	m_nPreHeatPos = 0;

	PreHeatDataSave();
	m_pEoCard->GetParameter(&m_fPara);

	m_nTimerID = SetTimer( 533, 1000, NULL );

	if (m_bAutoMode)
		OnButtonStart();



//	m_progTime.SetRange32( 0, 120 );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgLaserWarmUp::OnOK() 
{
//	CDialog::OnOK();
}

void CDlgLaserWarmUp::OnCancel() 
{
	if (m_pThread != NULL)
	{
		return;
	}
	if (m_pThreadDataBackup != NULL)
	{
		return;
	}
	
	if( m_bStart )
		return;

	BOOL bIsDspBusy = TRUE;
	while(bIsDspBusy)
	{
		::Sleep(1);
		bIsDspBusy = m_pEoCard->IsDSPBusy();
	}
	if(m_nTimerID)
	{
		KillTimer( m_nTimerID );
		m_nTimerID = 0;
	}

	

	CDialog::OnCancel();
}

void CDlgLaserWarmUp::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Setting
	m_btnSetting.SetFont( &m_fntBtn );
	m_btnSetting.SetFlat( FALSE );
	m_btnSetting.EnableBallonToolTip();
	m_btnSetting.SetToolTipText( _T("Motor Speed Setting") );
	m_btnSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetting.SetBtnCursor(IDC_HAND_1);
	m_btnSetting.SetWindowText( _T("Setting >>>") );

	// Start / Stop
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetRectAlign( 1 );
	m_btnStart.SetToolTipText( _T("Warm Up Start/Stop") );
	m_btnStart.SetWindowText( _T("Start") );

	// Speed Apply
	m_btnSpeedApply.SetFont( &m_fntBtn );
	m_btnSpeedApply.SetFlat( FALSE );
	m_btnSpeedApply.EnableBallonToolTip();
	m_btnSpeedApply.SetToolTipText( _T("Speed Apply") );
	m_btnSpeedApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSpeedApply.SetBtnCursor(IDC_HAND_1);
}

void CDlgLaserWarmUp::InitEditControl()
{
	CString strData;

	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Frequency
	m_edtFreq.SetFont( &m_fntEdit );
	m_edtFreq.SetReceivedFlag( 1 );
	strData.Format(_T("%d"), gProcessINI.m_sProcessCal.nPreheatFreq);
	m_edtFreq.SetWindowText(strData);

	// Duty
	m_edtDuty.SetFont( &m_fntEdit );
	m_edtDuty.SetReceivedFlag( 3 );
	strData.Format(_T("%.2f"), gProcessINI.m_sProcessCal.dPreheatDuty);
	m_edtDuty.SetWindowText(strData);

	// X
	m_edtSpeedX.SetFont( &m_fntEdit );
	m_edtSpeedX.SetReceivedFlag( 1 );
//	m_edtSpeedX.SetWindowText( _T("20000") );
	strData.Format(_T("%d"), gProcessINI.m_sProcessCal.nPreheatSpeedXY);
	m_edtSpeedX.SetWindowText(strData);

	m_edtTime.SetFont( &m_fntEdit );
	m_edtTime.SetReceivedFlag(1 );
	strData.Format(_T("%d"), gProcessINI.m_sProcessCal.nPreheatTime);
	m_edtTime.SetWindowText(strData);

	// Y
//	m_edtSpeedY.SetFont( &m_fntEdit );
//	m_edtSpeedY.SetReceivedFlag( 1 );
//	m_edtSpeedY.SetWindowText( _T("20000") );
//	strData.Format(_T("%d"), gProcessINI.m_sProcessOption.nPreheatSpeedXY);
//	m_edtSpeedY.SetWindowText(strData);

	// Z1
//	m_edtSpeedZ1.SetFont( &m_fntEdit );
//	m_edtSpeedZ1.SetReceivedFlag( 1 );
//	m_edtSpeedZ1.SetWindowText( _T("20000") );
//	strData.Format(_T("%d"), gProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2);
//	m_edtSpeedZ1.SetWindowText(strData);

	// Z2
//	m_edtSpeedZ2.SetFont( &m_fntEdit );
//	m_edtSpeedZ2.SetReceivedFlag( 1 );
//	m_edtSpeedZ2.SetWindowText( _T("20000") );
//	strData.Format(_T("%d"), gProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2);
//	m_edtSpeedZ2.SetWindowText(strData);
}

void CDlgLaserWarmUp::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_START)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NOW)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_END)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_MOTOR_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_X)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_Y)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_Z1)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_Z2)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PREHEAT_LASER_PARAMETER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_FREQUENCY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME2)->SetFont( &m_fntStatic );
}

void CDlgLaserWarmUp::OnButtonSetting() 
{
	m_bSetting = !m_bSetting;

	if( m_bSetting )
		m_btnSetting.SetWindowText( _T("Setting <<<") );
	else
		m_btnSetting.SetWindowText( _T("Setting >>>") );

	ResizeDlg( m_bSetting );
}

void CDlgLaserWarmUp::OnButtonStart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nCountShutter = 0;
	while(gDeviceFactory.GetLaser()->IsShutterOpen())
	{
		::Sleep(1);
		if(nCountShutter > 500)
		{
			ErrMessage(_T("Shutter can not close\n check EOCARD"));
			return;
		}
		nCountShutter++;
	}
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	SetWarmUpSpeed();

	m_progTime.SetRange32(0, m_nPreHeatTime);

	m_bStart = !m_bStart;
	m_btnStart.SetClick( m_bStart );

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

	CString strLog;

	if( m_bStart )
	{
		BOOL bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			::Sleep(1);
			bIsDspBusy = m_pEoCard->IsDSPBusy();
		}


		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			pMotor->TableClamp(TRUE);
			::Sleep(200);
		}
		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			pMotor->TableClamp(TRUE, FALSE);
			::Sleep(200);
		}

		time(&m_timeStart);
		FParameter fPara = m_fPara;
		fPara.Frequency = gProcessINI.m_sProcessCal.nPreheatFreq; // 100;
		fPara.dDuty = gProcessINI.m_sProcessCal.dPreheatDuty; // 80;
		fPara.DrawStep = 2000;
		m_pEoCard->SetParameter(&fPara);
		m_btnStart.SetWindowText( _T("Stop") );
//		m_pEoCard->LaserOnOff(TRUE);
		strLog.Format(_T("Start LaserPreheat"));
		pDlg->WriteProcessLog(strLog, _T(""));
		m_nMoveIndex = 0;
		m_bFirstMove = TRUE;
		m_pThread = ::AfxBeginThread(WarmupThread, this, THREAD_PRIORITY_NORMAL );
		m_pThreadDataBackup = ::AfxBeginThread(DataBackupThread, this, THREAD_PRIORITY_NORMAL );
		

		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
	}
	else
	{
		m_btnStart.SetWindowText( _T("Start") );
//		m_pEoCard->LaserOnOff(FALSE);
		//FParameter fPara = m_fPara;//2016
		//fPara.DrawStep = 2000;
		//m_pEoCard->SetParameter(&fPara);
		strLog.Format(_T("Stop LaserPreheat"));
		pDlg->WriteProcessLog(strLog, _T(""));
//		m_pMotor->Stop(AXIS_X);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

//		::Sleep(500);
//		double dPosX, dPosY;
//		m_pMotor->GetPosition(AXIS_X, dPosX);
//		m_pMotor->GetPosition(AXIS_Y, dPosY);
//		m_pMotor->MotorMoveXY(dPosX, dPosY);
	}

	EnableButton( !m_bStart );
}

void CDlgLaserWarmUp::OnButtonApply()
{
	CString strData;
	m_edtFreq.GetWindowText(strData);
	gProcessINI.m_sProcessCal.nPreheatFreq = atoi(strData);
	m_edtDuty.GetWindowText(strData);
	gProcessINI.m_sProcessCal.dPreheatDuty = atof(strData);
	m_edtSpeedX.GetWindowText(strData);
	gProcessINI.m_sProcessCal.nPreheatSpeedXY = atoi(strData);
	m_edtTime.GetWindowText(strData);
	gProcessINI.m_sProcessCal.nPreheatTime = atoi(strData);

//	m_edtSpeedY.GetWindowText(strData);
//	gProcessINI.m_sProcessOption.nPreheatSpeedXY = atoi(strData);
//	m_edtSpeedZ1.GetWindowText(strData);
//	gProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2 = atoi(strData);
//	m_edtSpeedZ2.GetWindowText(strData);
//	gProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2 = atoi(strData);

	m_nPreHeatTime = gProcessINI.m_sProcessCal.nPreheatTime * 60;

	int nHour = m_nPreHeatTime / 3600;
	int nMin = (m_nPreHeatTime - (nHour * 3600)) / 60;
	int nSec = m_nPreHeatTime - ((nHour * 3600) + (nMin  * 60));
	
	CString strTime;
	strTime.Format(_T("%02d:%02d:%02d"), nHour, nMin, nSec);
	SetDlgItemText(IDC_STATIC_END, strTime);

	m_progTime.SetRange32(0, m_nPreHeatTime);

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);
//	::AfxGetMainWnd()->SendMessage( PROCESS_APPLY, 0, 0 );
}

void CDlgLaserWarmUp::ResizeDlg(BOOL bResize)
{
	if( bResize ) // Extend
	{
		this->SetWindowPos( NULL, 0, 0, m_siExtendSize.cx, m_siExtendSize.cy, SWP_NOMOVE|SWP_NOZORDER );
	}
	else // Normal
	{
		this->SetWindowPos( NULL, 0, 0, m_siNormalSize.cx, m_siNormalSize.cy, SWP_NOMOVE|SWP_NOZORDER );
	}
}

void CDlgLaserWarmUp::OnTimer(UINT nIDEvent) 
{
	if( m_bStart )
	{
		time_t timeEnd;
		time(&timeEnd);
		double dNowTimeOne = difftime(timeEnd, m_timeStart);

		int nHour = static_cast<int>(dNowTimeOne / 3600.0);
		int nMin = static_cast<int>((dNowTimeOne - (nHour * 3600.0)) / 60.0);
		int nSec = static_cast<int>(dNowTimeOne - ((nHour * 3600.0) + (nMin  * 60.0)));

		CString strNowTime;
		strNowTime.Format(_T("%02d:%02d:%02d"), nHour, nMin, nSec);
		m_progTime.SetPos( (int)dNowTimeOne );
		SetDlgItemText(IDC_STATIC_NOW, strNowTime);
	}
/*	if( m_bStart )
	{
		time_t timeEnd;
		time(&timeEnd);
		double dNowTimeOne = difftime(timeEnd, m_timeStart);

		if(dNowTimeOne >= m_nPreHeatTime)
		{
			m_pEoCard->LaserOnOff(FALSE);

//			if(m_nTimerID)
//			{
//				KillTimer( m_nTimerID );
//				m_nTimerID = 0;
//			}

			m_bStart = FALSE;
			m_btnStart.SetClick( m_bStart );
			m_btnStart.SetWindowText( _T("Start") );
			EnableButton( !m_bStart );

			CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

			CString strLog;
			strLog.Format(_T("Finish LaserPreheat"));
			pDlg->WriteProcessLog(strLog,_T(""));
			FParameter fPara = m_fPara;
			m_pEoCard->SetParameter(&fPara);

			gProcessINI.m_sProcessOption.nPreheatEndTime = timeEnd;

			CDialog::OnTimer(nIDEvent);
			return;
		}

		int nHour = static_cast<int>(dNowTimeOne / 3600.0);
		int nMin = static_cast<int>((dNowTimeOne - (nHour * 3600.0)) / 60.0);
		int nSec = static_cast<int>(dNowTimeOne - ((nHour * 3600.0) + (nMin  * 60.0)));

		CString strNowTime;
		strNowTime.Format(_T("%02d:%02d:%02d"), nHour, nMin, nSec);
		m_progTime.SetPos( (int)dNowTimeOne );
		SetDlgItemText(IDC_STATIC_NOW, strNowTime);
		if (!m_bGalvaOnly)
		{
			if(!MotorMove(FALSE))
			{
				m_pEoCard->LaserOnOff(FALSE);
				
				m_bStart = FALSE;
				m_btnStart.SetClick( m_bStart );
				m_btnStart.SetWindowText( _T("Start") );
				EnableButton( !m_bStart );
				
				CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
				
				CString strLog;
				strLog.Format(_T("Stop LaserPreheat (MotorMove Err)"));
				pDlg->WriteProcessLog(strLog,_T(""));
				FParameter fPara = m_fPara;
				m_pEoCard->SetParameter(&fPara);
				
				gProcessINI.m_sProcessOption.nPreheatEndTime = timeEnd;
				
				CDialog::OnTimer(nIDEvent);
				return;
			}
		}
	}
*/	
	CDialog::OnTimer(nIDEvent);
}

void CDlgLaserWarmUp::EnableButton(BOOL bEnable)
{
	if( FALSE == bEnable )
	{
		if( m_bSetting )
		{
			m_bSetting = !m_bSetting;
			ResizeDlg( m_bSetting );
		}
	}

	m_btnSetting.EnableWindow( bEnable );
}

BOOL CDlgLaserWarmUp::DestroyWindow() 
{
	m_pEoCard->LaserOnOff(FALSE);

//	m_pMotor->InPositionIO(IND_X + IND_Y);
//	m_pMotor->IsInPosition();

	SetOriginalSpeed();

	if(m_nShutter1 == 1)
		m_nShutter1 = 1;
	else
		m_nShutter1 = 0;
	if(m_nShutter2 == 1)
		m_nShutter2 = 1;
	else
		m_nShutter2 = 0;

	// 20090629 Front Mode error
/*	m_pMotor->MotorShutterAll((BOOL)m_nShutter1, (BOOL)m_nShutter2);
	int nCount = 0;

#ifndef __TEST__
	int nShutter1, nShutter2;
	while(nCount < 50)
	{
		::Sleep(100);
		nShutter1 = m_pMotor->GetCurrentShutter1();
		nShutter2 = m_pMotor->GetCurrentShutter2();
		
		if(nShutter1 == 2)
			nShutter1 = 0;
		if(nShutter2 == 2)
			nShutter2 = 0;
		
		if(nShutter1 == m_nShutter1 && nShutter2 == m_nShutter2) // close
			break;
		
		if(nCount == 49)
		{
			ErrMessage(_T("Shutter ���� ����"));
		}
		nCount++;
	}
#endif

*/	gDeviceFactory.GetLaser()->ShutterOpen(TRUE);

	//m_pEoCard->SetParameter(&m_fPara);

	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgLaserWarmUp::SetWarmUpSpeed()
{
	gDeviceFactory.GetMotor()->SetAxisSpeed(AXIS_X, gProcessINI.m_sProcessCal.nPreheatSpeedXY);
	gDeviceFactory.GetMotor()->SetAxisSpeed(AXIS_Y, gProcessINI.m_sProcessCal.nPreheatSpeedXY);
//	gDeviceFactory.GetMotor()->SetAxisSpeed(AXIS_Z1, gProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2);
}

void CDlgLaserWarmUp::SetOriginalSpeed()
{
	gDeviceFactory.GetMotor()->SetOriginalSpeed();
}

void CDlgLaserWarmUp::PreHeatDataSave() 
{
	m_nPreHeatPos = 0;
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MINX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MINY;	// Left Bottom
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MAXX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MINY;	// Right Bottom
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MAXX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MAXY;	// Right Top
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MINX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MAXY;	// Left Top
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MINX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MINY;	// Left Bottom
	
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MAXX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MAXY;	// Right Top
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MAXX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MINY;	// Right Bottom
	m_dPreX[m_nPreHeatPos]	= PREHEAT_MINX;
	m_dPreY[m_nPreHeatPos++]= PREHEAT_MAXY;	// Left Top
}

BOOL CDlgLaserWarmUp::MotorMove(BOOL bStart) 
{
	if(!m_bStart)
		return TRUE;
	
	if(bStart == TRUE)
		m_nMoveIndex = 0;
#ifndef __TEST__

	if(!m_bFirstMove)
	{
//		if(m_pMotor->InPositionIO(IND_X + IND_Y) == FALSE)

		CCorrectTime	MyTestTime;
		MyTestTime.StartTime();
		double dWaitTime = 0.0;
		CString strTime;
		
		while(TRUE)
		{	
			if(!m_bStart)
				break;

			if(m_pMotor->InPositionIO(IND_X + IND_Y) != ALL_AXIS_OK)
				break;

			::Sleep(0);
			MessageLoop();
			
			dWaitTime = MyTestTime.PresentTime();
			if(dWaitTime > 10) // 10 sec time out
				return FALSE;
		}

//		if(!m_pMotor->IsInPosition(AXIS_X) || !m_pMotor->IsInPosition(AXIS_Y))
//			return;
	}
	else
		m_bFirstMove = FALSE;

	if(!m_bStart)
		return TRUE;
	
	if(m_nPreHeatPos <= m_nMoveIndex)
		m_nMoveIndex = 0;
	
	if (!(m_pMotor->MoveXY(m_dPreX[m_nMoveIndex], m_dPreY[m_nMoveIndex])))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	
#endif		
	m_nMoveIndex++;

	return TRUE;
}

void CDlgLaserWarmUp::MessageLoop()
{
	MSG msg;
	
	if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		TranslateMessage((LPMSG)&msg);
		DispatchMessage((LPMSG)&msg);
	}
}

void CDlgLaserWarmUp::RunWarmup()
{
	if( m_bStart )
	{
		time_t timeEnd;
		time(&timeEnd);
		double dNowTimeOne = difftime(timeEnd, m_timeStart);

		if(dNowTimeOne >= m_nPreHeatTime)
		{
			m_pEoCard->LaserOnOff(FALSE);

//			if(m_nTimerID)
//			{
//				KillTimer( m_nTimerID );
//				m_nTimerID = 0;
//			}

			m_bStart = FALSE;
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			m_btnStart.SetClick( m_bStart );
			m_btnStart.SetWindowText( _T("Start") );
			EnableButton( !m_bStart );

			CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

			BusyCheck();

			CString strLog;
			strLog.Format(_T("Finish LaserPreheat"));
			//pDlg->WriteProcessLog(strLog,_T(""));
			//FParameter fPara = m_fPara;
			//m_pEoCard->SetParameter(&fPara);

			gProcessINI.m_sProcessCal.nPreheatEndTime = (int)timeEnd;

			return;
		}

		int nHour = static_cast<int>(dNowTimeOne / 3600.0);
		int nMin = static_cast<int>((dNowTimeOne - (nHour * 3600.0)) / 60.0);
		int nSec = static_cast<int>(dNowTimeOne - ((nHour * 3600.0) + (nMin  * 60.0)));

//		CString strNowTime;
//		strNowTime.Format(_T("%02d:%02d:%02d"), nHour, nMin, nSec);
//		m_progTime.SetPos( (int)dNowTimeOne );
//		SetDlgItemText(IDC_STATIC_NOW, strNowTime);
		if (!m_bGalvaOnly)
		{
			if(!MotorMove(FALSE))
			{
				m_pEoCard->LaserOnOff(FALSE);
				
				m_bStart = FALSE;
				gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
				m_btnStart.SetClick( m_bStart );
				m_btnStart.SetWindowText( _T("Start") );
				EnableButton( !m_bStart );
				
				CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
				
				CString strLog;
				strLog.Format(_T("Stop LaserPreheat (MotorMove Err)"));
				//pDlg->WriteProcessLog(strLog,_T(""));
				//FParameter fPara = m_fPara;
				//m_pEoCard->SetParameter(&fPara);
				
				gProcessINI.m_sProcessCal.nPreheatEndTime = (int)timeEnd;
				
				return;
			}
		}
	}
}

BOOL CDlgLaserWarmUp::BusyCheck()
{
	BOOL bIsDspBusy = TRUE;
	CString m_strErrorPlus;
	while(bIsDspBusy)
	{
		::Sleep(1);
		
		if(m_pEoCard->IsMotorFault())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				m_pEoCard->EStop();
			ErrMsgDlg(STDGNALM567);
			return FALSE;
		}
		if(m_pEoCard->IsScannerCableError())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				m_pEoCard->EStop();
			m_strErrorPlus = _T("Scanner Cable Error.");
			ErrMsgDlg(STDGNALM1017,m_strErrorPlus);
			return FALSE;
		}
		//if(!m_bStart)
		//	return FALSE;
		bIsDspBusy = m_pEoCard->IsDSPBusy();

	}

	return TRUE;
}

void CDlgLaserWarmUp::ScannerWarmup()
{
	int nX, nY;

	if(!m_bStart)
		return;

	for(int i = 0; i< 300; i++)
	{
		//rand : 0 ~ 32767
		nX = (rand() * 2) % 65535 ;
		nY = (rand() * 2) % 65535 ;




		::Sleep(1);

		m_pEoCard->mark(nX, nY, nX, nY,	HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
		
	}
}

BOOL CDlgLaserWarmUp::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Laser_Warmup) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}

		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
void CDlgLaserWarmUp::SetStartButton(BOOL bStart)
{
	if(bStart)
	{
		//gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
		m_btnStart.SetClick( bStart );
		m_btnStart.SetWindowText( _T("Stop") );
		EnableButton( !bStart );
	}
	else
	{
		//gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
		m_btnStart.SetClick( bStart );
		m_btnStart.SetWindowText( _T("Start") );
		EnableButton( !bStart );
	}
}
