// PaneRecipeGenParameterNew.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenParameterNew.h"
#include "PaneRecipeGenFiducialNew.h"
#include "DlgLaserBeamHoleSet.h"
#include "..\easydrillerdlg.h"
#include "DlgVisionProView.h"
#include "DlgVisionView.h"
#include "DlgMatroxVisionView.h"
#include "..\model\DProject.h"
#include "..\Model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\alarmmsg.h"
#include "..\model\DBeamPathINI.h"
#include "math.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HDeviceFactory.h"
#include "..\model\DProcessINI.h"
#include "..\device\HLaser.h"
#include "..\device\HVision.h"
#include "PaneManualControl.h"
#include "PaneManualControlLaser.h"
#include "PaneManualControlPowerMeasurement.h"
#include "..\device\HMotor.h"
#include "DlgTableView.h"
#include "..\MODEL\DShotTableINI.h"


#include "DlgShotTable.h"
#include "DlgBeamPathTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

UINT FireHoleThread(LPVOID pParam)
{
	CPaneRecipeGenParameterNew* pRun = (CPaneRecipeGenParameterNew*)pParam;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	//20111107
	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
		{
#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Shot start Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot start Failure"));
#endif
			pRun->StopProcess();
			return 0U;
		}
		pRun->m_StandbyTime.StartTime();
	}
	

	int nMask = pRun->m_cmbMask.GetCurSel();
	int nCam = pRun->m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;
	int nHeadOffsetCnt = -1;
	double dHeadOffsetX, dHeadOffsetY;

	BOOL bHigh;

		
	switch(nCam)
	{
		case 0:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			break;
		case 1:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			break;
		case 2:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
			break;
		case 3:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
			break;
	}

	dHeadOffsetX += gSystemINI.m_sSystemDevice.dHeadOffsetX;
	dHeadOffsetY += gSystemINI.m_sSystemDevice.dHeadOffsetY;

	double dVisionXPos = pMotor->GetPosition(AXIS_X);
	double dVisionYPos = pMotor->GetPosition(AXIS_Y);
	double dLaserXPos = dVisionXPos, dLaserYPos = dVisionYPos;

	dLaserXPos = dVisionXPos - dHeadOffsetX;
	dLaserYPos = dVisionYPos - dHeadOffsetY;



	if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
		dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
		dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
		dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
	{
#ifndef __TEST__

		CString strM;
		strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
			gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
			gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
		ErrMessage(strM);
	//	pRun->EnableAllButton(TRUE);
		pRun->StopProcess();
		return 0L;
#endif
	}


//	if(nHeadOffsetCnt == 0) 
//	{
		if(nHead == 0) // Master
		{
			if(!pRun->ShutterMove(TRUE, FALSE))
			{
//					pRun->EnableAllButton(TRUE);
				pRun->StopProcess();
				return 0U;
			}
		}
		else if(nHead == 1) // Slave
		{
			if(!pRun->ShutterMove(FALSE, TRUE))
			{
//					pRun->EnableAllButton(TRUE);
				pRun->StopProcess();
				return 0U;
			}
		}

		if(pRun->m_bStop)
		{
			pRun->m_bStop = FALSE;
//			pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}
			
		if (!pMotor->MoveXY(dLaserXPos, dLaserYPos, TRUE, SHOT_MOVE))
		{
			TRACE("Motor out of position\n");
//			pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}

		if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
		{
			TRACE("Motor does not stop\n");
	//		pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}

		if(pRun->m_bStop)
		{
			pRun->m_bStop = FALSE;
	//		pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}

		if(!pRun->LaserFire())
		{
	//		pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U; 
		}

		if(pRun->m_bStop)
		{
			pRun->m_bStop = FALSE;
	//		pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}

		// 090805 shutter close
		if(!pRun->ShutterMove(FALSE, FALSE))
		{
	//		pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}
//	}

 	if (!pMotor->MoveXY(dVisionXPos, dVisionYPos))
	{
		TRACE("Motor out of position\n");
//		pRun->EnableAllButton(TRUE);
		pRun->StopProcess();
		return 0U;
	}

	if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
	{
		TRACE("Motor does not stop\n");
	//	pRun->EnableAllButton(TRUE);
		pRun->StopProcess();
		return 0U;
	}

	if(pRun->m_bStop)
	{
		pRun->m_bStop = FALSE;
//		pRun->EnableAllButton(TRUE);
		pRun->StopProcess();
		return 0U;
	}

	if(nCam%2)
		bHigh = FALSE;
	else
		bHigh = TRUE;

	if(nHead == 0)
	{
		if(!pRun->MoveVisionFoucs(TRUE, bHigh))
		{
//				pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}

	}
	else
	{
		if(!pRun->MoveVisionFoucs(FALSE, bHigh))
		{
//				pRun->EnableAllButton(TRUE);
			pRun->StopProcess();
			return 0U;
		}
	}

	if(pRun->m_bStop)
	{
		pRun->m_bStop = FALSE;
//			pRun->EnableAllButton(TRUE);
		pRun->StopProcess();
		return 0U;
	}

#ifndef __TEST__
	::Sleep(100);
#endif


	if(nHead == 0) //Master
	{
		pRun->SendMessage(VISION_INSPECTION, (WPARAM)nCam);
	}
	else if(nHead == 1) //Slave
	{
		pRun->SendMessage(VISION_INSPECTION, (WPARAM)nCam);
	}



	//	pRun->EnableAllButton(TRUE);

	pRun->m_bStop = FALSE;

	pRun->m_pThread = NULL;

	pRun->StopProcess();
	return 1U;
}

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNew

IMPLEMENT_DYNCREATE(CPaneRecipeGenParameterNew, CFormView)

CPaneRecipeGenParameterNew::CPaneRecipeGenParameterNew()
	: CFormView(CPaneRecipeGenParameterNew::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenParameterNew)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bGlobalParam = FALSE;
	m_strPath = _T("");
	m_strMemo = _T("");

	m_nToolIndex = -1;
	m_nSubIndex = -1;
	m_bUsePrePower = FALSE;
	m_bUsePreScal = FALSE;
	m_bConnectVision = FALSE;
	m_bStop = FALSE;
	m_nGridX = 1;
	m_nGridY = 1;
	m_nFieldSize = 64;
	m_dBaseZ1 = 0;
	m_dBaseZ2 = 0;
	m_dMeasuredPower = 0;
	m_bPowerStop = FALSE;
	for(int i =0 ; i<MAX_TOOL_NO; i++)
	{
		m_dMin[i] = 0;
		m_dMax[i] = 0;
	}
	memset(m_szToolName, 0, sizeof(m_szToolName));	

	m_pProject = NULL;
}

CPaneRecipeGenParameterNew::~CPaneRecipeGenParameterNew()
{
}

void CPaneRecipeGenParameterNew::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenParameterNew)
	DDX_Control(pDX, IDC_TREE_TOOL, m_ctrTreeTool);
	DDX_Control(pDX, IDC_LIST_MAIN_TOOL_CODE, m_listMainTool);
	DDX_Control(pDX, IDC_LIST_SUB_TOOL_CODE, m_listSubTool);
	DDX_Control(pDX, IDC_COMBO_COLOR, m_cmbColor);
	DDX_Control(pDX, IDC_COMBO_SUB_DRILL_METHOD, m_cmbDrillMethod);
	DDX_Control(pDX, IDC_COMBO_SUB_TOOL_TYPE, m_cmbToolType);
	DDX_Control(pDX, IDC_COMBO_SUB_MASK, m_cmbMask);
	DDX_Control(pDX, IDC_COMBO_SUB_TOOL_CAMERA, m_cmbCam);
	DDX_Control(pDX, IDC_CHECK_HOLE_FIND, m_chkHoleFind);
	DDX_Control(pDX, IDC_CHECK_HOLE_SORTING, m_chkHoleSorting);
	DDX_Control(pDX, IDC_CHECK_USE_TOOL, m_chkUseTool);
	DDX_Control(pDX, IDC_CHECK_TOOL_ORDER, m_chkUseToolOrder);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_APERTURE, m_chkUseAperture);

	DDX_Control(pDX, IDC_CHECK_SUB_USE_BARCODE_LINE_DRILL, m_chkUseBarcodeLineDrill);
	DDX_Control(pDX, IDC_COMBO_SUB_BARCODE_MATRIX, m_cmbBarcodeMatrix);


	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE_MAIN, m_btnUpdateMain);
	DDX_Control(pDX, IDC_BUTTON_PARAM_OPEN, m_btnOpenMainTool);
	DDX_Control(pDX, IDC_BUTTON_PARAM_SAVE, m_btnSaveMainTool);
	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE, m_btnUpdate);
	DDX_Control(pDX, IDC_BUTTON_PARAM_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_PARAM_DELETE, m_btnDelete);
	DDX_Control(pDX, IDC_BUTTON_SUB_SHOT_SETTING, m_btnSetting);
	DDX_Control(pDX, IDC_BUTTON_SUB_APERTURE_OPEN, m_btnFileOpen);
	DDX_Control(pDX, IDC_BUTTON_SUB_PROFILE_OPEN, m_btnScannerProfileOpen);
	DDX_Control(pDX, IDC_BUTTON_SUB_FIRE, m_btnFire);
	DDX_Control(pDX, IDC_BUTTON_SUB_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_SUB_POWER, m_btnPower);
	DDX_Control(pDX, IDC_CHECK_SUB_X_FLIP, m_chkUseFlipX);
	DDX_Control(pDX, IDC_CHECK_SUB_Y_FLIP, m_chkUseFlipY);
	DDX_Control(pDX, IDC_EDIT_TCODE_NO, m_edtMainTcode);
	DDX_Control(pDX, IDC_EDIT_TCODE_SUB, m_edtSubTcode);
	DDX_Control(pDX, IDC_EDIT_SIZE, m_edtToolSize);
	DDX_Control(pDX, IDC_EDIT_SUB_TCODE_NO, m_edtSubNo);
	DDX_Control(pDX, IDC_EDIT_SUB_DRAW_STEP, m_edtDrawStep);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_STEP, m_edtJumpStep);
	DDX_Control(pDX, IDC_EDIT_SUB_DRAW_STEP_PERIOD, m_edtDrawStepPeriod);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_STEP_PERIOD, m_edtJumpStepPeriod);
	DDX_Control(pDX, IDC_EDIT_SUB_CORNER_DELAY, m_edtCornerDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_DELAY, m_edtJumpDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_LINE_DELAY, m_edtLineDelay);	
	DDX_Control(pDX, IDC_EDIT_SUB_LASER_ON_DELAY, m_edtLaserOnDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_LASER_OFF_DELAY, m_edtLaserOffDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_FREQUENCY, m_edtFrequency);
	DDX_Control(pDX, IDC_EDIT_SUB_FPS, m_edtFPS);
	DDX_Control(pDX, IDC_EDIT_SUB_CURRENT, m_edtCurrent);
	DDX_Control(pDX, IDC_EDIT_SUB_A1, m_edtA1);
	DDX_Control(pDX, IDC_EDIT_SUB_A2, m_edtA2);
	DDX_Control(pDX, IDC_EDIT_SUB_TOTAL_SHOT, m_edtTotalShot);
	DDX_Control(pDX, IDC_EDIT_SUB_BURST_SHOT, m_edtBurstShot);
	DDX_Control(pDX, IDC_EDIT_SUB_LEAD_IN, m_edtLeadIn);
	DDX_Control(pDX, IDC_EDIT_SUB_LEAD_OUT, m_edtLeadOut);	
	DDX_Control(pDX, IDC_EDIT_SUB_TABLE_SPEED, m_edtTableSpeed);
	DDX_Control(pDX, IDC_EDIT_SUB_ROTATE, m_edtRotate);
	DDX_Control(pDX, IDC_EDIT_APERTURE_PATH, m_edtAperturePath);
	DDX_Control(pDX, IDC_EDIT_PROFILE_PATH, m_edtScannerProfilePath);
	DDX_Control(pDX, IDC_EDIT_SUB_APERTURE_BURST, m_edtApertureBurst);
	DDX_Control(pDX, IDC_EDIT_SUB_MINSHOTTIME, m_edtMinShotTime);
	DDX_Control(pDX, IDC_EDIT_SUB_THERMAL_TRACK, m_edtThermalTrack);
	DDX_Control(pDX, IDC_EDIT_SUB_Z_OFFSET, m_edtZOffset);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_TOPHAT, m_chkUseTophat);
	DDX_Control(pDX, IDC_EDIT_SUB_MEMO, m_edtMemo);
	DDX_Control(pDX, IDC_EDIT_MIN_ALLOWABLE, m_edtMinPower);
	DDX_Control(pDX, IDC_EDIT_MAX_ALLOWABLE, m_edtMaxPower);
	DDX_Control(pDX, IDC_EDIT_HOLE_SIZE, m_edtHoleSize);
	DDX_Control(pDX, IDC_EDIT_SUB_GRID_X, m_edtGridX);
	DDX_Control(pDX, IDC_EDIT_SUB_GRID_Y, m_edtGridY);
	DDX_Control(pDX, IDC_EDIT_SUB_FIELD_SIZE, m_edtFieldSize);
	DDX_Control(pDX, IDC_EDIT_HOLE_SIZE, m_edtHoleSize);
	DDX_Control(pDX, IDC_CHECK_PRE_POWER, m_chkUsePrePower);
	DDX_Control(pDX, IDC_CHECK_PRE_SCAL, m_chkUsePreScal);

	DDX_Control(pDX, IDC_CHECK_SHOW_TOOL, m_chkAllShowTool);
	DDX_Control(pDX, IDC_EDIT_SUB_POWER_RESULT, m_edtPowerResult);
	DDX_Control(pDX, IDC_BUTTON_SUB_POWER_STOP, m_btnPowerStop);
	DDX_Control(pDX, IDC_EDIT_LOT_ID, m_edtLotID);
	DDX_Control(pDX, IDC_EDIT_FONT_SIZE, m_edtFontSize);
	DDX_Control(pDX, IDC_EDIT_TEXT_HOLE_PITCH, m_edtTextHolePitch);
	DDX_Control(pDX, IDC_EDIT_TOOL_PATH, m_edtToolPath);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneRecipeGenParameterNew, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenParameterNew)

	ON_CBN_SELCHANGE(IDC_COMBO_SUB_BARCODE_MATRIX, OnSelChangeCombobBarcodeMatrix)
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_BARCODE_LINE_DRILL, OnCheckUseBarcodeLineDrill)

	ON_NOTIFY(NM_CLICK, IDC_LIST_MAIN_TOOL_CODE, OnClickListMainToolCode)
	ON_NOTIFY(NM_CLICK, IDC_LIST_SUB_TOOL_CODE, OnClickListSubToolCode)
	ON_CBN_SELCHANGE(IDC_COMBO_COLOR, OnSelChangeComboColor)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_DRILL_METHOD, OnSelChangeComboDrillMethod)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_TOOL_TYPE, OnSelChangeComboToolType)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_MASK, OnSelChangeComboMask)
	ON_BN_CLICKED(IDC_BUTTON_SUB_APERTURE_OPEN, OnButtonApertureOpen)
	ON_BN_CLICKED(IDC_BUTTON_SUB_SHOT_SETTING, OnButtonSetting)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_ADD, OnButtonParamAdd)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_DELETE, OnButtonParamDelete)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE, OnButtonParamUpdate)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE_MAIN, OnButtonParamUpdateMain)
	ON_BN_CLICKED(IDC_CHECK_USE_TOOL, OnCheckUseTool)
	ON_BN_CLICKED(IDC_CHECK_TOOL_ORDER, OnCheckUseToolOrder)
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_APERTURE, OnCheckUseAperture)
	ON_BN_CLICKED(IDC_CHECK_PRE_POWER, OnCheckUsePrePower)
	ON_BN_CLICKED(IDC_CHECK_PRE_SCAL, OnCheckUsePreScal)

	ON_BN_CLICKED(IDC_CHECK_HOLE_FIND, OnCheckUseHoleFind)
	ON_BN_CLICKED(IDC_CHECK_HOLE_SORTING, OnCheckUseHoleSorting)
	ON_BN_CLICKED(IDC_BUTTON_SUB_STOP, OnButtonStop)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_SUB_PROFILE_OPEN, OnButtonSubProfileOpen)
	ON_EN_CHANGE(IDC_EDIT_SUB_TOTAL_SHOT, OnChangeEditSubTotalShot)
	ON_NOTIFY(LVN_ITEMCHANGING, IDC_LIST_MAIN_TOOL_CODE, OnItemchangingListMainToolCode)
	ON_NOTIFY(LVN_ITEMCHANGING, IDC_LIST_SUB_TOOL_CODE, OnItemchangingListSubToolCode)
	ON_BN_CLICKED(IDC_CHECK_SUB_X_FLIP, OnCheckSubXFlip)
	ON_BN_CLICKED(IDC_CHECK_SUB_Y_FLIP, OnCheckSubYFlip)
	ON_WM_PAINT()
	ON_EN_CHANGE(IDC_EDIT_SUB_ROTATE, OnChangeEditSubRotate)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_OPEN, OnButtonParamOpen)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_SAVE, OnButtonParamSave)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_TOOL, OnSelchangedTreeTool)
	ON_EN_CHANGE(IDC_EDIT_SUB_DRAW_STEP, OnChangeEditSubDrawStep)
	ON_EN_CHANGE(IDC_EDIT_SUB_FREQUENCY, OnChangeEditSubFrequency)
	ON_EN_CHANGE(IDC_EDIT_SUB_LASER_OFF_DELAY, OnChangeEditSubLaserOffDelay)
	ON_EN_CHANGE(IDC_EDIT_SUB_LASER_ON_DELAY, OnChangeEditSubLaserOnDelay)
	ON_EN_CHANGE(IDC_EDIT_SUB_BURST_SHOT, OnChangeEditSubBurstShot)
	ON_EN_CHANGE(IDC_EDIT_SUB_MINSHOTTIME, OnChangeEditSubMinShotTime)
	ON_EN_CHANGE(IDC_EDIT_SUB_APERTURE_BURST, OnChangeEditSubApertureBurst)
	ON_EN_CHANGE(IDC_EDIT_SIZE, OnChangeEditSize)
	ON_EN_CHANGE(IDC_EDIT_MAX_ALLOWABLE, OnChnageEditMax)
	ON_EN_CHANGE(IDC_EDIT_MIN_ALLOWABLE, OnChnageEditMin)
	ON_EN_CHANGE(IDC_EDIT_FONT_SIZE, OnChnageEditMarkingSize)
	ON_EN_CHANGE(IDC_EDIT_TEXT_HOLE_PITCH, OnChnageEditTextHolePitch)
	ON_EN_KILLFOCUS(IDC_EDIT_TEXT_HOLE_PITCH, OnKillfocusEditTextHolePitch)
	ON_EN_CHANGE(IDC_EDIT_LOT_ID, OnChnageEditLotID)
	ON_EN_KILLFOCUS(IDC_EDIT_LOT_ID, OnKillfocusEditLotId)
	ON_EN_KILLFOCUS(IDC_EDIT_FONT_SIZE, OnKillfocusEditMarkingSize)
	ON_BN_CLICKED(IDC_CHECK_SHOW_TOOL, OnCheckShowTool)
	ON_CBN_DROPDOWN(IDC_COMBO_SUB_MASK, OnDropdownComboSubMask)
	ON_BN_CLICKED(IDC_BUTTON_SUB_FIRE, OnButtonFire)
	ON_MESSAGE( VISION_INSPECTION, OnInspection )
	ON_BN_CLICKED(IDC_BUTTON_SUB_POWER, OnButtonPower)
	ON_MESSAGE( UM_DO_POWERMEASUREMENT, OnPowerMeasure )
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_TOOL_CAMERA, OnSelchangeComboCamera)
	ON_BN_CLICKED(IDC_BUTTON_SUB_STOP, OnButtonPowerStop)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN_BEAMPATH_TABLE, &CPaneRecipeGenParameterNew::OnBnClickedButtonOpenBeampathTable)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_SHOT_TABLE, &CPaneRecipeGenParameterNew::OnBnClickedButtonOpenShotTable)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNew diagnostics

#ifdef _DEBUG
void CPaneRecipeGenParameterNew::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenParameterNew::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNew message handlers
void CPaneRecipeGenParameterNew::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	memset(&m_pToolCode, 0, sizeof(m_pToolCode));

	OnCheckUseTool();
	InitComboControl();
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitEditControl();

	memset(&m_dDuty, 0, sizeof(m_dDuty));
	memset(&m_dAOMDelay, 0, sizeof(m_dAOMDelay));
	memset(&m_dAOMDuty, 0, sizeof(m_dAOMDuty));
	memset(&m_dMinFreq, 0, sizeof(m_dMinFreq));
	memset(&m_dMaxFreq, 0, sizeof(m_dMaxFreq));

	memset(&m_dDutyOffsetM, 0, sizeof(m_dDutyOffsetM));
	memset(&m_dDutyOffsetS, 0, sizeof(m_dDutyOffsetS));
	memset(&m_dVolOffsetM, 0, sizeof(m_dVolOffsetM));
	memset(&m_dVolOffsetS, 0, sizeof(m_dVolOffsetS));

	memset(&m_dPowerMin, 0, sizeof(m_dPowerMin));
	memset(&m_dPowerMax, 0, sizeof(m_dPowerMax));
	

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		m_dDuty[i] = 0;
		m_dAOMDelay[i] = 0;
		m_dAOMDuty[i] = 50;
#ifdef __KUNSAN_SAMSUNG_LARGE__
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
			m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq;
		else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq2;

		m_dMaxFreq[i] = 4000;
#else
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		{
			m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq;
			m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;
		}
		else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		{
			m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq2;
			m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
		}
#endif

		m_dDutyOffsetM[i] = 0;
		m_dDutyOffsetS[i] = 0;
		m_dVolOffsetM[i] = 0;
		m_dVolOffsetS[i] = 0;

		m_dPowerMin[i] = 0;
		m_dPowerMax[i] = 0;

		memcpy(m_cAOMFilePath[i], str, str.GetLength()+1);
	}

	m_bUseTool = FALSE;
	m_bToolOrder = FALSE;
	m_bUseAperture = FALSE;
	m_bUseFlipX = FALSE;
	m_bUseFlipY = FALSE;
	m_bUsePrePower = FALSE;
	m_bUsePreScal= FALSE;

	m_bUseBarcodeLineDrill = FALSE;

	m_dlgMeasurement.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgMeasurement.ShowWindow(SW_HIDE);
}

BOOL CPaneRecipeGenParameterNew::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneRecipeGenParameterNew::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");
	m_ctrTreeTool.SetFont( &m_fntList );
}

void CPaneRecipeGenParameterNew::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(140, "Arial Bold");
	
	// Shot Count Setting
	m_btnSetting.SetFont( &m_fntBtn );
	m_btnSetting.SetFlat( FALSE );
	m_btnSetting.EnableBallonToolTip();
	m_btnSetting.SetToolTipText( _T("Shot Count Setting") );
	m_btnSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetting.SetBtnCursor(IDC_HAND_1);

	// Aperture File Open
	m_btnFileOpen.SetFont( &m_fntBtn );
	m_btnFileOpen.SetFlat( FALSE );
	m_btnFileOpen.EnableBallonToolTip();
	m_btnFileOpen.SetToolTipText( _T("Aperture File Open") );
	m_btnFileOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFileOpen.SetBtnCursor(IDC_HAND_1);

	// Scanner move profile File Open
	m_btnScannerProfileOpen.SetFont( &m_fntBtn );
	m_btnScannerProfileOpen.SetFlat( FALSE );
	m_btnScannerProfileOpen.EnableBallonToolTip();
	m_btnScannerProfileOpen.SetToolTipText( _T("Scanner Move Profile File Open") );
	m_btnScannerProfileOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScannerProfileOpen.SetBtnCursor(IDC_HAND_1);

	// Param Add
	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Add Parameter") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	// Param Delete
	m_btnDelete.SetFont( &m_fntBtn );
	m_btnDelete.SetFlat( FALSE );
	m_btnDelete.EnableBallonToolTip();
	m_btnDelete.SetToolTipText( _T("Delete Parameter") );
	m_btnDelete.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDelete.SetBtnCursor(IDC_HAND_1);

	// Param Update
	m_btnUpdate.SetFont( &m_fntBtn2 );
	m_btnUpdate.SetFlat( FALSE );
	m_btnUpdate.EnableBallonToolTip();
	m_btnUpdate.SetToolTipText( _T("Update Parameter") );
	m_btnUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);
	m_btnUpdate.SetColorType(1); // Blue & Bold Line

	// Param Update Main
	m_btnUpdateMain.SetFont( &m_fntBtn );
	m_btnUpdateMain.SetFlat( FALSE );
	m_btnUpdateMain.EnableBallonToolTip();
	m_btnUpdateMain.SetToolTipText( _T("Update Main Paramater") );
	m_btnUpdateMain.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdateMain.SetBtnCursor(IDC_HAND_1);

	// Param Open Main Tool
	m_btnOpenMainTool.SetFont( &m_fntBtn );
	m_btnOpenMainTool.SetFlat( FALSE );
	m_btnOpenMainTool.EnableBallonToolTip();
	m_btnOpenMainTool.SetToolTipText( _T("Open Main Paramater") );
	m_btnOpenMainTool.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenMainTool.SetBtnCursor(IDC_HAND_1);

	// Param Save Main Tool
	m_btnSaveMainTool.SetFont( &m_fntBtn );
	m_btnSaveMainTool.SetFlat( FALSE );
	m_btnSaveMainTool.EnableBallonToolTip();
	m_btnSaveMainTool.SetToolTipText( _T("Save Main Paramater") );
	m_btnSaveMainTool.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSaveMainTool.SetBtnCursor(IDC_HAND_1);
	
	// Use Aperture
	m_chkUseAperture.SetFont( &m_fntBtn );
	m_chkUseAperture.SetImageOrg( 10, 3 );
	m_chkUseAperture.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAperture.EnableBallonToolTip();
	m_chkUseAperture.SetToolTipText( _T("Use Aperture") );
	m_chkUseAperture.SetBtnCursor(IDC_HAND_1);
	m_chkUseAperture.EnableWindow(TRUE);

	m_chkUseBarcodeLineDrill.SetFont( &m_fntBtn );
	m_chkUseBarcodeLineDrill.SetImageOrg( 10, 3 );
	m_chkUseBarcodeLineDrill.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseBarcodeLineDrill.EnableBallonToolTip();
	m_chkUseBarcodeLineDrill.SetToolTipText( _T("Use Barcode Line Drill") );
	m_chkUseBarcodeLineDrill.SetBtnCursor(IDC_HAND_1);
	m_chkUseBarcodeLineDrill.EnableWindow(TRUE);

	// Use Flip X
	m_chkUseFlipX.SetFont( &m_fntBtn );
	m_chkUseFlipX.SetImageOrg( 10, 3 );
	m_chkUseFlipX.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseFlipX.EnableBallonToolTip();
	m_chkUseFlipX.SetToolTipText( _T("Use Flip X") );
	m_chkUseFlipX.SetBtnCursor(IDC_HAND_1);
	m_chkUseFlipX.EnableWindow(TRUE);

	// Use Flip Y
	m_chkUseFlipY.SetFont( &m_fntBtn );
	m_chkUseFlipY.SetImageOrg( 10, 3 );
	m_chkUseFlipY.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseFlipY.EnableBallonToolTip();
	m_chkUseFlipY.SetToolTipText( _T("Use Flip Y") );
	m_chkUseFlipY.SetBtnCursor(IDC_HAND_1);
	m_chkUseFlipY.EnableWindow(TRUE);

	if(m_cmbToolType.GetCurSel() != TEXT_TYPE)
	{
		m_chkUseFlipX.ShowWindow(SW_HIDE);
		m_chkUseFlipY.ShowWindow(SW_HIDE);
	}

	// Find Hole
	m_chkHoleFind.SetFont( &m_fntBtn );
	m_chkHoleFind.SetImageOrg( 10, 3 );
	m_chkHoleFind.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkHoleFind.EnableBallonToolTip();
	m_chkHoleFind.SetToolTipText( _T("Use Hole Finding") );
	m_chkHoleFind.SetBtnCursor(IDC_HAND_1);
	m_chkHoleFind.EnableWindow(TRUE);

	m_chkHoleSorting.SetFont( &m_fntBtn );
	m_chkHoleSorting.SetImageOrg( 10, 3 );
	m_chkHoleSorting.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkHoleSorting.EnableBallonToolTip();
	m_chkHoleSorting.SetToolTipText( _T("Use Hole Sorting") );
	m_chkHoleSorting.SetBtnCursor(IDC_HAND_1);
	m_chkHoleSorting.EnableWindow(TRUE);

	// Use Tool
	m_chkUseTool.SetFont( &m_fntBtn );
	m_chkUseTool.SetImageOrg( 10, 3 );
	m_chkUseTool.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTool.EnableBallonToolTip();
	m_chkUseTool.SetToolTipText( _T("Use Tool") );
	m_chkUseTool.SetBtnCursor(IDC_HAND_1);
	m_chkUseTool.EnableWindow(TRUE);

	// ToolOrder
	m_chkUseToolOrder.SetFont( &m_fntBtn );
	m_chkUseToolOrder.SetImageOrg( 10, 3 );
	m_chkUseToolOrder.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseToolOrder.EnableBallonToolTip();
	m_chkUseToolOrder.SetToolTipText( _T("Tool Order") );
	m_chkUseToolOrder.SetBtnCursor(IDC_HAND_1);
	m_chkUseToolOrder.EnableWindow(TRUE);

	//use tophat
	m_chkUseTophat.SetFont( &m_fntBtn );
	m_chkUseTophat.SetImageOrg( 10, 3 );
	m_chkUseTophat.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTophat.EnableBallonToolTip();
	m_chkUseTophat.SetToolTipText( _T("Use TopHat") );
	m_chkUseTophat.SetBtnCursor(IDC_HAND_1);
	m_chkUseTophat.EnableWindow(TRUE);

	//use Prework Power
	m_chkUsePrePower.SetFont( &m_fntBtn );
	m_chkUsePrePower.SetImageOrg( 10, 3 );
	m_chkUsePrePower.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePrePower.EnableBallonToolTip();
	m_chkUsePrePower.SetToolTipText( _T("Use Prework Power") );
	m_chkUsePrePower.SetBtnCursor(IDC_HAND_1);
	m_chkUsePrePower.EnableWindow(TRUE);

	m_chkUsePreScal.SetFont( &m_fntBtn );
	m_chkUsePreScal.SetImageOrg( 10, 3 );
	m_chkUsePreScal.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePreScal.EnableBallonToolTip();
	m_chkUsePreScal.SetToolTipText( _T("Use Prework Scal") );
	m_chkUsePreScal.SetBtnCursor(IDC_HAND_1);
	m_chkUsePreScal.EnableWindow(TRUE);

	//use Show All tool
	m_chkAllShowTool.SetFont( &m_fntBtn );
	m_chkAllShowTool.SetImageOrg( 10, 3 );
	m_chkAllShowTool.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAllShowTool.EnableBallonToolTip();
	m_chkAllShowTool.SetToolTipText( _T("Use Prework Power") );
	m_chkAllShowTool.SetBtnCursor(IDC_HAND_1);
	m_chkAllShowTool.EnableWindow(TRUE);

	// Fire
	m_btnFire.SetFont( &m_fntBtn );
	m_btnFire.SetFlat( FALSE );
	m_btnFire.EnableBallonToolTip();
	m_btnFire.SetToolTipText( _T("Fire") );
	m_btnFire.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFire.SetBtnCursor(IDC_HAND_1);
	
	// stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop Fire") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	// power
	m_btnPower.SetFont( &m_fntBtn );
	m_btnPower.SetFlat( FALSE );
	m_btnPower.EnableBallonToolTip();
	m_btnPower.SetToolTipText( _T("Power Measurement") );
	m_btnPower.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPower.SetBtnCursor(IDC_HAND_1);

	// power stop 
	m_btnPowerStop.SetFont( &m_fntBtn );
	m_btnPowerStop.SetFlat( FALSE );
	m_btnPowerStop.EnableBallonToolTip();
	m_btnPowerStop.SetToolTipText( _T("Stop Power Measurement") );
	m_btnPowerStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowerStop.SetBtnCursor(IDC_HAND_1);


	GetDlgItem(IDC_BUTTON_OPEN_BEAMPATH_TABLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_BUTTON_OPEN_SHOT_TABLE)->SetFont( &m_fntBtn );
}

void CPaneRecipeGenParameterNew::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	m_fntEdit2.CreatePointFont(100, "Arial Bold");
	
	// T-Code No
	m_edtMainTcode.SetFont( &m_fntEdit );
	m_edtMainTcode.SetForeColor( BLACK_COLOR );
	m_edtMainTcode.SetBackColor( WHITE_COLOR );
	m_edtMainTcode.SetReceivedFlag( 1 ); // Integer
	m_edtMainTcode.EnableWindow( FALSE );

	m_edtSubTcode.SetFont( &m_fntEdit );
	m_edtSubTcode.SetForeColor( BLACK_COLOR );
	m_edtSubTcode.SetBackColor( WHITE_COLOR );
	m_edtSubTcode.SetReceivedFlag( 1 ); // Integer
	m_edtSubTcode.EnableWindow( FALSE );
	
	// Tool Size
	m_edtToolSize.SetFont( &m_fntEdit );
	m_edtToolSize.SetForeColor( BLACK_COLOR );
	m_edtToolSize.SetBackColor( WHITE_COLOR );
	m_edtToolSize.SetReceivedFlag( 1 ); // Integer
	m_edtToolSize.SetWindowText( _T("0") );
	
	// Sub Tool No
	m_edtSubNo.SetFont( &m_fntEdit );
	m_edtSubNo.SetForeColor( BLACK_COLOR );
	m_edtSubNo.SetBackColor( WHITE_COLOR );
	m_edtSubNo.SetReceivedFlag( 1 ); // Integer
	m_edtSubNo.EnableWindow( FALSE );
	
	// Draw Step
	m_edtDrawStep.SetFont( &m_fntEdit );
	m_edtDrawStep.SetForeColor( BLACK_COLOR );
	m_edtDrawStep.SetBackColor( WHITE_COLOR );
	m_edtDrawStep.SetReceivedFlag( 3 ); // Integer
	m_edtDrawStep.SetWindowText( _T("25") );

	// Jump Step
	m_edtJumpStep.SetFont( &m_fntEdit );
	m_edtJumpStep.SetForeColor( BLACK_COLOR );
	m_edtJumpStep.SetBackColor( WHITE_COLOR );
	m_edtJumpStep.SetReceivedFlag( 3 ); // Integer
	m_edtJumpStep.SetWindowText( _T("50") );
	
	// Draw Step Period
	m_edtDrawStepPeriod.SetFont( &m_fntEdit );
	m_edtDrawStepPeriod.SetForeColor( BLACK_COLOR );
	m_edtDrawStepPeriod.SetBackColor( WHITE_COLOR );
	m_edtDrawStepPeriod.SetReceivedFlag( 1 ); // Integer
	m_edtDrawStepPeriod.SetWindowText( _T("20") );

	// Jump Step Period
	m_edtJumpStepPeriod.SetFont( &m_fntEdit );
	m_edtJumpStepPeriod.SetForeColor( BLACK_COLOR );
	m_edtJumpStepPeriod.SetBackColor( WHITE_COLOR );
	m_edtJumpStepPeriod.SetReceivedFlag(1); // Integer
	m_edtJumpStepPeriod.SetWindowText( _T("20") );

	// Corner Delay
	m_edtCornerDelay.SetFont( &m_fntEdit );
	m_edtCornerDelay.SetForeColor( BLACK_COLOR );
	m_edtCornerDelay.SetBackColor( WHITE_COLOR );
	m_edtCornerDelay.SetReceivedFlag( 1 ); // Integer
	m_edtCornerDelay.SetWindowText( _T("20") );
	
	// Jump Delay
	m_edtJumpDelay.SetFont( &m_fntEdit );
	m_edtJumpDelay.SetForeColor( BLACK_COLOR );
	m_edtJumpDelay.SetBackColor( WHITE_COLOR );
	m_edtJumpDelay.SetReceivedFlag( 1 ); // Integer
	m_edtJumpDelay.SetWindowText( _T("350") );

	// Line Delay
	m_edtLineDelay.SetFont( &m_fntEdit );
	m_edtLineDelay.SetForeColor( BLACK_COLOR );
	m_edtLineDelay.SetBackColor( WHITE_COLOR );
	m_edtLineDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLineDelay.SetWindowText( _T("200") );

	// Laser On Delay
	m_edtLaserOnDelay.SetFont( &m_fntEdit );
	m_edtLaserOnDelay.SetForeColor( BLACK_COLOR );
	m_edtLaserOnDelay.SetBackColor( WHITE_COLOR );
	m_edtLaserOnDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLaserOnDelay.SetWindowText( _T("350") );
	
	// Laser Off Delay
	m_edtLaserOffDelay.SetFont( &m_fntEdit );
	m_edtLaserOffDelay.SetForeColor( BLACK_COLOR );
	m_edtLaserOffDelay.SetBackColor( WHITE_COLOR );
	m_edtLaserOffDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLaserOffDelay.SetWindowText( _T("250") );

	// Frequency
	m_edtFrequency.SetFont( &m_fntEdit );
	m_edtFrequency.SetForeColor( BLACK_COLOR );
	m_edtFrequency.SetBackColor( WHITE_COLOR );
	m_edtFrequency.SetReceivedFlag( 1 ); // Integer
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		m_edtFrequency.SetWindowText( _T("90000") );
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		m_edtFrequency.SetWindowText( _T("20000") );
	else
		m_edtFrequency.SetWindowText( _T("1000") );

	// FPS
	m_edtFPS.SetFont( &m_fntEdit );
	m_edtFPS.SetForeColor( BLACK_COLOR );
	m_edtFPS.SetBackColor( WHITE_COLOR );
	m_edtFPS.SetReceivedFlag( 1 ); // Integer
	m_edtFPS.SetWindowText( _T("0") );

	// Current
	m_edtCurrent.SetFont( &m_fntEdit );
	m_edtCurrent.SetForeColor( BLACK_COLOR );
	m_edtCurrent.SetBackColor( WHITE_COLOR );
	m_edtCurrent.SetReceivedFlag( 3 ); // float
	m_edtCurrent.SetWindowText( _T("90.0") );

	// Attenuator 1
	m_edtA1.SetFont( &m_fntEdit );
	m_edtA1.SetForeColor( BLACK_COLOR );
	m_edtA1.SetBackColor( WHITE_COLOR );
	m_edtA1.SetReceivedFlag( 3 ); // float
	m_edtA1.SetWindowText( _T("100") );

	// Attenuator 2
	m_edtA2.SetFont( &m_fntEdit );
	m_edtA2.SetForeColor( BLACK_COLOR );
	m_edtA2.SetBackColor( WHITE_COLOR );
	m_edtA2.SetReceivedFlag( 3 ); // float
	m_edtA2.SetWindowText( _T("100") );

	// TotalShot
	m_edtTotalShot.SetFont( &m_fntEdit );
	m_edtTotalShot.SetForeColor( BLACK_COLOR );
	m_edtTotalShot.SetBackColor( WHITE_COLOR );
	m_edtTotalShot.SetReceivedFlag( 1 ); // Integer
	m_edtTotalShot.SetWindowText( _T("1") );

	// BurstShot
	m_edtBurstShot.SetFont( &m_fntEdit );
	m_edtBurstShot.SetForeColor( BLACK_COLOR );
	m_edtBurstShot.SetBackColor( WHITE_COLOR );
	m_edtBurstShot.SetReceivedFlag( 1 ); // Integer
	m_edtBurstShot.SetWindowText( _T("0") );

	// Lead In
	m_edtLeadIn.SetFont( &m_fntEdit );
	m_edtLeadIn.SetForeColor( BLACK_COLOR );
	m_edtLeadIn.SetBackColor( WHITE_COLOR );
	m_edtLeadIn.SetReceivedFlag( 1 ); // Integer
	m_edtLeadIn.SetWindowText( _T("50") );

	// Lead Out
	m_edtLeadOut.SetFont( &m_fntEdit );
	m_edtLeadOut.SetForeColor( BLACK_COLOR );
	m_edtLeadOut.SetBackColor( WHITE_COLOR );
	m_edtLeadOut.SetReceivedFlag( 1 ); // Integer
	m_edtLeadOut.SetWindowText( _T("50") );

	// TableSpeed
	m_edtTableSpeed.SetFont( &m_fntEdit );
	m_edtTableSpeed.SetForeColor( BLACK_COLOR );
	m_edtTableSpeed.SetBackColor( WHITE_COLOR );
	m_edtTableSpeed.SetReceivedFlag( 1 ); // Integer
	m_edtTableSpeed.SetWindowText( _T("2000") );

	// rotate
	m_edtRotate.SetFont( &m_fntEdit );
	m_edtRotate.SetForeColor( BLACK_COLOR );
	m_edtRotate.SetBackColor( WHITE_COLOR );
	m_edtRotate.SetReceivedFlag( 1 ); // Integer
	m_edtRotate.SetWindowText( _T("0") );
	
	// Aperture File Path
	m_edtAperturePath.SetFont( &m_fntEdit2 );
	m_edtAperturePath.SetForeColor( BLACK_COLOR );
	m_edtAperturePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtAperturePath.SetWindowText( _T("") );
	m_edtAperturePath.EnableWindow( FALSE );

	// Scanner Move Profile File Path
	m_edtScannerProfilePath.SetFont( &m_fntEdit2 );
	m_edtScannerProfilePath.SetForeColor( BLACK_COLOR );
	m_edtScannerProfilePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtScannerProfilePath.SetWindowText( _T("") );
	m_edtScannerProfilePath.EnableWindow( FALSE );

	// Aperture Burst Shot
	m_edtApertureBurst.SetFont( &m_fntEdit );
	m_edtApertureBurst.SetForeColor( BLACK_COLOR );
	m_edtApertureBurst.SetBackColor( WHITE_COLOR );
	m_edtApertureBurst.SetReceivedFlag( 1 ); // Integer
	m_edtApertureBurst.SetWindowText( _T("1") );

	m_edtMinShotTime.SetFont( &m_fntEdit );
	m_edtMinShotTime.SetForeColor( BLACK_COLOR );
	m_edtMinShotTime.SetBackColor( WHITE_COLOR );
	m_edtMinShotTime.SetReceivedFlag( 1 ); // Integer
	m_edtMinShotTime.SetWindowText( _T("1") );

	// Thermal Track
	m_edtThermalTrack.SetFont( &m_fntEdit );
	m_edtThermalTrack.SetForeColor( BLACK_COLOR );
	m_edtThermalTrack.SetBackColor( WHITE_COLOR );
	m_edtThermalTrack.SetReceivedFlag( 1 ); // Integer
	m_edtThermalTrack.SetWindowText( _T("2525") );

	// Z Offset
	m_edtZOffset.SetFont( &m_fntEdit );
	m_edtZOffset.SetForeColor( BLACK_COLOR );
	m_edtZOffset.SetBackColor( WHITE_COLOR );
	m_edtZOffset.SetReceivedFlag( 3 ); // float
	m_edtZOffset.SetWindowText( _T("0.0") );

	// Memo
	m_edtMemo.SetFont( &m_fntEdit2 );
	m_edtMemo.SetForeColor( BLACK_COLOR );
	m_edtMemo.SetBackColor( WHITE_COLOR );
	m_edtMemo.SetWindowText( _T("") );

	// Min Power
	m_edtMinPower.SetFont( &m_fntEdit );
	m_edtMinPower.SetForeColor( BLACK_COLOR );
	m_edtMinPower.SetBackColor( WHITE_COLOR );
	m_edtMinPower.SetReceivedFlag( 3 ); // float
	m_edtMinPower.SetWindowText( _T("1") );

	// Max Power
	m_edtMaxPower.SetFont( &m_fntEdit );
	m_edtMaxPower.SetForeColor( BLACK_COLOR );
	m_edtMaxPower.SetBackColor( WHITE_COLOR );
	m_edtMaxPower.SetReceivedFlag( 3 ); // float
	m_edtMaxPower.SetWindowText( _T("10") );

	// Hole Size for scal
	m_edtHoleSize.SetFont( &m_fntEdit );
	m_edtHoleSize.SetForeColor( BLACK_COLOR );
	m_edtHoleSize.SetBackColor( WHITE_COLOR );
	m_edtHoleSize.SetReceivedFlag( 3 ); // float
	m_edtHoleSize.SetWindowText( _T("0.25") );

	// field size
	m_edtFieldSize.SetFont( &m_fntEdit );
	m_edtFieldSize.SetForeColor( BLACK_COLOR );
	m_edtFieldSize.SetBackColor( WHITE_COLOR );
	m_edtFieldSize.SetReceivedFlag( 1 ); // float
	CString str;
	str.Format(_T("%.1f"), gSystemINI.m_sSystemDevice.dFieldSize);
	m_edtFieldSize.SetWindowText(str);
	
	// Max Power
	m_edtGridX.SetFont( &m_fntEdit );
	m_edtGridX.SetForeColor( BLACK_COLOR );
	m_edtGridX.SetBackColor( WHITE_COLOR );
	m_edtGridX.SetReceivedFlag( 1 ); // float
	m_edtGridX.SetWindowText( _T("1") );
	
	// Hole Size for scal
	m_edtGridY.SetFont( &m_fntEdit );
	m_edtGridY.SetForeColor( BLACK_COLOR );
	m_edtGridY.SetBackColor( WHITE_COLOR );
	m_edtGridY.SetReceivedFlag( 1 ); // float
	m_edtGridY.SetWindowText( _T("1") );

	m_edtPowerResult.SetFont( &m_fntEdit );
	m_edtPowerResult.SetForeColor( BLACK_COLOR );
	m_edtPowerResult.SetBackColor( WHITE_COLOR );
	m_edtPowerResult.SetReceivedFlag( 1 ); // float
	m_edtPowerResult.SetWindowText( _T("0") );

	// Lot id
	m_edtLotID.SetFont( &m_fntEdit2 );
	m_edtLotID.SetForeColor( BLACK_COLOR );
	m_edtLotID.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtLotID.SetWindowText( _T("") );
	m_edtLotID.EnableWindow( TRUE );
	
	// lot id marking size
	m_edtFontSize.SetFont( &m_fntEdit );
	m_edtFontSize.SetForeColor( BLACK_COLOR );
	m_edtFontSize.SetBackColor( WHITE_COLOR );
	m_edtFontSize.SetReceivedFlag( 1 ); // Integer
	m_edtFontSize.SetWindowText( _T("6000") );

	// lot id text hole pitch
	m_edtTextHolePitch.SetFont( &m_fntEdit );
	m_edtTextHolePitch.SetForeColor( BLACK_COLOR );
	m_edtTextHolePitch.SetBackColor( WHITE_COLOR );
	m_edtTextHolePitch.SetReceivedFlag( 1 ); // Integer
	m_edtTextHolePitch.SetWindowText( _T("200") );

	// Tool Path 
	m_edtToolPath.SetFont( &m_fntEdit2 );
	m_edtToolPath.SetForeColor( BLACK_COLOR );
	m_edtToolPath.SetBackColor( WHITE_COLOR );
	m_edtToolPath.SetWindowText( _T(" ") );
	if(!gProcessINI.m_sProcessSystem.bUseOpenTool)
		m_edtToolPath.ShowWindow(SW_HIDE);

	m_edtToolPath.EnableWindow(FALSE);
}

void CPaneRecipeGenParameterNew::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_TCODE_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COLOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TCODE_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TOOL_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP_PERIOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP_PERIOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_CORNER_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LINE_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LASER_ON_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LASER_OFF_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_FPS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_CURRENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_MASK_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRILL_METHOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TOTAL_SHOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LEAD_IN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LEAD_OUT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TABLE_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_ROTATE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_PROFILE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_A1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_A2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_MEMO)->SetFont(  &m_fntStatic );
	GetDlgItem(IDC_STATIC_MINMAX_ALLOWABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MIN_ALLOWABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAX_ALLOWABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_HOLE_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOLE_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_GRID_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_GRID_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_POWER_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOT_ID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HEIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TEXT_HOLE_PITCH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_MINSHOTTIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOOLPATH)->SetFont( &m_fntStatic );
	if(!gProcessINI.m_sProcessSystem.bUseOpenTool)
		GetDlgItem(IDC_STATIC_TOOLPATH)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SUB_SHOTGROUP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_SHOTGROUP_NO)->SetFont( &m_fntStatic );
	
}

void CPaneRecipeGenParameterNew::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");
	
	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbMask.SetCurSel( 0 );

	m_cmbColor.SetFont( &m_fntCombo );
	m_cmbColor.SetCurSel( 0 );
	
	m_cmbDrillMethod.SetFont( &m_fntCombo );
	m_cmbDrillMethod.SetCurSel( 1 );

	m_cmbBarcodeMatrix.SetFont( &m_fntCombo );
	m_cmbBarcodeMatrix.SetCurSel( 6 );

	m_cmbToolType.SetFont( &m_fntCombo );
	m_cmbToolType.ResetContent();
	m_cmbToolType.AddString("Marking");
	m_cmbToolType.AddString("Shot Drill");
	//if(gProcessINI.m_sProcessSystem.bUseTextMarking)
	//{
		m_cmbToolType.AddString("Text Drill");
		m_cmbToolType.AddString("Line Drill");
		m_cmbToolType.AddString("Flying Drill");
		m_cmbToolType.AddString("Barcode Drill");

	//}
	m_cmbToolType.SetCurSel( 1 );

	m_cmbCam.SetFont( &m_fntCombo );
	m_cmbCam.SetCurSel( 0 );

	ChangeBeamPathData();
}

void CPaneRecipeGenParameterNew::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	
	CFormView::OnDestroy();
}
BOOL CPaneRecipeGenParameterNew::CheckLaserDutyLimit(SUBTOOLDATA subData)
{
	//mark dummy�� üũ 
	if(subData.nToolType != MARKING_TYPE && subData.nToolType != LINE_DRILL_TYPE)
		return TRUE;

	double dDutyLimit = (1000000./(double)subData.nFrequency) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent/100.; // us ���� 
	double dMaskDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowOffsetDuty[subData.nMask];
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subData.nMask];

	double dTotalDuty;
	
	for(int k = 0 ; k < subData.nTotalShot; k++)
	{
		
		dTotalDuty = subData.dShotDuty[k] + dMaskDutyOffset + dPowerDutyOffset;
#ifdef __3RDAOD__
		if( dTotalDuty > dDutyLimit)
			return FALSE;
#else
		if( dTotalDuty > dDutyLimit ||  1 > dDutyLimit)
			return FALSE;
#endif
	}
	return TRUE;
}

BOOL CPaneRecipeGenParameterNew::GetData(DProject &tempDProject)
{
	CToolCodeList* pToolCode;
	SUBTOOLDATA subTool;
	BOOL bPower = FALSE;
	BOOL bHoldFind = FALSE;
	for(int i=0; i<MAX_TOOL_NO; i++)
	{
		pToolCode = m_pToolCode[i];
		if(!pToolCode->m_bUseTool)
			continue;

		if(pToolCode->m_bHoldFind == 1)
		{
			if(bHoldFind && tempDProject.m_nHoleFind != NO_FIND)
			{
				ErrMessage(_T("You just select one tool in order that hole finding"));
				return FALSE;
			}
			else
				bHoldFind = TRUE;
		}
		if(pToolCode->m_bPreworkPower == 1)
			bPower = TRUE;
		POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			subTool = pToolCode->m_SubToolData.GetNext(pos);
			if(!CheckSubTool(subTool, i))
				return FALSE;

			if(!CheckLaserDutyLimit(subTool))
			{
				ErrMessage(_T("You muse check Duty & Freq. for Duty limit"));
				return FALSE;
			}
		}
	}

	if(!bHoldFind && tempDProject.m_nHoleFind != NO_FIND)
	{
		ErrMessage(_T("You just select one tool in order that hole finding"));
		return FALSE;
	}
	if(!bPower)
	{
		ErrMessage(_T("You must use PrePower at least one tool. ")/*"��� �����̻��� PrePower�� ����ؾ� �մϴ�."*/);
		return FALSE;
	}
	CString strLot;
	m_edtLotID.GetWindowText(strLot);
	strcpy_s(tempDProject.m_szLotId, strLot);
	strcpy_s(tempDProject.m_szToolName, m_szToolName);
	return TRUE;
}

BOOL CPaneRecipeGenParameterNew::SetData(DProject& mDproject)
{ 

	m_pProject = &mDproject;

	ShowControl(FALSE);
	m_bGlobalParam = FALSE;
	m_ctrTreeTool.DeleteAllItems( );

	m_edtLotID.EnableWindow(TRUE);
	m_edtFontSize.EnableWindow(TRUE);
	m_edtTextHolePitch.EnableWindow(TRUE);

	BOOL bAllShow = m_chkAllShowTool.GetCheck();
	BOOL bSkiving = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SkivingCheck();
	if(bSkiving)
	{
		mDproject.m_pToolCode[0]->m_bUseTool = TRUE;
	}
	else 
	{
		mDproject.m_pToolCode[0]->m_bUseTool = FALSE;
	}
	ChangeBeamPathData();

	CString strText;
//	memset(&m_pToolCode, 0, sizeof(m_pToolCode));
	int nMainCount = -1, nSubCnt;
	HTREEITEM hRoot, hSubItem;
	SUBTOOLDATA subData;
	BOOL bMainAdd = FALSE, bSubAdd = FALSE;
	BOOL bChangePandSCal = FALSE;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
//		if(m_pToolCode[i] == NULL || m_pToolCode[i]->m_bUseTool != mDproject.m_pToolCode[i]->m_bUseTool)
//			bChangePandSCal = TRUE;
		m_pToolCode[i] = mDproject.m_pToolCode[i];

		POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
//		if(!m_pToolCode[i]->m_bUseTool && !bAllShow)
		if(!m_pToolCode[i]->m_bUseTool && !bAllShow/* && pos == NULL*/)
			continue;

			nMainCount++;
			bMainAdd = TRUE;
			strText.Format(_T("Tool %d(T%02d)"), i, m_pToolCode[i]->m_nRefToolNo);
			hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
			if (hRoot != NULL) 
			{
			   m_ctrTreeTool.SetItemData(hRoot, nMainCount * 100);
			}
			nSubCnt = 1;
			pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			while(pos)
			{
				subData = m_pToolCode[i]->m_SubToolData.GetAt(pos);
				
				SetFirstSubShot(subData);
				m_pToolCode[i]->m_SubToolData.SetAt(pos, subData);
				m_pToolCode[i]->m_SubToolData.GetNext(pos);
				strText.Format(_T("SubTool %d"), nSubCnt);
				hSubItem = m_ctrTreeTool.InsertItem(strText, 0, 1, hRoot);
				if (hSubItem != NULL)
				{
					m_ctrTreeTool.SetItemData(hSubItem, nMainCount * 100 + nSubCnt);
				}
				
				bSubAdd = TRUE;

				nSubCnt++;

/*				subData = m_pToolCode[i]->m_SubToolData.GetNext(pos);
				strText.Format(_T("SubTool %d"), nSubCnt);
				hSubItem = m_ctrTreeTool.InsertItem(strText, 0, 1, hRoot);
				if (hSubItem != NULL)
				{
					m_ctrTreeTool.SetItemData(hSubItem, nMainCount * 100 + nSubCnt);
				}

				bSubAdd = TRUE;
				SetFirstSubShot(subData);
				nSubCnt++;
*/

			}
			m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);
	}

/*	if(bChangePandSCal)
	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (Excellon Change) : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
*/

	strcpy(m_szToolName, mDproject.m_szToolName);
	if(bMainAdd)
		m_nToolIndex = 0;
	if(bSubAdd)
		m_nSubIndex = 0;

	UpdateList(m_nToolIndex,m_nSubIndex);
	ChangeDisplay(m_nToolIndex, m_nSubIndex);
	return TRUE;
}

void CPaneRecipeGenParameterNew::AddParameter(int nMainIndex)
{
}

void CPaneRecipeGenParameterNew::ChangeDisplay(int nMainIndex, int nSubIndex)
{
	CString str = _T("");
	SUBTOOLDATA subData;

	CToolCodeList* pToolCode;
	int nListIndex = GetUseToolIndex(nMainIndex);

	if(nListIndex == -1)
		return;

	pToolCode = m_pToolCode[nListIndex];
	str.Format(_T("%s"), m_szToolName);
	m_edtToolPath.SetWindowText(str);
	int i= -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	if( nSubIndex== -1)
	{
		
		if(m_bGlobalParam)
		{
/*			if(nListIndex == 0)
			{
				m_edtMainTcode.SetWindowText("S. Cal.");
				GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(TRUE);
				GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(TRUE);
			}
			else
*/			if(nListIndex == 0)
			{
				m_edtMainTcode.SetWindowText("One Hole");
//				GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(FALSE);
//				GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(FALSE);
			}
			else
			{
 				m_edtMainTcode.SetWindowText("Power");
// 				GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(FALSE);
// 				GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(FALSE);
			}
		}
		else
		{
			str.Format(_T("%d"), nListIndex);
			m_edtMainTcode.SetWindowText(str);
		}
		m_chkHoleFind.SetCheck(pToolCode->m_bHoldFind);
		m_chkHoleSorting.SetCheck(pToolCode->m_bHoleSorting);
		
		m_chkUseTool.SetCheck(pToolCode->m_bUseTool);
		
		m_cmbColor.SetCurSel(pToolCode->m_nToolColor);
		
		str.Format(_T("%d"), pToolCode->m_nToolSize);
		m_edtToolSize.SetWindowText(str);
		
		m_chkUseToolOrder.SetCheck(pToolCode->m_bToolOrder);
		m_chkUsePrePower.SetCheck(pToolCode->m_bPreworkPower);
		
		m_edtSubTcode.SetWindowText(_T("-"));

		m_chkUsePrePower.SetCheck(pToolCode->m_bPreworkPower);
		m_chkUsePreScal.SetCheck(pToolCode->m_bPreworkScanner);
//		m_edtMinPower.EnableWindow(pToolCode->m_bPreworkPower);
//		m_edtMaxPower.EnableWindow(pToolCode->m_bPreworkPower);

		
//		str.Format(_T("%.1f"), m_dMin[nListIndex]);
//		m_edtMinPower.SetWindowText(str);
		
//		str.Format(_T("%.1f"), m_dMax[nListIndex]);
//		m_edtMaxPower.SetWindowText(str);

		//---------------------------------------------
		EnableControl(FALSE);
		GetDlgItem(IDC_COMBO_COLOR)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SIZE)->EnableWindow(TRUE);
		//---------------------------------------------
		UpdateData(FALSE);

		return;
	}
	else
	{		
		GetDlgItem(IDC_EDIT_MIN_ALLOWABLE)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_MAX_ALLOWABLE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SUB_POWER)->EnableWindow(FALSE);
	}
	EnableControl(TRUE);
	UpdateData(FALSE);
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);

//	OnCheckUseTool();

	str.Format(_T("%.1f"), subData.dMinPower);
	m_edtMinPower.SetWindowText(str);
	
	str.Format(_T("%.1f"), subData.dMaxPower);
	m_edtMaxPower.SetWindowText(str);

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		if( i < subData.nTotalShot)
			m_dDuty[i] = subData.dShotDuty[i];
		else
		{
			m_dDuty[i] = 0;
			subData.dShotDuty[i] = 0;
		}

		m_dAOMDelay[i] = subData.dShotAOMDelay[i];
		m_dAOMDuty[i] = subData.dShotAOMDuty[i];
		if (subData.dShotMinFreq[i] == INT_MAX)	
		{
			if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
			{
				m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq;
			}
			else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			{
				m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq2;
			}
		}
		else
			m_dMinFreq[i] = subData.dShotMinFreq[i];
		
		if (subData.dShotMaxFreq[i] == INT_MAX)
		{
			if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			{
				m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;
			}
			else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			{
				m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
			}
		}
		else
			m_dMaxFreq[i] = subData.dShotMaxFreq[i];	

		memcpy(m_cAOMFilePath[i], subData.cAOMFilePath[i], 255);

		m_dDutyOffsetM[i] = subData.dShotDutyOffsetM[i];

		m_dPowerMin[i] = subData.dPowerMin[i];
		m_dPowerMax[i] = subData.dPowerMax[i];
#ifndef __USEAOD__
		m_dDutyOffsetS[i] = 0;
		m_dVolOffsetM[i] = 0;
		m_dVolOffsetS[i] = 0;
#else
		m_dDutyOffsetS[i] = subData.dShotDutyOffsetS[i];
		m_dVolOffsetM[i] = subData.dShotVolOffsetM[i];
		m_dVolOffsetS[i] = subData.dShotVolOffsetS[i];
#endif
	}
	pToolCode->m_SubToolData.SetAt(pos, subData);

	if(m_bGlobalParam)
	{

	}
	else
	{	
		m_dDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[subData.nMask];
		m_dAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[subData.nMask];
		m_dAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[subData.nMask];
		memcpy(m_cAOMFilePath[0], subData.cAOMFilePath[0], 255);

		m_dDutyOffsetM[0] = 0;
		m_dDutyOffsetS[0] = 0;
		m_dVolOffsetM[0] = 0;
		m_dVolOffsetS[0] = 0;

		str.Format(_T("%d"), nListIndex);
		m_edtMainTcode.SetWindowText(str);
	}

	str.Format(_T("Sub %d"), nSubIndex+1);
	m_edtSubTcode.SetWindowText(str);

	m_chkUseTool.SetCheck(pToolCode->m_bUseTool);

	m_bUseTool = pToolCode->m_bUseTool;
	m_cmbColor.SetCurSel(pToolCode->m_nToolColor);
	
	m_chkHoleFind.SetCheck(pToolCode->m_bHoldFind);
	m_chkHoleSorting.SetCheck(pToolCode->m_bHoleSorting);

	str.Format(_T("%d"), pToolCode->m_nToolSize);
	m_edtToolSize.SetWindowText(str);

	m_chkUseToolOrder.SetCheck(pToolCode->m_bToolOrder);
	
	m_chkUsePrePower.SetCheck(pToolCode->m_bPreworkPower);
	m_chkUsePreScal.SetCheck(pToolCode->m_bPreworkScanner);

//	if(pToolCode->m_bPreworkPower && nSubIndex == -1)
//	{
//		GetDlgItem(IDC_EDIT_MIN_ALLOWABLE)->EnableWindow(TRUE);
//		GetDlgItem(IDC_EDIT_MAX_ALLOWABLE)->EnableWindow(TRUE);
//		GetDlgItem(IDC_BUTTON_SUB_POWER)->EnableWindow(TRUE);
//	}
	m_bToolOrder = pToolCode->m_bToolOrder;

	str.Format(_T("%d"), pToolCode->m_nMarkingSize);
	m_edtFontSize.SetWindowText(str);

	str.Format(_T("%d"), pToolCode->m_nTextHolePitch);
	m_edtTextHolePitch.SetWindowText(str);
	
	str.Format(_T("%s"), gDProject.m_szLotId);
	m_edtLotID.SetWindowText(str);

	str.Format(_T("%d"), subData.nSubToolNo);
	m_edtSubNo.SetWindowText(str);


	 int nShotIndex2 = gBeamPathINI.m_sBeampath.nSelectShot[subData.nMask];


	subData.nToolType = gShotTableINI.m_sShotGroupTable.nToolType[nShotIndex2];//subData.nToolType;


	m_cmbToolType.SetCurSel(subData.nToolType);

	m_cmbMask.SetCurSel(subData.nMask);

	m_chkUseTophat.SetCheck(subData.bUseTophat);
	
	m_cmbDrillMethod.SetCurSel(subData.nShotMode);

	m_cmbBarcodeMatrix.SetCurSel(subData.nMatrix);

	m_chkUseAperture.SetCheck(subData.bUseAperture);
	m_bUseAperture = subData.bUseAperture;
	

	m_chkUseBarcodeLineDrill.SetCheck(subData.bBarcodeLineDrill);
	m_bUseBarcodeLineDrill = subData.bBarcodeLineDrill;


	str.Format(_T("%.2f"), subData.dDrawStep);
	m_edtDrawStep.SetWindowText(str);

	str.Format(_T("%d"), subData.nDrawStepPeriod);
	m_edtDrawStepPeriod.SetWindowText(str);

	str.Format(_T("%d"), subData.nJumpStepPeriod);
	m_edtJumpStepPeriod.SetWindowText(str);



	str.Format(_T("%d"), subData.nLaserOnDelay);
	m_edtLaserOnDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nLaserOffDelay);
	m_edtLaserOffDelay.SetWindowText(str);


	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subData.nMask];

	if(!m_bGlobalParam)
	{
		if(nSubIndex == 0)
		{
			str.Format(_T("%.1f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0]);
			m_edtMinPower.SetWindowText(str);
			str.Format(_T("%.1f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);
			m_edtMaxPower.SetWindowText(str);


			//subTool.dMinPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0];
			//subTool.dMaxPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0];
		}
		str.Format(_T("%d"), gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subData.nMask]); // subData.nFrequency);
	}
	else
		str.Format(_T("%d"), subData.nFrequency);

	m_edtFrequency.SetWindowText(str);

	str.Format(_T("[%d] %s"),nShotIndex, gShotTableINI.m_sShotGroupTable.strInfoName[nShotIndex]);
	GetDlgItem(IDC_STATIC_SUB_SHOTGROUP_NO)->SetWindowText(str);

	str.Format(_T("%d"), subData.nTotalShot);
	m_edtTotalShot.SetWindowText(str);

	str.Format(_T("%d"), subData.nBurstShot);
	m_edtBurstShot.SetWindowText(str);


	str.Format(_T("%.2f"), gSystemINI.m_sSystemDevice.dJumpSpeed);
	m_edtJumpStep.SetWindowText(str);
	
	str.Format(_T("%d"), gSystemINI.m_sSystemDevice.nCornerDelay);
	m_edtCornerDelay.SetWindowText(str);
	
	str.Format(_T("%d"), gSystemINI.m_sSystemDevice.nJumpDelay);
	m_edtJumpDelay.SetWindowText(str);
	
	str.Format(_T("%d"), gSystemINI.m_sSystemDevice.nLineDelay);
	m_edtLineDelay.SetWindowText(str);

	if(strcmp(subData.cFilePath, "") !=0)
		m_strPath.Format(_T("%s"), (CString)subData.cFilePath);

	str = m_strPath.Mid(m_strPath.ReverseFind(_T('\\'))+1);
	if(m_strPath.GetLength() < 1)
		m_edtAperturePath.SetWindowText("");
	else
		m_edtAperturePath.SetWindowText(str);

	m_strMemo.Format(_T("%s"), (CString)subData.cToolMemo);
	if(m_strMemo.GetLength() < 1)
		m_edtMemo.SetWindowText("");
	else
		m_edtMemo.SetWindowText(m_strMemo);

	str.Format(_T("%d"), subData.nApertureBurst);
	m_edtApertureBurst.SetWindowText(str);

	str.Format(_T("%d"), subData.nMinShotTime);
	m_edtMinShotTime.SetWindowText(str);

	m_chkUseFlipX.SetCheck(subData.bFlipX);
	m_bUseFlipX = subData.bFlipX;

	m_chkUseFlipY.SetCheck(subData.bFlipY);
	m_bUseFlipY = subData.bFlipY;



//	str.Format(_T("%d"), subData.nLeadIn);
//	m_edtLeadIn.SetWindowText(str);

//	str.Format(_T("%d"), subData.nLeadOut);
//	m_edtLeadOut.SetWindowText(str);
	
// 	str.Format(_T("%d"), subData.nTableSpeed);
// 	m_edtTableSpeed.SetWindowText(str);

 	str.Format(_T("%d"), subData.nRotate);
 	m_edtRotate.SetWindowText(str);
	
//	str.Format(_T("%d"), subData.nFPS);
//	m_edtFPS.SetWindowText(str);

//	str.Format(_T("%.3f"), subData.dCurrent);
//	m_edtCurrent.SetWindowText(str);

//	str.Format(_T("%.3f"), subData.dA1);
//	m_edtA1.SetWindowText(str);

//	str.Format(_T("%.3f"), subData.dA2);
//	m_edtA2.SetWindowText(str);
	
//	str.Format(_T("%.2f"), subData.dHoleSize);
// 	m_edtHoleSize.SetWindowText(str);

// 	str.Format(_T("%d"), subData.nThermalTrack);
// 	m_edtThermalTrack.SetWindowText(str);

// 	str.Format(_T("%.3f"), subData.dZOffset);
// 	m_edtZOffset.SetWindowText(str);
	
//	str.Format(_T("%s"), (CString)subData.cMoveProfileFilePath);
//	m_edtScannerProfilePath.SetWindowText(str);



	UpdateData(FALSE);

	OnSelChangeComboToolType();
	OnCheckUseAperture();
}

BOOL CPaneRecipeGenParameterNew::ChangeDataMain(int nMainIndex)
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal < 0)
	{
		ErrMessage(_T("Tool Size > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return FALSE;
	}

	int nListIndex = GetUseToolIndex(nMainIndex);
	if(nListIndex == -1)
		return FALSE;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
/*		if(0 == str.CompareNoCase("S. Cal."))
			pToolCode->m_nToolNo = 0;
		else */
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}

	if(pToolCode->m_bUseTool != m_chkUseTool.GetCheck())
	{
		strTemp.Format(_T("| Use Tool = %d"), m_chkUseTool.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();

	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nToolSize != nTempVal)
	{
		strTemp.Format(_T("| Size = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nToolSize = nTempVal;

	if(pToolCode->m_bToolOrder != m_chkUseToolOrder.GetCheck())
	{
		strTemp.Format(_T("| ToolOrder = %d"), m_chkUseToolOrder.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	if(pToolCode->m_bPreworkPower != m_chkUsePrePower.GetCheck())
	{
		strTemp.Format(_T("| PrePower = %d"), m_chkUsePrePower.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bPreworkPower = m_chkUsePrePower.GetCheck();


	if(pToolCode->m_bPreworkScanner != m_chkUsePreScal.GetCheck())
	{
		strTemp.Format(_T("| PreScal = %d"), m_chkUsePreScal.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bPreworkScanner = m_chkUsePreScal.GetCheck();

	m_pToolCode[nListIndex] = pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
/*			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC is changed. "));
			else*/
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return TRUE;
}

void CPaneRecipeGenParameterNew::ChangeData(int nMainIndex, int nSubIndex)
{

	int nTempVal;
	double dTempVal;
	CString str, strInfo, strTemp, strMessage, strAOM1, strAOM2;
	strInfo.Format(_T(""));

	int nListIndex = GetUseToolIndex(nMainIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	if(i == -1) return;

	subData = pToolCode->m_SubToolData.GetAt(pos);

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		if(subData.dShotDuty[i] != m_dDuty[i])
		{
			strTemp.Format(_T("| %d duty = %.3f"), i, m_dDuty[i]);
			strInfo += strTemp;
		}
		subData.dShotDuty[i] = m_dDuty[i];

		if(subData.dShotAOMDelay[i] != m_dAOMDelay[i])
		{
			strTemp.Format(_T("| %d duty = %.3f"), i, m_dAOMDelay[i]);
			strInfo += strTemp;
		}
		subData.dShotAOMDelay[i] = m_dAOMDelay[i];

		if(subData.dShotAOMDuty[i] != m_dAOMDuty[i])
		{
			strTemp.Format(_T("| %d duty = %.3f"), i, m_dAOMDuty[i]);
			strInfo += strTemp;
		}
		subData.dShotAOMDuty[i] = m_dAOMDuty[i];

		if(subData.dShotMinFreq[i] != m_dMinFreq[i])
		{
			strTemp.Format(_T("| %d MinFreq = %.3f"), i, m_dMinFreq[i]);
			strInfo += strTemp;
		}
		subData.dShotMinFreq[i] = m_dMinFreq[i];

		if(subData.dShotMaxFreq[i] != m_dMaxFreq[i])
		{
			strTemp.Format(_T("| %d MinFreq = %.3f"), i, m_dMaxFreq[i]);
			strInfo += strTemp;
		}
		subData.dShotMaxFreq[i] = m_dMaxFreq[i];

		//
		if(subData.dShotDutyOffsetM[i] != m_dDutyOffsetM[i])
		{
			strTemp.Format(_T("| %d DutyOffsetM = %.3f"), i, m_dDutyOffsetM[i]);
			strInfo += strTemp;
		}
		subData.dShotDutyOffsetM[i] = m_dDutyOffsetM[i];

		if(subData.dShotDutyOffsetS[i] != m_dDutyOffsetS[i])
		{
			strTemp.Format(_T("| %d DutyOffsetS = %.3f"), i, m_dDutyOffsetS[i]);
			strInfo += strTemp;
		}
#ifndef __USEAOD__
		subData.dShotDutyOffsetS[i] = 0;
#else
		subData.dShotDutyOffsetS[i] = m_dDutyOffsetS[i];
#endif
		if(subData.dPowerMin[i] != m_dPowerMin[i])
		{
			strTemp.Format(_T("| %d Power Min = %.3f"), i, m_dPowerMin[i]);
			strInfo += strTemp;
		}
		subData.dPowerMin[i] = m_dPowerMin[i];

		if(subData.dPowerMax[i] != m_dPowerMax[i])
		{
			strTemp.Format(_T("| %d Power Max = %.3f"), i, m_dPowerMax[i]);
			strInfo += strTemp;
		}
		subData.dPowerMax[i] = m_dPowerMax[i];

		if(subData.dShotVolOffsetM[i] != m_dVolOffsetM[i])
		{
			strTemp.Format(_T("| %d VolOffsetM = %.3f"), i, m_dVolOffsetM[i]);
			strInfo += strTemp;
		}
#ifndef __USEAOD__
		subData.dShotVolOffsetM[i] = 0;
#else
		subData.dShotVolOffsetM[i] = m_dVolOffsetM[i];
#endif
		

		if(subData.dShotVolOffsetS[i] != m_dVolOffsetS[i])
		{
			strTemp.Format(_T("| %d VolOffsetS = %.3f"), i, m_dVolOffsetS[i]);
			strInfo += strTemp;
		}
#ifndef __USEAOD__
		subData.dShotVolOffsetS[i] = 0;
#else
		subData.dShotVolOffsetS[i] = m_dVolOffsetS[i];
#endif
		
		//
		strAOM1.Format(_T("%s"), subData.cAOMFilePath[i]);
		strAOM2.Format(_T("%s"), m_cAOMFilePath[i]);
		if(0 != strAOM1.CompareNoCase(strAOM2))
		{
			strTemp.Format(_T("| %d AOM file = %s"), i, m_cAOMFilePath[i]);
			strInfo += strTemp;
		}
		memcpy(subData.cAOMFilePath[i], m_cAOMFilePath[i], 255);
	}


	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
/*		if(0 == str.CompareNoCase("S. Cal."))
			pToolCode->m_nToolNo = 0;
		else */
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}

	str.Format(_T("Sub %d"), nSubIndex+1);
	m_edtSubTcode.SetWindowText(str);

	if(pToolCode->m_bUseTool != m_chkUseTool.GetCheck())
	{
		strTemp.Format(_T("| Use Tool = %d"), m_chkUseTool.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();


	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);

	if(pToolCode->m_nToolSize != nTempVal)
	{
		strTemp.Format(_T("| Size = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nToolSize = nTempVal;

	if(pToolCode->m_bToolOrder != m_chkUseToolOrder.GetCheck())
	{
		strTemp.Format(_T("| ToolOrder = %d"), m_chkUseToolOrder.GetCheck());
		strInfo += strTemp;
	}
	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	m_edtSubNo.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nSubToolNo = nTempVal;

	if(subData.nToolType != m_cmbToolType.GetCurSel())
	{
		strTemp.Format(_T("| SubType = %d"), m_cmbToolType.GetCurSel());
		strInfo += strTemp;
	}
	subData.nToolType = m_cmbToolType.GetCurSel();

	if(subData.nMask != m_cmbMask.GetCurSel())
	{
		strTemp.Format(_T("| SubMask = %d"), m_cmbMask.GetCurSel());
		strInfo += strTemp;
	}
	subData.nMask = m_cmbMask.GetCurSel();
	
	if(subData.bUseTophat != m_chkUseTophat.GetCheck())
	{
		strTemp.Format(_T("| SubUseTophat = %d"), m_chkUseAperture.GetCheck());
		strInfo += strTemp;
	}
	subData.bUseTophat = m_chkUseTophat.GetCheck();

	if(subData.nShotMode != m_cmbDrillMethod.GetCurSel())
	{
		strTemp.Format(_T("| SubShotMode = %d"), m_cmbDrillMethod.GetCurSel());
		strInfo += strTemp;
	}
	subData.nShotMode = m_cmbDrillMethod.GetCurSel();

	if(subData.nMatrix != m_cmbBarcodeMatrix.GetCurSel())
	{
		strTemp.Format(_T("| SubBarcodeMatrix = %d"), m_cmbBarcodeMatrix.GetCurSel());
		strInfo += strTemp;
	}
	subData.nMatrix = m_cmbBarcodeMatrix.GetCurSel();

	if(subData.bUseAperture != m_chkUseAperture.GetCheck())
	{
		strTemp.Format(_T("| SubUseAper = %d"), m_chkUseAperture.GetCheck());
		strInfo += strTemp;
	}
	subData.bUseAperture = m_chkUseAperture.GetCheck();

	if(subData.bBarcodeLineDrill != m_chkUseBarcodeLineDrill.GetCheck())
	{
		strTemp.Format(_T("| SubUseBarcodeLineDrill = %d"), m_chkUseBarcodeLineDrill.GetCheck());
		strInfo += strTemp;
	}
	subData.bBarcodeLineDrill = m_chkUseBarcodeLineDrill.GetCheck();

	if(subData.bFlipX != m_chkUseFlipX.GetCheck() || 
		subData.bFlipY != m_chkUseFlipY.GetCheck())
	{
		strTemp.Format(_T("| SubFlip = %d, %d"), m_chkUseFlipX.GetCheck(), m_chkUseFlipY.GetCheck());
		strInfo += strTemp;
	}
	subData.bFlipX = m_chkUseFlipX.GetCheck();
	subData.bFlipY = m_chkUseFlipY.GetCheck();

	m_edtDrawStep.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.dDrawStep != nTempVal)
	{
		strTemp.Format(_T("| SubDS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.dDrawStep = nTempVal;

	m_edtJumpStep.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nJumpStep != nTempVal)
	{
		strTemp.Format(_T("| SubJS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nJumpStep = nTempVal;

	m_edtDrawStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nDrawStepPeriod != nTempVal)
	{
		strTemp.Format(_T("| SubDSP = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nDrawStepPeriod = nTempVal;

	m_edtJumpStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nJumpStepPeriod != nTempVal)
	{
		strTemp.Format(_T("| SubJSP = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nJumpStepPeriod = nTempVal;

	m_edtCornerDelay.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nCornerDelay != nTempVal)
	{
		strTemp.Format(_T("| SubCD = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nCornerDelay = nTempVal;

	m_edtJumpDelay.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nJumpDelay != nTempVal)
	{
		strTemp.Format(_T("| SubJD = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nJumpDelay = nTempVal;

	m_edtLineDelay.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nLineDelay != nTempVal)
	{
		strTemp.Format(_T("| SubLD = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nLineDelay = nTempVal;

	m_edtLaserOnDelay.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nLaserOnDelay != nTempVal)
	{
		strTemp.Format(_T("| SubLOD = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nLaserOnDelay = nTempVal;

	m_edtLaserOffDelay.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nLaserOffDelay != nTempVal)
	{
		strTemp.Format(_T("| SubLOFFD = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nLaserOffDelay = nTempVal;

	m_edtFrequency.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nFrequency != nTempVal)
	{
		strTemp.Format(_T("| SubFreq = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nFrequency = nTempVal;

	m_edtFPS.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nFPS != nTempVal)
	{
		strTemp.Format(_T("| SubFPS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nFPS = nTempVal;

	m_edtCurrent.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dCurrent != dTempVal)
	{
		strTemp.Format(_T("| SubCurr = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dCurrent = dTempVal;

	m_edtA1.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dA1 != dTempVal)
	{
		strTemp.Format(_T("| SubA1 = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dA1 = dTempVal;

	m_edtA2.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dA2 != dTempVal)
	{
		strTemp.Format(_T("| SubA2 = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dA2 = dTempVal;

	m_edtTotalShot.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nTotalShot != nTempVal)
	{
		strTemp.Format(_T("| SubTS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nTotalShot = nTempVal;

	m_edtBurstShot.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nBurstShot != nTempVal)
	{
		strTemp.Format(_T("| SubBS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nBurstShot = nTempVal;

	m_edtLeadIn.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nLeadIn != nTempVal)
	{
		strTemp.Format(_T("| SubLIn = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nLeadIn = nTempVal;

	m_edtLeadOut.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nLeadOut != nTempVal)
	{
		strTemp.Format(_T("| SubLOut = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nLeadOut = nTempVal;

	m_edtTableSpeed.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nTableSpeed != nTempVal)
	{
		strTemp.Format(_T("| SubTS = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nTableSpeed = nTempVal;

	m_edtRotate.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nRotate != nTempVal)
	{
		strTemp.Format(_T("| SubRotate = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nRotate = nTempVal;

//	m_edtAperturePath.GetWindowText(str);
	strTemp.Format(_T("%s"), subData.cFilePath);
	if(0 != strTemp.CompareNoCase(m_strPath))
	{
		strTemp.Format(_T("| SubPath = %s"), m_strPath);
		strInfo += strTemp;
	}
	strcpy_s(subData.cFilePath, m_strPath);

	GetDlgItem(IDC_EDIT_SUB_MEMO)->GetWindowText(m_strMemo);
	strTemp.Format(_T("%s"), subData.cToolMemo);
	if(0 != strTemp.CompareNoCase(m_strMemo))
	{
		strTemp.Format(_T("| Memo = %s"), m_strMemo);
		strInfo += strTemp;
	}
	strcpy_s(subData.cToolMemo, m_strMemo);

//	m_edtScannerProfilePath.GetWindowText(str);
//	strcpy_s(subData.cMoveProfileFilePath, str);

	m_edtApertureBurst.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nApertureBurst != nTempVal)
	{
		strTemp.Format(_T("| SubAB = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nApertureBurst = nTempVal;


	m_edtMinShotTime.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nMinShotTime != nTempVal)
	{
		strTemp.Format(_T("| SubMST = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nMinShotTime = nTempVal;

	m_edtThermalTrack.GetWindowText(str);
	nTempVal = atoi(str);
	if(subData.nThermalTrack != nTempVal)
	{
		strTemp.Format(_T("| SubTT = %d"), nTempVal);
		strInfo += strTemp;
	}
	subData.nThermalTrack = nTempVal;

	m_edtZOffset.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dZOffset != dTempVal)
	{
		strTemp.Format(_T("| SubZOff = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dZOffset = dTempVal;

	m_edtMinPower.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dMinPower != dTempVal)
	{
		strTemp.Format(_T("| MinPower = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dMinPower = dTempVal;

	m_edtMaxPower.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dMaxPower != dTempVal)
	{
		strTemp.Format(_T("| MaxPower = %.3f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dMaxPower = dTempVal;

	m_edtHoleSize.GetWindowText(str);
	dTempVal = atof(str);
	if(subData.dHoleSize != dTempVal)
	{
		strTemp.Format(_T("| HoleSize = %.2f"), dTempVal);
		strInfo += strTemp;
	}
	subData.dHoleSize = dTempVal;

	if(!CheckSubTool(subData, nMainIndex))
		return;

	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
/*			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC %d is changed. "), subData.nSubToolNo);
			else */
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. %d is changed. "), subData.nSubToolNo);
			else
				strMessage.Format(_T("PowerMeasurement Param. %d is changed. "), subData.nSubToolNo);
		}
		else
		{
			strMessage.Format(_T("Tool %d (sub : %d) is changed. "), nListIndex, subData.nSubToolNo);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	
}

void CPaneRecipeGenParameterNew::UpdateList(int nMainIndex, int nSubIndex)
{
	m_ctrTreeTool.DeleteAllItems( );
	int nMainCount = -1, nSubCnt, nToolCnt = 0;
	CString strText;
	HTREEITEM hRoot, hSubItem;
	m_nToolIndex = nMainIndex;
	m_nSubIndex = nSubIndex;

	BOOL bAllShow = m_chkAllShowTool.GetCheck();
	BOOL bSkiving = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SkivingCheck();
	
	if(!m_bGlobalParam)
	{
		if(bSkiving)
		{
			m_pToolCode[0]->m_bUseTool = TRUE;
		}
		else
			m_pToolCode[0]->m_bUseTool = FALSE;
	}
	BOOL bMainAdd = FALSE, bSubAdd = FALSE;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
//		if(!m_pToolCode[i]->m_bUseTool && !bAllShow)
		if(!m_pToolCode[i]->m_bUseTool && !bAllShow/* && pos == NULL*/)
			continue;

		nMainCount++;
		if(m_bGlobalParam)
		{
/*				if(nToolCnt == 0)
				strText.Format(_T("S. Cal."));
			else */
			if(nToolCnt == 0)
				strText.Format(_T("One Hole"));
			else
				strText.Format(_T("Power"));
		}
		else
			strText.Format(_T("Tool %d"), i);

		bMainAdd = TRUE;
		hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
		if (hRoot != NULL)
		{
		   m_ctrTreeTool.SetItemData(hRoot, nMainCount * 100);
		}
		nSubCnt = 1;
		pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			m_pToolCode[i]->m_SubToolData.GetNext(pos);
			strText.Format(_T("SubTool %d"), nSubCnt);
			hSubItem = m_ctrTreeTool.InsertItem(strText, 0, 1, hRoot);
			if (hSubItem != NULL)
			{
				m_ctrTreeTool.SetItemData(hSubItem, nMainCount * 100 + nSubCnt);
			}
			bSubAdd = TRUE;
			nSubCnt++;
		}
		nToolCnt++;
		m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);
	}

	if(m_nToolIndex != -1)
	{
		int nVal, nItemVal;
		if(m_nSubIndex != -1)
		{
			nVal = m_nToolIndex * 100 + m_nSubIndex + 1;
		}
		else
		{
			nVal = m_nToolIndex * 100;
		}

		HTREEITEM hCurrent = m_ctrTreeTool.GetFirstVisibleItem();//(TVI_ROOT, TVGN_NEXT);
		while (hCurrent != NULL)
		{
		   nItemVal = m_ctrTreeTool.GetItemData(hCurrent);
		   if(nItemVal == nVal)
		   {
				m_ctrTreeTool.SelectItem(hCurrent);
				break;
		   }
		   // Try to get the next item
		   hCurrent = m_ctrTreeTool.GetNextVisibleItem(hCurrent);//, TVGN_NEXT);
		}

	}

}

void CPaneRecipeGenParameterNew::OnClickListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CPaneRecipeGenParameterNew::OnClickListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CPaneRecipeGenParameterNew::OnSelChangeComboColor() 
{
	// TODO: Add your control notification handler code here
	ChangeDataMain(m_nToolIndex);
}

void CPaneRecipeGenParameterNew::OnSelChangeComboDrillMethod() 
{
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.nShotMode =  m_cmbDrillMethod.GetCurSel();
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	int nMode = subData.nShotMode;//m_cmbDrillMethod.GetCurSel();
	if(nMode < 2)
	{
		if(nMode == 0)
		{
			CString str;
			m_edtTotalShot.GetWindowText(str);
			m_edtBurstShot.SetWindowText(str);
		}
		else
		{
			m_edtBurstShot.SetWindowText("0");
		}
	}
	else
	{
		if(!m_bUseTool)
			return;
	}

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
	
}

void CPaneRecipeGenParameterNew::OnSelChangeComboToolType() 
{
	// TODO: Add your control notification handler code here

#ifdef __KUNSAN_8__
	GetDlgItem(IDC_STATIC_SUB_MINSHOTTIME)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_EDIT_SUB_MINSHOTTIME)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_M9)->ShowWindow(SW_SHOW);
#endif
	int nType = m_cmbToolType.GetCurSel();

//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.nToolType = nType;
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;


	GetDlgItem(IDC_EDIT_SUB_TCODE_NO)->EnableWindow(FALSE);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_SUB_MASK )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_A1 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_A2 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_A1 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_A2 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_STATIC_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_MASK_NO )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(FALSE);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_SUB_MASK )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_A1 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_A2 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_A1 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_A2 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_STATIC_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_MASK_NO )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(FALSE);
		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(TRUE);
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType != LASER_IPGPULSE)
		{
			GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(FALSE);
			GetDlgItem( IDC_STATIC_SUB_CURRENT )->EnableWindow(FALSE);
		}
		
		GetDlgItem( IDC_COMBO_SUB_MASK )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_A1 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_A2 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_A1 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_A2 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(FALSE);
				
		GetDlgItem( IDC_STATIC_SUB_MASK_NO )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_THERMAL_TRACK )->EnableWindow(FALSE);
		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_SHOTGROUP )->ShowWindow(SW_SHOW);
		
	}

//////////////// tool type 
	if(nType == BARCODE_TYPE|| nType == TEXT_TYPE)
	{
		GetDlgItem( IDC_STATIC_SUB_ROTATE )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_ROTATE )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_DEG )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_CHECK_SUB_X_FLIP )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_CHECK_SUB_Y_FLIP )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STC_2DBAR )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_TEXT_HOLE_PITCH )->EnableWindow(TRUE);
	
	}
	else
	{
		GetDlgItem( IDC_STATIC_SUB_ROTATE )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_ROTATE )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_DEG )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_CHECK_SUB_X_FLIP )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_CHECK_SUB_Y_FLIP )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STC_2DBAR )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_TEXT_HOLE_PITCH )->EnableWindow(FALSE);
		m_chkUseFlipX.SetCheck(FALSE);
		m_chkUseFlipY.SetCheck(FALSE);
	}

	if(nType == FLYING_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_MM1 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_MM2 )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_MMS )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->ShowWindow(SW_SHOW);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->ShowWindow(SW_SHOW);
	}
	else
	{
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_MM1 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_MM2 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_MMS )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->ShowWindow(SW_HIDE);
	}

	if(nType == MARKING_TYPE)
	{
		GetDlgItem(IDC_STATIC_SUB_LASER_ON_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_LASER_OFF_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_DRAW_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_JUMP_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_CORNER_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_JUMP_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_LINE_DELAY)->ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_EDIT_SUB_LASER_ON_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_LASER_OFF_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_DRAW_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_JUMP_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_CORNER_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_JUMP_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_LINE_DELAY)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_EDIT_SUB_JUMP_STEP)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_CORNER_DELAY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_JUMP_DELAY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_LINE_DELAY)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M8)->ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_STATIC_SUB_MINSHOTTIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_MINSHOTTIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_SUB_DRILL_METHOD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_TOTAL_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMBO_SUB_DRILL_METHOD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_TOTAL_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_BURST_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_SHOT_SETTING)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_SUB_USE_APERTURE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);

/*		if(m_bConnectVision && !m_bGlobalParam)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_HIDE);
		}
*/
	}
	else if(nType == SHOT_DRILL_TYPE  || nType == TEXT_TYPE)
	{
		int sel = m_nToolIndex;
		GetDlgItem(IDC_STATIC_SUB_LASER_ON_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_LASER_OFF_DELAY)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_DRAW_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_JUMP_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_CORNER_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_JUMP_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_LINE_DELAY)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_EDIT_SUB_LASER_ON_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_LASER_OFF_DELAY)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_EDIT_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_DRAW_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_JUMP_STEP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_CORNER_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_JUMP_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_LINE_DELAY)->ShowWindow(SW_HIDE);
		if(!gProcessINI.m_sProcessSystem.nNoSortHole)
			GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_STATIC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M8)->ShowWindow(SW_HIDE);


		GetDlgItem(IDC_STATIC_SUB_DRILL_METHOD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_TOTAL_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMBO_SUB_DRILL_METHOD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_TOTAL_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_BURST_SHOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_SHOT_SETTING)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_FREQUENCY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_SUB_USE_APERTURE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);


		




/*		if(m_bConnectVision && !m_bGlobalParam)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);

			GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_SHOW);
		}
*/
/*if( nType == TEXT_TYPE)
		{
			GetDlgItem( IDC_STATIC_LOT_ID )->EnableWindow(TRUE);
			GetDlgItem( IDC_STATIC_HEIGHT )->EnableWindow(TRUE);
			GetDlgItem( IDC_EDIT_LOT_ID )->EnableWindow(TRUE);
			GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem( IDC_STATIC_LOT_ID )->EnableWindow(FALSE);
			GetDlgItem( IDC_STATIC_HEIGHT )->EnableWindow(FALSE);
			GetDlgItem( IDC_EDIT_LOT_ID )->EnableWindow(FALSE);
			GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(FALSE);
		}
*/
	}
	else if(nType == LINE_DRILL_TYPE || nType == BARCODE_TYPE)
	{
		if(gSystemINI.m_sSystemDevice.nSelfLineDivide)
		{
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(TRUE);
			GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(FALSE);
			GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(FALSE);
		}
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		if(m_bGlobalParam)
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(FALSE);

		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(FALSE);
//		m_edtTotalShot.SetWindowText("1");
//		m_edtBurstShot.SetWindowText("1");
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(TRUE);
//		m_chkUseAperture.SetCheck(TRUE);
//		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(TRUE);
//		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
//		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(FALSE);
//		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);
		if(!gProcessINI.m_sProcessSystem.nNoSortHole)
			GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_SHOW);

/*		if(m_bConnectVision && !m_bGlobalParam)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_HIDE);
		}
*/		
// 		GetDlgItem( IDC_STATIC_LOT_ID )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_STATIC_HEIGHT )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_EDIT_LOT_ID )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(FALSE);
	}
	else //  if(nMode = FLYING_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		if(m_bGlobalParam)
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(FALSE);

		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(FALSE);
//		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(FALSE);
//		m_edtTotalShot.SetWindowText("1");
//		m_edtBurstShot.SetWindowText("1");
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(TRUE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(FALSE);
		m_chkUseAperture.SetCheck(FALSE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);

/*		if(m_bConnectVision && !m_bGlobalParam)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_HIDE);
		}
*/		
// 		GetDlgItem( IDC_STATIC_LOT_ID )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_STATIC_HEIGHT )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_EDIT_LOT_ID )->EnableWindow(FALSE);
// 		GetDlgItem( IDC_EDIT_FONT_SIZE )->EnableWindow(FALSE);
	}

//	OnSelChangeComboDrillMethod();
	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::OnSelChangeComboMask() 
{
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.nMask = m_cmbMask.GetCurSel();

	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subData.nMask];

	subData.nToolType = gShotTableINI.m_sShotGroupTable.nToolType[nShotIndex];
	m_cmbToolType.SetCurSel(subData.nToolType);

	if(!m_bGlobalParam)
	{
		if(i == 0)
		{
			str.Format(_T("%.1f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0]);
			m_edtMinPower.SetWindowText(str);
			str.Format(_T("%.1f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0]);
			m_edtMaxPower.SetWindowText(str);
		}
		str.Format(_T("%d"), gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subData.nMask]); // subData.nFrequency);
		
		subData.dPowerMin[0] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[subData.nMask];
		subData.dPowerMax[0] = gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[subData.nMask];
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (OnSelChangeComboMask) : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	else
		str.Format(_T("%d"), subData.nFrequency);

	m_edtFrequency.SetWindowText(str);
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}

	str.Format(_T("[%d] %s"),nShotIndex, gShotTableINI.m_sShotGroupTable.strInfoName[nShotIndex]);
	GetDlgItem(IDC_STATIC_SUB_SHOTGROUP_NO)->SetWindowText(str);

	OnSelChangeComboToolType();
}

void CPaneRecipeGenParameterNew::OnButtonSetting() 
{
	int sel = m_nToolIndex;
	if(-1 == sel) 
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int selSub = m_nSubIndex;
	if(-1 == selSub) 
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}
	
	int nShotCount = 0;
	
	nShotCount = GetDlgItemInt( IDC_EDIT_SUB_TOTAL_SHOT );
	
	if( nShotCount <= 0 || nShotCount > 15)
	{
		ErrMessage(IDS_SHOT_COUNT_INPUT_ERR, MB_ICONERROR);
		
		m_ctrTreeTool.SetFocus();
		return;
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;

	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
		
	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;

		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}
	
	if(pos)
		subData = pToolCode->m_SubToolData.GetAt(pos);
	else
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}
	
	for(int i = 0; i<MAX_BEAM_HOLE; i++)
	{
		if( i < subData.nTotalShot)
			m_dDuty[i] = subData.dShotDuty[i];
		else
			m_dDuty[i] = 0;

		m_dAOMDelay[i] = subData.dShotAOMDelay[i];
		m_dAOMDuty[i] = subData.dShotAOMDuty[i];

		if (subData.dShotMinFreq[i] == INT_MAX)	
		{
			if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
			{
				m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq;
			}
			else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			{
				m_dMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMinFreq2;
			}

		}
		else
			m_dMinFreq[i] = subData.dShotMinFreq[i];

		if (subData.dShotMaxFreq[i] == INT_MAX)
		{
			if (gDProject.m_nDummyFreeType == DUMMY_FREE_1)
			{
				m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;
			}
			else if (gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			{
				m_dMaxFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
			}
		}
		else
			m_dMaxFreq[i] = subData.dShotMaxFreq[i];		

		memcpy(m_cAOMFilePath[i], subData.cAOMFilePath[i], 255);

		m_dDutyOffsetM[i] = subData.dShotDutyOffsetM[i];

		m_dPowerMin[i] = subData.dPowerMin[i];
		m_dPowerMax[i] = subData.dPowerMax[i];
#ifndef __USEAOD__
		m_dDutyOffsetS[i] = 0;
		m_dVolOffsetM[i] = 0;
		m_dVolOffsetS[i] = 0;
#else
		m_dDutyOffsetS[i] = subData.dShotDutyOffsetS[i];
		m_dVolOffsetM[i] = subData.dShotVolOffsetM[i];
		m_dVolOffsetS[i] = subData.dShotVolOffsetS[i];
#endif
	}

	if(!m_bGlobalParam)
	{
		m_dDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[subData.nMask];
		m_dAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[subData.nMask];
		m_dAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[subData.nMask];
		memcpy(m_cAOMFilePath[0], subData.cAOMFilePath[0], 255);

//		m_dDutyOffsetM[0] = 0;
//		m_dDutyOffsetS[0] = 0;
//		m_dVolOffsetM[0] = 0;
//		m_dVolOffsetS[0] = 0;
		m_dPowerMin[0] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[subData.nMask];
		m_dPowerMax[0] = gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[subData.nMask];
	}
	
	CDlgLaserBeamHoleSet dlg;

	dlg.SetFireHole( nShotCount, m_dDuty, m_dAOMDelay, m_dAOMDuty, m_dMinFreq, m_dMaxFreq, &m_cAOMFilePath[0], m_dDutyOffsetM, m_dDutyOffsetS, m_dVolOffsetM, m_dVolOffsetS, m_bGlobalParam, m_dPowerMin, m_dPowerMax);
	dlg.SetUserLevel(m_nUserLevel);
	if(IDOK != dlg.DoModal())
	{
		m_ctrTreeTool.SetFocus();
		return;
	}
	
	dlg.GetFireHole(m_dDuty, m_dAOMDelay, m_dAOMDuty, m_dMinFreq, m_dMaxFreq, &m_cAOMFilePath[0], m_dDutyOffsetM, m_dDutyOffsetS, m_dVolOffsetM, m_dVolOffsetS, m_dPowerMin, m_dPowerMax);
	
	m_ctrTreeTool.SetFocus();
	
	for(int ej = 0; ej < MAX_BEAM_HOLE; ej++)
	{
		if(!m_bGlobalParam)
		{
			if(ej == 0 )
			{
				if(subData.dShotDuty[0] != m_dDuty[0] || subData.dShotAOMDelay[0] != m_dAOMDelay[0] || subData.dShotAOMDuty[0] != m_dAOMDuty[0])
				{
					::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
					CString strFile, strLog;
					strFile.Format(_T("PreWork"));
					strLog.Format(_T("AnyDo (OnButtonSetting) : P"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}	
		}
		subData.dShotDuty[ej] = m_dDuty[ej] ;
		subData.dShotAOMDelay[ej] = m_dAOMDelay[ej];
		subData.dShotAOMDuty[ej] = m_dAOMDuty[ej];
		subData.dShotMinFreq[ej] = m_dMinFreq[ej];
		subData.dShotMaxFreq[ej] = m_dMaxFreq[ej];
		memcpy(subData.cAOMFilePath[ej], m_cAOMFilePath[ej], 255);

		subData.dShotDutyOffsetM[ej] = m_dDutyOffsetM[ej];

		subData.dPowerMin[ej] = m_dPowerMin[ej];
		subData.dPowerMax[ej] = m_dPowerMax[ej];
#ifndef __USEAOD__
		subData.dShotDutyOffsetS[ej] = 0;
		subData.dShotVolOffsetM[ej] = 0;
		subData.dShotVolOffsetS[ej] = 0;
#else
		subData.dShotDutyOffsetS[ej] = m_dDutyOffsetS[ej];
		subData.dShotVolOffsetM[ej] = m_dVolOffsetM[ej];
		subData.dShotVolOffsetS[ej] = m_dVolOffsetS[ej];
#endif
	}

	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}

//	OnButtonParamUpdate();
}

void CPaneRecipeGenParameterNew::OnButtonApertureOpen()
{
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int selSub = m_nSubIndex;
	if(-1 == selSub)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}

	TCHAR BASED_CODE szFilter[] = _T("APL File (*.apl)|*.apl|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.apl"), NULL, dwFlags, szFilter);

	CString strPath;
	int nLength = m_strPath.GetLength();
	int nIndex;
	if(nLength > 0)
	{
		nIndex = m_strPath.ReverseFind(_T('\\'));
		strPath = m_strPath.Left(nIndex);
	}
	else
		strPath = gEasyDrillerINI.m_clsDirPath.GetApertureDir();

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;
	
	if(IDOK != dlg.DoModal())
	{
		m_ctrTreeTool.SetFocus();
		return;
	}
	
	m_strPath.Format(_T("%s"), dlg.GetPathName());

//	strPath = m_strPath.Mid(m_strPath.ReverseFind(_T('\\'))+1);
	if(m_strPath.GetLength() < 1)
		m_edtAperturePath.SetWindowText( "" );
	else
		m_edtAperturePath.SetWindowText( (LPCTSTR)m_strPath );

	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	_stprintf_s(subData.cFilePath, m_strPath);
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}

//	OnButtonParamUpdate();
}

void CPaneRecipeGenParameterNew::OnButtonSubProfileOpen() 
{
	// TODO: Add your control notification handler code here
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}
	
	int selSub = m_nSubIndex;
	if(-1 == selSub)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}
	
	TCHAR BASED_CODE szFilter[] = _T("PRO File (*.pro)|*.pro|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.pro"), NULL, dwFlags, szFilter);
	
	if(IDOK != dlg.DoModal())
	{
		m_ctrTreeTool.SetFocus();
		return;
	}
	
	CString strPath;
	strPath.Format(_T("%s"), dlg.GetPathName());
	m_edtScannerProfilePath.SetWindowText( (LPCTSTR)strPath );
}

void CPaneRecipeGenParameterNew::OnButtonParamAdd() 
{
	int sel = m_nToolIndex;
	BOOL bAllShow = m_chkAllShowTool.GetCheck();
	if(-1 == sel && !bAllShow)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int nTempVal;
	double dTempVal;
	CString str, strMessage, strInfo, strTemp;

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int nCount = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{ 
		subData = pToolCode->m_SubToolData.GetNext(pos);
		nCount++;
	}

	if(gProcessINI.m_sProcessSystem.bUseOpenTool)
	{
		if(nCount > 0 && subData.nToolType == SHOT_DRILL_TYPE)
		{
			ErrMessage(_T("use 1 sub tool"));
			return;
		}
	}

	memset(&subData, 0, sizeof(subData));

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		subData.dShotDuty[i] = m_dDuty[i];
		subData.dShotAOMDelay[i] = m_dAOMDelay[i];
		subData.dShotAOMDuty[i] = m_dAOMDuty[i];
		subData.dShotMinFreq[i] = m_dMinFreq[i];
		subData.dShotMaxFreq[i] = m_dMaxFreq[i];
		memcpy(subData.cAOMFilePath[i], m_cAOMFilePath[i], 255);

		subData.dShotDutyOffsetM[i] = m_dDutyOffsetM[i];

		if(i == 0)
		{
			subData.dPowerMin[i] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[subData.nMask];
			subData.dPowerMax[i] = gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[subData.nMask];
		}
		else
		{
			subData.dPowerMin[i] = m_dPowerMin[i];
			subData.dPowerMax[i] = m_dPowerMax[i];
		}
		
#ifndef __USEAOD__
		subData.dShotDutyOffsetS[i] = 0;
		subData.dShotVolOffsetM[i] = 0;
		subData.dShotVolOffsetS[i] = 0;
#else
		subData.dShotDutyOffsetS[i] = m_dDutyOffsetS[i];
		subData.dShotVolOffsetM[i] = m_dVolOffsetM[i];
		subData.dShotVolOffsetS[i] = m_dVolOffsetS[i];
#endif
	}

//	m_edtMainTcode.GetWindowText(str);
//	nTempVal = atoi(str);
//	pToolCode->m_nToolNo = nTempVal;
	
//	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();
	
//	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();
	
//	m_edtToolSize.GetWindowText(str);
//	nTempVal = atoi(str);
//	pToolCode->m_nToolSize = nTempVal;
	
//	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	subData.nSubToolNo = nCount+1;
	str.Format(_T("%d"),subData.nSubToolNo);
	m_edtSubNo.SetWindowText(str);

	subData.nToolType = m_cmbToolType.GetCurSel();

	subData.nMask = m_cmbMask.GetCurSel();
	
 	subData.nShotMode = m_cmbDrillMethod.GetCurSel();
	
	subData.bUseAperture = m_chkUseAperture.GetCheck();

	subData.bBarcodeLineDrill = m_chkUseBarcodeLineDrill.GetCheck();

	subData.bFlipX = m_chkUseFlipX.GetCheck();
	subData.bFlipY = m_chkUseFlipY.GetCheck();

	m_edtDrawStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.dDrawStep = nTempVal;

	m_edtJumpStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStep = nTempVal;

	m_edtDrawStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nDrawStepPeriod = nTempVal;

	m_edtJumpStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStepPeriod = nTempVal;

	m_edtCornerDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nCornerDelay = nTempVal;

	m_edtJumpDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpDelay = nTempVal;

	m_edtLineDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLineDelay = nTempVal;

	m_edtLaserOnDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOnDelay = nTempVal;

	m_edtLaserOffDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOffDelay = nTempVal;

	m_edtFrequency.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFrequency = nTempVal;

	m_edtFPS.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFPS = nTempVal;

	m_edtCurrent.GetWindowText(str);
	dTempVal = atof(str);
	subData.dCurrent = dTempVal;

	m_edtA1.GetWindowText(str);
	dTempVal = atof(str);
	subData.dA1 = dTempVal;
	
	m_edtA2.GetWindowText(str);
	dTempVal = atof(str);
	subData.dA2 = dTempVal;

	m_edtTotalShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTotalShot = nTempVal;

	m_edtBurstShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nBurstShot = nTempVal;

	m_edtLeadIn.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadIn = nTempVal;

	m_edtLeadOut.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadOut = nTempVal;

	m_edtTableSpeed.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTableSpeed = nTempVal;

	m_edtRotate.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nRotate = nTempVal;
#ifndef __NANYA__
	if(subData.nToolType == TEXT_TYPE)
	{
		subData.nRotate = 270;
		m_edtRotate.SetWindowText(_T("270"));
	}
	else
	{
		subData.nRotate = 0;
		m_edtRotate.SetWindowText(_T("0"));
	}
#endif

//	m_edtAperturePath.GetWindowText(str);
	strcpy_s(subData.cFilePath, m_strPath);

	strcpy_s(subData.cToolMemo, m_strMemo);

//	m_edtScannerProfilePath.GetWindowText(str);
//	strcpy_s(subData.cMoveProfileFilePath, str);

	m_edtApertureBurst.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nApertureBurst = nTempVal;

	m_edtMinShotTime.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nMinShotTime = nTempVal;

	m_edtThermalTrack.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nThermalTrack = nTempVal;

	m_edtZOffset.GetWindowText(str);
	dTempVal = atof(str);
	subData.dZOffset = dTempVal;

	m_edtMinPower.GetWindowText(str);
	dTempVal = atof(str);
	subData.dMinPower = dTempVal;

	m_edtMaxPower.GetWindowText(str);
	dTempVal = atof(str);
	subData.dMaxPower = dTempVal;

	m_edtHoleSize.GetWindowText(str);
	dTempVal = atof(str);
	subData.dHoleSize = dTempVal;

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		strTemp.Format(_T("| %d duty = %.3f"), i, subData.dShotDuty[i]);
		strInfo += strTemp;
		if(gSystemINI.m_sHardWare.nAOMType != 0)
		{
			strTemp.Format(_T("| %d AOM delay = %.3f"), i, subData.dShotAOMDelay[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d AOM duty = %.3f"), i, subData.dShotAOMDuty[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d AOM file = %s"), i, subData.cAOMFilePath[i]);
			strInfo += strTemp;
			
			strTemp.Format(_T("| %d DutyOffsetM = %.3f"), i, subData.dShotDutyOffsetM[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d DutyOffsetS = %.3f"), i, subData.dShotDutyOffsetS[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d VolOffsetM = %.3f"), i, subData.dShotVolOffsetM[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d VolOffsetS = %.3f"), i, subData.dShotVolOffsetS[i]);
			strInfo += strTemp;
		}
		strTemp.Format(_T("| %d MinFreq = %.3f"), i, subData.dShotMinFreq[i]);
		strInfo += strTemp;
		strTemp.Format(_T("| %d MaxFreq = %.3f"), i, subData.dShotMaxFreq[i]);
		strInfo += strTemp;		

		strTemp.Format(_T("| %d Power Min = %.3f"), i, subData.dPowerMin[i]);
		strInfo += strTemp;	
		strTemp.Format(_T("| %d Power Max = %.3f"), i, subData.dPowerMax[i]);
		strInfo += strTemp;	
	}
	strTemp.Format(_T("| SubType = %d"), subData.nToolType);
	strInfo += strTemp;
	strTemp.Format(_T("| SubMask = %d"), subData.nMask);
	strInfo += strTemp;
	strTemp.Format(_T("| SubShotMode = %d"), subData.nShotMode);
	strInfo += strTemp;
	strTemp.Format(_T("| SubUseAper = %d"), subData.bUseAperture);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFlip = %d, %d"), subData.bFlipX, subData.bFlipY);
	strInfo += strTemp;
	strTemp.Format(_T("| SubDS = %d"), subData.dDrawStep);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJS = %d"), subData.nJumpStep);
	strInfo += strTemp;
	strTemp.Format(_T("| SubDSP = %d"), subData.nDrawStepPeriod);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJSP = %d"), subData.nJumpStepPeriod);
	strInfo += strTemp;
	strTemp.Format(_T("| SubCD = %d"), subData.nCornerDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJD = %d"), subData.nJumpDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLD = %d"), subData.nLineDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOD = %d"), subData.nLaserOnDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOFFD = %d"), subData.nLaserOffDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFreq = %d"), subData.nFrequency);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFPS = %d"), subData.nFPS);
	strInfo += strTemp;
	strTemp.Format(_T("| SubCurr = %.3f"), subData.dCurrent);
	strInfo += strTemp;
	strTemp.Format(_T("| SubA1 = %.3f"), subData.dA1);
	strInfo += strTemp;
	strTemp.Format(_T("| SubA2 = %.3f"), subData.dA2);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTS = %d"), subData.nTotalShot);
	strInfo += strTemp;
	strTemp.Format(_T("| SubBS = %d"), subData.nBurstShot);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLIn = %d"), subData.nLeadIn);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOut = %d"), subData.nLeadOut);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTS = %d"), subData.nTableSpeed);
	strInfo += strTemp;
	strTemp.Format(_T("| SubRotate = %d"), subData.nRotate);
	strInfo += strTemp;
	strTemp.Format(_T("| SubPath = %s"), subData.cFilePath);
	strInfo += strTemp;
	strTemp.Format(_T("| SubAB = %d"), subData.nApertureBurst);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTT = %d"), subData.nThermalTrack);
	strInfo += strTemp;
	strTemp.Format(_T("| SubZOff = %.3f"), subData.dZOffset);
	strInfo += strTemp;
	strTemp.Format(_T("| Memo = %s"), subData.cToolMemo);
	strInfo += strTemp;
	strTemp.Format(_T("| MinPower = %.3f"), subData.dMinPower);
	strInfo += strTemp;
	strTemp.Format(_T("| MaxPower = %.3f"), subData.dMaxPower);
	strInfo += strTemp;
	strTemp.Format(_T("| HoleSize = %.2f"), subData.dHoleSize);
	strInfo += strTemp;

	if(!m_bGlobalParam)
		SetFirstSubShot(subData);

	pToolCode->m_SubToolData.AddTail(subData);

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
/*		if(sel == 0)
			strMessage.Format(_T("AGC %d Added. "), subData.nSubToolNo);
		else */
		if(sel == 0)
			strMessage.Format(_T("One Hole Param. %d Added. "), subData.nSubToolNo);
		else
			strMessage.Format(_T("PowerMeasurement Param. %d Added. "), subData.nSubToolNo);
	}
	else
	{
		strMessage.Format(_T("Tool %d (sub : %d) Added. "), nListIndex, subData.nSubToolNo);
	}
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));

	UpdateList(m_nToolIndex, nCount);
	m_ctrTreeTool.SetFocus();
}

void CPaneRecipeGenParameterNew::OnButtonParamDelete() 
{
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}

	if(i == 0)
		return;

	int selSub = m_nSubIndex;
	if(-1 == selSub)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}

	i = 0;
	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;
		
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}
	
	pToolCode->m_SubToolData.RemoveAt(pos);


	CString strMessage;
	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
/*		if(sel == 0)
			strMessage.Format(_T("Delete AGC %d. "), i+1);
		else */
		if(sel == 0)
			strMessage.Format(_T("Delete One Hole Param. "), i+1);
		else
			strMessage.Format(_T("Delete PowerMeasurement Param. %d. "), i+1);
	}
	else
	{
		strMessage.Format(_T("Delete Tool %d (sub : %d). "), nListIndex, i+1);
	}
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));

	SUBTOOLDATA subData;

	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subData = pToolCode->m_SubToolData.GetAt(pos);
		if(subData.nSubToolNo > selSub + 1)
		{
			subData.nSubToolNo--;
			pToolCode->m_SubToolData.SetAt(pos, subData);
		}
		pToolCode->m_SubToolData.GetNext(pos);
	}

	UpdateList(m_nToolIndex, selSub-1);
	m_ctrTreeTool.SetFocus();
}

void CPaneRecipeGenParameterNew::OnButtonParamUpdate() 
{
	// TODO: Add your control notification handler code here
	int sel = m_nToolIndex;
	if(-1 == sel) 
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int selSub = m_nSubIndex;
	if(-1 == selSub)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}
	
	ChangeData(sel, selSub);
	m_ctrTreeTool.SetFocus();
}

void CPaneRecipeGenParameterNew::OnButtonParamUpdateMain()
{
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	if(!ChangeDataMain(sel))
		return;
	m_ctrTreeTool.SetFocus();

}

void CPaneRecipeGenParameterNew::OnCheckUseTool() 
{

	return;
	/*
	UpdateData(TRUE);
	m_bUseTool = m_chkUseTool.GetCheck();

	int nLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel();
	if(nLevel < 1)
		return;
	
	EnableControl(m_bUseTool);

	OnCheckUseAperture();
//	OnSelChangeComboDrillMethod();
	OnSelChangeComboToolType();
	*/
}

void CPaneRecipeGenParameterNew::OnCheckUseToolOrder() 
{
	UpdateData(TRUE);
 
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
/*		if(0 == str.CompareNoCase("S. Cal."))
			pToolCode->m_nToolNo = 0;
		else */
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}

	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}

			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}

void CPaneRecipeGenParameterNew::OnCheckUseAperture() 
{
	UpdateData(TRUE);
	m_bUseAperture = m_chkUseAperture.GetCheck();

//	if(m_bUseAperture && !m_bUseTool)
//		return;

	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_THERMAL_TRACK)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_Z_OFFSET)->EnableWindow(m_bUseAperture);

	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->EnableWindow(m_bUseAperture);

/*	
	BOOL bShow = m_chkUseAperture.GetCheck();

	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(bShow);
	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_THERMAL_TRACK)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_Z_OFFSET)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_Z_OFFSET)->ShowWindow(bShow);
*/

	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.bUseAperture = m_bUseAperture;
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::GetColor(int nIndex, CString& strText)
{
	switch( nIndex )
	{
	case 0 :
		strText.Format(_T("Maroon"));
		break;
	case 1 :
		strText.Format(_T("Brown"));
		break;
	case 2 :
		strText.Format(_T("Red"));
		break;
	case 3 :
		strText.Format(_T("Magenta"));
		break;
	case 4 :
		strText.Format(_T("Orange"));
		break;
	case 5 :
		strText.Format(_T("Pink"));
		break;
	case 6 :
		strText.Format(_T("Yellow"));
		break;
	case 7 :
		strText.Format(_T("Cyan"));
		break;
	case 8 :
		strText.Format(_T("Blue"));
		break;
	case 9 :
		strText.Format(_T("Green"));
		break;
	case 10 :
		strText.Format(_T("Lime"));
		break;
	case 11 :
		strText.Format(_T("IndianRed"));
		break;
	case 12 :
		strText.Format(_T("Salmon"));
		break;
	case 13 :
		strText.Format(_T("Gold"));
		break;
	case 14 :
		strText.Format(_T("Tan"));
		break;
	case 15 :
		strText.Format(_T("Khaki"));
		break;
	case 16 :
		strText.Format(_T("Teal"));
		break;
	case 17 :
		strText.Format(_T("Purple"));
		break;
	case 18 :
		strText.Format(_T("CadeBlue"));
		break;
	case 19 :
		strText.Format(_T("Crimson"));
		break;
	case 20 :
		strText.Format(_T("Silver"));
		break;
	case 21 :
		strText.Format(_T("Navy"));
		break;
	case 22 :
		strText.Format(_T("Plum"));
		break;
	case 23 :
		strText.Format(_T("Violet"));
		break;
	case 24 :
		strText.Format(_T("SeaGreen"));
		break;
	case 25 :
		strText.Format(_T("DarkGray"));
		break;
	case 26 :
		strText.Format(_T("Indigo"));
		break;
	case 27 :
		strText.Format(_T("GoldenRod"));
		break;
	case 28 :
		strText.Format(_T("Gray"));
		break;
	case 29 :
		strText.Format(_T("Black"));
		break;
	}
}

void CPaneRecipeGenParameterNew::EnableControl(BOOL bUse)
{
//	if(m_nUserLevel == 0)
//		return;

	GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(bUse);
	GetDlgItem( IDC_COMBO_SUB_MASK )->EnableWindow(bUse);
	GetDlgItem( IDC_CHECK_SUB_USE_TOPHAT )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(bUse);
	
	if(m_nUserLevel == 3)
	{
		GetDlgItem( IDC_EDIT_SUB_ROTATE )->EnableWindow(bUse);
		GetDlgItem( IDC_CHECK_SUB_X_FLIP )->EnableWindow(bUse);
		GetDlgItem( IDC_CHECK_SUB_Y_FLIP )->EnableWindow(bUse);
	}
	else
	{
		GetDlgItem( IDC_EDIT_SUB_ROTATE )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_X_FLIP )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_Y_FLIP )->EnableWindow(FALSE);
	}

	
	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(bUse);
	if(m_bGlobalParam)
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(bUse);
	GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(bUse);
	
	GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(bUse);
//	GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(bUse);
	
	GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(bUse);
	
	GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(bUse);
	GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(bUse);
	GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(bUse);

	GetDlgItem(IDC_COMBO_COLOR)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE)->EnableWindow(bUse);
	GetDlgItem(IDC_COMBO_SUB_TOOL_TYPE)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_SUB_MEMO)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_SUB_POWER)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_POWER_STOP)->EnableWindow(bUse);
	GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_SUB_GRID_X)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_SUB_GRID_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_FIRE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_STOP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_SUB_SHOT_SETTING)->EnableWindow(bUse);
	

}

int CPaneRecipeGenParameterNew::GetUseToolIndex(int nIndex)
{
	BOOL bAllCheck = m_chkAllShowTool.GetCheck();

	int nCount = 0;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
//		if(!m_pToolCode[i]->m_bUseTool && !bAllCheck)
		if(!m_pToolCode[i]->m_bUseTool && !bAllCheck/* && pos == NULL*/)
			continue;

		if(m_pToolCode[i])
		{
			if(nCount == nIndex)
				return i;
			
			nCount++;
		}
	}
	return -1;
}



void CPaneRecipeGenParameterNew::OnChangeEditSubTotalShot() 
{
	int nMode = m_cmbDrillMethod.GetCurSel();
	if(nMode == 0) // burst
	{
		CString str;
		m_edtTotalShot.GetWindowText(str);
		m_edtBurstShot.SetWindowText(str);
	}
	else if(nMode == 1) // cycle
	{
		m_edtBurstShot.SetWindowText("0");
	}
	else
	{
		
	}

	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtTotalShot.GetWindowText(str);
	nTempVal = atoi(str);
	
	subData.nTotalShot = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}


}

BOOL CPaneRecipeGenParameterNew::CheckSubTool(SUBTOOLDATA subData, int nToolNum)
{
	return TRUE;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(subData.nToolType == FLYING_TYPE)
		{
			ErrMessage(_T("Flying Type can't be used."));
			GetDlgItem( IDC_COMBO_SUB_TOOL_TYPE )->SetFocus();
			return FALSE;
		}
		if(subData.dCurrent > 100 || subData.dCurrent <= 80)
		{
			ErrMessage(_T("Current range : 80 % < Current <= 100%"));
			GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 50000 || subData.nFrequency > 200000)
		{
			ErrMessage(_T("Frequency range : 50 KHz < Current <= 200 KHz"));
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}

		if(subData.dA1 < 0 || subData.dA1 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
			GetDlgItem( IDC_EDIT_SUB_A1 )->SetFocus();
			return FALSE;
		}
		if(subData.dA2 < 0 || subData.dA2 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
			GetDlgItem( IDC_EDIT_SUB_A2 )->SetFocus();
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(subData.dCurrent > 100 || subData.dCurrent <= 0)
		{
			ErrMessage(_T("Current range : 0 % < Current <= 100%"));
			GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 1000 || subData.nFrequency > 100000)
		{
			ErrMessage(_T("Frequency range : 1 KHz < Frequency <= 100 KHz"));
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}
		
		if(subData.dA1 < 0 || subData.dA1 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
			GetDlgItem( IDC_EDIT_SUB_A1 )->SetFocus();
			return FALSE;
		}
		if(subData.dA2 < 0 || subData.dA2 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
			GetDlgItem( IDC_EDIT_SUB_A2 )->SetFocus();
			return FALSE;
		}
		if(subData.nMask < 0)
		{
			ErrMessage(_T("Select Mask No."));
			GetDlgItem( IDC_COMBO_SUB_MASK )->SetFocus();
			return FALSE;
		}
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(subData.dCurrent < 0 || subData.dCurrent > 100)
			{
				ErrMessage(_T("Current range : 0 < Current <= 100"));
				GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
				return FALSE;
			}
			if(subData.nFrequency < 15000 || subData.nFrequency > 100000)
			{
				ErrMessage(_T("Frequency range : 15 KHz < Current <= 100 KHz"));
				GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
				return FALSE;
			}
		}
		else
		{
		
			if(subData.nFrequency < 1000 || subData.nFrequency > 10000)
			{
				ErrMessage(_T("Frequency range : 1 KHz < Current <= 10 KHz"));
				GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
				return FALSE;
			}
		}

//		if(subData.nToolType != SHOT_DRILL_TYPE)
//		{
//			ErrMessage(_T("You can only use Shot drill type."));
//			GetDlgItem( IDC_COMBO_SUB_TOOL_TYPE )->SetFocus();
//			return FALSE;
//		}
		if(subData.nMask < 0)
		{
			ErrMessage(_T("Select Mask No."));
			GetDlgItem( IDC_COMBO_SUB_MASK )->SetFocus();
			return FALSE;
		}
	}
	
	if(subData.nToolType != FLYING_TYPE)
	{
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Draw Speed : Insert 1 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
//			if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
//			{
//				ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
//				GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
//				return FALSE;
//			}
		}
		if(subData.nToolType == MARKING_TYPE || (subData.nToolType == LINE_DRILL_TYPE && m_bGlobalParam && nToolNum == 0))
		{
			if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 5001)
			{
				ErrMessage(_T("Draw Step Period : Insert 20 ~ 5000"));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}
		else
		{
			if(subData.nDrawStepPeriod < 15 || subData.nDrawStepPeriod > 5001)
			{
				ErrMessage(_T("Draw Step Period : Insert 15 ~ 5000"));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}

		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(IDS_PARAM_JSP);
			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nCornerDelay < 0 || subData.nCornerDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Corner Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nJumpDelay < 0 || subData.nJumpDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Jump Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nLineDelay < 0 || subData.nLineDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Line Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nLaserOnDelay < 1 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 1 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nFPS < 0 || subData.nFPS > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("FPS : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_FPS )->SetFocus();
				return FALSE;
			}
		}

		int nTotalCount = 1;
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nShotMode < 0)
			{
				ErrMessage(IDS_PARAM_SHOT);
				GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->SetFocus();
				return FALSE;
			}
			if(subData.nTotalShot < 1 || subData.nTotalShot > 15)
			{
				ErrMessage(_T("Total Shot : Insert 1 ~ 15."));
				GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->SetFocus();
				return FALSE;
			}
			
			if(subData.nShotMode != 1)
			{
				if(subData.nBurstShot < 0 || subData.nTotalShot < subData.nBurstShot)
				{
					ErrMessage(_T("Burst Shot : Insert 0 ~ Total Shot No."));
					GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->SetFocus();
					return FALSE;
				}
			}
			nTotalCount = subData.nTotalShot;
		}
		
		for(int i = 0; i < nTotalCount; i++)
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
			{
				/*
				if(subData.dShotDuty[i] / (10000. / subData.nFrequency) <= 0 || 
					subData.dShotDuty[i] / (10000. / subData.nFrequency) > 50) // %
				{
					ErrMessage(_T("Duty range : 0 < Duty < 50 %"));
					return FALSE;
				}
				*/
				if(gSystemINI.m_sHardWare.nAOMType != 0)
				{
					if(subData.dShotAOMDelay[i] < 0 || subData.dShotAOMDelay[i] > 1000000 / subData.nFrequency) // %
					{
						ErrMessage(_T("AOM Delay range : 0 < AOM Delay < 1 Freq. period"));
						return FALSE;
					}
					if(subData.dShotAOMDuty[i] < 0 || 
						subData.dShotAOMDelay[i] + subData.dShotAOMDuty[i] > 1000000 / subData.nFrequency) // %
					{
						ErrMessage(_T("AOM Duty range : 0 < AOM Delay + AOM Duty < 1 Freq. period"));
						return FALSE;
					}
					if(subData.cAOMFilePath[i][0] == NULL)
					{
						ErrMessage(IDS_PARAM_AOM);
						return FALSE;
					}
				}
			}
			else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				subData.dShotDuty[i] = 50;
			}
		}
		
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.bUseAperture && subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(IDS_PARAM_APERTURE);
				return FALSE;
			}
//			if(subData.cMoveProfileFilePath[0] == _T('\0'))
//			{
//				ErrMessage(_T("Select a Scanner Move Profile file."));
//				return FALSE;
//			}
		}
		if(subData.nToolType == LINE_DRILL_TYPE )
		{
			if(!subData.bUseAperture || subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(IDS_PARAM_APERTURE);
				return FALSE;
			}
		}
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nApertureBurst < 1 || subData.nApertureBurst > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Aperture Burst : Insert 1 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_APERTURE_BURST )->SetFocus();
				return FALSE;
			}
		}
	}
	else // flying type
	{
		if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Draw Speed : Insert 1 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
		{
//			ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
//			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
//			return FALSE;
		}
		if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 5001)
		{
			ErrMessage(_T("Draw Step Period : Insert 20 ~ 5000"));
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(IDS_PARAM_JSP);
			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOnDelay < 1 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 1 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
			return FALSE;
		}

		if(subData.nTableSpeed < 0)
		{
			ErrMessage(_T("Table Speed : Insert 1 ~ Max Table Speed."));
			GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->SetFocus();
			return FALSE;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
		{
			if(subData.dShotDuty[0] <= 0 || subData.dShotDuty[0] > 50) // %
			{
				ErrMessage(_T("Duty range : 0 < Duty < 50 %"));
				return FALSE;
			}
			if(gSystemINI.m_sHardWare.nAOMType != 0)
			{
				if(subData.dShotAOMDelay[0] < 0 || subData.dShotAOMDelay[0] > 1000000 / subData.nFrequency) // %
				{
					ErrMessage(_T("AOM Delay range : 0 < AOM Delay < 1 Freq. period"));
					return FALSE;
				}
				if(subData.dShotAOMDuty[0] < 0 || 
					subData.dShotAOMDelay[0] + subData.dShotAOMDuty[0] > 1000000 / subData.nFrequency) // %
				{
					ErrMessage(_T("AOM Duty range : 0 < AOM Delay + AOM Duty < 1 Freq. period"));
					return FALSE;
				}
				if(subData.cAOMFilePath[0][0] == NULL)
				{
					ErrMessage(IDS_PARAM_AOM);
					return FALSE;
				}
			}
		}
		//		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		//		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
	}
	if(subData.dZOffset < -5 || subData.dZOffset > 5)
	{
		ErrMessage(_T("Z-axis Offset : Insert -5mm ~ 5mm."));
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->SetFocus();
		return FALSE;
	}

	//if (subData.dMinPower > subData.dMaxPower && subData.dMinPower > 0 && subData.dMinPower < 100 && subData.dMaxPower > 0 && subData.dMaxPower < 100)
	if (subData.dMinPower > subData.dMaxPower ) //20110923
	{
		ErrMessage(IDS_MEASURE_REF_VALUE);
		SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
	}
	else if (subData.dMinPower <= 0 || subData.dMinPower >= 100)
	{
		ErrMessage(_T("0 < Min.Value < 100"));
		SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
	}
	else if (subData.dMaxPower <= 0 || subData.dMaxPower >= 100)
	{
		ErrMessage(_T("0 < Max.Value < 100"));
		SetEditBoxActive(IDC_EDIT_MAX_ALLOWABLE);
	}

	if(subData.dHoleSize < 0.001 || subData.dHoleSize > 2.0)
	{
		ErrMessage(_T("0.001 < HoleSize < 2.0"));
		SetEditBoxActive(IDC_EDIT_HOLE_SIZE);
	}


	return TRUE;
}

void CPaneRecipeGenParameterNew::SetEditBoxActive(int i)
{
	GetDlgItem(i)->SetFocus();
	CEdit* pEdit = static_cast<CEdit*>(GetDlgItem(i));
	pEdit->SetSel(0, -1);
}

BOOL CPaneRecipeGenParameterNew::SetData(GlobalVariable &mGlobal, int nMainTool)
{
	ShowControl(TRUE);
	m_bGlobalParam = TRUE;
	m_chkAllShowTool.ShowWindow(SW_HIDE);

/*	GetDlgItem(IDC_STATIC_SUB_MEMO)->ShowWindow(TRUE);
	GetDlgItem(IDC_EDIT_SUB_MEMO)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_MINMAX_ALLOWABLE)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_MIN_ALLOWABLE)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_MAX_ALLOWABLE)->ShowWindow(TRUE);
	GetDlgItem(IDC_EDIT_MIN_ALLOWABLE)->ShowWindow(TRUE);
	GetDlgItem(IDC_EDIT_MAX_ALLOWABLE)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_SCAL_HOLE_SIZE)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_HOLE_SIZE)->ShowWindow(TRUE);
	GetDlgItem(IDC_EDIT_HOLE_SIZE)->ShowWindow(TRUE);
*/
	ChangeBeamPathData();

	m_edtLotID.EnableWindow(FALSE);
	m_edtFontSize.EnableWindow(FALSE);
	m_edtTextHolePitch.EnableWindow(FALSE);

	m_ctrTreeTool.DeleteAllItems( );

	CString strText;
	memset(&m_pToolCode, 0, sizeof(m_pToolCode));
	int nToolCnt = 0, nSubCnt;
	HTREEITEM hRoot, hSubItem;
	BOOL bMainAdd = FALSE, bSubAdd = FALSE;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = mGlobal.m_pToolCode[i];

		if(m_pToolCode[i]->m_bUseTool)
		{
			bMainAdd = TRUE;
/*			if(nToolCnt == 0)
				strText.Format(_T("S. Cal."));
			else*/
			if(nToolCnt == 0)
				strText.Format(_T("One Hole"));
//			else
//				strText.Format(_T("Power"));

			hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
		    if (hRoot != NULL)
			{
			   m_ctrTreeTool.SetItemData(hRoot, nToolCnt * 100);
			}

			nSubCnt = 1;
			POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			while(pos)
			{
				m_pToolCode[i]->m_SubToolData.GetNext(pos);
				strText.Format(_T("SubTool %d"), nSubCnt);
				hSubItem = m_ctrTreeTool.InsertItem(strText, 0, 1, hRoot);
				if (hSubItem != NULL)
				{
					m_ctrTreeTool.SetItemData(hSubItem, nToolCnt * 100 + nSubCnt);
				}
				bSubAdd = TRUE;
				nSubCnt++;
			}
			nToolCnt++;
			m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);
		}
	}
	
	if(bMainAdd)
		m_nToolIndex = 0;
	if(bSubAdd)
		m_nSubIndex = 0;

	m_nToolIndex = nMainTool;
	if(nMainTool == -1) m_nToolIndex = 0;

	ChangeDisplay(m_nToolIndex, m_nSubIndex);

	if(nMainTool > -1)
		UpdateList(m_nToolIndex, m_nSubIndex);
	


	return TRUE;
}

void CPaneRecipeGenParameterNew::OnItemchangingListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	*pResult = 0;
}


void CPaneRecipeGenParameterNew::OnItemchangingListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CPaneRecipeGenParameterNew::OnCheckSubXFlip() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_bUseFlipX = m_chkUseFlipX.GetCheck();
	
	if(m_nToolIndex == -1)
		return ;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
		
	subData.bFlipX = m_bUseFlipX;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	Invalidate(FALSE);
}

void CPaneRecipeGenParameterNew::OnCheckSubYFlip() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_bUseFlipY = m_chkUseFlipY.GetCheck();
	if(m_nToolIndex == -1)
		return ;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.bFlipY = m_bUseFlipY;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	Invalidate(FALSE);
}

void CPaneRecipeGenParameterNew::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;

	switch(nLevel)
	{
	case 0: // Operator
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE_MAIN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_ADD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE)->EnableWindow(TRUE);
		m_btnOpenMainTool.EnableWindow(FALSE);
		m_btnSaveMainTool.EnableWindow(FALSE);
#ifdef __KUNSAN_SAMSUNG_LARGE__
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(TRUE);
#else
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(TRUE);
#endif
		GetDlgItem(IDC_CHECK_PRE_POWER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_SCAL)->EnableWindow(TRUE);

/*		GetDlgItem(IDC_BUTTON_PARAM_UPDATE_MAIN)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PARAM_ADD)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PARAM_DELETE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_PRE_POWER)->EnableWindow(FALSE);
*/		ApertureControlEnable(TRUE);
		EnableControl(TRUE);
		OnSelChangeComboToolType();
		break;
	case 1: // Engineer
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE_MAIN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_ADD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_POWER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_SCAL)->EnableWindow(TRUE);
		ApertureControlEnable(FALSE);
		EnableControl(TRUE);
		OnSelChangeComboToolType();
		m_btnOpenMainTool.EnableWindow(TRUE);
		m_btnSaveMainTool.EnableWindow(TRUE);
		break;
	case 2: // EO Engineer
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE_MAIN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_ADD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_POWER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_SCAL)->EnableWindow(TRUE);

		ApertureControlEnable(TRUE);
		EnableControl(TRUE);
		OnSelChangeComboToolType();
		m_btnOpenMainTool.EnableWindow(TRUE);
		m_btnSaveMainTool.EnableWindow(TRUE);
		break;
	case 3: // Super Engineer
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE_MAIN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_ADD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PARAM_UPDATE)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_POWER)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PRE_SCAL)->EnableWindow(TRUE);

		ApertureControlEnable(TRUE);
		EnableControl(TRUE);
		OnSelChangeComboToolType();
		m_btnOpenMainTool.EnableWindow(TRUE);
		m_btnSaveMainTool.EnableWindow(TRUE);
		break;
	}
	
	
}

void CPaneRecipeGenParameterNew::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DrawBarcode();
	// Do not call CFormView::OnPaint() for painting messages
}

void CPaneRecipeGenParameterNew::DrawBarcode()
{
	CClientDC dc(GetDlgItem(IDC_STC_2DBAR));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_2DBAR)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	//	SetDCCoord(&BufferDC);
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, 3, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
	int nX[7], nY[7];
	nX[0] = 25; nY[0] = 80;
	nX[1] = 25; nY[1] = 20;
	nX[2] = 65; nY[2] = 20;
	nX[3] = 75; nY[3] = 35;
	nX[4] = 65; nY[4] = 50;
	nX[5] = 75; nY[5] = 80;
	nX[6] = 25; nY[6] = 50;

	CString str;
	int nTempVal, nBarX, nBarY;	
	double cosTheta, sinTheta;
	m_edtRotate.GetWindowText(str);
	nTempVal = atoi(str);

	if(m_bUseFlipX)
	{
		for(int i = 0; i < 7; i++)
			nX[i] = 100 - nX[i];
	}
	if(m_bUseFlipY)
	{
		for(int i = 0; i < 7; i++)
			nY[i] = 100 - nY[i];
	}

	if(nTempVal != 0)
	{
		cosTheta = cos(-nTempVal * M_PI / 180);
		sinTheta = sin(-nTempVal * M_PI / 180);
		for(int i = 0; i < 7; i++)
		{	
			nBarX = (int)(cosTheta*(nX[i] - 50) - sinTheta*(nY[i]-50) + 0.5) + 50;
			nBarY = (int)(sinTheta*(nX[i] - 50) + cosTheta*(nY[i]-50) + 0.5) + 50;
			nX[i] = nBarX;
			nY[i] = nBarY;
		}
	}

	//
	BufferDC.MoveTo(nX[0] * cRect.Width() / 100 , nY[0] * cRect.Height() / 100);
	for(int i = 1; i < 6; i++)
		BufferDC.LineTo(nX[i] * cRect.Width() / 100, nY[i] * cRect.Height() / 100);

	BufferDC.MoveTo(nX[4] * cRect.Width() / 100, nY[4] * cRect.Height() / 100);
	BufferDC.LineTo(nX[6] * cRect.Width() / 100, nY[6] * cRect.Height() / 100);
	// draw end
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
}

void CPaneRecipeGenParameterNew::OnChangeEditSubRotate() 
{
	int nTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtRotate.GetWindowText(str);
	nTempVal = atoi(str);
	
	subData.nRotate = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;
	Invalidate(FALSE);
}

void CPaneRecipeGenParameterNew::OnButtonParamOpen() 
{
	// TODO: Add your control notification handler code here
#ifdef __TEST__
	ParameterOpen(1);
#endif
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}
/*
	if(m_bGlobalParam)
	{
		if(nListIndex == 0)
		{
			if(IDNO == ErrMessage(_T("S.Cal Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO | MB_ICONQUESTION))
				return;
		}
		else if(nListIndex == 1)
		{
			if(IDNO == ErrMessage(_T("OneHole Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO| MB_ICONQUESTION))
				return;
		}
	}
	else
	{
		CString strMsg;
		strMsg.Format(_T("%d�� Tool�� �����Ͻðڽ��ϱ�?"), nListIndex);
		if(IDNO == ErrMessage(strMsg, MB_YESNO| MB_ICONQUESTION))
			return;
	}
*/
	//
	TCHAR BASED_CODE szFilter[] = _T("PEN File (*.pen)|*.pen|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.pen"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	
	if(IDOK != dlg.DoModal())
	{
		m_ctrTreeTool.SetFocus();
		return;
	}
	//
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(dlg.GetPathName(), CFile::modeRead))
		{
			return;
		}
		CArchiveMark ar(&file, CArchive::load);
		CToolCodeList* pToolCode;
		//CToolCodeList* pToolCode2;
		int bUseToolBackup[MAX_TOOL_NO];
		int nRefToolNo[MAX_TOOL_NO];
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			bUseToolBackup[i] = m_pToolCode[i]->m_bUseTool;
			nRefToolNo[i] = m_pToolCode[i]->m_nRefToolNo;
		}
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			pToolCode = m_pToolCode[i];
			///pToolCodeBackup.m_SubToolData = m_pToolCode[i]->m_SubToolData;
			
			if(!pToolCode->LoadFile10000(ar, 10032, FALSE, TRUE))
				return;

			if((pToolCode->m_nRefToolNo != nRefToolNo[i]) || (pToolCode->m_bUseTool == FALSE && bUseToolBackup[i]))
			{
				CString strMsg;
				strMsg.Format(_T("%d Tool Parameter not match"), i);
				ErrMessage(strMsg);
			}
			//for(int j = 0; j < MAX_TOOL_NO; j++)
			//{
			//	pToolCode2 = m_pToolCode[j];
			//	if(nRefToolNo[j] == pToolCode->m_nRefToolNo)
			//	{
			//		if(!m_pToolCode[j]->m_bUseTool && !bUseToolBackup[i])
			//		{
			//			continue;
			//		}
			//		
			//		pToolCode->m_nToolNo = j;
			//		pToolCode2->m_nRefToolNo = nRefToolNo[j];
			//		//pToolCode2->m_nToolColor = pToolCode->m_nToolColor;
			//		//pToolCode2->m_nMarkingSize = pToolCode->m_nMarkingSize;
			//		//pToolCode = pToolCode2->m_nToolNo;
			//		//pToolCode2 = pToolCode; 


			//		SUBTOOLDATA subData;
			//		POSITION pos = pToolCode2->m_SubToolData.GetHeadPosition();
			//		if(pos)
			//		{
			//			subData = pToolCode2->m_SubToolData.GetAt(pos);
			//		}

			//		SUBTOOLDATA subDataOpen;
			//		POSITION pos2 = pToolCode->m_SubToolData.GetHeadPosition();
			//		if(pos2)
			//		{
			//			subDataOpen = pToolCode->m_SubToolData.GetAt(pos2);
			//		}
			//		subData = subDataOpen;

			//		pToolCode2->m_SubToolData.SetAt(pos,subData);
			//		//pToolCode->m_SubToolData.SetAt(pos2,subData);
			//		/*
			//		m_pProject->m_pToolCode[j]->m_SubToolData.RemoveAll();
			//		if( bUseToolBackup[j])
			//			AddSubToolToTool(j, i, pToolCode);
			//		break;*/
			//	}
			//}

#ifdef __KUNSAN_SAMSUNG_LARGE__
			pToolCode->GetDutyOffsetfromMDB();
#endif
			pToolCode->m_bUseTool = bUseToolBackup[i];
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH

	file.Close();
	
//	if(!ChangeDataMain(sel))
//		return;
	UpdateList(m_nToolIndex, -1);
	strcpy_s(m_szToolName, dlg.GetPathName());
	ChangeDisplay(m_nToolIndex, m_nSubIndex);
	CString str;
	str.Format(_T("%s"), m_szToolName);
	m_edtToolPath.SetWindowText(str);
	m_ctrTreeTool.SetFocus();
}

void CPaneRecipeGenParameterNew::OnButtonParamSave() 
{
	// TODO: Add your control notification handler code here
/*
	int sel = m_nToolIndex;
	if(-1 == sel)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}

	if(m_pToolCode[nListIndex]->m_nToolSize <= 0)
	{
		ErrMessage(_T("Tool Size > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return;
	}
*/

/*
	if(m_bGlobalParam)
	{
		if(nListIndex == 0)
		{
			if(IDNO == ErrMessage(_T("S.Cal Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO | MB_ICONQUESTION))
				return;
		}
		else if(nListIndex == 1)
		{
			if(IDNO == ErrMessage(_T("OneHole Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO | MB_ICONQUESTION))
				return;
		}
	}
	else
	{
		CString strMsg;
		strMsg.Format(_T("%d�� Tool�� �����Ͻðڽ��ϱ�?"), nListIndex);
		if(IDNO == ErrMessage(strMsg, MB_YESNO | MB_ICONQUESTION))
			return;
	}
*/	
	//
	TCHAR BASED_CODE szFilter[] = _T("PEN File (*.pen)|*.pen|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(FALSE, _T("*.pen"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	
	if(IDOK != dlg.DoModal())
	{
		m_ctrTreeTool.SetFocus();
		return;
	}

	//
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(dlg.GetPathName(), CFile::modeWrite|CFile::modeCreate))
		{
			return;
		}
		CArchiveMark ar(&file, CArchive::store);
		CToolCodeList* pToolCode;
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			pToolCode = m_pToolCode[i];
			pToolCode->SaveFile10000(ar, 10032);

#ifdef __KUNSAN_SAMSUNG_LARGE__
			pToolCode->SetDutyOffsettoMDB();
#endif
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
	strcpy_s(m_szToolName, (LPCTSTR)dlg.GetPathName());
	CString str;
	str.Format(_T("%s"), m_szToolName);
	m_edtToolPath.SetWindowText(str);
	m_ctrTreeTool.SetFocus();
}

void CPaneRecipeGenParameterNew::OnSelchangedTreeTool(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM hItem = pNMTreeView->itemNew.hItem;
	int nIndex = m_ctrTreeTool.GetItemData(hItem);
	BOOL bAllShow = m_chkAllShowTool.GetCheck();
	
	if(!bAllShow)
	{
		m_nToolIndex = nIndex/100;
		m_nSubIndex = nIndex%100 - 1;
	}
	else
	{
		m_nToolIndex = nIndex/100;
		m_nSubIndex = nIndex%100 - 1;
	}
	ChangeDisplay(m_nToolIndex, m_nSubIndex);

	*pResult = 0;
}
void CPaneRecipeGenParameterNew::OnCheckUsePrePower()
{
	m_bUsePrePower = m_chkUsePrePower.GetCheck();


		UpdateData(TRUE);
 
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);

		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);

		pToolCode->m_nToolNo = nTempVal;
	}
	if(!m_bGlobalParam)
	{
		if(pToolCode->m_bPreworkPower != m_bUsePrePower && m_bUsePrePower)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER);
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (OnCheckUsePrePower) : P"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
	}
	pToolCode->m_bPreworkPower = m_chkUsePrePower.GetCheck();

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}

			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}

void CPaneRecipeGenParameterNew::OnCheckUsePreScal()
{
	m_bUsePreScal = m_chkUsePreScal.GetCheck();


	UpdateData(TRUE);

	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);

		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);

		pToolCode->m_nToolNo = nTempVal;
	}
	if(!m_bGlobalParam)
	{
		if(pToolCode->m_bPreworkScanner != m_bUsePreScal && m_bUsePreScal)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER);
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (OnCheckUsePreScal) : P"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
	}
	pToolCode->m_bPreworkScanner = m_chkUsePreScal.GetCheck();

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}

			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}

void CPaneRecipeGenParameterNew::OnCheckUseHoleSorting()
{
	UpdateData(TRUE);
	
	if(m_bGlobalParam)
		return;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	pToolCode->m_bHoleSorting = m_chkHoleSorting.GetCheck();
	
	return ;
}
void CPaneRecipeGenParameterNew::OnCheckUseHoleFind()
{
	UpdateData(TRUE);
	
	if(m_bGlobalParam)
		return;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	pToolCode->m_bHoldFind = m_chkHoleFind.GetCheck();
	
	return ;
}
void CPaneRecipeGenParameterNew::ChangeBeamPathData()
{
	m_cmbMask.ResetContent();
	CString strTool;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"),i, gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbMask.AddString(strTool);
	}
	m_cmbMask.SetCurSel(0);
}

void CPaneRecipeGenParameterNew::ApertureControlEnable(BOOL bShow)
{
	if(bShow)
	{
		GetDlgItem(IDC_CHECK_SUB_USE_APERTURE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(SW_SHOW);
	}
	else
	{
		GetDlgItem(IDC_CHECK_SUB_USE_APERTURE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(SW_HIDE);
	}
}

void CPaneRecipeGenParameterNew::OnChangeEditSubDrawStep() 
{
	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	

	m_edtDrawStep.GetWindowText(str);
	dTempVal = atof(str);

	subData.dDrawStep = dTempVal;

	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;
}

void CPaneRecipeGenParameterNew::OnChangeEditSubFrequency() 
{
	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtFrequency.GetWindowText(str);
	nTempVal = atoi(str);
	
//	if(subData.nFrequency != nTempVal)
//		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
	
	subData.nFrequency = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::OnChangeEditSubLaserOffDelay() 
{
	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtLaserOffDelay.GetWindowText(str);
	nTempVal = atoi(str);
	
	subData.nLaserOffDelay = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;
	
}

void CPaneRecipeGenParameterNew::OnChangeEditSubLaserOnDelay() 
{
	int nTempVal;
//	double dTempVal;
	CString str;

	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtLaserOnDelay.GetWindowText(str);
	nTempVal = atoi(str);
	
	subData.nLaserOnDelay = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;
	
}

void CPaneRecipeGenParameterNew::OnChangeEditSubBurstShot() 
{
	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtBurstShot.GetWindowText(str);
	nTempVal = atoi(str);
	
	subData.nBurstShot = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;
	
	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::OnChangeEditSubMinShotTime()
{
	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtMinShotTime.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nMinShotTime = nTempVal;
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;
	
	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::OnChangeEditSubApertureBurst() 
{
	int nTempVal;
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;

	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	m_edtApertureBurst.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nApertureBurst = nTempVal;

	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
	
}
void CPaneRecipeGenParameterNew::OnChangeEditSize()
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
/*	if(nTempVal <= 0)
	{
		ErrMessage(_T("Tool Size > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus(); 
		return ;
	}
*/
	if(m_nToolIndex == -1)
		return;

	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nToolSize != nTempVal)
	{
		strTemp.Format(_T("| Size = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nToolSize = nTempVal;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}
	return ;
}
void CPaneRecipeGenParameterNew::OnChnageEditMax()
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}
	
	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}
	double dMin, dMax;
	
	m_edtMinPower.GetWindowText(str);
	dMin = atof(str);
	m_dMin[nListIndex] = dMin;
	
	m_edtMaxPower.GetWindowText(str);
	dMax = atof(str);
	m_dMax[nListIndex] = dMax;
	
	SUBTOOLDATA subtool;
	POSITION pos;
	
	pos = pToolCode->m_SubToolData.GetHeadPosition();

	

	while(pos)
	{
		subtool = pToolCode->m_SubToolData.GetAt(pos);
		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subtool.nMask];
		if(!m_bGlobalParam)
		{
//			if(subtool.dMaxPower != m_dMax[m_nToolIndex] || subtool.dMinPower != m_dMin[m_nToolIndex]) // min max ����� �ٽ� �Ŀ����� 
//			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
		}

		//subtool.dMinPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0];
		//subtool.dMaxPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0];

		subtool.dMinPower = dMin;
		subtool.dMaxPower = dMax;

		//subtool.dMinPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0];
		//subtool.dMaxPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0];

		pToolCode->m_SubToolData.SetAt(pos, subtool);
		subtool = pToolCode->m_SubToolData.GetNext(pos);
	}
	return ;
}
void CPaneRecipeGenParameterNew::OnChnageEditMin()
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return ;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	if(m_bGlobalParam)
	{
		m_edtMainTcode.GetWindowText(str);
		if(0 == str.CompareNoCase("One Hole"))
			pToolCode->m_nToolNo = 0;
		else
			pToolCode->m_nToolNo = 2;
	}
	else
	{
		m_edtMainTcode.GetWindowText(str);
		nTempVal = atoi(str);
		pToolCode->m_nToolNo = nTempVal;
	}
	
	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("One Hole Param. is changed. "));
			else
				strMessage.Format(_T("PowerMeasure Param is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}
	double dMin, dMax;
	
	m_edtMinPower.GetWindowText(str);
	dMin = atof(str);
	m_dMin[nListIndex] = dMin;
	
	m_edtMaxPower.GetWindowText(str);
	dMax = atof(str);
	m_dMax[nListIndex] = dMax;
	
	SUBTOOLDATA subtool;
	POSITION pos;
	
	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subtool = pToolCode->m_SubToolData.GetAt(pos);

		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subtool.nMask];
		if(!m_bGlobalParam)
		{
//			if(subtool.dMaxPower != m_dMax[m_nToolIndex] || subtool.dMinPower != m_dMin[m_nToolIndex]) // min max ����� �ٽ� �Ŀ����� 
//				::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
		}
		subtool.dMinPower = dMin;
		subtool.dMaxPower = dMax;

		//subtool.dMinPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[0];
		//subtool.dMaxPower = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[0];

		pToolCode->m_SubToolData.SetAt(pos, subtool);
		subtool = pToolCode->m_SubToolData.GetNext(pos);
	}

	

	return ;
}

void CPaneRecipeGenParameterNew::OnCheckShowTool() 
{
	BOOL bAllShow = m_chkAllShowTool.GetCheck();

	m_ctrTreeTool.DeleteAllItems( );
	
	ChangeBeamPathData();
	
	CString strText;
	int nMainCount = -1, nSubCnt;
	HTREEITEM hRoot, hSubItem;
	BOOL bMainAdd = FALSE, bSubAdd = FALSE;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
//		if(!m_pToolCode[i]->m_bUseTool && !bAllShow)
		if(!m_pToolCode[i]->m_bUseTool && !bAllShow/* && pos == NULL*/)
			continue;
/*	
		if(m_pToolCode[i]->m_bUseTool)
			m_ctrTreeTool.SetTextColor(RGB(0,0,0));
		else
			m_ctrTreeTool.SetTextColor(RGB(100,100,100));
*/
		nMainCount++;
		bMainAdd = TRUE;
		strText.Format(_T("Tool %d"), i);
		hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
		if (hRoot != NULL)
		{
			m_ctrTreeTool.SetItemData(hRoot, nMainCount * 100);
		}
		nSubCnt = 1;
		pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			m_pToolCode[i]->m_SubToolData.GetNext(pos);
			strText.Format(_T("SubTool %d"), nSubCnt);
			hSubItem = m_ctrTreeTool.InsertItem(strText, 0, 1, hRoot);
			if (hSubItem != NULL)
			{
				m_ctrTreeTool.SetItemData(hSubItem, nMainCount * 100 + nSubCnt);
			}
			bSubAdd = TRUE;
			nSubCnt++;
		}
		m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);
		
	}
	
	if(bMainAdd)
		m_nToolIndex = 0;
	if(bSubAdd)
		m_nSubIndex = 0;
	
	ChangeDisplay(m_nToolIndex, m_nSubIndex);
	
}

void CPaneRecipeGenParameterNew::OnDropdownComboSubMask() 
{
	// TODO: Add your control notification handler code here
	int nNumEntries = m_cmbMask.GetCount();
    int nWidth = 0;
    CString str;
	
    CClientDC dc(this);
    int nSave = dc.SaveDC();
    dc.SelectObject(this->GetFont());
	
    int nScrollWidth = ::GetSystemMetrics(SM_CXVSCROLL);
    for (int i = 0; i < nNumEntries; i++)
    {
        m_cmbMask.GetLBText(i, str);
        int nLength = dc.GetTextExtent(str).cx + nScrollWidth;
        nWidth = __max(nWidth, nLength);
    }   
    nWidth += dc.GetTextExtent(_T("0")).cx;
	
    dc.RestoreDC(nSave);
    m_cmbMask.SetDroppedWidth(nWidth);
}

void CPaneRecipeGenParameterNew::ConnectView()
{
//	if(m_bGlobalParam)
		return;

/*	m_bConnectVision = TRUE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}

	int nSel = m_cmbCam.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive( nSel, FALSE );
	pVision->OnCamChange( nSel );
	pVision->OnLive( nSel, TRUE );
*/	
}
void CPaneRecipeGenParameterNew::OnButtonFire()
{
	return;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("First. Select tool"));
		return;
	}
	
	m_bStop = FALSE;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}
	
//	EnableAllButton(FALSE);
	
	if (!UpdateData(TRUE))
	{
//		EnableAllButton(TRUE);
		return;
	}
	
	//gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);
	
	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		ErrMessage(_T("Dust Suction Shutter On Error."));
//		EnableAllButton(TRUE);
		return;
	}
	m_pThread = ::AfxBeginThread(FireHoleThread, this, THREAD_PRIORITY_NORMAL);
}

BOOL CPaneRecipeGenParameterNew::ShutterMove(BOOL bMaster, BOOL bSlave)
{
#ifdef __TEST__
	return TRUE;
#endif
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return TRUE;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BYTE nReStart = TRUE;
	if (pMotor != NULL)
	{
		// return value of GetCurrentShutter[1-2] : 1 = Open, 2 = Close, 3 = Center
		BYTE nShutter1 = pMotor->GetCurrentShutter1();
		BYTE nShutter2 = pMotor->GetCurrentShutter2();

		if (nShutter1 == 1)	
			nShutter1 = TRUE;
		else if (nShutter1 == 2)
			nShutter1 = FALSE;
		else	
			nShutter1 = 3;
		
		if (nShutter2 == 1)
			nShutter2 = TRUE;
		else if (nShutter2 == 2)
			nShutter2 = FALSE;
		else	
			nShutter2 = 3;

		if (bMaster == nShutter1 && bSlave == nShutter2)
			return TRUE;

RESHUTTER:
		int nCount = 0;
		pMotor->MotorShutterAll(bMaster, bSlave);
		::Sleep(20);

		do
		{
			nShutter1 = pMotor->GetCurrentShutter1();
			nShutter2 = pMotor->GetCurrentShutter2();

			if (nShutter1 == 1)
				nShutter1 = TRUE;
			else if (nShutter1 == 2)
				nShutter1 = FALSE;
			else
				nShutter1 = 3;
			
			if (nShutter2 == 1)
				nShutter2 = TRUE;
			else if (nShutter2 == 2)
				nShutter2 = FALSE;
			else
				nShutter2 = 3;

			if (nShutter1 == bMaster && nShutter2 == bSlave)
			{
				::Sleep(20);
				TRACE("Shutter Time : %d ms\n", nCount);
				return TRUE;
			}

			if (++nCount > 200)	//4 Sec
				break;

			::Sleep(20);
		} while (TRUE);

		nShutter1 = pMotor->GetCurrentShutter1();
		nShutter2 = pMotor->GetCurrentShutter2();

		if (nShutter1 == 1)			nShutter1 = TRUE;
		else if (nShutter1 == 2)	nShutter1 = FALSE;
		else						nShutter1 = 3;
		
		if (nShutter2 == 1)			nShutter2 = TRUE;
		else if (nShutter2 == 2)	nShutter2 = FALSE;
		else						nShutter2 = 3;

		if (nReStart == TRUE && (nShutter1 != bMaster || nShutter2 != bSlave))
		{
			nReStart = FALSE;
			goto RESHUTTER;
		}

		if (nShutter1 != bMaster)
		{
			if (bMaster)		// Open Error
			{
				ErrMsgDlg(STDGNALM413);
				return FALSE;
			}
			else					// Close Error
			{
				ErrMsgDlg(STDGNALM415);
				return FALSE;
			}
		}
		else if (nShutter2 != bSlave)
		{
			if (bSlave)		// Open Error
			{
				ErrMsgDlg(STDGNALM414);
				return FALSE;
			}
			else					// Close Error
			{
				ErrMsgDlg(STDGNALM416);
				return FALSE;
			}
		}
		else
			return FALSE;
	}
	else
		return FALSE;
	
	return TRUE;
}
BOOL CPaneRecipeGenParameterNew::LaserFire()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	
//	if (!UpdateData(TRUE))
//	{
//		return FALSE;
//	}

	CString strVal;

	int nCam = m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;
	
	m_edtGridX.GetWindowText(strVal);
	int nGridX = atoi(strVal);
	
	m_edtGridY.GetWindowText(strVal);
	int nGridY = atoi(strVal);

	if(nGridX < 1 || nGridY < 1)
	{
		ErrMessage(_T("Grid No Error : No >= 1"));
		return FALSE;
	}

	pEoCard->MoveToCenter();
	Sleep(500);

	unsigned short usMasterDumpPosX;
	unsigned short usMasterDumpPosY;
	unsigned short usSlaveDumpPosX;
	unsigned short usSlaveDumpPosY;
	
	pEoCard->GetDumperPosition(
		usMasterDumpPosX,
		usMasterDumpPosY,
		usSlaveDumpPosX,
		usSlaveDumpPosY
		);

//	m_edtScannerPosX.GetWindowText(strVal);
	int nMoveX = HALF_LSB;//atoi(strVal);
//	m_edtScannerPosY.GetWindowText(strVal);
	int nMoveY = HALF_LSB;//atoi(strVal);
	
	// grid size ����
	m_edtFieldSize.GetWindowText(strVal);
	int nGridSize = atoi(strVal);
	int nMaxLSB = (int)(MAXLSB * nGridSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;
	int nX, nY;
	if(nGridX == 1)
		nStepX = nMaxLSB;
	else
		nStepX = nMaxLSB / (nGridX - 1);

	if(nGridY == 1)
		nStepY = nMaxLSB;
	else
		nStepY = nMaxLSB / (nGridY - 1);

	nStartLSBX = (int)(nMoveX - (nGridX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(nMoveY - (nGridY/2.0 - 0.5)*nStepY);

	int nEocardHoleCount;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return FALSE;

	SUBTOOLDATA ToolData;
	POSITION pos;
	pos = m_pToolCode[nListIndex]->m_SubToolData.GetHeadPosition();
	//gVariable.m_pToolCode[0]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		if(m_bStop)
			return FALSE;

		ToolData = m_pToolCode[nListIndex]->m_SubToolData.GetNext(pos);
		if(!ChangeOneSubTool(ToolData))
			return FALSE;

		pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);

		pEoCard->GetDumperPosition(usMasterDumpPosX, usMasterDumpPosY, usSlaveDumpPosX, usSlaveDumpPosY);
		
		if(ToolData.nToolType == MARKING_TYPE)
		{
			if(nGridX < 2 || nGridY < 2)
				continue;

			for(int i = 0; i < nGridX; i++)
			{
				if(m_bStop)
					return FALSE;

				nX = nStartLSBX + i * nStepX;
				if(nX > MAXLSB) nX = MAXLSB;
				if(nX < 0)		nX = 0;
				
				nY = nStartLSBY;
				if(nY > MAXLSB) nY = MAXLSB;
				if(nY < 0)		nY = 0;

				if(nHead == 0) // Master
					pEoCard->jumpOne(nX, nY, TRUE);
				else
					pEoCard->jumpOne(nX, nY, FALSE);

				nY = nStartLSBY + (nGridY - 1) * nStepY;
				if(nY > MAXLSB) nY = MAXLSB;
				if(nY < 0)		nY = 0;

				if(nHead == 0) // Master
					pEoCard->markOne(nX, nY, TRUE);
				else
					pEoCard->markOne(nX, nY, FALSE);
			}

			for(int i = 0; i < nGridY; i++)
			{
				if(m_bStop)
					return FALSE;

				nX = nStartLSBX;
				if(nX > MAXLSB) nX = MAXLSB;
				if(nX < 0)		nX = 0;
				
				nY = nStartLSBY + i * nStepY;
				if(nY > MAXLSB) nY = MAXLSB;
				if(nY < 0)		nY = 0;
				
				if(nHead == 0) // Master
					pEoCard->jumpOne(nX, nY, TRUE);
				else
					pEoCard->jumpOne(nX, nY, FALSE);
				
				nX = nStartLSBX + (nGridX - 1) * nStepX;
				if(nX > MAXLSB) nX = MAXLSB;
				if(nX < 0)		nX = 0;
				
				if(nHead == 0) // Master
					pEoCard->markOne(nX, nY, TRUE);
				else
					pEoCard->markOne(nX, nY, FALSE);
			}

			if(m_bStop)
				return FALSE;
			
			WaitOneFireProcess();
		}
		else
		{
			pEoCard->ShotDataReset();
//			if(gSystemINI.m_sSystemDump.nDummyShot > 0)
//			{
//				pEoCard->DownloadShotDataDummy(gSystemINI.m_sSystemDump.nPtBeanDumper1.x, gSystemINI.m_sSystemDump.nPtBeanDumper1.y,
//												gSystemINI.m_sSystemDump.nPtBeanDumper2.x, gSystemINI.m_sSystemDump.nPtBeanDumper2.y,
//												FALSE, FALSE, DUMMY_TOOL);
//			}

		/*	if(m_bVariousZ)
			{
				if(nHead == 0) // Master
				{
					pEoCard->DownloadShotData2(32767, 32767, usSlaveDumpPosX,	usSlaveDumpPosY, TRUE, FALSE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(0, 0, usSlaveDumpPosX,	usSlaveDumpPosY, TRUE, FALSE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(0, 65535, usSlaveDumpPosX,	usSlaveDumpPosY, TRUE, FALSE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(65535, 65535, usSlaveDumpPosX,	usSlaveDumpPosY, TRUE, FALSE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(65535, 0, usSlaveDumpPosX,	usSlaveDumpPosY, TRUE, FALSE, ONE_HOLE_TOOL);
				}
				else if(nHead == 1) // Slave
				{
					pEoCard->DownloadShotData2(usMasterDumpPosX, usMasterDumpPosY, 32767, 32767, FALSE, TRUE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(usMasterDumpPosX, usMasterDumpPosY, 0, 0, FALSE, TRUE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(usMasterDumpPosX, usMasterDumpPosY, 0, 65535, FALSE, TRUE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(usMasterDumpPosX, usMasterDumpPosY, 65535, 65535, FALSE, TRUE, ONE_HOLE_TOOL);
					pEoCard->DownloadShotData2(usMasterDumpPosX, usMasterDumpPosY, 65535, 0, FALSE, TRUE, ONE_HOLE_TOOL);
				}
				nGridX = 1; nGridY = 5;
			}
			else */
			{
				for(int i = 0; i < nGridX; i++)
				{
					if(m_bStop)
						return FALSE;

					for(int j = 0; j < nGridY; j++)
					{
						if(m_bStop)
							return FALSE;
						
						nX = nStartLSBX + i * nStepX;
						if(nX > MAXLSB) nX = MAXLSB;
						if(nX < 0)		nX = 0;
						nY = nStartLSBY + j * nStepY;
						if(nY > MAXLSB) nY = MAXLSB;
						if(nY < 0)		nY = 0;

						if(nHead == 0) // Master
						{
							pEoCard->DownloadShotData2(
								nX, //HALFLSB,
								nY, //HALFLSB,
								usSlaveDumpPosX,
								usSlaveDumpPosY,
								TRUE,
								FALSE,
								ONE_HOLE_TOOL
								);
						}
						else if(nHead == 1) // Slave
						{
							pEoCard->DownloadShotData2(
								usMasterDumpPosX,
								usMasterDumpPosY,
								nX, //HALFLSB,
								nY, //HALFLSB,
								FALSE,
								TRUE,
								ONE_HOLE_TOOL
								);
						}
					}
				}
			}

			if(m_bStop)
				return FALSE;

			//20111107
			if(!gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				double dStandbyTime;
				while(TRUE)
				{
					MessageLoop();
					
					if(m_bStop)
						return FALSE;
					
					dStandbyTime = m_StandbyTime.PresentTime();

					if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
						if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
							break;
					else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
						if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime2)
							break;
//					if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
//						break;
				}
			}
			
			pEoCard->FieldPreStart(gSystemINI.m_sSystemDump.nDummyShot);

			if(gSystemINI.m_sSystemDump.nDummyShot > 0)
			{
				pEoCard->DummyFieldStart(gSystemINI.m_sSystemDump.nDummyShot, FALSE);
//				::Sleep(10);
				pEoCard->DummyStopAndDataShotStart(FALSE);//gProcessINI.m_sProcessSystem.bDryRun);
			}
			else
			{
				pEoCard->FieldStart(FALSE);
			}
			
			::Sleep(100);
			
			WaitOneFireProcess();

//			ErrMessage(_T("���� �Ϸ�."));

			nEocardHoleCount = pEoCard->ReadHoleCount();
			if( nEocardHoleCount != nGridX * nGridY)
			{
				CString str;
				str.Format(_T("MissHole. DownCount : %d, EoCard Count : %d "), nGridX * nGridY, nEocardHoleCount);
				ErrMessage(str);
			}
		}
	}

	if(m_bStop)
		return FALSE;

	::Sleep(100);
	//
	BOOL bIsDSPBusy = FALSE;
	int nBusyCount = 0;
	do
	{
		bIsDSPBusy = pEoCard->IsDSPBusy();
		MessageLoop();
		if(bIsDSPBusy)
			ErrMessage(_T("abnormal eocard busy."));

		nBusyCount++;
	} while(nBusyCount > 10);

//	ErrMessage(_T("WorkDone"));
	//
			
	pEoCard->MoveToCenter();

	return TRUE;
}
void CPaneRecipeGenParameterNew::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

BOOL CPaneRecipeGenParameterNew::ChangeOneSubTool(SUBTOOLDATA subTool, BOOL bPower)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEocard = gDeviceFactory.GetEocard();
	HLaser* pLaser = gDeviceFactory.GetLaser();
	
	double dC1, dC2, dA1, dA2, dM1, dM2; 
	
	if(subTool.nToolType == FLYING_TYPE)
	{
		ErrMessage(IDS_ERR_FLYING_TOOL);
		return FALSE;
	}

	CString strData;
	BOOL bTophat; 
	double dLaserHeight1, dLaserHeight2;

	bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];
	if(bPower)
	{
		dLaserHeight1 = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
		dLaserHeight2 = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
	}
	else
	{
		dLaserHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask];
		dLaserHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask];
	}
	m_dBaseZ1 = dLaserHeight1;
	m_dBaseZ2 = dLaserHeight2;

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}
	BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];
	BOOL bUseAom = gShotTableINI.m_sShotGroupTable.bUseAom[nShotIndex];
	//BOOL bUseAom = gBeamPathINI.m_sBeampath.bBeamPathUseAom[subTool.nMask];
	gVariable.m_nGlobalDummyType = gShotTableINI.m_sShotGroupTable.nDummyType[nShotIndex];

	/*if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return FALSE;
	}
*/

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		// Mask�� Z�� �̵�
		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 

		CString strMaster, strSlave;
		dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
		dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
		dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
		dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];
		if(!bPower)
		{
			strMaster.Format(_T("%s//%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strSlave.Format(_T("%s//%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
		
			TCHAR sz1stFile[255], sz2ndFile[255];
			lstrcpy(sz1stFile, strMaster);
			lstrcpy(sz2ndFile, strSlave);
			
			if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
			{
				CString strString, strMsg;
				strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
				strMsg.Format(strString, _T("ASC"));

				CString strTemp;
				strTemp.Format(_T("Beam Path : %d %s or %s"), subTool.nMask, strMaster, strSlave);
				strMsg.Format(strString, strTemp);
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				return FALSE;
			}
		}
		else
		{
			dHeight1 = dLaserHeight1;
			dHeight2 = dLaserHeight2; 
		}
		if(!pMotor->MoveZMCA2(	dHeight1 , dHeight2 ,
			dM1, dM2 ,dC1, dC2, dA1, dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			ErrMessage(strMsg);
			return FALSE;
		}
	}
	else // not use M, C
	{
		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 
		
		if(!pMotor->MoveZMC2(dHeight1 , dHeight2 , 
			subTool.dA1, subTool.dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
			ErrMessage(strMsg);
			return FALSE;
		}
	}

	// subTool download
	if(!pEocard->DownloadOneSubTool(ONE_HOLE_TOOL, subTool))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Parameter");
		ErrMessage(strMsg);
		return FALSE;
	}
	if(!pEocard->DownloadShotDrillScannerParam())
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Move Profile Parameter");
		ErrMessage(strMsg);
		return FALSE;
	}
	if(!bPower)
	{
		// Laser Current Set
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(!pLaser->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack))
			{
				ErrMessage(_T("Current Set Error"));
				return FALSE;
			}
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(!pLaser->SetCurrent(subTool.dCurrent))
			{
				ErrMessage(_T("Current Set Error"));
				return FALSE;
			}
		}
	}
	// M, C, Z Inposition
	//Inposition check
	if(!InPositionCheck())
	{
		ErrMessage(_T("Inposition Error"));
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneRecipeGenParameterNew::InPositionCheck()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2);
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_A1 + IND_A2  + IND_TOPHAT);
	}
	else // not use M, C
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2);
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_A1 + IND_A2 + IND_TOPHAT);
	}
	return TRUE;
}

void CPaneRecipeGenParameterNew::OnButtonStop()
{
	m_bStop = TRUE;
	
	if(m_pThread)
	{
		WaitForSingleObject(m_pThread, INFINITE);
		m_pThread = NULL;
	}
	
	//gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);
	
	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			ErrMessage(_T("Dust Suction Shutter Off Error."));
			return;
		}
	}
}
BOOL CPaneRecipeGenParameterNew::MoveVisionFoucs(BOOL b1st, BOOL bHighCam)
{
	double dZ1VisionFocus, dVisionHeight;

	if(b1st)
	{
		if(bHighCam)
			dVisionHeight = gSystemINI.m_sSystemDevice.d1stHighHeight;
		else
			dVisionHeight = gSystemINI.m_sSystemDevice.d1stLowHeight;
	}
	else
	{
		if(bHighCam)
			dVisionHeight = gSystemINI.m_sSystemDevice.d2ndHighHeight;
		else
			dVisionHeight = gSystemINI.m_sSystemDevice.d2ndLowHeight;
	}
	if(b1st)
		dZ1VisionFocus = dVisionHeight - gDProject.m_dPcbThick;
	else
		dZ1VisionFocus = dVisionHeight - gDProject.m_dPcbThick2;

	if (!gDeviceFactory.GetMotor()->MoveZ(dZ1VisionFocus))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	if (!gDeviceFactory.GetMotor()->InPositionIO(IND_Z1 + IND_Z2))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	return TRUE;
}
void CPaneRecipeGenParameterNew::WaitOneFireProcess()
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	if(pEoCard == NULL)
		return;
	
	BOOL bIsDSPBusy = FALSE;
	
	do
	{
/*		if(pEoCard->IsDrillTimeOut())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM566);
			return;
		}
		if(pEoCard->IsMotorFault())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM567);
			return;
		}
*/
		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, _T("Scanner Cable Error."));
			return;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, strErrorMsg);
			return;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg(STDGNALM1017, strErrorMsg);
			return;
		}
		else if(bTimeOutType)
		{
			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			ErrMsgDlg( STDGNALM566, strErrorMsg);
			return;
		}
		bIsDSPBusy = pEoCard->IsDSPBusy();
		MessageLoop();
#ifdef __TEST__
		bIsDSPBusy = FALSE;
#endif
	} while(bIsDSPBusy && !m_bStop);
}
LRESULT CPaneRecipeGenParameterNew::OnInspection(WPARAM wParam, LPARAM lParam)
{
	int nCam = (int)wParam;
	gDeviceFactory.GetVision()->OnLive(nCam, FALSE);
#ifndef __TEST__
	::Sleep(100);
#endif
	gDeviceFactory.GetVision()->OnLive(nCam, TRUE);
	return 1U;
}

void CPaneRecipeGenParameterNew::ShowControl(BOOL bGlobal)
{
/*	
	GetDlgItem(IDC_BUTTON_SUB_POWER)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_SUB_POWER_RESULT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SUB_POWER_RESULT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON_SUB_POWER_STOP)->ShowWindow(SW_HIDE);
*/	
	if(bGlobal)
	{
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_CHECK_TOOL_ORDER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_PRE_POWER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_PRE_SCAL)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_COLOR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMBO_COLOR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SIZE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SIZE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_UM)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_MIN_ALLOWABLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_MIN_ALLOWABLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_MAX_ALLOWABLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_MAX_ALLOWABLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_HOLE_FIND)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(FALSE);
		
		GetDlgItem(IDC_BUTTON_PARAM_OPEN)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_PARAM_SAVE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CHECK_HOLE_FIND)->ShowWindow(SW_SHOW);
		if(gProcessINI.m_sProcessSystem.nNoSortHole)
			GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_HIDE);
		else
			GetDlgItem(IDC_CHECK_HOLE_SORTING)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_SUB_TOOL_CAMERA)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_SUB_GRID_X)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_SUB_GRID_Y)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_SUB_FIELD_SIZE)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_SUB_POWER_RESULT)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_COMBO_SUB_TOOL_CAMERA)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_EDIT_SUB_GRID_X)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_EDIT_SUB_GRID_Y)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_EDIT_SUB_FIELD_SIZE)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_EDIT_SUB_POWER_RESULT)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_BUTTON_SUB_FIRE)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_BUTTON_SUB_STOP)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_BUTTON_SUB_POWER)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_SHOW);
		
	}
}
void CPaneRecipeGenParameterNew::OnButtonPower()
{
	return;

	m_bUserDummyOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();
	m_bPowerStop = FALSE;
	m_bStop = FALSE;
	m_dMeasuredPower = 0;
	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please reset error"));
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}

	if(CheckStatus(TRUE))
	{
		ErrMessage(_T("Stopped by User"));
		return;
	}

	pMotor->SetOutPort(PORT_POWER_METER, TRUE);

	m_dlgMeasurement.StartMeasurement(95);
	m_dlgMeasurement.ShowWindow(SW_SHOW);

	int nCam = m_cmbCam.GetCurSel();
	int nUsePanel;

	if(nCam < 2)
		nUsePanel = USE_1ST;	
	else 
		nUsePanel = USE_2ND;

	FParameter fPara;
	SUBTOOLDATA ToolData;
	POSITION ToolPos;

	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
	{
		ErrMessage(_T("Select Tool"));
		return ;
	}

	if(!m_pToolCode[nListIndex]->m_bUseTool)
	{
		ErrMessage(_T("Select Used Tool"));
		return ;
	}
	
	ToolPos = m_pToolCode[nListIndex]->m_SubToolData.GetHeadPosition();
	ToolData = m_pToolCode[nListIndex]->m_SubToolData.GetNext(ToolPos);
	

	if(!ChangeOneSubTool(ToolData, TRUE))
	{
		m_dlgMeasurement.ShowWindow(SW_HIDE);
		ErrMsgDlg(STDGNALM600);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		return ;
	}

	if(!UpdateNewParam(ToolData))
	{	
		ErrMsgDlg(STDGNALM445);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		m_dlgMeasurement.ShowWindow(SW_HIDE);
		return ;
	}
	

	double dX, dY, dZ1, dZ2;
	if(nUsePanel == USE_1ST)
	{
		dX = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x;
		dY = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y;
	}
	else
	{
		dX = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x;
		dY = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y;
	}
	
	dZ1  = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
	dZ2  = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
		
	int nCount = 0;
	double dMeasureResult = 0;
	CString strEvent, strInfo;
	

	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, TRUE, SHOT_MOVE, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		m_dlgMeasurement.ShowWindow(SW_HIDE);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		return;
	}
	
	if(CheckStatus(TRUE))
	{
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		ErrMessage(_T("Stopped by User"));
		return;
	}
	
	if(nUsePanel == USE_1ST)
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE))
		{
			ErrMsgDlg(STDGNALM417); // shutter sensor error
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
			m_dlgMeasurement.ShowWindow(SW_HIDE);
			return ;
		}
	}
	else
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE))
		{
			ErrMsgDlg(STDGNALM417); // shutter sensor error
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
			m_dlgMeasurement.ShowWindow(SW_HIDE);
			return;
		}
	}
			
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		m_dlgMeasurement.ShowWindow(SW_HIDE);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		return;
	}
	
	if(CheckStatus(TRUE))
	{
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		ErrMessage(_T("Stopped by User"));
		return;
	}

	//20111107
/*	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		m_bUserDummyOn = FALSE; // �ٽ� ���� �ʴ´�
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
		{
#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Shot start Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot start Failure"));
#endif
		}
		CCorrectTime	StandbyTime;
		StandbyTime.StartTime();
		
		double dStandbyTime;
		while(TRUE)
		{
			if(CheckStatus(TRUE))
			{
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					ErrMsgDlg(STDGNALM781);
					return;
				}
				ErrMessage(_T("Stopped by User"));
				return;
			}
			
			dStandbyTime = StandbyTime.PresentTime();
			if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
				break;
		}
	}
*/
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	gDeviceFactory.GetEocard()->jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
	//measure
	pEOCard->LaserOnOff(TRUE);
	nCount = 0;
	while(nCount < 20) // 2 sec
	{
		if(CheckStatus(TRUE))
		{
			pEOCard->LaserOnOff(FALSE);
			m_dlgMeasurement.ShowWindow(SW_HIDE);
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						ErrMsgDlg(STDGNALM781);
						return;
					}
				}
			}
			ErrMessage(_T("Stopped by User"));
			return;
		}
		::Sleep(100);
		MessageLoop();
		nCount++;
		m_dlgMeasurement.UpdateMeasurement(nCount);
	}
			

	for(int i = 0; i < 5; i++)
	{
		nCount = 0;
		while(nCount < 15) // 1.5 sec
		{
			if(CheckStatus(TRUE))
			{
				pEOCard->LaserOnOff(FALSE);
				m_dlgMeasurement.ShowWindow(SW_HIDE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
				if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
				{
					if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
					{
						if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
						{
							ErrMsgDlg(STDGNALM781);
							return;
						}
					}
				}
				ErrMessage(_T("Stopped by User"));
				return;
			}
			::Sleep(100);
			MessageLoop();
			nCount++;
			
			m_dlgMeasurement.UpdateMeasurement(20 + (nCount+15*i));
		}
		this->SendMessage(UM_DO_POWERMEASUREMENT);
		dMeasureResult += m_dMeasuredPower;
	}

	pEOCard->LaserOnOff(FALSE);
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun()  && m_bUserDummyOn)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				ErrMsgDlg(STDGNALM781);
				return;
			}
		}
	}
	dMeasureResult = dMeasureResult/5; 
		
#ifdef __TEST__
	dMeasureResult = 5.52;
#endif
	
	CString str;
	str.Format(_T("%.2f"), dMeasureResult);
	m_edtPowerResult.SetWindowText(str);
			
	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE)) 
	{
		ErrMsgDlg(STDGNALM417); 
		m_dlgMeasurement.ShowWindow(SW_HIDE);
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
		return;
	}

	// log
	strEvent = _T("Finished the process of measuring of laser power.");
	
	strInfo.Format(_T("Power Average = %f | Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Duty = %.1f um | AOM Delay = %.1f um | AOM Duty = %.1f um | Beam Path No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm | Duty Offset = %.1f um | AOM Delay Offset = %.1f um | AOM Duty Offset = %.1f um | Duty Compensation = %.1f um"),
		dMeasureResult, ToolData.dMinPower, ToolData.dMaxPower, ToolData.nFrequency, ToolData.dShotDuty[0], 
		ToolData.dShotAOMDelay[0], ToolData.dShotAOMDuty[0], ToolData.nMask, dZ1, dZ2,
		gBeamPathINI.m_sBeampath.dPowOffsetDuty, gBeamPathINI.m_sBeampath.dPowOffsetAomDelay,
		gBeamPathINI.m_sBeampath.dPowOffsetAomDuty, gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset);

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));


	pMotor->SetOutPort(PORT_POWER_METER, FALSE);

	m_dlgMeasurement.ShowWindow(SW_HIDE);


	return;
}

BOOL CPaneRecipeGenParameterNew::UpdateNewParam(SUBTOOLDATA subTool)
{
	ASSERT(gDeviceFactory.GetEocard() != NULL);
	FParameter fParam;
	gDeviceFactory.GetEocard()->GetParameter(&fParam);
	
	CString strData;
	fParam.Frequency = subTool.nFrequency;
	double dCurrent, dAOMDelay, dAOMDuty;
	int nThermalTrack;
	
	double dMaskDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
	double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subTool.nMask];
	double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subTool.nMask];
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		fParam.dDuty = 5000; // 50%
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;
		nThermalTrack = gProcessINI.m_sProcessPowerMeasure.nThermalTrack;		
		gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, fParam.Frequency, nThermalTrack);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;		
		fParam.dDuty = 5000; // 50%
	}
	else
	{
		fParam.dDuty = static_cast<unsigned short>(subTool.dShotDuty[0] * 100 + 0.5);
		fParam.dDuty += (dMaskDutyOffset) * 100 + dPowerDutyOffset * 100;
		
		dAOMDelay = subTool.dShotAOMDelay[0];
		dAOMDuty = subTool.dShotAOMDuty[0];
		fParam.dAOMDelay = dAOMDelay + dMaskAOMDelayOffset;
		fParam.dAOMDuty = dAOMDuty + dMaskAOMDutyOffset + dPowerDutyOffset;
		strData.Format(_T("%s"), subTool.cAOMFilePath);
		memcpy(fParam.cAOMFilePath, strData, strData.GetLength() + 1);
	}
	
	return gDeviceFactory.GetEocard()->SetParameter(&fParam, (dMaskAOMDutyOffset + dPowerDutyOffset), subTool.nMask);

}

LRESULT CPaneRecipeGenParameterNew::OnPowerMeasure(WPARAM wParam, LPARAM lParam)
{
	double dVal = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement->MeasuerPower();
	m_dMeasuredPower = dVal;
	
	return 1L;
}

void CPaneRecipeGenParameterNew::OnMoveVisionView()
{
	CRect rtPos;
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
//		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneRecipeGenParameterNew::OnSelchangeComboCamera()
{
	int nSel = m_cmbCam.GetCurSel();

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive( nSel, FALSE );

	pVision->OnCamChange( nSel );
	
	pVision->OnLive( nSel, TRUE );

}
void CPaneRecipeGenParameterNew::OnButtonPowerStop()
{
	m_bPowerStop = TRUE;
}

BOOL CPaneRecipeGenParameterNew::CheckStatus(BOOL bPower)
{
	if(bPower)
		return m_bPowerStop;
	else
		return m_bStop;
}

void CPaneRecipeGenParameterNew::CheckAnyDoPrework()
{

}

void CPaneRecipeGenParameterNew::StopProcess()
{
	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Shot stop Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot stop Failure"));
#endif
		}
		m_StandbyTime.Finish();
	}
}
void CPaneRecipeGenParameterNew::OnChnageEditMarkingSize()
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	m_edtFontSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal <= 0)
	{
		ErrMessage(_T("Marking Size > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return;
	}

	if(m_nToolIndex == -1)
		return;
	 
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	m_edtFontSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nMarkingSize != nTempVal)
	{
		strTemp.Format(_T("| MarkingSize = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nMarkingSize = nTempVal;

	m_pToolCode[nListIndex] =  pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC is changed. "));
			else
				strMessage.Format(_T("One Hole Param. is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}
void CPaneRecipeGenParameterNew::OnChnageEditLotID()
{
}

void CPaneRecipeGenParameterNew::OnKillfocusEditLotId() 
{
	// TODO: Add your control notification handler code here
/*	CString str;
	m_edtLotID.GetWindowText(str);
	int nLeng;
	nLeng = str.GetLength();
	if(nLeng < 9)
		return;
	TCHAR cFirst2[2];
	cFirst2[0] = str.GetAt(0);
	cFirst2[1] = str.GetAt(1);
	
	if(((cFirst2[0] >= 65 && cFirst2[0] <= 90) || (cFirst2[0] >= 97 && cFirst2[0] <= 122)) &&
		((cFirst2[0] >= 65 && cFirst2[0] <= 90) || (cFirst2[0] >= 97 && cFirst2[0] <= 122)))
	{
		str = str.Right(str.GetLength() - 2);
	}
	
	m_edtLotID.SetWindowText(str);

	strcpy_s(gDProject.m_szLotId, str);
	*/
}
void CPaneRecipeGenParameterNew::OnKillfocusEditMarkingSize()
{
	return;

	int nTempVal;
	CString str, strMessage, strInfo, strTemp;
	
	m_edtFontSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal <= 0)
	{
		ErrMessage(_T("Marking Size > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return;
	}
	
	if(m_nToolIndex == -1)
		return;
	
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	m_edtFontSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nMarkingSize != nTempVal)
	{
		strTemp.Format(_T("| MarkingSize = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nMarkingSize = nTempVal;
	
	m_pToolCode[nListIndex] =  pToolCode;
	
	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC is changed. "));
			else
				strMessage.Format(_T("One Hole Param. is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}
	
	return ;
}


void CPaneRecipeGenParameterNew::SetFirstSubShot(SUBTOOLDATA& subData)
{
	subData.dShotDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[subData.nMask];
	subData.dShotAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[subData.nMask];
	subData.dShotAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[subData.nMask];
}

void CPaneRecipeGenParameterNew::ChangeLotID(CString strLotID)
{
	m_edtLotID.SetWindowText(strLotID);
}
void CPaneRecipeGenParameterNew::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}


BOOL CPaneRecipeGenParameterNew::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Recipe_Parameter) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

BOOL CPaneRecipeGenParameterNew::ParameterOpen(BOOL bComSol)
{
	CString strLayUpCode, strMaterialGroup, strMaterialMaker, strMaterialKind, strMaterialThick, strLayer, strPPGThick, strDongbakThick, strCompRecipeFile, strSoldRecipeFile, strRecipePrj;
	CString strFile;

	CString strProcessCode, strBackwardLevel, strCopperThick, strCustomerCode, strPrevProcessCode;

	strFile.Format(_T("%s"),gEasyDrillerINI.m_clsDirPath.GetParameterDir());

	strLayer = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCurrentProcess;
	strLayUpCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLayUpCode;      // Type
	strMaterialGroup = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialGroup; 	// CCL/PPG
	strMaterialMaker = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialMaker;  // ��ü��
	strMaterialKind = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialKind; 	// ��������
	strMaterialThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialThick; 	// ����β�
	strPPGThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strPPGThick; 	// ppg�β�
	strDongbakThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDongbakThick; 	// ���ڵβ�
	
	strCompRecipeFile = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCompRecipeFile; 	// Comp Recipe Name
	strSoldRecipeFile = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strSoldRecipeFile; // Sold Recipe Name
	
	strRecipePrj = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePrj; // Sold Recipe Name
	
#ifdef __2016_KUNSAN__	
	strProcessCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProcessCode; // Process Code
	strBackwardLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBackwardLevel; // backward Level
	strCopperThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCopperThick; // copper Thick
	strCustomerCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCustomerCode; // Customer Code
	strPrevProcessCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strPrevProcessCode; // Customer Code
#endif

	int nLength = strRecipePrj.GetLength();
#ifdef __TEST__
	strLayUpCode = _T("00FN");
	strMaterialGroup = _T("PREPREG");
	strMaterialMaker = _T("EMC");
	strMaterialKind = _T("GR(FR4)");
	strMaterialThick = _T("0.06");
#endif
#ifndef __2016_KUNSAN__
	strLayUpCode = strLayUpCode.Mid(2,2);

	if(!gProcessINI.m_sProcessSystem.bUseNewParameter3)
	{
		strFile += strLayer + _T("_");
		if(nLength == 13)
		{
			strFile += strRecipePrj.Right(2) + _T("_");
		}

		strFile += strLayUpCode + _T("_");
		strFile += strMaterialMaker + _T("_");
		strFile += strPPGThick + _T("_");
		strFile += strMaterialGroup + _T("_");
		strFile += strMaterialKind + _T("_");
		strFile += strDongbakThick + _T("_");

		if(bComSol == 0)
			strFile += _T("COMP.pen");
		else
			strFile += _T("SOLDER.pen");

		strFile.Replace(_T("__"),_T("_"));

	}
	else
	{
		if(bComSol == 0)
		{
			strFile += strCompRecipeFile;
			strFile += _T(".pen");
		}
		else
		{
			strFile += strSoldRecipeFile; 
			strFile += _T(".pen");
		}
	}
#else
	strFile += strProcessCode + _T("_");
	strFile += strBackwardLevel + _T("_");
	strFile += strMaterialMaker + _T("_");
	strFile += strMaterialThick + _T("_");
	strFile += strMaterialGroup + _T("_");

	strFile += strLayUpCode + _T("_");
	strFile += strCopperThick + _T("_");
	strFile += strMaterialKind + _T("_");
	strFile += strCustomerCode + _T("_");
	strFile += strPrevProcessCode + _T("_");
	
	if(bComSol == 0)
		strFile += _T("COMP.pen");
	else
		strFile += _T("SOLDER.pen");

	strFile.Replace(_T("__"),_T("_"));
#endif	
	CString strMessage;
	strMessage.Format(_T("Pen file ( %s ) is opend"), strFile);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(strFile, CFile::modeRead))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::load);
		CToolCodeList* pToolCode;
		//CToolCodeList* pToolCode2;
		int bUseToolBackup[MAX_TOOL_NO];
		int nRefToolNo[MAX_TOOL_NO];
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			bUseToolBackup[i] = m_pToolCode[i]->m_bUseTool;
			nRefToolNo[i] = m_pToolCode[i]->m_nRefToolNo;
		}
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			pToolCode = m_pToolCode[i];
	//		bUseToolBackup[i] = m_pToolCode[i]->m_bUseTool;

			if(!pToolCode->LoadFile10000(ar, 10032, FALSE, TRUE))
			{
				file.Close();
				return FALSE;
			}

			if((pToolCode->m_nRefToolNo != nRefToolNo[i]) || (pToolCode->m_bUseTool == FALSE && bUseToolBackup[i]))
			{
				CString strMsg;
				strMsg.Format(_T("%d Tool Parameter not match"), i);
				ErrMessage(strMsg);
			}

			//for(int j = 0; j < MAX_TOOL_NO; j++)
			//{
			//	pToolCode2 = m_pToolCode[j];
			//	if(nRefToolNo[j] == pToolCode->m_nRefToolNo)
			//	{
			//		if(!m_pToolCode[j]->m_bUseTool && !bUseToolBackup[i])
			//		{
			//			continue;
			//		}
			//		
			//		pToolCode->m_nToolNo = j;
			//		pToolCode2->m_nRefToolNo = nRefToolNo[j];
			//		//pToolCode2->m_nToolColor = pToolCode->m_nToolColor;
			//		//pToolCode2->m_nMarkingSize = pToolCode->m_nMarkingSize;
			//		//pToolCode = pToolCode2->m_nToolNo;
			//		//pToolCode2 = pToolCode; 


			//		SUBTOOLDATA subData;
			//		POSITION pos = pToolCode2->m_SubToolData.GetHeadPosition();
			//		if(pos)
			//		{
			//			subData = pToolCode2->m_SubToolData.GetAt(pos);
			//		}

			//		SUBTOOLDATA subDataOpen;
			//		POSITION pos2 = pToolCode->m_SubToolData.GetHeadPosition();
			//		if(pos2)
			//		{
			//			subDataOpen = pToolCode->m_SubToolData.GetAt(pos2);
			//		}
			//		subData = subDataOpen;

			//		pToolCode2->m_SubToolData.SetAt(pos,subData);
			//		//pToolCode->m_SubToolData.SetAt(pos2,subData);
			//		/*
			//		m_pProject->m_pToolCode[j]->m_SubToolData.RemoveAll();
			//		if( bUseToolBackup[j])
			//			AddSubToolToTool(j, i, pToolCode);
			//		break;*/
			//	}
			//}

			/*if(bUseToolBackup[i] &&nRefToolNo[i] != pToolCode->m_nRefToolNo)
			{
				file.Close();
				return FALSE;			
			}*/

#ifdef __KUNSAN_SAMSUNG_LARGE__
			pToolCode->GetDutyOffsetfromMDB();
#endif
			pToolCode->m_bUseTool = bUseToolBackup[i];
		}

	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH

	file.Close();
	
//	if(!ChangeDataMain(sel))
//		return;
	UpdateList(m_nToolIndex, -1);
	strcpy_s(m_szToolName, strFile);
	ChangeDisplay(m_nToolIndex, m_nSubIndex);
	CString str;
	str.Format(_T("%s"), m_szToolName);
	m_edtToolPath.SetWindowText(str);
	m_ctrTreeTool.SetFocus();
	
	return TRUE;
}

void CPaneRecipeGenParameterNew::AddSubToolToTool(int nToolNo, int nSelectTool,CToolCodeList* pToolCodeList ) 
{
	int nTempVal = 0;
	double dTempVal = 0;

	CString str, strMessage, strInfo, strTemp;
	
	SUBTOOLDATA subData;
	POSITION pos = gDProject.m_pToolCode[nToolNo]->m_SubToolData.GetHeadPosition();
	BOOL bUseSubData = FALSE;
	while(pos)
	{
		subData = gDProject.m_pToolCode[nToolNo]->m_SubToolData.GetNext(pos);
		bUseSubData = TRUE;
	}

	SUBTOOLDATA subDataOpen;
	POSITION pos2 = pToolCodeList->m_SubToolData.GetHeadPosition();
	while(pos2)
	{
		subDataOpen = pToolCodeList->m_SubToolData.GetNext(pos);
	}


	if(!bUseSubData)
	{
		subData = subDataOpen;
	}
	else
	{
		subData = subDataOpen;

		m_pProject->m_pToolCode[nToolNo]->m_SubToolData.RemoveAll();
		//subData.nMask = nSelectTool;
	}
	m_pProject->m_pToolCode[nToolNo]->m_SubToolData.AddTail(subData);
}

void CPaneRecipeGenParameterNew::OnCheckUseBarcodeLineDrill() 
{
	UpdateData(TRUE);
	m_bUseBarcodeLineDrill = m_chkUseBarcodeLineDrill.GetCheck();

	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.bBarcodeLineDrill = m_bUseBarcodeLineDrill;
	
	pToolCode->m_SubToolData.SetAt(pos,subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
}

void CPaneRecipeGenParameterNew::OnSelChangeCombobBarcodeMatrix() 
{
//	double dTempVal;
	CString str;
	
	if(m_nToolIndex == -1)
		return ;
	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == m_nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}
	
	if(i == -1) return;
	
	if(pos == NULL)
		return;
	
	subData = pToolCode->m_SubToolData.GetAt(pos);	
	
	subData.nMatrix =  m_cmbBarcodeMatrix.GetCurSel();
	
	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;

	if(m_bGlobalParam)
	{
		if(!gVariable.SaveGlobalTool())
		{
			ErrMsgDlg(STDGNALM111);
		}
	}
	
}



void CPaneRecipeGenParameterNew::OnBnClickedButtonOpenBeampathTable()
{


	CDlgBeamPathTable dlg;

	dlg.SetBeamPath(gBeamPathINI.m_sBeampath);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}


void CPaneRecipeGenParameterNew::OnBnClickedButtonOpenShotTable()
{
	CDlgShotTable dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}

void CPaneRecipeGenParameterNew::OnChnageEditTextHolePitch()
{
	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	m_edtTextHolePitch.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal <= 0)
	{
		ErrMessage(_T("Text Hole Pitch > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return;
	}

	if(m_nToolIndex == -1)
		return;

	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	m_edtTextHolePitch.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nTextHolePitch != nTempVal)
	{
		strTemp.Format(_T("| MarkingSize = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nTextHolePitch = nTempVal;

	m_pToolCode[nListIndex] =  pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC is changed. "));
			else
				strMessage.Format(_T("One Hole Param. is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}

void CPaneRecipeGenParameterNew::OnKillfocusEditTextHolePitch()
{
	return;

	int nTempVal;
	CString str, strMessage, strInfo, strTemp;

	m_edtTextHolePitch.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal <= 0)
	{
		ErrMessage(_T("Text Hole Pitch > 0 um"));
		GetDlgItem( IDC_EDIT_SIZE )->SetFocus();
		return;
	}

	if(m_nToolIndex == -1)
		return;

	int nListIndex = GetUseToolIndex(m_nToolIndex);
	if(nListIndex == -1)
		return;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	m_edtTextHolePitch.GetWindowText(str);
	nTempVal = atoi(str);
	if(pToolCode->m_nTextHolePitch != nTempVal)
	{
		strTemp.Format(_T("| TextHolePitch = %d"), nTempVal);
		strInfo += strTemp;
	}
	pToolCode->m_nTextHolePitch = nTempVal;

	m_pToolCode[nListIndex] =  pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
		if(m_bGlobalParam)
		{
			if(!gVariable.SaveGlobalTool())
			{
				ErrMsgDlg(STDGNALM111);
			}
			if(pToolCode->m_nToolNo == 0)
				strMessage.Format(_T("AGC is changed. "));
			else
				strMessage.Format(_T("One Hole Param. is changed. "));
		}
		else
		{
			strMessage.Format(_T("Tool %d is changed. "), nListIndex);
		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}

	return ;
}