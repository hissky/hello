// DlgInformationBox.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgInformationBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInformationBox dialog


CDlgInformationBox::CDlgInformationBox(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInformationBox::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInformationBox)
	m_strContent = _T("");
	m_strTitle = _T("");
	//}}AFX_DATA_INIT
}


void CDlgInformationBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInformationBox)
	DDX_Text(pDX, IDC_STC_CONTENT, m_strContent);
	DDX_Text(pDX, IDC_STC_TITLE, m_strTitle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInformationBox, CDialog)
	//{{AFX_MSG_MAP(CDlgInformationBox)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInformationBox message handlers
void CDlgInformationBox::SetDlgFont()
{
	m_dlgFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_STC_TITLE)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STC_CONTENT)->SetFont(&m_dlgFont);

	m_btnFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDOK)->SetFont(&m_btnFont);
}

BOOL CDlgInformationBox::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetDlgFont();

	return TRUE;
}

void CDlgInformationBox::SetTitleContent(int nIdTitle, LPCTSTR strContent)
{
	m_strTitle.Empty();
	m_strTitle.LoadString(nIdTitle);

	m_strContent.Empty();
	m_strContent = strContent;
}

void CDlgInformationBox::SetTitleContent(int nIdTitle, int nIdContent)
{
	m_strTitle.Empty();
	m_strTitle.LoadString(nIdTitle);

	m_strContent.Empty();
	m_strContent.LoadString(nIdContent);
}

void CDlgInformationBox::SetTitleContent(LPCTSTR strTitle, int nIdContent)
{
	m_strTitle.Empty();
	m_strTitle = strTitle;

	m_strContent.Empty();
	m_strContent.LoadString(nIdContent);
}

void CDlgInformationBox::SetTitleContent(LPCTSTR strTitle, LPCTSTR strContent)
{
	m_strTitle.Empty();
	m_strTitle = strTitle;

	m_strContent.Empty();
	m_strContent = strContent;
}

