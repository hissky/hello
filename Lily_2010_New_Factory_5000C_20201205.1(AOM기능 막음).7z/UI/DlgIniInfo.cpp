// INIINFO.cpp : implementation file
//

#include "stdafx.h"
#include "easydriller.h"
#include "DlgIniInfo.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "PaneProcessSetupOption.h"
#include "..\model\DBeampathINI.h"
#include "..\EasyDrillerDlg.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "..\DEVICE\HDeviceFactory.h"
#include"..\MODEL\DTemperCompensation.h"
#include "DlgToolHoleSort.h"
#include "..\device\DeviceMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgIniInfo dialog


CDlgIniInfo::CDlgIniInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIniInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIniInfo)
	//}}AFX_DATA_INIT
	m_bScannerChange = FALSE;
}


void CDlgIniInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIniInfo)
	DDX_Control(pDX, IDC_EStop, m_edtEStop);
	DDX_Control(pDX, IDC_PowerStep, m_edtPowerStep);
	DDX_Control(pDX, IDC_ConpensationLimitCount, m_edtConpensationLimitCount);
	DDX_Control(pDX, IDC_COMPENLIMIT_TOL, m_edtCompensationLimitTol);
	DDX_Control(pDX, IDC_CompensationDutyPerwatt, m_edtCompensationDutyPerWatt);
	DDX_Control(pDX, IDC_FidImgSaveData, m_edtFidImgSaveData);
	DDX_Control(pDX, IDC_NoSortLine, m_edtNoSortLine);
	DDX_Control(pDX, IDC_NoSortHole, m_edtNoSortHole);
	DDX_Control(pDX, IDC_NoSortArea, m_edtNoSortArea);
	DDX_Control(pDX, IDC_XYOrder, m_edtXYOrder);
	DDX_Control(pDX, IDC_UseInnerOCRFont, m_edtUseInnerOCRFont);
	DDX_Control(pDX, IDC_TextRefMode, m_edtTextRefMode);
	DDX_Control(pDX, IDC_TextGap, m_edtTextGap);
	DDX_Control(pDX, IDC_CameraPixelY, m_edtCameraPixelY);
	DDX_Control(pDX, IDC_CameraPixelX, m_edtCameraPixelX);
	DDX_Control(pDX, IDC_HighFOVY, m_edtHighFOVY);
	DDX_Control(pDX, IDC_HighFOVX, m_edtHighFOVX);
	DDX_Control(pDX, IDC_LowFOVY, m_edtLowFOVY);
	DDX_Control(pDX, IDC_LowFOVX, m_edtLowFOVX);
	DDX_Control(pDX, IDC_CalGridMode, m_edtCalGridMode);
	DDX_Control(pDX, IDC_CalGridDelay, m_edtCalGridDelay);
	DDX_Control(pDX, IDC_AcceptScore, m_edtAcceptScore);
	DDX_Control(pDX, IDC_RESULTSCORE, m_edtResultScore);
	DDX_Control(pDX, IDC_EXPOSURE, m_edtExposure);
	DDX_Control(pDX, IDC_FID_FIND_EXPOSURE, m_edtFidFindExposure);
	DDX_Control(pDX, IDC_BLOB, m_edtBlob);
	DDX_Control(pDX, IDC_RotateHoleAcceptScore, m_edtRotateHoleAcceptScore);
	DDX_Control(pDX, IDC_AcceptEdgeScore, m_edtAcceptEdgeScore);
	DDX_Control(pDX, IDC_EocardDownCount, m_edtEocardDownCount);
	DDX_Control(pDX, IDC_ShotDrillType, m_edtShotDrillType);
	DDX_Control(pDX, IDC_MinShotTime, m_edtMinShotTime);
	DDX_Control(pDX, IDC_MinCycleTime, m_edtMinCycleTime);
	DDX_Control(pDX, IDC_CHILLER_CH1, m_edtChillerCH1);
	DDX_Control(pDX, IDC_CHILLER_CH2, m_edtChillerCH2);


	
	DDX_Control(pDX, IDC_EDIT_DUTY_LIMIT, m_edtDutyLimit);

	DDX_Control(pDX, IDC_VACUUM_OFFSET_MASTER, m_edtVacOffsetMaster);
	DDX_Control(pDX, IDC_VACUUM_OFFSET_SLAVE, m_edtVacOffsetSlave);
	DDX_Control(pDX, IDC_VACUUM_OFFSET_DUST, m_edtVacOffsetDust);
	DDX_Control(pDX, IDC_CHECK_LPC_ERROR, m_edtCheckLPCError);
	DDX_Control(pDX, IDC_LOG_LPC_DETAIL, m_edtLogDetail);
	DDX_Control(pDX, IDC_LPC_MIN_TOL, m_edtLPCMinTol);
	DDX_Control(pDX, IDC_LPC_MAX_TOL, m_edtLPCMaxTol);
	DDX_Control(pDX, IDC_LPC_START_TOL, m_edtLPCStartTolPercent);
	DDX_Control(pDX, IDC_LPC_START_SKIP_COUNT, m_edtLPCStartSkipCount);
	

	

	DDX_Control(pDX, IDC_FiducialFindType, m_edtFiducialFindType);
	DDX_Control(pDX, IDC_LowCalArea, m_edtLowCalArea);
	DDX_Control(pDX, IDC_HighCalArea, m_edtHighCalArea);
	DDX_Control(pDX, IDC_PowerMeasurementSSizeY, m_edtPowerMeasurementSSizeY);
	DDX_Control(pDX, IDC_PowerMeasurementSSizeX, m_edtPowerMeasurementSSizeX);
	DDX_Control(pDX, IDC_PowerMeasurementMSizeY, m_edtPowerMeasurementMSizeY);
	DDX_Control(pDX, IDC_PowerMeasurementMSizeX, m_edtPowerMeasurementMSizeX);
	DDX_Control(pDX, IDC_OriginFieldSizeX, m_edtOriginFieldSizeX);
	DDX_Control(pDX, IDC_UseBarcodeReader, m_edtUseBarcodeReader);
	
	DDX_Control(pDX, IDC_USE_SPEED_UP, m_edtUseSpeedUp);
	DDX_Control(pDX, IDC_USE_ALL_FID_FIND, m_edtUseAllFidFind);
	DDX_Control(pDX, IDC_USE_DETAIL_LOG, m_edtUseDetailLog);
	DDX_Control(pDX, IDC_USE_FIX_OCR_DIRECTION, m_edtUseFixOCRDirection);


	DDX_Control(pDX, IDC_ShortLineLength, m_edtShortLineLength);
	DDX_Control(pDX, IDC_ShortLineDutyOffset, m_edtShortLineDutyOffset);
	DDX_Control(pDX, IDC_EXCELLONOPENAXIS, m_edtExcellonOpenAxis);
	DDX_Control(pDX, IDC_SCANNERAXISTYPE2, m_edtScannerAxisType2);
	DDX_Control(pDX, IDC_SCANNERAXISTYPE, m_edtScannerAxisType);
	DDX_Control(pDX, IDC_OriginFieldSizeY, m_edtOriginFieldSizeY);
	DDX_Control(pDX, IDC_SCANNER_JUMP_DELAY, m_edtScannerJumpDelay);
	DDX_Control(pDX, IDC_EDIT_NO_USE_CHILLER_ALARM, m_edtNoUseChillerAlarm);
	DDX_Control(pDX, IDC_TableLimitMinX, m_edtTableLimitMinX);
	DDX_Control(pDX, IDC_TableLimitMinY, m_edtTableLimitMinY);
	DDX_Control(pDX, IDC_TableLimitMaxX, m_edtTableLimitMaxX);
	DDX_Control(pDX, IDC_TableLimitMaxY, m_edtTableLimitMaxY);
	DDX_Control(pDX, IDC_EDIT_3RD_DUMMY_TYPE, m_edt3rdDummyType);
	DDX_Control(pDX, IDC_EDIT_NO_USE_DIVIDE_UNIT, m_edtNoDivideUnit);
	DDX_Control(pDX, IDC_EDIT_USE_DUMMYSHOT_SCANCAL, m_edtUseDummyForSCal);
	DDX_Control(pDX, IDC_EDIT_MACHINE_NO, m_edtMachineNo);
	DDX_Control(pDX, IDC_EDIT_USE_IDLE_SHOT, m_edtUseIdleShot);
	DDX_Control(pDX, IDC_EDIT_REPEAT_IDLE_SHOT, m_edtIdleShotRepeat);
	DDX_Control(pDX, IDC_TEMPER_COMPENSATION_MODE, m_edtTemperCompensationMode);
	DDX_Control(pDX, IDC_TEMPER_MEASURE_MODE, m_edtTemperMeasureMode);
	DDX_Control(pDX, IDC_TEMPER_CONTRAST, m_edtTemperContrast);
	DDX_Control(pDX, IDC_TEMPER_BRIGHTNESS, m_edtTemperBrightness);
	DDX_Control(pDX, IDC_TEMPER_COMPENSATION_GRID_NO, m_edtTemperCompenGridNo);
	DDX_Control(pDX, IDC_TEMPER_DELTA_T, m_edtTemperDeltaT);
	DDX_Control(pDX, IDC_TEMPER_END_DELTA_T, m_edtTemperEndT);
	DDX_Control(pDX, IDC_TEMPER_TRANS_T, m_edtTemperTransT);
	DDX_Control(pDX, IDC_TEMPER_COMPENSATION_TIMEOUT_MIN, m_edtTemperCompenTimeoutMin);
	DDX_Control(pDX, IDC_TEMPER_COMPENSATION_REPEAT_NO, m_edtTemperCompenRepeatNo);
	DDX_Control(pDX, IDC_TEMPER_2D_LINEAR_MODE, m_edtTemper2DLinearMode);
	DDX_Control(pDX, IDC_TEMPER_MIN_T_LIMIT, m_edtTemperMinTLimit);
	DDX_Control(pDX, IDC_TEMPER_MAX_T_LIMIT, m_edtTemperMaxTLimit);
	DDX_Control(pDX, IDC_TEMPER_DIFFER_T_LIMIT, m_edtTemperDifferTLimit);
	DDX_Control(pDX, IDC_TEMPER_DELTA_T_LIMIT, m_edtTemperDetaTLimit);
	DDX_Control(pDX, IDC_TEMPER_MINUS_DELTA_T_LIMIT, m_edtTemperMinusDetaTLimit);
	DDX_Control(pDX, IDC_TEMPER_NOCHANGE_TIME_LIMIT_SEC, m_edtTemperTNoChangeTimeLimitSec);
	DDX_Control(pDX, IDC_TEMPER_DETAIL_LOG, m_edtTemperDetailLog);
	DDX_Control(pDX, IDC_TEMPER_SHORT_WAIT, m_edtTableMoveWaitT);
	DDX_Control(pDX, IDC_TEMPER_LONG_WAIT, m_edtLongWaitT);
	DDX_Control(pDX, IDC_TEMPER_VERIFY_MODE, m_edtVerifyMode); 
	DDX_Control(pDX, IDC_TEMPER_START_LM, m_edtStartLM);
	DDX_Control(pDX, IDC_TEMPER_LM_STEP, m_edtLMStep);
	DDX_Control(pDX, IDC_TEMPER_LM_STEP_NO, m_edtLMStepNo);
	DDX_Control(pDX, IDC_TEMPER_START_POWER, m_edtStartPower);
	DDX_Control(pDX, IDC_TEMPER_END_POWER, m_edtEndPower);
	DDX_Control(pDX, IDC_EDIT_SCHEDULE, m_edtSchedule);

	DDX_Control(pDX, IDC_RECIPE_SORT, m_edtRecipeSort);
	DDX_Control(pDX, IDC_CHECK_VISION_SIZE_ERROR, m_edtCheckVisionSizeError);
	DDX_Control(pDX, IDC_CHECK_USE_MARKING_DUAL_MODE, m_edtCheckUseMarkingDualMode);

	DDX_Control(pDX, IDC_CHECK_SLAVE_MEASURE_START, m_edtCheckSlaveMeasureStart);
	DDX_Control(pDX, IDC_CHECK_USE_FULL_SCHEDULING, m_edtCheckFullScheduling);


	DDX_Control(pDX, IDC_CHECK_NO_USE_TOPHAT, m_edtCheckNoUseTopHat);


	DDX_Control(pDX, IDC_EDIT_OPC_TIMEOUT, m_edtOPCTimeOut);
	DDX_Control(pDX, IDC_COMBO_LANGUAGE, m_cmbLanguage);
	DDX_Control(pDX, IDC_EDIT_OFFSET_MODE, m_edtFirstOffsetMode);
	DDX_Control(pDX, IDC_TEMPER_FIRE_COUNT_FOR_VISION_COMPEN1, m_edtTemperFireCountForVisionCompen);
	DDX_Control(pDX, IDC_TEMPER_FIRE_COUNT_FOR_VISION_COMPEN2, m_edtTemperFireCountForVisionCompen2);
	DDX_Control(pDX, IDC_TEMPER_FIRE_COUNT_FOR_VISION_COMPEN3, m_edtTemperFireCountForVisionCompen3);
	DDX_Control(pDX, IDC_TEMPER_FIRE_COUNT_FOR_VISION_COMPEN4, m_edtTemperFireCountForVisionCompen4);
	DDX_Control(pDX, IDC_TEMPER_FIRE_COUNT_FOR_VISION_COMPEN5, m_edtTemperFireCountForVisionCompen5);
	DDX_Control(pDX, IDC_TEMPER_COMPEN_REPEAT_LOT_COUNT, m_edtTemperCompenRepeatLotCount);
	DDX_Control(pDX, IDC_TEMPER_USE_EVERY_STEP_COMPEN, m_edtTemperCompenEveryPnl);
	DDX_Control(pDX, IDC_TEMPER_COMPEN_VERIFY_LOT_COUNT, m_edtTemperCompenVerifyLotCount);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgIniInfo, CDialog)
	//{{AFX_MSG_MAP(CDlgIniInfo)
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_OPEN_EXPLOERE, &CDlgIniInfo::OnBnClickedOpenExploere)
	ON_WM_CLOSE()
	ON_EN_CHANGE(IDC_TEMPER_NOCHANGE_TIME_LIMIT_SEC, &CDlgIniInfo::OnEnChangeTemperNochangeTimeLimitSec)
	ON_BN_CLICKED(IDC_OPEN_TEMPERTABLE, &CDlgIniInfo::OnBnClickedOpenTempertable)
	ON_BN_CLICKED(IDC_OPEN_TOOL_SORT, &CDlgIniInfo::OnBnClickedOpenToolSort)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIniInfo message handlers

BOOL CDlgIniInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here

	ShowInI();
	ToolTip();
	
#ifdef __NO_USE_OPC__
	GetDlgItem(IDC_EDIT_OPC_TIMEOUT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_OPC)->ShowWindow(SW_HIDE);
#endif
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}




void CDlgIniInfo::OnOk() 
{
	// TODO: Add your control notification handler code here
	CString str;

	if(!CheckData())
		return;
	
	m_edtScannerAxisType.GetWindowText(str);
	gSystemINI.m_sHardWare.nScannerAxisType = atoi((LPSTR)(LPCTSTR)str);

	m_edtScannerAxisType2.GetWindowText(str);
	gSystemINI.m_sHardWare.nScannerAxisType2= atoi((LPSTR)(LPCTSTR)str);

	m_edtExcellonOpenAxis.GetWindowText(str);
	gSystemINI.m_sHardWare.nExcellonOpenAxis= atoi((LPSTR)(LPCTSTR)str);

	m_edtShortLineDutyOffset.GetWindowText(str);
	gSystemINI.m_sHardWare.nShortLineDutyOffset= atoi((LPSTR)(LPCTSTR)str);

	m_edtShortLineLength.GetWindowText(str);
	gSystemINI.m_sHardWare.nShortLineLength= atoi((LPSTR)(LPCTSTR)str);

	m_edtUseBarcodeReader.GetWindowText(str);
	gSystemINI.m_sHardWare.nUseBarcodeReader= atoi((LPSTR)(LPCTSTR)str);

	m_edtOriginFieldSizeX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dOriginFieldSize.x= atof((LPSTR)(LPCTSTR)str);

	m_edtOriginFieldSizeY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dOriginFieldSize.y= atof((LPSTR)(LPCTSTR)str);

	m_edtPowerMeasurementMSizeX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x= atof((LPSTR)(LPCTSTR)str);

	m_edtPowerMeasurementMSizeY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y= atof((LPSTR)(LPCTSTR)str);

	m_edtPowerMeasurementSSizeX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x= atof((LPSTR)(LPCTSTR)str);

	m_edtPowerMeasurementSSizeY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y= atof((LPSTR)(LPCTSTR)str);

	m_edtLowCalArea.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nLowCalArea= atoi((LPSTR)(LPCTSTR)str);

	m_edtHighCalArea.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nHighCalArea= atoi((LPSTR)(LPCTSTR)str);

	m_edtFiducialFindType.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nFiducialFindType= 1; // HDI�� �����ϰ� ��� 1 atoi((LPSTR)(LPCTSTR)str);

	m_edtMinCycleTime.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nMinCycleTime= atoi((LPSTR)(LPCTSTR)str);

	m_edtMinShotTime.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nMinShotTime= atoi((LPSTR)(LPCTSTR)str);

	m_edtShotDrillType.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nShotDrillType= atoi((LPSTR)(LPCTSTR)str);

	m_edtChillerCH1.GetWindowText(str);
	gSystemINI.m_sSystemDevice.sChillerPort.dCH1 = atof((LPSTR)(LPCTSTR)str);

	m_edtChillerCH2.GetWindowText(str);
	gSystemINI.m_sSystemDevice.sChillerPort.dCH2 = atof((LPSTR)(LPCTSTR)str);
	
	m_edtDutyLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dDutyLimit = atof((LPSTR)(LPCTSTR)str);


	m_edtVacOffsetMaster.GetWindowText(str);
	gSystemINI.m_sSystemVacuum.dVacuumOffset = atof((LPSTR)(LPCTSTR)str);

	m_edtVacOffsetSlave.GetWindowText(str);
	gSystemINI.m_sSystemVacuum.dVacuumOffset2 = atof((LPSTR)(LPCTSTR)str);

	m_edtVacOffsetDust.GetWindowText(str);
	gSystemINI.m_sSystemVacuum.dSuctionHoodOffset = atof((LPSTR)(LPCTSTR)str);

	m_edtCheckLPCError.GetWindowText(str);
	gProcessINI.m_sProcessOption.bCheckLPCError = atoi((LPSTR)(LPCTSTR)str);
	
	m_edtLogDetail.GetWindowText(str);
	gProcessINI.m_sProcessOption.bLPCLogDetail = atoi((LPSTR)(LPCTSTR)str);

	m_edtLPCMinTol.GetWindowText(str);
	gSystemINI.m_sHardWare.dLPCMinTolerence = atof((LPSTR)(LPCTSTR)str);
	
	m_edtLPCMaxTol.GetWindowText(str);
	gSystemINI.m_sHardWare.dLPCMaxTolerence = atof((LPSTR)(LPCTSTR)str);

	m_edtLPCStartTolPercent.GetWindowText(str);
	gSystemINI.m_sHardWare.dLPCStartTolerencePercent = atof((LPSTR)(LPCTSTR)str);
	
	m_edtLPCStartSkipCount.GetWindowText(str);
	gSystemINI.m_sHardWare.nLPCStartSkipCount = atoi((LPSTR)(LPCTSTR)str);
	
	m_edtEocardDownCount.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nEocardDownCount= atoi((LPSTR)(LPCTSTR)str);

	m_edtAcceptScore.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dAcceptScore= atof((LPSTR)(LPCTSTR)str);

	m_edtResultScore.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dResultScore= atof((LPSTR)(LPCTSTR)str);

	m_edtExposure.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dExposure= atof((LPSTR)(LPCTSTR)str);

	m_edtFidFindExposure.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dFidFindExposure= atof((LPSTR)(LPCTSTR)str);

	m_edtBlob.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nBlob= atoi((LPSTR)(LPCTSTR)str);

	m_edtRotateHoleAcceptScore.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore= atof((LPSTR)(LPCTSTR)str);

	m_edtAcceptEdgeScore.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.dAcceptEdgeScore= atof((LPSTR)(LPCTSTR)str);

	m_edtEStop.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nEStop = 0;// ���� �ҷ� �ּ�ȭ�� ���� atoi((LPSTR)(LPCTSTR)str);

	m_edtCalGridDelay.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nCalGridDelay= atoi((LPSTR)(LPCTSTR)str);

	m_edtCalGridMode.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nCalGridMode= atoi((LPSTR)(LPCTSTR)str);

	m_edtLowFOVX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dLowFOVX= atof((LPSTR)(LPCTSTR)str);

	m_edtLowFOVY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dLowFOVY= atof((LPSTR)(LPCTSTR)str);

	m_edtHighFOVX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dHighFOVX= atof((LPSTR)(LPCTSTR)str);

	m_edtHighFOVY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dHighFOVY= atof((LPSTR)(LPCTSTR)str);

	m_edtCameraPixelX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nCameraPixelX= atoi((LPSTR)(LPCTSTR)str);

	m_edtCameraPixelY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nCameraPixelY= atoi((LPSTR)(LPCTSTR)str);

	m_edtTextGap.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dTextGap= atof((LPSTR)(LPCTSTR)str);

	m_edtTextRefMode.GetWindowText(str);
	gSystemINI.m_sSystemDevice.nTextRefMode= atoi((LPSTR)(LPCTSTR)str);

	m_edtUseInnerOCRFont.GetWindowText(str);
	gSystemINI.m_sSystemDevice.bUseInnerOCRFont= atoi((LPSTR)(LPCTSTR)str);

	m_edtXYOrder.GetWindowText(str);
	gProcessINI.m_sProcessCal.nXYOrder= atoi((LPSTR)(LPCTSTR)str);

	m_edtNoSortArea.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bNoSortArea= atoi((LPSTR)(LPCTSTR)str);

	m_edtNoSortHole.GetWindowText(str);
	gProcessINI.m_sProcessSystem.nNoSortHole= atoi((LPSTR)(LPCTSTR)str);

	m_edtNoSortLine.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bNoSortLine= atoi((LPSTR)(LPCTSTR)str);

	m_edtFidImgSaveData.GetWindowText(str);
	gProcessINI.m_sProcessFidFind.nFidImgSaveData= atoi((LPSTR)(LPCTSTR)str);

	m_edtConpensationLimitCount.GetWindowText(str);
	gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount= atoi((LPSTR)(LPCTSTR)str);

	m_edtCompensationLimitTol.GetWindowText(str);
	gProcessINI.m_sProcessPowerMeasure.nCompensationPowerSpecPercent= atoi((LPSTR)(LPCTSTR)str);

	m_edtCompensationDutyPerWatt.GetWindowText(str);
	gProcessINI.m_sProcessPowerMeasure.dCompensationDutyPerWatt= atoi((LPSTR)(LPCTSTR)str);

	m_edtPowerStep.GetWindowText(str);
	gProcessINI.m_sProcessPowerMeasure.dPowerStep= atof((LPSTR)(LPCTSTR)str);

	m_edtScannerJumpDelay.GetWindowText(str);
	gBeamPathINI.m_sBeampath.dScannerJumpDelay = atof((LPSTR)(LPCTSTR)str);

	m_edtNoUseChillerAlarm.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bNoUseChillerAlarm = atoi((LPSTR)(LPCTSTR)str);

	if(gProcessINI.m_sProcessSystem.bNoUseChillerAlarm == TRUE)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_NO_USE_CHILLER, TRUE);
	else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_NO_USE_CHILLER, FALSE);

	m_edtNoDivideUnit.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bNoDivideUnit = atoi((LPSTR)(LPCTSTR)str);

	m_edtUseDummyForSCal.GetWindowText(str);
	gProcessINI.m_sProcessScannerCal.bUseDummy = atoi((LPSTR)(LPCTSTR)str);

	m_edtMachineNo.GetWindowText(str);
	gSystemINI.m_sHardWare.nMachineNo = atoi((LPSTR)(LPCTSTR)str);

	m_edtIdleShotRepeat.GetWindowText(str);
	gProcessINI.m_sProcessAutoSetting.nIdleShotRepeatCount = atoi((LPSTR)(LPCTSTR)str);;

	m_edtTableLimitMinX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dTableLimitMinX = atof((LPSTR)(LPCTSTR)str);

	m_edtTableLimitMinY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dTableLimitMinY = atof((LPSTR)(LPCTSTR)str);

	m_edtTableLimitMaxX.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dTableLimitMaxX = atof((LPSTR)(LPCTSTR)str);

	m_edtTableLimitMaxY.GetWindowText(str);
	gSystemINI.m_sSystemDevice.dTableLimitMaxY = atof((LPSTR)(LPCTSTR)str);



	m_edtTemperCompensationMode.GetWindowText(str);
	gProcessINI.m_sProcessOption.bTemperCompensationMode = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperMeasureMode.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperMeasureMode = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperContrast.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperVerifyContrast = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperBrightness.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperVerifyBrightness = atof((LPSTR)(LPCTSTR)str);

	m_edtVerifyMode.GetWindowText(str);
	gProcessINI.m_sProcessOption.bTemperVerifyMode = atoi((LPSTR)(LPCTSTR)str);

	if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
		gProcessINI.m_sProcessOption.bTemperVerifyMode = !gProcessINI.m_sProcessOption.nTemperMeasureMode;

	m_edtTemperCompenGridNo.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenGridNo = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperDeltaT.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperDeltaT = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperEndT.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperEndT = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperTransT.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperTransT = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperCompenTimeoutMin.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenTimeoutMin = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperCompenRepeatNo.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenRepeatNo = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemper2DLinearMode.GetWindowText(str);
	gProcessINI.m_sProcessOption.bTemper2DLinearMode = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperMinTLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperMinTLimit = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperMaxTLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperMaxTLimit = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperDifferTLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperDifferTLimit = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperDetaTLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperDetaTLimit = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperMinusDetaTLimit.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperMinusDetaTLimit = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperTNoChangeTimeLimitSec.GetWindowText(str);
	gProcessINI.m_sProcessOption.dTemperTWaitScal = atof((LPSTR)(LPCTSTR)str);

	m_edtTemperDetailLog.GetWindowText(str);
	gProcessINI.m_sProcessOption.bTemperDetailLog = atoi((LPSTR)(LPCTSTR)str);

	m_edtTableMoveWaitT.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTableMoveWaitTimeMS = atoi((LPSTR)(LPCTSTR)str);

	m_edtLongWaitT.GetWindowText(str);
	gProcessINI.m_sProcessOption.nSBTemperLongWaitTime = atoi((LPSTR)(LPCTSTR)str);

	m_edtStartLM.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperStartDuty = atoi((LPSTR)(LPCTSTR)str);

	m_edtLMStep.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperStepDuty = atoi((LPSTR)(LPCTSTR)str);

	m_edtLMStepNo.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperDutyStepNo = atoi((LPSTR)(LPCTSTR)str);

	m_edtStartPower.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperStartPower = atoi((LPSTR)(LPCTSTR)str);

	m_edtEndPower.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperEndPower = atoi((LPSTR)(LPCTSTR)str);
	
	m_edtSchedule.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bUseScheduling = atoi((LPSTR)(LPCTSTR)str);

	m_edtUseSpeedUp.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bUseSpeedUp = atoi((LPSTR)(LPCTSTR)str);


	m_edtUseAllFidFind.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bUseAllFidFind = atoi((LPSTR)(LPCTSTR)str);

	m_edtUseFixOCRDirection.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bUseFixOCRDirection = atoi((LPSTR)(LPCTSTR)str);

	m_edtUseDetailLog.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bUseDetailLog = atoi((LPSTR)(LPCTSTR)str);

		m_edtCheckVisionSizeError.GetWindowText(str);
	gProcessINI.m_sProcessSystem.bCheckVisionSizeError = atoi((LPSTR)(LPCTSTR)str);
	
	m_edtCheckUseMarkingDualMode.GetWindowText(str);
	gProcessINI.m_sProcessOption.bMarkingDualMode = atoi((LPSTR)(LPCTSTR)str);

	m_edtCheckSlaveMeasureStart.GetWindowText(str);
	gProcessINI.m_sProcessOption.bSlaveMeasureStart = atoi((LPSTR)(LPCTSTR)str);

	m_edtCheckFullScheduling.GetWindowText(str);
	gProcessINI.m_sProcessOption.bFullScheduling = atoi((LPSTR)(LPCTSTR)str);
	

	m_edtCheckNoUseTopHat.GetWindowText(str);
	gProcessINI.m_sProcessOption.bNoUseTopHat = atoi((LPSTR)(LPCTSTR)str);

	m_edtOPCTimeOut.GetWindowText(str);
	gProcessINI.m_sProcessOption.nOPCTimeOut = atoi((LPSTR)(LPCTSTR)str);

	m_edtFirstOffsetMode.GetWindowText(str);
	gSystemINI.m_sHardWare.bFirstOffsetMode = atoi((LPSTR)(LPCTSTR)str);

	gSystemINI.m_sHardWare.nLanguageType = m_cmbLanguage.GetCurSel();

	m_edtTemperFireCountForVisionCompen.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperFireCountForVisionCompen2.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen2 = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperFireCountForVisionCompen3.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen3 = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperFireCountForVisionCompen4.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen4 = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperFireCountForVisionCompen5.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen5 = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperCompenRepeatLotCount.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperCompenEveryPnl.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTemperCompenEveryPnl = atoi((LPSTR)(LPCTSTR)str);

	m_edtTemperCompenVerifyLotCount.GetWindowText(str);
	gProcessINI.m_sProcessOption.nTempCompenVerifyLotCount = atoi((LPSTR)(LPCTSTR)str);

	OnOK();
	
	
}

void CDlgIniInfo::OnCancel() 
{
	// TODO: Add your control notification handler code here

	CDialog::OnCancel();
	
}


void CDlgIniInfo::ToolTip()
{

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_SCANNERAXISTYPE), "���ɳ� �� ���� ��");
	m_ToolTip.AddTool(GetDlgItem(IDC_SCANNERAXISTYPE2), "���ɳ� �� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_ShortLineDutyOffset), "cavity �������� ª�� ������ duty�� �ٸ��� �� �� �ִ� ��� (%)");
	m_ToolTip.AddTool(GetDlgItem(IDC_ShortLineLength), "���� ª�� ���� �Ǵ� ���� (���� um)");
	m_ToolTip.AddTool(GetDlgItem(IDC_OriginFieldSizeX), "Zero cal file ���� �ʵ��� X �� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_OriginFieldSizeY), "Zero cal file ���� �ʵ��� Y �� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_PowerMeasurementMSizeX), "power ������ ������ �������� �ʵ� ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_PowerMeasurementMSizeY), "power ������ ������ �������� �ʵ� ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_PowerMeasurementSSizeX), "power ������ ������ �������� �ʵ� ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_PowerMeasurementSSizeY), "power ������ ������ �������� �ʵ� ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_MinCycleTime), "cycle ���� �� �� ���ʵ忡 Ȧ�� ������ ���ٸ� �ð��� ���� �ð��� �ʿ��ϴ�.\nCycle ���� �ð��� ���⼭ ������ ������ ���� �� ���� �ȴ�. (ms)");
	m_ToolTip.AddTool(GetDlgItem(IDC_MinShotTime), "������ �������� �ּ� �ð�(us)");
	m_ToolTip.AddTool(GetDlgItem(IDC_AcceptScore), "VISION�� ���� ��� ���� (�ǵ���� ���Ϳ��� �ٽ� �ѹ� ã����) (0.8 �̻��ؾ� ��)");
	m_ToolTip.AddTool(GetDlgItem(IDC_RotateHoleAcceptScore), "�����̼� �ǵ���� ���� ���� VISION ��� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_AcceptEdgeScore), "vision �ǵ���� �������� ã�� �� ���� ������ (��ĳ�� ���������� �� ���� �����)");
	m_ToolTip.AddTool(GetDlgItem(IDC_LowFOVX), "ī�޶� FOV�� �ݵ�� �����ϰ� ���� �Ѵ�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_LowFOVY), "ī�޶� FOV�� �ݵ�� �����ϰ� ���� �Ѵ�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_HighFOVX), "ī�޶� FOV�� �ݵ�� �����ϰ� ���� �Ѵ�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_HighFOVY), "ī�޶� FOV�� �ݵ�� �����ϰ� ���� �Ѵ�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_CameraPixelX), "ī�޶� pixel �� ǥ��");
	m_ToolTip.AddTool(GetDlgItem(IDC_CameraPixelY), "ī�޶� pixel �� ǥ��");
	m_ToolTip.AddTool(GetDlgItem(IDC_CalGridDelay), "TABLE CALGRID ������ ���̺��� ���� ������ ���� SPEEP �Լ� ȣ��� ��밪");
	m_ToolTip.AddTool(GetDlgItem(IDC_CalGridMode), "1 : �Ŵ��� �������� Ȧ Ž�� �� 2nd�ʵ� xy.calibration ���Ϸ� ���� ��ġ�� ǥ���ϰ� �ȴ�. \n0 : Ķ�׸��尡 ��� �Ϸ�ǰ� �������� ����� �� ���� �ϴ� ���̴�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_TextGap), "���ڰ� ���� (���� : ���� �� * gap) (0 ~ 1)");
	m_ToolTip.AddTool(GetDlgItem(IDC_TextRefMode), "������Ʈ Ȧ ��ġ�������� �ؽ�Ʈ�� �����Ǵ� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_ConpensationLimitCount), "�Ŀ����� ��ǥġ���� ������Ű�� ���� Ƚ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_CompensationDutyPerwatt), "�Ŀ������� 1Watt �� Duty ��ȭ��");
	m_ToolTip.AddTool(GetDlgItem(IDC_PowerStep), "�Ŀ������ �Ŀ� ������ ");
	m_ToolTip.AddTool(GetDlgItem(IDC_LowCalArea), "�ڵ� ��ĳ�� ���� �� �� �˻� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_HighCalArea), "�ڵ� ��ĳ�� ���� �� �� �˻� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_NoSortArea), "SORT AREA ��� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_NoSortHole), "SORT HOLE ��� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_NoSortLine), "SORT LINE ��� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_EXCELLONOPENAXIS), "excellon ������ �ڵ� �ຯȯ (-1 : �� ��ȯ�� �Ｚ �������� ��)");
	m_ToolTip.AddTool(GetDlgItem(IDC_UseBarcodeReader), "���ڵ� �������� ������Ʈ�� ���� ������ ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_FiducialFindType), "HDI ó�� multi-fiducial�� ��ճ��� ����̸� 1 \n������ ���� ���� 0");
	m_ToolTip.AddTool(GetDlgItem(IDC_ShotDrillType), "step �������� burst, cycle ������ ��� ���� (���� : 0, ����� : 1)");
	m_ToolTip.AddTool(GetDlgItem(IDC_EocardDownCount), "EOCARD���� �ٿ��ϴ� Ƚ��");
	m_ToolTip.AddTool(GetDlgItem(IDC_EStop), "��� ���� ���� �� �ʵ带 �� �����ϰ� ������ ��� ������ ���� ( 1�̸� ��� ����, 0����õ��)");
	m_ToolTip.AddTool(GetDlgItem(IDC_XYOrder), "��ĳ�� ���� �� �� random, x , y ������ ���� (��ĳ�� ���� ����)");
	m_ToolTip.AddTool(GetDlgItem(IDC_FidImgSaveData), "�ǵ�� �̹��� ���� �Ⱓ");
	m_ToolTip.AddTool(GetDlgItem(IDC_UseInnerOCRFont), "Ư�� ���� OCR ��Ʈ�� ����ϴ� ��� 1 \n�׷��� ������ viahole�� TEXT.FNT�� �ε���");
	m_ToolTip.AddTool(GetDlgItem(IDOK),"���� ���� �մϴ�.");
	m_ToolTip.AddTool(GetDlgItem(IDC_CANCEL),"���");
	m_ToolTip.AddTool(GetDlgItem(IDC_SCANNER_JUMP_DELAY), "��ĳ�ʺ����� Jump Delay�� ������");
	m_ToolTip.AddTool(GetDlgItem(IDC_TableLimitMinX), "�������� �����ϴ� ���̺� �ּ� X ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_TableLimitMaxX), "�������� �����ϴ� ���̺� �ִ� X ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_TableLimitMinY), "�������� �����ϴ� ���̺� �ּ� Y ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_TableLimitMaxY), "�������� �����ϴ� ���̺� �ִ� Y ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_3RD_DUMMY_TYPE), "�������� �����ϴ� ���̺� �ִ� Y ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_SCHEDULE), "�����층 ���μ��� ��� ���� ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_TEMPER_CONTRAST), "�µ� ���� �� ���� ��忡�� Vision Contrast ����");
	m_ToolTip.AddTool(GetDlgItem(IDC_TEMPER_BRIGHTNESS), "�µ� ���� �� ���� ��忡�� Vision Brightness ����");

}

BOOL CDlgIniInfo::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(INI_Info) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	if(pMsg->wParam == VK_ESCAPE)
	{
		return TRUE;
	} 
	m_ToolTip.RelayEvent(pMsg);



	return CDialog::PreTranslateMessage(pMsg);
}

HBRUSH CDlgIniInfo::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if( GetDlgItem(IDC_SCANEER_AXIS)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_SHOT_LINE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_ORIGINAL_FIELD_SIZE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_POWER_FIELD_SIZE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_MIN_TIME)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_VISION_EXPOSURE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_CAMERA_FOV)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_LowFOV)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_HighFOV)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_CameraPixel)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_TABLE_CALGRID)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_TABLE_OFFSET)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_TABLE_LIMIT)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_TEMPER_LIMIT)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_TEMPER_COMPENSATION)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_DEFAULT_TEXT)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_POWER_CONPENSATION)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_SCANEER_CAL_AREA)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_DUMMY_TYPE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_IDLE_SHOT)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_CHILLER_SETTING)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_VACUUM_OFFSET)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_SORT)->GetSafeHwnd() == pWnd->m_hWnd)

		
			pDC->SetTextColor(RGB(0,0,255));
	
			// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgIniInfo::InitStaticControl()
{

	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_SCANEER_AXIS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_SCANEER_AXIS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_LINE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ORIGINAL_FIELD_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_FIELD_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MIN_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_EXPOSURE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAMERA_FOV)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LowFOV)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HighFOV)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CameraPixel)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_CALGRID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DEFAULT_TEXT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_CONPENSATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANEER_CAL_AREA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SORT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TEMPER_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TEMPER_COMPENSATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IDLE_SHOT)->SetFont( &m_fntStatic );
	

	
}

void CDlgIniInfo::ShowInI()
{
	CString str;
	
	str.Format(_T("%d"),gSystemINI.m_sHardWare.nScannerAxisType);
	m_edtScannerAxisType.SetWindowText(str);
	
	str.Format(_T("%d"),gSystemINI.m_sHardWare.nScannerAxisType2);
	m_edtScannerAxisType2.SetWindowText(str);
	
	str.Format(_T("%d"),gSystemINI.m_sHardWare.nExcellonOpenAxis);
	m_edtExcellonOpenAxis.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sHardWare.nShortLineDutyOffset);
	m_edtShortLineDutyOffset.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sHardWare.nShortLineLength);
	m_edtShortLineLength.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sHardWare.nUseBarcodeReader);
	m_edtUseBarcodeReader.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dOriginFieldSize.x);
	m_edtOriginFieldSizeX.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dOriginFieldSize.y);
	m_edtOriginFieldSizeY.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x);
	m_edtPowerMeasurementMSizeX.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y);
	m_edtPowerMeasurementMSizeY.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x);
	m_edtPowerMeasurementSSizeX.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y);
	m_edtPowerMeasurementSSizeY.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nLowCalArea);
	m_edtLowCalArea.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nHighCalArea);
	m_edtHighCalArea.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nFiducialFindType);
	m_edtFiducialFindType.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nMinCycleTime);
	m_edtMinCycleTime.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nMinShotTime);
	m_edtMinShotTime.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nShotDrillType);
	m_edtShotDrillType.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nEocardDownCount);
	m_edtEocardDownCount.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.sChillerPort.dCH1);
	m_edtChillerCH1.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.sChillerPort.dCH2);
	m_edtChillerCH2.SetWindowText(str);

	str.Format(_T("%.2f"),gProcessINI.m_sProcessOption.dDutyLimit);
	m_edtDutyLimit.SetWindowText(str);

	str.Format(_T("%.1f"),gSystemINI.m_sSystemVacuum.dVacuumOffset);
	m_edtVacOffsetMaster.SetWindowText(str);

	str.Format(_T("%.1f"),gSystemINI.m_sSystemVacuum.dVacuumOffset2);
	m_edtVacOffsetSlave.SetWindowText(str);

	str.Format(_T("%.1f"),gSystemINI.m_sSystemVacuum.dSuctionHoodOffset);
	m_edtVacOffsetDust.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessOption.bCheckLPCError);
	m_edtCheckLPCError.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessOption.bLPCLogDetail);
	m_edtLogDetail.SetWindowText(str);

	str.Format(_T("%.2f"),gSystemINI.m_sHardWare.dLPCMinTolerence);
	m_edtLPCMinTol.SetWindowText(str);
	
	str.Format(_T("%.2f"),gSystemINI.m_sHardWare.dLPCMaxTolerence);
	m_edtLPCMaxTol.SetWindowText(str);
	
	str.Format(_T("%.2f"),gSystemINI.m_sHardWare.dLPCStartTolerencePercent);
	m_edtLPCStartTolPercent.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sHardWare.nLPCStartSkipCount);
	m_edtLPCStartSkipCount.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dAcceptScore);
	m_edtAcceptScore.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dResultScore);
	m_edtResultScore.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dExposure);
	m_edtExposure.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dFidFindExposure);
	m_edtFidFindExposure.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nBlob);
	m_edtBlob.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore);
	m_edtRotateHoleAcceptScore.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
	m_edtAcceptEdgeScore.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nEStop);
	m_edtEStop.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nCalGridDelay);
	m_edtCalGridDelay.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nCalGridMode);
	m_edtCalGridMode.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dLowFOVX);
	m_edtLowFOVX.SetWindowText(str);
	
	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dLowFOVY);
	m_edtLowFOVY.SetWindowText(str);
	
	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dHighFOVX);
	m_edtHighFOVX.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dHighFOVY);
	m_edtHighFOVY.SetWindowText(str);
	
	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nCameraPixelX);
	m_edtCameraPixelX.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nCameraPixelY);
	m_edtCameraPixelY.SetWindowText(str);

	str.Format(_T("%.3f"),gSystemINI.m_sSystemDevice.dTextGap);
	m_edtTextGap.SetWindowText(str);

	str.Format(_T("%d"),gSystemINI.m_sSystemDevice.nTextRefMode);
	m_edtTextRefMode.SetWindowText(str);

	str.Format(_T("%d"), gSystemINI.m_sSystemDevice.bUseInnerOCRFont);
	m_edtUseInnerOCRFont.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nXYOrder);
	m_edtXYOrder.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessSystem.bNoSortArea);
	m_edtNoSortArea.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessSystem.nNoSortHole);
	m_edtNoSortHole.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessSystem.bNoSortLine);
	m_edtNoSortLine.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessFidFind.nFidImgSaveData);
	m_edtFidImgSaveData.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount);
	m_edtConpensationLimitCount.SetWindowText(str);

	str.Format(_T("%d"),gProcessINI.m_sProcessPowerMeasure.nCompensationPowerSpecPercent);
	m_edtCompensationLimitTol.SetWindowText(str);

	str.Format(_T("%.3f"),gProcessINI.m_sProcessPowerMeasure.dCompensationDutyPerWatt);
	m_edtCompensationDutyPerWatt.SetWindowText(str);
	

	str.Format(_T("%.3f"), gProcessINI.m_sProcessPowerMeasure.dPowerStep);
	m_edtPowerStep.SetWindowText(str);

	str.Format(_T("%.0f"), gBeamPathINI.m_sBeampath.dScannerJumpDelay);
	m_edtScannerJumpDelay.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bNoUseChillerAlarm);
	m_edtNoUseChillerAlarm.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bNoDivideUnit);
	m_edtNoDivideUnit.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessScannerCal.bUseDummy);
	m_edtUseDummyForSCal.SetWindowText(str);

	str.Format(_T("%d"), gSystemINI.m_sHardWare.nMachineNo);
	m_edtMachineNo.SetWindowText(str);

	str.Format(_T("%.3f"), gSystemINI.m_sSystemDevice.dTableLimitMinX);
	m_edtTableLimitMinX.SetWindowText(str);

	str.Format(_T("%.3f"), gSystemINI.m_sSystemDevice.dTableLimitMinY);
	m_edtTableLimitMinY.SetWindowText(str);

	str.Format(_T("%.3f"), gSystemINI.m_sSystemDevice.dTableLimitMaxX);
	m_edtTableLimitMaxX.SetWindowText(str);

	str.Format(_T("%.3f"), gSystemINI.m_sSystemDevice.dTableLimitMaxY);
	m_edtTableLimitMaxY.SetWindowText(str);



	str.Format(_T("%d"), gProcessINI.m_sProcessAutoSetting.nIdleShotRepeatCount);
	m_edtIdleShotRepeat.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bTemperCompensationMode);
	m_edtTemperCompensationMode.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperMeasureMode);
	m_edtTemperMeasureMode.SetWindowText(str);

	str.Format(_T("%.1f"), gProcessINI.m_sProcessOption.dTemperVerifyContrast);
	m_edtTemperContrast.SetWindowText(str);

	str.Format(_T("%.1f"), gProcessINI.m_sProcessOption.dTemperVerifyBrightness);
	m_edtTemperBrightness.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bTemperVerifyMode);
	m_edtVerifyMode.SetWindowText(str);
	
	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenGridNo);
	m_edtTemperCompenGridNo.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperDeltaT);
	m_edtTemperDeltaT.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperEndT);
	m_edtTemperEndT.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperTransT);
	m_edtTemperTransT.SetWindowText(str);
	
	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenTimeoutMin);
	m_edtTemperCompenTimeoutMin.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenRepeatNo);
	m_edtTemperCompenRepeatNo.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bTemper2DLinearMode);
	m_edtTemper2DLinearMode.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperMinTLimit);
	m_edtTemperMinTLimit.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperMaxTLimit);
	m_edtTemperMaxTLimit.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperDifferTLimit);
	m_edtTemperDifferTLimit.SetWindowText(str);
	
	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperDetaTLimit);
	m_edtTemperDetaTLimit.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperMinusDetaTLimit);
	m_edtTemperMinusDetaTLimit.SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessOption.dTemperTWaitScal);
	m_edtTemperTNoChangeTimeLimitSec.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bTemperDetailLog);
	m_edtTemperDetailLog.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTableMoveWaitTimeMS);
	m_edtTableMoveWaitT.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nSBTemperLongWaitTime);
	m_edtLongWaitT.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperStartDuty);
	m_edtStartLM.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperStepDuty);
	m_edtLMStep.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperDutyStepNo);
	m_edtLMStepNo.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperStartPower);
	m_edtStartPower.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperEndPower);
	m_edtEndPower.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bUseScheduling);
	m_edtSchedule.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bRecipeHoleSort);
	m_edtRecipeSort.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bUseSpeedUp);
	m_edtUseSpeedUp.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bUseAllFidFind);
	m_edtUseAllFidFind.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bUseFixOCRDirection);
	m_edtUseFixOCRDirection.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bUseDetailLog);
	m_edtUseDetailLog.SetWindowText(str);

		str.Format(_T("%d"), gProcessINI.m_sProcessSystem.bCheckVisionSizeError);//20170929
	m_edtCheckVisionSizeError.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bMarkingDualMode);//20170929
	m_edtCheckUseMarkingDualMode.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bSlaveMeasureStart);//20170929
	m_edtCheckSlaveMeasureStart.SetWindowText(str);


	str.Format(_T("%d"), gProcessINI.m_sProcessOption.bFullScheduling);//20170929
	m_edtCheckFullScheduling.SetWindowText(str);

		str.Format(_T("%d"), gProcessINI.m_sProcessOption.bNoUseTopHat);//20170929
	m_edtCheckNoUseTopHat.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nOPCTimeOut);
	m_edtOPCTimeOut.SetWindowText(str);

	str.Format(_T("%d"), gSystemINI.m_sHardWare.bFirstOffsetMode);
	m_edtFirstOffsetMode.SetWindowText(str);

	m_cmbLanguage.SetCurSel(gSystemINI.m_sHardWare.nLanguageType);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen);
	m_edtTemperFireCountForVisionCompen.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen2);
	m_edtTemperFireCountForVisionCompen2.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen3);
	m_edtTemperFireCountForVisionCompen3.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen4);
	m_edtTemperFireCountForVisionCompen4.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen5);
	m_edtTemperFireCountForVisionCompen5.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount);
	m_edtTemperCompenRepeatLotCount.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTemperCompenEveryPnl);
	m_edtTemperCompenEveryPnl.SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessOption.nTempCompenVerifyLotCount);
	m_edtTemperCompenVerifyLotCount.SetWindowText(str);
}

BOOL CDlgIniInfo::CheckData()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	
	CString str;
	int nTemp = 0;
	double dTemp =0.0;
	int  nVisionTemp = 0, nVisionTemp2 = 0, nVisionTemp3 = 0, nVisionTemp4 = 0;
	m_edt3rdDummyType.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || dTemp > 2)
	{
		ErrMessage( _T("Dummy Type is 0 or 1 or 2"));
		return FALSE;
	}

	m_edtScannerAxisType.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 7)
	{
		ErrMessage( _T("0 <= ScannerAxisType < 8"));
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nScannerAxisType != nTemp)
	{
		strTemp.Format(_T("| nScannerAxisType : %d "), nTemp);
		strMessage += strTemp;
		m_bScannerChange = TRUE;
	}

	m_edtScannerAxisType2.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 7)
	{
		ErrMessage( _T("0 <= nScannerAxisType2 < 8"));
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nScannerAxisType2 != nTemp)
	{
		strTemp.Format(_T("| nScannerAxisType2 : %d "), nTemp);
		strMessage += strTemp;
		m_bScannerChange = TRUE;
	}

	m_edtExcellonOpenAxis.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 7)
	{
		ErrMessage( _T("0 <= nExcellonOpenAxis < 8"));
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nExcellonOpenAxis != nTemp)
	{
		strTemp.Format(_T("| nExcellonOpenAxis : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtShortLineDutyOffset.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < -5 || nTemp > 5)
	{
		ErrMessage( _T("-5 <= nShortLineDutyOffset <= 5"));
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nShortLineDutyOffset != nTemp)
	{
		strTemp.Format(_T("| nShortLineDutyOffset : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtShortLineLength.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0)
	{
		ErrMessage( _T("0 <= nShortLineLength"));
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nShortLineLength != nTemp)
	{
		strTemp.Format(_T("| nShortLineLength : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtUseBarcodeReader.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.nUseBarcodeReader != nTemp)
	{
		strTemp.Format(_T("| nUseBarcodeReader : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtOriginFieldSizeX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= gSystemINI.m_sSystemDevice.dFieldSize.x)
	{
		ErrMessage( _T("FieldSize < OriginFieldSize"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dOriginFieldSize.x != dTemp)
	{
		strTemp.Format(_T("| dOriginFieldSize.x : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtOriginFieldSizeY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= gSystemINI.m_sSystemDevice.dFieldSize.x)
	{
		ErrMessage( _T("FieldSize < OriginFieldSize"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dOriginFieldSize.y != dTemp)
	{
		strTemp.Format(_T("| dOriginFieldSize.y : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtPowerMeasurementMSizeX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= 0)
	{
		ErrMessage( _T("0 < dPowerMeasurementMSize.x"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x != dTemp)
	{
		strTemp.Format(_T("| dPowerMeasurementMSize.x : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtPowerMeasurementMSizeY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= 0)
	{
		ErrMessage( _T("0 < dPowerMeasurementMSize.y"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y != dTemp)
	{
		strTemp.Format(_T("| dPowerMeasurementMSize.y : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtPowerMeasurementSSizeX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= 0)
	{
		ErrMessage( _T("0 < dPowerMeasurementSSize.x"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x != dTemp)
	{
		strTemp.Format(_T("| dPowerMeasurementSSize.x : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtPowerMeasurementSSizeY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp <= 0)
	{
		ErrMessage( _T("0 < dPowerMeasurementSSize.y"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y != dTemp)
	{
		strTemp.Format(_T("| dPowerMeasurementSSize.y : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtLowCalArea.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0)
	{
		ErrMessage( _T("0 <= nLowCalArea"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nLowCalArea != nTemp)
	{
		strTemp.Format(_T("| nLowCalArea : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtHighCalArea.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0)
	{
		ErrMessage( _T("0 <= nHighCalArea"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nHighCalArea != nTemp)
	{
		strTemp.Format(_T("| nHighCalArea : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtMinCycleTime.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0)
	{
		ErrMessage( _T("0 <= nMinCycleTime"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nMinCycleTime != nTemp)
	{
		strTemp.Format(_T("| nMinCycleTime : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtMinShotTime.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0)
	{
		ErrMessage( _T("0 <= nMinShotTime"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nMinShotTime != nTemp)
	{
		strTemp.Format(_T("| nMinShotTime : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtShotDrillType.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("nShotDrillType = 0 or 1"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nShotDrillType != nTemp)
	{
		strTemp.Format(_T("| nShotDrillType : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtEocardDownCount.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 500)
	{
		ErrMessage( _T("nEocardDownCount >= 500"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nEocardDownCount != nTemp)
	{
		strTemp.Format(_T("| nEocardDownCount : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtAcceptScore.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.6 || dTemp > 1)
	{
		ErrMessage( _T("0.6 <= dAcceptScore <= 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessFidFind.dAcceptScore != dTemp)
	{
		strTemp.Format(_T("| dAcceptScore : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtResultScore.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.6 || dTemp > 1)
	{
		ErrMessage( _T("0.6 <= ResultScore <= 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessFidFind.dResultScore != dTemp)
	{
		strTemp.Format(_T("| ResultScore : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtExposure.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessFidFind.dExposure != dTemp)
	{
		strTemp.Format(_T("| Vision Exposure : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtFidFindExposure.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessFidFind.dFidFindExposure != dTemp)
	{
		strTemp.Format(_T("| Fid Find Vision Exposure : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtBlob.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 255)
	{
		ErrMessage( _T("1 <= Vision Blob <= 255"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nBlob != nTemp)
	{
		strTemp.Format(_T("| Vision Blob : %d "), nTemp);
		strMessage += strTemp;
	}
	m_edtRotateHoleAcceptScore.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.6 || dTemp > 1)
	{
		ErrMessage( _T("0.6 <= dRotateHoleAcceptScore <= 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore != dTemp)
	{
		strTemp.Format(_T("| dRotateHoleAcceptScore : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtAcceptEdgeScore.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.6 || dTemp > 1)
	{
		ErrMessage( _T("0.6 <= dAcceptEdgeScore <= 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore != dTemp)
	{
		strTemp.Format(_T("| dAcceptEdgeScore : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtEStop.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("nEStop = 0 or 1"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nEStop != nTemp)
	{
		strTemp.Format(_T("| nEStop : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtCalGridDelay.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 100)
	{
		ErrMessage( _T("100 <= nCalGridDelay"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nCalGridDelay != nTemp)
	{
		strTemp.Format(_T("| nCalGridDelay : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtCalGridMode.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("nCalGridMode = 0 or 1"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nCalGridMode != nTemp)
	{
		strTemp.Format(_T("| nCalGridMode : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtNoUseChillerAlarm.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("bNoUseChillerAlarm = 0 or 1"));
		return FALSE;
	}

	m_edtNoDivideUnit.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("bNoDivideUnit = 0 or 1"));
		return FALSE;
	}

	m_edtUseDummyForSCal.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("UseDummyForSCal = 0 or 1"));
		return FALSE;
	}

	if(gProcessINI.m_sProcessSystem.bNoUseChillerAlarm != nTemp)
	{
		strTemp.Format(_T("| bNoUseChillerAlarm : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtMachineNo.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.nMachineNo != nTemp)
	{
		strTemp.Format(_T("| MachineNo : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtLowFOVX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1)
	{
		ErrMessage( _T("0.1 <= dLowFOVX"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dLowFOVX != dTemp)
	{
		strTemp.Format(_T("| dLowFOVX : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtLowFOVY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1)
	{
		ErrMessage( _T("0.1 <= dLowFOVY"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dLowFOVY != dTemp)
	{
		strTemp.Format(_T("| dLowFOVY : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtHighFOVX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1)
	{
		ErrMessage( _T("0.1 <= dHighFOVX"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dHighFOVX != dTemp)
	{
		strTemp.Format(_T("| dHighFOVX : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtHighFOVY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1)
	{
		ErrMessage( _T("0.1 <= dHighFOVY"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.dHighFOVY != dTemp)
	{
		strTemp.Format(_T("| dHighFOVY : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtCameraPixelX.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 300)
	{
		ErrMessage( _T("300 <= nCameraPixelX"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nCameraPixelX != nTemp)
	{
		strTemp.Format(_T("| nCameraPixelX : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtCameraPixelY.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 300)
	{
		ErrMessage( _T("300 <= nCameraPixelY"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nCameraPixelY != nTemp)
	{
		strTemp.Format(_T("| nCameraPixelY : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtTextGap.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.dTextGap != dTemp)
	{
		strTemp.Format(_T("| dTextGap : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtTextRefMode.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 8)
	{
		ErrMessage( _T("0 <= nTextRefMode <= 8"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.nTextRefMode != nTemp)
	{
		strTemp.Format(_T("| nTextRefMode : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtUseInnerOCRFont.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("bUseInnerOCRFont = 0 or 1"));
		return FALSE;
	}
	if(gSystemINI.m_sSystemDevice.bUseInnerOCRFont != nTemp)
	{
		strTemp.Format(_T("| bUseInnerOCRFont : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtNoSortArea.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("bNoSortArea = 0 or 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessSystem.bNoSortArea != nTemp)
	{
		strTemp.Format(_T("| bNoSortArea : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtNoSortHole.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 4)
	{
		ErrMessage( _T("No Sort Hole = 0 ~ 4"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessSystem.nNoSortHole != nTemp)
	{
		strTemp.Format(_T("| bNoSortHole : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtNoSortLine.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 0 || nTemp > 1)
	{
		ErrMessage( _T("bNoSortLine = 0 or 1"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessSystem.bNoSortLine != nTemp)
	{
		strTemp.Format(_T("| bNoSortLine : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtFidImgSaveData.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 7)
	{
		ErrMessage( _T("7 <= nFidImgSaveData"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessFidFind.nFidImgSaveData != nTemp)
	{
		strTemp.Format(_T("| nFidImgSaveData : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtConpensationLimitCount.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp < 5)
	{
		ErrMessage( _T("5 <= nConpensationLimitCount"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount != nTemp)
	{
		strTemp.Format(_T("| nConpensationLimitCount : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtCompensationDutyPerWatt.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessPowerMeasure.dCompensationDutyPerWatt != dTemp)
	{
		strTemp.Format(_T("| CompensationDutyPerWatt : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtPowerStep.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0)
	{
		ErrMessage( _T("0 <= dPowerStep"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessPowerMeasure.dPowerStep != dTemp)
	{
		strTemp.Format(_T("| dPowerStep : %d "), dTemp);
		strMessage += strTemp;
	}

	if(0 != strMessage.CompareNoCase(""))
	{
		CString strTitle;
		strTitle.Format(_T("Ini Save "));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strTitle), reinterpret_cast<WPARAM>(&strMessage));
	}

	m_edtTableLimitMinX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.dTableLimitMinX != dTemp)
	{
		strTemp.Format(_T("| Table Limit Min X : %.3f "), dTemp);
		strMessage += strTemp;
	}
	m_edtTableLimitMinY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.dTableLimitMinY != dTemp)
	{
		strTemp.Format(_T("| Table Limit Min X : %.3f "), dTemp);
		strMessage += strTemp;
	}
	m_edtTableLimitMaxX.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.dTableLimitMaxX != dTemp)
	{
		strTemp.Format(_T("| Table Limit Min X : %.3f "), dTemp);
		strMessage += strTemp;
	}
	m_edtTableLimitMaxY.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.dTableLimitMaxY != dTemp)
	{
		strTemp.Format(_T("| Table Limit Min X : %.3f "), dTemp);
		strMessage += strTemp;
	}
	
	m_edtTemperContrast.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1 || dTemp > 1)
	{
		ErrMessage( _T("0.1 <= Vision Contrast <= 1"));
		return FALSE;
	}
	m_edtTemperContrast.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessOption.dTemperVerifyContrast != dTemp)
	{
		strTemp.Format(_T("| Temper Verify Contrast : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtTemperBrightness.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(dTemp < 0.1 || dTemp > 1)
	{
		ErrMessage( _T("0.1 <= Vision Brightness <= 1"));
		return FALSE;
	}
	m_edtTemperBrightness.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessOption.dTemperVerifyBrightness != dTemp)
	{
		strTemp.Format(_T("| Temper Verify Brightness : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtChillerCH1.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.sChillerPort.dCH1 != dTemp)
	{
		strTemp.Format(_T("| Chiller CH1 : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtChillerCH2.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemDevice.sChillerPort.dCH2 != dTemp)
	{
		strTemp.Format(_T("| Chiller CH2 : %.3f "), dTemp);
		strMessage += strTemp;
	}

	m_edtDutyLimit.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessOption.dDutyLimit != dTemp)
	{
		strTemp.Format(_T("| Duty Limit : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtVacOffsetMaster.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemVacuum.dVacuumOffset != dTemp)
	{
		strTemp.Format(_T("| Vacuum Offset : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtVacOffsetSlave.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemVacuum.dVacuumOffset2 != dTemp)
	{
		strTemp.Format(_T("| Vacuum Offset2 : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtVacOffsetDust.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sSystemVacuum.dSuctionHoodOffset != dTemp)
	{
		strTemp.Format(_T("| Dust Suction Offset : %.1f "), dTemp);
		strMessage += strTemp;
	}

	m_edtCheckLPCError.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessOption.bCheckLPCError != nTemp)
	{
		strTemp.Format(_T("| Check LPC Error : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtLogDetail.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(gProcessINI.m_sProcessOption.bLPCLogDetail != nTemp)
	{
		strTemp.Format(_T("| LPC Log detail: %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtLPCMinTol.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.dLPCMinTolerence != dTemp)
	{
		strTemp.Format(_T("| LPC Min Tol: %.2f "), dTemp);
		strMessage += strTemp;
	}
	
	m_edtLPCMaxTol.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.dLPCMaxTolerence != dTemp)
	{
		strTemp.Format(_T("| LPC Max Tol: %.2f "), dTemp);
		strMessage += strTemp;
	}
	
	m_edtLPCStartTolPercent.GetWindowText(str);
	dTemp = atof((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.dLPCStartTolerencePercent != dTemp)
	{
		strTemp.Format(_T("| LPC Start Tolerence Percent: %.2f "), dTemp);
		strMessage += strTemp;
	}
	
	m_edtLPCStartSkipCount.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(gSystemINI.m_sHardWare.nLPCStartSkipCount != nTemp)
	{
		strTemp.Format(_T("| LPC Start Skip Count: %d "), nTemp);
		strMessage += strTemp;
	}
	
	dTemp = m_cmbLanguage.GetCurSel();
	if(gSystemINI.m_sHardWare.nLanguageType != dTemp)
	{
		ErrMessage( _T("Language change\nPlease re-open Lily program."));
	}

	m_edtTemperFireCountForVisionCompen.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	nVisionTemp = nTemp;
	if(gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen != nTemp)
	{
		strTemp.Format(_T("Temper Compen Fire Count For Vision Compen : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtTemperFireCountForVisionCompen2.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	nVisionTemp2 = nTemp;
	if(nTemp <= nVisionTemp && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 2 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen2 != nTemp)
	{
		strTemp.Format(_T("Temper Compen Fire Count For Vision Compen 2 : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtTemperFireCountForVisionCompen3.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	nVisionTemp3 = nTemp;
	if(nTemp <= nVisionTemp && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 3 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp2 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 3 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen3 != nTemp)
	{
		strTemp.Format(_T("Temper Compen Fire Count For Vision Compen 3 : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtTemperFireCountForVisionCompen4.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	nVisionTemp4 = nTemp;
	if(nTemp <= nVisionTemp && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 4 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp2 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 4 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp3 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 4 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen4 != nTemp)
	{
		strTemp.Format(_T("Temper Compen Fire Count For Vision Compen 4 : %d "), nTemp);
		strMessage += strTemp;
	}

	m_edtTemperFireCountForVisionCompen5.GetWindowText(str);
	nTemp = atoi((LPSTR)(LPCTSTR)str);
	if(nTemp <= nVisionTemp && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 5 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp2 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 5 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp3 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 5 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(nTemp <= nVisionTemp4 && nTemp != 0)
	{
		ErrMessage( _T("Temper Compen Fire Count For Vision Compen 5 <= Temper Compen Fire Count For Vision Compen"));
		return FALSE;
	}
	if(gProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen5 != nTemp)
	{
		strTemp.Format(_T("Temper Compen Fire Count For Vision Compen 5 : %d "), nTemp);
		strMessage += strTemp;
	}

	return TRUE;
}



void CDlgIniInfo::OnBnClickedOpenExploere()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	ShellExecute(NULL, _T("open"), "D:\\Viahole\\System", NULL, NULL, SW_SHOW);
}


void CDlgIniInfo::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnClose();
}


void CDlgIniInfo::OnEnChangeTemperNochangeTimeLimitSec()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CDlgIniInfo::OnBnClickedOpenTempertable()
{
	CString strFile;
	strFile.Format(_T("%s\\Temper.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	if(!gDeviceFactory.Get1stTemperCompen()->LoadTemperCompenFile(strFile))
	{
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		{
			ErrMessage(_T("Temperature Compensation File Open Error. Please check the Temper.Table file."));
		}
		CString str;
		str.Format(_T("Temperature Compensation File Open Error"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	}

	strFile.Format(_T("%s\\TemperS.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	if(!gDeviceFactory.Get2ndTemperCompen()->LoadTemperCompenFile(strFile))
	{
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		{
			ErrMessage(_T("Temperature Compensation File Open Error. Please check the TemperS.Table file."));
		}
		CString str;
		str.Format(_T("Temperature Compensation File Open Error"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	}
}


void CDlgIniInfo::OnBnClickedOpenToolSort()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CDlgToolHoleSort dlg;

	dlg.SetProcessSystem(gProcessINI.m_sProcessSystem);
	dlg.DoModal();
}
