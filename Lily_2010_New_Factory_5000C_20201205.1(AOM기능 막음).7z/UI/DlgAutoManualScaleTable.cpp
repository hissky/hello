// DlgAutoManualScaleTable.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAutoManualScaleTable.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\Device\HEocard.h"
#include "GridCtrl_src\GridCtrl.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "..\MODEL\AutoManualScaleINIFile.h"
#include "..\MODEL\DAutoManualScaleINI.h"
#include "..\MODEL\GlobalVariable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define		COLOR_APPLYTOOL	RGB(255, 202, 108)
#define		COLOR_APPLYTOOLA	RGB(255, 226, 197)
#define		COLOR_POWERCOMPEN		RGB(255, 255, 162)
#define		COLOR_APPLY_ON		RGB(60, 110, 200)

#define		COLOR_TABLE		RGB(255, 255, 162)
/////////////////////////////////////////////////////////////////////////////
// CDlgAutoManualScaleTable dialog

IMPLEMENT_DYNAMIC(CDlgAutoManualScaleTable, CDialog)

CDlgAutoManualScaleTable::CDlgAutoManualScaleTable(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAutoManualScaleTable::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAutoManualScaleTable)
		// NOTE: the ClassWizard will add member initialization here
	m_nColumnCount = 0;

	strTable0[0] = "  Film Layer  ";
	strTable0[1] = "  Scale Type  ";
	
	//}}AFX_DATA_INIT
}
CDlgAutoManualScaleTable::~CDlgAutoManualScaleTable()
{
}

void CDlgAutoManualScaleTable::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAutoManualScaleTable)

	DDX_GridControl(pDX, IDC_GRID, m_Grid);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSave);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAutoManualScaleTable, CDialog)
	//{{AFX_MSG_MAP(CDlgAutoManualScaleTable)
	ON_WM_CTLCOLOR()
	//ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID, OnGridEndEdit)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CDlgAutoManualScaleTable::OnBnClickedButtonSave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAutoManualScaleTable message handlers

BOOL CDlgAutoManualScaleTable::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitGrid();
	OnCheckRefresh();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAutoManualScaleTable::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);


	GetDlgItem(IDCANCEL)->SetFont(&m_fntBtn);
}

void CDlgAutoManualScaleTable::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");
	// Set Static Font
	m_fntStatic.CreatePointFont(110, "Arial Bold");
}

void CDlgAutoManualScaleTable::InitGrid()
{
	//if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	//{
	//	CRect rt;
	//	GetDlgItem(IDC_LIST_INFO)->GetWindowRect(rt);// GetWindowRect(rt);
	//	ScreenToClient(rt);
	//	m_Grid.Create(rt,this,0xffffff);
	//}
	
	m_Grid.SetEditable(TRUE);
	m_Grid.SetListMode(FALSE);
	m_Grid.EnableDragAndDrop(FALSE);
	m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);


	m_Grid.SetFixedRowCount(1);        //1���� ��
	m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����
}

void CDlgAutoManualScaleTable::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	
	BOOL bOnOff;
	COLORREF pColor = COLOR_TABLE;
	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("Film No %d"),  gVariable.m_sgAutoManualScaleTable.nFilmLayer[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;

		DWORD oldMask = Gvitem.mask;
		Gvitem.mask = GVIF_TEXT|GVIF_FORMAT;
		m_Grid.SetItem(&Gvitem);
		Gvitem.mask = oldMask;
		ColumnNo++;

		//Scale Type
		int nScaleType = gVariable.m_sgAutoManualScaleTable.nScaleType[ColCount];
		if(nScaleType == 0)
		{
			strData.Format(_T("%s"), "Auto");
		}
		else 
		{
			strData.Format(_T("%s"), "Manual");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		CStringArray options;
		options.RemoveAll();

		options.Add(_T("Auto"));
		options.Add(_T("Manual"));

		CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

	}

	m_Grid.AutoSize();
}

void CDlgAutoManualScaleTable::InsertListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	//m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strTable0[i].GetLength();
			nStrLen = 150;

			ColumnNo++;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strTable0[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else
	{

	}
}

void CDlgAutoManualScaleTable::SetDrawMember(int listcount)
{
	int i;
	LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = (AUTO_MANUAL_SCALE_COUNT -1) ; i >= 0 ;i--)
		{
			m_Grid.SetRowCount(1 + AUTO_MANUAL_SCALE_COUNT);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount ==2 )  //2
	{
		/*InsertListComumn(0,TABLE1);

		for( i = 27 ; i >= 0 ;i--)
		{
			m_Grid.SetRowCount(2 + i);
			InsertGridValue(Item, 0, TABLE1, i);
		}*/
	}
	else if(listcount == 3) //1,2
	{
		//InsertListComumn(0,TABLE0);
		//InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		//for( i = 27 ; i >= 0 ;i--)
		//{
		//	m_Grid.SetRowCount(2 + 27);
		//	InsertGridValue(Item, 0, TABLE0, i);
		//	InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);// 3�� �÷� ���� ���� 
		//}
	}
}

void CDlgAutoManualScaleTable::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
		gVariable.m_sgAutoManualScaleTable.nFilmLayer[yPos] = atoi(str);
	else if(xPos == 1)
	{
		if(strcmp(str, "Auto") == 0)
			gVariable.m_sgAutoManualScaleTable.nScaleType[yPos] = 0;
		else if(strcmp(str, "Manual") == 0)
			gVariable.m_sgAutoManualScaleTable.nScaleType[yPos] = 1;
	}
}

void CDlgAutoManualScaleTable::FillTable1Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;
}

void CDlgAutoManualScaleTable::ListUpdate(CPoint ClickedPos, CString str)
{
	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(xPos < TABLE0_COLUMN_COUNT)
		FillTable0Data(xPos,yPos, str);	
	/*	else
	{
	xPos -= TABLE0_COLUMN_COUNT;
	FillTable1Data(xPos,yPos, str);
	}*/	
}

//void CDlgAutoManualScaleTable::OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
//{
//	CString str;
//	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
//	m_posClicked.x = pItem->iColumn;
//	m_posClicked.y = pItem->iRow - 1;
//	str = m_Grid.GetItemText( pItem->iRow, pItem->iColumn);
//	//	if(!ListUpdate(m_posClicked, str))
//	//	OnCheckRefresh();	
//
//	ListUpdate(m_posClicked, str);
//	OnCheckRefresh();
//	//m_Grid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));
//}

void CDlgAutoManualScaleTable::OnCheckRefresh()
{
	m_nColumnCount = 0;
	SetDrawMember(1);

	Invalidate(FALSE);
}

void CDlgAutoManualScaleTable::SetAutoManualScale(SAUTOMANUALSCALE sAutoManualScale)
{
	memcpy( &gVariable.m_sgAutoManualScaleTable, &sAutoManualScale, sizeof(gVariable.m_sgAutoManualScaleTable) );	

}
void CDlgAutoManualScaleTable::GetAutoManualScale(SAUTOMANUALSCALE* pAutoManualScale)
{
	memcpy( pAutoManualScale, &gVariable.m_sgAutoManualScaleTable, sizeof(gVariable.m_sgAutoManualScaleTable) );
}

void CDlgAutoManualScaleTable::OnBnClickedButtonSave()
{
	CString strData;

	GetAutoManualScale( &gAutoManualScaleINI.m_sAutoManualScale );

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, AUTOMANUAL_INI))
	{
		//ErrMsgDlg(STDGNALM114);
	}

	OnCheckRefresh();
	::AfxMessageBox(_T("Auto Manual Scale Data Save Complete"), MB_OK);
}

BOOL CDlgAutoManualScaleTable::PreTranslateMessage(MSG* pMsg) 
{

	if(m_Grid.m_bKeyboardOn)
	{
		CCellID cCellId;
		CPoint cpClickedCell;
		CString str;
		int nCol = 0;
		int nRow = 0;
		nCol = m_Grid.GetColumnCount();
		nRow = m_Grid.GetRowCount();
		cCellId = m_Grid.GetEditedCell();

		for(int i = 1; i < nCol; i++)
		{
			cpClickedCell.x = i;
			for(int j = 1; j < nRow; j++)
			{
				cpClickedCell.y = j - 1;
				str = m_Grid.GetItemText(j, i);
				ListUpdate(cpClickedCell, str);
			}
		}
		m_Grid.m_bKeyboardOn = FALSE;
		OnCheckRefresh();
	}

	return CDialog::PreTranslateMessage(pMsg);
}