// PaneSubMotorPositionLarge.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSubMotorPositionLarge.h"
#include "..\EasyDrillerDlg.h"
#include "..\device\hdevicefactory.h"
#include "..\device\DeviceMotor.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HLaserAttenuator.h"
#include "..\device\HMotor.h"
#include "..\model\dprocessini.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionLarge

IMPLEMENT_DYNCREATE(CPaneSubMotorPositionLarge, CFormView)

CPaneSubMotorPositionLarge::CPaneSubMotorPositionLarge()
	: CFormView(CPaneSubMotorPositionLarge::IDD)
{
	//{{AFX_DATA_INIT(CPaneSubMotorPositionPusan1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

CPaneSubMotorPositionLarge::~CPaneSubMotorPositionLarge()
{
}

void CPaneSubMotorPositionLarge::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSubMotorPositionPusan1)
	DDX_Control(pDX, IDC_STATIC_POS_X_VALUE, m_stcPosX);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VALUE, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VALUE, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Z2_VALUE, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE3, m_stcPosM2);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE4, m_stcPosM3);
	
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE5, m_stcPosM4);
	DDX_Control(pDX, IDC_STATIC_POS_TOP_VALUE, m_stcPosTop);
	DDX_Control(pDX, IDC_STATIC_POS_ROT_VALUE, m_stcPosRot);

	DDX_Control(pDX, IDC_STATIC_POS_C_VALUE, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_LC_VALUE, m_stcPosLC);
	DDX_Control(pDX, IDC_STATIC_POS_UC_VALUE, m_stcPosUC);
	DDX_Control(pDX, IDC_STATIC_POS_C_VALUE3, m_stcPosC2);

	//2011524
	DDX_Control(pDX, IDC_STATIC_POSA_VALUE, m_stcPos1A);
	DDX_Control(pDX, IDC_STATIC_POSA2_VALUE, m_stcPos2A);

	DDX_Control(pDX, IDC_STATIC_POS_LP1_VALUE, m_stcPosLP1);
	DDX_Control(pDX, IDC_STATIC_POS_LP2_VALUE, m_stcPosLP2);
	DDX_Control(pDX, IDC_STATIC_POS_UP1_VALUE, m_stcPosUP1);
	DDX_Control(pDX, IDC_STATIC_POS_UP2_VALUE, m_stcPosUP2);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSubMotorPositionLarge, CFormView)
	//{{AFX_MSG_MAP(CPaneSubMotorPositionLarge)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionLarge diagnostics

#ifdef _DEBUG
void CPaneSubMotorPositionLarge::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSubMotorPositionLarge::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionLarge message handlers

void CPaneSubMotorPositionLarge::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();

	InitTimer();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		m_stcPosZ2.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
		m_stcPosZ2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			GetDlgItem(IDC_STATIC_POS_Z1)->EnableWindow(FALSE);
			m_stcPosZ1.EnableWindow(FALSE);
		}

	}
	if(gSystemINI.m_sHardWare.nLaserType != LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(TRUE);
			m_stcPosZ2.EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_POS_Z2)->SetWindowText("T");
			m_stcPosZ2.ShowWindow(SW_SHOW);
		}
		else
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
			m_stcPosZ2.ShowWindow(SW_HIDE);
		}
			
		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);
	}

#ifndef __SERVO_MOTOR__
	GetDlgItem(IDC_STATIC_POS_M_VALUE4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_M_VALUE3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_M4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_M3)->ShowWindow(SW_HIDE);

#endif
}

void CPaneSubMotorPositionLarge::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(110, "Arial Bold");
	m_fntStatic2.CreatePointFont(100, "Arial Bold");
	
	// Position
	GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->SetFont( &m_fntStatic2 );

	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_LC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_UC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_C3)->SetFont( &m_fntStatic );

	
		
		
	GetDlgItem(IDC_STATIC_POS_M5)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_TOP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_ROT)->SetFont( &m_fntStatic );


	//2011524
	GetDlgItem(IDC_STATIC_POSA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POSA2)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_POS_LP1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_LP2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_UP1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_UP2)->SetFont( &m_fntStatic );

#ifdef __2016_KUNSAN__
	GetDlgItem(IDC_STATIC_POSA)->ShowWindow(SW_HIDE);
#endif
	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM2.SetFont( &m_fntStatic );
	m_stcPosM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM3.SetFont( &m_fntStatic );
	m_stcPosM3.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM3.SetBackColor( VALUE_BACK_COLOR );


	m_stcPosM4.SetFont( &m_fntStatic );
	m_stcPosM4.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM4.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosTop.SetFont( &m_fntStatic );
	m_stcPosTop.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosTop.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosRot.SetFont( &m_fntStatic );
	m_stcPosRot.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosRot.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC2.SetFont( &m_fntStatic );
	m_stcPosC2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosLC.SetFont( &m_fntStatic );
	m_stcPosLC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosLC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosUC.SetFont( &m_fntStatic );
	m_stcPosUC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosUC.SetBackColor( VALUE_BACK_COLOR );

	//2011524
	m_stcPos1A.SetFont( &m_fntStatic );
	m_stcPos1A.SetForeColor( VALUE_FORE_COLOR );
	m_stcPos1A.SetBackColor( VALUE_BACK_COLOR );
#ifdef __2016_KUNSAN__
	m_stcPos1A.ShowWindow(SW_HIDE);
#endif


	m_stcPos2A.SetFont( &m_fntStatic );
	m_stcPos2A.SetForeColor( VALUE_FORE_COLOR );
	m_stcPos2A.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosLP1.SetFont( &m_fntStatic );
	m_stcPosLP1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosLP1.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosLP2.SetFont( &m_fntStatic );
	m_stcPosLP2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosLP2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosUP1.SetFont( &m_fntStatic );
	m_stcPosUP1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosUP1.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosUP2.SetFont( &m_fntStatic );
	m_stcPosUP2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosUP2.SetBackColor( VALUE_BACK_COLOR );
	

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_STATIC_POS_M)->SetWindowText("A1");
		GetDlgItem(IDC_STATIC_POS_C)->SetWindowText("A2");
	}

#ifdef __YOUNGPOONG__
	GetDlgItem(IDC_STATIC_POS_LP1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_LP2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_UP1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_UP2)->ShowWindow(SW_SHOW);
	m_stcPosLP1.ShowWindow(SW_SHOW);
	m_stcPosLP2.ShowWindow(SW_SHOW);
	m_stcPosUP1.ShowWindow(SW_SHOW);
	m_stcPosUP2.ShowWindow(SW_SHOW);
#else
	GetDlgItem(IDC_STATIC_POS_LP1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_LP2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_UP1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_UP2)->ShowWindow(SW_HIDE);
	m_stcPosLP1.ShowWindow(SW_HIDE);
	m_stcPosLP2.ShowWindow(SW_HIDE);
	m_stcPosUP1.ShowWindow(SW_HIDE);
	m_stcPosUP2.ShowWindow(SW_HIDE);
#endif
}

HBRUSH CPaneSubMotorPositionLarge::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSubMotorPositionLarge::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dPos = 0;
	int nPos = 0;
	CString strData;
	strData.GetBuffer(256);
	// X
	pMotor->GetRawPosition( AXIS_X, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );
	
	// Y
	pMotor->GetRawPosition( AXIS_Y, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );
	
	// Z1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z1, dPos );

	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );
	
	// Z2
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z2, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );
	
	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M, dPos );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );

	// M2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M2, dPos );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM2.SetWindowText( (LPCTSTR)strData );

	// M3
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M3, dPos );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM3.SetWindowText( (LPCTSTR)strData );
	// M4
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M4, dPos );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM4.SetWindowText( (LPCTSTR)strData );


	pMotor->GetRawPosition( AXIS_ROT, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosRot.SetWindowText( (LPCTSTR)strData );

	pMotor->GetRawPosition( AXIS_TOPHAT, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosTop.SetWindowText( (LPCTSTR)strData );

	// C
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_C, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosC.SetWindowText( (LPCTSTR)strData );

	//C2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_C2, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosC2.SetWindowText( (LPCTSTR)strData );

	dPos = 0;
	// L.C
	pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosLC.SetWindowText( (LPCTSTR)strData );

	// U.C
	pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosUC.SetWindowText( (LPCTSTR)strData );

	//A1
	pMotor->GetRawPosition( AXIS_A1, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPos1A.SetWindowText( (LPCTSTR)strData );

	//A2
	pMotor->GetRawPosition( AXIS_A2, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPos2A.SetWindowText( (LPCTSTR)strData );

#ifdef __YOUNGPOONG__
	// LP1
	pMotor->GetRawPosition( AXIS_LP1, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosLP1.SetWindowText( (LPCTSTR)strData );

	// LP2
	pMotor->GetRawPosition( AXIS_LP2, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosLP2.SetWindowText( (LPCTSTR)strData );

	// UP1
	pMotor->GetRawPosition( AXIS_UP1, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosUP1.SetWindowText( (LPCTSTR)strData );

	// UP2
	pMotor->GetRawPosition( AXIS_UP2, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosUP2.SetWindowText( (LPCTSTR)strData );
#endif

	m_bTimer = FALSE;
	strData.ReleaseBuffer();
}

void CPaneSubMotorPositionLarge::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	if(!m_bTimer)
		DispStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneSubMotorPositionLarge::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_bTimer = FALSE;
		m_nTimerID = SetTimer(999, 500, NULL);
	}
}

void CPaneSubMotorPositionLarge::DestroyTimer()
{
	if(m_nTimerID)
	{
		m_bTimer = TRUE;
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneSubMotorPositionLarge::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	m_fntStatic.DeleteObject();
	m_fntStatic2.DeleteObject();
}
