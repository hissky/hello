#define	__3RDAOD__

#ifndef __3RDAOD__
	typedef struct {
			BOOL bUse_StandbyDummyShot;
			BOOL bUse_Hole2HoleDummyShot;
		} TDrillDummyShotMode;
#endif

