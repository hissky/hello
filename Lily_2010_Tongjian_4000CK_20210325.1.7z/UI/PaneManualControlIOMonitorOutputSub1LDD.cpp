// PaneManualControlIOMonitorOutputSub1LDD.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutputSub1LDD.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\Model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "..\model\deasydrillerini.h"
#include "..\device\hmotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1LDD

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutputSub1LDD, CFormView)

CPaneManualControlIOMonitorOutputSub1LDD::CPaneManualControlIOMonitorOutputSub1LDD()
	: CFormView(CPaneManualControlIOMonitorOutputSub1LDD::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutputSub1)
		// NOTE: the ClassWizard will add member initialization here
	m_nTimerID = 0;
	m_lStatus1 = m_lStatus1Old = 0;
	m_lStatus2 = m_lStatus2Old = 0;
	m_lStatus3 = m_lStatus3old = 0;
	m_lStatus4 = m_lStatus4old = 0;
	m_nSuction = m_nSuctionOld = 0;
	m_bMotor = m_bMotorOld = FALSE;
	m_bLamp = m_bLampOld = FALSE;
	m_bChuck = m_bChuckOld = FALSE;
	m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
	m_bBrushSol = m_bBrushSolOld = FALSE;
	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorOutputSub1LDD::~CPaneManualControlIOMonitorOutputSub1LDD()
{
}

void CPaneManualControlIOMonitorOutputSub1LDD::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutputSub1)
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_ON, m_btnLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_OFF, m_btnLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, m_btnSafeOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, m_btnSafeOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_X, m_btnInitX);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Y, m_btnInitY);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z1, m_btnInitZ1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z2, m_btnInitZ2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M, m_btnInitM);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_C, m_btnInitC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_OPEN, m_btnPowermeterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, m_btnPowermeterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, m_btnHeightSensorUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, m_btnHeightSensorDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, m_btnHeightSensorUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, m_btnHeightSensorDown2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, m_btnShutter1Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, m_btnShutter1Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, m_btnShutter2Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, m_btnShutter2Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, m_btnSuction1On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, m_btnSuction1Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, m_btnSuction2On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, m_btnSuction2Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, m_btnVacuumMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, m_btnVacuumMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ALIGN, m_btnLoaderAlign);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_LOAD, m_btnLoaderLoad);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, m_btnLoadElvLoadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, m_btnLoadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, m_btnLoadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, m_btnLoadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, m_btnUnloaderUnload);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, m_btnUnloadElvUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, m_btnUnloadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, m_btnUnloadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, m_btnUnloadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP, m_btnTableClamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, m_btnTableUnclamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP2, m_btnTableClamp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, m_btnTableUnclamp2);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_ON, m_btnDoorByPassOn);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_OFF, m_btnDoorByPassOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, m_btnLoadingShutterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, m_btnLoadingShutterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_ON, m_btnBuzzerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_OFF, m_btnBuzzerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, m_btnAirBlowerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, m_btnAirBlowerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, m_btnBrushMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, m_btnBrushMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, m_btnBrushSolUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, m_btnBrushSolDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, m_btnGreenLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, m_btnGreenLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, m_btnYellowLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, m_btnYellowLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_ON, m_btnRedLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_OFF, m_btnRedLampOff);
	DDX_Control(pDX, IDC_BUTTON_FRONT_DOOR_LOCK, m_btnFrontDoorLock);
	DDX_Control(pDX, IDC_BUTTON_FRONT_DOOR_UNLOCK, m_btnFrontDoorUnLock);
	DDX_Control(pDX, IDC_BUTTON_LOAD_DOOR_LOCK, m_btnLoadDoorLock);
	DDX_Control(pDX, IDC_BUTTON_LOAD_DOOR_UNLOCK, m_btnLoadDoorUnLock);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutputSub1LDD, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutputSub1)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_ON, OnButtonOutputLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_OFF, OnButtonOutputLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, OnButtonOutputSafetyModeOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, OnButtonOutputSafetyModeOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_X, OnButtonOutputInitializeX)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Y, OnButtonOutputInitializeY)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z1, OnButtonOutputInitializeZ1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z2, OnButtonOutputInitializeZ2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M, OnButtonOutputInitializeM)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_C, OnButtonOutputInitializeC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_OPEN, OnButtonOutputPowermeterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, OnButtonOutputPowermeterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, OnButtonOutputHeightSensorUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, OnButtonOutputHeightSensorDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, OnButtonOutputHeightSensorUp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, OnButtonOutputHeightSensorDown2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, OnButtonOutputLasershutter1Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, OnButtonOutputLasershutter1Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, OnButtonOutputLasershutter2Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, OnButtonOutputLasershutter2Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, OnButtonOutputTablesuction1On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, OnButtonOutputTablesuction1Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, OnButtonOutputTablesuction2On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, OnButtonOutputTablesuction2Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, OnButtonOutputVacuumMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, OnButtonOutputVacuumMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ALIGN, OnButtonOutputLoaderAlign)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_LOAD, OnButtonOutputLoaderLoad)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, OnButtonOutputLoaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, OnButtonOutputLoaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, OnButtonOutputLoaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, OnButtonOutputLoaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, OnButtonOutputUnloaderUnload)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, OnButtonOutputUnloaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, OnButtonOutputUnloaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, OnButtonOutputUnloaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, OnButtonOutputUnloaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP, OnButtonOutputTableClamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, OnButtonOutputTableUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP2, OnButtonOutputTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, OnButtonOutputTableUnclamp2)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_ON, OnButtonDoorByPassOn)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_OFF, OnButtonDoorByPassOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, OnButtonOutputLoadingShutterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, OnButtonOutputLoadingShutterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_ON, OnButtonOutputBuzzerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_OFF, OnButtonOutputBuzzerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, OnButtonOutputAirBlowerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, OnButtonOutputAirBlowerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, OnButtonOutputBrushMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, OnButtonOutputBrushMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, OnButtonOutputBrushSolUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, OnButtonOutputBrushSolDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, OnButtonOutputGreenLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, OnButtonOutputGreenLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, OnButtonOutputYellowLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, OnButtonOutputYellowLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_ON, OnButtonOutputRedLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_OFF, OnButtonOutputRedLampOff)
	ON_BN_CLICKED(IDC_BUTTON_FRONT_DOOR_LOCK, OnButtonFrontDoorLock)
	ON_BN_CLICKED(IDC_BUTTON_FRONT_DOOR_UNLOCK, OnButtonFrontDoorUnlock)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_DOOR_LOCK, OnButtonLoadDoorLock)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_DOOR_UNLOCK, OnButtonLoadDoorUnlock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1 diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutputSub1LDD::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutputSub1LDD::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1 message handlers

void CPaneManualControlIOMonitorOutputSub1LDD::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();
}

void CPaneManualControlIOMonitorOutputSub1LDD::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	m_btnLampOn.SetFont( &m_fntBtn );
	m_btnLampOn.SetFlat( FALSE );
	m_btnLampOn.EnableBallonToolTip();
	m_btnLampOn.SetToolTipText( _T("FlouorescentLamp On") );
	m_btnLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnLampOff.SetFont( &m_fntBtn );
	m_btnLampOff.SetFlat( FALSE );
	m_btnLampOff.EnableBallonToolTip();
	m_btnLampOff.SetToolTipText( _T("FlouorescentLamp Off") );
	m_btnLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnSafeOn.SetFont( &m_fntBtn );
	m_btnSafeOn.SetFlat( FALSE );
	m_btnSafeOn.EnableBallonToolTip();
	m_btnSafeOn.SetToolTipText( _T("Safety Mode On") );
	m_btnSafeOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOn.SetBtnCursor(IDC_HAND_1);

	m_btnSafeOff.SetFont( &m_fntBtn );
	m_btnSafeOff.SetFlat( FALSE );
	m_btnSafeOff.EnableBallonToolTip();
	m_btnSafeOff.SetToolTipText( _T("Safety Mode Off") );
	m_btnSafeOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOff.SetBtnCursor(IDC_HAND_1);

	m_btnInitX.SetFont( &m_fntBtn );
	m_btnInitX.SetFlat( FALSE );
	m_btnInitX.EnableBallonToolTip();
	m_btnInitX.SetToolTipText( _T("Axis-X Initialize") );
	m_btnInitX.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitX.SetBtnCursor(IDC_HAND_1);

	m_btnInitY.SetFont( &m_fntBtn );
	m_btnInitY.SetFlat( FALSE );
	m_btnInitY.EnableBallonToolTip();
	m_btnInitY.SetToolTipText( _T("Axis-Y Initialize") );
	m_btnInitY.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitY.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ1.SetFont( &m_fntBtn );
	m_btnInitZ1.SetFlat( FALSE );
	m_btnInitZ1.EnableBallonToolTip();
	m_btnInitZ1.SetToolTipText( _T("Axis-Z1 Initialize") );
	m_btnInitZ1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ1.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ2.SetFont( &m_fntBtn );
	m_btnInitZ2.SetFlat( FALSE );
	m_btnInitZ2.EnableBallonToolTip();
	m_btnInitZ2.SetToolTipText( _T("Axis-Z2 Initialize") );
	m_btnInitZ2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ2.SetBtnCursor(IDC_HAND_1);

	m_btnInitM.SetFont( &m_fntBtn );
	m_btnInitM.SetFlat( FALSE );
	m_btnInitM.EnableBallonToolTip();
	m_btnInitM.SetToolTipText( _T("Axis-M Initialize") );
	m_btnInitM.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM.SetBtnCursor(IDC_HAND_1);

	m_btnInitC.SetFont( &m_fntBtn );
	m_btnInitC.SetFlat( FALSE );
	m_btnInitC.EnableBallonToolTip();
	m_btnInitC.SetToolTipText( _T("Axis-C Initialize") );
	m_btnInitC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitC.SetBtnCursor(IDC_HAND_1);
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		m_btnInitM.SetWindowText("Axis-A1 Initialize");
		m_btnInitM.SetToolTipText( _T("Axis-A1 Initialize") );
		m_btnInitC.SetWindowText("Axis-A2 Initialize");
		m_btnInitC.SetToolTipText( _T("Axis-A2 Initialize") );
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_btnInitM.SetWindowText("Axis-T Initialize");
		m_btnInitM.SetToolTipText( _T("Axis-T Initialize") );
	}

	m_btnPowermeterOpen.SetFont( &m_fntBtn );
	m_btnPowermeterOpen.SetFlat( FALSE );
	m_btnPowermeterOpen.EnableBallonToolTip();
	m_btnPowermeterOpen.SetToolTipText( _T("PowerMeter Shutter Open") );
	m_btnPowermeterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnPowermeterClose.SetFont( &m_fntBtn );
	m_btnPowermeterClose.SetFlat( FALSE );
	m_btnPowermeterClose.EnableBallonToolTip();
	m_btnPowermeterClose.SetToolTipText( _T("PowerMeter Shutter Close") );
	m_btnPowermeterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterClose.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp.SetFont( &m_fntBtn );
	m_btnHeightSensorUp.SetFlat( FALSE );
	m_btnHeightSensorUp.EnableBallonToolTip();
	m_btnHeightSensorUp.SetToolTipText( _T("HeightSensor Up") );
	m_btnHeightSensorUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorDown.SetFont( &m_fntBtn );
	m_btnHeightSensorDown.SetFlat( FALSE );
	m_btnHeightSensorDown.EnableBallonToolTip();
	m_btnHeightSensorDown.SetToolTipText( _T("HeightSensor Down") );
	m_btnHeightSensorDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp2.SetFont( &m_fntBtn );
	m_btnHeightSensorUp2.SetFlat( FALSE );
	m_btnHeightSensorUp2.EnableBallonToolTip();
	m_btnHeightSensorUp2.SetToolTipText( _T("HeightSensor 2 Up") );
	m_btnHeightSensorUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnHeightSensorDown2.SetFont( &m_fntBtn );
	m_btnHeightSensorDown2.SetFlat( FALSE );
	m_btnHeightSensorDown2.EnableBallonToolTip();
	m_btnHeightSensorDown2.SetToolTipText( _T("HeightSensor 2 Down") );
	m_btnHeightSensorDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown2.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Open.SetFont( &m_fntBtn );
	m_btnShutter1Open.SetFlat( FALSE );
	m_btnShutter1Open.EnableBallonToolTip();
	m_btnShutter1Open.SetToolTipText( _T("LaserShutter1 Open") );
	m_btnShutter1Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Open.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Close.SetFont( &m_fntBtn );
	m_btnShutter1Close.SetFlat( FALSE );
	m_btnShutter1Close.EnableBallonToolTip();
	m_btnShutter1Close.SetToolTipText( _T("LaserShutter1 Close") );
	m_btnShutter1Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Close.SetBtnCursor(IDC_HAND_1);

	m_btnShutter2Open.SetFont( &m_fntBtn );
	m_btnShutter2Open.SetFlat( FALSE );
	m_btnShutter2Open.EnableBallonToolTip();
	m_btnShutter2Open.SetToolTipText( _T("LaserShutter2 Open") );
	m_btnShutter2Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Open.SetBtnCursor(IDC_HAND_1);
	
	m_btnShutter2Close.SetFont( &m_fntBtn );
	m_btnShutter2Close.SetFlat( FALSE );
	m_btnShutter2Close.EnableBallonToolTip();
	m_btnShutter2Close.SetToolTipText( _T("LaserShutter2 Close") );
	m_btnShutter2Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Close.SetBtnCursor(IDC_HAND_1);

	m_btnSuction1On.SetFont( &m_fntBtn );
	m_btnSuction1On.SetFlat( FALSE );
	m_btnSuction1On.EnableBallonToolTip();
	m_btnSuction1On.SetToolTipText( _T("TableSuction1 On") );
	m_btnSuction1On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1On.SetBtnCursor(IDC_HAND_1);

	m_btnSuction1Off.SetFont( &m_fntBtn );
	m_btnSuction1Off.SetFlat( FALSE );
	m_btnSuction1Off.EnableBallonToolTip();
	m_btnSuction1Off.SetToolTipText( _T("TableSuction1 Off") );
	m_btnSuction1Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1Off.SetBtnCursor(IDC_HAND_1);

	m_btnSuction2On.SetFont( &m_fntBtn );
	m_btnSuction2On.SetFlat( FALSE );
	m_btnSuction2On.EnableBallonToolTip();
	m_btnSuction2On.SetToolTipText( _T("TableSuction2 On") );
	m_btnSuction2On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2On.SetBtnCursor(IDC_HAND_1);
	
	m_btnSuction2Off.SetFont( &m_fntBtn );
	m_btnSuction2Off.SetFlat( FALSE );
	m_btnSuction2Off.EnableBallonToolTip();
	m_btnSuction2Off.SetToolTipText( _T("TableSuction2 Off") );
	m_btnSuction2Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2Off.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotorOn.SetFont( &m_fntBtn );
	m_btnVacuumMotorOn.SetFlat( FALSE );
	m_btnVacuumMotorOn.EnableBallonToolTip();
	m_btnVacuumMotorOn.SetToolTipText( _T("VacuumMotor On") );
	m_btnVacuumMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotorOff.SetFont( &m_fntBtn );
	m_btnVacuumMotorOff.SetFlat( FALSE );
	m_btnVacuumMotorOff.EnableBallonToolTip();
	m_btnVacuumMotorOff.SetToolTipText( _T("VacuumMotor Off") );
	m_btnVacuumMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOff.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderAlign.SetFont( &m_fntBtn );
	m_btnLoaderAlign.SetFlat( FALSE );
	m_btnLoaderAlign.EnableBallonToolTip();
	m_btnLoaderAlign.SetToolTipText( _T("Loader Align Command") );
	m_btnLoaderAlign.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlign.SetBtnCursor(IDC_HAND_1);	

	m_btnLoaderLoad.SetFont( &m_fntBtn );
	m_btnLoaderLoad.SetFlat( FALSE );
	m_btnLoaderLoad.EnableBallonToolTip();
	m_btnLoaderLoad.SetToolTipText( _T("Loader Load Command") );
	m_btnLoaderLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderLoad.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvLoadPos.SetFont( &m_fntBtn );
	m_btnLoadElvLoadPos.SetFlat( FALSE );
	m_btnLoadElvLoadPos.EnableBallonToolTip();
	m_btnLoadElvLoadPos.SetToolTipText( _T("LoadElevator Load Pos") );
	m_btnLoadElvLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvLoadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvOriPos.SetFont( &m_fntBtn );
	m_btnLoadElvOriPos.SetFlat( FALSE );
	m_btnLoadElvOriPos.EnableBallonToolTip();
	m_btnLoadElvOriPos.SetToolTipText( _T("LoadElevator Origin Pos") );
	m_btnLoadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrCartPos.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos.SetFlat( FALSE );
	m_btnLoadCarrCartPos.EnableBallonToolTip();
	m_btnLoadCarrCartPos.SetToolTipText( _T("LoadCarrier Cart Pos") );
	m_btnLoadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrTablePos.SetFont( &m_fntBtn );
	m_btnLoadCarrTablePos.SetFlat( FALSE );
	m_btnLoadCarrTablePos.EnableBallonToolTip();
	m_btnLoadCarrTablePos.SetToolTipText( _T("LoadCarrier Table Pos") );
	m_btnLoadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrTablePos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloaderUnload.SetFont( &m_fntBtn );
	m_btnUnloaderUnload.SetFlat( FALSE );
	m_btnUnloaderUnload.EnableBallonToolTip();
	m_btnUnloaderUnload.SetToolTipText( _T("Unloder Unload Command") );
	m_btnUnloaderUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderUnload.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadElvUnloadPos.SetFlat( FALSE );
	m_btnUnloadElvUnloadPos.EnableBallonToolTip();
	m_btnUnloadElvUnloadPos.SetToolTipText( _T("UnloadElevator Unload Pos") );
	m_btnUnloadElvUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvUnloadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvOriPos.SetFont( &m_fntBtn );
	m_btnUnloadElvOriPos.SetFlat( FALSE );
	m_btnUnloadElvOriPos.EnableBallonToolTip();
	m_btnUnloadElvOriPos.SetToolTipText( _T("UnloaderElevator Origin Pos") );
	m_btnUnloadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrCartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrCartPos.SetFlat( FALSE );
	m_btnUnloadCarrCartPos.EnableBallonToolTip();
	m_btnUnloadCarrCartPos.SetToolTipText( _T("UnloadCarrier Cart Pos") );
	m_btnUnloadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrTablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarrTablePos.SetFlat( FALSE );
	m_btnUnloadCarrTablePos.EnableBallonToolTip();
	m_btnUnloadCarrTablePos.SetToolTipText( _T("UnloadCarrier Table Pos") );
	m_btnUnloadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrTablePos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnTableClamp.SetFont( &m_fntBtn );
	m_btnTableClamp.SetFlat( FALSE );
	m_btnTableClamp.EnableBallonToolTip();
	m_btnTableClamp.SetToolTipText( _T("Left Table Clamp") );
	m_btnTableClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp.SetFont( &m_fntBtn );
	m_btnTableUnclamp.SetFlat( FALSE );
	m_btnTableUnclamp.EnableBallonToolTip();
	m_btnTableUnclamp.SetToolTipText( _T("Left Table Unclamp") );
	m_btnTableUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnTableClamp2.SetFont( &m_fntBtn );
	m_btnTableClamp2.SetFlat( FALSE );
	m_btnTableClamp2.EnableBallonToolTip();
	m_btnTableClamp2.SetToolTipText( _T("Right Table Clamp") );
	m_btnTableClamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp2.SetFont( &m_fntBtn );
	m_btnTableUnclamp2.SetFlat( FALSE );
	m_btnTableUnclamp2.EnableBallonToolTip();
	m_btnTableUnclamp2.SetToolTipText( _T("Right Table Unclamp") );
	m_btnTableUnclamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp2.SetBtnCursor(IDC_HAND_1);

	if (gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		m_btnTableClamp.ShowWindow(SW_HIDE);
		m_btnTableUnclamp.ShowWindow(SW_HIDE);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
	}

	m_btnDoorByPassOn.SetFont( &m_fntBtn );
	m_btnDoorByPassOn.SetFlat( FALSE );
	m_btnDoorByPassOn.EnableBallonToolTip();
	m_btnDoorByPassOn.SetToolTipText( _T("Door By Pass On") );
	m_btnDoorByPassOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOn.SetBtnCursor(IDC_HAND_1);

	m_btnDoorByPassOff.SetFont( &m_fntBtn );
	m_btnDoorByPassOff.SetFlat( FALSE );
	m_btnDoorByPassOff.EnableBallonToolTip();
	m_btnDoorByPassOff.SetToolTipText( _T("Door By Pass Off") );
	m_btnDoorByPassOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnShutter2Open.ShowWindow(SW_HIDE);
		m_btnShutter2Close.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnInitM.ShowWindow(SW_HIDE);
		m_btnInitC.ShowWindow(SW_HIDE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
			m_btnInitZ1.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{
		m_btnSuction2On.ShowWindow(SW_HIDE);
		m_btnSuction2Off.ShowWindow(SW_HIDE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_btnPowermeterOpen.ShowWindow(SW_HIDE);
		m_btnPowermeterClose.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_btnHeightSensorUp.ShowWindow(SW_HIDE);
		m_btnHeightSensorDown.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
	{
		m_btnHeightSensorUp2.ShowWindow(SW_HIDE);
		m_btnHeightSensorDown2.ShowWindow(SW_HIDE);
	}

	m_btnLoadingShutterOpen.SetFont( &m_fntBtn );
	m_btnLoadingShutterOpen.SetFlat( FALSE );
	m_btnLoadingShutterOpen.EnableBallonToolTip();
	m_btnLoadingShutterOpen.SetToolTipText( _T("LoadingShutter Open") );
	m_btnLoadingShutterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnLoadingShutterClose.SetFont( &m_fntBtn );
	m_btnLoadingShutterClose.SetFlat( FALSE );
	m_btnLoadingShutterClose.EnableBallonToolTip();
	m_btnLoadingShutterClose.SetToolTipText( _T("LoadingShutter Close") );
	m_btnLoadingShutterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterClose.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOn.SetFont( &m_fntBtn );
	m_btnBuzzerOn.SetFlat( FALSE );
	m_btnBuzzerOn.EnableBallonToolTip();
	m_btnBuzzerOn.SetToolTipText( _T("Buzzer On") );
	m_btnBuzzerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOn.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOff.SetFont( &m_fntBtn );
	m_btnBuzzerOff.SetFlat( FALSE );
	m_btnBuzzerOff.EnableBallonToolTip();
	m_btnBuzzerOff.SetToolTipText( _T("Buzzer Off") );
	m_btnBuzzerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOff.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOn.SetFont( &m_fntBtn );
	m_btnAirBlowerOn.SetFlat( FALSE );
	m_btnAirBlowerOn.EnableBallonToolTip();
	m_btnAirBlowerOn.SetToolTipText( _T("AirBlower On") );
	m_btnAirBlowerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOn.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOff.SetFont( &m_fntBtn );
	m_btnAirBlowerOff.SetFlat( FALSE );
	m_btnAirBlowerOff.EnableBallonToolTip();
	m_btnAirBlowerOff.SetToolTipText( _T("AirBlower Off") );
	m_btnAirBlowerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOn.SetFont( &m_fntBtn );
	m_btnBrushMotorOn.SetFlat( FALSE );
	m_btnBrushMotorOn.EnableBallonToolTip();
	m_btnBrushMotorOn.SetToolTipText( _T("BrushMotor On") );
	m_btnBrushMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOff.SetFont( &m_fntBtn );
	m_btnBrushMotorOff.SetFlat( FALSE );
	m_btnBrushMotorOff.EnableBallonToolTip();
	m_btnBrushMotorOff.SetToolTipText( _T("BrushMotor Off") );
	m_btnBrushMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_btnBrushMotorOn.SetWindowText("Dust Collector On");
		m_btnBrushMotorOn.SetToolTipText( _T("Dust Collector On") );
		m_btnBrushMotorOff.SetWindowText("Dust Collector Off");
		m_btnBrushMotorOff.SetToolTipText( _T("Dust Collector Off") );
	}
	
	m_btnBrushSolUp.SetFont( &m_fntBtn );
	m_btnBrushSolUp.SetFlat( FALSE );
	m_btnBrushSolUp.EnableBallonToolTip();
	m_btnBrushSolUp.SetToolTipText( _T("BrushSol Up") );
	m_btnBrushSolUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolUp.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushSolDown.SetFont( &m_fntBtn );
	m_btnBrushSolDown.SetFlat( FALSE );
	m_btnBrushSolDown.EnableBallonToolTip();
	m_btnBrushSolDown.SetToolTipText( _T("BrushSol Down") );
	m_btnBrushSolDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolDown.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOn.SetFont( &m_fntBtn );
	m_btnGreenLampOn.SetFlat( FALSE );
	m_btnGreenLampOn.EnableBallonToolTip();
	m_btnGreenLampOn.SetToolTipText( _T("GreenLamp On") );
	m_btnGreenLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOff.SetFont( &m_fntBtn );
	m_btnGreenLampOff.SetFlat( FALSE );
	m_btnGreenLampOff.EnableBallonToolTip();
	m_btnGreenLampOff.SetToolTipText( _T("GreenLamp Off") );
	m_btnGreenLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnYellowLampOn.SetFont( &m_fntBtn );
	m_btnYellowLampOn.SetFlat( FALSE );
	m_btnYellowLampOn.EnableBallonToolTip();
	m_btnYellowLampOn.SetToolTipText( _T("YellowLamp On") );
	m_btnYellowLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnYellowLampOff.SetFont( &m_fntBtn );
	m_btnYellowLampOff.SetFlat( FALSE );
	m_btnYellowLampOff.EnableBallonToolTip();
	m_btnYellowLampOff.SetToolTipText( _T("YellowLamp Off") );
	m_btnYellowLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOn.SetFont( &m_fntBtn );
	m_btnRedLampOn.SetFlat( FALSE );
	m_btnRedLampOn.EnableBallonToolTip();
	m_btnRedLampOn.SetToolTipText( _T("RedLamp On") );
	m_btnRedLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOff.SetFont( &m_fntBtn );
	m_btnRedLampOff.SetFlat( FALSE );
	m_btnRedLampOff.EnableBallonToolTip();
	m_btnRedLampOff.SetToolTipText( _T("RedLamp Off") );
	m_btnRedLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnFrontDoorLock.SetFont( &m_fntBtn );
	m_btnFrontDoorLock.SetFlat( FALSE );
	m_btnFrontDoorLock.EnableBallonToolTip();
	m_btnFrontDoorLock.SetToolTipText( _T("Front door lock") );
	m_btnFrontDoorLock.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFrontDoorLock.SetBtnCursor(IDC_HAND_1);

	m_btnFrontDoorUnLock.SetFont( &m_fntBtn );
	m_btnFrontDoorUnLock.SetFlat( FALSE );
	m_btnFrontDoorUnLock.EnableBallonToolTip();
	m_btnFrontDoorUnLock.SetToolTipText( _T("Front door unlock") );
	m_btnFrontDoorUnLock.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFrontDoorUnLock.SetBtnCursor(IDC_HAND_1);

	m_btnLoadDoorLock.SetFont( &m_fntBtn );
	m_btnLoadDoorLock.SetFlat( FALSE );
	m_btnLoadDoorLock.EnableBallonToolTip();
	m_btnLoadDoorLock.SetToolTipText( _T("Loading door lock") );
	m_btnLoadDoorLock.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadDoorLock.SetBtnCursor(IDC_HAND_1);

	m_btnLoadDoorUnLock.SetFont( &m_fntBtn );
	m_btnLoadDoorUnLock.SetFlat( FALSE );
	m_btnLoadDoorUnLock.EnableBallonToolTip();
	m_btnLoadDoorUnLock.SetToolTipText( _T("Loading door unlock") );
	m_btnLoadDoorUnLock.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadDoorUnLock.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		m_btnLoadingShutterOpen.ShowWindow(SW_HIDE);
		m_btnLoadingShutterClose.ShowWindow(SW_HIDE);
		m_btnBuzzerOn.ShowWindow(SW_HIDE);
		m_btnBuzzerOff.ShowWindow(SW_HIDE);
		m_btnAirBlowerOn.ShowWindow(SW_HIDE);
		m_btnAirBlowerOff.ShowWindow(SW_HIDE);
		m_btnBrushMotorOn.ShowWindow(SW_HIDE);
		m_btnBrushMotorOff.ShowWindow(SW_HIDE);
		m_btnBrushSolUp.ShowWindow(SW_HIDE);
		m_btnBrushSolDown.ShowWindow(SW_HIDE);
		m_btnGreenLampOn.ShowWindow(SW_HIDE);
		m_btnGreenLampOff.ShowWindow(SW_HIDE);
		m_btnYellowLampOn.ShowWindow(SW_HIDE);
		m_btnYellowLampOff.ShowWindow(SW_HIDE);
		m_btnRedLampOn.ShowWindow(SW_HIDE);
		m_btnRedLampOff.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnShutter1Open.ShowWindow(SW_HIDE);
		m_btnShutter1Close.ShowWindow(SW_HIDE);
		m_btnSafeOn.ShowWindow(SW_HIDE);
		m_btnSafeOff.ShowWindow(SW_HIDE);
		m_btnLoaderLoad.ShowWindow(SW_HIDE);
		m_btnUnloaderUnload.ShowWindow(SW_HIDE);

		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableClamp2.EnableWindow(TRUE);
		m_btnTableClamp2.SetWindowText("Chuck Clamp");
		m_btnTableClamp2.SetToolTipText(_T("Chuck Clamp"));
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.EnableWindow(TRUE);
		m_btnTableUnclamp2.SetWindowText("Chuck Unclamp");
		m_btnTableUnclamp2.SetToolTipText(_T("Chuck Unclamp"));

		m_btnSuction1On.SetWindowText("TableSuction On");
		m_btnSuction1On.SetToolTipText( _T("TableSuction On") );
		m_btnSuction1Off.SetWindowText("TableSuction Off");
		m_btnSuction1Off.SetToolTipText( _T("TableSuction Off") );
	}
#ifdef __PUSAN_LDD__
	m_btnInitC.ShowWindow(SW_HIDE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::UpdateStatus()
{
	if(m_pMotor->IsInOrigin(AXIS_X, FALSE))
		m_btnInitX.SetSelection(1);
	else
		m_btnInitX.SetSelection(0);

	if(m_pMotor->IsInOrigin(AXIS_Y, FALSE))
		m_btnInitY.SetSelection(1);
	else
		m_btnInitY.SetSelection(0);

	if(m_pMotor->IsInOrigin(AXIS_Z1, FALSE))
		m_btnInitZ1.SetSelection(1);
	else
		m_btnInitZ1.SetSelection(0);
	
	if(m_pMotor->IsInOrigin(AXIS_Z2, FALSE))
		m_btnInitZ2.SetSelection(1);
	else
		m_btnInitZ2.SetSelection(0);

	if(m_pMotor->IsInOrigin(AXIS_M, FALSE))
		m_btnInitM.SetSelection(1);
	else
		m_btnInitM.SetSelection(0);

	if(m_pMotor->IsInOrigin(AXIS_C, FALSE))
		m_btnInitC.SetSelection(1);
	else
		m_btnInitC.SetSelection(0);
#ifdef __MP920_MOTOR__
	int nRet = m_pMotor->GetCurrentStatus(CURRENT_SUCTION);
#ifdef __CUNGJU_JASMINE_OLD__
	if(nRet == 5)
	{
		m_btnSuction1On.SetSelection(1);
		m_btnSuction1Off.SetSelection(0);
		m_btnSuction2On.SetSelection(0);
		m_btnSuction2Off.SetSelection(1);
	}
	else if(nRet == 11)
	{
		m_btnSuction1On.SetSelection(0);
		m_btnSuction1Off.SetSelection(1);
		m_btnSuction2On.SetSelection(1);
		m_btnSuction2Off.SetSelection(0);
	}
	else if(nRet == 15)
	{
		m_btnSuction1On.SetSelection(1);
		m_btnSuction1Off.SetSelection(0);
		m_btnSuction2On.SetSelection(1);
		m_btnSuction2Off.SetSelection(0);
	}
	else
	{
		m_btnSuction1On.SetSelection(0);
		m_btnSuction1Off.SetSelection(1);
		m_btnSuction2On.SetSelection(0);
		m_btnSuction2Off.SetSelection(1);
	}
#else
	if(nRet & 0x01)
	{
		m_btnSuction1On.SetSelection(1);
		m_btnSuction1Off.SetSelection(0);
	}
	else
	{
		m_btnSuction1On.SetSelection(0);
		m_btnSuction1Off.SetSelection(1);
	}
	if(nRet & 0x02)
	{
		m_btnSuction2On.SetSelection(1);
		m_btnSuction2Off.SetSelection(0);
	}
	else
	{
		m_btnSuction2On.SetSelection(0);
		m_btnSuction2Off.SetSelection(1);
	}
#endif
	if(m_pMotor->GetCurrentStatus(CURRENT_HEIGHT, FALSE))
	{
		m_btnHeightSensorUp.SetSelection(1);
		m_btnHeightSensorDown.SetSelection(0);
	}
	else
	{
		m_btnHeightSensorUp.SetSelection(0);
		m_btnHeightSensorDown.SetSelection(1);
	}

	#ifdef __CUNGJU_JASMINE_OLD__
		if(m_pMotor->GetCurrentStatus(CURRENT_HEIGHT2, FALSE))
		{
			m_btnHeightSensorUp2.SetSelection( 1 );
			m_btnHeightSensorDown2.SetSelection( 0);
		}
		else
		{
			m_btnHeightSensorUp2.SetSelection( 0 );
			m_btnHeightSensorDown2.SetSelection( 1 );
		}
	#endif

	if(m_pMotor->GetCurrentStatus(CURRENT_SHUTTER1) & 0x01)
	{
		m_btnShutter1Open.SetSelection(1);
		m_btnShutter1Close.SetSelection(0);
	}
	else
	{
		m_btnShutter1Open.SetSelection(0);
		m_btnShutter1Close.SetSelection(1);
	}

	if(m_pMotor->GetCurrentStatus(CURRENT_SHUTTER2) & 0x01)
	{
		m_btnShutter2Open.SetSelection(1);
		m_btnShutter2Close.SetSelection(0);
	}
	else
	{
		m_btnShutter2Open.SetSelection(0);
		m_btnShutter2Close.SetSelection(1);
	}

	if(m_pMotor->IsStatus(IS_OPEN_LASER_SHUTTER))
	{
		m_btnPowermeterOpen.SetSelection(1);
		m_btnPowermeterClose.SetSelection(0);
	}
	else
	{
		m_btnPowermeterOpen.SetSelection(0);
		m_btnPowermeterClose.SetSelection(1);
	}
#endif
	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		if(m_pMotor->GetCurrentTableClamp(TRUE, TRUE))
			m_btnTableClamp.SetSelection( 1 );
		else
			m_btnTableClamp.SetSelection( 0 );
		
		if(m_pMotor->GetCurrentTableClamp(TRUE, FALSE))
			m_btnTableUnclamp.SetSelection( 1 );
		else
			m_btnTableUnclamp.SetSelection( 0 );
	}
	
	if(gSystemINI.m_sHardWare.nTableClamp > 1)
	{
		if(m_pMotor->GetCurrentTableClamp(FALSE, TRUE))
			m_btnTableClamp2.SetSelection( 1 );
		else
			m_btnTableClamp2.SetSelection( 0 );
		
		if(m_pMotor->GetCurrentTableClamp(FALSE, FALSE))
			m_btnTableUnclamp2.SetSelection( 1 );
		else
			m_btnTableUnclamp2.SetSelection( 0 );
	}

/*
	if(m_lStatus1 != m_lStatus1Old)
	{
		m_lStatus1Old = m_lStatus1;

		if(m_lStatus1 & 0x0008)
		{
			m_btnSafeOn.SetSelection( 1 );
			m_btnSafeOff.SetSelection( 0 );
		}
		else
		{
			m_btnSafeOn.SetSelection( 0 );
			m_btnSafeOff.SetSelection( 1 );
		}

//		if(m_lStatus1 & 0x0010)
//		{
//			m_btnDoorByPassOn.SetSelection( 1 );
//			m_btnDoorByPassOff.SetSelection( 0 );
//		}
//		else
//		{
//			m_btnDoorByPassOn.SetSelection( 0 );
//			m_btnDoorByPassOff.SetSelection( 1 );
//		}

//		if(m_lStatus1 & 0x0020)
//		{
//			m_btnSuction1On.SetSelection( 1 );
//			m_btnSuction1Off.SetSelection( 0 );
//		}
//		else
//		{
//			m_btnSuction1On.SetSelection( 0 );
//			m_btnSuction1Off.SetSelection( 1 );
//		}

//		if(m_lStatus1 & 0x0040)
//		{
//			m_btnSuction2On.SetSelection( 1 );
//			m_btnSuction2Off.SetSelection( 0 );
//		}
//		else
//		{
//			m_btnSuction2On.SetSelection( 0 );
//			m_btnSuction2Off.SetSelection( 1 );
//		}

		if(m_lStatus1 & 0x0400)
			m_btnInitX.SetSelection( 1 );
		else
			m_btnInitX.SetSelection( 0 );

		if(m_lStatus1 & 0x4000)
			m_btnInitY.SetSelection( 1 );
		else
			m_btnInitY.SetSelection( 0 );
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		if(m_lStatus2 != m_lStatus2Old)
		{
			m_lStatus2Old = m_lStatus2;

			if(m_lStatus2 & 0x0004)
				m_btnInitZ1.SetSelection( 1 );
			else
				m_btnInitZ1.SetSelection( 0 );

			if(m_lStatus2 & 0x0040)
				m_btnInitZ2.SetSelection( 1 );
			else
				m_btnInitZ2.SetSelection( 0 );

			if(m_lStatus2 & 0x0400)
				m_btnInitM.SetSelection( 1 );
			else
				m_btnInitM.SetSelection( 0 );

			if(m_lStatus2 & 0x4000)
				m_btnInitC.SetSelection( 1 );
			else
				m_btnInitC.SetSelection( 0 );
		}
			
		if(m_lStatus3 != m_lStatus3old)
		{
			m_lStatus3old = m_lStatus3;

			if(m_lStatus3 & 0x0004)
				m_btnShutter1Close.SetSelection( 1 );
			else
				m_btnShutter1Close.SetSelection( 0 );

			if(m_lStatus3 & 0x0008)
				m_btnShutter1Open.SetSelection( 1 );
			else
				m_btnShutter1Open.SetSelection( 0 );

			if(m_lStatus3 & 0x0010)
				m_btnShutter2Close.SetSelection( 1 );
			else
				m_btnShutter2Close.SetSelection( 0 );

			if(m_lStatus3 & 0x0020)
				m_btnShutter2Open.SetSelection( 1 );
			else
				m_btnShutter2Open.SetSelection( 0 );
			

			if(m_lStatus3 & 0x0040)
				m_btnHeightSensorUp.SetSelection( 1 );
			else
				m_btnHeightSensorUp.SetSelection( 0 );

			if(m_lStatus3 & 0x0080)
				m_btnHeightSensorDown.SetSelection( 1 );
			else
				m_btnHeightSensorDown.SetSelection( 0 );

			if(m_lStatus3 & 0x0100)
				m_btnPowermeterOpen.SetSelection( 1 );
			else
				m_btnPowermeterOpen.SetSelection( 0 );

			if(m_lStatus3 & 0x0200)
				m_btnPowermeterClose.SetSelection( 1 );
			else
				m_btnPowermeterClose.SetSelection( 0 );

	//		if(m_lStatus3 & 0x0400)
	//		{
	//			m_btnVacuumMotorOn.SetSelection( 1 );
	//			m_btnVacuumMotorOff.SetSelection( 0 );
	//		}
	//		else
	//		{
	//			m_btnVacuumMotorOn.SetSelection( 0 );
	//			m_btnVacuumMotorOff.SetSelection( 1 );
	//		}

			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				if(m_lStatus3 & 0x0800)
					m_btnTableClamp.SetSelection( 1 );
				else
					m_btnTableClamp.SetSelection( 0 );

				if(m_lStatus3 & 0x1000)
					m_btnTableUnclamp.SetSelection( 1 );
				else
					m_btnTableUnclamp.SetSelection( 0 );
			}

			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				if(m_lStatus3 & 0x2000)
					m_btnTableClamp2.SetSelection( 1 );
				else
					m_btnTableClamp2.SetSelection( 0 );

				if(m_lStatus3 & 0x4000)
					m_btnTableUnclamp2.SetSelection( 1 );
				else
					m_btnTableUnclamp2.SetSelection( 0 );
			}
		}
		if(m_lStatus4 != m_lStatus4old)
		{
			m_lStatus4old = m_lStatus4;
			if(m_lStatus4 & 0x0001)
				m_btnHeightSensorUp2.SetSelection( 1 );
			else
				m_btnHeightSensorUp2.SetSelection( 0 );
			
			if(m_lStatus4 & 0x0002)
				m_btnHeightSensorDown2.SetSelection( 1 );
			else
				m_btnHeightSensorDown2.SetSelection( 0 );
		}
	}

	if(m_nSuction != m_nSuctionOld)
	{
		m_nSuctionOld = m_nSuction;

		if(m_nSuction & 0x01)
		{
			m_btnSuction1On.SetSelection( 1 );
			m_btnSuction1Off.SetSelection( 0 );
		}
		else
		{
			m_btnSuction1On.SetSelection( 0 );
			m_btnSuction1Off.SetSelection( 1 );
		}
		
		if(m_nSuction & 0x02)
		{
			m_btnSuction2On.SetSelection( 1 );
			m_btnSuction2Off.SetSelection( 0 );
		}
		else
		{
			m_btnSuction2On.SetSelection( 0 );
			m_btnSuction2Off.SetSelection( 1 );
		}
	}

	if(m_bMotor != m_bMotorOld)
	{
		m_bMotorOld = m_bMotor;

		if(m_bMotor)
		{
			m_btnVacuumMotorOn.SetSelection( 1 );
			m_btnVacuumMotorOff.SetSelection( 0 );
		}
		else
		{
			m_btnVacuumMotorOn.SetSelection( 0 );
			m_btnVacuumMotorOff.SetSelection( 1 );
		}
	}

	if(m_bLamp != m_bLampOld)
	{
		m_bLampOld = m_bLamp;

		if(m_bLamp)
		{
			m_btnLampOn.SetSelection( 1 );
			m_btnLampOff.SetSelection( 0 );
		}
		else
		{
			m_btnLampOn.SetSelection( 0 );
			m_btnLampOff.SetSelection( 1 );
		}
	}

	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
#ifndef __MP920_MOTOR__
		if(m_bChuck != m_bChuckOld)
		{
			m_bChuckOld = m_bChuck;

			if(m_bChuck)
			{
				m_btnTableClamp2.SetSelection( 1 );
				m_btnTableUnclamp2.SetSelection( 0 );
			}
			else
			{
				m_btnTableClamp2.SetSelection( 0 );
				m_btnTableUnclamp2.SetSelection( 1 );
			}
		}

		if(m_bLoadingShutter != m_bLoadingShutterOld)
		{
			m_bLoadingShutterOld = m_bLoadingShutter;

			if(m_bLoadingShutter)
			{
				m_btnLoadingShutterOpen.SetSelection( 1 );
				m_btnLoadingShutterClose.SetSelection( 0 );
			}
			else
			{
				m_btnLoadingShutterOpen.SetSelection( 0 );
				m_btnLoadingShutterClose.SetSelection( 1 );
			}
		}

		if(m_bBrushSol != m_bBrushSolOld)
		{
			m_bBrushSolOld = m_bBrushSol;

			if(m_bBrushSol)
			{
				m_btnBrushSolUp.SetSelection( 1 );
				m_btnBrushSolDown.SetSelection( 0 );
			}
			else
			{
				m_btnBrushSolUp.SetSelection( 0 );
				m_btnBrushSolDown.SetSelection( 1 );
			}
		}
#endif
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
#ifndef __MP920_MOTOR__	
		if(m_bMotor & 0x01)
		{
			m_btnSuction1On.SetSelection( 1 );
			m_btnSuction1Off.SetSelection( 0 );
		}
		else
		{
			m_btnSuction1On.SetSelection( 0 );
			m_btnSuction1Off.SetSelection( 1 );
		}

		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		if(bBuzzer)
		{
			m_btnBuzzerOn.SetSelection(1);
			m_btnBuzzerOff.SetSelection(0);
		}
		else
		{
			m_btnBuzzerOn.SetSelection(0);
			m_btnBuzzerOff.SetSelection(1);
		}

		if(nColor & TOWER_RED)
		{
			m_btnRedLampOn.SetSelection(1);
			m_btnRedLampOff.SetSelection(0);
		}
		else
		{
			m_btnRedLampOn.SetSelection(0);
			m_btnRedLampOff.SetSelection(1);
		}

		if(nColor & TOWER_YELLOW)
		{
			m_btnYellowLampOn.SetSelection(1);
			m_btnYellowLampOff.SetSelection(0);
		}
		else
		{
			m_btnYellowLampOn.SetSelection(0);
			m_btnYellowLampOff.SetSelection(1);
		}

		if(nColor & TOWER_GREEN)
		{
			m_btnGreenLampOn.SetSelection(1);
			m_btnGreenLampOff.SetSelection(0);
		}
		else
		{
			m_btnGreenLampOn.SetSelection(0);
			m_btnGreenLampOff.SetSelection(1);
		}

		if(gDeviceFactory.GetMotor()->IsIonizerAirOn())
		{
			m_btnAirBlowerOn.SetSelection(1);
			m_btnAirBlowerOff.SetSelection(0);
		}
		else
		{
			m_btnAirBlowerOn.SetSelection(0);
			m_btnAirBlowerOff.SetSelection(1);
		}

		if(gDeviceFactory.GetMotor()->IsDustCollectorOn()) // dust collector
		{
			m_btnBrushMotorOn.SetSelection(1);
			m_btnBrushMotorOff.SetSelection(0);
		}
		else
		{
			m_btnBrushMotorOn.SetSelection(0);
			m_btnBrushMotorOff.SetSelection(1);
		}

		if(!gDeviceFactory.GetMotor()->IsFrontDoorOpen()) // front door lock
		{
			m_btnFrontDoorLock.SetSelection(1);
			m_btnFrontDoorUnLock.SetSelection(0);
		}
		else
		{
			m_btnFrontDoorLock.SetSelection(0);
			m_btnFrontDoorUnLock.SetSelection(1);
		}

		if(!gDeviceFactory.GetMotor()->IsLeftDoorOpen()) // loading door lock
		{
			m_btnLoadDoorLock.SetSelection(1);
			m_btnLoadDoorUnLock.SetSelection(0);
		}
		else
		{
			m_btnLoadDoorLock.SetSelection(0);
			m_btnLoadDoorUnLock.SetSelection(1);
		}
#endif
	}
*/
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
//	m_lStatus1 = m_pMotor->GetCurrentError(STATUS_IO1);
	m_nSuction = m_pMotor->GetCurrentSuction();
#ifndef __MP920_MOTOR__
	m_bMotor = m_pMotor->GetCurrentMotorSol();
#endif

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
#ifndef __MP920_MOTOR__
		m_bChuck = m_pMotor->GetChuckStatus(TRUE);
		m_bLoadingShutter = m_pMotor->GetLoadingShutterStatus(TRUE);
		m_bBrushSol = m_pMotor->GetBrushStatus(TRUE);
#endif
	}
	else
	{
		m_lStatus2 = m_pMotor->GetCurrentError(STATUS_IO2);
		m_lStatus3 = m_pMotor->GetCurrentError(STATUS_IO3);
		m_lStatus4 = m_pMotor->GetCurrentError(STATUS_IO4);
#ifndef __MP920_MOTOR__
		m_bLamp = m_pMotor->IsFluorescentLampOn();
#endif
	}
	
	UpdateStatus();

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorOutputSub1LDD::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9981, 1000, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
//	SetTimer(9981, 1000, NULL);
}

void CPaneManualControlIOMonitorOutputSub1LDD::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
		
		m_lStatus1 = m_lStatus1Old = 0;
		m_lStatus2 = m_lStatus2Old = 0;
		m_lStatus3 = m_lStatus3old = 0;
		m_lStatus4 = m_lStatus4old = 0;

		m_nSuction = m_nSuctionOld = 0;
		m_bMotor = m_bMotorOld = FALSE;
		m_bLamp = m_bLampOld = FALSE;
		m_bChuck = m_bChuckOld = FALSE;
		m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
		m_bBrushSol = m_bBrushSolOld = FALSE;
	}
//	KillTimer(9981);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLampOn() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(1, 6, TRUE);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_LAMP, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLampOff() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(1, 6, FALSE);
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_LAMP, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputSafetyModeOn() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->SetOutPort(PORT_MODE_SELECT, 4);
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 1);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputSafetyModeOff() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->SetOutPort(PORT_MODE_SELECT, 1);

	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 0);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeX() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_X);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeY() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
		
#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_Y);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeZ1() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
		
#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	gDeviceFactory.GetMotor()->SetOrigin(AXIS_Z1);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeZ2() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
		
#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_Z2);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeM() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
		
#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_M);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputInitializeC() 
{
	// TODO: Add your control notification handler code here

#ifndef __MP920_MOTOR__
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_MPG)
#endif
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
		
#ifndef __MP920_MOTOR__
	if(m_pMotor->IsSafetyMode())
#else
	if(m_pMotor->GetCurrentStatus(CURRENT_MODE) == MODE_SAFE)
#endif
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_C);
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputPowermeterOpen() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 10, TRUE);
#else
//	wAddr = ADD0B_WRITE_OUTPORT + PORT_SHUTTER_MASTER;
//		SetOutPort( wAddr, bFlag, TRUE );
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputPowermeterClose() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 11, TRUE);
#else
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputHeightSensorUp() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 8, TRUE);
#else
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_HEIGHT_SENSOR, FALSE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputHeightSensorDown() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 9, TRUE);
#else
	m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_HEIGHT_SENSOR, TRUE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputHeightSensorUp2() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(1, 13, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputHeightSensorDown2() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(1, 14, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLasershutter1Open() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 4, TRUE);
#else
	m_pMotor->SetCurrentStatus(CURRENT_SHUTTER1, TRUE);
//	m_pMotor->SetOutPort(PORT_SHUTTER_MASTER, TRUE, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLasershutter1Close() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 5, TRUE);
#else
	m_pMotor->SetCurrentStatus(CURRENT_SHUTTER1, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLasershutter2Open() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 6, TRUE);
#else
//	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, TRUE, FALSE);
	m_pMotor->SetCurrentStatus(CURRENT_SHUTTER2, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLasershutter2Close() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 7, TRUE);
#else
	m_pMotor->SetCurrentStatus(CURRENT_SHUTTER2, FALSE);
//	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, FALSE, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTablesuction1On() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 0, TRUE);
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_TABLE_SUCTION, TRUE);
	}
#else
	if(m_nSuction & 0x02)
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
	else
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTablesuction1Off() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 1, TRUE);
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_TABLE_SUCTION, FALSE);
	}
#else
	if(m_nSuction & 0x02)
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
	else
		m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTablesuction2On() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 2, TRUE);
#else
	#ifdef __CUNGJU_JASMINE_OLD__
		if(m_nSuction == 5)
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
		else if(m_nSuction == 15)
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
		else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
	#else
		if(m_nSuction & 0x01)
	
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
		else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
	#endif
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTablesuction2Off() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->WriteOutputIOBIt(2, 3, TRUE);
#else
	#ifdef __CUNGJU_JASMINE_OLD__
		if(m_nSuction == 5)
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
		else if(m_nSuction == 15)
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
		else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
	#else
		if(m_nSuction & 0x01)
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
		else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
	#endif
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputVacuumMotorOn() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->Table1VacuumMotor(TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputVacuumMotorOff() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->Table1VacuumMotor(FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderAlign() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderLoad() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->HandlerOperation(HANDLER_LOADER_LOAD);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->LoaderElvLoadPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->LoaderElvOriginPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->LoaderCarrierAlignPos();	
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->LoaderCarrierLoadPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputUnloaderUnload() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputUnloaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->UnloaderElvUnloadPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputUnloaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->UnloaderElvOriginPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputUnloaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->UnloaderCarrierUnloadPos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputUnloaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->UnloaderCarrierTablePos();
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTableClamp() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->TableClamp(TRUE);
#else
	m_pMotor->TableClamp(TRUE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTableUnclamp() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->TableClamp(FALSE);
#else
	m_pMotor->TableClamp(FALSE, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTableClamp2() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->TableClamp(TRUE, FALSE);
#else
	m_pMotor->TableClamp(TRUE, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputTableUnclamp2() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	m_pMotor->TableClamp(FALSE, FALSE);
#else
	m_pMotor->TableClamp(FALSE, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonDoorByPassOn() 
{
	// TODO: Add your control notification handler code here
#ifdef __MP920_MOTOR__
	m_pMotor->SetOutPort((ADD0B_WRITE_OUTPORT + PORT_SYSTEM_DOOR_BYPASS), TRUE, TRUE);
#else
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, TRUE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonDoorByPassOff() 
{
	// TODO: Add your control notification handler code here
#ifdef __MP920_MOTOR__
	m_pMotor->SetOutPort((ADD0B_WRITE_OUTPORT + PORT_SYSTEM_DOOR_BYPASS, FALSE), TRUE);
#else
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::EnableButton(BOOL bUse)
{
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_X)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_M)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_C)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ALIGN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_LOAD)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS)->EnableWindow(bUse);
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_ON)->EnableWindow(bUse);
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_OFF)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_OFF)->EnableWindow(bUse);

	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP)->EnableWindow(bUse);
	}
	if(gSystemINI.m_sHardWare.nTableClamp > 1 ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
#ifndef __MP920_MOTOR__
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP2)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2)->EnableWindow(bUse);
#endif
	}
}

void CPaneManualControlIOMonitorOutputSub1LDD::SetAuthorityByLevel(int nLevel)
{
	// 100209 operator�� ��� ����Ҽ� �ְ�
	EnableButton(TRUE);
	return;

	switch(nLevel)
	{
	case 0: // Operator
		EnableButton(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3: // Super Engineer
		EnableButton(TRUE);
		break;
	}
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoadingShutterOpen()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(SHUTTER_OPEN_CLOSE_SOL, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputLoadingShutterClose()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(SHUTTER_OPEN_CLOSE_SOL, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBuzzerOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BUZZER, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		m_pMotor->SetTowerLampBuzzer(nColor, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBuzzerOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BUZZER, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		m_pMotor->SetTowerLampBuzzer(nColor, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputAirBlowerOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(AIR_BLOWER, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->IonizerOn(TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputAirBlowerOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(AIR_BLOWER, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->IonizerOn(FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBrushMotorOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_MOTOR_ON, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->DustSuctionControl(FALSE, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBrushMotorOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_MOTOR_ON, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->DustSuctionControl(FALSE, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBrushSolUp()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_SOL, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputBrushSolDown()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_SOL, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputGreenLampOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_GREEN, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		m_pMotor->SetTowerLampBuzzer(nColor | TOWER_GREEN, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputGreenLampOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_GREEN, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		nColor ^= TOWER_GREEN;
		m_pMotor->SetTowerLampBuzzer(nColor, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputYellowLampOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_YELLOW, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		m_pMotor->SetTowerLampBuzzer(nColor | TOWER_YELLOW, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputYellowLampOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_YELLOW, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		nColor ^= TOWER_YELLOW;
		m_pMotor->SetTowerLampBuzzer(nColor, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputRedLampOn()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_RED, TRUE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		m_pMotor->SetTowerLampBuzzer(nColor | TOWER_RED, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonOutputRedLampOff()
{
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_RED, FALSE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		int nColor = 0;
		BOOL bBuzzer = FALSE;
		m_pMotor->GetTowerLampBuzzer(nColor, bBuzzer);
		nColor ^= TOWER_RED;
		m_pMotor->SetTowerLampBuzzer(nColor, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonFrontDoorLock() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_FROMT_DOOR_LOCK, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonFrontDoorUnlock() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_FROMT_DOOR_LOCK, FALSE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonLoadDoorLock() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_LOAD_DOOR_LOCK, TRUE);
	}
#endif
}

void CPaneManualControlIOMonitorOutputSub1LDD::OnButtonLoadDoorUnlock() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_pMotor->SetOutPort(PORT_LOAD_DOOR_LOCK, FALSE);
	}	
#endif
}

BOOL CPaneManualControlIOMonitorOutputSub1LDD::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

BOOL CPaneManualControlIOMonitorOutputSub1LDD::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_IO_Output1) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
