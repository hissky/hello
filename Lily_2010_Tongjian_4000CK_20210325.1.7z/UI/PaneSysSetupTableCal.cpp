// PaneSysSetupTableCal.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupTableCal.h"
#include "DlgVisionOnly.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\DEasyDrillerINI.h"
#include <FSTREAM>
#include "..\device\devicemotor.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include <math.h>
#include "..\device\hlaser.h"
#include "..\model\dsystemini.h"
#include "..\alarmmsg.h"
#include "model\SystemINIFile.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\device\HMotor.h"
#include "..\MODEL\GlobalVariable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define NUMGRIDX		50
#define NUMGRIDY		50
#define CALGRID_STEP	10.0 // �� �Ǽ��� ���
#define CALGRID_THICK	4.8
static LPCTSTR g_lpszFilter =_T("Calibration Files (*.TABLE)|*.TABLE|");

const TCHAR	WHOLE_Z_CALIBRATION_FILE[] = _T("z.CalGrid");

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTableCal

IMPLEMENT_DYNCREATE(CPaneSysSetupTableCal, CFormView)

CPaneSysSetupTableCal::CPaneSysSetupTableCal()
	: CFormView(CPaneSysSetupTableCal::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupTableCal)
	//}}AFX_DATA_INIT
	m_bStopDraw			= FALSE;
	m_bSuccess			= FALSE;
	m_nXPixelNum		= 67;
	m_nYPixelNum		= 77;
	m_dMaxOffset		= 0.;
	m_pVisionOnly		= NULL;
	m_dMaxOffsetX = m_dMaxOffsetY = 0.0;
	m_dMinOffsetX = m_dMinOffsetY = 0.0;
	m_dAvgX = m_dAvgY = 0.0;
	m_dCalThick = 4.8;
	m_dCalGap = 10.0;
	m_dXStartPos = 100.0;
	m_dYStartPos = 100.0;

	m_pXCal = NULL;
	m_pYCal = NULL;
	m_pXProofPos = NULL;
	m_pYProofPos = NULL;

	m_dXStart = 0.0;
	m_dXEnd = 0.0;
	m_dYStart = 0.0;
	m_dYEnd = 0.0;
	m_Offset = NULL;
	m_CalHead.dOffset = NULL;

	m_bStartCal = FALSE;
	m_bStartProof = FALSE;
	m_dStartPosZ = 0.0;
	m_bRotateCalDone = FALSE;
	m_nFoundIndex = -1;
}

CPaneSysSetupTableCal::~CPaneSysSetupTableCal()
{
	ClearMem();
}

void CPaneSysSetupTableCal::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupTableCal)
	DDX_Control(pDX, IDC_COMBO_USE_VISION, m_cmbUseVision);
	DDX_Control(pDX, IDC_STATIC_AVG_X_VAL, m_stcAvgXVal);
	DDX_Control(pDX, IDC_STATIC_AVG_Y_VAL, m_stcAvgYVal);
	DDX_Control(pDX, IDC_STATIC_RANGE_Y_MIN, m_stcRangeYMin);
	DDX_Control(pDX, IDC_STATIC_RANGE_Y_MAX, m_stcRangeYMax);
	DDX_Control(pDX, IDC_STATIC_RANGE_X_MIN, m_stcRangeXMin);
	DDX_Control(pDX, IDC_STATIC_RANGE_X_MAX, m_stcRangeXMax);
	DDX_Control(pDX, IDC_STATIC_DISP_RET, m_stcDispRet);
	DDX_Control(pDX, IDC_EDIT_START_Y, m_edtStartY);
	DDX_Control(pDX, IDC_EDIT_START_X, m_edtStartX);
	DDX_Control(pDX, IDC_EDIT_GRID_Y, m_edtGridY);
	DDX_Control(pDX, IDC_EDIT_GRID_X, m_edtGridX);
	DDX_Control(pDX, IDC_EDIT_CAL_GAP, m_edtCalGap);
	DDX_Control(pDX, IDC_BUTTON_VERIFY, m_btnVerify);
	DDX_Control(pDX, IDC_BUTTON_SHOW_VISION, m_btnShowVision);
	DDX_Control(pDX, IDC_BUTTON_SET_CUR_POS, m_btnSetCurPos);
	DDX_Control(pDX, IDC_BUTTON_LOAD_CAL_DATA, m_btnLoadCalData);
	DDX_Control(pDX, IDC_BUTTON_CAL_START, m_btnCalStart);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BUTTON_MAKE_XYCAL, m_btnMakeCalFile);
	DDX_Text(pDX, IDC_EDIT_GRID_X, m_nXPixelNum);
	DDV_MinMaxInt(pDX, m_nXPixelNum, 1, 80);
	DDX_Text(pDX, IDC_EDIT_GRID_Y, m_nYPixelNum);
	DDV_MinMaxInt(pDX, m_nYPixelNum, 1, 80);
	DDX_Text(pDX, IDC_EDIT_CAL_GAP, m_dCalGap);
	DDX_Text(pDX, IDC_EDIT_START_X, m_dXStartPos);
	DDX_Text(pDX, IDC_EDIT_START_Y, m_dYStartPos);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupTableCal, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupTableCal)
	ON_WM_CTLCOLOR()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_SET_CUR_POS, OnButtonSetCurPos)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CAL_DATA, OnButtonLoadCalData)
	ON_BN_CLICKED(IDC_BUTTON_CAL_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_SHOW_VISION, OnButtonShowVision)
	ON_BN_CLICKED(IDC_BUTTON_VERIFY, OnProof)
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_COMBO_USE_VISION, OnSelchangeComboUseVision)
	ON_BN_CLICKED(IDC_BUTTON_MAKE_XYCAL, OnButtonMakeXycal)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_TCAL_LOG1, &CPaneSysSetupTableCal::OnBnClickedButtonTcalLog1)
	ON_BN_CLICKED(IDC_BUTTON_TCAL_LOG2, &CPaneSysSetupTableCal::OnBnClickedButtonTcalLog2)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTableCal diagnostics

#ifdef _DEBUG
void CPaneSysSetupTableCal::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupTableCal::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTableCal message handlers

void CPaneSysSetupTableCal::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitComboControl();
}

void CPaneSysSetupTableCal::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}


BOOL CPaneSysSetupTableCal::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupTableCal::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));

	// XY Start Position
	GetDlgItem(IDC_STATIC_START_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_START_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_START_Y)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_GRID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAL_GAP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DISP_RET)->SetFont( &m_fntStatic );

	// 1st Panel 
	GetDlgItem(IDC_STATIC_1ST_PANEL)->SetFont( &m_fntStatic );

	// Calibration Result
	GetDlgItem(IDC_STATIC_CAL_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RANGE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RANGE_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AVG_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AVG_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2)->SetFont( &m_fntStatic );

	// Display Result
	m_stcDispRet.SetFont( &m_fntStatic );
	m_stcDispRet.SetForeColor( RGB(255, 0, 0) );
	m_stcDispRet.SetBackColor( WHITE_COLOR );
	m_stcDispRet.SetWindowText( _T("X = 0.000, Y = 0.000") );

	// X Range
	m_stcRangeXMin.SetFont( &m_fntStatic );
	m_stcRangeXMin.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeXMin.SetBackColor( WHITE_COLOR );
	m_stcRangeXMin.SetWindowText( _T("0.0") );

	m_stcRangeXMax.SetFont( &m_fntStatic );
	m_stcRangeXMax.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeXMax.SetBackColor( WHITE_COLOR );
	m_stcRangeXMax.SetWindowText( _T("0.0") );

	// Y Range
	m_stcRangeYMin.SetFont( &m_fntStatic );
	m_stcRangeYMin.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeYMin.SetBackColor( WHITE_COLOR );
	m_stcRangeYMin.SetWindowText( _T("0.0") );

	m_stcRangeYMax.SetFont( &m_fntStatic );
	m_stcRangeYMax.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeYMax.SetBackColor( WHITE_COLOR );
	m_stcRangeYMax.SetWindowText( _T("0.0") );

	// X Avg
	m_stcAvgXVal.SetFont( &m_fntStatic );
	m_stcAvgXVal.SetForeColor( RGB(255, 0, 0) );
	m_stcAvgXVal.SetBackColor( WHITE_COLOR );
	m_stcAvgXVal.SetWindowText( _T("0.0") );

	// Y Avg
	m_stcAvgYVal.SetFont( &m_fntStatic );
	m_stcAvgYVal.SetForeColor( RGB(255, 0, 0) );
	m_stcAvgYVal.SetBackColor( WHITE_COLOR );
	m_stcAvgYVal.SetWindowText( _T("0.0") );

	GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->ShowWindow(SW_HIDE);
}

void CPaneSysSetupTableCal::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(120,_T("Arial Bold"));

	// Set Current Position
	m_btnSetCurPos.SetFont( &m_fntBtn );
	m_btnSetCurPos.SetFlat( FALSE );
	m_btnSetCurPos.EnableBallonToolTip();
	m_btnSetCurPos.SetToolTipText( _T("Set Current Position") );
	m_btnSetCurPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetCurPos.SetBtnCursor(IDC_HAND_1);

	// Load Calibration Data
	m_btnLoadCalData.SetFont( &m_fntBtn );
	m_btnLoadCalData.SetFlat( FALSE );
	m_btnLoadCalData.EnableBallonToolTip();
	m_btnLoadCalData.SetToolTipText( _T("Load Calibration Data") );
	m_btnLoadCalData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCalData.SetBtnCursor(IDC_HAND_1);

	// Start
	m_btnCalStart.SetFont( &m_fntBtn );
	m_btnCalStart.SetRectAlign( 0 ); 
	m_btnCalStart.SetToolTipText( _T("Calibration Start") );
	m_btnCalStart.SetBtnCursor( IDC_HAND_1 );

	// Apply
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// make xy.cal file
	m_btnMakeCalFile.SetFont( &m_fntBtn );
	m_btnMakeCalFile.SetFlat( FALSE );
	m_btnMakeCalFile.EnableBallonToolTip();
	m_btnMakeCalFile.SetToolTipText( _T("Make xy.calibration") );
	m_btnMakeCalFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMakeCalFile.SetBtnCursor(IDC_HAND_1);

	// Show Vision
	m_btnShowVision.SetFont( &m_fntBtn );
	m_btnShowVision.SetFlat( FALSE );
	m_btnShowVision.EnableBallonToolTip();
	m_btnShowVision.SetToolTipText( _T("Show Vision") );
	m_btnShowVision.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShowVision.SetBtnCursor(IDC_HAND_1);

	// Verify
	m_btnVerify.SetFont( &m_fntBtn );
	m_btnVerify.SetFlat( FALSE );
	m_btnVerify.EnableBallonToolTip();
	m_btnVerify.SetToolTipText( _T("Verify") );
	m_btnVerify.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVerify.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupTableCal::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150,_T("Arial Bold"));

	// Mechanical Setting
	m_edtStartX.SetFont( &m_fntEdit );
	m_edtStartX.SetForeColor( BLACK_COLOR );
	m_edtStartX.SetBackColor( WHITE_COLOR );
	m_edtStartX.SetReceivedFlag( 3 );
	m_edtStartX.SetWindowText( _T("100.0") );

	m_edtStartY.SetFont( &m_fntEdit );
	m_edtStartY.SetForeColor( BLACK_COLOR );
	m_edtStartY.SetBackColor( WHITE_COLOR );
	m_edtStartY.SetReceivedFlag( 3 );
	m_edtStartY.SetWindowText( _T("100.0") );

	// Grid
	m_edtGridX.SetFont( &m_fntEdit );
	m_edtGridX.SetForeColor( BLACK_COLOR );
	m_edtGridX.SetBackColor( WHITE_COLOR );
	m_edtGridX.SetReceivedFlag( 1 );
	m_edtGridX.SetWindowText( _T("59") );

	m_edtGridY.SetFont( &m_fntEdit );
	m_edtGridY.SetForeColor( BLACK_COLOR );
	m_edtGridY.SetBackColor( WHITE_COLOR );
	m_edtGridY.SetReceivedFlag( 1 );
	m_edtGridY.SetWindowText( _T("70") );

	// Cal Gap
	m_edtCalGap.SetFont( &m_fntEdit );
	m_edtCalGap.SetForeColor( BLACK_COLOR );
	m_edtCalGap.SetBackColor( WHITE_COLOR );
	m_edtCalGap.SetReceivedFlag( 3 );
	m_edtCalGap.SetWindowText( _T("10.0") );
}

void CPaneSysSetupTableCal::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130,_T("Arial Bold"));

	m_cmbUseVision.SetFont( &m_fntCombo );
	
	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("Vision");
		m_cmbUseVision.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("High Vision");
		m_cmbUseVision.AddString("Low Vision");
		break;
	}

	m_cmbUseVision.SetCurSel( 1 );
#ifdef __USE_ONLY_LOW_CAM__
	m_cmbUseVision.ResetContent();
	m_cmbUseVision.AddString("1'st Vision");
	m_cmbUseVision.AddString("2'nd Vision");
	m_cmbUseVision.SetCurSel( 0 );
#endif
}

HBRUSH CPaneSysSetupTableCal::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_START_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_1ST_PANEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_RESULT)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupTableCal::SetPictureBackground()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_TABLE));
	CRect cRect;
	GetDlgItem(IDC_STATIC_TABLE)->GetClientRect(&cRect);
	CBrush cBr(RGB(0, 0, 0));
	dc.FrameRect(&cRect, &cBr);
	cRect.DeflateRect(1, 1);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));

	SetDCCoord(&dc);
	if (m_bStopDraw)	return;

	for (int i = 0; i < m_nYPixelNum; i++)
	{
		if (m_bStopDraw)	return;
		dc.MoveTo(0, i * 1000);
		dc.LineTo((m_nXPixelNum - 1) * 1000, i * 1000);
	}

	for(int i =  0; i < m_nXPixelNum; i++)
	{
		if (m_bStopDraw)	return;
		dc.MoveTo(i * 1000, 0);
		dc.LineTo(i * 1000, (m_nYPixelNum - 1) * 1000);
	}
}

void CPaneSysSetupTableCal::SetDCCoord(CDC *pDC)
{
	CRect cRect;
	GetDlgItem(IDC_STATIC_TABLE)->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	
	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12));
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(12));
	
	if (m_bStopDraw)	return;
	pDC->SetMapMode(MM_ANISOTROPIC);
	pDC->SetWindowOrg(0, 0);
	pDC->SetViewportOrg(nXOffset, cRect.Height() - nYOffset);
	pDC->SetViewportExt(cRect.Width(), -cRect.Height());
	pDC->SetWindowExt((m_nXPixelNum - 1) * 1200, (m_nYPixelNum - 1) * 1200);
}

void CPaneSysSetupTableCal::DrawCalibration()
{
	SetPictureBackground();

	if (m_bSuccess == FALSE || m_bStopDraw == TRUE )
		return;
	
	CClientDC dc(GetDlgItem(IDC_STATIC_TABLE));
	CRect cRect;
	GetDlgItem(IDC_STATIC_TABLE)->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	dc.SelectClipRgn(&cRgn);
	
	SetDCCoord(&dc);
	if (m_bStopDraw)	return;

	int nHRadius, nPenSize;
	nPenSize = 60;
	nHRadius = 200;

	int nVRadius = static_cast<int>(static_cast<double>(nHRadius) * m_nYPixelNum / m_nXPixelNum + 0.5);

	CPen pen;
	CPen* pOldPen;
	CBrush cBr;
	CBrush* pOldBrush;

	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = dc.SelectObject(&pen);
		
	cBr.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = dc.SelectObject(&cBr);

	const double dRatio = 0.3;

	for (int i = 0; i < m_nXPixelNum; i++)
	{
		for (int j = 0; j < m_nYPixelNum; j++)
		{
			int nX = i * 1000 + static_cast<int>(dRatio * 1000 * m_dpDraw[i * m_nYPixelNum + j].x / m_dMaxOffset + 0.5);
			int nY = j * 1000 + static_cast<int>(dRatio * 1000 * m_dpDraw[i * m_nYPixelNum + j].y / m_dMaxOffset + 0.5);
			
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);
			
			dc.Ellipse(nX - nHRadius, nY - nVRadius, nX + nHRadius, nY + nVRadius);
		}
	}
	for(int i =  0; i < m_nYPixelNum; i++)
	{
		for (int j = 0; j < m_nXPixelNum; j++)
		{
			if (m_bStopDraw)	return;

			int nX = j * 1000 + static_cast<int>(dRatio * 1000 * m_dpDraw[j * m_nYPixelNum + i].x / m_dMaxOffset + 0.5);
			int nY = i * 1000 + static_cast<int>(dRatio * 1000 * m_dpDraw[j * m_nYPixelNum + i].y / m_dMaxOffset + 0.5);
			
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);
			
			dc.Ellipse(nX - nHRadius, nY - nVRadius, nX + nHRadius, nY + nVRadius);
		}
	}

	dc.SelectObject(pOldBrush);
	dc.SelectObject(pOldPen);
}

void CPaneSysSetupTableCal::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	DrawCalibration();
}

void CPaneSysSetupTableCal::OnButtonLoadCalData() 
{
	double XCal = 0;
	double YCal = 0;
	UpdateData(TRUE);
	TCHAR szFilters[] = _T("CalGrid Files (*.txt)|*.*||");

	CFileDialog filedlg(TRUE,_T(".txt"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR | OFN_NONETWORKBUTTON, szFilters, this);

	filedlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();

	m_bRotateCalDone = FALSE;
	m_nFoundIndex = -1;

	TRY
	{
		m_dpArray.SetSize(m_nXPixelNum * m_nYPixelNum);
	}
	CATCH (CMemoryException, e)
	{
		return;
	}
	END_CATCH
	
	if (IDOK == filedlg.DoModal() )
	{
		m_bStopDraw = TRUE;
		m_dpDraw.SetSize(m_nXPixelNum * m_nYPixelNum);
		m_bStopDraw = FALSE;

		if(m_pXCal != NULL)
		{
			delete[] m_pXCal;
			m_pXCal = NULL;
		}

		if(m_pYCal != NULL)
		{
			delete[] m_pYCal;
			m_pYCal = NULL;
		}

		m_pXCal = new double[m_nXPixelNum * m_nYPixelNum];
		m_pYCal = new double[m_nXPixelNum * m_nYPixelNum];
		
		double dStartOffsetX, dStartOffsetY;
		
		CString filepath = filedlg.GetPathName();
		std::ifstream file;
		TCHAR buf[40];
		int nCount = 0;
		memset(buf, 0, sizeof(buf));
		file.open(filepath, std::ios::in);
		if(file.fail())
		{
			ErrMessage(_T("Cal. Grid File is incorrect file!"));
			delete []m_pXCal;
			delete []m_pYCal;
			m_pXCal = m_pYCal = NULL;
			file.close();
			return;
		}
		while(nCount < m_nXPixelNum * m_nYPixelNum)
		{
			file.getline(buf, sizeof(buf), _T('\n'));
			sscanf_s(buf,_T("%lf\t%lf"), &XCal, &YCal);
			if(nCount == 0)
			{
				dStartOffsetX = XCal;
				dStartOffsetY = YCal;
			}
			m_pXCal[nCount] = XCal - dStartOffsetX;
			m_pYCal[nCount] = YCal - dStartOffsetY;
			nCount++;
		}
		
		if(!file.eof())
		{
			ErrMessage(_T("Cal. Grid File is incorrect file!"));
			delete []m_pXCal;
			delete []m_pYCal;
			m_pXCal = m_pYCal = NULL;
			file.close();
			return;
		}
		
		file.close();
	}
	else
	{
		m_bStopDraw = TRUE;
		m_dpDraw.SetSize(m_nXPixelNum * m_nYPixelNum);
		m_bStopDraw = FALSE;
	}
}

BOOL CPaneSysSetupTableCal::DoCalibration()
{
	ConnectView();

	DPOINT dpReal;
	TCHAR szBuf[255];
	
	m_dMaxOffset = 0.0;
	m_dMaxOffsetX = m_dMaxOffsetY = -100.0;
	m_dMinOffsetX = m_dMinOffsetY = 100.0;
	m_dAvgX = m_dAvgY = 0.0;
	m_bSuccess = FALSE;
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		if(m_pXCal)
			delete [] m_pXCal;
	
		if(m_pYCal)
			delete [] m_pYCal;
		m_pXCal = new double[m_nXPixelNum * m_nYPixelNum];
		m_pYCal = new double[m_nXPixelNum * m_nYPixelNum];
		memset(m_pXCal, NULL, sizeof(double)*m_nXPixelNum * m_nYPixelNum);
		memset(m_pYCal, NULL, sizeof(double)*m_nXPixelNum * m_nYPixelNum);
	}
	
	if(m_pXCal == NULL || m_pYCal == NULL)	return FALSE;

	double dXPos, dYPos;

	FILE * pFile;
	errno_t err;
	CString strPath;
	strPath.Format(_T("%sTemp\\CalGridOffset.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());

	err = fopen_s(&pFile, strPath,_T("w+"));

	BOOL bSuccess = TRUE;

	DPOINT* dpOffset = NULL;
	int nXmax, nYmax;
	nXmax = (int)((m_nXPixelNum - 1)/ 9);
	nYmax = (int)((m_nYPixelNum - 1)/ 9);
	TRY
	{
		dpOffset = new DPOINT[(nXmax + 1) * (nYmax + 1)];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		ErrMessage(_T("Can't create Data."));
		return FALSE;
	}
	END_CATCH

	int nCam = m_cmbUseVision.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	int nCheckAxis;
	if(nCam < 2)
	{
		m_nUsePanel = AXIS_Z1;
		nCheckAxis = IND_Z1;
	}
	else
	{
		m_nUsePanel = AXIS_Z2;
		nCheckAxis = IND_Z2;
	}

	double dPosZ = 0.0;
	m_dStartPosZ = gDeviceFactory.GetMotor()->GetPosition(m_nUsePanel);

	m_dGap = 90.0;

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_UMAC_PROGRAM)
	{

		if(IDYES == ErrMessage(_T("Areas to the Z-axis settings Yes, press No to use the existing settings."), MB_YESNO))
		{
			for(int y = 0 ; y <= nYmax; y++)
			{
				for(int x = 0; x <= nXmax; x++)
				{
					if((y % 2) == 0)
					{
						dXPos = m_dXStartPos - x * m_dGap;
					}
					else
					{
						dXPos = m_dXStartPos - (nXmax - x) * m_dGap;
					}
					
					dYPos = m_dYStartPos - y * m_dGap;

					TRACE("%d,%d, %.3f, %.3f\n", x, y, dXPos, dYPos);
					
					if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
					{
						if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
						{
							delete [] dpOffset;
							return FALSE;
						}
						if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
						{
							delete [] dpOffset;
							return FALSE;
						}
					}
					else
					{
						if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
						{
							delete [] dpOffset;
							return FALSE;
						}
					}

					gDeviceFactory.GetVision()->OnLive(nCam, TRUE);

					ErrMessage(_T("Move Z Axis and Click OK"));
					while(gDeviceFactory.GetMotor()->GetCurrentMode() == MODE_MPG)
					{
						ErrMessage(_T("Please MPG OFF and Click OK"));
					}

					gDeviceFactory.GetVision()->OnLive(nCam, FALSE);

					dPosZ = gDeviceFactory.GetMotor()->GetPosition(m_nUsePanel);

					if(y % 2)
					{
						dpOffset[x * (nYmax + 1) + (nYmax - y)].x = m_dStartPosZ - dPosZ;
					}
					else
					{
						dpOffset[(nXmax - x) * (nYmax + 1) + (nYmax - y)].x = m_dStartPosZ - dPosZ;
					}
				}
			}

					
			if(m_CalHead.dOffset)
			{
				delete [] m_CalHead.dOffset;
			}
			
			m_CalHead.dGap = m_dGap;
			m_CalHead.dOffset = dpOffset;
			m_CalHead.dXStart = m_dXStartPos - nXmax * m_CalHead.dGap ;
			m_CalHead.dYStart = m_dYStartPos - nYmax * m_CalHead.dGap ;		
			m_CalHead.nGridX = nXmax + 1;
			m_CalHead.nGridY = nYmax + 1;

			UpdateCalibration(m_CalHead);
			SaveCalibration(m_nUsePanel);
		}

		if(dpOffset != NULL)
		{
			delete [] dpOffset;
			dpOffset = NULL;
			m_CalHead.dOffset = NULL;
		}

		LoadData(m_nUsePanel);
	}

	double dOffsetZ = 0.0;
	DPOINT ptStart[2];

	if(!m_bRotateCalDone)
	{
		for (int j = 0; j < 2; j++)
		{
			if(!m_bStartCal)
				return FALSE;

			MessageLoop();

			dpReal.x = dpReal.y = 0;

			if(j == 0)
				dXPos = (m_dXStartPos);
			else
				dXPos = (m_dXStartPos) - (m_nXPixelNum - 1) * m_dCalGap ;
			dYPos = (m_dYStartPos) ;

			if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_UMAC_PROGRAM)
			{
				GetPartialCalibrationOffset(dXPos, dYPos, dOffsetZ);
				
				if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
				{
					if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
					{
						ErrMessage(_T("Z-axis Move Command Error. Please Retry."));
						return FALSE;
					}
					
					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
					{
						ErrMessage(_T("Z-axis Move Inposition Error. Please Retry."));
						return FALSE;
					}
				}
				else
				{
					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
					{
						ErrMessage(_T("Z-axis Move Inposition Error. Please Retry."));
						return FALSE;
					}
				}
			}

			while(TRUE)
			{
				dXPos = dXPos - dpReal.x;
				dYPos = dYPos - dpReal.y;

				if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
				{
					if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
					{
						ErrMessage(_T("X, Y-axis Move Command Error. Please Retry."));
						return FALSE;
					}

					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
					{
						ErrMessage(_T("X, Y-axis Move Inposition Error. Please Retry."));
						return FALSE;
					}
				}
				else
				{
					if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
					{
						ErrMessage(_T("X, Y-axis Move Inposition Error. Please Retry."));
						return FALSE;
					}
				}
				
				MessageLoop();
				::Sleep(gSystemINI.m_sSystemDevice.nCalGridDelay);

				for(int kk=0; kk<100; kk++)
				{
					int nIndexNo = 0;
					if(kk % 9 == 0 && kk > 0)
					{
						while(1)
						{
							if(IDOK == ErrMessage(_T("Hole Find Error 10 Times, Vision Check and Click OK")))
								break;
						}
					}
					bSuccess = gDeviceFactory.GetVision()->GetRealPos(&dpReal, nCam, MODEL_CIRCLE, FALSE);
					if(bSuccess == 1)
					{
						break;
					}
					else
					{
						if(kk==99)
						{
							ErrMessage(_T("There is a vision inspection in somewhere.\r\nTry again."));
							return FALSE;
						}
					}
				}
				if(fabs(dpReal.x) < 0.0015 && fabs(dpReal.y) < 0.0015)
				{
					ptStart[j].x = dXPos;
					ptStart[j].y = dYPos;
					break;
				}
			}
		}
		double dAngle = atan2(ptStart[1].y - ptStart[0].y + m_pYCal[m_nXPixelNum - 1], (m_nXPixelNum - 1) * m_dCalGap);
		double dCosTheta, dSinTheta, dTempX, dTempY;
		dCosTheta = cos(-dAngle);
		dSinTheta = sin(-dAngle);

		if(m_pXProofPos != NULL)
		{
			delete[] m_pXProofPos;
			m_pXProofPos = NULL;
		}
		if(m_pYProofPos != NULL)
		{
			delete[] m_pYProofPos;
			m_pYProofPos = NULL;
		}
		m_pXProofPos = new double[m_nXPixelNum * m_nYPixelNum];
		m_pYProofPos = new double[m_nXPixelNum * m_nYPixelNum];

		for (int i = 0; i < m_nYPixelNum ; i++)
		{
			for (int j = 0; j < m_nXPixelNum; j++)
			{
//				if((i % 2) == 0)
					dXPos = -j * m_dCalGap - m_pXCal[i * m_nXPixelNum + j];
//				else
//					dXPos = -(m_nXPixelNum - j - 1) * m_dCalGap - m_pXCal[i * m_nXPixelNum + j];
				dYPos = - i * m_dCalGap - m_pYCal[i * m_nXPixelNum + j];
				dTempX = dCosTheta*(dXPos) - dSinTheta*(dYPos) + ptStart[0].x;
				dTempY = dSinTheta*(dXPos) + dCosTheta*(dYPos) + ptStart[0].y;
				m_pXProofPos[i * m_nXPixelNum + j]  = dTempX;
				m_pYProofPos[i * m_nXPixelNum + j]  = dTempY;
			}
		}
		m_bRotateCalDone = TRUE;
	}

	dpReal.x = dpReal.y = 0;
	for (int i = 0; i < m_nXPixelNum * m_nYPixelNum ; i++)
	{
		if(!m_bStartCal)
			return FALSE;

		if(i <= m_nFoundIndex)
			continue;

		dXPos = m_pXProofPos[i];
		dYPos = m_pYProofPos[i];

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_UMAC_PROGRAM)
		{
			GetPartialCalibrationOffset(dXPos, dYPos, dOffsetZ);
			
			if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
			{
				if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
				{
					ErrMessage(_T("Z-axis Move Command Error. Please Retry."));
					return FALSE;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
				{
					ErrMessage(_T("Z-axis Move Inposition Error. Please Retry."));
					return FALSE;
				}
			}
			else
			{
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
				{
					ErrMessage(_T("Z-axis Move Inposition Error. Please Retry."));
					return FALSE;
				}
			}
		}

		int nFirstCnt = 0;

		while(TRUE)
		{
			nFirstCnt++;
			MessageLoop();
			dXPos = dXPos - dpReal.x;
			dYPos = dYPos - dpReal.y;

			if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
			{
				if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
				{
					ErrMessage(_T("X, Y-axis Move Command Error. Please Retry."));
					return FALSE;
				}

				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("X, Y-axis Move Inposition Error. Please Retry."));
					return FALSE;
				}
			}
			else
			{
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("X, Y-axis Move Inposition Error. Please Retry."));
					return FALSE;
				}
			}
			
			MessageLoop();
			
			if(nFirstCnt == 1)
				::Sleep(gSystemINI.m_sSystemDevice.nCalGridDelay);
			else
				::Sleep(50);

			for(int kk=0; kk<100; kk++)
			{
				int nIndexNo = 0;
				if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
					nIndexNo = 5;

				if(kk % 9 == 0 && kk > 0)
				{
					while(1)
					{
						if(IDOK == ErrMessage(_T("Hole Find Error 10 Times, Vision Check and Click OK")))
							break;
					}
				}

				bSuccess = gDeviceFactory.GetVision()->GetRealPos(&dpReal, nCam, MODEL_CIRCLE, FALSE);

				if(bSuccess == 1)
				{
					_stprintf_s(szBuf,_T("X : %.3f, Y : %.3f\0"), dpReal.x, dpReal.y);
					m_stcDispRet.SetWindowText(szBuf);
					break;
				}
				else
				{
					if(kk==99)
					{
						ErrMessage(_T("There is a vision inspection in somewhere.\r\nTry again."));
						return FALSE;
					}
				}
			}

			if(fabs(dpReal.x) < 0.0015 && fabs(dpReal.y) < 0.0015)
			{
				if(err != NULL)
					return FALSE;
				
				fprintf(pFile,_T("XPOS=%lf\tYPOS=%lf\tXOffset=%lf\tYOffset=%lf\n"),  m_pXProofPos[i],  m_pYProofPos[i], dXPos - dpReal.x - m_pXProofPos[i], dYPos - dpReal.y - m_pYProofPos[i]);
				
				m_dpArray[i].x = dXPos - dpReal.x - m_pXProofPos[i];
				m_dpArray[i].y = dYPos - dpReal.y - m_pYProofPos[i];

				if(i == m_nXPixelNum - 1)
				{
					if(fabs(m_dpArray[i].y - m_dpArray[0].y) > 0.0015)
					{
						m_bRotateCalDone = FALSE;
						m_nFoundIndex = -1;
						ErrMessage(_T("Table angle repeat fail. try again chick start"));
						return FALSE;
					}
				}

				dpReal.x = -m_dpArray[i].x;
				dpReal.y = -m_dpArray[i].y;
				
				
				_stprintf_s(szBuf,_T("X : %.3f, Y : %.3f\0"), m_dpArray[i].x, m_dpArray[i].y);
				m_stcDispRet.SetWindowText(szBuf);
				
				if (m_dpArray[i].x > m_dMaxOffsetX)	m_dMaxOffsetX = m_dpArray[i].x;
				if (m_dpArray[i].x < m_dMinOffsetX)	m_dMinOffsetX = m_dpArray[i].x;
				
				if (m_dpArray[i].y > m_dMaxOffsetY)	m_dMaxOffsetY = m_dpArray[i].y;
				if (m_dpArray[i].y < m_dMinOffsetY)	m_dMinOffsetY = m_dpArray[i].y;
				
				m_dAvgX += m_dpArray[i].x;
				m_dAvgY += m_dpArray[i].y;

				m_nFoundIndex = i;
				break;
			}
		}
	}
	m_bSuccess = TRUE;
	fclose(pFile);
	return TRUE;
}

void CPaneSysSetupTableCal::CalOffset()
{
	// 1) real offset ���ϱ� + ù���� �������� �̵�(ù���� offset = 0�� ��)
	moveOffset();
	// 2) calgrid�� table�� rotate angle�� ���Ͽ� �� �縸ŭ �ݴ�� ȸ��
	rotateOffset();
}

void CPaneSysSetupTableCal::moveOffset()
{
	double dStartOffsetX = 0., dStartOffsetY = 0.;

	CString strPath;
	strPath.Format(_T("%sTemp\\moved.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	
	FILE* movefile;
	errno_t err = fopen_s(&movefile, strPath,_T("w+"));
	for (int i = 0; i < m_nYPixelNum ; i++)
	{
		for (int j = 0; j < m_nXPixelNum; j++)
		{
			if(i==0 && j==0) // ù���̸�
			{
//				TRACE("m_dp[%d][%d].x = %f m_dp[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
				
				dStartOffsetX = m_dpArray[i * m_nXPixelNum + j].x - m_pXCal[i * m_nXPixelNum + j];
				dStartOffsetY = m_dpArray[i * m_nXPixelNum + j].y - m_pYCal[i * m_nXPixelNum + j];
				m_dpArray[i * m_nXPixelNum + j].x = 0.;
				m_dpArray[i * m_nXPixelNum + j].y = 0.;
				if(err == NULL)
					fprintf(movefile,_T("offsetX=%lf\t offsetY=%lf\n"), dStartOffsetX, dStartOffsetY);
//				TRACE("m_dpArray[%d][%d].x = %f m_dpArray[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
			}
			else
			{
//				TRACE("m_dp[%d][%d].x = %f m_dp[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
				m_dpArray[i * m_nXPixelNum + j].x -= (m_pXCal[i * m_nXPixelNum + j]+dStartOffsetX);
				m_dpArray[i * m_nXPixelNum + j].y -= (m_pYCal[i * m_nXPixelNum + j]+dStartOffsetY);
//				TRACE("m_dpArray[%d][%d].x = %f m_dpArray[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
			}
			if(err == NULL)
				fprintf(movefile,_T("X=%lf\t Y=%lf calX=%lf\t calY=%lf\t \n"), m_dpArray[i * m_nXPixelNum + j].x, m_dpArray[i * m_nXPixelNum + j].y, m_pXCal[i * m_nXPixelNum + j],m_pYCal[i * m_nXPixelNum + j]);
			Sleep(2);
		}
	}
	
	if(err == NULL)
		fclose(movefile);	
}

void CPaneSysSetupTableCal::rotateOffset()
{
	// ���� �Ʒ����� ������ ���������� tan���� ���Ͽ�, �� �� ����� 2���� ���� ��ճ���.
	CString strPath;
	strPath.Format(_T("%sTemp\\rotated.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	
	FILE* rotatefile;
	errno_t err = fopen_s(&rotatefile, strPath,_T("w+"));

	double dTan1, dTan2, dTan3, dTanV, dAngle;
	double dis1, dis2, dis3;
	dTan1 = m_dpArray[m_nXPixelNum-3].y/((m_nXPixelNum-3)*m_dCalGap);
	dTan2 = m_dpArray[m_nXPixelNum-2].y/((m_nXPixelNum-2)*m_dCalGap);
	dTan3 = m_dpArray[m_nXPixelNum-1].y/((m_nXPixelNum-1)*m_dCalGap);

	dis1 = fabs(dTan1-dTan2) + fabs(dTan1-dTan3);
	dis2 = fabs(dTan2-dTan1) + fabs(dTan2-dTan3);
	dis3 = fabs(dTan3-dTan2) + fabs(dTan3-dTan1);

	if(err == NULL)
		fprintf(rotatefile,_T("rotate angle1=%lf\t 2=%lf 3=%lf\t \n"), dTan1, dTan2, dTan3);
	
	if(dis1>dis2)
	{
		if(dis1>dis3)
			dTanV = (dTan2+dTan3)/2.;
		else
			dTanV = (dTan1+dTan2)/2.;
	}
	else
	{
		if(dis2>dis3)
			dTanV = (dTan1+dTan3)/2.;
		else
			dTanV = (dTan1+dTan2)/2.;
	}
	dAngle = -atan(dTanV);
	if(err == NULL)
		fprintf(rotatefile,_T("last Tan =%lf\t last angle=%lf XS=%.3f YS=%.3f\n"), dTanV, dAngle, m_dXStartPos - 0.00444, m_dYStartPos + 0.03649);
	// ������ ���� ������ŭ ��� ȸ�� ���Ѿ� �Ѵ�.
	double posX, posY, tempX, tempY;
	for (int i = 0; i < m_nYPixelNum ; i++)
	{
		for (int j = 0; j < m_nXPixelNum; j++)
		{
			if ( i%2 ) posX = (m_nXPixelNum -j -1) * m_dCalGap;
			else	posX = j * m_dCalGap;

			posY = i*m_dCalGap;

//			TRACE("m_dp[%d][%d].x = %f m_dp[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
			
			tempX = cos(dAngle)*(posX+m_dpArray[i * m_nXPixelNum + j].x) -sin(dAngle)*(posY+m_dpArray[i * m_nXPixelNum + j].y) - posX;
			tempY = sin(dAngle)*(posX+m_dpArray[i * m_nXPixelNum + j].x) +cos(dAngle)*(posY+m_dpArray[i * m_nXPixelNum + j].y) - posY;
			
			m_dpArray[i * m_nXPixelNum + j].x = -tempX;
			m_dpArray[i * m_nXPixelNum + j].y = -tempY;
//			TRACE("m_dpArray[%d][%d].x = %f m_dpArray[%d][%d].y = %f\n", j,i,m_dpArray[i * m_nXPixelNum + j].x, j,i,m_dpArray[i * m_nXPixelNum + j].y);
			if(err == NULL)
				fprintf(rotatefile,_T("X=%lf\t Y=%lf calX=%lf\t calY=%lf\t posX=%lf\t posY=%lf\t \n"), m_dpArray[i * m_nXPixelNum + j].x, m_dpArray[i * m_nXPixelNum + j].y, m_pXCal[i * m_nXPixelNum + j],m_pYCal[i * m_nXPixelNum + j], posX, posY);
			Sleep(2);
		}
	}
	if(err == NULL)
		fclose(rotatefile);
}

void CPaneSysSetupTableCal::OnButtonStart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	
	BOOL bPower, bShutter;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		bPower = nPower;
		bShutter = nShutter;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(nPower & 0x02) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x02)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		if(nPower & 0x03) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x03)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}
	
	if(bPower && bShutter)
	{
		ErrMsgDlg(STDGNALM307);
		return;
	}

#ifndef __TEST__
	BYTE nMode = gDeviceFactory.GetMotor()->GetCurrentMode();
	if (nMode != MODE_MANUAL)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(gDeviceFactory.GetMotor()->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
#endif

	if(m_bStartCal)
	{
		m_bStartCal = FALSE;
		return;
	}
	
	GetDlgItem(IDC_BUTTON_CAL_START)->SetWindowText("Stop");

	m_bStartCal = TRUE;

	UpdateData(TRUE);
	
	EnableAllButton(FALSE);
	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(TRUE);

	if (DoCalibration())
	{
//		CalOffset();
		TRY
		{
			m_bStopDraw = TRUE;
			::Sleep(10);

			m_dpDraw.SetSize(m_nXPixelNum * m_nYPixelNum);

			for(int i =0; i < m_nYPixelNum; i++)
			{
				for(int j =0; j < m_nXPixelNum; j++)
				{
					if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
					{
						m_dpDraw[m_nXPixelNum*m_nYPixelNum-1 - m_nYPixelNum*j - i] = m_dpArray[m_nXPixelNum * i + j ];
					}
					else
					{
//						if(i%2 ==0)
							m_dpDraw[m_nXPixelNum*m_nYPixelNum-1 - m_nYPixelNum*j - i] = m_dpArray[m_nXPixelNum * i + j ];
//						else
//							m_dpDraw[m_nXPixelNum*m_nYPixelNum-1 - m_nYPixelNum*(m_nXPixelNum-j-1) - i] = m_dpArray[m_nXPixelNum * i + j ];

					}
				}
			}
	
			m_bStopDraw = FALSE;
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			GetDlgItem(IDC_BUTTON_CAL_START)->SetWindowText(_T("Start"));
			m_bStartCal = FALSE;
			EnableAllButton(TRUE);

			return;
		}
		END_CATCH

		TCHAR szBuf[255];
		_stprintf_s(szBuf,_T("%.3f "), m_dMinOffsetX);
		m_stcRangeXMin.SetWindowText(szBuf);
		_stprintf_s(szBuf,_T("%.3f "), m_dMinOffsetY);
		m_stcRangeYMin.SetWindowText(szBuf);
		_stprintf_s(szBuf,_T("%.3f "), m_dMaxOffsetX);
		m_stcRangeXMax.SetWindowText(szBuf);
		_stprintf_s(szBuf,_T("%.3f "), m_dMaxOffsetY);
		m_stcRangeYMax.SetWindowText(szBuf);
		_stprintf_s(szBuf,_T("%.3f "), m_dAvgX/(m_nXPixelNum * m_nYPixelNum));
		m_stcAvgXVal.SetWindowText(szBuf);
		_stprintf_s(szBuf,_T("%.3f "), m_dAvgY/(m_nXPixelNum * m_nYPixelNum));
		m_stcAvgYVal.SetWindowText(szBuf);
		m_bStopDraw = FALSE;
		m_bSuccess = TRUE;
		Invalidate();

	}
	else
	{
		ErrMessage(_T("Table Calibration Failure."));
	}

	EnableAllButton(TRUE);
	GetDlgItem(IDC_BUTTON_CAL_START)->SetWindowText("Start");
	m_bStartCal = FALSE;

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		if(SavePLC())
		{
			gSystemINI.m_sSystemDevice.d2DCompTableOffset.x = -m_dXStartPos;
			gSystemINI.m_sSystemDevice.d2DCompTableOffset.y = -m_dYStartPos;

			// Save System INI File
			CString strFilePath;
			CSystemINIFile clsSystemINI;
			strFilePath.Format(_T("%sSystem.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
			clsSystemINI.SaveSystemINIFile( strFilePath, gSystemINI );
		}
	}
}

void CPaneSysSetupTableCal::OnButtonApply() 
{
	if (m_bSuccess == FALSE || m_bStopDraw == TRUE)
		return;

	m_bRotateCalDone = FALSE;
	m_nFoundIndex = -1;

	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(FALSE);
	
	CWaitCursor wait;

	CString strFileName = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	strFileName += TABLE_CALIBRATION_FILE;

	CFileStatus cFileStatus;
	
	EnableAllButton(FALSE);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(TRUE);

	TRY
	{
		if (CFile::GetStatus(strFileName, cFileStatus))
		{
			cFileStatus.m_attribute |= CFile::readOnly;
			cFileStatus.m_attribute ^= CFile::readOnly;

			CFile::SetStatus(strFileName, cFileStatus);
		}
		
		if (SaveFile(strFileName))
		{
			if (CFile::GetStatus(strFileName, cFileStatus))
			{
				cFileStatus.m_attribute |= CFile::readOnly;

				CFile::SetStatus(strFileName, cFileStatus);
			}
			else
			{
				ErrMessage(_T("File operation Error"));

				EnableAllButton(TRUE);
				GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(TRUE);
				return;
			}
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();

		EnableAllButton(TRUE);
		GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(TRUE);
		return;
	}
	END_CATCH

	m_bStopDraw = FALSE;
	EnableAllButton(TRUE);
	return;

/*	gDeviceFactory.GetMotor()->UpdateCalibrationFile(gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	strFileName.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetBackupDir());
	CTime cTime(CTime::GetCurrentTime());
	CString strDate = cTime.Format(_T("%Y%m%d%H%M"));
	strFileName += strDate;
	strFileName += TABLE_CALIBRATION_FILE;
	SaveFile(strFileName);

	CString strEvent, strInfo;
	strEvent = _T("Applied XY Table calibration.");
	strInfo.Format(_T("Starting Position = (%.3f, %.3f) | Calibration Size = (%.3f, %.3f) | Field Size = %.3f | Grid Size = %d x %d | Thickness = %.3f | X Range = (%.3f, %.3f) | Y Range = (%.3f, %.3f) |Average Offset = (%.3f, %.3f)"),
		m_dXStartPos, m_dYStartPos, (m_nXPixelNum-1)*m_dCalGap, (m_nYPixelNum-1)*m_dCalGap, m_dCalGap, m_nXPixelNum, m_nYPixelNum, m_dCalThick, m_dMinOffsetX, m_dMaxOffsetX, m_dMinOffsetY, m_dMaxOffsetY, m_dAvgX, m_dAvgY);
	
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
*/
//	EnableAllButton(TRUE);
//	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(TRUE);
//	m_bSuccess = FALSE;
}

void CPaneSysSetupTableCal::OnButtonSetCurPos() 
{
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, m_dXStartPos);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, m_dYStartPos);
	
	UpdateData(FALSE);
}

void CPaneSysSetupTableCal::OnButtonShowVision() 
{
/*
	if( NULL == m_pVisionOnly )
	{
		m_pVisionOnly = new CDlgVisionOnly;
		m_pVisionOnly->Create( this );
	}

	if( NULL != m_pVisionOnly )
	{
		if( FALSE == m_pVisionOnly->IsWindowVisible() )
			m_pVisionOnly->ShowWindow( SW_SHOW );
	}
*/

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		if( FALSE != ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->IsWindowVisible() )
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			m_btnShowVision.SetWindowText("Show Vision");
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
			m_btnShowVision.SetWindowText("Hide Vision");
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		if( FALSE != ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->IsWindowVisible() )
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			m_btnShowVision.SetWindowText("Show Vision");
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
			m_btnShowVision.SetWindowText("Hide Vision");
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if( FALSE != ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->IsWindowVisible() )
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			m_btnShowVision.SetWindowText("Show Vision");
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
			m_btnShowVision.SetWindowText("Hide Vision");
		}
	}
}

void CPaneSysSetupTableCal::OnDestroy() 
{
	if( NULL != m_pVisionOnly )
	{
		m_pVisionOnly->DestroyWindow();
		delete m_pVisionOnly;
		m_pVisionOnly	= NULL;
	}

	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntCombo.DeleteObject();

	if(m_pXProofPos != NULL)
	{
		delete [] m_pXProofPos;
		m_pXProofPos = NULL;
	}
	if(m_pYProofPos != NULL)
	{
		delete [] m_pYProofPos;
		m_pYProofPos = NULL;
	}
	
	m_dpArray.RemoveAll();
	m_dpDraw.RemoveAll();
	
	if(m_pXCal !=NULL)
	{
		delete [] m_pXCal;
		m_pXCal = NULL;
	}
	
	if(m_pYCal !=NULL)
	{
		delete [] m_pYCal;
		m_pYCal = NULL;
	}
	
	if(m_CalHead.dOffset)
	{
		delete [] m_CalHead.dOffset;
		m_CalHead.dOffset = NULL;
	}
	
	if(m_Offset)
	{
		delete [] m_Offset;
		m_Offset = NULL;
	}
	
	CFormView::OnDestroy();
}

void CPaneSysSetupTableCal::ConnectView()
{
//	CRect rtPos;
//	GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->GetWindowRect( rtPos );
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_HIDE );
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(TABLE_CAL_VISION_VIEW);
//	m_btnShowVision.SetWindowText("Show Vision");

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(TABLE_CAL_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		

	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(TABLE_CAL_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );

	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(TABLE_CAL_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		

	}
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->ShowWindow(SW_HIDE);
	int nCamNo = m_cmbUseVision.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	OnCamChange( nCamNo );
}

void CPaneSysSetupTableCal::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

void CPaneSysSetupTableCal::OnSelchangeComboUseVision() 
{
	int nCamNo = m_cmbUseVision.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	pVision->OnCamChange( nCamNo );
	pVision->OnLive(nCamNo,TRUE);
}

void CPaneSysSetupTableCal::OnMoveVisionView()
{
	CRect rtPos;
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_TABLE_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

BOOL CPaneSysSetupTableCal::SaveFile(const CString& strFileName)
{
	FILE* fp = NULL;
	
	if (NULL == fopen_s(&fp, strFileName,_T("w")))
	{
		fprintf(fp,_T("%d\t%d\t%f\n"), m_nXPixelNum, m_nYPixelNum, m_dCalGap);
		
		// index = GridSize * nX + nY
		for (int i = 0; i < m_nXPixelNum; i++)
		{
			for (int j = 0; j < m_nYPixelNum; j++)
			{
				fprintf(fp,_T("%lf\t%lf\t%lf\t%lf\n"),
					m_dXStartPos + (-m_nXPixelNum + i + 1) * m_dCalGap,
					m_dYStartPos + (-m_nYPixelNum + j + 1) * m_dCalGap,
					m_dpDraw[m_nYPixelNum * i + j].x,
					m_dpDraw[m_nYPixelNum * i + j].y);
			}
		}
		
		fclose(fp);
		
		CString strEvent, strInfo;
		strEvent = _T("Saved XY Table calibration file.");
		strInfo.Format(_T("Calibration File = %s | Starting Position = (%.3f, %.3f) | Calibration Size = (%.3f, %.3f) | Field Size = %.3f | Grid Size = %d x %d | Thickness = %.3f | X Range = (%.3f, %.3f) | Y Range = (%.3f, %.3f) |Average Offset = (%.3f, %.3f)"),
			strFileName, m_dXStartPos, m_dYStartPos, (m_nXPixelNum-1)*m_dCalGap, (m_nYPixelNum-1)*m_dCalGap, m_dCalGap, m_nXPixelNum, m_nYPixelNum, m_dCalThick, m_dMinOffsetX, m_dMaxOffsetX, m_dMinOffsetY, m_dMaxOffsetY, m_dAvgX, m_dAvgY);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
		
		return TRUE;
	}
	else
	{
		ErrMessage(_T("Can not write file"));
		return FALSE;
	}
}

void CPaneSysSetupTableCal::OnProof() 
{
	// TODO: Add your control notification handler code here
	DPOINT dpReal;
	TCHAR szBuf[255];
	
	m_dMaxOffset = 0.0;
	m_dMaxOffsetX = m_dMaxOffsetY = -100.0;
	m_dMinOffsetX = m_dMinOffsetY = 100.0;
	m_dAvgX = m_dAvgY = 0.0;
	m_bSuccess = FALSE;
	
	if(m_pXProofPos == NULL || m_pYProofPos == NULL)	return;
	
	double dXPos, dYPos;

	if(m_bStartProof)
	{
		m_bStartProof = FALSE;
		return;
	}
	
	GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Stop");
	EnableAllButton(FALSE);
	GetDlgItem(IDC_BUTTON_VERIFY)->EnableWindow(TRUE);
	
	m_bStartProof = TRUE;
	
	FILE * pFile;
	errno_t err;
	CString strPath;
	strPath.Format(_T("%sTemp\\CalGridProof.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	
	err = fopen_s(&pFile, strPath,_T("w+"));

	BOOL bSuccess = TRUE;

	double dOffsetZ = 0.0;

	int nCam = m_cmbUseVision.GetCurSel();

	int nCheckAxis;
	if(nCam < 2)
	{
		m_nUsePanel = AXIS_Z1;
		nCheckAxis = IND_Z1;
	}
	else
	{
		m_nUsePanel = AXIS_Z2;
		nCheckAxis = IND_Z2;
	}

	m_dStartPosZ = gDeviceFactory.GetMotor()->GetPosition(m_nUsePanel);

	LoadData(m_nUsePanel);
		
	for (int i = 0; i < m_nYPixelNum *m_nXPixelNum; i++)
	{
		if(!m_bStartProof)
		{
			GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
			m_bStartProof = FALSE;
			fclose(pFile);
			EnableAllButton(TRUE);
			return;
		}
		
			dXPos = m_pXProofPos[i];
			dYPos = m_pYProofPos[i];

			if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
			{
				if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return ;
				}
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return ;
				}
			}
			else
			{
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return ;
				}
			}

			GetPartialCalibrationOffset(dXPos, dYPos, dOffsetZ);

			if(dOffsetZ != 0.0)
				::Sleep(1);
			
			if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
			{
				if (!gDeviceFactory.GetMotor()->MotorMoveAxis(m_nUsePanel, m_dStartPosZ - dOffsetZ))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return;
				}
			}
			else
			{
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(nCheckAxis))
				{
					GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
					m_bStartProof = FALSE;
					fclose(pFile);
					EnableAllButton(TRUE);
					return;
				}
			}
#ifndef __TEST__
			::Sleep(200);
#endif			
			MessageLoop();

			::Sleep(gSystemINI.m_sSystemDevice.nCalGridDelay);

			for(int kk=0; kk<100; kk++)
			{
				int nIndexNo = 6;
				if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
					nIndexNo = 5;

				if(kk % 9 == 0 && kk > 0)
				{
					while(1)
					{
						if(IDOK == ErrMessage(_T("Hole Find Error 10 Times, Vision Check and Click OK")))
							break;
					}
				}
				
				bSuccess = gDeviceFactory.GetVision()->GetRealPos(&dpReal, nCam, MODEL_CIRCLE, FALSE);

				if(bSuccess == 1)
				{
					if(err != NULL)
					{
						GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
						m_bStartProof = FALSE;
						fclose(pFile);
						EnableAllButton(TRUE);
						return;
					}
					
					Sleep(2);
					_stprintf_s(szBuf,_T("X : %.3f, Y : %.3f\0"), dpReal.x, dpReal.y);
					m_stcDispRet.SetWindowText(szBuf);
					fprintf(pFile,_T("XPOS=%lf\tYPOS=%lf\tXOffset=%lf\tYOffset=%lf\n"), dXPos, dYPos, dpReal.x, dpReal.y);
					break;
				}
				else
				{
					if(kk==99)
					{
						ErrMessage(_T("There is a vision inspection in somewhere.\r\nTry again."));
						GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
						m_bStartProof = FALSE;
						fclose(pFile);
						EnableAllButton(TRUE);
						return;
					}
				}
			}
	}
	fclose(pFile);

	EnableAllButton(TRUE);
	GetDlgItem(IDC_BUTTON_VERIFY)->SetWindowText("Verify");
	m_bStartProof = FALSE;

	return;
}

void CPaneSysSetupTableCal::GetCalibrationOffset(double dX, double dY, double& dOffset)
{
	GetPartialCalibrationOffset(dX, dY, dOffset);
}

void CPaneSysSetupTableCal::GetPartialCalibrationOffset(double dX, double dY, double& dOffset)
{
	if (IsPartialInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);

		double dXDist = dX - m_dXStart - m_dGap * nX;
		double dYDist = dY - m_dYStart - m_dGap * nY;

		double ax, bx;

		if (nX == m_nGridX - 1)
			ax = m_Offset[m_nGridY * nX + nY].x;
		else
			ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			bx = ax;
		else if (nX == m_nGridX - 1 && nY != m_nGridY - 1)
			bx = m_Offset[m_nGridY * nX + nY + 1].x;
		else
			bx = m_Offset[m_nGridY * nX + nY + 1].x + (m_Offset[m_nGridY * (nX + 1) + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x) * dXDist / m_dGap;

		dOffset = ax + (bx - ax) * dYDist / m_dGap;
	}
	else if (IsInside(dX, dY))
	{
		if (m_dXStart < MIN_TABLE || m_dXEnd > MAX_TABLE || m_dYStart < MIN_TABLE || m_dYEnd > MAX_TABLE)
		{
			dOffset = 0.0;
			return;
		}

		if (dX < m_dXStart && dY < m_dYStart)
		{
			dOffset = m_Offset[0].x;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = 0;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY;
			
			if (nX == m_nGridX - 1)
				dOffset = m_Offset[m_nGridY * nX].x;
			else
				dOffset = m_Offset[m_nGridY * nX].x + (m_Offset[m_nGridY * (nX + 1)].x - m_Offset[m_nGridY * nX].x) * dXDist / m_dGap;
			
		}
		else if (dX > m_dXEnd && dY < m_dYStart)
		{
			dOffset = m_Offset[m_nGridY * (m_nGridX - 1) + 0].x;
		}
		else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = 0;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[nY].x;
			if (nY == m_nGridY - 1)
				dOffset = m_Offset[nY].x;
			else
				dOffset = m_Offset[nY].x + (m_Offset[nY + 1].x - m_Offset[nY].x) * dYDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = m_nGridX - 1;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			if (nY == m_nGridY - 1)
				dOffset = m_Offset[m_nGridY * nX + nY].x;
			else
				dOffset = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * nX + nY + 1].x - m_Offset[m_nGridY * nX + nY].x) * dYDist / m_dGap;

		}
		else if (dX < m_dXStart && dY > m_dYEnd)
		{
			dOffset = m_Offset[m_nGridY * 0 + m_nGridY - 1].x;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = m_nGridY - 1;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY - m_dYEnd;
			
			if (nX == m_nGridX - 1)
				dOffset = m_Offset[m_nGridY * nX + nY].x;
			else
				dOffset = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY > m_dYEnd)
		{
			dOffset = m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x;
		}
		else
			dOffset= 0.0;
	}
	else
		dOffset = 0.0;
}

BOOL CPaneSysSetupTableCal::IsPartialInside(double dX, double dY)
{
	if (dX >= m_dXStart && dX <= m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		return TRUE;
	else
		return FALSE;
}

BOOL CPaneSysSetupTableCal::IsInside(double dX, double dY)
{
	if (dX >= MIN_TABLE && dX <= MAX_TABLE && dY >= MIN_TABLE && dY <= MAX_TABLE)
		return TRUE;
	else
		return FALSE;
}

BOOL CPaneSysSetupTableCal::LoadCalibration(int nUsePanel)
{	
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;

	CString strPath;
	strPath.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	CString strFile;
	if(nUsePanel == AXIS_Z1)
		strFile =_T(".Z1");
	else
		strFile =_T(".Z2");

	CString strFileName(strPath + WHOLE_Z_CALIBRATION_FILE + strFile);
	
	if (NULL == fopen_s(&fp, strFileName,_T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return FALSE;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return FALSE;
		}
		END_CATCH

		double dX = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1000.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dX = atof(token);

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = 0;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		UpdateCalibration(calHead);
		delete [] dpOffset;
		return TRUE;
	}
	else
		return FALSE;
}

void CPaneSysSetupTableCal::SaveCalibration(int nUsePanel)
{
	FILE *fp = NULL;

	CString strPath;
	strPath.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	CString strFile;
	if(nUsePanel == AXIS_Z1)
		strFile =_T(".Z1");
	else
		strFile =_T(".Z2");

	CString strFileName(strPath + WHOLE_Z_CALIBRATION_FILE + strFile);

	if (NULL == fopen_s(&fp, strFileName,_T("w")))
	{
		fprintf(fp,_T("%d\t%d\t%f\n"), m_nGridX, m_nGridY, m_dGap);
		
		// index = GridSize * nX + nY
		for (int i = 0; i < m_nGridX; i++)
		{
			for (int j = 0; j < m_nGridY; j++)
			{
				fprintf(fp,_T("%lf\t%lf\t%lf\n"),
					m_dXEnd + (-m_nGridX + i + 1) * m_dGap,
					m_dYEnd + (-m_nGridY + j + 1) * m_dGap,
					m_Offset[i * m_nGridY + j].x);
			}
		}
		
		fclose(fp);
		return;
	}
	else
	{
		ErrMessage(_T("Can not write file"));
		return;
	}
}

void CPaneSysSetupTableCal::SetMatrixToZero()
{
	m_nGridX = 2;
	m_nGridY = 2;
	m_dGap = 90;
	m_dXStart = 500;
	m_dXEnd = 590;
	m_dYStart = 500;
	m_dYEnd = 590;
	
	TRY
	{
		if(m_Offset)
		{
			delete [] m_Offset;
			m_Offset = NULL;
		}
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		m_Offset[0].x = 0.;
		m_Offset[0].y = 0.;
		m_Offset[1].x = 0.;
		m_Offset[1].y = 0.;
		m_Offset[2].x = 0.;
		m_Offset[2].y = 0.;
		m_Offset[3].x = 0.;
		m_Offset[3].y = 0.;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		m_nGridX = 0;
		m_nGridY = 0;
		m_dGap = 0.0;
		m_dXStart = 0.0;
		m_dXEnd = 0.0;
		m_dYStart = 0.0;
		m_dYEnd = 0.0;
		m_Offset = NULL;
		
		return;
	}
	END_CATCH
}

void CPaneSysSetupTableCal::UpdateCalibration(const CALHEAD& calHead)
{
	m_nGridX = calHead.nGridX;
	m_nGridY = calHead.nGridY;
	m_dGap = calHead.dGap;
	m_dXStart = calHead.dXStart;
	m_dXEnd = m_dXStart + m_dGap * (m_nGridX - 1);
	m_dYStart = calHead.dYStart;
	m_dYEnd = m_dYStart + m_dGap * (m_nGridY - 1);
	
	TRY
	{
		delete [] m_Offset;
		m_Offset = NULL;
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		memcpy(m_Offset, calHead.dOffset, sizeof(DPOINT) * m_nGridX * m_nGridY);
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		m_nGridX = 0;
		m_nGridY = 0;
		m_dGap = 0.0;
		m_dXStart = 0.0;
		m_dXEnd = 0.0;
		m_dYStart = 0.0;
		m_dYEnd = 0.0;
		m_Offset = NULL;

		return;
	}
	END_CATCH
}

void CPaneSysSetupTableCal::LoadData(int nUsePanel)
{
	if(!LoadCalibration(nUsePanel))
		SetMatrixToZero();
}

void CPaneSysSetupTableCal::EnableAllButton(BOOL bEnable)
{
	GetDlgItem(IDC_BUTTON_SET_CUR_POS)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_LOAD_CAL_DATA)->EnableWindow(bEnable);

	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_VERIFY)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDIT_START_X)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_START_Y)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_X)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_Y)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_CAL_GAP)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_USE_VISION)->EnableWindow(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}

void CPaneSysSetupTableCal::ClearMem()
{
	if(m_pXProofPos != NULL)
	{
		delete [] m_pXProofPos;
		m_pXProofPos = NULL;
	}
	if(m_pYProofPos != NULL)
	{
		delete [] m_pYProofPos;
		m_pYProofPos = NULL;
	}
	
	m_dpArray.RemoveAll();
	m_dpDraw.RemoveAll();
	
	if(m_pXCal !=NULL)
	{
		delete [] m_pXCal;
		m_pXCal = NULL;
	}
	
	if(m_pYCal !=NULL)
	{
		delete [] m_pYCal;
		m_pYCal = NULL;
	}
	
	if(m_CalHead.dOffset)
	{
		delete [] m_CalHead.dOffset;
		m_CalHead.dOffset = NULL;
	}
	
	if(m_Offset)
	{
		delete [] m_Offset;
		m_Offset = NULL;
	}
}

void CPaneSysSetupTableCal::EnableControl(BOOL bUse)
{
	GetDlgItem(IDC_BUTTON_SET_CUR_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_LOAD_CAL_DATA)->EnableWindow(bUse);
	
	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_VERIFY)->EnableWindow(bUse);
	
	GetDlgItem(IDC_EDIT_START_X)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_START_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_GRID_X)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_GRID_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_EDIT_CAL_GAP)->EnableWindow(bUse);

	GetDlgItem(IDC_COMBO_USE_VISION)->EnableWindow(bUse);
}

void CPaneSysSetupTableCal::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}

BOOL CPaneSysSetupTableCal::SavePLC()
{
	CStdioFile sFile, sOffsetFile;
	CString strFileName, strOffsetFileName, strToleranceFileName, strOffsetToleranceFileName;
	int nMultipleCount = 0;

	CTime CurTime = CTime::GetCurrentTime();
	CString strMsg;

	strMsg.Format(_T("%04d-%02d-%02d_%02dH_%02dM_%dmm"), CurTime.GetYear(), CurTime.GetMonth(), CurTime.GetDay(),
													 CurTime.GetHour(), CurTime.GetMinute(), int(m_dCalGap));

	strFileName.Format(_T("%s2DCompensation(%s).plc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), strMsg);
	if(FALSE == sFile.Open( strFileName, CFile::modeCreate|CFile::modeWrite|CFile::typeText ) )
	{
		CString strMsg;

		strMsg.Format(_T("Can't Save %s file  "), strFileName);
		ErrMessage(strMsg, MB_ICONERROR);

		return FALSE;
	}

	strOffsetFileName.Format(_T("%sVisionOffset(%s).txt"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), strMsg);
	if( FALSE == sOffsetFile.Open( strOffsetFileName, CFile::modeCreate|CFile::modeWrite|CFile::typeText ) )
	{
		CString strMsg;

		strMsg.Format(_T("Can't not save %s file "), strOffsetFileName);
		ErrMessage(strMsg, MB_ICONERROR);

		sFile.Close();
		
		return FALSE;
	}

	CPoint nStageSize;
	int nGridX, nGridY;
	nGridX = m_nXPixelNum - 1;
	nGridY = m_nYPixelNum - 1;

	nStageSize.x	= long( double(nGridX+1) * m_dCalGap * 6400 /*STAGE_X_FACTOR*/ );
	nStageSize.y	= long( double(nGridY+1) * m_dCalGap * 6400 /*STAGE_Y_FACTOR*/ );

	CString strSetData;
	CString strOffset;

	strSetData.Format(_T("CLOSE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("END GAT\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("DEL GAT\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("#1 DELETE COMP\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("#2 DELETE COMP\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("#2 DEF COMP %ld.%ld, #22D, #21D, #2, %ld, %ld\n"), nGridY+1, nGridX+1, nStageSize.x, nStageSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	DPOINT*		pTolerance = NULL;
	TCHAR szTemp[40] = {0,};
	TCHAR szOffsetTemp[40] = {0,};
	TCHAR szToleranceTemp[40] = {0,};
	TCHAR szOffsetToleranceTemp[40] = {0,};
	int nIndex = 0, nToleranceIndex = 0;

	// X Axis(#2)
	for( int i = 0 ; i < (nGridY+2) ; i++ )
	{
		for( int j = 0 ; j < (nGridX+2) ; j++ )
		{
			if( 0 == j && 0 == i )
			{
				_stprintf_s( szTemp,_T("%c"), _T(' ') );
				strSetData.Format(_T("%10s"), szTemp);
				sFile.WriteString( (LPCTSTR)strSetData );
				sOffsetFile.WriteString( (LPCTSTR)strSetData );
				continue;
			}

			if( 0 != j && 0 == j % 24 )
			{
				strSetData.Format(_T("\n"));
				sFile.WriteString( (LPCTSTR)strSetData );
			}

			if( i <= nGridY )
			{
				if( j > nGridX )
					nIndex = ( ( nGridX+1) * i ) + 0;
				else
					nIndex = ( ( nGridX+1) * i ) + j;
			}
			else
			{
				if( j > nGridX )
					nIndex = 0;
				else
					nIndex = j;
			}

//			if( NULL == pData )
//			{
//				_stprintf_s( szTemp,_T("%ld,"), 0 );
//				_stprintf_s( szOffsetTemp,_T("%.4f,"), 0.);
//				_stprintf_s( szToleranceTemp,_T("%ld,"), 0);
//				_stprintf_s( szOffsetToleranceTemp,_T("%.4f,"), 0.);
//			}
//			else
			{
				if( 0 == i && (nGridX+1) == j )
				{
					_stprintf_s( szTemp,_T("%ld,"), 0 );
					_stprintf_s( szOffsetTemp,_T("%.4f,"), 0.);
					_stprintf_s( szToleranceTemp,_T("%ld,"), 0);
					_stprintf_s( szOffsetToleranceTemp,_T("%.4f,"), 0.);
				}
				else if( (nGridY+1) == i && 0 == j )
				{
					_stprintf_s( szTemp,_T("%ld,"), 0 );
					_stprintf_s( szOffsetTemp,_T("%.4f,"), 0.);
					_stprintf_s( szToleranceTemp,_T("%ld,"), 0);
					_stprintf_s( szOffsetToleranceTemp,_T("%.4f,"), 0.);
				}
				else if( (nGridY+1) == i && (nGridX+1) == j )
				{
					_stprintf_s( szTemp,_T("%ld "), 0 );
					_stprintf_s( szOffsetTemp,_T("%.4f "), 0.);
					_stprintf_s( szToleranceTemp,_T("%ld "), 0);
					_stprintf_s( szOffsetToleranceTemp,_T("%.4f "), 0.);
				}
				else
				{
					long nOffset = 0;

					nOffset = long( m_dpArray[ nIndex ].x * 16 * 6400 /*STAGE_X_FACTOR*/);
					_stprintf_s( szTemp,_T("%ld,"), nOffset );

					double dOffset = 0.;

					dOffset = -1. * m_dpArray[ nIndex ].x;
					_stprintf_s( szOffsetTemp,_T("%.4f,"), dOffset );

				}
			}
			
			strSetData.Format(_T("%10s"), szTemp);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("%10s"), szOffsetTemp);
			sOffsetFile.WriteString( (LPCTSTR)strSetData );

		}

		// new line
		strSetData.Format(_T("\n"));
		sFile.WriteString( (LPCTSTR)strSetData );
		sOffsetFile.WriteString( (LPCTSTR)strSetData );
	}

	strSetData.Format(_T("\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("#1 DEF COMP %ld.%ld, #22D, #21D, #1, %ld, %ld\n"), nGridY+1, nGridX+1, nStageSize.x, nStageSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );
	sOffsetFile.WriteString( (LPCTSTR)strSetData );

	// Y Axis(#1)
	for(int i = 0 ; i < (nGridY+2) ; i++ )
	{
		for( int j = 0 ; j < (nGridX+2) ; j++ )
		{
			if( 0 == j && 0 == i )
			{
				_stprintf_s( szTemp,_T("%c"), _T(' ') );
				strSetData.Format(_T("%10s"), szTemp);
				sFile.WriteString( (LPCTSTR)strSetData );
				sOffsetFile.WriteString( (LPCTSTR)strSetData );
				continue;
			}

			if( 0 != j && 0 == j % 24 )
			{
				strSetData.Format(_T("\n"));
				sFile.WriteString( (LPCTSTR)strSetData );
				//sOffsetFile.WriteString( (LPCTSTR)strSetData );
			}

			if( i <= nGridY )
			{
				if( j > nGridX )
					nIndex = ( ( nGridX+1) * i ) + 0;
				else
					nIndex = ( ( nGridX+1) * i ) + j;
			}
			else
			{
				if( j > nGridX )
					nIndex = 0;
				else
					nIndex = j;
			}

//			if( NULL == pData )
//			{
//				_stprintf_s( szTemp, 40,_T("%ld,"), 0 );
//				_stprintf_s( szOffsetTemp, 40,_T("%.4f,"), 0.);
//				_stprintf_s( szToleranceTemp, 40,_T("%ld,"), 0);
//				_stprintf_s( szOffsetToleranceTemp, 40,_T("%.4f,"), 0.);
//			}
//			else
			{
				if( 0 == i && (nGridX+1) == j )
				{
					_stprintf_s( szTemp, 40,_T("%ld,"), 0 );
					_stprintf_s( szOffsetTemp, 40,_T("%.4f,"), 0.);
					_stprintf_s( szToleranceTemp, 40,_T("%ld,"), 0);
					_stprintf_s( szOffsetToleranceTemp, 40,_T("%.4f,"), 0.);
				}
				else if( (nGridY+1) == i && 0 == j )
				{
					_stprintf_s( szTemp, 40,_T("%ld,"), 0 );
					_stprintf_s( szOffsetTemp, 40,_T("%.4f,"), 0.);
					_stprintf_s( szToleranceTemp, 40,_T("%ld,"), 0);
					_stprintf_s( szOffsetToleranceTemp, 40, _T("%.4f,"), 0.);
				}
				else if( (nGridY+1) == i && (nGridX+1) == j )
				{
					_stprintf_s( szTemp, 40, _T("%ld "), 0 );
					_stprintf_s( szOffsetTemp, 40, _T("%.4f "), 0.);
					_stprintf_s( szToleranceTemp, 40, _T("%ld "), 0);
					_stprintf_s( szOffsetToleranceTemp, 40, _T("%.4f "), 0.);
				}
				else
				{
					long nOffset = 0;

					nOffset = long( m_dpArray[ nIndex ].y * 16 * 6400 /*STAGE_Y_FACTOR*/);
					_stprintf_s( szTemp, 40, _T("%ld,"), nOffset );

					double dOffset = 0.;

					dOffset = -1. * m_dpArray[ nIndex ].y;
					_stprintf_s( szOffsetTemp, 40, _T("%.4f,"), dOffset );

				}
			}
			
			strSetData.Format(_T("%10s"), szTemp);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("%10s"), szOffsetTemp);
			sOffsetFile.WriteString( (LPCTSTR)strSetData );

		}

		// new line
		strSetData.Format(_T("\n"));
		sFile.WriteString( (LPCTSTR)strSetData );
		sOffsetFile.WriteString( (LPCTSTR)strSetData );
	}

	sFile.Close();
	sOffsetFile.Close();
	return TRUE;
}

void CPaneSysSetupTableCal::OnButtonMakeXycal() 
{
	// TODO: Add your control notification handler code here
	if(!m_bSuccess)
		return;

	gDeviceFactory.GetMotor()->UpdateCalibrationFile(gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	CString strEvent, strInfo;
	strEvent = _T("Applied XY Table calibration.");
	strInfo.Format(_T("Starting Position = (%.3f, %.3f) | Calibration Size = (%.3f, %.3f) | Field Size = %.3f | Grid Size = %d x %d | Thickness = %.3f | X Range = (%.3f, %.3f) | Y Range = (%.3f, %.3f) |Average Offset = (%.3f, %.3f)"),
		m_dXStartPos, m_dYStartPos, (m_nXPixelNum-1)*m_dCalGap, (m_nYPixelNum-1)*m_dCalGap, m_dCalGap, m_nXPixelNum, m_nYPixelNum, m_dCalThick, m_dMinOffsetX, m_dMaxOffsetX, m_dMinOffsetY, m_dMaxOffsetY, m_dAvgX, m_dAvgY);
	
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	GetDlgItem(IDC_BUTTON_CAL_START)->EnableWindow(TRUE);

	m_bSuccess = FALSE;
//	m_bStopDraw = FALSE;
}


BOOL CPaneSysSetupTableCal::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_TableCal) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupTableCal::OnBnClickedButtonTcalLog1()
{
	gVariable.SaveTableCalLog(TRUE);
}


void CPaneSysSetupTableCal::OnBnClickedButtonTcalLog2()
{
	gVariable.SaveTableCalLog(FALSE);
}
