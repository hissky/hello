// PaneManualControlIOMonitorOutputSub2Osan.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutputSub2Osan.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\Model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "..\model\deasydrillerini.h"
#include "paneautorun.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Osan

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutputSub2Osan, CFormView)

CPaneManualControlIOMonitorOutputSub2Osan::CPaneManualControlIOMonitorOutputSub2Osan()
	: CFormView(CPaneManualControlIOMonitorOutputSub2Osan::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutputSub2Osan)
	m_nTimerID = 0;
	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorOutputSub2Osan::~CPaneManualControlIOMonitorOutputSub2Osan()
{
}

void CPaneManualControlIOMonitorOutputSub2Osan::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutputSub2Osan)
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_ORI_POS, m_btnLoadCarr1OriPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_ALIGN_POS, m_btnLoadCarr1AlignPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_TABLE_POS, m_btnLoadCarr1TablePos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_CART_POS, m_btnLoadCarr1CartPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_ORI_POS, m_btnLoadCarr2OriPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_ALIGN_POS, m_btnLoadCarr2AlignPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_TABLE_POS, m_btnLoadCarr2TablePos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_CART_POS, m_btnLoadCarr2CartPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_SUCTION_ON, m_btnLoadCarr1SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_SUCTION_OFF, m_btnLoadCarr1SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_SUCTION_ON, m_btnLoadCarr2SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_SUCTION_OFF, m_btnLoadCarr2SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_LOADER_CLAMP, m_btnLoadClamp);
	DDX_Control(pDX, IDC_BUTTON_LOADER_UNCLAMP, m_btnLoadUnclamp);
	DDX_Control(pDX, IDC_BUTTON_LOADER_TABLE_FORWARD, m_btnLoadTableFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_TABLE_BACKWARD, m_btnLoadTableBwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN_FORWARD, m_btnLoadAlignFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN_BACKWARD, m_btnLoadAlignBwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_SHEET_TABLE_FORWARD, m_btnLoadSheetTableFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_SHEET_TABLE_BACKWARD, m_btnLoadSheetTableBwd);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_ORI_POS, m_btnUnloadCarr1OriPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_ALIGN_POS, m_btnUnloadCarr1AlignPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_TABLE_POS, m_btnUnloadCarr1TablePos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_CART_POS, m_btnUnloadCarr1CartPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_ORI_POS, m_btnUnloadCarr2OriPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_ALIGN_POS, m_btnUnloadCarr2AlignPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_TABLE_POS, m_btnUnloadCarr2TablePos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_CART_POS, m_btnUnloadCarr2CartPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_SUCTION_ON, m_btnUnloadCarr1SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_SUCTION_OFF, m_btnUnloadCarr1SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_SUCTION_ON, m_btnUnloadCarr2SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_SUCTION_OFF, m_btnUnloadCarr2SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_CLAMP, m_btnUnloadClamp);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_UNCLAMP, m_btnUnloadUnclamp);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_TABLE_FORWARD, m_btnUnloadTableFwd);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_TABLE_BACKWARD, m_btnUnloadTableBwd);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, m_btnLoadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, m_btnLoadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, m_btnUnloadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, m_btnUnloadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_UP_POS, m_btnLoadPicker1Up);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_UP_POS, m_btnLoadPicker2Up);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER3_UP_POS, m_btnLoadPicker3Up);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_UP_POS, m_btnUnloadPicker1Up);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_UP_POS, m_btnUnloadPicker2Up);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER3_UP_POS, m_btnUnloadPicker3Up);
	DDX_Control(pDX, IDC_BUTTON_LOADER_INIT, m_btnLoaderInit);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_INIT, m_btnUnloaderInit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutputSub2Osan, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutputSub2Osan)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_ORI_POS, OnButtonLoaderPicker1OriPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_ALIGN_POS, OnButtonLoaderPicker1AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_TABLE_POS, OnButtonLoaderPicker1TablePos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_CART_POS, OnButtonLoaderPicker1CartPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_ORI_POS, OnButtonLoaderPicker2OriPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_ALIGN_POS, OnButtonLoaderPicker2AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_TABLE_POS, OnButtonLoaderPicker2TablePos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_CART_POS, OnButtonLoaderPicker2CartPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_SUCTION_ON, OnButtonLoaderPicker1SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_SUCTION_OFF, OnButtonLoaderPicker1SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_SUCTION_ON, OnButtonLoaderPicker2SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_SUCTION_OFF, OnButtonLoaderPicker2SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_CLAMP, OnButtonLoaderClamp)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_UNCLAMP, OnButtonLoaderUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_TABLE_FORWARD, OnButtonLoaderTableForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_TABLE_BACKWARD, OnButtonLoaderTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN_FORWARD, OnButtonLoaderAlignForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN_BACKWARD, OnButtonLoaderAlignBackward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_SHEET_TABLE_FORWARD, OnButtonLoaderSheetTableForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_SHEET_TABLE_BACKWARD, OnButtonLoaderSheetTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_ORI_POS, OnButtonUnloaderPicker1OriPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_ALIGN_POS, OnButtonUnloaderPicker1AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_TABLE_POS, OnButtonUnloaderPicker1TablePos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_CART_POS, OnButtonUnloaderPicker1CartPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_ORI_POS, OnButtonUnloaderPicker2OriPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_ALIGN_POS, OnButtonUnloaderPicker2AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_TABLE_POS, OnButtonUnloaderPicker2TablePos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_CART_POS, OnButtonUnloaderPicker2CartPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_SUCTION_ON, OnButtonUnloaderPicker1SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_SUCTION_OFF, OnButtonUnloaderPicker1SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_SUCTION_ON, OnButtonUnloaderPicker2SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_SUCTION_OFF, OnButtonUnloaderPicker2SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_CLAMP, OnButtonUnloaderClamp)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_UNCLAMP, OnButtonUnloaderUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_TABLE_FORWARD, OnButtonUnloaderTableForward)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_TABLE_BACKWARD, OnButtonUnloaderTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, OnButtonOutputLoaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, OnButtonOutputLoaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, OnButtonOutputUnloaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, OnButtonOutputUnloaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_UP_POS, OnButtonOutputLoadPicker1UpPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_UP_POS, OnButtonOutputLoadPicker2UpPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER3_UP_POS, OnButtonOutputLoadPicker3UpPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_UP_POS, OnButtonOutputUnloadPicker1UpPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_UP_POS, OnButtonOutputUnloadPicker2UpPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER3_UP_POS, OnButtonOutputUnloadPicker3UpPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_INIT, OnButtonUnloaderInit)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_INIT, OnButtonLoaderInit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Osan diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutputSub2Osan::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutputSub2Osan::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Osan message handlers

void CPaneManualControlIOMonitorOutputSub2Osan::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();
}

void CPaneManualControlIOMonitorOutputSub2Osan::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	m_btnLoadCarr1OriPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1OriPos.SetFlat( FALSE );
	m_btnLoadCarr1OriPos.EnableBallonToolTip();
	m_btnLoadCarr1OriPos.SetToolTipText( _T("�δ���Ŀ1 �ʱ� ��ġ��") );
	m_btnLoadCarr1OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1OriPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1AlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1AlignPos.SetFlat( FALSE );
	m_btnLoadCarr1AlignPos.EnableBallonToolTip();
	m_btnLoadCarr1AlignPos.SetToolTipText( _T("�δ���Ŀ1 ����� ��ġ��") );
	m_btnLoadCarr1AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1AlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1TablePos.SetFont( &m_fntBtn );
	m_btnLoadCarr1TablePos.SetFlat( FALSE );
	m_btnLoadCarr1TablePos.EnableBallonToolTip();
	m_btnLoadCarr1TablePos.SetToolTipText( _T("�δ���Ŀ1 ���̺� ��ġ��") );
	m_btnLoadCarr1TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1TablePos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1CartPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1CartPos.SetFlat( FALSE );
	m_btnLoadCarr1CartPos.EnableBallonToolTip();
	m_btnLoadCarr1CartPos.SetToolTipText( _T("�δ���Ŀ1 īƮ ��ġ��") );
	m_btnLoadCarr1CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr2OriPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2OriPos.SetFlat( FALSE );
	m_btnLoadCarr2OriPos.EnableBallonToolTip();
	m_btnLoadCarr2OriPos.SetToolTipText( _T("�δ���Ŀ2 �ʱ� ��ġ��") );
	m_btnLoadCarr2OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2OriPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2AlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2AlignPos.SetFlat( FALSE );
	m_btnLoadCarr2AlignPos.EnableBallonToolTip();
	m_btnLoadCarr2AlignPos.SetToolTipText( _T("�δ���Ŀ2 ����� ��ġ��") );
	m_btnLoadCarr2AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2AlignPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2TablePos.SetFont( &m_fntBtn );
	m_btnLoadCarr2TablePos.SetFlat( FALSE );
	m_btnLoadCarr2TablePos.EnableBallonToolTip();
	m_btnLoadCarr2TablePos.SetToolTipText( _T("�δ���Ŀ2 ���̺� ��ġ��") );
	m_btnLoadCarr2TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2TablePos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2CartPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2CartPos.SetFlat( FALSE );
	m_btnLoadCarr2CartPos.EnableBallonToolTip();
	m_btnLoadCarr2CartPos.SetToolTipText( _T("�δ���Ŀ1 īƮ ��ġ��") );
	m_btnLoadCarr2CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1SuctionOn.SetFont( &m_fntBtn );
	m_btnLoadCarr1SuctionOn.SetFlat( FALSE );
	m_btnLoadCarr1SuctionOn.EnableBallonToolTip();
	m_btnLoadCarr1SuctionOn.SetToolTipText( _T("�δ���Ŀ1 �����ѱ�") );
	m_btnLoadCarr1SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1SuctionOn.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1SuctionOff.SetFont( &m_fntBtn );
	m_btnLoadCarr1SuctionOff.SetFlat( FALSE );
	m_btnLoadCarr1SuctionOff.EnableBallonToolTip();
	m_btnLoadCarr1SuctionOff.SetToolTipText( _T("�δ���Ŀ1 ���в���") );
	m_btnLoadCarr1SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr2SuctionOn.SetFont( &m_fntBtn );
	m_btnLoadCarr2SuctionOn.SetFlat( FALSE );
	m_btnLoadCarr2SuctionOn.EnableBallonToolTip();
	m_btnLoadCarr2SuctionOn.SetToolTipText( _T("�δ���Ŀ2 �����ѱ�") );
	m_btnLoadCarr2SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2SuctionOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2SuctionOff.SetFont( &m_fntBtn );
	m_btnLoadCarr2SuctionOff.SetFlat( FALSE );
	m_btnLoadCarr2SuctionOff.EnableBallonToolTip();
	m_btnLoadCarr2SuctionOff.SetToolTipText( _T("�δ���Ŀ2 ���в���") );
	m_btnLoadCarr2SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnLoadClamp.SetFont(&m_fntBtn );
	m_btnLoadClamp.SetFlat( FALSE );
	m_btnLoadClamp.EnableBallonToolTip();
	m_btnLoadClamp.SetToolTipText( _T("�δ� Ŭ����") );
	m_btnLoadClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadClamp.SetBtnCursor(IDC_HAND_1);

	m_btnLoadUnclamp.SetFont(&m_fntBtn );
	m_btnLoadUnclamp.SetFlat( FALSE );
	m_btnLoadUnclamp.EnableBallonToolTip();
	m_btnLoadUnclamp.SetToolTipText( _T("�δ� ��Ŭ����") );
	m_btnLoadUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnLoadTableFwd.SetFont(&m_fntBtn );
	m_btnLoadTableFwd.SetFlat( FALSE );
	m_btnLoadTableFwd.EnableBallonToolTip();
	m_btnLoadTableFwd.SetToolTipText( _T("�δ����̺� ����") );
	m_btnLoadTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadTableBwd.SetFont(&m_fntBtn );
	m_btnLoadTableBwd.SetFlat( FALSE );
	m_btnLoadTableBwd.EnableBallonToolTip();
	m_btnLoadTableBwd.SetToolTipText( _T("�δ����̺� ����") );
	m_btnLoadTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadAlignFwd.SetFont(&m_fntBtn );
	m_btnLoadAlignFwd.SetFlat( FALSE );
	m_btnLoadAlignFwd.EnableBallonToolTip();
	m_btnLoadAlignFwd.SetToolTipText( _T("�δ������ ����") );
	m_btnLoadAlignFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadAlignFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadAlignBwd.SetFont(&m_fntBtn );
	m_btnLoadAlignBwd.SetFlat( FALSE );
	m_btnLoadAlignBwd.EnableBallonToolTip();
	m_btnLoadAlignBwd.SetToolTipText( _T("�δ������ ����") );
	m_btnLoadAlignBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadAlignBwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadSheetTableFwd.SetFont(&m_fntBtn );
	m_btnLoadSheetTableFwd.SetFlat( FALSE );
	m_btnLoadSheetTableFwd.EnableBallonToolTip();
	m_btnLoadSheetTableFwd.SetToolTipText( _T("�δ���Ʈ���̺� ����") );
	m_btnLoadSheetTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadSheetTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadSheetTableBwd.SetFont(&m_fntBtn );
	m_btnLoadSheetTableBwd.SetFlat( FALSE );
	m_btnLoadSheetTableBwd.EnableBallonToolTip();
	m_btnLoadSheetTableBwd.SetToolTipText( _T("�δ���Ʈ���̺� ����") );
	m_btnLoadSheetTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadSheetTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1OriPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1OriPos.SetFlat( FALSE );
	m_btnUnloadCarr1OriPos.EnableBallonToolTip();
	m_btnUnloadCarr1OriPos.SetToolTipText( _T("��δ���Ŀ1 �ʱ� ��ġ��") );
	m_btnUnloadCarr1OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1OriPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1AlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1AlignPos.SetFlat( FALSE );
	m_btnUnloadCarr1AlignPos.EnableBallonToolTip();
	m_btnUnloadCarr1AlignPos.SetToolTipText( _T("��δ���Ŀ1 ����� ��ġ��") );
	m_btnUnloadCarr1AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1AlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1TablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1TablePos.SetFlat( FALSE );
	m_btnUnloadCarr1TablePos.EnableBallonToolTip();
	m_btnUnloadCarr1TablePos.SetToolTipText( _T("��δ���Ŀ1 ���̺� ��ġ��") );
	m_btnUnloadCarr1TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1TablePos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1CartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1CartPos.SetFlat( FALSE );
	m_btnUnloadCarr1CartPos.EnableBallonToolTip();
	m_btnUnloadCarr1CartPos.SetToolTipText( _T("��δ���Ŀ1 īƮ ��ġ��") );
	m_btnUnloadCarr1CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr2OriPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2OriPos.SetFlat( FALSE );
	m_btnUnloadCarr2OriPos.EnableBallonToolTip();
	m_btnUnloadCarr2OriPos.SetToolTipText( _T("��δ���Ŀ2 �ʱ� ��ġ��") );
	m_btnUnloadCarr2OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2OriPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2AlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2AlignPos.SetFlat( FALSE );
	m_btnUnloadCarr2AlignPos.EnableBallonToolTip();
	m_btnUnloadCarr2AlignPos.SetToolTipText( _T("��δ���Ŀ2 ����� ��ġ��") );
	m_btnUnloadCarr2AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2AlignPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2TablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2TablePos.SetFlat( FALSE );
	m_btnUnloadCarr2TablePos.EnableBallonToolTip();
	m_btnUnloadCarr2TablePos.SetToolTipText( _T("��δ���Ŀ2 ���̺� ��ġ��") );
	m_btnUnloadCarr2TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2TablePos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2CartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2CartPos.SetFlat( FALSE );
	m_btnUnloadCarr2CartPos.EnableBallonToolTip();
	m_btnUnloadCarr2CartPos.SetToolTipText( _T("��δ���Ŀ2 īƮ ��ġ��") );
	m_btnUnloadCarr2CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1SuctionOn.SetFont( &m_fntBtn );
	m_btnUnloadCarr1SuctionOn.SetFlat( FALSE );
	m_btnUnloadCarr1SuctionOn.EnableBallonToolTip();
	m_btnUnloadCarr1SuctionOn.SetToolTipText( _T("��δ���Ŀ 1�����ѱ�") );
	m_btnUnloadCarr1SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1SuctionOn.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1SuctionOff.SetFont( &m_fntBtn );
	m_btnUnloadCarr1SuctionOff.SetFlat( FALSE );
	m_btnUnloadCarr1SuctionOff.EnableBallonToolTip();
	m_btnUnloadCarr1SuctionOff.SetToolTipText( _T("��δ���Ŀ 1���в���") );
	m_btnUnloadCarr1SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr2SuctionOn.SetFont( &m_fntBtn );
	m_btnUnloadCarr2SuctionOn.SetFlat( FALSE );
	m_btnUnloadCarr2SuctionOn.EnableBallonToolTip();
	m_btnUnloadCarr2SuctionOn.SetToolTipText( _T("��δ���Ŀ 2�����ѱ�") );
	m_btnUnloadCarr2SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2SuctionOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2SuctionOff.SetFont( &m_fntBtn );
	m_btnUnloadCarr2SuctionOff.SetFlat( FALSE );
	m_btnUnloadCarr2SuctionOff.EnableBallonToolTip();
	m_btnUnloadCarr2SuctionOff.SetToolTipText( _T("��δ���Ŀ 2���в���") );
	m_btnUnloadCarr2SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadClamp.SetFont(&m_fntBtn );
	m_btnUnloadClamp.SetFlat( FALSE );
	m_btnUnloadClamp.EnableBallonToolTip();
	m_btnUnloadClamp.SetToolTipText( _T("��δ� Ŭ����") );
	m_btnUnloadClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadClamp.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadUnclamp.SetFont(&m_fntBtn );
	m_btnUnloadUnclamp.SetFlat( FALSE );
	m_btnUnloadUnclamp.EnableBallonToolTip();
	m_btnUnloadUnclamp.SetToolTipText( _T("��δ� ��Ŭ����") );
	m_btnUnloadUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadTableFwd.SetFont(&m_fntBtn );
	m_btnUnloadTableFwd.SetFlat( FALSE );
	m_btnUnloadTableFwd.EnableBallonToolTip();
	m_btnUnloadTableFwd.SetToolTipText( _T("��δ����̺� ����") );
	m_btnUnloadTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadTableBwd.SetFont(&m_fntBtn );
	m_btnUnloadTableBwd.SetFlat( FALSE );
	m_btnUnloadTableBwd.EnableBallonToolTip();
	m_btnUnloadTableBwd.SetToolTipText( _T("��δ����̺� ����") );
	m_btnUnloadTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarrCartPos.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos.SetFlat( FALSE );
	m_btnLoadCarrCartPos.EnableBallonToolTip();
	m_btnLoadCarrCartPos.SetToolTipText( _T("�δ� ĳ���� Elevator ��ġ��") );
	m_btnLoadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnLoadCarrTablePos.SetFont( &m_fntBtn );
	m_btnLoadCarrTablePos.SetFlat( FALSE );
	m_btnLoadCarrTablePos.EnableBallonToolTip();
	m_btnLoadCarrTablePos.SetToolTipText( _T("�δ��ɸ��� ���̺� ��ġ��") );
	m_btnLoadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrTablePos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadPicker1Up.SetFont( &m_fntBtn );
	m_btnLoadPicker1Up.SetFlat( FALSE );
	m_btnLoadPicker1Up.EnableBallonToolTip();
	m_btnLoadPicker1Up.SetToolTipText( _T("�δ���Ŀ1 Up ��ġ��") );
	m_btnLoadPicker1Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPicker1Up.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadPicker2Up.SetFont( &m_fntBtn );
	m_btnLoadPicker2Up.SetFlat( FALSE );
	m_btnLoadPicker2Up.EnableBallonToolTip();
	m_btnLoadPicker2Up.SetToolTipText( _T("�δ���Ŀ2 Up ��ġ��") );
	m_btnLoadPicker2Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPicker2Up.SetBtnCursor(IDC_HAND_1);

	m_btnLoadPicker3Up.SetFont( &m_fntBtn );
	m_btnLoadPicker3Up.SetFlat( FALSE );
	m_btnLoadPicker3Up.EnableBallonToolTip();
	m_btnLoadPicker3Up.SetToolTipText( _T("�δ���Ŀ3 Up ��ġ��") );
	m_btnLoadPicker3Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPicker3Up.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarrCartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrCartPos.SetFlat( FALSE );
	m_btnUnloadCarrCartPos.EnableBallonToolTip();
	m_btnUnloadCarrCartPos.SetToolTipText( _T("��δ� ĳ���� Elevator ��ġ��") );
	m_btnUnloadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrTablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarrTablePos.SetFlat( FALSE );
	m_btnUnloadCarrTablePos.EnableBallonToolTip();
	m_btnUnloadCarrTablePos.SetToolTipText( _T("��δ��ɸ��� ���̺� ��ġ��") );
	m_btnUnloadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrTablePos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadPicker1Up.SetFont( &m_fntBtn );
	m_btnUnloadPicker1Up.SetFlat( FALSE );
	m_btnUnloadPicker1Up.EnableBallonToolTip();
	m_btnUnloadPicker1Up.SetToolTipText( _T("��δ���Ŀ1 Up ��ġ��") );
	m_btnUnloadPicker1Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPicker1Up.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadPicker2Up.SetFont( &m_fntBtn );
	m_btnUnloadPicker2Up.SetFlat( FALSE );
	m_btnUnloadPicker2Up.EnableBallonToolTip();
	m_btnUnloadPicker2Up.SetToolTipText( _T("��δ���Ŀ2 Up ��ġ��") );
	m_btnUnloadPicker2Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPicker2Up.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadPicker3Up.SetFont( &m_fntBtn );
	m_btnUnloadPicker3Up.SetFlat( FALSE );
	m_btnUnloadPicker3Up.EnableBallonToolTip();
	m_btnUnloadPicker3Up.SetToolTipText( _T("��δ���Ŀ3 Up ��ġ��") );
	m_btnUnloadPicker3Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPicker3Up.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderInit.SetFont( &m_fntBtn );
	m_btnLoaderInit.SetFlat( FALSE );
	m_btnLoaderInit.EnableBallonToolTip();
	m_btnLoaderInit.SetToolTipText( _T("�δ� �ʱ�ȭ") );
	m_btnLoaderInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderInit.SetBtnCursor(IDC_HAND_1);

	m_btnUnloaderInit.SetFont( &m_fntBtn );
	m_btnUnloaderInit.SetFlat( FALSE );
	m_btnUnloaderInit.EnableBallonToolTip();
	m_btnUnloaderInit.SetToolTipText( _T("��δ� �ʱ�ȭ") );
	m_btnUnloaderInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderInit.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlIOMonitorOutputSub2Osan::UpdateStatus()
{
#ifndef __ADD_MELSEC_MOTOR__
	BOOL bStatus1, bStatus2;

	// LP1
	bStatus1 = m_pMotor->IsLP1P1Up();
	bStatus2 = m_pMotor->IsLP1P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnLoadCarr1OriPos.SetSelection(TRUE);
		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
		m_btnLoadCarr1TablePos.SetSelection(FALSE);
		m_btnLoadCarr1CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnLoadCarr1OriPos.SetSelection(FALSE);
		m_btnLoadCarr1AlignPos.SetSelection(TRUE);
		m_btnLoadCarr1TablePos.SetSelection(FALSE);
		m_btnLoadCarr1CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnLoadCarr1OriPos.SetSelection(FALSE);
		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
		m_btnLoadCarr1TablePos.SetSelection(TRUE);
		m_btnLoadCarr1CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnLoadCarr1OriPos.SetSelection(FALSE);
		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
		m_btnLoadCarr1TablePos.SetSelection(FALSE);
		m_btnLoadCarr1CartPos.SetSelection(TRUE);
	}
	
	// LP2
	bStatus1 = m_pMotor->IsLP2P1Up();
	bStatus2 = m_pMotor->IsLP2P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(TRUE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(FALSE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(TRUE);
		m_btnLoadCarr2TablePos.SetSelection(FALSE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(TRUE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(FALSE);
		m_btnLoadCarr2CartPos.SetSelection(TRUE);
	}

	
	// Picker1Vacuum
	bStatus1 = m_pMotor->IsLoaderPicker1Vacuum();
	m_btnLoadCarr1SuctionOn.SetSelection(bStatus1);
	m_btnLoadCarr1SuctionOff.SetSelection(!bStatus1);
	
	// Picker2Vacuum
	bStatus1 = m_pMotor->IsLoaderPicker2Vacuum();
	m_btnLoadCarr2SuctionOn.SetSelection(bStatus1);
	m_btnLoadCarr2SuctionOff.SetSelection(!bStatus1);



	// UP1
	bStatus1 = m_pMotor->IsULP1P1Up();
	bStatus2 = m_pMotor->IsULP1P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(TRUE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(FALSE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(TRUE);
		m_btnUnloadCarr1TablePos.SetSelection(FALSE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(TRUE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(FALSE);
		m_btnUnloadCarr1CartPos.SetSelection(TRUE);
	}
	
	// UP2
	bStatus1 = m_pMotor->IsULP2P1Up();
	bStatus2 = m_pMotor->IsULP2P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(TRUE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(FALSE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(TRUE);
		m_btnUnloadCarr2TablePos.SetSelection(FALSE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(TRUE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(FALSE);
		m_btnUnloadCarr2CartPos.SetSelection(TRUE);
	}
	
	// Picker1Vacuum
	bStatus1 = m_pMotor->IsUnloaderPicker1Vacuum();
	m_btnUnloadCarr1SuctionOn.SetSelection(bStatus1);
	m_btnUnloadCarr1SuctionOff.SetSelection(!bStatus1);
	
	// Picker2Vacuum
	bStatus1 = m_pMotor->IsUnloaderPicker2Vacuum();
	m_btnUnloadCarr2SuctionOn.SetSelection(bStatus1);
	m_btnUnloadCarr2SuctionOff.SetSelection(!bStatus1);


#else
		BOOL bStatus1;
	// LoaderClamp
	bStatus1 = m_pMotor->IsLoaderCartClamp();
	m_btnLoadClamp.SetSelection(bStatus1);
	m_btnLoadUnclamp.SetSelection(!bStatus1);
	
	// AlignTable
	bStatus1 = m_pMotor->IsLoaderAlignTableForward();
	m_btnLoadTableFwd.SetSelection(!bStatus1);
	m_btnLoadTableBwd.SetSelection(bStatus1);
	
	// AlignGuide
	bStatus1 = m_pMotor->IsAlignSheetTableForward();
	m_btnLoadAlignFwd.SetSelection(bStatus1);
	m_btnLoadAlignBwd.SetSelection(!bStatus1);
	
	// AlignSheetTable
	bStatus1 = m_pMotor->IsAlignGuideForward();
	m_btnLoadSheetTableFwd.SetSelection(bStatus1);
	m_btnLoadSheetTableBwd.SetSelection(!bStatus1);
	
	// AlignTable
	bStatus1 = m_pMotor->IsUnloaderCartClamp();
	m_btnUnloadClamp.SetSelection(bStatus1);
	m_btnUnloadUnclamp.SetSelection(!bStatus1);
	
	// UnloaderClamp
	bStatus1 = m_pMotor->IsUnloaderAlignTableForward(); // 2010.1.21 �ݴ��
	m_btnUnloadTableFwd.SetSelection(!bStatus1);
	m_btnUnloadTableBwd.SetSelection(bStatus1);

	LONG lStatus = m_pMotor->GetCurrentError(STATUS_HANDLER_LOADER);
	if(lStatus & 0x00010000)
		m_btnLoadCarrCartPos.SetSelection(TRUE);
	else
		m_btnLoadCarrCartPos.SetSelection(FALSE);

	if(lStatus & 0x00020000)
		m_btnLoadCarrTablePos.SetSelection(TRUE);
	else
		m_btnLoadCarrTablePos.SetSelection(FALSE);

	if(lStatus & 0x00040000)
		m_btnLoadPicker1Up.SetSelection(TRUE);
	else
		m_btnLoadPicker1Up.SetSelection(FALSE);

	if(lStatus & 0x00080000)
		m_btnLoadPicker2Up.SetSelection(TRUE);
	else
		m_btnLoadPicker2Up.SetSelection(FALSE);

	if(lStatus & 0x00100000)
		m_btnLoadPicker3Up.SetSelection(TRUE);
	else
		m_btnLoadPicker3Up.SetSelection(FALSE);

	lStatus = m_pMotor->GetCurrentError(STATUS_HANDLER_UNLOADER);	
	if(lStatus & 0x00001000)
		m_btnUnloadCarrCartPos.SetSelection(TRUE);
	else
		m_btnUnloadCarrCartPos.SetSelection(FALSE);
	
	if(lStatus & 0x00002000)
		m_btnUnloadCarrTablePos.SetSelection(TRUE);
	else
		m_btnUnloadCarrTablePos.SetSelection(FALSE);
	
	if(lStatus & 0x00004000)
		m_btnUnloadPicker1Up.SetSelection(TRUE);
	else
		m_btnUnloadPicker1Up.SetSelection(FALSE);
	
	if(lStatus & 0x00008000)
		m_btnUnloadPicker2Up.SetSelection(TRUE);
	else
		m_btnUnloadPicker2Up.SetSelection(FALSE);
	
	if(lStatus & 0x00010000)
		m_btnUnloadPicker3Up.SetSelection(TRUE);
	else
		m_btnUnloadPicker3Up.SetSelection(FALSE);

	if(m_pMotor->IsHandlerInitEnd(HANDLER_LC) && m_pMotor->IsHandlerInitEnd(HANDLER_LP1) && m_pMotor->IsHandlerInitEnd(HANDLER_LP2) && m_pMotor->IsHandlerInitEnd(HANDLER_LP2))
		m_btnLoaderInit.SetSelection(TRUE);
	else
		m_btnLoaderInit.SetSelection(FALSE);

	if(m_pMotor->IsHandlerInitEnd(HANDLER_UC) && m_pMotor->IsHandlerInitEnd(HANDLER_UP1) && m_pMotor->IsHandlerInitEnd(HANDLER_UP2) && m_pMotor->IsHandlerInitEnd(HANDLER_UP2))
		m_btnUnloaderInit.SetSelection(TRUE);
	else
		m_btnUnloaderInit.SetSelection(FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorOutputSub2Osan::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9982, 1000, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
}

void CPaneManualControlIOMonitorOutputSub2Osan::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1OriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1AlignPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Align();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1TablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1P2();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1CartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Load();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2OriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2AlignPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Align();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2TablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2P2();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2CartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Load();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1SuctionOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	//	gDeviceFactory.GetMotor()->LoaderVacuum1On();
	gDeviceFactory.GetMotor()->SetPickerVacuum(TRUE,  TRUE,  TRUE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker1SuctionOff() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
//	gDeviceFactory.GetMotor()->LoaderVacuum1Off();
	
	gDeviceFactory.GetMotor()->SetPickerVacuum(TRUE,  TRUE,  FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2SuctionOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->LoaderVacuum2On();
	gDeviceFactory.GetMotor()->SetPickerVacuum(TRUE,  FALSE,  TRUE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderPicker2SuctionOff() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->LoaderVacuum2Off();
	gDeviceFactory.GetMotor()->SetPickerVacuum(TRUE,  FALSE,  FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderClamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderClampForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderUnclamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderClampBackward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderTableForward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderTableForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderTableBackward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderTableBackward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderAlignForward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignXForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderAlignBackward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignXBackward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderSheetTableForward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignYForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderSheetTableBackward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignYBackward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1OriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1AlignPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Table();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1TablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1P2();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1CartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Unload();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2OriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2AlignPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Table();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2TablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2P2();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2CartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Unload();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1SuctionOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->UnloaderVacuum1On();	
	gDeviceFactory.GetMotor()->SetPickerVacuum(FALSE,  TRUE,  TRUE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker1SuctionOff() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->UnloaderVacuum1Off();
	gDeviceFactory.GetMotor()->SetPickerVacuum(FALSE,  TRUE,  FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2SuctionOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->UnloaderVacuum2On();
	gDeviceFactory.GetMotor()->SetPickerVacuum(FALSE,  FALSE,  TRUE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderPicker2SuctionOff() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	//gDeviceFactory.GetMotor()->UnloaderVacuum2Off();
	gDeviceFactory.GetMotor()->SetPickerVacuum(FALSE,  FALSE,  FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderClamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderClampForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderUnclamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderClampBackward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderTableForward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderTableForward();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderTableBackward() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderTableBackward();
}

BOOL CPaneManualControlIOMonitorOutputSub2Osan::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoaderCarrCartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierAlignPos();	
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoaderCarrTablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierLoadPos();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloaderCarrCartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloaderCarrTablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierTablePos();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoadPicker1UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoadPicker2UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoadPicker3UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderPicker3Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloadPicker1UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloadPicker2UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloadPicker3UpPos()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderPicker3Init();
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputLoaderInit()
{
//	if( m_pMotor->IsAnyError() )
//	{
//		ErrMessage(_T("Must do error reset")); // 110603
//		return;
//	}
	
	// TODO: Add your control notification handler code here
//	m_pMotor->HandlerOperation(HANDLER_LOADER_INIT);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonOutputUnloaderInit()
{
//	if( m_pMotor->IsAnyError() )
//	{
//		ErrMessage(_T("Must do error reset")); // 110603
//		return;
//	}
	
	// TODO: Add your control notification handler code here
//	m_pMotor->HandlerOperation(HANDLER_UNLOADER_INIT);
}
void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonUnloaderInit() 
{
	// TODO: Add your control notification handler code here
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_UNLOADER_INIT);
}

void CPaneManualControlIOMonitorOutputSub2Osan::OnButtonLoaderInit() 
{
	// TODO: Add your control notification handler code here
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_LOADER_INIT);
}
