// DlgLaserOnTime.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgLaserOnTime.h"

#include "..\model\dprocessini.h"
#include "..\easydrillerdlg.h"
#include "..\device\hdevicefactory.h"
#include "..\Device\HEoCard.h"
#include "..\device\devicemotor.h"
#include "..\Device\HLaser.h"
#include "..\model\dsystemini.h"
#include "..\alarmmsg.h"
#include <math.h>
#include <direct.h>
#include "..\model\DTempINI.h"
#include "..\device\HMotor.h"
#include "..\model\DEasyDrillerINI.h"
#include "PaneManualControl.h"
#include "PaneManualControlLaser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT POWER_PREHEAT	= 2;
const double PREHEAT_MINX	= 5.0;
const double PREHEAT_MINY	= 5.0;
const double PREHEAT_MAXX	= 645.0;
const double PREHEAT_MAXY	= 645.0;

const int PREHEAT_TIME		= 5 * 60;	// 5 minutes

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserOnTime dialog

CDlgLaserOnTime::CDlgLaserOnTime(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserOnTime::IDD, pParent)
{
	m_lDay = 0;
	m_lHour = 0;
	m_lMin = 0;
	m_lSec = 0;
	//{{AFX_DATA_INIT(CDlgLaserOnTime)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgLaserOnTime::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLaserOnTime)
	DDX_Control(pDX, IDC_EDIT_DAY, m_edtDay);
	DDX_Control(pDX, IDC_EDIT_HOUR, m_edtHour);
	DDX_Control(pDX, IDC_EDIT_MIN, m_edtMin);
	DDX_Control(pDX, IDC_EDIT_SEC, m_edtSec);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLaserOnTime, CDialog)
	//{{AFX_MSG_MAP(CDlgLaserOnTime)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, OnCancel)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserOnTime message handlers

BOOL CDlgLaserOnTime::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgLaserOnTime::OnOK() 
{
//	CDialog::OnOK();
}

void CDlgLaserOnTime::OnCancel() 
{
	CDialog::OnCancel();
}

void CDlgLaserOnTime::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");


	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BUTTON_RESET)->SetFont(&m_fntBtn);
	GetDlgItem(IDC_BUTTON_CANCEL)->SetFont(&m_fntBtn);
}

void CDlgLaserOnTime::InitEditControl()
{
	CString strData;

	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	
	m_edtDay.SetFont( &m_fntEdit );
	m_edtDay.SetReceivedFlag( 1 );
	strData.Format(_T("%d"), m_lDay);
	m_edtDay.SetWindowText(strData);


	m_edtHour.SetFont( &m_fntEdit );
	m_edtHour.SetReceivedFlag( 3 );
	strData.Format(_T("%d"), m_lHour);
	m_edtHour.SetWindowText(strData);

	
	m_edtMin.SetFont( &m_fntEdit );
	m_edtMin.SetReceivedFlag( 1 );
	strData.Format(_T("%d"), m_lMin);
	m_edtMin.SetWindowText(strData);

	m_edtSec.SetFont( &m_fntEdit );
	m_edtSec.SetReceivedFlag(1 );
	strData.Format(_T("%d"), m_lSec);
	m_edtSec.SetWindowText(strData);

}

void CDlgLaserOnTime::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_DAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOUR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MIN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SEC)->SetFont( &m_fntStatic );
}


void CDlgLaserOnTime::OnButtonApply()
{
	if(!CheckTime())
	{
		return;
	}

	CString strTemp;
	m_edtDay.GetWindowText(strTemp);
	m_lDay = atol(strTemp);

	m_edtHour.GetWindowText(strTemp);
	m_lHour = atol(strTemp);

	m_edtMin.GetWindowText(strTemp);
	m_lMin = atol(strTemp);

	m_edtSec.GetWindowText(strTemp);
	m_lSec = atol(strTemp);

	CDialog::OnOK();
}

void CDlgLaserOnTime::OnTimer(UINT nIDEvent) 
{

	CDialog::OnTimer(nIDEvent);
}


BOOL CDlgLaserOnTime::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgLaserOnTime::MessageLoop()
{
	MSG msg;
	
	if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		TranslateMessage((LPMSG)&msg);
		DispatchMessage((LPMSG)&msg);
	}
}

BOOL CDlgLaserOnTime::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Laser_Warmup) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}

		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgLaserOnTime::OnButtonReset()
{
	m_edtDay.SetWindowText(_T("0"));

	m_edtHour.SetWindowText(_T("0"));

	m_edtMin.SetWindowText(_T("0"));

	m_edtSec.SetWindowText(_T("0"));
}

BOOL CDlgLaserOnTime::CheckTime()
{
	CString strTemp;
	m_edtDay.GetWindowText(strTemp);
	m_lDay = atol(strTemp);

	m_edtHour.GetWindowText(strTemp);
	m_lHour = atol(strTemp);
	if(!(m_lHour >= 0 && m_lHour <= 23))
	{
		ErrMessage(_T("0 < Hour < 23"));
		return FALSE;
	}
	m_edtMin.GetWindowText(strTemp);
	m_lMin = atol(strTemp);
	if(!(m_lMin >= 0 && m_lMin <= 59))
	{
		ErrMessage(_T("0 < Min < 59"));
		return FALSE;
	}
	m_edtSec.GetWindowText(strTemp);
	m_lSec = atol(strTemp);
	if(!(m_lSec >= 0 && m_lSec <= 59))
	{
		ErrMessage(_T("0 < Sec < 59"));
		return FALSE;
	}
	return TRUE;
}
