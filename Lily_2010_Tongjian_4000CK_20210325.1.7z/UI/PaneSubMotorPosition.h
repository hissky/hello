#if !defined(AFX_PANESUBMOTORPOSITION_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_)
#define AFX_PANESUBMOTORPOSITION_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSubMotorPosition.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPosition form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "ColorStatic.h"


class CPaneSubMotorPosition : public CFormView
{
protected:
	CPaneSubMotorPosition();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSubMotorPosition)

// Form Data
public:
	//{{AFX_DATA(CPaneSubMotorPosition)
	enum { IDD = IDD_DLG_SUB_MOTOR_POSITION };
	CColorStatic m_stcPosX;
	CColorStatic m_stcPosY;
	CColorStatic m_stcPosZ1;
	CColorStatic m_stcPosZ2;
	CColorStatic m_stcPosM;
	CColorStatic m_stcPosM2;
	CColorStatic m_stcPosC;
	CColorStatic m_stcPosC2;
	CColorStatic m_stcPosLC;
	CColorStatic m_stcPosUC;
	//2011524
	CColorStatic m_stcPos1A;
	CColorStatic m_stcPos2A;

	//}}AFX_DATA

// Attributes
public:
	void InitStaticControl();
	void DispStatus();

	void InitTimer();
	void DestroyTimer();

	CFont m_fntStatic;
	CFont m_fntStatic2;

	BOOL m_bTimer;
	int	 m_nTimerID;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSubMotorPosition)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSubMotorPosition();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSubMotorPosition)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESUBMOTORPOSITION_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_)
