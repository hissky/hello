#if !defined(AFX_PANERECIPEGENFIDUCIALNEW_H__AD102E96_3F03_4F0D_9591_13317202EF64__INCLUDED_)
#define AFX_PANERECIPEGENFIDUCIALNEW_H__AD102E96_3F03_4F0D_9591_13317202EF64__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenFiducialNew.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducialNew form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "ColorStatic.h"
#include "UEasyButton.h"
#include "LedButton.h"
#include "..\model\DProject.h"
#include "DlgLpcView.h"

class CPaneRecipeGenFiducialNew : public CFormView
{
protected:
	CPaneRecipeGenFiducialNew();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenFiducialNew)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenFiducialNew)
	enum { IDD = IDD_DLG_RECIPE_GEN_FIDUCIAL_NEW };
	CTreeCtrl	m_ctrTreeTool;
	CComboBox		m_cmbFidType;
	CComboBox		m_cmbToolNo;
	UEasyButtonEx	m_chkUseDrill;
	UEasyButtonEx	m_chkUseVerify;
	UEasyButtonEx	m_btnApplyParam;
	UEasyButtonEx	m_btnApplySameFidParam;
	UEasyButtonEx	m_btnDataUpdate;
	CColorEdit		m_edtFidIndex;
	CColorEdit		m_edtFidOffsetZ;
	UEasyButtonEx	m_btnApplyCam;
	UEasyButtonEx	m_btnApplyParamCam;
	CColorEdit	m_edtOrientation;
	CStatic	m_stcPic;
	CColorEdit	m_edtPath;
	CColorEdit	m_edtSizeC;
	CColorEdit	m_edtSizeB;
	CColorEdit	m_edtSizeA;
	CColorEdit	m_edtSize;
	CColorEdit	m_edtRing;
	CColorEdit	m_edtIR;

	CColorEdit	m_edtContrast;
	CColorEdit	m_edtCoaxial;
	CColorEdit	m_edtBrightness;
	CColorEdit	m_edtAspectRatio;
	CColorEdit	m_edtAngle;
	CColorEdit	m_edtRoiX2;
	CColorEdit	m_edtRefPosX;
	CColorEdit	m_edtRefPosY;





	CColorEdit	m_edtRoiX;
	CColorEdit	m_edtRoiY;
	UEasyButtonEx	m_chkRoiSize;	
	UEasyButtonEx	m_chkRoiSize2;	
	CColorEdit	m_edtThreshold;
	CComboBox	m_cmbType;
	int		m_nPolarity;
	CComboBox	m_cmbCamera;
	CComboBox	m_cmbCameraNo;
	UEasyButtonEx	m_btnJobFile;
	UEasyButtonEx	m_chkFindFidOrder;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnMoveNearPos1;
	UEasyButtonEx	m_btnMoveNearPos2;
	UEasyButtonEx	m_btnSetRef;
	UEasyButtonEx   m_btnApplyRefPos;

	UEasyButtonEx	m_btnShowTest;
	UEasyButtonEx	m_btnMarkStart;
	UEasyButtonEx	m_btnMarkStop;


	UEasyButtonEx	m_btnFindFid;
	UEasyButtonEx	m_btnFindHole;
	UEasyButtonEx	m_btnMotor;
	UEasyButtonEx	m_chkSetROI;
	UEasyButton		m_btnSetLive;
	UEasyButtonEx	m_btnTrainTest;
	UEasyButtonEx	m_btnSetPos;
	UEasyButtonEx	m_btnMoveLoadPos;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnLpcView;
	UEasyButtonEx	m_chkUseScaleLimit;
	UEasyButtonEx	m_btnSave;
	CComboBox	m_cmbCameraSelect;
	CColorStatic	m_stcInspResult;
	CListBox	m_lboxResult;
	CLedButton m_ledTableSuction;
	CLedButton m_ledTableSuction2;
	CSliderCtrl     m_SliderCoaxial;
	CSliderCtrl     m_SliderRing;
	CSliderCtrl     m_SliderIR;
	//}}AFX_DATA

// Attributes
public:
	int m_nUserLevel;
	BOOL m_bDrawMode;
	BOOL m_bTableSuction;
	BOOL m_bTableSuction2;
	int		m_nTimerID;
	CPoint	m_ptFidPos;
	BOOL	m_bNoUIAutoChange;
	BOOL	m_bCalFidPosWithFirst2Point;
	BOOL	m_b1stPanel;
	TCHAR	m_ResultChar[255];
	CDPoint m_visionResult;
	int		m_nCameraNo;
	CWinThread* m_pFindFidThread;
	CWinThread* m_pHoleFindThread;
	BOOL	m_bStop;
	double  m_dZPos;
	VISION_INFO m_sHoleVisInfo;
	BOOL	m_bIsLive;
	BOOL	m_bUseDrillFid;
	BOOL	m_bUseVerifyFid;

	int		m_nFidIndex;
	int		m_nOldMotorMode;
	double	m_dContrast[4];
	double	m_dBrightness[4];
	int		m_nCoaxial[4];
	int		m_nRing[4];
	int		m_nIR[4];
	CBitmap m_imgAnnulus;
	CBitmap m_imgCircle;
	CBitmap m_imgCross;
	CBitmap m_imgDiamond;
	CBitmap m_imgDouble;
	CBitmap m_imgRect;
	CBitmap m_imgTriangle;
	CBitmap	m_imgUserImage;
	
	int		m_nModelType;
	
	CString m_strPath;
	CDlgLpcView* m_pLPCView;
	DProject* m_pProject;

	CString m_strMsg;
	CString m_strBarcode;

	CPoint	m_ptMoveStart;
	BOOL m_bDrawMoveStart;
	int	m_nHoleFindCam;

// Operations
public:
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	void InitTimer();
	void DestroyTimer();
	int GetCurrentFidType();
	void UpdateUIToHoleInfo();
	BOOL GetFidPosHighCamInCenter(BOOL b1stPanel, LPFIDDATA pFidData);
	void SendFindTrigger(BOOL &b1stFound, BOOL &b2ndFound, BOOL bHighCam, BOOL b1stSkip, BOOL b2ndSkip, LPFIDDATA pFidData, double dFinalMoveX, double dFinalMoveY, CDPoint &dptResult1st, CDPoint &dptResult2nd,BOOL bDisp = FALSE);
	CPoint GetNextStepIndex(int nStepNo);
	BOOL CalFidPosWithFirst2Point(C2DTransform* pTrans);
	BOOL FindOneFiducial(LPFIDDATA pFidData, int nFidNo);
	BOOL FindOneVerifyFiducial(LPFIDDATA pFidData, BOOL bAfterFire, int nFidNo);
	BOOL FindFiducialInCenter(int nFidKind, int nFindMethod, int nFidBlock);
	void FindFiducial();
	void ButtonEnable(BOOL bEnable);
	void SetRealPos(BOOL b1stPanel);
	BOOL ApplyFidDataToShot(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode);
	void DPHoleInfo(CString strMsg);
	void OnMoveVisionView();
	void ConnectView();
	BOOL SkivingCheck();
	BOOL CheckFidData();
	void InitialDrawRatio();
	void DrawData();
	void InitListControl();
	void InitStaticControl();
	void InitBtnControl();
	void InitComboControl();
	void InitEditControl();
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

	BOOL SetData(DProject& mDproject);
	BOOL GetData(DProject& tempDProject);
	void InitBitmap();
	void SelectPic(int nType);
	void ChangeControl(BOOL bUse);
	void ChangeDisplay(int nFidIndex);
	void SetValue(int nNumber);
	void InitSlideControl();
	void EnableButton(BOOL bStart,BOOL bStop);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenFiducialNew)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenFiducialNew();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntEdit2;
	CFont		m_fntBtn;
	CFont		m_fntBtn2;
	CFont		m_fntBtn3;
	
	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenFiducialNew)
	afx_msg void OnSelChangeComboFidType();
	afx_msg void OnSelChangeComboToolNo();
	afx_msg void OnButtonApplyCam();
	afx_msg void OnButtonApplyParam();
	afx_msg void OnButtonApplySameFidParam();
	afx_msg void OnButtonApplyParamCam();
	afx_msg void OnButtonDataUpdate();
	afx_msg void OnCheckUseDrill();
	afx_msg void OnCheckUseVerify();
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);	
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeComboType();
	afx_msg void OnSelchangeComboCamera();
	afx_msg void OnSelchangeComboCameraNo();
	afx_msg void OnButtonJobFileOpen();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnChangeEditSizeA();
	afx_msg void OnChangeEditSizeB();
	afx_msg void OnChangeEditSizeC();
	afx_msg void OnRadioPolarity();
	afx_msg void OnUpdateEditContrast();
	afx_msg void OnUpdateEditBrightness();
	afx_msg void OnChangeEditZOffset();
	afx_msg void OnChangeEditRoiX2();
	afx_msg void OnChangeEditRoiX();
	afx_msg void OnChangeEditRoiY();
	afx_msg void OnChangeAcceptSize();
	afx_msg void OnChangeEditAspectratio();
	afx_msg	void OnChangeEditThreashold();
	afx_msg void OnCheckFidFindOrder();
	afx_msg void OnCheckUseRoiSize();
	afx_msg void OnCheckUseRoiSize2();
	afx_msg void OnButtonMove();
	afx_msg void OnButtonMoveNearPos1();
	afx_msg void OnButtonMoveNearPos2();
	afx_msg void OnButtonSetref();
	afx_msg void OnButtonFindFid();
	afx_msg void OnButtonFindHole();
	afx_msg void OnEditchangeComboCamNo2();
	afx_msg void OnCheckInspArea();
	afx_msg void OnButtonLive2();
	afx_msg void OnButtonTest2();
	afx_msg void OnButtonSetOffset();
	afx_msg void OnButtonStop();

	afx_msg LRESULT GetVisionResultBarcode(WPARAM wParam, LPARAM lParam);

	afx_msg LRESULT GetVisionResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROIUM(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT ChangeVisionParameter(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT GetVisionResultNoGrab(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetVisionLamp(WPARAM wParam, LPARAM lParam);
	afx_msg void OnUpdateEditCoaxial();
	afx_msg void OnUpdateEditRing();
	afx_msg void OnUpdateEditIR();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMoveToFiducial();
	afx_msg void OnCheckTableSuction();
	afx_msg void OnCheckTableSuction2();
	afx_msg void OnButtonMotor();
	afx_msg void OnButtonLpcView();
	afx_msg void OnButtonSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonMoveLoadingPos();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedCheckUseScaleLimit();
	afx_msg void OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderIR(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedButtonShowTest();
	afx_msg void OnBnClickedButtonMarkStart();
	afx_msg void OnBnClickedButtonMarkStop();
	afx_msg void OnBnClickedButtonShowMotorMove();
	afx_msg void OnBnClickedButtonClearFindHole();
	afx_msg void OnBnClickedButtonApplyRefpos();
	afx_msg void OnBnClickedButtonFidInfoBlockCopyInclude();
	afx_msg void OnBnClickedButtonFidInfoBlockCopyExclude();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENFIDUCIALNEW_H__AD102E96_3F03_4F0D_9591_13317202EF64__INCLUDED_)
