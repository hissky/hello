// CDlgOpcLossInput.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "CDlgOpcLossInput.h"
#include "..\EasyDrillerDlg.h"
#include "..\model\DProject.h"
#include "..\MODEL\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\MODEL\DProcessINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOpcLossInput dialog


CDlgOpcLossInput::CDlgOpcLossInput(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOpcLossInput::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOpcLossInput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bModifyLossList = FALSE;
}


void CDlgOpcLossInput::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOpcLossInput)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_OPC_LOSS, m_listBoardParam);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancle);
	DDX_Control(pDX, ID_BTN_OPC_INPUT, m_btnOPCInput);
	DDX_Control(pDX, ID_BTN_OPC_MODIFY, m_btnOPCModify);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgOpcLossInput, CDialog)
	//{{AFX_MSG_MAP(CDlgOpcLossInput)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_OPC_LOSS, OnDblclkListOpcLoss)
	ON_NOTIFY(NM_CLICK, IDC_LIST_OPC_LOSS, OnClickListOpcLoss)
	ON_BN_CLICKED(ID_BTN_OPC_INPUT, OnBtnOpcInput)
	ON_BN_CLICKED(ID_BTN_OPC_MODIFY, OnBtnOpcModify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOpcLossInput message handlers

BOOL CDlgOpcLossInput::OnInitDialog() 
{
	CDialog::OnInitDialog();
	InitListControl();
	InitBtnControl();

	m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
	m_dlgOPCWait.ShowWindow(SW_HIDE);
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgOpcLossInput::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(120, "Arial Bold");
	
	m_listBoardParam.SetFont( &m_fntList );
	
	const int nMaxColumnNum = 4;
	LV_COLUMN lvcolumn;
	CString strText;
	char szText[256] = {0,};
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format("����");
			lvcolumn.cx = 50;
			lvcolumn.fmt = LVCFMT_CENTER;
			break;
		case 1 :
			strText.Format("No");
			lvcolumn.cx = 85;
			break;
		case 2 :
			strText.Format("���Ǹ�");
			lvcolumn.cx = 125;
			break;
		case 3 :
			strText.Format("�ڵ�");
			lvcolumn.cx = 95;
			break;
		}
		sprintf( szText, "%s", strText );
		lvcolumn.pszText = szText;
		
		lvcolumn.iSubItem = i;
		
		m_listBoardParam.InsertColumn(i, &lvcolumn);
	}
	
	DWORD dwStyle = m_listBoardParam.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	dwStyle |= LVS_EX_CHECKBOXES;
	
	m_listBoardParam.SetExtendedStyle( dwStyle );
	SetListItemFromOPCLossINI();
}

BOOL CDlgOpcLossInput::SetListItemFromOPCLossINI()
{
	CStdioFile file;
	CString strRead;
	CString strData;
	char* pToken;
	char szStr[400] = {0,};
	int nCount = 0;
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
//	lvItem.stateMask = LVIS_SELECTED;
	if(file.Open("d:\\viahole\\OPCLossInfo.ini", CFile::modeReadWrite|CFile::shareDenyNone) == FALSE)
	{
		ErrMessage("ViaHole �������� OPCLossInfo.ini ������ �߸��Ǿ��ų� ���� �����ϴ�.");
		return FALSE;
	}
	while(file.ReadString(strRead))
	{
		if(strRead.GetLength() <= 0)
			continue;
		lvItem.iItem = nCount;
		lvItem.iSubItem = 0;
		strData = _T("");
		lvItem.pszText = (LPSTR)(LPCSTR)strData;
		m_listBoardParam.InsertItem(&lvItem);

		strcpy(szStr, strRead);
		pToken = strtok(szStr, "::");
		int nTokenCount = 0;
		while(pToken != NULL)
		{
			strData.Format("%s", pToken);
			if(strData.GetLength() > 0)
			{
				strData.TrimLeft();
				strData.TrimRight();
			}
			if(nTokenCount == 0)
				m_listBoardParam.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strData);
			else if(nTokenCount == 1)
				m_listBoardParam.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strData);
			else if(nTokenCount == 2)
				m_listBoardParam.SetItemText(nCount, 3, (LPSTR)(LPCSTR)strData);
			nTokenCount++;
			pToken = strtok(NULL, "::");
		}
		nCount++;
	}
	file.Close();
	for(int i=0; i<m_listBoardParam.GetItemCount(); i++)	
	{
		m_listBoardParam.SetItemData(i, i);
	}
	m_listBoardParam.SortItems(CompareFunc, (LPARAM)&m_listBoardParam);
	return TRUE;
}

void CDlgOpcLossInput::OnDblclkListOpcLoss(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
    NM_LISTVIEW*  pNMListView = (NM_LISTVIEW*)pNMHDR;   
	int nListCount = m_listBoardParam.GetItemCount();
	for(int i = 0; i <nListCount; i++)
	{
		m_listBoardParam.SetCheck(i, FALSE);
	}
    int  pos  = pNMListView->iItem;   
    BOOL  bCheck  = m_listBoardParam.GetCheck(pos);   
	if(!m_bModifyLossList)
	{
		if(m_listBoardParam.GetCheck(pos))   
		{   
//		   if(m_listBoardParam.GetItemText(pos, 0) != "")   
//		   {   
			m_listBoardParam.SetCheck(pos, false);   
//		   }   
		}   
		else  
		{   
			m_listBoardParam.SetCheck(pos, true);   
		}   
	}	
	 *pResult = true; //*pResult = 0; �� true�� ��ȯ   
}

void CDlgOpcLossInput::OnClickListOpcLoss(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
    NM_LISTVIEW*  pNMListView = (NM_LISTVIEW*)pNMHDR;   
	int nListCount = m_listBoardParam.GetItemCount();
	for(int i = 0; i <nListCount; i++)
	{
		m_listBoardParam.SetCheck(i, FALSE);
	}
    int  pos  = pNMListView->iItem;   
    BOOL  bCheck  = m_listBoardParam.GetCheck(pos);   
	CString strName;
    if(m_listBoardParam.GetCheck(pos))   
    {   
		m_listBoardParam.SetCheck(pos, false);   
    }   
    else  
    {   
		m_listBoardParam.SetCheck(pos, true);   
		strName.Format(_T("%s"), m_listBoardParam.GetItemText(pos, 2));
    }   
	

	 *pResult = true; //*pResult = 0; �� true�� ��ȯ   
}

void CDlgOpcLossInput::OnBtnOpcInput() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDCANCEL)->EnableWindow(FALSE);
	GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError = _T("");
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossPass = _T("");
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossResult = _T("");
	CString strLossError = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	int nListCount = m_listBoardParam.GetItemCount();
	CString strMode = _T("");
	for(int i=0; i<nListCount; i++)
	{
		if(m_listBoardParam.GetCheck(i) == TRUE)
		{
			strMode.Format("%s", m_listBoardParam.GetItemText(i, 3));
			break;
		}
	}
	
	if(strMode.GetLength() < 1)
	{
		ErrMessage(_T("������ ���� ���� �ڵ尡 �����ϴ�."));
		
		GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(TRUE);
		return;
	}
	else
		ErrMessage(_T("���� ���� �ڵ� ����"));
	
	CTime EventTime = CTime::GetCurrentTime();
	CString strTime, strLotID, strLotID2, strPrj1, strPrj2;
	strTime.Format("%04d%02d%02d%02d%02d%02d",
		EventTime.GetYear(), EventTime.GetMonth(), EventTime.GetDay(),
		EventTime.GetHour(), EventTime.GetMinute(), EventTime.GetSecond());
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->GetCurrentLotID(strLotID, strLotID2, strPrj1, strPrj2);
	CString strUserID = gDProject.m_strUserID;
	CString strComment;
	GetDlgItem(IDC_EDT_COMMENT)->GetWindowText(strComment);
	
	CString strOPC = _T("");
	strOPC.Format("%s;%s;%s;%s;%s;%s", "000", strMode, strTime, strUserID , strComment, strLotID);
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 9, reinterpret_cast<LPARAM>(&strOPC));	//8 ����->TC �� �������� ���� : L_000_000000_01

	int nCount = 0;
	CString strGetLoss = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	
	CTime StartTime = CTime::GetCurrentTime();
	CTime EndTime;
	
		
	if(!WaitOPCRecvMessage())
	{
		ErrMsgDlg(STDGNALM250);
		GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(TRUE);
		return;
	}

	strGetLoss = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	CString strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossPass;
	
#ifdef __TEST__
//	strPass.Format(_T("pass"));
#endif
	strPass.MakeUpper();

	if(strcmp(strPass, "PASS") == 0)
	{
		ErrMessage(_T("���� �ڵ� ���� �Ϸ�"));
	}
	else
	{
		ErrMessage(_T("���� �ڵ� ���� ����"));
	}

	GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
	GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(TRUE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(TRUE);
	
	GetDlgItem(IDC_EDT_LOSS_RESULT)->SetWindowText(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossResult);

}

void CDlgOpcLossInput::OnBtnOpcModify() 
{
	// TODO: Add your control notification handler code here
	m_bModifyLossList = !m_bModifyLossList;

	if(m_bModifyLossList)
	{
		GetDlgItem(ID_BTN_OPC_MODIFY)->SetWindowText("���� �Ϸ�");
		GetDlgItem(IDCANCEL)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(FALSE);
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(ID_BTN_OPC_MODIFY)->SetWindowText("����");
		GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_INPUT)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_OPC_MODIFY)->EnableWindow(TRUE);
	}
}

void CDlgOpcLossInput::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CDlgOpcLossInput::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	//OK
	m_btnOK.SetFont( &m_fntBtn );
	m_btnOK.SetFlat( FALSE );
	m_btnOK.EnableBallonToolTip();
	m_btnOK.SetToolTipText( _T("") );
	m_btnOK.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOK.SetBtnCursor(IDC_HAND_1);

	//Cancle
	m_btnCancle.SetFont( &m_fntBtn );
	m_btnCancle.SetFlat( FALSE );
	m_btnCancle.EnableBallonToolTip();
	m_btnCancle.SetToolTipText( _T("") );
	m_btnCancle.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancle.SetBtnCursor(IDC_HAND_1);

	//OPC Input
	m_btnOPCInput.SetFont( &m_fntBtn );
	m_btnOPCInput.SetFlat( FALSE );
	m_btnOPCInput.EnableBallonToolTip();
	m_btnOPCInput.SetToolTipText( _T("") );
	m_btnOPCInput.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOPCInput.SetBtnCursor(IDC_HAND_1);

	//OPC Modify
	m_btnOPCModify.SetFont( &m_fntBtn );
	m_btnOPCModify.SetFlat( FALSE );
	m_btnOPCModify.EnableBallonToolTip();
	m_btnOPCModify.SetToolTipText( _T("") );
	m_btnOPCModify.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOPCModify.SetBtnCursor(IDC_HAND_1);

}
void CDlgOpcLossInput::InitEditControl()
{
	// Set Button Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");
}
int CALLBACK CDlgOpcLossInput::CompareFunc(LPARAM lParam1 , LPARAM lParam2 , LPARAM lParamSort)
{
	CListCtrl *pListCtrl = (CListCtrl*)lParamSort;
	LVFINDINFO info1, info2;
	info1.flags = LVFI_PARAM;
	info1.lParam = lParam1;
	info2.flags = LVFI_PARAM;
	info2.lParam = lParam2;
	int irow1 = pListCtrl->FindItem(&info1, -1);
	int irow2 = pListCtrl->FindItem(&info2, -1);

	CString strItem1 = pListCtrl->GetItemText(irow1, 1);
	CString strItem2 = pListCtrl->GetItemText(irow2, 1);

	if(atoi(strItem1) < atoi(strItem2))
	{
		return -1;
	}
	else if(atoi(strItem1) == atoi(strItem2))
	{
		return 0;
	}
	else
	{
		return 1;
	}

}

BOOL CDlgOpcLossInput::SaveOPCINI()
{
	int nListCount = m_listBoardParam.GetItemCount();

	CStdioFile file;
	CString strBuf;
	CString strIndex;
	CString strData;
	CString strCode;
	char szStr[400] = {0,};
	int nCount = 0;
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	//	lvItem.stateMask = LVIS_SELECTED;
	if(file.Open("d:\\viahole\\OPCLossInfo.ini", CFile::modeReadWrite|CFile::shareDenyNone) == FALSE)
	{
		ErrMessage("ViaHole �������� OPCLossInfo.ini ������ �߸��Ǿ��ų� ���� �����ϴ�.");
		return FALSE;
	}
	for(int i =0; i<nListCount; i++)
	{
		strIndex.Format(_T("%s"), m_listBoardParam.GetItemText(i, 1));
		strData.Format(_T("%s"), m_listBoardParam.GetItemText(i, 2));
		strCode.Format(_T("%s"), m_listBoardParam.GetItemText(i, 3));
		strBuf.Format(_T("%s::%s::%s\n"), strIndex,strData,strCode);
		file.WriteString(strBuf);
	}
	file.Close();
	return TRUE;
}


BOOL CDlgOpcLossInput::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_LBUTTONDOWN  || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Scal_Result) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CDlgOpcLossInput::WaitOPCRecvMessage()
{

#ifdef __NO_USE_OPC__
	return TRUE;
#endif
	MSG msg;
	if( ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc == NULL)
		return TRUE;

	int nWaitTime = gProcessINI.m_sProcessOption.nOPCTimeOut * 100; // sec 

	BOOL bRecv = FALSE;
	int nCount = 0;
	m_dlgOPCWait.ShowWindow(SW_SHOW);
	m_dlgOPCWait.StartMeasurement(nWaitTime);

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
	do
	{
		if(nCount > nWaitTime) //���Ƿ� 5��
		{
			m_dlgOPCWait.ShowWindow(SW_HIDE);
			return FALSE;
		}
		bRecv =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv;
		Sleep(10);
	
		if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
		{
			TranslateMessage((LPMSG)&msg);
			DispatchMessage((LPMSG)&msg);
		}
		nCount++;
		m_dlgOPCWait.UpdateMeasurement(nCount);
	}while(!bRecv);

	if(bRecv)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv = FALSE;
	}
	m_dlgOPCWait.ShowWindow(SW_HIDE);
	return TRUE;
}