// PaneAutoRunViewFiducial.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewFiducial.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgMatroxVisionView.h"
#include "DlgVisionProView.h"
#include "..\model\DProject.h"
#include "..\model\DFidData.h"
#include "PaneAutoRun.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewFiducial

IMPLEMENT_DYNCREATE(CPaneAutoRunViewFiducial, CFormView)

CPaneAutoRunViewFiducial::CPaneAutoRunViewFiducial()
	: CFormView(CPaneAutoRunViewFiducial::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewFiducial)
	m_bDrawMode = FALSE;
	m_nSelPanel = -1;
	m_bShowVision = FALSE;
	m_nTimer = -1;
	m_bDrawMoveStart = FALSE;
	m_bShow = TRUE;
	//}}AFX_DATA_INIT
}

CPaneAutoRunViewFiducial::~CPaneAutoRunViewFiducial()
{
	DestroyTimer();
}

void CPaneAutoRunViewFiducial::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewFiducial)
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_CHECK_SCALE, m_ledScale);
	DDX_Control(pDX, IDC_LIST_FIDUCIAL_INFO, m_listFiducial);
	DDX_Control(pDX, IDC_BUTTON_MODE, m_btnMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewFiducial, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewFiducial)
	ON_WM_CTLCOLOR()
	ON_LBN_SELCHANGE(IDC_LIST_RESULT, OnSelchangeListResult)
	ON_BN_CLICKED(IDC_BUTTON_MODE, OnButtonMode)
	//}}AFX_MSG_MAP
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_MOUSEWHEEL()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewFiducial diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewFiducial::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewFiducial::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewFiducial message handlers

void CPaneAutoRunViewFiducial::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitBtnControl();
	InitListControl();
	InitTimer();

}

BOOL CPaneAutoRunViewFiducial::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewFiducial::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_RECIPE_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RECIPE_INFO2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RECIPE_RESULT2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RECIPE_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIDUCIAL_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACCEPT_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACCEPT_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_Y2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RETRIAL)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_FIDUCIAL_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAM_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACCEPT_SIZE_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACCEPT_ANGLE_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_X_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_Y_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_X_VAL2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_Y_VAL2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RETRIAL_VAL)->SetFont( &m_fntStatic );
	
	
	GetDlgItem(IDC_STC_RUN_VIEW)->ShowWindow(SW_HIDE);

}
void CPaneAutoRunViewFiducial::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	m_ledScale.SetFont( &m_fntBtn );
	m_ledScale.SetImage( IDB_LEDCOLOR, 15 );
	m_ledScale.Depress( FALSE );

	//Unload To Table
	m_btnMode.SetFont( &m_fntBtn );
	m_btnMode.SetFlat( FALSE );
	m_btnMode.EnableBallonToolTip();
	m_btnMode.SetToolTipText( _T("View Mode / Find Mode") );
	m_btnMode.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMode.SetBtnCursor(IDC_HAND_1);

	
}
void CPaneAutoRunViewFiducial::InitListControl()
{
	m_fntListBox.CreatePointFont(100, "Arial Bold");
	
	m_lboxResult.SetFont( &m_fntListBox );

	m_listFiducial.SetFont( &m_fntListBox );

	m_listFiducial.SetExtendedStyle(m_listFiducial.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_listFiducial.DeleteAllItems();
	
	m_listFiducial.InsertColumn(0, _T(" No "), LVCFMT_CENTER, 40);
	m_listFiducial.InsertColumn(1, _T(" Info "), LVCFMT_CENTER, 65);
	m_listFiducial.InsertColumn(2, _T(" Scale "), LVCFMT_CENTER, 74);
	m_listFiducial.InsertColumn(3, _T(" Ref X "), LVCFMT_CENTER, 72);
	m_listFiducial.InsertColumn(4, _T(" Offset X "), LVCFMT_CENTER, 72);
	m_listFiducial.InsertColumn(5, _T(" Ref Y "), LVCFMT_CENTER, 72);
	m_listFiducial.InsertColumn(6, _T(" Offset Y "), LVCFMT_CENTER, 72);

//	m_listFiducial.InsertColumn(5, _T(" Get Pos Y "), LVCFMT_CENTER, 85);
	//	m_listFiducial.InsertColumn(2, _T(" Get Pos X "), LVCFMT_CENTER, 85);
	
	
//	m_listFiducial.InsertColumn(8, _T(" Distance "), LVCFMT_CENTER, 85);

}


HBRUSH CPaneAutoRunViewFiducial::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if(GetDlgItem(IDC_STATIC_RECIPE_INFO)->GetSafeHwnd() == pWnd->m_hWnd || 
		GetDlgItem(IDC_STATIC_RECIPE_INFO2)->GetSafeHwnd() == pWnd->m_hWnd || 
		GetDlgItem(IDC_STATIC_RECIPE_RESULT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_RECIPE_RESULT2)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewFiducial::ConnectView()
{
	if(m_bDrawMode)
		return;

	m_bShowVision = TRUE;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		
	}

	GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_STC_RUN_VIEW)->ShowWindow(SW_HIDE);

}

void CPaneAutoRunViewFiducial::DisconnectView()
{
	m_bShowVision = FALSE;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_HIDE );
//		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_HIDE );
//		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_HIDE );
//		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}

}

void CPaneAutoRunViewFiducial::ChangeDisplay()
{
	
	CString str;

	//Auto Scale 
	double dMove = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_dAvgScaleX;
	str.Format(_T("%.2f"), dMove);
	GetDlgItem(IDC_STATIC_RETRIAL_VAL)->SetWindowText(str);
	
	dMove = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_dAvgScaleY;
	str.Format(_T("%.2f"), dMove);
	GetDlgItem(IDC_STATIC_MOVE_X_VAL)->SetWindowText(str);
	
	dMove = gDProject.m_dScaleTolerance2;
	str.Format(_T("%.2f"), dMove);
	GetDlgItem(IDC_STATIC_MOVE_Y_VAL)->SetWindowText(str);
	
	dMove = gDProject.m_dScaleTolerance2;
	str.Format(_T("%.2f"), dMove);
	GetDlgItem(IDC_STATIC_MOVE_X_VAL2)->SetWindowText(str);

	//Manual 
	dMove = gDProject.m_dScaleTolerance2;
	str.Format(_T("%.2f"), dMove);
	GetDlgItem(IDC_STATIC_MOVE_Y_VAL2)->SetWindowText(str);


	BOOL bMode =gDProject.m_nScaleMode;
	
	if(bMode == 0)
		m_ledScale.SetWindowText("Use Auto Scale");
	else
		m_ledScale.SetWindowText("Use Manual Scale");

	LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);
	if(pFidData == NULL)
		return;

	//use fid count 
	int nCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	str.Format(_T("%d"), nCount);
	GetDlgItem(IDC_STATIC_FIDUCIAL_NO_VAL)->SetWindowText(str);

	//cam type


	switch(pFidData->nCam)
	{
	case HIGH_CAM :
		str.Format(_T("%s"), "High Cam"); break;
	case LOW_CAM :
		str.Format(_T("%s"), "Low Cam"); break;
	case LOW_TO_HIGH_CAM :
		str.Format(_T("%s"), "Low to High Cam"); break;
	}
	GetDlgItem(IDC_STATIC_CAM_VAL1)->SetWindowText(str);

	//model type 
	switch(pFidData->sVisInfo.nModelType)
	{
	case 0 :
		str.Format(_T("%s"), "Annulus"); break;
	case 1 : 
		str.Format(_T("%s"), "Circle"); break;
	case 2 :
		str.Format(_T("%s"), "Cross"); break;
	case 3 :
		str.Format(_T("%s"), "Diamond"); break;
	case 4 :
		str.Format(_T("%s"), "Double rectangle"); break;
	case 5 :
		str.Format(_T("%s"), "Rectangle"); break;
	case 6 :
		str.Format(_T("%s"), "Triangle"); break;
	default :
		str.Format(_T("%s"), "User Image"); break;
	}
	GetDlgItem(IDC_STATIC_MODEL_VAL)->SetWindowText(str);

	//size
	double dSize = pFidData->sVisInfo.dSizeA;
	str.Format(_T("%.2f"), dSize);
	GetDlgItem(IDC_STATIC_SIZE_VAL)->SetWindowText(str);

	//polarity
	int nPol = pFidData->sVisInfo.nPolarity;
	if(nPol == 0)
		str.Format(_T("Black"));
	else if(nPol == 1)
		str.Format(_T("White"));
	else if(nPol == 2)
		str.Format(_T("Ignore"));
	GetDlgItem(IDC_STATIC_POLARITY_VAL)->SetWindowText(str);

	//accept size
	double dAC = pFidData->sVisInfo.dScoreSize;
	str.Format(_T("%.2f"), dAC);
	GetDlgItem(IDC_STATIC_ACCEPT_SIZE_VAL)->SetWindowText(str);

	//accept angle
	dAC = pFidData->sVisInfo.dScoreAngle;
	str.Format(_T("%.2f"), dAC);
	GetDlgItem(IDC_STATIC_ACCEPT_ANGLE_VAL)->SetWindowText(str);

	if(gSystemINI.m_sHardWare.bUseWideMonitor)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
}

void CPaneAutoRunViewFiducial::InsertFidResult(int nLotNo)
{
	int n = m_lboxResult.GetCount();

	CString str;
	str.Format(_T("Panel #%d"), nLotNo+1);
	m_lboxResult.InsertString(n, str);
}

void CPaneAutoRunViewFiducial::OnSelchangeListResult() 
{
	int nIndex = m_lboxResult.GetCurSel();
	
	TCHAR szBuffer[125] = {0,};
	m_lboxResult.GetText(nIndex, szBuffer);
	
/*	CString str, strTemp;
	str.Format(_T("%s"), szBuffer);
	
	nIndex = str.Find("#",0);

	strTemp = str.Mid(nIndex + 1);
*/	int nPanelNo = nIndex;//atoi((LPST	R)(LPCTSTR)strTemp - 1);

	m_nSelPanel = nPanelNo;
	ChangeFidList(nPanelNo);
//	DisconnectView();
	DrawFiducial(nPanelNo);
//	m_bDrawMode = TRUE;
//	m_btnMode.SetWindowText("Find Mode");
}

void CPaneAutoRunViewFiducial::ChangeFidList(int nPanelNo)
{
	m_listFiducial.DeleteAllItems();

	LPPNLFIDINFO pPanel;
	pPanel = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetPanel(nPanelNo, TRUE);

	if(pPanel == NULL)
		return;

	LPFIDRESULT pFidResult;
	int nIndex = 0;
	CString str;
	POSITION pos = pPanel->FidResult.GetHeadPosition();
	while(pos)
	{
		pFidResult = pPanel->FidResult.GetNext(pos);

		m_listFiducial.InsertItem(nIndex, _T(""));

		str.Format(_T("%d"), pFidResult->nFindIndex + 1);
		m_listFiducial.SetItemText(nIndex, 0, str);
	
		if(!pFidResult->bFound)
		{
			str.Format(_T("NotFound"));
			m_listFiducial.SetItemText(nIndex, 1, str);
		}
		else
		{
			if(pPanel->nNGType ==  FID_NG_SCALE)
			{
				str.Format(_T("Scale"));
				m_listFiducial.SetItemText(nIndex, 1, str);
			}
			else if(pPanel->nNGType == FID_NG_LENGH)
			{
				str.Format(_T("Tol.1"));
				m_listFiducial.SetItemText(nIndex, 1, str);
			}
			else if(pPanel->nNGType == FID_NG_LENGH2)
			{
				str.Format(_T("Tol.2"));
				m_listFiducial.SetItemText(nIndex, 1, str);
			}
			else 
			{
				str.Format(_T("OK"));
				m_listFiducial.SetItemText(nIndex, 1, str);
			}
		}

		str.Format(_T("%.2f"), pFidResult->dScale);
		m_listFiducial.SetItemText(nIndex, 2, str);
		
		str.Format(_T("%d"), pFidResult->npRefPosition.x);
		m_listFiducial.SetItemText(nIndex, 3, str);
	
//		str.Format(_T("%.2f"), pFidResult->dpGetPosition.x);
//		m_listFiducial.SetItemText(nIndex, 2, str);

		str.Format(_T("%d"), pFidResult->dpFidOffset.x);
		m_listFiducial.SetItemText(nIndex, 4, str);

		str.Format(_T("%d"), pFidResult->npRefPosition.y);
		m_listFiducial.SetItemText(nIndex, 5, str);
		
//		str.Format(_T("%.2f"), pFidResult->dpGetPosition.y);
//		m_listFiducial.SetItemText(nIndex, 5, str);

		str.Format(_T("%d"), pFidResult->dpFidOffset.y);
		m_listFiducial.SetItemText(nIndex, 6, str);

		nIndex++;
	}

}

void CPaneAutoRunViewFiducial::RemoveList()
{
	m_lboxResult.ResetContent();
	m_listFiducial.DeleteAllItems();

	gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].RemovePanel();

	Invalidate(FALSE);
}

void CPaneAutoRunViewFiducial::DrawFiducial(int nPanelNo)
{
	m_lboxResult.SetCurSel(nPanelNo);

	GetDlgItem(IDC_STC_RUN_VIEW)->ShowWindow(SW_SHOW);

	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	int nPenSize;
	nPenSize = 2;
	
	CPen pen;
	CPen penLine;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(38, 125, 232));
	pOldPen = BufferDC.SelectObject(&pen);
	
	penLine.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 0));

	cBr2.CreateSolidBrush(RGB(255, 255, 255));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	if(nPanelNo >= 0)
	{
		//draw
		if(m_bShow)
		{
			gDProject.InitialDrawRatio(cRect, 4);
			m_bShow= FALSE;
		}
		gDProject.DrawOnlyFiducial(&BufferDC, cRect, nPanelNo, 4);
	}
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);

}

void CPaneAutoRunViewFiducial::OnButtonMode() 
{
	
	if(m_bDrawMode)
	{
		m_btnMode.SetWindowText("Draw Mode");
		m_bDrawMode = FALSE;
		ConnectView();
	}
	else
	{
		m_btnMode.SetWindowText("Find Mode");
		m_bDrawMode = TRUE;
		DisconnectView();
		Sleep(1);
		DrawFiducial(m_nSelPanel);
		
	}	
}

void CPaneAutoRunViewFiducial::OnMoveVisionView()
{
	if(!m_bShowVision)
		return;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(MAIN_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	
	GetDlgItem(IDC_STC_RUN_VIEW)->ShowWindow(SW_HIDE);

	if(m_bDrawMode)
		DisconnectView();
}

CRect CPaneAutoRunViewFiducial::GetVisionWindowRect()
{
	CRect rtPos;
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
	}
	else  // if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
	}
	return rtPos;

}
void CPaneAutoRunViewFiducial::OnPaint() 
{
	CPaintDC dc(this);
	m_nSelPanel = m_lboxResult.GetCurSel();
	if(m_nSelPanel == -1)
		return;

	if(m_bDrawMode)
		DrawFiducial(m_nSelPanel);

	CFormView::OnPaint();
}
void CPaneAutoRunViewFiducial::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
/*	m_nSelPanel = m_lboxResult.GetCurSel();
	if(m_nSelPanel == -1)
		return;

	if(nIDEvent == m_nTimer)
	{
		if(m_bDrawMode)
			DrawFiducial(m_nSelPanel);
	}
*/
	CFormView::OnTimer(nIDEvent);
}
void CPaneAutoRunViewFiducial::DestroyTimer()
{
////	if(m_nTimer)
////	{
////		KillTimer(m_nTimer);
////		m_nTimer = -1;
////	}
}
void CPaneAutoRunViewFiducial::InitTimer()
{
	if(m_nTimer == -1)
		m_nTimer = SetTimer(1234, 500, NULL );
}

BOOL CPaneAutoRunViewFiducial::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Drill_Fiducial) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


BOOL CPaneAutoRunViewFiducial::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(!m_bDrawMode)
		return TRUE;

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			gDProject.SetDrawRect(tempP, 1, 4);
		else
			gDProject.SetDrawRect(tempP, -1, 4);
		
		Invalidate(FALSE);
	}
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);

	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}


void CPaneAutoRunViewFiducial::OnMouseMove(UINT nFlags, CPoint point)
{
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;
			
			if(m_ptMoveStart != tempP)
			{
				m_ptMoveStart = endP;
				gDProject.SetDrawRect(tempP, 0, 4);
				Invalidate(FALSE);
			}
		}
	}
	CFormView::OnMouseMove(nFlags, point);
}


void CPaneAutoRunViewFiducial::OnLButtonDown(UINT nFlags, CPoint point)
{

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;

		GetDlgItem(IDC_STC_RUN_VIEW)->SetFocus();
	}
	else
		return;

	m_ptMoveStart = tempP;
	m_bDrawMoveStart = TRUE;
	CFormView::OnLButtonDown(nFlags, point);
}


void CPaneAutoRunViewFiducial::OnLButtonUp(UINT nFlags, CPoint point)
{
	m_bDrawMoveStart = FALSE;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		
		Invalidate(FALSE);
	}

	CFormView::OnLButtonUp(nFlags, point);
}
