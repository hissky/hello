// PaneSysSetupMGC.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupMGC.h"

#include <afxpriv.h>
#include "SelectionView.h"
#include "MGCView.h"

#include "DlgChangeAxis.h"
#include "DlgChangeField.h"
#include "DlgInformationBox.h"
#include "DlgQuestionBox.h"
#include "DlgCalibrationView.h"

#include "NAxis.h"
#include "NGrid.h"
#include "NMode.h"
#include "NAnswer.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\dsystemini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC

IMPLEMENT_DYNCREATE(CPaneSysSetupMGC, CFormView)

CPaneSysSetupMGC::CPaneSysSetupMGC()
	: CFormView(CPaneSysSetupMGC::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupMGC)

	m_nGrid = NGrid::grid9x9;
	m_dDeltaX = 0.0;
	m_dDeltaY = 0.0;
	
	m_nAxis = NAxis::axis_270;
	
	m_strAppTitle = _T("MGC");
	m_strAscTempFileNameHead = _T("TempMGC");

	m_strAscDirectory = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	m_strAscTempFileDirectory = gEasyDrillerINI.m_clsDirPath.GetRootDir() + m_strAscTempFileNameHead;
	m_strAscFilePath = _T("");
	
	InitTempFileName();
	
//	m_dFieldSizeX = SCANNER_FIELD_SIZE;
//	m_dFieldSizeY = SCANNER_FIELD_SIZE;
	
	m_nBackupFileNumber = 0;
	
	m_bInitDSPEoCard = FALSE;
	
	m_bEnableRedo = FALSE;
	m_bEnableUndo = FALSE;
	
	m_bEnableZoomIn = TRUE;
	m_bEnableZoomOut = FALSE;
	m_bEnableZoomAll = FALSE;
	m_bEnableCalView = FALSE;
	//}}AFX_DATA_INIT
}

CPaneSysSetupMGC::~CPaneSysSetupMGC()
{
}

void CPaneSysSetupMGC::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupMGC)
	DDX_CBIndex(pDX, IDC_CMB_GRID, m_nGrid);
	DDX_Text(pDX, IDC_EDT_X, m_dDeltaX);
	DDX_Text(pDX, IDC_EDT_Y, m_dDeltaY);
	DDX_Control(pDX, IDC_BTN_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BTN_SELECT_ALL, m_btnSelectAll);
	DDX_Control(pDX, IDC_BTN_UNSELECT_ALL, m_btnDeselectAll);
	DDX_Control(pDX, IDC_BTN_INVERT, m_btnReverse);
	DDX_Control(pDX, IDC_BTN_RESET, m_btnReset);
	DDX_Control(pDX, IDC_BTN_CHANGE_FIELD, m_btnChangeField);
	DDX_Control(pDX, IDC_BTN_CHANGE_AXIS, m_btnChangeAxis);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupMGC, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupMGC)
	ON_WM_CTLCOLOR()
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_CMB_GRID, OnSelchangeCmbGrid)
	ON_BN_CLICKED(IDC_BTN_SELECT_ALL, OnBtnSelectAll)
	ON_BN_CLICKED(IDC_BTN_UNSELECT_ALL, OnBtnUnselectAll)
	ON_BN_CLICKED(IDC_BTN_INVERT, OnBtnInvert)
	ON_BN_CLICKED(IDC_BTN_RESET, OnBtnReset)
	ON_BN_CLICKED(IDC_BTN_APPLY, OnBtnApply)
	ON_BN_CLICKED(IDC_BTN_CHANGE_AXIS, OnBtnChangeAxis)
	ON_BN_CLICKED(IDC_BTN_CHANGE_FIELD, OnBtnChangeField)
	ON_COMMAND(IDT_ZOOM_IN, OnZoomIn)
	ON_COMMAND(IDT_ZOOM_OUT, OnZoomOut)
	ON_COMMAND(IDT_ZOOM_ALL, OnZoomAll)
	ON_COMMAND(IDT_CALIBRATION, OnCalibration)
	ON_COMMAND(IDT_UNDO, OnUndo)
	ON_COMMAND(IDT_FILE_OPEN, OnFileOpen)
	ON_COMMAND(IDT_FILE_SAVE, OnFileSave)
	ON_COMMAND(IDT_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(IDT_REDO, OnRedo)
	ON_UPDATE_COMMAND_UI(IDT_REDO, OnUpdateRedo)
	ON_UPDATE_COMMAND_UI(IDT_UNDO, OnUpdateUndo)
	ON_UPDATE_COMMAND_UI(IDT_ZOOM_IN, OnUpdateZoomIn)
	ON_UPDATE_COMMAND_UI(IDT_ZOOM_OUT, OnUpdateZoomOut)
	ON_UPDATE_COMMAND_UI(IDT_ZOOM_ALL, OnUpdateZoomAll)
	ON_UPDATE_COMMAND_UI(IDT_CALIBRATION, OnUpdateCalibration)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXT, 0, 0xFFFF, OnToolTipText)
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC diagnostics

#ifdef _DEBUG
void CPaneSysSetupMGC::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupMGC::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC message handlers

BOOL CPaneSysSetupMGC::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneSysSetupMGC::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	m_dFieldSizeX = gSystemINI.m_sSystemDevice.dFieldSize.x;
	m_dFieldSizeY = gSystemINI.m_sSystemDevice.dFieldSize.y;
	
	// ��ǥ�� ǥ�� Control �ʱ�ȭ - ����
	CWnd *pWnd = GetDlgItem(IDC_STC_AXIS);
	LONG lStyle = ::GetWindowLong(pWnd->m_hWnd, GWL_STYLE);
	::SetWindowLong(
		pWnd->m_hWnd,
		GWL_STYLE,
		lStyle | SS_BITMAP | SS_CENTERIMAGE
		);
	// ��ǥ�� ǥ�� Control �ʱ�ȭ - ��
	
	// ToolBar �ʱ�ȭ - ����
	InitToolBar();
	// ToolBar �ʱ�ȭ - ��
	
	// Font ���� - ����
	SetDlgFont();
	// Font ���� - ��
	
	// Asc Temp File Directory üũ - ����
	CheckAscTempFileDirectory();
	// Asc Temp File Directory üũ - ��
	
	ChangeAxis();
	ChangeGrid();
	ChangeField();
	
//	OnFileOpen();
}

void CPaneSysSetupMGC::SetDlgFont()
{
	SetButtonFont();
	
	m_dlgFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_STC_X)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STC_Y)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC1)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC2)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_CMB_GRID)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STC_FIELD)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC3)->SetFont(&m_dlgFont);

	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Text
	GetDlgItem(IDC_STC_MGC_VIEW_TITLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_SELECTION_VIEW_TITLE)->SetFont( &m_fntStatic );
	
	// Group
	GetDlgItem(IDC_STC_GROUP_EDIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_GROUP_GRID_FIELD)->SetFont( &m_fntStatic );
	
	m_editFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_EDT_X)->SetFont(&m_editFont);
	GetDlgItem(IDC_EDT_Y)->SetFont(&m_editFont);
}

void CPaneSysSetupMGC::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
	}
	else
	{
		CFormView::OnPaint();
	}
}

HBRUSH CPaneSysSetupMGC::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STC_GROUP_EDIT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STC_GROUP_GRID_FIELD)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CPaneSysSetupMGC::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class

	// Enter Key�� Escape Key�� ���� �ʰ��ϱ� - ����
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
		return TRUE;

	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE)
		return TRUE;
	// Enter Key�� Escape Key�� ���� �ʰ��ϱ� - ��
	
	return CFormView::PreTranslateMessage(pMsg);
}

void CPaneSysSetupMGC::ChangeAxis()
{
	HINSTANCE hInstance = AfxGetInstanceHandle();
	HBITMAP hBitmap;

	CStatic *pWnd = (CStatic *)GetDlgItem(IDC_STC_AXIS);
	
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_0));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_90:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_90));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_180:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_180));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_270:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_270));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_left_0:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_LEFT_0));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_left_90:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_LEFT_90));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_left_180:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_LEFT_180));
		pWnd->SetBitmap(hBitmap);
		break;
	case NAxis::axis_left_270:
		hBitmap = ::LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_AXIS_LEFT_270));
		pWnd->SetBitmap(hBitmap);
		break;
	}

	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);
	
	pMGCView->SetAxis(m_nAxis);
	
	CSelectionView *pSelectionView =
		(CSelectionView *) GetDlgItem(IDC_CTM_SELECTION_VIEW);
	
	pSelectionView->SetAxis(m_nAxis);

}

void CPaneSysSetupMGC::OnSelchangeCmbGrid() 
{
	// TODO: Add your control notification handler code here

	CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

	// Choi - Debug
	if(pMGCView->getModified() == TRUE)
	{
		int nAnswer = saveDataBeforeChangeSetting();
		if(nAnswer == NAnswer::answerCancel)
		{
			UpdateData(FALSE);
			return;
		}
	}
	// Choi - Debug

	UpdateData(TRUE);
	ChangeGrid();
}

void CPaneSysSetupMGC::ChangeGrid()
{
	CMGCView *pMGCView =
		(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);
	
	pMGCView->SetGrid(m_nGrid);
}

void CPaneSysSetupMGC::OnBtnSelectAll() 
{
	// TODO: Add your control notification handler code here
	CMGCView *pMGCView = 
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->SelectAll();
}

void CPaneSysSetupMGC::OnBtnUnselectAll() 
{
	// TODO: Add your control notification handler code here
	CMGCView *pMGCView = 
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->UnselectAll();
}

void CPaneSysSetupMGC::OnBtnInvert() 
{
	// TODO: Add your control notification handler code here
	CMGCView *pMGCView = 
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->Invert();
}

void CPaneSysSetupMGC::ChangeField()
{
	OnBtnReset();

	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->SetField(m_dFieldSizeX, m_dFieldSizeY);

	CString strField;
	strField.Format(
		_T("%.2f"),
		m_dFieldSizeX
		);

	SetDlgItemText(IDC_STC_FIELD, strField);
}

void CPaneSysSetupMGC::OnBtnReset() 
{
	// TODO: Add your control notification handler code here
	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	if(pMGCView->getModified() == TRUE)
	{
		CDlgQuestionBox dlgQuestionBox;
		dlgQuestionBox.HideCancelBtn();

		dlgQuestionBox.SetContent("Data was modified.\nWill you reset?");

		if(dlgQuestionBox.DoModal() == NAnswer::answerNo)
			return;
	}

	pMGCView->ClearDeltaValue();
	pMGCView->ClearNodeSelected();
	pMGCView->ClearNodeChanged();
	pMGCView->setModified(FALSE);

	pMGCView->SetDrawDelta(FALSE);

	CheckAscTempFileDirectory();
	InitTempFileName();
	
	EnableUndoRedoButton();
	// Reset�� Backup File Number�� 0���� ���� �ʴ´�.
	// Backup File Number�� ���� ����� ���� �ٸ��̸����� ����
	// �� ���� �Ѵ�.
	
}

void CPaneSysSetupMGC::OnBtnApply() 
{
	// TODO: Add your control notification handler code here
	CSelectionView *pSelectionView =
		(CSelectionView *) GetDlgItem(IDC_CTM_SELECTION_VIEW);

	// Choi - Debug
	// ���õ� ������ �ִ��� ���� - ����
	if(pSelectionView->getRegionSelected() == FALSE)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Select region which will be modified"
			);

		dlgInformationBox.DoModal();

		return;
	}
	// ���õ� ������ �ִ��� ���� - ��
	// Choi - Debug

	double dMaxDeltaXOld = m_dDeltaX;
	double dMaxDeltaYOld = m_dDeltaY;

	UpdateData(TRUE);

	CMGCView * pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	// Choi - Debug
	// ���õ� �������� ������ ���� ���õ� Node�� �ִ��� ���� - ����
	if(pMGCView->getNumberOfSelectedNode() == 0)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Select node which will be modified"
			);

		dlgInformationBox.DoModal();

		return;
	}
	// ���õ� �������� ������ ���� ���õ� Node�� �ִ��� ���� - ��
	// Choi - Debug

	int nMaxDeltaInLsbX;
	int nMaxDeltaInLsbY;
	
	nMaxDeltaInLsbX = int(double(65535) * m_dDeltaX / m_dFieldSizeX);
	nMaxDeltaInLsbY = int(double(65535) * m_dDeltaY / m_dFieldSizeY);
	
	if(pMGCView->CheckDeltaLimit(nMaxDeltaInLsbX, nMaxDeltaInLsbY) == TRUE)
	{
		// �ӽ� ���� ���� - ����
		if(IsFileExist(m_strAscTempFileDirectory) == true &&
			IsDirectory(m_strAscTempFileDirectory) == true)
		{
			int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
			int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));
			
			CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
			int nIndex = ::atoi(strTemp);
			
			if(nIndex < m_nNumberOfTempFile)
			{
				m_nNumberOfTempFile = nIndex;
			}
			
			CString strTempFilePath = m_strAscTempFileDirectory + _T("\\") + m_strAscTempFileName;
			pMGCView->SaveTempFile(strTempFilePath);
			m_nNumberOfTempFile++;
			TRACE(_T("Number Of Temp File: %d\n"), m_nNumberOfTempFile);
			FindNextTempFile();

			EnableUndoRedoButton();
		}
		// �ӽ� ���� ���� - ��
		
		pMGCView->CalculateDelta(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		pMGCView->setModified(TRUE);
		
		pMGCView->SetDrawDelta(TRUE);

		pMGCView->Invalidate();
	}
	else
	{
		CDlgInformationBox dlgInformationBox;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Overflow");

		dlgInformationBox.DoModal();

		m_dDeltaX = dMaxDeltaXOld;
		m_dDeltaY = dMaxDeltaYOld;

		UpdateData(FALSE);
	}
	
}

void CPaneSysSetupMGC::ApplyDelta()
{
	UpdateData(FALSE);

	OnBtnApply();
}

void CPaneSysSetupMGC::FindNextTempFile()
{
	int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
	int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));

	CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
	int nIndex = ::atoi(strTemp);
	strTemp.Format(_T("%d"), nIndex + 1);

	m_strAscTempFileName = m_strAscTempFileNameHead + _T("_") + strTemp + _T(".asc");
	TRACE(_T("Current Temp File Name: %s\n"), m_strAscTempFileName);

}

void CPaneSysSetupMGC::FindPrevTempFile()
{
	int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
	int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));

	CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
	int nIndex = ::atoi(strTemp) - 1;

	if(nIndex < 0)
	{
		nIndex = 0;
	}

	if(nIndex == 0)
	{
		CMGCView *pMGCView =
			(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

		//pMGCView->setModified(FALSE);
	}

	strTemp.Format(_T("%d"), nIndex);

	m_strAscTempFileName = m_strAscTempFileNameHead + _T("_") + strTemp + _T(".asc");
	TRACE(_T("Current Temp File Name: %s\n"), m_strAscTempFileName);
}

void CPaneSysSetupMGC::InitTempFileName()
{
	m_strAscTempFileName = m_strAscTempFileNameHead + _T("_0.asc");
	m_nNumberOfTempFile = 0;

	TRACE(_T("Current Temp File Name: %s\n"), m_strAscTempFileName);
	TRACE(_T("Number of Temp File: %d\n"), m_nNumberOfTempFile);
}

void CPaneSysSetupMGC::CheckAscTempFileDirectory()
{
	TRACE(_T("Check Asc Temp File Directory\n"));

	if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory) == true)
	{
		// Asc Temp Directory�� ���� �� ���
		// Asc Temp Directory���� ��� ������ �����.
		TRACE(_T("Asc Temp File Directory : %s : exists\n"), m_strAscTempFileDirectory);

		DeleteAscTempFiles();

		return;
	}
	else if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory) == false)
	{
		// Asc Temp Directory�� �Ȱ��� �̸��� �Ϲ� ������ �����ϴ� ���
		// ���� �̸��� �Ϲ� ������ �����.

		TRACE(_T("Same file %s is exists\n"), m_strAscTempFileDirectory);

		if(::DeleteFile(m_strAscTempFileDirectory) == FALSE)
		{
			TRACE(_T("Fail to delete same file %s\n"), m_strAscTempFileDirectory);

			CDlgInformationBox dlgInformationBox;

			CString strErrorMsg1;
			strErrorMsg1 = "Failed to create Temp Directory for undo operation.\n";
			CString strErrorMsg2;
			strErrorMsg2 = " is already exist.\n";
			CString strErrorMsg3;
			strErrorMsg3 = " , Make this directory.";
			CString strErrorMsg = strErrorMsg1 + m_strAscTempFileDirectory + strErrorMsg2;
			strErrorMsg += m_strAscTempFileDirectory + strErrorMsg3;

			dlgInformationBox.SetTitleContent(
				"ERROR",
				strErrorMsg
				);
			
			dlgInformationBox.DoModal();
			
			return;
		}
	}

	if(::CreateDirectory(m_strAscTempFileDirectory, NULL) == FALSE)
	{
		TRACE(_T("Fail to create Asc Temp File Directory\n"));

		CDlgInformationBox dlgInformationBox;

		CString strErrorMsg1;
		strErrorMsg1 = "Failed to create Temp Directory for undo operation.\n";
		CString strErrorMsg2;
		strErrorMsg2 = "Temp directory for undo operation does not exist.\nCannot operate Undo.";

		CString strErrorMsg = strErrorMsg1 + strErrorMsg2;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			strErrorMsg
			);

		dlgInformationBox.DoModal();

		return;
	}
	
}

void CPaneSysSetupMGC::DeleteAscTempFiles()
{
	WIN32_FIND_DATA wfd32;
	TCHAR szTempFileName[MAX_PATH];
	BOOL bResult = TRUE;
	CString TempFilePath = m_strAscTempFileDirectory + _T("\\*.*");

	HANDLE hSrch = ::FindFirstFile(TempFilePath, &wfd32);
	
	while(bResult)
	{
		if(wfd32.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
		}
		else
		{
			::sprintf_s(szTempFileName, MAX_PATH, _T("%s"), wfd32.cFileName);
			CString strOldTempFilePath = m_strAscTempFileDirectory + _T("\\") + szTempFileName;
			if(::DeleteFile(strOldTempFilePath) == FALSE)
			{
				CString strErrorMsg;
				strErrorMsg = " is unable to delete.";
				strErrorMsg = strOldTempFilePath + strErrorMsg;

				CDlgInformationBox dlgInformationBox;
				dlgInformationBox.SetTitleContent(
					"ERROR",
					strErrorMsg
					);

				dlgInformationBox.DoModal();
			}
			else
			{
				TRACE(_T("Temp File Name %s is deleted\n"), strOldTempFilePath);
			}
		}

		bResult = ::FindNextFile(hSrch, &wfd32);
	}

	::FindClose(hSrch);
}

void CPaneSysSetupMGC::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory) == true)
	{
		DeleteAscTempFiles();
	}
}

int CPaneSysSetupMGC::saveDataBeforeChangeSetting()
{
	CDlgQuestionBox dlgQuestionBox;
	dlgQuestionBox.SetContent("Data was modified.\nWill you save?\nor, Reset?");

	CString str1, str2, str3;
	str1 = "Save";
	str2 = "Reset";
	str3 = "Cancel";
	dlgQuestionBox.SetBtnText(str1, str2, str3);

	int nAnswer = dlgQuestionBox.DoModal();
	if(nAnswer == NAnswer::answerCancel)
		return NAnswer::answerCancel;
	else if(nAnswer == NAnswer::answerNo)
	{
		// Reset �� ������ ȿ���� ����.
		CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

		pMGCView->ClearDeltaValue();
		pMGCView->ClearNodeSelected();
		pMGCView->ClearNodeChanged();
		pMGCView->setModified(FALSE);

		pMGCView->SetDrawDelta(FALSE);

		CheckAscTempFileDirectory();
		InitTempFileName();

		EnableUndoRedoButton();
		// Reset�� Backup File Number�� 0���� ���� �ʴ´�.
		// Backup File Number�� ���� ����� ���� �ٸ��̸����� ����
		// �� ���� �Ѵ�.

		return NAnswer::answerNo;
	}
	
	TCHAR szFilters[] =
		_T("Asc Files (*.asc)|*.asc||");
	DWORD  dwFlags =
		OFN_HIDEREADONLY | OFN_EXPLORER | OFN_NOCHANGEDIR;
	
	CFileDialog dlgFile(FALSE, "*.asc", NULL, dwFlags, szFilters);
	
	dlgFile.m_ofn.lpstrInitialDir = m_strAscDirectory;
	
	if(dlgFile.DoModal() == IDOK)
	{
		CString strAscFilePath = dlgFile.GetPathName();
		
		CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);
		
		// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ����
		pMGCView->CombineAscFileDataAndDeltaValue();
		pMGCView->ClearDeltaValue();
		pMGCView->ClearNodeSelected();
		pMGCView->ClearNodeChanged();
		// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ��
		
		if(pMGCView->SaveAscFile(strAscFilePath) == TRUE)
		{
			m_strAscFilePath = strAscFilePath;
			InitTempFileName();
			
			CString strTitle;
			strTitle.Format(_T("%s - %s"), m_strAppTitle, m_strAscFilePath);
			
			SetWindowText(strTitle);
			
			// Temp File Name �ʱ�ȭ - ����
			CheckAscTempFileDirectory();
			InitTempFileName();
			EnableUndoRedoButton();
			// Temp File Name �ʱ�ȭ - ��
			
			pMGCView->setModified(FALSE);
			pMGCView->Invalidate();
		}
	}
	else
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"WARNING",
			"Data was modified.\nSave First."
			);
		
		dlgInformationBox.DoModal();
		
		return NAnswer::answerCancel;
	}
	
	return NAnswer::answerYes;
}

void CPaneSysSetupMGC::OnBtnChangeAxis() 
{
	// TODO: Add your control notification handler code here
	// Choi - Debug
	CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

	if(pMGCView->getModified() == TRUE)
	{
		int nAnswer = saveDataBeforeChangeSetting();
		if( nAnswer == NAnswer::answerCancel)
			return;
	}
	// Choi - Debug

	CDlgChangeAxis dlgChangeAxis;

	if(dlgChangeAxis.DoModal() == IDCANCEL)
	{
		return;
	}

	m_nAxis = dlgChangeAxis.m_nAxis;

	ChangeAxis();
	
}

void CPaneSysSetupMGC::OnBtnChangeField() 
{
	// TODO: Add your control notification handler code here
	// Choi - Debug
	CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

	if(pMGCView->getModified() == TRUE)
	{
		int nAnswer = saveDataBeforeChangeSetting();
		if( nAnswer == NAnswer::answerCancel)
			return;
	}
	// Choi - Debug

	CDlgChangeField dlgChangeField;

	dlgChangeField.m_dFieldSizeX = m_dFieldSizeX;
	dlgChangeField.m_dFieldSizeY = m_dFieldSizeY;

	if(dlgChangeField.DoModal() == IDOK)
	{
		m_dFieldSizeX = dlgChangeField.m_dFieldSizeX;
		m_dFieldSizeY = dlgChangeField.m_dFieldSizeY;

		ChangeField();
	}
	
}

void CPaneSysSetupMGC::InitToolBar()
{
	m_MainToolBar.Create(this);
	m_MainToolBar.LoadToolBar(IDR_TOOLBAR_MAIN);
	m_MainToolBar.SetBarStyle( CBRS_ALIGN_BOTTOM | CBRS_FLYBY | CBRS_TOOLTIPS);
	m_MainToolBar.ModifyStyle(0, TBSTYLE_FLAT | TBSTYLE_TRANSPARENT);

	CToolBarCtrl &toolBarCtrl = m_MainToolBar.GetToolBarCtrl();
	CBitmap bmp;
	CImageList imageList;

	bmp.LoadMappedBitmap(IDB_TOOLBAR_NORMAL);
	imageList.Create(32, 32, ILC_COLORDDB | ILC_MASK, 9, 1);
	imageList.Add(&bmp, RGB(255, 255, 255));
	toolBarCtrl.SetImageList(&imageList);
	imageList.Detach();
	bmp.Detach();

	bmp.LoadMappedBitmap(IDB_TOOLBAR_HOT);
	imageList.Create(32, 32, ILC_COLORDDB | ILC_MASK, 9, 1);
	imageList.Add(&bmp, RGB(255, 255, 255));
	toolBarCtrl.SetHotImageList(&imageList);
	imageList.Detach();
	bmp.Detach();

	bmp.LoadMappedBitmap(IDB_TOOLBAR_DISABLE);
	imageList.Create(32, 32, ILC_COLORDDB | ILC_MASK, 9, 1);
	imageList.Add(&bmp, RGB(255, 255, 255));
	toolBarCtrl.SetDisabledImageList(&imageList);
	imageList.Detach();
	bmp.Detach();

	/*
	toolBarCtrl.EnableButton(IDT_FILE_OPEN, FALSE);
	toolBarCtrl.EnableButton(IDT_FILE_SAVE, FALSE);
	toolBarCtrl.EnableButton(IDT_FILE_SAVE_AS, FALSE);
	toolBarCtrl.EnableButton(IDT_UNDO, FALSE);
	toolBarCtrl.EnableButton(IDT_REDO, FALSE);
	toolBarCtrl.EnableButton(IDT_ZOOM_IN, FALSE);
	toolBarCtrl.EnableButton(IDT_ZOOM_OUT, FALSE);
	toolBarCtrl.EnableButton(IDT_ZOOM_ALL, FALSE);
	*/

	CRect rectClient;
	GetClientRect(rectClient);

	CMGCView *pMGCView = (CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);
	CRect rectMGCView;
	pMGCView->GetWindowRect(&rectMGCView);
	ScreenToClient(&rectMGCView);

	CRect rectToolBar;
	rectToolBar.left = 0;//rectMGCView.left;
	rectToolBar.top = rectMGCView.bottom;
	rectToolBar.right = rectToolBar.left + rectMGCView.Width();
	rectToolBar.bottom = 720; //rectToolBar.top + rectClient.Height() - (rectMGCView.top + rectMGCView.Height());

	RepositionBars(
		AFX_IDW_CONTROLBAR_FIRST,
		AFX_IDW_CONTROLBAR_LAST,
		0, 0, 0, rectToolBar
		);

	m_MainToolBar.ShowWindow(SW_SHOW);
}

void CPaneSysSetupMGC::OnZoomIn() 
{
	// TODO: Add your command handler code here
	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->PointZoomIn();
	
}

void CPaneSysSetupMGC::OnZoomOut() 
{
	// TODO: Add your command handler code here
	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->PointZoomOut();
	
}

void CPaneSysSetupMGC::OnZoomAll() 
{
	// TODO: Add your command handler code here
	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->PointZoomAll();
	
}

void CPaneSysSetupMGC::OnUndo() 
{
	// TODO: Add your command handler code here
	if(IsFileExist(m_strAscTempFileDirectory) == false)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Temp directory for redo operation does not exist.\nCannot operate Redo."
			);

		dlgInformationBox.DoModal();
		return;
	}
	else if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory) == false)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Temp directory for undo operation does not exist.\nCannot operate Undo."
			);

		dlgInformationBox.DoModal();
		return;
	}

	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	CString strTempFilePath;

	// Temp File Name�� ���� Temp File ���� �� - ����
	// Temp File Name�� Index�� Temp File ������ ���� ���
	// ���� ���¸� Temp File�� �����Ѵ�.
	int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
	int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));
	
	CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
	int nIndex = ::atoi(strTemp);
	if(nIndex == m_nNumberOfTempFile)
	{
		strTempFilePath = m_strAscTempFileDirectory + _T("\\") + m_strAscTempFileName;
		pMGCView->SaveTempFile(strTempFilePath);
		m_nNumberOfTempFile++;
		TRACE(_T("Number Of Temp File: %d\n"), m_nNumberOfTempFile);
	}
	// Temp File Name�� ���� Temp File ���� �� - ��

	FindPrevTempFile();
	
	strTempFilePath = m_strAscTempFileDirectory + _T("\\") + m_strAscTempFileName;
	
	pMGCView->ReadTempFile(strTempFilePath);
	EnableUndoRedoButton();
	
}

void CPaneSysSetupMGC::OnFileOpen() 
{
	// TODO: Add your command handler code here
	CMGCView *pMGCView =
		(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);
	
	// Data�� ���� �Ǿ����� ���� - ����
	if(pMGCView->getModified() == TRUE)
	{
		if(saveDataBeforeChangeSetting() == false)
			return;
	}
	// Data�� ���� �Ǿ����� ���� - ��
	
	TCHAR szFilters[] =
		_T("Asc Files (*.asc)|*.asc||");
	DWORD  dwFlags =
		OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlgFile(TRUE, "*.asc", NULL, dwFlags, szFilters);
	
	dlgFile.m_ofn.lpstrInitialDir = m_strAscDirectory;
	
	if(dlgFile.DoModal() == IDOK)
	{
		CString strAscFilePath = dlgFile.GetPathName();
		
		if(pMGCView->ReadAscFile(strAscFilePath) == TRUE)
		{
			// �������� CMGCView::ReadAscFile()���� �����.
			
			m_strAscFilePath = strAscFilePath;
			InitTempFileName();
			
			// ������ �׸��� ���� - ����
			pMGCView->SetDrawDelta(FALSE);
			// ������ �׸��� ���� - ��
			
			pMGCView->setModified(FALSE);
			
			CString strTitle;
			strTitle.Format(_T("%s - %s"), m_strAppTitle, m_strAscFilePath);
			
			SetWindowText(strTitle);
			
			// Temp File Name �ʱ�ȭ - ����
			CheckAscTempFileDirectory();
			InitTempFileName();
			// Temp File Name �ʱ�ȭ - ��

			// Backup File Number �ʱ�ȭ - ����
			m_nBackupFileNumber = 0;
			// Backup File Number �ʱ�ȭ - ��
		}	
	}
	
}

void CPaneSysSetupMGC::OnFileSave() 
{
	// TODO: Add your command handler code here
	if(m_strAscFilePath == _T(""))
	{
		OnFileSaveAs();
		return;
	}

	// ���� Asc Data Backup - ����
	BackupAscFile();
	// ���� Asc Data Backup - ��

	CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

	// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ����
	pMGCView->CombineAscFileDataAndDeltaValue();
	pMGCView->ClearDeltaValue();
	pMGCView->ClearNodeSelected();
	pMGCView->ClearNodeChanged();
	// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ��

	pMGCView->SaveAscFile(m_strAscFilePath);

	// Temp File Name �ʱ�ȭ - ����
	CheckAscTempFileDirectory();
	InitTempFileName();
	EnableUndoRedoButton(); // Choi - Debug
	// Temp File Name �ʱ�ȭ - ��

	pMGCView->setModified(FALSE);
	pMGCView->Invalidate();
	
}

void CPaneSysSetupMGC::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	TCHAR szFilters[] =
		_T("Asc Files (*.asc)|*.asc||");
	DWORD  dwFlags =
		OFN_HIDEREADONLY | OFN_EXPLORER | OFN_NOCHANGEDIR;

	CFileDialog dlgFile(FALSE, "*.asc", NULL, dwFlags, szFilters);

	dlgFile.m_ofn.lpstrInitialDir = m_strAscDirectory;

	if(dlgFile.DoModal() == IDOK)
	{
		CString strAscFilePath = dlgFile.GetPathName();
		
		// Save As�� Backup�� ���� �ʰ�, Backup File Number �� 0���� �Ѵ�.
		m_nBackupFileNumber = 0;
		// Save As�� Backup�� ���� �ʰ�, Backup File Number �� 0���� �Ѵ�.

		CMGCView *pMGCView =
			(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);
		
		// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ����
		pMGCView->CombineAscFileDataAndDeltaValue();
		pMGCView->ClearDeltaValue();
		pMGCView->ClearNodeSelected();
		pMGCView->ClearNodeChanged();
		// Asc File Data�� �������� ��ġ��, ������ 0���� �ʱ�ȭ �ϱ� - ��

		if(pMGCView->SaveAscFile(strAscFilePath) == TRUE)
		{
			m_strAscFilePath = strAscFilePath;
			InitTempFileName();

			CString strTitle;
			strTitle.Format(_T("%s - %s"), m_strAppTitle, m_strAscFilePath);

			SetWindowText(strTitle);
			
			// Temp File Name �ʱ�ȭ - ����
			CheckAscTempFileDirectory();
			InitTempFileName();
			EnableUndoRedoButton(); // Choi - Debug
			// Temp File Name �ʱ�ȭ - ��
			
			pMGCView->setModified(FALSE);
			pMGCView->Invalidate();
		}
	}
	
}

void CPaneSysSetupMGC::OnRedo() 
{
	// TODO: Add your command handler code here
	if(IsFileExist(m_strAscTempFileDirectory) == false)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Temp directory for undo operation does not exist.\nCannot operate Undo."
			);

		dlgInformationBox.DoModal();
		return;
	}
	else if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory) == false)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Temp directory for undo operation does not exist.\nCannot operate Undo."
			);

		dlgInformationBox.DoModal();
		return;
	}

	CMGCView *pMGCView =
		(CMGCView *) GetDlgItem(IDC_CTM_MGC_VIEW);

	FindNextTempFile();

	// Temp File Name�� ���� Temp File ���� �� - ����
	// Temp File Name�� Index�� Temp File ���� ���� �۾ƾ� �Ѵ�.
	int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
	int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));

	CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
	int nIndex = ::atoi(strTemp);
	// Temp File Name�� ���� Temp File ���� �� - ��

	if(nIndex >= m_nNumberOfTempFile)
	{
		FindPrevTempFile();
		EnableUndoRedoButton();
		return;
	}

	CString strTempFilePath = m_strAscTempFileDirectory + _T("\\") + m_strAscTempFileName;

	pMGCView->ReadTempFile(strTempFilePath);
	pMGCView->setModified(TRUE);
	EnableUndoRedoButton();

	
}

bool CPaneSysSetupMGC::IsTempFileDirectoryExist()
{
	TRACE(_T("Check whether temp file directory exist or not\n"));

	if(IsFileExist(m_strAscTempFileDirectory) == true &&
		IsDirectory(m_strAscTempFileDirectory))
	{
		return true;
	}

	return false;
}

bool CPaneSysSetupMGC::IsFileExist(const CString &strFilePath)
{
	WIN32_FIND_DATA wfd32;

	HANDLE hSrch = ::FindFirstFile(strFilePath, &wfd32);

	if(hSrch == INVALID_HANDLE_VALUE)
	{
		TRACE(_T("%s is not exist\n"), strFilePath);

		return false;
	}

	::FindClose(hSrch);

	return true;
}

bool CPaneSysSetupMGC::IsDirectory(const CString &strFilePath)
{
	WIN32_FIND_DATA wfd32;

	HANDLE hSrch = ::FindFirstFile(strFilePath, &wfd32);

	if(hSrch == INVALID_HANDLE_VALUE)
	{
		TRACE(_T("%s is not exist\n"), strFilePath);

		return false;
	}

	if(wfd32.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{
		::FindClose(hSrch);
		
		return true;
	}

	::FindClose(hSrch);

	return false;
}

BOOL CPaneSysSetupMGC::OnToolTipText(UINT id, NMHDR *pTTStruct, LRESULT *pResult)
{
	TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pTTStruct;

	int nID = pTTStruct->idFrom;

	if((pTTStruct->code == TTN_NEEDTEXT) &&
		(pTTT->uFlags & TTF_IDISHWND))
	{
		nID = ::GetDlgCtrlID((HWND) nID);
	}

	if(nID)
	{
		TCHAR szToolTip[80];
		AfxLoadString(nID, szToolTip, 79);

		CString strToolTip = szToolTip;

		::lstrcpyn(pTTT->szText, strToolTip, sizeof(pTTT->szText));

		*pResult = 0;

		return TRUE;
	}

	return (FALSE);
}

class CToolCmdUI : public CCmdUI
{// class needed for the command button update in a dailog box tool bar
public: // re-implementations only
	virtual void Enable(BOOL bOn);
	virtual void SetCheck(int nCheck);
	virtual void SetText(LPCTSTR lpszText);
};

LRESULT CPaneSysSetupMGC::OnKickIdle(WPARAM wParam, LPARAM lParam)
{
	// Update controls
	UpdateDialogControls(this, FALSE);
	
	// Update toolbar command buttons.
	CToolCmdUI state;
	state.m_pOther = &m_MainToolBar;
	state.m_nIndexMax = m_MainToolBar.GetToolBarCtrl().GetButtonCount();
	for ( state.m_nIndex = 0; state.m_nIndex < state.m_nIndexMax; state.m_nIndex++ )
	{
		state.m_nID = m_MainToolBar.GetItemID( state.m_nIndex );
		
		// ignore separators
		if (!(m_MainToolBar.GetButtonStyle( state.m_nIndex ) & TBSTYLE_SEP))
		{
			// allow the owner to process the update
			state.DoUpdate( this, TRUE );
		}
	}
	
	return 0L;
}

void CPaneSysSetupMGC::OnUpdateRedo(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableRedo);
}

void CPaneSysSetupMGC::OnUpdateUndo(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableUndo);
}

void CPaneSysSetupMGC::EnableUndoRedoButton()
{
	int nIndex1 = m_strAscTempFileName.ReverseFind(_T('_'));
	int nIndex2 = m_strAscTempFileName.ReverseFind(_T('.'));
	
	CString strTemp = m_strAscTempFileName.Mid(nIndex1 + 1, nIndex2 - nIndex1 - 1);
	int nIndex = ::atoi(strTemp);

	if(nIndex == 0)
		m_bEnableUndo = FALSE;
	else
		m_bEnableUndo = TRUE;

	if(nIndex < m_nNumberOfTempFile - 1)
		m_bEnableRedo = TRUE;
	else
		m_bEnableRedo = FALSE;
}

void CPaneSysSetupMGC::EnableZoomIn(BOOL bEnableZoomIn)
{
	m_bEnableZoomIn = bEnableZoomIn;
}

void CPaneSysSetupMGC::EnableZoomOut(BOOL bEnableZoomOut)
{
	m_bEnableZoomOut = bEnableZoomOut;
}

void CPaneSysSetupMGC::EnableZoomAll(BOOL bEnableZoomAll)
{
	m_bEnableZoomAll = bEnableZoomAll;
}

void CPaneSysSetupMGC::EnableCalView(BOOL bEnableCalView)
{
	m_bEnableCalView = bEnableCalView;
}

void CPaneSysSetupMGC::OnUpdateZoomIn(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableZoomIn);
}

void CPaneSysSetupMGC::OnUpdateZoomOut(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableZoomOut);
	
}

void CPaneSysSetupMGC::OnUpdateZoomAll(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableZoomAll);
	
}

void CPaneSysSetupMGC::OnUpdateCalibration(CCmdUI* pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bEnableCalView);

}

void CPaneSysSetupMGC::BackupAscFile()
{
	CString strBackupFilePath = m_strAscFilePath;
	strBackupFilePath.Format(_T("%s.%d"), strBackupFilePath, m_nBackupFileNumber);
	m_nBackupFileNumber++;

	CMGCView *pMGCView =
		(CMGCView *)GetDlgItem(IDC_CTM_MGC_VIEW);

	pMGCView->SaveAscFile(strBackupFilePath);

}

void CPaneSysSetupMGC::SetButtonFont()
{
	// Set Button Font
	m_fontBtn.CreatePointFont(130, "Arial Bold");
	
	// Apply
	m_btnApply.SetFont( &m_fontBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// Select All
	m_btnSelectAll.SetFont( &m_fontBtn );
	m_btnSelectAll.SetFlat( FALSE );
	m_btnSelectAll.EnableBallonToolTip();
	m_btnSelectAll.SetToolTipText( _T("Select All") );
	m_btnSelectAll.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSelectAll.SetBtnCursor(IDC_HAND_1);

	// Deselect All
	m_btnDeselectAll.SetFont( &m_fontBtn );
	m_btnDeselectAll.SetFlat( FALSE );
	m_btnDeselectAll.EnableBallonToolTip();
	m_btnDeselectAll.SetToolTipText( _T("Deselect All") );
	m_btnDeselectAll.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDeselectAll.SetBtnCursor(IDC_HAND_1);

	// Reverse
	m_btnReverse.SetFont( &m_fontBtn );
	m_btnReverse.SetFlat( FALSE );
	m_btnReverse.EnableBallonToolTip();
	m_btnReverse.SetToolTipText( _T("Reverse Selected") );
	m_btnReverse.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReverse.SetBtnCursor(IDC_HAND_1);

	// Reset
	m_btnReset.SetFont( &m_fontBtn );
	m_btnReset.SetFlat( FALSE );
	m_btnReset.EnableBallonToolTip();
	m_btnReset.SetToolTipText( _T("Reset") );
	m_btnReset.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReset.SetBtnCursor(IDC_HAND_1);

	// Change Field
	m_btnChangeField.SetFont( &m_fontBtn );
	m_btnChangeField.SetFlat( FALSE );
	m_btnChangeField.EnableBallonToolTip();
	m_btnChangeField.SetToolTipText( _T("Change Field") );
	m_btnChangeField.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeField.SetBtnCursor(IDC_HAND_1);

	// Change Axis
	m_btnChangeAxis.SetFont( &m_fontBtn );
	m_btnChangeAxis.SetFlat( FALSE );
	m_btnChangeAxis.EnableBallonToolTip();
	m_btnChangeAxis.SetToolTipText( _T("Change Axis") );
	m_btnChangeAxis.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeAxis.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupMGC::OnCalibration() 
{
	CDlgCalibrationView dlgCalibrationView;
	CMGCView* pMGCView = (CMGCView*)GetDlgItem(IDC_CTM_MGC_VIEW);

	dlgCalibrationView.m_pMGCView = pMGCView;
	dlgCalibrationView.m_nAxis = m_nAxis;
	dlgCalibrationView.m_dFieldSizeX = m_dFieldSizeX;
	dlgCalibrationView.m_dFieldSizeY = m_dFieldSizeY;
	dlgCalibrationView.m_nXMax = pMGCView->m_nXMax;
	dlgCalibrationView.m_nYMax = pMGCView->m_nYMax;
	dlgCalibrationView.m_nXMin = pMGCView->m_nXMin;
	dlgCalibrationView.m_nYMin = pMGCView->m_nYMin;
	dlgCalibrationView.m_nDistanceMax = pMGCView->m_nDistanceMax;
	dlgCalibrationView.DoModal();
}

void CPaneSysSetupMGC::EnableControl(BOOL bUse)
{
	m_btnApply.EnableWindow(bUse);
	m_btnSelectAll.EnableWindow(bUse);
	m_btnDeselectAll.EnableWindow(bUse);
	m_btnReverse.EnableWindow(bUse);
	m_btnReset.EnableWindow(bUse);
	m_btnChangeField.EnableWindow(bUse);
	m_btnChangeAxis.EnableWindow(bUse);
	m_MainToolBar.EnableWindow(bUse);

	GetDlgItem(IDC_EDT_X)->EnableWindow(bUse);
	GetDlgItem(IDC_EDT_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_CMB_GRID)->EnableWindow(bUse);
}

void CPaneSysSetupMGC::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}