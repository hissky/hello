#if !defined(AFX_DLGCALRESULT_H__7DA4104E_71CA_46DD_97B3_6C7B6A5EA691__INCLUDED_)
#define AFX_DLGCALRESULT_H__7DA4104E_71CA_46DD_97B3_6C7B6A5EA691__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCalResult.h : header file
//

#include "UEasyButtonEx.h"
#include "ColorStatic.h"
#include "..\model\dpoint.h"
#include "..\device\alAGC.h"

const int MAX_GRIDSIZE	= 65;

/////////////////////////////////////////////////////////////////////////////
// CDlgCalResult dialog

class CDlgCalResult : public CDialog
{
// Construction
public:
	void SetTemperature(BOOL bFullCooling, double d1st, double d2nd, double d1stSB, double d2ndSB, double* pTempVal);
	void SaveScalTimeLog(BOOL bMaster, CString strASCFile);
	void SetToolIndex(int nTool);
	void SetTablePos(double dx, double dy);
	CalAGC* m_pcalAGCMaster;
	CalAGC* m_pcalAGCSlave;
	void SetAGCUnit(CalAGC* pMaster, CalAGC* pSlave);
	void CallOnOk();
	void SetASCFilePath(CString str1st, CString str2nd);
	CDlgCalResult(CWnd* pParent = NULL);   // standard constructor
	
	void		SetAutoProcessMode(void);
	void		SetSelectHead(int nSelHead);

	void		InitBtnControl();
	void		InitStaticControl();

	void		Show1stPanelOffset();
	void		Show1stPanelBackGround();
	void		Show2ndPanelOffset();
	void		Show2ndPanelBackGround();

	BOOL		ReadCalOffsetFile(void);
	BOOL		SaveRawFile();
	BOOL		SetCalMatrix(TCHAR* szMasterFile, TCHAR* szSlaveFile);

// Dialog Data
	//{{AFX_DATA(CDlgCalResult)
	enum { IDD = IDD_DLG_CAL_RESULT };
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnCancel;
	CColorStatic	m_stc2ndY;
	CColorStatic	m_stc2ndX;
	CColorStatic	m_stc1stY;
	CColorStatic	m_stc1stX;
	CColorStatic	m_stc1stR;
	CColorStatic	m_stc2ndR;
	CColorStatic	m_stc2ndCalPath;
	CColorStatic	m_stc1stCalPath;
	UEasyButtonEx	m_chkSaveCalResultFile;
	UEasyButtonEx	m_chkApplyCalResult;
	UEasyButtonEx	m_btn2ndCal;
	UEasyButtonEx	m_btn1stCal;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCalResult)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bFullCoolingAGC;
	double m_d1stTemperature;
	double m_d2ndTemperature;
	double m_d1stSBTemperature;
	double m_d2ndSBTemperature;
	double m_dAllTemper[10];
	double		m_dCalTablePosX;
	double		m_dCalTablePosY;
	
	CFont		m_fntBtn;
	CFont		m_fntStatic;

	int			m_nGridSize;

	double		m_dMaxOffsetMasterX;
	double		m_dMaxOffsetMasterY;
	double		m_dMaxOffsetSlaveX;
	double		m_dMaxOffsetSlaveY;
	double		m_dMaxOffsetMasterR;
	double		m_dMaxOffsetSlaveR;
	DPOINT		m_ptMasterGridOffset[MAX_GRIDSIZE * MAX_GRIDSIZE];
	DPOINT		m_ptSlaveGridOffset[MAX_GRIDSIZE * MAX_GRIDSIZE];

	BOOL		m_bShow;
	BOOL		m_bOnTimer;
	int			m_nTimerID;
	
	BOOL		m_bIsAutoProcessMode;
	int			m_nSelectHead;
	TCHAR		m_c1st1ASC[256];
	TCHAR		m_c2nd1ASC[256];
	int			m_nTool;
	HANDLE		m_hEndView;
	BOOL		m_bDrillingLimitOK[2]; // master/ slave
	// Generated message map functions
	//{{AFX_MSG(CDlgCalResult)
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButton1stCal();
	afx_msg void OnButton2ndCal();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCALRESULT_H__7DA4104E_71CA_46DD_97B3_6C7B6A5EA691__INCLUDED_)
