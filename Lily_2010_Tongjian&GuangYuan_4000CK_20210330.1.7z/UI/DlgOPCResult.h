#pragma once
#include "afxwin.h"
#include "ColorStatic.h"
#include "UEasyButtonEx.h"

// CDlgOPCResult ��ȭ �����Դϴ�.

class CDlgOPCResult : public CDialog
{
	DECLARE_DYNAMIC(CDlgOPCResult)

public:
	CDlgOPCResult(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgOPCResult();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_OPC_RESULT };


	void InitStatic();
	void InitBtn();
	void ChangeDisplay();
	void SetResult(CString strBasket, CString strCount, CString strFilmNO, CString strLotID, CString strMessage, CString strPrjC, CString strPrjS, CString strResult);
	CString m_strBasket;
	CString m_strCount;
	CString m_strFilmNO;
	CString m_strLotID;
	CString m_strMessage;
	CString m_strPrjC;
	CString m_strPrjS;
	CString m_strResult;

	CFont m_fntStatic;
	CFont m_fntBtn;	
	UEasyButtonEx m_btnCancel;
	UEasyButtonEx m_btnOK;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	afx_msg void OnBnClickedOk();
};
