// PaneManualControlOneHole.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlOneHole.h"
#include "DlgLaserBeamHoleSet.h"
#include "DlgMeasuringPCBThickness.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dprocessini.h"
#include "..\model\dsystemini.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\device\HLaser.h"
#include "PaneSysSetup.h"
#include "..\model\GlobalVariable.h"
#include <math.h>
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\model\DBeampathINI.h"
#include "PaneManualControl.h"
#include "PanemanualControlLaser.h"
#include "..\device\HMotor.h"
#include "..\model\DProject.h"
#include "DlgTableView.h"
#include "..\device\HVisionOmi.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include "PaneManualControlScannerCalibration.h"
#include "DlgShotTableNoAom.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


enum {SHOT_BURST, SHOT_CYCLE, SHOT_STEP};

const int GO_RIGHT	= 1;
const int GO_BOTTOM	= 2;
const int GO_LEFT	= 3;
const int GO_TOP	= 4;
const int HEIGHT_GAP	= 500; // um 

#define MAX_CHAR_READ	50

UINT OneHoleThread(LPVOID pParam)
{
	CPaneManualControlOneHole* pRun = (CPaneManualControlOneHole*)pParam;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	//20111107
	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
		{
	#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Shot start Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot start Failure"));
	#endif
			pRun->EnableAllButton(TRUE);
			pRun->EndProcess();
			return 0U;
		}
		pRun->m_StandbyTime.StartTime();
	}
#ifdef __3RDAOD__
	if(gProcessINI.m_sProcessScannerCal.bUseDummy && gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_FIELD)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				pRun->EnableAllButton(TRUE);
				pRun->EndProcess();
				return 0U;
			}
		}
	}
#endif

	int nMask = pRun->m_cmbMask.GetCurSel();
	int nCam = pRun->m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;
	double dHeadOffsetX, dHeadOffsetY;
	BOOL bHigh;
	BOOL bFoundOK;

	pRun->GetHeadOffsets(dHeadOffsetX, dHeadOffsetY, nCam);

	double dVisionXPos = pMotor->GetPosition(AXIS_X);
	double dVisionYPos = pMotor->GetPosition(AXIS_Y);
	pRun->SetDefaultZScan();
	double dLaserXPos = dVisionXPos, dLaserYPos = dVisionYPos;

	if( pRun->m_nPattern != 2)
	{
		dLaserXPos = dVisionXPos - dHeadOffsetX;
		dLaserYPos = dVisionYPos - dHeadOffsetY;
	}
	else
	{
		dLaserXPos = pRun->m_dStartPosX - dHeadOffsetX;
		dLaserYPos = pRun->m_dStartPosY - dHeadOffsetY;
	}
	if( pRun->m_nPattern != 2)
	{
		pRun->m_nGridX = 1;
		pRun->m_nGridY = 1;
	}
	for(int i = 0; i < pRun->m_nGridY; i++)
	{
		if( pRun->m_nPattern == 2)
		{
			if( i >=1)
			{
				dLaserYPos -= pRun->m_dGridGapY;
			}
		}
		for(int j = 0; j < pRun->m_nGridX; j++)
		{
			if( pRun->m_nPattern == 2)
			{
				if( j == 0)
				{
					dLaserXPos = pRun->m_dStartPosX - dHeadOffsetX;
				}
				if( j >= 1)
				{
					dLaserXPos -= pRun->m_dGridGapX;
				}
			}
			if( pRun->m_nPattern == 2)
			{
				if(!pRun->IsValidLaserFirePos(dLaserXPos, dLaserYPos))
					return 0L;

				if(!pRun->TableMoveAndFire(dLaserXPos, dLaserYPos))
					return 0L;

			
//				pRun->FindShot(dLaserXPos +  dHeadOffsetX, dLaserYPos +  dHeadOffsetY);
			}
			else
			{
				if(!pRun->IsValidLaserFirePos(dLaserXPos, dLaserYPos))
					return 0L;

				if(!pRun->TableMoveAndFire(dLaserXPos, dLaserYPos))
					return 0L;

				// find hole
 				if (!pMotor->MoveXY(dVisionXPos, dVisionYPos))
				{
					TRACE("Motor out of position\n");
					pRun->EnableAllButton(TRUE);
					pRun->EndProcess();
					return 0U;
				}
				if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
				{
					TRACE("Motor does not stop\n");
					pRun->EnableAllButton(TRUE);
					pRun->EndProcess();
					return 0U;
				}
				if(pRun->m_bStop)
				{
					pRun->m_bStop = FALSE;
					pRun->EnableAllButton(TRUE);
					pRun->EndProcess();
					return 0U;
				}

				if(nCam%2)
					bHigh = FALSE;
				else
					bHigh = TRUE;

				if(nHead == 0)
				{
					if(!pRun->MoveZ1VisionFocus(bHigh))
					{
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
				}
				else
				{
					if(!pRun->MoveZ2VisionFocus(bHigh))
					{
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
				}
				if(pRun->m_bStop)
				{
					pRun->m_bStop = FALSE;
					pRun->EnableAllButton(TRUE);
					pRun->EndProcess();
					return 0U;
				}

			#ifndef __TEST__
				::Sleep(100);
			#endif

				bFoundOK = pRun->SendMessage(VISION_INSPECTION, (WPARAM)nCam);
				// first end
				// second find
				if(pRun->m_bHeadOffsetMode && bFoundOK)
				{
					if(nCam == HIGH_1ST_CAM) // ���� ���� ����
						nCam = LOW_1ST_CAM;
					else if(nCam == LOW_1ST_CAM)
						nCam = HIGH_1ST_CAM;
					else if(nCam == HIGH_2ND_CAM)
						nCam = LOW_2ND_CAM;
					else 
						nCam = HIGH_2ND_CAM;

					double dHeadOffsetX2, dHeadOffsetY2;
					bHigh = !bHigh;

					pRun->GetHeadOffsets(dHeadOffsetX2, dHeadOffsetY2, nCam);

					if (!pMotor->MoveXY(dVisionXPos + dHeadOffsetX2 - dHeadOffsetX, dVisionYPos + dHeadOffsetY2 - dHeadOffsetY))
					{
						TRACE("Motor out of position\n");
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
					if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
					{
						TRACE("Motor does not stop\n");
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
					if(pRun->m_bStop)
					{
						pRun->m_bStop = FALSE;
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}

					if(nHead == 0)
					{
						if(!pRun->MoveZ1VisionFocus(bHigh))
						{
							pRun->EnableAllButton(TRUE);
							pRun->EndProcess();
							return 0U;
						}
					}
					else
					{
						if(!pRun->MoveZ2VisionFocus(bHigh))
						{
							pRun->EnableAllButton(TRUE);
							pRun->EndProcess();
							return 0U;
						}
					}
					if(pRun->m_bStop)
					{
						pRun->m_bStop = FALSE;
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}

				#ifndef __TEST__
					::Sleep(100);
				#endif
					bFoundOK = pRun->SendMessage(VISION_INSPECTION, (WPARAM)nCam, TRUE);
					if (!pMotor->MoveXY(dVisionXPos, dVisionYPos))
					{
						TRACE("Motor out of position\n");
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
					if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
					{
						TRACE("Motor does not stop\n");
						pRun->EnableAllButton(TRUE);
						pRun->EndProcess();
						return 0U;
					}
					bHigh = !bHigh;
					if(nHead == 0)
					{
						if(!pRun->MoveZ1VisionFocus(bHigh))
						{
							pRun->EnableAllButton(TRUE);
							pRun->EndProcess();
							return 0U;
						}
					}
					else
					{
						if(!pRun->MoveZ2VisionFocus(bHigh))
						{
							pRun->EnableAllButton(TRUE);
							pRun->EndProcess();
							return 0U;
						}
					}
				}
			}
		}
	}
	//

	if( pRun->m_nPattern == 2)
	{
		dLaserXPos = pRun->m_dStartPosX - dHeadOffsetX;
		dLaserYPos = pRun->m_dStartPosY - dHeadOffsetY;
		for(int i = 0; i < pRun->m_nGridY; i++)
		{
			if( i >=1)
			{
				dLaserYPos -= pRun->m_dGridGapY;
			}
			for(int j = 0; j < pRun->m_nGridX; j++)
			{
				if( j == 0)
				{
					dLaserXPos = pRun->m_dStartPosX - dHeadOffsetX;
				}
				if( j >= 1)
				{
					dLaserXPos -= pRun->m_dGridGapX;
				}

				pRun->FindShot(dLaserXPos +  dHeadOffsetX, dLaserYPos +  dHeadOffsetY);

				if(pRun->m_bStop)
				{
					break;
				}
			}
			if(pRun->m_bStop)
			{
				break;
			}
		}
	}
	pRun->EnableAllButton(TRUE);
	pRun->EndProcess();

	pRun->m_bStop = FALSE;

	pRun->m_pOneHole = NULL;

	if(pRun->m_bHeadOffsetMode && bFoundOK)
		pRun->SetHeadOffsetRes();

	return 1U;
}

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlOneHole

IMPLEMENT_DYNCREATE(CPaneManualControlOneHole, CFormView)

CPaneManualControlOneHole::CPaneManualControlOneHole()
	: CFormView(CPaneManualControlOneHole::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlOneHole)
	m_nFireType = 0;
	//}}AFX_DATA_INIT
	m_nCamNo		= 0;
	m_bIsLive			= FALSE;
	m_dBaseX = 0.0;
	m_dBaseY = 0.0;
	m_dBaseZ1 = 0.0;
	m_dBaseZ2 = 0.0;

	for(int i = 0 ; i < MAX_BEAM_HOLE ; i++ )
		m_dHoleSet[i] = 11.;

	m_bLineFire = FALSE;
	m_bTopHat = FALSE;
	m_bStop = FALSE;
	m_bBeamPass = FALSE;
	m_pOneHole = NULL;
	m_strPath = _T("");
	m_bHeadOffsetMode = FALSE; 

	m_dHeadOffsetX = 0;
	m_dHeadOffsetY = 0;
	m_nBeamPath = 0;
	m_nUserLevel = 0;

	m_nZIndex = 0;
	m_nXScanIndex = 0;
	m_nYScanIndex = 0;
	m_nPattern = 0;
	m_nIncrementalFirstPosX = 0;
	m_nIncrementalFirstPosY = 0;

	m_bContinuousFind = FALSE;
	m_nAxisMode = PX_PY;
	memset( &sVisionInfo, 0, sizeof(sVisionInfo) );
	for(int i=0; i<4; i++)
	{
		CString strCoaxial, strRing;
		gDeviceFactory.GetVision()->GetLampValue(i, strCoaxial, strRing); 
		int nCoaxial, nRing;
		sVisionInfo.nCoaxial[i] = atoi(strCoaxial);
		sVisionInfo.nRing[i] = atoi(strRing);
	}
	m_nRemote = 0;
	m_dStartPosX = 0;
	m_dStartPosY = 0;
	m_dGridGapX = 0;
	m_dGridGapY = 0;
	m_nGridX = 0;
	m_nGridY = 0;
	m_dStartPosX = 0;
}

CPaneManualControlOneHole::~CPaneManualControlOneHole()
{
	DeleteData();
}

void CPaneManualControlOneHole::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlOneHole)
	DDX_Control(pDX, IDC_EDIT_JOB_FILE, m_edtPath);
	DDX_Control(pDX, IDC_EDIT_SCANNER_POS_Y, m_edtScannerPosY);
	DDX_Control(pDX, IDC_EDIT_SCANNER_POS_X, m_edtScannerPosX);
	DDX_Control(pDX, IDC_STATIC_POS_Y, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_X, m_stcPosX);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_EDIT_THICKNESS, m_edtThickness);
	DDX_Control(pDX, IDC_EDIT_SHOT_COUNT, m_edtShotCount);
	DDX_Control(pDX, IDC_EDIT_BURST_COUNT, m_edtBurstCount);
	DDX_Control(pDX, IDC_COMBO_MASK, m_cmbMask);
	DDX_Control(pDX, IDC_COMBO_CAM, m_cmbCam);
	DDX_Control(pDX, IDC_CHECK_INSP_AREA, m_chkInspArea);
	DDX_Control(pDX, IDC_BUTTON_SET_CUR_POS_ZERO_Y, m_btnSetCurPosZeroY);
	DDX_Control(pDX, IDC_BUTTON_SET_CUR_POS_ZERO_X, m_btnSetCurPosZeroX);
	DDX_Control(pDX, IDC_BUTTON_PULSE_WIDTH, m_btnPulseWidth);
	DDX_Control(pDX, IDC_BUTTON_MEASURE, m_btnMeasure);
	DDX_Control(pDX, IDC_BUTTON_FIRE, m_btnFire);
	DDX_Control(pDX, IDC_BUTTON_PATTERN, m_btnPattern);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, m_btnManualSCalPosMove);
	DDX_Radio(pDX, IDC_RADIO_USE_DEFAULT, m_nPattern);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApplyToBeampath);
	DDX_Control(pDX, IDC_BUTTON_VISION_TEST, m_btnVisionTest);
	DDX_Control(pDX, IDC_BUTTON_VFIRE, m_btnVariousFire);
	DDX_Control(pDX, IDC_BTN_APPLY_Z, m_btnApplyZ);
	DDX_Control(pDX, IDC_CHECK_TOPHAT, m_chkTopHat);
	DDX_Control(pDX, IDC_STATIC_VISION_RESULT, m_stcVisionResult);
	DDX_Control(pDX, IDC_EDIT_GRID_SIZE_X_VAL, m_edtGridX);
	DDX_Control(pDX, IDC_EDIT_GRID_SIZE_Y_VAL, m_edtGridY);
	DDX_Control(pDX, IDC_EDIT_FIELD_SIZE, m_edtFieldSize);
	DDX_Radio(pDX, IDC_RADIO_BURST, m_nFireType);
	DDX_Control(pDX, IDC_CHECK_SUB_LINE, m_chkLineFire);
	DDX_Control(pDX, IDC_BUTTON_SUB_APERTURE_OPEN, m_btnFileOpen);
	DDX_Control(pDX, IDC_EDIT_APERTURE_FILE_PATH, m_edtAperturePath);
	DDX_Control(pDX, IDC_BUTTON_JOB_FILE_OPEN3, m_btnJobFile);
	DDX_Control(pDX, IDC_BUTTON_HEAD_OFFSET, m_btnHeadOffset);
	DDX_Control(pDX, IDC_EDIT_HEAD_OFFSET_X, m_edtHeadOffsetX);
	DDX_Control(pDX, IDC_EDIT_HEAD_OFFSET_Y, m_edtHeadOffsetY);
	DDX_Control(pDX, IDC_COMBO_TOOL2, m_cmbTool);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M1, m_edtTargetM1);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M3, m_edtTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_B1, m_edtTargetB1);
	DDX_Control(pDX, IDC_EDIT_TARGET_B2, m_edtTargetB2);
	DDX_Control(pDX, IDC_EDIT_TARGET_A1, m_edtTargetA1);
	DDX_Control(pDX, IDC_EDIT_TARGET_A2, m_edtTargetA2);
	DDX_Control(pDX, IDC_EDIT_GAP, m_edtZGap);
	DDX_Control(pDX, IDC_BTN_Z1, m_btnZMinus5);
	DDX_Control(pDX, IDC_BTN_Z2, m_btnZMinus4);
	DDX_Control(pDX, IDC_BTN_Z3, m_btnZMinus3);
	DDX_Control(pDX, IDC_BTN_Z4, m_btnZMinus2);
	DDX_Control(pDX, IDC_BTN_Z5, m_btnZMinus1);
	DDX_Control(pDX, IDC_BTN_Z6, m_btnZNone);
	DDX_Control(pDX, IDC_BTN_Z7, m_btnZPlus1);
	DDX_Control(pDX, IDC_BTN_Z8, m_btnZPlus2);
	DDX_Control(pDX, IDC_BTN_Z9, m_btnZPlus3);
	DDX_Control(pDX, IDC_BTN_Z10, m_btnZPlus4);
	DDX_Control(pDX, IDC_BTN_Z11, m_btnZPlus5);
	DDX_Control(pDX, IDC_BTN_UPLEFT, m_btnLeftTop);
	DDX_Control(pDX, IDC_BTN_UPRIGHT, m_btnRightTop);
	DDX_Control(pDX, IDC_BTN_CENTER, m_btnCenter);
	DDX_Control(pDX, IDC_BTN_DOWNLEFT, m_btnLeftBottom);
	DDX_Control(pDX, IDC_BTN_DOWNRIGHT, m_btnRightBottom);
	DDX_Control(pDX, IDC_CHECK_USE_PARMA, m_chkUseParam);
	DDX_Control(pDX, IDC_EDIT_FREQ, m_edtFreq);
	DDX_Control(pDX, IDC_EDIT_DUTY, m_edtDuty);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY, m_edtAOMDelay);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY, m_edtAOMDuty);
	DDX_Control(pDX, IDC_EDIT_TARGET_VOLTAGE1, m_edtVoltage1);
	DDX_Control(pDX, IDC_EDIT_TARGET_VOLTAGE2, m_edtVoltage2);
	DDX_Control(pDX, IDC_CHECK_BEAM_PASS, m_chkBeamPath);
	DDX_Control(pDX, IDC_EDIT_TARGET_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_TARGET_COAXIAL, m_edtCoaxial);
	DDX_Radio(pDX, IDC_RADIO_REMOTE, m_nRemote);
	DDX_Control(pDX, IDC_EDIT_X_POS, m_edtXPos);
	DDX_Control(pDX, IDC_EDIT_Y_POS, m_edtYPos);
	DDX_Control(pDX, IDC_EDIT_GRID_GAP_X, m_edtGridGapX);
	DDX_Control(pDX, IDC_EDIT_GRID_GAP_Y, m_edtGridGapY);
	DDX_Control(pDX, IDC_EDIT_GRID_X_NO, m_edtGridXNo);
	DDX_Control(pDX, IDC_EDIT_GRID_Y_NO, m_edtGridYNo);

	DDX_Control(pDX, IDC_BUTTON_FIRE2, m_btnFire2);
	DDX_Control(pDX, IDC_BUTTON_SHOT_EDIT, m_btnShotEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlOneHole, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlOneHole)
	ON_BN_CLICKED(IDC_CHECK_SUB_LINE, OnCheckLineFire)
	ON_BN_CLICKED(IDC_BUTTON_SUB_APERTURE_OPEN, OnButtonApertureOpen)
	ON_BN_CLICKED(IDC_BUTTON_FIRE, OnButtonFire)
	ON_BN_CLICKED(IDC_BUTTON_PATTERN, OnButtonPattern)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, OnButtonManualSCalPosMove)
	ON_BN_CLICKED(IDC_RADIO_USE_DEFAULT, OnButtonDefaultMode)
	ON_BN_CLICKED(IDC_RADIO_USE_PATTERN, OnButtonPatternMode)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_PULSE_WIDTH, OnButtonPulseWidth)
	ON_BN_CLICKED(IDC_BUTTON_MEASURE, OnButtonMeasure)
	ON_BN_CLICKED(IDC_RADIO_BURST, OnButtonBurst)
	ON_BN_CLICKED(IDC_BUTTON_SET_CUR_POS_ZERO_X, OnStartPosX)
	ON_BN_CLICKED(IDC_BUTTON_SET_CUR_POS_ZERO_Y, OnStartPosY)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_COMBO_CAM, OnSelchangeComboCam)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_JOB_FILE_OPEN3, OnButtonJobFileOpen)
	ON_BN_CLICKED(IDC_BUTTON_HEAD_OFFSET, OnButtonHeadOffset)
	ON_CBN_SELCHANGE(IDC_COMBO_TOOL2, OnEditchangeComboTool)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_VISION_TEST, OnButtonVisionTest)	
	ON_BN_CLICKED(IDC_CHECK_TOPHAT, OnCheckTophat)
	ON_BN_CLICKED(IDC_BUTTON_VFIRE, OnButtonVfire)
	ON_BN_CLICKED(IDC_BTN_APPLY_Z, OnBtnApplyZ)
	ON_BN_CLICKED(IDC_BTN_Z1, OnBtnZ1)
	ON_BN_CLICKED(IDC_BTN_Z2, OnBtnZ2)
	ON_BN_CLICKED(IDC_BTN_Z3, OnBtnZ3)
	ON_BN_CLICKED(IDC_BTN_Z4, OnBtnZ4)
	ON_BN_CLICKED(IDC_BTN_Z5, OnBtnZ5)
	ON_BN_CLICKED(IDC_BTN_Z6, OnBtnZ6)
	ON_BN_CLICKED(IDC_BTN_Z7, OnBtnZ7)
	ON_BN_CLICKED(IDC_BTN_Z8, OnBtnZ8)
	ON_BN_CLICKED(IDC_BTN_Z9, OnBtnZ9)
	ON_BN_CLICKED(IDC_BTN_Z10, OnBtnZ10)
	ON_BN_CLICKED(IDC_BTN_Z11, OnBtnZ11)
	ON_BN_CLICKED(IDC_BTN_UPLEFT, OnBtnUpleft)
	ON_BN_CLICKED(IDC_BTN_UPRIGHT, OnBtnUpright)
	ON_BN_CLICKED(IDC_BTN_CENTER, OnBtnCenter)
	ON_BN_CLICKED(IDC_BTN_DOWNLEFT, OnBtnDownleft)
	ON_BN_CLICKED(IDC_RADIO_CYCLE, OnButtonBurst)
	ON_BN_CLICKED(IDC_RADIO_STEP, OnButtonBurst)
	ON_BN_CLICKED(IDC_BTN_DOWNRIGHT, OnBtnDownright)
	//}}AFX_MSG_MAP
	ON_MESSAGE( VISION_INSPECTION, OnInspection )
	ON_BN_CLICKED(IDC_BTN_CHANGE_AXIS, OnBnClickedBtnChangeAxis)
	ON_BN_CLICKED(IDC_BTN_FIND_HOLE, OnBnClickedBtnFindHole)
	ON_BN_CLICKED(IDC_CHECK_CONTINUE, OnBnClickedCheckContinue)
	ON_BN_CLICKED(IDC_BTN_FIND_STOP, OnBnClickedBtnFindStop)
	ON_BN_CLICKED(IDC_RADIO_REMOTE,OnRadioRemote)
	ON_BN_CLICKED(IDC_RADIO_MANUAL,OnRadioManual)
	
	ON_BN_CLICKED(IDC_BUTTON_SHOT_EDIT, &CPaneManualControlOneHole::OnBnClickedButtonShotEdit)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlOneHole diagnostics

#ifdef _DEBUG
void CPaneManualControlOneHole::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlOneHole::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlOneHole message handlers

void CPaneManualControlOneHole::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitComboControl();
	InitListBoxControl();

	OnCheckLineFire();

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_JOB_FILE)->ShowWindow(FALSE);
		GetDlgItem(IDC_EDIT_JOB_FILE)->ShowWindow(FALSE);
		GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN3)->ShowWindow(FALSE);
	}
	CString strCoaxial, strRing;
	gDeviceFactory.GetVision()->GetLampValue(m_cmbCam.GetCurSel(), strCoaxial, strRing );
	m_edtCoaxial.SetWindowText(strCoaxial);
	m_edtRing.SetWindowText(strRing);

#ifdef __PUSAN_LDD__
	m_nTimerID = SetTimer( 428, 500, NULL );
#endif

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
//		GetDlgItem(IDC_STATIC_THICKNESS)->EnableWindow(FALSE);
//		m_edtThickness.EnableWindow(FALSE);
		m_btnMeasure.EnableWindow(FALSE);
	}

	if(!gSystemINI.m_sHardWare.nUseAOD)
	{
		GetDlgItem(IDC_STATIC_VOLTAGE1)->ShowWindow(SW_HIDE);	
		GetDlgItem(IDC_STATIC_VOLTAGE2)->ShowWindow(SW_HIDE);
		m_edtVoltage1.ShowWindow(SW_HIDE);
		m_edtVoltage2.ShowWindow(SW_HIDE);
	}
	else
	{
//		m_chkTopHat.SetWindowText(_T("Use Long Path"));
	}
#ifdef __PUSAN2__
#ifndef __SERVO_MOTOR__
	GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);
#endif
#endif

#ifdef __PUSAN_LDD__
	GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_B2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_B2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TOPHAT)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_CHECK_BEAM_PASS)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_STATIC_B1)->SetWindowText("C1");
	GetDlgItem(IDC_STATIC_B1)->ShowWindow(SW_HIDE);
#endif

#ifdef __PUSAN_OLD_32__
	GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VOLTAGE2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE2)->ShowWindow(SW_HIDE);
#endif
#ifdef __PUSAN_OLD_17__
	#ifndef __SERVO_MOTOR__
		GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);	
		GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);
	#endif
#endif
#ifdef __KUNSAN_1__
	GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_B2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_B2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_B1)->SetWindowText("C1");
#endif

#ifdef __KUNSAN_8__
	GetDlgItem(IDC_CHECK_TOPHAT)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_CHECK_BEAM_PASS)->ShowWindow(SW_HIDE);
	
	GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_B2)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_M2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);	
	GetDlgItem(IDC_EDIT_TARGET_B2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_B1)->SetWindowText("C1");
	GetDlgItem(IDC_STATIC_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VOLTAGE2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE2)->ShowWindow(SW_HIDE);
#endif

#ifdef __3RDAOD__
	GetDlgItem(IDC_STATIC_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VOLTAGE2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DUTY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_VOLTAGE2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(SW_HIDE);
#endif
}

BOOL CPaneManualControlOneHole::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlOneHole::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// JobFile
	GetDlgItem(IDC_STATIC_JOB_FILE)->SetFont( &m_fntStatic );

	// Setting
	GetDlgItem(IDC_STATIC_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_USE_PATTERN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BURST_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_GRID_SIZE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_GRID_SIZE_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIELD_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_POS_Y)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_LEN)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HEAD_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HEAD_OFFSET2)->SetFont( &m_fntStatic );
	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );

	m_stcVisionResult.SetFont( &m_fntStatic );
	m_stcVisionResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcVisionResult.SetBackColor( VALUE_BACK_COLOR );

	// parameter
	GetDlgItem(IDC_STATIC_PARAM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOOL_NO2)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_Z1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Z2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_M1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_M2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_M3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_B1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_B2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_A1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_A_2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_DUTY2)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_AOM_DELAY)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_AOM_DUTY)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );	

	//various Z
	GetDlgItem(IDC_STATIC_VIEW_POINT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Z_GAP)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_VOLTAGE1)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_VOLTAGE2)->SetFont( &m_fntStatic );
}

void CPaneManualControlOneHole::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_RADIO_BURST)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_CYCLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_STEP)->SetFont( &m_fntBtn );


	// Pulse Width
	m_btnPulseWidth.SetFont( &m_fntBtn );
	m_btnPulseWidth.SetFlat( FALSE );
	m_btnPulseWidth.EnableBallonToolTip();
	m_btnPulseWidth.SetToolTipText( _T("Pulse Width") );
	m_btnPulseWidth.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPulseWidth.SetBtnCursor(IDC_HAND_1);

	// Measure
	m_btnMeasure.SetFont( &m_fntBtn );
	m_btnMeasure.SetFlat( FALSE );
	m_btnMeasure.EnableBallonToolTip();
	m_btnMeasure.SetToolTipText( _T("Height Sensor Measurement") );
	m_btnMeasure.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMeasure.SetBtnCursor(IDC_HAND_1);

	// Set Current X Position to zero
	m_btnSetCurPosZeroX.SetFont( &m_fntBtn );
	m_btnSetCurPosZeroX.SetFlat( FALSE );
	m_btnSetCurPosZeroX.EnableBallonToolTip();
	m_btnSetCurPosZeroX.SetToolTipText( _T("Set Current X Position to zero") );
	m_btnSetCurPosZeroX.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetCurPosZeroX.SetBtnCursor(IDC_HAND_1);

	// Set Current Y Position to zero
	m_btnSetCurPosZeroY.SetFont( &m_fntBtn );
	m_btnSetCurPosZeroY.SetFlat( FALSE );
	m_btnSetCurPosZeroY.EnableBallonToolTip();
	m_btnSetCurPosZeroY.SetToolTipText( _T("Set Current Y Position to zero") );
	m_btnSetCurPosZeroY.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetCurPosZeroY.SetBtnCursor(IDC_HAND_1);

	// Fire
	m_btnFire.SetFont( &m_fntBtn );
	m_btnFire.SetFlat( FALSE );
	m_btnFire.EnableBallonToolTip();
	m_btnFire.SetToolTipText( _T("Fire") );
	m_btnFire.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFire.SetBtnCursor(IDC_HAND_1);

	m_btnFire2.SetFont( &m_fntBtn );
	m_btnFire2.SetFlat( FALSE );
	m_btnFire2.EnableBallonToolTip();
	m_btnFire2.SetToolTipText( _T("Fire") );
	m_btnFire2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFire2.SetBtnCursor(IDC_HAND_1);
	
	//Pattern
	m_btnPattern.SetFont( &m_fntBtn );
	m_btnPattern.SetFlat( FALSE );
	m_btnPattern.EnableBallonToolTip();
	m_btnPattern.SetToolTipText( _T("Pattern Load") );
	m_btnPattern.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPattern.SetBtnCursor(IDC_HAND_1);

	//Manual S.Cal Position Move
	m_btnManualSCalPosMove.SetFont( &m_fntBtn );
	m_btnManualSCalPosMove.SetFlat( FALSE );
	m_btnManualSCalPosMove.EnableBallonToolTip();
	m_btnManualSCalPosMove.SetToolTipText( _T("Pattern Load") );
	m_btnManualSCalPosMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualSCalPosMove.SetBtnCursor(IDC_HAND_1);
	
	//Pattern Mode
	GetDlgItem(IDC_RADIO_USE_PATTERN)->SetFont(&m_fntBtn);

	//Default Mode
	GetDlgItem(IDC_RADIO_USE_DEFAULT)->SetFont(&m_fntBtn);

	// Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	// Inspection Area
	m_chkInspArea.SetFont( &m_fntBtn );
	m_chkInspArea.SetImageOrg( 10, 3 );
	m_chkInspArea.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkInspArea.EnableBallonToolTip();
	m_chkInspArea.SetToolTipText( _T("Insp Area") );
	m_chkInspArea.SetBtnCursor(IDC_HAND_1);
	m_chkInspArea.SetCheck( 1 );
	m_chkInspArea.ShowWindow(SW_HIDE);

	// Use Aperture
	m_chkLineFire.SetFont( &m_fntBtn );
	m_chkLineFire.SetImageOrg( 10, 3 );
	m_chkLineFire.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkLineFire.EnableBallonToolTip();
	m_chkLineFire.SetToolTipText( _T("Use Line") );
	m_chkLineFire.SetBtnCursor(IDC_HAND_1);
	m_chkLineFire.EnableWindow(TRUE);

	// Use Parameter
	m_chkUseParam.SetFont( &m_fntBtn );
	m_chkUseParam.SetImageOrg( 10, 3 );
	m_chkUseParam.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseParam.EnableBallonToolTip();
	m_chkUseParam.SetToolTipText( _T("Use Parameter") );
	m_chkUseParam.SetBtnCursor(IDC_HAND_1);
	m_chkUseParam.EnableWindow(TRUE);

	// Aperture File Open
	m_btnFileOpen.SetFont( &m_fntBtn );
	m_btnFileOpen.SetFlat( FALSE );
	m_btnFileOpen.EnableBallonToolTip();
	m_btnFileOpen.SetToolTipText( _T("Aperture File Open") );
	m_btnFileOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFileOpen.SetBtnCursor(IDC_HAND_1);

	// Head Offset
	m_btnHeadOffset.SetFont( &m_fntBtn );
	m_btnHeadOffset.SetFlat( FALSE );
	m_btnHeadOffset.EnableBallonToolTip();
	m_btnHeadOffset.SetToolTipText( _T("Get Head Offset") );
	m_btnHeadOffset.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeadOffset.SetBtnCursor(IDC_HAND_1);

	m_fntBtn2.CreatePointFont(120, "Arial Bold");
	
	m_btnJobFile.SetFont( &m_fntBtn2 );
	m_btnJobFile.SetFlat( FALSE );
	m_btnJobFile.EnableBallonToolTip();
	m_btnJobFile.SetToolTipText( _T("Job FilePath Selection") );
	m_btnJobFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobFile.SetBtnCursor(IDC_HAND_1);

	m_btnApplyToBeampath.SetFont( &m_fntBtn );
	m_btnApplyToBeampath.SetFlat( FALSE );
	m_btnApplyToBeampath.EnableBallonToolTip();
	m_btnApplyToBeampath.SetToolTipText( _T("Apply parameter to Beam path") );
	m_btnApplyToBeampath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyToBeampath.SetBtnCursor(IDC_HAND_1);

	m_btnVisionTest.SetFont( &m_fntBtn );
	m_btnVisionTest.SetFlat( FALSE );
	m_btnVisionTest.EnableBallonToolTip();
	m_btnVisionTest.SetToolTipText( _T("Test") );
	m_btnVisionTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVisionTest.SetBtnCursor(IDC_HAND_1);
	
	// use top hat
	m_chkTopHat.SetFont( &m_fntBtn );
	m_chkTopHat.SetImageOrg( 10, 3 );
	m_chkTopHat.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkTopHat.EnableBallonToolTip();
	m_chkTopHat.SetToolTipText( _T("Use Top hat mode") );
	m_chkTopHat.SetBtnCursor(IDC_HAND_1);
	m_chkTopHat.EnableWindow(TRUE);

	// Use BeamPath
	m_chkBeamPath.SetFont( &m_fntBtn );
	m_chkBeamPath.SetImageOrg( 10, 3 );
	m_chkBeamPath.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkBeamPath.EnableBallonToolTip();
	m_chkBeamPath.SetToolTipText( _T("Use Long Pass") );
	m_chkBeamPath.SetBtnCursor(IDC_HAND_1);
	m_chkBeamPath.EnableWindow(TRUE);
#ifdef __PUSAN_OLD_17__
	m_chkBeamPath.ShowWindow(SW_HIDE);
#endif
	
#ifdef __PUSAN_OLD_32__
	m_chkBeamPath.ShowWindow(SW_HIDE);
#endif
	m_btnVariousFire.SetFont( &m_fntBtn );
	m_btnVariousFire.SetFlat( FALSE );
	m_btnVariousFire.EnableBallonToolTip();
	m_btnVariousFire.SetToolTipText( _T("Fire in 11 z-axis position") );
	m_btnVariousFire.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVariousFire.SetBtnCursor(IDC_HAND_1);
	
	m_btnApplyZ.SetFont( &m_fntBtn );
	m_btnApplyZ.SetFlat( FALSE );
	m_btnApplyZ.EnableBallonToolTip();
	m_btnApplyZ.SetToolTipText( _T("Apply Selected Z position to Parameter UI") );
	m_btnApplyZ.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyZ.SetBtnCursor(IDC_HAND_1);

	m_btnZMinus5.SetFont( &m_fntBtn );
	m_btnZMinus5.SetFlat( FALSE );
	m_btnZMinus5.EnableBallonToolTip();
	m_btnZMinus5.SetToolTipText( _T("Show default Z - 5 Position Hole") );
	m_btnZMinus5.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZMinus5.SetBtnCursor(IDC_HAND_1);

	m_btnZMinus4.SetFont( &m_fntBtn );
	m_btnZMinus4.SetFlat( FALSE );
	m_btnZMinus4.EnableBallonToolTip();
	m_btnZMinus4.SetToolTipText( _T("Show default Z - 4 Position Hole") );
	m_btnZMinus4.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZMinus4.SetBtnCursor(IDC_HAND_1);

	m_btnZMinus3.SetFont( &m_fntBtn );
	m_btnZMinus3.SetFlat( FALSE );
	m_btnZMinus3.EnableBallonToolTip();
	m_btnZMinus3.SetToolTipText( _T("Show default Z - 3 Position Hole") );
	m_btnZMinus3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZMinus3.SetBtnCursor(IDC_HAND_1);

	m_btnZMinus2.SetFont( &m_fntBtn );
	m_btnZMinus2.SetFlat( FALSE );
	m_btnZMinus2.EnableBallonToolTip();
	m_btnZMinus2.SetToolTipText( _T("Show default Z - 2 Position Hole") );
	m_btnZMinus2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZMinus2.SetBtnCursor(IDC_HAND_1);

	m_btnZMinus1.SetFont( &m_fntBtn );
	m_btnZMinus1.SetFlat( FALSE );
	m_btnZMinus1.EnableBallonToolTip();
	m_btnZMinus1.SetToolTipText( _T("Show default Z - 1 Position Hole") );
	m_btnZMinus1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZMinus1.SetBtnCursor(IDC_HAND_1);

	m_btnZNone.SetFont( &m_fntBtn );
	m_btnZNone.SetFlat( FALSE );
	m_btnZNone.EnableBallonToolTip();
	m_btnZNone.SetToolTipText( _T("Show default Z Position Hole") );
	m_btnZNone.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZNone.SetBtnCursor(IDC_HAND_1);
	m_btnZNone.SetSelection( TRUE );
	
	m_btnZPlus1.SetFont( &m_fntBtn );
	m_btnZPlus1.SetFlat( FALSE );
	m_btnZPlus1.EnableBallonToolTip();
	m_btnZPlus1.SetToolTipText( _T("Show default Z + 1 Position Hole") );
	m_btnZPlus1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZPlus1.SetBtnCursor(IDC_HAND_1);
	
	m_btnZPlus2.SetFont( &m_fntBtn );
	m_btnZPlus2.SetFlat( FALSE );
	m_btnZPlus2.EnableBallonToolTip();
	m_btnZPlus2.SetToolTipText( _T("Show default Z + 2 Position Hole") );
	m_btnZPlus2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZPlus2.SetBtnCursor(IDC_HAND_1);

	m_btnZPlus3.SetFont( &m_fntBtn );
	m_btnZPlus3.SetFlat( FALSE );
	m_btnZPlus3.EnableBallonToolTip();
	m_btnZPlus3.SetToolTipText( _T("Show default Z + 3 Position Hole") );
	m_btnZPlus3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZPlus3.SetBtnCursor(IDC_HAND_1);

	m_btnZPlus4.SetFont( &m_fntBtn );
	m_btnZPlus4.SetFlat( FALSE );
	m_btnZPlus4.EnableBallonToolTip();
	m_btnZPlus4.SetToolTipText( _T("Show default Z + 4 Position Hole") );
	m_btnZPlus4.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZPlus4.SetBtnCursor(IDC_HAND_1);

	m_btnZPlus5.SetFont( &m_fntBtn );
	m_btnZPlus5.SetFlat( FALSE );
	m_btnZPlus5.EnableBallonToolTip();
	m_btnZPlus5.SetToolTipText( _T("Show default Z + 5 Position Hole") );
	m_btnZPlus5.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZPlus5.SetBtnCursor(IDC_HAND_1);

	m_btnLeftTop.SetFlat( FALSE );
	m_btnLeftTop.EnableBallonToolTip();
	m_btnLeftTop.SetToolTipText( _T("Show Left-Top Scanner Position Hole") );
	m_btnLeftTop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLeftTop.SetBtnCursor(IDC_HAND_1);
	
	m_btnRightTop.SetFlat( FALSE );
	m_btnRightTop.EnableBallonToolTip();
	m_btnRightTop.SetToolTipText( _T("Show Right-Top Scanner Position Hole") );
	m_btnRightTop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRightTop.SetBtnCursor(IDC_HAND_1);
	
	m_btnCenter.SetFlat( FALSE );
	m_btnCenter.EnableBallonToolTip();
	m_btnCenter.SetToolTipText( _T("Show Center Scanner Position Hole") );
	m_btnCenter.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCenter.SetBtnCursor(IDC_HAND_1);
	m_btnCenter.SetSelection( TRUE );
	
	m_btnLeftBottom.SetFlat( FALSE );
	m_btnLeftBottom.EnableBallonToolTip();
	m_btnLeftBottom.SetToolTipText( _T("Show Left-Bottom Scanner Position Hole") );
	m_btnLeftBottom.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLeftBottom.SetBtnCursor(IDC_HAND_1);
	
	m_btnRightBottom.SetFlat( FALSE );
	m_btnRightBottom.EnableBallonToolTip();
	m_btnRightBottom.SetToolTipText( _T("Show Right-Bottom Scanner Position Hole") );
	m_btnRightBottom.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRightBottom.SetBtnCursor(IDC_HAND_1);

	m_btnShotEdit.SetFont( &m_fntBtn );
	m_btnShotEdit.SetImageOrg( 10, 3 );
	m_btnShotEdit.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_btnShotEdit.EnableBallonToolTip();
	m_btnShotEdit.SetToolTipText( _T("Shot Edit Button") );
	m_btnShotEdit.SetBtnCursor(IDC_HAND_1);
	m_btnShotEdit.EnableWindow(TRUE);
	
	GetDlgItem(IDC_RADIO_REMOTE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_MANUAL)->SetFont( &m_fntBtn );
	m_nRemote = 0;
}

void CPaneManualControlOneHole::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	m_fntEdit2.CreatePointFont(100, "Arial Bold");

	m_edtBurstCount.SetFont( &m_fntEdit );
	m_edtBurstCount.SetReceivedFlag( 1 );
	m_edtBurstCount.SetWindowText( _T("0") );

	m_edtShotCount.SetFont( &m_fntEdit );
	m_edtShotCount.SetReceivedFlag( 1 );
	m_edtShotCount.SetWindowText( _T("1") );

	m_edtThickness.SetFont( &m_fntEdit );
	m_edtThickness.SetReceivedFlag( 3 );
	m_edtThickness.SetWindowText( _T("0.3") );

	m_edtScannerPosX.SetFont( &m_fntEdit );
	m_edtScannerPosX.SetReceivedFlag( 1 );
	m_edtScannerPosX.SetWindowText( _T("32768") );

	m_edtScannerPosY.SetFont( &m_fntEdit );
	m_edtScannerPosY.SetReceivedFlag( 1 );
	m_edtScannerPosY.SetWindowText( _T("32768") );

	m_edtGridX.SetFont( &m_fntEdit );
	m_edtGridX.SetReceivedFlag( 1 );
	m_edtGridX.SetWindowText( _T("1") );

	m_edtGridY.SetFont( &m_fntEdit );
	m_edtGridY.SetReceivedFlag( 1 );
	m_edtGridY.SetWindowText( _T("1") );

	m_edtFieldSize.SetFont( &m_fntEdit );
	m_edtFieldSize.SetReceivedFlag( 1 );
	m_edtFieldSize.SetWindowText( _T("50") );

	m_edtHeadOffsetX.SetFont( &m_fntEdit );
	m_edtHeadOffsetX.SetReceivedFlag( 3 );
	m_edtHeadOffsetX.SetWindowText( _T("0.0") );

	m_edtHeadOffsetY.SetFont( &m_fntEdit );
	m_edtHeadOffsetY.SetReceivedFlag( 3 );
	m_edtHeadOffsetY.SetWindowText( _T("0.0") );

	// Aperture File Path
	m_edtAperturePath.SetFont( &m_fntEdit2 );
	m_edtAperturePath.SetForeColor( BLACK_COLOR );
	m_edtAperturePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtAperturePath.SetWindowText( _T("") );
	m_edtAperturePath.EnableWindow( FALSE );

	m_fntEdit3.CreatePointFont(120, "Arial Bold");

	// Job File Path
	m_edtPath.SetFont( &m_fntEdit3 );
	m_edtPath.SetForeColor( BLACK_COLOR );
	m_edtPath.SetBackColor( WHITE_COLOR );
	m_edtPath.SetWindowText( (LPCTSTR)m_strPath );

	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );
	
	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );
	
	// Target M
	m_edtTargetM1.SetFont( &m_fntEdit );
	m_edtTargetM1.SetReceivedFlag( 3 );
	m_edtTargetM1.SetWindowText( _T("0.0") );

	// Target M2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );
	
	// Target M3
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );
	
	// Target B
	m_edtTargetB1.SetFont( &m_fntEdit );
	m_edtTargetB1.SetReceivedFlag( 3 );
	m_edtTargetB1.SetWindowText( _T("0.0") );
	
	// Target B2
	m_edtTargetB2.SetFont( &m_fntEdit );
	m_edtTargetB2.SetReceivedFlag( 3 );
	m_edtTargetB2.SetWindowText( _T("0.0") );
	
	// Target A
	m_edtTargetA1.SetFont( &m_fntEdit );
	m_edtTargetA1.SetReceivedFlag( 3 );
	m_edtTargetA1.SetWindowText( _T("0.0") );

	// Target A2
	m_edtTargetA2.SetFont( &m_fntEdit );
	m_edtTargetA2.SetReceivedFlag( 3 );
	m_edtTargetA2.SetWindowText( _T("0.0") );

	// Z Gap
	m_edtZGap.SetFont( &m_fntEdit );
	m_edtZGap.SetReceivedFlag( 3 );
	m_edtZGap.SetWindowText( _T("0.01") );

	//Freq
	m_edtFreq.SetFont( &m_fntEdit );
	m_edtFreq.SetReceivedFlag( 1 );
	m_edtFreq.SetWindowText( _T("1") );
	
	//Duty
	m_edtDuty.SetFont( &m_fntEdit );
	m_edtDuty.SetReceivedFlag( 3 );
	m_edtDuty.SetWindowText( _T("40.0") );
	
	//Aom Delay
	m_edtAOMDelay.SetFont( &m_fntEdit );
	m_edtAOMDelay.SetReceivedFlag( 3 );
	m_edtAOMDelay.SetWindowText( _T("20.0") );
	
	//Aom Duty
	m_edtAOMDuty.SetFont( &m_fntEdit );
	m_edtAOMDuty.SetReceivedFlag( 3 );
	m_edtAOMDuty.SetWindowText( _T("20.0") );

	//Voltage1
	m_edtVoltage1.SetFont( &m_fntEdit );
	m_edtVoltage1.SetReceivedFlag( 3 );
	m_edtVoltage1.SetWindowText( _T("90.0") );
	
	//Voltage2
	m_edtVoltage2.SetFont( &m_fntEdit );
	m_edtVoltage2.SetReceivedFlag( 3 );
	m_edtVoltage2.SetWindowText( _T("90.0") );

	m_edtXPos.SetFont( &m_fntEdit );
	m_edtXPos.SetReceivedFlag( 3 );
	m_edtXPos.SetWindowText( _T("100.0") );

	m_edtYPos.SetFont( &m_fntEdit );
	m_edtYPos.SetReceivedFlag( 3 );
	m_edtYPos.SetWindowText( _T("100.0") );

	m_edtGridGapX.SetFont( &m_fntEdit );
	m_edtGridGapX.SetReceivedFlag( 3 );
	m_edtGridGapX.SetWindowText( _T("200.0") );

	m_edtGridGapY.SetFont( &m_fntEdit );
	m_edtGridGapY.SetReceivedFlag( 3 );
	m_edtGridGapY.SetWindowText( _T("300.0") );

	m_edtGridXNo.SetFont( &m_fntEdit );
	m_edtGridXNo.SetReceivedFlag( 3 );
	m_edtGridXNo.SetWindowText( _T("3") );

	m_edtGridYNo.SetFont( &m_fntEdit );
	m_edtGridYNo.SetReceivedFlag( 3 );
	m_edtGridYNo.SetWindowText( _T("3") );


#ifdef __PUSAN_LDD__
	m_edtTargetB1.ShowWindow(SW_HIDE);
#endif
}

void CPaneManualControlOneHole::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbCam.SetFont( &m_fntCombo );

	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbCam.ResetContent();
		m_cmbCam.AddString("Vision");
		m_cmbCam.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbCam.ResetContent();
		m_cmbCam.AddString("High Vision");
		m_cmbCam.AddString("Low Vision");
		break;
	}

	m_cmbCam.SetCurSel( 0 );

	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbMask.SetCurSel( 1 );

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );
}

void CPaneManualControlOneHole::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(110, "Arial Bold");

	m_lboxResult.SetFont( &m_fntListBox );
}

void CPaneManualControlOneHole::OnButtonStop() 
{
	m_bStop = TRUE;

	if(m_pOneHole)
	{
		WaitForSingleObject(m_pOneHole, INFINITE);
		m_pOneHole = NULL;
	}

	gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);
	
	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			ErrMessage(_T("Dust Suction Shutter Off Error."));
			return;
		}
	}
}

void CPaneManualControlOneHole::OnButtonFire() 
{
	m_bHeadOffsetMode = FALSE;
	m_bVariousZ = FALSE;
	m_nPattern = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	m_bStop = FALSE;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(m_bVariousZ == 0 && m_nPattern == 1)
	{
		if(m_HolePatternList.GetCount() == 0)
		{
			ErrMessage(_T("Pattern File Loading Please"));
			return;
		}
	}

	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			ErrMsgDlg(STDGNALM607);
			return;
		}
	}
	
	EnableAllButton(FALSE);
	EndProcess(FALSE);

	if (!UpdateData(TRUE))
	{
		EnableAllButton(TRUE);
		EndProcess();
		return;
	}
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);

	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		ErrMessage(_T("Dust Suction Shutter On Error."));
		EnableAllButton(TRUE);
		return;
	}
#endif

	CString strVal;
	m_edtFieldSize.GetWindowText(strVal);
	m_dHalfField = atof(strVal) / 2.;
	gDProject.ScannerWarmingStop();
	m_pOneHole = ::AfxBeginThread(OneHoleThread, this, THREAD_PRIORITY_NORMAL);
}


void CPaneManualControlOneHole::OnButtonPulseWidth() 
{
/*	int nShotCount = 0;

	nShotCount = GetDlgItemInt( IDC_EDIT_SHOT_COUNT );

	if( nShotCount <= 0 || nShotCount > 15)
	{
		ErrMessage(IDS_SHOT_COUNT_INPUT_ERR, MB_ICONERROR);
		return;
	}

	CDlgLaserBeamHoleSet dlg;
	dlg.SetFireHole( nShotCount, m_dHoleSet );
	if(dlg.DoModal() != IDCANCEL)
		nShotCount = dlg.GetFireHole(m_dHoleSet);
	
	CString strVal;
	strVal.Format(_T("%d"), nShotCount);
	m_edtShotCount.SetWindowText(strVal);
*/	
}

void CPaneManualControlOneHole::OnButtonMeasure() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	CDlgMeasuringPCBThickness dlg;
	int nCam = m_cmbCam.GetCurSel();

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		ErrMessage(IDS_NO_HEIGHTSENSOR1);
		return;
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2 &&
		nCam >= 2)
	{
		ErrMessage(IDS_NO_HEIGHTSENSOR2);
		return;
	}
	
	dlg.SetBaseZ( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
		gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	if(nCam < 2 || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		dlg.AutoSelectHead(1);
		dlg.SelectHead(1);
	}
	else
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		dlg.AutoSelectHead(2);
		dlg.SelectHead(2);
	}
	dlg.ChangeHeadSelectStatus(FALSE);

	if(dlg.DoModal() == IDOK)
	{
		double dThickness;

		if(nCam < 2 || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
			dThickness = dlg.GetHeight();
		else
			dThickness = dlg.GetHeight(FALSE);

		CString strData;
		strData.Format(_T("%.3f"), dThickness);
		m_edtThickness.SetWindowText( (LPCTSTR)strData );
	}
	
}

void CPaneManualControlOneHole::OnCheckLineFire()
{
	UpdateData(TRUE);
	m_bLineFire = m_chkLineFire.GetCheck();

	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(m_bLineFire);
}

void CPaneManualControlOneHole::OnButtonApertureOpen()
{
	TCHAR BASED_CODE szFilter[] = _T("APL File (*.apl)|*.apl|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.apl"), NULL, dwFlags, szFilter);
	
	if(IDOK != dlg.DoModal())
		return;
	
	CString strPath;
	strPath.Format(_T("%s"), dlg.GetPathName());
	m_edtAperturePath.SetWindowText( (LPCTSTR)strPath );
}

void CPaneManualControlOneHole::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntEdit3.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntListBox.DeleteObject();
	
	CFormView::OnDestroy();
}

HBRUSH CPaneManualControlOneHole::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( nCtlColor == CTLCOLOR_STATIC )
	{
		if( GetDlgItem(IDC_STATIC_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_SCANNER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_LEN)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PARAM)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_VIEW_POINT)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_JOB_FILE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_USE_PATTERN)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlOneHole::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(ONE_HOLE_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(ONE_HOLE_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(ONE_HOLE_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	
	}


	OnCamChange(m_nCamNo);
	m_bIsLive = TRUE;
	OnLive( m_nCamNo, m_bIsLive );
}

void CPaneManualControlOneHole::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

void CPaneManualControlOneHole::OnMoveVisionView()
{
	CRect rtPos;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_ONE_HOLE_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneManualControlOneHole::OnLive(int nCamNo, BOOL bOnOff)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive( nCamNo, bOnOff );
}

void CPaneManualControlOneHole::OnSelchangeComboCam() 
{
	int nSel = m_cmbCam.GetCurSel();

	if( nSel == m_nCamNo )
		return;

	m_bIsLive = FALSE;
	OnLive( m_nCamNo, m_bIsLive );

	m_nCamNo = nSel;
	OnCamChange( m_nCamNo );

	CString strCoaxial, strRing;
	gDeviceFactory.GetVision()->GetLampValue(m_nCamNo, strCoaxial, strRing );
	m_edtCoaxial.SetWindowText(strCoaxial);
	m_edtRing.SetWindowText(strRing);

	m_bIsLive = TRUE;
	OnLive( m_nCamNo, m_bIsLive );
	::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ONEHOLE,m_nCamNo);
}

void CPaneManualControlOneHole::OnTimer(UINT nIDEvent) 
{
#ifdef __PUSAN_LDD__
	if( m_bIsLive )
	{
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnAcquire(m_nCamNo);
	}
#endif

	double dPosX = gDeviceFactory.GetMotor()->GetPosition(AXIS_X);
	double dPosY = gDeviceFactory.GetMotor()->GetPosition(AXIS_Y);
	
	CString strVal;
	strVal.Format(_T("%.3f "), dPosX - m_dBaseX);
	m_stcPosX.SetWindowText((LPCTSTR)strVal);
	strVal.Format(_T("%.3f "), dPosY - m_dBaseY);
	m_stcPosY.SetWindowText((LPCTSTR)strVal);

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlOneHole::ResetLive()
{
	m_bIsLive = FALSE;
	OnLive( m_nCamNo, m_bIsLive );
}

void CPaneManualControlOneHole::OnButtonBurst()
{
	UpdateData(TRUE);
	 
	if(m_nFireType == 2)
		m_edtBurstCount.EnableWindow(TRUE);
	else
		m_edtBurstCount.EnableWindow(FALSE);
}

void CPaneManualControlOneHole::OnStartPosX() 
{
	m_dBaseX = gDeviceFactory.GetMotor()->GetPosition(AXIS_X);
}

void CPaneManualControlOneHole::OnStartPosY() 
{
	m_dBaseY = gDeviceFactory.GetMotor()->GetPosition(AXIS_Y);
}

void CPaneManualControlOneHole::EndProcess(BOOL bEnable)
{
	ShutterMove(FALSE, FALSE); // 20090629 Front Mode error
	gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);

	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
	{
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
		{
			ErrMessage(_T("Dust Suction Shutter Off Error."));
		}
	}
	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
	#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Shot stop Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot stop Failure"));
	#endif
		}
		m_StandbyTime.Finish();
	}
#ifdef __3RDAOD__
	if(bEnable)
	{
		if(gProcessINI.m_sProcessScannerCal.bUseDummy && gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_FIELD)
		{
			if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					ErrMsgDlg(STDGNALM781);
				}
			}
		}
	}
#endif
	gDProject.ScannerWarmingStart();
}
void CPaneManualControlOneHole::EnableAllButton(BOOL bEnable)
{
	GetDlgItem(IDC_RADIO_BURST)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_CYCLE)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_STEP)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_BURST_COUNT)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SHOT_COUNT)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_PULSE_WIDTH)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_MASK)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_THICKNESS)->EnableWindow(bEnable);
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 0)
		GetDlgItem(IDC_BUTTON_MEASURE)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CAM)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_SIZE_X_VAL)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_SIZE_Y_VAL)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_FIELD_SIZE)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SCANNER_POS_X)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SCANNER_POS_Y)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SET_CUR_POS_ZERO_X)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SET_CUR_POS_ZERO_Y)->EnableWindow(bEnable);

	GetDlgItem(IDC_BUTTON_FIRE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_PATTERN)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_USE_DEFAULT)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_USE_PATTERN)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(!bEnable);

	GetDlgItem(IDC_CHECK_SUB_LINE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDIT_JOB_FILE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN3)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_TOOL2)->EnableWindow(bEnable);

	//various Z
	GetDlgItem(IDC_EDIT_GAP)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_VFIRE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_APPLY_Z)->EnableWindow(bEnable);

	GetDlgItem(IDC_BUTTON_VISION_TEST)->EnableWindow(bEnable);
	if(m_nUserLevel == 2 || m_nUserLevel == 3)
	{
		GetDlgItem(IDC_EDIT_TARGET_Z1)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_M1)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_M2)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_B1)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_B2)->EnableWindow(bEnable);
//		GetDlgItem(IDC_EDIT_TARGET_A1)->EnableWindow(bEnable);
//		GetDlgItem(IDC_EDIT_TARGET_A2)->EnableWindow(bEnable);  //2012 bskim 
		GetDlgItem(IDC_CHECK_TOPHAT)->EnableWindow(bEnable);
		GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_VOLTAGE1)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_TARGET_VOLTAGE2)->EnableWindow(bEnable);
	}
	else
	{
		GetDlgItem(IDC_EDIT_TARGET_Z1)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M1)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_B1)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_B2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_A1)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_A2)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TOPHAT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_VOLTAGE1)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_VOLTAGE2)->EnableWindow(FALSE);
	}

	GetDlgItem(IDC_BUTTON_HEAD_OFFSET)->EnableWindow(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}

void CPaneManualControlOneHole::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}

BOOL CPaneManualControlOneHole::MoveZ1VisionFocus(BOOL bLarge)
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __MP920_MOTOR__
	HMotor* pMotor = gDeviceFactory.GetMotor();
#else
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dZ1VisionFocus, dVisionHeight;

	if(bLarge)
		dVisionHeight = gSystemINI.m_sSystemDevice.d1stHighHeight;
	else
		dVisionHeight = gSystemINI.m_sSystemDevice.d1stLowHeight;

	CString strVal;
	m_edtThickness.GetWindowText(strVal);

	dZ1VisionFocus = dVisionHeight - atof(strVal);

	if (!pMotor->MoveZ(dZ1VisionFocus))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	if (TRUE != pMotor->InPositionIO(IND_Z1))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	return TRUE;
#endif
}

BOOL CPaneManualControlOneHole::MoveZ1LaserFocus()
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __MP920_MOTOR__
	HMotor* pMotor = gDeviceFactory.GetMotor();
#else
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dZ1LaserFocus, dLaserHeight;
	int nMask = m_cmbMask.GetCurSel();

	SUBTOOLDATA ToolData;
	POSITION pos;
	pos = gVariable.m_pToolCode[0]->m_SubToolData.GetHeadPosition();
	int nFind = 0;
	while (pos) 
	{
		ToolData = gVariable.m_pToolCode[0]->m_SubToolData.GetNext(pos);
		nFind++;
	}
	
	if(nFind > 0)
	{
		if(ToolData.bUseTophat)
			dLaserHeight = gSystemINI.m_sSystemDevice.d1stLaserHeightTophat[nMask];
		else
			dLaserHeight = gSystemINI.m_sSystemDevice.d1stLaserHeight[nMask];
	}
	else
		dLaserHeight = gSystemINI.m_sSystemDevice.d1stLaserHeight[nMask];

	CString strVal;
	m_edtThickness.GetWindowText(strVal);
	dZ1LaserFocus = dLaserHeight - atof(strVal);

	if (!pMotor->MotorMoveAxis(AXIS_Z1, dZ1LaserFocus))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	if (TRUE != pMotor->InPositionIO(IND_Z1))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	return TRUE;
#endif
}

BOOL CPaneManualControlOneHole::MoveZ2VisionFocus(BOOL bLarge)
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __MP920_MOTOR__
	HMotor* pMotor = gDeviceFactory.GetMotor();
#else
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dZ2VisionFocus, dVisionHeight;
	
	if(bLarge)
		dVisionHeight = gSystemINI.m_sSystemDevice.d2ndHighHeight;
	else
		dVisionHeight = gSystemINI.m_sSystemDevice.d2ndLowHeight;

	CString strVal;
	m_edtThickness.GetWindowText(strVal);

	dZ2VisionFocus = dVisionHeight - atof(strVal);
	
	if (!pMotor->MotorMoveAxis(AXIS_Z2, dZ2VisionFocus, TRUE))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	if (TRUE != pMotor->InPositionIO(IND_Z2))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	return TRUE;
#endif
}

BOOL CPaneManualControlOneHole::MoveZ2LaserFocus()
{
#ifdef __TEST__
	return TRUE;
#else
#ifdef __MP920_MOTOR__
	HMotor* pMotor = gDeviceFactory.GetMotor();
#else
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dZ2LaserFocus, dLaserHeight;
	int nMask = m_cmbMask.GetCurSel();

	SUBTOOLDATA ToolData;
	POSITION pos;
	pos = gVariable.m_pToolCode[0]->m_SubToolData.GetHeadPosition();
	int nFind = 0;
	while (pos) 
	{
		ToolData = gVariable.m_pToolCode[0]->m_SubToolData.GetNext(pos);
		nFind++;
	}

	if(nFind > 0)
	{
		if(ToolData.bUseTophat)
			dLaserHeight = gSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[nMask];
		else
			dLaserHeight = gSystemINI.m_sSystemDevice.d2ndLaserHeight[nMask];
	}
	else
		dLaserHeight = gSystemINI.m_sSystemDevice.d2ndLaserHeight[nMask];

	CString strVal;
	m_edtThickness.GetWindowText(strVal);
	dZ2LaserFocus = dLaserHeight - atof(strVal);

	if (!pMotor->MotorMoveAxis(AXIS_Z2, dZ2LaserFocus, TRUE))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	if (TRUE != pMotor->InPositionIO(IND_Z2))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	return TRUE;
#endif
}

BOOL CPaneManualControlOneHole::MarkingGrid(int nGridX, int nGridY, int nMoveX, int nMoveY, int nGridSize, int nHead)
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	int nMaxLSB = (int)(MAXLSB * nGridSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;
	int nX, nY;

	if(nGridX == 1)
		nStepX = nMaxLSB;
	else
		nStepX = nMaxLSB / (nGridX - 1);

	if(nGridY == 1)
		nStepY = nMaxLSB;
	else
		nStepY = nMaxLSB / (nGridY - 1);

	nStartLSBX = (int)(nMoveX - (nGridX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(nMoveY - (nGridY/2.0 - 0.5)*nStepY);

	if(nGridX < 2 || nGridY < 2)
		return TRUE;

	for(int i = 0; i < nGridX; i++)
	{
		if(m_bStop)
			return FALSE;

		nX = nStartLSBX + i * nStepX;
		if(nX > MAXLSB) nX = MAXLSB;
		if(nX < 0)		nX = 0;
				
		nY = nStartLSBY;
		if(nY > MAXLSB) nY = MAXLSB;
		if(nY < 0)		nY = 0;

		if(nHead == 0) // Master
			pEoCard->jumpOne(nX, nY, TRUE);
		else
			pEoCard->jumpOne(nX, nY, FALSE);

		nY = nStartLSBY + (nGridY - 1) * nStepY;
		if(nY > MAXLSB) nY = MAXLSB;
		if(nY < 0)		nY = 0;

		if(nHead == 0) // Master
			pEoCard->markOne(nX, nY, TRUE);
		else
			pEoCard->markOne(nX, nY, FALSE);
	}

	for(int i = 0; i < nGridY; i++)
	{
		if(m_bStop)
			return FALSE;

		nX = nStartLSBX;
		if(nX > MAXLSB) nX = MAXLSB;
		if(nX < 0)		nX = 0;
				
		nY = nStartLSBY + i * nStepY;
		if(nY > MAXLSB) nY = MAXLSB;
		if(nY < 0)		nY = 0;
				
		if(nHead == 0) // Master
			pEoCard->jumpOne(nX, nY, TRUE);
		else
			pEoCard->jumpOne(nX, nY, FALSE);
				
		nX = nStartLSBX + (nGridX - 1) * nStepX;
		if(nX > MAXLSB) nX = MAXLSB;
		if(nX < 0)		nX = 0;
				
		if(nHead == 0) // Master
			pEoCard->markOne(nX, nY, TRUE);
		else
			pEoCard->markOne(nX, nY, FALSE);
	}

	if(m_bStop)
		return FALSE;
			
	WaitOneFireProcess();
	return TRUE;
}

BOOL CPaneManualControlOneHole::DrillGrid(int nGridX, int nGridY, int nMoveX, int nMoveY, int nGridSize, int nHead, int nScannerIndex)
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	int nMaxLSB = (int)(MAXLSB * nGridSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;
	int nX, nY;
	LPHOLEDATA pHoleData;

	if(nGridX == 1)
		nStepX = nMaxLSB;
	else
		nStepX = nMaxLSB / (nGridX - 1);

	if(nGridY == 1)
		nStepY = nMaxLSB;
	else
		nStepY = nMaxLSB / (nGridY - 1);

	nStartLSBX = (int)(nMoveX - (nGridX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(nMoveY - (nGridY/2.0 - 0.5)*nStepY);

	pEoCard->ShotDataReset();

	CString strFile = _T("OneHoleDownload1");
	CString strData = _T("");
	if(m_bVariousZ)
	{	
		if(nHead == 0) // Master
		{
			switch(nScannerIndex)
			{
			case 0 : pEoCard->DownloadShotData2(HALF_LSB - nStepX, HALF_LSB + nStepY, HALF_LSB,	HALF_LSB, TRUE, FALSE, ONE_HOLE_TOOL); break;
			case 1 : pEoCard->DownloadShotData2(HALF_LSB + nStepX, HALF_LSB + nStepY, HALF_LSB,	HALF_LSB, TRUE, FALSE, ONE_HOLE_TOOL); break;
			case 2 : pEoCard->DownloadShotData2(HALF_LSB		 , HALF_LSB			, HALF_LSB,	HALF_LSB, TRUE, FALSE, ONE_HOLE_TOOL); break;
			case 3 : pEoCard->DownloadShotData2(HALF_LSB - nStepX, HALF_LSB - nStepY, HALF_LSB,	HALF_LSB, TRUE, FALSE, ONE_HOLE_TOOL); break;
			case 4 : pEoCard->DownloadShotData2(HALF_LSB + nStepX, HALF_LSB - nStepY, HALF_LSB,	HALF_LSB, TRUE, FALSE, ONE_HOLE_TOOL); break;
			}
		}
		else if(nHead == 1) // Slave
		{
			switch(nScannerIndex)
			{
			case 0 : pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, HALF_LSB - nStepX, HALF_LSB + nStepY, FALSE, TRUE, ONE_HOLE_TOOL); break;
			case 1 : pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, HALF_LSB + nStepX, HALF_LSB + nStepY, FALSE, TRUE, ONE_HOLE_TOOL); break;
			case 2 : pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, HALF_LSB		 , HALF_LSB			, FALSE, TRUE, ONE_HOLE_TOOL); break;
			case 3 : pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, HALF_LSB - nStepX, HALF_LSB - nStepY, FALSE, TRUE, ONE_HOLE_TOOL); break;
			case 4 : pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, HALF_LSB + nStepX, HALF_LSB - nStepY, FALSE, TRUE, ONE_HOLE_TOOL); break;
			}
		}
		nGridX = 1; nGridY = 1;
	}
	else
	{
		if( m_nPattern == 0 || m_nPattern == 2)
		{
			for(int i = 0; i < nGridX; i++)
			{
				if(m_bStop)
					return FALSE;

				for(int j = 0; j < nGridY; j++)
				{
					if(m_bStop)
						return FALSE;
						
					nX = nStartLSBX + i * nStepX;
					if(nX > MAXLSB) nX = MAXLSB;
					if(nX < 0)		nX = 0;
					nY = nStartLSBY + j * nStepY;
					if(nY > MAXLSB) nY = MAXLSB;
					if(nY < 0)		nY = 0;

					strData.Format(_T("%d , %d"), nX, nY);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strData));
					if(nHead == 0) // Master
					{
						pEoCard->DownloadShotData2(nX, nY, HALF_LSB, HALF_LSB, TRUE, FALSE,	ONE_HOLE_TOOL);
					}
					else if(nHead == 1) // Slave
					{
						pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, nX, nY, FALSE, TRUE, ONE_HOLE_TOOL);
					}
				}
			}
		}
		else if( m_nPattern == 1)
		{
			POSITION pos = m_HolePatternList.GetHeadPosition();
			while(pos)
			{
				pHoleData = m_HolePatternList.GetNext(pos);
				nX = XUMtoLSB(pHoleData->npPos.x);
				if(nX > MAXLSB) nX = MAXLSB;
				if(nX < 0)		nX = 0;
				nY = YUMtoLSB(pHoleData->npPos.y);
				if(nY > MAXLSB) nY = MAXLSB;
				if(nY < 0)		nY = 0;

				if(nHead == 0) // Master
				{
					pEoCard->DownloadShotData2(nX, nY, HALF_LSB, HALF_LSB, TRUE, FALSE,	ONE_HOLE_TOOL);
				}
				else if(nHead == 1) // Slave
				{
					pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, nX, nY, FALSE, TRUE, ONE_HOLE_TOOL);
				}
			}
		}
	}

	if(m_bStop)
		return FALSE;

	//20111107
	#ifndef __KUNSAN_8__
		if(!gSystemINI.m_sHardWare.nUseFirstOrder)
		{
			double dStandbyTime;
			while(TRUE)
			{
				MessageLoop();
						
				if(m_bStop)
					return FALSE;
						
				dStandbyTime = m_StandbyTime.PresentTime();
				if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
					if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
						break;
				else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
					if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime2)
						break;
			}
		}
	#endif

	int nDummyShot;
	nDummyShot = gSystemINI.m_sSystemDump.nDummyShot;
	#ifdef __KUNSAN_8__
		if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
			nDummyShot = gSystemINI.m_sSystemDump.nDummyShot2;
		if(nDummyShot > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!pEoCard->DummyParamSet(gDProject.m_nDummyFreeType))
			{
				CString strFile, strLog;
				strFile.Format(_T("ReadHole"));
				strLog.Format(_T("Dump Parameter Set Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				ErrMessage(_T("Error : Dummy shot parameter download Failure"));
			}
		}
	#endif

	pEoCard->FieldPreStart(nDummyShot);

	if(nDummyShot > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		pEoCard->DummyFieldStart(nDummyShot, FALSE);
		pEoCard->DummyStopAndDataShotStart(FALSE);
	}
	else
	{
		pEoCard->FieldStart(FALSE);
	}
			
	::Sleep(100);
			
	WaitOneFireProcess();

	int nEocardHoleCount = pEoCard->ReadHoleCount();
	
	if(m_nPattern == 0 || m_bVariousZ || m_nPattern == 2 )
	{
		if( nEocardHoleCount != nGridX * nGridY)
		{
	#ifndef __TEST__
			CString str;
			str.Format(_T("MissHole. DownCount : %d, EoCard Count : %d "), nGridX * nGridY, nEocardHoleCount);
			ErrMessage(str);
	#endif
		}
		return TRUE;
	}
	else
	{
		if( nEocardHoleCount != m_HolePatternList.GetCount())
		{
			#ifndef __TEST__
			CString str;
			str.Format(_T("MissHole. DownCount : %d, EoCard Count : %d "), m_HolePatternList.GetCount(), nEocardHoleCount);
			ErrMessage(str);
			#endif
		}
		return TRUE;
	}
}

BOOL CPaneManualControlOneHole::LaserFire(int nZIndex, int nScannerIndex)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEoCard = gDeviceFactory.GetEocard();

	CString strVal;

	int nCam = m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;
	
	m_edtGridX.GetWindowText(strVal);
	int nGridX = atoi(strVal);
	
	m_edtGridY.GetWindowText(strVal);
	int nGridY = atoi(strVal);

	if(nGridX < 1 || nGridY < 1)
	{
		ErrMessage(_T("Grid No Error : No >= 1"));
		return FALSE;
	}
	
	m_edtScannerPosX.GetWindowText(strVal);
	int nMoveX = atoi(strVal);
	m_edtScannerPosY.GetWindowText(strVal);
	int nMoveY = atoi(strVal);
	
	// grid size ����
	m_edtFieldSize.GetWindowText(strVal);
	int nGridSize = atoi(strVal);
	int nMaxLSB = (int)(MAXLSB * nGridSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;

	if(m_bVariousZ)
	{
		nGridX = 3; nGridY = 3;
	}
	if(nGridX == 1)
		nStepX = nMaxLSB;
	else
		nStepX = nMaxLSB / (nGridX - 1);

	if(nGridY == 1)
		nStepY = nMaxLSB;
	else
		nStepY = nMaxLSB / (nGridY - 1);

	nStartLSBX = (int)(nMoveX - (nGridX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(nMoveY - (nGridY/2.0 - 0.5)*nStepY);

	SUBTOOLDATA ToolData;
	POSITION pos;
	pos = gVariable.m_pToolCode[0]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		if(m_bStop)
			return FALSE;

		ToolData = gVariable.m_pToolCode[0]->m_SubToolData.GetNext(pos);
		if(!ChangeOneSubTool(ToolData, nZIndex))
			return FALSE;

		pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);
		
		if(ToolData.nToolType == MARKING_TYPE)
		{
			if(!MarkingGrid(nGridX, nGridY, nMoveX, nMoveY, nGridSize, nHead))
				return FALSE;
		}
		else
		{
			if(!DrillGrid(nGridX, nGridY, nMoveX, nMoveY, nGridSize, nHead, nScannerIndex))
				return FALSE;
		}
	}

	if(m_bStop)
		return FALSE;

	return TRUE;
}

void CPaneManualControlOneHole::WaitOneFireProcess()
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	if(pEoCard == NULL)
		return;
	
	BOOL bIsDSPBusy = FALSE;
	
	do
	{
		if(pEoCard->IsDrillTimeOut())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM566);
			return;
		}
		if(pEoCard->IsMotorFault())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM567);
			return;
		}
		if(m_bStop)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
		}
		bIsDSPBusy = pEoCard->IsDSPBusy();
		MessageLoop();
#ifdef __TEST__
		bIsDSPBusy = FALSE;
#endif
	} while(bIsDSPBusy && !m_bStop);
}

void CPaneManualControlOneHole::SetvisionParam(SVISIONINFO sVisionParam) 
{
	for(int i=0; i<4; i++)
	{
//		sVisionInfo.nCoaxial[i] = sVisionParam.nCoaxial[i];
//		sVisionInfo.nRing[i] = sVisionParam.nRing[i];
	}
}
BOOL CPaneManualControlOneHole::FindOneHole(int nCamNo) 
{
	BOOL bResult;
	CString strMsg;
	TCHAR szToken[512] = {0,};
	TCHAR szTemp[512] = {0,};
	int nCnt=0, nCnt2 =0;


//	VISION_INFO sVisionInfo;
	
	// Model Type
	sVisionInfo.nModelType = MODEL_CIRCLE;
	// Polarity
	sVisionInfo.nPolarity = gBeamPathINI.m_sBeampath.nScannerPolarity[m_nBeamPath];
	// Size A, B, C, Orientation
	sVisionInfo.dSizeA	= gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeB	= gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
	sVisionInfo.dSizeC	= gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nBeamPath];
		
	// Accept Score
	sVisionInfo.dScoreSize	= gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nBeamPath];
	sVisionInfo.dScoreAngle	= 0;
	sVisionInfo.dAspectRatio	= gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nBeamPath];
	sVisionInfo.nThreshold = 0;//pFidData->sVisInfo.nThreshold;
	
	for(int i=0; i<4; i++)
	{

// 		sVisionInfo.nCoaxial[i] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nBeamPath];
// 		sVisionInfo.nRing[i] = gBeamPathINI.m_sBeampath.nScannerRing[m_nBeamPath];
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nBeamPath];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nBeamPath];
	}

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
	pVision->SetShapeType(MODEL_CIRCLE);
	pVision->OnApplyVisionParameter( sVisionInfo.nModelType, nCamNo, sVisionInfo );
	bResult = pVision->OnFindFiducial( nCamNo, MODEL_CIRCLE, strMsg , FALSE, 1);
	if(bResult)
	{
#ifdef USE_VISION_PRO
		m_dFoundOffset[nCamNo].x = gProcess.m_ResultData[nCamNo].dx;
		m_dFoundOffset[nCamNo].y = gProcess.m_ResultData[nCamNo].dy;
#endif
	}
	
	m_stcVisionResult.SetWindowText( strMsg );

	//Token HeadOffset 
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;
	
	CString strData;
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		switch( nCamNo )
		{
		case HIGH_1ST_CAM :
		case LOW_1ST_CAM :
			b1st = TRUE;
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
			strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
			strData.Format(_T("1st %s %s"), strPos, strMsg);
			break;
		case HIGH_2ND_CAM :
		case LOW_2ND_CAM :
			b1st = FALSE;
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
			strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
			strData.Format(_T("2nd %s %s"), strPos, strMsg);
			break;
		}
	}
	else
	{
		if(nCamNo == 0)
			b1st = TRUE;
		else
			b1st = FALSE;

		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("%s %s"), strPos, strMsg);
	}
	m_strResult = strData;
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );
	return bResult;
}

void CPaneManualControlOneHole::SetHeadOffset()
{
}

void CPaneManualControlOneHole::GetNextRetryFiducialPoint(DPOINT& ptStart, DPOINT& ptEnd, int& nDirection)
{
}

int CPaneManualControlOneHole::XUMtoLSB(double dXPos)
{
	return (int) (dXPos * 65536 / (gSystemINI.m_sSystemDevice.dFieldSize.x * 1000) + 32767);
}

int CPaneManualControlOneHole::YUMtoLSB(double dYPos)
{
	return (int) (dYPos * 65536 / (gSystemINI.m_sSystemDevice.dFieldSize.y * 1000) + 32767);
}

BOOL CPaneManualControlOneHole::ChangeOneSubTool(SUBTOOLDATA subTool, int nZIndex)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEocard = gDeviceFactory.GetEocard();
	HLaser* pLaser = gDeviceFactory.GetLaser();
	
	double dC1, dC2, dA1, dA2, dM1, dM2, dM3; 
	
	if(subTool.nToolType == FLYING_TYPE)
	{
		ErrMessage(IDS_ERR_FLYING_TOOL);
		return FALSE;
	}

	CString strVal;
	m_edtThickness.GetWindowText(strVal);
	double dThick = atof(strVal);
	CString strData;
	BOOL bTophat; 
	double dLaserHeight1, dLaserHeight2, dZGap;
	double dVoltage1, dVoltage2;
	BOOL bUseParam = m_chkUseParam.GetCheck();
	BOOL bLaserPath;
	if(m_nUserLevel < 2)
		bUseParam = FALSE;
	if(bUseParam)
	{
		bTophat = m_chkTopHat.GetCheck();
		bLaserPath = m_chkBeamPath.GetCheck();
		// target Z1
		m_edtTargetZ1.GetWindowText( strData );
		dLaserHeight1 = atof(strData);
		
		// Target Z2
		m_edtTargetZ2.GetWindowText( strData );
		dLaserHeight2 = atof(strData);
		
		//voltage1
		m_edtVoltage1.GetWindowText( strData );
		dVoltage1 = atof(strData);
		
		//voltage2
		m_edtVoltage2.GetWindowText( strData );
		dVoltage2 = atof(strData);
	}
	else
	{
		bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
		bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];
		dLaserHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask];
		dLaserHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask];
		dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask];
		dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask];
	}

	m_dBaseZ1 = dLaserHeight1;
	m_dBaseZ2 = dLaserHeight2;

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}
	
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Beam Pass move error!"));
		return FALSE;
	}


	m_edtZGap.GetWindowText( strData );
	dZGap = atof(strData);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		// Mask�� Z�� �̵�
		double dHeight1 = dLaserHeight1 - dThick + dZGap * nZIndex;
		double dHeight2 = dLaserHeight2 - dThick + dZGap * nZIndex; 

		CString strMaster, strSlave;
		if(bUseParam)
		{
			// Target M
			m_edtTargetM1.GetWindowText( strData );
			dM1 = atof(strData);
			
			// Target M2
			m_edtTargetM2.GetWindowText( strData );
			dM2 = atof(strData);

			// Target M3
			m_edtTargetM3.GetWindowText( strData );
			dM3 = atof(strData);

			// Target B
			m_edtTargetB1.GetWindowText( strData );
			dC1 = atof(strData);
			
			// Target B2
			m_edtTargetB2.GetWindowText( strData );
			dC2 = atof(strData);
			
			// Target A
			m_edtTargetA1.GetWindowText( strData );
			dA1 = atof(strData);
			
			// Target A2
			m_edtTargetA2.GetWindowText( strData );
			dA2 = atof(strData);

			strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);
			strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nBeamPath]);
		}
		else
		{
			dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
			dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
			dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask];
			dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
			dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
			dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
			dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];

			strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
		}
		
		TCHAR sz1stFile[255], sz2ndFile[255];
		lstrcpy(sz1stFile, strMaster);
		lstrcpy(sz2ndFile, strSlave);
		
		if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
			strMsg.Format(strString, _T("ASC"));
			ErrMessage(strMsg);
			CString strTemp;
			strTemp.Format(_T("Beam Path : %d %s or %s"), subTool.nMask, strMaster, strSlave);
			strMsg.Format(strString, strTemp);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return FALSE;
		}
#ifndef __SERVO_MOTOR__
		if(!pMotor->MoveZMCA2(	dHeight1 , dHeight2 ,
			dM1, dM2 ,dC1, dC2, dA1, dA2, TRUE, bTophat))
#else
		if(!pMotor->MoveZMC3(dHeight1, dHeight2, dM1, dM2, dM3, dC1, dC2, TRUE, bTophat))
#endif
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			ErrMessage(strMsg);
			return FALSE;
		}
	}
	else // not use M, C
	{
		double dHeight1 = dLaserHeight1 - dThick;
		double dHeight2 = dLaserHeight2 - dThick; 
		
		if(!pMotor->MoveZMC2(dHeight1 , dHeight2 , 
			subTool.dA1, subTool.dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
			ErrMessage(strMsg);
			return FALSE;
		}
	}
	if(bUseParam)
	{
		//Shot No.
		m_edtShotCount.GetWindowText( strData );
		subTool.nTotalShot = atoi( strData );
		
		//Duty
		m_edtDuty.GetWindowText( strData );
		subTool.dShotDuty[0] = atof( strData );

		//AOM Delay
		m_edtAOMDelay.GetWindowText( strData );
		subTool.dShotAOMDelay[0] = atof( strData );

		//AOM Duty
		m_edtAOMDuty.GetWindowText( strData );
		subTool.dShotAOMDuty[0] = atof( strData );

		for(int i = 1; i < MAX_SHOT; i++)
		{
			subTool.dShotDuty[i] = subTool.dShotDuty[0];
			subTool.dShotAOMDelay[i] = subTool.dShotAOMDelay[0];
			subTool.dShotAOMDuty[i] = subTool.dShotAOMDuty[0];
		}

		//Beam Path
		subTool.nMask = m_cmbTool.GetCurSel();
		subTool.nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subTool.nMask];
	}
	else
	{
		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];
		subTool.nTotalShot = gVariable.m_sgShotGroupTable.nTotalShotCount[nShotIndex];
	}

	subTool.nJumpDelay = (int)(gBeamPathINI.m_sBeampath.dScannerJumpDelay);
	// subTool download
	if(!gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Voltage");
		ErrMsgDlg(STDGNALM117);
		return FALSE;
	}
	if(!pEocard->DownloadOneSubTool(ONE_HOLE_TOOL, subTool))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Parameter");
		ErrMessage(strMsg);
		return FALSE;
	}
	if(!pEocard->DownloadShotDrillScannerParam())
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Move Profile Parameter");
		ErrMessage(strMsg);
		return FALSE;
	}
	// Laser Current Set
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(!pLaser->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack))
		{
			ErrMessage(_T("Current Set Error"));
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		if(!pLaser->SetCurrent(subTool.dCurrent))
		{
			ErrMessage(_T("Current Set Error"));
			return FALSE;
		}
	}
	// M, C, Z Inposition
	//Inposition check
	if(!InPositionCheck())
	{
		ErrMessage(_T("Inposition Error"));
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneManualControlOneHole::InPositionCheck()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2);
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3 + IND_A1 + IND_A2 );
	}
	else // not use M, C
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2);
		else
			return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3 + IND_A1 + IND_A2);
	}
	return TRUE;
}

BOOL CPaneManualControlOneHole::ShutterMove(BOOL bMaster, BOOL bSlave)
{
#ifdef __TEST__
	return TRUE;
#endif
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return TRUE;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BYTE nReStart = TRUE;
	if (pMotor != NULL)
	{
		// return value of GetCurrentShutter[1-2] : 1 = Open, 2 = Close, 3 = Center
		BYTE nShutter1 = pMotor->GetCurrentShutter1();
		BYTE nShutter2 = pMotor->GetCurrentShutter2();

		if (nShutter1 == 1)	
			nShutter1 = TRUE;
		else if (nShutter1 == 2)
			nShutter1 = FALSE;
		else	
			nShutter1 = 3;
		
		if (nShutter2 == 1)
			nShutter2 = TRUE;
		else if (nShutter2 == 2)
			nShutter2 = FALSE;
		else	
			nShutter2 = 3;

		if (bMaster == nShutter1 && bSlave == nShutter2)
			return TRUE;

RESHUTTER:
		int nCount = 0;
		pMotor->MotorShutterAll(bMaster, bSlave);
		::Sleep(20);

		do
		{
			nShutter1 = pMotor->GetCurrentShutter1();
			nShutter2 = pMotor->GetCurrentShutter2();

			if (nShutter1 == 1)
				nShutter1 = TRUE;
			else if (nShutter1 == 2)
				nShutter1 = FALSE;
			else
				nShutter1 = 3;
			
			if (nShutter2 == 1)
				nShutter2 = TRUE;
			else if (nShutter2 == 2)
				nShutter2 = FALSE;
			else
				nShutter2 = 3;

			if (nShutter1 == bMaster && nShutter2 == bSlave)
			{
				::Sleep(20);
				TRACE("Shutter Time : %d ms\n", nCount);
				return TRUE;
			}

			if (++nCount > 200)	//4 Sec
				break;

			::Sleep(20);
		} while (TRUE);

		nShutter1 = pMotor->GetCurrentShutter1();
		nShutter2 = pMotor->GetCurrentShutter2();

		if (nShutter1 == 1)			nShutter1 = TRUE;
		else if (nShutter1 == 2)	nShutter1 = FALSE;
		else						nShutter1 = 3;
		
		if (nShutter2 == 1)			nShutter2 = TRUE;
		else if (nShutter2 == 2)	nShutter2 = FALSE;
		else						nShutter2 = 3;

		if (nReStart == TRUE && (nShutter1 != bMaster || nShutter2 != bSlave))
		{
			nReStart = FALSE;
			goto RESHUTTER;
		}

		if (nShutter1 != bMaster)
		{
			if (bMaster)		// Open Error
			{
				ErrMsgDlg(STDGNALM413);
				return FALSE;
			}
			else					// Close Error
			{
				ErrMsgDlg(STDGNALM415);
				return FALSE;
			}
		}
		else if (nShutter2 != bSlave)
		{
			if (bSlave)		// Open Error
			{
				ErrMsgDlg(STDGNALM414);
				return FALSE;
			}
			else					// Close Error
			{
				ErrMsgDlg(STDGNALM416);
				return FALSE;
			}
		}
		else
			return FALSE;
	}
	else
		return FALSE;
	
	return TRUE;
}
//�����ϴ� �Լ��� 
BOOL CPaneManualControlOneHole::SpinMask(int nMaskNo)
{
	return TRUE;		
}

LRESULT CPaneManualControlOneHole::OnInspection(WPARAM wParam, LPARAM lParam)
{
	BOOL bResult;
	int nCam = (int)wParam;
	CString strData;
//	int nRing = gBeamPathINI.m_sBeampath.nHoleRing[m_nBeamPath];
//	int nCoaxial = gBeamPathINI.m_sBeampath.nHoleCoaxial[m_nBeamPath];
	m_edtRing.GetWindowText( strData );
	sVisionInfo.nRing[nCam] = atoi(strData);
	m_edtCoaxial.GetWindowText( strData );
	sVisionInfo.nCoaxial[nCam] = atoi(strData);
	for( int i = 0; i < 4; i++)
	{
		if(i == nCam)
			gDeviceFactory.GetVision()->OnLightAll(nCam, sVisionInfo.nCoaxial[nCam], sVisionInfo.nRing[nCam]  );
		else
			gDeviceFactory.GetVision()->OnLightAll(i, 0, 0  );
	}
	

	gDeviceFactory.GetVision()->OnLive(nCam, FALSE);

	bResult = FindOneHole(nCam);

	if(lParam)
	{
		OnCamChange( m_cmbCam.GetCurSel() );
		::Sleep(100);
		gDeviceFactory.GetVision()->OnLive(m_cmbCam.GetCurSel(), TRUE);
	}
	else
		gDeviceFactory.GetVision()->OnLive(nCam, TRUE);

	if(bResult)
		return 1U;
	return 0U;
}

void CPaneManualControlOneHole::OnButtonJobFileOpen()
{
	TCHAR BASED_CODE szFilter[] = _T("Job Files (*.Job)|*.job|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.Job"), NULL, dwFlags, szFilter);
	
	CString strPath;
	strPath.Format(_T("%s\\JobFile\\"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	dlg.m_ofn.lpstrInitialDir = strPath;
	
	if(IDOK != dlg.DoModal())
		return;
	
	m_strPath = dlg.GetPathName();
	
	m_edtPath.SetWindowText(m_strPath);
	
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->LoadProject(m_strPath);	
}
void CPaneManualControlOneHole::OnButtonHeadOffset()
{
	m_bHeadOffsetMode = TRUE;
	m_bVariousZ = FALSE;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	m_bStop = FALSE;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(m_bVariousZ == 0 && m_nPattern == 1)
	{
		if(m_HolePatternList.GetCount() == 0)
		{
			ErrMessage(_T("Pattern File Loading Please"));
			return;
		}
	}

	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			ErrMsgDlg(STDGNALM607);
			return;
		}
	}
	
	EnableAllButton(FALSE);
	EndProcess(FALSE);

	if (!UpdateData(TRUE))
	{
		EnableAllButton(TRUE);
		EndProcess();
		return;
	}
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);

	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		ErrMessage(_T("Dust Suction Shutter On Error."));
		EnableAllButton(TRUE);
		return;
	}
#endif

	CString strVal;
	m_edtFieldSize.GetWindowText(strVal);
	m_dHalfField = atof(strVal) / 2.;
	m_pOneHole = ::AfxBeginThread(OneHoleThread, this, THREAD_PRIORITY_NORMAL);
}

void CPaneManualControlOneHole::SetHeadOffsetRes()
{
	int nCam = m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;

	if(ErrMessage(_T("Do you want to apply Head Offset?"), MB_YESNO) == IDYES)
	{
		if(nCam == HIGH_1ST_CAM)
		{
			gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x -= (m_dFoundOffset[LOW_1ST_CAM].x - m_dFoundOffset[HIGH_1ST_CAM].x);
			gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y -= (m_dFoundOffset[LOW_1ST_CAM].y - m_dFoundOffset[HIGH_1ST_CAM].y);
		}
		else if(nCam == LOW_1ST_CAM)
		{
			gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x -= (m_dFoundOffset[HIGH_1ST_CAM].x - m_dFoundOffset[LOW_1ST_CAM].x);
			gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y -= (m_dFoundOffset[HIGH_1ST_CAM].y - m_dFoundOffset[LOW_1ST_CAM].y);
		}
		else if(nCam == HIGH_2ND_CAM)
		{
			gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x -= (m_dFoundOffset[LOW_2ND_CAM].x - m_dFoundOffset[HIGH_2ND_CAM].x);
			gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y -= (m_dFoundOffset[LOW_2ND_CAM].y - m_dFoundOffset[HIGH_2ND_CAM].y);
		}
		else 
		{
			gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x -= (m_dFoundOffset[HIGH_2ND_CAM].x - m_dFoundOffset[LOW_2ND_CAM].x);
			gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y -= (m_dFoundOffset[HIGH_2ND_CAM].y - m_dFoundOffset[LOW_2ND_CAM].y);
		}
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
			ErrMsgDlg(STDGNALM110);
	}
}

void CPaneManualControlOneHole::OnEditchangeComboTool() 
{
	// TODO: Add your control notification handler code here
	int nBeamPathNo = m_cmbTool.GetCurSel();
	if(nBeamPathNo >= 0)
		ChangeParam(nBeamPathNo);
	
	m_nBeamPath = nBeamPathNo;
}

void CPaneManualControlOneHole::SetToolComboBox()
{
	m_cmbTool.ResetContent();
	
	CString strTool;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbTool.AddString(strTool);
	}
	if(gBeamPathINI.m_sBeampath.nLastIndex >= m_nBeamPath && m_nBeamPath >= 0)
	{
		m_cmbTool.SetCurSel(m_nBeamPath);
		ChangeParam(m_nBeamPath);
	}
	else
		m_nBeamPath = -1;
}

void CPaneManualControlOneHole::OnButtonApply() 
{
	// TODO: Add your control notification handler code here
	double dTemp = 0;
	
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeBeamPath_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}
	
	file.SeekToEnd();

	strDetail = _T("----------------------------------------------------------------------------------------------\n");
	file.Write(strDetail, strDetail.GetLength());

	strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
	file.Write(strDetail, strDetail.GetLength());


	int nIndex = m_cmbTool.GetCurSel();
	if(gBeamPathINI.m_sBeampath.nLastIndex >= nIndex && nIndex >= 0)
	{
		// target Z1
		CString strData;
		m_edtTargetZ1.GetWindowText( strData );

		if(gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nIndex] != atof(strData))
		{

			double dTemp = atof(strData);
			if(gProcessINI.m_sProcessSystem.bUseZAxisValidtion)
			{
				double dTol = gProcessINI.m_sProcessOption.dLaserZAxisTol;
				double dMin = gBeamPathINI.m_sBeampath.dBeamPathZAxis1RefValue[nIndex] - dTol - 0.000001;
				double dMax = gBeamPathINI.m_sBeampath.dBeamPathZAxis1RefValue[nIndex] + dTol + 0.000001;

				if(dTemp < dMin || dTemp > dMax)
				{
					::AfxMessageBox(_T("Z1 Axis Focus value out of spec"));
					return;
				}
			}


			str.Format(_T("[%d]Index Z1 Pos : %.3f -> %.3f\n"),  nIndex, gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nIndex] = atof(strData);
		
		// Target Z2
		m_edtTargetZ2.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nIndex] != atof(strData))
		{

			double dTemp = atof(strData);
			if(gProcessINI.m_sProcessSystem.bUseZAxisValidtion)
			{
				double dTol = gProcessINI.m_sProcessOption.dLaserZAxisTol;
				double dMin = gBeamPathINI.m_sBeampath.dBeamPathZAxis2RefValue[nIndex] - dTol - 0.000001;
				double dMax = gBeamPathINI.m_sBeampath.dBeamPathZAxis2RefValue[nIndex] + dTol + 0.000001;

				if(dTemp < dMin || dTemp > dMax)
				{
					::AfxMessageBox(_T("Z2 Axis Focus value out of spec"));
					return;
				}
			}

			str.Format(_T("[%d]Index Z2 Pos : %.3f -> %.3f\n"),  nIndex, gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nIndex] = atof(strData);
		
		// Target M
		m_edtTargetM1.GetWindowText( strData );
			if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex] != atof(strData))
		{
			str.Format(_T("%d M1 Pos : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex] = atoi(strData);
		
		// Target M2
		m_edtTargetM2.GetWindowText( strData );
			if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nIndex] != atof(strData))
		{
			str.Format(_T("%d M2 Pos : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nIndex] = atoi(strData);

		// Target M2
		m_edtTargetM3.GetWindowText( strData );
			if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nIndex] != atof(strData))
		{
			str.Format(_T("%d M3 Pos : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nIndex] = atoi(strData);
		
		// Target B
		m_edtTargetB1.GetWindowText( strData );
				if(gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nIndex] != atof(strData))
		{
			str.Format(_T("%d BET1 Pos : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nIndex] = atof(strData);
		
		// Target B2
		m_edtTargetB2.GetWindowText( strData );
						if(gBeamPathINI.m_sBeampath.dBeamPathBetPos2[nIndex] != atof(strData))
		{
			str.Format(_T("%d BET2 Pos : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dBeamPathBetPos2[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}

		gBeamPathINI.m_sBeampath.dBeamPathBetPos2[nIndex] = atof(strData);
		
		// Target A
		m_edtTargetA1.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nIndex] != atof(strData))
		{
			str.Format(_T("%d A1 Pos : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nIndex] = atoi(strData);
		
		// Target A2
		m_edtTargetA2.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[nIndex] != atof(strData))
		{
			str.Format(_T("%d A2 Pos : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[nIndex] = atoi(strData);
		
		//Tophat
		m_bTopHat = m_chkTopHat.GetCheck();
		if(gBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex] != atof(strData))
		{
			str.Format(_T("%d Tophat : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex] = m_bTopHat;

		//Long Pass
		m_bBeamPass = m_chkBeamPath.GetCheck();
		if(gBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex] != atof(strData))
		{
			str.Format(_T("%d Laser Path : %d -> %d\n"), nIndex, gBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex] = m_bBeamPass;

		//Freq
//		m_edtFreq.GetWindowText( strData );
//		gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex]  = atoi( strData );
		
		//Duty
		m_edtDuty.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex] != atof(strData))
		{
			str.Format(_T("%d Power Compensation Duty : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex] = atof( strData );
		
		//AOM Delay
		m_edtAOMDelay.GetWindowText( strData );
			if(gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex] != atof(strData))
		{
				str.Format(_T("%d Power Compensation AOM Delay : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nIndex] = atof( strData );
		
		//AOM Duty
		m_edtAOMDuty.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex] != atof(strData))
		{
			str.Format(_T("%d Power Compensation AOM Duty : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nIndex] = atof( strData );

		// voltage1
		m_edtVoltage1.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[nIndex] != atof(strData))
		{
			str.Format(_T("%d Voltage1 : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dBeamPathVoltage1[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dBeamPathVoltage1[nIndex] = atoi(strData);
		
		// voltage2
		m_edtVoltage2.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.dBeamPathVoltage2[nIndex] != atof(strData))
		{
			str.Format(_T("%d Voltage2 : %.3f -> %.3f\n"), nIndex, gBeamPathINI.m_sBeampath.dBeamPathVoltage2[nIndex], atof(strData) );
			file.Write(str, str.GetLength());
		}
		gBeamPathINI.m_sBeampath.dBeamPathVoltage2[nIndex] = atoi(strData);

		file.Close();
		int nCamNo = m_cmbCam.GetCurSel();
		// ring
		m_edtRing.GetWindowText( strData );
		sVisionInfo.nRing[nCamNo] = atoi(strData);

		// coaxial
		m_edtCoaxial.GetWindowText( strData );
		sVisionInfo.nCoaxial[nCamNo] = atoi(strData);
		
		gDeviceFactory.GetVision()->OnLightAll(nCamNo, sVisionInfo.nCoaxial[nCamNo], sVisionInfo.nRing[nCamNo]);

		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (OneHole) : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
		else
		{
			ErrMessage(IDS_DATA_CHANGED);
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SYSTEM_BEAMPATH);
	}

}

void CPaneManualControlOneHole::ChangeParam(int nIndex)
{
	CString strData;
	
	// target z1
	strData.Format(_T("%.3f"), gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nIndex]);
	m_edtTargetZ1.SetWindowText( strData );
	
	// Target Z2
	strData.Format(_T("%.3f"), gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nIndex]);
	m_edtTargetZ2.SetWindowText( strData );
	
	// Target M
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex]);
	m_edtTargetM1.SetWindowText( strData );
	
	// Target M2
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nIndex]);
	m_edtTargetM2.SetWindowText( strData );
	
	// Target M3
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nIndex]);
	m_edtTargetM3.SetWindowText( strData );

	// Target B
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nIndex]);
	m_edtTargetB1.SetWindowText( strData );
	
	// Target B2
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dBeamPathBetPos2[nIndex]);
	m_edtTargetB2.SetWindowText( strData );
	
	// Target A
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nIndex]);
	m_edtTargetA1.SetWindowText( strData );
	
	// Target A2
	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[nIndex]);
	m_edtTargetA2.SetWindowText( strData );

	//Freq
//	strData.Format(_T("%d"), gBeamPathINI.m_sBeampath.bBeamPathUseTophat [nIndex]);
//	m_edtFreq.SetWindowText( strData );

	//Duty
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex]);
	m_edtDuty.SetWindowText( strData );

	//Aom delay
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nIndex]);
	m_edtAOMDelay.SetWindowText( strData );

	//aom duty
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nIndex]);
	m_edtAOMDuty.SetWindowText( strData );

	//Tophat 
	m_bTopHat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex];
	m_chkTopHat.SetCheck(m_bTopHat);

	//Long Pass
	m_bBeamPass = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex];
	m_chkBeamPath.SetCheck(m_bBeamPass);

	//voltage1
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dBeamPathVoltage1[nIndex]);
	m_edtVoltage1.SetWindowText( strData );
	
	//voltage2
	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dBeamPathVoltage2[nIndex]);
	m_edtVoltage2.SetWindowText( strData );
	
// 	// ring
// 	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.nHoleRing[nIndex]);
// 	m_edtRing.SetWindowText( strData );
// 	
// 	// coaxial
// 	strData.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.nHoleCoaxial[nIndex]);
// 	m_edtCoaxial.SetWindowText( strData );

}

void CPaneManualControlOneHole::OnCheckTophat() 
{
	// TODO: Add your control notification handler code here
	m_bTopHat = m_chkTopHat.GetCheck();
}

void CPaneManualControlOneHole::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		GetDlgItem(IDC_BUTTON_APPLY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VIEW_POINT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_APPLY_Z)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_Z_GAP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_GAP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_VFIRE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_WHITE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_HEAD_OFFSET)->ShowWindow(SW_HIDE);
		m_btnZMinus5.ShowWindow(SW_HIDE);
		m_btnZMinus4.ShowWindow(SW_HIDE);
		m_btnZMinus3.ShowWindow(SW_HIDE);
		m_btnZMinus2.ShowWindow(SW_HIDE);
		m_btnZMinus1.ShowWindow(SW_HIDE);
		m_btnZNone.ShowWindow(SW_HIDE);
		m_btnZPlus1.ShowWindow(SW_HIDE);
		m_btnZPlus2.ShowWindow(SW_HIDE);
		m_btnZPlus3.ShowWindow(SW_HIDE);
		m_btnZPlus4.ShowWindow(SW_HIDE);
		m_btnZPlus5.ShowWindow(SW_HIDE);
		m_btnLeftTop.ShowWindow(SW_HIDE);
		m_btnRightTop.ShowWindow(SW_HIDE);
		m_btnCenter.ShowWindow(SW_HIDE);
		m_btnLeftBottom.ShowWindow(SW_HIDE);
		m_btnRightBottom.ShowWindow(SW_HIDE);
		m_chkUseParam.ShowWindow(SW_HIDE);
		break;
	
	case 2:
	case 3:
		GetDlgItem(IDC_BUTTON_APPLY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_VIEW_POINT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_APPLY_Z)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_Z_GAP)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_GAP)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_VFIRE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_WHITE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_HEAD_OFFSET)->ShowWindow(SW_SHOW);
		m_btnZMinus5.ShowWindow(SW_SHOW);
		m_btnZMinus4.ShowWindow(SW_SHOW);
		m_btnZMinus3.ShowWindow(SW_SHOW);
		m_btnZMinus2.ShowWindow(SW_SHOW);
		m_btnZMinus1.ShowWindow(SW_SHOW);
		m_btnZNone.ShowWindow(SW_SHOW);
		m_btnZPlus1.ShowWindow(SW_SHOW);
		m_btnZPlus2.ShowWindow(SW_SHOW);
		m_btnZPlus3.ShowWindow(SW_SHOW);
		m_btnZPlus4.ShowWindow(SW_SHOW);
		m_btnZPlus5.ShowWindow(SW_SHOW);
		m_btnLeftTop.ShowWindow(SW_SHOW);
		m_btnRightTop.ShowWindow(SW_SHOW);
		m_btnCenter.ShowWindow(SW_SHOW);
		m_btnLeftBottom.ShowWindow(SW_SHOW);
		m_btnRightBottom.ShowWindow(SW_SHOW);
		m_chkUseParam.ShowWindow(SW_SHOW);
		break;
	}
	EnableAllButton(TRUE);
}

void CPaneManualControlOneHole::OnButtonVfire() 
{
	// TODO: Add your control notification handler code here
	m_bHeadOffsetMode = FALSE;
	m_bVariousZ = TRUE;
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	m_bStop = FALSE;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}
	
	EnableAllButton(FALSE);
	EndProcess(FALSE);
	
	if (!UpdateData(TRUE))
	{
		EnableAllButton(TRUE);
		EndProcess();
		return;
	}
	
	gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);
	
	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		ErrMessage(_T("Dust Suction Shutter On Error."));
		EnableAllButton(TRUE);
		EndProcess();
		return;
	}
	CString strVal;
	m_edtFieldSize.GetWindowText(strVal);
	m_dHalfField = atof(strVal) / 2.;

	m_pOneHole = ::AfxBeginThread(OneHoleThread, this, THREAD_PRIORITY_NORMAL);
}

void CPaneManualControlOneHole::OnBtnApplyZ() 
{
	// TODO: Add your control notification handler code here
	CString strData;
	int nSel = m_cmbCam.GetCurSel();
	if(nSel > LOW_1ST_CAM)
	{
		m_edtTargetZ2.GetWindowText( strData );
		double dTemp = atof( (LPSTR)(LPCTSTR)strData );
		m_edtZGap.GetWindowText( strData );
		double dGap = atof( (LPSTR)(LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_dBaseZ2 + m_nZIndex * dGap);
		m_edtTargetZ2.SetWindowText(strData);
	}
	else
	{
		m_edtTargetZ1.GetWindowText( strData );
		double dTemp = atof( (LPSTR)(LPCTSTR)strData );
		m_edtZGap.GetWindowText( strData );
		double dGap = atof( (LPSTR)(LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_dBaseZ1 + m_nZIndex * dGap);
		m_edtTargetZ1.SetWindowText(strData);
	}
	UpdateData(TRUE);
}

void CPaneManualControlOneHole::OnBtnZ1() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((5) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = -5;
	UnSelectAllZButton();

}

void CPaneManualControlOneHole::OnBtnZ2() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((4) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = -4;
	UnSelectAllZButton();

}

void CPaneManualControlOneHole::OnBtnZ3() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((3) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = -3;
	UnSelectAllZButton();

}

void CPaneManualControlOneHole::OnBtnZ4() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((2) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = -2;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ5() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((1) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = -1;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ6() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY(m_dFirePosX - m_dFirePosX * m_nXScanIndex, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 0;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ7() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-1) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 1;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ8() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-2) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 2;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ9() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-3) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 3;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ10() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-4) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 4;
	UnSelectAllZButton();
	
}

void CPaneManualControlOneHole::OnBtnZ11() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-5) * 0.5 + m_dFirePosX - m_nXScanIndex * dHalfField, m_dFirePosY - m_nYScanIndex * dHalfField))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	m_nZIndex = 5;
	UnSelectAllZButton();

}

void CPaneManualControlOneHole::OnBtnUpleft() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-m_nZIndex) * 0.5 + m_dFirePosX , m_dFirePosY - 2 * (double)HEIGHT_GAP/1000.))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	UnSelectScannerButton();
	m_btnLeftTop.SetSelection( TRUE );
	m_nXScanIndex = -1;
	m_nYScanIndex = 1;
}

void CPaneManualControlOneHole::OnBtnUpright() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-m_nZIndex) * 0.5 + m_dFirePosX, m_dFirePosY - (double)HEIGHT_GAP/1000.))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	UnSelectScannerButton();
	m_btnRightTop.SetSelection( TRUE );
	m_nXScanIndex = 1;
	m_nYScanIndex = 1;
}

void CPaneManualControlOneHole::OnBtnCenter() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-m_nZIndex) * 0.5 + m_dFirePosX, m_dFirePosY))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	UnSelectScannerButton();
	m_btnCenter.SetSelection( TRUE );
	m_nXScanIndex = 0;
	m_nYScanIndex = 0;
}

void CPaneManualControlOneHole::OnBtnDownleft() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-m_nZIndex) * 0.5 + m_dFirePosX , m_dFirePosY + (double)HEIGHT_GAP/1000.))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	UnSelectScannerButton();
	m_btnLeftBottom.SetSelection( TRUE );
	m_nXScanIndex = -1;
	m_nYScanIndex = -1;
}

void CPaneManualControlOneHole::OnBtnDownright() 
{
	// TODO: Add your control notification handler code here
	double dHalfField = gSystemINI.m_sSystemDevice.dFieldSize.x / 2;
	if (!gDeviceFactory.GetMotor()->MoveXY((-m_nZIndex) * 0.5 + m_dFirePosX, m_dFirePosY + 2 * (double)HEIGHT_GAP/1000.))
		return;
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return;
	}
	UnSelectScannerButton();
	m_btnRightBottom.SetSelection( TRUE );
	m_nXScanIndex = 1;
	m_nYScanIndex = -1;
}

void CPaneManualControlOneHole::UnSelectAllZButton()
{
	m_btnZMinus5.SetSelection( FALSE );
	m_btnZMinus4.SetSelection( FALSE );
	m_btnZMinus3.SetSelection( FALSE );
	m_btnZMinus2.SetSelection( FALSE );
	m_btnZMinus1.SetSelection( FALSE );
	m_btnZNone.SetSelection( FALSE );
	m_btnZPlus1.SetSelection( FALSE );
	m_btnZPlus2.SetSelection( FALSE );
	m_btnZPlus3.SetSelection( FALSE );
	m_btnZPlus4.SetSelection( FALSE );
	m_btnZPlus5.SetSelection( FALSE );

	switch(m_nZIndex)
	{
	case -5 :
		m_btnZMinus5.SetSelection( TRUE ); break;
	case -4 :
		m_btnZMinus4.SetSelection( TRUE ); break;
	case -3 :
		m_btnZMinus3.SetSelection( TRUE ); break; 
	case -2 :
		m_btnZMinus2.SetSelection( TRUE ); break;
	case -1 :
		m_btnZMinus1.SetSelection( TRUE ); break;
	case 0 :
		m_btnZNone.SetSelection( TRUE ); break;
	case 1 :
		m_btnZPlus1.SetSelection( TRUE ); break;
	case 2 :
		m_btnZPlus2.SetSelection( TRUE ); break;
	case 3 :
		m_btnZPlus3.SetSelection( TRUE ); break;
	case 4 :
		m_btnZPlus4.SetSelection( TRUE ); break;
	case 5 :
		m_btnZPlus5.SetSelection( TRUE ); break;
		
	}
}

void CPaneManualControlOneHole::UnSelectScannerButton()
{
	m_btnLeftTop.SetSelection( FALSE );
	m_btnRightTop.SetSelection( FALSE );
	m_btnCenter.SetSelection( FALSE );
	m_btnLeftBottom.SetSelection( FALSE );
	m_btnRightBottom.SetSelection( FALSE );
}

void CPaneManualControlOneHole::SetDefaultZScan()
{
	double dVisionXPos = gDeviceFactory.GetMotor()->GetPosition(AXIS_X);
	double dVisionYPos = gDeviceFactory.GetMotor()->GetPosition(AXIS_Y);
	m_dFirePosX = dVisionXPos;
	m_dFirePosY = dVisionYPos;
//	m_nZIndex = 0;
	m_nXScanIndex = 0;
	m_nYScanIndex = 0;

	UnSelectAllZButton();
	UnSelectScannerButton();
	m_btnCenter.SetSelection( TRUE );
//	m_btnZNone.SetSelection( TRUE );
}

void CPaneManualControlOneHole::GetHeadOffsets(double& dHeadOffsetX, double& dHeadOffsetY, int nCam)
{
	dHeadOffsetX = dHeadOffsetY = 0;
	switch(nCam)
	{
		case 0:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
			break;
		case 1:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			break;
		case 2:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
			break;
		case 3:
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
			break;
	}
}

BOOL CPaneManualControlOneHole::IsValidLaserFirePos(double dLaserXPos, double dLaserYPos)
{
#ifndef __TEST__

	if(m_nUserLevel <= 2)
	{
		if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
			dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
			dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
			dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
		{
			CString strM;
			strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
				gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
				gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
			ErrMessage(strM);
			EnableAllButton(TRUE);
			EndProcess();
			return FALSE;
		}
	}
#endif
	return TRUE;
}

BOOL CPaneManualControlOneHole::TableMoveAndFire(double dLaserXPos, double dLaserYPos)
{
	int nCam = m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;

	if(nHead == 0) // Master
	{
		if(!ShutterMove(TRUE, FALSE))
		{
			EnableAllButton(TRUE);
			EndProcess();
			return FALSE;
		}
	}
	else if(nHead == 1) // Slave
	{
		if(!ShutterMove(FALSE, TRUE))
		{
			EnableAllButton(TRUE);
			EndProcess();
			return FALSE;
		}
	}

	if(m_bStop)
	{
		m_bStop = FALSE;
		EnableAllButton(TRUE);
		EndProcess();
		return FALSE;
	}

	int nStartIndex, nEndIndex;
	int nScannerIndex;
	double dScanneerXY[5][2]; //x,y
	double dHoleHight = 0;
			 		
	if(m_bVariousZ)
	{
		nStartIndex = -5;
		nEndIndex = 5;
		nScannerIndex = 5;

		dScanneerXY[0][0] = -m_dHalfField;		dScanneerXY[0][1] = m_dHalfField; // �»�
		dScanneerXY[1][0] = m_dHalfField;		dScanneerXY[1][1] = m_dHalfField; // ���
		dScanneerXY[2][0] = 0;					dScanneerXY[2][1] = 0;			 // ����
		dScanneerXY[3][0] = -m_dHalfField;		dScanneerXY[3][1] = -m_dHalfField;// ����
		dScanneerXY[4][0] = m_dHalfField;		dScanneerXY[4][1] = -m_dHalfField;// ����  <<�� ������ ���� 
	}
	else 
	{
		nStartIndex = 0;
		nEndIndex = 0;
		nScannerIndex = 1; 

		dScanneerXY[0][0] = 0; dScanneerXY[0][1] = 0; // �»�
		dScanneerXY[1][0] = 0; dScanneerXY[1][1] = 0; // ���
		dScanneerXY[2][0] = 0; dScanneerXY[2][1] = 0;			 // ����
		dScanneerXY[3][0] = 0; dScanneerXY[3][1] = 0;// ����
		dScanneerXY[4][0] = 0; dScanneerXY[4][1] = 0;// ����  <<�� ������ ���� 
	}

	for(int k = 0; k < nScannerIndex; k++)
	{
		dHoleHight = 0;
		if(m_bVariousZ)
		{
			if(k < 3 )
				dHoleHight = (k%3 - 2) * (double)HEIGHT_GAP/1000.; 
			else
				dHoleHight = (k%3 + 1) * (double)HEIGHT_GAP/1000.; 
		}
				
		for(int i = nStartIndex; i <= nEndIndex; i++)
		{
		
			if (!gDeviceFactory.GetMotor()->MoveXY(dLaserXPos - i * 0.5 + dScanneerXY[k][0] , dLaserYPos + dScanneerXY[k][1] - dHoleHight, TRUE, SHOT_MOVE))
			{
				TRACE("Motor out of position\n");
				EnableAllButton(TRUE);
				EndProcess();
				return FALSE;
			}   

			if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			{
				TRACE("Motor does not stop\n");
				EnableAllButton(TRUE);
				EndProcess();
				return FALSE;
			}

			if(m_bStop)
			{
				m_bStop = FALSE;
				EnableAllButton(TRUE);
				EndProcess();
				return FALSE;
			}

			if(!LaserFire(i, k))
			{
				EnableAllButton(TRUE);
				EndProcess();
				return FALSE; 
			}
		}
	}

	if(m_bStop)
	{
		m_bStop = FALSE;
		EnableAllButton(TRUE);
		EndProcess();
		return FALSE;
	}

	// shutter close
	if(!ShutterMove(FALSE, FALSE))
	{
		EnableAllButton(TRUE);
		EndProcess();
		return FALSE;
	}

	return TRUE;
}

void CPaneManualControlOneHole::OnButtonPattern() 
{
	// TODO: Add your control notification handler code here
	CString strFilePath;
	
	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt)|*.txt|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, _T("*.txt"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = _T("D:\\ViaHole\\Temp");

	if(IDOK != dlg.DoModal())
	{
		SetFocus();
		return;
	}

	strFilePath.Format(_T("%s"), dlg.GetPathName());
	DeleteData();
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strFilePath, _T("rb"));
	if (err == NULL)
	{
		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));
			ReadNums(token); // Write to buffer
		};
		fclose(pFile);
	}

	m_nAxisMode = PX_PY;
	GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (PX_PY)"));
}

void CPaneManualControlOneHole::ReadNums(TCHAR *szBuffer)
{
	HOLEDATA* pHolePatternData;

	int nPosX = 0, nPosY = 0;

	if(!GetXYPos(szBuffer, nPosX, nPosY))
		return;

	pHolePatternData = new HOLEDATA;
	pHolePatternData->npPos.x = nPosX;
	pHolePatternData->npPos.y = nPosY;
	m_HolePatternList.AddTail(pHolePatternData);
}

BOOL CPaneManualControlOneHole::GetXYPos(TCHAR* szBuffer, int &nPosX, int &nPosY)
{
	CString strTemp, str1, str2;
	strTemp.Format(_T("%s"), szBuffer);
	int nCheckNULL;
	nCheckNULL = strTemp.Find(_T(" "));
	TCHAR szTemp[BUFMAX];
	memset(szTemp, NULL, sizeof(szTemp));
	//�߰��� NULL�� �����ϴ� ���
	if(nCheckNULL > 0)
	{
		str1 = strTemp.Left(nCheckNULL);

		for(int e = nCheckNULL; e < strTemp.GetLength(); e++)
		{
			if(szBuffer[e] != _T(' '))
			{
				nCheckNULL = e;
				break;
			}
			e++;
		}
		str2 = strTemp.Mid(nCheckNULL);
		str2.TrimRight();
		strTemp.Format(_T("%s%s"),str1, str2);

		strcpy_s(szTemp, (LPCTSTR)strTemp);
		memcpy(szBuffer, szTemp, sizeof(szTemp));
	}


	TCHAR	m_TempData[BUFMAX];
	int nTotalLen = strlen(szBuffer);
	if(szBuffer[0] == _T('X'))
	{
		int nCount = 0;
		int i = 1;
		for(i = 1; i < nTotalLen; i++)
		{
			if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
			{
				m_TempData[nCount++] = szBuffer[i];
			}
			else if (szBuffer[i] == _T(' '))
			{
					break;
			}
			else
				break;
		}
		m_TempData[nCount] = _T('\0');


		if (m_TempData[0] == _T('-'))
			nCount = nCount - 1;
		IsTzs(nCount);

//		nPosX = atoi(m_TempData);// * m_lTzsLzs; ���밪
		m_nIncrementalFirstPosX +=  atoi(m_TempData);
		nPosX = m_nIncrementalFirstPosX;

		BOOL bY = FALSE;
		BOOL bStart = FALSE;
		nCount = 0;
		for(i; i < nTotalLen; i++)
		{
			if(bY)
			{
				if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[i];
				}
				else if (szBuffer[i] == _T(' '))
				{
					if(bStart)
						break;
				}
				else if(szBuffer[i] == _T('X') || szBuffer[i] == _T('Y'))
				{
					break;
				}
				else
					break;
			}

			if(szBuffer[i] == _T('X'))
			{
				break;
			}

			if(szBuffer[i] == _T('Y'))
			{
				bY = TRUE;
			}				
		}
		m_TempData[nCount] = _T('\0');

		if(bY && bStart)
		{
			if (m_TempData[0] == _T('-'))
				nCount = nCount - 1;
			IsTzs(nCount);

//			nPosY = atoi(m_TempData); //  * m_lTzsLzs; ���밪
			m_nIncrementalFirstPosY +=  atoi(m_TempData);
			nPosY = m_nIncrementalFirstPosY;


		}
	}
	return TRUE;
}

void CPaneManualControlOneHole::IsTzs(int nCount)
{
	switch (nCount)
	{
	case 1 : m_lTzsLzs = 100000; break;
	case 2 : m_lTzsLzs = 10000;  break;
	case 3 : m_lTzsLzs = 1000;   break;
	case 4 : m_lTzsLzs = 100;    break;
	case 5 : m_lTzsLzs = 10;     break;
	case 6 : m_lTzsLzs = 1;      break;
	default : m_lTzsLzs = 1;	 break;
	} 
}

void CPaneManualControlOneHole::OnButtonDefaultMode()
{
	// TODO: Add your control notification handler code here
	m_nPattern = 0;
	UpdateData(FALSE);
}

void CPaneManualControlOneHole::OnButtonPatternMode() 
{
	// TODO: Add your control notification handler code here
	m_nPattern = 1;
	UpdateData(FALSE);
}

void CPaneManualControlOneHole::DeleteData()
{

	POSITION pos;
	HOLEDATA* pHolePatternData;

	pos = m_HolePatternList.GetHeadPosition();
	while (pos) 
	{
		pHolePatternData = m_HolePatternList.GetNext(pos);
		delete pHolePatternData;
	}
	m_HolePatternList.RemoveAll();

	m_nIncrementalFirstPosX=0;
	m_nIncrementalFirstPosY=0;
}

void CPaneManualControlOneHole::OnBnClickedBtnChangeAxis()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	// PX_PY = 0, NX_PY, PX_NY, NX_NY, PY_PX, NY_PX, PY_NX, NY_NX
	if(m_nAxisMode == NY_NX)
		m_nAxisMode = PX_PY;
	else
		m_nAxisMode++;

	if(m_nAxisMode == PX_PY)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (PX_PY)"));
	if(m_nAxisMode == NX_PY)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (NX_PY)"));
	if(m_nAxisMode == PX_NY)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (PX_NY)"));
	if(m_nAxisMode == NX_NY)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (NX_NY)"));

	if(m_nAxisMode == PY_PX)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (PY_PX)"));
	if(m_nAxisMode == NY_PX)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (NY_PX)"));
	if(m_nAxisMode == PY_NX)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (PY_NX)"));
	if(m_nAxisMode == NY_NX)
		GetDlgItem(IDC_BTN_CHANGE_AXIS)->SetWindowText(_T("Change Axis (NY_NX)"));
}


void CPaneManualControlOneHole::OnBnClickedBtnFindHole()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}


void CPaneManualControlOneHole::OnBnClickedCheckContinue()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_bContinuousFind = !m_bContinuousFind;
}


void CPaneManualControlOneHole::OnBnClickedBtnFindStop()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}

void CPaneManualControlOneHole::FindFireHole()
{
	int nX, nY;
	LPHOLEDATA pHoleData;
	POSITION pos = m_HolePatternList.GetHeadPosition();
	while(pos)
	{
		pHoleData = m_HolePatternList.GetNext(pos);
		nX = XUMtoLSB(pHoleData->npPos.x);
		if(nX > MAXLSB) nX = MAXLSB;
		if(nX < 0)		nX = 0;
		nY = YUMtoLSB(pHoleData->npPos.y);
		if(nY > MAXLSB) nY = MAXLSB;
		if(nY < 0)		nY = 0;

/*		if(nHead == 0) // Master
		{
			pEoCard->DownloadShotData2(nX, nY, HALF_LSB, HALF_LSB, TRUE, FALSE,	ONE_HOLE_TOOL);
		}
		else if(nHead == 1) // Slave
		{
			pEoCard->DownloadShotData2(HALF_LSB, HALF_LSB, nX, nY, FALSE, TRUE, ONE_HOLE_TOOL);
		}
*/	}
}

void CPaneManualControlOneHole::OnButtonManualSCalPosMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

	EnableAllButton( FALSE );
	EndProcess(FALSE);


	// X, Y
	double dPosX, dPosY;
	int nCam = m_cmbCam.GetCurSel();
	int nHead = nCam<2 ? 0 : 1;
	double dHeadOffsetX, dHeadOffsetY;

	switch(nCam)
	{
	case 0:
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		break;
	case 1:
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		break;
	case 2:
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		break;
	case 3:
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		break;
	}

	dPosX = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + (gSystemINI.m_sSystemDevice.dFieldSize.x/2) + 10 + dHeadOffsetX;
	dPosY = (gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY + gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY)/2 + dHeadOffsetY ;

	pMotor->MoveXY(dPosX,dPosY);

	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y);

	EnableAllButton(TRUE);
	EndProcess();

	if(!nRet )
	{
		ErrMessage(_T("Move Fail"));
	}
}



BOOL CPaneManualControlOneHole::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_OneHole) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

void CPaneManualControlOneHole::OnRadioRemote()
{
	m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->UpdateData(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->UpdateData(FALSE);
	CString strCoaxial, strRing;

	gDeviceFactory.GetVision()->UseRemoteControl(!m_nRemote);

	gDeviceFactory.GetVision()->GetLampValue(m_cmbCam.GetCurSel(), strCoaxial, strRing); 
	
	m_edtCoaxial.SetWindowText(strCoaxial);
	m_edtRing.SetWindowText(strRing);
	int nCoaxial, nRing;
	nCoaxial = atoi(strCoaxial);
	nRing = atoi(strRing);
	gDeviceFactory.GetVision()->OnLightAll(m_cmbCam.GetCurSel(), nCoaxial, nRing);

	UpdateData(FALSE);
}
void CPaneManualControlOneHole::OnRadioManual()
{
	m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->UpdateData(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->UpdateData(FALSE);

	gDeviceFactory.GetVision()->UseRemoteControl(!m_nRemote);

	UpdateData(FALSE);
}

void CPaneManualControlOneHole::OnButtonVisionTest() 
{
	int nCam = m_cmbCam.GetCurSel();
	SendMessage(VISION_INSPECTION, (WPARAM)nCam);


	/*m_edtRing.GetWindowText( strData );
	sVisionInfo.nRing[nCam] = atoi(strData);
	m_edtCoaxial.GetWindowText( strData );
	sVisionInfo.nCoaxial[nCam] = atoi(strData);

	gDeviceFactory.GetVision()->OnLightAll(nCam, sVisionInfo.nCoaxial[nCam], sVisionInfo.nRing[nCam]  );
	*/
}
void CPaneManualControlOneHole::OnButtonFire2() 
{
	m_bHeadOffsetMode = FALSE;
	m_bVariousZ = FALSE;

	m_nPattern = 2;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	m_bStop = FALSE;
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(m_bVariousZ == 0 && m_nPattern == 1)
	{
		if(m_HolePatternList.GetCount() == 0)
		{
			ErrMessage(_T("Pattern File Loading Please"));
			return;
		}
	}

	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			bPower = nPower;
			bShutter = nShutter;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(nPower & 0x02) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x02)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
		{
			if(nPower & 0x03) 
				bPower = TRUE;
			else
				bPower = FALSE;
			
			if(nShutter & 0x03)
				bShutter = TRUE;
			else
				bShutter = FALSE;
		}
		
		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			return;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			ErrMsgDlg(STDGNALM607);
			return;
		}
	}
	
	EnableAllButton(FALSE);
	EndProcess(FALSE);

	//if (!UpdateData(TRUE))
	//{
	//	EnableAllButton(TRUE);
	//	EndProcess();
	//	return;
	//}
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->IonizerOn(TRUE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);

	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
	if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
	{
		ErrMessage(_T("Dust Suction Shutter On Error."));
		EnableAllButton(TRUE);
		return;
	}
#endif

	CString strVal;
	m_edtFieldSize.GetWindowText(strVal);
	m_dHalfField = atof(strVal) / 2.;
	m_nFieldSize = atoi(strVal);

	m_edtXPos.GetWindowText(strVal);
	m_dStartPosX = atof(strVal);

	m_edtYPos.GetWindowText(strVal);
	m_dStartPosY = atof(strVal);

	m_edtGridGapX.GetWindowText(strVal);
	m_dGridGapX = atof(strVal);

	m_edtGridGapY.GetWindowText(strVal);
	m_dGridGapY = atof(strVal);

	m_edtGridXNo.GetWindowText(strVal);
	m_nGridX = atoi(strVal);

	m_edtGridYNo.GetWindowText(strVal);
	m_nGridY = atoi(strVal);


	m_pOneHole = ::AfxBeginThread(OneHoleThread, this, THREAD_PRIORITY_NORMAL);
}

BOOL CPaneManualControlOneHole::FindShot(double dStartPosX, double dStartPosY)
{
	double dStartZ1, dStartZ2;
//	double dStartPosX = m_dStartPosX;
//	double dStartPosY = m_dStartPosY;

	CString strVal;
	m_edtGridX.GetWindowText(strVal);
	int nGridX = atoi(strVal);
	
	m_edtGridY.GetWindowText(strVal);
	int nGridY = atoi(strVal);

	//if( nGridX == 65 || nGridY == 65)
	//{
	//	nGridX = 5;
	//	nGridY = 5;
	//}
	int nDivision = (nGridX * nGridY)/nGridY;

	double dMoveX, dMoveY;
	double dFieldSize = m_nFieldSize;
	double dHalfFieldSize = m_dHalfField;
	BOOL bUseLowCam;
	int nCam = m_cmbCam.GetCurSel();

	CString strFile = _T("OneHoleFind");
	CString strFile2 = _T("OneHoleDownload2");
	CString strData = _T("");
	strData.Format(_T("OneHole Find Start -- %.3f Field -- %d x %d"), dFieldSize, m_nGridX, m_nGridY);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strData));
	
	m_edtFieldSize.GetWindowText(strVal);
	int nGridSize = atoi(strVal);
	int nMaxLSB = (int)(MAXLSB * nGridSize / (gSystemINI.m_sSystemDevice.dFieldSize.x));
	int nStartLSBX, nStartLSBY, nStepX, nStepY;
	int nX, nY;

	nStepX = nMaxLSB / (nGridY - 1);
	nStepY = nMaxLSB / (nGridY - 1);
	m_edtScannerPosX.GetWindowText(strVal);
	int nMoveX = atoi(strVal);
	m_edtScannerPosY.GetWindowText(strVal);
	int nMoveY = atoi(strVal);

	nStartLSBX = (int)(nMoveX - (nGridX/2.0 - 0.5)*nStepX);
	nStartLSBY = (int)(nMoveY - (nGridY/2.0 - 0.5)*nStepY);

	switch(nCam)
	{
		case 0:
		case 2:
			bUseLowCam = 0;
			break;
		case 3:
		case 1:
			bUseLowCam = 1;
			break;
	}

	m_edtThickness.GetWindowText(strVal);
	double dThick = atof(strVal);

	if(bUseLowCam)
	{
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dThick;
	}
	else
	{	
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dThick;
	}


	BOOL bRet;

	for(int nCountX = 0, nCountY; nCountX < nGridX; nCountX++)
	{
		if( nGridX == 65)
			if( nCountX % 16 != 0)
				continue;
		for (nCountY = 0; nCountY < nGridY; nCountY++)
		{
			if( nGridY == 65)
				if( nCountY % 16 != 0)
					continue;
			//double dCalc = dFieldSize / (nDivision - 1.0);
			//if((nDivision - 1.0) == 0)
			//{
			//	dCalc = 0;
			//}
			//if(bUseLowCam)
			//{
			//	dMoveY = dStartPosY - dHalfFieldSize + nCountY * (dCalc);	//gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			//	dMoveX = dStartPosX + dHalfFieldSize - nCountX * (dCalc);	//gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			//}
			//else
			//{
			//	dMoveY = dStartPosY - dHalfFieldSize + nCountY * (dCalc); //gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			//	dMoveX = dStartPosX + dHalfFieldSize - nCountX * (dCalc); //gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			//}
			//if ((nCountY % 2) == 1)
			//	dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));

			nX = nStartLSBX + nCountX * nStepX;
			if(nX > MAXLSB) nX = MAXLSB;
			if(nX < 0)		nX = 0;
			nY = nStartLSBY + nCountY * nStepY;
			if(nY > MAXLSB) nY = MAXLSB;
			if(nY < 0)		nY = 0;

			strData.Format(_T("%d , %d"), nX, nY);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strData));

					
			dMoveX = ( nX * (gSystemINI.m_sSystemDevice.dFieldSize.x )/FIELD_LSB - (gSystemINI.m_sSystemDevice.dFieldSize.x /2) );
			dMoveY = ( nY * (gSystemINI.m_sSystemDevice.dFieldSize.x )/FIELD_LSB - (gSystemINI.m_sSystemDevice.dFieldSize.x /2) );

			dMoveX = dStartPosX + dMoveX;
			dMoveY = dStartPosY + dMoveY;

			if (!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dStartZ1, dStartZ2))	
			{
				return TRUE;
			}
			if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				return TRUE;
			}

			bRet = this->SendMessage(VISION_INSPECTION, nCam, TRUE);
			//if(!GetOffsetFromVisionData(dMoveX, dMoveY, nCountX, nCountY, bUseLowCam, em1st, em2nd, bSave, pdPos1, pdOffset1, pSuccess1, pdPos2, pdOffset2, pSuccess2))
			//	return TRUE;
			m_strResult.Replace(_T("["), _T(" "));
			m_strResult.Replace(_T("]"), _T(" "));
			m_strResult.Replace(_T("("), _T(" "));
			m_strResult.Replace(_T(")"), _T(" "));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&m_strResult));
			if(m_bStop)
			{
				/*m_bStop = FALSE;
				EnableAllButton(TRUE);
				EndProcess();*/
				break;
			}
		}
		if(m_bStop)
		{
			m_bStop = FALSE;
			EnableAllButton(TRUE);
			EndProcess();
			break;
		}
	}
//	m_bFindHoleMode = 0;

	return FALSE;
}

void CPaneManualControlOneHole::OnBnClickedButtonShotEdit()
{
	CDlgShotTableNoAom dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}
