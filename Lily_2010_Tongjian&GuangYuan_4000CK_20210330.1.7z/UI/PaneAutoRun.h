#if !defined(AFX_PANEAUTORUN_H__521FA4AB_D76C_40AD_B450_8E5639289E79__INCLUDED_)
#define AFX_PANEAUTORUN_H__521FA4AB_D76C_40AD_B450_8E5639289E79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRun.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRun form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "LedButton.h"
#include "ColorStatic.h"
#include "..\MODEL\DPoint.h"	// Added by ClassView
#include "..\device\CorrectTime.h"
#include "DlgLaserMeasurement.h"
#include "..\device\devicemotor.h"
#include "DlgVacuumViewer.h"
#include "..\model\ToolCodeList.h"
#include "..\Device\FParameter.h"
#include "..\DPaneArray.h"
#include "..\device\calibrationpath.h"
#include "..\model\DFidData.h"
#include "..\device\alAGC.h"
#include "..\device\HMotor.h"
#include "..\model\2DTransform.h"
#include "..\model\HoleConvertData.h"
#include "..\model\Glyph.h"
#include "DlgLaserMeasurement.h"
#include "DlgInputTemp.h"

#define T_OFFSET_FIRE		1
#define T_OFFSET_FIND		2

class DAreaInfo;
class CPaneAutoRunViewFiducial;
class CPaneAutoRunViewPrework;
class CPaneAutoRunViewProcess;
class CPaneAutoRunViewSystem;
class CPaneAutoRunViewStatus;
class CPaneAutoRunViewOPC;
#include "USimpleTab.h"

class CPaneAutoRunViewData;

class CPaneAutoRun : public CFormView
{
protected:
	CPaneAutoRun();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRun)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRun)
	enum { IDD = IDD_DLG_AUTO_RUN };
	CLedButton m_ledFluorescentLamp;
	CLedButton m_ledTableSuction;
	CLedButton m_ledTableSuction2;
	CLedButton m_ledInit;
	CColorStatic m_stcDrillStatus;
	CColorStatic m_stcPCBCounter;
	CColorStatic m_stcTotalHole;
	CColorStatic m_stcLotHole;
	CColorStatic m_stcDrillingCount;
	CListCtrl m_listBoardParam;
	CLedButton m_ledScanner;
	CLedButton m_ledVision;
	CLedButton m_ledMotor;
	CLedButton m_ledMainPower;
	CLedButton m_ledLaser;
	CLedButton m_ledEStop;
	CLedButton m_ledAutoRun;
	CLedButton m_ledIdleMode;
	CLedButton m_ledSelectFire;
	UEasyButtonEx m_btnProductCounterClear;
	UEasyButtonEx m_btnLotInput;
	UEasyButtonEx m_btnTotalLotInput;
	UEasyButtonEx m_btnLotClear;
	UEasyButtonEx m_btnClear;
	UEasyButtonEx m_btnLPCart;
	UEasyButtonEx m_btnLPTable;
	UEasyButtonEx m_btnUPCart;
	UEasyButtonEx m_btnUPTable;
	UEasyButtonEx m_btnChangeDP;
	CProgressCtrl m_ctlOneTime;
	CProgressCtrl m_ctlTotalTime;
	UEasyButtonEx m_btnVacuumViewer;
	CListCtrl m_listLotID;
	UEasyButtonEx m_btnModifyData;
	//}}AFX_DATA

// Attributes
public:
	int	   m_nTotalLotCount;
	int	   m_nDrillCountForCheckTotalLot;
	double m_dTargetTemper;
	double m_d1stTemper;
	double m_d2ndTemper;
	double m_d1stSBTemper;
	double m_d2ndSBTemper;
	double m_dScal1stTemper;
	double m_dScal2ndTemper;
	double m_dScal1stSBTemper;
	double m_dScal2ndSBTemper;
	double m_dMeasureStartTemper;
	BOOL	m_bChangePanelInfo;
	int		m_nBackupSeparation;// FindFiducial ���ʸ� ���н� ��� ���� 
	//20111107
	double	m_dLengthStrech[2][2];// 20130404 bhlee
	double	m_dLengthStrechLimit;
	BOOL	m_bPCBReject;
	BOOL	m_bRetryFidFind;// 20130404 bhlee
	int		m_nFidIndexForFidShowAll; // 20130404 bhlee
	int		m_nFidBlockForFidShowAll; // 20130516 bskim
	BOOL	m_bEocardEstopAtOnceForDrillstop;
	int		m_nCurrentPrjIndex;
	int		m_nCycleCount;
	int		m_nCurrentMarkingCount;
	int		m_nNGLotCount;
//	int		m_nPrevPrjIndex;
//	int		m_nPrevMarkingCount;
	TCHAR	m_szCurrentLotID[256];
	TCHAR	m_cPrjName[255];
	BOOL	m_bShowTimeDP;
	int		m_nDrillEndTime; // ���� ��ƾ ������� �ð��� �帧. ���� �ð� �� dummyshot ���Ḧ ����.
	int		m_nDrillOneBoardEndTime;//  �µ������� ����
	int		m_nLilyStartTime; // �µ� ������ ����
	CCorrectTime	m_StandbyTime;
	CCorrectTime	m_VaccumTime;
	BOOL	m_bStartVacuumTime;
	int		m_nChillerErrorCount;
	int		m_nUserLevel;
	int		m_nPreworkStep;
	CString m_strUserID;
	BOOL	m_bCalFidPosWithFirst2Point;
	int	    m_nUseFastFidFindMode;//20171222
	int	    m_nFastFidFindIndex;//20171222

	CalAGC m_calAGCMaster;
	CalAGC m_calAGCSlave;
	TCHAR	m_cDownASC[256];
	CCalibrationPath* GetMasterPath()	{return &m_CalMasterPath;};
	CCalibrationPath* GetSlavePath()	{return &m_CalSlavePath;};
	
	CCalibrationPath m_CalMasterPath;
	CCalibrationPath m_CalSlavePath;
	
	double m_dMaxOffsetMasterX;
	double m_dMaxOffsetMasterY;
	double m_dMaxOffsetSlaveX;
	double m_dMaxOffsetSlaveY;
	double m_dMaxOffsetMasterR;
	double m_dMaxOffsetSlaveR;
	double m_dCalculateStartXAuto;
	double m_dCalculateStartYAuto;
	
	BOOL m_bNeedUnload;
	BOOL m_bEndBoard;
	CString m_strPLCAlarmLogFile;
	CDlgLaserMeasurement m_dlgMeasurement;
	CDlgLaserMeasurement m_dlgOPCWait;
	BOOL		m_bTextTool;
	int			m_nDummyDP;
	DPOINT		visionResult;
	DPOINT		m_dOffsetM, m_dOffsetS;

	void		InitBtnControl();
	void		InitStaticControl();
	void		InitListControl();

	void		OnCamChange(int nCamNo);
	void		OnMoveVisionView();
	
	int			m_nUVTriggerMode; // 20090629 Front Mode error
	int			m_nTimeCheckTrigger;

	DAreaInfo *m_pLPCAreaInfo;
	int				m_nLPCSubToolNo;
	BOOL		m_bLPCStartField;
	BOOL		m_bLPCDontGetYet;
	BOOL		m_bInit;
	BOOL		m_bLaser;
	BOOL		m_bOdd;
	BOOL		m_bAutoRun;
	BOOL		m_bSelectFire;
	BOOL		m_bShotDrill;
	BOOL		m_bBarcodeTool;
	BOOL		m_bFlyingTool;
	BOOL		m_bUserStop;
	BOOL		m_bDrillPause;
	BOOL		m_bOneCycleStop;
	BOOL		m_bOneCycleStopNoUnloadPause;
	BOOL		m_bOldMelsec;
	int			m_nMelsecCount;
	int			m_nSettingLotCount;
	int			m_nInputLot;
	int			m_nCurrentLotCount; // lot���� ���� ���� �� (������)
	int			m_nTotalCurrentLotCount; // ��ü �����ٸ����� ��Ż ���� ���� ��
	int			m_nCurrentLotIndex; // lot index 0 ~ 9i
	int			m_nAutoStartLotIndex;
	BOOL	m_bHaveToChangeProject;
	int			m_nListCount;
	int			m_nAutoLotCount;
	int			m_nMarkingLotCount;
	int			m_nTotalHoleCount;
	int			m_nTotalLineCount;
	int			m_nLotHoleCount;
	int			m_nLotSelectHoleCount;
	int			m_nVisionCompenCount; // ���� ���� ī��Ʈ
	int			m_nLotLineCount;
	int			m_nRealFiredHoleCount;
	int			m_nRelaFiredLineCount;
	int			m_nLotMarkStartNo;
	int			m_nLotMarkCurrent;
	int			m_nErrMsgID;
	BOOL		m_bMissFire;
	BOOL		m_bFireDataDoing;
	double		m_dAvgScaleX;
	double		m_dAvgScaleY;
	double		m_dAvgScaleXBackup;
	double		m_dAvgScaleYBackup;
	double		m_dCurrentScaleX[2];
	double		m_dCurrentScaleY[2];
	void		SetErrMsg();
	BOOL		m_bFirstSCal;
	BOOL		m_bForcePrework;

	int			m_nTotalBarHoleNo;
	int			m_nTotalTextHoleNo;
	
	CColorStatic m_stcBarcodeM;
	CColorStatic m_stcBarcodeID;
	CColorStatic m_stcBarcodeS;

	CColorStatic m_stcBarcodeData;

	BOOL m_bPrework;

	CCorrectTime m_pStepTime;
	CCorrectTime m_pOneCycleTime;
	CCorrectTime m_pDrillTime;
	CCorrectTime m_pMarkingTime;
	CCorrectTime m_pMarkingAvgTime;
	CCorrectTime m_pLineDummyTime;


	CCorrectTime m_pLoadUnloadTime;
	CCorrectTime m_pPowerTime;
	CCorrectTime m_pFireDrillTime;
	CCorrectTime m_pThickMeasureTime;
	CCorrectTime m_pFindFiducialTime;
	CCorrectTime m_pSCalTime;

	double m_dLoadUnloadTime;
	double m_dPowerTime;
	double m_dFireDrillTime;
	double m_dThickMeasureTime;
	double m_dFindFiducialTime;
	double m_dSCalTime;

	BOOL	m_bNextAlign;
	BOOL	m_bAutoTimeStart;
	int		m_nAlignTime;
	double  m_dAvrProcessTime;
	double	m_dAvrTime;
	double	m_dPriTime;
	double	m_dLotTime;
	double	m_dAvgMarkingTime;
	int		m_nAOMAlarmCnt;
	BOOL	m_bTimer1;
	BOOL	m_bTimer2;
	BOOL	m_bTimer3;
	BOOL	m_bTimer4;
	BOOL	m_bTimer5;
	TCHAR	m_c2DContents[255];

	LONG m_lErrorIo1New;
	LONG m_lErrorLoad1New;
	LONG m_lErrorLoad2New;
	LONG m_lErrorLoad3New;
	LONG m_lErrorUnload1New;
	LONG m_lErrorUnload2New;
	LONG m_lErrorUnload3New;
	LONG m_lErrorTableLimit1New;
	LONG m_lErrorOtherLimit1New;
	LONG m_lErrorLaser1New;
	LONG m_lErrorOthers1New;
	LONG m_lErrorOthers2New;
	LONG m_lErrorOthers3New;
	LONG m_lErrorOthers4New;
	LONG m_lErrorOthers5New;
	LONG m_lErrorOthers6New;
	LONG m_lErrorTable1New;
	LONG m_lErrorMelsecMainNew;
	LONG m_lErrorMelsecLoaderNew;
	LONG m_lErrorMelsecUnloaderNew;
	LONG m_lErrorMelsecEtc1New;
	LONG m_lErrorMelsecEtc2New;

	LONG m_lErrorIo1Old;
	LONG m_lErrorLoad1Old;
	LONG m_lErrorLoad2Old;
	LONG m_lErrorLoad3Old;
	LONG m_lErrorUnload1Old;
	LONG m_lErrorUnload2Old;
	LONG m_lErrorUnload3Old;
	LONG m_lErrorTableLimit1Old;
	LONG m_lErrorOtherLimit1Old;
	LONG m_lErrorLaser1Old;
	LONG m_lErrorOthers1Old;
	LONG m_lErrorOthers2Old;
	LONG m_lErrorOthers3Old;
	LONG m_lErrorOthers4Old;
	LONG m_lErrorOthers5Old;
	LONG m_lErrorOthers6Old;
	LONG m_lErrorTable1Old;
	LONG m_lErrorMelsecMainOld;
	LONG m_lErrorMelsecLoaderOld;
	LONG m_lErrorMelsecUnloaderOld;
	LONG m_lErrorMelsecEtc1Old;
	LONG m_lErrorMelsecEtc2Old;

	CTime m_ctStart;
	CTime	m_ctMarkingContentsStartTime;

	BYTE m_bModeNew;
	BYTE m_bModeOld;

	BOOL m_bStopField;
	int  m_nStopField;

	double m_dTableTime;
	double m_dScannerTime;
	double m_dFiducialTime;
	CCorrectTime myTableTime;
	BOOL m_bCheckZMC;
	BOOL m_bCheckMC;

	double		m_dMeasuredPower[2];

	double		m_dRefLeght;
	double		m_dTransLeght;

	BOOL		m_bStartCheckComponentTime;		//20110604
	
	BOOL		m_bWorkingAutoSCal;  //������ 
	BOOL		m_bWorkingAutoPreheat;

	BOOL		m_bDoAutoSCal; //Ÿ�̸ӿ� ���� ���� cmd
	BOOL		m_bDoAutoPower;
	BOOL		m_bDoAutoPreheat;

	BOOL		m_bAnyDoAutoSCal; //�׹��� ���ǿ� ���� ���� cmd (  drill ���� prework ����� ���Ǵ� ���� )
	BOOL		m_bAnyDoAutoPower;
	BOOL		m_bAnyDoAutoPreheat;

	BOOL		m_bPrePreheat; //��뿩�� ���� 
	BOOL		m_bPreScanner;

	int			m_nASCCount; //Prework - Scal�� ������ Ƚ�� 
	BOOL		m_bASCTool[BEAMPATH_COUNT];
	BOOL		m_bPowerTool[BEAMPATH_COUNT];
	int			m_nDoASCTool;
	BOOL		m_bRunThreadEnd;
	CWinThread* m_pCheckPreTimeThread;
	CWinThread* m_pCheckDrillThread;
	CString		m_strErrorPlus;

	DPOINT	m_dpFindFiducialPos; //table pos 
	DPOINT	m_dpFindFiducialPos2; 
	BOOL	m_bUiAlivePulse;
	int		m_nNGBoxCondition; //20130502 bskim 
	double	m_dPower; // for Temperature Compensation
	BOOL m_bAlreadyLoading;

	int		m_nChekedCount;

	int		m_nLaserWaringCnt;
	int		m_nLaserOverTempCnt;
	BOOL	m_bLaserWaringOld;
	BOOL	m_bLaserOverTempOld;
	C2DTransform m_2DTrans1stForTempCompen[BEAMPATH_COUNT];
	C2DTransform m_2DTrans2ndForTempCompen[BEAMPATH_COUNT];
	int		m_nTempCompenCurrentLotCount;
//	BOOL m_bFirstFire;  // ó�� �����϶� AlignEnd �Ⱥ��� �ٷ� Loading �ϱ� ���� 
	// 0 = No NG
	// 1 = Master NG
	// 2 = Slave NG
	// 3 = Dual NG
//	BOOL		m_bIdleStatus; 
	// IdleOff �� LaserOn,ShutterOpen,AomOn,MotorInitialized���¿��� Mainȭ��(Drill)���� ��ȯ�ϴ� ��� IdleOn�� ���.
	// IdleOn���¿����� Mainȭ�鿡�� �ٸ� ȭ������ ��ȯ �Ұ����ϸ�, IdleOff�� �ؾ���.
	// IdleOn���¿��� ������ �ð��� �Ǹ� ScannerCalibration�� PowerMeasurement�� �ڵ� ������ �Ǹ�,
	// IdleOff���¿��� ������ �ð��� �Ǿ� SCal�� PowerMeasure������ �Ǹ� ���� ���ο� ���� �޼����� ��.
	
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif

	CDlgVacuumViewer	m_dlgVacuumViewer;

	FParameter  m_NewParameter;

	//AutoRun Viewer
	CFont		m_fntTab;
	USimpleTab	m_tabAutoRunView;
	CPaneAutoRunViewFiducial* m_pFiducial;
	CPaneAutoRunViewPrework* m_pPrework;
	CPaneAutoRunViewProcess* m_pProcess;
	CPaneAutoRunViewSystem* m_pSystem;
	CPaneAutoRunViewData* m_pData;	
	CPaneAutoRunViewStatus* m_pStatus;
	CPaneAutoRunViewOPC* m_pOPC;

	BOOL		m_bManualMeasurePower;
	BOOL		m_bCheckTablePCB;

	CDlgInputTemp * m_pDlgInputTemp; //2015.11.30

	double m_dNewDutyOffset[SHOT_COUNT];
	double m_dDeltaDuty;
	double m_dOldPower;
	int		m_nSelectShotIndex;
// Attribute
protected :
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	CFont		m_fntStaticBig;
	CFont		m_fntStaticSmall;
	CFont		m_fntList;

	BOOL		m_bMotor;
	BOOL		m_bScanner;
	BOOL		m_bScannerOld;
	BOOL		m_bLaserPowerOld;
	BOOL		m_bVision;
	BOOL		m_bMainPower;
	BOOL		m_bEStop;
	BOOL		m_bTableSuction;
	BOOL		m_bTableSuction2;
	BOOL		m_bFluorescentLamp;
	
	int			m_nTimerID1;
	int			m_nTimerID2;
	int			m_nTimerID3;
	int			m_nTimerID4;	//201164 system component�� 
	int			m_nTimerID5;

	double		m_dPosZ1New;
	double		m_dPosZ1Old;
	double		m_dPosZ2New;
	double		m_dPosZ2Old;
	int			m_nMask1Old;
	double		m_dPosC1Old;
	double		m_dPosC2Old;
	BOOL		m_bMoveXYMC;
	double		m_dCurrent;
	int			m_nthermal;

	BOOL		m_bCheckTablePos;
	BOOL		m_bCheckAPos;

	BOOL		m_bOldResetSwitch;

	int			m_nWarningNo[4];
	int			m_nAlarmNo[4];
	int			m_nMaxValue[4];
	int			m_nInposMissNo[4];

	int			m_nHoleAreaIndex[9];
	DPOINT		m_dpHoleTablePos[9][9][2];
	CPoint		m_cpHolePos[9][9][2];// [area] [hole] [pnl]
	DPOINT		m_dpHoleOffset[9][9][2]; // [area] [hole] [pnl]
	BOOL		m_bHoleFindOK[9][9][2]; 
	double		m_dOffsetStartXAuto;
	double		m_dOffsetStartYAuto;
	BOOL		m_bUseManualDrillDummy;
	int			m_nMotorInitialCount;

	BOOL		m_bBasketLDIn;
	BOOL		m_bBasketUDIn;
	BOOL		m_bOldBasketLDIn;
	BOOL		m_bOldBasketUDIn;	
	BOOL		m_bBasketLDOut;
	BOOL		m_bBasketUDOut;
	BOOL		m_bOldBasketLDOut;
	BOOL		m_bOldBasketUDOut;	
	BOOL		m_bReadAddress;
	BOOL		m_bAlignCommandDoneAfterLoading;
	int				m_nTooSumInfo[MAX_TOOL_NO];
	double		m_FidMoveX[4];
	double		m_FidMoveY[4];
	double		m_FidMove2ndX[4];
	double		m_FidMove2ndY[4];

	double		m_FidMoveOffset1stX[4];
	double		m_FidMoveOffset1stY[4];
	double		m_FidMoveOffset2ndX[4];
	double		m_FidMoveOffset2ndY[4];


// Operations
public:
	BOOL IsSameLineTool(int nToolNoRef, int nToolNo);
	void GetLineToolSumInfo(DAreaInfo *pAreaInfo);
	int GetSameSubIndx(int nTool, int nSubIndex, int nEndIndex);
	int DownloadSumSubToolDataToEocard(int nTool, int nSubIndex, int nEndIndex);
	BOOL GetCurrentLotIndex();
	void GetVisionCompenCount();
	BOOL		SaveRawFile();
	BOOL GetRepeatCompenTransResult(int nX, int nY, BOOL b1st, int& nResultX, int& nResultY, int nBeamPathNo);
	void ResetLotCountAndData();
	BOOL WaitOPCRecvMessage();
	void ResetOPCRecvMessage();
	BOOL SubDoLoading(BOOL b1st, BOOL b2nd);
	BOOL SubDoUnloading(BOOL b1st, BOOL b2nd);
	double GetAvgPower();
	BOOL SetAutoTemperature(BOOL bStartT);
	BOOL WaitTargetTToDown();
	BOOL WaitDownTemp(int nTimeSec);
	void CheckBasketInOut();
	void GetSubToolParam(SUBTOOLDATA subTool, int nToolNo, int nSubToolNo);
	void OPCUpdateParameter(int nType);
	BOOL GetLPCDataAndSave(DAreaInfo *pAreaInfo, BOOL bOnlyErrorStop, int nSubToolNo);
	void UpdateOPCDisplay(BOOL bClear = FALSE);
	BOOL OPCBasket(BOOL bIn, BOOL bLoad, char* szBasketID);// OPC Basket & Panel in/out
	void OPCEvent(BOOL bLoad, BOOL bFirstEnd);// OPC Event(panel in/out info)
	void OPCStatus();
	BOOL WaitRearchTargetT();
	BOOL InitStartTemperCompen();
	BOOL MakeTemperCompenFile();
	BOOL CheckOffsetForTemperCompensation(int nRepeatNo, int nFireAndFindMode, int nTempStep);
	BOOL HeatingScannerBlockUsingIdleInfo(int nRepeat, BOOL& bEndStep, int nDuty);
	BOOL CheckChangePanelInfo(BOOL b1st, BOOL b2nd, int nFidBlock, BOOL bApply);
	int	 GetFirstBeamPath();
	void ResetScale();
	BOOL IdleShotProcess();
	int	 GetFidRectPosIndex(int nCenterX, int nCenterY,	LPFIDDATA pFidData);// 20130404 bhlee
	BOOL CheckVisionHeadOffset();
	void CalculateAvgScale();
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	void ChangeDiffFidStartPos();
	BOOL GetHeadOffset(int nHeadSel);
	void SaveFidCompensation(BOOL b1st, int nFidBlock, double dAvgScaleX, double dAvgScaleY, double* dScale, int* nLRTB,  CDPoint* dRefPos, CDPoint* dFindPos, int nLogTime);
	void SetProportaionOffset(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB);
	BOOL SetProportaionScale(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB, double dAvgScaleX, double dAvgScaleY, double* dScale);
	BOOL SetProportaionAngle(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB, double* dScale, BOOL bNoTrans);
	BOOL SetProportaionCompensation(BOOL b1st, int nFidBlock, double dAvgScaleX, double dAvgScaleY, double* dScale, int* nLRTB, BOOL bOnlyLog = FALSE);
	void SetNeedUnload(BOOL bNeed);
	BOOL GetNeedUnload();
	void SaveHoleFindResult(int nUseBeamPath);
	BOOL FindOneHole(int nTool, int nUseBeamPath, DAreaInfo* pAreaInfo, int nAreaIndex, int nHoleIndex, int nMasterX, int nMasterY, int nSlaveX, int nSlaveY);
	BOOL FindOneHole_2ndVer(int nTool, int nUseBeamPath, DAreaInfo* pAreaInfo, int nAreaIndex, LPFIREHOLE pHole);

	

	BOOL FindArea(int nTool, int nUseBeamPath, int nAreaIndex[]);
	BOOL FindArea_2ndVer(int nTool, int nUseBeamPath);

	void FindNearAreaFiducial(int nToolNo, int nAreaIndex[]);
	void FindNearHole(int nTool,int nAtArea, DAreaInfo *pAreaInfo);
	BOOL HoleFind();
	BOOL HoleFind_2ndVer();
	void ChangeBMPtoJPG();
	void SaveSCalResult();
	void ChangeBMPToJPG_Once(CString strFile);
	void DoFidImageWork();
	void DeleteAll_IMGFile(CString strFilePath, int nDay);
	void ChangeDP();
	void ChangeLotIDInfo();
	BOOL AutoOpenProject(BOOL bCompare = TRUE);
	int GetCurrentLotID(CString& strLotID1, CString& strLotID2, CString& strPrj1, CString& strPrj2);
	void WriteDrillParam();
	void ResetScannerErrorCnt();
	void SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
						int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
						int ndiff, int nJobType);
	void GetBeamPathLaserInfo( SUBTOOLDATA &subTool);
	void RemoveOldFidImage();
	void SaveFiducialImg(int nCamNo, int nFidNo);
	void SaveFailFiducialImg(int nCamNo, int nFidNo);
	void MoveScaleLog();
	void TurnOffAllLaserDevice();
	void SetAuthorityByLevel(int nLevel);
	BOOL WaitPrework();
	BOOL AOMAlarmCheck();
	BOOL CalFidPosWithFirst2Point(C2DTransform* pTrans, C2DTransform* pTrans2);
	BOOL FireOneSkivingFiducial(LPFIDDATA pFidData);
	BOOL SkivingFire(BOOL bCheckAlreadyFire);
	BOOL FindOneSkiveFiducialBeforeFire(LPFIDDATA pFidData, BOOL bAfterFire,LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, int nFidNo = -1, int nFidBlock = -1);
	BOOL FindOneVerifyFiducial(LPFIDDATA pFidData, BOOL bAfterFire,LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, int nFidNo = -1, int nFidBlock = -1);
	BOOL VerifyFiducialOrRecheckFidAfterFire(BOOL bAfterFire);
	
	BOOL InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave);
	BOOL m_bUserDummyOn;  // Use First Order �� �ƴҶ� dummyshot�� �����ϰ�, first order�� drill start ���� ���̼� ��Ȳ�� �����Ѵ� (������ �Ѵ¹���)
	BOOL DoStandby(double dDiffTime);
	int DoOneCyclyStopNoUnloadPause();
	void DrillOneCycleNoUnloadPause();
	BOOL FindOneFiducial(LPFIDDATA pFidData, int nFidNo, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd);
	BOOL ChangeVisionAllParam(int nCamNo, LPFIDDATA pFidData);
	BOOL GetFidPosInCenter(double dX, double dY, double dZ1, double dZ2,  BOOL b1stPanel, BOOL bHighCam, LPFIDDATA pFidData, double dRetryX, double dRetryY);
	void SendFindTrigger(BOOL& b1stFound, BOOL& b2ndFound, BOOL bHighCam, BOOL b1stSkip, BOOL b2ndSkip, 
						LPFIDDATA pFidData, double dFinalMoveX, double dFinalMoveY, CDPoint& dptResult1st, CDPoint& dptResult2nd,
						int nFidIndex,
						double dHead1stOffsetX, double dHead1stOffsetY, double dHead2ndOffsetX, double dHead2ndOffsetY, int nFindCount);
	BOOL GetFidPosHighCamInCenter(BOOL b1stPanel, LPFIDDATA pFidData);
	BOOL BusyCheck();
	void ScannerWamup();
	void SaveScalTime(BOOL b1st);
	BOOL DownloadASC();
	void GetLaserParam(SUBTOOLDATA &subTool);
	BOOL DownScalParam();
	BOOL ControlDeviceForScal(BOOL bStart);
	BOOL UpdateNewParam(SUBTOOLDATA subTool, int nPulseNo = 0);
	BOOL ChangeBeamPath(SUBTOOLDATA subTool, int nToolType);
	int GetPointIndex(int nCountX, int nCountY, int nDivision);
	BOOL IsUserStop();
	int GetMaskNo();
	int GetDivision();
	void WriteCalibrationStopEvent(BOOL bFinish = FALSE);
	
	BOOL OnDoPowerMeasurement();
	void KillRunThread();
	BOOL OnDoPreheat();
	void SetPreworkInfo();
	void ChangeView(int nChangePane, BOOL bCapture = FALSE);
	void InsertFidList(int nLotNo);
	void InsertFidResult(BOOL b1stPanel, CPoint npFile, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, double dVal1 = 0, double dVal2 = 0);
	void ScaleAndLength(int nFidBlock, double* dScale, double dLenghStrech1, double dLenghStrech2, BOOL bMaster, LPPNLFIDINFO pPanel1st = NULL, LPPNLFIDINFO pPanel2nd = NULL);
	BOOL GetAutoRun();
	void CheckTab();
	void InitAutoRunViewer();
	BOOL ManualFidFind(double dPosX, double dPosY, int nFidKind, BOOL bNoMove = FALSE);
	void CalRefFidPos(double &PosX, double &PosY);
	void CreateFidResult(LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd);
	void ResetFidResult(LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, int nFidBlock, int nFidKind);
	void CheckComponentTime();
	void GetOnlyMarkingAvgTime();
	BOOL CalLength(BOOL bLog, int nFidKind, int nFidBlock, LPPNLFIDINFO pPanel1st = NULL, LPPNLFIDINFO pPanel2nd = NULL);
	BOOL SavePowerAuto(double d1stMeasureResult, double d2ndMeasureResult, double dZ1, double dZ2, int nMask, int nFrequency, double dDuty, double dAOMDelay, double dAOMDuty);
	BOOL CheckPowerAuto();
	BOOL CheckPowerAuto_Compen();
	BOOL DoSCalAuto(BOOL bDryRunCheck, BOOL bGetHeadOffset = FALSE, int nFireMode = -1, int nFireAndFindMode =  T_OFFSET_FIRE + T_OFFSET_FIND); // firemode = -1 : 9 by 9 cal, 1 : center fire and check head offset, 4 : 4 edge check and log
	void CalculateAutoStartPosition(BOOL bOnlyCenterPointFire);
	void CalculateVisionStartPosition(BOOL bOnlyCenterPointFire);
	BOOL CheckMotorPositionValidity(BOOL bUseLowCam, BOOL bOnlyCenterPointFire);
	BOOL IsOutOfAxisValidity(int nAxis, double dVal);
	BOOL DoFindPreviousHole(BOOL bUseLowCam, BOOL bOnlyCenterPointFire);
	BOOL DoFireCalibrationHole(int nSelHead, BOOL bUseLowCam, BOOL bGetHeadOffset, BOOL bOnlyCenterPointFire, int nFireMode = -1);
	BOOL DoFindCurrentShot(BOOL bUseLowCam, BOOL bDryRunCheck, int nFireMode);
	
	bool FireCalibrationHole(bool bFire = true, bool b1st = true, BOOL bGetHeadOffset = FALSE, BOOL bOnlyCenterPointFire = FALSE, int nFireMode = -1);
	bool FindPreviousShot(double dZ1, double dZ2, emHEAD emHead = emMaster);
	bool FindPreviousShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd);
	
	bool FindCurrentShot(double dZ1, double dZ2, int nFireMode, emHEAD emHead = emMaster, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);
	bool FindCurrentShot(double dZ1, double dZ2, int nFireMode, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);
	bool FindShot(double dZ1, double dZ2, int nFireMode, emHEAD emHead = emMaster, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);
	bool FindShot(double dZ1, double dZ2, int nFireMode, emHEAD em1st, emHEAD em2nd, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);
	
	BOOL ChangeOneSubToolCheckInposition();
	BOOL InpositionCheckAll(DAreaInfo *pAreaInfo);
	void ChangeShotDrillInfo(int nTool);
	void DestroyTimer();
	BOOL IsGoodFireCount();
	CString GetCountString(int nNo);
	void ChangeProjectInfo(BOOL bOnlyCount = FALSE);
	void DrawDoingFireField();
	BOOL DownloadLaserOneSubTool(int nTool, int nSubIndex);
	BOOL OnlyTransform(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK);
	BOOL ApplyFidDataToShot(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode = FALSE);
	BOOL CheckFoundFidValid(int nFidKind, int nFindMethod, int nFidBlock, BOOL& bReChange, BOOL& b1stOK, BOOL& b2ndOK, LPPNLFIDINFO pPanel1st = NULL, LPPNLFIDINFO pPanel2nd = NULL);
	CDPoint GetNextStepIndex(int nStepNo);
	BOOL ChangeOneSubTool(int nTool, int nSubIndex, BOOL bLineToShot = FALSE);
	BOOL DownloadOneSubTool(int nTool, int nSubIndex, BOOL bLineToShot = FALSE);
	BOOL CheckFidTransResultForSample(DAreaInfo *pAreaInfo, int nFidBlock);// 20130312
	BOOL OneFieldFire(DAreaInfo* pAreaInfo, DAreaInfo* pNextAreaInfo, BOOL bSkive, int nFidBlock, BOOL bLogHole, int nFieldCount);
	BOOL InPositionCheck();
	BOOL DownloadFirstToolFireInformData(DAreaInfo *pAreaInfo, BOOL bSkive);
	BOOL MoveIO();
	BOOL DownloadFirstToolMotorPos(DAreaInfo* pAreaInfoOld, DAreaInfo* pAreaInfo, BOOL bSkive);
	BOOL MoveLaserBeamPath(DAreaInfo *pAreaInfo, BOOL bSkive);
	BOOL IsAvailableArea(DAreaInfo* pAreaInfo, int nToolNo, int nFidBlock);
	BOOL FireBoard(BOOL bSkive, int nFidBlock);
	BOOL FindFiducialAndApply(int nFidKind, int nFindMethod, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd);
	BOOL CheckSelectedFiducial(int* nFidBlockArray);
	BOOL DrillOneBoard();
	BOOL PCBReject();

	void DrillStart();
	BOOL SuctionCheck(BOOL bWait = FALSE);

	BOOL ThickMeasurement();
	
	void DrillOneCycle();
	void DrillPause();
	void DrillStop();
	void SetUserStop(BOOL bStop);

	void SetAutoRun();

	BOOL CheckStatus();
	BOOL IsDrilling();
//	BOOL IsIdleStatus();
	BOOL GetLotCntAndMarkIndex(BOOL bDrillStart, BOOL bLotCountSetting = FALSE, BOOL bAutoDataLoad = FALSE, int nCount = 36);

	void ProgressInitial();
	void SetProgress(BOOL bFlag);
	void SetCycleTime(int nLot);
	void SetDrillTime();
	void SetPresentDrillTime();
	void CalcProductTime();
	void GetTime(double dTime, LONG& lHour, LONG& lMin, LONG& lSec);
	void MakeReadableNumber(CString& strVal);

	void ReadStatus();
	void ReadDeviceError();
	void UpdateLed();

	void ReadErrorIo1();
	void ReadErrorLoad1();
	void ReadErrorLoad2();
	void ReadErrorLoad3();
	void ReadErrorUnload1();
	void ReadErrorUnload2();
	void ReadErrorUnload3();
	void ReadErrorTableLimit1();
	void ReadErrorOtherLimit1();
	void ReadErrorLaser1();
	void ReadErrorOthers1();
	void ReadErrorOthers2();
	void ReadErrorOthers3();
	void ReadErrorOthers4();
	void ReadErrorOthers5();
	void ReadErrorOthers6();
	void ReadErrorTable1();
	void ReadErrorMelsecMain();
	void ReadErrorMelsecLoader();
	void ReadErrorMelsecUnloader();
	void ReadErrorMelsecEtc1();
	void ReadErrorMelsecEtc2();

	void InitTimer();

	BOOL WaitHandler(int nCmd, BOOL b1st = TRUE, BOOL b2nd = TRUE);

	void WriteLotLog(BOOL bStartLot = FALSE);
	void GetTime(double dTime, int& nHour, int& nMin, int& nSec);

	BOOL CheckPCBExist();
	BOOL DoLoading(BOOL bEndLot, CPaneAutoRun* pRun);
	BOOL DoUnloading(BOOL bEndLot);
	BOOL IsPCBOnTable();
	
	BOOL CheckLoaderPCBStatus();

	BOOL DustSuction();
	
	void MessageLoop();

	void CheckResetSwitchAndTableSuction();
	
	void ShowDetailInformation();
	void SaveFiducialScale(int nUseFidCount, CDPoint* dRefPos, CDPoint* dFindPos,  double* dAvgScaleX, double* dAvgScaleY, BOOL* bScaleOK, double* dLengthStrechX, double* dLengthStrechY, double* dDiagonal,int nBlockNo);
	
	void StartRunThread();
	void CheckOmiVisionConnect();

	BOOL NGBoxCheck(int nNGCondition);
	int FindSameFidPosIndexAndApply(LPFIDDATA& pFidData, int nAddProperty, int nDelProperty, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd);
	void ChangeAllSameFidResult(LPFIDDATA pFidData, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd);
	void CheckVaccumMotor();
	void CheckAbsoluteScale(BOOL& bScaleOK);
	void ScannerWarmup();
	BOOL IsSkipVisionCompen(); 
	double	CalculateAverageOnePower(double dPower[]);
	BOOL		CheckCompensationRepeat(double dMeasureResult, int nPulseNo, int nHead );
	BOOL		CheckCompensationLimit(double dMeasureResult, int nPulseNo);
	double	GetCompensationOffset(BOOL bMaster,int nRepeatCnt, double dCurrentPower, BOOL bFirst, int nPulseNo);
	void		SaveOffset_AutoPowerCompen(BOOL bMaster,int nMask);
	void		SaveAutoPowerCompenTime();
	BOOL		PowerCompenCheck();
	BOOL		PowerCompenEndTimeCheck(int nMask);
	BOOL		SavePowerAuto_Compen(double d1stMeasureResult[], double d2ndMeasureResult[], double dZ1, double dZ2, int nMask, int nFrequency, double dDuty, double dAOMDelay, double dAOMDuty, double dMinPower, double dMaxPower);
	void        GenerateMarkingContents();
	BOOL LowCamCheck();
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRun)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRun();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRun)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonVacuumViewer();
	afx_msg void OnButtonClear();
	afx_msg void OnButtonProductCounterClear();
	afx_msg void OnButtonLotInput();
	afx_msg void OnDestroy();
	afx_msg void OnChkSuction1();
	afx_msg void OnChkSuction2();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnAutoStartSetting(WPARAM wParam, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnCheckSelectRun();
	afx_msg void OnChkFluorescentLamp();
	afx_msg LRESULT ChangeVisionParam(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT ChangeVisionParameter(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT GetVisionResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROIUM(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT	AutoSaveProject(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT GetVisionResultNoGrab(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButtonLPickTable();
	afx_msg void OnButtonUPickTable();
	afx_msg void OnButtonUPickCart();
	afx_msg void OnButtonLPickCart();
	afx_msg LRESULT OnChangePower(WPARAM wParam, LPARAM lParam);
	afx_msg void OnClickListBoardParam(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickTabViewer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg LRESULT SaveVisionImg(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SaveVisionFailImg(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetVisionLamp(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetVisionLamp2(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButtonChangeDp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bCanCheckTransValid; // 20130312
	BOOL m_bPostPreWorkDoing;
	BOOL m_bUnloadStart;
	BOOL PreLoadUnloadRun(BOOL bUnloadAlign = FALSE);
	BOOL PostAlign();
	void DrillStopProcess(int nErrorID);
	BOOL VerifyTemperComp();
	BOOL PreDoPrework();
	BOOL PostDoPrework();
	BOOL DoPreHeatProcess();
	BOOL DoPreworkPowerProcess();
	BOOL DoPreworkSCalProcess(BOOL bOnlyCenterPointFire, int nMode = T_OFFSET_FIRE + T_OFFSET_FIND);
	BOOL DummyfreeOnFor2ndOrderOption();
	void SetLastBoardBit();
	BOOL DoLoadingProcess();
	BOOL DoCheckPCBThickProcess();
	BOOL CheckDummyfreeOn();
	BOOL DrillOneBoardProcess();
	BOOL DoUnloadingProcess();
	BOOL OpticShutterOpen(BOOL bOpen);
	void CalcFireTime();
	BOOL GetLotInform();
	BOOL CheckSystemForDrill();
	BOOL GetLotInformAndCheckValid();
	BOOL InitSystemForDrill();
	void InitVariableForDrill();

	void WaitEocardIdleForDrillStop();
	void InitVariableForDrillStop();
	void InitSystemForDrillStop();
	void SaveDrillDataForDrillStop();

	BOOL MoveShutterToDrillPanel(BOOL bOpen);
	BOOL FindFiducialForDrill(int nFidKind, int nFindMethod, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd );

	BOOL MoveShutterToDrillPanel(BOOL bMOpen, BOOL bSOpen);

	void GetFirePanelInfo(BOOL& b1stPanelFire, BOOL& b2ndPanelFire);
	void WriteFidOffsetData(LPFIREHOLE pHole, int nTableX, int nTableY);
	void SaveBarcodeContents(CString strBarcodeContents, int nPanelNo); //2015.12.17
	int DownloadBarcodeData(int nTool, CDPoint ptMaster, CDPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL bMaster = TRUE, int nArrayNo = 0);
	void WriteTablePosition(double dX , double dY, double dZ1, double dZ2, double dM2, double dM3, DAreaInfo *pAreaInfo);
	int DownloadTextData(LPFIREHOLE pHole, int nTool, CDPoint ptMaster, CDPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL bMaster , int nStartCount = -1,int nDevideCount = -1);	
	int MMtoLSB(double dPos);

	BOOL IsNeedDevideOCR(LPFIREHOLE pHole, int nTool, BOOL b1stPanelFire, BOOL b2ndPanelFire , int &nDevideCount, int &nDevideSize , double &dDevideLength, int &nFinalRotation, BOOL bMaster);

	CString GetMarkingContents_UseIndex(LPFIREHOLE pHole, int nTool, CDPoint ptMaster, CDPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL bMaster = TRUE);
	CString GetMarkingContents_NewIndex(LPFIREHOLE pHole, int nTool, CDPoint ptMaster, CDPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL bMaster = TRUE);
	CString PasingOCRString(LPFIREHOLE pHole, int nTool,BOOL bMaster,CString strData,BOOL bFinal);
	CString PasingOCRIndex(LPFIREHOLE pHole, int nTool,BOOL bMaster,int nOCRIndex,BOOL bFinal);

	CString GetMarkingContentsNew(LPFIREHOLE pHole, int nTool, CDPoint ptMaster, CDPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL bMaster = TRUE);

	LPFIREHOLE GetFirstHole(BOOL bSelectOnly, BOOL bAuto);
	BOOL DrillFireAndWait(BOOL& bSubToolChangSkip, BOOL& bNextAreaPosDownNeed, BOOL& bCheckInpositionCheckAll, DAreaInfo *pAreaInfo, DAreaInfo *pNextAreaInfo, int nTool, int nDumperShotNo, BOOL bSkive, int nDrillHoleCnt, BOOL b1stTCalMove);
	BOOL WaitEocardIdle(BOOL& bNextAreaPosDownNeed, DAreaInfo *pAreaInfo, DAreaInfo *pNextAreaInfo, BOOL bSkive, BOOL b1stTCalMove);
	void DownloadLineData(LPFIRELINE pLine, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL& bShortLine, CDPoint& ptLast);
	BOOL DownloadLineToShotData(LPFIRELINE pLine, BOOL b1stPanelFire, BOOL b2ndPanelFire, int nDivideCount, double dFileDivideX, double dFileDivideY, double dDivideX1, double dDivideY1, double dDivideX2, double dDivideY2, int nToolNo, int nFieldIndex, CDPoint& ptLast);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	BOOL IsOk_BarcodeValidation(int nPanelNo, CString strContents); //2015.12.18
	CString GetBarcodeID();
	BOOL DoBarcodeValidation();
	
	afx_msg void OnClickedStaticPcbCount();
	afx_msg void OnBnClickedButtonTotalLotInput();
	afx_msg void OnBnClickedButtonLotClear();
	afx_msg void OnBnClickedButtonModifyData();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUN_H__521FA4AB_D76C_40AD_B450_8E5639289E79__INCLUDED_)
