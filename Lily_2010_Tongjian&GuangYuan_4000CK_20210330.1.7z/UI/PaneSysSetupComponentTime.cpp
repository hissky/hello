// PaneSysSetupComponentTime.cpp: implementation of the CPaneSysSetupComponentTime class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PaneSysSetupComponentTime.h"
#include "..\Model\DSystemINI.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


IMPLEMENT_DYNCREATE(CPaneSysSetupComponentTime, CFormView)

CPaneSysSetupComponentTime::CPaneSysSetupComponentTime()
	: CFormView(CPaneSysSetupComponentTime::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupTophat)

		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_hEnv			= NULL;
	m_hDbc			= NULL;
	m_hStmt			= NULL;
	m_strWorkingDir	= _T("D:\\ViaHole\\System");
	//m_strWorkingDir	= _T("D:\\EasyDriller");

	cAlarm = NULL;

	m_nPreaccTime = 0;
}

CPaneSysSetupComponentTime::~CPaneSysSetupComponentTime()
{
	if(cAlarm)
	{
		delete cAlarm;
	}
}
 
void CPaneSysSetupComponentTime::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupTophat)

	DDX_Control(pDX, IDC_BUTTON_COMPONENT_INSERT, m_btnInsert);
	DDX_Control(pDX, IDC_BUTTON_COMPONENT_DEL, m_btnDel);
	DDX_Control(pDX, IDC_BUTTON_COMPONENT_UPTATE, m_btnUpdate);
	DDX_Control(pDX, IDC_BUTTON_COMPONENT_INIT, m_btnInit);
	DDX_Control(pDX, IDC_BUTTON_ALL_COMPONENT_INIT, m_btnAllInit);
	DDX_Control(pDX, IDC_LIST_COMPONENT, m_lbComponent);
	DDX_Control(pDX, IDC_BUTTON_PREACC_TIME, m_btnPreaccTime);
	//2011602
	DDX_Control(pDX, IDC_EDIT_COMPONENT_NAME, m_edtName);
	DDX_Control(pDX, IDC_EDIT_COMPONENT_EXPIRETIME, m_edtExpireTime);
	DDX_Control(pDX, IDC_EDIT_COMPONENT_USINGTIME, m_edtUsingTime);
	DDX_Control(pDX, IDC_EDIT_PREACC_TIME, m_edtPreAccTime);

	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupComponentTime, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupComponentTime)
	ON_BN_CLICKED(IDC_BUTTON_COMPONENT_INSERT, OnButtonInsert)
	ON_BN_CLICKED(IDC_BUTTON_COMPONENT_DEL, OnButtonDel)
	ON_BN_CLICKED(IDC_BUTTON_COMPONENT_UPTATE, OnButtonUpdate)
	ON_BN_CLICKED(IDC_BUTTON_COMPONENT_INIT, OnButtonInit)
	ON_BN_CLICKED(IDC_BUTTON_ALL_COMPONENT_INIT, OnButtonAllInit)
	ON_NOTIFY(NM_CLICK, IDC_LIST, OnClickList)
	ON_BN_CLICKED(IDC_BUTTON_PREACC_TIME, OnButtonPreAccTime)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_NOTIFY(HDN_ENDTRACK, 0, &CPaneSysSetupComponentTime::OnHdnEndtrackList)
END_MESSAGE_MAP()


BOOL CPaneSysSetupComponentTime::DBConnect()
{
	SQLCHAR		InCon[255];
	SQLCHAR		OutCon[1024];
	SQLSMALLINT	cbOutCon;
	TCHAR Dir[255] = {0,};
	SQLRETURN	bRet;
	
	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;

	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;
	
	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;
	
	// Connect mdb file
	CString strDBPath;
	
	strDBPath.Format(_T("%s\\Component.mdb"), m_strWorkingDir);
	sprintf_s( Dir, 255, _T("%s"), strDBPath );

	sprintf_s( (TCHAR*)InCon, 255, _T("DRIVER={Microsoft Access Driver (*.mdb)};")
		_T("DBQ=%s;PWD=EasyEasy;"), Dir);

	bRet = ::SQLDriverConnect( m_hDbc, NULL, InCon, sizeof(InCon), OutCon, sizeof(OutCon),
		&cbOutCon, SQL_DRIVER_NOPROMPT );

	if( bRet != SQL_SUCCESS )
		return FALSE;
	
	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;
	



	return TRUE;
}

void CPaneSysSetupComponentTime::DBDisconnect()
{
	// Free Stmt Handle
	if( NULL != m_hStmt )
	{
		::SQLFreeHandle( SQL_HANDLE_STMT, m_hStmt );
		m_hStmt = NULL;
	}
	
	// Free Dbc Handle
	if( NULL != m_hDbc )
	{
		// Disconnect
		::SQLDisconnect(m_hDbc);
		::SQLFreeHandle( SQL_HANDLE_DBC, m_hDbc );
		m_hDbc = NULL;
	}
	
	// Free Env Handle
	if( NULL != m_hEnv )
	{
		::SQLFreeHandle( SQL_HANDLE_ENV, m_hEnv );
		m_hEnv = NULL;
	}


}

void CPaneSysSetupComponentTime::GetDiagonostics()
{
	int			nDiag = 0;
	SQLINTEGER	nNativeError;
	SQLCHAR		szSqlState[6], szMsg[256];
	SQLSMALLINT	nMsgLen;
	
	::SQLGetDiagField( SQL_HANDLE_STMT, m_hStmt, 0, SQL_DIAG_NUMBER, &nDiag, 0, &nMsgLen );
	
	SQLRETURN nRet;
	
	nDiag = 1;
	while( 1 )
	{
		nRet = ::SQLGetDiagRec( SQL_HANDLE_STMT, m_hStmt, nDiag, szSqlState, &nNativeError, szMsg, sizeof(szMsg), &nMsgLen );
		if( nRet == SQL_NO_DATA )
			break;
		ErrMessage( (LPCTSTR)szMsg, MB_ICONSTOP );
		nDiag++;
	}
}


BOOL CPaneSysSetupComponentTime::AddNewComponent(CString strComponent, CString strExpiryDate, CString strUsingDate, CString strTime)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}

	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	_stprintf_s(szSql, _T("Insert into Component(Component,ExpiryDate,UsingDate,SetTime) Values ('%s', %s, '%s','%s')"),
		strComponent, strExpiryDate, "0",strTime );
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();
	
	bRet = 1;
	
	return bRet;
}

BOOL CPaneSysSetupComponentTime::RemoveComponent(CString strComponent)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
 	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	_stprintf_s(szSql, _T("Delete From Component Where Component = '%s'"), strComponent);
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();
	
	bRet = 1;
	
	return bRet;
}

BOOL CPaneSysSetupComponentTime::RemoveAllComponent()
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	_stprintf_s(szSql, _T("Delete From Component"));
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );	
	DBDisconnect();	
	bRet = 1;	
	return bRet;
}

BOOL CPaneSysSetupComponentTime::UpdateComponent( CString strComponent, CString strExpiryDate,CString strBeforeCompnoent)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	
	_stprintf_s(szSql, _T("Update Component  set Component = '%s', ExpiryDate = '%s' where Component = '%s' "),
		 strComponent, strExpiryDate, strBeforeCompnoent);

	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();
	
	bRet = 1;
	
	return bRet;
}

BOOL CPaneSysSetupComponentTime::InitComponent(CString strComponent,CString strExpiryDate,CString strUsingDate,CString strTime,CString strBeforeCompnoent)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	
	_stprintf_s(szSql, _T("Update Component  set Component = '%s', ExpiryDate = '%s', UsingDate = '%s', SetTime = '%s' where Component = '%s' "),
		 strComponent, strExpiryDate, strUsingDate,strTime,strBeforeCompnoent);
	
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	bRet = 1;	
	return bRet;	
}

BOOL CPaneSysSetupComponentTime::ALLInitComponent(CString UsingDate, CString strTime)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	
	_stprintf_s(szSql, _T("Update Component set UsingDate = '%s' , SetTime = '%s' "), UsingDate,strTime);
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	bRet = 1;	
	return bRet;	
}

BOOL CPaneSysSetupComponentTime::SelectComponentList()
{
	BOOL bRet = 0;

	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}	
	
	TCHAR szSql[256] = {0, };
	TCHAR szID[256] = {0,};
	TCHAR szComponent[256] = {0,};
	TCHAR szExpiryDate[100] = {0,};
	TCHAR szSetTime[256] = {0,};
	TCHAR szUsingTime[256] = {0,};
	int  nUserLevel = 0;
	
	SQLINTEGER	nComponent;
	SQLINTEGER  nExpiryDate, nSetTime, nUsingTime;
	
	// Column Binding

	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, &szComponent, sizeof(szComponent), &nComponent );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, &szExpiryDate, sizeof(szExpiryDate), &nExpiryDate );
	::SQLBindCol( m_hStmt, 3, SQL_C_CHAR, &szUsingTime, sizeof(szUsingTime), &nUsingTime );
	::SQLBindCol( m_hStmt, 4, SQL_C_CHAR, &szSetTime, sizeof(szSetTime), &nSetTime );
	
	// Excute SQL
	_stprintf_s(szSql, _T("select Component,ExpiryDate,UsingDate,SetTime from Component"));
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}

	for(int i = 0 ; i < 50; i++)
		m_Progress[i].ShowWindow(FALSE);
	
	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		
// 		if( nDrillerLevel <= nLevel )		// �� �������� �����ϱ�
// 			AddComponentList(szID, szComponent, szExpiryDate,szUsingDate);
		AddComponentList(szComponent, szExpiryDate,szSetTime);
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	bRet = 1;	
	return bRet;
}

void CPaneSysSetupComponentTime::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitListContorl();	
	InitProgressControl();
	memset(&m_sSystemComponent, 0, sizeof(m_sSystemComponent));

	if(cAlarm == NULL)
	{
		cAlarm = new CPaneSysSetupComponentTimeAlarm;
		cAlarm->Create(IDD_DLG_SYS_SETUP_COMPONENT_TIME_ALARM,this);
	}
}
void CPaneSysSetupComponentTime::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, _T("Arial Bold"));
	
	// Group
	GetDlgItem(IDC_STATIC_COMPONENT_SET)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_NOTICE_TIME_SET)->SetFont(&m_fntStatic);

	GetDlgItem(IDC_STATIC_COMPONENT_NAME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COMPONENT_EXPIRYDATE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COMPONENT_USINGDATE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREACC_TIME)->SetFont( &m_fntStatic );

}
void CPaneSysSetupComponentTime::InitBtnControl()
{ 
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// insert
	m_btnInsert.SetFont( &m_fntBtn );
	m_btnInsert.SetFlat( FALSE );
	m_btnInsert.EnableBallonToolTip();
	m_btnInsert.SetToolTipText( _T("Insert") );
	m_btnInsert.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInsert.SetBtnCursor(IDC_HAND_1);

	// del
	m_btnDel.SetFont( &m_fntBtn );
	m_btnDel.SetFlat( FALSE );
	m_btnDel.EnableBallonToolTip();
	m_btnDel.SetToolTipText( _T("Delete") );
	m_btnDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDel.SetBtnCursor(IDC_HAND_1);

	
	// update
	m_btnUpdate.SetFont( &m_fntBtn );
	m_btnUpdate.SetFlat( FALSE );
	m_btnUpdate.EnableBallonToolTip();
	m_btnUpdate.SetToolTipText( _T("Update") );
	m_btnUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);
	
	// init
	m_btnInit.SetFont( &m_fntBtn );
	m_btnInit.SetFlat( FALSE );
	m_btnInit.EnableBallonToolTip();
	m_btnInit.SetToolTipText( _T("Init") );
	m_btnInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInit.SetBtnCursor(IDC_HAND_1);

	// Allinit
	m_btnAllInit.SetFont( &m_fntBtn );
	m_btnAllInit.SetFlat( FALSE );
	m_btnAllInit.EnableBallonToolTip();
	m_btnAllInit.SetToolTipText( _T("All Init") );
	m_btnAllInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAllInit.SetBtnCursor(IDC_HAND_1);

	// preacc time
	m_btnPreaccTime.SetFont( &m_fntBtn );
	m_btnPreaccTime.SetFlat( FALSE );
	m_btnPreaccTime.EnableBallonToolTip();
	m_btnPreaccTime.SetToolTipText( _T("Preacquaintance Time") );
	m_btnPreaccTime.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPreaccTime.SetBtnCursor(IDC_HAND_1);

}
void  CPaneSysSetupComponentTime::InitEditControl()
{
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
	m_edtName.SetFont( &m_fntEdit );
	m_edtName.SetForeColor( BLACK_COLOR );
	m_edtName.SetBackColor( WHITE_COLOR );
//	m_edtName.SetReceivedFlag(  );
	m_edtName.SetWindowText( _T("") );

	m_edtExpireTime.SetFont( &m_fntEdit );
	m_edtExpireTime.SetForeColor( BLACK_COLOR );
	m_edtExpireTime.SetBackColor( WHITE_COLOR );
	m_edtExpireTime.SetReceivedFlag( 3 );
	m_edtExpireTime.SetWindowText( _T("") );

	m_edtUsingTime.SetFont( &m_fntEdit );
	m_edtUsingTime.SetForeColor( BLACK_COLOR );
	m_edtUsingTime.SetBackColor( WHITE_COLOR );
//	m_edtUsingTime.SetReceivedFlag( 3 );
	m_edtUsingTime.SetWindowText( _T("") );

	m_edtPreAccTime.SetFont( &m_fntEdit );
	m_edtPreAccTime.SetForeColor( BLACK_COLOR );
	m_edtPreAccTime.SetBackColor( WHITE_COLOR );
	m_edtPreAccTime.SetReceivedFlag( 3 );
	m_edtPreAccTime.SetWindowText( _T("0") );


}
void  CPaneSysSetupComponentTime::InitListContorl()
{
	m_fntList.CreatePointFont(130, "Arial Bold");
	m_lbComponent.SetFont( &m_fntList );
	
	m_lbComponent.InsertColumn(0, _T("Device"), LVCFMT_CENTER, 160);
	m_lbComponent.InsertColumn(1, _T("ExpiryDate"), LVCFMT_CENTER, 100); 
	m_lbComponent.InsertColumn(2, _T("StartDate"), LVCFMT_CENTER, 120);
	m_lbComponent.InsertColumn(3, _T(""), LVCFMT_CENTER, 120);
	m_lbComponent.ModifyStyle(LVS_TYPEMASK, LVS_REPORT);
	
}

void  CPaneSysSetupComponentTime::InitProgressControl()
{
	CRect rt;
			
	for(int i = 0; i< 50; i++ )
	{
		m_lbComponent.GetSubItemRect(i, 3, LVIR_BOUNDS ,rt);
		m_Progress[i].Create(PBS_SMOOTH | WS_CHILD | WS_VISIBLE | WS_EX_TOPMOST ,rt, CWnd::FromHandle(m_lbComponent.m_hWnd), 1);
		m_Progress[i].ShowWindow(SW_HIDE);
		m_Progress[i].SetRange(0, 100);
		m_Progress[i].SetWindowPos(CWnd::FromHandle(m_lbComponent.m_hWnd), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
	}
}

HBRUSH CPaneSysSetupComponentTime::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_COMPONENT_SET)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_NOTICE_TIME_SET)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupComponentTime::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntListBox.DeleteObject();
	m_fntList.DeleteObject();
	
	CFormView::OnDestroy();
}


void CPaneSysSetupComponentTime::OnButtonInsert()
{
	
	CString strC,StrE;

	m_edtName.GetWindowText( strC );
	m_edtExpireTime.GetWindowText( StrE );

	
	if( strC.CompareNoCase("") == 0 || StrE.CompareNoCase("") == 0)
	{
		ErrMessage(_T("Please Input all item"));
		return ;
	}

	//���� �ð� �������� 
	COleDateTime cTime;
	cTime = COleDateTime::GetCurrentTime();
	CString strTime;
	//strTime = cTime.Format(_T("%Y%m%d%H%M%S"));		//�̷��� �ϸ� ������ 
	strTime.Format(_T("%4d%2d%2d%2d%2d%2d"),
		cTime.GetYear(),
		cTime.GetMonth(),
		cTime.GetDay(),
		cTime.GetHour(),
		cTime.GetMinute(),
		cTime.GetSecond());

	AddNewComponent(strC,StrE,"0", strTime);

	m_lbComponent.DeleteAllItems();
	SelectComponentList();

	m_edtName.SetWindowText(strC);
	m_edtExpireTime.SetWindowText(StrE);	
}
void CPaneSysSetupComponentTime::OnButtonDel()
{
	CString strC,strE;
		
	m_edtName.GetWindowText( strC );
	m_edtExpireTime.GetWindowText( strE );


	if( strC.CompareNoCase("") == 0 || strE.CompareNoCase("") == 0)
	{
		ErrMessage(_T("Select item that you want to delete"));
		return ;
	}
	
	RemoveComponent(strC);

	m_lbComponent.DeleteAllItems();
	SelectComponentList();

	m_edtName.SetWindowText("");
	m_edtExpireTime.SetWindowText("");

}
void CPaneSysSetupComponentTime::OnButtonUpdate()
{
	CString strC,strE;
	
	m_edtName.GetWindowText( strC );
	m_edtExpireTime.GetWindowText( strE );
	

	if( strC.CompareNoCase("") == 0 || strE.CompareNoCase("") == 0)
	{
		ErrMessage(_T("Select item that you want to update"));
		return ;
	}

	//���콺 Ŭ���� ���� �÷��� ��������
//	int nSel = m_lbComponent.GetSelectionMark();
//	if(nSel == -1)
//		return ;
//	CString strBeforeCompnoent = m_lbComponent.GetItemText(nSel, 0); 
	
	UpdateComponent(strC,strE, m_strListClickDevice);

	m_lbComponent.DeleteAllItems();
	SelectComponentList();

	m_edtName.SetWindowText(strC);
	m_edtExpireTime.SetWindowText(strE);
	

}
void CPaneSysSetupComponentTime::OnButtonInit()
{
	CString strC,strE;
	
	m_edtName.GetWindowText( strC );
	m_edtExpireTime.GetWindowText( strE );
	
	if( strC.CompareNoCase("") == 0 || strE.CompareNoCase("") == 0 )
	{
		ErrMessage(_T("Select item that you want to reset"));
		return ;
	}

	//���콺 Ŭ���� ���� �÷��� ��������
//	int nSel = m_lbComponent.GetSelectionMark();
//	if(nSel == -1)
//		return ;
//	CString strBeforeCompnoent = m_lbComponent.GetItemText(nSel, 0); 

	//���� �ð� �������� 
	COleDateTime cTime;
	cTime = COleDateTime::GetCurrentTime();
	CString strTime;
	//strTime = cTime.Format(_T("%Y%m%d%H%M%S"));
	strTime.Format(_T("%4d%2d%2d%2d%2d%2d"),
		cTime.GetYear(),
		cTime.GetMonth(),
		cTime.GetDay(),
		cTime.GetHour(),
		cTime.GetMinute(),
		cTime.GetSecond());

	InitComponent(strC,strE,"0", strTime, m_strListClickDevice);

	m_lbComponent.DeleteAllItems();
	SelectComponentList();

	m_edtName.SetWindowText(strC);
	m_edtExpireTime.SetWindowText(strE);	
}

void CPaneSysSetupComponentTime::OnButtonAllInit()
{
	CString strComponent;

	//���� �ð� �������� 
	COleDateTime cTime;
	cTime = COleDateTime::GetCurrentTime();
	CString strTime;
	//strTime = cTime.Format(_T("%Y%m%d%H%M%S"));
	strTime.Format(_T("%4d%2d%2d%2d%2d%2d"),
		cTime.GetYear(),
		cTime.GetMonth(),
		cTime.GetDay(),
		cTime.GetHour(),
		cTime.GetMinute(),
		cTime.GetSecond());

	ALLInitComponent("0",strTime);


	m_lbComponent.DeleteAllItems();
	SelectComponentList();
}
					

void CPaneSysSetupComponentTime::AddComponentList( CString strComponent, CString strExpiryDate, CString strSetTime)
{
	CString strData;
	int nNo = m_lbComponent.GetItemCount();
	LV_ITEM lvitem;
	
	lvitem.iItem = 0;
	lvitem.mask = LVIF_TEXT;
	lvitem.iSubItem = 0; 
	strData.Format(_T("%s"), strComponent);
	lvitem.pszText = (LPSTR)(LPCTSTR)strData;
//	m_lbComponent.InsertItem(&lvitem);
	m_lbComponent.InsertItem(nNo, lvitem.pszText);
	strData.Format(_T("%s"), strExpiryDate);
	m_lbComponent.SetItemText(nNo, 1, strData);


	strData.Format(_T("%02d%02d%02d:%02d"),atoi(strSetTime.Left(4)), atoi(strSetTime.Mid(4,2)), atoi(strSetTime.Mid(6,2)), atoi(strSetTime.Mid(8,2)) );
	m_lbComponent.SetItemText(nNo, 2, strData);
	CreateProgress(nNo, strExpiryDate, strSetTime);
		

}


void CPaneSysSetupComponentTime::OnClickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here

	
	int nSel;
	CString strCompnoent; 

	//���콺 Ŭ���� ���� �÷��� ��������
	nSel = m_lbComponent.GetSelectionMark();
	if(nSel == -1)
		return ;
	strCompnoent = m_lbComponent.GetItemText(nSel, 0); 
	

	CString strC,StrE,StrU;
	DisplayComponent(strCompnoent,strC,StrE,StrU);

	m_strListClickDevice.Empty();
	m_strListClickDevice = strC;

	m_edtName.SetWindowText( (LPCTSTR)strC );
	m_edtExpireTime.SetWindowText( (LPCTSTR)StrE );
	m_edtUsingTime.SetWindowText( (LPCTSTR)StrU );
	m_lbComponent.DeleteAllItems();
	SelectComponentList();	
	*pResult = 0;
}


BOOL CPaneSysSetupComponentTime::DisplayComponent(CString strCom, CString &strC,CString &StrE,CString &StrU)
{
	BOOL bRet = 0;

	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	
	TCHAR	szSql[256] = {0, };
	
	SQLCHAR szComponent[100] = {0,};
	SQLCHAR szExpiryDate[100] = {0,};
	SQLCHAR szUsingDate[100] = {0,};
 

 	SQLINTEGER	nComponent;
	SQLINTEGER	nExpiryDate;
	SQLINTEGER	nUsingDate;
	
	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, &szComponent, sizeof(szComponent), &nComponent );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, &szExpiryDate, sizeof(szExpiryDate), &nExpiryDate );
	::SQLBindCol( m_hStmt, 3, SQL_C_CHAR, &szUsingDate, sizeof(szUsingDate), &nUsingDate );

	// Excute SQL
	_stprintf_s(szSql, "select Component, ExpiryDate, UsingDate From Component where Component = '%s' ", strCom );
	

	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	// Fetch Result Set

	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		strC.Format(_T("%s"), szComponent);
		StrE.Format(_T("%s"), szExpiryDate);
		StrU.Format(_T("%s"), szUsingDate);
	}

	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );

	DBDisconnect();	
	return bRet;
}


void CPaneSysSetupComponentTime::UpdateUsingTime()
{

	BOOL bRet = 0;

	int i;
	int	nSel;
	CString strCompnoent,  strC, strE,strU,strT,strUpdateUsingDate;
	
	COleDateTime cCurrentTime,cGetDBTime;
	COleDateTimeSpan cCalTime;
	CString strTime;

	int nCalTime;

	
	nSel = m_lbComponent.GetItemCount();

	for( i = 0;i < nSel; i++)
	{
		int nCaltime = 0;

		strCompnoent = m_lbComponent.GetItemText(i, 0);	//0�� �� ������ �����´�
		GetUpdateItemFromDB(strCompnoent,strC,strE,strU,strT);	//strT �� ��� (��� ����� settime��)


		cCurrentTime = COleDateTime::GetCurrentTime();
	
		cGetDBTime.SetDateTime(atoi(strT.Left(4)),
							atoi(strT.Mid(4,2)),
							atoi(strT.Mid(6,2)),
							atoi(strT.Mid(8,2)),
							atoi(strT.Mid(10,2)),
							atoi(strT.Mid(12,2))
							);
	
		cCalTime = cCurrentTime - cGetDBTime;
		nCalTime = (int)(cCalTime.GetTotalDays());	// ���õ� �� ���� day�� ���� 
		//nCalTime = cCalTime.GetTotalMinutes();	// ���õ� �� ���� �� ���� test�� 



		strUpdateUsingDate.Format(_T("%d"),nCalTime);
		UpdateDBData(strC,strE,strUpdateUsingDate);
	}

//	m_lbComponent.DeleteAllItems();
//	SelectComponentList();
}

BOOL CPaneSysSetupComponentTime::GetUpdateItemFromDB(CString strCompnoent,CString &strC, CString &strE, CString &strU, CString &strT)
{
	BOOL bRet = 0;

	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}	
	
	TCHAR	szSql[256] = {0, };
	
	SQLCHAR szComponent[100] = {0,};
	SQLCHAR szExpiryDate[100] = {0,};
	SQLCHAR szUsingDate[100] = {0,};
	SQLCHAR szSetTime[100] = {0,};
 
 	SQLINTEGER	nComponent;
	SQLINTEGER	nExpiryDate;
	SQLINTEGER	nUsingDate;
	SQLINTEGER	nSetTime;
	
	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, &szComponent, sizeof(szComponent), &nComponent );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, &szExpiryDate, sizeof(szExpiryDate), &nExpiryDate );
	::SQLBindCol( m_hStmt, 3, SQL_C_CHAR, &szUsingDate, sizeof(szUsingDate), &nUsingDate );
	::SQLBindCol( m_hStmt, 4, SQL_C_CHAR, &szSetTime, sizeof(szSetTime), &nSetTime );

	// Excute SQL
	_stprintf_s(szSql, "select Component, ExpiryDate, UsingDate, SetTime From Component where Component = '%s' ", strCompnoent );
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	// Fetch Result Set

	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		strC.Format(_T("%s"), szComponent);
		strE.Format(_T("%s"), szExpiryDate);
		strU.Format(_T("%s"), szUsingDate);
		strT.Format(_T("%s"), szSetTime);

	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	return bRet;

}

BOOL CPaneSysSetupComponentTime::UpdateDBData(CString strC, CString strE, CString strU)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	TCHAR	szSql[256] = {0, };
	
	// Excute SQL
	
	_stprintf_s(szSql, _T("Update Component  set Component = '%s', ExpiryDate = '%s', UsingDate = '%s' where Component = '%s' "),
		strC, strE, strU, strC);
		
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	bRet = 1;	
	return bRet;
}


void CPaneSysSetupComponentTime::CheckComponentOverDate()
{
	//����Ʈ �ʱ�ȭ 
	cAlarm->m_lShow.DeleteAllItems();
	
	int i;
	int nSel;
	CString strC, strS, strE, strU, strW, strA;

	CString strStrartDate, strUsingDate, strAlarmDate;

	int nOverTimeComponentCount = 0;

	COleDateTime	cTime, cWarrantyTime, cAlarmTime;
	COleDateTimeSpan csTime;

//	CString 

		
	nSel = m_lbComponent.GetItemCount();
	
	for( i = 0;i < nSel; i++)
	{
		int nOverDay = 0;

		strC = m_lbComponent.GetItemText(i, 0);	
		GetUsingDateFromDB(strC,strE,strU, strS);
		nOverDay = atoi(strE) - atoi(strU);

		if(nOverDay <= GetPreAccTime())	//��� ��� �Ⱓ over , �ܺο��� �Է¹��� �� �ʱⰪ 0
		{
			cTime.SetDateTime(atoi(strS.Left(4)),
				atoi(strS.Mid(4,2)),
				atoi(strS.Mid(6,2)),
				atoi(strS.Mid(8,2)),
				atoi(strS.Mid(10,2)),
				atoi(strS.Mid(12,2))
				);	
			
			strStrartDate.Format(_T("%d.%d.%d.%dh"),atoi(strS.Left(4)), atoi(strS.Mid(4,2)), atoi(strS.Mid(6,2)), atoi(strS.Mid(8,2)) );		

			csTime.SetDateTimeSpan(atoi(strE), 0,0,0);
			cWarrantyTime= cTime+csTime;
			strUsingDate.Format(_T("%d.%d.%d.%dh"), cWarrantyTime.GetYear(), cWarrantyTime.GetMonth(), cWarrantyTime.GetDay(), cWarrantyTime.GetHour());

			
			csTime.SetDateTimeSpan(GetPreAccTime(),0,0,0);
			cAlarmTime = cWarrantyTime - csTime;
			strAlarmDate.Format(_T("%d.%d.%d.%dh"), cAlarmTime.GetYear(), cAlarmTime.GetMonth(), cAlarmTime.GetDay(), cAlarmTime.GetHour());
	

			cAlarm->AddItem(strC, strStrartDate, strE, strUsingDate, strAlarmDate);
			nOverTimeComponentCount++;


			cAlarm->SetPreAcqtime( GetPreAccTime() );
		}	
	}

	if(nOverTimeComponentCount > 0 ) 	
	{
		cAlarm->ShowWindow(SW_SHOW);
	}
	
}

BOOL CPaneSysSetupComponentTime::GetUsingDateFromDB(CString strC, CString &strE,CString &strU, CString &strS)
{
	BOOL bRet = 0;
	
	if( FALSE == DBConnect() )
	{
		ErrMessage(_T("Can't open Component.mdb file  "), MB_ICONSTOP);
		return bRet;
	}
	
	
	TCHAR	szSql[256] = {0, };	
	SQLCHAR	szExpiryDate[100] = {0,};
	SQLCHAR szUsingDate[100] = {0,};
	SQLCHAR szSetTime[100] = {0,};

	SQLINTEGER  nExpiryDate;
	SQLINTEGER	nUsingDate;
	SQLINTEGER  nSetTime;

	
	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, &szExpiryDate, sizeof(szExpiryDate), &nExpiryDate );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, &szUsingDate, sizeof(szUsingDate), &nUsingDate );	
	::SQLBindCol( m_hStmt, 3, SQL_C_CHAR, &szSetTime, sizeof(szSetTime), &nSetTime );

	
	// Excute SQL
	_stprintf_s(szSql, "select ExpiryDate, UsingDate, SetTime From Component where Component = '%s' ", strC );
	
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS );
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		return FALSE;
	}
	
	// Fetch Result Set
	
	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		strE.Format(_T("%s"), szExpiryDate);
		strU.Format(_T("%s"), szUsingDate);	
		strS.Format(_T("%s"), szSetTime);
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	DBDisconnect();	
	return bRet;	
}


void CPaneSysSetupComponentTime::OnButtonPreAccTime()
{


}

int CPaneSysSetupComponentTime::GetPreAccTime()
{
	CString strPreAccTime;
	m_edtPreAccTime.GetWindowText(strPreAccTime);
	
	return m_nPreaccTime= atoi(strPreAccTime);
}

void CPaneSysSetupComponentTime::OnApply()
{
	CString strData;
	
	m_edtPreAccTime.GetWindowText( strData );
	m_sSystemComponent.nPreAcTime = atoi( (LPSTR)(LPCTSTR)strData );

}

CString CPaneSysSetupComponentTime::GetChangeValueStr()
{
	CString strMessage, strTemp, strPath1, strPath2;
	strMessage.Format(_T(""));
	

	m_edtPreAccTime.GetWindowText( strPath1 );

	strPath2.Format(_T("%d"), gSystemINI.m_sSystemComponent.nPreAcTime);
//	strPath2 = gSystemINI.m_sSystemComponent.nPreAcTime;

	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| PreAcqTime : %s "), strPath1);
		strMessage += strTemp;
	}

	return strMessage;
}

void CPaneSysSetupComponentTime::GetSystemComponent(SYSTEMCOMPONENT *pSystemComponent)
{
	memcpy( pSystemComponent, &m_sSystemComponent, sizeof(m_sSystemComponent) );
}

void CPaneSysSetupComponentTime::SetSystemComponent(SYSTEMCOMPONENT sSystemComponent)
{
	memcpy( &m_sSystemComponent, &sSystemComponent, sizeof(m_sSystemComponent) );
	
	SetComponentData();
}

void CPaneSysSetupComponentTime::SetComponentData()
{
	CString str;
	str.Format(_T("%d"),m_sSystemComponent.nPreAcTime);
	m_edtPreAccTime.SetWindowText(str);
}

void CPaneSysSetupComponentTime::ShowComponentOverDate()
{
		//cAlarm->ShowWindow(SW_SHOW);
	//	cAlarm->CheckComponentOverDate
}

BOOL CPaneSysSetupComponentTime::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneSysSetupComponentTime::CreateProgress(int Index, CString strExpiryDate, CString strSetTime)
{

	if (Index >= m_lbComponent.GetItemCount())
		return;

	m_Progress[Index].ShowWindow(SW_SHOW);
	int nVal = CalRemainedDate(strExpiryDate, strSetTime);
	m_Progress[Index].SetPos(nVal);
	if(nVal > 50 && nVal <= 80)
		m_Progress[Index].SendMessage(PBM_SETBARCOLOR, 0, (LPARAM)(COLORREF)RGB(255, 255, 0));
	if(nVal > 80)
		m_Progress[Index].SendMessage(PBM_SETBARCOLOR, 0, (LPARAM)(COLORREF)RGB(255, 0, 0));
	else
		m_Progress[Index].SendMessage(PBM_SETBARCOLOR, 0, (LPARAM)(COLORREF)RGB(0, 255, 0));
}

int CPaneSysSetupComponentTime::CalRemainedDate(CString strExpiryDate, CString strSetTime)
{
	int nYear = atoi(strSetTime.Left(4));
	int nMon = atoi(strSetTime.Mid(4,2));
	int nDay = atoi(strSetTime.Mid(6,2));
	int nHour = atoi(strSetTime.Mid(8,2));

	int nExpiry = atoi(strExpiryDate);

	CTime ctCurrent = CTime::GetCurrentTime();
	CTime ctSet(nYear, nMon, nDay, nHour, 0, 0);

	CTimeSpan timespan= ctCurrent - ctSet;
	int nRemainedTime = (int)timespan.GetDays(); 
	double dRes = (double)(nRemainedTime * 100) / (double)nExpiry;

	return (int)dRes;
}

void CPaneSysSetupComponentTime::ResizeProg()
{
  CRect ItemRect;
  int Index=0;
  for(int i =0; i < m_lbComponent.GetItemCount(); i++)
  { 
      m_lbComponent.GetSubItemRect(i, 3, LVIR_BOUNDS, ItemRect);
      int left = ItemRect.left;
      int top = ItemRect.top;
      int right = ItemRect.right;
      int bottom = ItemRect.bottom;

	  m_Progress[i].MoveWindow(left, top, (right - left), (bottom - top));
	  m_Progress[i].Invalidate(TRUE);
  }
  m_lbComponent.Invalidate(TRUE);
}

void CPaneSysSetupComponentTime::OnHdnEndtrackList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMHEADER phdr = reinterpret_cast<LPNMHEADER>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	ResizeProg();
	*pResult = 0;
}

