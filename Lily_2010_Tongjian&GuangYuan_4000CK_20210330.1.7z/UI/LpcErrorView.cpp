// D:\source3\EasyDriller_MFC\2010_ver\Lily_2010\UI\LpcErrorView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "D:\source3\EasyDriller_MFC\2010_ver\Lily_2010\UI\LpcErrorView.h"
#include "afxdialogex.h"


// CLpcErrorView ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CLpcErrorView, CDialog)

CLpcErrorView::CLpcErrorView(CWnd* pParent /*=NULL*/)
	: CDialog(CLpcErrorView::IDD, pParent)
{

}

CLpcErrorView::~CLpcErrorView()
{
}

void CLpcErrorView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CLpcErrorView, CDialog)
END_MESSAGE_MAP()


// CLpcErrorView �޽��� ó�����Դϴ�.
