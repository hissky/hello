// PaneSysSetupLaserScannerPusan1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "PaneManualControl.h"
#include "PaneManualCOntrolLaser.h"
#include "PaneSysSetupLaserScannerPusan1.h"
#include "PaneManualControlMotorPusan1.h"
#include "PaneManualControlMotorLarge.h"
#include "PaneManualControlMotorKunsan1.h"
#include "PaneManualControlMotorKunsan6.h"
#include "PaneManualControlMotor.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\Device\FParameter.h"
#include "..\device\hlaser.h"
#include "..\model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HLaserAttenuator.h"
#include "paneautorun.h"
#include "..\model\DProcessINI.h"
#include "..\device\HMotor.h"
#include "..\model\DProject.h"
#include "DlgTableView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int		CW_SHOT		= 0;
const int		SINGLE_SHOT	= 1;

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerPusan1

IMPLEMENT_DYNCREATE(CPaneSysSetupLaserScannerPusan1, CFormView)

CPaneSysSetupLaserScannerPusan1::CPaneSysSetupLaserScannerPusan1()
	: CFormView(CPaneSysSetupLaserScannerPusan1::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupLaserScannerPusan1)
	//}}AFX_DATA_INIT
	m_bMainSht = FALSE;
	m_b1stSht = FALSE;
	m_b2ndSht = FALSE;
	m_dPulseMax = 50;
	m_dPulseMin = 0.01;
	m_bUseButtonFire = FALSE;
	m_nAbs = 0;
	m_bTargetZ1 = FALSE;
	m_bTargetZ2 = FALSE;
	m_bTargetC = FALSE;
	m_bTargetC2 = FALSE;
	m_bTargetM = FALSE;
	m_bTargetM2 = FALSE;
	m_bTargetM3	= FALSE;
	m_nMPGMode				= 0;

	//2011520
	m_bTargetA = FALSE;
	m_bTargetA2 = FALSE;
	memset(m_bScannerPos, 0 , sizeof(m_bScannerPos));

	m_nOld1stAOMOffset = 0;
	m_nOld2ndAOMOffset = 0;
}

CPaneSysSetupLaserScannerPusan1::~CPaneSysSetupLaserScannerPusan1()
{
}

void CPaneSysSetupLaserScannerPusan1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupLaserScannerPusan1)
	DDX_Control(pDX, IDC_EDIT_SCANNER_Y, m_edtScannerY);
	DDX_Control(pDX, IDC_EDIT_SCANNER_X, m_edtScannerX);
	DDX_Control(pDX, IDC_EDIT_FREQUENCY, m_edtFrequency);
	DDX_Control(pDX, IDC_EDIT_DIODE_CURRENT, m_edtCurrent);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY, m_edtAOMDelay);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY, m_edtAOMDuty);
	DDX_Control(pDX, IDC_EDIT_AOM_PROFILE, m_edtAOMProfilePath);
	DDX_Control(pDX, IDC_EDIT_SHOT_NO, m_edtShotNo);
	DDX_Control(pDX, IDC_EDIT_THERMAL_TRACK, m_edtThermalTrack);
	DDX_Control(pDX, IDC_EDIT_PULSE_WIDTH, m_edtPulseWidth);
	DDX_Control(pDX, IDC_BUTTON_SCANNER_LINE, m_btnScannerLine);
	DDX_Control(pDX, IDC_BUTTON_AOM_PROFILE, m_btnAOMOpen);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_OPEN, m_btnMainShtOpen);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_CLOSE, m_btnMainShtClose);
	DDX_Control(pDX, IDC_BUTTON_2ND_PANEL_SHT_OPEN, m_btn2ndPanelShtOpen);
	DDX_Control(pDX, IDC_BUTTON_2ND_PANEL_SHT_CLOSE, m_btn2ndPanelShtClose);
	DDX_Control(pDX, IDC_BUTTON_1ST_PANEL_SHT_OPEN, m_btn1stPanelShtOpen);
	DDX_Control(pDX, IDC_BUTTON_1ST_PANEL_SHT_CLOSE, m_btn1stPanelShtClose);
	DDX_Control(pDX, IDC_BUTTON_POWER_DETECTOR_ON, m_btnPDetectorShtOpen);
	DDX_Control(pDX, IDC_BUTTON_POWER_DETECTOR_OFF, m_btnPDetectorShtClose);
	DDX_Control(pDX, IDC_BUTTON_OPEN_LASER_DLG, m_btnLaserDlgShow);
	DDX_Control(pDX, IDC_BUTTON_MOVE_ATTEN, m_btnAttenMove);
	DDX_Control(pDX, IDC_BUTTON_HOME_ATTEN, m_btnAttenHome);
	DDX_Control(pDX, IDC_BUTTON_MPG_MODE, m_btnMPG);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_MOVE2, m_btnMove2);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, m_btnManualSCalPosMove);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z1, m_bTargetZ1);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z2, m_bTargetZ2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C, m_bTargetC);
	DDX_Check(pDX, IDC_CHECK_TARGET_C2, m_bTargetC2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK, m_bTargetM);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK2, m_bTargetM2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK4, m_bTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_M, m_edtTargetM);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M7, m_edtTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_C, m_edtTargetC);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2, m_edtTargetC2);

	DDX_Control(pDX, IDC_EDIT_TARGET_Z2_2, m_edtTargetZ2_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1_2, m_edtTargetZ1_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C1_2, m_edtTargetC1_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2_2, m_edtTargetC2_2);

	DDX_Control(pDX, IDC_EDIT_A, m_edtTargetA);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nAbs);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_TOPHAT2, m_chkUseTophat);
	DDX_Control(pDX, IDC_CHECK_SHOT_COUNT, m_chkUseShotCount);
	DDX_Control(pDX, IDC_CHECK_APPLY_MOVE, m_chkApplyAsc);
	DDX_Control(pDX, IDC_EDIT_AOM_OFFSET_MASTER, m_edt1stAOMOffset);
	DDX_Control(pDX, IDC_EDIT_AOM_OFFSET_SLAVE, m_edt2ndAOMOffset);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE1, m_edtVoltage1);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE2, m_edtVoltage2);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_TOPHAT3, m_chkBeamPass);
	DDX_Control(pDX, IDC_BTN_GET_LPC_DATA, m_btnLpcGet);
	DDX_Control(pDX, IDC_BUT_LPC_DIST, m_btnLpcVerify);
	DDX_Control(pDX, IDC_BUTTON_GET_LPC_STOP, m_btnLpcStop);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupLaserScannerPusan1, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupLaserScannerPusan1)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_OPEN, OnButtonMainShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_CLOSE, OnButtonMainShtClose)
	ON_BN_CLICKED(IDC_BUTTON_1ST_PANEL_SHT_OPEN, OnButton1stPanelShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_1ST_PANEL_SHT_CLOSE, OnButton1stPanelShtClose)
	ON_BN_CLICKED(IDC_BUTTON_2ND_PANEL_SHT_OPEN, OnButton2ndPanelShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_2ND_PANEL_SHT_CLOSE, OnButton2ndPanelShtClose)
	ON_BN_CLICKED(IDC_BUTTON_SCANNER_LINE, OnButtonScannerLine)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE2, OnButtonMove2)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, OnButtonManualSCalPosMove)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_MPG_MODE, OnButtonMpgMode)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_LASER_DLG, OnButtonOpenLaserDlg)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_ATTEN, OnButtonMoveAtten)
	ON_BN_CLICKED(IDC_BUTTON_HOME_ATTEN, OnButtonHomeAtten)
	ON_BN_CLICKED(IDC_BUTTON_AOM_PROFILE, OnButtonAomProfile)
	ON_BN_CLICKED(IDC_BUTTON_POWER_DETECTOR_ON, OnButtonPowerDetectorOn)
	ON_BN_CLICKED(IDC_BUTTON_POWER_DETECTOR_OFF, OnButtonPowerDetectorOff)
	ON_BN_CLICKED(IDC_BUTTON_POS0, OnButtonPos0)
	ON_BN_CLICKED(IDC_BUTTON_POS1, OnButtonPos1)
	ON_BN_CLICKED(IDC_BUTTON_POS2, OnButtonPos2)
	ON_BN_CLICKED(IDC_BUTTON_POS3, OnButtonPos3)
	ON_BN_CLICKED(IDC_BUTTON_POS4, OnButtonPos4)
	ON_BN_CLICKED(IDC_BUTTON_POS5, OnButtonPos5)
	ON_BN_CLICKED(IDC_BUTTON_POS6, OnButtonPos6)
	ON_BN_CLICKED(IDC_BUTTON_POS7, OnButtonPos7)
	ON_BN_CLICKED(IDC_BUTTON_POS8, OnButtonPos8)
	ON_BN_CLICKED(IDC_CHECK_APPLY_MOVE, OnCheckApplyAscFile)
	ON_BN_CLICKED(IDC_BTN_GET_LPC_DATA, OnButtonGetLpcData)
	ON_BN_CLICKED(IDC_BUT_LPC_DIST, OnButLpcDist)
	ON_BN_CLICKED(IDC_BUTTON_GET_LPC_STOP, OnButtonGetLpcStop)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_TOPHAT3, &CPaneSysSetupLaserScannerPusan1::OnClickedCheckSubUseTophat3)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerPusan1 diagnostics

#ifdef _DEBUG
void CPaneSysSetupLaserScannerPusan1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupLaserScannerPusan1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerPusan1 message handlers

void CPaneSysSetupLaserScannerPusan1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEditControl();

	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	BOOL bShutter = (nShutter > 0) ? TRUE : FALSE;
	m_btnMainShtOpen.SetClick(bShutter);
	m_btnMainShtOpen.SetClick(!bShutter);

	m_dPulseMin = 0.01;
	m_bIsLaserOn = FALSE;
	m_bIsLaserOnFire = FALSE;
	m_bStopFire = FALSE;
	m_bLastSignal = FALSE;
	m_nLaserMode = CW_SHOT;

	m_nTimerID = 0;
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->EnableWindow(FALSE);
		m_btn2ndPanelShtOpen.EnableWindow(FALSE);
		m_btn2ndPanelShtClose.EnableWindow(FALSE);

		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		m_edtTargetZ2.EnableWindow(FALSE);
		m_edtTargetZ2_2.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		m_edtTargetZ2.ShowWindow(SW_HIDE);
		m_edtTargetZ2_2.ShowWindow(SW_HIDE);
		m_edtTargetM.ShowWindow(SW_HIDE);
		m_edtTargetM2.ShowWindow(SW_HIDE);
		m_edtTargetC.ShowWindow(SW_HIDE);
		m_edtTargetC2.ShowWindow(SW_HIDE);
		m_edtTargetC1_2.ShowWindow(SW_HIDE);
		m_edtTargetC2_2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_TARGET_Z2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C2)->ShowWindow(SW_HIDE);
		//2011520

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			m_edtTargetZ1.ShowWindow(SW_HIDE);
			m_edtTargetZ1_2.ShowWindow(SW_HIDE);

			GetDlgItem(IDC_CHECK_TARGET_Z1)->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_RADIO_ABS)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_RADIO_INC)->ShowWindow(SW_HIDE);
			
			m_btnMove.ShowWindow(SW_HIDE);
			m_btnMove2.ShowWindow(SW_HIDE);
//			m_btnStop.ShowWindow(SW_HIDE);
			
			GetDlgItem(IDC_STATIC_TARGET_POS)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_BAR)->ShowWindow(SW_HIDE);
			m_btnMPG.ShowWindow(SW_HIDE);
		}
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		GetDlgItem(IDC_STATIC_1ST_PANEL_SHT)->EnableWindow(FALSE);
		m_btn1stPanelShtOpen.EnableWindow(FALSE);
		m_btn1stPanelShtClose.EnableWindow(FALSE);
	}
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		GetDlgItem(IDC_STATIC_MAIN_SHT)->EnableWindow(FALSE);
		m_btnMainShtOpen.EnableWindow(FALSE);
		m_btnMainShtClose.EnableWindow(FALSE);
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_SHT)->SetWindowText(" Attenuator");
		GetDlgItem(IDC_STATIC_THERMAL_TRACK)->SetWindowText("FPS");
		GetDlgItem(IDC_STATIC_MAIN_SHT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_1ST_PANEL_SHT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_MAIN_SHT_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_MAIN_SHT_CLOSE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_1ST_PANEL_SHT_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_1ST_PANEL_SHT_CLOSE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_2ND_PANEL_SHT_OPEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_2ND_PANEL_SHT_CLOSE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_MPG_MODE)->EnableWindow(FALSE);

		m_edtTargetZ2.ShowWindow(SW_HIDE);
		m_edtTargetM.ShowWindow(SW_HIDE);
		m_edtTargetM2.ShowWindow(SW_HIDE);
		m_edtTargetC.ShowWindow(SW_HIDE);
		m_edtTargetC2.ShowWindow(SW_HIDE);

		m_edtTargetZ2_2.ShowWindow(SW_HIDE);
		m_edtTargetC1_2.ShowWindow(SW_HIDE);
		m_edtTargetC2_2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_TARGET_Z2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C2)->ShowWindow(SW_HIDE);
		//2011520
	}
	else
	{
		GetDlgItem(IDC_BUTTON_OPEN_LASER_DLG)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_A)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_MOVE_ATTEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_ATTEN_POS)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_HOME_ATTEN)->ShowWindow(SW_HIDE);
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		GetDlgItem(IDC_EDIT_DIODE_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_DIODE_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_THERMAL_TRACK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_THERMAL_TRACK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CURRENT)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_AOM_DUTY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_PER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_PROFILE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_PROFILE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_AOM_PROFILE)->ShowWindow(SW_HIDE);
	}

#ifndef __SERVO_MOTOR__
		m_edtTargetM2.ShowWindow(SW_HIDE);
		m_edtTargetM3.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK4)->ShowWindow(SW_HIDE);
#endif

#ifdef __PUSAN_LDD__
		GetDlgItem(IDC_CHECK_TARGET_C2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->SetWindowText("C1");
		GetDlgItem(IDC_EDIT_TARGET_C2_2)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C1_2)->ShowWindow(SW_HIDE);
#endif
#ifdef __KUNSAN_1__
		GetDlgItem(IDC_CHECK_TARGET_C2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_TARGET_C2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->SetWindowText("C1");
		GetDlgItem(IDC_EDIT_TARGET_C2_2)->ShowWindow(SW_HIDE);
#endif
#ifdef __3RDAOD__
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_AOM_DUTY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_PER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_OFFSET_MASTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_OFFSET_SLAVE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VOLTAGE1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VOLTAGE2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_OFFSET_MASTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_OFFSET_SLAVE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_VOLTAGE1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_VOLTAGE2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER4)->ShowWindow(SW_HIDE);
#endif
		if(!gSystemINI.m_sHardWare.bUseLPC)
		{
			GetDlgItem(IDC_STATIC_GRID_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BTN_GET_LPC_DATA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUT_LPC_DIST)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_GET_LPC_STOP)->ShowWindow(SW_HIDE);
		}

}

BOOL CPaneSysSetupLaserScannerPusan1::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupLaserScannerPusan1::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Shutter
	m_btnLaserDlgShow.SetFont( &m_fntBtn );
	m_btnLaserDlgShow.SetFlat( FALSE );
	m_btnLaserDlgShow.EnableBallonToolTip();
	m_btnLaserDlgShow.SetToolTipText( _T("Laser Setting Dlg Open") );
	m_btnLaserDlgShow.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserDlgShow.SetBtnCursor(IDC_HAND_1);

	m_btnAttenMove.SetFont( &m_fntBtn );
	m_btnAttenMove.SetFlat( FALSE );
	m_btnAttenMove.EnableBallonToolTip();
	m_btnAttenMove.SetToolTipText( _T("Attenuator Move") );
	m_btnAttenMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAttenMove.SetBtnCursor(IDC_HAND_1);

	m_btnAttenHome.SetFont( &m_fntBtn );
	m_btnAttenHome.SetFlat( FALSE );
	m_btnAttenHome.EnableBallonToolTip();
	m_btnAttenHome.SetToolTipText( _T("Attenuator Homing") );
	m_btnAttenHome.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAttenHome.SetBtnCursor(IDC_HAND_1);

	m_btnMainShtOpen.SetFont( &m_fntBtn );
	m_btnMainShtOpen.SetRectAlign( 1 ); 
	m_btnMainShtOpen.SetToolTipText( _T("Main Shutter Open") );
	m_btnMainShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btnMainShtClose.SetFont( &m_fntBtn );
	m_btnMainShtClose.SetRectAlign( 1 ); 
	m_btnMainShtClose.SetToolTipText( _T("Main Shutter Close") );
	m_btnMainShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtOpen.SetFont( &m_fntBtn );
	m_btn1stPanelShtOpen.SetRectAlign( 1 ); 
	m_btn1stPanelShtOpen.SetToolTipText( _T("1st Panel Shutter Open") );
	m_btn1stPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtClose.SetFont( &m_fntBtn );
	m_btn1stPanelShtClose.SetRectAlign( 1 ); 
	m_btn1stPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn1stPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtOpen.SetFont( &m_fntBtn );
	m_btn2ndPanelShtOpen.SetRectAlign( 1 ); 
	m_btn2ndPanelShtOpen.SetToolTipText( _T("2nd Panel Shutter Open") );
	m_btn2ndPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtClose.SetFont( &m_fntBtn );
	m_btn2ndPanelShtClose.SetRectAlign( 1 ); 
	m_btn2ndPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn2ndPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btnPDetectorShtOpen.SetFont( &m_fntBtn );
	m_btnPDetectorShtOpen.SetRectAlign( 1 ); 
	m_btnPDetectorShtOpen.SetToolTipText( _T("Power Detector Shutter Open") );
	m_btnPDetectorShtOpen.SetBtnCursor( IDC_HAND_1 );
	
	m_btnPDetectorShtClose.SetFont( &m_fntBtn );
	m_btnPDetectorShtClose.SetRectAlign( 1 ); 
	m_btnPDetectorShtClose.SetToolTipText( _T("Power Detector Shutter Close") );
	m_btnPDetectorShtClose.SetBtnCursor( IDC_HAND_1 );

	// Scanner Position
	m_btnScannerLine.SetFont( &m_fntBtn );
	m_btnScannerLine.SetRectAlign( 0 ); 
	m_btnScannerLine.SetToolTipText( _T("Draw") );
	m_btnScannerLine.SetBtnCursor( IDC_HAND_1 );

	m_btnAOMOpen.SetFont( &m_fntBtn );
	m_btnAOMOpen.SetRectAlign( 0 ); 
	m_btnAOMOpen.SetToolTipText( _T("Open AOM Profile file") );
	m_btnAOMOpen.SetBtnCursor( IDC_HAND_1 );

	GetDlgItem(IDC_CHECK_TARGET_Z1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK4)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C2)->SetFont( &m_fntBtn );
	//2011520
	GetDlgItem(IDC_RADIO_ABS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_INC)->SetFont( &m_fntBtn );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_CHECK_TARGET_MASK)->SetWindowText("A1");
		GetDlgItem(IDC_CHECK_TARGET_C)->SetWindowText("A2");
	}
	
	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMove2.SetFont( &m_fntBtn );
	m_btnMove2.SetFlat( FALSE );
	m_btnMove2.EnableBallonToolTip();
	m_btnMove2.SetToolTipText( _T("Move Tagerget Position 2") );
	m_btnMove2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove2.SetBtnCursor(IDC_HAND_1);

	m_btnManualSCalPosMove.SetFont( &m_fntBtn );
	m_btnManualSCalPosMove.SetFlat( FALSE );
	m_btnManualSCalPosMove.EnableBallonToolTip();
	m_btnManualSCalPosMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnManualSCalPosMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualSCalPosMove.SetBtnCursor(IDC_HAND_1);
	
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop fire") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);
	m_btnStop.EnableWindow( FALSE );

	// MPG Mode
	m_btnMPG.SetFont( &m_fntBtn );
	m_btnMPG.SetFlat( FALSE );
	m_btnMPG.EnableBallonToolTip();
	m_btnMPG.SetToolTipText( _T("MPG Mode Select") );
	m_btnMPG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMPG.SetBtnCursor(IDC_HAND_1);

	//use tophat
	m_chkUseTophat.SetFont( &m_fntBtn );
	m_chkUseTophat.SetImageOrg( 10, 3 );
	m_chkUseTophat.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTophat.EnableBallonToolTip();
	m_chkUseTophat.SetToolTipText( _T("Use Top Hat") );
	m_chkUseTophat.SetBtnCursor(IDC_HAND_1);
	m_chkUseTophat.EnableWindow(TRUE);

	//use shot count
	m_chkUseShotCount.SetFont( &m_fntBtn );
	m_chkUseShotCount.SetImageOrg( 10, 3 );
	m_chkUseShotCount.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseShotCount.EnableBallonToolTip();
	m_chkUseShotCount.SetToolTipText( _T("Use Shot Count") );
	m_chkUseShotCount.SetBtnCursor(IDC_HAND_1);
	m_chkUseShotCount.EnableWindow(TRUE);

	//use tophat
	m_chkBeamPass.SetFont( &m_fntBtn );
	m_chkBeamPass.SetImageOrg( 10, 3 );
	m_chkBeamPass.SetIcon( IDI_LEDON, IDI_LEDOFF ); 
	m_chkBeamPass.EnableBallonToolTip();
	m_chkBeamPass.SetToolTipText( _T("Use Long Path") );
	m_chkBeamPass.SetBtnCursor(IDC_HAND_1);
	m_chkBeamPass.EnableWindow(TRUE);
#ifdef __PUSAN_OLD_17__
	m_chkBeamPass.ShowWindow(SW_HIDE);
#endif

#ifdef __KUNSAN_6__
	m_chkBeamPass.ShowWindow(SW_HIDE);
	m_chkUseTophat.ShowWindow(SW_HIDE);
#endif
	
#ifdef __KUNSAN_8__
	m_chkBeamPass.ShowWindow(SW_HIDE);
	m_chkUseTophat.ShowWindow(SW_HIDE);
#endif

	// ApplyAsc
	m_chkApplyAsc.SetFont( &m_fntBtn );
	m_chkApplyAsc.SetImageOrg( 10, 3 );
	m_chkApplyAsc.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkApplyAsc.EnableBallonToolTip();
	m_chkApplyAsc.SetToolTipText( _T("Apply Asc File ") );
	m_chkApplyAsc.SetBtnCursor(IDC_HAND_1);
	m_chkApplyAsc.EnableWindow(TRUE);

	m_btnLpcGet.SetFont( &m_fntBtn );
	m_btnLpcGet.SetFlat( FALSE );
	m_btnLpcGet.EnableBallonToolTip();
	m_btnLpcGet.SetToolTipText( _T("Find LPC Min. Max. Data") );
	m_btnLpcGet.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcGet.SetBtnCursor(IDC_HAND_1);

	m_btnLpcVerify.SetFont( &m_fntBtn );
	m_btnLpcVerify.SetFlat( FALSE );
	m_btnLpcVerify.EnableBallonToolTip();
	m_btnLpcVerify.SetToolTipText( _T("Verify LPC Data for Various Frequency") );
	m_btnLpcVerify.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcVerify.SetBtnCursor(IDC_HAND_1);


	m_btnLpcStop.SetFont( &m_fntBtn );
	m_btnLpcStop.SetFlat( FALSE );
	m_btnLpcStop.EnableBallonToolTip();
	m_btnLpcStop.SetToolTipText( _T("Stop Process fpr LPC") );
	m_btnLpcStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcStop.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupLaserScannerPusan1::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Shutter
	GetDlgItem(IDC_STATIC_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ATTEN_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_DETECTOR)->SetFont( &m_fntStatic );

	// Laser Mode
	GetDlgItem(IDC_STATIC_LASER_MODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PULSE_WIDTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQUENCY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DIODE_CURRENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THERMAL_TRACK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_PROFILE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_NO)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STC_AOM_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_AOM_DUTY)->SetFont( &m_fntStatic );

	// Scanner Position
	GetDlgItem(IDC_STATIC_SCANNER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_Y)->SetFont( &m_fntStatic );

	// Grid Size
	GetDlgItem(IDC_STATIC_GRID_SIZE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_TARGET_POS)->SetFont( &m_fntStatic );

	
	GetDlgItem(IDC_STATIC_AOM_OFFSET_MASTER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_OFFSET_SLAVE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE2)->SetFont( &m_fntStatic );


}

void CPaneSysSetupLaserScannerPusan1::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(180, "Arial Bold");

	// Laser Mode
	m_edtPulseWidth.SetFont( &m_fntEdit );
	m_edtPulseWidth.SetForeColor( BLACK_COLOR );
	m_edtPulseWidth.SetBackColor( WHITE_COLOR );
	m_edtPulseWidth.SetReceivedFlag( 3 );
	if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		m_edtPulseWidth.SetWindowText( _T("50"));
	else
		m_edtPulseWidth.SetWindowText( _T("20") );

	m_edtFrequency.SetFont( &m_fntEdit );
	m_edtFrequency.SetForeColor( BLACK_COLOR );
	m_edtFrequency.SetBackColor( WHITE_COLOR );
	m_edtFrequency.SetReceivedFlag( 1 );
	if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		m_edtFrequency.SetWindowText( _T("20000") );
	else
		m_edtFrequency.SetWindowText( _T("1000") );

	m_edtCurrent.SetFont( &m_fntEdit );
	m_edtCurrent.SetForeColor( BLACK_COLOR );
	m_edtCurrent.SetBackColor( WHITE_COLOR );
	m_edtCurrent.SetReceivedFlag( 3 );
	m_edtCurrent.SetWindowText( _T("90.0") );

	m_edtThermalTrack.SetFont( &m_fntEdit );
	m_edtThermalTrack.SetForeColor( BLACK_COLOR );
	m_edtThermalTrack.SetBackColor( WHITE_COLOR );
	m_edtThermalTrack.SetReceivedFlag( 1 );
	m_edtThermalTrack.SetWindowText( _T("2525") );

	m_edtAOMDelay.SetFont( &m_fntEdit );
	m_edtAOMDelay.SetForeColor( BLACK_COLOR );
	m_edtAOMDelay.SetBackColor( WHITE_COLOR );
	m_edtAOMDelay.SetReceivedFlag( 3 );
	m_edtAOMDelay.SetWindowText( _T("0.0") );

	m_edtAOMDuty.SetFont( &m_fntEdit );
	m_edtAOMDuty.SetForeColor( BLACK_COLOR );
	m_edtAOMDuty.SetBackColor( WHITE_COLOR );
	m_edtAOMDuty.SetReceivedFlag( 3 );
	m_edtAOMDuty.SetWindowText( _T("20") );

	m_edtShotNo.SetFont( &m_fntEdit );
	m_edtShotNo.SetForeColor( BLACK_COLOR );
	m_edtShotNo.SetBackColor( WHITE_COLOR );
	m_edtShotNo.SetReceivedFlag( 1 );
	m_edtShotNo.SetWindowText( _T("1") );

//	m_edtAOMProfilePath.SetFont( &m_fntEdit );
	m_edtAOMProfilePath.EnableWindow(FALSE);
	m_edtAOMProfilePath.SetWindowText( _T("D:\\ViaHole\\AOM\\Default.AOM") );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_STATIC_PULSE_WIDTH)->EnableWindow(FALSE);
		m_edtPulseWidth.EnableWindow(FALSE);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		
	}
	else
	{
		m_edtPulseWidth.EnableWindow(FALSE);
		if(gSystemINI.m_sHardWare.nLaserType != LASER_IPGPULSE)
		{
			GetDlgItem(IDC_STATIC_DIODE_CURRENT)->EnableWindow(FALSE);
			m_edtCurrent.EnableWindow(FALSE);
		}

		GetDlgItem(IDC_STATIC_THERMAL_TRACK)->EnableWindow(FALSE);
		m_edtThermalTrack.EnableWindow(FALSE);
	}

	// Scanner
	m_edtScannerX.SetFont( &m_fntEdit );
	m_edtScannerX.SetForeColor( BLACK_COLOR );
	m_edtScannerX.SetBackColor( WHITE_COLOR );
	m_edtScannerX.SetReceivedFlag( 1 );
	m_edtScannerX.SetWindowText( _T("32767") );

	m_edtScannerY.SetFont( &m_fntEdit );
	m_edtScannerY.SetForeColor( BLACK_COLOR );
	m_edtScannerY.SetBackColor( WHITE_COLOR );
	m_edtScannerY.SetReceivedFlag( 1 );
	m_edtScannerY.SetWindowText( _T("32767") );

	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );
	
	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );
	
	// Target M
	m_edtTargetM.SetFont( &m_fntEdit );
	m_edtTargetM.SetReceivedFlag( 3 );
	m_edtTargetM.SetWindowText( _T("0.0") );

	// Target M2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );
	
	// Target M3
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );

	// Target C
	m_edtTargetC.SetFont( &m_fntEdit );
	m_edtTargetC.SetReceivedFlag( 3 );
	m_edtTargetC.SetWindowText( _T("0.0") );

	// Target C2
	m_edtTargetC2.SetFont( &m_fntEdit );
	m_edtTargetC2.SetReceivedFlag( 3 );
	m_edtTargetC2.SetWindowText( _T("0.0") );

	///////
	// Target Z1_2
	m_edtTargetZ1_2.SetFont( &m_fntEdit );
	m_edtTargetZ1_2.SetReceivedFlag( 3 );
	m_edtTargetZ1_2.SetWindowText( _T("0.0") );
	
	// Target Z2_2
	m_edtTargetZ2_2.SetFont( &m_fntEdit );
	m_edtTargetZ2_2.SetReceivedFlag( 3 );
	m_edtTargetZ2_2.SetWindowText( _T("0.0") );
	
	// Target C_2
	m_edtTargetC1_2.SetFont( &m_fntEdit );
	m_edtTargetC1_2.SetReceivedFlag( 3 );
	m_edtTargetC1_2.SetWindowText( _T("0.0") );

	// Target C2
	m_edtTargetC2_2.SetFont( &m_fntEdit );
	m_edtTargetC2_2.SetReceivedFlag( 3 );
	m_edtTargetC2_2.SetWindowText( _T("0.0") );
	//////

	//AOM Offset 1st
	m_edt1stAOMOffset.SetFont( &m_fntEdit );
	m_edt1stAOMOffset.SetReceivedFlag(1);
	m_edt1stAOMOffset.SetWindowText(_T("50"));
	
	//AOM Offset 2nd
	m_edt2ndAOMOffset.SetFont( &m_fntEdit );
	m_edt2ndAOMOffset.SetReceivedFlag(1);
	m_edt2ndAOMOffset.SetWindowText(_T("50"));
	
	//voltage1
	m_edtVoltage1.SetFont( &m_fntEdit );
	m_edtVoltage1.SetReceivedFlag(3);

	CString str;
	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV);
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV2);

	m_edtVoltage1.SetWindowText(str);
	
	//voltage2
	m_edtVoltage2.SetFont( &m_fntEdit );
	m_edtVoltage2.SetReceivedFlag(3);

	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby2ndV);
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV2);
	m_edtVoltage2.SetWindowText(str);

}

void CPaneSysSetupLaserScannerPusan1::OnButtonMainShtOpen() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	gDeviceFactory.GetLaser()->ShutterOpen(TRUE);

	m_btnMainShtOpen.SetClick( TRUE );
	m_btnMainShtClose.SetClick( FALSE );
}

void CPaneSysSetupLaserScannerPusan1::OnButtonMainShtClose() 
{
	gDeviceFactory.GetLaser()->ShutterOpen(FALSE);

	m_btnMainShtOpen.SetClick( FALSE );
	m_btnMainShtClose.SetClick( TRUE );
}

void CPaneSysSetupLaserScannerPusan1::OnButton1stPanelShtOpen() 
{	
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_MASTER, TRUE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn1stPanelShtOpen.SetClick( bStatus );
	m_btn1stPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerPusan1::OnButton1stPanelShtClose() 
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_MASTER, FALSE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn1stPanelShtOpen.SetClick( bStatus );
	m_btn1stPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerPusan1::OnButton2ndPanelShtOpen() 
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_SLAVE, TRUE);

	::Sleep(1000);

	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;

	m_btn2ndPanelShtOpen.SetClick( bStatus );
	m_btn2ndPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerPusan1::OnButton2ndPanelShtClose() 
{	
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_SLAVE, FALSE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn2ndPanelShtOpen.SetClick( bStatus );
	m_btn2ndPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerPusan1::OnButtonScannerLine() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

//	BOOL bFlag = m_btnScannerLine.GetClick();
//	m_btnScannerLine.SetClick( !bFlag );

	UpdateData(TRUE);

	HEocard* pEOCard = gDeviceFactory.GetEocard();

	EnableAllButton(FALSE);

	if(!CheckPulseWidth())
	{
		ErrMessage(_T("Duty setting Error : 0.01 <= Duty <= 50 %"));
		EnableAllButton(TRUE);
		return;
	}

	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		gDeviceFactory.GetEocard()->SetMasterSlave(TRUE);
	else
		gDeviceFactory.GetEocard()->SetMasterSlave(FALSE);

	CString strVal;
	double dAOMDelay, dAOMDuty;
	m_edtAOMDelay.GetWindowText(strVal);
	dAOMDelay = atof(strVal);
	m_edtAOMDuty.GetWindowText(strVal);
	dAOMDuty = atof(strVal);

	double dVoltage1, dVoltage2;
	m_edtVoltage1.GetWindowText(strVal);
	dVoltage1 = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	dVoltage2 = atof(strVal);
	
	if(!gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2))
	{
		ErrMsgDlg(STDGNALM117);
		EnableAllButton(TRUE);
		return;
	}

	BOOL bTophat = m_chkUseTophat.GetCheck();
	if(!gDeviceFactory.GetMotor()->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		EnableAllButton(TRUE);
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		EnableAllButton(TRUE);
		return ;
	}

//	if(m_bLastSignal == FALSE)
	{
		
		double dLaserXPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_X );
		double dLaserYPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_Y );
		if(m_nUserLevel <= 2)
		{
			if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
				dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				CString strM;
				strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
					gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
					gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
				ErrMessage(strM);
				EnableAllButton(TRUE);
				return;
			}
		}
		if(dLaserXPos >= gSystemINI.m_sSystemDevice.dTableLimitMaxX ||
			dLaserXPos <= gSystemINI.m_sSystemDevice.dTableLimitMinX ||
			dLaserYPos >= gSystemINI.m_sSystemDevice.dTableLimitMaxY ||
			dLaserYPos <= gSystemINI.m_sSystemDevice.dTableLimitMinY )
		{
			CString strM;
			strM.Format(_T("Laser fire position is out of table.\n Table Min X = %.3f, Table Min Y = %.3f\n Table Max X = %.3f, Table Max Y = %.3f"),
				gSystemINI.m_sSystemDevice.dTableLimitMinX, gSystemINI.m_sSystemDevice.dTableLimitMinY, 
				gSystemINI.m_sSystemDevice.dTableLimitMaxX, gSystemINI.m_sSystemDevice.dTableLimitMaxY);
			ErrMessage(strM);
			EnableAllButton(TRUE);
			return;
		}

		m_bUseButtonFire = TRUE;
		UpdateData();
		FParameter fPara;
		pEOCard->GetParameter(&fPara);
		m_usOldPulseWidth = (unsigned short)fPara.dDuty;
		m_usOldFrequency = fPara.Frequency;
		
		double dPulseWidth;
		m_edtPulseWidth.GetWindowText(strVal);
		dPulseWidth = atof(strVal);
		
		int nFrequency, nShotNo;
		m_edtFrequency.GetWindowText(strVal);
		nFrequency = atoi(strVal);
		m_edtShotNo.GetWindowText(strVal);
		nShotNo = atoi(strVal);

		m_edtAOMProfilePath.GetWindowText(strVal);
		memcpy(fPara.cAOMFilePath, strVal, strVal.GetLength()+1);
		
		m_nOld1stAOMOffset = gSystemINI.m_sSystemDevice.nDualAom1stOffset;
		m_nOld2ndAOMOffset = gSystemINI.m_sSystemDevice.nDualAom2ndOffset;
		
		m_edt1stAOMOffset.GetWindowText(strVal);
		gSystemINI.m_sSystemDevice.nDualAom1stOffset = atoi(strVal);
		
		m_edt2ndAOMOffset.GetWindowText(strVal);
		gSystemINI.m_sSystemDevice.nDualAom2ndOffset = atoi(strVal);

		CString strMessage, strSub;
		strMessage.Format(_T("Laser Beam Hole Fire "));
		
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			fPara.dDuty = 5000; // 50%
			double dCurrent;
			m_edtCurrent.GetWindowText(strVal);
			dCurrent = atof(strVal);
			
			int nThermalTrack;
			m_edtThermalTrack.GetWindowText(strVal);
			nThermalTrack = atoi(strVal);
			
			gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, nFrequency, nThermalTrack);
			strSub.Format(_T("| Freq. = %d | Current = %.3f | ThermalTrack = %d"), nFrequency, dCurrent, nThermalTrack);
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			double dCurrent;
			m_edtCurrent.GetWindowText(strVal);
			dCurrent = atof(strVal);
			
			gDeviceFactory.GetLaser()->SetCurrent(dCurrent);
			
			fPara.dDuty = 5000; // 50%
			strSub.Format(_T("| Freq. = %d | Current = %.2f | Duty = %.2f"), nFrequency, dCurrent, dPulseWidth);
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			int nCurrent;
			m_edtCurrent.GetWindowText(strVal);
			nCurrent = atoi(strVal);
			
			int nThermalTrack;
			m_edtThermalTrack.GetWindowText(strVal);
			nThermalTrack = atoi(strVal);
			gDeviceFactory.GetLaser()->setQuataParam(nThermalTrack, nCurrent);
			strSub.Format(_T("| Freq. = %d | Duty = %.2f | Current = %d | FPK = %d"), nFrequency, dPulseWidth, nCurrent, nThermalTrack);
		}
		else
		{
			fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
			strSub.Format(_T("| Freq. = %d | Duty = %.2f"), nFrequency, dPulseWidth);
			fPara.dAOMDelay = dAOMDelay;
			fPara.dAOMDuty = dAOMDuty;

//			if(fPara.dAOMDelay + fPara.dAOMDuty > dPulseWidth + 50)
//			{
//				ErrMessage(IDS_ERR_AOM);
//				EnableAllButton(TRUE);
//				return;
//			}
		}
		
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strSub));
		
		gDeviceFactory.GetMotor()->IonizerOn(TRUE);
		gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);

		gDeviceFactory.GetMotor()->HoodOpen(TRUE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
		{
			gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
			ErrMessage(_T("Dust Suction Shutter On Error."));
			EnableAllButton(TRUE);
			return;
		}
		
		fPara.Frequency = static_cast<unsigned>(nFrequency);
		pEOCard->SetParameter(&fPara);

//		m_btnScannerLine.SetWindowText(_T("Stop"));
		m_btnScannerLine.EnableWindow(FALSE);
		m_btnStop.EnableWindow( TRUE );
		m_bLastSignal = TRUE;
		
		double dFireTime = 1.0 / nFrequency * (nShotNo - 0.5);
		double dWaitTime;

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
					gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
					ErrMsgDlg(STDGNALM781);
					EnableAllButton(TRUE);
					return;
				}
			}
		}
		Sleep(100);
		int nPosX, nPosY;
		
		m_edtScannerX.GetWindowText(strVal);
		nPosX = atoi(strVal);
		
		m_edtScannerY.GetWindowText(strVal);
		nPosY = atoi(strVal);
		
//		gDeviceFactory.GetEocard()->DrillMove(FALSE, nPosX, nPosY, FALSE, nPosX, nPosY, FALSE);
		gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
		

		CCorrectTime MyTestTime;
		MyTestTime.StartTime();
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
		pEOCard->LaserOnOff(TRUE);
			
		do 
		{
			dWaitTime = MyTestTime.PresentTime();
			if(dWaitTime > dFireTime) 
				break;
			MessageLoop();
			::Sleep(0);

		} while(!m_bStopFire);

		m_bStopFire = FALSE;

//	}		
//	else
//	{
		pEOCard->LaserOnOff(FALSE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
		
		BOOL bOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && bOn)
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
				{
					gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
					gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
					ErrMsgDlg(STDGNALM781);
					EnableAllButton(TRUE);
					return;
				}
			}
		}
		gDeviceFactory.GetMotor()->IonizerOn(FALSE);
		gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);

		gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
		gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
		
		fPara.dDuty = m_usOldPulseWidth;
		fPara.Frequency = m_usOldFrequency;
		pEOCard->SetParameter(&fPara);
		m_bLastSignal = FALSE;

		m_btnScannerLine.EnableWindow(TRUE);
		m_btnStop.EnableWindow( FALSE );

//		m_btnScannerLine.SetWindowText(_T("Fire"));
//		m_btnScannerLine.EnableWindow(TRUE);
		m_bUseButtonFire = FALSE;

		if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
		{
			gDeviceFactory.GetMotor()->HoodOpen(FALSE);
			if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
			{
			ErrMessage(_T("Dust Suction Shutter Off Error."));
			}
		}

		EnableAllButton(TRUE);
	}
}

void CPaneSysSetupLaserScannerPusan1::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	m_bStopFire = TRUE;
}

void CPaneSysSetupLaserScannerPusan1::OnButtonMpgMode() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
#ifndef __KUNSAN_6__
	#ifndef __KUNSAN_8__
	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
		m_btnMPG.SetToolTipText("M1, B1, B2");
	}
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 2;
		m_btnMPG.SetWindowText("MPG Mode 3");
		m_btnMPG.SetToolTipText("LC, UC");
	}
	else
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
	}
	#endif
#endif

#ifdef __KUNSAN_6__
	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
		m_btnMPG.SetToolTipText("M1, B1, B2");
	}
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
	}
#endif

#ifdef __KUNSAN_8__
	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
		m_btnMPG.SetToolTipText("M, C");
	}
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
	}
#endif

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_MPG_MODE, m_nMPGMode);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_MPG_MODE, m_nMPGMode);
#endif
}

HBRUSH CPaneSysSetupLaserScannerPusan1::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_SHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_GRID_SIZE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TARGET_POS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupLaserScannerPusan1::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupLaserScannerPusan1::SetShutterStatus()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen();
	m_btnMainShtOpen.SetClick(bOpen);
	m_btnMainShtClose.SetClick(!bOpen);

	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
	{
		m_btn1stPanelShtOpen.SetClick(TRUE);
		m_btn1stPanelShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn1stPanelShtOpen.SetClick(FALSE);
		m_btn1stPanelShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn1stPanelShtOpen.SetClick(FALSE);
		m_btn1stPanelShtClose.SetClick(FALSE);
	}

	nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
	{
		m_btn2ndPanelShtOpen.SetClick(TRUE);
		m_btn2ndPanelShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn2ndPanelShtOpen.SetClick(FALSE);
		m_btn2ndPanelShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn2ndPanelShtOpen.SetClick(FALSE);
		m_btn2ndPanelShtClose.SetClick(FALSE);
	}

	//
	LONG lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO3);
	
	if(lStatus & 0x0100)
		m_btnPDetectorShtOpen.SetClick( 1 );
	else
		m_btnPDetectorShtOpen.SetClick( 0 );
	
	if(lStatus & 0x0200)
		m_btnPDetectorShtClose.SetClick( 1 );
	else
		m_btnPDetectorShtClose.SetClick( 0 );
	//

	if(m_nTimerID == 0)
	{
#ifndef __PUSAN_LDD__
		m_nMPGMode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pMotor->GetMPGMode();
#endif
//		int nMode = gDeviceFactory.GetMotor()->GetMPGMode();
//		m_nMPGMode = nMode;
		switch(m_nMPGMode)
		{
		case 0:
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
			break;
		case 1:
			m_btnMPG.SetWindowText("MPG Mode 2");
			m_btnMPG.SetToolTipText("M1, B1, B2");
			break;
		case 2:
			m_btnMPG.SetWindowText("MPG Mode 3");
			m_btnMPG.SetToolTipText("LC, UC");
			break;
		}
		m_nTimerID = SetTimer(111, 100, NULL);
	}

}

void CPaneSysSetupLaserScannerPusan1::StopExternalLaser()
{
	if(m_nTimerID)
	{
		gDeviceFactory.GetEocard()->MoveToCenter();
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneSysSetupLaserScannerPusan1::OnTimer(UINT nIDEvent) 
{
#ifndef __TEST__
	if(!m_bUseSelfShot || m_bUseButtonFire)
		return;

	HEocard* pEOCard = gDeviceFactory.GetEocard();
#ifndef __MP920_MOTOR__
	BYTE bLaserOn = gDeviceFactory.GetMotor()->GetExternalLaser();
#else
	BYTE bLaserOn = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
#endif
	BOOL bApply1 = pEOCard->GetApplyCalibrationFile(0);
	BOOL bApply2 = pEOCard->GetApplyCalibrationFile(1);

	if(bApply1 || bApply2)
		m_chkApplyAsc.SetCheck(TRUE);

	
	CString strVal;
	double dAOMDelay, dAOMDuty;
	m_edtAOMDelay.GetWindowText(strVal);
	dAOMDelay = atof(strVal);
	m_edtAOMDuty.GetWindowText(strVal);
	dAOMDuty = atof(strVal);

	double dVoltage1, dVoltage2;
	m_edtVoltage1.GetWindowText(strVal);
	dVoltage1 = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	dVoltage2 = atof(strVal);

#ifndef __MP920_MOTOR__
	DeviceMotor *pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(bLaserOn & 0x01)
	{
		BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
		if(nShutter == 1)
			gDeviceFactory.GetEocard()->SetMasterSlave(TRUE);
		else
			gDeviceFactory.GetEocard()->SetMasterSlave(FALSE);

		if(!gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2))
		{
			ErrMsgDlg(STDGNALM117);
			return;
		}
		double dLaserXPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_X );
		double dLaserYPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_Y );
		if(m_nUserLevel <= 2)
		{
			if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
				dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				CString strM;
				strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
					gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
					gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
				ErrMessage(strM);
				EnableAllButton(TRUE);
				return;
			}
		}

		if(m_bLastSignal == FALSE)
		{
			if(!CheckPulseWidth())
			{
				ErrMessage(_T("Duty setting Error : 0.01 <= Duty <= 50 %"));
				CFormView::OnTimer(nIDEvent);
				return;
			}
			
			UpdateData();
			FParameter fPara;
			pEOCard->GetParameter(&fPara);
			m_usOldPulseWidth = (USHORT)fPara.dDuty;
			m_usOldFrequency = fPara.Frequency;

			double dPulseWidth;
			m_edtPulseWidth.GetWindowText(strVal);
			dPulseWidth = atof(strVal);
			
			int nFrequency, nShotNo;
			m_edtFrequency.GetWindowText(strVal);
			nFrequency = atoi(strVal);
			m_edtShotNo.GetWindowText(strVal);
			nShotNo = atoi(strVal);

			m_nOld1stAOMOffset = gSystemINI.m_sSystemDevice.nDualAom1stOffset;
			m_nOld2ndAOMOffset = gSystemINI.m_sSystemDevice.nDualAom2ndOffset;
			
			m_edt1stAOMOffset.GetWindowText(strVal);
			gSystemINI.m_sSystemDevice.nDualAom1stOffset = atoi(strVal);
			
			m_edt2ndAOMOffset.GetWindowText(strVal);
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = atoi(strVal);

			m_edtAOMProfilePath.GetWindowText(strVal);
			memcpy(fPara.cAOMFilePath, strVal, strVal.GetLength()+1);

			CString strMessage, strSub;
			strMessage.Format(_T("Laser Beam Hole Fire "));

			if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
			{
				fPara.dDuty = 5000; // 50%
				double dCurrent;
				m_edtCurrent.GetWindowText(strVal);
				dCurrent = atof(strVal);
				
				int nThermalTrack;
				m_edtThermalTrack.GetWindowText(strVal);
				nThermalTrack = atoi(strVal);
				
				gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, nFrequency, nThermalTrack);
				strSub.Format(_T("| Freq. = %d | Current = %.3f | ThermalTrack = %d"), nFrequency, dCurrent, nThermalTrack);
			}
			else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				double dCurrent;
				m_edtCurrent.GetWindowText(strVal);
				dCurrent = atof(strVal);
				
				gDeviceFactory.GetLaser()->SetCurrent(dCurrent);
				
				fPara.dDuty = 5000; // 50%
				strSub.Format(_T("| Freq. = %d | Current = %.2f | Duty = %.2f"), nFrequency, dCurrent, dPulseWidth);
			}
			else
			{

				fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
				strSub.Format(_T("| Freq. = %d | Duty = %.2f"), nFrequency, dPulseWidth);
				fPara.dAOMDelay = dAOMDelay;
				fPara.dAOMDuty = dAOMDuty;
			}

			fPara.Frequency = static_cast<unsigned>(nFrequency);
			pEOCard->SetParameter(&fPara);
			
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strSub));

// SelfFire�� ����
//			gDeviceFactory.GetMotor()->HoodOpen(TRUE);
//			if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
//			{
//				ErrMessage(_T("Dust Suction Shutter On Error."));
//				return;
//			}

			m_btnScannerLine.EnableWindow(FALSE);
			m_btnStop.EnableWindow( TRUE );
			m_bLastSignal = TRUE;
			
			double dFireTime = 1.0 / nFrequency * (nShotNo - 0.5);
			double dWaitTime;
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{

				if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
					{
						gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
						gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
						ErrMsgDlg(STDGNALM781);
						return;
					}
				}
			}
			Sleep(100);
			int nPosX, nPosY;
			
			m_edtScannerX.GetWindowText(strVal);
			nPosX = atoi(strVal);
			
			m_edtScannerY.GetWindowText(strVal);
			nPosY = atoi(strVal);
			
//			gDeviceFactory.GetEocard()->DrillMove(FALSE, nPosX, nPosY, FALSE, nPosX, nPosY, FALSE);
			gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);

			CCorrectTime MyTestTime;
			MyTestTime.StartTime();
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
			pEOCard->LaserOnOff(TRUE);
			
			BYTE bSelfFire;
			do 
			{
				dWaitTime = MyTestTime.PresentTime();
				if(m_chkUseShotCount.GetCheck())
				{
					if(dWaitTime > dFireTime) 
					{
						m_bStopFire = TRUE;
						break;
					}
				}
				else
				{
					#ifndef __MP920_MOTOR__
						bSelfFire = gDeviceFactory.GetMotor()->GetExternalLaser();
					#else
						bSelfFire = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
					#endif

					if(!(bSelfFire & 0x01))
						break;
				}
				MessageLoop();
				::Sleep(0);
				
			} while(!m_bStopFire);
			
			m_bStopFire = FALSE;
			
			pEOCard->LaserOnOff(FALSE);

			do 
			{
				#ifndef __MP920_MOTOR__
					bSelfFire = gDeviceFactory.GetMotor()->GetExternalLaser();
				#else
					bSelfFire = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
				#endif

				if(!(bSelfFire & 0x01))
					break;
				MessageLoop();
				::Sleep(0);
				
			} while(!m_bStopFire);

			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			BOOL bOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && bOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
						gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
						ErrMsgDlg(STDGNALM781);
						return;
					}
				}
			}
			gDeviceFactory.GetMotor()->IonizerOn(FALSE);
			gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);

			gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
			
			fPara.dDuty = m_usOldPulseWidth;
			fPara.Frequency = m_usOldFrequency;
			pEOCard->SetParameter(&fPara);
			m_bLastSignal = FALSE;
			
			m_btnScannerLine.EnableWindow(TRUE);
			m_btnStop.EnableWindow( FALSE );
		}		
//		m_bLastSignal = TRUE;
	}
/*	else
	{
		if(m_bLastSignal == TRUE)
		{
			pEOCard->LaserOnOff(FALSE);

			FParameter fPara;
			fPara.dDuty = m_usOldPulseWidth;
			fPara.Frequency = m_usOldFrequency;
			pEOCard->SetParameter(&fPara);
			m_btnScannerLine.SetWindowText(_T("Fire"));
			m_btnScannerLine.EnableWindow(TRUE);

// SelfFire�� ����
//			gDeviceFactory.GetMotor()->HoodOpen(FALSE);
//			if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
//			{
//				ErrMessage(_T("Dust Suction Shutter Off Error."));
//			}
		}
		m_bLastSignal = FALSE;
	}
*/	
#endif
	CString str, str2;
	int nPulse = gDeviceFactory.GetAttenuator()->GetCurrentPos();
	str2 = gDeviceFactory.GetAttenuator()->GetError();
	str.Format(_T(" Pulses : %d / %s"), nPulse, str2);
	GetDlgItem(IDC_STATIC_ATTEN_POS)->SetWindowText(str);
	CFormView::OnTimer(nIDEvent);

	switch(m_nMPGMode )
	{
		case 0:
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
			break;
		case 1:
			m_btnMPG.SetWindowText("MPG Mode 2");
			m_btnMPG.SetToolTipText("M1, B1, B2");
			break;
		case 2:
			m_btnMPG.SetWindowText("MPG Mode 3");
			m_btnMPG.SetToolTipText("LC, UC");
			break;
	}
}

BOOL CPaneSysSetupLaserScannerPusan1::CheckParam()
{
	UpdateData(TRUE);
	
	BOOL bFlag = TRUE;
	
	CString strVal;
	m_edtFrequency.GetWindowText(strVal);
	int nFrequency = atoi(strVal); 
	
	m_edtCurrent.GetWindowText(strVal);
	double dCurrent = atof(strVal);
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		if (nFrequency >= 15000 && nFrequency <= 100000)
			bFlag = TRUE;
		else
			bFlag = FALSE;
		
		if (dCurrent > 0 && dCurrent <= 100)
			bFlag = bFlag & TRUE;
		else
			bFlag = bFlag & FALSE;
	}
	return bFlag;
}

BOOL CPaneSysSetupLaserScannerPusan1::CheckPulseWidth()
{
	UpdateData(TRUE);

	CString strVal;
	m_edtPulseWidth.GetWindowText(strVal);
	double dPulseWidth = atof(strVal);

	int nFrequency;
	m_edtFrequency.GetWindowText(strVal);
	nFrequency = atoi(strVal);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if (dPulseWidth / (10000 / nFrequency) >= m_dPulseMin &&
			dPulseWidth / (10000 / nFrequency) <= m_dPulseMax)
			return TRUE;
		else
			return FALSE;
	}
	return TRUE;
}

void CPaneSysSetupLaserScannerPusan1::MessageLoop()
{
	MSG msg;
	
	if(::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		CRect rtPos;
		GetDlgItem(IDC_BUTTON_MAIN_SHT_OPEN)->GetWindowRect( rtPos ); // ���� �ִ� tab�� disable ���� �ʾƼ� �߰�
		if(msg.pt.y < rtPos.top)
			return; // ���� �ִ� tab�� disable ���� �ʾƼ� �߰�
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}

void CPaneSysSetupLaserScannerPusan1::EnableAllButton(BOOL bEnable)
{
	EnableButton(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}

void CPaneSysSetupLaserScannerPusan1::EnableButton(BOOL bUse)
{
	if(gSystemINI.m_sHardWare.nLaserType != LASER_IPGPULSE)
	{
		m_btnMainShtOpen.EnableWindow(bUse);
		m_btnMainShtClose.EnableWindow(bUse);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA &&
		gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{
		m_btn1stPanelShtOpen.EnableWindow(bUse);
		m_btn1stPanelShtClose.EnableWindow(bUse);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() != 1)
	{
		m_btn2ndPanelShtOpen.EnableWindow(bUse);
		m_btn2ndPanelShtClose.EnableWindow(bUse);
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow( bUse );
	}

	m_btnPDetectorShtOpen.EnableWindow(bUse);
	m_btnPDetectorShtClose.EnableWindow(bUse);

	m_btnMPG.EnableWindow( bUse );
		
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		m_edtCurrent.EnableWindow(bUse);
		m_edtThermalTrack.EnableWindow(bUse);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		m_edtCurrent.EnableWindow(bUse);
		m_edtThermalTrack.EnableWindow(bUse);

		m_edtTargetA.EnableWindow(bUse);	//	2011520 ����
		m_btnLaserDlgShow.EnableWindow(bUse);
		m_btnAttenMove.EnableWindow(bUse);
		m_btnAttenHome.EnableWindow(bUse);
		m_btnMPG.EnableWindow( FALSE );
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			m_edtCurrent.EnableWindow(bUse);
		else
			m_edtPulseWidth.EnableWindow(bUse);
		m_edtFrequency.EnableWindow(bUse);
		m_edtAOMDelay.EnableWindow(bUse);
		m_edtAOMDuty.EnableWindow(bUse);
		m_edtShotNo.EnableWindow(bUse);
	}
	
	m_edtScannerX.EnableWindow(bUse);
	m_edtScannerY.EnableWindow(bUse);
	
	m_btnScannerLine.EnableWindow(bUse);
	m_btnAOMOpen.EnableWindow(bUse);

	//
	GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C2)->EnableWindow( bUse );
	//2011520
	
	m_btnMove.EnableWindow( bUse );
	m_btnMove2.EnableWindow( bUse );
	m_btnManualSCalPosMove.EnableWindow( bUse );
	// MPG Mode
}

void CPaneSysSetupLaserScannerPusan1::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
		EnableButton(FALSE);
		m_bUseSelfShot = FALSE;
		break;
	case 1:
	case 2:
	case 3:
		EnableButton(TRUE);
		m_bUseSelfShot = TRUE;
		break;
	}
}

void CPaneSysSetupLaserScannerPusan1::OnButtonMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if(!m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2
		&&!m_bTargetA && !m_bTargetA2 && !m_bTargetM3)		//2011520
		return;
	
	EnableAllButton( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X
	double dPosX, dPosY;
	pMotor->GetPosition(AXIS_X, dPosX);
	pMotor->GetPosition(AXIS_Y, dPosY);
	
	// Z1
	m_edtTargetZ1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2
	m_edtTargetZ2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2 
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );
	
	// M3 
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );

	// C
	m_edtTargetC.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );

	//C2
	m_edtTargetC2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	BOOL bTophat = m_chkUseTophat.GetCheck();

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();// = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}

	pMotor->MotorMoveXYZMC3(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosC, dPosC2, TRUE, AUTORUN_MOVE, FALSE, TRUE);	
	
	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A1 + IND_A2);

	EnableAllButton(TRUE);
	
	if( FALSE != nRet )
	{
//		m_btnStop.EnableWindow( FALSE );
	}
}

void CPaneSysSetupLaserScannerPusan1::OnButtonMove2() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if(!m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2
		&&!m_bTargetA && !m_bTargetA2 && !m_bTargetM3)		//2011520
		return;
	
	EnableAllButton( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X
	double dPosX, dPosY;
	pMotor->GetPosition(AXIS_X, dPosX);
	pMotor->GetPosition(AXIS_Y, dPosY);
	
	// Z1
	m_edtTargetZ1_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2
	m_edtTargetZ2_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2 
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );
	
	// M3 
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );

	// C
	m_edtTargetC1_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );

	//C2
	m_edtTargetC2_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	BOOL bTophat = m_chkUseTophat.GetCheck();

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();// = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}

	pMotor->MotorMoveXYZMC3(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosC, dPosC2, TRUE, AUTORUN_MOVE, FALSE, TRUE);	
	
	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A1 + IND_A2);

	EnableAllButton(TRUE);
	
	if( FALSE != nRet )
	{
//		m_btnStop.EnableWindow( FALSE );
	}
}

double CPaneSysSetupLaserScannerPusan1::GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if( FALSE == bUse )
		return pMotor->GetPosition( nAxisNo );
	
	double dPos = 0.;
	
	if( FALSE == bAbs ) // Relative Movement
	{
		dPos = dMovePos + pMotor->GetPosition( nAxisNo );
	}
	else // ABS Movement
		dPos = dMovePos;
	
	return dPos;
}

void CPaneSysSetupLaserScannerPusan1::OnButtonOpenLaserDlg() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetLaser()->OpenPowerDlg();
}

void CPaneSysSetupLaserScannerPusan1::OnButtonMoveAtten() 
{
	// TODO: Add your control notification handler code here
	CString strData;
	UpdateData(TRUE);
	EnableAllButton( FALSE );
	m_edtTargetA.GetWindowText( strData );
	int nTemp = atoi( (LPSTR)(LPCTSTR)strData );
	if(!gDeviceFactory.GetAttenuator()->Move(nTemp))
	{
		EnableAllButton(TRUE);
		return;
	}
	if(!gDeviceFactory.GetAttenuator()->IsInposition())
	{
		EnableAllButton(TRUE);
		return;
	}
	
	EnableAllButton(TRUE);
}

void CPaneSysSetupLaserScannerPusan1::OnButtonHomeAtten() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetAttenuator()->HomingCmd();
}

void CPaneSysSetupLaserScannerPusan1::OnButtonAomProfile() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] = _T("AOM File (*.aom)|*.aom|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.aom"), NULL, dwFlags, szFilter);

	CString strPath;
	m_edtAOMProfilePath.GetWindowText(strPath);
	int nLength = strPath.GetLength();
	int nIndex;
	if(nLength > 0)
	{
		nIndex = strPath.ReverseFind(_T('\\'));
		strPath = strPath.Left(nIndex);
	}
	else
		strPath = gEasyDrillerINI.m_clsDirPath.GetRootDir() + "AOM\\";

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	m_edtAOMProfilePath.SetWindowText(dlg.GetPathName());
}

void CPaneSysSetupLaserScannerPusan1::OnButtonPowerDetectorOn() 
{
	// TODO: Add your control notification handler code here
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, TRUE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, TRUE, TRUE);
#endif

	::Sleep(1000);
	
	LONG lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO3);

#ifndef __MP920_MOTOR__
	if(lStatus & 0x0100)
		m_btnPDetectorShtOpen.SetClick( 1 );
	else
		m_btnPDetectorShtOpen.SetClick( 0 );
	
	if(lStatus & 0x0200)
		m_btnPDetectorShtClose.SetClick( 1 );
	else
		m_btnPDetectorShtClose.SetClick( 0 );
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, TRUE, TRUE);
	::Sleep(1000);
	if(gDeviceFactory.GetMotor()->IsStatus(IS_OPEN_LASER_SHUTTER))
	{
		m_btnPDetectorShtOpen.SetClick( 1 );
		m_btnPDetectorShtClose.SetClick( 0 );
	}
	else
	{
		m_btnPDetectorShtOpen.SetClick( 0 );
		m_btnPDetectorShtClose.SetClick( 1 );
	}
#endif

}

void CPaneSysSetupLaserScannerPusan1::OnButtonPowerDetectorOff() 
{
	// TODO: Add your control notification handler code here
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
	
	::Sleep(1000);
	
	LONG lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO3);
	
#ifndef __MP920_MOTOR__
	if(lStatus & 0x0100)
		m_btnPDetectorShtOpen.SetClick( 1 );
	else
		m_btnPDetectorShtOpen.SetClick( 0 );

	if(lStatus & 0x0200)
		m_btnPDetectorShtClose.SetClick( 1 );
	else
		m_btnPDetectorShtClose.SetClick( 0 );

#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
	::Sleep(1000);
	if(gDeviceFactory.GetMotor()->IsStatus(IS_OPEN_LASER_SHUTTER))
	{
		m_btnPDetectorShtOpen.SetClick( 1 );
		m_btnPDetectorShtClose.SetClick( 0 );
	}
	else
	{
		m_btnPDetectorShtOpen.SetClick( 0 );
		m_btnPDetectorShtClose.SetClick( 1 );
	}
#endif
}

int CPaneSysSetupLaserScannerPusan1::GetMPGMode()
{
	return m_nMPGMode;
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos0()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );

	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);

}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos1()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);

}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos2()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos3()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos4()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos5()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos6()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
		
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos7()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}
void CPaneSysSetupLaserScannerPusan1::OnButtonPos8()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
	
}

void CPaneSysSetupLaserScannerPusan1::ResetScannerBtn()
{
	memset(m_bScannerPos, 0 , sizeof(m_bScannerPos));

	((CButton*)GetDlgItem(IDC_BUTTON_POS0))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS1))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS3))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS4))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS5))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS6))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS7))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS8))->SetCheck(FALSE);

}
void CPaneSysSetupLaserScannerPusan1::OnCheckApplyAscFile()
{
	BOOL bCheck = m_chkApplyAsc.GetCheck();
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, bCheck);
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, bCheck);

}

void CPaneSysSetupLaserScannerPusan1::OnButtonManualSCalPosMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

	EnableAllButton( FALSE );


	// X, Y
	double dPosX, dPosY;
	dPosX = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2  + 10;
	dPosY = (gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY)/2;

	pMotor->MoveXY(dPosX,dPosY);

	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y);

	EnableAllButton(TRUE);

	if(!nRet)
	{
		ErrMessage(_T("Move Fail"));
	}
}



BOOL CPaneSysSetupLaserScannerPusan1::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Align) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupLaserScannerPusan1::OnClickedCheckSubUseTophat3()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bLaserPath = m_chkBeamPass.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}
}

void CPaneSysSetupLaserScannerPusan1::OnButtonGetLpcStop() 
{
	// TODO: Add your control notification handler code here
	m_bLPCStop = TRUE;
}

BOOL CPaneSysSetupLaserScannerPusan1::SaveLPCFile(int nMinTime, int nMinDuty, int nTimeNo, int nDutyNo, double* pdValMin, double* pdValMax)
{
	FILE* fp = NULL;
	double dCalGap = 1.0;
	CString strFileName = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	strFileName +=  _T("LPC.table");
	
	if (NULL == fopen_s(&fp, strFileName, "w"))
	{
		fprintf(fp, "%d\t%d\t%f\n", nTimeNo, nDutyNo, dCalGap);
		
		// index = GridSize * nX + nY
		for (int i = 0; i < nTimeNo; i++)
		{
			for (int j = 0; j < nDutyNo; j++)
			{
				fprintf(fp, "%lf\t%lf\t%lf\t%lf\n",
					nMinTime + i * dCalGap,
					nMinDuty + j * dCalGap,
					pdValMin[i + j * nTimeNo],
					pdValMax[i + j * nTimeNo]);
			}
		}
		fclose(fp);
		
		gDeviceFactory.GetEocard()->UpdateLPCCalibrationFile(gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
		
		CString strEvent;
		strEvent = _T("Saved LPC Table calibration file.");
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strFileName));
		
		return TRUE;
	}
	else
	{
		ErrMessage(_T("Can not LPC write file"));
		return FALSE;
	}
}

void CPaneSysSetupLaserScannerPusan1::OnButLpcDist() 
{ 
#ifdef __LPC_FOR_3RD_AOD__
	// TODO: Add your control notification handler code here
	m_bLPCStop = FALSE;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_MASTER, FALSE);

	BYTE nShutter2 = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter2 == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_SLAVE, FALSE);

	if(nShutter == 1 || nShutter2 == 1)
	{
		::Sleep(1000);
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 1st panel shutter"));
			return;
		}
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 2nd panel shutter"));
			return;
		}
	}

	if(!gDeviceFactory.GetLaser()->IsPowerOn())
	{
		ErrMessage(_T("First Turn on Laser"));
		return;
	}

	if(gSystemINI.m_sSystemDump.nStandbyDuty / (1000000. / gSystemINI.m_sSystemDump.nStandbyMaxFreq) * 100  >
		 gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent)
	{
		ErrMessage(_T("Too high Standby Duty or Standby Max. Freq."));
		return;
	}

	// fire
	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
//	subTool.nDrawStep = 5;
	subTool.nJumpStep = 5;
	subTool.nJumpStepPeriod = 30;
	subTool.nDrawStepPeriod = 20;
	subTool.nCornerDelay = 10;
	subTool.nJumpDelay = 0;
	subTool.nLineDelay = 10;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1500;
	subTool.nFPS = 0;
	// Drill
	subTool.nShotMode = 1;
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 0;
//	subTool.dShotDuty[MAX_SHOT];
//	subTool.dShotAOMDelay[MAX_SHOT];
//	subTool.dShotAOMDuty[MAX_SHOT];
	subTool.nMask = 1;
	subTool.bUseAperture = 0;
	subTool.nApertureBurst = 1;
	subTool.nThermalTrack = 0;
	subTool.dZOffset = 0;
	subTool.bUseTophat = FALSE;
	subTool.cFilePath[0] = NULL;

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		memcpy(subTool.cAOMFilePath[i], str, str.GetLength()+1);

	// 
	int nMinDuty = gSystemINI.m_sSystemDump.nStandbyInpositionTime, nMaxDuty = gSystemINI.m_sSystemDump.nStandbyDuty;
	int nDutyNo = nMaxDuty - nMinDuty + 1;
	gDeviceFactory.GetEocard()->ShotDataReset();
	double dMinVal = 0, dMaxVal = 0;
	int	nDist[2000];

	for(int kkk = 0; kkk < 3; kkk++)
	{
		CTime ct = CTime::GetCurrentTime();
		CString strPath;
		strPath.Format(_T("%s\\LPCTable_%2d%2d%2d%2d%2d_%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetTempDir(), 
			ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(),ct.GetSecond());
		CString strLogFile;
		
		FILE* pfile;
		errno_t err = fopen_s(&pfile, strPath, "w+");
		if(err != 0)
			pfile = NULL;

		gDeviceFactory.GetEocard()->ShotDataReset();

		for(int i = 0; i < 1000; i++)
		{
			nDist[i] = (abs(rand()) * 2) % 65535;
			gDeviceFactory.GetEocard()->DownloadShotData2(nDist[i], 32767, 32767, 32767, TRUE, TRUE, 1);
			if(i > 0)
				TRACE("%d\n", abs(nDist[i] - nDist[i-1]));
		}

		for(int i = nMinDuty; i <= nMaxDuty; i++)
		{
			strLogFile.Format(_T("%s%d.txt"), strPath, i);
			FILE* pfile2;
			errno_t err2 = fopen_s(&pfile2, strLogFile , "w+");
			if(err2 != 0)
				pfile2 = NULL;
	
			subTool.dShotMinFreq[0] = subTool.dShotMaxFreq[0] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;
			subTool.dShotDuty[0] = i;
			subTool.dShotAOMDelay[0] = 0;
			subTool.dShotAOMDuty[0] = i;

			gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool, TRUE);

			gDeviceFactory.GetEocard()->FieldPreStart();
			gDeviceFactory.GetEocard()->FieldStart(FALSE);
			
			BOOL bResult = TRUE;
			::Sleep(100);
			do
			{
				::Sleep(1);
				bResult = gDeviceFactory.GetEocard()->IsDSPBusy();

				if(gDeviceFactory.GetEocard()->IsMotorFault())
				{
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Stop : Scanner Motor Fault"));
					return;
				}
					
				MessageLoop();
				if(m_bLPCStop)
				{
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Stop"));
					return;
				}
			}while(bResult); 

			if(!gDeviceFactory.GetEocard()->SetLPCDataReadReady())
			{
				ErrMessage(_T("Error SetLPCDataReadReady"));
				if(pfile) fclose(pfile);
				if(pfile2) fclose(pfile2);
				return;
			}

			do
			{
				::Sleep(10);
				bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
					
				MessageLoop();
				if(m_bLPCStop)
				{
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Stop"));
					return;
				}
			}while(bResult);
				
			TLpc_Buffer*  pLPC_Data;
			pLPC_Data = gDeviceFactory.GetEocard()->GetLPCResult();

			if(pLPC_Data == NULL)
			{
				if(pfile) fclose(pfile);
				if(pfile2) fclose(pfile2);
				ErrMessage(_T("Get data Fail"));
				return;
			}
				
			dMinVal = 1000000;
			dMaxVal = -1000000;

			for(int k = 1; k < (int)pLPC_Data->HoleCount.nTotal; k++)
			{
				if(pfile2) 
				{
					fprintf(pfile2,_T("duty = \t%d\t  \t%.3f\t %.3f\t Dist LSB \t%d\t\n"), 
						i,	(double)(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16),
						(double)(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16) * 5. / 4096, 
						nDist[k] - nDist[k-1]);
				}
				if(dMinVal > pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
					dMinVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
				if(dMaxVal < pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
					dMaxVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
			}

			if(pfile) 
				fprintf(pfile, _T("duty = \t%d\t  \t%.3f\t %.3f\t\n"), 
									i, dMinVal, dMaxVal);

			::Sleep(10);
			if(pfile2) fclose(pfile2);
		}
		if(pfile) fclose(pfile);
	}
	ErrMessage(_T("End"));
#endif
}


void CPaneSysSetupLaserScannerPusan1::OnButtonGetLpcData() 
{
#ifdef __LPC_FOR_3RD_AOD__
	// TODO: Add your control notification handler code here
	m_bLPCStop = FALSE;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_MASTER, FALSE);

	BYTE nShutter2 = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter2 == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_SLAVE, FALSE);

	if(nShutter == 1 || nShutter2 == 1)
	{
		::Sleep(1000);
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 1st panel shutter"));
			return;
		}
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 2nd panel shutter"));
			return;
		}
	}
	
	if(!gDeviceFactory.GetLaser()->IsPowerOn())
	{
		ErrMessage(_T("First Turn on Laser"));
		return;
	}

	if(gSystemINI.m_sSystemDump.nStandbyDuty / (1000000. / gSystemINI.m_sSystemDump.nStandbyMaxFreq) * 100  >
		 gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent)
	{
		ErrMessage(_T("Too high Standby Duty or Standby Max. Freq."));
		return;
	}
	
	// fire
	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
//	subTool.nDrawStep = 5;
	subTool.nJumpStep = 5;
	subTool.nJumpStepPeriod = 30;
	subTool.nDrawStepPeriod = 20;
	subTool.nCornerDelay = 10;
	subTool.nJumpDelay = 0;
	subTool.nLineDelay = 10;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1500;
	subTool.nFPS = 0;
	// Drill
	subTool.nShotMode = 1;
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 0;
//	subTool.dShotDuty[MAX_SHOT];
//	subTool.dShotAOMDelay[MAX_SHOT];
//	subTool.dShotAOMDuty[MAX_SHOT];
	subTool.nMask = 1;
	subTool.bUseAperture = 0;
	subTool.nApertureBurst = 1;
	subTool.nThermalTrack = 0;
	subTool.dZOffset = 0;
	subTool.bUseTophat = FALSE;
	subTool.cFilePath[0] = NULL;

	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(1))
	{
		ErrMsgDlg(STDGNALM445);
		return;
	}

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		memcpy(subTool.cAOMFilePath[i], str, str.GetLength()+1);

	// 
	int nMinDuty = gSystemINI.m_sSystemDump.nStandbyInpositionTime, nMaxDuty = gSystemINI.m_sSystemDump.nStandbyDuty;
	int nMinTime = (int)(1000000. / gSystemINI.m_sSystemDump.nStandbyMaxFreq);
	int nMaxTime = (int)(1000000. / gSystemINI.m_sSystemDump.nStandbyMinFreq);
	nMaxTime = min(nMaxTime, 1000);
	int nDutyNo = nMaxDuty - nMinDuty + 1;
	int nTimeGap = 100;
	int nTimeNo = (nMaxTime - nMinTime) / nTimeGap + 1;
	double* pdValMin, *pdValMax;
	pdValMin = new double [nDutyNo * nTimeNo];
	pdValMax = new double [nDutyNo * nTimeNo];
	double dMinVal, dMaxVal;

	for(int kkk = 0; kkk < 5; kkk++)
	{
		CTime ct = CTime::GetCurrentTime();
		CString strPath;
		strPath.Format(_T("%s\\LPCTable_%2d%2d%2d%2d%2d_%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetTempDir(), 
			ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(),ct.GetSecond());
		CString strLogFile;
		
		FILE* pfile;
		errno_t err = fopen_s(&pfile, strPath, "w+");
		if(err != 0)
			pfile = NULL;

		gDeviceFactory.GetEocard()->ShotDataReset();

		for(int i = 0; i < 25; i++)
		{
			gDeviceFactory.GetEocard()->DownloadShotData2(32767, 32767, 32767, 32767, TRUE, TRUE, 1);
			gDeviceFactory.GetEocard()->DownloadShotData2(32787, 32787, 32787, 32787, TRUE, TRUE, 1);
		}

		for(int i = nMinDuty; i <= nMaxDuty; i++)
		{
			strLogFile.Format(_T("%s%d.txt"), strPath, i);
			FILE* pfile2;
			errno_t err2 = fopen_s(&pfile2, strLogFile , "w+");
			if(err2 != 0)
				pfile2 = NULL;
			
			for(int j =0; j < nTimeNo; j++ )
			{
				subTool.dShotMinFreq[0] = subTool.dShotMaxFreq[0] = 1000000. / (nMinTime + j * nTimeGap);
				subTool.dShotDuty[0] = i;
				subTool.dShotAOMDelay[0] = 0;
				subTool.dShotAOMDuty[0] = i;

				gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool, FALSE, TRUE);

				gDeviceFactory.GetEocard()->FieldPreStart();
				gDeviceFactory.GetEocard()->FieldStart(FALSE);

				BOOL bResult = TRUE;
				::Sleep(100);
				do
				{
					::Sleep(1);
					bResult = gDeviceFactory.GetEocard()->IsDSPBusy();

					if(gDeviceFactory.GetEocard()->IsMotorFault())
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop : Scanner Motor Fault"));
						return;
					}
					
					MessageLoop();
					if(m_bLPCStop)
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop"));
						return;
					}
				}while(bResult); 

				if(!gDeviceFactory.GetEocard()->SetLPCDataReadReady())
				{
					delete pdValMax;
					delete pdValMin;
					ErrMessage(_T("Error SetLPCDataReadReady"));
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					return;
				}

				do
				{
					::Sleep(10);
					bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
					
					MessageLoop();
					if(m_bLPCStop)
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop"));
						return;
					}
				}while(bResult);
				
				TLpc_Buffer*  pLPC_Data;
				pLPC_Data = gDeviceFactory.GetEocard()->GetLPCResult();

				if(pLPC_Data == NULL)
				{
					delete pdValMax;
					delete pdValMin;
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Get data Fail"));
					return;
				}
	
				dMinVal = 1000000;
				dMaxVal = -1000000;
				for(int k = 0; k < (int)pLPC_Data->HoleCount.nTotal; k++)
				{
					if(pfile2) 
					{
						fprintf(pfile2,_T("duty =\t%d\t minTime =\t%.0f\t Val[\t%d\t] =\t%.3f\t %.3f \t\n"), 
							i, nMinTime + j * nTimeGap,
							( i - nMinDuty) * nTimeNo + j,
							(double)(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16),
							(double)(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16) * 5. / 4096);
					}
					if(dMinVal > pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
						dMinVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
					if(dMaxVal < pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
						dMaxVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
				}

				if(kkk == 0)
				{	
					pdValMin[ ( i - nMinDuty) * nTimeNo + j ] = dMinVal;
					pdValMax[ ( i - nMinDuty) * nTimeNo + j ] = dMaxVal;
				}
				else
				{
					if(pdValMin[ ( i - nMinDuty) * nTimeNo + j ] > dMinVal)
						pdValMin[ ( i - nMinDuty) * nTimeNo + j ] = dMinVal;

					if(pdValMax[ ( i - nMinDuty) * nTimeNo + j ] < dMaxVal)
						pdValMax[ ( i - nMinDuty) * nTimeNo + j ] = dMaxVal;
				}

				if(pfile) 
					fprintf(pfile, _T("duty =\t%d\t minTime =\t%.0f\t Val[\t%d\t] =\t%.3f\t %.3f \t\n"), 
						i, nMinTime + j * nTimeGap,
							( i - nMinDuty) * nTimeNo + j,
						pdValMin[ ( i - nMinDuty) * nTimeNo + j ],
						pdValMax[ ( i - nMinDuty) * nTimeNo + j ]);

				::Sleep(10);
			}
			if(pfile2)  fclose(pfile2);
		}
		if(pfile) fclose(pfile);
	}
	if(!SaveLPCFile(nMinTime, nMinDuty, nTimeNo, nDutyNo, pdValMin, pdValMax))
	{
		delete pdValMax;
		delete pdValMin;
		return;
	}
	delete pdValMax;
	delete pdValMin;
	ErrMessage(_T("End"));
#endif
}
