// PaneLogManagerSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerSub.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerSub

IMPLEMENT_DYNCREATE(CPaneLogManagerSub, CFormView)

CPaneLogManagerSub::CPaneLogManagerSub()
	: CFormView(CPaneLogManagerSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo			= 0;
}

CPaneLogManagerSub::~CPaneLogManagerSub()
{
}

void CPaneLogManagerSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerSub)
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerSub, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerSub diagnostics

#ifdef _DEBUG
void CPaneLogManagerSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerSub message handlers

void CPaneLogManagerSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneLogManagerSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
}

void CPaneLogManagerSub::OnButtonBack() 
{
/*	WPARAM wParam = DRILL;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 0 );*/
	
	// 110621
/*	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus() && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bLaser && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bInit)
	{
//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
		{		
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = TRUE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
		}
	}
*/	
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneLogManagerSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}
