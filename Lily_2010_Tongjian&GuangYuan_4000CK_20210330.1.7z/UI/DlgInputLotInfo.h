#if !defined(AFX_DLGINPUTLOTINFO_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
#define AFX_DLGINPUTLOTINFO_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputLotInfo.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLotInfo dialog
class DAreaInfo;

class CDlgInputLotInfo : public CDialog
{
// Construction
public:
	CDlgInputLotInfo(CWnd* pParent = NULL);   // standard constructor

	void		InitControl();
	void		SetInputLot(int nLot)	{ m_nInputLot = nLot; }
	int			GetInputLot()			{ return m_nInputLot; }
	void		SetStartNo(int nStartNo)	{ m_nStartNo = nStartNo; }
	int			GetStartNo()			{ return m_nStartNo; }
	void		SetAutoRun(BOOL bAutoRun) {m_bAutoRun = bAutoRun;}
	void		SetSelectFire(BOOL bSelectfire) {m_bSelectFire = bSelectfire;}
	void		SetData();
	void		InitListControl();
	BOOL IsAvailableArea(DAreaInfo* pAreaInfo, int nToolNo, int nFidBlock);
	CString SelectField();
// Dialog Data
	//{{AFX_DATA(CDlgInputLotInfo)
	enum { IDD = IDD_DLG_INPUT_LOT_INFO };
	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnCancel;
	CColorEdit	m_edtStartNo;
	CColorEdit	m_edtInputLot;
	UEasyButtonEx	m_chkData;
	UEasyButtonEx	m_chkSelect;
	UEasyButtonEx	m_chkBeampath;
	UEasyButtonEx	m_chkField;
	UEasyButtonEx	m_chkLotCount;
	BOOL			m_bAutoRun;
	BOOL			m_bSelectFire;
	CFont			m_fntList;
	CListCtrl m_listBoardParam;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputLotInfo)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	int				m_nInputLot;
	int				m_nStartNo;

	// Generated message map functions
	//{{AFX_MSG(CDlgInputLotInfo)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnCheckData();
	afx_msg void OnCheckSelect();
	afx_msg void OnCheckBeampath();
	afx_msg void OnCheckField();
	afx_msg void OnCheckLotCount();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTLOTINFO_H__00C1EA6B_0CE1_4D01_A7FD_C6062ED33B95__INCLUDED_)
