// PaneAutoRunViewSystem.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewSystem.h"
#include "..\model\DProject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewSystem

IMPLEMENT_DYNCREATE(CPaneAutoRunViewSystem, CFormView)

CPaneAutoRunViewSystem::CPaneAutoRunViewSystem()
	: CFormView(CPaneAutoRunViewSystem::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewSystem)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneAutoRunViewSystem::~CPaneAutoRunViewSystem()
{
}

void CPaneAutoRunViewSystem::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewSystem)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewSystem, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewSystem)
		ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewSystem diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewSystem::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewSystem::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewSystem message handlers

BOOL CPaneAutoRunViewSystem::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewSystem::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	memset(&m_sSystemDump, 0 , sizeof(m_sSystemDump));

}

void CPaneAutoRunViewSystem::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	GetDlgItem(IDC_STATIC_DUMMY_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_INTERVAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PULSE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUMMY_COUNT_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_INTERVAL_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PULSE_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DELAY_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_DUTY_VAL)->SetFont( &m_fntStatic );


	GetDlgItem(IDC_STATIC_STANDBY_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MIN_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAX_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STAND_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STAND_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_INPOSITION_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_TIME_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MIN_FREQ_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAX_FREQ_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STAND_FREQ_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_STAND_DUTY_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_INPOSITION_TIME_VAL)->SetFont( &m_fntStatic );




}
HBRUSH CPaneAutoRunViewSystem::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_DUMMY_INFO)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_STANDBY_INFO)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewSystem::ChangeDisplay()
{
	CString str;
	str.Format(_T("%d"), m_sSystemDump.nDummyShot);
	GetDlgItem(IDC_STATIC_DUMMY_COUNT_VAL)->SetWindowText(str);

	str.Format(_T("%d"), m_sSystemDump.nDummyInterval);
	GetDlgItem(IDC_STATIC_INTERVAL_VAL)->SetWindowText(str);

	str.Format(_T("%d"), m_sSystemDump.nDummyFreq);
	GetDlgItem(IDC_STATIC_FREQ_VAL)->SetWindowText(str);

	str.Format(_T("%d"), m_sSystemDump.nDummyDuty);
	GetDlgItem(IDC_STATIC_PULSE_VAL)->SetWindowText(str);

	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDelay);
	GetDlgItem(IDC_STATIC_AOM_DELAY_VAL)->SetWindowText(str);
	
	str.Format(_T("%d"), m_sSystemDump.nDummyAOMDuty);
	GetDlgItem(IDC_STATIC_AOM_DUTY_VAL)->SetWindowText(str);


	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
	{
		str.Format(_T("%d"), m_sSystemDump.nStandbyTime);
		GetDlgItem(IDC_STATIC_SHOT_TIME_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyMinFreq);
		GetDlgItem(IDC_STATIC_MIN_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyMaxFreq);
		GetDlgItem(IDC_STATIC_MAX_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyInterval);
		GetDlgItem(IDC_STATIC_STAND_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyDuty);
		GetDlgItem(IDC_STATIC_STAND_DUTY_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyInpositionTime);
		GetDlgItem(IDC_STATIC_INPOSITION_TIME_VAL)->SetWindowText(str);
	}
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
	{
		str.Format(_T("%d"), m_sSystemDump.nStandbyTime2);
		GetDlgItem(IDC_STATIC_SHOT_TIME_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyMinFreq2);
		GetDlgItem(IDC_STATIC_MIN_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyMaxFreq2);
		GetDlgItem(IDC_STATIC_MAX_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyInterval2);
		GetDlgItem(IDC_STATIC_STAND_FREQ_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyDuty2);
		GetDlgItem(IDC_STATIC_STAND_DUTY_VAL)->SetWindowText(str);
		
		str.Format(_T("%d"), m_sSystemDump.nStandbyInpositionTime2);
		GetDlgItem(IDC_STATIC_INPOSITION_TIME_VAL)->SetWindowText(str);
	}


}

void CPaneAutoRunViewSystem::SetSystemData(SSYSTEMDUMP sSystemDump)
{
	memcpy( &m_sSystemDump, &sSystemDump, sizeof(m_sSystemDump) );
	ChangeDisplay();
}
