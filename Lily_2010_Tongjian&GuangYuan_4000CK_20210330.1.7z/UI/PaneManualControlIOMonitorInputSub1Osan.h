#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB1OSAN_H__54B431A0_5687_4972_97E2_157FD7F078F3__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUTSUB1OSAN_H__54B431A0_5687_4972_97E2_157FD7F078F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInputSub1Osan.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub1Osan form view

#include "LedButton.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorInputSub1Osan : public CFormView
{
protected:
	CPaneManualControlIOMonitorInputSub1Osan();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInputSub1Osan)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInputSub1Osan)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT_SUB1_OSAN };
	CFont m_fntBtn;
	CLedButton m_ledMainMotorReady;
	CLedButton m_ledPLCalivePulse;
	CLedButton m_ledMachineRun;
	CLedButton m_ledSafetyMode;
	CLedButton m_ledDoorByPass;
	CLedButton m_ledTable1PCB;
	CLedButton m_ledTable2PCB;
	CLedButton m_ledMainInitComplete;
	CLedButton m_ledMainAlarm;
	CLedButton m_ledMainInitializing;
	CLedButton m_ledXInitComplete;
	CLedButton m_ledXInitializing;
	CLedButton m_ledXInposition;
	CLedButton m_ledXRun;
	CLedButton m_ledYInitComplete;
	CLedButton m_ledYInitializing;
	CLedButton m_ledYInposition;
	CLedButton m_ledYRun;
	CLedButton m_ledZ1InitComplete;
	CLedButton m_ledZ1Initializing;
	CLedButton m_ledZ1Inposition;
	CLedButton m_ledZ1Run;
	CLedButton m_ledZ2InitComplete;
	CLedButton m_ledZ2Initializing;
	CLedButton m_ledZ2Inposition;
	CLedButton m_ledZ2Run;
	CLedButton m_ledMInitComplete;
	CLedButton m_ledMInitializing;
	CLedButton m_ledMInposition;
	CLedButton m_ledMRun;
	CLedButton m_ledM2InitComplete;
	CLedButton m_ledM2Initializing;
	CLedButton m_ledM2Inposition;
	CLedButton m_ledM2Run;
	CLedButton m_ledCInitComplete;
	CLedButton m_ledCInitializing;
	CLedButton m_ledCInposition;
	CLedButton m_ledCRun;
	CLedButton m_ledC2InitComplete;
	CLedButton m_ledC2Initializing;
	CLedButton m_ledC2Inposition;
	CLedButton m_ledC2Run;
	CLedButton m_ledMasterShtExt;
	CLedButton m_ledMasterShtRet;
	CLedButton m_ledSlaveShtExt;
	CLedButton m_ledSlaveShtRet;
	CLedButton m_ledHeightSensorUp;
	CLedButton m_ledHeightSensorDown;
	CLedButton m_ledHeightSensorUp2;
	CLedButton m_ledHeightSensorDown2;
	CLedButton m_ledPowerDetectorFwd;
	CLedButton m_ledPowerDetectorBwd;
	CLedButton m_ledVacuumMotorOn;
	CLedButton m_ledTableClamp1;
	CLedButton m_ledTableUnclamp1;
	CLedButton m_ledTableClamp2;
	CLedButton m_ledTableUnclamp2;
	CLedButton m_ledSystemAir;
	CLedButton m_ledLoadingShutterOpen;
	CLedButton m_ledFrontDoor;
	CLedButton m_ledLeftDoor;
	CLedButton m_ledRear1Door;
	CLedButton m_ledRear2Door;
	CLedButton m_ledRightDoor;
	CLedButton m_ledStartSW;
	CLedButton m_ledStopSW;
	CLedButton m_ledResetSW;
	CLedButton m_ledBrushUp;
	CLedButton m_ledBrushDown;
	CLedButton m_ledLaserBeamPassUp;
	CLedButton m_ledLaserBeamPassDown;

	CLedButton m_ledA1InitComplete;						//2011519
	CLedButton m_ledA1Initializing;
	CLedButton m_ledA1Inposition;
	CLedButton m_ledA1Run;
	
	CLedButton m_ledA2InitComplete;
	CLedButton m_ledA2Initializing;
	CLedButton m_ledA2Inposition;
	CLedButton m_ledA2Run;

	CLedButton m_ledLaserSysWaring;						//2011518
	CLedButton m_ledLaserovertempFault;
	CLedButton m_ledPCBGuideAirBlower;	

	CLedButton m_ledTableXmotorOverTemp;			//2011526
	CLedButton m_ledTableYmotorOverTemp;
	
	CLedButton m_ledHoodOpen;
	CLedButton m_ledHoodClose;
	CLedButton m_ledHoodAirSensor;

	//}}AFX_DATA

// Attributes
public:
	int m_nTimerID;

	LONG m_lStatus1;
	LONG m_lStatus2;
	LONG m_lStatus3;
	LONG m_lStatus4;
	LONG m_lStatus5;		//2011518
	LONG m_lStatus1Old;
	LONG m_lStatus2Old;
	LONG m_lStatus3old;
	LONG m_lstatus4Old;
	LONG m_lstatus5Old;		//2011518

	LONG m_lTableLimit;
	LONG m_lTableError;
	LONG m_lTableLimitOld;
	LONG m_lTableErrorOld;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif
// Operations
public:
	void SetAuthorityByLevel(int nLevel);
	void UpdateStatus();

	void InitTimer();
	void DestroyTimer();

	void InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInputSub1Osan)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInputSub1Osan();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInputSub1Osan)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB1OSAN_H__54B431A0_5687_4972_97E2_157FD7F078F3__INCLUDED_)
