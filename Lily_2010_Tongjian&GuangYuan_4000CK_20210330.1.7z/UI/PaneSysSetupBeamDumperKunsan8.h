#if !defined(AFX_PANESYSSETUPBEAMDUMPERKUNSAN8_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)
#define AFX_PANESYSSETUPBEAMDUMPERKUNSAN8_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupBeamDumperKunsan8.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumperKunsan8 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "ColorEdit.h"

class CPaneSysSetupBeamDumperKunsan8 : public CFormView
{
protected:
	CPaneSysSetupBeamDumperKunsan8();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupBeamDumperKunsan8)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupBeamDumperKunsan8)
	enum { IDD = IDD_DLG_SYS_SETUP_BEAM_DUMPER_KUNSAN8 };
	UEasyButton	m_btnFire;
	UEasyButton	m_btn2ndPanelShtOpen;
	UEasyButton	m_btn2ndPanelShtClose;
	UEasyButton	m_btn1stPanelShtOpen;
	UEasyButton	m_btn1stPanelShtClose;
	UEasyButton	m_btnMainShtOpen;
	UEasyButton	m_btnMainShtClose;
	UEasyButton	m_btnModeSingleShot;
	UEasyButton	m_btnModeContinuous;
	CColorEdit	m_edt2ndPanelPosY;
	CColorEdit	m_edt2ndPanelPosX;
	CColorEdit	m_edt1stPanelPosY;
	CColorEdit	m_edt1stPanelPosX;
	CColorEdit	m_edtPulseWidth;
	CColorEdit	m_edtDummyShotNo;
	CColorEdit	m_edtDummyInterval;
	CColorEdit	m_edtDummyFreq;
	CColorEdit	m_edtDummyDuty;
	CColorEdit	m_edtDummyAOMDelay;
	CColorEdit	m_edtDummyAOMDuty;
	CColorEdit	m_edtDummyShotNo2;
	CColorEdit	m_edtDummyInterval2;
	CColorEdit	m_edtDummyFreq2;
	CColorEdit	m_edtDummyDuty2;
	CColorEdit	m_edtDummyAOMDelay2;
	CColorEdit	m_edtDummyAOMDuty2;

	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntEdit;

// Operations
public:
	void GetSystemDevice(SSYSTEMDUMP* pSystemDump);
	CString GetChangeValueStr();
	void SetSystemDevice(SSYSTEMDUMP sSystemDump);
	SSYSTEMDUMP			m_sSystemDump;
	void			OnApply();
	void			SetBeamDumperData();
	void		InitBtnControl();
	void		InitEditControl();
	void		InitStaticControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupBeamDumperKunsan8)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupBeamDumperKunsan8();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupBeamDumperKunsan8)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBtnMainShtOpen();
	afx_msg void OnBtnMainShtClose();
	afx_msg void OnBtn1stPanelShtOpen();
	afx_msg void OnBtn1stPanelShtClose();
	afx_msg void OnBtn2ndPanelShtOpen();
	afx_msg void OnBtn2ndPanelShtClose();
	afx_msg void OnButtonModeContinuous();
	afx_msg void OnButtonModeSingleShot();
	afx_msg void OnButtonFire();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPBEAMDUMPERKUNSAN8_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)
