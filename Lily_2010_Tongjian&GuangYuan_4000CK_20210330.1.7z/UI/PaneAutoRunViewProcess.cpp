// PaneAutoRunViewProcess.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewProcess.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewProcess

IMPLEMENT_DYNCREATE(CPaneAutoRunViewProcess, CFormView)

CPaneAutoRunViewProcess::CPaneAutoRunViewProcess()
	: CFormView(CPaneAutoRunViewProcess::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewProcess)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneAutoRunViewProcess::~CPaneAutoRunViewProcess()
{
}

void CPaneAutoRunViewProcess::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewProcess)
	DDX_Control(pDX, IDC_CHECK_DOOR_LOCK, m_ledMainDoorLock);
	DDX_Control(pDX, IDC_CHECK_NO_LU, m_ledNoUseLU);
	DDX_Control(pDX, IDC_CHECK_DRY_RUN, m_ledDryRun);
	DDX_Control(pDX, IDC_CHECK_NO_TABLE_SUCTION, m_ledNoUseSuction);
	DDX_Control(pDX, IDC_CHECK_NO_VISION, m_ledNoUseVision);
	DDX_Control(pDX, IDC_CHECK_NO_AOM_ALARM, m_ledNoAOMAlarm);
	DDX_Control(pDX, IDC_CHECK_NO_PAPER, m_ledNoUsePaper);
	DDX_Control(pDX, IDC_CHECK_NO_APPLY_SCANNER_RESULT, m_ledNoApplySCResult);
	DDX_Control(pDX, IDC_CHECK_NO_POWERCHECK_AFTER_LOT_END, m_ledNoUsePowerAfterLotEnd);
	DDX_Control(pDX, IDC_CHECK_NO_USE_PREWORK, m_ledNoUsePrework);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewProcess, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewProcess)
		ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewProcess diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewProcess::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewProcess::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewProcess message handlers

BOOL CPaneAutoRunViewProcess::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewProcess::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitBtnControl();
	memset(&m_sProcessSystem, 0, sizeof(m_sProcessSystem));
}

void CPaneAutoRunViewProcess::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_PROCESS_INFO)->SetFont( &m_fntStatic );

}
HBRUSH CPaneAutoRunViewProcess::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_PROCESS_INFO)->GetSafeHwnd() == pWnd->m_hWnd  )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewProcess::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	// MainDoorLock
	m_ledMainDoorLock.SetFont( &m_fntBtn );
	m_ledMainDoorLock.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainDoorLock.Depress( TRUE );
	
	
	// No use load unload
	m_ledNoUseLU.SetFont( &m_fntBtn );
	m_ledNoUseLU.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUseLU.Depress( TRUE );
	
	// Dry Run
	m_ledDryRun.SetFont( &m_fntBtn );
	m_ledDryRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledDryRun.Depress( TRUE );
	
	// No Use Suction
	m_ledNoUseSuction.SetFont( &m_fntBtn );
	m_ledNoUseSuction.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUseSuction.Depress( TRUE );
	
	// No use vision 
	m_ledNoUseVision.SetFont( &m_fntBtn );
	m_ledNoUseVision.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUseVision.Depress( TRUE );
	
	// No use Aom alarm
	m_ledNoAOMAlarm.SetFont( &m_fntBtn );
	m_ledNoAOMAlarm.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoAOMAlarm.Depress( TRUE );

	// No Use paper
	m_ledNoUsePaper.SetFont( &m_fntBtn );
	m_ledNoUsePaper.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUsePaper.Depress( TRUE );
	
	// No use Power check after lot end 
	m_ledNoUsePowerAfterLotEnd.SetFont( &m_fntBtn );
	m_ledNoUsePowerAfterLotEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUsePowerAfterLotEnd.Depress( TRUE );
	
	// No apply scanner result 
	m_ledNoApplySCResult.SetFont( &m_fntBtn );
	m_ledNoApplySCResult.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoApplySCResult.Depress( TRUE );

	//No Use Prework
	m_ledNoUsePrework.SetFont( &m_fntBtn );
	m_ledNoUsePrework.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoUsePrework.Depress( TRUE );
}

void CPaneAutoRunViewProcess::ChangeDisplay()
{
	//Main Door Lock
	m_ledMainDoorLock.Depress( !m_sProcessSystem.bLoaderUnloaderDoorLock );
	
	// No use load unload
	m_ledNoUseLU.Depress( !m_sProcessSystem.bNoUseLoaderUnloader );
	
	// Dry Run
	m_ledDryRun.Depress( !m_sProcessSystem.bDryRun );
	
	// No Use Suction
	m_ledNoUseSuction.Depress( !m_sProcessSystem.bNoUseSuction );
	
	// No use vision 
	m_ledNoUseVision.Depress( !m_sProcessSystem.bNoUseFiducialFind );
	
	// No use Aom alarm
	m_ledNoAOMAlarm.Depress( !m_sProcessSystem.bNoUseAOMAlarm );
	
	// No Use paper
	m_ledNoUsePaper.Depress( !m_sProcessSystem.bNoUsePaper );
	
	// No use Power check after lot end 
	m_ledNoUsePowerAfterLotEnd.Depress( !m_sProcessSystem.bNoUsePowerCheck );
	
	// No apply scanner result 
	m_ledNoApplySCResult.Depress( !m_sProcessSystem.bNoUseApplyScal );

	//No Use Prework
	m_ledNoUsePrework.Depress( !m_sProcessSystem.bNoUsePrework );
}

void CPaneAutoRunViewProcess::SetProcessData(SPROCESSSYSTEM sProcessSystem)
{
	memcpy( &m_sProcessSystem, &sProcessSystem, sizeof(m_sProcessSystem) );
	ChangeDisplay();
}
