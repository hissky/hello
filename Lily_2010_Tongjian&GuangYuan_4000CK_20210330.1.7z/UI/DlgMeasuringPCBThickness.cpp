// DlgMeasuringPCBThickness.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgMeasuringPCBThickness.h"
#include "..\model\deasydrillerini.h"
//#include "..\device\hmotor.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\Model\DProcessINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgMeasuringPCBThickness dialog

const UINT TIMER_HEIGHT		= 1;
const UINT HEIGHT_INTERVAL	= 100;

CDlgMeasuringPCBThickness::CDlgMeasuringPCBThickness(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMeasuringPCBThickness::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgMeasuringPCBThickness)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_dThickness		= 0.;
	m_d2ndThickness		= 0.;
	memset( &m_dMeasurementPos, 0, sizeof(m_dMeasurementPos) );
	m_bAutoStart = FALSE;
	m_bOnTimer = FALSE;
	m_bEnableHeadSelect = TRUE;
	m_bAcrylSuction = FALSE;
	m_bZCalEnable = TRUE;

	for(int i = 0; i < 4; i++)
		m_dMinMaxValue[i] = 0;

	m_bStop = FALSE;
	m_bAcrylFlat = FALSE;
}


void CDlgMeasuringPCBThickness::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgMeasuringPCBThickness)
	DDX_Control(pDX, IDC_EDIT_POS_Y, m_edtPosY);
	DDX_Control(pDX, IDC_EDIT_POS_X, m_edtPosX);
	DDX_Control(pDX, IDC_COMBO_SELECT_HEAD, m_cmbSelectHead);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS, m_edt2ndThickness);
	DDX_Control(pDX, IDOK, m_btnClose);
	DDX_Control(pDX, IDC_LIST_MESSAGE, m_lboxMsg);
	DDX_Control(pDX, IDC_EDIT_THICKNESS, m_edtThickness);
	DDX_Control(pDX, IDC_BUTTON_MEASURING_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MEASURING_START, m_btnStart);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_BUTTON_POSITION, m_btnPosition);
	DDX_Control(pDX, IDC_BUTTON_ACRYL_FLAT_MEASURING_START, m_btnAcrylFlatStart);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgMeasuringPCBThickness, CDialog)
	//{{AFX_MSG_MAP(CDlgMeasuringPCBThickness)
	ON_BN_CLICKED(IDC_BUTTON_MEASURING_START, OnButtonMeasuringStart)
	ON_BN_CLICKED(IDC_BUTTON_MEASURING_STOP, OnButtonMeasuringStop)
	ON_BN_CLICKED(IDC_BUTTON_POSITION, OnButtonPosition)
	ON_BN_CLICKED(IDC_BUTTON_ACRYL_FLAT_MEASURING_START, OnButtonAcrylFlatMeasuringStart)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgMeasuringPCBThickness message handlers

void CDlgMeasuringPCBThickness::OnCancel() 
{
	CDialog::OnCancel();
}

BOOL CDlgMeasuringPCBThickness::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_nSensorNum = gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum();
	
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitListBoxControl();
	InitComboControl();

	SetupText();

	m_nTimeID	= 0;
	m_nRunCount = -1;
	m_dHeight = 0.0;
	m_dHeight2 = 0.0;

	m_bIsHeight = TRUE;
	AddList(m_strError[m_bIsHeight]);
	if(m_bAutoStart == TRUE)
		OnButtonMeasuringStart();

	if(m_bAcrylFlat == TRUE)
	{
		m_btnStart.EnableWindow( FALSE );
		m_btnClose.EnableWindow( FALSE );
		//m_btnCancel.EnableWindow( FALSE);
	}
	else
	{
		m_btnAcrylFlatStart.EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgMeasuringPCBThickness::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Measuring Start
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Measurement Start") );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.SetBtnCursor(IDC_HAND_1);

	// Measuring Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Measurement Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);
	m_btnStop.EnableWindow( FALSE );

	// Apply
	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("Apply") );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.SetBtnCursor(IDC_HAND_1);

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	// Position
	m_btnPosition.SetFont( &m_fntBtn );
	m_btnPosition.SetFlat( FALSE );
	m_btnPosition.EnableBallonToolTip();
	m_btnPosition.SetToolTipText( _T("Get Position") );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPosition.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_btnStart.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
	}

	// Measuring Start
	m_btnAcrylFlatStart.SetFont( &m_fntBtn );
	m_btnAcrylFlatStart.SetFlat( FALSE );
	m_btnAcrylFlatStart.EnableBallonToolTip();
	m_btnAcrylFlatStart.SetToolTipText( _T("Measurement Acryl Flatness Start") );
	m_btnAcrylFlatStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAcrylFlatStart.SetBtnCursor(IDC_HAND_1);
}

void CDlgMeasuringPCBThickness::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_SELECT_HEAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS)->SetFont( &m_fntStatic );

	if( 0 == m_nSensorNum )
	{
		m_edtThickness.EnableWindow(FALSE);	
		m_edt2ndThickness.EnableWindow(FALSE);
	}
	else if( 1 == m_nSensorNum )
	{
		m_edt2ndThickness.EnableWindow(FALSE);
	}

	GetDlgItem(IDC_STATIC_MEASUREMENT_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );

	if( m_bAutoStart )
	{
		GetDlgItem(IDC_STATIC_MEASUREMENT_POS)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_X)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Y)->EnableWindow(FALSE);
	}
}

void CDlgMeasuringPCBThickness::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(180, "Arial Bold");

	m_edtThickness.SetFont( &m_fntEdit );
	m_edtThickness.SetForeColor( BLACK_COLOR );
	m_edtThickness.SetBackColor( WHITE_COLOR );
	m_edtThickness.SetReceivedFlag( 3 ); // Floating-Point

	CString str;

	str.Format(_T("%.3f"), m_dThickness);
	m_edtThickness.SetWindowText( (LPCTSTR)str );

	m_edt2ndThickness.SetFont( &m_fntEdit );
	m_edt2ndThickness.SetForeColor( BLACK_COLOR );
	m_edt2ndThickness.SetBackColor( WHITE_COLOR );
	m_edt2ndThickness.SetReceivedFlag( 3 ); // Floating-Point

	str.Format(_T("%.3f"), m_d2ndThickness);
	m_edt2ndThickness.SetWindowText( (LPCTSTR)str );

	if( 1 == m_nSensorNum )
		m_edt2ndThickness.EnableWindow(FALSE);

	m_edtPosX.SetFont( &m_fntEdit );
	m_edtPosX.SetReceivedFlag( 3 );
	
	str.Format(_T("%.3f"), m_dMeasurementPos.x);
	m_edtPosX.SetWindowText( (LPCTSTR)str );

	m_edtPosY.SetFont( &m_fntEdit );
	m_edtPosY.SetReceivedFlag( 3 );
	
	str.Format(_T("%.3f"), m_dMeasurementPos.y);
	m_edtPosY.SetWindowText( (LPCTSTR)str );

	if( m_bAutoStart )
	{
		m_edtPosX.EnableWindow(FALSE);
		m_edtPosY.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_edtPosX.EnableWindow(FALSE);
		m_edtPosY.EnableWindow(FALSE);
	}
}

void CDlgMeasuringPCBThickness::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(130, "Arial Bold");

	m_lboxMsg.SetFont( &m_fntListBox );
}

void CDlgMeasuringPCBThickness::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(150, "Arial Bold");

	m_cmbSelectHead.SetFont( &m_fntCombo );

	if( 1 == m_nSensorNum )
	{
		m_cmbSelectHead.ResetContent();
		m_cmbSelectHead.AddString("Master");
		m_cmbSelectHead.SetCurSel( 0 );
	}
	else
	{
		m_cmbSelectHead.SetCurSel( m_nSelectHead );

	}


	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1 || !m_bEnableHeadSelect)
	{
		m_cmbSelectHead.EnableWindow(FALSE);
	}
}

void CDlgMeasuringPCBThickness::OnButtonMeasuringStart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif


	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(m_nTimeID == TIMER_HEIGHT)
		return;

	if( m_bAcrylSuction)
	{
		pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, TRUE);
		pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, TRUE);
	}
	m_btnStart.EnableWindow( FALSE );
	m_btnStop.EnableWindow( TRUE );
	m_btnClose.EnableWindow( FALSE );
	m_btnCancel.EnableWindow( FALSE);

	m_dOldX		= pMotor->GetPosition(AXIS_X);
	m_dOldY		= pMotor->GetPosition(AXIS_Y);
	m_dOldZ		= pMotor->GetPosition(AXIS_Z1);
	m_dOldZ2	= pMotor->GetPosition(AXIS_Z2);

	if( FALSE == m_bAutoStart )
	{
		CString strData;

		m_edtPosX.GetWindowText( strData );
		m_dNewX = atof( (LPSTR)(LPCTSTR)strData );
		m_edtPosY.GetWindowText( strData );
		m_dNewY = atof( (LPSTR)(LPCTSTR)strData );
	}

	if( !pMotor->MoveXY( m_dNewX, m_dNewY ) )
	{
		TRACE("Motor out of position\n");
		OnCheckStop(STDGNALM425);

		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	#ifndef __NO_USE_HEIGHT_SENSOR__
		Sleep(50);
	#endif

	if(!pMotor->InPositionIO(IND_X + IND_Y) )
	{
		OnCheckStop(STDGNALM425);

		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	m_nSelectHead = m_cmbSelectHead.GetCurSel();

	if(m_nSensorNum == 1)
	{
		if( !pMotor->MoveZ(m_dNewZ1, !m_bZCalEnable) )
		{
			TRACE("Motor ouf of position\n");
			OnCheckStop(STDGNALM425);
			
			m_btnStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);
			
			return;
		}
		
		if( !pMotor->InPositionIO(IND_Z1) )
		{
			OnCheckStop(STDGNALM425);
			
			m_btnStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);
			
			return;
		}
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
		Sleep(50);
#endif
	}
	else
	{
		if(m_nSelectHead == 0)
		{
			if( !pMotor->MoveZ(m_dNewZ1, m_dNewZ2, !m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
			
			if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
			{
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
			pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(50);
#endif
		}
		else if(m_nSelectHead == 1)
		{
#ifdef __KUNSAN_1__
			if( !pMotor->MoveZ(m_dNewZ1, m_dNewZ2, !m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
			
			if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
			{
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
	#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
	#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
	#endif
#else

			if( !pMotor->MoveZ(m_dNewZ1, !m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}

			if( !pMotor->InPositionIO(IND_Z1) )
			{
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
	#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
	#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
	#endif
#endif
#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(50);
#endif

		}
		else
		{
#if defined (__KUNSAN_1__) || defined (__PUSAN_LDD__)
		if( !pMotor->MoveZ(m_dNewZ1, m_dNewZ2, !m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
			
			if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
			{
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
	#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
	#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
	#endif
#else
			if( !pMotor->MotorMoveAxis(AXIS_Z2, m_dNewZ2, FALSE, m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}
			
			if( !pMotor->InPositionIO(IND_Z2) )
			{
				OnCheckStop(STDGNALM425);
				
				m_btnStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);
				
				return;
			}

	#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
	#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
	#endif
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(50);
#endif
		}
	}

	m_nRunCount = 0;

	AddList(m_strStatus[m_nRunCount]);

	if(m_bAutoStart && m_nSensorNum == 2)
		m_nSelectHead = m_nSelectHeadAuto;

	if(m_nTimeID == 0 && m_nSensorNum > 0)
		m_nTimeID = SetTimer(TIMER_HEIGHT, HEIGHT_INTERVAL, NULL);
}

void CDlgMeasuringPCBThickness::OnButtonMeasuringStop() 
{
	m_nRunCount = -1;

	if(m_nTimeID)
	{
		KillTimer(m_nTimeID);
		m_nTimeID = 0;
	}

	if(m_bAcrylFlat)
	{
		m_bStop = TRUE;
		return;
	}

#ifndef __NO_USE_HEIGHT_SENSOR__
	// Height Sensor Up
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#endif

	if (!GetHeightSensor(TRUE, FALSE))
	{
		OnCheckStop(STDGNALM424);

		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	if(m_nSensorNum == 2)
	{
#ifdef __MP920_MOTOR__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
		if (!GetHeightSensor(FALSE, FALSE))
		{
			OnCheckStop(STDGNALM424);
			
			m_btnStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);
			
			return;
		}
	}
	
	// Axis X,Y Move
	if( !pMotor->MoveXY(m_dOldX, m_dOldY) )
	{
		TRACE("Motor out of position\n");
		OnCheckStop(STDGNALM424);

		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	Sleep(100);

	if( !pMotor->InPositionIO(IND_X + IND_Y) )
	{
		OnCheckStop(STDGNALM424);

		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	Sleep(100);

	if( !pMotor->MoveZ(m_dOldZ, m_dOldZ2) )
	{
		TRACE("Motor out of position\n");
		OnCheckStop(STDGNALM424);
		
		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);
		
		return;
	}
	
	if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
	{
		OnCheckStop(STDGNALM424);
		
		m_btnStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);
		
		return;
	}
#endif

	AddList(m_strStatus[5]);	// Stop Message

	m_btnStart.EnableWindow( TRUE );
	m_btnStop.EnableWindow( FALSE );
	m_btnClose.EnableWindow( TRUE );
	m_btnCancel.EnableWindow( TRUE);
}

BOOL CDlgMeasuringPCBThickness::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntListBox.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgMeasuringPCBThickness::SetMeasurementPos(DPOINT* pdPos)
{
	memcpy( &m_dMeasurementPos, pdPos, sizeof(m_dMeasurementPos) );
}

void CDlgMeasuringPCBThickness::SetBaseZ(double dBaseZ, double dBaseZ2)
{
	m_dBaseZ = dBaseZ;

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
		m_dBaseZ2 = dBaseZ;
	else
		m_dBaseZ2 = dBaseZ2;
}

void CDlgMeasuringPCBThickness::SetPosition(double dX, double dY, double dZ1, double dZ2)
{
	m_dNewX = dX;
	m_dNewY	= dY;
	m_dNewZ1= dZ1;
	m_dNewZ2= dZ2;

	m_dMeasurementPos.x	= dX;
	m_dMeasurementPos.y	= dY;
}

double CDlgMeasuringPCBThickness::GetHeight(BOOL b1st)
{
#ifdef __TEST__
	return 0.5;
#endif

#ifdef __NO_USE_HEIGHT_SENSOR__
	return 0.3;
#else
	double dValue = 0.0;
	if(b1st)
	{
		if(m_nHeightPos <= 2)
			return -1;

		dValue = ((m_dHeight - m_dMinMaxValue[0] - m_dMinMaxValue[1]) / (m_nHeightPos - 2)) - m_dBaseZ;
		long lValue = static_cast<long>(dValue * 1000.0 + 0.5);

		dValue = static_cast<double>(lValue / 1000.0);
		if(dValue < 0.0)
			return 0.0;
	}
	else
	{
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
		{
			if(m_nHeightPos <= 2)
				return -1;
			
			dValue = ((m_dHeight - m_dMinMaxValue[0] - m_dMinMaxValue[1]) / (m_nHeightPos - 2)) - m_dBaseZ;
			long lValue = static_cast<long>(dValue * 1000.0 + 0.5);
			
			dValue = static_cast<double>(lValue / 1000.0);
			if(dValue < 0.0)
				return 0.0;
		}
		else
		{
			if(m_nHeightPos2 <= 2)
				return -1;
			
			dValue = ((m_dHeight2 - m_dMinMaxValue[2] - m_dMinMaxValue[3]) / (m_nHeightPos2 - 2)) - m_dBaseZ2;
			long lValue = static_cast<long>(dValue * 1000.0 + 0.5);
			
			dValue = static_cast<double>(lValue / 1000.0);
			if(dValue < 0.0)
				return 0.0;
		}
	}

	return dValue;
#endif
}

void CDlgMeasuringPCBThickness::AutoStart()
{
	m_bAutoStart = TRUE;	
	DoModal();

	return;
}

void CDlgMeasuringPCBThickness::AutoSelectHead(int nHead)
{
	m_nSelectHeadAuto = nHead;
}

void CDlgMeasuringPCBThickness::ChangeHeadSelectStatus(BOOL bEnable)
{
	m_bEnableHeadSelect = bEnable;
}

void CDlgMeasuringPCBThickness::SelectHead(int nHead)
{
	m_nSelectHead = nHead;
}

void CDlgMeasuringPCBThickness::SetupText()
{
	m_strStatus[0].LoadString(IDS_TEXT_HEIGHT_STATUS0);
	m_strStatus[1].LoadString(IDS_TEXT_HEIGHT_STATUS1);
	m_strStatus[2].LoadString(IDS_TEXT_HEIGHT_STATUS2);
	m_strStatus[3].LoadString(IDS_TEXT_HEIGHT_STATUS3);
	m_strStatus[4].LoadString(IDS_TEXT_HEIGHT_STATUS4);
	m_strStatus[5].LoadString(IDS_TEXT_HEIGHT_STATUS5);
	m_strError[0].LoadString(IDS_TEXT_HEIGHT_ERROR0);
	m_strError[1].LoadString(IDS_TEXT_HEIGHT_ERROR1);
}

void CDlgMeasuringPCBThickness::DisplayHeight(double dValue, BOOL b1st)
{
	CString strValue;
	strValue.Format(_T("%.3f"), dValue);

	if(b1st)
	{
		m_edtThickness.SetWindowText( (LPCTSTR)strValue );
		if(m_nSensorNum == 1)
			strValue.Format(_T("%.3f"), dValue);
		else
			strValue.Format(_T("%.3f - 1st PNL"), dValue);

	}
	else
	{
		m_edt2ndThickness.SetWindowText( (LPCTSTR)strValue );
		strValue.Format(_T("%.3f - 2nd PNL"), dValue);
	}

	AddList(strValue);
}

void CDlgMeasuringPCBThickness::AddList(CString strList)
{
	if(m_lboxMsg.GetCount() > 100)
		m_lboxMsg.DeleteString(0);

	m_lboxMsg.AddString(strList);
	m_lboxMsg.SetCurSel(m_lboxMsg.GetCount()-1);
}

BOOL CDlgMeasuringPCBThickness::GetHeightSensor(BOOL bFirst, BOOL bDown)
{
	int nCount = 0;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	while(TRUE)
	{
		if( pMotor->GetCurrentHeight(bFirst, bDown))
			return TRUE;

		if(nCount > 50)	// 5 Sec
			return FALSE;

		nCount++;

		#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(100);
		#endif
	}

	return FALSE;
}

void CDlgMeasuringPCBThickness::OnCheckStop(STDGNALM nID)
{
	if (m_nTimeID)
	{
		KillTimer(m_nTimeID);
		m_nTimeID = 0;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if( !pMotor->InPositionIO(IND_X + IND_Y) )
		return;

#ifdef __MP920_MOTOR__
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
	pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	

	if( !pMotor->MoveZ( m_dOldZ, m_dOldZ2 ) )
	{
		TRACE("Motor out of position\n");
		return;
	}

	if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
		return;

	GetDlgItem(IDC_BUTTON_MEASURING_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_MEASURING_STOP)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);

	ErrMsgDlg( nID );
}

void CDlgMeasuringPCBThickness::OnOK() 
{
	if(m_nSensorNum > 0)
	{
#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
#ifdef __MP920_MOTOR__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	
		
		GetHeightSensor(TRUE, FALSE);

		if(m_nSensorNum == 2)
		{
#ifdef __MP920_MOTOR__
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
			pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
			GetHeightSensor(FALSE, FALSE);
		}
	}
	
	CDialog::OnOK();
}

void CDlgMeasuringPCBThickness::OnTimer(UINT nIDEvent) 
{
	CString strFile,strLog, strFile2;
	strFile.Format(_T("HeightMeasureLog"));
	strFile2.Format(_T("HeightMeasureDetailLog"));
	if (m_bOnTimer == TRUE)
	{
		strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
		CDialog::OnTimer(nIDEvent);
		return;
	}

	m_bOnTimer = TRUE;

	int nStatus, nStatus2;
	double dValue, dValue2;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	HHeightSensor*	pHeightSensor = gDeviceFactory.GetHeightSensor();
	//	BOOL bRet;
	BOOL bFirst = FALSE, bSecond = FALSE;
	int nMeasureCnt = 0;
	strLog.Format(_T("m_nRunCount = %d"),m_nRunCount);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
	switch(m_nRunCount)
	{
		case 0 :
			m_nHeightPos = 0;
			m_nHeightPos2 = 0;
			m_dHeight = 0.0;
			m_dHeight2 = 0.0;
			//m_nSleepCount = 0;

			for(int i = 0; i < 4; i++)
				m_dMinMaxValue[i] = 0;

			#ifndef __NO_USE_HEIGHT_SENSOR__
				Sleep(100);
			#endif

			if(m_nSensorNum == 1)
				bFirst = TRUE;
			else
			{
				if(m_nSelectHead == 0)
					bFirst = bSecond = TRUE;
				else if(m_nSelectHead == 1)
					bFirst = TRUE;
				else
					bSecond = TRUE;
			}


			if(bFirst)
			{
				if (!GetHeightSensor(TRUE, TRUE))	// Down Error
				{
					OnCheckStop(STDGNALM425);
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}
			}
			if(bSecond)
			{
#ifdef __KUNSAN_1__
				if (!GetHeightSensor(TRUE, TRUE))	// Down Error
				{
					OnCheckStop(STDGNALM425);
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);
						
					return;
				}
#else
				if (!GetHeightSensor(FALSE, TRUE))	// Down Error
				{
					OnCheckStop(STDGNALM425);
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);
						
					return;
				}
#endif
			}
			AddList(m_strStatus[++m_nRunCount]);
#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(500);
#endif
			strLog.Format(_T("m_nRunCount = %d"),m_nRunCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
			break;
		case 1 :
			if(m_nTimeID == 0)
			{
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);

				return;
			}
			//m_nSleepCount++;

			for(nMeasureCnt = 0; nMeasureCnt < 10; nMeasureCnt++)
			{
				::Sleep(60);
				if(m_nSensorNum == 1)
				{
					nStatus = pHeightSensor->Reading(dValue, 0);
					if(nStatus == 0)
					{
						if(m_nHeightPos == 0)
						{
							m_dMinMaxValue[0] = dValue;
							m_dMinMaxValue[1] = dValue;
						}
						else
						{
							if(m_dMinMaxValue[0] >= dValue)
								m_dMinMaxValue[0] = dValue;
							if(m_dMinMaxValue[1] <= dValue)
								m_dMinMaxValue[1] = dValue;
						}

						m_nHeightPos++;
						m_dHeight = m_dHeight + dValue;
						DisplayHeight(dValue - m_dBaseZ);
						strLog.Format(_T("%.3f"),dValue);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					}
					else if(nStatus == PROBE_UNDER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too low."));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else if(nStatus == PROBE_OVER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too high."));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else
					{
						CString strVal;
						strVal.Format(_T("There is an error."));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
				}
				else
				{
					if(m_nSelectHead == 0 || m_nSelectHead == 1)
					{
						nStatus = pHeightSensor->Reading(dValue, 0);

						if(nStatus == 0)
						{
							if(m_nHeightPos == 0)
							{
								m_dMinMaxValue[0] = dValue;
								m_dMinMaxValue[1] = dValue;
							}
							else
							{
								if(m_dMinMaxValue[0] >= dValue)
									m_dMinMaxValue[0] = dValue;
								if(m_dMinMaxValue[1] <= dValue)
									m_dMinMaxValue[1] = dValue;
							}

							m_nHeightPos++;
							m_dHeight = m_dHeight + dValue;
							DisplayHeight(dValue - m_dBaseZ);
							strLog.Format(_T("%.3f"),dValue);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
						}
						else if(nStatus == PROBE_UNDER_RANGE)
						{
							CString strVal;
							strVal.Format(_T("Height is too low. - 1st"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
						else if(nStatus == PROBE_OVER_RANGE)
						{
							CString strVal;
							strVal.Format(_T("Height is too high. - 1st"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
						else
						{
							CString strVal;
							strVal.Format(_T("There is an error. - 1st"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
					}
					if(m_nSelectHead == 0 || m_nSelectHead == 2)
					{
						nStatus2 = pHeightSensor->Reading(dValue2, 1);

						if(nStatus2 == 0)
						{
							if(m_nHeightPos2 == 0)
							{
								m_dMinMaxValue[2] = dValue2;
								m_dMinMaxValue[3] = dValue2;
							}
							else
							{
								if(m_dMinMaxValue[2] >= dValue2)
									m_dMinMaxValue[2] = dValue2;
								if(m_dMinMaxValue[3] <= dValue2)
									m_dMinMaxValue[3] = dValue2;
							}

							m_nHeightPos2++;
							m_dHeight2 = m_dHeight2 + dValue2;
							DisplayHeight(dValue2 - m_dBaseZ2, FALSE);
							strLog.Format(_T("%.3f"),dValue2);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
						}
						else if(nStatus2 == PROBE_UNDER_RANGE)
						{
							CString strVal;
							strVal.Format(_T("Height is too low. - 2nd"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
						else if(nStatus2 == PROBE_OVER_RANGE)
						{
							CString strVal;
							strVal.Format(_T("Height is too high. - 2nd"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
						else
						{
							CString strVal;
							strVal.Format(_T("There is an error. - 2nd"));
							AddList(strVal);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
						}
					}
				}	
			}

//			if(m_nSleepCount >= 5)	// 0.5 sec
			{
				if(m_nTimeID == 0)
				{
					strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
				if(m_nSensorNum == 2)
						pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
				if(m_nSensorNum == 2)
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#endif
				AddList(m_strStatus[++m_nRunCount]);
			}	
			strLog.Format(_T("m_nRunCount = %d"),m_nRunCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
			break;
		case 2 :
			if(m_nTimeID == 0)
			{
				strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);

				return;
			}
			if(!GetHeightSensor(TRUE, FALSE))	// Up Error
			{
				OnCheckStop(STDGNALM424);
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);

				return;
			}

			if(m_nSensorNum == 2)
			{
				if(!GetHeightSensor(FALSE, FALSE))	// Up Error
				{
					OnCheckStop(STDGNALM424);
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);
						
					return;
				}
			}
			AddList(m_strStatus[++m_nRunCount]);
			strLog.Format(_T("m_nRunCount = %d"),m_nRunCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
			break;
		case 3 :
			if(m_nTimeID == 0)
			{
				strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);
				return;
			}
			if(!GetHeightSensor(TRUE, FALSE))	// Up Error
			{
				OnCheckStop(STDGNALM424);
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);

				return;
			}

			if(m_nSensorNum == 2)
			{
				if(!GetHeightSensor(FALSE, FALSE))	// Up Error
				{
					OnCheckStop(STDGNALM424);
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);
						
					return;
				}
			}
			if(m_bAutoStart == FALSE)
			{
				AddList(m_strStatus[++m_nRunCount]);
				if( !pMotor->MotorMoveXYZ( m_dOldX, m_dOldY, m_dOldZ, m_dOldZ2, TRUE ) )
				{
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}

				#ifndef __NO_USE_HEIGHT_SENSOR__
					Sleep(100);
				#endif
			}
			else
			{
				if (m_nTimeID == 0)
				{
					strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}

				AddList(m_strStatus[++m_nRunCount]);

/*				if( TRUE != pMotor->InPositionIO(IND_X + IND_Y) )
				{
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}
*/
				if(!pMotor->MoveZ(m_dOldZ, m_dOldZ2) )
				{
					strLog.Format(_T("m_bOntimer = %d, MoveZ Error"),m_bOnTimer);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					m_bOnTimer = FALSE;
					CDialog::OnTimer(nIDEvent);

					return;
				}

				#ifndef __NO_USE_HEIGHT_SENSOR__
					Sleep(10);
				#endif
			}
			strLog.Format(_T("m_nRunCount = %d"),m_nRunCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
			break;
		case 4 :
			if(m_nTimeID == 0)
			{
				strLog.Format(_T("m_bOntimer = %d"),m_bOnTimer);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				m_bOnTimer = FALSE;
				CDialog::OnTimer(nIDEvent);

				return;
			}

			if( TRUE == pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2) )
			{
				AddList(_T(""));

				if(m_nTimeID)
				{
					KillTimer(m_nTimeID);
					m_nTimeID = 0;
				}

				m_btnStart.EnableWindow(TRUE);
				m_btnStop.EnableWindow(FALSE);
				m_btnClose.EnableWindow(TRUE);
				m_btnCancel.EnableWindow( TRUE);

				CString strVal, strVal2;
				strVal.LoadString(IDS_TEXT_HEIGHT_APPLY_VAL);

			
	
	


				if(m_nSensorNum == 1)
				{
					strVal2.Format(_T("Master %s : %.3f"), strVal, GetHeight());
					AddList(strVal2);
					DisplayHeight(GetHeight());
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
				}
				else
				{
					if(m_nSelectHead == 0 || m_nSelectHead == 1)
					{
						strVal2.Format(_T("1st PNL %s : %.3f"), strVal, GetHeight());
						AddList(strVal2);
						DisplayHeight(GetHeight());
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
					}
					if(m_nSelectHead == 0 || m_nSelectHead == 2)
					{
						strVal2.Format(_T("2nd PNL %s : %.3f"), strVal, GetHeight(FALSE));
						AddList(strVal2);
						DisplayHeight(GetHeight(FALSE), FALSE);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
					}
				}
#ifndef __NO_USE_HEIGHT_SENSOR__
				Sleep(100);
#endif
				if(m_bAutoStart == TRUE)
					SendMessage(WM_CLOSE);
			}
			break;
	}

	m_bOnTimer = FALSE;
	
	CDialog::OnTimer(nIDEvent);
}

void CDlgMeasuringPCBThickness::OnClose() 
{
	if(m_nTimeID)
	{
		KillTimer(m_nTimeID);
		m_nTimeID = 0;
	}
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
#ifdef __MP920_MOTOR__
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
	pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	
	
	GetHeightSensor(TRUE, FALSE);

	if(m_nSensorNum == 2)
	{
#ifdef __MP920_MOTOR__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
		GetHeightSensor(FALSE, FALSE);
	}
	
	CDialog::OnClose();
}
void CDlgMeasuringPCBThickness::OnButtonPosition()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	int nSel = m_cmbSelectHead.GetCurSel();
	double dPosX, dPosY;
	if(nSel == USE_DUAL || nSel == USE_1ST)
	{
		pMotor->GetPosition(AXIS_X, dPosX, TRUE);
		pMotor->GetPosition(AXIS_Y, dPosY, TRUE);
	}
	else if(nSel == USE_2ND)
	{
		pMotor->GetPosition(AXIS_X, dPosX, FALSE);
		pMotor->GetPosition(AXIS_Y, dPosY, FALSE);
	}
	CString str;
	str.Format(_T("%.3f"), dPosX);
	m_edtPosX.SetWindowText(str);

	str.Format(_T("%.3f"), dPosY);
	m_edtPosY.SetWindowText(str);

}

void CDlgMeasuringPCBThickness::SetAcrylSuction(BOOL bAcrylSuction)
{
	m_bAcrylSuction = bAcrylSuction;
}


void CDlgMeasuringPCBThickness::OnButtonAcrylFlatMeasuringStart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	m_bStop = FALSE;
	m_bAcrylFlat = TRUE;

	CString strFile,strLog, strFile2;
	CString strVal, strVal2;
	strFile.Format(_T("AcrylFlatMeasureLog"));
	strFile2.Format(_T("AcrylFlatMeasureDetailLog"));

	int nStatus, nStatus2;
	double dValue, dValue2;

	double dSumThick1, dSumThick2;
	dSumThick1 = dSumThick2 = 0.0;
	double dAvrThick1, dAvrThick2;

	HHeightSensor*	pHeightSensor = gDeviceFactory.GetHeightSensor();

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(m_nTimeID == TIMER_HEIGHT)
		return;

	if( m_bAcrylSuction)
	{
		pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, TRUE);
		pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, TRUE);
	}
	m_btnAcrylFlatStart.EnableWindow( FALSE );
	m_btnStop.EnableWindow( TRUE );
	m_btnClose.EnableWindow( FALSE );
	m_btnCancel.EnableWindow( FALSE);

	m_dOldX		= pMotor->GetPosition(AXIS_X);
	m_dOldY		= pMotor->GetPosition(AXIS_Y);
	m_dOldZ		= pMotor->GetPosition(AXIS_Z1);
	m_dOldZ2	= pMotor->GetPosition(AXIS_Z2);

	//3x3 ����A�Ϣ��� 9����AI���� ��I���� A��A��
	for(int i = 0; i < 9; i++)
	{
		if( !pMotor->MoveXY( gProcessINI.m_sProcessOption.dAcrylFlatPosX[i], gProcessINI.m_sProcessOption.dAcrylFlatPosY[i] ) )
		{
			TRACE("Motor out of position\n");
			OnCheckStop(STDGNALM425);

			m_btnAcrylFlatStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			//m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);

			return;
		}

#ifndef __NO_USE_HEIGHT_SENSOR__
		Sleep(50);
#endif

		if(!pMotor->InPositionIO(IND_X + IND_Y) )
		{
			OnCheckStop(STDGNALM425);

			m_btnAcrylFlatStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			//m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);

			return;
		}

		MessageLoop();
		if(m_bStop)
		{
			ErrMessage(_T("You clicked the stop button."));
			StopProcess();
			return;		
		}

		m_nSelectHead = m_cmbSelectHead.GetCurSel();

		if(m_nSensorNum == 1)
		{
			if( !pMotor->MoveZ(m_dNewZ1, !m_bZCalEnable) )
			{
				TRACE("Motor ouf of position\n");
				OnCheckStop(STDGNALM425);

				m_btnAcrylFlatStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				//m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);

				return;
			}

			if( !pMotor->InPositionIO(IND_Z1) )
			{
				OnCheckStop(STDGNALM425);

				m_btnAcrylFlatStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				//m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);

				return;
			}
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
			Sleep(50);
#endif
		}
		else
		{
			if(m_nSelectHead == 0)
			{
				if( !pMotor->MoveZ(m_dNewZ1, m_dNewZ2, !m_bZCalEnable) )
				{
					TRACE("Motor ouf of position\n");
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}

				if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
				{
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
				Sleep(50);
#endif
			}
			else if(m_nSelectHead == 1)
			{
				if( !pMotor->MoveZ(m_dNewZ1, !m_bZCalEnable) )
				{
					TRACE("Motor ouf of position\n");
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}

				if( !pMotor->InPositionIO(IND_Z1) )
				{
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
				Sleep(50);
#endif
			}
			else
			{
				if( !pMotor->MotorMoveAxis(AXIS_Z2, m_dNewZ2, FALSE, m_bZCalEnable) )
				{
					TRACE("Motor ouf of position\n");
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}

				if( !pMotor->InPositionIO(IND_Z2) )
				{
					OnCheckStop(STDGNALM425);

					m_btnAcrylFlatStart.EnableWindow( TRUE );
					m_btnStop.EnableWindow( FALSE );
					//m_btnClose.EnableWindow( TRUE );
					m_btnCancel.EnableWindow( TRUE);

					return;
				}

#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#endif

#ifndef __NO_USE_HEIGHT_SENSOR__
				Sleep(50);
#endif
			}
		}

		MessageLoop();
		if(m_bStop)
		{
			ErrMessage(_T("You clicked the stop button."));
			StopProcess();
			return;		
		}

		// A��A�� ��I����
		m_nHeightPos = 0;
		m_nHeightPos2 = 0;
		m_dHeight = 0.0;
		m_dHeight2 = 0.0;
		for(int j = 0; j < 4; j++)
			m_dMinMaxValue[j] = 0;

		BOOL bFirst = FALSE, bSecond = FALSE;
		int nMeasureCnt = 0;

		if(m_nSensorNum == 1)
			bFirst = TRUE;
		else
		{
			if(m_nSelectHead == 0)
				bFirst = bSecond = TRUE;
			else if(m_nSelectHead == 1)
				bFirst = TRUE;
			else
				bSecond = TRUE;
		}

		if(bFirst)
		{
			if (!GetHeightSensor(TRUE, TRUE))	// Down Error
			{
				OnCheckStop(STDGNALM425);
				m_btnAcrylFlatStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				//m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);

				return;
			}
		}
		if(bSecond)
		{
			if (!GetHeightSensor(FALSE, TRUE))	// Down Error
			{
				OnCheckStop(STDGNALM425);
				m_btnAcrylFlatStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				//m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);

				return;
			}
		}

#ifndef __NO_USE_HEIGHT_SENSOR__
#ifndef __TEST__	
		MessageLoopWait(500);
		//::Sleep(1000);
#endif		
#endif

		for(nMeasureCnt = 0; nMeasureCnt < 10; nMeasureCnt++)
		{
			::Sleep(60);
			if(m_nSensorNum == 1)
			{
				nStatus = pHeightSensor->Reading(dValue, 0);
				if(nStatus == 0)
				{
					if(m_nHeightPos == 0)
					{
						m_dMinMaxValue[0] = dValue;
						m_dMinMaxValue[1] = dValue;
					}
					else
					{
						if(m_dMinMaxValue[0] >= dValue)
							m_dMinMaxValue[0] = dValue;
						if(m_dMinMaxValue[1] <= dValue)
							m_dMinMaxValue[1] = dValue;
					}

					m_nHeightPos++;
					m_dHeight = m_dHeight + dValue;
					DisplayHeight(dValue - m_dBaseZ);
					strLog.Format(_T("%.3f"),dValue);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				}
				else if(nStatus == PROBE_UNDER_RANGE)
				{
					CString strVal;
					strVal.Format(_T("Height is too low."));
					AddList(strVal);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
				}
				else if(nStatus == PROBE_OVER_RANGE)
				{
					CString strVal;
					strVal.Format(_T("Height is too high."));
					AddList(strVal);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
				}
				else
				{
					CString strVal;
					strVal.Format(_T("There is an error."));
					AddList(strVal);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
				}
			}
			else
			{
				if(m_nSelectHead == 0 || m_nSelectHead == 1)
				{
					nStatus = pHeightSensor->Reading(dValue, 0);

					if(nStatus == 0)
					{
						if(m_nHeightPos == 0)
						{
							m_dMinMaxValue[0] = dValue;
							m_dMinMaxValue[1] = dValue;
						}
						else
						{
							if(m_dMinMaxValue[0] >= dValue)
								m_dMinMaxValue[0] = dValue;
							if(m_dMinMaxValue[1] <= dValue)
								m_dMinMaxValue[1] = dValue;
						}

						m_nHeightPos++;
						m_dHeight = m_dHeight + dValue;
						DisplayHeight(dValue - m_dBaseZ);
						strLog.Format(_T("%.3f"),dValue);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					}
					else if(nStatus == PROBE_UNDER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too low. - 1st"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else if(nStatus == PROBE_OVER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too high. - 1st"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else
					{
						CString strVal;
						strVal.Format(_T("There is an error. - 1st"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
				}
				if(m_nSelectHead == 0 || m_nSelectHead == 2)
				{
					nStatus2 = pHeightSensor->Reading(dValue2, 1);

					if(nStatus2 == 0)
					{
						if(m_nHeightPos2 == 0)
						{
							m_dMinMaxValue[2] = dValue2;
							m_dMinMaxValue[3] = dValue2;
						}
						else
						{
							if(m_dMinMaxValue[2] >= dValue2)
								m_dMinMaxValue[2] = dValue2;
							if(m_dMinMaxValue[3] <= dValue2)
								m_dMinMaxValue[3] = dValue2;
						}

						m_nHeightPos2++;
						m_dHeight2 = m_dHeight2 + dValue2;
						DisplayHeight(dValue2 - m_dBaseZ2, FALSE);
						strLog.Format(_T("%.3f"),dValue2);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
					}
					else if(nStatus2 == PROBE_UNDER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too low. - 2nd"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else if(nStatus2 == PROBE_OVER_RANGE)
					{
						CString strVal;
						strVal.Format(_T("Height is too high. - 2nd"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
					else
					{
						CString strVal;
						strVal.Format(_T("There is an error. - 2nd"));
						AddList(strVal);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strVal));
					}
				}
			}
		} //1Point 10���� A��A�� Loop

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
		if(m_nSensorNum == 2)
			pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
		if(m_nSensorNum == 2)
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#endif

		MessageLoop();
		if(m_bStop)
		{
			ErrMessage(_T("You clicked the stop button."));
			StopProcess();
			return;		
		}

		if(!GetHeightSensor(TRUE, FALSE))	// Up Error
		{
			OnCheckStop(STDGNALM424);
			m_btnAcrylFlatStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			//m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);

			return;
		}

		if(m_nSensorNum == 2)
		{
			if(!GetHeightSensor(FALSE, FALSE))	// Up Error
			{
				OnCheckStop(STDGNALM424);
				m_btnAcrylFlatStart.EnableWindow( TRUE );
				m_btnStop.EnableWindow( FALSE );
				//m_btnClose.EnableWindow( TRUE );
				m_btnCancel.EnableWindow( TRUE);

				return;
			}
		}
		double dMin, dMax, dTol;
		CString strErr;
		dMin = gProcessINI.m_sProcessOption.dAcrylFlatRef * (100 - gProcessINI.m_sProcessOption.dAcrylFlatTol) / 100;
		dMax = gProcessINI.m_sProcessOption.dAcrylFlatRef * (100 + gProcessINI.m_sProcessOption.dAcrylFlatTol) / 100;
		
		if(m_nSensorNum == 1)
		{
			strVal2.Format(_T("Point %d, Master : %.3f"),i+1 , GetHeight());
			AddList(strVal2);

			if(GetHeight() > dMax || GetHeight() < dMin)
			{
				strErr.Format(_T("Acryl Thickness Over Tolerance. Thick : %.3f, Ref : %.3f, Tol : %.3f"),GetHeight(),gProcessINI.m_sProcessOption.dAcrylFlatRef, gProcessINI.m_sProcessOption.dAcrylFlatTol);
				ErrMessage(strErr);
				StopProcess();
				return;
			}

			dSumThick1 += GetHeight();
			//DisplayHeight(GetHeight());
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
		}
		else
		{
			if(m_nSelectHead == 0 || m_nSelectHead == 1)
			{
				strVal2.Format(_T("Point %d, 1st Acryl : %.3f"), i+1, GetHeight());
				AddList(strVal2);
				if(GetHeight() > dMax || GetHeight() < dMin)
				{
					strErr.Format(_T("1st Acryl Thickness Over Tolerance. Thick : %.3f, Ref : %.3f, Tol : %.3f"),GetHeight(),gProcessINI.m_sProcessOption.dAcrylFlatRef, gProcessINI.m_sProcessOption.dAcrylFlatTol);
					ErrMessage(strErr);
					StopProcess();
					return;
				}
				dSumThick1 += GetHeight();
				//DisplayHeight(GetHeight());
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
			}
			if(m_nSelectHead == 0 || m_nSelectHead == 2)
			{
				strVal2.Format(_T("Point %d, 2nd Acryl : %.3f"), i+1, GetHeight(FALSE));
				AddList(strVal2);

				if(GetHeight(FALSE) > dMax || GetHeight(FALSE) < dMin)
				{
					strErr.Format(_T("2nd Acryl Thickness Over Tolerance. Thick : %.3f, Ref : %.3f, Tol : %.3f"),GetHeight(FALSE),gProcessINI.m_sProcessOption.dAcrylFlatRef, gProcessINI.m_sProcessOption.dAcrylFlatTol);
					ErrMessage(strErr);
					StopProcess();
					return;
				}
				dSumThick2 += GetHeight(FALSE);
				//DisplayHeight(GetHeight(FALSE), FALSE);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
			}
		}
#ifndef __NO_USE_HEIGHT_SENSOR__
#ifndef __TEST__	
		MessageLoopWait(100);
#endif		
#endif

	} //(3x3) 9 Point A��A�� Loop

	//9Point A��A�� �ƨ� ��o��O ����CI��a
	if(m_nSensorNum == 1)
	{
		dAvrThick1 = dSumThick1 / 9;
		DisplayHeight(dAvrThick1);
	}
	else
	{
		if(m_nSelectHead == 0 || m_nSelectHead == 1)
		{
			dAvrThick1 = dSumThick1 / 9;
			DisplayHeight(dAvrThick1);
		}
		if(m_nSelectHead == 0 || m_nSelectHead == 2)
		{
			dAvrThick2 = dSumThick2 / 9;
			DisplayHeight(dAvrThick2);
		}
	}

	if( !pMotor->MotorMoveXYZ( m_dOldX, m_dOldY, m_dOldZ, m_dOldZ2, TRUE ) )
	{
		ErrMsgDlg(STDGNALM438);
		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	if( FALSE == pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2) )
	{
		ErrMsgDlg(STDGNALM438);
	}

	m_btnAcrylFlatStart.EnableWindow( TRUE );
	m_btnStop.EnableWindow( FALSE );
	m_btnClose.EnableWindow( TRUE );
	m_btnCancel.EnableWindow( TRUE);
#ifndef __NO_USE_HEIGHT_SENSOR__
#ifndef __TEST__	
	MessageLoopWait(100);
#endif		
#endif

}

void CDlgMeasuringPCBThickness::SetAcrylFlat(BOOL bSet)
{
	m_bAcrylFlat = bSet;
}

void CDlgMeasuringPCBThickness::MessageLoop()
{
	MSG msg;

	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CDlgMeasuringPCBThickness::StopProcess()
{
	m_bAcrylFlat = FALSE;
#ifndef __NO_USE_HEIGHT_SENSOR__
	// Height Sensor Up
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#endif

	if (!GetHeightSensor(TRUE, FALSE))
	{
		OnCheckStop(STDGNALM424);

		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		//m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	if(m_nSensorNum == 2)
	{
#ifdef __MP920_MOTOR__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
		pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
		if (!GetHeightSensor(FALSE, FALSE))
		{
			OnCheckStop(STDGNALM424);

			m_btnAcrylFlatStart.EnableWindow( TRUE );
			m_btnStop.EnableWindow( FALSE );
			//m_btnClose.EnableWindow( TRUE );
			m_btnCancel.EnableWindow( TRUE);

			return;
		}
	}

	// Axis X,Y Move
	if( !pMotor->MoveXY(m_dOldX, m_dOldY) )
	{
		TRACE("Motor out of position\n");
		OnCheckStop(STDGNALM424);

		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		//m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	Sleep(100);

	if( !pMotor->InPositionIO(IND_X + IND_Y) )
	{
		OnCheckStop(STDGNALM424);

		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		//m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	Sleep(100);

	if( !pMotor->MoveZ(m_dOldZ, m_dOldZ2) )
	{
		TRACE("Motor out of position\n");
		OnCheckStop(STDGNALM424);

		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		//m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}

	if( !pMotor->InPositionIO(IND_Z1 + IND_Z2) )
	{
		OnCheckStop(STDGNALM424);

		m_btnAcrylFlatStart.EnableWindow( TRUE );
		m_btnStop.EnableWindow( FALSE );
		//m_btnClose.EnableWindow( TRUE );
		m_btnCancel.EnableWindow( TRUE);

		return;
	}
#endif

	m_btnAcrylFlatStart.EnableWindow( TRUE );
	m_btnStop.EnableWindow( FALSE );
	//m_btnClose.EnableWindow( TRUE );
	m_btnCancel.EnableWindow( TRUE);
}
