// Interpolation.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include "Interpolation.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dsystemini.h"
#include "..\resource.h"
#include "ScannerBiCubic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Interpolation

Interpolation::Interpolation()
{
	m_nMatrixSize = 9;
}

Interpolation::~Interpolation()
{
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(Interpolation, CObject)
	//{{AFX_MSG_MAP(Interpolation)
	ON_COMMAND(ID_CALIBRATION, OnCalibration)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// Interpolation member functions

void Interpolation::Calibration()
{

	// change to LSB....
	CString strTemp;
	double dScanPitchX, dScanPitchY;
	dScanPitchX = gSystemINI.m_sSystemDevice.dOriginFieldSize.x;
	dScanPitchY = gSystemINI.m_sSystemDevice.dOriginFieldSize.x;

	for(int i = 0;i<m_nMatrixSize;i++)
	{
		for(int j=0;j<m_nMatrixSize;j++)
		{
			if(gSystemINI.m_sHardWare.nEocardType == ETS5_TYPE)
			{
				OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[j][i].PosX;
				OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[j][i].PosY;
				OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[j][i].PosX;
				OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[j][i].PosY;
			}
			else
			{
				if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[j][m_nMatrixSize- i -1].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[j][m_nMatrixSize- i -1].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[j][m_nMatrixSize- i -1].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[j][m_nMatrixSize- i -1].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[j][i].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[j][i].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[j][i].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[j][i].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[m_nMatrixSize- j -1][m_nMatrixSize- i -1].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[m_nMatrixSize- j -1][m_nMatrixSize- i -1].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[m_nMatrixSize- j -1][m_nMatrixSize- i -1].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[m_nMatrixSize- j -1][m_nMatrixSize- i- 1].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[m_nMatrixSize- j -1][i].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[m_nMatrixSize- j -1][i].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[m_nMatrixSize- j -1][i].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[m_nMatrixSize- j -1][i].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[m_nMatrixSize- i -1][j].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[m_nMatrixSize- i -1][j].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[m_nMatrixSize- i -1][j].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[m_nMatrixSize- i -1][j].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[i][j].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[i][j].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[i][j].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[i][j].PosY;
				}
				else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[m_nMatrixSize- i -1][m_nMatrixSize- j -1].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[m_nMatrixSize- i -1][m_nMatrixSize- j -1].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[m_nMatrixSize- i -1][m_nMatrixSize- j -1].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[m_nMatrixSize- i -1][m_nMatrixSize- j -1].PosY;
				}
				else 
				{
					OffsetPointLSB[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint[i][m_nMatrixSize- j -1].PosX;
					OffsetPointLSB[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint[i][m_nMatrixSize- j -1].PosY;
					OffsetPointLSB2[i][j].PosX=((double)MAXLSB/dScanPitchX)*OffsetPoint2[i][m_nMatrixSize- j -1].PosX;
					OffsetPointLSB2[i][j].PosY=((double)MAXLSB/dScanPitchY)*OffsetPoint2[i][m_nMatrixSize- j -1].PosY;
				}
			}
		}
	}

	double dMatrixStep;

	//////////////////////////////////////////	
	//modify calibration file.
	int lx, ly, hx, hy;
	double ax, ay, bx, by;
	double dTemp;

	//if matrix size smaller than 65...
	if(	m_nMatrixSize>1 && m_nMatrixSize<=MAX_CAL_X)
	{
		dMatrixStep=64/(m_nMatrixSize-1);	//calculate step.

		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				int modx = i%(int)dMatrixStep;
				int mody = j%(int)dMatrixStep;

				if( modx == 0 )
					lx = hx = (int)(i/dMatrixStep);
				else
				 {
					lx = (int)(i/dMatrixStep);
					hx = lx + 1;
				 }
				if( mody == 0 )
					ly = hy = (int)(j/dMatrixStep);
				else
				 {
					ly = (int)(j/dMatrixStep);
					hy = ly + 1;
				 }

				ax = OffsetPointLSB[lx][ly].PosX + ( (OffsetPointLSB[lx][hy].PosX - OffsetPointLSB[lx][ly].PosX)*mody/dMatrixStep);
				bx = OffsetPointLSB[hx][ly].PosX + ( (OffsetPointLSB[hx][hy].PosX - OffsetPointLSB[hx][ly].PosX)*mody/dMatrixStep);
				ay = OffsetPointLSB[lx][ly].PosY + ( (OffsetPointLSB[hx][ly].PosY - OffsetPointLSB[lx][ly].PosY)*modx/dMatrixStep);
				by = OffsetPointLSB[lx][hy].PosY + ( (OffsetPointLSB[hx][hy].PosY - OffsetPointLSB[lx][hy].PosY)*modx/dMatrixStep);

				// x = dX, y = dY
				if(gSystemINI.m_sHardWare.nEocardType == ETS5_TYPE)
				{
					dTemp = CalibrationFile[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
					CalibrationFile[i][j].PosX = dTemp;
					dTemp = CalibrationFile[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
					CalibrationFile[i][j].PosY = dTemp;
				}
				else
				{
					if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
					{
						dTemp = CalibrationFile[i][j].PosX + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
						dTemp = CalibrationFile[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
					{
						dTemp = CalibrationFile[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
						dTemp = CalibrationFile[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
					{
						dTemp = CalibrationFile[i][j].PosX + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
						dTemp = CalibrationFile[i][j].PosY + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
					{
						dTemp = CalibrationFile[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
						dTemp = CalibrationFile[i][j].PosY + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
					{
						dTemp = CalibrationFile[i][j].PosX - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
						dTemp = CalibrationFile[i][j].PosY + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
					{
						dTemp = CalibrationFile[i][j].PosX + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
						dTemp = CalibrationFile[i][j].PosY + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
					{
						dTemp = CalibrationFile[i][j].PosX - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
						dTemp = CalibrationFile[i][j].PosY - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
					}
					else 
					{
						dTemp = CalibrationFile[i][j].PosX + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile[i][j].PosY = dTemp;
						dTemp = CalibrationFile[i][j].PosY - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile[i][j].PosX = dTemp;
					}
				}

				ax = OffsetPointLSB2[lx][ly].PosX + ( (OffsetPointLSB2[lx][hy].PosX - OffsetPointLSB2[lx][ly].PosX)*mody/dMatrixStep);
				bx = OffsetPointLSB2[hx][ly].PosX + ( (OffsetPointLSB2[hx][hy].PosX - OffsetPointLSB2[hx][ly].PosX)*mody/dMatrixStep);
				ay = OffsetPointLSB2[lx][ly].PosY + ( (OffsetPointLSB2[hx][ly].PosY - OffsetPointLSB2[lx][ly].PosY)*modx/dMatrixStep);
				by = OffsetPointLSB2[lx][hy].PosY + ( (OffsetPointLSB2[hx][hy].PosY - OffsetPointLSB2[lx][hy].PosY)*modx/dMatrixStep);
				
				if(gSystemINI.m_sHardWare.nEocardType == ETS5_TYPE)
				{
					dTemp = CalibrationFile2[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
					CalibrationFile2[i][j].PosX = dTemp;
					dTemp = CalibrationFile2[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
					CalibrationFile2[i][j].PosY = dTemp;
				}
				else
				{
					if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
					{
						dTemp = CalibrationFile2[i][j].PosX + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
						dTemp = CalibrationFile2[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
					{
						dTemp = CalibrationFile2[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
						dTemp = CalibrationFile2[i][j].PosY - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
					{
						dTemp = CalibrationFile2[i][j].PosX + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
						dTemp = CalibrationFile2[i][j].PosY + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
					{
						dTemp = CalibrationFile2[i][j].PosX - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
						dTemp = CalibrationFile2[i][j].PosY + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
					{
						dTemp = CalibrationFile2[i][j].PosX - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
						dTemp = CalibrationFile2[i][j].PosY + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
					{
						dTemp = CalibrationFile2[i][j].PosX + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
						dTemp = CalibrationFile2[i][j].PosY + (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
					}
					else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
					{
						dTemp = CalibrationFile2[i][j].PosX - (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
						dTemp = CalibrationFile2[i][j].PosY - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
					}
					else 
					{
						dTemp = CalibrationFile2[i][j].PosX + (ay + (by - ay)*mody/dMatrixStep);
						CalibrationFile2[i][j].PosY = dTemp;
						dTemp = CalibrationFile2[i][j].PosY - (ax + (bx - ax)*modx/dMatrixStep);
						CalibrationFile2[i][j].PosX = dTemp;
					}
				}
			}
		}
	}

	//-------temp interpolation
	//if matrix size smaller than 65...
	if(m_nMatrixSize == 33)
	{
		dMatrixStep=64/(m_nMatrixSize-1);	//calculate step.

		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				int modx = i%(int)dMatrixStep;
				int mody = j%(int)dMatrixStep;

				if(modx == 0 && mody == 0)
					continue;

				if( modx == 0 )
					lx = hx = i;
				else
				{
					lx = i - 1;
					hx = i + 1;
				}
				if( mody == 0 )
					ly = hy = j;
				else
				{
					ly = j - 1;
					hy = j + 1;
				}

				ax = (CalibrationFile[lx][ly].PosX * modx + CalibrationFile[hx][ly].PosX * (dMatrixStep - modx))/dMatrixStep;
				bx = (CalibrationFile[lx][hy].PosX * modx + CalibrationFile[hx][hy].PosX * (dMatrixStep - modx))/dMatrixStep;
				CalibrationFile[i][j].PosX = (ax * mody + bx * (dMatrixStep - mody))/dMatrixStep;
				
				ay = (CalibrationFile[lx][ly].PosY * modx + CalibrationFile[hx][ly].PosY * (dMatrixStep - modx))/dMatrixStep;
				by = (CalibrationFile[lx][hy].PosY * modx + CalibrationFile[hx][hy].PosY * (dMatrixStep - modx))/dMatrixStep;
				CalibrationFile[i][j].PosY = (ay * mody + by * (dMatrixStep - mody))/dMatrixStep;
			
				ax = (CalibrationFile2[lx][ly].PosX * modx + CalibrationFile2[hx][ly].PosX * (dMatrixStep - modx))/dMatrixStep;
				bx = (CalibrationFile2[lx][hy].PosX * modx + CalibrationFile2[hx][hy].PosX * (dMatrixStep - modx))/dMatrixStep;
				CalibrationFile2[i][j].PosX = (ax * mody + bx * (dMatrixStep - mody))/dMatrixStep;
				
				ay = (CalibrationFile2[lx][ly].PosY * modx + CalibrationFile2[hx][ly].PosY * (dMatrixStep - modx))/dMatrixStep;
				by = (CalibrationFile2[lx][hy].PosY * modx + CalibrationFile2[hx][hy].PosY * (dMatrixStep - modx))/dMatrixStep;
				CalibrationFile2[i][j].PosY = (ay * mody + by * (dMatrixStep - mody))/dMatrixStep;
			
			}
		}
	}
	
	////////////////////////////////////////
	// write master....

	char pFileMasterPath[MAX_PATH];
	lstrcpy(pFileMasterPath, (LPCTSTR)gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
	CTime cTime = CTime::GetCurrentTime();
	CString strVal(pFileMasterPath);
	int nDot = strVal.ReverseFind(_T('.'));
	if (nDot == -1)
	{
		strVal += cTime.Format(_T("%Y%m%d%H%M"));
		strVal += _T(".asc");
	}
	else
	{
		strVal = strVal.Left(nDot);
		strVal += cTime.Format(_T("%Y%m%d%H%M"));
		strVal += _T(".asc");
	}
	nDot = strVal.ReverseFind(_T('\\'));
	strVal = strVal.Right(strVal.GetLength() - nDot - 1);
	strVal = gEasyDrillerINI.m_clsDirPath.GetBackupDir() + strVal;

	CFile file;	
	if(!file.Open(pFileMasterPath, CFile::modeCreate | CFile::modeWrite))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFileMasterPath);
		ErrMessage(strMsg);
		return;
	}
	CFile file2;
	if(!file2.Open(strVal, CFile::modeCreate | CFile::modeWrite))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strVal);
		ErrMessage(strMsg);
		return;
	}	

	char buffer[32];
	CString str;

	TRY
	{
		file.Write(_T("LT\r\n"),4);
		file2.Write(_T("LT\r\n"),4);

		//y position first
		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				str.Format(_T("%.3f\r\n"), CalibrationFile[j][i].PosY);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
				file2.Write(buffer,str.GetLength());
			}
		}

		//x position second
		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				str.Format(_T("%.3f\r\n"), CalibrationFile[j][i].PosX);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
				file2.Write(buffer,str.GetLength());
			}
		}

		file.Write(_T("QT\r\n"),4);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
		file2.Write(_T("QT\r\n"),4);
		if (file2.m_hFile != CFile::hFileNull)
			file2.Close();
	}
	CATCH (CFileException, e)
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T(""));
		ErrMessage(strMsg);
		e->Delete();

		return;
	}
	END_CATCH

	////////////////////////////
	// for slave

	char pFileSlavePath[MAX_PATH];
	lstrcpy(pFileSlavePath, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
	strVal = pFileSlavePath;
	nDot = strVal.ReverseFind(_T('.'));
	if (nDot == -1)
	{
		strVal += cTime.Format(_T("%Y%m%d%H%M"));
		strVal += _T(".asc");
	}
	else
	{
		strVal = strVal.Left(nDot);
		strVal += cTime.Format(_T("%Y%m%d%H%M"));
		strVal += _T(".asc");
	}
	nDot = strVal.ReverseFind(_T('\\'));
	strVal = strVal.Right(strVal.GetLength() - nDot - 1);
	strVal = gEasyDrillerINI.m_clsDirPath.GetBackupDir() + strVal;

	if(!file.Open(pFileSlavePath, CFile::modeCreate |CFile::modeWrite))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFileSlavePath);
		ErrMessage(strMsg);
		return;
	}
	if(!file2.Open(strVal, CFile::modeCreate |CFile::modeWrite))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strVal);
		ErrMessage(strMsg);
		return;
	}

	TRY
	{
		file.Write("LT\r\n",4);
		file2.Write("LT\r\n",4);

		//y position first
		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				str.Format(_T("%.3f\r\n"), CalibrationFile2[j][i].PosY);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
				file2.Write(buffer,str.GetLength());
			}
		}

		//x position second
		for(int i = 0;i<MAX_CAL_X;i++)
		{
			for(int j=0;j<MAX_CAL_Y;j++)
			{
				str.Format(_T("%.3f\r\n"), CalibrationFile2[j][i].PosX);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
				file2.Write(buffer,str.GetLength());
			}
		}

		file.Write(_T("QT\r\n"),4);
		file2.Write(_T("QT\r\n"),4);
	}
	CATCH (CFileException, e)
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T(""));
		ErrMessage(strMsg);
		e->Delete();
		
		return;
	}
	END_CATCH

	return;
}

void Interpolation::FalseInterpolation()
{
	//check the false and interpolation the value

	int j;
	int a,b,h,l;

	//////////////////
	// master
	for(int i = 0;i<m_nMatrixSize;i++)
	{
		for(j=0;j<m_nMatrixSize;j++)
		{
	///////////////////////////////////////////////////////////////////////////
			if(IsSuccess[i][j]==FALSE)
			{
				a=i+1;
				b=i-1;
				h=j+1;
				l=j-1;
				
				if (0 > b)	b = 0;
				if (0 > l)	l = 0;
				if (m_nMatrixSize - 1 < a)	a = m_nMatrixSize - 1;
				if (m_nMatrixSize - 1 < h)	h = m_nMatrixSize - 1;
				while(IsSuccess[a][j]!=TRUE) {if(a<m_nMatrixSize-1) a++; else break;}
				while(IsSuccess[b][j]!=TRUE) {if(b>0) b--; else break;}

				while(IsSuccess[i][h]!=TRUE) {if(h<m_nMatrixSize-1) h++; else break;}
				while(IsSuccess[i][l]!=TRUE) {if(l>0) l--; else break;}

				if(a == m_nMatrixSize-1 && IsSuccess[a][j]!=TRUE) 
				{
					if(b>0) 
					{
						a=b-1;
						while(IsSuccess[a][j]!=TRUE) {if(a>0) a--; else break;}
					}
				}

				if(h == m_nMatrixSize-1 && IsSuccess[i][h]!=TRUE)
				{
					if(l>0) 
					{
						h=l-1;
						while(IsSuccess[i][h]!=TRUE) {if(h>0) h--; else break;}
					}
				}

				if(b == 0 && IsSuccess[b][j]!=TRUE && a!=0)
				{
					if(a<m_nMatrixSize-1)
					{
						b=a+1;
						while(IsSuccess[b][j]!=TRUE) {if(b<m_nMatrixSize-1) b++; else break;}
					}
				}
				if(l == 0 && IsSuccess[i][l]!=TRUE && h!=0)
				{
					if(h<m_nMatrixSize-1)
					{
						l=h+1;
						while(IsSuccess[i][l]!=TRUE) {if(l<m_nMatrixSize-1) l++; else break;}
					}
				}

				///////////////////////////////////////////////
				// interpolation 

				if(IsSuccess[a][j]==TRUE && IsSuccess[b][j]==TRUE &&
				   IsSuccess[i][h]==TRUE && IsSuccess[i][l]==TRUE)
				{
					OffsetPoint[i][j].PosX=( ((OffsetPoint[a][j].PosX-OffsetPoint[b][j].PosX)/(a-b)*(i-b)+OffsetPoint[b][j].PosX ) +
											 ((OffsetPoint[i][h].PosX-OffsetPoint[i][l].PosX)/(h-l)*(j-l)+OffsetPoint[i][l].PosX ) ) / 2.0;
					OffsetPoint[i][j].PosY=( ((OffsetPoint[a][j].PosY-OffsetPoint[b][j].PosY)/(a-b)*(i-b)+OffsetPoint[b][j].PosY ) +
											 ((OffsetPoint[i][h].PosY-OffsetPoint[i][l].PosY)/(h-l)*(j-l)+OffsetPoint[i][l].PosY ) ) / 2.0;
				}
				else if(IsSuccess[i][h]!=TRUE || IsSuccess[i][l]!=TRUE)
				{
					OffsetPoint[i][j].PosX=((OffsetPoint[a][j].PosX-OffsetPoint[b][j].PosX)/(a-b)*(i-b)+OffsetPoint[b][j].PosX );
					OffsetPoint[i][j].PosY=((OffsetPoint[a][j].PosY-OffsetPoint[b][j].PosY)/(a-b)*(i-b)+OffsetPoint[b][j].PosY );
										
				}
				else if(IsSuccess[a][j]!=TRUE || IsSuccess[b][j]!=TRUE)
				{
					OffsetPoint[i][j].PosX=((OffsetPoint[i][h].PosX-OffsetPoint[i][l].PosX)/(h-l)*(j-l)+OffsetPoint[i][l].PosX );
					OffsetPoint[i][j].PosY=((OffsetPoint[i][h].PosY-OffsetPoint[i][l].PosY)/(h-l)*(j-l)+OffsetPoint[i][l].PosY );
										
				}
			}
		}
	}

	//////////////////
	// slave
	for(int i = 0;i<m_nMatrixSize;i++)
	{
		for(j=0;j<m_nMatrixSize;j++)
		{
	///////////////////////////////////////////////////////////////////////////
			if(IsSuccess2[i][j]==FALSE)
			{
				a=i+1;
				b=i-1;
				h=j+1;
				l=j-1;
				
				if(0 > b)	b = 0;
				if(0 > l)	l = 0;
				if (m_nMatrixSize - 1 < a)	a = m_nMatrixSize - 1;
				if (m_nMatrixSize - 1 < h)	h = m_nMatrixSize - 1;
				while(IsSuccess2[a][j]!=TRUE) {if(a<m_nMatrixSize-1) a++; else break;}
				while(IsSuccess2[b][j]!=TRUE) {if(b>0) b--; else break;}

				while(IsSuccess2[i][h]!=TRUE) {if(h<m_nMatrixSize-1) h++; else break;}
				while(IsSuccess2[i][l]!=TRUE) {if(l>0) l--; else break;}

				if(a == m_nMatrixSize-1 && IsSuccess2[a][j]!=TRUE) 
				{
					if(b>0) 
					{
						a=b-1;
						while(IsSuccess2[a][j]!=TRUE) {if(a>0) a--; else break;}
					}
				}

				if(h == m_nMatrixSize-1 && IsSuccess2[i][h]!=TRUE)
				{
					if(l>0) 
					{
						h=l-1;
						while(IsSuccess2[i][h]!=TRUE) {if(h>0) h--; else break;}
					}
				}

				if(b==0 && IsSuccess2[b][j]!=TRUE && a!=0)
				{
					if(a<m_nMatrixSize-1)
					{
						b=a+1;
						while(IsSuccess2[b][j]!=TRUE) {if(b<m_nMatrixSize-1) b++; else break;}
					}
				}
				if(l==0 && IsSuccess2[i][l]!=TRUE && h!=0)
				{
					if(h<m_nMatrixSize-1)
					{
						l=h+1;
						while(IsSuccess2[i][l]!=TRUE) {if(l<m_nMatrixSize-1) l++; else break;}
					}
				}

				///////////////////////////////////////////////
				// interpolation 

				if(IsSuccess2[a][j]==TRUE && IsSuccess2[b][j]==TRUE &&
				   IsSuccess2[i][h]==TRUE && IsSuccess2[i][l]==TRUE)
				{
					OffsetPoint2[i][j].PosX=( ((OffsetPoint2[a][j].PosX-OffsetPoint2[b][j].PosX)/(a-b)*(i-b)+OffsetPoint2[b][j].PosX ) +
											 ((OffsetPoint2[i][h].PosX-OffsetPoint2[i][l].PosX)/(h-l)*(j-l)+OffsetPoint2[i][l].PosX ) ) / 2.0;
					OffsetPoint2[i][j].PosY=( ((OffsetPoint2[a][j].PosY-OffsetPoint2[b][j].PosY)/(a-b)*(i-b)+OffsetPoint2[b][j].PosY ) +
											 ((OffsetPoint2[i][h].PosY-OffsetPoint2[i][l].PosY)/(h-l)*(j-l)+OffsetPoint2[i][l].PosY ) ) / 2.0;
				}
				else if(IsSuccess2[i][h]!=TRUE || IsSuccess2[i][l]!=TRUE)
				{
					OffsetPoint2[i][j].PosX=((OffsetPoint2[a][j].PosX-OffsetPoint2[b][j].PosX)/(a-b)*(i-b)+OffsetPoint2[b][j].PosX );
					OffsetPoint2[i][j].PosY=((OffsetPoint2[a][j].PosY-OffsetPoint2[b][j].PosY)/(a-b)*(i-b)+OffsetPoint2[b][j].PosY );
										
				}
				else if(IsSuccess2[a][j]!=TRUE || IsSuccess2[b][j]!=TRUE)
				{
					OffsetPoint2[i][j].PosX=((OffsetPoint2[i][h].PosX-OffsetPoint2[i][l].PosX)/(h-l)*(j-l)+OffsetPoint2[i][l].PosX );
					OffsetPoint2[i][j].PosY=((OffsetPoint2[i][h].PosY-OffsetPoint2[i][l].PosY)/(h-l)*(j-l)+OffsetPoint2[i][l].PosY );
										
				}
			}
		}
	}	
	return;
}

void Interpolation::BicubicCalibration()
{
	Calibration();
}


