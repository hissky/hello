// RefuseList.h: interface for the CRefuseList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REFUSELIST_H__2760C1C7_AAB8_4176_AF7D_1E3CB34E22A8__INCLUDED_)
#define AFX_REFUSELIST_H__2760C1C7_AAB8_4176_AF7D_1E3CB34E22A8__INCLUDED_

#include "ArchiveMark.h"

struct POSITIONDATA {
	int nNo;
	double dPosX;
	double dPosY;
};
typedef	POSITIONDATA*	LPPOSITIONDATA;

typedef CTypedPtrList <CPtrList, LPPOSITIONDATA>	PositionDataList;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRefuseList : public CObject
{
public:
	CRefuseList();
	virtual ~CRefuseList();

	void Initialize();

	int	m_nTotalListNo;
	
	CList <POSITIONDATA, POSITIONDATA> m_RefuseData;

	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion);
};

#endif // !defined(AFX_REFUSELIST_H__2760C1C7_AAB8_4176_AF7D_1E3CB34E22A8__INCLUDED_)
