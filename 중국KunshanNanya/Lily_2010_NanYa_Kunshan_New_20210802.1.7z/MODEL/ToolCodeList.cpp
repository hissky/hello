// ToolCodeList.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "ToolCodeList.h"
#include "DProject.h"
#include "dsystemini.h"
#include "deasydrillerini.h"
#include "DProcessINI.h"
#include "DBeampathINI.h"
#include "ParamODBC.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolCodeList

CToolCodeList::CToolCodeList()
{
	Initialize();
}

CToolCodeList::~CToolCodeList()
{
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CToolCodeList, CObject)
	//{{AFX_MSG_MAP(CToolCodeList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CToolCodeList member functions

void CToolCodeList::Initialize()
{
	m_bCountOver = FALSE;
	m_nApertureCount = 0;
	m_bVisible = TRUE;
	m_nToolNo = 0;
	m_bUseTool = FALSE;
	m_bToolOrder = FALSE;
	m_nToolSize = 0;
	m_nApertureSize = 0;
	m_nLeadIn = 0;
	m_nLeadOut = 0;
	m_nToolColor = RGB(0,0,0);
	m_nRefToolNo = 0;
	m_nTotalSubNo = 0;
	m_nMarkingSize = 600;
	m_bPreworkPower = TRUE;
	m_bPreworkPreheat = TRUE;
	m_bPreworkScanner = TRUE;
	m_rcAperture.left = m_rcAperture.right = m_rcAperture.bottom = m_rcAperture.top = 0; // default : shot
	m_bHoldFind = FALSE;
	m_bHoleSorting = TRUE;

	m_nTempToolIsHole = 0;
	m_bContainBlockData = FALSE;
	
}

void CToolCodeList::Serialize(CArchiveMark& ar)
{
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			SaveFile10000(ar, 10000);
		}
		else
		{	// loading code
			LoadFile10000(ar, 10000);
			m_bVisible = TRUE;
			CalApertureSizeAndLeadInOut();
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
	}
	END_CATCH
}

int CToolCodeList::GetApertureSize()
{
	return m_nApertureSize;
}

BOOL CToolCodeList::IsValidCount()
{
	return !(m_bCountOver);
}

void CToolCodeList::CalApertureSizeAndLeadInOut()
{
	BOOL bBarCode = FALSE;
	m_rcAperture.bottom = m_rcAperture.left = INT_MAX;
	m_rcAperture.top = m_rcAperture.right = INT_MIN;

	m_nLeadIn = 0;
	m_nLeadOut = 0;
	
	SUBTOOLDATA subTool;
	POSITION pos = m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subTool = m_SubToolData.GetNext(pos);
		if(subTool.nToolType == BARCODE_TYPE)
		{
			bBarCode = TRUE;
			m_nApertureSize = m_nToolSize;
		}
		else
		{
			if(subTool.bUseAperture)
			{
				m_bCountOver = FALSE;
				
				ParseApertureData(subTool.cFilePath, m_rcAperture, TRUE);
				
				if(m_bCountOver)
				{
					m_nApertureSize = 0;
					return;
				}
			}
		}
		if(subTool.nToolType == FLYING_TYPE)
		{
			if(m_nLeadIn < subTool.nLeadIn)
				m_nLeadIn = subTool.nLeadIn;
			if(m_nLeadOut < subTool.nLeadOut)
				m_nLeadOut = subTool.nLeadOut;
		}
		
	}
	
	if(bBarCode)
		return;

	if(m_rcAperture.bottom == INT_MAX)
	{
		m_nApertureSize = 0;
	}
	else
	{
		m_nApertureSize = max(abs(m_rcAperture.bottom), abs(m_rcAperture.left));
		int nTemp = max(abs(m_rcAperture.top), abs(m_rcAperture.right));
		m_nApertureSize = max(m_nApertureSize, nTemp);
	}
}

BOOL CToolCodeList::ParseApertureData(CString str, CRect &rect, BOOL bCalArea)
{
	if(str == _T(""))
		return FALSE;
	
	FILE* fp;
	errno_t err;
	err = fopen_s(&fp, (LPCTSTR)str, _T("r"));
	if(err != NULL)
		return FALSE;

	BOOL bResult = TRUE;
	TCHAR szBuf[256];
	CString strRead = _T("");
	CString strXPos = _T(""), strYPos = _T("");
	double dXPos = 0, dYPos = 0;
	int nChar = 0;

	m_nApertureCount = 0;
	
	while(!feof(fp))
	{
		fgets(szBuf, 255, fp);
		strRead = (CString) szBuf;
		strRead.TrimLeft();
		strRead.TrimRight();
		if(strRead.GetAt(0) == _T('P') && strRead.GetAt(2) == _T(';'))
		{
			if(strRead.GetAt(1) == _T('D'))
			{
				m_nApertureCount++;

				if(strRead.Find(_T(',')) == -1)
				{
					bResult = FALSE;
					break;
				}
				else
				{
					for(nChar = 3; nChar < strRead.Find(_T(',')); ++nChar)
						strXPos += strRead.GetAt(nChar);
					for(nChar = strRead.Find(_T(','))+1; nChar < strRead.GetLength()-1; ++nChar)
						strYPos += strRead.GetAt(nChar);
					dXPos = atof(strXPos);
					dYPos = atof(strYPos);
					strXPos = _T("");
					strYPos = _T("");
					if(bCalArea)
					{
						if(rect.bottom > dYPos) rect.bottom = (long)dYPos;
						if(rect.top < dYPos)	rect.top	= (long)dYPos;
						if(rect.left > dXPos)	rect.left	= (long)dXPos;
						if(rect.right < dXPos)	rect.right	= (long)dXPos;
					}
				}						
			}
			else if(strRead.GetAt(1) == _T('U'))
			{
				m_nApertureCount++;
				
				if(strRead.Find(_T(',')) == -1)
				{
					bResult = FALSE;
					break;
				}
				else
				{
					for(nChar = 3; nChar < strRead.Find(_T(',')); ++nChar)
						strXPos += strRead.GetAt(nChar);
					for(nChar = strRead.Find(_T(','))+1; nChar < strRead.GetLength()-1; ++nChar)
						strYPos += strRead.GetAt(nChar);
					dXPos = atof(strXPos);
					dYPos = atof(strYPos);
					strXPos = _T("");
					strYPos = _T("");
					if(bCalArea)
					{
						if(rect.bottom > dYPos) rect.bottom = (long)dYPos;
						if(rect.top < dYPos)	rect.top	= (long)dYPos;
						if(rect.left > dXPos)	rect.left	= (long)dXPos;
						if(rect.right < dXPos)	rect.right	= (long)dXPos;
					}
				}
			}
		}
	}
	fclose(fp);

	if(m_nApertureCount > 3000)
		m_bCountOver = TRUE;
	
	return (bResult);
}

int CToolCodeList::GetToolSumInfo()
{
	if(m_SubToolData.GetCount() <= 0)
		return emNoUse;

	BOOL bMark = FALSE;
	SUBTOOLDATA subTool;
	POSITION pos = m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subTool = m_SubToolData.GetNext(pos);
		if(subTool.nToolType == emToolFlying)
			return emFlying;
		
		if(subTool.nToolType == emToolBarcode)
			return emOneBoardTool;
		
		if(subTool.nToolType == emToolMark)
			bMark = TRUE;

		if(subTool.nToolType == emToolText)
			return emTextOneBoard;
	}

	if(m_bToolOrder)
		return emOneBoardTool;	
	if(bMark)
	{
//		if(!gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
			return emOneFieldTool;
//		else
//			return emOneBoardTool;
	}

	return emSameTool;
}

BOOL CToolCodeList::IsSameTool(CToolCodeList *pToolCode, BOOL bChangeSave)
{
	if(m_SubToolData.GetCount() != pToolCode->m_SubToolData.GetCount())
			return FALSE;

	SUBTOOLDATA subTool, subToolRef;
	POSITION pos = m_SubToolData.GetHeadPosition();
	POSITION posRef = pToolCode->m_SubToolData.GetHeadPosition();

	if(pos == NULL || posRef == NULL)
		return FALSE;

	while(pos != NULL && posRef != NULL)
	{
		subTool = m_SubToolData.GetNext(pos);
		subToolRef = pToolCode->m_SubToolData.GetNext(posRef);
		
		if(bChangeSave)
		{
			if(!IsSameSubTool2(subTool, subToolRef))
				return FALSE;
		}
		else
		{
			if(!IsSameSubTool(subTool, subToolRef))
				return FALSE;
		}
	}
	return TRUE;
}

BOOL CToolCodeList::IsSameSubTool(SUBTOOLDATA &subTool1, SUBTOOLDATA &subTool2)
{
	if(subTool1.nToolType != subTool2.nToolType)
		return FALSE;

	if(subTool1.nToolType == SHOT_DRILL_TYPE)
	{
		if(subTool1.nDrawStepPeriod != subTool2.nDrawStepPeriod)
			return FALSE;
		if(subTool1.nJumpStepPeriod != subTool2.nJumpStepPeriod)
			return FALSE;



		if(subTool1.nMask != subTool2.nMask)
				return FALSE;
		

		if(subTool1.nApertureBurst != subTool2.nApertureBurst)
			return FALSE;
		if(subTool1.dZOffset != subTool2.dZOffset)
			return FALSE;


//		CString str1, str2;
//		str1.Format(_T("%s"), subTool1.cMoveProfileFilePath);
//		str2.Format(_T("%s"), subTool2.cMoveProfileFilePath);
//		if(str1.CompareNoCase(str2)) // 
//			return FALSE;
	}
	else if(subTool1.nToolType == LINE_DRILL_TYPE || subTool1.nToolType == BARCODE_TYPE)
	{
		if(subTool1.nJumpStep != subTool2.nJumpStep)
			return FALSE;
		if(subTool1.nDrawStepPeriod != subTool2.nDrawStepPeriod)
			return FALSE;
		if(subTool1.nJumpStepPeriod != subTool2.nJumpStepPeriod)
			return FALSE;
		if(subTool1.nJumpDelay != subTool2.nJumpDelay)
			return FALSE;
		if(subTool1.nLineDelay != subTool2.nLineDelay)
			return FALSE;
		if(subTool1.nLaserOnDelay != subTool2.nLaserOnDelay)
			return FALSE;
		if(subTool1.nLaserOffDelay != subTool2.nLaserOffDelay)
			return FALSE;
		if(subTool1.nFrequency != subTool2.nFrequency)
			return FALSE;


			if(subTool1.nMask != subTool2.nMask)
				return FALSE;
	
		CString str1, str2;

		for(int i=0; i < subTool1.nTotalShot; i++)
		{
			if(subTool1.dShotDuty[i] != subTool2.dShotDuty[i])
				return FALSE;
			if(subTool1.dShotAOMDelay[i] != subTool2.dShotAOMDelay[i])
				return FALSE;
			if(subTool1.dShotAOMDuty[i] != subTool2.dShotAOMDuty[i])
				return FALSE;

			str1.Format(_T("%s"), subTool1.cAOMFilePath[i]);
			str2.Format(_T("%s"), subTool2.cAOMFilePath[i]);
			if(0 != str1.CompareNoCase(str2))
				return FALSE;
		}

		if(subTool1.bUseAperture != subTool2.bUseAperture)
			return FALSE;

		if(subTool1.dZOffset != subTool2.dZOffset)
			return FALSE;

		str1.Format(_T("%s"), subTool1.cFilePath);
		str2.Format(_T("%s"), subTool2.cFilePath);
		if(str1.CompareNoCase(str2)) // 
			return FALSE;
		
		if(subTool1.nToolType == BARCODE_TYPE)
		{
			if(subTool1.bFlipX != subTool2.bFlipX)
				return FALSE;
			if(subTool1.bFlipY != subTool2.bFlipY)
				return FALSE;
			if(subTool1.nRotate != subTool2.nRotate)
				return FALSE;
		}
	}
	else
	{
			if(subTool1.nMask != subTool2.nMask)
				return FALSE;
	}
	return TRUE;
}

BOOL CToolCodeList::IsSameSubTool2(SUBTOOLDATA &subTool1, SUBTOOLDATA &subTool2)
{
	CString str1, str2;
	if(subTool1.nToolType != subTool2.nToolType)
		return FALSE;

	if(subTool1.nMask != subTool2.nMask)
		return FALSE;

	if(subTool1.nTotalShot != subTool2.nTotalShot)
		return FALSE;
	
	if(subTool1.nBurstShot != subTool2.nBurstShot)
		return FALSE;

	if(subTool1.bUseAperture != subTool2.bUseAperture)
		return FALSE;

	if(subTool1.nApertureBurst != subTool2.nApertureBurst)
		return FALSE;

	for(int i=0; i < subTool1.nTotalShot; i++)
	{

		if(subTool1.dShotDuty[i] != subTool2.dShotDuty[i])
			return FALSE;
		if(subTool1.dShotAOMDelay[i] != subTool2.dShotAOMDelay[i])
			return FALSE;
		if(subTool1.dShotAOMDuty[i] != subTool2.dShotAOMDuty[i])
			return FALSE;
	

		str1.Format(_T("%s"), subTool1.cAOMFilePath[i]);
		str2.Format(_T("%s"), subTool2.cAOMFilePath[i]);
		if(0 != str1.CompareNoCase(str2))
			return FALSE;

		if(subTool1.dShotDuty[i] != subTool2.dShotDuty[i])
			return FALSE;
		
	}

	if(subTool1.nToolType == MARKING_TYPE || subTool1.nToolType == TEXT_TYPE)
	{
		if(subTool1.nJumpStep != subTool2.nJumpStep)
			return FALSE;
		if(subTool1.nDrawStepPeriod != subTool2.nDrawStepPeriod)
			return FALSE;
		if(subTool1.nJumpStepPeriod != subTool2.nJumpStepPeriod)
			return FALSE;
		if(subTool1.nJumpDelay != subTool2.nJumpDelay)
			return FALSE;
		if(subTool1.nLineDelay != subTool2.nLineDelay)
			return FALSE;
		if(subTool1.nLaserOnDelay != subTool2.nLaserOnDelay)
			return FALSE;
		if(subTool1.nLaserOffDelay != subTool2.nLaserOffDelay)
			return FALSE;
		if(subTool1.nFrequency != subTool2.nFrequency)
			return FALSE;

		if(subTool1.nToolType == BARCODE_TYPE)
		{
			if(subTool1.bFlipX != subTool2.bFlipX)
				return FALSE;
			if(subTool1.bFlipY != subTool2.bFlipY)
				return FALSE;
			if(subTool1.nRotate != subTool2.nRotate)
				return FALSE;
		}
	}
	
	return TRUE;
}
BOOL CToolCodeList::IsVisable()
{
	return m_bVisible;
}

BOOL CToolCodeList::LoadFile10000(CArchiveMark &ar, int nVersion, BOOL bGlobal, BOOL bPenOpen)
{
	SUBTOOLDATA toolData;
	CString str = _T("");;
	CString strTool = _T("");;
	CString strName = _T("");;
	CString strToolNo = _T("");;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			m_SubToolData.RemoveAll();
			
			ar >> str;
			ar >> strTool;
			int nIndex = strTool.Find("=");
			strName = strTool.Left(nIndex-1);
			if( strName.CompareNoCase(_T("T Code")) == 0 )
			{
				strToolNo = strTool.Right(1);
				m_nToolNo = atoi(strToolNo);
				if( bPenOpen)
					nVersion = 10025;
			}
			else
			{
				ar >> m_nToolNo;
				strToolNo = strTool.Right(5);
				nVersion =  atoi(strToolNo);
			}
				
			ar >> m_bUseTool;
			ar >> m_bToolOrder;
			ar >> m_nToolSize;
			ar >> m_nApertureSize;
			ar >> m_nToolColor;
			ar >> m_nTotalSubNo;

			if(nVersion >= 10030)
				ar >> m_nRefToolNo;
			else
				m_nRefToolNo = 0;


			if(nVersion >= 10011)
			{
				ar >> m_bPreworkPreheat;
				ar >> m_bPreworkPower;
				ar >> m_bPreworkScanner;
			}
			else
			{
				m_bPreworkPreheat = TRUE;
				m_bPreworkPower = TRUE;
				m_bPreworkScanner = TRUE;
			}

			if(nVersion >= 10016)
				ar >> m_nMarkingSize;
			else
				m_nMarkingSize = m_nToolSize;

			if(nVersion >= 10019)
				ar >> m_bHoldFind;
			else
				m_bHoldFind = FALSE;

			if(nVersion >= 10030)
				ar >> m_bHoleSorting;
			else
				m_bHoleSorting = TRUE;

			for(int i=0; i<m_nTotalSubNo; i++)
			{
				ar >> str;
				ar >> toolData.nSubToolNo;
				ar >> toolData.nToolType;
				ar >> toolData.dDrawStep;
				ar >> toolData.nJumpStep;
				ar >> toolData.nJumpStepPeriod;
				ar >> toolData.nDrawStepPeriod;
				ar >> toolData.nCornerDelay;
				ar >> toolData.nJumpDelay;
				ar >> toolData.nLineDelay;
				ar >> toolData.nLaserOnDelay;
				ar >> toolData.nLaserOffDelay;
				ar >> toolData.nFrequency;
				ar >> toolData.nFPS;
				ar >> toolData.dCurrent;
				ar >> toolData.nShotMode;
				ar >> toolData.nTotalShot;
				ar >> toolData.nBurstShot;
				ar >> toolData.nMask;

				if(nVersion >= 10007)

				{		
					ar >> toolData.bUseTophat;
				}
				else
					toolData.bUseTophat = FALSE;

				if(nVersion >= 10021)
					ar >> toolData.nMinShotTime;
				else
					toolData.nMinShotTime = 10;
				ar >> str;
				for(int j=0; j<MAX_SHOT; j++)
				{
					ar >> toolData.dShotDuty[j];
					ar >> toolData.dShotAOMDelay[j];
					ar >> toolData.dShotAOMDuty[j];

					if(nVersion >= 10017)

					{
						ar >> toolData.dShotDutyOffsetM[j];
						ar >> toolData.dShotDutyOffsetS[j];
						ar >> toolData.dShotVolOffsetM[j];
						ar >> toolData.dShotVolOffsetS[j];
					}
					else
					{
						toolData.dShotDutyOffsetM[j] = 0;
						toolData.dShotDutyOffsetS[j] = 0;
						toolData.dShotVolOffsetM[j] = 0;
						toolData.dShotVolOffsetS[j] = 0;
					}

					if (nVersion >= 10022)
					{
						ar >> toolData.dShotMinFreq[j];
						ar >> toolData.dShotMaxFreq[j];
					}
					else
					{

						toolData.dShotMinFreq[j] = gSystemINI.m_sSystemDump.nStandbyMinFreq;
						toolData.dShotMaxFreq[j] = 4000;
                       }

					if(nVersion >= 10004)
					{
						ar >> str;
						strcpy_s(toolData.cAOMFilePath[j], str);
					}
					else
					{
						str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
						strcpy_s(toolData.cAOMFilePath[j], str);
					}

					if( nVersion >= 10036)
					{
						ar >> toolData.dShotLPCMin_M[j];
						ar >> toolData.dShotLPCMax_M[j];
						ar >> toolData.dShotLPCMin_S[j];
						ar >> toolData.dShotLPCMax_S[j];
					}
					else
					{
						toolData.dShotLPCMin_M[j] = 99999;
						toolData.dShotLPCMax_M[j] = -99999;
						toolData.dShotLPCMin_S[j] = 99999;
						toolData.dShotLPCMax_S[j] = -99999;
					}

					if(nVersion >= 10029)
					{
						ar >> toolData.dPowerMin[j];
						ar >> toolData.dPowerMax[j];
					}
					else
					{
						toolData.dPowerMin[j] = -1;
						toolData.dPowerMax[j] = -1;
					}
				}

				if(nVersion >= 10031)
				{
					ar >> toolData.bBarcodeLineDrill;
					ar >> toolData.nMatrix;
				}
				else
				{
					toolData.bBarcodeLineDrill = FALSE;
					toolData.nMatrix = 6;
				}

				if(nVersion >= 10039 )
				{
					ar >> toolData.nMarkingContentsType;
				}
				else
				{
					toolData.nMarkingContentsType = 0;
				}

				
				ar >> toolData.bUseAperture;
				ar >> toolData.nApertureBurst;
				ar >> toolData.nThermalTrack;
				ar >> toolData.dA1;
				ar >> toolData.dA2;
				ar >> toolData.dZOffset;
				ar >> str;
 				strcpy_s(toolData.cFilePath, str);
				ar >> str;
//				strcpy_s(toolData.cMoveProfileFilePath, str);
//				ar >> str;
				ar >> toolData.nLeadIn;
				ar >> toolData.nLeadOut;
				ar >> toolData.nTableSpeed;
				
				ar >> toolData.bFlipX;
				ar >> toolData.bFlipY;
				ar >> toolData.nRotate;

				if(nVersion >= 10011)
				{
					ar >> str;
					strcpy_s(toolData.cToolMemo, str);
					ar >> toolData.dMinPower;
					ar >> toolData.dMaxPower;
					ar >> toolData.dHoleSize;
					
				}
				else
				{
					memset(toolData.cToolMemo, 0, MAX_PATH_LEN);
					toolData.dMinPower = 0.1;
					toolData.dMaxPower = 0.1;
					toolData.dHoleSize = 0.25;
					
				}
				
				if(nVersion >= 10011)
				{
					ar >> str;
					strcpy_s(toolData.cAscFile, str);
				}
				else
				{
					memset(toolData.cAscFile, 0, sizeof(toolData.cAscFile));
				}

				m_SubToolData.AddTail(toolData);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
		
	return TRUE;
}

BOOL CToolCodeList::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	SUBTOOLDATA toolData;
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("\n");
			ar << _T("Version = ") << nVersion << _T("\n");
			ar << _T("T Code = ") << m_nToolNo << _T("\n");
			ar << _T("Use Tool = ") << m_bUseTool << _T("\n");
			ar << _T("Tool Order = ") << m_bToolOrder << _T("\n");
			ar << _T("Tool Size = ") << m_nToolSize << _T("\n");
			ar << _T("Tool A Size = ") << m_nApertureSize << _T("\n");
			ar << _T("Tool Color = ") << m_nToolColor << _T("\n");
			ar << _T("SubTool Count = ") << m_SubToolData.GetCount() << _T("\n");
			ar << _T("Ref Tool = ") << m_nRefToolNo << _T("\n");
			ar << _T("PrePreheat = ") << m_bPreworkPreheat << _T("\n");
			ar << _T("PrePower = ") << m_bPreworkPower << _T("\n");
			ar << _T("PreScanner = ") << m_bPreworkScanner << _T("\n");
			ar << _T("Marking Size = ") << m_nMarkingSize << _T("\n");
			ar << _T("Hole Find = ") << m_bHoldFind << _T("\n");
			if( nVersion >=10030)
				ar << _T("Hole Sorting = ") << m_bHoleSorting << _T("\n");
			POSITION pos = m_SubToolData.GetHeadPosition();
			while(pos)
			{
				toolData = m_SubToolData.GetNext(pos);
				ar << _T("\n");
				ar << _T("Sub T Code = ") << toolData.nSubToolNo << _T("\n");
				ar << _T("Tool Type = ") << toolData.nToolType << _T("\n");
				ar << _T("Draw Step = ") << toolData.dDrawStep << _T("\n");
				ar << _T("Jump Step = ") << toolData.nJumpStep << _T("\n");
				ar << _T("Jump Step Period = ") << toolData.nJumpStepPeriod << _T("\n");
				ar << _T("Draw Step Period = ") << toolData.nDrawStepPeriod << _T("\n");
				ar << _T("Corner Delay = ") << toolData.nCornerDelay << _T("\n");
				ar << _T("Jump Delay = ") << toolData.nJumpDelay << _T("\n");
				ar << _T("Line Delay = ") << toolData.nLineDelay << _T("\n");
				ar << _T("Laser On Delay = ") << toolData.nLaserOnDelay << _T("\n");
				ar << _T("Laser Off Delay = ") << toolData.nLaserOffDelay << _T("\n");
				ar << _T("Frequency = ") << toolData.nFrequency << _T("\n");
				ar << _T("FPS = ") << toolData.nFPS << _T("\n");
				ar << _T("Current = ") << toolData.dCurrent << _T("\n");
				ar << _T("Shot Mode = ") << toolData.nShotMode << _T("\n");
				ar << _T("Total Shot = ") << toolData.nTotalShot << _T("\n");
				ar << _T("Burst Shot = ") << toolData.nBurstShot << _T("\n");
				ar << _T("Mask = ") << toolData.nMask << _T("\n");
				ar << _T("Use Tophat = ") << toolData.bUseTophat << _T("\n");
				ar << _T("Min Shot Time = ") << toolData.nMinShotTime << _T("\n");
				ar << _T("\n");
				for(int i=0; i<MAX_SHOT; i++)
				{
					str.Format(_T("#%d Duty = %.3f\n"), i+1, toolData.dShotDuty[i]);
					ar << str;
					str.Format(_T("#%d AOM Delay = %.3f\n"), i+1, toolData.dShotAOMDelay[i]);
					ar << str;
					str.Format(_T("#%d AOM Duty = %.3f\n"), i+1, toolData.dShotAOMDuty[i]);
					ar << str;

					str.Format(_T("#%d DutyOffsetM = %.3f\n"), i+1, toolData.dShotDutyOffsetM[i]);
					ar << str;
					str.Format(_T("#%d DutyOffsetS = %.3f\n"), i+1, toolData.dShotDutyOffsetS[i]);
					ar << str;
					str.Format(_T("#%d VolOffsetM = %.3f\n"), i+1, toolData.dShotVolOffsetM[i]);
					ar << str;
					str.Format(_T("#%d VolOffsetS = %.3f\n"), i+1, toolData.dShotVolOffsetS[i]);
					ar << str;

					str.Format(_T("#%d MinFreq = %.3f\n"), i+1, toolData.dShotMinFreq[i]);
					ar << str;
					str.Format(_T("#%d MaxFreq = %.3f\n"), i+1, toolData.dShotMaxFreq[i]);
					ar << str;
					str.Format(_T("%s\n"), toolData.cAOMFilePath[i]);
					ar << str;

					if( nVersion >= 10036)
					{
						str.Format(_T("#%d LPCMin_M = %.3f\n"), i+1, toolData.dShotLPCMin_M[i]);
						ar << str;
						str.Format(_T("#%d LPCMax_M = %.3f\n"), i+1, toolData.dShotLPCMax_M[i]);
						ar << str;
						str.Format(_T("#%d LPCMin_S = %.3f\n"), i+1, toolData.dShotLPCMin_S[i]);
						ar << str;
						str.Format(_T("#%d LPCMax_S = %.3f\n"), i+1, toolData.dShotLPCMax_S[i]);
						ar << str;
					}


					if( nVersion >=10029)
					{
						str.Format(_T("#%d Power Min = %.3f\n"), i+1, toolData.dPowerMin[i]);
						ar << str;
						str.Format(_T("#%d Power Max = %.3f\n"), i+1, toolData.dPowerMax[i]);
						ar << str;
					}
				}

				ar << _T("Use Barcode Line Drill = ") << toolData.bBarcodeLineDrill << _T("\n");
				ar << _T("Use Matrix = ") << toolData.nMatrix << _T("\n");
				ar << _T("Use Marking Contents Type = ") << toolData.nMarkingContentsType << _T("\n");
				ar << _T("Use Aperture = ") << toolData.bUseAperture << _T("\n");
				ar << _T("Aperture Burst = ") << toolData.nApertureBurst << _T("\n");
				ar << _T("Thermal Track = ") << toolData.nThermalTrack << _T("\n");
				ar << _T("A1 = ") << toolData.dA1 << _T("\n");
				ar << _T("A2 = ") << toolData.dA2 << _T("\n");
				ar << _T("Z Offset = ") << toolData.dZOffset << _T("\n");
				str.Format(_T("%s\n"), toolData.cFilePath);
				ar << str;
//				str.Format(_T("%s\n"), toolData.cMoveProfileFilePath);
//				ar << str;
				ar << _T("\n");
				ar << _T("Lead In = ") << toolData.nLeadIn << _T("\n");
				ar << _T("Lead Out = ") << toolData.nLeadOut << _T("\n");
				ar << _T("Table Speed = ") << toolData.nTableSpeed << _T("\n");

				ar << _T("Flip X = ") << toolData.bFlipX << _T("\n");
				ar << _T("Flip Y = ") << toolData.bFlipY << _T("\n");
				ar << _T("Rotate = ") << toolData.nRotate << _T("\n");

				str.Format(_T("%s\n"), toolData.cToolMemo);
				ar << str;

				ar << _T("MinPower = ") << toolData.dMinPower << _T("\n");
				ar << _T("MaxPower = ") << toolData.dMaxPower << _T("\n");
				ar << _T("HoleSize = ") << toolData.dHoleSize << _T("\n");

				str.Format(_T("%s\n"), toolData.cAscFile);
				ar << str;
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	
	return TRUE;
}


int CToolCodeList::CompareBeamPath(SUBTOOLDATA subTool, int nToolNo, int nSubIndex)
{
	//false return  -1;
	//else  return maskNo;

	int nRealNo = subTool.nMask;
	double dDuty = subTool.dShotDuty[0];
	double dAomDelay = subTool.dShotAOMDelay[0];
	double dAomDuty = subTool.dShotAOMDuty[0];
	double dZ1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[subTool.nMask];
	double dZ2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[subTool.nMask];
	double dM1 = gSystemINI.m_sSystemCollimator.dMaskPosition[subTool.nMask];
	double dC1 = gSystemINI.m_sSystemCollimator.sCollimatorPos[subTool.nMask].dPositon;

	double dM2 = gSystemINI.m_sSystemCollimator.dFixedMask;
	double dC2 = gSystemINI.m_sSystemCollimator.sCollimatorPos2[subTool.nMask].dPositon;


	int nFreq = subTool.nFrequency;
	CString strMsg, strLog;

	if(gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nRealNo] == nFreq && 
		gBeamPathINI.m_sBeampath.dPowCompensationDuty[nRealNo] == dDuty && 
		gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nRealNo] == dAomDelay && 
		gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nRealNo] == dAomDuty /*&&  
		gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nRealNo] == dZ1 && 
		gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nRealNo] == dZ2 && 
		gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nRealNo] == dC1 && 
		(double)gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nRealNo] == dM1*/)
	{
		return subTool.nMask;
	}
	else
	{
		for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
		{
			//���� ������Ʈ�� ���� ���� ��ġ�� ������Ʈ�� ����ũ�� ��ġ�� ������ Ȯ���� ���� 
			if(gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i] == nFreq && 
				gBeamPathINI.m_sBeampath.dPowCompensationDuty[i] == dDuty && 
				gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i] == dAomDelay && 
				gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i] == dAomDuty && 
				gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i] == gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nRealNo] && 
				gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i] == gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nRealNo] && 

				gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i] == gBeamPathINI.m_sBeampath.dBeamPathBetPos1[nRealNo] && 
				gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i] == gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nRealNo])
			{
			
				if(m_bUseTool)
				{
	
					strLog.Format(_T("Tool No : %d | SubTool No : %d | Real BeamPath No : %d | Change BeamPath No : %d | Project Freq : %d | Project Duty : %.1f | Project AOM Delay : %.1f | Project AOM Duty : %.1f | Z1 : %.1f | Z2 : %.1f | M1 : %.1f | C1 : %.1f | M2 : %.1f | C2 : %.1f | #Old BeamPath Info | Freq : %d | Duty : %.1f | AOM Delay : %.1f | AOM Duty : %.1f | #Changed BeamPath Info | Freq : %d | Duty : %.1f | AOM Delay : %.1f | AOM Duty : %.1f |" ), 
						nToolNo, nSubIndex, nRealNo, i, nFreq, dDuty, dAomDelay, dAomDuty, dZ1, dZ2, dM1, dC1, dM2, dC2,
						gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nRealNo],
						gBeamPathINI.m_sBeampath.dPowCompensationDuty[nRealNo], 
						gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nRealNo],
						gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nRealNo],
						gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i],
						gBeamPathINI.m_sBeampath.dPowCompensationDuty[i], 
						gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i],
						gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i]);
					ErrMessage(strMsg);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg), reinterpret_cast<WPARAM>(&strLog));
				}
				return i;
			}
		}
	}
	if(m_bUseTool)
	{
		strMsg.Format(_T("Project Open fail. There is no matched BeamPath"));
//		strLog.Format(_T("Tool No : %d | SubTool No : %d | BeamPath No : %d | Project Freq : %d | Project Duty : %.1f | Project AOM Delay : %.1f | Project AOM Duty : %.1f"), 
//					nToolNo, nSubIndex, nRealNo, nFreq, dDuty, dAomDelay, dAomDuty);
		strLog.Format(_T("Tool No : %d | SubTool No : %d | BeamPath No : %d | Project Freq : %d | Project Duty : %.1f | Project AOM Delay : %.1f | Project AOM Duty : %.1f | Z1 : %.1f | Z2 : %.1f | M1 : %.1f | C1 : %.1f"), 
					nToolNo, nSubIndex, nRealNo, nFreq, dDuty, dAomDelay, dAomDuty, dZ1, dZ2, dM1, dC1);
		ErrMessage(strMsg + _T("\n Please add new Beampath"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg), reinterpret_cast<WPARAM>(&strLog));

	}
	return -1;
}

BOOL CToolCodeList::IsSameBeamPath(CToolCodeList* pToolCode)
{
	int nSubToolCount = m_SubToolData.GetCount();
	int nSubToolCount2 = pToolCode->m_SubToolData.GetCount();

	if(m_SubToolData.GetCount() != pToolCode->m_SubToolData.GetCount())
		return FALSE;
	
	SUBTOOLDATA subTool, subToolRef;
	POSITION pos = m_SubToolData.GetHeadPosition();
	POSITION posRef = pToolCode->m_SubToolData.GetHeadPosition();
	if(pos != NULL && posRef != NULL)
	{
		subTool = m_SubToolData.GetNext(pos);
		subToolRef = pToolCode->m_SubToolData.GetNext(posRef);
		
			//if(subTool.nMask != subToolRef.nMask)
				//return FALSE;

		if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subToolRef.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask] || 
			gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subToolRef.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask] ||
			gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subToolRef.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask] ||
			gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[subToolRef.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[subTool.nMask] ||

			gBeamPathINI.m_sBeampath.dBeamPathRotator[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathRotator[subTool.nMask] || 
			gBeamPathINI.m_sBeampath.dBeamPathTopHat[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathTopHat[subTool.nMask] || 

			gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask] || 
			gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask] || 
			gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask] ||
			gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subToolRef.nMask] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask] ||
			gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subToolRef.nMask] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask] ||
			gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subToolRef.nMask] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask])
			return FALSE;
	}
	else
		return FALSE;
	return TRUE;
}

BOOL CToolCodeList::IsSameMinMaxFreq(CToolCodeList* pToolCode)
{

	return TRUE;

	SUBTOOLDATA subTool, subToolRef;
	POSITION pos = m_SubToolData.GetHeadPosition();
	POSITION posRef = pToolCode->m_SubToolData.GetHeadPosition();
	if(pos != NULL && posRef != NULL)
	{
		subTool = m_SubToolData.GetNext(pos);
		subToolRef = pToolCode->m_SubToolData.GetNext(posRef);
		
		//	if(subTool.nMask != subToolRef.nMask)
		//		return FALSE;
		for(int i = 0; i < subTool.nTotalShot; i++)
		{
			if(subTool.dShotMinFreq[i] != subToolRef.dShotMinFreq[i]  || 
				subTool.dShotMaxFreq[i] != subToolRef.dShotMaxFreq[i]  )
				return FALSE;
		}

	}
	else
		return FALSE;

	return TRUE;
}


void CToolCodeList::GetDutyOffsetfromMDB()
{
	return;
	ParamOdbc Odbc;
	if(!Odbc.DBConnect())
		return;

	SUBTOOLDATA subTool;
	POSITION pos;
	int nID[50],nType,nBeamPath;
	double dDuty[15], dFreq[15];
	double dOffset[15] = {0,};
	BOOL bResult= TRUE;
	double dGetOffset[15];

	pos = m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subTool = m_SubToolData.GetAt(pos);

		nType = subTool.nToolType;
		nBeamPath = subTool.nMask;

		memcpy(dDuty, subTool.dShotDuty, sizeof(subTool.dShotDuty));
		memcpy(dFreq, subTool.dShotMaxFreq, sizeof(subTool.dShotMaxFreq));
		memset(dGetOffset, 0, sizeof(dGetOffset));
		memset(nID, 0, sizeof(nID));

		if(!Odbc.GetStartIndex(subTool.nTotalShot, nType, nBeamPath, dFreq, dDuty, nID, dGetOffset))
		{
			Odbc.DBDisconnect();
			return; //ù��°������ �����Ƿ� ��ġ�ϴ°� ���ٰ� �Ǵ� 
		}
			
		for(int j = 0; j < subTool.nTotalShot; j++)
		{
			subTool.dShotDutyOffsetM[j] = dGetOffset[j]; 
		}
		m_SubToolData.SetAt(pos, subTool);

		m_SubToolData.GetNext(pos);
	}
	Odbc.DBDisconnect();

}

void CToolCodeList::SetDutyOffsettoMDB()
{
	return;
	ParamOdbc Odbc;
	if(!Odbc.DBConnect())
		return;

	SUBTOOLDATA subTool;
	POSITION pos;
	int nID[50],nType,nBeamPath;
	double dDuty[15], dFreq[15];
	double dOffset[15], dGetOffset[15];
	BOOL bGetOffset[15];
	BOOL bExist= TRUE;

	pos = m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subTool = m_SubToolData.GetAt(pos);

		nType = subTool.nToolType;
		nBeamPath = subTool.nMask;
		memset(nID, 0, sizeof(nID));
		memcpy(dDuty, subTool.dShotDuty, sizeof(subTool.dShotDuty));
		memcpy(dFreq, subTool.dShotMaxFreq, sizeof(subTool.dShotMaxFreq));
		memcpy(dOffset, subTool.dShotDutyOffsetM, sizeof(subTool.dShotDutyOffsetM));
		memset(bGetOffset, 0, sizeof(bGetOffset));
		memset(dGetOffset, 0, sizeof(dGetOffset));
		int nFoundCount = 0; 
		
		if(!Odbc.GetStartIndex(subTool.nTotalShot, nType, nBeamPath, dFreq, dDuty, nID,dGetOffset))
		{
			bExist = FALSE;
		}
		/*double dTemp;
		for(int k = 0; k < subTool.nTotalShot; k++)
		{
			if(!Odbc.GetDutyOffset(nID[nFoundCount]+k, nType, nBeamPath, dFreq[k], dDuty[k], &dTemp))
			{
				memset(bGetOffset, 0, sizeof(bGetOffset));
				nFoundCount++;
				k = 0;
				if(nID[nFoundCount] == 0) 
				{
					bExist = FALSE;
					break;
				}

				continue;
			}
			else
			{
				dGetOffset[k] = dTemp;
				bGetOffset[k] = TRUE;
			}
		}
		BOOL bMatch = TRUE;
		for(int j =0; j<subTool.nTotalShot; j++)
		{
			if(bGetOffset[j] != TRUE)
				bExist = FALSE;
			 if(dOffset[j] != dGetOffset[j])
				 bMatch = FALSE;
		}
		*/

		if(!bExist) // save 
		{
			Odbc.SetDutyOffset(subTool.nTotalShot, nType, nBeamPath, dFreq, dDuty, dOffset);
		}
		else 
		{
			Odbc.SetUpdateDutyOffset(subTool.nTotalShot, nID[0] , nType, nBeamPath, dFreq, dDuty, dOffset);
		}
		m_SubToolData.GetNext(pos);
	}
	Odbc.DBDisconnect();

}