// ProcessINIFile.cpp: implementation of the CProcessINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "ProcessINIFile.h"

#include "DProcessINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessINIFile::CProcessINIFile()
{

}

CProcessINIFile::~CProcessINIFile()
{

}

BOOL CProcessINIFile::OpenProcessINIFile(CString strFilePath, DProcessINI& clsProcessINI)
{


	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START LASER AND SCANNER SECTION")) )
		{
			if( FALSE == ParsingLaserScanner( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingLaserScanner"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START AUTO SETTING SECTION")) )
		{
			if( FALSE == ParsingAutoSetting( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingAutoSetting"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START OPTION SECTION")) )
		{
			if( FALSE == ParsingOption( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingOption"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START SYSTEM SECTION")) )
		{
			if( FALSE == ParsingSystem( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingSystem"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START FIDUCIAL FIND SECTION")) )
		{
			if( FALSE == ParsingFidFind( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingFidFind"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START SCANNER CAL SECTION")) )
		{
			if( FALSE == ParsingScannerCal( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingScannerCal"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START POWER MEASURE SECTION")) )
		{
			if( FALSE == ParsingPowerMeasure( sFile, clsProcessINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingPowerMeasure"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// END EASYDRILLER PROCESS INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CProcessINIFile::ParsingLaserScanner(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;

	while( sFile.ReadString( strGetData ) )
	{
		// Pen File Path
//		if( ScanSys( strGetData, _T("PEN PATH NAME ="), strTarget ) )
//		{
//			strTarget.TrimLeft(); strTarget.TrimRight();
//			sprintf_s( clsProcessINI.m_sProcessLaserScanner.szPenName, _T("%s"), strTarget );
//			continue;
//		}
		// Shot Count
		if( ScanSys( strGetData, _T("SHOT COUNT ="), strTarget ) )
		{
			CString strTotalShot;
			strTotalShot = ::AfxGetApp()->GetProfileString(_T("TOTAL SHOT"), _T("TOTAL SHOT"), _T("0"));
			__int64 nTemp1 = _atoi64( (LPSTR)(LPCTSTR)strTotalShot );
			__int64 nTemp2 = _atoi64( (LPSTR)(LPCTSTR)strTarget );

			if( nTemp1 >= nTemp2 )
				clsProcessINI.m_sProcessOption.nShotCount = nTemp1;
			else
				clsProcessINI.m_sProcessOption.nShotCount = nTemp2;
			continue;
		}
		// XY Order
		if( ScanSys( strGetData, _T("XY ORDER ="), clsProcessINI.m_sProcessCal.nXYOrder ) )
			continue;
		// recent 1st cal time
		if( ScanSys( strGetData, _T("1ST CAL TIME ="), clsProcessINI.m_sProcessCal.n1stCalTime ) )
			continue;
		// recent 2nd cal time
		if( ScanSys( strGetData, _T("2ND CAL TIME ="), clsProcessINI.m_sProcessCal.n2ndCalTime ) )
			continue;
		// Preheat SpeedZ1Z2
//		if( ScanSys( strGetData, _T("PREHEAT Z1Z2 ="), clsProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2 ) )
//			continue;
		if( 0 == strGetData.CompareNoCase(_T("// END LASER AND SCANNER SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CProcessINIFile::ParsingAutoSetting(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;

	while( sFile.ReadString( strGetData ) )
	{
		// Load Position #1 X, Y
		if( ScanSys( strGetData, _T("LOAD POSITION'1 X ="), clsProcessINI.m_sProcessAutoSetting.dLoadPosX ) )
			continue;
		if( ScanSys( strGetData, _T("LOAD POSITION'1 Y ="), clsProcessINI.m_sProcessAutoSetting.dLoadPosY ) )
			continue;
		// Load Position #2 X, Y
		if( ScanSys( strGetData, _T("LOAD POSITION'2 X ="), clsProcessINI.m_sProcessAutoSetting.dLoadPosX2 ) )
			continue;
		if( ScanSys( strGetData, _T("LOAD POSITION'2 Y ="), clsProcessINI.m_sProcessAutoSetting.dLoadPosY2 ) )
			continue;
		// Load Carrier Position
		if ( ScanSys( strGetData, _T("LOADER CARRIER CART POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderCartPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER CARRIER LOAD POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderLoadPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER CARRIER LOAD POSITION 2 ="), clsProcessINI.m_sProcessAutoSetting.dLoaderLoadPos2 ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER CARRIER ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderAlignPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER CARRIER CART POSITION 2 ="), clsProcessINI.m_sProcessAutoSetting.dLoaderCartPos2 ) )
			continue;
		// Unload Position X, Y
		if( ScanSys( strGetData, _T("UNLOAD POSITION X ="), clsProcessINI.m_sProcessAutoSetting.dUnloadPosX ) )
			continue;
		if( ScanSys( strGetData, _T("UNLOAD POSITION Y ="), clsProcessINI.m_sProcessAutoSetting.dUnloadPosY ) )
			continue;
		if( ScanSys( strGetData, _T("UNLOAD POSITION X2 ="), clsProcessINI.m_sProcessAutoSetting.dUnloadPosX2 ) )
			continue;
		if( ScanSys( strGetData, _T("UNLOAD POSITION Y2 ="), clsProcessINI.m_sProcessAutoSetting.dUnloadPosY2 ) )
			continue;
		// Unloader Carrier Position
		if ( ScanSys( strGetData, _T("UNLOADER CARRIER CART POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderCartPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER CARRIER UNLOAD POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderUnloadPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER CARRIER UNLOAD POSITION 2 ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderUnloadPos2 ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER CARRIER ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderAlignPos ) )
			continue;
		// Table Unclamp Limit
		if ( ScanSys( strGetData, _T("UNCLAMP LIMIT Y POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnclampLimitY ) )
			continue;
		// DustSuction Table Min Limit
		if ( ScanSys( strGetData, _T("DUSTSUCTION TABLE MIN LIMIT ="), clsProcessINI.m_sProcessAutoSetting.dDustSuctionMin ) )
			continue;
		// DustSuction Table Max Limit
		if ( ScanSys( strGetData, _T("DUSTSUCTION TABLE MAX LIMIT ="), clsProcessINI.m_sProcessAutoSetting.dDustSuctionMax ) )
			continue;

		// Loader Picker Position
		if ( ScanSys( strGetData, _T("LOADER PICKER1 UP POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1UpPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER1 ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1AlignPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER1 TABLE POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1TablePos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER2 UP POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2UpPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER2 ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2AlignPos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER2 TABLE POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2TablePos ) )
			continue;
		if ( ScanSys( strGetData, _T("LOADER PICKER2 CART POSITION ="), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2CartPos ) )
			continue;

		// Unloader Picker Position
		if ( ScanSys( strGetData, _T("UNLOADER PICKER1 UP POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1UpPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER1 ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1AlignPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER1 TABLE POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1TablePos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER1 CART POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1CartPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER2 UP POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2UpPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER2 ALIGN POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2AlignPos ) )
			continue;
		if ( ScanSys( strGetData, _T("UNLOADER PICKER2 TABLE POSITION ="), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2TablePos ) )
			continue;
	
		// Fiducial Standby Position X, Y
//		if( ScanSys( strGetData, _T("FIDUCIAL STANDBY POSITION X ="), clsProcessINI.m_sProcessAutoSetting.dFiducialX ) )
//			continue;
//		if( ScanSys( strGetData, _T("FIDUCIAL STANDBY POSITION Y ="), clsProcessINI.m_sProcessAutoSetting.dFiducialY ) )
//			continue;
		// Table Offset X, Y
//		if( ScanSys( strGetData, _T("TABLE OFFSET X ="), clsProcessINI.m_sProcessAutoSetting.dTableOffsetX ) )
//			continue;
//		if( ScanSys( strGetData, _T("TABLE OFFSET Y ="), clsProcessINI.m_sProcessAutoSetting.dTableOffsetY ) )
//			continue;
		// 1'st Height Sensor
		if( ScanSys( strGetData, _T("HS 1 MANUAL X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 MANUAL Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 AUTO X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 AUTO Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 OFFSET X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 OFFSET Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 HEAD Z ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ ) )
			continue;
		if( ScanSys( strGetData, _T("HS 1 BASE Z ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ ) )
			continue;
		// 2'nd Height Sensor
		if( ScanSys( strGetData, _T("HS 2 MANUAL X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 MANUAL Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 AUTO X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 AUTO Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 OFFSET X ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetX ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 OFFSET Y ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetY ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 HEAD Z ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ ) )
			continue;
		if( ScanSys( strGetData, _T("HS 2 BASE Z ="), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ ) )
			continue;
		// 1'st Powermeter
		if( ScanSys( strGetData, _T("PM 1 POS X ="), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x ) )
			continue;
		if( ScanSys( strGetData, _T("PM 1 POS Y ="), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y ) )
			continue;
		// 2'nd Powermeter
		if( ScanSys( strGetData, _T("PM 2 POS X ="), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x ) )
			continue;
		if( ScanSys( strGetData, _T("PM 2 POS Y ="), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y ) )
			continue;

		// TC Lens Cleaning Position
		if( ScanSys( strGetData, _T("TC CLEAN POS X ="), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosX ) )
			continue;
		if( ScanSys( strGetData, _T("TC CLEAN POS Y ="), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosY ) )
			continue;
		if( ScanSys( strGetData, _T("TC CLEAN POS Z1 ="), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosZ1 ) )
			continue;
		if( ScanSys( strGetData, _T("TC CLEAN POS Z2 ="), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosZ2 ) )
			continue;

/*
		// Mask Position 1 ~ 10
		if( ScanSys( strGetData, _T("MASK POS 1 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[0] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 2 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[1] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 3 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[2] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 4 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[3] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 5 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[4] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 6 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[5] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 7 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[6] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 8 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[7] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 9 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[8] ) )
			continue;
		if( ScanSys( strGetData, _T("MASK POS 10 ="), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[9] ) )
			continue;
*/
		
		if( 0 == strGetData.CompareNoCase(_T("// END AUTO SETTING SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CProcessINIFile::ParsingOption(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;

	while( sFile.ReadString( strGetData ) )
	{
		// 1'st Tolerance X
		if( ScanSys( strGetData, _T("1ST TOLERANCE X ="), clsProcessINI.m_sProcessCal.n1stToleranceX ) )
			continue;
		// 1'st Tolerance Y
		if( ScanSys( strGetData, _T("1ST TOLERANCE Y ="), clsProcessINI.m_sProcessCal.n1stToleranceY ) )
			continue;
		// 2'nd Tolerance X
		if( ScanSys( strGetData, _T("2ND TOLERANCE X ="), clsProcessINI.m_sProcessCal.n2ndToleranceX ) )
			continue;
		// 2'nd Tolerance Y
		if( ScanSys( strGetData, _T("2ND TOLERANCE Y ="), clsProcessINI.m_sProcessCal.n2ndToleranceY ) )
			continue;
		// 1'st Tolerance R
		if( ScanSys( strGetData, _T("1ST TOLERANCE R ="), clsProcessINI.m_sProcessCal.n1stToleranceR ) )
			continue;
		// 2'nd Tolerance R
		if( ScanSys( strGetData, _T("2ND TOLERANCE R ="), clsProcessINI.m_sProcessCal.n2ndToleranceR ) )
			continue;
		// Post prework minimum count
		if( ScanSys( strGetData, _T("PREWORK DOING MINIMUM COUNT ="), clsProcessINI.m_sProcessCal.nPostDoPreworkMinimumCount ) )
			continue;
		// Prework 1'st Tolerance X
		if( ScanSys( strGetData, _T("1ST PREWORK TOLERANCE X ="), clsProcessINI.m_sProcessCal.n1stPreworkToleranceX ) )
			continue;
		// Prework 1'st Tolerance Y
		if( ScanSys( strGetData, _T("1ST PREWORK TOLERANCE Y ="), clsProcessINI.m_sProcessCal.n1stPreworkToleranceY ) )
			continue;
		// Prework 2'nd Tolerance X
		if( ScanSys( strGetData, _T("2ND PREWORK TOLERANCE X ="), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceX ) )
			continue;
		// Prework 2'nd Tolerance Y
		if( ScanSys( strGetData, _T("2ND PREWORK TOLERANCE Y ="), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceY ) )
			continue;
		// Prework 1'st Tolerance R
		if( ScanSys( strGetData, _T("1ST PREWORK TOLERANCE R ="), clsProcessINI.m_sProcessCal.n1stPreworkToleranceR ) )
			continue;
		// Prework 2'nd Tolerance R
		if( ScanSys( strGetData, _T("2ND PREWORK TOLERANCE R ="), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceR ) )
			continue;
		// Auto Calibration Count
		if( ScanSys( strGetData, _T("AUTO CALIBRATION COUNT ="), clsProcessINI.m_sProcessCal.nAutoCalibrationCount ) )
			continue;
		// Auto Calibration Field Count
		if( ScanSys( strGetData, _T("AUTO CALIBRATION FIELD COUNT ="), clsProcessINI.m_sProcessCal.nAutoCalibrationFieldCount ) )
			continue;
		// Vision Calibration Field Count
		if( ScanSys( strGetData, _T("VISION CALIBRATION FIELD COUNT ="), clsProcessINI.m_sProcessCal.nVisionCalibrationFieldCount ) )
			continue;
		// Calibration Hole Gap
		if( ScanSys( strGetData, _T("CALIBRATION HOLE GAP ="), clsProcessINI.m_sProcessCal.dCalibrationHoleGap ) )
			continue;
		// Vision Calibration X Count
		if( ScanSys( strGetData, _T("VISION CALIBRATION X COUNT ="), clsProcessINI.m_sProcessCal.nVisionCalibrationXCount ) )
			continue;
		// Vision Calibration Y Count
		if( ScanSys( strGetData, _T("VISION CALIBRATION Y COUNT ="), clsProcessINI.m_sProcessCal.nVisionCalibrationYCount ) )
			continue;
		// Auto Calibration X Count
		if( ScanSys( strGetData, _T("AUTO CALIBRATION X COUNT ="), clsProcessINI.m_sProcessCal.nAutoCalibrationXCount ) )
			continue;
		// Auto Calibration Y Count
		if( ScanSys( strGetData, _T("AUTO CALIBRATION Y COUNT ="), clsProcessINI.m_sProcessCal.nAutoCalibrationYCount ) )
			continue;
		// Align Time
		if( ScanSys( strGetData, _T("ALIGN TIME ="), clsProcessINI.m_sProcessOption.nAlignTime ) )
			continue;
		// Load Time
		if( ScanSys( strGetData, _T("LOAD TIME ="), clsProcessINI.m_sProcessOption.nLoadTime ) )
			continue;
		// Unload Time
		if( ScanSys( strGetData, _T("UNLOAD TIME ="), clsProcessINI.m_sProcessOption.nUnloadTime ) )
			continue;
		// Auto Height Tol
		if( ScanSys( strGetData, _T("PCB HEIGHT AUTO TOL ="), clsProcessINI.m_sProcessOption.dPCBHeihtAutoTol ) )
			continue;
		// 1'st PCB Height Min
		if( ScanSys( strGetData, _T("1ST PCB HEIGHT MIN ="), clsProcessINI.m_sProcessOption.d1stPCBHeightMin ) )
			continue;
		// 1'st PCB Height Max
		if( ScanSys( strGetData, _T("1ST PCB HEIGHT MAX ="), clsProcessINI.m_sProcessOption.d1stPCBHeightMax ) )
			continue;
		// 2'nd PCB Height Min
		if( ScanSys( strGetData, _T("2ND PCB HEIGHT MIN ="), clsProcessINI.m_sProcessOption.d2ndPCBHeightMin ) )
			continue;
		// 2'nd PCB Height Max
		if( ScanSys( strGetData, _T("2ND PCB HEIGHT MAX ="), clsProcessINI.m_sProcessOption.d2ndPCBHeightMax ) )
			continue;
		// Check Suction Error
		if( ScanSys( strGetData, _T("CHECK SUCTION ERROR ="), clsProcessINI.m_sProcessOption.bCheckSuctionError ) )
			continue;
		// Reject Suction off
		if( ScanSys( strGetData, _T("REJECT SUCTION OFF ="), clsProcessINI.m_sProcessOption.bRejectSuctionOff ) )
			continue;
		// Valid Time
		if( ScanSys( strGetData, _T("VALID TIME ="), clsProcessINI.m_sProcessCal.nValidTime ) )
			continue;
		// Use Apply Tolerance
		if( ScanSys( strGetData, _T("USE APPLY TOLERANCE ="), clsProcessINI.m_sProcessCal.bUseApplyTolerance ) )
			continue;
		// Skip Board Check
//		if( ScanSys( strGetData, _T("SKIP BOARD CHECK ="), clsProcessINI.m_sProcessCal.bSkipBoardCheck ) )
//			continue;
		// Valid Measure Time
		if( ScanSys( strGetData, _T("VALID MEASURE TIME ="), clsProcessINI.m_sProcessCal.nValidMeasureTime ) )
			continue;

		// Align Start Time
		if( ScanSys( strGetData, _T("ALIGN START TIME ="), clsProcessINI.m_sProcessOption.nAlignStartPer ) )
			continue;
		// Align Dual Time
		if( ScanSys( strGetData, _T("ALIGN DUAL TIME ="), clsProcessINI.m_sProcessOption.nAlignDualTime ) )
			continue;
		// Align Single Time
		if( ScanSys( strGetData, _T("ALIGN SINGLE TIME ="), clsProcessINI.m_sProcessOption.nAlignSingleTime ) )
			continue;

		// Align Dual Time OnlyPCB
		if( ScanSys( strGetData, _T("ALIGN DUAL TIME ONLY PCB ="), clsProcessINI.m_sProcessOption.nAlignDualTimeOnlyPCB ) )
			continue;
		if( ScanSys( strGetData, _T("CAVITY DRAW IN OFFSET ="), clsProcessINI.m_sProcessOption.nCavityDrawInOffset ) )
			continue;

		if( ScanSys( strGetData, _T("CAVITY DRAW OUT OFFSET ="), clsProcessINI.m_sProcessOption.nCavityDrawOutOffset ) )
			continue;
		// Align Single Time OnlyPCB
		if( ScanSys( strGetData, _T("ALIGN SINGLE TIME ONLY PCB ="), clsProcessINI.m_sProcessOption.nAlignSingleTimeOnlyPCB ) )
			continue;

		if( ScanSys( strGetData, _T("VACUUM MOTOR OFF TIME ="), clsProcessINI.m_sProcessOption.nVacuumMotorOffTime ) )
			continue;

		// CCL Size
		if( ScanSys( strGetData, _T("FIDUCIAL CCL SIZE ="), clsProcessINI.m_sProcessOption.dCCLSize ) )
			continue;

		// PPG Size
		if( ScanSys( strGetData, _T("FIDUCIAL PPG SIZE ="), clsProcessINI.m_sProcessOption.dPPGSize ) )
			continue;

		// Verify Size
		if( ScanSys( strGetData, _T("FIDUCIAL VERIFY SIZE ="), clsProcessINI.m_sProcessOption.dVerifySize ) )
			continue;


		// Wait Temper down for AGC
		if( ScanSys( strGetData, _T("WAIT TEMPER DOWN FOR AGC ="), clsProcessINI.m_sProcessOption.bWaitTemperDownForAGC ) )
			continue;
		
		// Temper Compensation Repeat Comp Lot Count
		if( ScanSys( strGetData, _T("TEMPER COMPEN REPEAT LOT COUNT ="), clsProcessINI.m_sProcessOption.nTempRepeatCompenLotCount ) )
			continue;

		//
		if( ScanSys( strGetData, _T("TEMPER COMPEN EVERY STEP ="), clsProcessINI.m_sProcessOption.nTemperCompenEveryPnl ) )
			continue;

		// Temper Compensation verify lot count
		if( ScanSys( strGetData, _T("TEMPER COMPEN VERIFY LOT COUNT ="), clsProcessINI.m_sProcessOption.nTempCompenVerifyLotCount ) )
			continue;

		if( ScanSys( strGetData, _T("OCR MOVE OFFSET MM ="), clsProcessINI.m_sProcessOption.nOCRMoveOffset ) )
			continue;

		// Temper Compensation fire count for vision compensation
		if( ScanSys( strGetData, _T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN ="), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen ) )
			continue;

		if( ScanSys( strGetData, _T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 2 ="), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen2 ) )
			continue;

		if( ScanSys( strGetData, _T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 3 ="), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen3 ) )
			continue;

		if( ScanSys( strGetData, _T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 4 ="), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen4 ) )
			continue;

		if( ScanSys( strGetData, _T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 5 ="), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen5 ) )
			continue;

		// Temper Compensation mode
		if( ScanSys( strGetData, _T("TEMPER COMPENSATION MODE ="), clsProcessINI.m_sProcessOption.bTemperCompensationMode ) )
			continue;

		// Temper Measure mode
		if( ScanSys( strGetData, _T("TEMPER MEASURE MODE ="), clsProcessINI.m_sProcessOption.nTemperMeasureMode ) )
			continue;

		// Temper Verify mode
		if( ScanSys( strGetData, _T("TEMPER VERIFY MODE ="), clsProcessINI.m_sProcessOption.bTemperVerifyMode ) )
			continue;

		// Temper Verify Low Cam
		if( ScanSys( strGetData, _T("TEMPER VERIFY LOW CAM ="), clsProcessINI.m_sProcessOption.bTempVerifyLowCam ) )
		{
			clsProcessINI.m_sProcessOption.bTempVerifyLowCam = 0;
			continue;
		}
		// Temper Compensation Grid No
		if( ScanSys( strGetData, _T("TEMPER COMPENSATION GRID NO ="), clsProcessINI.m_sProcessOption.nTemperCompenGridNo ) )
			continue;

		// Temper Delta T
		if( ScanSys( strGetData, _T("TEMPER DELTA T ="), clsProcessINI.m_sProcessOption.dTemperDeltaT ) )
			continue;

		// Temper Compensation Timeout Min
		if( ScanSys( strGetData, _T("TEMPER COMPENSATION TIMEOUT MIN ="), clsProcessINI.m_sProcessOption.nTemperCompenTimeoutMin ) )
			continue;

		// Temper Compensation Repeat No
		if( ScanSys( strGetData, _T("TEMPER COMPENSATION REPEAT NO ="), clsProcessINI.m_sProcessOption.nTemperCompenRepeatNo ) )
			continue;

		// Temper 2D Linear Mode
		if( ScanSys( strGetData, _T("TEMPER 2D LINEAR MODE ="), clsProcessINI.m_sProcessOption.bTemper2DLinearMode ) )
			continue;

		// Temper Min T Limit
		if( ScanSys( strGetData, _T("TEMPER MIN T LIMIT ="), clsProcessINI.m_sProcessOption.dTemperMinTLimit ) )
			continue;

		// Temper Max T Limit
		if( ScanSys( strGetData, _T("TEMPER MAX T LIMIT ="), clsProcessINI.m_sProcessOption.dTemperMaxTLimit ) )
			continue;

		// Temper start T
		if( ScanSys( strGetData, _T("TEMPER END T ="), clsProcessINI.m_sProcessOption.dTemperEndT ) )
			continue;
		// Temper end T
		if( ScanSys( strGetData, _T("TEMPER TRANS T ="), clsProcessINI.m_sProcessOption.dTemperTransT ) )
			continue;

		// Temp Differ T Limit
		if( ScanSys( strGetData, _T("TEMPER DIFFER T LIMIT ="), clsProcessINI.m_sProcessOption.dTemperDifferTLimit ) )
			continue;

		// Temper Delta T Limit
		if( ScanSys( strGetData, _T("TEMPER DELTA T LIMIT ="), clsProcessINI.m_sProcessOption.dTemperDetaTLimit ) )
			continue;

		// Temper Minus Delta T Limit
		if( ScanSys( strGetData, _T("TEMPER MINUS DELTA T LIMIT ="), clsProcessINI.m_sProcessOption.dTemperMinusDetaTLimit ) )
			continue;

		// Temper No Change Time Limit Sec
		if( ScanSys( strGetData, _T("TEMPER WAIT SCAL SEC ="), clsProcessINI.m_sProcessOption.dTemperTWaitScal ) )
			continue;

		// Temper Detail Log
		if( ScanSys( strGetData, _T("TEMPER DETAIL LOG ="), clsProcessINI.m_sProcessOption.bTemperDetailLog ) )
			continue;

		// SBTemper Short Wait Time
		if( ScanSys( strGetData, _T("SB TEMPER TABLE MOVE WAIT TIME ="), clsProcessINI.m_sProcessOption.nTableMoveWaitTimeMS ) )
			continue;

		// SBTemper Long Wait Time
		if( ScanSys( strGetData, _T("SB TEMPER LONG WAIT TIME ="), clsProcessINI.m_sProcessOption.nSBTemperLongWaitTime ) )
			continue;

		// Temper Channel Index
		if( ScanSys( strGetData, _T("TEMPER TCM1 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nTCMasterCH1 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER TCM2 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nTCMasterCH2 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER TCS1 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nTCSlaveCH1 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER TCS2 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nTCSlaveCH2 ) )
			continue;

		if( ScanSys( strGetData, _T("TEMPER SBM1 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nSBMasterCH1 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER SBM2 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nSBMasterCH2 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER SBS1 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nSBSlaveCH1 ) )
			continue;
		if( ScanSys( strGetData, _T("TEMPER SBS2 CHANNEL NO ="), clsProcessINI.m_sProcessOption.nSBSlaveCH2 ) )
			continue;

		// Temper Start Duty
		if( ScanSys( strGetData, _T("TEMPER START DUTY ="), clsProcessINI.m_sProcessOption.nTemperStartDuty ) )
			continue;
		// Temper Step Duty
		if( ScanSys( strGetData, _T("TEMPER STEP DUTY ="), clsProcessINI.m_sProcessOption.nTemperStepDuty) )
			continue;
		// Temper Index Duty
		if( ScanSys( strGetData, _T("TEMPER POWER COUNT ="), clsProcessINI.m_sProcessOption.nTemperDutyStepNo ) )
			continue;
		// Temper Start Power
		if( ScanSys( strGetData, _T("TEMPER START POWER ="), clsProcessINI.m_sProcessOption.nTemperStartPower ) )
			continue;
		// Temper End Power
		if( ScanSys( strGetData, _T("TEMPER END POWER ="), clsProcessINI.m_sProcessOption.nTemperEndPower ) )
			continue;

		// Temper Verify Vision Contrast
		if( ScanSys( strGetData, _T("TEMPER VERIFY VISION CONTRAST ="), clsProcessINI.m_sProcessOption.dTemperVerifyContrast ) )
			continue;

		// Temper Verify Vision brightness
		if( ScanSys( strGetData, _T("TEMPER VERIFY VISION BRIGHTNESS ="), clsProcessINI.m_sProcessOption.dTemperVerifyBrightness ) )
			continue;
		
		// OPC Time Out
		if( ScanSys( strGetData, _T("SERVER TIME OUT ="), clsProcessINI.m_sProcessOption.nOPCTimeOut ) )
			continue;

		if( ScanSys( strGetData, _T("TABLE INPOS COUNT ="), clsProcessINI.m_sProcessOption.nTabelInposCount ) )
			continue;

		// OPC Log Save Data
		if( ScanSys( strGetData, _T("OPC LOG SAVE DATA ="), clsProcessINI.m_sProcessOption.nOpcLogSaveData ) )
			continue;

		// LPC Log Save Data
		if( ScanSys( strGetData, _T("LPC LOG SAVE DAT ="), clsProcessINI.m_sProcessOption.nLpcLogSaveData ) )
			continue;

		// Scal absolute time
		if( ScanSys( strGetData, _T("SCAL ABS TIME ="), clsProcessINI.m_sProcessCal.nScalAbsTime ) )
			continue;

		// Scal relative time
		if( ScanSys( strGetData, _T("SCAL REL TIME ="), clsProcessINI.m_sProcessCal.nScalRelTime ) )
			continue;

		// Scal Count
		if( ScanSys( strGetData, _T("SCAL COUNT TIME ="), clsProcessINI.m_sProcessCal.nScalCountTime ) )
			continue;

		// Scal Count
		if( ScanSys( strGetData, _T("SCAL COUNT TIME FOR SKIVE ="), clsProcessINI.m_sProcessCal.nScalCountTimeForSkive ) )
			continue;


		// Scal Count
		if( ScanSys( strGetData, _T("SCAL COUNT TIME 2 ="), clsProcessINI.m_sProcessCal.nScalCountTime2 ) )
			continue;

		// Power absolute time
		if( ScanSys( strGetData, _T("POWER ABS TIME ="), clsProcessINI.m_sProcessCal.nPowerAbsTime ) )
			continue;

		// Power relative time
		if( ScanSys( strGetData, _T("POWER REL TIME ="), clsProcessINI.m_sProcessCal.nPowerRelTime ) )
			continue;

		// Power Count
		if( ScanSys( strGetData, _T("POWER COUNT TIME ="), clsProcessINI.m_sProcessCal.nPowerCountTime ) )
			continue;

		// Preheat absolute time
		if( ScanSys( strGetData, _T("PREHEAT ABS TIME ="), clsProcessINI.m_sProcessCal.nPreheatAbsTime ) )
			continue;
		
		// Preheat relative time
		if( ScanSys( strGetData, _T("PREHEAT REL TIME ="), clsProcessINI.m_sProcessCal.nPreheatRelTime ) )
			continue;

		// Preheat relative time
		if( ScanSys( strGetData, _T("PREHEAT COUNT TIME ="), clsProcessINI.m_sProcessCal.nPreheatCountTime ) )
			continue;

		// Scal method
		if( ScanSys( strGetData, _T("PREWORK USE COUNT UNIT ="), clsProcessINI.m_sProcessCal.bUsePNLCountUnit ) )
			continue;


			// Scal method
		if( ScanSys( strGetData, _T("SCAL METHOD ="), clsProcessINI.m_sProcessCal.nScalMethod ) )
			continue;

		// Power method
		if( ScanSys( strGetData, _T("POWER METHOD ="), clsProcessINI.m_sProcessCal.nPowerMethod ) )
			continue;

		// Preheat method
		if( ScanSys( strGetData, _T("PREHEAT METHOD ="), clsProcessINI.m_sProcessCal.nPreheatMethod ) )
			continue;
/*

		// Scal Time
		if( ScanSys( strGetData, _T("SCAL START TIME ="), clsProcessINI.m_sProcessCal.nStartScalTime ) )
			continue;

		// Power Time
		if( ScanSys( strGetData, _T("POWER START TIME ="), clsProcessINI.m_sProcessCal.nStartPowerTime ) )
			continue;

		// Preheat Time
		if( ScanSys( strGetData, _T("PREHEAT START TIME ="), clsProcessINI.m_sProcessCal.nStartPreheatTime ) )
			continue;
*/
		// Preheat Modulation Time
		if( ScanSys( strGetData, _T("PREHEAT MODULATION TIME ="), clsProcessINI.m_sProcessCal.nPreheatModulationTime ) )
			continue;
		// Manual Preheat Time
		if( ScanSys( strGetData, _T("PREHEAT TIME ="), clsProcessINI.m_sProcessCal.nPreheatTime ) )
			continue;
		// AutoRun Preheat Time
		if( ScanSys( strGetData, _T("AUTORUN PREHEAT TIME ="), clsProcessINI.m_sProcessCal.nAutoRunPreheatTime ) )
			continue;
		// AutoRun Preheat Duty
		if( ScanSys( strGetData, _T("AUTORUN PREHEAT DUTY ="), clsProcessINI.m_sProcessCal.dAutoRunPreheatDuty ) )
			continue;
		// AutoRun Preheat Frequency
		if( ScanSys( strGetData, _T("AUTORUN PREHEAT FREQUENCY ="), clsProcessINI.m_sProcessCal.nAutoRunPreheatFreq ) )
			continue;
		if( ScanSys( strGetData, _T("AUTORUN PREHEAT JUMPDELAY ="), clsProcessINI.m_sProcessCal.nAutoRunPreheatJumpDelay ) )
			continue;



		// recent Preheat time
		if( ScanSys( strGetData, _T("PREHEAT END TIME ="), clsProcessINI.m_sProcessCal.nPreheatEndTime ) )
			continue;
		// Preheat SpeedXY
		if( ScanSys( strGetData, _T("PREHEAT XY ="), clsProcessINI.m_sProcessCal.nPreheatSpeedXY ) )
			continue;
		// Preheat Frequency
		if( ScanSys( strGetData, _T("PREHEAT FREQUENCY ="), clsProcessINI.m_sProcessCal.nPreheatFreq ) )
			continue;
		// Preheat Duty
		if( ScanSys( strGetData, _T("PREHEAT DUTY ="), clsProcessINI.m_sProcessCal.dPreheatDuty ) )
			continue;

		// Drill End Time 
		if( ScanSys( strGetData, _T("DRILL END TIME ="), clsProcessINI.m_sProcessCal.nDrillEndTime ) )
			continue;

		
		if( ScanSys( strGetData, _T("DUTY LIMIT2 ="), clsProcessINI.m_sProcessOption.dDutyLimit ) )
			continue;

		if( ScanSys( strGetData, _T("CHECK LPC ERROR ="), clsProcessINI.m_sProcessOption.bCheckLPCError ) )
			continue;

		if( ScanSys( strGetData, _T("LPC ERROR COUNT ="), clsProcessINI.m_sProcessOption.nLPCErrorCount ) )
			continue;

		if( ScanSys( strGetData, _T("LPC LOG SAVE DATE ="), clsProcessINI.m_sProcessOption.nLPCLogsaveDate ) )
			continue;

		if( ScanSys( strGetData, _T("LOG LPC DETAIL ="), clsProcessINI.m_sProcessOption.bLPCLogDetail ) )
			continue;

		if( ScanSys( strGetData, _T("USE POWER LOT END ="), clsProcessINI.m_sProcessCal.bPowerEndLot ) )
			continue;

		if( ScanSys( strGetData, _T("PREWORK USE POWER COMPENSATION MODE ="), clsProcessINI.m_sProcessCal.bUsePowerCompensationMode ) )
			continue;

		
		if( ScanSys( strGetData, _T("IDLE BEAMPATH ="), clsProcessINI.m_sProcessCal.nIdleBeamPath ) )
			continue;

		if( ScanSys( strGetData, _T("VISION CAL MODE ="), clsProcessINI.m_sProcessCal.nVisionCalMode ) )
			continue;

		if( ScanSys( strGetData, _T("MARKING DUAL MODE ="), clsProcessINI.m_sProcessOption.bMarkingDualMode ) )
			continue;

		if( ScanSys( strGetData, _T("SLAVE MEASURE START ="), clsProcessINI.m_sProcessOption.bSlaveMeasureStart ) )
			continue;

		if( ScanSys( strGetData, _T("USE FULL SCHEDULING ="), clsProcessINI.m_sProcessOption.bFullScheduling ) )
			continue;

		if( ScanSys( strGetData, _T("NO USE TOPHAT ="), clsProcessINI.m_sProcessOption.bNoUseTopHat ) )
			continue;

		if( ScanSys( strGetData, _T("WATER FLOW LASER ="), clsProcessINI.m_sProcessOption.dWaterFlowLaser ) )
			continue;

		if( ScanSys( strGetData, _T("WATER FLOW AOM ="), clsProcessINI.m_sProcessOption.dWaterFlowAom ) )
			continue;

		if( ScanSys( strGetData, _T("WATER FLOW SCANNER1 ="), clsProcessINI.m_sProcessOption.dWaterFlowScanner1 ) )
			continue;

		if( ScanSys( strGetData, _T("WATER FLOW SCANNER2 ="), clsProcessINI.m_sProcessOption.dWaterFlowScanner2 ) )
			continue;

		if( ScanSys( strGetData, _T("WATER FLOW ERROR CHECK ="), clsProcessINI.m_sProcessOption.bWaterFlowErrorCheck ) )
			continue;

		if( ScanSys( strGetData, _T("FIELD FIRE TIME LIMIT ="), clsProcessINI.m_sProcessOption.nFieldFireTimeLimit ) )
			continue;

		if( ScanSys( strGetData, _T("LOG COPY TIME ="), clsProcessINI.m_sProcessOption.nLogCopyTime ) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END OPTION SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CProcessINIFile::ParsingSystem(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	char szTemp[BUFMAX];
	while( sFile.ReadString( strGetData ) )
	{
		// Loader Unloader Cart Lock
		if( ScanSys( strGetData, _T("LOADER UNLOADER CART LOCK ="), clsProcessINI.m_sProcessSystem.bLoaderUnloaderCartLock ) )
			continue;
		// Dry Run
		if( ScanSys( strGetData, _T("DRY RUN ="), clsProcessINI.m_sProcessSystem.bDryRun ) )
			continue;
		// No Use Loader Unloader
		if( ScanSys( strGetData, _T("NO USE LOADER UNLOADER ="), clsProcessINI.m_sProcessSystem.bNoUseLoaderUnloader ) )
			continue;
		// Loader Unloader Door Lock
		if( ScanSys( strGetData, _T("LOADER UNLOADER DOOR LOCK ="), clsProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock ) )
			continue;
		// Show Scanner Path
		if( ScanSys( strGetData, _T("SHOW SCANNER PATH ="), clsProcessINI.m_sProcessSystem.bShowScannerPath ) )
			continue;
		// No Use Suction
		if( ScanSys( strGetData, _T("NO USE SUCTION ="), clsProcessINI.m_sProcessSystem.bNoUseSuction ) )
			continue;
		if( ScanSys( strGetData, _T("USE PRE LPR LIMIT ="), clsProcessINI.m_sProcessSystem.bUsePreLPRLimit ) )
			continue;

		// No Use Fiducial Find
		if( ScanSys( strGetData, _T("NO USE FIDUCIAL FIND ="), clsProcessINI.m_sProcessSystem.bNoUseFiducialFind ) )
			continue;
		// No Use Scanner
		if( ScanSys( strGetData, _T("NO USE SCANNER ="), clsProcessINI.m_sProcessSystem.bNoUseScanner ) )
			continue;
		// No Use Dust Suction
		if( ScanSys( strGetData, _T("NO USE DUST SUCTION ="), clsProcessINI.m_sProcessSystem.bNoUseDustSuction ) )
			continue;
		// No Sort Area
		if( ScanSys( strGetData, _T("NO SORT AREA ="), clsProcessINI.m_sProcessSystem.bNoSortArea ) )
			continue;
		if( ScanSys( strGetData, _T("AREA SORT MODE ="), clsProcessINI.m_sProcessSystem.nAreaSortMode ) )
			continue;
		// No Sort Area Y Ratio
		if( ScanSys( strGetData, _T("SORT AREA Y RATIO ="), clsProcessINI.m_sProcessSystem.dSortAreaYRatio ) )
			continue;

		// Use Recipe Sort
		if( ScanSys( strGetData, _T("RECIPE HOLE SORT ="), clsProcessINI.m_sProcessSystem.bRecipeHoleSort ) )
			continue;
		
		// No Sort Hole
		if( ScanSys( strGetData, _T("NO SORT HOLE ="), clsProcessINI.m_sProcessSystem.nNoSortHole ) )
			continue;
		// Sort Hole Pitch
		if( ScanSys( strGetData, _T("HOLE SORT PITCH ="), clsProcessINI.m_sProcessSystem.nHoleSortPitch) )
			continue;
		// Sort Distance Pitch
		if( ScanSys( strGetData, _T("HOLE DISTANCE PITCH ="), clsProcessINI.m_sProcessSystem.nHoleDistancePitch) )
			continue;
		// No Sort Line
		if( ScanSys( strGetData, _T("NO SORT LINE ="), clsProcessINI.m_sProcessSystem.bNoSortLine ) )
			continue;
		// No Divide Unit
		if( ScanSys( strGetData, _T("NO DIVIDE UNIT ="), clsProcessINI.m_sProcessSystem.bNoDivideUnit ) )
			continue;
		// Use Manual Fiducial Set
		if( ScanSys( strGetData, _T("USE MANUAL FID ="), clsProcessINI.m_sProcessSystem.bUseManualFidSet ) )
			continue;
		// No Use AOM Alarm	//2011526
		if( ScanSys( strGetData, _T("NO USE AOM ALARM ="), clsProcessINI.m_sProcessSystem.bNoUseAOMAlarm ) )
			continue;
		if( ScanSys( strGetData, _T("NO USE Z CAL ="), clsProcessINI.m_sProcessSystem.bNoUseZCal ) )
			continue;
		if( ScanSys( strGetData, _T("NO USE LASER CAL ="), clsProcessINI.m_sProcessSystem.bNoUseLaserCal ) )
			continue;

				if( ScanSys( strGetData, _T("NO USE T CAL ="), clsProcessINI.m_sProcessSystem.bNoUseTCal ) )
			continue;
		// No Use chiller Alarm	//2011526
		if( ScanSys( strGetData, _T("NO USE CHILLER ALARM ="), clsProcessINI.m_sProcessSystem.bNoUseChillerAlarm ) )
			continue;

		// No Use Power Check
		if( ScanSys( strGetData, _T("NO USE POWERCHECK ="), clsProcessINI.m_sProcessSystem.bNoUsePowerCheck ) )
			continue;
		//Field Minimum Divide
//		if( ScanSys( strGetData, _T("USE FIELD MINIMUM DIVIDE ="), clsProcessINI.m_sProcessSystem.bFieldMinimumDivide ) )
//			continue;
		// No Use Roll Up/Down
		if( ScanSys( strGetData, _T("NO USE ROLL UPDOWN ="), clsProcessINI.m_sProcessSystem.bNoUseRollUpDown ) )
			continue;
		// No Use Paper
		if( ScanSys( strGetData, _T("NO USE PAPER ="), clsProcessINI.m_sProcessSystem.bNoUsePaper ) )
		{
			clsProcessINI.m_sProcessSystem.bNoUsePaper = FALSE;
			continue;
		}
		//No Use Prework
		if( ScanSys( strGetData, _T("NO USE PREWORK ="), clsProcessINI.m_sProcessSystem.bNoUsePrework ) )
			continue;
		//No Use view change
		if( ScanSys( strGetData, _T("NO USE CHANGE VIEW ="), clsProcessINI.m_sProcessSystem.bNoUseChangeView ) )
			continue;
		// No Use Apply scal 
		if( ScanSys( strGetData, _T("NO USE APPLY SCAL ="), clsProcessINI.m_sProcessSystem.bNoUseApplyScal ) )
			continue;
		// Check Prework Data 
		if( ScanSys( strGetData, _T("CHECK PREWORK DATA ="), clsProcessINI.m_sProcessSystem.bCheckPreworkData ) )
			continue;
		// Use Get Head Offst 
		if( ScanSys( strGetData, _T("USE HIGH CAM OFFSET ="), clsProcessINI.m_sProcessSystem.bUseGetHighCamOffset ) )
			continue;

		if( ScanSys( strGetData, _T("USE 4WAY SCAL ="), clsProcessINI.m_sProcessSystem.bUse4WayScalMain ) )

			continue;
		if( ScanSys( strGetData, _T("USE PATTERN DEVIDE ="), clsProcessINI.m_sProcessSystem.bUsePatternDevide ) )
			continue;

		if( ScanSys( strGetData, _T("USE APPLY SCAL TO EOCARD ="), clsProcessINI.m_sProcessSystem.bUseApplyScalToEocard ) )
			continue;

		if( ScanSys( strGetData, _T("USE SHOT SCALE ="), clsProcessINI.m_sProcessSystem.bUseShotScale ) )
			continue;

		if( ScanSys( strGetData, _T("USE 1POINT VISION COMPEN ="), clsProcessINI.m_sProcessSystem.bUse1PointVisionCompen) )
			continue;

		if( ScanSys( strGetData, _T("USE SPARE1 ="), clsProcessINI.m_sProcessSystem.bUseSpare1) )
		{
			clsProcessINI.m_sProcessSystem.bUseSpare1 = FALSE;
			continue;
		}
		if( ScanSys( strGetData, _T("USE AUTO MONITORING ="), clsProcessINI.m_sProcessSystem.bUseAutoMonitoring ) )
			continue;

		if( ScanSys( strGetData, _T("USE SHEET SUCTION ="), clsProcessINI.m_sProcessSystem.bUseSheetSuction ) )
			continue;

		if( ScanSys( strGetData, _T("USE AUTO PREHEAT ="), clsProcessINI.m_sProcessSystem.bUseAutoPreHeat) )
			continue;

		// Use Text Marking
		if( ScanSys( strGetData, _T("USE TEXT MARKING ="), clsProcessINI.m_sProcessSystem.bUseTextMarking ) )
			continue;

		// Use Save Fid Image
		if( ScanSys( strGetData, _T("USE SAVE FID IMAGE ="), clsProcessINI.m_sProcessSystem.bUseSaveFidImage ) )
			continue;

		// Use Find Second Fid
		if( ScanSys( strGetData, _T("USE FIND SECOND FID ="), clsProcessINI.m_sProcessSystem.bUseFindSecondFid ) )
			continue;
		
		// Every Panel Thickness Measurement
		if( ScanSys( strGetData, _T("EVERY PANEL THICKNESS ="), clsProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement ) )
			continue;

		if( ScanSys( strGetData, _T("EVERY PANEL CHECK HEADOFFSET ="), clsProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck ) )
			continue;

		if( ScanSys( strGetData, _T("USE SCHEDULE ="), clsProcessINI.m_sProcessSystem.bUseScheduling) )
			continue;
		if( ScanSys( strGetData, _T("USE AI MODE ="), clsProcessINI.m_sProcessSystem.bUseAIMode) )
			continue;

		if( ScanSys( strGetData, _T("USE NEW PARAMETER3 ="), clsProcessINI.m_sProcessSystem.bUseNewParameter3) )
			continue;

		if( ScanSys( strGetData, _T("USE SPEED UP ="), clsProcessINI.m_sProcessSystem.bUseSpeedUp) )
			continue;

		if( ScanSys( strGetData, _T("USE ALL FID FIND ="), clsProcessINI.m_sProcessSystem.bUseAllFidFind) )
			continue;

		if( ScanSys( strGetData, _T("USE DETAIL LOG ="), clsProcessINI.m_sProcessSystem.bUseDetailLog) )
			continue;


		if( ScanSys( strGetData, _T("USE NEW BARCODE CONTENTS ="), clsProcessINI.m_sProcessSystem.bUseNewBarcodeContents) )
			continue;
		
		if( ScanSys( strGetData, _T("USE ALL TOOL SCAL ="), clsProcessINI.m_sProcessSystem.bUseAllToolScal) )
			continue;

		if( ScanSys( strGetData, _T("USE ALL TOOL POWER ="), clsProcessINI.m_sProcessSystem.bUseAllToolPower) )
			continue;


		if( ScanSys( strGetData, _T("USE ORIGIN INSPECTION MODE ="), clsProcessINI.m_sProcessSystem.bUseOriginalInspectionMode) )//No Use
		{
			clsProcessINI.m_sProcessSystem.bUseOriginalInspectionMode = FALSE;
			continue;
		}
		if( ScanSys( strGetData, _T("USE 1ST PANEL STOP ="), clsProcessINI.m_sProcessSystem.bUse1stPanelStop) )//No Use
		{
			clsProcessINI.m_sProcessSystem.bUse1stPanelStop = FALSE;
			continue;
		}
		
		// No Use Melsec Interface
		if( ScanSys( strGetData, "NO USE MELSEC INTERFACE =", clsProcessINI.m_sProcessSystem.bNoUseMelsecInterface ) )
			continue;
		
		if( ScanSys( strGetData, _T("HOLE COUNT CHECK ="), clsProcessINI.m_sProcessSystem.bCheckHoleCount) )
			continue;
		if( ScanSys( strGetData, _T("LASER ERROR CHECK ="), clsProcessINI.m_sProcessSystem.bLaserErrorCheck) )
			continue;
		if( ScanSys( strGetData, _T("SHOW ALL FID IMAGE ="), clsProcessINI.m_sProcessSystem.bShowAllFidImage) )
			continue;
		if( ScanSys( strGetData, _T("FAIL FIND FID CONTINUE ="), clsProcessINI.m_sProcessSystem.bFailFidCountinue) )
			continue;
		if( ScanSys( strGetData, _T("USE OPEN TOOL ="), clsProcessINI.m_sProcessSystem.bUseOpenTool) )
			continue;
		if( ScanSys( strGetData, _T("NO USE NGBOX ="), clsProcessINI.m_sProcessSystem.bNoUseNGBox) )
		{
			clsProcessINI.m_sProcessSystem.bNoUseNGBox = TRUE;
			continue;
		}
		if( ScanSys( strGetData, _T("USE TURN PANEL ="), clsProcessINI.m_sProcessSystem.bUseTurnPanel) )
			continue;
		if( ScanSys( strGetData, _T("DRY RUN NO PCB ="), clsProcessINI.m_sProcessSystem.bDryRunNoPCB) )
			continue;

		if( ScanSys( strGetData, _T("LINE TO SHOT DRILL MODE ="), clsProcessINI.m_sProcessSystem.bLineToShotFireMode) )// 20131028
		{
			clsProcessINI.m_sProcessSystem.bLineToShotFireMode = FALSE;
			continue;
		}
		if( ScanSys( strGetData, _T("LINE TO SHOT SAME LENGTH ="), clsProcessINI.m_sProcessSystem.bLineToShotSameLength) )// 20131028
		{
			clsProcessINI.m_sProcessSystem.bLineToShotSameLength = 1;//��n��E��e���� ��iA��
			continue;
		}
		if( ScanSys( strGetData, _T("PASS MODE ="), clsProcessINI.m_sProcessSystem.bPassMode) )
			continue;
		
				if( ScanSys( strGetData, _T("CHECK VISION SIZE ERROR ="), clsProcessINI.m_sProcessSystem.bCheckVisionSizeError) )
			continue;

	/*	for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			if( ScanSys( strGetData, _T("%d TOOL HOLE SORT ="),i, clsProcessINI.m_sProcessSystem.bToolHoleSort[i]) )
			continue;
		}*/

		for(int i=0; i < MAX_TOOL_NO; i++)
		{
			strTarget.Format(_T("%d TOOL HOLE SORT ="), i);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessSystem.bToolHoleSort[i] ))
				sFile.ReadString(strGetData);
		}


		
		if( 0 == strGetData.CompareNoCase(_T("// END SYSTEM SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CProcessINIFile::ParsingFidFind(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	char szTemp[50];
	int i = 0, k = 0;

	clsProcessINI.m_sProcessFidFind.dRefScale = 0.02;

	clsProcessINI.m_sProcessFidFind.dRefLengthTol = 0.105;

	clsProcessINI.m_sProcessFidFind.dRefLengthTol2 = 0.105;
	while( sFile.ReadString( strGetData ) )
	{
		// Fid Error Before Process
//		if( ScanSys( strGetData, _T("FIDUCIAL ERROR BEFORE PROCESS ="), clsProcessINI.m_sProcessFidFind.nFidErrorBeforeProcess ) )
//			continue;
		// Use Remove Fid
//		if( ScanSys( strGetData, _T("USE REMOVE FIDUCIAL ="), clsProcessINI.m_sProcessFidFind.bUseRemoveFid ) )
//			continue;
		// Remove Fiducial
//		if( ScanSys( strGetData, _T("REMOVE FIDUCIAL ="), clsProcessINI.m_sProcessFidFind.nRemoveFid ) )
//			continue;
		// Fiducial Vision Count
//		if( ScanSys( strGetData, _T("FIDUCIAL VISION COUNT ="), clsProcessINI.m_sProcessFidFind.nFidVisionCount ) )
//			continue;
		// Fiducial Find Method 1
		if( ScanSys( strGetData, _T("FIDUCIAL FIND METHOD 1 ="), clsProcessINI.m_sProcessFidFind.nFidFindMethod[0] ) )
			continue;
		// Fiducial Find Method 2
		if( ScanSys( strGetData, _T("FIDUCIAL FIND METHOD 2 ="), clsProcessINI.m_sProcessFidFind.nFidFindMethod[1] ) )
			continue;
		// Fiducial Total Retrial
		if( ScanSys( strGetData, _T("FIDUCIAL TOTAL RETRIAL ="), clsProcessINI.m_sProcessFidFind.nFidTotalRetrial ) )
			continue;
		// Fiducial Angle Limit
		if( ScanSys( strGetData, _T("FIDUCIAL ANGLE LIMIT ="), clsProcessINI.m_sProcessFidFind.dFidAngleLimit ) )
			continue;
		if( ScanSys( strGetData, _T("MULTI FIDUCIAL ORDER ="), clsProcessINI.m_sProcessFidFind.bMultiFidAscentOrder ) )
			continue;
		// Fiducial Error After Process
//		if( ScanSys( strGetData, _T("FIDUCIAL ERROR AFTER PROCESS ="), clsProcessINI.m_sProcessFidFind.nFidErrorAfterProcess ) )
//			continue;
		// PCB Length Tolerance
		if( ScanSys( strGetData, _T("PCB LENGTH TOLERANCE ="), clsProcessINI.m_sProcessFidFind.dPCBLenTolerance ) )
			continue;

		if( ScanSys( strGetData, _T("PCB LENGTH TOLERANCE2 ="), clsProcessINI.m_sProcessFidFind.dPCBLenTolerance2 ) )
			continue;

		if( ScanSys( strGetData, _T("REF. SCALE ="), clsProcessINI.m_sProcessFidFind.dRefScale ) )
			continue;

		if( ScanSys( strGetData, _T("REF. LENGTH TOLERANCE RUN LIMIT ="), clsProcessINI.m_sProcessFidFind.dRefLengthTol ) )
			continue;

		if( ScanSys( strGetData, _T("REF. LENGTH TOLERANCE2 ="), clsProcessINI.m_sProcessFidFind.dRefLengthTol2 ) )
			continue;

		// AUTO fiducial Tolerance
//		if( ScanSys( strGetData, _T("AUTO FIDUCIAL TOLERANCE ="), clsProcessINI.m_sProcessFidFind.bAutoFidTolerance ) )
//			continue;
		// AUTO fiducial recheck
		if( ScanSys( strGetData, _T("FIDUCIAL RECHECK ="), clsProcessINI.m_sProcessFidFind.bAutoFidRecheck ) )
			continue;
		// Recheck Tolerance
		if( ScanSys( strGetData, _T("RECHECK TOLERANCE ="), clsProcessINI.m_sProcessFidFind.dRecheckTolerance ) )
			continue;

		// user can run when scale limit over
		if( ScanSys( strGetData, _T("OPER CAN RUN FOR SCALE OVER ="), clsProcessINI.m_sProcessFidFind.bOperatorCanRunForScaleOver ) )
			continue;
		// Recheck Tolerance
		if( ScanSys( strGetData, _T("OPER CAN RUN TOL ="), clsProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit ) )
			continue;

		// Move Low Vision X
		if( ScanSys( strGetData, _T("MOVE LOW VISION X ="), clsProcessINI.m_sProcessFidFind.dMoveLowVision.x ) )
			continue;
		// Move Low Vision Y
		if( ScanSys( strGetData, _T("MOVE LOW VISION Y ="), clsProcessINI.m_sProcessFidFind.dMoveLowVision.y ) )
			continue;
		// Move High Vision X
		if( ScanSys( strGetData, _T("MOVE HIGH VISION X ="), clsProcessINI.m_sProcessFidFind.dMoveHighVision.x ) )
			continue;
		// Move High Vision Y
		if( ScanSys( strGetData, _T("MOVE HIGH VISION Y ="), clsProcessINI.m_sProcessFidFind.dMoveHighVision.y ) )
			continue;
		// Ref Pos X
		if( ScanSys( strGetData, _T("REF FID POS X ="), clsProcessINI.m_sProcessFidFind.dRefPosX ) )
			continue;
		// Ref Pos Y
		if( ScanSys( strGetData, _T("REF FID POS Y ="), clsProcessINI.m_sProcessFidFind.dRefPosY ) )
			continue;
		// Ref Pos X2
		if( ScanSys( strGetData, _T("REF FID POS X2 ="), clsProcessINI.m_sProcessFidFind.dRefPosX2 ) )
			continue;
		// Ref Pos Y2
		if( ScanSys( strGetData, _T("REF FID POS Y2 ="), clsProcessINI.m_sProcessFidFind.dRefPosY2 ) )
			continue;
		// Ref Pos X3
		if( ScanSys( strGetData, _T("REF FID POS X3 ="), clsProcessINI.m_sProcessFidFind.dRefPosX3 ) )
			continue;
		// Ref Pos Y3
		if( ScanSys( strGetData, _T("REF FID POS Y3 ="), clsProcessINI.m_sProcessFidFind.dRefPosY3 ) )
			continue;
		// Near Pos X
		if( ScanSys( strGetData, _T("NEAR FID POS X ="), clsProcessINI.m_sProcessFidFind.dNearPosX ) )
			continue;
		// Near Pos Y
		if( ScanSys( strGetData, _T("NEAR FID POS Y ="), clsProcessINI.m_sProcessFidFind.dNearPosY ) )
			continue;
		// Near Pos X2
		if( ScanSys( strGetData, _T("NEAR FID POS X2 ="), clsProcessINI.m_sProcessFidFind.dNearPosX2 ) )
			continue;
		// Near Pos Y2
		if( ScanSys( strGetData, _T("NEAR FID POS Y2 ="), clsProcessINI.m_sProcessFidFind.dNearPosY2 ) )
			continue;
		//Accept Size
		if( ScanSys( strGetData, _T("ACCEPT SIZE ="), clsProcessINI.m_sProcessFidFind.nAcceptSize) )
			continue;
		//Accept AspectRatio
		if( ScanSys( strGetData, _T("ACCEPT RATIO ="), clsProcessINI.m_sProcessFidFind.nAcceptRatio) )
			continue;

		if( ScanSys( strGetData, _T("USE ALL FID CONTROL ="), clsProcessINI.m_sProcessFidFind.bUseAllControl) )
			continue;

		if( ScanSys( strGetData, _T("HOLE PRE LIMIT ="), clsProcessINI.m_sProcessFidFind.nHolePreLimit) )
			continue;

		if( ScanSys( strGetData, _T("HOLE POST LIMIT ="), clsProcessINI.m_sProcessFidFind.nHolePostLimit) )
			continue;

		if( ScanSys( strGetData, _T("SCALE MINUS LIMIT ="), clsProcessINI.m_sProcessFidFind.dScaleMinusLimit) )
			continue;

		if( ScanSys( strGetData, _T("SCALE PLUS LIMIT ="), clsProcessINI.m_sProcessFidFind.dScalePlusLimit) )
			continue;
		
		if( ScanSys( strGetData, _T("DIAGNAL SCALE MINUS LIMIT ="), clsProcessINI.m_sProcessFidFind.dDiagonalScaleMinusLimit) )
			continue;

		if( ScanSys( strGetData, _T("DIAGNAL SCALE PLUS LIMIT ="), clsProcessINI.m_sProcessFidFind.dDiagonalScalePlusLimit) )
			continue;

		memset(szTemp, 0 , sizeof(szTemp));
		sprintf_s(szTemp,_T("HOLE FIND AREA POS%d ="), i );
		if( ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessFidFind.bHoleFindAreaPos[i]) )
		{
			i++;
			continue;
		}
		memset(szTemp, 0 , sizeof(szTemp));
		sprintf_s(szTemp,_T("HOLE FIND HOLE POS%d ="), k );
		if( ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessFidFind.bHoleFindHolePos[k]) )
		{
			k++;
			continue;
		}
				
		// Fid Save Data
		if( ScanSys( strGetData, _T("FID IMG SAVE DATE ="), clsProcessINI.m_sProcessFidFind.nFidImgSaveData ) )
			continue;

		// Log Save Data
		if( ScanSys( strGetData, _T("LOG SAVE DATE ="), clsProcessINI.m_sProcessFidFind.nLogSaveData ) )
			continue;

		if( ScanSys( strGetData, _T("PROPORTION COMPENSATION ="), clsProcessINI.m_sProcessFidFind.bUseProportionCompensation) )
			continue;

		// Vision Accept Score
		if( ScanSys( strGetData, _T("VISION ACCEPT SCORE ="), clsProcessINI.m_sProcessFidFind.dAcceptScore ) )
			continue;
		if( ScanSys( strGetData, _T("VISION ROTATE HOLE ACCEPT SCORE ="), clsProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore ) )
			continue;
		if( ScanSys( strGetData, _T("VISION EDGE HOLE ACCEPT SCORE ="), clsProcessINI.m_sProcessFidFind.dAcceptEdgeScore ) )
			continue;
		if( ScanSys( strGetData, _T("VISION RESULT SCORE ="),clsProcessINI.m_sProcessFidFind.dResultScore ) )
			continue;
		if( ScanSys( strGetData, _T("VISION EXPOSURE ="), clsProcessINI.m_sProcessFidFind.dExposure ) )
			continue;
		if( ScanSys( strGetData, _T("FID FIND VISION EXPOSURE ="), clsProcessINI.m_sProcessFidFind.dFidFindExposure ) )
			continue;


		if( 0 == strGetData.CompareNoCase(_T("// END FIDUCIAL FIND SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CProcessINIFile::ParsingScannerCal(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	TCHAR szTemp[BUFMAX];
	
	while( sFile.ReadString( strGetData ) )
	{
		// Auto Division
		if( ScanSys( strGetData, _T("AUTO DIVISION ="), clsProcessINI.m_sProcessScannerCal.nAutoDivision ) )
			continue;
		// Auto Mask
		if( ScanSys( strGetData, _T("AUTO MASK ="), clsProcessINI.m_sProcessScannerCal.nAutoMask ) )
			continue;
		// Auto Head
		if( ScanSys( strGetData, _T("AUTO HEAD ="), clsProcessINI.m_sProcessScannerCal.nAutoHead ) )
			continue;
		// Auto Pulse Width
		if( ScanSys( strGetData, _T("AUTO PULSE WIDTH ="), clsProcessINI.m_sProcessScannerCal.dAutoPulseWidth ) )
			continue;
		// Auto 1st Thickness
		if( ScanSys( strGetData, _T("AUTO 1ST THICKNESS ="), clsProcessINI.m_sProcessScannerCal.dAuto1stThickness ) )
			continue;
		// Auto 2nd Thickness
		if( ScanSys( strGetData, _T("AUTO 2ND THICKNESS ="), clsProcessINI.m_sProcessScannerCal.dAuto2ndThickness ) )
			continue;
		// Auto Start X
		if( ScanSys( strGetData, _T("AUTO START X ="), clsProcessINI.m_sProcessScannerCal.dAutoStart.x ) )
			continue;
		// Auto Start Y
		if( ScanSys( strGetData, _T("AUTO START Y ="), clsProcessINI.m_sProcessScannerCal.dAutoStart.y ) )
			continue;
		// Manual Division
		if( ScanSys( strGetData, _T("MANUAL DIVISION ="), clsProcessINI.m_sProcessScannerCal.nManualDivision ) )
			continue;
		// Manual Mask
		if( ScanSys( strGetData, _T("MANUAL MASK ="), clsProcessINI.m_sProcessScannerCal.nManualMask ) )
			continue;
		// Manual Head
		if( ScanSys( strGetData, _T("MANUAL HEAD ="), clsProcessINI.m_sProcessScannerCal.nManualHead ) )
			continue;
		// Manual PulseWidth
		if( ScanSys( strGetData, _T("MANUAL PULSE WIDTH ="), clsProcessINI.m_sProcessScannerCal.dManualPulseWidth ) )
			continue;
		// Manual 1st Thickness
		if( ScanSys( strGetData, _T("MANUAL 1ST THICKNESS ="), clsProcessINI.m_sProcessScannerCal.dManual1stThickness ) )
			continue;
		// Manual 2nd Thickness
		if( ScanSys( strGetData, _T("MANUAL 2ND THICKNESS ="), clsProcessINI.m_sProcessScannerCal.dManual2ndThickness ) )
			continue;
		// Manual Start X
		if( ScanSys( strGetData, _T("MANUAL START X ="), clsProcessINI.m_sProcessScannerCal.dManualStart.x ) )
			continue;
		// Manual Start Y
		if( ScanSys( strGetData, _T("MANUAL START Y ="), clsProcessINI.m_sProcessScannerCal.dManualStart.y ) )
			continue;
		// Model Size
		if( ScanSys( strGetData, _T("MODEL SIZE ="), clsProcessINI.m_sProcessScannerCal.dModelSize ) )
			continue;
		// Model Orientation
		if( ScanSys( strGetData, _T("MODEL ORIENTATION ="), clsProcessINI.m_sProcessScannerCal.dModelOrientation ) )
			continue;
		// Model Polarity
		if( ScanSys( strGetData, _T("MODEL POLARITY ="), clsProcessINI.m_sProcessScannerCal.nModelPolarity ) )
			continue;
		// Size Tolerance
		if( ScanSys( strGetData, _T("SIZE TOLERANCE ="), clsProcessINI.m_sProcessScannerCal.dSizeTolerance ) )
			continue;
		// Angle Tolerance
		if( ScanSys( strGetData, _T("ANGLE TOLERANCE ="), clsProcessINI.m_sProcessScannerCal.dAngleTolerance ) )
			continue;
		// Aspect Ratio
		if( ScanSys( strGetData, _T("ASPECT RATIO ="), clsProcessINI.m_sProcessScannerCal.dAspectRatio ) )
			continue;

		// Vision Z Offset
		if( ScanSys( strGetData, _T("CAL VISION Z OFFSET ="), clsProcessINI.m_sProcessScannerCal.dVisionZOffset ) )
			continue;

		for(int i=0; i<4; i++)
		{
			strTarget.Format(_T("COAXIAL #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessScannerCal.nCoaxial[i] ))
				sFile.ReadString(strGetData);

			strTarget.Format(_T("IR #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessScannerCal.nIR[i] ))
				sFile.ReadString(strGetData);

			
			strTarget.Format(_T("RING #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessScannerCal.nRing[i] ))
				sFile.ReadString(strGetData);

			strTarget.Format(_T("CONTRAST #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessScannerCal.dContrast[i] ))
				sFile.ReadString(strGetData);

			strTarget.Format(_T("BRIGHTNESS #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessScannerCal.dBrightness[i] ) )
				sFile.ReadString(strGetData);
		}

		// Count Auto
		if( ScanSys( strGetData, _T("COUNT AUTO ="), clsProcessINI.m_sProcessScannerCal.nCountAuto ) )
			continue;

		// Vision Count Auto
		if( ScanSys( strGetData, _T("VISION COUNT AUTO ="), clsProcessINI.m_sProcessScannerCal.nVisionCountAuto ) )
			continue;
		
		if( ScanSys( strGetData, _T("COUNT CHECK HEAD OFFSET AUTO ="), clsProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto ) )
			continue;

		// Scan Temp X
		if( ScanSys( strGetData, _T("SCAN TEMP X ="), clsProcessINI.m_sProcessScannerCal.dScanXTemp ) )
			continue;

		// Scan Temp Y
		if( ScanSys( strGetData, _T("SCAN TEMP Y ="), clsProcessINI.m_sProcessScannerCal.dScanYTemp ) )
			continue;

		// Scan Master X
		if( ScanSys( strGetData, _T("SCAN MASTER X ="), clsProcessINI.m_sProcessScannerCal.dScanMasterX ) )
			continue;

		// Scan Master Y
		if( ScanSys( strGetData, _T("SCAN MASTER Y ="), clsProcessINI.m_sProcessScannerCal.dScanMasterY ) )
			continue;

		// Scan Slave X
		if( ScanSys( strGetData, _T("SCAN SLAVE X ="), clsProcessINI.m_sProcessScannerCal.dScanSlaveX ) )
			continue;

		// Scan Slave Y
		if( ScanSys( strGetData, _T("SCAN SLAVE Y ="), clsProcessINI.m_sProcessScannerCal.dScanSlaveY ) )
			continue;

		// Cal Table pos X Master
		if( ScanSys( strGetData, _T("MASTER CAL TABLE POS X ="), clsProcessINI.m_sProcessScannerCal.dMasterCalTablePosX ) )
			continue;
		// Cal Table pos Y Master
		if( ScanSys( strGetData, _T("MASTER CAL TABLE POS Y ="), clsProcessINI.m_sProcessScannerCal.dMasterCalTablePosY ) )
			continue;
		// Cal Table pos X Slave
		if( ScanSys( strGetData, _T("SLAVE CAL TABLE POS X ="), clsProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX ) )
			continue;
		// Cal Table pos Y Slave
		if( ScanSys( strGetData, _T("SLAVE CAL TABLE POS Y ="), clsProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY ) )
			continue;
		
		// default low scal
		if( ScanSys( strGetData, _T("DEFAULT LOW CAM ="), clsProcessINI.m_sProcessScannerCal.bDefaultLow ) )
		{
			continue;
		}
		// Scanner Cal Use Dummy
		if( ScanSys( strGetData, _T("SCANNER CAL USE DUMMY ="), clsProcessINI.m_sProcessScannerCal.bUseDummy ) )
			continue;

		// Max Offset Master X
		if( ScanSys( strGetData, _T("MAX OFFSET MASTER X ="), clsProcessINI.m_sProcessScannerCal.dMaxOffsetMasterX ) )
			continue;

		// Max Offset Master Y
		if( ScanSys( strGetData, _T("MAX OFFSET MASTER Y ="), clsProcessINI.m_sProcessScannerCal.dMaxOffsetMasterY ) )
			continue;

		// Max Offset Slave X
		if( ScanSys( strGetData, _T("MAX OFFSET SLAVE X ="), clsProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveX ) )
			continue;

		// Max Offset Slave Y
		if( ScanSys( strGetData, _T("MAX OFFSET SLAVE Y ="), clsProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveY) )
			continue;

		// Cal Table pos X min limit
		if( ScanSys( strGetData, _T("AUTO CAL TABLE MIN X ="), clsProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX ) )
			continue;
		// Cal Table pos Y min limit
		if( ScanSys( strGetData, _T("AUTO CAL TABLE MIN Y ="), clsProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY ) )
			continue;
		// Cal Table pos X max limit
		if( ScanSys( strGetData, _T("AUTO CAL TABLE MAX X ="), clsProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX ) )
			continue;
		// Cal Table pos Y max limit
		if( ScanSys( strGetData, _T("AUTO CAL TABLE MAX Y ="), clsProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY ) )
			continue;

		// optic Offset X, Y
		if( ScanSys( strGetData, _T("OPTIC OFFSET MX ="), clsProcessINI.m_sProcessAutoSetting.nOpticMX ) )
			continue;
		if( ScanSys( strGetData, _T("OPTIC OFFSET SX ="), clsProcessINI.m_sProcessAutoSetting.nOpticSX ) )
			continue;
		if( ScanSys( strGetData, _T("OPTIC OFFSET MY ="), clsProcessINI.m_sProcessAutoSetting.nOpticMY ) )
			continue;
		if( ScanSys( strGetData, _T("OPTIC OFFSET SY ="), clsProcessINI.m_sProcessAutoSetting.nOpticSY ) )
			continue;

		if( ScanSys( strGetData, _T("IDLE SHOT X ="), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX ) )
			continue;
		if( ScanSys( strGetData, _T("IDLE SHOT Y ="), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY ) )
			continue;
		if( ScanSys( strGetData, _T("IDLE SHOT Z1 ="), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ1 ) )
			continue;
		if( ScanSys( strGetData, _T("IDLE SHOT Z2 ="), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ2 ) )
			continue;
		if( ScanSys( strGetData, _T("IDLE SHOT BEAMPATH NO ="), clsProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo ) )
			continue;
		if( ScanSys( strGetData, _T("IDLE SHOT REPEAT NO ="), clsProcessINI.m_sProcessAutoSetting.nIdleShotRepeatCount ) )
			continue;
		// JOB FILE
		if( ScanSys( strGetData, _T("JOB FILE ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsProcessINI.m_sProcessScannerCal.szJobFilePath,  260, _T("%s"), strTarget );
			continue;
		}
		
		// Use Tool
		if( ScanSys( strGetData,_T("USE TOOL ="), clsProcessINI.m_sProcessScannerCal.nUseTool) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END SCANNER CAL SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}

BOOL CProcessINIFile::ParsingPowerMeasure(CStdioFile& sFile, DProcessINI& clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strGetData, strAOM;
	CString strTarget;
	TCHAR szTemp[BUFMAX];
	
	while( sFile.ReadString( strGetData ) )
	{
		// Min Allowable
		if( ScanSys( strGetData, _T("MIN ALLOWABLE ="), clsProcessINI.m_sProcessPowerMeasure.dMinAllowable ) )
			continue;

		// Max Allowable
		if( ScanSys( strGetData, _T("MAX ALLOWABLE ="), clsProcessINI.m_sProcessPowerMeasure.dMaxAllowable ) )
			continue;

		// Head
		if( ScanSys( strGetData, _T("HEAD ="), clsProcessINI.m_sProcessPowerMeasure.nHead ) )
			continue;

		// Measure Mode
//		if( ScanSys( strGetData, _T("MEASURE MODE ="), clsProcessINI.m_sProcessPowerMeasure.nMeasureMode ) )
//			continue;

		// 1st Height
		if( ScanSys( strGetData, _T("1ST HEIGHT ="), clsProcessINI.m_sProcessPowerMeasure.d1stHeight ) )
			continue;

		// 2nd Height
		if( ScanSys( strGetData, _T("2ND HEIGHT ="), clsProcessINI.m_sProcessPowerMeasure.d2ndHeight ) )
			continue;

		// Long Term Check Total Time
		if( ScanSys( strGetData, _T("LONG TERM CHECK TOTAL TIME ="), clsProcessINI.m_sProcessPowerMeasure.nLongTermTotalTime ) )
			continue;

		// Long Term Check Period
		if( ScanSys( strGetData, _T("LONG TERM CHECK PERIOD ="), clsProcessINI.m_sProcessPowerMeasure.nLongTermPeriod ) )
			continue;

		// Long Term Dummy On Time
		if( ScanSys( strGetData, _T("LONG TERM DUMMY ON TIME ="), clsProcessINI.m_sProcessPowerMeasure.nLongTermDummyOnTime ) )
			continue;

		// Frquency
		if( ScanSys( strGetData, _T("FREQUENCY ="), clsProcessINI.m_sProcessPowerMeasure.nFrequency ) )
			continue;

		// PulseWidth
		if( ScanSys( strGetData, _T("PULSE WIDTH ="), clsProcessINI.m_sProcessPowerMeasure.dPulseWidth ) )
			continue;

		// Mask
		if( ScanSys( strGetData, _T("MASK ="), clsProcessINI.m_sProcessPowerMeasure.nMask ) )
			continue;
		
		// Tophat
		if( ScanSys( strGetData, _T("TOPHAT ="), clsProcessINI.m_sProcessPowerMeasure.bTophat ) )
			continue;

		// Compensation mode
		if( ScanSys( strGetData, _T("COMPENSATION ="), clsProcessINI.m_sProcessPowerMeasure.bCompensation ) )
			continue;

		// Long Term Check mode
		if( ScanSys( strGetData, _T("LONGTERMCHECK ="), clsProcessINI.m_sProcessPowerMeasure.bLongTermCheck ) )
			continue;
		
		// Attenuator 1
		if( ScanSys( strGetData, _T("ATTEN1 ="), clsProcessINI.m_sProcessPowerMeasure.dAttenuator1 ) )
			continue;

		// Attenuator 2
		if( ScanSys( strGetData, _T("ATTEN2 ="), clsProcessINI.m_sProcessPowerMeasure.dAttenuator2 ) )
			continue;

		for(int i=0; i<25; i++)
		{
			strTarget.Format(_T("1ST POWER #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if(ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessPowerMeasure.b1stPower[i] ))
				sFile.ReadString(strGetData);
			
			strTarget.Format(_T("2ND POWER #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsProcessINI.m_sProcessPowerMeasure.b2ndPower[i] ) )
				sFile.ReadString(strGetData);
		}

		// Last Measure Time
		if( ScanSys( strGetData, _T("MEASURE TIME ="), clsProcessINI.m_sProcessPowerMeasure.nMeasureTime ) )
			continue;

		// Measure Wait Time
		if( ScanSys( strGetData, _T("MEASURE WAIT TIME ="), clsProcessINI.m_sProcessPowerMeasure.nMeasureWaitTime ) )
			continue;

		// AOM delay
		if( ScanSys( strGetData, _T("AOM DELAY ="), clsProcessINI.m_sProcessPowerMeasure.dAOMDelay ) )
			continue;

		// AOM duty
		if( ScanSys( strGetData, _T("AOM DUTY ="), clsProcessINI.m_sProcessPowerMeasure.dAOMDuty ) )
			continue;

		// AOM profile file
		if( ScanSys( strGetData, _T("AOM FILE ="), strAOM))
		{
			memcpy(clsProcessINI.m_sProcessPowerMeasure.cAOMFilePath, strAOM, strAOM.GetLength() + 1 );
			continue;
		}
		
		//Power Compensation Target
		if( ScanSys( strGetData, _T("TARGET ="), clsProcessINI.m_sProcessPowerMeasure.dCompensationTarget) )
			continue;

		//Powr Compensation Tolerance
		if( ScanSys( strGetData, _T("DUTY LIMIT ="), clsProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent ) )
			continue;
	
		//Power Compensation Limit Count 
		if( ScanSys( strGetData, _T("LIMIT COUNT ="), clsProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount) )
			continue;
		
		if( ScanSys( strGetData, _T("DUTY PER WATT ="), clsProcessINI.m_sProcessPowerMeasure.dCompensationDutyPerWatt) )
			continue;
		
		//Power Compensation Step Val 
		if( ScanSys( strGetData, _T("POWER STEP VAL ="), clsProcessINI.m_sProcessPowerMeasure.dPowerStep) )
			continue;

		//Power Compensation Spec Percent
		if( ScanSys( strGetData, _T("POWER SPEC PERCENT ="), clsProcessINI.m_sProcessPowerMeasure.nCompensationPowerSpecPercent) )
			continue;

		//Power Compensation Wait Limit 
		if( ScanSys( strGetData, _T("POWER WAIT LIMIT ="), clsProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit) )
			continue;
		// Use Tool
		if( ScanSys( strGetData, _T("USE TOOL ="), clsProcessINI.m_sProcessPowerMeasure.nUseTool) )
			continue;

		if( ScanSys( strGetData, _T("PULSE NUM ="), clsProcessINI.m_sProcessPowerMeasure.nPulseNum) )
			continue;
			
		if( 0 == strGetData.CompareNoCase(_T("// END POWER MEASURE SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}

BOOL CProcessINIFile::SaveProcessINIFile(CString strFilePath, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
//		CString strMsg;

//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
//		ErrMessage(strMsg, MB_ICONERROR);

		return bRet;
	}

	CString strSetData;

	strSetData.Format(_T("// START EASYDRILLER PROCESS INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );

	SaveLaserScanner( sFile, clsProcessINI );
	SaveAutoSetting( sFile, clsProcessINI );
	SaveOption( sFile, clsProcessINI );
	SaveSystem( sFile, clsProcessINI );
	SaveFidFind( sFile, clsProcessINI );
	SaveScannerCal( sFile, clsProcessINI );
	SavePowerMeasure( sFile, clsProcessINI );

	strSetData.Format(_T("// END EASYDRILLER PROCESS INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	sFile.Close();
	bRet = TRUE;

	return bRet;
}

BOOL CProcessINIFile::SaveLaserScanner(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START LASER AND SCANNER SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Pen File Path
//	strSetData.Format(_T("PEN PATH NAME = %s\n"), clsProcessINI.m_sProcessLaserScanner.szPenName);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Shot Count
	{
		CString strTotalShot;
		strTotalShot = ::AfxGetApp()->GetProfileString(_T("TOTAL SHOT"), _T("TOTAL SHOT"), _T("0"));
		__int64 nTemp = _atoi64( (LPSTR)(LPCTSTR)strTotalShot );

		if( nTemp >= clsProcessINI.m_sProcessOption.nShotCount )
			clsProcessINI.m_sProcessOption.nShotCount = nTemp;
	}
	strSetData.Format(_T("SHOT COUNT = %I64d\n"), clsProcessINI.m_sProcessOption.nShotCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// XY Order
	strSetData.Format(_T("XY ORDER = %d\n"), clsProcessINI.m_sProcessCal.nXYOrder);
	sFile.WriteString( (LPCTSTR)strSetData );

	// recent 1st cal time
	strSetData.Format(_T("1ST CAL TIME = %d\n"), clsProcessINI.m_sProcessCal.n1stCalTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// recent 2nd cal time
	strSetData.Format(_T("2ND CAL TIME = %d\n"), clsProcessINI.m_sProcessCal.n2ndCalTime);
	sFile.WriteString( (LPCTSTR)strSetData );



	// Preheat SpeedZ1Z2
//	strSetData.Format(_T("PREHEAT Z1Z2 = %d\n"), clsProcessINI.m_sProcessOption.nPreheatSpeedZ1Z2);
//	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END LASER AND SCANNER SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CProcessINIFile::SaveAutoSetting(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START AUTO SETTING SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Load Position #1 X, Y
	strSetData.Format(_T("LOAD POSITION'1 X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoadPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOAD POSITION'1 Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoadPosY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Load Position #2 X, Y
	strSetData.Format(_T("LOAD POSITION'2 X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoadPosX2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOAD POSITION'2 Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoadPosY2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Loader Carrier Position
	strSetData.Format(_T("LOADER CARRIER CART POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderCartPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER CARRIER CART POSITION 2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderCartPos2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER CARRIER LOAD POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderLoadPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER CARRIER LOAD POSITION 2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderLoadPos2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER CARRIER ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderAlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Unload Position X, Y
	strSetData.Format(_T("UNLOAD POSITION X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloadPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOAD POSITION Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloadPosY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOAD POSITION X2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloadPosX2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOAD POSITION Y2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloadPosY2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Table Unclamp Limit
	strSetData.Format(_T("UNCLAMP LIMIT Y POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnclampLimitY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// DustSuction Table Min Limit
	strSetData.Format(_T("DUSTSUCTION TABLE MIN LIMIT = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dDustSuctionMin);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// DustSuction Table Max Limit
	strSetData.Format(_T("DUSTSUCTION TABLE MAX LIMIT = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dDustSuctionMax);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Unloader Carrier Position
	strSetData.Format(_T("UNLOADER CARRIER CART POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderCartPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER CARRIER UNLOAD POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderUnloadPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER CARRIER UNLOAD POSITION 2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderUnloadPos2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER CARRIER ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderAlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Loader Picker Position
	strSetData.Format(_T("LOADER PICKER1 UP POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1UpPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER1 ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1AlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER1 TABLE POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker1TablePos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER2 UP POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2UpPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER2 ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2AlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER2 TABLE POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2TablePos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOADER PICKER2 CART POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dLoaderPicker2CartPos);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Unloader Picker Position
	strSetData.Format(_T("UNLOADER PICKER1 UP POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1UpPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER1 ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1AlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER1 TABLE POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1TablePos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER1 CART POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker1CartPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER2 UP POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2UpPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER2 ALIGN POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2AlignPos);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("UNLOADER PICKER2 TABLE POSITION = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dUnloaderPicker2TablePos);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	

	// Fiducial Standby Position X, Y
//	strSetData.Format(_T("FIDUCIAL STANDBY POSITION X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dFiducialX);
//	sFile.WriteString( (LPCTSTR)strSetData );
//	strSetData.Format(_T("FIDUCIAL STANDBY POSITION Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dFiducialY);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Table Offset
//	strSetData.Format(_T("TABLE OFFSET X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTableOffsetX);
//	sFile.WriteString( (LPCTSTR)strSetData );
//	strSetData.Format(_T("TABLE OFFSET Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTableOffsetY);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Height Sensor
	strSetData.Format(_T("HS 1 MANUAL X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 MANUAL Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 AUTO X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 AUTO Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 OFFSET X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 OFFSET Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dOffsetY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 HEAD Z = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 1 BASE Z = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Height Sensor
	strSetData.Format(_T("HS 2 MANUAL X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 MANUAL Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 AUTO X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 AUTO Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 OFFSET X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 OFFSET Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dOffsetY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 HEAD Z = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HS 2 BASE Z = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Powermeter Position X, Y
	strSetData.Format(_T("PM 1 POS X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("PM 1 POS Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Powermeter Position X, Y
	strSetData.Format(_T("PM 2 POS X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("PM 2 POS Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// TC Lens Cleaning Position
	strSetData.Format(_T("TC CLEAN POS X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TC CLEAN POS Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TC CLEAN POS Z1 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosZ1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TC CLEAN POS Z2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dTCCleanPosZ2);
	sFile.WriteString( (LPCTSTR)strSetData );

/*
	for(int i = 0 ; i < MOTOR_MASK_MAX ; i++ )
	{
		strSetData.Format(_T("MASK POS 1 = %.2f\n"), clsProcessINI.m_sProcessAutoSetting.dMaskPosition[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}
*/
	
	strSetData.Format(_T("// END AUTO SETTING SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CProcessINIFile::SaveOption(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START OPTION SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Tolerance X
	strSetData.Format(_T("1ST TOLERANCE X = %d\n"), clsProcessINI.m_sProcessCal.n1stToleranceX);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Tolerance Y
	strSetData.Format(_T("1ST TOLERANCE Y = %d\n"), clsProcessINI.m_sProcessCal.n1stToleranceY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Tolerance X
	strSetData.Format(_T("2ND TOLERANCE X = %d\n"), clsProcessINI.m_sProcessCal.n2ndToleranceX);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Tolerance Y
	strSetData.Format(_T("2ND TOLERANCE Y = %d\n"), clsProcessINI.m_sProcessCal.n2ndToleranceY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Tolerance R
	strSetData.Format(_T("1ST TOLERANCE R = %d\n"), clsProcessINI.m_sProcessCal.n1stToleranceR);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Tolerance R
	strSetData.Format(_T("2ND TOLERANCE R = %d\n"), clsProcessINI.m_sProcessCal.n2ndToleranceR);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Post prework minimum count
	strSetData.Format(_T("PREWORK DOING MINIMUM COUNT = %d\n"), clsProcessINI.m_sProcessCal.nPostDoPreworkMinimumCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 1'st Tolerance X
	strSetData.Format(_T("1ST PREWORK TOLERANCE X = %d\n"), clsProcessINI.m_sProcessCal.n1stPreworkToleranceX);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 1'st Tolerance Y
	strSetData.Format(_T("1ST PREWORK TOLERANCE Y = %d\n"), clsProcessINI.m_sProcessCal.n1stPreworkToleranceY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 2'nd Tolerance X
	strSetData.Format(_T("2ND PREWORK TOLERANCE X = %d\n"), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceX);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 2'nd Tolerance Y
	strSetData.Format(_T("2ND PREWORK TOLERANCE Y = %d\n"), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 1'st Tolerance R
	strSetData.Format(_T("1ST PREWORK TOLERANCE R = %d\n"), clsProcessINI.m_sProcessCal.n1stPreworkToleranceR);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Prework 2'nd Tolerance R
	strSetData.Format(_T("2ND PREWORK TOLERANCE R = %d\n"), clsProcessINI.m_sProcessCal.n2ndPreworkToleranceR);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Calibration Count
	strSetData.Format(_T("AUTO CALIBRATION COUNT = %d\n"), clsProcessINI.m_sProcessCal.nAutoCalibrationCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Calibration Field Count
	strSetData.Format(_T("AUTO CALIBRATION FIELD COUNT = %d\n"), clsProcessINI.m_sProcessCal.nAutoCalibrationFieldCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vision Calibration Field Count
	strSetData.Format(_T("VISION CALIBRATION FIELD COUNT = %d\n"), clsProcessINI.m_sProcessCal.nVisionCalibrationFieldCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Time
	strSetData.Format(_T("ALIGN TIME = %d\n"), clsProcessINI.m_sProcessOption.nAlignTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// LOAD Time
	strSetData.Format(_T("LOAD TIME = %d\n"), clsProcessINI.m_sProcessOption.nLoadTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Time
	strSetData.Format(_T("UNLOAD TIME = %d\n"), clsProcessINI.m_sProcessOption.nUnloadTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Auto Height Tol
	strSetData.Format(_T("PCB HEIGHT AUTO TOL = %.3f\n"), clsProcessINI.m_sProcessOption.dPCBHeihtAutoTol);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st PCB Height Min
	strSetData.Format(_T("1ST PCB HEIGHT MIN = %.3f\n"), clsProcessINI.m_sProcessOption.d1stPCBHeightMin);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st PCB Height Max
	strSetData.Format(_T("1ST PCB HEIGHT MAX = %.3f\n"), clsProcessINI.m_sProcessOption.d1stPCBHeightMax);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd PCB Height Min
	strSetData.Format(_T("2ND PCB HEIGHT MIN = %.3f\n"), clsProcessINI.m_sProcessOption.d2ndPCBHeightMin);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd PCB Height Max
	strSetData.Format(_T("2ND PCB HEIGHT MAX = %.3f\n"), clsProcessINI.m_sProcessOption.d2ndPCBHeightMax);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Check Suction Error
	strSetData.Format(_T("CHECK SUCTION ERROR = %d\n"), clsProcessINI.m_sProcessOption.bCheckSuctionError);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Reject Suction off
	strSetData.Format(_T("REJECT SUCTION OFF = %d\n"), clsProcessINI.m_sProcessOption.bRejectSuctionOff);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Valid Time
	strSetData.Format(_T("VALID TIME = %d\n"), clsProcessINI.m_sProcessCal.nValidTime);
	sFile.WriteString( (LPCTSTR)strSetData );
		
	// Use Apply Tolerance
	strSetData.Format(_T("USE APPLY TOLERANCE = %d\n"), clsProcessINI.m_sProcessCal.bUseApplyTolerance);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Skip Board Check
//	strSetData.Format(_T("SKIP BOARD CHECK = %d\n"), clsProcessINI.m_sProcessCal.bSkipBoardCheck);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Valid Measure Time
	strSetData.Format(_T("VALID MEASURE TIME = %d\n"), clsProcessINI.m_sProcessCal.nValidMeasureTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Start Time
	strSetData.Format(_T("ALIGN START TIME = %d\n"), clsProcessINI.m_sProcessOption.nAlignStartPer);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Dual Time
	strSetData.Format(_T("ALIGN DUAL TIME = %d\n"), clsProcessINI.m_sProcessOption.nAlignDualTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Single Time
	strSetData.Format(_T("ALIGN SINGLE TIME = %d\n"), clsProcessINI.m_sProcessOption.nAlignSingleTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Dual Time OnlyPCB
	strSetData.Format(_T("ALIGN DUAL TIME ONLY PCB = %d\n"), clsProcessINI.m_sProcessOption.nAlignDualTimeOnlyPCB);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Align Single Time OnlyPCB
	strSetData.Format(_T("ALIGN SINGLE TIME ONLY PCB = %d\n"), clsProcessINI.m_sProcessOption.nAlignSingleTimeOnlyPCB);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VACUUM MOTOR OFF TIME = %d\n"), clsProcessINI.m_sProcessOption.nVacuumMotorOffTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// CCL Size
	strSetData.Format(_T("FIDUCIAL CCL SIZE = %.2f\n"), clsProcessINI.m_sProcessOption.dCCLSize);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PPG Size
	strSetData.Format(_T("FIDUCIAL PPG SIZE = %.2f\n"), clsProcessINI.m_sProcessOption.dPPGSize);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Verify SIze
	strSetData.Format(_T("FIDUCIAL VERIFY SIZE = %.2f\n"), clsProcessINI.m_sProcessOption.dVerifySize);
	sFile.WriteString( (LPCTSTR)strSetData );


	// Wait Temper down for AGC
	strSetData.Format(_T("WAIT TEMPER DOWN FOR AGC = %d\n"), clsProcessINI.m_sProcessOption.bWaitTemperDownForAGC);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("CAVITY DRAW IN OFFSET = %d\n"), clsProcessINI.m_sProcessOption.nCavityDrawInOffset);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("CAVITY DRAW OUT OFFSET = %d\n"), clsProcessINI.m_sProcessOption.nCavityDrawInOffset);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation Repeat Comp Lot Count
	strSetData.Format(_T("TEMPER COMPEN REPEAT LOT COUNT = %d\n"), clsProcessINI.m_sProcessOption.nTempRepeatCompenLotCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	//
	strSetData.Format(_T("TEMPER COMPEN EVERY STEP = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenEveryPnl);
	sFile.WriteString( (LPCTSTR)strSetData );


	// Temper Compensation verify lot count
	strSetData.Format(_T("TEMPER COMPEN VERIFY LOT COUNT = %d\n"), clsProcessINI.m_sProcessOption.nTempCompenVerifyLotCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("OCR MOVE OFFSET MM = %d\n"), clsProcessINI.m_sProcessOption.nOCRMoveOffset );
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation fire count for vision compensation
	strSetData.Format(_T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation fire count for vision compensation
	strSetData.Format(_T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 2 = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation fire count for vision compensation
	strSetData.Format(_T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 3 = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen3);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation fire count for vision compensation
	strSetData.Format(_T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 4 = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen4);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation fire count for vision compensation
	strSetData.Format(_T("TEMPER COMPEN FIRE COUNT FOR VISION COMPEN 5 = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenFireCountForVisionCompen5);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation mode
	strSetData.Format(_T("TEMPER COMPENSATION MODE = %d\n"), clsProcessINI.m_sProcessOption.bTemperCompensationMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Measure mode
	strSetData.Format(_T("TEMPER MEASURE MODE = %d\n"), clsProcessINI.m_sProcessOption.nTemperMeasureMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Verify mode
	strSetData.Format(_T("TEMPER VERIFY MODE = %d\n"), clsProcessINI.m_sProcessOption.bTemperVerifyMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Verify Low Cam
	strSetData.Format(_T("TEMPER VERIFY LOW CAM = %d\n"), clsProcessINI.m_sProcessOption.bTempVerifyLowCam);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation Grid No
	strSetData.Format(_T("TEMPER COMPENSATION GRID NO = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenGridNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Delta T
	strSetData.Format(_T("TEMPER DELTA T = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperDeltaT);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation Timeout Min
	strSetData.Format(_T("TEMPER COMPENSATION TIMEOUT MIN = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenTimeoutMin);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Compensation Repeat No
	strSetData.Format(_T("TEMPER COMPENSATION REPEAT NO = %d\n"), clsProcessINI.m_sProcessOption.nTemperCompenRepeatNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper 2D Linear Mode
	strSetData.Format(_T("TEMPER 2D LINEAR MODE = %d\n"), clsProcessINI.m_sProcessOption.bTemper2DLinearMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Min T Limit
	strSetData.Format(_T("TEMPER MIN T LIMIT = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperMinTLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Max T Limit
	strSetData.Format(_T("TEMPER MAX T LIMIT = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperMaxTLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper start T
	strSetData.Format(_T("TEMPER END T = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperEndT);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper end T
	strSetData.Format(_T("TEMPER TRANS T = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperTransT);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Temp Differ T Limit
	strSetData.Format(_T("TEMPER DIFFER T LIMIT = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperDifferTLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Delta T Limit
	strSetData.Format(_T("TEMPER DELTA T LIMIT = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperDetaTLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Minus Delta T Limit
	strSetData.Format(_T("TEMPER MINUS DELTA T LIMIT = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperMinusDetaTLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper No Change Time Limit Sec
	strSetData.Format(_T("TEMPER WAIT SCAL SEC = %.2f\n"), clsProcessINI.m_sProcessOption.dTemperTWaitScal);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Temper Detail Log
	strSetData.Format(_T("TEMPER DETAIL LOG = %d\n"), clsProcessINI.m_sProcessOption.bTemperDetailLog);
	sFile.WriteString( (LPCTSTR)strSetData );

	// SBTemper Short Wait Time
	strSetData.Format(_T("SB TEMPER TABLE MOVE WAIT TIME = %d\n"), clsProcessINI.m_sProcessOption.nTableMoveWaitTimeMS);
	sFile.WriteString( (LPCTSTR)strSetData );

	// SBTemper Long Wait Time
	strSetData.Format(_T("SB TEMPER LONG WAIT TIME = %d\n"), clsProcessINI.m_sProcessOption.nSBTemperLongWaitTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Channel Index
	strSetData.Format(_T("TEMPER TCM1 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nTCMasterCH1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER TCM2 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nTCMasterCH2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER TCS1 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nTCSlaveCH1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER TCS2 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nTCSlaveCH2);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("TEMPER SBM1 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nSBMasterCH1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER SBM2 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nSBMasterCH2);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER SBS1 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nSBSlaveCH1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("TEMPER SBS2 CHANNEL NO = %d\n"), clsProcessINI.m_sProcessOption.nSBSlaveCH2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper Start Duty
	strSetData.Format(_T("TEMPER START DUTY = %d\n"), clsProcessINI.m_sProcessOption.nTemperStartDuty);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Temper Step Duty
	strSetData.Format(_T("TEMPER STEP DUTY = %d\n"), clsProcessINI.m_sProcessOption.nTemperStepDuty);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Temper Index Duty
	strSetData.Format(_T("TEMPER POWER COUNT = %d\n"), clsProcessINI.m_sProcessOption.nTemperDutyStepNo);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Temper Start Power
	strSetData.Format(_T("TEMPER START POWER = %d\n"), clsProcessINI.m_sProcessOption.nTemperStartPower);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Temper End Power
	strSetData.Format(_T("TEMPER END POWER = %d\n"), clsProcessINI.m_sProcessOption.nTemperEndPower);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper verify Vision Contrast
	strSetData.Format(_T("TEMPER VERIFY VISION CONTRAST = %.1f\n"), clsProcessINI.m_sProcessOption.dTemperVerifyContrast);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Temper verify Vision Brightness
	strSetData.Format(_T("TEMPER VERIFY VISION BRIGHTNESS = %.1f\n"), clsProcessINI.m_sProcessOption.dTemperVerifyBrightness);
	sFile.WriteString( (LPCTSTR)strSetData );

	// OPC Time Out
	strSetData.Format(_T("SERVER TIME OUT = %d\n"), clsProcessINI.m_sProcessOption.nOPCTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("TABLE INPOS COUNT = %d\n"), clsProcessINI.m_sProcessOption.nTabelInposCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// OPC Log Save Data
	strSetData.Format(_T("OPC LOG SAVE DATA = %d\n"), clsProcessINI.m_sProcessOption.nOpcLogSaveData);
	sFile.WriteString( (LPCTSTR)strSetData );

	// LPC Log Save Data
	strSetData.Format(_T("LPC LOG SAVE DATA = %d\n"), clsProcessINI.m_sProcessOption.nLpcLogSaveData);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Scal absolute time
	strSetData.Format(_T("SCAL ABS TIME = %d\n"), clsProcessINI.m_sProcessCal.nScalAbsTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Scal relative time
	strSetData.Format(_T("SCAL REL TIME = %d\n"), clsProcessINI.m_sProcessCal.nScalRelTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Scal Count time
	strSetData.Format(_T("SCAL COUNT TIME = %d\n"), clsProcessINI.m_sProcessCal.nScalCountTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Scal Count time
	strSetData.Format(_T("SCAL COUNT TIME 2 = %d\n"), clsProcessINI.m_sProcessCal.nScalCountTime2);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCAL COUNT TIME FOR SKIVE = %d\n"), clsProcessINI.m_sProcessCal.nScalCountTimeForSkive);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Power absolute time
	strSetData.Format(_T("POWER ABS TIME = %d\n"), clsProcessINI.m_sProcessCal.nPowerAbsTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Power relative time
	strSetData.Format(_T("POWER REL TIME = %d\n"), clsProcessINI.m_sProcessCal.nPowerRelTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Power Count time
	strSetData.Format(_T("POWER COUNT TIME = %d\n"), clsProcessINI.m_sProcessCal.nPowerCountTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Preheat absolute time
	strSetData.Format(_T("PREHEAT ABS TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatAbsTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Preheat relative time
	strSetData.Format(_T("PREHEAT REL TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatRelTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Preheat Count time
	strSetData.Format(_T("PREHEAT COUNT TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatCountTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Scal method
	strSetData.Format(_T("PREWORK USE COUNT UNIT = %d\n"), clsProcessINI.m_sProcessCal.bUsePNLCountUnit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Scal method
	strSetData.Format(_T("SCAL METHOD = %d\n"), clsProcessINI.m_sProcessCal.nScalMethod);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Power method
	strSetData.Format(_T("POWER METHOD = %d\n"), clsProcessINI.m_sProcessCal.nPowerMethod);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Preheat method
	strSetData.Format(_T("PREHEAT METHOD = %d\n"), clsProcessINI.m_sProcessCal.nPreheatMethod);
	sFile.WriteString( (LPCTSTR)strSetData );
/*
	// Scal time
	strSetData.Format(_T("SCAL START TIME = %d\n"), clsProcessINI.m_sProcessCal.nStartScalTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Power time
	strSetData.Format(_T("POWER START TIME = %d\n"), clsProcessINI.m_sProcessCal.nStartPowerTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Preheat time
	strSetData.Format(_T("PREHEAT START TIME = %d\n"), clsProcessINI.m_sProcessCal.nStartPreheatTime);
	sFile.WriteString( (LPCTSTR)strSetData );
*/
	// Preheat Modulation Time
	strSetData.Format(_T("PREHEAT MODULATION TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatModulationTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Preheat Time
	strSetData.Format(_T("PREHEAT TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AutoRun Preheat Time
	strSetData.Format(_T("AUTORUN PREHEAT TIME = %d\n"), clsProcessINI.m_sProcessCal.nAutoRunPreheatTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// recent Preheat time
	strSetData.Format(_T("PREHEAT END TIME = %d\n"), clsProcessINI.m_sProcessCal.nPreheatEndTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Preheat SpeedXY
	strSetData.Format(_T("PREHEAT XY = %d\n"), clsProcessINI.m_sProcessCal.nPreheatSpeedXY);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Preheat Frequency
	strSetData.Format(_T("PREHEAT FREQUENCY = %d\n"), clsProcessINI.m_sProcessCal.nPreheatFreq);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AutoRun Preheat Frequency
	strSetData.Format(_T("AUTORUN PREHEAT FREQUENCY = %d\n"), clsProcessINI.m_sProcessCal.nAutoRunPreheatFreq);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("AUTORUN PREHEAT JUMPDELAY = %d\n"), clsProcessINI.m_sProcessCal.nAutoRunPreheatJumpDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Preheat Duty
	strSetData.Format(_T("PREHEAT DUTY = %.2f\n"), clsProcessINI.m_sProcessCal.dPreheatDuty);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AutoRun Preheat Duty
	strSetData.Format(_T("AUTORUN PREHEAT DUTY = %.2f\n"), clsProcessINI.m_sProcessCal.dAutoRunPreheatDuty);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Drill End Time
	strSetData.Format(_T("DRILL END TIME = %d\n"), clsProcessINI.m_sProcessCal.nDrillEndTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("DUTY LIMIT2 = %.2f\n"), clsProcessINI.m_sProcessOption.dDutyLimit);
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("CHECK LPC ERROR = %d\n"), clsProcessINI.m_sProcessOption.bCheckLPCError);
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("LPC LOG SAVE DATE = %d\n"), clsProcessINI.m_sProcessOption.nLPCLogsaveDate);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LPC ERROR COUNT = %d\n"), clsProcessINI.m_sProcessOption.nLPCErrorCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LOG LPC DETAIL = %d\n"), clsProcessINI.m_sProcessOption.bLPCLogDetail);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE POWER LOT END = %d\n"), clsProcessINI.m_sProcessCal.bPowerEndLot);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PREWORK USE POWER COMPENSATION MODE = %d\n"), clsProcessINI.m_sProcessCal.bUsePowerCompensationMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("IDLE BEAMPATH = %d\n"), clsProcessINI.m_sProcessCal.nIdleBeamPath);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION CAL MODE = %d\n"), clsProcessINI.m_sProcessCal.nVisionCalMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MARKING DUAL MODE = %d\n"), clsProcessINI.m_sProcessOption.bMarkingDualMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SLAVE MEASURE START = %d\n"), clsProcessINI.m_sProcessOption.bSlaveMeasureStart);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE FULL SCHEDULING = %d\n"), clsProcessINI.m_sProcessOption.bFullScheduling);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NO USE TOPHAT = %d\n"), clsProcessINI.m_sProcessOption.bNoUseTopHat);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("WATER FLOW LASER = %.2f\n"), clsProcessINI.m_sProcessOption.dWaterFlowLaser);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("WATER FLOW AOM = %.2f\n"), clsProcessINI.m_sProcessOption.dWaterFlowAom);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("WATER FLOW SCANNER1 = %.2f\n"), clsProcessINI.m_sProcessOption.dWaterFlowScanner1);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("WATER FLOW SCANNER2 = %.2f\n"), clsProcessINI.m_sProcessOption.dWaterFlowScanner2);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("WATER FLOW ERROR CHECK = %d\n"), clsProcessINI.m_sProcessOption.bWaterFlowErrorCheck);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FIELD FIRE TIME LIMIT = %d\n"), clsProcessINI.m_sProcessOption.nFieldFireTimeLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LOG COPY TIME = %d\n"), clsProcessINI.m_sProcessOption.nLogCopyTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("// END OPTION SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CProcessINIFile::SaveSystem(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START SYSTEM SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Loader Unloader Cart Lock
	strSetData.Format(_T("LOADER UNLOADER CART LOCK = %d\n"), clsProcessINI.m_sProcessSystem.bLoaderUnloaderCartLock);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Dry Run
	strSetData.Format(_T("DRY RUN = %d\n"), clsProcessINI.m_sProcessSystem.bDryRun);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Loader Unloader
	strSetData.Format(_T("NO USE LOADER UNLOADER = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseLoaderUnloader);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Loader Unloader Door Lock
	strSetData.Format(_T("LOADER UNLOADER DOOR LOCK = %d\n"), clsProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Show Scanner Path
	strSetData.Format(_T("SHOW SCANNER PATH = %d\n"), clsProcessINI.m_sProcessSystem.bShowScannerPath);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Suction
	strSetData.Format(_T("NO USE SUCTION = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseSuction);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE PRE LPR LIMIT = %d\n"), clsProcessINI.m_sProcessSystem.bUsePreLPRLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Fiducial Find
	strSetData.Format(_T("NO USE FIDUCIAL FIND = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseFiducialFind);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Scanner
	strSetData.Format(_T("NO USE SCANNER = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseScanner);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Dust Suction
	strSetData.Format(_T("NO USE DUST SUCTION = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseDustSuction);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Sort Area
	strSetData.Format(_T("NO SORT AREA = %d\n"), clsProcessINI.m_sProcessSystem.bNoSortArea);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("AREA SORT MODE = %d\n"), clsProcessINI.m_sProcessSystem.nAreaSortMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Sort Area Y Ratio
	strSetData.Format(_T("SORT AREA Y RATIO = %.1f\n"), clsProcessINI.m_sProcessSystem.dSortAreaYRatio);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Recipe Sort
	strSetData.Format(_T("RECIPE HOLE SORT = %d\n"), clsProcessINI.m_sProcessSystem.bRecipeHoleSort);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Sort Hole
	strSetData.Format(_T("NO SORT HOLE = %d\n"), clsProcessINI.m_sProcessSystem.nNoSortHole);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Hole Sort Pitch
	strSetData.Format(_T("HOLE SORT PITCH = %d\n"), clsProcessINI.m_sProcessSystem.nHoleSortPitch);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Hole Distance Pitch
	strSetData.Format(_T("HOLE DISTANCE PITCH = %d\n"), clsProcessINI.m_sProcessSystem.nHoleDistancePitch);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Sort Line 
	strSetData.Format(_T("NO SORT LINE = %d\n"), clsProcessINI.m_sProcessSystem.bNoSortLine);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Divide Unit
	strSetData.Format(_T("NO DIVIDE UNIT = %d\n"), clsProcessINI.m_sProcessSystem.bNoDivideUnit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Manual Fiducial Set
	strSetData.Format(_T("USE MANUAL FID = %d\n"), clsProcessINI.m_sProcessSystem.bUseManualFidSet);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use AOM Alarm	//2011526
	strSetData.Format(_T("NO USE AOM ALARM = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseAOMAlarm);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NO USE Z CAL = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseZCal);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NO USE LASER CAL = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseLaserCal);
	sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("NO USE T CAL = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseTCal);
	sFile.WriteString( (LPCTSTR)strSetData );
		// No Use chiller Alarm	//2011526
	strSetData.Format(_T("NO USE CHILLER ALARM = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseChillerAlarm);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use PowerCheck
	strSetData.Format(_T("NO USE POWERCHECK = %d\n"), clsProcessINI.m_sProcessSystem.bNoUsePowerCheck);
	sFile.WriteString( (LPCTSTR)strSetData ); 

	//Field Minimum Divide
//	strSetData.Format(_T("USE FIELD MINIMUM DIVIDE = %d\n"), clsProcessINI.m_sProcessSystem.bFieldMinimumDivide);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Roll Up/Down
	strSetData.Format(_T("NO USE ROLL UPDOWN = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseRollUpDown);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Paper
	strSetData.Format(_T("NO USE PAPER = %d\n"), clsProcessINI.m_sProcessSystem.bNoUsePaper);
	sFile.WriteString( (LPCTSTR)strSetData );

	//No Use Prework
	strSetData.Format(_T("NO USE PREWORK = %d\n"), clsProcessINI.m_sProcessSystem.bNoUsePrework);
	sFile.WriteString( (LPCTSTR)strSetData );

	//No Use change view
	strSetData.Format(_T("NO USE CHANGE VIEW = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseChangeView);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Apply Scal
	strSetData.Format(_T("NO USE APPLY SCAL = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseApplyScal);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Check Prework Data
	strSetData.Format(_T("CHECK PREWORK DATA = %d\n"), clsProcessINI.m_sProcessSystem.bCheckPreworkData);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Get Use Offset
	strSetData.Format(_T("USE HIGH CAM OFFSET = %d\n"), clsProcessINI.m_sProcessSystem.bUseGetHighCamOffset);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE 4WAY SCAL = %d\n"), clsProcessINI.m_sProcessSystem.bUse4WayScalMain);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE PATTERN DEVIDE = %d\n"), clsProcessINI.m_sProcessSystem.bUsePatternDevide);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE APPLY SCAL TO EOCARD = %d\n"), clsProcessINI.m_sProcessSystem.bUseApplyScalToEocard);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE SHOT SCALE = %d\n"), clsProcessINI.m_sProcessSystem.bUseShotScale);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE 1POINT VISION COMPEN = %d\n"), clsProcessINI.m_sProcessSystem.bUse1PointVisionCompen);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE AUTO PREHEAT = %d\n"), clsProcessINI.m_sProcessSystem.bUseAutoPreHeat);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE SPARE1 = %d\n"), clsProcessINI.m_sProcessSystem.bUseSpare1);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("USE AUTO MONITORING = %d\n"), clsProcessINI.m_sProcessSystem.bUseAutoMonitoring);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE SHEET SUCTION = %d\n"), clsProcessINI.m_sProcessSystem.bUseSheetSuction);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Text Marking
	strSetData.Format(_T("USE TEXT MARKING = %d\n"), clsProcessINI.m_sProcessSystem.bUseTextMarking);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Save Fid Image
	strSetData.Format(_T("USE SAVE FID IMAGE = %d\n"), clsProcessINI.m_sProcessSystem.bUseSaveFidImage);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Find Second Fid
	strSetData.Format(_T("USE FIND SECOND FID = %d\n"), clsProcessINI.m_sProcessSystem.bUseFindSecondFid);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Every Panel Thickness Measurement
	strSetData.Format(_T("EVERY PANEL THICKNESS = %d\n"), clsProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("EVERY PANEL CHECK HEADOFFSET = %d\n"), clsProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE AI MODE = %d\n"), clsProcessINI.m_sProcessSystem.bUseAIMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE NEW PARAMETER3 = %d\n"), clsProcessINI.m_sProcessSystem.bUseNewParameter3);
	sFile.WriteString( (LPCTSTR)strSetData );



	strSetData.Format(_T("USE SPEED UP = %d\n"), clsProcessINI.m_sProcessSystem.bUseSpeedUp);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE ALL FID FIND = %d\n"), clsProcessINI.m_sProcessSystem.bUseAllFidFind);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE DETAIL LOG = %d\n"), clsProcessINI.m_sProcessSystem.bUseDetailLog);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE NEW BARCODE CONTENTS = %d\n"), clsProcessINI.m_sProcessSystem.bUseNewBarcodeContents);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE ALL TOOL SCAL = %d\n"), clsProcessINI.m_sProcessSystem.bUseAllToolScal);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE ALL TOOL POWER = %d\n"), clsProcessINI.m_sProcessSystem.bUseAllToolPower);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE ORIGIN INSPECTION MODE = %d\n"), clsProcessINI.m_sProcessSystem.bUseOriginalInspectionMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE 1ST PANEL STOP = %d\n"), clsProcessINI.m_sProcessSystem.bUse1stPanelStop);
	sFile.WriteString( (LPCTSTR)strSetData );

	// No Use Melsec Interface
	strSetData.Format("NO USE MELSEC INTERFACE = %d\n", clsProcessINI.m_sProcessSystem.bNoUseMelsecInterface);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE SCHEDULE = %d\n"), clsProcessINI.m_sProcessSystem.bUseScheduling);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("HOLE COUNT CHECK = %d\n"), clsProcessINI.m_sProcessSystem.bCheckHoleCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LASER ERROR CHECK = %d\n"), clsProcessINI.m_sProcessSystem.bLaserErrorCheck);
	sFile.WriteString( (LPCTSTR)strSetData );
	 
	strSetData.Format(_T("SHOW ALL FID IMAGE = %d\n"), clsProcessINI.m_sProcessSystem.bShowAllFidImage);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FAIL FIND FID CONTINUE = %d\n"), clsProcessINI.m_sProcessSystem.bFailFidCountinue);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE OPEN TOOL = %d\n"), clsProcessINI.m_sProcessSystem.bUseOpenTool);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NO USE NGBOX = %d\n"), clsProcessINI.m_sProcessSystem.bNoUseNGBox);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE TURN PANEL = %d\n"), clsProcessINI.m_sProcessSystem.bUseTurnPanel);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("DRY RUN NO PCB = %d\n"), clsProcessINI.m_sProcessSystem.bDryRunNoPCB);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LINE TO SHOT DRILL MODE = %d\n"), clsProcessINI.m_sProcessSystem.bLineToShotFireMode); // 20131028
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LINE TO SHOT SAME LENGTH = %d\n"), clsProcessINI.m_sProcessSystem.bLineToShotSameLength); // 20131028
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PASS MODE = %d\n"), clsProcessINI.m_sProcessSystem.bPassMode);
	sFile.WriteString( (LPCTSTR)strSetData );
	
		strSetData.Format(_T("CHECK VISION SIZE ERROR = %d\n"), clsProcessINI.m_sProcessSystem.bCheckVisionSizeError);
	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		strSetData.Format(_T("%d TOOL HOLE SORT = %d\n"),i, clsProcessINI.m_sProcessSystem.bToolHoleSort[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

	}


	strSetData.Format(_T("// END SYSTEM SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CProcessINIFile::SaveFidFind(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START FIDUCIAL FIND SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Fid Error Before Process
//	strSetData.Format(_T("FIDUCIAL ERROR BEFORE PROCESS = %d\n"), clsProcessINI.m_sProcessFidFind.nFidErrorBeforeProcess);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Remove Fid
//	strSetData.Format(_T("USE REMOVE FIDUCIAL = %d\n"), clsProcessINI.m_sProcessFidFind.bUseRemoveFid);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Remove Fiducial
//	strSetData.Format(_T("REMOVE FIDUCIAL = %d\n"), clsProcessINI.m_sProcessFidFind.nRemoveFid);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Vision Count
//	strSetData.Format(_T("FIDUCIAL VISION COUNT = %d\n"), clsProcessINI.m_sProcessFidFind.nFidVisionCount);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Find Method 1
	strSetData.Format(_T("FIDUCIAL FIND METHOD 1 = %d\n"), clsProcessINI.m_sProcessFidFind.nFidFindMethod[0]);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Find Method 2
	strSetData.Format(_T("FIDUCIAL FIND METHOD 2 = %d\n"), clsProcessINI.m_sProcessFidFind.nFidFindMethod[1]);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Total Retrial
	strSetData.Format(_T("FIDUCIAL TOTAL RETRIAL = %d\n"), clsProcessINI.m_sProcessFidFind.nFidTotalRetrial);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Angle Limit
	strSetData.Format(_T("FIDUCIAL ANGLE LIMIT = %.1f\n"), clsProcessINI.m_sProcessFidFind.dFidAngleLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MULTI FIDUCIAL ORDER = %d\n"), clsProcessINI.m_sProcessFidFind.bMultiFidAscentOrder);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Fiducial Error After Process
//	strSetData.Format(_T("FIDUCIAL ERROR AFTER PROCESS = %d\n"), clsProcessINI.m_sProcessFidFind.nFidErrorAfterProcess);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// PCB Length Tolerance
	strSetData.Format(_T("PCB LENGTH TOLERANCE = %.3f\n"), clsProcessINI.m_sProcessFidFind.dPCBLenTolerance);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PCB Length Tolerance
	strSetData.Format(_T("PCB LENGTH TOLERANCE2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dPCBLenTolerance2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PCB Length Tolerance
	strSetData.Format(_T("REF. SCALE = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefScale);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PCB Length Tolerance
	strSetData.Format(_T("REF. LENGTH TOLERANCE RUN LIMIT = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefLengthTol);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("REF. LENGTH TOLERANCE2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefLengthTol2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AUTO fiducial Tolerance
//	strSetData.Format(_T("AUTO FIDUCIAL TOLERANCE = %d\n"), clsProcessINI.m_sProcessFidFind.bAutoFidTolerance);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto fiducial recheck
	strSetData.Format(_T("FIDUCIAL RECHECK = %d\n"), clsProcessINI.m_sProcessFidFind.bAutoFidRecheck);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Recheck Tolerance
	strSetData.Format(_T("RECHECK TOLERANCE = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRecheckTolerance);
	sFile.WriteString( (LPCTSTR)strSetData );

	// user can run when scale limit over
	strSetData.Format(_T("OPER CAN RUN FOR SCALE OVER = %d\n"), clsProcessINI.m_sProcessFidFind.bOperatorCanRunForScaleOver);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("OPER CAN RUN TOL = %.3f\n"), clsProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Move Low Vision X
	strSetData.Format(_T("MOVE LOW VISION X = %.3f\n"), clsProcessINI.m_sProcessFidFind.dMoveLowVision.x);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Move Low Vision Y
	strSetData.Format(_T("MOVE LOW VISION Y = %.3f\n"), clsProcessINI.m_sProcessFidFind.dMoveLowVision.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Move High Vision X
	strSetData.Format(_T("MOVE HIGH VISION X = %.3f\n"), clsProcessINI.m_sProcessFidFind.dMoveHighVision.x);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Move High Vision Y
	strSetData.Format(_T("MOVE HIGH VISION Y = %.3f\n"), clsProcessINI.m_sProcessFidFind.dMoveHighVision.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// ref pos x 
	strSetData.Format(_T("REF FID POS X = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// ref pos y
	strSetData.Format(_T("REF FID POS Y = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosY);
	sFile.WriteString( (LPCTSTR)strSetData );

	// ref pos x2 
	strSetData.Format(_T("REF FID POS X2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosX2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// ref pos y2
	strSetData.Format(_T("REF FID POS Y2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosY2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// ref pos x3 
	strSetData.Format(_T("REF FID POS X3 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosX3);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// ref pos y3
	strSetData.Format(_T("REF FID POS Y3 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dRefPosY3);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Near Pos X
	strSetData.Format(_T("NEAR FID POS X = %.3f\n"), clsProcessINI.m_sProcessFidFind.dNearPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Near Pos Y
	strSetData.Format(_T("NEAR FID POS Y = %.3f\n"), clsProcessINI.m_sProcessFidFind.dNearPosY);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Near Pos X2
	strSetData.Format(_T("NEAR FID POS X2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dNearPosX2);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Near Pos Y2
	strSetData.Format(_T("NEAR FID POS Y2 = %.3f\n"), clsProcessINI.m_sProcessFidFind.dNearPosY2);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Accept Size 
	strSetData.Format(_T("ACCEPT SIZE = %d\n"), clsProcessINI.m_sProcessFidFind.nAcceptRatio);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Accept Ratio
	strSetData.Format(_T("ACCEPT RATIO = %d\n"), clsProcessINI.m_sProcessFidFind.nAcceptRatio);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE ALL FID CONTROL = %d\n"), clsProcessINI.m_sProcessFidFind.bUseAllControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("HOLE PRE LIMIT = %d\n"), clsProcessINI.m_sProcessFidFind.nHolePreLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("HOLE POST LIMIT = %d\n"), clsProcessINI.m_sProcessFidFind.nHolePostLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCALE MINUS LIMIT = %.3f\n"), clsProcessINI.m_sProcessFidFind.dScaleMinusLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCALE PLUS LIMIT = %.3f\n"), clsProcessINI.m_sProcessFidFind.dScalePlusLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("DIAGNAL SCALE MINUS LIMIT = %.3f\n"), clsProcessINI.m_sProcessFidFind.dDiagonalScaleMinusLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("DIAGNAL SCALE PLUS LIMIT = %.3f\n"), clsProcessINI.m_sProcessFidFind.dDiagonalScalePlusLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i = 0; i <9; i++)
	{
		strSetData.Format(_T("HOLE FIND AREA POS%d = %d\n"), i, clsProcessINI.m_sProcessFidFind.bHoleFindAreaPos[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}
	for(int k = 0; k <9; k++)
	{
		strSetData.Format(_T("HOLE FIND HOLE POS%d = %d\n"), k, clsProcessINI.m_sProcessFidFind.bHoleFindHolePos[k]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}
	// Fid Save Data
	strSetData.Format(_T("FID IMG SAVE DATE = %d\n"), clsProcessINI.m_sProcessFidFind.nFidImgSaveData);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Log Save Data
	strSetData.Format(_T("LOG SAVE DATE = %d\n"), clsProcessINI.m_sProcessFidFind.nLogSaveData);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PROPORTION COMPENSATION = %d\n"), clsProcessINI.m_sProcessFidFind.bUseProportionCompensation);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vision Accept Score
	strSetData.Format(_T("VISION ACCEPT SCORE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dAcceptScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION ROTATE HOLE ACCEPT SCORE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION EDGE HOLE ACCEPT SCORE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION RESULT SCORE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dResultScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION EXPOSURE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dExposure);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FID FIND VISION EXPOSURE = %.2f\n"), clsProcessINI.m_sProcessFidFind.dFidFindExposure);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END FIDUCIAL FIND SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CProcessINIFile::SaveScannerCal(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	CString strTemp;
	
	strSetData.Format(_T("// START SCANNER CAL SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Auto Division
	strSetData.Format(_T("AUTO DIVISION = %d\n"), clsProcessINI.m_sProcessScannerCal.nAutoDivision);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Mask
	strSetData.Format(_T("AUTO MASK = %d\n"), clsProcessINI.m_sProcessScannerCal.nAutoMask);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Head
	strSetData.Format(_T("AUTO HEAD = %d\n"), clsProcessINI.m_sProcessScannerCal.nAutoHead);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Pulse Width
	strSetData.Format(_T("AUTO PULSE WIDTH = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAutoPulseWidth);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto 1st Thickness
	strSetData.Format(_T("AUTO 1ST THICKNESS = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAuto1stThickness);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto 2nd Thickness
	strSetData.Format(_T("AUTO 2ND THICKNESS = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAuto2ndThickness);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Start X
	strSetData.Format(_T("AUTO START X = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAutoStart.x);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Auto Start Y
	strSetData.Format(_T("AUTO START Y = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAutoStart.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Division
	strSetData.Format(_T("MANUAL DIVISION = %d\n"), clsProcessINI.m_sProcessScannerCal.nManualDivision);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Mask
	strSetData.Format(_T("MANUAL MASK = %d\n"), clsProcessINI.m_sProcessScannerCal.nManualMask);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Head
	strSetData.Format(_T("MANUAL HEAD = %d\n"), clsProcessINI.m_sProcessScannerCal.nManualHead);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Pulse Width
	strSetData.Format(_T("MANUAL PULSE WIDTH = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dManualPulseWidth);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual 1st Thickness
	strSetData.Format(_T("MANUAL 1ST THICKNESS = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dManual1stThickness);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual 2nd Thickness
	strSetData.Format(_T("MANUAL 2ND THICKNESS = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dManual2ndThickness);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Start X
	strSetData.Format(_T("MANUAL START X = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dManualStart.x);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Start Y
	strSetData.Format(_T("MANUAL START Y = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dManualStart.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Model Size
	strSetData.Format(_T("MODEL SIZE = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dModelSize);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Model Orientation
	strSetData.Format(_T("MODEL ORIENTATION = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dModelOrientation);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Model Polarity
	strSetData.Format(_T("MODEL POLARITY = %d\n"), clsProcessINI.m_sProcessScannerCal.nModelPolarity);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Size Tolerance
	strSetData.Format(_T("SIZE TOLERANCE = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dSizeTolerance);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Angle Tolerance
	strSetData.Format(_T("ANGLE TOLERANCE = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAngleTolerance);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Aspect Ratio
	strSetData.Format(_T("ASPECT RATIO = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dAspectRatio);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Vision Z Offset
	strSetData.Format(_T("CAL VISION Z OFFSET = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dVisionZOffset);
	sFile.WriteString( (LPCTSTR)strSetData);
	
	for(int i=0; i<4; i++)
	{
		strTemp.Format(_T("COAXIAL #%d"), i+1);
		strSetData.Format(_T("%s = %d\n"), strTemp, clsProcessINI.m_sProcessScannerCal.nCoaxial[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strTemp.Format(_T("IR #%d"), i+1);
		strSetData.Format(_T("%s = %d\n"), strTemp, clsProcessINI.m_sProcessScannerCal.nIR[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strTemp.Format(_T("RING #%d"), i+1);
		strSetData.Format(_T("%s = %d\n"), strTemp, clsProcessINI.m_sProcessScannerCal.nRing[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strTemp.Format(_T("CONTRAST #%d"), i+1);
		strSetData.Format(_T("%s = %.1f\n"), strTemp, clsProcessINI.m_sProcessScannerCal.dContrast[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strTemp.Format(_T("BRIGHTNESS #%d"), i+1);
		strSetData.Format(_T("%s = %.1f\n"), strTemp, clsProcessINI.m_sProcessScannerCal.dBrightness[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	// Count Auto
	strSetData.Format(_T("COUNT AUTO = %d\n"), clsProcessINI.m_sProcessScannerCal.nCountAuto);
	sFile.WriteString( (LPCTSTR)strSetData);

	//Vision Count Auto
	strSetData.Format(_T("VISION COUNT AUTO = %d\n"), clsProcessINI.m_sProcessScannerCal.nVisionCountAuto);
	sFile.WriteString( (LPCTSTR)strSetData);

	strSetData.Format(_T("COUNT CHECK HEAD OFFSET AUTO = %d\n"), clsProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Temp X
	strSetData.Format(_T("SCAN TEMP X = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanXTemp);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Temp Y
	strSetData.Format(_T("SCAN TEMP Y = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanYTemp);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Cal Table pos X Master
	strSetData.Format(_T("MASTER CAL TABLE POS X = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dMasterCalTablePosX);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos Y Master
	strSetData.Format(_T("MASTER CAL TABLE POS Y = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dMasterCalTablePosY);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos X Slave
	strSetData.Format(_T("SLAVE CAL TABLE POS X = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos Y Slave
	strSetData.Format(_T("SLAVE CAL TABLE POS Y = %.3f\n"), clsProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY);
	sFile.WriteString( (LPCTSTR)strSetData);

	// default low scal
	strSetData.Format(_T("DEFAULT LOW CAM = %d\n"), clsProcessINI.m_sProcessScannerCal.bDefaultLow);
	sFile.WriteString( (LPCTSTR)strSetData);

	// default low scal
	strSetData.Format(_T("SCANNER CAL USE DUMMY = %d\n"), clsProcessINI.m_sProcessScannerCal.bUseDummy);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Master X
	strSetData.Format(_T("SCAN MASTER X = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanMasterX);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Master Y
	strSetData.Format(_T("SCAN MASTER Y = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanMasterY);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Slave X
	strSetData.Format(_T("SCAN SLAVE X = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanSlaveX);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Scan Slave Y
	strSetData.Format(_T("SCAN SLAVE Y = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dScanSlaveY);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Max Offset Master X
	strSetData.Format(_T("MAX OFFSET MASTER X = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dMaxOffsetMasterX);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Max Offset Master Y
	strSetData.Format(_T("MAX OFFSET MASTER Y = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dMaxOffsetMasterY);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Max Offset Slave X
	strSetData.Format(_T("MAX OFFSET SLAVE X = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveX);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Max Offset Slave Y
	strSetData.Format(_T("MAX OFFSET SLAVE Y = %.4f\n"), clsProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveY);
	sFile.WriteString( (LPCTSTR)strSetData);
	
	// Cal Table pos X min limit
	strSetData.Format(_T("AUTO CAL TABLE MIN X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos Y min limit
	strSetData.Format(_T("AUTO CAL TABLE MIN Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos X max limit
	strSetData.Format(_T("AUTO CAL TABLE MAX X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX);
	sFile.WriteString( (LPCTSTR)strSetData);
	// Cal Table pos Y max limit
	strSetData.Format(_T("AUTO CAL TABLE MAX Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Table Offset
	strSetData.Format(_T("OPTIC OFFSET MX = %d\n"), clsProcessINI.m_sProcessAutoSetting.nOpticMX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("OPTIC OFFSET SX = %d\n"), clsProcessINI.m_sProcessAutoSetting.nOpticSX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("OPTIC OFFSET MY = %d\n"), clsProcessINI.m_sProcessAutoSetting.nOpticMY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("OPTIC OFFSET SY = %d\n"), clsProcessINI.m_sProcessAutoSetting.nOpticSY);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("IDLE SHOT X = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX );
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("IDLE SHOT Y = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY );
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("IDLE SHOT Z1 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ1 );
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("IDLE SHOT Z2 = %.3f\n"), clsProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ2 );
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("IDLE SHOT BEAMPATH NO = %d\n"), clsProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("IDLE SHOT REPEAT NO = %d\n"), clsProcessINI.m_sProcessAutoSetting.nIdleShotRepeatCount);
	sFile.WriteString( (LPCTSTR)strSetData );
	// JOB FILE
	strSetData.Format(_T("JOB FILE = %s\n"), clsProcessINI.m_sProcessScannerCal.szJobFilePath);
	sFile.WriteString( (LPCTSTR)strSetData);

	// Use Tool
	strSetData.Format(_T("USE TOOL = %d\n"), clsProcessINI.m_sProcessScannerCal.nUseTool );
	sFile.WriteString( (LPCTSTR)strSetData);

	strSetData.Format(_T("// END SCANNER CAL SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	return bRet;
}

BOOL CProcessINIFile::SavePowerMeasure(CStdioFile& sFile, DProcessINI clsProcessINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	CString strTemp;
	
	strSetData.Format(_T("// START POWER MEASURE SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Min Allowable
	strSetData.Format(_T("MIN ALLOWABLE = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dMinAllowable);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Max Allowable
	strSetData.Format(_T("MAX ALLOWABLE = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dMaxAllowable);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Head
	strSetData.Format(_T("HEAD = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nHead);
	sFile.WriteString( (LPCTSTR)strSetData );

	// MeasureMode
//	strSetData.Format(_T("MEASURE MODE = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nMeasureMode);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// 1st Height
	strSetData.Format(_T("1ST HEIGHT = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.d1stHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2nd Height
	strSetData.Format(_T("2ND HEIGHT = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.d2ndHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Long Term Check Total Time
	strSetData.Format(_T("LONG TERM CHECK TOTAL TIME = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nLongTermTotalTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Long Term Check Period
	strSetData.Format(_T("LONG TERM CHECK PERIOD = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nLongTermPeriod);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Long Term Check Period
	strSetData.Format(_T("LONG TERM DUMMY ON TIME = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nLongTermDummyOnTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Frequency
	strSetData.Format(_T("FREQUENCY = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nFrequency);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PulseWidth
	strSetData.Format(_T("PULSE WIDTH = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dPulseWidth);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Mask
	strSetData.Format(_T("MASK = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nMask);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Tophat
	strSetData.Format(_T("TOPHAT = %d\n"), clsProcessINI.m_sProcessPowerMeasure.bTophat);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Compensation
	strSetData.Format(_T("COMPENSATION = %d\n"), clsProcessINI.m_sProcessPowerMeasure.bCompensation);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Long Term Check
	strSetData.Format(_T("LONGTERMCHECK = %d\n"), clsProcessINI.m_sProcessPowerMeasure.bLongTermCheck);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Attenuator 1
	strSetData.Format(_T("ATTEN1 = %d\n"), clsProcessINI.m_sProcessPowerMeasure.dAttenuator1);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Attenuator 2
	strSetData.Format(_T("ATTEN2 = %d\n"), clsProcessINI.m_sProcessPowerMeasure.dAttenuator2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	for(int i=0; i<25; i++)
	{
		strTemp.Format(_T("1ST POWER #%d"), i+1);
		strSetData.Format(_T("%s = %d\n"), strTemp, clsProcessINI.m_sProcessPowerMeasure.b1stPower[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strTemp.Format(_T("2ND POWER #%d"), i+1);
		strSetData.Format(_T("%s = %d\n"), strTemp, clsProcessINI.m_sProcessPowerMeasure.b2ndPower[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	// Measure Time
	strSetData.Format(_T("MEASURE TIME = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nMeasureTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Measure Wait Time
	strSetData.Format(_T("MEASURE WAIT TIME = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nMeasureWaitTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AOM delay
	strSetData.Format(_T("AOM DELAY = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dAOMDelay);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// AOM duty
	strSetData.Format(_T("AOM DUTY = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dAOMDuty);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AOM profile file
	strSetData.Format(_T("AOM FILE =%s\n"), clsProcessINI.m_sProcessPowerMeasure.cAOMFilePath);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Power Compensation Target
	strSetData.Format(_T("TARGET = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dCompensationTarget);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Power Compensation Tolerance 
	strSetData.Format(_T("DUTY LIMIT = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Power Compensation Limit Count 
	strSetData.Format(_T("LIMIT COUNT = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("DUTY PER WATT = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dCompensationDutyPerWatt);
	sFile.WriteString( (LPCTSTR)strSetData );

	
	//Power Compensation Step Val 
	strSetData.Format(_T("POWER STEP VAL = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dPowerStep);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("POWER SPEC PERCENT = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nCompensationPowerSpecPercent);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Power Compensation Step Val 
	strSetData.Format(_T("POWER WAIT LIMIT = %.3f\n"), clsProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Tool
	strSetData.Format(_T("USE TOOL = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nUseTool);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("PULSE NUM = %d\n"), clsProcessINI.m_sProcessPowerMeasure.nPulseNum);
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("// END POWER MEASURE SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	return bRet;
}

void CProcessINIFile::WriteLog(CString strLog)
{
	CString strPathName;
	strPathName.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}