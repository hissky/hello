// ShotTableINIFile.h: interface for the CShotTableINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHOTTABLEINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)
#define AFX_SHOTTABLEINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class DShotTableINI;
class DSystemINI;

class CShotTableINIFile  
{
public:
	CShotTableINIFile();
	virtual ~CShotTableINIFile();

	BOOL	GetOldShotTableData(DShotTableINI& clsShotTableINI, DSystemINI clsSystemINI);
	BOOL	OpenShotTableINIFile(CString strFilePath, DShotTableINI& clsShotTableINI);
	BOOL	ParsingShotTable(CStdioFile& sFile, DShotTableINI& clsShotTableINI);

	
	BOOL	SaveShotTableNIFile(CString strFilePath, DShotTableINI clsShotTableINI);


	
	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_SHOTTABLEINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)
