// DEasyDrillerINI.cpp: implementation of the DEasyDrillerINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DEasyDrillerINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DEasyDrillerINI gEasyDrillerINI;

DEasyDrillerINI::DEasyDrillerINI()
{

}

DEasyDrillerINI::~DEasyDrillerINI()
{

}
