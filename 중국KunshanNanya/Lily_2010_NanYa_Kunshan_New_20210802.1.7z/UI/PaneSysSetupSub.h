#if !defined(AFX_PANESYSSETUPSUB_H__2C42F05B_2F3F_414A_BA1E_24672D60F7B8__INCLUDED_)
#define AFX_PANESYSSETUPSUB_H__2C42F05B_2F3F_414A_BA1E_24672D60F7B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneSysSetupSub : public CFormView
{
protected:
	CPaneSysSetupSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupSub)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupSub)
	enum { IDD = IDD_DLG_SYS_SETUP_SUB };
	UEasyButtonEx	m_btnSystemSetupApply;
	UEasyButtonEx	m_btnBack;

	UEasyButtonEx	m_btnOpenBeampath;
	UEasyButtonEx	m_btnOpenShot;

	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	int m_nBeamDumperNo;
	void ViewApplyButton(int nTabNo);
	void		InitBtnControl();
	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

	void		SetBackButton(BOOL bEnable);

	void SetAuthorityByLevel(int nLevel);
	int				m_nUserLevel;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupSub)
	afx_msg void OnButtonBack();
	afx_msg void OnButtonSystemSetupApply();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonOpenBeampathTable();
	afx_msg void OnBnClickedButtonOpenShotTable();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPSUB_H__2C42F05B_2F3F_414A_BA1E_24672D60F7B8__INCLUDED_)
