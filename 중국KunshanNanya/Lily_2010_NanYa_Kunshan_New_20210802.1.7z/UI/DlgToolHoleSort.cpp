// DlgToolHoleSort.cpp: implementation of the CDlgToolHoleSort class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgToolHoleSort.h"
#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "GridCtrl_src\GridCtrl.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "model\DSystemINI.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "..\MODEL\GlobalVariable.h"
#include "..\alarmmsg.h"
//#include "..\Util\Global.h"
#include "..\model\DProcessINI.h"

#define		USETOPHAT_POSITION	 1 
#define		POLARITY_POSITION	 2
#define		VISION_POSION		 6 


#define		COLOR_BEAMPATH		RGB(255, 255, 162)
#define		COLOR_POWEROFFSET	RGB(243, 255, 72)
#define		COLOR_COMPENSATION	RGB(207, 255, 36)
#define		COLOR_SCANNERFACTS	RGB(255, 202, 108)
#define		COLOR_HOLEFACTS		RGB(180, 255, 255)
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CDlgToolHoleSort, CDialog)


CDlgToolHoleSort::CDlgToolHoleSort(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgToolHoleSort::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgToolHoleSort)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT


	m_bInfoCheck = FALSE;
	m_bBeamPathCheck = FALSE;
	m_bPowerOffsetCheck = FALSE;
	m_bpowerCompensationCheck = FALSE;
	m_bScannerFactCheck = FALSE;



	m_nUserLevel = 0;

	for(int i = 0;i < 6; i++)
	{
		m_bCheckBox[i] = FALSE;
	}
		m_bCheckBox[0] =TRUE;

	m_bClickList = FALSE;		// ����Ʈ�� Ŭ�������� �� 
	m_ClickID = FALSE;			// ����Ʈ�� �ε����� Ŭ�������� �� 
	m_IdNoToAddDel = 0;	

	strTable0[0] = "Tool No";
	strTable0[1] = "Sort Use";

	m_bDelClick = FALSE;
	m_bDeleteAndSaveClick = FALSE;
	m_nRepeatCount = MAX_TOOL_NO -1;
}

CDlgToolHoleSort::~CDlgToolHoleSort()
{

}

void CDlgToolHoleSort::DoDataExchange(CDataExchange* pDX)
{
 	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgToolHoleSort)
	DDX_Control(pDX, IDC_CHECK_BEAMPATH, m_ChkSubBox[1]);
	DDX_Control(pDX, IDC_CHECK_POWER_OFFSET, m_ChkSubBox[2]);
	DDX_Control(pDX, IDC_CHECK_COMPENSATIO, m_ChkSubBox[3]);
	DDX_Control(pDX, IDC_CHECK_SCANNER_FACT, m_ChkSubBox[4]);
	DDX_Control(pDX, IDC_CHECK_HOLE_FACT, m_ChkSubBox[5]);
	DDX_Control(pDX, IDC_BUTTON_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDC_EDIT_BEAMPATH_FIXED_MASK_POS, m_edtFixMask);
	DDX_Control(pDX, IDC_LIST_INFO, m_list);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_DEL, m_btnDel);
	DDX_Control(pDX, IDC_BUTTON_UP, m_btnUp);
	DDX_Control(pDX, IDC_BUTTON_DOWN, m_btnDown);
	if( 0 == gSystemINI.m_sHardWare.nLanguageType ) // English Version
	{
		DDX_GridControl(pDX, IDC_GRID, m_Grid);
	}


	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgToolHoleSort, CDialog)
	//{{AFX_MSG_MAP(CDlgToolHoleSort)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_BEAMPATH, OnCheckBeamPath)
	ON_BN_CLICKED(IDC_CHECK_POWER_OFFSET, OnCheckPowerOffset)
	ON_BN_CLICKED(IDC_CHECK_COMPENSATIO, OnCheckPowerCompensation)
	ON_BN_CLICKED(IDC_CHECK_SCANNER_FACT,OnCheckScannerFact)
	ON_BN_CLICKED(IDC_CHECK_HOLE_FACT,OnCheckHoleFact)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH,OnCheckRefresh)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INFO, OnClickList)
	ON_BN_CLICKED(IDC_BUTTON_ADD,OnCheckAdd)
	ON_BN_CLICKED(IDC_BUTTON_DEL,OnCheckDel)
	ON_BN_CLICKED(IDC_BUTTON_UP,OnCheckUp)
	ON_BN_CLICKED(IDC_BUTTON_DOWN,OnCheckDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_INFO, OnNMCustomdrawListTest)
	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID, OnGridEndEdit)

	ON_NOTIFY(NM_DBLCLK, IDC_GRID, OnGridDblClick)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_SAVE, &CDlgToolHoleSort::OnBnClickedBtnSave)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CDlgToolHoleSort::OnBnClickedBtnCancel)
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamPath message handlers


BOOL CDlgToolHoleSort::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();
	OnCheckRefresh();

	// TODO: Add your specialized code here and/or call the base class	OnCheckRefresh();
	return TRUE;
}


void CDlgToolHoleSort::InitGrid()
{
	
	if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	{
		CRect rt;
		GetDlgItem(IDC_LIST_INFO)->GetWindowRect(rt);// GetWindowRect(rt);
		ScreenToClient(rt);
		m_Grid.Create(rt,this,0xffffff);
	}
	
	m_Grid.SetEditable(TRUE);
    m_Grid.SetListMode(FALSE);
    m_Grid.EnableDragAndDrop(FALSE);
    m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	
	
    m_Grid.SetFixedRowCount(1);        //1���� ��
    m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����
}
void CDlgToolHoleSort::InitBtnControl()
{
	m_fntBtn.CreatePointFont(120, "Arial");
	
	m_ChkSubBox[1].SetFont( &m_fntBtn );
	m_ChkSubBox[1].SetImageOrg( 10, 3 );
	m_ChkSubBox[1].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[1].EnableBallonToolTip();
	m_ChkSubBox[1].SetToolTipText( _T("Beam Path") );
	m_ChkSubBox[1].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[1].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_BEAMPATH );
	
	m_ChkSubBox[2].SetFont( &m_fntBtn );
	m_ChkSubBox[2].SetImageOrg( 10, 3 );
	m_ChkSubBox[2].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[2].EnableBallonToolTip();
	m_ChkSubBox[2].SetToolTipText( _T("Power Offset") );
	m_ChkSubBox[2].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[2].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_POWEROFFSET );
	
	m_ChkSubBox[3].SetFont( &m_fntBtn );
	m_ChkSubBox[3].SetImageOrg( 10, 3 );
	m_ChkSubBox[3].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[3].EnableBallonToolTip();
	m_ChkSubBox[3].SetToolTipText( _T("Power Compensation") );
	m_ChkSubBox[3].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[3].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_COMPENSATION );
	
	m_ChkSubBox[4].SetFont( &m_fntBtn );
	m_ChkSubBox[4].SetImageOrg( 10, 3 );
	m_ChkSubBox[4].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[4].EnableBallonToolTip();
	m_ChkSubBox[4].SetToolTipText( _T("Scanner Facts") );
	m_ChkSubBox[4].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[4].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_SCANNERFACTS );

	m_ChkSubBox[5].SetFont( &m_fntBtn );
	m_ChkSubBox[5].SetImageOrg( 10, 3 );
	m_ChkSubBox[5].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[5].EnableBallonToolTip();
	m_ChkSubBox[5].SetToolTipText( _T("Hole Facts") );
	m_ChkSubBox[5].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[5].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_HOLEFACTS );

	m_btnRefresh.SetFont( &m_fntBtn );
	m_btnRefresh.SetFlat( FALSE );
	m_btnRefresh.EnableBallonToolTip();
	m_btnRefresh.SetToolTipText( _T("Refresh") );
	m_btnRefresh.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRefresh.SetBtnCursor(IDC_HAND_1);


	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Refresh") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	m_btnDel.SetFont( &m_fntBtn );
	m_btnDel.SetFlat( FALSE );
	m_btnDel.EnableBallonToolTip();
	m_btnDel.SetToolTipText( _T("Refresh") );
	m_btnDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDel.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BTN_SAVE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_BTN_CANCEL)->SetFont( &m_fntBtn );

	m_btnUp.SetFont( &m_fntBtn );
	m_btnUp.SetFlat( FALSE );
	m_btnUp.EnableBallonToolTip();
	m_btnUp.SetToolTipText( _T("Refresh") );
	m_btnUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUp.SetBtnCursor(IDC_HAND_1);

	m_btnDown.SetFont( &m_fntBtn );
	m_btnDown.SetFlat( FALSE );
	m_btnDown.EnableBallonToolTip();
	m_btnDown.SetToolTipText( _T("Refresh") );
	m_btnDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDown.SetBtnCursor(IDC_HAND_1);



}
void CDlgToolHoleSort::InitStaticControl()
{

}
void CDlgToolHoleSort::InitEditControl()
{
	m_editwnd.Create(WS_CHILD|ES_NOHIDESEL|ES_AUTOHSCROLL|WS_VISIBLE, CRect(0,0,0,0), this, IDC_EDIT_BOX);
	m_editwnd.SetFont(GetFont(), FALSE);
	m_editwnd.SetMargins(4,4);
	SetWindowLong(m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);

	m_edtFixMask.SetFont( &m_fntEdit );
	m_edtFixMask.SetReceivedFlag( 1 );
	m_edtFixMask.SetWindowText( _T("0") );
}

void CDlgToolHoleSort::OnCheckBeamPath()
{


}

void CDlgToolHoleSort::OnCheckPowerOffset()
{

}

void CDlgToolHoleSort::OnCheckPowerCompensation()
{

}

void CDlgToolHoleSort::OnCheckScannerFact()
{

}

void CDlgToolHoleSort::OnCheckHoleFact()
{
	m_bCheckBox[1] = !m_bCheckBox[1];

	OnCheckRefresh();
}

void CDlgToolHoleSort::OnCheckRefresh()
{
	m_editwnd.ShowWindow(SW_HIDE);

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate(FALSE);
}


void CDlgToolHoleSort::InitListControl() 
{
	for(int i = 1; i< 5; i++)
	{
		if( TRUE == m_bCheckBox[i])
			m_ChkSubBox[i].SetCheck(1);
		else
			m_ChkSubBox[i].SetCheck(0);
	}

	// ����Ʈ ��Ʈ�ѳ� �ѱ� �߰� ��ƾ 
	CFont m_Font;
	m_Font.CreateFont(12, 0,      // Height, Width
		0, 0,      // Escapement, Orientation
		FW_NORMAL, FALSE,              // Weight, Italic
		FALSE, FALSE,                // Underline, StrikeOut
		HANGEUL_CHARSET,                // Character Set
		OUT_DEFAULT_PRECIS,   // OutPrecision
		CLIP_DEFAULT_PRECIS,   // ClipPrecision
		DEFAULT_QUALITY,             // Quality
		DEFAULT_PITCH,               // PitchAndFamily
		"SYSTEM");  
	
	
	m_Font.DeleteObject();
	
	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate();


}

int CDlgToolHoleSort::GetListIndex()		//1: 1���̺� ���, 2: 2���̺� ���, 4: 3�� ���̺� ��� , 8 :4�� ���̺� ���, 16: 5�� ���̺� ��� 
{
	int nCount = 0;

	if(m_bCheckBox[0])
		nCount+=1;

	return nCount;
	
}

int CDlgToolHoleSort::GetListRowIndexCount()
{
	int nRowCount = 0;

	if(m_bCheckBox[0])
		nRowCount += SHOT_PREWORK_TABLE0_COLUMN_COUNT;

	return nRowCount;
}

void CDlgToolHoleSort::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("Tool %d"), ColCount);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		if( m_sProcessSystem.bToolHoleSort[ColCount])
			strData.Format(_T("Sort"));
		else
			strData.Format(_T("No Sort"));
		
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		//Gvitem.iComboType = GVC_SORT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
	}
}



int CDlgToolHoleSort::GetColumnSize(int nStrlen)
{

	if( nStrlen < 3)
		nStrlen = (nStrlen * COLUMNWIDTH) + 25;
	else if(nStrlen < 6 )
		nStrlen *= ( COLUMNWIDTH -2);
	else
		nStrlen = (4 * COLUMNWIDTH) + 25 ;	

	return nStrlen;
}

void CDlgToolHoleSort::InsertListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(SHOT_PREWORK_TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < SHOT_PREWORK_TABLE0_COLUMN_COUNT; i++)  
		{
			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strTable0[i];
			m_Grid.SetItem(&Item);	
			//m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else
	{
		//error
	}
}

void CDlgToolHoleSort::DeleteList()
{
/*	CListCtrl &ctrllist = m_list;
	CHeaderCtrl	*pHeaderCtrl;

	pHeaderCtrl = ctrllist.GetHeaderCtrl();
	int nCount = pHeaderCtrl->GetItemCount();
*/
	m_nColumnCount = 0;
/*
	if( -1 ==nCount)
	{
		ErrMessage(_T("Header Column not exist"));
		return;
	}
	else if( 0 < nCount)
	{
		ctrllist.DeleteAllItems();
		for(int i = 0;i <nCount; i++)
		{
			ctrllist.DeleteColumn(0);
		}
	}
*/
}

void CDlgToolHoleSort::SetDrawMember(int listcount)
{
	int i;

	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount == 3) // 1, 2
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + SHOT_PREWORK_TABLE0_COLUMN_COUNT,TABLE1);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + SHOT_PREWORK_TABLE0_COLUMN_COUNT ,TABLE1, i);
		}
	}


	CRect rect;
	m_Grid.GetWindowRect(&rect);
	int nWidth = 0;
	for(int i = 0; i <m_Grid.GetColumnCount(); i++)
	{
		nWidth += m_Grid.GetColumnWidth(i);
	}

	if(nWidth == 0)
		nWidth = rect.Width();
	m_Grid.SetWindowPos(NULL, 0, 0, nWidth + 20, rect.Height(), SWP_NOMOVE);

	this->GetWindowRect(&rect);
	this->SetWindowPos(NULL, 0, 0, nWidth + 50, rect.Height(), SWP_NOMOVE);

}


void CDlgToolHoleSort::OnClickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;
	
	*pResult = 0;
}

BOOL CDlgToolHoleSort::PreTranslateMessage(MSG* pMsg) 
{
	if(m_Grid.m_bKeyboardOn)
	{
		CCellID cCellId;
		CPoint cpClickedCell;
		CString str;
		int nCol = 0;
		int nRow = 0;
		nCol = m_Grid.GetColumnCount();
		nRow = m_Grid.GetRowCount();
		cCellId = m_Grid.GetEditedCell();

		for(int i = 1; i < nCol; i++)
		{
			cpClickedCell.x = i;
			for(int j = 1; j < nRow; j++)
			{
				cpClickedCell.y = j - 1;
				str = m_Grid.GetItemText(j, i);
				ListUpdate(cpClickedCell, str);
			}
		}
		m_Grid.m_bKeyboardOn = FALSE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CDlgToolHoleSort::MoveFocus(int nXpos, int nYpos, int nMoveType) //nXpos,nypos �̵� ���� �� �����ϰ� ���� 
{
	return TRUE;
}

void CDlgToolHoleSort::OnKillfocusEditGrid()
{
	//EditBox�� �����ش�.
	m_editwnd.ShowWindow(SW_HIDE);
	
	if (m_posClicked.x==-1 || m_posClicked.y==-1) return;
	
	//�ڷ��� ������ ������. ��������.
	CString str;
	m_editwnd.GetWindowText(str);

	ListUpdate(m_posClicked, str);
	OnCheckRefresh();	
}

BOOL CDlgToolHoleSort::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 1 )
	{
		if(strcmp(str, "Sort") == 0)
			 m_sProcessSystem.bToolHoleSort[yPos] = 1;
		else
			 m_sProcessSystem.bToolHoleSort[yPos] = 0;
	}

	/*if(xPos == 0)
		gVariable.m_sgPreworkTable.nInfoId[yPos] = atoi(str);
	else if(xPos == 1 )
	{
		gVariable.m_sgPreworkTable.nHole[yPos] = atoi(str);
	}
	else if(xPos == 2)
	{
		gVariable.m_sgPreworkTable.bCheckHole[yPos] = atoi(str);
	}
	else if(xPos == 3)
	{
		gVariable.m_sgPreworkTable.bCheckPanel[yPos] = atoi(str);
	}*/

	return FALSE;
}

BOOL CDlgToolHoleSort::ListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetListIndex();

	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(listcount == 0)
	{
		return TRUE;
	}
	else if(listcount == 1) //1
	{
		if(!FillTable0Data(xPos,yPos, str))
			return FALSE;
	}

	//else  if(listcount == 3) //1,32
	//{
	//	if(xPos < SHOT_PREWORK_TABLE0_COLUMN_COUNT)
	//	{
	//		if(!FillTable0Data(xPos,yPos, str))
	//			return FALSE;
	//	}
	//}
	return TRUE;
}
BOOL CDlgToolHoleSort::ValidateFiducialValue()
{
	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		CString strMsg;
		
	}

	return TRUE;
}

void CDlgToolHoleSort::SaveChangeValue()
{
	/*CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangePreworkTable_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;
	
	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}

	TRY
	{
		file.SeekToEnd();

		strDetail = _T("----------------------------------------------------------------------------------------------\n");
		file.Write(strDetail, strDetail.GetLength());

		strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
		file.Write(strDetail, strDetail.GetLength());


		for(int i = 0 ;i <= m_nRepeatCount; i++)
		{
			
		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
			file.Close();
		return;
	}
	END_CATCH

	file.Close();*/
}
CString CDlgToolHoleSort::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	return strMessage;
}

void CDlgToolHoleSort::OnCheckAdd()
{
	//GetCurrentASC();
	BOOL bSelect= FALSE;
	//m_nRepeatCount++;

	
	OnCheckRefresh();
}

void CDlgToolHoleSort::OnCheckDel()
{
	
}

//del �� ����׸��� �Ѵٰ� �Ͽ��� �� 
//ó�� ����� ������ �׸� ���� ���� ������  temp ����������-> ������ ������ �������� ������ ������ ���� temp ������ ����->
// ������������ ������ ���� ������ �ʱ�ȭ 
void CDlgToolHoleSort::CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo)
{
	
}

void CDlgToolHoleSort::CopyFromTempToOriginal()
{
	
}

void CDlgToolHoleSort::SetIdNoToAddDel(int nIdYPos)
{
	m_IdNoToAddDel = nIdYPos;
}

int CDlgToolHoleSort::GetIdNoToAddDel()
{
	return m_IdNoToAddDel;
}

void CDlgToolHoleSort::InitDataStruct()
{
	//gVariable.m_sgPreworkTable.nLastIndex = -1;


	//for(int i = 0 ;i < PREWORK_COUNT; i++)
	//{
	//	gVariable.m_sgPreworkTable.nInfoId[i] = i+1;

	//	gVariable.m_sgPreworkTable.nHole[i] = gProcessINI.m_sProcessCal.nTemperCompenfireCountForVisionCompenArray[i];

	//	int nTemp; 
	//	nTemp = gProcessINI.m_sProcessCal.nTempRepeatCompenLotHoleCount >> i;
	//	gVariable.m_sgPreworkTable.bCheckHole[i] = nTemp & 1;

	//	nTemp = gProcessINI.m_sProcessCal.nTempRepeatCompenLotCount >> i;
	//	gVariable.m_sgPreworkTable.bCheckPanel[i] = nTemp & 1;

	//	gVariable.m_sgPreworkTable.nLastIndex++;

	//}
}


// up, down��  �迭�� ���Ʒ��� �ٲٸ� �Ǳ� ������ ��ü ���縦 ���� �ʰ�
// m_sTempBeamPath ������ 0�� �δ콺 �������� �̿��Ͽ� m_sBeamPath ������ ������ ���� �Ѵ�. 

void CDlgToolHoleSort::OnCheckUp()
{
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
}

void CDlgToolHoleSort::OnCheckDown()
{
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
}

void CDlgToolHoleSort::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CDialog::OnDestroy();
}

void CDlgToolHoleSort::SetCurrentScrollPos(int xPos, int yPos)
{
	return;
}

int CDlgToolHoleSort::GetShowBoxMode(int nXPos)
{
	int listcount = GetListIndex();

	if(listcount == 0)
	{
		return 0;
	}
	else if(listcount == 1) //1
	{
		return 0;
	}

	else if(listcount == 3) //1,2
	{

		if(nXPos == SHOT_PREWORK_TABLE0_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;			
	}



	return TRUE;
}

void CDlgToolHoleSort::OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult)  //����ֱ� �κ�..
{
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	COLORREF clrNewTextColor, clrNewBkColor;   

    *pResult = CDRF_DODEFAULT;
	
	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
        *pResult = CDRF_NOTIFYITEMDRAW;
	}
    else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{	
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
    else if ( (CDDS_ITEMPREPAINT | CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{		   

		int listcount = GetListIndex();

		int xPos = pLVCD->iSubItem;

		if(listcount == 0)
		{	
			clrNewTextColor =TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 1) //1
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==2 )  //2
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}


		else if(listcount == 3) //1,2
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;    			
		}

		pLVCD->clrText = clrNewTextColor;
		pLVCD->clrTextBk = clrNewBkColor;     
        *pResult = CDRF_DODEFAULT;  
	}

}

void CDlgToolHoleSort::CheckAnyDoPrework()
{

}

BOOL CDlgToolHoleSort::CheckApply()
{
	for(int i = 0; i<= m_nRepeatCount; i++)
	{
		/*
		if(gVariable.m_sgFiducialTable.dPowOffsetAomDual1[i] + gVariable.m_sgFiducialTable.dPowOffsetAomDual2[i] != 100)
		{
			ErrMessage(_T("Please insert aom percentage total 100"));
			return FALSE;
		}	
		*/
	}
	return TRUE;
}

void CDlgToolHoleSort::GetCurrentASC()
{
	


}

void CDlgToolHoleSort::CellDisable(int y)
{
	for(int x = 0; x < m_Grid.GetRowCount(); x++)
		m_Grid.SetItemState(x, y, m_Grid.GetItemState(x,y) | GVIS_READONLY);
}


void CDlgToolHoleSort::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}
void CDlgToolHoleSort::EnableControl(BOOL bEnable)
{
	m_Grid.EnableWindow(bEnable);
	m_btnAdd.EnableWindow(bEnable);
	m_btnDel.EnableWindow(bEnable);



	for(int i = 1 ; i < 6; i++)
	{
	/*	if((i == 5 || i == 4) && m_nUserLevel == 2)
		{
			m_ChkSubBox[i].SetCheck(FALSE);
			m_ChkSubBox[i].EnableWindow(FALSE);
			continue;
		}
		*/
		m_ChkSubBox[i].EnableWindow(bEnable);

	}
}
void CDlgToolHoleSort::OnBnClickedBtnSave()
{

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		gProcessINI.m_sProcessSystem.bToolHoleSort[i] = m_sProcessSystem.bToolHoleSort[i];
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);

	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_SYSTEM);


	/*int nTemp = 0;

	for(int i = 0; i < PREWORK_COUNT; i++)
	{
		gProcessINI.m_sProcessCal.nTemperCompenfireCountForVisionCompenArray[i] = gVariable.m_sgPreworkTable.nHole[i] ;
	}



	for(int i = 0; i < PREWORK_COUNT; i++)
	{
		nTemp += gVariable.m_sgPreworkTable.bCheckHole[i] << i;
	}

	gProcessINI.m_sProcessCal.nTempRepeatCompenLotHoleCount = nTemp;


	nTemp = 0;
	for(int i = 0; i < PREWORK_COUNT; i++)
	{
		nTemp += gVariable.m_sgPreworkTable.bCheckPanel[i] << i;
	}
	
	gProcessINI.m_sProcessCal.nTempRepeatCompenLotCount = nTemp;

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);

	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);
*/
}


void CDlgToolHoleSort::OnBnClickedBtnCancel()
{
	OnCancel();
}

void CDlgToolHoleSort::OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	m_posClicked.x = pItem->iColumn;
	m_posClicked.y = pItem->iRow-1;
	str = m_Grid.GetItemText( pItem->iRow, pItem->iColumn);
	if(!ListUpdate(m_posClicked, str))
		OnCheckRefresh();	
}

void CDlgToolHoleSort::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
//	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
//	CCellID cCellId;
//	cCellId = m_Grid.GetFocusCell();

//	for(int i = 0; i < BEAMPATH_COUNT; i++)
	{
	//	gVariable.m_sgPreworkTable.bSelectedList[i] = FALSE;
	}
	//gVariable.m_sgPreworkTable.bSelectedList[pItem->iRow] = TRUE;


}

void CDlgToolHoleSort::OnGridDblClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	m_posClicked.x = pItem->iColumn;
	m_posClicked.y = pItem->iRow;

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
		return;


	LotListDlbCheck(m_posClicked);

	//OnButtonLotSave2();
	Invalidate();
}


void CDlgToolHoleSort::LotListDlbCheck(CPoint m_posDblClick)
{
	int xPos = m_posDblClick.x;
	int yPos = m_posDblClick.y;
	CString str;

	//if(xPos == 2) 
	//{
	//	
	//	if(gVariable.m_sgPreworkTable.bCheckHole[yPos-1] == TRUE)
	//	{
	//		str = "No Use";
	//		m_Grid.SetItemBkColour(yPos,xPos,DARK_GREEN_COLOR);
	//		m_Grid.SetItemText(yPos,xPos,str);
	//		gVariable.m_sgPreworkTable.bCheckHole[yPos-1] = FALSE;
	//	}
	//	else
	//	{
	//		str = "Use";
	//		m_Grid.SetItemBkColour(yPos,xPos,LIGHT_GREEN_COLOR);
	//		m_Grid.SetItemText(yPos,xPos,str);
	//		gVariable.m_sgPreworkTable.bCheckHole[yPos-1] = TRUE;
	//	}
	//}
	//if(xPos == 3) 
	//{
	//	
	//	if(gVariable.m_sgPreworkTable.bCheckPanel[yPos-1] == TRUE)
	//	{
	//		str = "No Use";
	//		m_Grid.SetItemBkColour(yPos,xPos,DARK_GREEN_COLOR);
	//		m_Grid.SetItemText(yPos,xPos,str);
	//		gVariable.m_sgPreworkTable.bCheckPanel[yPos-1] = FALSE;
	//	}
	//	else
	//	{
	//		str = "Use";
	//		m_Grid.SetItemBkColour(yPos,xPos,LIGHT_GREEN_COLOR);
	//		m_Grid.SetItemText(yPos,xPos,str);
	//		gVariable.m_sgPreworkTable.bCheckPanel[yPos-1] = TRUE;
	//	}
	//}
	//

	//GetLotTable( &gLotTableINI.m_sLotTable );
	Invalidate();
}

void CDlgToolHoleSort::SetProcessSystem(SPROCESSSYSTEM sProcessSystem)
{
	memcpy( &m_sProcessSystem, &sProcessSystem, sizeof(m_sProcessSystem) );	
}