#define TIMER_POWER_SUPPLY	(0) // Power Supply Timer
#define TIMER_POWER_MEASURE	(1) // Power Measurement Timer
#define TIMER_LED			(2) // LED Timer
#define TIMER_UPSCROLL		(3)	// Object List Up Scroll Timer
#define TIMER_DOWNSCROLL	(4) // Object List Down Scrill Timer