#pragma once

#include "Led.h"
// CDlgAutoLoaderInterface ��ȭ �����Դϴ�.

#define AUTOLOADER_OPTION_STATUS					3
#define AUTOLOADER_PCB_STATUS						7
#define AUTOLOADER_INPUT_STATUS						7
#define AUTOLOADER_OUTPUT_STATUS					9

class CDlgAutoLoaderInterface : public CDialog
{
	DECLARE_DYNAMIC(CDlgAutoLoaderInterface)

public:
	CDlgAutoLoaderInterface(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgAutoLoaderInterface();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_AUTO_LOADER_IF_SIGNAL };
	CListBox	m_lboxResult;


	// Option Status
	CLed m_ledOption[AUTOLOADER_OPTION_STATUS];
	CString m_strOptionText[AUTOLOADER_OPTION_STATUS];
	int		m_nOption[AUTOLOADER_OPTION_STATUS];
	int		m_nOption_Old[AUTOLOADER_OPTION_STATUS];

	// PCB Status
	CLed m_ledPcb[AUTOLOADER_PCB_STATUS];
	CString m_strPcbText[AUTOLOADER_PCB_STATUS];
	int		m_nPcb[AUTOLOADER_PCB_STATUS];
	int		m_nPcb_Old[AUTOLOADER_PCB_STATUS];

	// Input
	CLed m_ledInput[AUTOLOADER_INPUT_STATUS];
	CString m_strInputText[AUTOLOADER_INPUT_STATUS];
	int		m_nInput[AUTOLOADER_INPUT_STATUS];
	int		m_nInput_Old[AUTOLOADER_INPUT_STATUS];

	// Output
	CLed m_ledOutput[AUTOLOADER_OUTPUT_STATUS];
	CString m_strOutputText[AUTOLOADER_OUTPUT_STATUS];
	int		m_nOutput[AUTOLOADER_OUTPUT_STATUS];
	int		m_nOutput_Old[AUTOLOADER_OUTPUT_STATUS];

	CLed m_ledOptionReverse;
	BOOL m_bOldReverse; 
	int m_nTimerID;
	CFont m_fntList;
	void InitTimer();
	void DestroyTimer();
	void UpdateStatus();
	void DisplayStatus(CString strStatus);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonClear();
	afx_msg void OnBnClickedButtonChangeLog();
	afx_msg void OnStnClickedLedOption02();
};
