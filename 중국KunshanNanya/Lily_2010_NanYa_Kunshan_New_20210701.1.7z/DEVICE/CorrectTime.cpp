// CrrectTime.cpp: implementation of the CCrrectTime class.
///////////////////////////////////////////////////////////
#include "Stdafx.h"
#include "CorrectTime.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////
// Purpose	: Constructor
CCorrectTime::CCorrectTime()
{
	m_bPause		= FALSE;
	m_nStart		= (__int64)0; 
	m_nPauseStart	= (__int64)0;
	m_nPauseTime	= (__int64)0;
}

/////////////////////////////
// Purpose	: Destructor
CCorrectTime::~CCorrectTime()
{
}

///////////////////////////////
// Purpose	: Start timing
BOOL CCorrectTime::StartTime()
{
	m_bPause		= FALSE;
	m_nStart		= (__int64)0; 
	m_nPauseStart	= (__int64)0;
	m_nPauseTime	= (__int64)0;

	m_bAvailable = QueryPerformanceFrequency((LARGE_INTEGER *)&m_nFrequency);
	if(!m_bAvailable)
		return FALSE;
	return QueryPerformanceCounter((LARGE_INTEGER*)&m_nStart);
}

/////////////////////////////////////////////
// Purpose	: Pause timing
BOOL CCorrectTime::Pause(BOOL bPause/*TRUE*/)
{
	if(!m_bAvailable)
		return FALSE;

	m_bPause = bPause;
	if(bPause)
		return QueryPerformanceCounter((LARGE_INTEGER*)&m_nPauseStart);
	
	BOOL bFlag = QueryPerformanceCounter((LARGE_INTEGER *)&m_nPauseFinish);
	m_nPauseTime += (m_nPauseFinish - m_nPauseStart);
	return bFlag;
}

/////////////////////////////////////////////////////////////
// Purpose	: Present timing and get elapsed time in seconds
double CCorrectTime::PresentTime()
{
	if(!m_bAvailable || m_nStart == 0)
		return -1.0;

	__int64 nPause = (__int64)0;
	if(m_bPause)		// Pause Time
	{
		QueryPerformanceCounter((LARGE_INTEGER *)&nPause);
		nPause = (nPause - m_nPauseStart) + m_nPauseTime;
	}
	else
		nPause = m_nPauseTime;

	__int64	nPresent;
	QueryPerformanceCounter((LARGE_INTEGER *)&nPresent);
	return (double)(nPresent - m_nStart - nPause) / m_nFrequency;
}

/////////////////////////////////////////////////////////////
// Purpose	: stop timing and get elapsed time in seconds
double CCorrectTime::Finish()
{
	if(!m_bAvailable || m_nStart == 0)
		return -1.0;
	if(m_bPause)		// Pause Time
		Pause(FALSE);

	m_bAvailable= 0;
	m_bPause	= FALSE;
	QueryPerformanceCounter((LARGE_INTEGER *)&m_nFinish);
	return (double)(m_nFinish - m_nStart - m_nPauseTime) / m_nFrequency;
}

