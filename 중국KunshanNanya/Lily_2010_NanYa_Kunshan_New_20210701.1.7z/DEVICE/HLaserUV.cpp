// HLaserUV.cpp: implementation of the HLaserUV class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HLaserUV.h"
#include "..\InterfaceAVIAModule.h"
#include "math.h"
#include "..\Model\DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define GET_PERCENT_MODE				-1
#define GET_CURRENT_MODE				-2
#define GET_NONE						-3

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaserUV::HLaserUV()
{
	
}

HLaserUV::~HLaserUV()
{
	DestroyAVIAPower();
}

void HLaserUV::Initialize()
{
	InitializeAVIAPower();
}

void HLaserUV::OpenPowerDlg()
{
	AVIALaser_DoModal(gSystemINI.m_sSystemDevice.nAviaUserLevel);	
}

BOOL HLaserUV::IsPowerOn()
{
	return AVIAisPowerOn();
}

BOOL HLaserUV::IsShutterOpen()
{
	return AVIAisShutterOpen();
}

BOOL HLaserUV::IsPulseOpen()
{
	return AVIAisPulseOpen();
}

BOOL HLaserUV::IsTempReady()
{
	return IsAllTempReady();
}

BOOL HLaserUV::ChangeAviaDiodeCurrent(double dDiodeCurrent, long lFreq, int nThermalTrack)
{
	double dPower;
	double dCurrentPer;
	double dCurrentAmp;
	double dNewCurrentAmp;
	long lPulseRate;
	int iThermaTrack;

	dCurrentAmp = GET_PERCENT_MODE;

	GetAviaLaserParam(
		&dPower,
		&dCurrentPer,
		&lPulseRate,
		&iThermaTrack
		);

	if(dCurrentPer == dDiodeCurrent && lPulseRate == lFreq && (nThermalTrack != -1 && iThermaTrack == nThermalTrack))
		return TRUE;

	dCurrentAmp = GET_CURRENT_MODE;

	lPulseRate = lFreq;

	if(nThermalTrack != -1)
		iThermaTrack = nThermalTrack;

	dNewCurrentAmp = 0;

	if(SetAviaLaserParam(dDiodeCurrent, lPulseRate, iThermaTrack) == FALSE)
		return FALSE;

	::Sleep(200);

	if(dCurrentPer == dDiodeCurrent && (nThermalTrack != -1 && iThermaTrack == nThermalTrack))
	{
		::Sleep(100);
		return TRUE;
	}

	int iCount = int(fabs(dCurrentPer - dDiodeCurrent)) + 1;
	if(iCount < 5)
		iCount = 5;

#ifdef __TEST__
	iCount = 1;
#endif

	::Sleep(iCount * 300);
	dCurrentAmp = GET_CURRENT_MODE;
	GetFeedbackAviaLaserParam(&dPower, &dCurrentPer, &dCurrentAmp, &lPulseRate, &iThermaTrack);

	int iLoop = 0;

	int iMatchCount = 0;
	int iSleepTime = 100;
	BOOL bResult = FALSE;
	do
	{
		++iLoop;
		if(iLoop >= 15)
			return FALSE;
		
		if(::fabs(dCurrentAmp - dNewCurrentAmp) > 0.01)
		{
			iMatchCount = 0;
			iSleepTime = 100;

			bResult = FALSE;
			dNewCurrentAmp = dCurrentAmp;

			::Sleep(50);
			dCurrentAmp = GET_CURRENT_MODE;
			GetFeedbackAviaLaserParam(&dPower, &dCurrentPer, &dCurrentAmp, &lPulseRate, &iThermaTrack);
		}
		else
		{
			++iMatchCount;
			if(iMatchCount >= 3)
			{
				bResult = TRUE;
			}
			else
			{
				::Sleep(50);
				iSleepTime =100;
				bResult = FALSE;

				dCurrentAmp = GET_CURRENT_MODE;
				GetFeedbackAviaLaserParam(&dPower, &dCurrentPer, &dCurrentAmp, &lPulseRate, &iThermaTrack);
			}
		}
	} while(bResult == FALSE);

	iLoop = 0;
	while(TRUE)
	{
		if (IsAllTempReady()) 
			return TRUE;
		iLoop++;
		::Sleep(100);
		if(iLoop>600) // 1min
		{
			ErrMessage(_T("Thermal track time over : 1min."));
			return FALSE;
		}
#ifdef __TEST__
		break;
#endif
	}
	return TRUE;
}

void HLaserUV::PowerOn(BOOL bFlag)
{
	AVIAPowerOn(bFlag);
}

void HLaserUV::ShutterOpen(BOOL bFlag)
{
	AVIAShutterOpen(bFlag);
}

void HLaserUV::PulseOpen(BOOL bFlag)
{
	AVIAPulseOpen(bFlag);
}

int HLaserUV::GetTriggerMode()// 20090629 Front Mode error
{
	return GetAVIATriggerMode(); 
}
