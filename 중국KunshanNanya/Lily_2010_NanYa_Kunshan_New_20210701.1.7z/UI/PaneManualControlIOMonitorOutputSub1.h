#if !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB1_H__23FC99A9_C7D5_4244_9421_40C72B27309E__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB1_H__23FC99A9_C7D5_4244_9421_40C72B27309E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorOutputSub1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "..\device\devicemotor.h"

class CPaneManualControlIOMonitorOutputSub1 : public CFormView
{
protected:
	CPaneManualControlIOMonitorOutputSub1();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorOutputSub1)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorOutputSub1)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_OUTPUT_SUB1 };
	UEasyButtonEx m_btnLampOn;
	UEasyButtonEx m_btnLampOff;
	UEasyButtonEx m_btnSafeOn;
	UEasyButtonEx m_btnSafeOff;
	UEasyButtonEx m_btnInitX;
	UEasyButtonEx m_btnInitY;
	UEasyButtonEx m_btnInitZ1;
	UEasyButtonEx m_btnInitZ2;
	UEasyButtonEx m_btnInitM;
	UEasyButtonEx m_btnInitM2;
	UEasyButtonEx m_btnInitM3;
	UEasyButtonEx m_btnInitC;
	UEasyButtonEx m_btnInitC2;
	UEasyButtonEx m_btnInitLC;
	UEasyButtonEx m_btnInitUC;
	UEasyButtonEx m_btnPowermeterOpen;
	UEasyButtonEx m_btnPowermeterClose;
	UEasyButtonEx m_btnHeightSensorUp;
	UEasyButtonEx m_btnHeightSensorDown;
	UEasyButtonEx m_btnHeightSensorUp2;
	UEasyButtonEx m_btnHeightSensorDown2;
	UEasyButtonEx m_btnShutter1Open;
	UEasyButtonEx m_btnShutter1Close;
	UEasyButtonEx m_btnShutter2Open;
	UEasyButtonEx m_btnShutter2Close;
	UEasyButtonEx m_btnSuction1On;
	UEasyButtonEx m_btnSuction1Off;
	UEasyButtonEx m_btnSuction2On;
	UEasyButtonEx m_btnSuction2Off;
	UEasyButtonEx m_btnVacuumMotorOn;
	UEasyButtonEx m_btnVacuumMotorOff;
	UEasyButtonEx m_btnVacuumMotor2On;
	UEasyButtonEx m_btnVacuumMotor2Off;
	UEasyButtonEx m_btnLoaderAlign;
	UEasyButtonEx m_btnLoaderLoad;
	UEasyButtonEx m_btnLoadElvLoadPos;
	UEasyButtonEx m_btnLoadElvOriPos;
	UEasyButtonEx m_btnLoadCarrCartPos;
	UEasyButtonEx m_btnLoadCarrTablePos;
	UEasyButtonEx m_btnLoadCarrAlignPos;
	UEasyButtonEx m_btnUnloaderUnload;
	UEasyButtonEx m_btnUnloadElvUnloadPos;
	UEasyButtonEx m_btnUnloadElvOriPos;
	UEasyButtonEx m_btnUnloadCarrCartPos;
	UEasyButtonEx m_btnUnloadCarrTablePos;
	UEasyButtonEx m_btnUnloadCarrAlignPos;
	UEasyButtonEx m_btnTableClamp;
	UEasyButtonEx m_btnTableUnclamp;
	UEasyButtonEx m_btnTableClamp2;
	UEasyButtonEx m_btnTableUnclamp2;
	UEasyButtonEx m_btnDoorByPassOn;
	UEasyButtonEx m_btnDoorByPassOff;
	UEasyButtonEx m_btnLoadingShutterOpen;
	UEasyButtonEx m_btnLoadingShutterClose;
	UEasyButtonEx m_btnBuzzerOn;
	UEasyButtonEx m_btnBuzzerOff;
	UEasyButtonEx m_btnAirBlowerOn;
	UEasyButtonEx m_btnAirBlowerOff;
	UEasyButtonEx m_btnBrushMotorOn;
	UEasyButtonEx m_btnBrushMotorOff;
	UEasyButtonEx m_btnBrushSolUp;
	UEasyButtonEx m_btnBrushSolDown;
	UEasyButtonEx m_btnGreenLampOn;
	UEasyButtonEx m_btnGreenLampOff;
	UEasyButtonEx m_btnYellowLampOn;
	UEasyButtonEx m_btnYellowLampOff;
	UEasyButtonEx m_btnRedLampOn;
	UEasyButtonEx m_btnRedLampOff;
	UEasyButtonEx m_btnResetLoader1;
	UEasyButtonEx m_btnResetLoader2;
	UEasyButtonEx m_btnResetLoaderTable;
	UEasyButtonEx m_btnResetUnLoader1;
	UEasyButtonEx m_btnResetUnLoader2;
	UEasyButtonEx m_btnResetUnLoaderTable;
	UEasyButtonEx m_btnResetTable1;
	UEasyButtonEx m_btnResetTable2;
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntBtn;

// Operations
public:
	void UpdateStatus();
	void InitBtnControl();

	void InitTimer();
	void DestroyTimer();
	
	void SetAuthorityByLevel(int nLevel);
	void EnableButton(BOOL bUse);
	
	int m_nTimerID;

	LONG m_lStatus1;
	LONG m_lStatus2;
	LONG m_lStatus3;
	LONG m_lStatus4;
	LONG m_lStatus1Old;
	LONG m_lStatus2Old;
	LONG m_lStatus3old;
	LONG m_lStatus4old;

	int	m_nSuction;
	int m_nSuctionOld;

	BOOL m_bSuction1;
	BOOL m_bSuction2;
	BOOL m_bSuction1Old;
	BOOL m_bSuction2Old;

	BOOL m_bMotor;
	BOOL m_bMotorOld;

	BOOL m_bMotor2;
	BOOL m_bMotor2Old;
	
	BOOL m_bLamp;
	BOOL m_bLampOld;

	BOOL m_bChuck;
	BOOL m_bChuckOld;
	BOOL m_bLoadingShutter;
	BOOL m_bLoadingShutterOld;
	BOOL m_bBrushSol;
	BOOL m_bBrushSolOld;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif
	BOOL	m_bStatusLoader1;
	BOOL	m_bStatusLoader2;
	BOOL	m_bStatusUnloader1;
	BOOL	m_bStatusUnloader2;
	BOOL	m_bStatusTable1;
	BOOL	m_bStatusTable2;
	BOOL	m_bStatusAligner;
	BOOL	m_bStatusAligner2;
	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorOutputSub1)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorOutputSub1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorOutputSub1)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonOutputLampOn();
	afx_msg void OnButtonOutputLampOff();
	afx_msg void OnButtonOutputSafetyModeOn();
	afx_msg void OnButtonOutputSafetyModeOff();
	afx_msg void OnButtonOutputInitializeX();
	afx_msg void OnButtonOutputInitializeY();
	afx_msg void OnButtonOutputInitializeZ1();
	afx_msg void OnButtonOutputInitializeZ2();
	afx_msg void OnButtonOutputInitializeM();
	afx_msg void OnButtonOutputInitializeM2();
	afx_msg void OnButtonOutputInitializeM3();
	afx_msg void OnButtonOutputInitializeC();
	afx_msg void OnButtonOutputInitializeC2();
	afx_msg void OnButtonOutputInitializeLC();
	afx_msg void OnButtonOutputInitializeUC();
	afx_msg void OnButtonOutputPowermeterOpen();
	afx_msg void OnButtonOutputPowermeterClose();
	afx_msg void OnButtonOutputHeightSensorUp();
	afx_msg void OnButtonOutputHeightSensorDown();
	afx_msg void OnButtonOutputHeightSensorUp2();
	afx_msg void OnButtonOutputHeightSensorDown2();
	afx_msg void OnButtonOutputLasershutter1Open();
	afx_msg void OnButtonOutputLasershutter1Close();
	afx_msg void OnButtonOutputLasershutter2Open();
	afx_msg void OnButtonOutputLasershutter2Close();
	afx_msg void OnButtonOutputTablesuction1On();
	afx_msg void OnButtonOutputTablesuction1Off();
	afx_msg void OnButtonOutputTablesuction2On();
	afx_msg void OnButtonOutputTablesuction2Off();
	afx_msg void OnButtonOutputVacuumMotorOn();
	afx_msg void OnButtonOutputVacuumMotorOff();
	afx_msg void OnButtonOutputVacuumMotor2On();
	afx_msg void OnButtonOutputVacuumMotor2Off();
	afx_msg void OnButtonOutputLoaderAlign();
	afx_msg void OnButtonOutputLoaderLoad();
	afx_msg void OnButtonOutputLoaderElvLoadPos();
	afx_msg void OnButtonOutputLoaderElvOriPos();
	afx_msg void OnButtonOutputLoaderCarrCartPos();
	afx_msg void OnButtonOutputLoaderCarrTablePos();
	afx_msg void OnButtonOutputUnloaderUnload();
	afx_msg void OnButtonOutputUnloaderElvLoadPos();
	afx_msg void OnButtonOutputUnloaderElvOriPos();
	afx_msg void OnButtonOutputUnloaderCarrCartPos();
	afx_msg void OnButtonOutputUnloaderCarrTablePos();
	afx_msg void OnButtonOutputTableClamp();
	afx_msg void OnButtonOutputTableUnclamp();
	afx_msg void OnButtonOutputTableClamp2();
	afx_msg void OnButtonOutputTableUnclamp2();
	afx_msg void OnButtonDoorByPassOn();
	afx_msg void OnButtonDoorByPassOff();
	afx_msg void OnButtonOutputLoadingShutterOpen();
	afx_msg void OnButtonOutputLoadingShutterClose();
	afx_msg void OnButtonOutputBuzzerOn();
	afx_msg void OnButtonOutputBuzzerOff();
	afx_msg void OnButtonOutputAirBlowerOn();
	afx_msg void OnButtonOutputAirBlowerOff();
	afx_msg void OnButtonOutputBrushMotorOn();
	afx_msg void OnButtonOutputBrushMotorOff();
	afx_msg void OnButtonOutputBrushSolUp();
	afx_msg void OnButtonOutputBrushSolDown();
	afx_msg void OnButtonOutputGreenLampOn();
	afx_msg void OnButtonOutputGreenLampOff();
	afx_msg void OnButtonOutputYellowLampOn();
	afx_msg void OnButtonOutputYellowLampOff();
	afx_msg void OnButtonOutputRedLampOn();
	afx_msg void OnButtonOutputRedLampOff();
	afx_msg void OnButtonOutputResetLoader1();
	afx_msg void OnButtonOutputResetLoader2();
	afx_msg void OnButtonOutputResetLoaderTable();
	afx_msg void OnButtonOutputResetUnloader1();
	afx_msg void OnButtonOutputResetUnloader2();
	afx_msg void OnButtonOutputResetUnloaderTable();
	afx_msg void OnButtonOutputResetTable1();
	afx_msg void OnButtonOutputResetTable2();
	afx_msg void OnButtonOutputLoaderCarrAlignPos();
	afx_msg void OnButtonOutputUnloaderCarrAlignPos();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUTSUB1_H__23FC99A9_C7D5_4244_9421_40C72B27309E__INCLUDED_)
