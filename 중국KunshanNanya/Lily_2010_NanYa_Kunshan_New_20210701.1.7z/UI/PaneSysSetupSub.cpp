// PaneSysSetupSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupSub.h"

#include "..\EasyDrillerDlg.h"
#include "PaneSysSetup.h"
#include "PaneSysSetupDir.h"
#include "paneautorun.h"
#include "..\Model\DSystemINI.h"

#include "DlgShotTable.h"
#include "DlgBeamPathTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupSub

IMPLEMENT_DYNCREATE(CPaneSysSetupSub, CFormView)

CPaneSysSetupSub::CPaneSysSetupSub()
	: CFormView(CPaneSysSetupSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo		= 0;
	m_nUserLevel = 0;
}

CPaneSysSetupSub::~CPaneSysSetupSub()
{
}

void CPaneSysSetupSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupSub)
	DDX_Control(pDX, IDC_BUTTON_SYSTEM_SETUP_APPLY, m_btnSystemSetupApply);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);

	DDX_Control(pDX, IDC_BUTTON_OPEN_BEAMPATH_TABLE, m_btnOpenBeampath);
	DDX_Control(pDX, IDC_BUTTON_OPEN_SHOT_TABLE, m_btnOpenShot);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupSub, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_BN_CLICKED(IDC_BUTTON_SYSTEM_SETUP_APPLY, OnButtonSystemSetupApply)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN_BEAMPATH_TABLE, &CPaneSysSetupSub::OnBnClickedButtonOpenBeampathTable)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_SHOT_TABLE, &CPaneSysSetupSub::OnBnClickedButtonOpenShotTable)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupSub diagnostics

#ifdef _DEBUG
void CPaneSysSetupSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupSub message handlers

void CPaneSysSetupSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneSysSetupSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );

	m_btnSystemSetupApply.SetFont( &m_fntBtn );
	m_btnSystemSetupApply.SetFlat( FALSE );
	m_btnSystemSetupApply.SetImageOrg( 10, 3 );
	m_btnSystemSetupApply.SetIcon( IDI_APPLY );
	m_btnSystemSetupApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSystemSetupApply.EnableBallonToolTip();
	m_btnSystemSetupApply.SetToolTipText( _T("System Setup Apply") );
	m_btnSystemSetupApply.SetBtnCursor( IDC_HAND_1 );


	m_btnOpenBeampath.SetFont( &m_fntBtn );
	m_btnOpenBeampath.SetFlat( FALSE );
	m_btnOpenBeampath.SetImageOrg( 10, 3 );
	m_btnOpenBeampath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenBeampath.EnableBallonToolTip();
	m_btnOpenBeampath.SetToolTipText( _T("Open Beampath") );
	m_btnOpenBeampath.SetBtnCursor( IDC_HAND_1 );

	m_btnOpenShot.SetFont( &m_fntBtn );
	m_btnOpenShot.SetFlat( FALSE );
	m_btnOpenShot.SetImageOrg( 10, 3 );
	m_btnOpenShot.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenShot.EnableBallonToolTip();
	m_btnOpenShot.SetToolTipText( _T("Open Shot") );
	m_btnOpenShot.SetBtnCursor( IDC_HAND_1 );

	
	

}

void CPaneSysSetupSub::OnButtonBack() 
{
	// 110621
/*	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus() && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bLaser && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bInit)
	{
//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
		{		
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = TRUE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
		}
	}
*/	
#ifdef	__SERVER_PC__
	WPARAM wParam = RECIPE_GEN;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, SYSTEM_SETUP );
#else
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
#endif
}

void CPaneSysSetupSub::OnButtonSystemSetupApply() 
{
	::AfxGetMainWnd()->SendMessage( SYSTEM_APPLY, 0, 0 ); 
}

void CPaneSysSetupSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupSub::ViewApplyButton(int nTabNo)
{
	if( 0 == nTabNo || 2 == nTabNo || 4 == nTabNo ||  7 == nTabNo || 8 == nTabNo || 9 == nTabNo ) // 20070730 beam dumper
	{
		m_btnSystemSetupApply.ShowWindow(SW_SHOW);
	}
	else
	{
		m_btnSystemSetupApply.ShowWindow(SW_HIDE);
	}
}

void CPaneSysSetupSub::SetBackButton(BOOL bEnable)
{
	m_btnBack.EnableWindow(bEnable);
}


BOOL CPaneSysSetupSub::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Sub) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupSub::OnBnClickedButtonOpenBeampathTable()
{
	CDlgBeamPathTable dlg;

	dlg.SetBeamPath(gBeamPathINI.m_sBeampath);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}


void CPaneSysSetupSub::OnBnClickedButtonOpenShotTable()
{
	CDlgShotTable dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}

void CPaneSysSetupSub::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;

	switch(nLevel)
	{
	case 0:
	case 1:
		//m_btnOpenBeampath.ShowWindow( SW_HIDE );
		//m_btnOpenShot.ShowWindow( SW_HIDE );
		break;
	case 2:
	case 3:
		//m_btnOpenBeampath.ShowWindow( SW_SHOW );
		//m_btnOpenShot.ShowWindow( SW_SHOW );
		break;
	}
}