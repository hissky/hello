#if !defined(AFX_DLGINIINFO_H__1C28701F_507B_4506_9589_DED20F07348C__INCLUDED_)
#define AFX_DLGINIINFO_H__1C28701F_507B_4506_9589_DED20F07348C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// INIINFO.h : header file

#include "ColorEdit.h"
//

/////////////////////////////////////////////////////////////////////////////
// CDlgIniInfo dialog

class CDlgIniInfo : public CDialog
{
// Construction
public:
	BOOL m_bScannerChange;
	BOOL CheckData();
	void ShowInI();
	void InitStaticControl();
	void ToolTip();
	CToolTipCtrl m_ToolTip;

	CFont m_fntStatic;
	CDlgIniInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgIniInfo)
	enum { IDD = IDD_DLG_INIINFO };
	CEdit	m_edtEStop;
	CEdit	m_edtPowerStep;
	CEdit	m_edtConpensationLimitCount;
	CEdit	m_edtCompensationDutyPerWatt;
	CEdit	m_edtFidImgSaveData;
	CEdit	m_edtNoSortLine;
	CEdit	m_edtNoSortHole;
	CEdit	m_edtNoSortArea;
	CEdit	m_edtAreaSortMode;
	CEdit	m_edtXYOrder;
	CEdit	m_edtUseInnerOCRFont;
	CEdit	m_edtTextRefMode;
	CEdit	m_edtTextGap;
	CEdit	m_edtCameraPixelY;
	CEdit	m_edtCameraPixelX;

	CEdit	m_edtCognex_CoarseLimit;
	CEdit	m_edtCognex_CoarseLimitCenter;
	CEdit	m_edtCognex_FineLimit;

	CEdit	m_edtHighFOVY;
	CEdit	m_edtHighFOVX;
	CEdit	m_edtLowFOVY;
	CEdit	m_edtLowFOVX;
	CEdit	m_edtCalGridMode;
	CEdit	m_edtCalGridDelay;
	CEdit	m_edtAcceptScore;
	CEdit	m_edtResultScore;
	CEdit   m_edtExposure;
	CEdit	m_edtFidFindExposure;
	CEdit   m_edtBlob;
	CEdit	m_edtRotateHoleAcceptScore;
	CEdit	m_edtAcceptEdgeScore;
	CEdit	m_edtEocardDownCount;
	CEdit	m_edtShotDrillType;
	CEdit	m_edtMinShotTime;

	CEdit	m_edtChillerCH1;
	CEdit	m_edtChillerCH2;

	CEdit	m_edtVacOffsetMaster;
	CEdit	m_edtVacOffsetSlave;
	CEdit	m_edtVacOffsetDust;

	CEdit	m_edtLPCLogDate;
		CEdit	m_edtLPCErrorCount;
		
	CEdit	m_edtDutyLimit;
	CEdit	m_edtCheckLPCError;
   
	CEdit	m_edtLogDetail;
	CEdit	m_edtLPCMinTol;
	CEdit	m_edtLPCMaxTol;
	CEdit	m_edtLPCMinimum;
	CEdit	m_edtLPCStartTolPercent;
	CEdit	m_edtLPCStartSkipCount;
	
	CEdit	m_edtFieldFireTimeLimit;
    	CEdit	m_edtLPCHoleDeviationTolPercent;
	CEdit	m_edtPreLPCShotCount;
	
	CEdit	m_edtPreLPCMinTol;
	CEdit	m_edtPreLPCMaxTol;
	CEdit	m_edtPreLPCMaxValueOffset;


	CEdit	m_edtMinCycleTime;
	CEdit	m_edtFiducialFindType;
	CEdit	m_edtLowCalArea;
	CEdit	m_edtHighCalArea;
	CEdit	m_edtPowerMeasurementSSizeY;
	CEdit	m_edtPowerMeasurementSSizeX;
	CEdit	m_edtPowerMeasurementMSizeY;
	CEdit	m_edtPowerMeasurementMSizeX;
	CEdit	m_edtOriginFieldSizeX;
	CEdit	m_edtUseBarcodeReader;

	CEdit	m_edtUseSpeedUp;
	CEdit	m_edtUseAllFidFind;
	CEdit	m_edtUseDetailLog;

	CEdit	m_edtShortLineLength;
	CEdit	m_edtShortLineDutyOffset;
	CEdit	m_edtExcellonOpenAxis;
	CEdit	m_edtScannerAxisType2;
	CEdit	m_edtScannerAxisType;
	CEdit	m_edtOriginFieldSizeY;
	CEdit	m_edtScannerJumpDelay;
	CEdit	m_edtNoUseChillerAlarm;
	CEdit	m_edtTableLimitMinX;
	CEdit	m_edtTableLimitMinY;
	CEdit	m_edtTableLimitMaxX;
	CEdit	m_edtTableLimitMaxY;
	CEdit	m_edt3rdDummyType;
	CEdit   m_edtNoDivideUnit;
	CEdit   m_edtUseDummyForSCal;
	CEdit	m_edtMachineNo;
	CEdit	m_edtIdleShotRepeat;
	CEdit	m_edtUseIdleShot;
	CEdit	m_edtTemperCompensationMode;
	CEdit m_edtTemperMeasureMode;
	CEdit m_edtTemperContrast;
	CEdit m_edtTemperBrightness;
	CEdit	m_edtTemperCompenGridNo;
	CEdit	m_edtTemperDeltaT;
	CEdit	m_edtTemperEndT;
	CEdit	m_edtTemperTransT;
	CEdit	m_edtTemperCompenTimeoutMin;
	CEdit	m_edtTemperCompenRepeatNo;
	CEdit	m_edtTemper2DLinearMode;
	CEdit	m_edtTemperMinTLimit;
	CEdit	m_edtTemperMaxTLimit;
	CEdit	m_edtTemperDifferTLimit;
	CEdit	m_edtTemperDetaTLimit;
	CEdit	m_edtTemperMinusDetaTLimit;
	CEdit	m_edtTemperTNoChangeTimeLimitSec;
	CEdit	m_edtTemperDetailLog;
	CEdit m_edtTableMoveWaitT;
	CEdit m_edtLongWaitT;

	CEdit m_edtVerifyMode; 
	CEdit m_edtStartLM;
	CEdit m_edtLMStep;
	CEdit m_edtLMStepNo;
	CEdit m_edtStartPower;
	CEdit m_edtEndPower;
	CEdit m_edtSchedule;
	CEdit m_edtRecipeSort;
	CEdit m_edtCheckVisionSizeError;
	CEdit m_edtCheckUseMarkingDualMode;
	CEdit m_edtCheckNoUseTopHat;
	CEdit m_edtCheckSlaveMeasureStart;
	CEdit m_edtSotingHolePitch;
	CEdit m_edtCheckFullScheduling;
	CEdit m_edtOPCTimeOut;
	CEdit m_edtTabelInposCount;

	CEdit m_edtFirstOffsetMode;
	CEdit m_edtLogCopyTime;
	CComboBox m_cmbLanguage;
	CEdit m_edtTemperFireCountForVisionCompen;
	CEdit m_edtTemperFireCountForVisionCompen2;
	CEdit m_edtTemperFireCountForVisionCompen3;
	CEdit m_edtTemperFireCountForVisionCompen4;
	CEdit m_edtTemperFireCountForVisionCompen5;

	CEdit m_edtTemperCompenRepeatLotCount;
	CEdit m_edtTemperCompenVerifyLotCount;
	CEdit m_edtTemperCompenEveryPnl;
	CEdit m_edtOCRMoveOffset;

	CEdit	m_edtWaterFlowLaser;
	CEdit	m_edtWaterFlowAom;
	CEdit	m_edtWaterFlowScanner1;
	CEdit	m_edtWaterFlowScanner2;
	CEdit	m_edtWaterFlowErrorCheck;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgIniInfo)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgIniInfo)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	afx_msg void OnCancel();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeBlob();
	afx_msg void OnBnClickedOpenExploere();
	afx_msg void OnClose();
	afx_msg void OnEnChangeTemperNochangeTimeLimitSec();
	afx_msg void OnBnClickedOpenTempertable();
	afx_msg void OnBnClickedOpenToolSort();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINIINFO_H__1C28701F_507B_4506_9589_DED20F07348C__INCLUDED_)
