#if _MSC_VER > 1000
#pragma once
#endif
// CDlgAlarmMessage dialog

#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButtonEx.h"
class CDlgAlarmMessage : public CDialog
{
	DECLARE_DYNAMIC(CDlgAlarmMessage)

public:
	CDlgAlarmMessage(CWnd* pParent = NULL);   // standard constructor

	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			ResizeWindow();
	int				SetErrMsg(CString pErrMessage, UINT nType, BOOL bLog);
	//	void		ResizeWindow();

	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnYes;
	UEasyButtonEx	m_btnNo;
	UEasyButtonEx	m_btnCancel;
	CStatic			m_stcIcon;
	UINT			m_nType;
	int				m_nResult;
	CFont			m_edtFont;
	int				m_nRrefreshTimer;
	BOOL			m_bEasyDrillerDlgStart;
//	CColorEdit m_edtErrMessage;
	virtual ~CDlgAlarmMessage();

// Dialog Data
	enum { IDD = IDD_DLG_ALARM_MESSAGE };
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntEdit;
	CEdit editctrl;
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	CString m_strErrMessage;
	afx_msg BOOL DestroyWindow();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnButtonYes();
	afx_msg void OnButtonNo();
	afx_msg void OnButtonCancel();
	afx_msg void OnButtonOk();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
