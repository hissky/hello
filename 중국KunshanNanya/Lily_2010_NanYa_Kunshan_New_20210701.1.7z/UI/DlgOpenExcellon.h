#if !defined(AFX_DLGOPENEXCELLON_H__73D71E4A_0336_4E20_B6D7_B499598766A1__INCLUDED_)
#define AFX_DLGOPENEXCELLON_H__73D71E4A_0336_4E20_B6D7_B499598766A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgOpenExcellon.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenExcellon dialog

class CDlgOpenExcellon : public CDialog
{
// Construction
public:
	CDlgOpenExcellon(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgOpenExcellon)
	enum { IDD = IDD_DLG_OPEN_EXCELLON };
	int		m_nTZS;
	int		m_nABS;
	int		m_nUnit;
	UINT	m_nLineDistance;
	UINT	m_nLineNo;
	BOOL	m_bZigZag;
	int		m_nLineExtend;

	double m_dManualScaleX;
	double m_dManualScaleY;


	BOOL	m_bCheckApplyManualScale;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgOpenExcellon)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgOpenExcellon)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGOPENEXCELLON_H__73D71E4A_0336_4E20_B6D7_B499598766A1__INCLUDED_)
