// DeviceMotor.h: interface for the DeviceMotor class.
//////////////////////////////////////////////////////
#if !defined(AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_)
#define AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define FIRST_PANEL_OFFSET	1
#define SECOND_PANEL_OFFSET	2
#define DELTA_PANEL_OFFSET	3

#define TOWER_GREEN		1
#define TOWER_YELLOW	2
#define TOWER_RED		4

enum { INDEX_LEFT_VAC_SOL=0,			// table ����
		CHUCK_CLAMP_SOL = 2,			// chuck clamp on/off
		SHUTTER_OPEN_CLOSE_SOL = 4,		// �ε� ����
		SUCTION_MOTOR_ON,				// dust suction power on
		FLUORESCENT_LAMP,				// ������
		START_SW_LAMP,					// start ��ư ����
		STOP_SW_LAMP,					// stop ��ư ����
	    TOWER_LAMP_GREEN,				
	    TOWER_LAMP_YELLOW, 
	    TOWER_LAMP_RED, 
	    BUZZER,
		AIR_BLOWER,						// 5�� �Ѱ� air �ѱ�
		BRUSH_MOTOR_ON,					// brush motor ȸ��
		BRUSH_SOL,						// brush down/up
		LASER_MARKING_START,			// do not need
		RESET_SW_LAMP = 25};			// reset ��ư ����



	
	class DeviceMelsecLarge;
	#include "DeviceMelsecLarge.h"



	class DeviceUMacLarge;
   #include "DeviceUmacLarge.h"


#endif



class DevicePMac;
#include "DevicePMac.h"

class CDevMCCDaq;
class CDevVoltage;
class CDevTemperCompen;
class CDevHumidity;
class CDevChiller;
class CDevChillerNew;
class CSysUMAC;
class DeviceComiZoa;
class CComiDaq;
class CComiMotion;

class CCalibration;
class CZCalibration;

struct CALHEAD;

class TCalibration;
struct CALDATA;

class DeviceMotor
{
public:
	DeviceMotor();
	virtual ~DeviceMotor();

public:
	BOOL TableVacuumOnOff(BOOL bMaster, BOOL bSlave);
	BOOL SetNoUseLoadUnload(BOOL bNoUse);
	BOOL GetLPCStatus();
	BOOL SetNoUseSuction(BOOL bNoUse);
	BOOL Set2DBarcodeTrigger();
	BYTE GetBasketIn();
	BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd);

	BOOL SetSuctionHoodAirBlowerSol(BOOL bOn);
	BOOL SetMaskSol(BOOL bOn);

	BOOL SetAutomaticLubricatorY1Remote(BOOL bOn);
	BOOL SetAutomaticLubricatorY2Remote(BOOL bOn);
	BOOL SetAutomaticLubricatorRemote(BOOL bOn);
	BOOL SetLaserOn(BOOL bOn);

	BOOL SetAOM1MirrorFWDSol(BOOL bOn);
	BOOL SetAOM1MirrorBWDSol(BOOL bOn);
	BOOL SetAOM2MirrorFWDSol(BOOL bOn);
	BOOL SetAOM2MirrorBWDSol(BOOL bOn);

	BYTE GetUnloadPickerDownOK();
	BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd);
	BYTE GetLoadPickerDownOK();
	BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL GetTableBUse();
	BOOL IsStartMode();
	BOOL IsAlignReady();
	BOOL IsUnloadReady();
	void SetTemeratureLimits();
	void	ReadAddressTemperatureComp();
	void	GetTemperatureForAllCh (double* dTemper);
	void	GetTCTemperature (double& d1stTemper, double& d2ndTemper);
	void	GetSBTemperature (double& d1stTemper, double& d2ndTemper);

	BOOL MoveLaserBeamPath(BOOL bUp, BOOL bUseAom);
	BOOL GetBeamPathStatus(BOOL bShortPath, BOOL bUseAom);
	BOOL GetAOMAlarm();
	BOOL IsResetSwitch();
	BOOL IsHandlerPartError(BOOL bLoader);

	BOOL TableLoadPos();
	BOOL TableUnloadPos();
	BOOL IsHoodOK(BOOL bOpen);
	BOOL HoodOpen(BOOL bOpen);
	BOOL GetScannerStatus();
	BOOL GetCurrentHoodOpen();

	BOOL AOMNABeamPassUpDown(BOOL bUp);
	BOOL AOMNABeamPassUpDown2(BOOL bUp);
	BOOL AOMUseBeamPassUpDown(BOOL bUp);
	BOOL AOMUseBeamPassUpDown2(BOOL bUp);
	BOOL AOMUseBeamPassUpDown3(BOOL bUp);

	BOOL GetAOMNABeamPassUpDown(BOOL bUp);
	BOOL GetAOMNABeamPassUpDown2(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown2(BOOL bUp);
	BOOL GetAOMUseBeamPassUpDown3(BOOL bUp);


	BOOL GetManualSWStatus();
	BOOL GetAutoSWStatus();
	BOOL GetTalbeMoveEnableFlag();
	BOOL GetAOMStatus();

	

	BOOL SetError(BOOL bError);
	BOOL SetAOMPowerON(BOOL bOn);
	BOOL ScannerPower(BOOL bOn);
	BOOL IsAnyError();
	/* Table IO Control -------------------------------------------------- */

	BOOL InPositionIO(int nAxis);
	BOOL SetMoveIO(int nMoveAxis);

	BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	/* Table IO Control end ---------------------------------------------- */
	BOOL MotorMoveXY(double dPosX, double dPosY, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	BOOL MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);
	
	BOOL InitMotor(CComiMotion* pMotion, CComiDaq* pDaq); 
	BOOL DestroyMotor();

	// Purpose		: �ڵ����
	BOOL	SetAxis(int nAxis, SAXISINFO pSet);
	BOOL	GetAxis(int nAxis, SAXISINFO& pGet);

	BOOL	SetAxisMax(int nAxisMax);

	double	GetMoveSpeed(int nAxis);

public:

	#ifdef __KUNSAN_SAMSUNG_LARGE__
		PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
	#else
		PLC_BIT_SIGNAL GetMelsecIOStuct();
	#endif
	
	BOOL GetReverseReady();
	BOOL GetChillerRun();
	BOOL GetChillerRun2();

	BOOL GetChillerTempOk(CString &strChillerError);

	BOOL GetChillerAlarm1();
	BOOL GetChillerAlarm2();

	BOOL SetNGPanel(int nNG);
	int	GetDustSuctionValue();
		int	GetTableVauumValue(BOOL b1st);
	void GetAllTableVauumValue(int &nMa,int &nMb,int &nMc,int &nSa,int &nSb,int &nSc);
	void GetOutputStatus(int &Out1,int &Out2,int &Out3,int &Out4,int &Out5,int &Out6);
	void GetInputStatus(int &In1,int &In2,int &In3,int &In4,int &In5,int &In6);

	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetTrunPanel(BOOL bTurn);
	BOOL SetPCBSize(BOOL bLarge);
	BOOL SetDoorLock(BOOL bLock);	
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetUnloadBasketSignal(BOOL bIn);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetReverseDirection();
	BOOL GetPcbSize();
	BOOL SetStageMode(int nMode, BOOL bLoader=TRUE);
	BOOL SetLoaderUnloaderStop(BOOL bStop);
	BOOL SetLoaderUnloaderPause(BOOL bPause);

	void DisconnectAnyDevice(int nType);
	void ConnectAnyDevice(int nType); // 0 : chiller 1: thermo-hyprometer
	void ReadTemperatureComp();
	void GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint);
	void GetTemp_And_Humidiy(double &dOpticTemp,double &dOpticHumidy,double &dProcessTemp,double &dProcessHumidy);

	void GetVoltage(double& dV, double& dA,double& dKw);
	double GetVolateSubData(int nIndex);
	double GetChillerTemp(int nChannel, double &dTemperature, double &dFlowRate, double &dPressure);
	void GetScannerTemp(double &dTemperature1, double &dTemperature2);

	double SetChillerRun(int nRun);
	double GetChillerTemp();


	BOOL CheckMelsecConnect();




	BOOL IsHandlerStop(int nAxis);	BOOL IsOrigin(int nAxis);
	BOOL Connect(int nPortNo, long lBaudrate);
	BOOL Disconnect();
	BOOL MoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2);
	BOOL MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2);
	BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat);
	BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);
	BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);


	BOOL MoveMC3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2);
	BOOL MoveMCA3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2,double dRot,double dTopHat);

	BOOL MoveZMC3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat);

	BOOL MoveZMCA3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat);
	BOOL MotorMoveXYZMC3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);
	BOOL MotorMoveXYZMCA3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat);

	BOOL NoUseClamp(BOOL bNoUse);
	BOOL IsBMMotorHomeEnd();
	BOOL SetOutportTableVacuum(BOOL bUseBTable);
	BOOL LoaderCarrierCartPos();
	BOOL LoaderCarrierCartPos2();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL SetLimitYPos(double dPos);
	BOOL GetCurrentSuctionMotor();
	BOOL MoveTophatShutter(BOOL bUp);





	double	m_dXLimitM;
	double	m_dXLimitP;
	double	m_dYLimitM;
	double	m_dYLimitP;

	void ReadTableLimit();

	// comizoa

	// comizoa


	void	SetAxisSpeed(int nAxis, double dSpeed);
	void	SetOriginalSpeed();
	BOOL	DownloadAxisInfo();
	BOOL	DownloadAutoSetting();
	BOOL	SetAutoSetting(SAUTOSETTING sAutoSetting);
	BOOL	SetAxisInfo(SAXISINFO* sAxisInfo);
	
	void	SetMotorType(int nType)		{ m_nMotorType = nType; }
	int		GetMotorType()				{ return m_nMotorType; }
	
	void	SetCalType(int nCalType)	{ m_nCalType = nCalType; }
	int		GetCalType()				{ return m_nCalType; }
	
	void	SetUseDualPanel(int nDual)	{ m_nUseDualPanel = nDual; }
	int		GetUseDualPanel()			{ return m_nUseDualPanel; }

	void UpdateZCalibrationFile(CALHEAD& calHead, BOOL bFirst);
	void LoadZCalibrationFile(CString strPath, BOOL bFirst);
	void GetZMoveOffset(double dX, double dY, double &dOffset, BOOL bFirst);
	UINT IsScannerFault();

	void UpdateTCalibrationFile(CALDATA& calData);
	void LoadTCalibrationFile(CString strPath);

	BOOL	Initialize();
	BOOL  IsServo_Enable(int nAxis); 
	BOOL	SetOrigin(int nAxis = -1);
	BOOL IsInitialSWOn(); 
	double	GetPosition(int nAxis, BOOL b1stPanel = TRUE);
	
	BOOL	GetPosition(int nAxis, double& dPosition, BOOL b1stPanel = TRUE);

	BOOL	GetRawPosition(int nAxis, double& dPosition);

	void	GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag);
	void	UpdateCalibrationFile(CString strPath);

	BOOL	MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);

	BOOL	SetLimitZ(); // yhchung 061024 Set Limit Axis-Z
	BOOL	SetVibration(); // Vibration Count & Delay

	BOOL	MoveXY(double dPosX, double dPosY, BOOL b1stPanel = TRUE, BOOL bMoveFire = FALSE, BOOL bPass = FALSE);
	BOOL	MoveZ(double dPosZ1, BOOL bRawMove = FALSE);
	BOOL	MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove = FALSE);
	
	BOOL	MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE);	
	
	BOOL	MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE, BOOL bTophat = FALSE);

	BOOL	MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE);

	BOOL	MoveMC(double dMaskPos, double dPosC);

	BOOL	MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE);
	BOOL	MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE);
	BOOL	MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat = FALSE);
	BOOL	MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2,double dPosA, double dPosA2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE, BOOL bTophat = FALSE);
	

	BOOL	MotorShutterAll(BOOL bOpenMaster = TRUE, BOOL bOpenSlave = TRUE);

	// Load Command
	BOOL	LoaderElvOriginPos();
	BOOL	LoaderElvLoadPos();
	BOOL	LoaderCarrierAlignPos();
	BOOL	LoaderCarrierAlignPos2();
	BOOL	LoaderCarrierLoadPos();
	BOOL	LoaderPicker1Init();
	BOOL	LoaderPicker1Align();
	BOOL	LoaderPicker1Load();
	BOOL	LoaderPicker1P2();
	BOOL	LoaderPicker2Init();
	BOOL	LoaderPicker2Align();
	BOOL	LoaderPicker2Load();
	BOOL	LoaderPicker2P2();
	BOOL	LoaderClampForward();
	BOOL	LoaderClampBackward();
	BOOL	LoaderVacuum1On();
	BOOL	LoaderVacuum1Off();
	BOOL	LoaderVacuum2On();
	BOOL	LoaderVacuum2Off();

	BOOL	LoaderTableForward();
	BOOL	LoaderTableBackward();
	BOOL	LoaderAlignXForward();
	BOOL	LoaderAlignXBackward();
	BOOL	LoaderAlignYForward();
	BOOL	LoaderAlignYBackward();
	BOOL	IsLoaderPicker1PCBExist();
	BOOL	IsLoaderPicker2PCBExist();
	BOOL	IsAlignerPCBExist();
	BOOL	IsULAlignerPCBExist();

	BOOL IsLoaderPicker1Init();
	BOOL IsLoaderPicker2Init();
	
	BOOL	Loader1PCBExist(BOOL bOn);
	BOOL	Loader2PCBExist(BOOL bOn);
	BOOL	AlignTablePCBExist(BOOL bOn);
	BOOL	ULAlignTablePCBExist(BOOL bOn);

	BOOL	TablePCBReset();
	BOOL	LoaderPCBReset();
	BOOL	UnLoaderPCBReset();
	BOOL	TableCalibration(BOOL bAxisX);

	BOOL	TableClamp(BOOL bClamp, BOOL bLeft = TRUE);
	BOOL	GetCurrentMotorSol();
	BOOL	SendLoadCartNoPCB();

	BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff);
	BOOL WriteOutputDWord(UINT nAddr, DWORD dwVal);



	// UnLoad Command
	BOOL	UnloaderElvOriginPos();
	BOOL	UnloaderElvUnloadPos();
	BOOL	UnloaderCarrierTablePos();
	BOOL	UnloaderCarrierUnloadPos();
	BOOL	UnloaderCarrierAlignPos();
	BOOL	UnloaderPicker1Init();
	BOOL	UnloaderPicker1Table();
	BOOL	UnloaderPicker1Unload();
	BOOL	UnloaderPicker1P2();
	BOOL	UnloaderPicker2Init();
	BOOL	UnloaderPicker2Table();
	BOOL	UnloaderPicker2Unload();
	BOOL	UnloaderPicker2P2();
	BOOL	UnloaderClampForward();
	BOOL	UnloaderClampBackward();
	BOOL	UnloaderVacuum1On();
	BOOL	UnloaderVacuum1Off();
	BOOL	UnloaderVacuum2On();
	BOOL	UnloaderVacuum2Off();

	BOOL	UnloaderTableForward();
	BOOL	UnloaderTableBackward();
	BOOL	IsUnloaderPicker1PCBExist();
	BOOL	IsUnloaderPicker2PCBExist();

	BOOL	Unloader1PCBExist(BOOL bOn);
	BOOL	Unloader2PCBExist(BOOL bOn);
	BOOL	UnloadTablePCBExist(BOOL bOn);

	BOOL	IsTable1PCBExist();
	BOOL	IsTable2PCBExist();

	BOOL	IsLCinCartPos();
	BOOL	IsLCinCartPos2();
	BOOL	IsLCinLoadPos();

	BOOL	IsUCinCartPos();
	BOOL	IsUCinUnloadPos();

	BOOL	IsLCinAlignPos();
	BOOL	IsLCinAlignPos2();
	BOOL	IsUCinAlignPos();
	
	BOOL	IsLP1P1Up();
	BOOL	IsLP1P2Up();
	BOOL	IsLP2P1Up();
	BOOL	IsLP2P2Up();
	BOOL	IsULP1P1Up();
	BOOL	IsULP1P2Up();
	BOOL	IsULP2P1Up();
	BOOL	IsULP2P2Up();
	BOOL	IsLoaderAlignTableForward();
	BOOL	IsUnloaderAlignTableForward();
	BOOL	IsLoaderCartClamp();
	BOOL	IsAlignSheetTableForward();
	BOOL	IsAlignGuideForward();
	BOOL	IsLoaderPicker1Vacuum();
	BOOL	IsLoaderPicker2Vacuum();

	BOOL	IsUnloaderCartClamp();
	BOOL	IsUnloaderPicker1Vacuum();
	BOOL	IsUnloaderPicker2Vacuum();

	BOOL	IsUnloaderNGBoxForward();
	BOOL	IsUnloaderNGBoxBackward();

	BOOL IsUnloaderPicker1Init();
	BOOL IsUnloaderPicker2Init();

	BOOL	Stop(int nAxis = -1);


	BOOL	IsLoadCartNoPCB();
	BOOL	IsMelsecConnect();

	BOOL	IsLoaderPicker1inOriPos();
	BOOL	IsLoaderPicker1inAlignPos();
	BOOL	IsLoaderPicker1inTablePos();
	BOOL	IsLoaderPicker2inOriPos();
	BOOL	IsLoaderPicker2inAlignPos();
	BOOL	IsLoaderPicker2inTablePos();
	BOOL	IsLoaderPicker2inCartPos();
	BOOL	IsUnloaderPicker1inOriPos();
	BOOL	IsUnloaderPicker1inAlignPos();
	BOOL	IsUnloaderPicker1inTablePos();
	BOOL	IsUnloaderPicker1inCartPos();
	BOOL	IsUnloaderPicker2inOriPos();
	BOOL	IsUnloaderPicker2inAlignPos();
	BOOL	IsUnloaderPicker2inTablePos();


	BOOL	IsUnloaderElvOriginPos();
	BOOL	IsUnloaderElvUnloadPos();
	BOOL	IsLoaderElvOriginPos();
	BOOL	IsLoaderElvLoadPos();

	BOOL	IsML3ResetEnd();

	LONG	GetCurrentError(ERRORCOMMAND nError);
	BOOL GetCurrentAutoStatus();
	BYTE	GetCurrentMode();
	BYTE	GetCurrentEMStop();
	BYTE	GetCurrentShutter1();
	BYTE	GetCurrentShutter2();
	BYTE	GetCurrentPowerMeter();
	BYTE	GetCurrentSuction();
	BOOL	GetCurrentAcrylSuction(BOOL b1st);
	BYTE	GetCurrentLoadDetect(int nUsePanel);
	BYTE	GetExternalLaser();
	BOOL	GetCurrentHeight(BOOL bFirst, BOOL bDown);
	BOOL	GetCurrentVacuumMotor(BOOL b1st);
	int		GetMainAirValue();
	BOOL	IsLaserSystemWarning();
	BOOL	IsLaserOverTempFault();
	BOOL	SetOutPort(int nPortNo, WORD wOnOff, BOOL bAbs=TRUE);
	BOOL	GetStartSWStatus();
	
	int		IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	int		IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);

	BOOL	Table1VacuumMotor(BOOL bOn);
	BOOL	Table2VacuumMotor(BOOL bOn);



	BOOL	IsReady(int nAxis = -1);

	BOOL IsFlowWater();
	BOOL IsTowerBuzzer();

	BOOL IsLaserKeyOn();
	BOOL IsFluorescentLampOn();
	BOOL IsAutomaticLubricatorRemoteOn();
	BOOL IsOpticBlowerOn();
	BOOL IsMaskBlowerOn();

// Add - Door Safety

	BOOL IsDoorLockOnStatus();

	BOOL IsMainDoorStop();

	BOOL SetLoaderCartPCB(BOOL bNoUse);	
	BOOL SetSafetyMode(int nSafety);
	BOOL IsMainDoorOpen();
	BOOL IsHandlerDoorOpen();
	BOOL IsLoaderDoorOpen();
	BOOL IsUnLoaderDoorOpen();
	BOOL IsOpticsDoorOpen();

	BOOL IsSafetyMode();

	BOOL	HandlerOperation(int nHadnlerOperationID, BOOL bAction=TRUE);
	BOOL	IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait=TRUE);

	BOOL	GetCurrentTableClamp(BOOL b1st, BOOL bClamp);

	BOOL	MainReset(BOOL bOn = TRUE);

	BOOL	DustSuctionControl(BOOL bLeft, BOOL bUp);

	BOOL	DustSuctionError();
	int		GetInpositionError();

	BOOL	SetAlarmTolLed(BOOL bOn);
	int		GetWaterFlow1Value();
	int		GetWaterFlow2Value();
	int		GetAOMWaterFlow1Value();
	int		GetAOMWaterFlow2Value();
	void	ReadAllError(int* pnVal);
	int    GetLaserWaterFlowValue();

	BOOL	SetWaterFlow1Value(double dVal);
	BOOL	SetWaterFlow2Value(double dVal);
	BOOL	SetMainAirValue(double dVal);
	BOOL	SetDustSuctionValue(double dVal);
	BOOL	SetTableVauumValue(BOOL b1st, double dVal);
	BOOL	GetMotorConnect(int nType);
	BOOL    SetMotorConnect(int nType, BOOL bConnect);
	BOOL SetLoadTableVacuumOn(BOOL bOk);

	BOOL SetLampOn(BOOL bOn);
	BOOL IsHavePLCError();//20160525

	// Auto Loader I/F 
	int				m_nSetReverse;
	int				m_nSetTurnPanel;
	int				m_nSetPcbSize;
	int				m_nSetAlign;
	int				m_nSetLoad;
	int				m_nSetUnload;
	int				m_nSetTable1PcbExist;
	int				m_nSetTable2PcbExist;
	int				m_nSetTable1LoadPickerDown;
	int				m_nSetTable2LoadPickerDown;
	int				m_nSetTable1UnloadPickerDown;
	int				m_nSetTable2UnloadPickerDown;

public:
	BOOL	IsAxisOver(int nAxis, CString strMessage);
	BOOL	IsValidAxisPosition(int nAxis, double& dPosition, int nMoveMode = 0, BOOL bPass = FALSE);
//	BOOL	IsValidAxisPosition(int nAxis, int& nPosition, int nMoveMode = 0, BOOL bPass = FALSE);
	void	ShowWarning(int nAxis, BOOL bIsMax);

	void	LoadCalibrationFile(CString strPath);

	BOOL	IsRingblowerPower(int nMode);
	BOOL	IsRingblowerSolValve();

	BOOL IsAnalogLogRecodingStart(); //20160829
	BOOL GetCurrentSuctionOutput();
	BOOL IsServoConnect();
	BOOL			m_bReverse;
	BOOL			m_bAnyError;
	BOOL			m_bOldMelsecConnect;
	BOOL			m_bReadStatus;	
	int				m_nMotorType;
	int				m_nCalType;
	int				m_nUseDualPanel;
	volatile int	m_nAutoDataMax;				// ����� ������ ����
	int				m_nInpositionError;	
	SAXISINFO		m_pSetting[MOTOR_AXIS_MAX];				// ���ͼ��������� ����

	SAUTOSETTING	m_sAutoSetting;
	BOOL			m_bUmacConnect;
	BOOL			m_bMelsecConnect;
	double	m_dDestinationPos[30]; // ������ ũ��
	double	m_dCalibrationOffset[30];
	double	m_dSlaveCalibrationOffset[30];
	CCalibration*	m_Calibration;
	CCalibration*	m_SlaveCalibration;
	CZCalibration*  m_ZCalInfo1;
	CZCalibration*  m_ZCalInfo2;
	TCalibration*	m_TCalInfo;

	CDevChillerNew*	m_ChillerNew;
	CDevChiller*	m_Chiller;

	
	CDevHumidity*	m_Humidity;
#ifdef __MCCDAQ_USE_FOR_TEMPERATURE__
	CDevMCCDaq* m_TemperatureMeasure;
#else
	CDevTemperCompen* m_TemperatureMeasure;
#endif

	CDevVoltage* m_Voltage;



	DeviceUMacLarge*	m_clsMotor;

	


	;

	DeviceComiZoa*  m_pComizorMotor;				// comizoa class
	DevicePMac*		m_clsPmacMotor;
	CSysUMAC*		m_clsUmacProgram;


	DeviceMelsecLarge*	m_clsMelsec;

	

public:
	int ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel);

	BOOL SetNoUseTableClamp(BOOL bNoUse);
	BOOL SetNoUseChiller(BOOL bNoUse);
	BOOL DoMoveTableClamp(BOOL b1stOn,BOOL b2ndOn);
	// Inposition Fail Axis No
};

 // !defined(AFX_DEVICEMOTOR_H__B9CFB761_2C79_11D5_A280_004F490C60A0__INCLUDED_)
