// PaneManualControlPowerMeasurement.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\EasyDrillerDlg.h"
#include "PaneManualControlPowerMeasurement.h"
#include "..\model\dprocessini.h"
#include "..\model\dsystemini.h"
#include "..\device\hdevicefactory.h"
#include "..\device\DeviceMotor.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\device\hlaser.h"
#include "..\Alarmmsg.h"
#include "..\model\dprocessini.h"
#include "..\model\ProcessINIFile.h"
#include "paneautorun.h"
#include "math.h"
#include "..\model\globalvariable.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DTempINI.h"
#include "panemanualcontrol.h"
#include "PaneManualControlLaser.h"

#include "..\model\DProject.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\MODEL\DPowerAttenCompensation.h"
#include "..\MODEL\DShotTableINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int PREHEATTIME		= 2;
const int MEASURETIME		= 1;
const int MEASURE_REPEAT	= 7;
const double SLEEP_TIME		= 0.5;

const UINT UM_START_COMPENSATION	= WM_APP + 1;
const UINT UM_RESOURCE_CONTROL		= WM_APP + 2;

extern volatile HANDLE g_hDoPowerManual;

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlPowerMeasurement

IMPLEMENT_DYNCREATE(CPaneManualControlPowerMeasurement, CFormView)

CPaneManualControlPowerMeasurement::CPaneManualControlPowerMeasurement()
	: CFormView(CPaneManualControlPowerMeasurement::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlPowerMeasurement)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_dMasterAvrPower = m_dSlaveAvrPower = 0.0;
	m_nMeasureMode = 1;
	
	m_pThread = NULL;
	m_bMeasureComplete		= false;

	m_dMeasureTime			= 0.0;
	m_nStart				= 0;
	m_nEnd					= 25;
	m_ThreadParam.pParent	= this;
	m_ThreadParam.pHandle[0]	= INVALID_HANDLE_VALUE;
	m_ThreadParam.pHandle[1]	= INVALID_HANDLE_VALUE;
	m_ThreadParam.pHandle[2]	= INVALID_HANDLE_VALUE;
	m_pEOCard = NULL;
	m_bLongTermCheck		= FALSE;
	m_nTimer1				= -1;
	m_bTimer				= FALSE;
	m_dNewDutyOffset		= 0.0;
	m_dNewDutyOffset1 = 0;
	m_dNewDutyOffset2 = 0;
	m_dNewOntimeOffset1		= 0.0;
	m_dNewOntimeOffset2		= 0.0;
	
	m_nNewAttenOffsetPos = 0;
	m_nUserLevel			= 0;
	m_bUserDummyOn			= FALSE;
	m_dDeltaDuty			= 0;
	m_nDeltaAttenPos = 0;
	m_dDeltaPower			= 0;
	m_dOldPower				= 0;

	for(int i = 0; i < 10; i++)
	{
		m_dEachPowerMaster[i] = 0;
		m_dEachPowerSlave[i] = 0;
	}

	 m_nSelectBeamPathIndex = 0;//20160404
	 m_nSelectShotIndex = 0;
	m_dMinPower = 999; 
	m_dMaxPower = 0;
}

CPaneManualControlPowerMeasurement::~CPaneManualControlPowerMeasurement()
{

}

void CPaneManualControlPowerMeasurement::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlPowerMeasurement)
	DDX_Control(pDX, IDC_PROGRESS_PERCENTAGE, m_progTime);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_LIST_RESULT_SUB, m_lboxResult_Sub);

	DDX_Control(pDX, IDC_EDIT_2ND_HEAD, m_edt2ndHead);
	DDX_Control(pDX, IDC_EDIT_1ST_HEAD, m_edt1stHead);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MEASURE_START, m_btnMeasureStart);
	DDX_Control(pDX, IDC_COMBO_MEASUREMENT_MODE, m_cmbMeasurementMode);
	DDX_Control(pDX, IDC_COMBO_HEAD, m_cmbHead);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_COMPENSATION, m_chkUseCompensation);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_LONG_TERM_CHECK, m_chkUseLongTermCheck);
	DDX_Control(pDX, IDC_EDIT_TARGET_MIN, m_edtCompensationTargetMin);
	DDX_Control(pDX, IDC_EDIT_TARGET_MAX, m_edtCompensationTargetMax);
	DDX_Control(pDX, IDC_EDIT_TARGET_VALUE, m_edtCompensationTarget);
	DDX_Control(pDX, IDC_EDIT_TARGET_PERCENT, m_edtCompensationTargetPercent);
	DDX_Control(pDX, IDC_EDIT_TOTAL_TIME, m_edtLongTermCheckTime);
	DDX_Control(pDX, IDC_EDIT_PERIOD, m_edtLongTermCheckPeriod);
	DDX_Control(pDX, IDC_EDIT_DUMMY, m_edtLongTermCheckDummyOnTime);
	DDX_Control(pDX, IDC_EDIT_FREQ, m_edtFreq);
	DDX_Control(pDX, IDC_EDIT_DUTY, m_edtDuty);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY, m_edtAOMDelay);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY, m_edtAOMDuty);
	DDX_Control(pDX, IDC_EDIT_DUTY_OFFSET, m_edtDutyOffset);
	DDX_Control(pDX, IDC_EDIT_DUTY_OFFSET2, m_edtDutyOffset2);
	
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY_OFFSET, m_edtAOMDelayOffset);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY_OFFSET, m_edtAOMDutyOffset);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cmbTool);

	DDX_Control(pDX, IDC_COMBO_PULSE, m_cmbPulse);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BUTTON_BEAMSHOT_UPDATE, m_btnUpdate);
	DDX_Control(pDX, IDC_EDIT_WAIT_TIME, m_edtWaitTime);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE_MASTER2, m_edtVoltage_M);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE_SLAVE2, m_edtVoltage_S);

	DDX_Control(pDX, IDC_EDIT_LIMIT_COUNT, m_edtPowerLimitCount);
	DDX_Control(pDX, IDC_EDIT_SPEC_LIMIT, m_edtPowerSpecLimit);
	DDX_Control(pDX, IDC_EDIT_POWER_STEP, m_edtPowerStep);
	DDX_Control(pDX, IDC_EDIT_WAIT_LIMIT, m_edtPowerWaitLimit);
	DDX_Control(pDX, IDC_EDIT_ONTIME, m_edtOnTime);

	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneManualControlPowerMeasurement, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlPowerMeasurement)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CHECK_1ST_P0, OnCheck1stP0)
	ON_BN_CLICKED(IDC_CHECK_1ST_P1, OnCheck1stP1)
	ON_BN_CLICKED(IDC_CHECK_1ST_P2, OnCheck1stP2)
	ON_BN_CLICKED(IDC_CHECK_1ST_P3, OnCheck1stP3)
	ON_BN_CLICKED(IDC_CHECK_1ST_P4, OnCheck1stP4)
	ON_BN_CLICKED(IDC_CHECK_1ST_P5, OnCheck1stP5)
	ON_BN_CLICKED(IDC_CHECK_1ST_P6, OnCheck1stP6)
	ON_BN_CLICKED(IDC_CHECK_1ST_P7, OnCheck1stP7)
	ON_BN_CLICKED(IDC_CHECK_1ST_P8, OnCheck1stP8)
	ON_BN_CLICKED(IDC_CHECK_1ST_P9, OnCheck1stP9)
	ON_BN_CLICKED(IDC_CHECK_1ST_P10, OnCheck1stP10)
	ON_BN_CLICKED(IDC_CHECK_1ST_P11, OnCheck1stP11)
	ON_BN_CLICKED(IDC_CHECK_1ST_P12, OnCheck1stP12)
	ON_BN_CLICKED(IDC_CHECK_1ST_P13, OnCheck1stP13)
	ON_BN_CLICKED(IDC_CHECK_1ST_P14, OnCheck1stP14)
	ON_BN_CLICKED(IDC_CHECK_1ST_P15, OnCheck1stP15)
	ON_BN_CLICKED(IDC_CHECK_1ST_P16, OnCheck1stP16)
	ON_BN_CLICKED(IDC_CHECK_1ST_P17, OnCheck1stP17)
	ON_BN_CLICKED(IDC_CHECK_1ST_P18, OnCheck1stP18)
	ON_BN_CLICKED(IDC_CHECK_1ST_P19, OnCheck1stP19)
	ON_BN_CLICKED(IDC_CHECK_1ST_P20, OnCheck1stP20)
	ON_BN_CLICKED(IDC_CHECK_1ST_P21, OnCheck1stP21)
	ON_BN_CLICKED(IDC_CHECK_1ST_P22, OnCheck1stP22)
	ON_BN_CLICKED(IDC_CHECK_1ST_P23, OnCheck1stP23)
	ON_BN_CLICKED(IDC_CHECK_1ST_P24, OnCheck1stP24)
	ON_BN_CLICKED(IDC_CHECK_2ND_P0, OnCheck2ndP0)
	ON_BN_CLICKED(IDC_CHECK_2ND_P1, OnCheck2ndP1)
	ON_BN_CLICKED(IDC_CHECK_2ND_P2, OnCheck2ndP2)
	ON_BN_CLICKED(IDC_CHECK_2ND_P3, OnCheck2ndP3)
	ON_BN_CLICKED(IDC_CHECK_2ND_P4, OnCheck2ndP4)
	ON_BN_CLICKED(IDC_CHECK_2ND_P5, OnCheck2ndP5)
	ON_BN_CLICKED(IDC_CHECK_2ND_P6, OnCheck2ndP6)
	ON_BN_CLICKED(IDC_CHECK_2ND_P7, OnCheck2ndP7)
	ON_BN_CLICKED(IDC_CHECK_2ND_P8, OnCheck2ndP8)
	ON_BN_CLICKED(IDC_CHECK_2ND_P9, OnCheck2ndP9)
	ON_BN_CLICKED(IDC_CHECK_2ND_P10, OnCheck2ndP10)
	ON_BN_CLICKED(IDC_CHECK_2ND_P11, OnCheck2ndP11)
	ON_BN_CLICKED(IDC_CHECK_2ND_P12, OnCheck2ndP12)
	ON_BN_CLICKED(IDC_CHECK_2ND_P13, OnCheck2ndP13)
	ON_BN_CLICKED(IDC_CHECK_2ND_P14, OnCheck2ndP14)
	ON_BN_CLICKED(IDC_CHECK_2ND_P15, OnCheck2ndP15)
	ON_BN_CLICKED(IDC_CHECK_2ND_P16, OnCheck2ndP16)
	ON_BN_CLICKED(IDC_CHECK_2ND_P17, OnCheck2ndP17)
	ON_BN_CLICKED(IDC_CHECK_2ND_P18, OnCheck2ndP18)
	ON_BN_CLICKED(IDC_CHECK_2ND_P19, OnCheck2ndP19)
	ON_BN_CLICKED(IDC_CHECK_2ND_P20, OnCheck2ndP20)
	ON_BN_CLICKED(IDC_CHECK_2ND_P21, OnCheck2ndP21)
	ON_BN_CLICKED(IDC_CHECK_2ND_P22, OnCheck2ndP22)
	ON_BN_CLICKED(IDC_CHECK_2ND_P23, OnCheck2ndP23)
	ON_BN_CLICKED(IDC_CHECK_2ND_P24, OnCheck2ndP24)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_MEASURE_START, OnButtonMeasureStart)
	ON_CBN_SELCHANGE(IDC_COMBO_HEAD, OnSelectHeadCombo)
	ON_CBN_SELCHANGE(IDC_COMBO_MEASUREMENT_MODE, OnSelectModeCombo)
	ON_WM_TIMER()
	ON_MESSAGE(UM_START_COMPENSATION, OnStartCompensation)
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_COMPENSATION, OnCheckSubUseCompensation)
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_LONG_TERM_CHECK, OnCheckSubUseLongTermCheck)
	ON_MESSAGE(UM_RESOURCE_CONTROL, OnResourceControl)
	ON_CBN_SELCHANGE(IDC_COMBO_TOOL, OnSelchangeComboTool)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_CBN_SELCHANGE(IDC_COMBO_PULSE, OnSelchangeComboPulse)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_BEAMSHOT_UPDATE, &CPaneManualControlPowerMeasurement::OnBnClickedButtonBeamshotUpdate)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlPowerMeasurement diagnostics

#ifdef _DEBUG
void CPaneManualControlPowerMeasurement::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlPowerMeasurement::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlPowerMeasurement message handlers

void CPaneManualControlPowerMeasurement::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitComboControl();
	InitBtnControl();
	InitEditControl();
	InitPosition();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_cmbHead.SetCurSel(1);
		GetDlgItem(IDC_COMBO_HEAD)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_2ND_HEAD)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_2ND_HEAD)->EnableWindow(FALSE);

		OnSelectHeadCombo();
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		this->SendMessage(UM_RESOURCE_CONTROL, FALSE);
		OnSelectHeadCombo();
	}


	GetDlgItem(IDC_STATIC_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DUTY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DUTY)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);



}

BOOL CPaneManualControlPowerMeasurement::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlPowerMeasurement::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnMeasureStart.SetFont( &m_fntBtn );
	m_btnMeasureStart.SetRectAlign( 0 );
	m_btnMeasureStart.SetToolTipText( _T("Start") );
	m_btnMeasureStart.SetBtnCursor(IDC_HAND_1);

	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetRectAlign( 0 );
	m_btnStop.SetToolTipText( _T("Stop") );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetRectAlign( 0 );
	m_btnApply.SetToolTipText( _T("Apply to BeamPath") );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	m_btnUpdate.SetFont( &m_fntBtn );
	m_btnUpdate.SetRectAlign( 0 );
	m_btnUpdate.SetToolTipText( _T("Download from BeamPath") );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);
	
	//use compensation
	m_chkUseCompensation.SetFont( &m_fntBtn );
	m_chkUseCompensation.SetImageOrg( 10, 3 );
	m_chkUseCompensation.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseCompensation.EnableBallonToolTip();
	m_chkUseCompensation.SetToolTipText( _T("Use Power Compensation") );
	m_chkUseCompensation.SetBtnCursor(IDC_HAND_1);
	m_chkUseCompensation.EnableWindow(TRUE);

	//use Long Term Check
	m_chkUseLongTermCheck.SetFont( &m_fntBtn );
	m_chkUseLongTermCheck.SetImageOrg( 10, 3 );
	m_chkUseLongTermCheck.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseLongTermCheck.EnableBallonToolTip();
	m_chkUseLongTermCheck.SetToolTipText( _T("Long Term Power Check") );
	m_chkUseLongTermCheck.SetBtnCursor(IDC_HAND_1);
	m_chkUseLongTermCheck.EnableWindow(TRUE);
	
}

void CPaneManualControlPowerMeasurement::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	m_fntStaticSmall.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_100_PER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_0_PER)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_1ST_PANEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_SELECT_HEAD)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_TOOL_SELECTION)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_MEASUREMENT_MODE)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_SET_HEAD_HEIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_HEAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_HEAD)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_SET_POWER_COMPENSATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TARGET_MIN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TARGET_MAX)->SetFont( &m_fntStatic );	

	GetDlgItem(IDC_STATIC_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_DUTY)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_AOM_DELAY)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_AOM_DUTY)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_DUTY_OFFSET)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_DUTY_OFFSET2)->SetFont( &m_fntStatic );	
	
	GetDlgItem(IDC_STATIC_AOM_DELAY_OFFSET)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_AOM_DUTY_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TARGET_VALUE)->SetFont( &m_fntStatic );
	

	GetDlgItem(IDC_STATIC_VOLTAGE_M)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_ONTIME)->SetFont( &m_fntStatic );	
	GetDlgItem(IDC_STATIC_SHOT_NUM)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_WAIT_TIME)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_TIME_TOTAL)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_TIME_PERIOD)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_TIME_DUMMY)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_TIME_TOTAL2)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_WAIT_TIME2)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_TIME_PERIOD2)->SetFont( &m_fntStaticSmall );	
	GetDlgItem(IDC_STATIC_WAIT_LIMIT)->SetFont( &m_fntStaticSmall );	
	


}

void CPaneManualControlPowerMeasurement::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// 1'st Panel Height
	m_edt1stHead.SetFont( &m_fntEdit );
	m_edt1stHead.SetReceivedFlag( 3 );
	m_edt1stHead.SetWindowText( _T("0.0") );

	// 2'nd Panel Height
	m_edt2ndHead.SetFont( &m_fntEdit );
	m_edt2ndHead.SetReceivedFlag( 3 );
	m_edt2ndHead.SetWindowText( _T("0.0") );

	//Target
	m_edtCompensationTargetMin.SetFont( &m_fntEdit );
	m_edtCompensationTargetMin.SetReceivedFlag( 3 );
	m_edtCompensationTargetMin.SetWindowText( _T("5.0") );

	//Tolerance
	m_edtCompensationTargetMax.SetFont( &m_fntEdit );
	m_edtCompensationTargetMax.SetReceivedFlag( 3 );
	m_edtCompensationTargetMax.SetWindowText( _T("5.1") );

	//Target
	m_edtCompensationTarget.SetFont( &m_fntEdit );
	m_edtCompensationTarget.SetReceivedFlag( 3 );
	m_edtCompensationTarget.SetWindowText( _T("10") );

	//Tolerance
	m_edtCompensationTargetPercent.SetFont( &m_fntEdit );
	m_edtCompensationTargetPercent.SetReceivedFlag( 3 );
	m_edtCompensationTargetPercent.SetWindowText( _T("10") );

	//LongTermCheck
	m_edtLongTermCheckTime.SetWindowText(_T("6"));
	m_edtLongTermCheckPeriod.SetWindowText(_T("5"));
	m_edtLongTermCheckDummyOnTime.SetWindowText(_T("5"));

	m_edtPowerLimitCount.SetWindowText(_T("20"));
	m_edtPowerSpecLimit.SetWindowText(_T("10"));
	m_edtPowerStep.SetWindowText(_T("0.5"));
	m_edtPowerWaitLimit.SetWindowText(_T("8"));

	// laser parameter & Offset
	m_edtFreq.SetFont( &m_fntEdit );
	m_edtFreq.SetReceivedFlag( 1 );
	m_edtFreq.SetWindowText( _T("1000") );

	m_edtDuty.SetFont( &m_fntEdit );
	m_edtDuty.SetReceivedFlag( 3 );
	m_edtDuty.SetWindowText( _T("40.0") );

	m_edtAOMDelay.SetFont( &m_fntEdit );
	m_edtAOMDelay.SetReceivedFlag( 3 );
	m_edtAOMDelay.SetWindowText( _T("20.0") );

	m_edtAOMDuty.SetFont( &m_fntEdit );
	m_edtAOMDuty.SetReceivedFlag( 3 );
	m_edtAOMDuty.SetWindowText( _T("20.0") );

	m_edtDutyOffset.SetFont( &m_fntEdit );
	m_edtDutyOffset.SetReceivedFlag( 3 );
	m_edtDutyOffset.SetWindowText( _T("0.0") );

	m_edtDutyOffset2.SetFont( &m_fntEdit );
	m_edtDutyOffset2.SetReceivedFlag( 3 );
	m_edtDutyOffset2.SetWindowText( _T("0.0") );
	

	m_edtAOMDelayOffset.SetFont( &m_fntEdit );
	m_edtAOMDelayOffset.SetReceivedFlag( 3 );
	m_edtAOMDelayOffset.SetWindowText( _T("0.0") );

	m_edtAOMDutyOffset.SetFont( &m_fntEdit );
	m_edtAOMDutyOffset.SetReceivedFlag( 3 );
	m_edtAOMDutyOffset.SetWindowText( _T("0.0") );

	m_edtWaitTime.SetWindowText(_T("30"));
	m_edtWaitTime.SetFont( &m_fntEdit );

	m_edtLongTermCheckTime.SetWindowText(_T("30"));
	m_edtLongTermCheckTime.SetFont( &m_fntEdit );

	m_edtLongTermCheckPeriod.SetWindowText(_T("30"));
	m_edtLongTermCheckPeriod.SetFont( &m_fntEdit );

	m_edtLongTermCheckDummyOnTime.SetWindowText(_T("30"));
	m_edtLongTermCheckDummyOnTime.SetFont( &m_fntEdit );

	m_edtPowerLimitCount.SetWindowText(_T("30"));
	m_edtPowerLimitCount.SetFont( &m_fntEdit );

	m_edtPowerSpecLimit.SetWindowText(_T("30"));
	m_edtPowerSpecLimit.SetFont( &m_fntEdit );

	m_edtPowerStep.SetWindowText(_T("30"));
	m_edtPowerStep.SetFont( &m_fntEdit );

	m_edtPowerWaitLimit.SetWindowText(_T("30"));
	m_edtPowerWaitLimit.SetFont( &m_fntEdit );

	m_edtVoltage_M.SetFont( &m_fntEdit );
	m_edtVoltage_M.SetReceivedFlag( 3 );
	m_edtVoltage_M.SetWindowText( _T("10.0") );


	m_edtVoltage_S.SetFont( &m_fntEdit );
	m_edtVoltage_S.SetReceivedFlag( 3 );
	m_edtVoltage_S.SetWindowText( _T("10.0") );

	m_edtOnTime.SetFont( &m_fntEdit );
	m_edtOnTime.SetReceivedFlag( 3 );
	m_edtOnTime.SetWindowText( _T("1") );


}

void CPaneManualControlPowerMeasurement::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(140, "Arial Bold");

	m_cmbHead.SetFont( &m_fntCombo );
	m_cmbHead.SetCurSel( 0 );

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );

	m_cmbMeasurementMode.SetFont( &m_fntCombo );
	m_cmbMeasurementMode.SetCurSel( 1 );

	m_cmbPulse.SetFont( &m_fntCombo );
	m_cmbPulse.SetCurSel( 0 );
}

void CPaneManualControlPowerMeasurement::InitPosition()
{
	const USHORT usQuarterLSB = HALFLSB / 2;
	
	for (int nY = 4, nNum = 0; nY >= 0; nY--)
	{
		for (int nX = 0; nX < 5; nX++, nNum++)
		{
			m_pPowerMeasure[nNum].xGalvoPos	= static_cast<USHORT>(nX * usQuarterLSB == NUMLSB ? MAXLSB : nX * usQuarterLSB);
			if (nY % 2 == 1)
				m_pPowerMeasure[nNum].xGalvoPos = static_cast<USHORT>(MAXLSB - m_pPowerMeasure[nNum].xGalvoPos);
			
			m_pPowerMeasure[nNum + 25].xGalvoPos	= m_pPowerMeasure[nNum].xGalvoPos;
			m_pPowerMeasure[nNum + 25].yGalvoPos	= m_pPowerMeasure[nNum].yGalvoPos	= static_cast<USHORT>(nY * usQuarterLSB == NUMLSB ? MAXLSB : nY * usQuarterLSB);
			m_pPowerMeasure[nNum + 25].dVal			= m_pPowerMeasure[nNum].dVal		= 0.0;
		}
	}
}

void CPaneManualControlPowerMeasurement::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(130, "Arial Bold");
	
	m_lboxResult.SetFont( &m_fntListBox );
	m_lboxResult_Sub.SetFont( &m_fntListBox );
}

HBRUSH CPaneManualControlPowerMeasurement::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_1ST_PANEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_PANEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SELECT_HEAD)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MEASUREMENT_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SET_HEAD_HEIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TOOL_SELECTION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_OFFSET)->GetSafeHwnd() == pWnd->m_hWnd ||
		//GetDlgItem(IDC_STATIC_SELECT_TOOL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SET_POWER_COMPENSATION)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlPowerMeasurement::DisplayAndCheck(UINT nID, BOOL bIsMeasure)
{
	if( bIsMeasure )
		((CButton*)GetDlgItem( nID ))->SetWindowText( _T("ready") );
	else
		((CButton*)GetDlgItem( nID ))->SetWindowText( _T(" ") );

	((CButton*)GetDlgItem( nID ))->SetCheck( bIsMeasure );
}

void CPaneManualControlPowerMeasurement::ToggleMeasure(UINT nID, BOOL bIs1stPanel)
{
	UINT nIndex;
	
	if( bIs1stPanel )
	{
		nIndex = nID - IDC_CHECK_1ST_P0;
		m_b1stPower[nIndex] = !m_b1stPower[nIndex];
		DisplayAndCheck(nID, m_b1stPower[nIndex]);
	}
	else
	{
		nIndex = nID - IDC_CHECK_2ND_P0;
		m_b2ndPower[nIndex] = !m_b2ndPower[nIndex];
		DisplayAndCheck(nID, m_b2ndPower[nIndex]);
	}
}

void CPaneManualControlPowerMeasurement::OnCheck1stP0() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P0, 1 );
		m_b1stPower[0] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P0 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP1() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P1, 1 );
		m_b1stPower[1] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P1 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP2() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P2, 1 );
		m_b1stPower[2] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P2 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP3() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P3, 1 );
		m_b1stPower[3] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P3 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP4() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P4, 1 );
		m_b1stPower[4] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P4 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP5() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P5, 1 );
		m_b1stPower[5] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P5 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP6() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P6, 1 );
		m_b1stPower[6] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P6 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP7() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P7, 1 );
		m_b1stPower[7] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P7 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP8() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P8, 1 );
		m_b1stPower[8] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P8 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP9() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P9, 1 );
		m_b1stPower[9] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P9 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP10() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P10, 1 );
		m_b1stPower[10] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P10 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP11() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P11, 1 );
		m_b1stPower[11] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P11 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP12() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P12, 1 );
		m_b1stPower[12] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P12 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP13() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P13, 1 );
		m_b1stPower[13] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P13 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP14() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P14, 1 );
		m_b1stPower[14] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P14 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP15() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P15, 1 );
		m_b1stPower[15] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P15 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP16() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P16, 1 );
		m_b1stPower[16] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P16 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP17() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P17, 1 );
		m_b1stPower[17] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P17 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP18() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P18, 1 );
		m_b1stPower[18] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P18 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP19() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P19, 1 );
		m_b1stPower[19] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P19 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP20() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P20, 1 );
		m_b1stPower[20] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P20 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP21() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P21, 1 );
		m_b1stPower[21] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P21 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP22() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P22, 1 );
		m_b1stPower[22] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P22 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP23() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P23, 1 );
		m_b1stPower[23] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P23 );
}

void CPaneManualControlPowerMeasurement::OnCheck1stP24() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_1ST_P24, 1 );
		m_b1stPower[24] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_1ST_P24 );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP0() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P0, 1 );
		m_b2ndPower[0] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P0, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP1() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P1, 1 );
		m_b2ndPower[1] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P1, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP2() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P2, 1 );
		m_b2ndPower[2] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P2, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP3() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P3, 1 );
		m_b2ndPower[3] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P3, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP4() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P4, 1 );
		m_b2ndPower[4] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P4, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP5() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P5, 1 );
		m_b2ndPower[5] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P5, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP6() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P6, 1 );
		m_b2ndPower[6] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P6, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP7() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P7, 1 );
		m_b2ndPower[7] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P7, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP8() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P8, 1 );
		m_b2ndPower[8] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P8, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP9() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P9, 1 );
		m_b2ndPower[9] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P9, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP10() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P10, 1 );
		m_b2ndPower[10] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P10, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP11() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P11, 1 );
		m_b2ndPower[11] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P11, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP12() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P12, 1 );
		m_b2ndPower[12] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P12, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP13() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P13, 1 );
		m_b2ndPower[13] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P13, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP14() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P14, 1 );
		m_b2ndPower[14] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P14, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP15() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P15, 1 );
		m_b2ndPower[15] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P15, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP16() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P16, 1 );
		m_b2ndPower[16] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P16, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP17() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P17, 1 );
		m_b2ndPower[17] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P17, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP18() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P18, 1 );
		m_b2ndPower[18] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P18, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP19() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P19, 1 );
		m_b2ndPower[19] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P19, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP20() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P20, 1 );
		m_b2ndPower[20] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P20, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP21() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P21, 1 );
		m_b2ndPower[21] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P21, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP22() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P22, 1 );
		m_b2ndPower[22] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P22, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP23() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{
		DisplayAndCheck( IDC_CHECK_2ND_P23, 1 );
		m_b2ndPower[23] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P23, FALSE );
}

void CPaneManualControlPowerMeasurement::OnCheck2ndP24() 
{
	if( 0 == m_cmbMeasurementMode.GetCurSel() )
	{ 
		DisplayAndCheck( IDC_CHECK_2ND_P24, 1 );
		m_b2ndPower[24] = 1;
	}
	else
		ToggleMeasure( IDC_CHECK_2ND_P24, FALSE );
}

void CPaneManualControlPowerMeasurement::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntListBox.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlPowerMeasurement::SetProcessPowerMeasure(SPROCESSPOWERMEASURE sProcessPowerMeasure, DPOINT dMeasurePos[2])
{
	memcpy( &m_sProcessPowerMeasure, &sProcessPowerMeasure, sizeof(m_sProcessPowerMeasure) );

	m_d1stPos = dMeasurePos[0];
	m_d2ndPos = dMeasurePos[1];
	
	DispProcessPowerMeasure();
}

void CPaneManualControlPowerMeasurement::GetProcessPowerMeasure(SPROCESSPOWERMEASURE* sProcessPowerMeasure)
{
	SetControlToData();
	m_sProcessPowerMeasure.dCompensationDutyPerWatt = sProcessPowerMeasure->dCompensationDutyPerWatt;
	m_sProcessPowerMeasure.nConpensationLimitCount = sProcessPowerMeasure->nConpensationLimitCount;
	memcpy( sProcessPowerMeasure, &m_sProcessPowerMeasure, sizeof(m_sProcessPowerMeasure) );
}

void CPaneManualControlPowerMeasurement::DispProcessPowerMeasure()
{
	CString strData;

	// Use Tool
	m_cmbTool.SetCurSel(m_sProcessPowerMeasure.nUseTool);

	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];//20160404
	m_nSelectBeamPathIndex = m_sProcessPowerMeasure.nUseTool;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nUseTool];//20160404
	UpdatePulseCombo(m_nSelectShotIndex);
	// Head
	m_cmbHead.SetCurSel(m_sProcessPowerMeasure.nHead);
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		m_cmbHead.SetCurSel(1);

	// Measure Mode
	m_nMeasureMode = 1; //m_sProcessPowerMeasure.nMeasureMode;
	m_cmbMeasurementMode.SetCurSel(m_nMeasureMode);

	// 1st Height
	strData.Format(_T("%.3f"), m_sProcessPowerMeasure.d1stHeight);
	m_edt1stHead.SetWindowText( (LPCTSTR)strData );

	// 2nd Height
	strData.Format(_T("%.3f"), m_sProcessPowerMeasure.d2ndHeight);
	m_edt2ndHead.SetWindowText( (LPCTSTR)strData );

	// Compensation
	m_chkUseCompensation.SetCheck(m_sProcessPowerMeasure.bCompensation);
	m_bCompensationMode = m_sProcessPowerMeasure.bCompensation;

	// Long Term Check
	m_chkUseLongTermCheck.SetCheck(m_sProcessPowerMeasure.bLongTermCheck);
	m_bLongTermCheck = m_sProcessPowerMeasure.bLongTermCheck;
	strData.Format(_T("%d"), m_sProcessPowerMeasure.nLongTermTotalTime);
	m_edtLongTermCheckTime.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessPowerMeasure.nLongTermPeriod);
	m_edtLongTermCheckPeriod.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessPowerMeasure.nLongTermDummyOnTime);
	m_edtLongTermCheckDummyOnTime.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%d"), m_sProcessPowerMeasure.nMeasureWaitTime);
	m_edtWaitTime.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%d"), m_sProcessPowerMeasure.nConpensationLimitCount);
	m_edtPowerLimitCount.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessPowerMeasure.nCompensationPowerSpecPercent);
	m_edtPowerSpecLimit.SetWindowText( (LPCTSTR)strData );
	
	//m_sProcessPowerMeasure.dPowerStep = gProcessINI.m_sProcessPowerMeasure.dPowerStep;

	strData.Format(_T("%.2f"), m_sProcessPowerMeasure.dPowerStep);
	m_edtPowerStep.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sProcessPowerMeasure.dCompensationWaitLimit);
	m_edtPowerWaitLimit.SetWindowText( (LPCTSTR)strData );

	if(m_sProcessPowerMeasure.bCompensation)
		m_cmbMeasurementMode.EnableWindow(FALSE);
	else
		m_cmbMeasurementMode.EnableWindow(TRUE);
	
	//Target
	strData.Format(_T("%.2f"), m_sProcessPowerMeasure.dMinAllowable);
	m_edtCompensationTargetMin.SetWindowText( (LPCTSTR)strData );

	//Tolerance
	strData.Format(_T("%d"), m_sProcessPowerMeasure.dMaxAllowable);
	m_edtCompensationTargetMax.SetWindowText( (LPCTSTR)strData );





	strData.Format(_T("%.2f"), m_sProcessPowerMeasure.dVoltage_M);
	m_edtVoltage_M.SetWindowText( (LPCTSTR)strData );



	memcpy(m_b1stPower, &m_sProcessPowerMeasure.b1stPower, sizeof(m_sProcessPowerMeasure.b1stPower));
	memcpy(m_b2ndPower, &m_sProcessPowerMeasure.b2ndPower, sizeof(m_sProcessPowerMeasure.b2ndPower));

	int nID;
	for(int i=0; i<25; i++)
	{
		nID = IDC_CHECK_1ST_P0 + i;
		DisplayAndCheck(nID, m_b1stPower[i]);

		nID = IDC_CHECK_2ND_P0 + i;
		DisplayAndCheck(nID, m_b2ndPower[i]);
	}

	UpdateData(FALSE);
}

void CPaneManualControlPowerMeasurement::SetControlToData()
{
	UpdateData(TRUE);
	
	CString strData;

	// Use Tool
	m_sProcessPowerMeasure.nUseTool = m_cmbTool.GetCurSel();

	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];//20160404
	m_nSelectBeamPathIndex = m_sProcessPowerMeasure.nUseTool;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nUseTool];

	m_sProcessPowerMeasure.dPowerStep = gProcessINI.m_sProcessPowerMeasure.dPowerStep;

	m_sProcessPowerMeasure.nConpensationLimitCount =  gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount;

	m_sProcessPowerMeasure.nPulseNum = m_cmbPulse.GetCurSel();

	// Head
	m_sProcessPowerMeasure.nHead = m_cmbHead.GetCurSel();

	// Measure Mode
	m_nMeasureMode = m_cmbMeasurementMode.GetCurSel();
//	m_sProcessPowerMeasure.nMeasureMode = m_nMeasureMode;

	if(m_nMeasureMode == 1)
	{
		int nID;
		for(int i=0; i<25; i++)
		{
			nID = IDC_CHECK_1ST_P0 + i;
			m_b1stPower[i] = ((CButton*)GetDlgItem(nID))->GetCheck();
			
			nID = IDC_CHECK_2ND_P0 + i;
			m_b2ndPower[i] = ((CButton*)GetDlgItem(nID))->GetCheck();
		}
		
		memcpy(m_sProcessPowerMeasure.b1stPower, &m_b1stPower, sizeof(m_b1stPower));
		memcpy(m_sProcessPowerMeasure.b2ndPower, &m_b2ndPower, sizeof(m_b2ndPower));
	}

	// 1st Height
	m_edt1stHead.GetWindowText( strData );
	m_sProcessPowerMeasure.d1stHeight = atof( (LPSTR)(LPCTSTR)strData );

	// 2nd Height
	m_edt2ndHead.GetWindowText( strData );
	m_sProcessPowerMeasure.d2ndHeight = atof( (LPSTR)(LPCTSTR)strData );

	//Compensation
	m_sProcessPowerMeasure.bCompensation = m_chkUseCompensation.GetCheck();
	
	//Long Term Check
	m_sProcessPowerMeasure.bLongTermCheck = m_chkUseLongTermCheck.GetCheck();
	m_edtLongTermCheckTime.GetWindowText( strData );
	m_sProcessPowerMeasure.nLongTermTotalTime = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtLongTermCheckPeriod.GetWindowText( strData );
	m_sProcessPowerMeasure.nLongTermPeriod = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtLongTermCheckDummyOnTime.GetWindowText( strData );
	m_sProcessPowerMeasure.nLongTermDummyOnTime = atoi( (LPSTR)(LPCTSTR)strData );
		
	m_edtWaitTime.GetWindowText( strData );
	m_sProcessPowerMeasure.nMeasureWaitTime = atoi( (LPSTR)(LPCTSTR)strData );

	GetMeasureData();
}

BOOL CPaneManualControlPowerMeasurement::MoveZ(BYTE nAxis, double dMove)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return TRUE;
	
	if (!pMotor->MotorMoveAxis(nAxis, dMove))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}

	int nCheckAxis;
	if(nAxis == AXIS_Z1)
		nCheckAxis = IND_Z1;
	else
		nCheckAxis = IND_Z2;

	if (TRUE != pMotor->InPositionIO(nCheckAxis))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
#ifndef __TEST__
	::Sleep(50);
#endif
	
	return TRUE;
}

BOOL CPaneManualControlPowerMeasurement::MoveMotor(int i)
{
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return TRUE;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();

	if (!pMotor->MoveXY(m_pPowerMeasure[i].xTablePos, m_pPowerMeasure[i].yTablePos, TRUE, SHOT_MOVE, TRUE)) // 090804 shutter üũ ����
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();

	if (!pMotor->MoveXY(m_pPowerMeasure[i].xTablePos, m_pPowerMeasure[i].yTablePos, TRUE, TRUE)) // 090804 shutter üũ ����
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	

#endif



	if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}
	
#ifndef __TEST__
	::Sleep(50);
#endif
	
	return TRUE;
}

void CPaneManualControlPowerMeasurement::OnButtonMeasureStart()
{


	// check compen mode
/*	if( m_bCompensationMode )
	{
		if(m_cmbHead.GetCurSel() == 0) // dual
		{
			ErrMessage(_T("Can't compensate for both head. Choose 1st or 2nd PNL"));
			return;
		}


	}
*/

	int nPulseNo = m_cmbPulse.GetCurSel();

	BOOL bCheck =m_chkUseCompensation.GetCheck();

	if(nPulseNo != 0 && bCheck)
	{
		CString strShow = "Pulse 0 Only Power Compensation Mode";
		ErrMessage(strShow);
		return;
	}

	if( bCheck )
	{
		int nMainTool = CheckMainTool();
		int nMainBeamPath = 0;
		POSITION ToolPos = gDProject.m_pToolCode[nMainTool]->m_SubToolData.GetHeadPosition();

		if(ToolPos != NULL)
		{
			SUBTOOLDATA ToolData = gDProject.m_pToolCode[nMainTool]->m_SubToolData.GetNext(ToolPos);
			nMainBeamPath = ToolData.nMask;
		}

		BeamPathInfoUpdate(nMainBeamPath);

	}



	::ResetEvent(g_hDoPowerManual);
	m_nDeltaAttenPos = 0;
		
	m_dDeltaDuty = m_dDeltaPower = m_dOldPower = m_dNewDutyOffset = m_nNewAttenOffsetPos = 0;







	m_bUserDummyOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		::SetEvent(g_hDoPowerManual);
		return;
	}
	
	CString strData;

	if(m_nTimer1 != -1)
	{
		KillTimer(m_nTimer1);
		m_nTimer1 = -1;
	}
	m_bTimer = FALSE;

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		::SetEvent(g_hDoPowerManual);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		::SetEvent(g_hDoPowerManual);
		return;
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && !m_bUserDummyOn)
	{
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			ErrMsgDlg(STDGNALM607);
			::SetEvent(g_hDoPowerManual);
			return;
		}
	}
	GetProcessPowerMeasure( &gProcessINI.m_sProcessPowerMeasure );
	m_bCompensationMode = m_sProcessPowerMeasure.bCompensation;
	m_d1stPos = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0];
	m_d2ndPos = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1];

	m_pEOCard = gDeviceFactory.GetEocard();

	pMotor->TableClamp(TRUE);
	pMotor->TableClamp(TRUE, FALSE);
#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, TRUE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, TRUE, TRUE);
#endif
#ifndef __TEST__
	::Sleep(1500);
#endif

	double dQuarterLenMX = gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x / 4.0;
	double dQuarterLenMY = gSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y / 4.0;
	double dQuarterLenSX = gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x / 4.0;
	double dQuarterLenSY = gSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y / 4.0;
	
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			m_pPowerMeasure[i * 5 + j].xTablePos = m_d1stPos.x - 2 * dQuarterLenMX + j * dQuarterLenMX;
			m_pPowerMeasure[i * 5 + j + 25].xTablePos = m_d2ndPos.x - 2 * dQuarterLenSX + j * dQuarterLenSX;
			m_pPowerMeasure[i * 5 + j].yTablePos = m_d1stPos.y + 2 * dQuarterLenMY - i * dQuarterLenMY;
			m_pPowerMeasure[i * 5 + j + 25].yTablePos = m_d2ndPos.y + 2 * dQuarterLenSY - i * dQuarterLenSY;
			if ((i % 2) == 1)
			{
				m_pPowerMeasure[i * 5 + j].xTablePos += 4 * dQuarterLenMX - 2 * j * dQuarterLenMX;
				m_pPowerMeasure[i * 5 + j + 25].xTablePos += 4 * dQuarterLenSX - 2 * j * dQuarterLenSX;
			}
		
		}
	}
	
#ifndef __TEST__
	if (!m_Serial.PortOpened())
	{
		ConnectPort();
		if (!m_Serial.PortOpened())
		{
			ErrMsgDlg(STDGNALM701);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
			::SetEvent(g_hDoPowerManual);
			return;
		}
	}
#endif

	if (m_pThread != NULL)
	{
		ErrMessage(IDS_MEASURE_THREAD_PREV);
		::SetEvent(g_hDoPowerManual);
		return;
	}

	this->SendMessage(UM_RESOURCE_CONTROL, FALSE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE);
	::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, TRUE);

	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
		int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
		BOOL bAOM = gDeviceFactory.GetMotor()->GetAOMStatus(); // 110607
		BOOL bScanner = gDeviceFactory.GetMotor()->GetScannerStatus();
		
		BOOL bPower, bShutter;
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
		{
			bPower = nPower;
			bShutter = nShutter;
		}


		if(!bPower || !bShutter || !bAOM || !bScanner)
		{
			ErrMsgDlg(STDGNALM303);
			this->SendMessage(UM_RESOURCE_CONTROL, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
			::SetEvent(g_hDoPowerManual);
			ButtonInit();
			return;
		}
	}
	int nCheckSelect = 0;
	for (int j = m_nStart; j < m_nEnd; ++j)
	{
		nCheckSelect += m_b1stPower[j];
		nCheckSelect += m_b2ndPower[j];
	}
	
	if (nCheckSelect == 0)
	{
		ErrMessage(IDS_MEASURE_POINT);
		this->SendMessage(UM_RESOURCE_CONTROL, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
		::SetEvent(g_hDoPowerManual);
		ButtonInit();
		return;
	}

	EnablePowerLocationButton(FALSE);

	bool bPara = ParameterIntegrity();

	int nHead = m_cmbHead.GetCurSel();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		nHead = 1;

	if(m_bCompensationMode)
		nHead = 0;

	m_lboxResult.ResetContent();
	m_lboxResult_Sub.ResetContent();
	m_bMeasureComplete = false;
	if(bPara)
	{
		if(nHead == 0)
		{
			m_nStart = 0;
			m_nEnd = 50;
		}
		else if(nHead == 1)
		{
			m_nStart = 0;
			m_nEnd = 25;
		}
		else
		{
			m_nStart = 25;
			m_nEnd = 50;
		}


		if(!ChangeBeamPath(m_sProcessPowerMeasure.nMask))
		{
			this->SendMessage(UM_RESOURCE_CONTROL, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);
			::SetEvent(g_hDoPowerManual);
			ButtonInit();
			return;
		}

		memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );

		CString strAOMFile;
		strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
		strcpy_s(m_sProcessPowerMeasure.cAOMFilePath, strAOMFile);

		m_ThreadParam.pParent = this;
		m_ThreadParam.pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
		m_ThreadParam.pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
		m_ThreadParam.pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event

		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
		m_pThread = ::AfxBeginThread(ThreadProc, static_cast<LPVOID>(const_cast<MEASURETHREADPARAM*>(&m_ThreadParam)));
		if (m_pThread == NULL)
		{
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			ErrMessage(IDS_MEASURE_THREAD_CREATE);
			ButtonInit();
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
			::SetEvent(g_hDoPowerManual);
			return;
		}

		m_dMasterAvrPower = m_dSlaveAvrPower = 0.0;

//		time_t	timeEnd;
//		time(&timeEnd);
//		gProcessINI.m_sProcessPowerMeasure.nMeasureTime = timeEnd;
		
		::SetEvent(m_ThreadParam.pHandle[0]);
		::Sleep(100);

		CString strEvent, strInfo;
		strEvent = _T("Started the process of measuring of laser power.");
		

		
			strInfo.Format(_T("Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Pulse Width = %f %% | Beam Path No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm"),
				m_sProcessPowerMeasure.dMinAllowable, m_sProcessPowerMeasure.dMaxAllowable, m_sProcessPowerMeasure.nFrequency, m_sProcessPowerMeasure.dPulseWidth, m_sProcessPowerMeasure.nMask, m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight);
		
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
		
		//		this->SendMessage(UM_RESOURCE_CONTROL, FALSE);
//		::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE);
		return;	
	}
	else
	{
		ButtonInit();
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
		::SetEvent(g_hDoPowerManual);
		return;
	}
}

void CPaneManualControlPowerMeasurement::OnButtonStop()
{
	MeasureLaserOff();
	gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y);
	
	if (m_pThread)
	{	
		::SetEvent(m_ThreadParam.pHandle[1]);
		DWORD dwRetCode = -1;
		//while(dwRetCode != WAIT_OBJECT_0)
	//	{
			dwRetCode = ::WaitForSingleObject(m_ThreadParam.pHandle[2], 1000);
	//		MessageLoop();
	//	}
		if (dwRetCode == WAIT_OBJECT_0)
		{
			MakeThreadClear();
			ButtonInit();
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			return;
		}
		else	// Not entered in the case of INFINITE
		{
			ButtonInit();
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			ErrMessage(IDS_MEASURE_THREAD_PREV);
			return;
		}
	}
	ButtonInit();
}

void CPaneManualControlPowerMeasurement::ButtonInit()
{
	this->SendMessage(UM_RESOURCE_CONTROL, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);
	
	for (int i = 0; i < 25; ++i)
	{
		DisplayAndCheck(IDC_CHECK_1ST_P0 + i, m_b1stPower[i]);
		DisplayAndCheck(IDC_CHECK_2ND_P0 + i, m_b2ndPower[i]);
	}
}

void CPaneManualControlPowerMeasurement::OnSelectModeCombo()
{
	m_nMeasureMode = m_cmbMeasurementMode.GetCurSel();

	if(m_nMeasureMode == 0) // Auto
	{
		for(int i=0; i<25; i++)
		{
			m_b1stPower[i] = TRUE;
			m_b2ndPower[i] = TRUE;
			DisplayAndCheck( IDC_CHECK_1ST_P0 + i, 1 );
			DisplayAndCheck( IDC_CHECK_2ND_P0 + i, 1 );
		}
	}

	UpdateData(FALSE);
}

void CPaneManualControlPowerMeasurement::OnSelectHeadCombo()
{
	int nSel = m_cmbHead.GetCurSel();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		nSel = 1;

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
		nSel = -1;

	if(nSel == 0)
	{
		for(int i=0; i<25; i++)
		{
			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(TRUE);
		}
	}
	else if(nSel == 1)
	{
		for(int i=0; i<25; i++)
		{
			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(FALSE);
		}
	}
	else if(nSel == 2)
	{
		for(int i=0; i<25; i++)
		{
			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(FALSE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(TRUE);
		}
	}
	else
	{
		for(int i=0; i<25; i++)
		{
			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(FALSE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(FALSE);
		}
	}
}

void CPaneManualControlPowerMeasurement::SetComPortData(SCOMPORT* psComPort)
{
	memcpy( &m_sComPort, psComPort, sizeof(m_sComPort) );
}

void CPaneManualControlPowerMeasurement::EnablePowerLocationButton(BOOL bEnable)
{
	int nSelectHead = m_cmbHead.GetCurSel();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		nSelectHead = 1;

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
		nSelectHead = -1;

	int i;
	if (bEnable)
	{
		switch (nSelectHead)
		{
		case 0:
			for( i =  0; i < 25; ++i)
			{
				GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(bEnable);
				GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(bEnable);
			}
			break;
		case 1:
			for( i =  0; i < 25; ++i)
				GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(bEnable);
			break;
		case 2:
			for( i =  0; i < 25; ++i)
				GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(bEnable);
			break;
		}
	}
	else
	{
		for( i =  0; i < 25; ++i)
		{
			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(FALSE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(FALSE);
		}
	}
}

bool CPaneManualControlPowerMeasurement::ParameterIntegrity()
{
	BOOL bFind = FALSE;
	
	if(gBeamPathINI.m_sBeampath.nLastIndex >= m_sProcessPowerMeasure.nUseTool && m_sProcessPowerMeasure.nUseTool >= 0)
		bFind = TRUE;
	
	if(!bFind)
		return false;

	bool bParameterIntegrity;
	if (m_sProcessPowerMeasure.dMinAllowable > m_sProcessPowerMeasure.dMaxAllowable && m_sProcessPowerMeasure.dMinAllowable > 0 
		&& m_sProcessPowerMeasure.dMinAllowable < 100 && m_sProcessPowerMeasure.dMaxAllowable > 0 && m_sProcessPowerMeasure.dMaxAllowable < 100)
	{
		ErrMessage(IDS_MEASURE_REF_VALUE);
		OnButtonStop();
		bParameterIntegrity = false;
		GetDlgItem(IDC_EDIT_TARGET_MIN)->SetFocus();
//		SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
	}
	else if (m_sProcessPowerMeasure.dMinAllowable <= 0 || m_sProcessPowerMeasure.dMinAllowable >= 100)
	{
		ErrMessage(_T("0 < Target Min.Value < 100"));
		OnButtonStop();
		bParameterIntegrity = false;
		GetDlgItem(IDC_EDIT_TARGET_MIN)->SetFocus();
//		SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
	}
	else if (m_sProcessPowerMeasure.dMaxAllowable <= 0 || m_sProcessPowerMeasure.dMaxAllowable >= 100)
	{
		ErrMessage(_T("0 < Target Max.Value < 100"));
		OnButtonStop();
		bParameterIntegrity = false;
		GetDlgItem(IDC_EDIT_TARGET_MAX)->SetFocus();
//		SetEditBoxActive(IDC_EDIT_MAX_ALLOWABLE);
	}
	else if ( (m_sProcessPowerMeasure.nFrequency < 1 || m_sProcessPowerMeasure.nFrequency > 10000) && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		ErrMessage(_T("1 <= Frequency <= 10,000 [Hz]"));
		OnButtonStop();
		bParameterIntegrity = false;
//		SetEditBoxActive(IDC_EDIT_LASER_PULSE_FREQ);
		GetDlgItem(IDC_EDIT_FREQ)->SetFocus();
	}

	else if ( ((m_sProcessPowerMeasure.dPulseWidth + m_sProcessPowerMeasure.dDutyOffset) / (10000 / m_sProcessPowerMeasure.nFrequency) < 0.1 || 
				(m_sProcessPowerMeasure.dPulseWidth + m_sProcessPowerMeasure.dDutyOffset) / (10000 / m_sProcessPowerMeasure.nFrequency) > 60) && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		ErrMessage(_T("0.1 <= Duty <= 60 [%]"));
		OnButtonStop();
		bParameterIntegrity = false;
//		SetEditBoxActive(IDC_EDIT_LASER_PULSE_WIDTH);
		GetDlgItem(IDC_EDIT_DUTY)->SetFocus();
	}

	else if (m_sProcessPowerMeasure.d1stHeight < 0.0 || m_sProcessPowerMeasure.d1stHeight > 95)
	{
		ErrMessage(_T("0 <= 1stHeight <= 95"));
		OnButtonStop();
		bParameterIntegrity = false;
		SetEditBoxActive(IDC_EDIT_1ST_HEAD);
	}
	else if (m_sProcessPowerMeasure.d2ndHeight < 0.0 || m_sProcessPowerMeasure.d2ndHeight > 95)
	{
		ErrMessage(_T("0 <= 2ndHeight <= 95"));
		OnButtonStop();
		bParameterIntegrity = false;
		SetEditBoxActive(IDC_EDIT_2ND_HEAD);
	}
	else
		bParameterIntegrity = true;
	
	return bParameterIntegrity;
}

int CPaneManualControlPowerMeasurement::CharToInt(TCHAR chNumber)
{
	if (isdigit(chNumber))
		return chNumber - _T('0');
	else
		return 0;
}

double CPaneManualControlPowerMeasurement::ConvertDouble(TCHAR *chData)
{
	int a, b, c, d, e;
	
	TCHAR buf[MAX_PATH];
	memset(buf, 0x00, sizeof(buf));
	for (int i = 0; *chData != 0x00 && i < MAX_PATH; i++, chData++)
		buf[i] = *chData;
	
	if (buf[0] != _T('*') || buf[3] != _T('.') || buf[7] != _T('E'))
		return 0.0;
	
	a = CharToInt(buf[2]);
	b = CharToInt(buf[4]);
	c = CharToInt(buf[5]);
	d = CharToInt(buf[6]);
	e = CharToInt(buf[8]);
	
	double dTemp = a + (b * 0.1) + (c * 0.01) + (d * 0.001);
	
	for(int i =  0; i < e; ++i)
		dTemp *= 10.0;
	
	return dTemp;
}

double CPaneManualControlPowerMeasurement::Measure()
{
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return 0.0;
	
	TCHAR szTemp[100];
	m_Serial.SetCmdSize(5);
	strcpy_s(szTemp, m_Serial.QueryCommand((LPSTR)(LPCTSTR)"$SP"));
	double dTemp = ConvertDouble(szTemp);
#ifdef __TEST__
	dTemp = 5.0;
	int nOffset = rand()%10;
	double dOffset = (double)nOffset/10; //eunjin test 
	dTemp += dOffset;

#endif
	return dTemp;
}

CString CPaneManualControlPowerMeasurement::GetTextString(int i)
{
	CString strVal;
	switch (i)
	{
	case 0:
		strVal = _T("First Measurement : ");
		break;
	case 1:
		strVal = _T("Second Measurement : ");
		break;
	case 2:
		strVal = _T("Third Measurement : ");
		break;
	case 3:
		strVal = _T("Fourth Measurement : ");
		break;
	case 4:
		strVal = _T("Fifth Measurement : ");
		break;
	}
	
	return strVal;
}

void CPaneManualControlPowerMeasurement::UpdateResult_Sub(double dResult)
{
	double dTemp = 0.0;
	CString strValue, strMeasure;

	strMeasure.Format("%.3f W",dResult);

	if(m_lboxResult_Sub.GetCount() > 400)
		m_lboxResult_Sub.DeleteString(0);

	m_lboxResult_Sub.AddString((LPCTSTR)strMeasure);
	m_lboxResult_Sub.SetCurSel(m_lboxResult_Sub.GetCount()-1);

}
void CPaneManualControlPowerMeasurement::UpdateStrResult(CString strResult)
{
	if(m_lboxResult.GetCount() > 400)
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strResult);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);

}

void CPaneManualControlPowerMeasurement::UpdateResult(double dResult, int nPoint)
{

	double dTemp = 0.0;
	CString strValue, strMeasure;
	for(int nNo = 0; nNo < MEASURE_REPEAT - 2 && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; nNo++)
	{
		if(nPoint < 25 )
			strValue.Format(_T("%.2f"), m_dEachPowerMaster[nNo]);
		else
			strValue.Format(_T("%.2f"), m_dEachPowerSlave[nNo]);

		strMeasure = GetTextString(nNo) + strValue;

		if(m_lboxResult.GetCount() > 400)
			m_lboxResult.DeleteString(0);

		m_lboxResult.AddString((LPCTSTR)strMeasure);
		m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	}

	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return;

	CString strVal, strCount, strTemp;
	strVal = _T(" Avr. : ");
	strTemp.Format(_T("%0.2f"), dResult);

	if (nPoint < 25 &&  !m_bMeasureComplete)
	{
		if ((nPoint % 10) < 5)
			strCount.Format(_T("%2d"), nPoint + 1);
		else
			strCount.Format(_T("%2d"), nPoint + 5 - 2 * (nPoint % 5));

		strMeasure = "Master #" + strCount + strVal + strTemp;
	}
	else
	{
		if ((nPoint % 10) >= 5)
			strCount.Format(_T("%2d"), nPoint - 24);
		else
			strCount.Format(_T("%2d"), nPoint - 20 - 2 * (nPoint % 5));

		strMeasure = "Slave #" + strCount + strVal + strTemp;
	}
	
	if(m_lboxResult.GetCount() > 400)
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strMeasure);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	m_lboxResult.AddString("");
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);

	m_pPowerMeasure[nPoint].dVal = dResult;
 	ResultViewText(dResult, IDC_CHECK_1ST_P0 + nPoint);
}

void CPaneManualControlPowerMeasurement::UpdateResult(double dResult, int nPoint, int nToolNo, int nSubToolNo, int nShotNo, int nRetryCount)
{
	double dTemp = 0.0;
	CString strValue, strMeasure;
	CString strCompensationTitle;
	strCompensationTitle.Format(_T("Tool No %d, SubToolNo %d"), nToolNo, nSubToolNo);
	m_lboxResult.AddString((LPCTSTR)strCompensationTitle);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	strCompensationTitle.Format(_T("ShotNo %d, Retry %d"),nShotNo, nRetryCount);
	m_lboxResult.AddString((LPCTSTR)strCompensationTitle);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	for(int nNo = 0; nNo < MEASURE_REPEAT - 2 && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; nNo++)
	{
		if(nPoint < 25 )
			strValue.Format(_T("%.2f"), m_dEachPowerMaster[nNo]);
		else
			strValue.Format(_T("%.2f"), m_dEachPowerSlave[nNo]);

		strMeasure = GetTextString(nNo) + strValue;

		if(m_lboxResult.GetCount() > 400)
			m_lboxResult.DeleteString(0);

		m_lboxResult.AddString((LPCTSTR)strMeasure);
		m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	}

	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return;

	CString strVal, strCount, strTemp;
	strVal = _T(" Avr. : ");
	strTemp.Format(_T("%0.2f"), dResult);

	if (nPoint < 25 &&  !m_bMeasureComplete)
	{
		if ((nPoint % 10) < 5)
			strCount.Format(_T("%2d"), nPoint + 1);
		else
			strCount.Format(_T("%2d"), nPoint + 5 - 2 * (nPoint % 5));

		strMeasure = "Master #" + strCount + strVal + strTemp;
	}
	else
	{
		if ((nPoint % 10) >= 5)
			strCount.Format(_T("%2d"), nPoint - 24);
		else
			strCount.Format(_T("%2d"), nPoint - 20 - 2 * (nPoint % 5));

		strMeasure = "Slave #" + strCount + strVal + strTemp;
	}

	if(m_lboxResult.GetCount() > 400)
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strMeasure);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
	m_lboxResult.AddString("");
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);

	m_pPowerMeasure[nPoint].dVal = dResult;
	ResultViewText(dResult, IDC_CHECK_1ST_P0 + nPoint);
}
double CPaneManualControlPowerMeasurement::CalculateAverageOnePower(double dPower[], int nPoint)
{
	int nNo, nMinNo1 = 0, nMinNo2 = 0;
	double dMin1 = 9999.999, dMin2 = 9999.999;
	for (nNo = 0; nNo < MEASURE_REPEAT && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; nNo++)
	{
		if (dPower[nNo] < dMin1)
		{
			nMinNo1 = nNo;
			dMin1 = dPower[nNo];
		}
	}
	for (nNo = 0; nNo < MEASURE_REPEAT && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; nNo++)
	{
		if ((dPower[nNo] < dMin2) && (nMinNo1 != nNo))
		{
			nMinNo2 = nNo;
			dMin2 = dPower[nNo];
		}
	}
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return 0.0;

	double dTemp = 0.0;
	for(int i =  0, nNo = 0; nNo < MEASURE_REPEAT && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; nNo++)
	{
		if (nNo == nMinNo1 || nNo == nMinNo2)
			continue;

		dTemp += dPower[nNo];
		
		if(nPoint < 25)
			m_dEachPowerMaster[i] = dPower[nNo];
		else if(nPoint > 24)
			m_dEachPowerSlave[i] = dPower[nNo];

		i++;
	}

	return dTemp / (MEASURE_REPEAT - 2.0);
}
double CPaneManualControlPowerMeasurement::RepeatMeasure(int nPoint)
{
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return FALSE;

	if (m_bMeasureComplete)
		return FALSE;

	if(nPoint < 25)
		gDeviceFactory.GetEocard()->SetMasterSlave(TRUE);
	else
		gDeviceFactory.GetEocard()->SetMasterSlave(FALSE);

	double dPower[MEASURE_REPEAT];
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	CString strTemp, strCount;
	CString strValue, strMeasure;
	double dFinalResultPower = 0;;
	double dResultPower[2] = {0,};
	int nOffset = 30; // 0.3 us
	BOOL bFirst = TRUE;
	BOOL bSuccessCompen = TRUE;
	BOOL bMeasureAllTool = TRUE;
	BOOL bCanSave = FALSE;
	int nPowerTryCnt = 0;
	int nTargetOK = 0;
	CString strDutyOffsetMsg = _T("");


	gVariable.m_bGrobalDutyOffsetCompenMode = TRUE;
	do
	{
//		nPowerTryCnt++;
		if(m_bCompensationMode)
		{
		//	if(ErrMessage(_T("Compensation All Tools?"), MB_YESNO) == IDYES)
				bMeasureAllTool = TRUE;
		//	else
				//bMeasureAllTool = FALSE;

			memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );

			int nBeamPathTable[BEAMPATH_COUNT] = {0,};

			int nMainTool = CheckMainTool();

			for(int nTool = 1; nTool < MAX_TOOL_NO; nTool++)
			{
				if(nMainTool != nTool )
					continue;

				int nMainTool = CheckMainTool();
				if(!gDProject.m_pToolCode[nTool]->m_bUseTool)
					continue;
				if(!bMeasureAllTool)
				{
					CString strMsg;
					strMsg.Format(_T("Do you want compensation %d Tool ? "), nTool);
					if(ErrMessage(strMsg, MB_YESNO) == IDNO)
						continue;
				}
				int nSub = gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount();

				pToolCode = gDProject.m_pToolCode[nTool];

				int nSubCount = 0;
				POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
				while(pos)
				{
					subData = pToolCode->m_SubToolData.GetAt(pos);

					int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subData.nMask];

					if(nSubCount == nSub) 
						break;
					nSubCount++;

					if(nBeamPathTable[subData.nMask] == TRUE)
						continue;

					nBeamPathTable[subData.nMask] = TRUE;


					subData.nTotalShot = gVariable.m_sgShotGroupTable.nTotalShotCount[nShotIndex];

					


					nPowerTryCnt = 0;
					for(int nShotCount = 0; nShotCount < subData.nTotalShot; nShotCount++)
					{

						if(nShotCount != 0)
							continue;

						if(gVariable.m_sgShotGroupTable.bUseAom[nShotIndex] == TRUE)
							gVariable.m_bGrobalDutyOffsetCompenMode = FALSE;
			
						else
							gVariable.m_bGrobalDutyOffsetCompenMode = TRUE;

						m_dNewDutyOffset = 0;
						nPowerTryCnt = 0;

						while(TRUE)
						{

							UpdateStrResult("");

							CString strCompenMode = "DutyOffset Compen";

							if(gVariable.m_bGrobalDutyOffsetCompenMode == FALSE)
							{
								strCompenMode = "Wait Compen";
							}


							CString strM;
							strM.Format("Tool%d , BeamPath%d , %s",nTool,subData.nMask,strCompenMode);
							UpdateStrResult(strM);
							TRACE("%s\n",strM);

							strM.Format("Shot%d , Pulse%d , Retry%d",nShotIndex,nShotCount,nPowerTryCnt);
							UpdateStrResult(strM);
							TRACE("%s\n",strM);


							//if(nShotCount == 0)
							{
								subData.dPowerMax[nShotCount] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[nShotCount];
								subData.dPowerMin[nShotCount] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[nShotCount];
							}
							if(subData.dPowerMin[nShotCount] <= 0)
							{
								::ErrMessage(_T("Shot Power Target is under 0 please resetting"));
								return 0.0;
							}
							if(subData.dPowerMax[nShotCount] <= 0)
							{
								::ErrMessage(_T("Shot Power Tolerance is under 0 please resetting"));
								return 0.0;
							}
							double dPMinMsg, dPMaxMsg;
							dPMinMsg = subData.dPowerMin[nShotCount];
							dPMaxMsg = subData.dPowerMax[nShotCount];

							CString strResult= _T("");
							strResult.Format(_T("Target Min %.3f max %.3f"), dPMinMsg, dPMaxMsg);

							UpdateStrResult(strResult);


							int nHeadCount = 0;
							int nStartHead = 0;
							int nEndHead = 2;

							if(m_cmbHead.GetCurSel() == 1)
							{
								nEndHead = 1;
							}
							else if(m_cmbHead.GetCurSel() == 2)
							{
								nStartHead = 1;
							}
			

							dFinalResultPower = 0;
							int nBackupPoint;
							nBackupPoint = nPoint;
							bSuccessCompen = TRUE;
							bCanSave = TRUE;



							double dPMin, dPMax;
							dPMin = subData.dPowerMin[nShotCount];
							dPMax = subData.dPowerMax[nShotCount];

							double dTarget = (dPMin + dPMax)/2.;




							int nHeadNo = 0;

							if(gProcessINI.m_sProcessOption.bSlaveMeasureStart == FALSE)
							{
								nHeadNo = nStartHead;
							}
							else
							{
								nHeadNo = nEndHead-1;
							}


							while(TRUE)
							{

								strResult.Format(_T("Head %d Measure Start"), nHeadNo+1);
								UpdateStrResult(strResult);

								if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE))
								{
									MeasureLaserOff();
									return 0.0;
								}
								int nTempPoint = nBackupPoint;
								if(nHeadNo == 1) //2��° ��� ����
								{
									nTempPoint += 25;
									
									if (!MoveMotor(nTempPoint))
									{
										ProcessMeasureStop();
										return FALSE;
									}
									GalvoStepMove(nTempPoint);
								}
								else
								{
									if (!MoveMotor(nTempPoint))
									{
										ProcessMeasureStop();
										return FALSE;
									}
									GalvoStepMove(nTempPoint);
								}



								if(!UpdateSubToolParam(subData, m_dNewDutyOffset, nShotCount))
								{
									ErrMessage(_T("Duty or AOM Setting Limit Over")); 
									return 0.0;
								}

								if(!ChangeBeamPath(subData.nMask))
								{
									return 0.0;
								}


								PreHeatWait(TRUE, PREHEATTIME);

								if (nTempPoint >= 0 && nTempPoint <25)	// Master
								{
									if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE))
									{
										MeasureLaserOff();
										return 0.0;
									}
								}

								if (nTempPoint >= 25)	// Slave
								{
									if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE))
									{
										MeasureLaserOff();
										return 0.0;
									}
								}

								time_t	timeNow, time1st;
								time(&timeNow);
								time(&time1st);
								while(difftime(time1st, timeNow) < gProcessINI.m_sProcessPowerMeasure.nMeasureWaitTime && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT)
								{
									time(&time1st);
								}

								memset(dPower, 0, sizeof(double) * MEASURE_REPEAT);
								for (int i = 0; i < MEASURE_REPEAT && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; ++i)
								{



									dPower[i] = MeasureDuringWait(MEASURETIME/2. , 3);	// Unit sec


									if(dPower[i] < 0.5)
									{
										CString strMsg = _T("");
										strMsg.Format(_T("Laser power = %.3f.\nCheck laser power measuring position or port setting"), dPower[i]);
										MeasureLaserOff();
										ErrMessage(strMsg);
										return 0.0;
									}

									if(gSystemINI.m_sHardWare.nUseAOD)
									{
										if(nPoint < 25) // ���� ������. �������� �� �ڵ� -> re : �¾ƿ�! 
											dPower[i] += gBeamPathINI.m_sBeampath.dPowOffsetVoltage1[m_sProcessPowerMeasure.nMask];
										else
											dPower[i] += gBeamPathINI.m_sBeampath.dPowOffsetVoltage2[m_sProcessPowerMeasure.nMask];
									}

									MeasureWait(SLEEP_TIME);	// Unit sec

									if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
									{
										MeasureLaserOff();
										return 0.0;
									}
								}
								MeasureLaserOff();


								dResultPower[nHeadNo] = CalculateAverageOnePower(dPower, nTempPoint);

								strResult.Format(_T("Head %d , Target %.3f"), nHeadNo+1,dTarget);

								UpdateStrResult(strResult);

								strM.Format(" Result: %.3f (Gap:%.3f)",dResultPower[nHeadNo],dResultPower[nHeadNo] - dTarget);
								UpdateStrResult(strM);
								TRACE("%s\n",strM);

								SetMeasureTime(TRUE, 0.0);
								if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
									return 0.0;

								if(gProcessINI.m_sProcessOption.bSlaveMeasureStart == FALSE)
								{
									nHeadNo++;
									if(nHeadNo >= nEndHead)
										break;
								}
								else
								{
									nHeadNo--;
									if(nHeadNo < nStartHead)
										break;
								}

							}


							double dOldShotDuty = m_dNewDutyOffset;

							bSuccessCompen = GetCompensationOffsetNew(dTarget,dResultPower, dPMin, dPMax);

							double dOriginOffset = 0;

							if(gVariable.m_bGrobalDutyOffsetCompenMode == TRUE)
							{
								dOriginOffset = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[nShotCount];
							}
							else
							{
								dOriginOffset = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dAOMWait_M[nShotCount];
							}


							if(bSuccessCompen == FALSE)
							{
								CString strMsg;

								strMsg.Format("Offset change(%.3f -> %.3f)", dOldShotDuty,  m_dNewDutyOffset);
								UpdateStrResult(strMsg);
								TRACE("%s\n",strMsg);
								::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));

								nPowerTryCnt++;

								if(gVariable.m_bGrobalDutyOffsetCompenMode == FALSE)
								{
									double dWaitOffset = m_dNewDutyOffset + dOriginOffset;
									double dWaitOffsetLimit = gProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit;

									if(dWaitOffset < 0 || dWaitOffset > dWaitOffsetLimit)
									{
										strMsg.Format("Wait Offset is %.3f us, Over Limit (0us ~ %.3fus) . Power Compensation Fail)", dWaitOffset, dWaitOffsetLimit);
										UpdateStrResult(strMsg);
										TRACE("%s\n",strMsg);

										ErrMessage(strMsg); 
										return 0.0;

										/*
										strMsg.Format("Start  Duty Offset Change");
										UpdateStrResult(strMsg);
										TRACE("%s\n",strMsg);

										gVariable.m_bGrobalDutyOffsetCompenMode = TRUE;
										m_dNewDutyOffset = 0;
										*/


									}

								}

							}
							else
							{


								if(gVariable.m_bGrobalDutyOffsetCompenMode == TRUE)
									gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[nShotCount] += m_dNewDutyOffset;
								else
									gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dAOMWait_M[nShotCount] += m_dNewDutyOffset;

								CString strMsg;
								strMsg.Format("Success , Apply (%.3f -> %.3f)  ", dOriginOffset, dOriginOffset + m_dNewDutyOffset);
								UpdateStrResult(strMsg);
								TRACE("%s\n",strMsg);

								strMsg.Format("Final Result , Head 1 : %.3f , Head 2 : %.3f)  ", dResultPower[0], dResultPower[1]);
								UpdateStrResult(strMsg);
								TRACE("%s\n",strMsg);

								::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
								pToolCode->m_SubToolData.SetAt(pos, subData);

								if(m_dNewDutyOffset == 0)
									bCanSave = FALSE;
								break;
							}


							if(nPowerTryCnt >= gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount)
							{
								ErrMessage(_T("Power Compensation Fail")); 
								return 0.0;
							}

						}//while
						////
					}
					pToolCode->m_SubToolData.GetNext(pos);
				}
			}
			if(bCanSave)
			{
				CString strMsg;

				if(gVariable.m_bGrobalDutyOffsetCompenMode == FALSE)
				    strMsg.Format("Do you want Save Wait Setting to Shot Table?");
				else
					strMsg.Format("Do you want Save Duty offset Setting to Shot Table?");
				if(ErrMessage(strMsg, MB_YESNO) == IDYES)
				{

					memcpy( &gShotTableINI.m_sShotGroupTable, &gVariable.m_sgShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );
					if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SHOT_INI))
					{
						ErrMsgDlg(STDGNALM114);
						return 0.0;
					}

					::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SHOT_INI);
				}

			}	
		}
		else
		{
			if(!UpdateNewParam(m_dNewDutyOffset))
			{
				ErrMessage(_T("Duty or AOM Setting Limit Over")); 
				return 0.0;
			}



			if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE))
			{
				MeasureLaserOff();
				return 0.0;
			}
	/*
			if (nPoint >= 0 && nPoint <25)	// Master
			{
				if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE))
				{
					MeasureLaserOff();
					return 0.0;
				}
			}

			if (nPoint >= 25)	// Slave
			{
				if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE))
				{
					MeasureLaserOff();
					return 0.0;
				}
			}
	*/
			PreHeatWait(TRUE, PREHEATTIME);

			if (nPoint >= 0 && nPoint <25)	// Master
			{
				if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE))
				{
					MeasureLaserOff();
					return 0.0;
				}
			}

			if (nPoint >= 25)	// Slave
			{
				if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE))
				{
					MeasureLaserOff();
					return 0.0;
				}
			}

			time_t	timeNow, time1st;
			time(&timeNow);
			time(&time1st);
			while(difftime(time1st, timeNow) < gProcessINI.m_sProcessPowerMeasure.nMeasureWaitTime && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT)
			{
				time(&time1st);
			}

			memset(dPower, 0, sizeof(double) * MEASURE_REPEAT);
			for (int i = 0; i < MEASURE_REPEAT && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT; ++i)
			{
			


				dPower[i] = MeasureDuringWait(MEASURETIME/2. , 3);	// Unit sec


				if(dPower[i] < 0.5)
				{
					CString strMsg = _T("");
					strMsg.Format(_T("Laser power = %.3f.\nCheck laser power measuring position or port setting"), dPower[i]);
					MeasureLaserOff();
					ErrMessage(strMsg);
					return 0.0;
				}

				if(gSystemINI.m_sHardWare.nUseAOD)
				{
					if(nPoint < 25) // ���� ������. �������� �� �ڵ� -> re : �¾ƿ�! 
						dPower[i] += gBeamPathINI.m_sBeampath.dPowOffsetVoltage1[m_sProcessPowerMeasure.nMask];
					else
						dPower[i] += gBeamPathINI.m_sBeampath.dPowOffsetVoltage2[m_sProcessPowerMeasure.nMask];
				}

				MeasureWait(SLEEP_TIME);	// Unit sec

				if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
				{
					MeasureLaserOff();
					return 0.0;
				}
			}
			MeasureLaserOff();
		
			dFinalResultPower = CalculateAverageOnePower(dPower, nPoint);
		
			UpdateResult(dFinalResultPower, nPoint);

			if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
				return 0.0;

			m_nDeltaAttenPos = 100;
			if(m_bCompensationMode)
			{
				if(CheckCompensationRepeat(nPoint))
					break;

	
					m_dDeltaDuty = GetCompensationOffset(nPowerTryCnt, dFinalResultPower);
					if(m_dDeltaDuty == 999)
					{
						ErrMessage(_T("Check POWER STEP VAL is under 5us."));
						break;
					}
					m_dNewDutyOffset += m_dDeltaDuty;
				
			

				m_dOldPower = dFinalResultPower;

				SetMeasureTime(TRUE, 0.0);
			}
		}
		
			
	}while(/*m_bCompensationMode && nPowerTryCnt <= gProcessINI.m_sProcessPowerMeasure.nConpensationLimitCount*/false);

	if(m_dDeltaDuty == 999 || (m_nDeltaAttenPos <= 1 && m_nDeltaAttenPos >= -1))
	{
		return FALSE;
	}
#ifndef __TEST__
	if(!m_bCompensationMode)
	{
		if (dFinalResultPower < m_sProcessPowerMeasure.dMinAllowable)
		{
			MeasureLaserOff();
	//			::MessageDlg(STDGNALM707, MB_ICONSTOP);      //���������� Under �ϸ�
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						ErrMsgDlg(STDGNALM781);
						return FALSE;
					}
				}
			}
			ErrMsgDlg(STDGNALM707);
		}
		else if (dFinalResultPower > m_sProcessPowerMeasure.dMaxAllowable)
		{
			MeasureLaserOff();
	//			::MessageDlg(STDGNALM708, MB_ICONSTOP);      //���������� over �ϸ�
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						ErrMsgDlg(STDGNALM781);
						return FALSE;
					}
				}
			}
			ErrMsgDlg(STDGNALM708);
		}
	}
#endif
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return 0.0;
	
	return TRUE;
}

void CPaneManualControlPowerMeasurement::ResultViewText(double dAverage, int i)
{
	CString strTemp;
	strTemp.Format(_T("%0.1f"), dAverage);
	GetDlgItem(i)->SetWindowText(strTemp);
}

BOOL CPaneManualControlPowerMeasurement::UpdateSubToolParam(SUBTOOLDATA subdata, double dOffsetDuty, int nShotCount)
{
	ASSERT(m_pEOCard != NULL);

	m_pEOCard->GetParameter(&m_NewParameter);

	CString strData;
	m_NewParameter.Frequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subdata.nMask];
	double dCurrent = 0, dAOMDelay = 0, dAOMDuty = 0;
	int nThermalTrack = 0;

	int nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subdata.nMask];

	BOOL bRet = TRUE;
	double dMaskDutyOffset = 0;//m_sProcessPowerMeasure.dDutyOffset; 
	double dMaskAOMDelayOffset = m_sProcessPowerMeasure.dAOMDelayOffset;
	double dMaskAOMDutyOffset = m_sProcessPowerMeasure.dAOMDutyOffset;
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[m_sProcessPowerMeasure.nMask];
	BOOL bUseAom = gVariable.m_sgShotGroupTable.bUseAom[nSelectShotIndex];

	if(bUseAom)
		m_NewParameter.dDuty = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nSelectShotIndex];
	else
		m_NewParameter.dDuty = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOnTime_M[subdata.nMask];

	strData.Format(_T("%s"), m_sProcessPowerMeasure.cAOMFilePath);
	memcpy(m_NewParameter.cAOMFilePath, strData, strData.GetLength() + 1);



	double dOnOffsetMaster = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_M[nShotCount] + gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset2_M[nShotCount];
	double dOnOffsetSlave = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_S[nShotCount] + gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset2_S[nShotCount];


	double dInserted_WaitOffsetM = 0;
	double dInserted_WaitOffsetS = 0;

	if(gVariable.m_bGrobalDutyOffsetCompenMode == TRUE)
	{
		//dOnOffsetMaster += dOffsetDuty;//20171018
		//dOnOffsetSlave += dOffsetDuty;
		if(bUseAom)
		{
			dOnOffsetMaster += dOffsetDuty;//20171018
			dOnOffsetSlave += dOffsetDuty;
		}
		else
		{
			m_NewParameter.dDuty += (dOffsetDuty + dOnOffsetMaster);
		}
	}
	else
	{
		dInserted_WaitOffsetM = dOffsetDuty;
		dInserted_WaitOffsetS = dOffsetDuty;
	}
	return bRet && m_pEOCard->SetParameter(&m_NewParameter, m_sProcessPowerMeasure.nMask,dOnOffsetMaster,dOnOffsetSlave,nShotCount,dInserted_WaitOffsetM,dInserted_WaitOffsetS);
}
BOOL CPaneManualControlPowerMeasurement::UpdateNewParam(double dOffsetDuty)
{
	ASSERT(m_pEOCard != NULL);

	m_pEOCard->GetParameter(&m_NewParameter);

	CString strData;
	m_NewParameter.Frequency = m_sProcessPowerMeasure.nFrequency;
	double dCurrent = 0, dAOMDelay = 0, dAOMDuty = 0;
	int nThermalTrack = 0;
	
	BOOL bRet = 0;
	double dMaskDutyOffset = 0;//m_sProcessPowerMeasure.dDutyOffset; 
	double dMaskAOMDelayOffset = m_sProcessPowerMeasure.dAOMDelayOffset;
	double dMaskAOMDutyOffset = m_sProcessPowerMeasure.dAOMDutyOffset;
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[m_sProcessPowerMeasure.nMask];


	int nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nMask];
	gVariable.m_sgShotGroupTable.dVoltage_M[nSelectShotIndex] = m_sProcessPowerMeasure.dVoltage_M;
	gVariable.m_sgShotGroupTable.dVoltage_S[nSelectShotIndex] = m_sProcessPowerMeasure.dVoltage_S;
	BOOL bUseAom = gVariable.m_sgShotGroupTable.bUseAom[nSelectShotIndex];



	

		if(bUseAom)
			m_NewParameter.dDuty = m_sProcessPowerMeasure.dPulseWidth;
		else
			m_NewParameter.dDuty = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOnTime_M[m_sProcessPowerMeasure.nPulseNum];

		strData.Format(_T("%s"), m_sProcessPowerMeasure.cAOMFilePath);
		memcpy(m_NewParameter.cAOMFilePath, strData, strData.GetLength() + 1);

	

	int nPulseNo = m_cmbPulse.GetCurSel();

	gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_M[nPulseNo] = m_sProcessPowerMeasure.dDutyOffset;
	gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_S[nPulseNo] = m_sProcessPowerMeasure.dDutyOffset;

	double dOnOffsetMaster = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_M[nPulseNo] + gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset2_M[nPulseNo];
	double dOnOffsetSlave = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset_S[nPulseNo] + gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dOntimeOffset2_S[nPulseNo];

	//dOnOffsetMaster += dOffsetDuty;//20171018
	//dOnOffsetSlave += dOffsetDuty;
	if(bUseAom)
	{
		dOnOffsetMaster += dOffsetDuty;
		dOnOffsetSlave += dOffsetDuty;
	}
	else
	{	
		m_NewParameter.dDuty += (dOnOffsetMaster + dOffsetDuty);
	}
	
	double dInserted_WaitOffsetM = 0;
	double dInserted_WaitOffsetS = 0;


	//dOnOffsetMaster += dOffsetDuty;//20171018
	//dOnOffsetSlave += dOffsetDuty;



	return m_pEOCard->SetParameter(&m_NewParameter, m_sProcessPowerMeasure.nMask,dOnOffsetMaster,dOnOffsetSlave,nPulseNo,dInserted_WaitOffsetM,dInserted_WaitOffsetS);
}

void CPaneManualControlPowerMeasurement::SetEditBoxActive(int i)
{
	GetDlgItem(i)->SetFocus();
	CEdit* pEdit = static_cast<CEdit*>(GetDlgItem(i));
	pEdit->SetSel(0, -1);
}

void CPaneManualControlPowerMeasurement::MakeThreadClear()
{
	m_pThread = NULL;
	if (m_ThreadParam.pHandle[0] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[0]);
	if (m_ThreadParam.pHandle[1] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[1]);
	if (m_ThreadParam.pHandle[2] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_ThreadParam.pHandle[2]);
	m_ThreadParam.pHandle[0] = m_ThreadParam.pHandle[1]
		= m_ThreadParam.pHandle[2] = INVALID_HANDLE_VALUE;
}


void CPaneManualControlPowerMeasurement::CalculateAveragePower()
{
	int nSel = m_cmbHead.GetCurSel();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		nSel = 1;

	if (m_bMeasureComplete || m_bLongTermCheck)
	{
		if (nSel == 0)
		{
			m_dMasterAvrPower = m_dSlaveAvrPower = 0.0;
			int nCount1 = 0, nCount2 = 0;
			int i = 0;
			for (nCount1 = 0, nCount2 = 0, i = 0; i < 25; i++)
			{
				if (m_b1stPower[i])
				{
					nCount1++;
					m_dMasterAvrPower += m_pPowerMeasure[i].dVal;
				}
				if (m_b2ndPower[i])
				{
					nCount2++;
					m_dSlaveAvrPower += m_pPowerMeasure[i + 25].dVal;
				}
			}
			if (nCount1)
				m_dMasterAvrPower /= static_cast<double>(nCount1);
			
			if (nCount2)
				m_dSlaveAvrPower /= static_cast<double>(nCount2);
		}
		else if (nSel == 1)
		{
			m_dMasterAvrPower = 0.0;
			int nCount1 = 0, i = 0;
			for (nCount1 = 0, i = 0; i < 25; i++)
			{
				if (m_b1stPower[i])
				{
					nCount1++;
					m_dMasterAvrPower += m_pPowerMeasure[i].dVal;
				}
			}
			if (nCount1)
				m_dMasterAvrPower /= static_cast<double>(nCount1);
		}
		else
		{
			m_dSlaveAvrPower = 0.0;
			int nCount2 = 0, i = 25;
			for (nCount2 = 0, i = 25; i < 50; i++)
			{
				if (m_b2ndPower[i - 25])
				{
					nCount2++;
					m_dSlaveAvrPower += m_pPowerMeasure[i].dVal;
				}
			}
			if (nCount2)
				m_dSlaveAvrPower /= static_cast<double>(nCount2);
		}
	}
}
void CPaneManualControlPowerMeasurement::SaveAllResult(CTime cStartTime, CTime cEndTime, double dDrillTime)
{
	CString strEvent, strInfo;
	strEvent = _T("Finished the process of measuring of power.");


	
		strInfo.Format(_T("Master Power Average = %f | Slave Power Average = %f | Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Duty = %.1f um | AOM Delay = %.1f um | AOM Duty = %.1f um | Beam Path No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm | Duty Offset = %.1f um | AOM Delay Offset = %.1f um | AOM Duty Offset = %.1f um | Duty Compensation = %.1f um"),
			m_dMasterAvrPower, m_dSlaveAvrPower, m_sProcessPowerMeasure.dMinAllowable, m_sProcessPowerMeasure.dMaxAllowable, m_sProcessPowerMeasure.nFrequency, m_sProcessPowerMeasure.dPulseWidth, 
			m_sProcessPowerMeasure.dAOMDelay, m_sProcessPowerMeasure.dAOMDuty, m_sProcessPowerMeasure.nMask, m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight,
			m_sProcessPowerMeasure.dDutyOffset, m_sProcessPowerMeasure.dAOMDelayOffset,
			m_sProcessPowerMeasure.dAOMDutyOffset, gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[m_sProcessPowerMeasure.nMask]);
	
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

	
	SavePowerTrend();
	SavePowerTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
		cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
		cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
		cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillTime, POWER_JOB);
	
	gOPCParam.dPowerMeasure[0] = m_dMasterAvrPower;
	gOPCParam.dPowerMeasure[1] = m_dSlaveAvrPower;

	int nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nMask];
	int nPulseNo = m_cmbPulse.GetCurSel();
	
	gOPCParam.dPowerTarget[0] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[m_sProcessPowerMeasure.nMask];
	gOPCParam.dPowerTarget[1] = gBeamPathINI.m_sBeampath.dPowCompensationTarget[m_sProcessPowerMeasure.nMask];
	gOPCParam.dPowerTargetMin[0] = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dTargetMin_M[nPulseNo];
	gOPCParam.dPowerTargetMin[1] = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dTargetMin_M[nPulseNo];
	gOPCParam.dPowerTargetMax[0] = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dTargetMax_M[nPulseNo];
	gOPCParam.dPowerTargetMax[1] = gVariable.m_sgShotGroupTable.m_sShotParam[nSelectShotIndex].dTargetMax_M[nPulseNo];

//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_POWER);
}
void CPaneManualControlPowerMeasurement::SavePowerTrend()
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strPathName += _T("PowerTrend");
	CTime curDate = CTime::GetCurrentTime();
	

	int nSelectBeamPathIndex = m_sProcessPowerMeasure.nMask;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nMask];

	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	TRY
	{
		file.SeekToEnd();
		CString strBuf;


		

#ifdef __SERVO_MOTOR__
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f| %.2f | %d | %.1f | %d, %d, %d, %d | %.2f | %.2f | %.2f | %.2f | %.2f | %.2f "),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				m_dMasterAvrPower, m_dSlaveAvrPower,
				m_sProcessPowerMeasure.nFrequency, m_sProcessPowerMeasure.dPulseWidth, 
				m_sProcessPowerMeasure.nMask, 
				gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_sProcessPowerMeasure.nMask], 
				gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_sProcessPowerMeasure.nMask],
				gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_sProcessPowerMeasure.nMask] ,
				m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight, 
				m_sProcessPowerMeasure.dMinAllowable, 
				m_sProcessPowerMeasure.dMaxAllowable, 
			
				m_sProcessPowerMeasure.dVoltage_M,
				m_sProcessPowerMeasure.dVoltage_S);

			strBuf = strBuf + "|";
			for(int i = 0; i < MEASURE_REPEAT - 2; i++)
			{
				CString strPower;
				strPower.Format(_T(" ,%.2f"),m_dEachPowerMaster[i]);
				strBuf = strBuf + strPower;
			}
			strBuf = strBuf + "|";
			for(int i = 0; i < MEASURE_REPEAT - 2; i++)
			{
				CString strPower;
				strPower.Format(_T(" ,%.2f"),m_dEachPowerSlave[i]);
				strBuf = strBuf + strPower;
			}
			strBuf = strBuf + "\n";
#else
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f | %d , %d | %.2f | %.2f | %.2f | %.2f | %.2f | %.2f"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				m_dMasterAvrPower, m_dSlaveAvrPower,
				m_sProcessPowerMeasure.nFrequency, m_sProcessPowerMeasure.dPulseWidth,
				m_sProcessPowerMeasure.nMask,
				gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_sProcessPowerMeasure.nMask], 
				m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight,
				m_sProcessPowerMeasure.dMinAllowable, 
				m_sProcessPowerMeasure.dMaxAllowable,
				m_sProcessPowerMeasure.dVoltage_M,
				m_sProcessPowerMeasure.dVoltage_S);
			strBuf = strBuf + " |";
			for(int i = 0; i < MEASURE_REPEAT - 2; i++)
			{
				CString strPower;
				strPower.Format(_T(" ,%.2f"),m_dEachPowerMaster[i]);
				strBuf = strBuf + strPower;
			}
			strBuf = strBuf + "|";
			for(int i = 0; i < MEASURE_REPEAT - 2; i++)
			{
				CString strPower;
				strPower.Format(_T(" ,%.2f"),m_dEachPowerSlave[i]);
				strBuf = strBuf + strPower;
			}
			strBuf = strBuf + "\n";
#endif

		
		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
	file.Close();

	

}

void CPaneManualControlPowerMeasurement::ProcessMeasureStop()
{
	MeasureLaserOff();
	m_bMeasureComplete = true;
	::SetEvent(m_ThreadParam.pHandle[2]);

	DWORD dwRetCode = ::WaitForSingleObject(m_ThreadParam.pHandle[1], 1000);

	if (dwRetCode != WAIT_OBJECT_0)
	{
		MakeThreadClear();
	}
	int nSelectBeamPathIndex = m_sProcessPowerMeasure.nMask;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nMask];

	((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);// 20090629 Front Mode error
//	 gDeviceFactory.GetMotor()->MotorShutterAll(FALSE, FALSE);

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
	 gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

	 if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		 if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
		 {
			 if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			 {
				 ErrMsgDlg(STDGNALM781);
				 return;
			 }
		}
	 }
#ifndef __TEST__
	::Sleep(100);
#endif
				
	EnablePowerLocationButton(TRUE);
	this->SendMessage(UM_RESOURCE_CONTROL, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);
				
	CString strEvent, strInfo;
	strEvent = _T("Stopped measuring of laser power on account of system failure or user's stop event.");
	

		strInfo.Format(_T("Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Pulse Width = %f %% | Mask No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm"),
			m_sProcessPowerMeasure.dMinAllowable, m_sProcessPowerMeasure.dMaxAllowable, m_sProcessPowerMeasure.nFrequency, m_sProcessPowerMeasure.dPulseWidth, m_sProcessPowerMeasure.nMask, m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight);
	
	
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	
	::SetEvent(g_hDoPowerManual);

//	time_t	timeEnd;
//	time(&timeEnd);
//	gProcessINI.m_sProcessPowerMeasure.nMeasureTime = timeEnd;
}

void CPaneManualControlPowerMeasurement::SetMeasureTime(BOOL bIsInit, double dTime)
{
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return;
	
	if (bIsInit)
	{
		double dTimeMax = PREHEATTIME + (MEASURE_REPEAT * MEASURETIME);
		dTimeMax += MEASURE_REPEAT * SLEEP_TIME;
		m_dMeasureTime = 0.0;
		m_progTime.SetRange32(0, static_cast<int>(dTimeMax * 100 + 0.5));
		m_progTime.SetPos(0);
	}
	else
		m_progTime.SetPos(static_cast<int>(dTime * 100 + 0.5));
}

void CPaneManualControlPowerMeasurement::GalvoStepMove(int i)
{
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return;

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				ErrMsgDlg(STDGNALM781);
				return;
			}
			if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
			{
				// Set Cal Apply error 
				ErrMsgDlg(STDGNALM607);
				return;
			}
		}
	}

	if (0 <= i && i < 25)
		gDeviceFactory.GetEocard()->jump_Use_vm(m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos, 
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos,
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos,
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos, TRUE);
	else if (25 <= i && i < 50)
		gDeviceFactory.GetEocard()->jump_Use_vm(m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos, 
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos,
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos,
		m_pPowerMeasure[i].xGalvoPos, m_pPowerMeasure[i].yGalvoPos, TRUE);
}

bool CPaneManualControlPowerMeasurement::PreHeatWait(BOOL bIsOff, double dTime)
{
	BOOL bIsDspBusy = TRUE;
	while(bIsDspBusy)
		bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();

	MeasureLaserOn();
	
	bool bWait;
	
	if (bIsOff)
	{
		MeasureLaserOn();
		bWait = Wait(dTime);

		MeasureLaserOff();
		bWait = Wait(dTime/2);

		MeasureLaserOn();
		bWait = Wait(dTime);
	}
	else
	{
		MeasureLaserOn();
		bWait = Wait(dTime);
	}
	
	return bWait;
}

bool CPaneManualControlPowerMeasurement::MeasureWait(double dTime)
{
	return Wait(dTime);
}

double CPaneManualControlPowerMeasurement::MeasureDuringWait(double dTime, int nDivide)
{
	double dResult = 0;
	if(nDivide != 0)
	{
		double dMeasureResult = 0;
		double dTemp;
		int nFailCount = 0;
		for(int i = 0; i < nDivide; i++)
		{
			Wait(dTime/nDivide);
			dTemp = Measure();
			if(dTemp == 0)
				nFailCount++;
			else
				dMeasureResult += Measure();
		}

		dResult = dMeasureResult/(nDivide - nFailCount);
	}
	UpdateResult_Sub(dResult);
	return dResult;
}

bool CPaneManualControlPowerMeasurement::Wait(double dTime)
{
#ifndef __TEST__
	CCorrectTime pTimer;
	pTimer.StartTime();
	double dPreHeatTime = 0, dOldTime = m_dMeasureTime;
	int nSleepTime = static_cast<int>(dTime * 20.0 + 0.5);
	
	while (dPreHeatTime <= dTime && ::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_TIMEOUT)
	{
		MessageLoop();
		dPreHeatTime = pTimer.PresentTime();
		m_dMeasureTime = dOldTime + dPreHeatTime;
		SetMeasureTime(FALSE, m_dMeasureTime);
		::Sleep(nSleepTime);
	}
#endif
	if (::WaitForSingleObject(m_ThreadParam.pHandle[1], 0) == WAIT_OBJECT_0)
		return false;
	else
		return true;
}


void CPaneManualControlPowerMeasurement::MeasureLaserOn()
{
	gDeviceFactory.GetEocard()->LaserOnOff(TRUE);
}

void CPaneManualControlPowerMeasurement::MeasureLaserOff()
{
	gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
}

void CPaneManualControlPowerMeasurement::MessageLoop()
{
	MSG msg;
	
	if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		TranslateMessage((LPMSG)&msg);
		DispatchMessage((LPMSG)&msg);
	}
}

UINT ThreadProc(LPVOID lParam)
{
	MEASURETHREADPARAM* pParam = static_cast<MEASURETHREADPARAM*>(lParam);
	CPaneManualControlPowerMeasurement* pThreadDlg = pParam->pParent;
	HANDLE* pHandle = pParam->pHandle;
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();
	
	CCorrectTime dDrillTime, dLongTermTime;
	double dDrillSec, dLongTermSec = 0;
	dDrillTime.StartTime();
	dLongTermTime.StartTime();
	CTime cStartTime, cEndTime, cLongTermStartTime;
	cStartTime = CTime::GetCurrentTime();

	pThreadDlg->m_dNewDutyOffset1 = 0;
	pThreadDlg->m_dNewDutyOffset2 = 0;

	pThreadDlg->m_dNewOntimeOffset1 = 0;
	pThreadDlg->m_dNewOntimeOffset2 = 0;

	if(!pThreadDlg->m_bLongTermCheck)
		pThreadDlg->m_sProcessPowerMeasure.nLongTermTotalTime = 0;

	int nLongTermTotalTime =  pThreadDlg->m_sProcessPowerMeasure.nLongTermTotalTime * 60;

	do
	{
		DWORD dwRetCode = ::WaitForMultipleObjects(3, pHandle, FALSE, INFINITE);
		pThreadDlg->m_btnStop.EnableWindow(TRUE);
		if (dwRetCode == WAIT_OBJECT_0)
			::ResetEvent(pHandle[0]);
		else
		{
			pThreadDlg->ProcessMeasureStop();
			return 0;
		}
				
		pThreadDlg->SetMeasureTime(TRUE, 0.0);

		if(pThreadDlg->m_bCompensationMode)
		{
			for (int i = 0; i < 25; ++i)
			{
				if(!pThreadDlg->MeasureOnePoint(i))
					return 0;

				if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pThreadDlg->ProcessMeasureStop();
					return 0;
				}
			}
		}
		else
		{

			if(gProcessINI.m_sProcessOption.bSlaveMeasureStart == FALSE)
			{
				for (int i = pThreadDlg->m_nStart; i < pThreadDlg->m_nEnd; ++i)
				{
					//TRACE("%d\n",i);
						if(!pThreadDlg->MeasureOnePoint(i))
							return 0;

					if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pThreadDlg->ProcessMeasureStop();
						return 0;
					}
				}
			}
			else
			{
				for (int i = pThreadDlg->m_nEnd-1; i >= pThreadDlg->m_nStart; --i)
				{
					//TRACE("%d\n",i);
						if(!pThreadDlg->MeasureOnePoint(i))
							return 0;

					if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pThreadDlg->ProcessMeasureStop();
						return 0;
					}
				}
			}
		}

		pThreadDlg->MeasureLaserOff();
		
		if(pThreadDlg->m_bLongTermCheck)
		{
			::SetEvent(pHandle[0]);
		}
		else
			pThreadDlg->m_bMeasureComplete = true;


		pThreadDlg->CalculateAveragePower();

		cEndTime = CTime::GetCurrentTime();
		dDrillSec = dDrillTime.PresentTime();
		pThreadDlg->SaveAllResult(cStartTime, cEndTime, dDrillSec);
				
		int nSleepCount = 0;
		if(pThreadDlg->m_bLongTermCheck)
		{	
			if(!pThreadDlg->WaitLongTerm(nSleepCount, pHandle))
				return 0;
		}

		dLongTermSec = dLongTermTime.PresentTime();


	}while(pThreadDlg->m_bLongTermCheck && dLongTermSec <= nLongTermTotalTime);

	if(pThreadDlg->m_bCompensationMode)
	{
		pThreadDlg->AddCompensationResult();
	}	 

	pThreadDlg->m_bMeasureComplete = true;
	::SetEvent(pHandle[2]);

	pDlg->ShutterMove(FALSE, FALSE); 

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

	pThreadDlg->MakeThreadClear();
	pThreadDlg->SendMessage(UM_RESOURCE_CONTROL, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
	pThreadDlg->EnablePowerLocationButton(TRUE);
	::AfxGetMainWnd()->SendMessage(UM_LOCK_BUTTON, FALSE);

	CString strLog;
	strLog.Format(_T("Finish Power Measure"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	::SetEvent(g_hDoPowerManual);
	return 1;
}


void CPaneManualControlPowerMeasurement::ConnectPort()
{
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
	{
		m_Serial.SetParameter(gSystemINI.m_sSystemDevice.sPowermeterPort.nPortNo, gSystemINI.m_sSystemDevice.sPowermeterPort.nBaudRate, gSystemINI.m_sSystemDevice.sPowermeterPort.nParity, gSystemINI.m_sSystemDevice.sPowermeterPort.nDataBits, gSystemINI.m_sSystemDevice.sPowermeterPort.nStopBits, gSystemINI.m_sSystemDevice.sPowermeterPort.nFlowControl);
		
#ifndef __TEST__
		if (!m_Serial.PortOpened())
		{
			if(!m_Serial.Create())
			{
				ErrMessage(_T("Power Measure Port Connect Failure"));
			}
		}
#endif
	}
}

void CPaneManualControlPowerMeasurement::DisconnectPort()
{
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
	{
#ifndef __TEST__
		if(m_Serial.PortOpened())
			m_Serial.Destroy();
#endif
	}
}

void CPaneManualControlPowerMeasurement::SetCompensation()
{
	return;
}

void CPaneManualControlPowerMeasurement::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	CFormView::OnTimer(nIDEvent);
}

LRESULT CPaneManualControlPowerMeasurement::OnResourceControl(WPARAM wParam, LPARAM lParam)
{
	EnableControl((BOOL)wParam);
	return 1L;
}

LRESULT CPaneManualControlPowerMeasurement::OnStartCompensation(WPARAM wParam, LPARAM lParam)
{
	CTime st, et;
	st = CTime::GetCurrentTime();
	CTimeSpan diff;
	int nTime; 
	while(1)
	{
		et = CTime::GetCurrentTime();
		diff = et - st;
		nTime = (int)diff.GetTotalMinutes();
		
		if(nTime > 0)
			break;
		
		::Sleep(10);
		MessageLoop();
	}
	OnButtonMeasureStart();
	return 1L;
}

double CPaneManualControlPowerMeasurement::MeasuerPower()
{
	TCHAR szTemp[100];
	m_Serial.SetCmdSize(5);
	strcpy_s(szTemp, m_Serial.QueryCommand((LPSTR)(LPCTSTR)"$SP"));
	double dTemp = ConvertDouble(szTemp);
	return dTemp;
}

void CPaneManualControlPowerMeasurement::EnableControl(BOOL bEnable)
{
	m_cmbTool.EnableWindow(bEnable);
	m_cmbPulse.EnableWindow(bEnable);

	m_cmbHead.EnableWindow(bEnable);
	m_cmbMeasurementMode.EnableWindow(bEnable);
	
	m_btnMeasureStart.EnableWindow(bEnable);
	m_btnStop.EnableWindow(bEnable);
	m_edt1stHead.EnableWindow(bEnable);
	m_edt2ndHead.EnableWindow(bEnable);

	if(m_nUserLevel != 0)
	{
		m_edtFreq.EnableWindow(bEnable);
		//m_edtDuty.EnableWindow(bEnable);
		m_edtAOMDelay.EnableWindow(bEnable);
		m_edtAOMDuty.EnableWindow(bEnable);

		m_chkUseCompensation.EnableWindow(bEnable);
		m_edtCompensationTargetMin.EnableWindow(bEnable);
		m_edtCompensationTargetMax.EnableWindow(bEnable);
		m_chkUseLongTermCheck.EnableWindow(bEnable);
		m_edtLongTermCheckTime.EnableWindow(bEnable);
		m_edtLongTermCheckPeriod.EnableWindow(bEnable);
		m_edtLongTermCheckDummyOnTime.EnableWindow(bEnable);
		m_edtCompensationTargetPercent.EnableWindow(bEnable);
		m_edtCompensationTarget.EnableWindow(bEnable);
		m_edtDutyOffset.EnableWindow(bEnable);
		m_edtDutyOffset2.EnableWindow(bEnable);
		m_edtVoltage_M.EnableWindow(bEnable);
		m_edtVoltage_S.EnableWindow(bEnable);
		m_edtOnTime.EnableWindow(bEnable);
	}
	else
	{
		m_edtFreq.EnableWindow(FALSE);
		m_edtDuty.EnableWindow(FALSE);
		m_edtAOMDelay.EnableWindow(FALSE);
		m_edtAOMDuty.EnableWindow(FALSE);
		m_edtDutyOffset.EnableWindow(FALSE);
		m_edtDutyOffset2.EnableWindow(FALSE);
//		m_chkUseCompensation.SetCheck(FALSE);
		m_chkUseCompensation.EnableWindow(FALSE);
		m_chkUseLongTermCheck.SetCheck(FALSE);
		m_chkUseLongTermCheck.EnableWindow(FALSE);
		m_edtCompensationTargetMin.EnableWindow(FALSE);
		m_edtCompensationTargetMax.EnableWindow(FALSE);
		m_edtLongTermCheckTime.EnableWindow(bEnable);
		m_edtLongTermCheckPeriod.EnableWindow(bEnable);
		m_edtLongTermCheckDummyOnTime.EnableWindow(bEnable);
		m_edtCompensationTargetPercent.EnableWindow(FALSE);
		m_edtCompensationTarget.EnableWindow(FALSE);
	m_edtVoltage_M.EnableWindow(FALSE);
		m_edtVoltage_S.EnableWindow(FALSE);
		m_edtOnTime.EnableWindow(FALSE);
	}

	if(m_nUserLevel <= 1)
	{
		m_edtPowerLimitCount.EnableWindow(FALSE);
		m_edtPowerSpecLimit.EnableWindow(FALSE);
		m_edtPowerStep.EnableWindow(FALSE);
		m_edtPowerWaitLimit.EnableWindow(FALSE);
	}
	else
	{
		m_edtPowerLimitCount.EnableWindow(bEnable);
		m_edtPowerSpecLimit.EnableWindow(bEnable);
		m_edtPowerStep.EnableWindow(bEnable);
		m_edtPowerWaitLimit.EnableWindow(bEnable);
	}
	

	

//	m_edtDutyOffset.EnableWindow(bEnable);
	m_edtAOMDelayOffset.EnableWindow(bEnable);
	m_edtAOMDutyOffset.EnableWindow(bEnable);
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_edtCompensationTargetMin.EnableWindow(FALSE);
	m_edtCompensationTargetMax.EnableWindow(FALSE);
#endif
	m_edtOnTime.EnableWindow(FALSE);

#ifdef __NANYA_NEW__
	if(m_nUserLevel == 0)
	{
		m_edtLongTermCheckTime.EnableWindow(FALSE);
		m_edtLongTermCheckPeriod.EnableWindow(FALSE);
		m_edtLongTermCheckDummyOnTime.EnableWindow(FALSE);
		m_edtWaitTime.EnableWindow(FALSE);

		m_edtLongTermCheckDummyOnTime.EnableWindow(FALSE);
		m_edtWaitTime.EnableWindow(FALSE);

		m_edt1stHead.EnableWindow(FALSE);
		m_edt2ndHead.EnableWindow(FALSE);
	}
#endif
}

void CPaneManualControlPowerMeasurement::OnCheckSubUseCompensation() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_bCompensationMode = m_chkUseCompensation.GetCheck();

	if(m_bCompensationMode)
	{
		if(m_chkUseLongTermCheck.GetCheck())
		{
			m_chkUseLongTermCheck.SetCheck(FALSE);
			GetDlgItem(IDC_STATIC_TIME_TOTAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_TIME_TOTAL_H)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_TIME_PERIOD)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_TIME_PERIOD_M)->EnableWindow(FALSE);
			m_edtLongTermCheckTime.EnableWindow(FALSE);
			m_edtLongTermCheckPeriod.EnableWindow(FALSE);
			m_edtLongTermCheckDummyOnTime.EnableWindow(FALSE);
		}
		m_cmbMeasurementMode.SetCurSel( 1 );
		m_cmbMeasurementMode.EnableWindow(FALSE);

		for (int i = 0; i < 25; ++i)
		{
			DisplayAndCheck(IDC_CHECK_1ST_P0 + i, FALSE);
			DisplayAndCheck(IDC_CHECK_2ND_P0 + i, FALSE);

			GetDlgItem(IDC_CHECK_1ST_P0 + i)->EnableWindow(FALSE);
			GetDlgItem(IDC_CHECK_2ND_P0 + i)->EnableWindow(FALSE);
		}

		int nSel = m_cmbHead.GetCurSel();

		if(nSel == 0 || nSel == 1)
		{
			DisplayAndCheck( IDC_CHECK_1ST_P12, 1 );
			m_b1stPower[12] = 1;
			GetDlgItem(IDC_CHECK_1ST_P12)->EnableWindow(TRUE);
		}

		if(nSel == 0 || nSel == 2)
		{
			DisplayAndCheck( IDC_CHECK_2ND_P12, 1 );
			m_b2ndPower[12] = 1;
			GetDlgItem(IDC_CHECK_2ND_P12)->EnableWindow(TRUE);
		}
	}
	else
	{
		m_cmbHead.EnableWindow(TRUE);
		m_cmbMeasurementMode.EnableWindow(TRUE);

		OnSelectHeadCombo();

		m_cmbMeasurementMode.SetCurSel( 1 );
	}
}

void CPaneManualControlPowerMeasurement::OnCheckSubUseLongTermCheck() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_bLongTermCheck = m_chkUseLongTermCheck.GetCheck();

	if(m_bLongTermCheck)
	{
		if(m_chkUseCompensation.GetCheck())
		{
			m_chkUseCompensation.SetCheck(FALSE);	
		}
		GetDlgItem(IDC_STATIC_TIME_TOTAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_TIME_TOTAL_H)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_TIME_PERIOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_TIME_PERIOD_M)->EnableWindow(TRUE);
		m_edtLongTermCheckTime.EnableWindow(TRUE);
		m_edtLongTermCheckPeriod.EnableWindow(TRUE);
		m_edtLongTermCheckDummyOnTime.EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_TIME_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TIME_TOTAL_H)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TIME_PERIOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TIME_PERIOD_M)->EnableWindow(FALSE);
		m_edtLongTermCheckTime.EnableWindow(FALSE);
		m_edtLongTermCheckPeriod.EnableWindow(FALSE);
		m_edtLongTermCheckDummyOnTime.EnableWindow(FALSE);
	}
}

BOOL CPaneManualControlPowerMeasurement::InPositionCheck()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2 + IND_TOPHAT);
		else
			return pMotor->InPositionIO(IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_A1 + IND_A2 + IND_TOPHAT );
	}
	else // not use M, C
	{
		if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
			return pMotor->InPositionIO(IND_Z1 + IND_M1 + IND_C1 + IND_C2 + IND_A1 + IND_A2 + IND_TOPHAT);
		else
			return pMotor->InPositionIO(IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_A1 + IND_A2 + IND_TOPHAT);
	}
	return TRUE;
}

int CPaneManualControlPowerMeasurement::GetUseTool()
{
	return m_cmbTool.GetCurSel();
}

void CPaneManualControlPowerMeasurement::SetToolComboBox()
{
	m_cmbTool.ResetContent();
	
	CString strTool;

	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbTool.AddString(strTool);
	}

	//if(nBeamPathNo >= 0)
		UpdatePulseCombo(m_nSelectShotIndex);
//	if(gBeamPathINI.m_sBeampath.nLastIndex >= m_sProcessPowerMeasure.nUseTool && m_sProcessPowerMeasure.nUseTool >= 0)
//	{
//		m_cmbTool.SetCurSel(m_sProcessPowerMeasure.nUseTool);
//		ChangeLaserParam(m_sProcessPowerMeasure.nUseTool);
//	}
//	else
//		m_sProcessPowerMeasure.nUseTool = -1;


	SUBTOOLDATA subTool;
	BOOL bProjectOpen = FALSE;
	int nMainTool = CheckMainTool();

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		/*if( i <= 1)
			continue;*/

		if(nMainTool != i)
			continue;

		for(int j = 0; j < gDProject.m_pToolCode[i]->m_SubToolData.GetCount(); j++)
		{
			if(gDProject.GetSubTool(i, j, subTool))
			{
				m_sProcessPowerMeasure.nUseTool = subTool.nMask;
				m_cmbTool.SetCurSel(m_sProcessPowerMeasure.nUseTool);
				
				m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];//20160404
				m_nSelectBeamPathIndex = m_sProcessPowerMeasure.nUseTool;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nUseTool];
					
				ChangeLaserParam(m_sProcessPowerMeasure.nUseTool);
				UpdatePulseCombo(m_nSelectShotIndex);
				bProjectOpen = TRUE;
			}
			if(bProjectOpen)
				return;
		}
	}
	if(!bProjectOpen)
		m_sProcessPowerMeasure.nUseTool = 0;

}

void CPaneManualControlPowerMeasurement::OnSelchangeComboTool() 
{
	// TODO: Add your control notification handler code here	int nBeamPathNo = m_cmbTool.GetCurSel();
	int nBeamPathNo = m_cmbTool.GetCurSel();
	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nBeamPathNo];//20160404
	if(nBeamPathNo >= 0)
		UpdatePulseCombo(m_nSelectShotIndex);
		ChangeLaserParam(nBeamPathNo);

	m_sProcessPowerMeasure.nUseTool = nBeamPathNo;
}

void CPaneManualControlPowerMeasurement::OnSelchangeComboPulse() 
{
	// TODO: Add your control notification handler code here
	m_sProcessPowerMeasure.nPulseNum = m_cmbPulse.GetCurSel();
	int nBeamPathNo = m_cmbTool.GetCurSel();
	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nBeamPathNo];//20160404
	ChangeLaserParam(nBeamPathNo);
}

void CPaneManualControlPowerMeasurement::ChangeLaserParam(int nIndex)
{
	if(nIndex > gBeamPathINI.m_sBeampath.nLastIndex)
		return;

	CString str;
	
	
	/*
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex]);
	m_edtDuty.SetWindowText( str );
	
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nIndex]);
	m_edtAOMDelay.SetWindowText( str );
	
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nIndex]);
	m_edtAOMDuty.SetWindowText( str );
	
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowOffsetDuty[nIndex]);
	m_edtDutyOffset.SetWindowText( str );
	
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[nIndex]);
	m_edtAOMDelayOffset.SetWindowText( str );
	
	str.Format(_T("%.1f"), gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[nIndex]);
	m_edtAOMDutyOffset.SetWindowText( str );

	str.Format(_T("%.2f"), gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nIndex]);
	m_edtCompensationTargetMin.SetWindowText( str );
	
	str.Format(_T("%.2f"), gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nIndex]);
	m_edtCompensationTargetMax.SetWindowText( str );

	str.Format(_T("%.2f"), gBeamPathINI.m_sBeampath.dPowCompensationTarget[nIndex]);
	m_edtCompensationTarget.SetWindowText( str );

	str.Format(_T("%.2f"), gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[nIndex]);
	m_edtCompensationTargetPercent.SetWindowText( str );
*/

	if(m_nSelectShotIndex > gShotTableINI.m_sShotGroupTable.nGroupLastIndex)
		return;


	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dOntimeOffset_M[m_sProcessPowerMeasure.nPulseNum]);
	m_edtDutyOffset.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dOntimeOffset_S[m_sProcessPowerMeasure.nPulseNum]);
	m_edtDutyOffset2.SetWindowText( str );

	//str.Format(_T("%d"), gShotTableINI.m_sShotGroupTable.nShotFrequency[m_nSelectShotIndex]);//20171016
	//m_edtFreq.SetWindowText( str );

	str.Format(_T("%d"), gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex]);
	m_edtFreq.SetWindowText( str );
	
	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[m_nSelectShotIndex]);
	m_edtDuty.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dTargetMin_M[m_sProcessPowerMeasure.nPulseNum]);
	m_edtCompensationTargetMin.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dTargetMax_M[m_sProcessPowerMeasure.nPulseNum]);
	m_edtCompensationTargetMax.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dRefPower[m_sProcessPowerMeasure.nPulseNum]);
	m_edtCompensationTarget.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dPower_Tol[m_sProcessPowerMeasure.nPulseNum]);
	m_edtCompensationTargetPercent.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.dVoltage_M[m_nSelectShotIndex]);
	m_edtVoltage_M.SetWindowText( str );

	str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.dVoltage_S[m_nSelectShotIndex]);
	m_edtVoltage_S.SetWindowText( str );

	BOOL bUseAom =  gShotTableINI.m_sShotGroupTable.bUseAom[m_nSelectShotIndex];

	if(bUseAom)
	{
		str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].m_sAOMParam[m_sProcessPowerMeasure.nPulseNum].dAOM_ON_M[0]);
		m_edtOnTime.SetWindowText( str );
	}
	else
	{
		str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.m_sShotParam[m_nSelectShotIndex].dOnTime_M[m_sProcessPowerMeasure.nPulseNum]);
		m_edtOnTime.SetWindowText( str );
	}

}

void CPaneManualControlPowerMeasurement::GetMeasureData()
{
	CString str;
	m_edtFreq.GetWindowText( str );
	m_sProcessPowerMeasure.nFrequency = atoi(str);
	
	m_edtDuty.GetWindowText( str );
	m_sProcessPowerMeasure.dPulseWidth = atof(str);
	
	m_edtAOMDelay.GetWindowText( str );
	m_sProcessPowerMeasure.dAOMDelay = atof(str);
	
	m_edtAOMDuty.GetWindowText( str );
	m_sProcessPowerMeasure.dAOMDuty = atof(str);
	
	m_edtDutyOffset.GetWindowText( str );
	m_sProcessPowerMeasure.dDutyOffset = atof(str);

	m_edtDutyOffset2.GetWindowText( str );
	m_sProcessPowerMeasure.dDutyOffset2 = atof(str);

	m_edtAOMDelayOffset.GetWindowText( str );
	m_sProcessPowerMeasure.dAOMDelayOffset = atof(str);
	
	m_edtAOMDutyOffset.GetWindowText( str );
	m_sProcessPowerMeasure.dAOMDutyOffset = atof(str);
	
	m_edtCompensationTargetMin.GetWindowText( str );
	m_sProcessPowerMeasure.dMinAllowable = atof(str);
	
	m_edtCompensationTargetMax.GetWindowText( str );
	m_sProcessPowerMeasure.dMaxAllowable = atof(str);

	m_sProcessPowerMeasure.nMask = GetUseTool();

	m_edtLongTermCheckTime.GetWindowText( str );
	m_sProcessPowerMeasure.nLongTermTotalTime = atoi(str);

	m_edtLongTermCheckPeriod.GetWindowText( str );
	m_sProcessPowerMeasure.nLongTermPeriod = atoi(str);

	m_edtLongTermCheckDummyOnTime.GetWindowText( str );
	m_sProcessPowerMeasure.nLongTermDummyOnTime = atoi(str);
	
	m_edtWaitTime.GetWindowText( str );
	m_sProcessPowerMeasure.nMeasureWaitTime = atoi(str);


	//str.Format(_T("%.2f"), gShotTableINI.m_sShotGroupTable.dVoltage_M[m_nSelectShotIndex]);
	m_edtVoltage_M.GetWindowText( str );
	m_sProcessPowerMeasure.dVoltage_M = atoi(str);

	m_edtVoltage_S.GetWindowText( str );
	m_sProcessPowerMeasure.dVoltage_S = atoi(str);



		m_edtPowerStep.GetWindowText( str );
	m_sProcessPowerMeasure.dPowerStep = atof(str);

			m_edtPowerWaitLimit.GetWindowText( str );
	m_sProcessPowerMeasure.dCompensationWaitLimit = atof(str);


}

BOOL CPaneManualControlPowerMeasurement::ChangeBeamPath(int nIndex)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dC1, dC2, dA1, dA2, dM1, dM2, dM3,dM4,dRot,dTopHat; 
	CString strVal, strMaster, strSlave;

	BOOL bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_sProcessPowerMeasure.nUseTool];
	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}
	BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[m_sProcessPowerMeasure.nUseTool];
	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];
	BOOL bUseAom = gVariable.m_sgShotGroupTable.bUseAom[nShotIndex];
	//BOOL bUseAom = gBeamPathINI.m_sBeampath.bBeamPathUseAom[m_sProcessPowerMeasure.nUseTool];

	gVariable.m_nGlobalDummyType = gVariable.m_sgShotGroupTable.nDummyType[nShotIndex];

	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return FALSE;
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[m_sProcessPowerMeasure.nUseTool];
		dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[m_sProcessPowerMeasure.nUseTool];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[m_sProcessPowerMeasure.nUseTool] + m_nNewAttenOffsetPos;
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[m_sProcessPowerMeasure.nUseTool] + m_nNewAttenOffsetPos;

		dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_sProcessPowerMeasure.nUseTool];
	//	if(bTophat)
			dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_sProcessPowerMeasure.nUseTool];
	//	else
	//		dM2 = gBeamPathINI.m_sBeampath.nFixedMask;

		dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_sProcessPowerMeasure.nUseTool];
		dM4 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[m_sProcessPowerMeasure.nUseTool];
		dRot = gBeamPathINI.m_sBeampath.dBeamPathRotator[m_sProcessPowerMeasure.nUseTool];
		dTopHat = gBeamPathINI.m_sBeampath.dBeamPathTopHat[m_sProcessPowerMeasure.nUseTool];
/*
		strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), "zero"));
		strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), "zero"));

		TCHAR sz1stFile[255], sz2ndFile[255];
		lstrcpy(sz1stFile, strMaster);
		lstrcpy(sz2ndFile, strSlave);
		
		if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
			strMsg.Format(strString, "ASC");
			ErrMessage(strMsg);
			return FALSE;
		}
*/

		if(!pMotor->MoveZMCA3_B(	m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight,
			dM1, dM2 , dM3, dM4, dC1, dC2, dRot, dTopHat, TRUE, bTophat))

		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			ErrMessage(strMsg);
			return FALSE;
		}
			
	}
	else // not use M, C
	{
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[m_sProcessPowerMeasure.nUseTool];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[m_sProcessPowerMeasure.nUseTool];

		if(!pMotor->MoveZMC2(m_sProcessPowerMeasure.d1stHeight, m_sProcessPowerMeasure.d2ndHeight, 
			dA1, dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
			ErrMessage(strMsg);
			return FALSE;
		}
	}
	// M, C, Z Inposition
	//Inposition check
	if(!InPositionCheck())
	{
		ErrMessage(_T("Inposition Error"));
		return FALSE;
	}
	return TRUE;
}

void CPaneManualControlPowerMeasurement::ReDrawData_WhenTableChange()
{
	if(m_sProcessPowerMeasure.nUseTool == -1)
		return;

	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];//20160404
	m_nSelectBeamPathIndex = m_sProcessPowerMeasure.nUseTool;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nUseTool];

	ChangeLaserParam(m_sProcessPowerMeasure.nUseTool);

	UpdatePulseCombo(m_nSelectShotIndex);

}
void CPaneManualControlPowerMeasurement::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;

	switch(nLevel)
	{
	case 0:
#ifndef __KUNSAN_SAMSUNG_LARGE__
		GetDlgItem(IDC_STATIC_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_DUTY_OFFSET)->ShowWindow(SW_HIDE);
#endif
		GetDlgItem(IDC_STATIC_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		break;
	case 1:
#ifndef __KUNSAN_SAMSUNG_LARGE__
		GetDlgItem(IDC_STATIC_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_DUTY_OFFSET)->ShowWindow(SW_HIDE);
#endif
		GetDlgItem(IDC_STATIC_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DUTY_OFFSET)->ShowWindow(SW_HIDE);
		break;
	case 2:
	case 3:
		GetDlgItem(IDC_STATIC_OFFSET)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_DUTY_OFFSET)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_DUTY_OFFSET)->ShowWindow(SW_SHOW);

		break;
	}
	EnableControl(TRUE);
}

void CPaneManualControlPowerMeasurement::OnButtonApply() 
{
	int nIndex = m_cmbTool.GetCurSel();
	
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeBeamPath_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}
	
	file.SeekToEnd();

	strDetail = _T("----------------------------------------------------------------------------------------------\n");
	file.Write(strDetail, strDetail.GetLength());

	strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
	file.Write(strDetail, strDetail.GetLength());


	if(gBeamPathINI.m_sBeampath.nLastIndex >= nIndex && nIndex >= 0)
	{
		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nIndex];
		// Freq
		CString strData;
		m_edtFreq.GetWindowText( strData );
		if(gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex] != atoi(strData))
		{
			str.Format(_T("%d Power Compensation Freq : %d -> %d\n"),  nIndex, gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex], atoi(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		gBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex] = atoi(strData);


		m_edtVoltage_M.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex]!= atof(strData))
		{
			str.Format(_T("%d RF_M : %d -> %d\n"),  nShotIndex, gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex], atof(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex] = atof(strData);
		gVariable.m_sgShotGroupTable.dVoltage_M[nShotIndex] = atof(strData);

		m_edtVoltage_S.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex]!= atof(strData))
		{
			str.Format(_T("%d RF_S : %d -> %d\n"),  nShotIndex, gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex], atof(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex] = atof(strData);
		gVariable.m_sgShotGroupTable.dVoltage_S[nShotIndex] = atof(strData);

		m_edtCompensationTarget.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dRefPower[m_sProcessPowerMeasure.nPulseNum]!= atof(strData))
		{
			str.Format(_T("%d Power Target : %d -> %d\n"),  nShotIndex, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dRefPower[m_sProcessPowerMeasure.nPulseNum], atof(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dRefPower[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dRefPower[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		double dRefPower = atof(strData);
		m_edtCompensationTarget.SetWindowText(strData);

		m_edtCompensationTargetPercent.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dPower_Tol[m_sProcessPowerMeasure.nPulseNum]!= atof(strData))
		{
			str.Format(_T("%d Power Tol : %d -> %d\n"),  nShotIndex, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dPower_Tol[m_sProcessPowerMeasure.nPulseNum], atof(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dPower_Tol[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dPower_Tol[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		double dTol = atof(strData);
		m_edtCompensationTargetPercent.SetWindowText(strData);


		//double dRefPower = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[ColCount];
		//double dTol = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[ColCount];
		double dMin,dMax;
		gVariable.GetMinMaxPower(dRefPower,dTol,dMin,dMax);


		strData.Format(_T("%.2f"),dMin);
		m_edtCompensationTargetMin.SetWindowText(strData);
		gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMin_M[m_sProcessPowerMeasure.nPulseNum] = atof(strData);


		strData.Format(_T("%.2f"),dMax);
		m_edtCompensationTargetMax.SetWindowText(strData);
		gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[m_sProcessPowerMeasure.nPulseNum] = atof(strData);
		gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dTargetMax_M[m_sProcessPowerMeasure.nPulseNum] = atof(strData);



		m_edtDutyOffset.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[m_sProcessPowerMeasure.nPulseNum]!= atof(strData))
		{
			str.Format(_T("Shot Index [%d], Pulse Index [%d], Duty Offset M : %.2f -> %.2f\n"),  nShotIndex, m_sProcessPowerMeasure.nPulseNum, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[m_sProcessPowerMeasure.nPulseNum], atof(strData) );
			file.Write(str, str.GetLength());
			((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(str, _T(""));
		}
		double		dBackupOntimeOffset_M[SHOT_COUNT];
		double		dBackupOntimeOffset_S[SHOT_COUNT];

		for(int i = 0; i < MAX_SHOT; i ++)
		{
			dBackupOntimeOffset_M[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i];
			if(m_sProcessPowerMeasure.nPulseNum == i)
				gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i] = atof(strData);
		}
		if(!gVariable.IsValidateTableModulationData(gBeamPathINI.m_sBeampath, gVariable.m_sgShotGroupTable))
		{
			for(int i = 0; i < MAX_SHOT; i ++)
			{
				gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i] = dBackupOntimeOffset_M[i];
			}

			return;	
		}
		for(int i = 0; i < MAX_SHOT; i ++)
		{
			gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i];
		}
		m_edtDutyOffset2.GetWindowText( strData );
		if(gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[m_sProcessPowerMeasure.nPulseNum]!= atof(strData))
		{
			str.Format(_T("%d Duty Offset S : %.2f -> %.2f\n"),  nShotIndex, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[m_sProcessPowerMeasure.nPulseNum], atof(strData) );
			file.Write(str, str.GetLength());
		}
	/*	for(int i = 0; i < MAX_SHOT; i ++)
		{
			gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] = atof(strData);
			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] = atof(strData);
		}*/

		for(int i = 0; i < MAX_SHOT; i ++)
		{
			dBackupOntimeOffset_S[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i];

			gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] = atof(strData);
		}
		if(!gVariable.IsValidateTableModulationData(gBeamPathINI.m_sBeampath, gVariable.m_sgShotGroupTable))
		{
			for(int i = 0; i < MAX_SHOT; i ++)
			{
				gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] = dBackupOntimeOffset_S[i];
			}
			return;	
		}
		for(int i = 0; i < MAX_SHOT; i ++)
		{
			gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i];
		}


		


		file.Close();
//		m_bTopHat = m_chkTopHat.GetCheck();
//		gBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex] = m_bTopHat;
		
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
		
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (MeasurePower) : P"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
		else
		{

			ErrMessage(IDS_DATA_CHANGED);
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SYSTEM_BEAMPATH);

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SHOT_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
		else
		{

			ErrMessage(IDS_DATA_CHANGED);
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SHOT_INI);
	}
}
BOOL CPaneManualControlPowerMeasurement::GetCompensationOffsetNew(double dTarget, double * dResultPower,double dPMin,double dPMax)
{


	BOOL bSuccess = TRUE;
	double dResult = 0;


	int nHeadCount = 0;
	int nStartHead = 0;
	int nEndHead = 2;

	if(m_cmbHead.GetCurSel() == 1)
	{
		nEndHead = 1;
	}
	else if(m_cmbHead.GetCurSel() == 2)
	{
		nStartHead = 1;
	}

	for(int nHeadNo = nStartHead; nHeadNo < nEndHead; nHeadNo++)
	{

		if(dResultPower[nHeadNo] < dPMin || dResultPower[nHeadNo] > dPMax)
		{

			dResult = dResultPower[nHeadNo];
			bSuccess = FALSE;
			CString strM;
			strM.Format(" Head %d  Power NG ",nHeadNo+1);
			UpdateStrResult(strM);
			TRACE("%s\n",strM);

			break;
		}

	}

	if(bSuccess == FALSE)
	{
		BOOL bOver;

		if(dResult < dPMin)
			bOver = FALSE;
		if(dResult > dPMax)
			bOver = TRUE;

		double dPowerGap = fabs(dResult - dTarget);
		double dDeltaPower = 0;
		
		if(gVariable.m_bGrobalDutyOffsetCompenMode == TRUE)
		    dDeltaPower = 0.1;//Duty�� 0.1 ����
		else
			dDeltaPower = gProcessINI.m_sProcessPowerMeasure.dPowerStep;//���� ����

		if(bOver)
		{
			m_dNewDutyOffset -=  dDeltaPower;
		}
		else
		{
			m_dNewDutyOffset +=  dDeltaPower;
		}

	}

	return bSuccess;
}
double CPaneManualControlPowerMeasurement::GetCompensationOffset(int nRepeatCnt, double dCurrentPower)
{
	double dTargetW =( m_sProcessPowerMeasure.dMinAllowable +
						m_sProcessPowerMeasure.dMaxAllowable) / 2;

	if(nRepeatCnt <= 1 ) // �ι�°�� ���Ǹ�ŭ �߰� 
	{
		if(gProcessINI.m_sProcessPowerMeasure.dPowerStep >= 5)
			return 999;

		if(dCurrentPower > dTargetW)
			return -gProcessINI.m_sProcessPowerMeasure.dPowerStep;
		else
			return gProcessINI.m_sProcessPowerMeasure.dPowerStep;
	}
	else // �� �̻��� ����ؼ�~ Duty : Power = X : Target
	{
		double dResultDuty = 0;
		dResultDuty = m_dDeltaDuty * (dTargetW - dCurrentPower) / (dCurrentPower - m_dOldPower);
		return dResultDuty;
	}
}


BOOL CPaneManualControlPowerMeasurement::MeasureOnePoint(int nIndex)
{
	if(m_bCompensationMode)
	{
		BOOL bCheck = FALSE;

		if(m_b1stPower[nIndex])
			bCheck = TRUE;

		if(bCheck)
		{	
			if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE))
			{
				ProcessMeasureStop();
				return 0;
			}
			if (!MoveMotor(nIndex))
			{
				ProcessMeasureStop();
				return FALSE;
			}
			GalvoStepMove(nIndex);
			if(!RepeatMeasure(nIndex))
			{
				ProcessMeasureStop();
				return FALSE;
			}
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						ProcessMeasureStop();
						ErrMsgDlg(STDGNALM781);
						return FALSE;
					}
				}
			}

			SetMeasureTime(TRUE, 0.0);
		}
	}
	else
	{
		BOOL bCheck = FALSE;
		if(nIndex<25)
		{
			if(m_b1stPower[nIndex])
				bCheck = TRUE;
		}
		else
		{
			if(m_b2ndPower[nIndex-25])
				bCheck = TRUE;
		}
		if(bCheck)
		{	
			if (!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE))
			{
				ProcessMeasureStop();
				return 0;
			}
			if (!MoveMotor(nIndex))
			{
				ProcessMeasureStop();
				return FALSE;
			}
			GalvoStepMove(nIndex);
			if(!RepeatMeasure(nIndex))
			{
				ProcessMeasureStop();
				return FALSE;
			}
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						ProcessMeasureStop();
						ErrMsgDlg(STDGNALM781);
						return FALSE;
					}
				}
			}

			SetMeasureTime(TRUE, 0.0);
		}	
	}
	return TRUE;	
}
void CPaneManualControlPowerMeasurement::SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
														int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
														int ndiff, int nJobType)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strpathName+=_T("JobTime");
	CTime  curDate = CTime::GetCurrentTime();
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//�켱 ���� �˻�
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	
	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strType;
		if(nJobType == PREHEAT_JOB)
			strType.Format(_T("H"));
		else if(nJobType == SCAL_JOB)
			strType.Format(_T("S"));
		else if(nJobType == POWER_JOB)
			strType.Format(_T("P"));
		else
			strType.Format(_T("D"));
		
		strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
			strType,
			nStartYear, nStartMonth, nStartDay, nStartHour, nStartMin, nStartSec, 
			nEndYear, nEndMonth, nEndDay, nEndHour, nEndMin, nEndSec,
			ndiff);
		
		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();

	// copy
	/*CString strFileName, strMovePath;
	strFileName.Format(_T("JobTime%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strMovePath.Format(_T("%s%d\\%s"), gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo, strFileName);
	CopyFile(strpathName, strMovePath, FALSE);*/
}
void CPaneManualControlPowerMeasurement::SavePowerTime()
{
	time_t	timeEnd;
	time(&timeEnd);


	for (int k = m_nStart; k < m_nEnd; ++k)
	{		
		if(k<25)
		{
			if (m_b1stPower[k])
			{
				if(m_sProcessPowerMeasure.dMaxAllowable >= m_pPowerMeasure[k].dVal &&
					m_sProcessPowerMeasure.dMinAllowable <= m_pPowerMeasure[k].dVal)
					gTempINI.m_sTempTime.nAutoPowerEndTime[m_sProcessPowerMeasure.nMask][0] = (int)timeEnd;	
			}
		}

		if(k >= 25)
		{
			if (m_b2ndPower[k-25])
			{
				if(m_sProcessPowerMeasure.dMaxAllowable >= m_pPowerMeasure[k].dVal &&
					m_sProcessPowerMeasure.dMinAllowable <= m_pPowerMeasure[k].dVal )
					gTempINI.m_sTempTime.nAutoPowerEndTime[m_sProcessPowerMeasure.nMask][1] = (int)timeEnd;
			}
		}
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		ErrMsgDlg(STDGNALM119);

}
void CPaneManualControlPowerMeasurement::AddCompensationResult()
{	
	CString strEvent, strInfo;
	if(m_bCompensationMode)
	{
		int nMask = m_sProcessPowerMeasure.nMask;
		BOOL bTophat = m_sProcessPowerMeasure.bTophat;

		//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[nMask] += m_dNewDutyOffset;

		strEvent = _T("Finished the process of power compensation");

		gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nMask] += m_nNewAttenOffsetPos;
		strInfo.Format(_T("Power Offset = %.3f | Atten. Offset = %d | Tophat Mode = %d | MASK = %d"), 
				m_dNewDutyOffset, m_nNewAttenOffsetPos, bTophat, nMask);
	

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
			ErrMsgDlg(STDGNALM114);

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
			ErrMsgDlg(STDGNALM110);
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);

}
BOOL CPaneManualControlPowerMeasurement::WaitLongTerm(int& nSleepCount, HANDLE* pHandle)
{
	if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
			ProcessMeasureStop();
			ErrMsgDlg(STDGNALM781);
			return FALSE;
		}
		if(!gDeviceFactory.GetEocard()->GetApplyCalibrationFile(0) || !gDeviceFactory.GetEocard()->GetApplyCalibrationFile(1))
		{
			// Set Cal Apply error 
			ProcessMeasureStop();
			ErrMsgDlg(STDGNALM607);
			return FALSE;
		}
	}
	while(nSleepCount < m_sProcessPowerMeasure.nLongTermPeriod * 600)
	{
		Sleep(100);
		MessageLoop();
		nSleepCount++;
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			ProcessMeasureStop();
			return 0;
		}
	}
	if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
		{
			ProcessMeasureStop();
			ErrMsgDlg(STDGNALM781);
			return FALSE;
		}
	}
	nSleepCount = 0;
	while(nSleepCount < m_sProcessPowerMeasure.nLongTermDummyOnTime * 600)
	{
		Sleep(100);
		MessageLoop();
		nSleepCount++;
		if (::WaitForSingleObject(pHandle[1], 0) == WAIT_OBJECT_0)
		{
			ProcessMeasureStop();
			return 0;
		}
	}
	return TRUE;
}

BOOL CPaneManualControlPowerMeasurement::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Power) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
BOOL CPaneManualControlPowerMeasurement::CheckCompensationRepeat(int nPoint)
{
	BOOL bResult = FALSE;
	double dComMax, dComMin, dTarget;

	dTarget = (m_sProcessPowerMeasure.dMaxAllowable + m_sProcessPowerMeasure.dMinAllowable) /2;
	
	dComMin = dTarget - 0.2;
	dComMax = dTarget + 0.2;

	BOOL bPlusMinusOK[2] = {FALSE,}; //target +-�� �Ǿ�� TRUE
	BOOL bAllErrorSmall = TRUE;
	double dDiff;


	if(nPoint < 25)
	{
		for(int k = 0; k<MEASURE_REPEAT - 2; k++)
		{
			if(m_dEachPowerMaster[k] == -1)
			{
				bAllErrorSmall = FALSE;
				continue;
			}
			dDiff = m_dEachPowerMaster[k] - dTarget;
			if(dDiff > 0.05 || dDiff < -0.05)
				bAllErrorSmall = FALSE;

			if(dDiff > 0)
				bPlusMinusOK[0] = TRUE;

			if(dDiff <= 0) // + �ؾߵǴ°��
				bPlusMinusOK[1] = TRUE;
		}

		if(m_pPowerMeasure[nPoint].dVal < dComMin) 
		{
			m_nPattern = INCREASE;
			m_bMasterOK = FALSE;
			return FALSE;
		}
		else if(m_pPowerMeasure[nPoint].dVal > dComMax)
		{
			m_nPattern = DECREASE;
			m_bMasterOK = FALSE;
			return FALSE;
		}
		else
		{
			if((bPlusMinusOK[0] && bPlusMinusOK[1]) || bAllErrorSmall)
			{
				m_bMasterOK = TRUE;
				return TRUE;
			}
			else
			{
				m_bMasterOK = FALSE;
				bResult = FALSE;

				if(m_pPowerMeasure[nPoint].dVal < dTarget)
				{
					m_nPattern = INCREASE;
					return FALSE;
				}
				else
				{
					m_nPattern = DECREASE;
					return FALSE;
				}
			}
		}
	}
	else
	{
		for(int k = 0; k<MEASURE_REPEAT; k++)
		{
			if(m_dEachPowerSlave[k] == -1)
			{
				bAllErrorSmall = FALSE;
				continue;
			}

			dDiff = m_dEachPowerSlave[k] - dTarget;

			if(dDiff > 0.05 || dDiff < -0.05)
				bAllErrorSmall = FALSE;

			if(dDiff > 0)
				bPlusMinusOK[0] = TRUE;

			if(dDiff <= 0)
				bPlusMinusOK[1] = TRUE;
		}

		if(m_pPowerMeasure[nPoint].dVal < dComMin)
		{
			bResult = FALSE;
			m_nPattern = DECREASE;
			m_bSlaveOK = FALSE;
			return FALSE;
		}
		else if(m_pPowerMeasure[nPoint].dVal > dComMax)
		{
			bResult = FALSE;
			m_nPattern = INCREASE;
			m_bSlaveOK = FALSE;
			return FALSE;
		}
		else
		{
			if((bPlusMinusOK[0] && bPlusMinusOK[1]) || bAllErrorSmall)
			{
				m_bSlaveOK = TRUE;
			}
			else
			{
				m_bSlaveOK = FALSE;
				bResult = FALSE;
				if(m_pPowerMeasure[nPoint].dVal < dTarget)
				{
					m_nPattern = DECREASE;
					return FALSE;
				}
				else
				{
					m_nPattern = INCREASE;
					return FALSE;
				}
			}
		}
	}
	return TRUE;
}

void CPaneManualControlPowerMeasurement::UpdatePulseCombo(int nShotIndex)
{
	CString str;
	str.Format("Shot Table No: %d",nShotIndex);

	GetDlgItem(IDC_STATIC_SHOT_NUM)->SetWindowText(str);

	m_cmbPulse.ResetContent();
	 
	CString strTool;
	int nCount = 1;
	
	if(m_nUserLevel > 1) 
		nCount = gShotTableINI.m_sShotGroupTable.nTotalShotCount[nShotIndex];

	for(int i = 0; i <nCount ; i++)
	{
		strTool.Format(_T("Pulse %d "), i);
		m_cmbPulse.AddString(strTool);
	}

	m_sProcessPowerMeasure.nPulseNum = 0;
	m_cmbPulse.SetCurSel(m_sProcessPowerMeasure.nPulseNum);

	ChangeLaserParam(m_sProcessPowerMeasure.nUseTool);
}


void CPaneManualControlPowerMeasurement::OnBnClickedButtonBeamshotUpdate()
{
	if(m_sProcessPowerMeasure.nUseTool == -1)
		return;

      BeamPathInfoUpdate(m_sProcessPowerMeasure.nUseTool);
}

void CPaneManualControlPowerMeasurement::BeamPathInfoUpdate(int nTool)
{
    m_sProcessPowerMeasure.nUseTool = nTool;

	m_cmbTool.SetCurSel(nTool);

	m_nSelectShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[m_sProcessPowerMeasure.nUseTool];//20160404
	m_nSelectBeamPathIndex = m_sProcessPowerMeasure.nUseTool;//gToolTableINI.m_sToolTable.nSelectBeamPath[m_sProcessPowerMeasure.nUseTool];

	ChangeLaserParam(m_sProcessPowerMeasure.nUseTool);

	UpdatePulseCombo(m_nSelectShotIndex);
}

int CPaneManualControlPowerMeasurement::CheckMainTool()
{
	int nMaxCount = 0;
	int nMainTool = 0;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if( gDProject.GetDataNo(i) > nMaxCount)
		{
			nMaxCount = gDProject.GetDataNo(i);
			nMainTool = i;
		}

	}
	return nMainTool;
}