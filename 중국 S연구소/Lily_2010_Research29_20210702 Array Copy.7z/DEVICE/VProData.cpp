// VProData.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "VProData.h"
#include "..\model\DSystemINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\MODEL\DProject.h"
#include <math.h>
#include "..\model\GlobalVariable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// VProData

VProData::VProData()
{
	m_bInitBoard = 0;
	m_nPMAlignToolCount = 0;
	m_ImageWidth  = 1020;
	m_ImageHeight = 766;
	m_nCamNo = 0;
	m_bROIShow = TRUE;
	m_nSelIndexNo = 1;
	m_bAArea = FALSE;

	for(int i = 0; i < CREATEVP; i++)
	{
		m_dXYRatio[i] = 0;
		m_dAngle[i] = 0;
		m_nThreshold[i] = 0;
//		m_nBlob[i] = 128;
	}
}

VProData::~VProData()
{

}


BEGIN_MESSAGE_MAP(VProData, CWnd)
	//{{AFX_MSG_MAP(VProData)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// VProData message handlers

bool VProData::InitVision(int nBoardNum, CString lpszVideoFormat, int nCameraPort)
{
#ifdef USE_VISION_PRO
	long nCount;
	VARIANT_BOOL vb;

	//	COM �ʱ�ȭ
	m_hr = CoInitialize( NULL );
	if( FAILED(m_hr) ) {
		ErrMessage( _T("Could not initialize COM.") );
		return false;
	}

	//	Frame Graber ����
	CComPtr<ICogFrameGrabbers>	pCogFrameGrabbers = 0;
	m_hr = pCogFrameGrabbers.CoCreateInstance( CLSID_CogFrameGrabbers );
	m_hr = pCogFrameGrabbers->get_Count( &nCount );
	if( FAILED(m_hr) || (! pCogFrameGrabbers) || nCount < 1 ) {
#ifndef __TEST__
		ErrMessage( _T("No Cognex frame grabber is present.") );
#endif
		return false;
	}
	m_hr = pCogFrameGrabbers->get_Item( nBoardNum, &m_pCogFrameGrabber );
	if( FAILED(m_hr) || (!m_pCogFrameGrabber) ) {
		ErrMessage( _T("Wrong Cognex frame grabber number.") );
		return false;
	}

	for(int i=0;i<CAM_TOT_COUNT;i++)
	{
		//	Camera format ����
		CComBSTR aVF;
		aVF.m_str = lpszVideoFormat.AllocSysString();
		m_hr = m_pCogFrameGrabber->CreateAcqFifo( aVF, cogAcqFifoPixelFormat8Grey, i, VARIANT_TRUE, &m_pAcqFifo[i] );
		//SysFreeString( aVF.m_str );
		if( FAILED(m_hr) || (!m_pAcqFifo[i]) ) {
			ErrMessage( _T("Could not create Video") );
			return false;
		}
		//	Camera Port ����
		SetCameraPort( i );

		//	Image Acquire
		Acquire( i, i, false );
		if( m_pImg[i] ) {
			m_hr = m_pImg[i]->get_Allocated( &vb );
			if( SUCCEEDED(m_hr) && vb ) {
				m_pImg[i]->get_Width( &m_ImageWidth );
				m_pImg[i]->get_Height( &m_ImageHeight );
			}
		}
	}
	//

	CComQIPtr<ICogTool> pTool[CAM_TOT_COUNT];


	for(int j=0;j<CAM_TOT_COUNT;j++)	{
		
		m_pAcqFifoTool[j].CoCreateInstance ( CLSID_CogAcqFifoTool );
		
		WCHAR	Buffer[64];
		if( m_pAcqFifoTool[j] == 0 ) return false;	
		swprintf_s( Buffer, L"AcqFifoTool_%d", j );
		m_pAcqFifoTool[j]->put_ToolName( Buffer );

		if( m_pAcqFifoTool[j] == 0 ) return false;		
		m_hr = m_pAcqFifoTool[j].QueryInterface( &pTool[j] );	
			
		if( SUCCEEDED(m_hr) && pTool[j] ) {
			if( m_pToolGroup == 0 ) m_pToolGroup.CoCreateInstance( CLSID_CogToolGroup );
			m_hr = m_pToolGroup->Add( pTool[j], -1 );
		}

	} 

	m_bInitBoard = true;

#endif
	return true;
}

bool VProData::Acquire(int iDisplayNo, int iCamNo, bool bDisplay)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogImage>			pImg;
	CComPtr<ICogAcqContrast>	CamContrast;
	CComPtr<ICogAcqBrightness>	CamBrightness;
	CComPtr<ICogAcqExposure>	CamExposure;
	long						ntr;
	
	if( m_pAcqFifo[iCamNo] == 0 ) return false;

	m_pAcqFifo[iCamNo]->QueryInterface( &CamBrightness);	//��� ����
	CamBrightness->put_Brightness(m_BrightData[iCamNo]);
	CamBrightness.Release();

	m_pAcqFifo[iCamNo]->QueryInterface( &CamContrast);		//���� ����
	CamContrast->put_Contrast(m_ContrastData[iCamNo]);
	CamContrast.Release();

	if(gProcessINI.m_sProcessFidFind.dExposure > 1)
	{
		m_pAcqFifo[iCamNo]->QueryInterface( &CamExposure);		//���� ����
		if( gFidFindExposure == TRUE)
		{
			CamExposure->put_Exposure(gProcessINI.m_sProcessFidFind.dFidFindExposure);
		}
		else
		{
			CamExposure->put_Exposure(gProcessINI.m_sProcessFidFind.dExposure);
		}
		
		CamExposure.Release();
	}
	else
	{
		m_pAcqFifo[iCamNo]->QueryInterface( &CamExposure);		//���� ����
		CamExposure->put_Exposure(0.02);
		CamExposure.Release();
	}
	
	m_hr = m_pAcqFifo[iCamNo]->Acquire( &ntr, &pImg );
	
	if( SUCCEEDED(m_hr) ) {
		m_pImg[iDisplayNo] = pImg;
		if( bDisplay ) ImageDisplay(iDisplayNo, true );
	}
	else {	//ErrMessage( _T("Oops - no image!") );
		return false;
	}
#endif
	return true;
}

void VProData::LiveImage(int iDisplayNo, int iCamNo, BOOL bStart)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogAcqContrast>	CamContrast;
	CComPtr<ICogAcqBrightness>	CamBrightness;
	CComPtr<ICogAcqExposure>	CamExposure;

	if( m_bInitBoard == 0 ) return;
	if( bStart )
	{
		m_pAcqFifo[iCamNo]->QueryInterface( &CamBrightness);	//��� ����
		CamBrightness->put_Brightness(m_BrightData[iCamNo]);
		CamBrightness.Release();

		m_pAcqFifo[iCamNo]->QueryInterface( &CamContrast);		//���� ����
		CamContrast->put_Contrast(m_ContrastData[iCamNo]);
		CamContrast.Release();

		if(gProcessINI.m_sProcessFidFind.dExposure > 1)
		{
			m_pAcqFifo[iCamNo]->QueryInterface( &CamExposure);		//���� ����
			if( gFidFindExposure == TRUE)
			{
				CamExposure->put_Exposure(gProcessINI.m_sProcessFidFind.dFidFindExposure);
			}
			else
			{
				CamExposure->put_Exposure(gProcessINI.m_sProcessFidFind.dExposure);
			}
			CamExposure.Release();
		}
		else
		{
			m_pAcqFifo[iCamNo]->QueryInterface( &CamExposure);		//���� ����
			CamExposure->put_Exposure(0.02);
			CamExposure.Release();
		}

		m_pDisplay[iDisplayNo]->StartLiveDisplay( m_pAcqFifo[iCamNo], false );

		//
		if(m_bROIShow)
		{
			CComPtr<ICogInteractiveGraphicsContainer>	pInteractiveGrapicContainer;
			m_hr = m_pDisplay[iDisplayNo]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
			if( FAILED(m_hr) || pInteractiveGrapicContainer == 0 ) return;

			CComPtr<ICogPointMarker>	pCrossLine;
			pCrossLine.CoCreateInstance( CLSID_CogPointMarker );
			pCrossLine->put_Interactive( VARIANT_TRUE );
			pCrossLine->put_GraphicType( cogPointMarkerGraphicTypeCross );
			pCrossLine->put_SizeInScreenPixels( m_ImageWidth );
			pCrossLine->put_X( m_ImageWidth/2 );
			pCrossLine->put_Y( m_ImageHeight/2 );
			pCrossLine->put_Rotation( 0 );
			pCrossLine->put_Color( cogColorPurple );
			BSTR cName;
			cName = SysAllocString(L"CenterLine");
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCrossLine), cName, VARIANT_TRUE );
			SysFreeString(cName);
			pCrossLine.Release();
			pInteractiveGrapicContainer.Release();
		}

	}
	else {
		m_pDisplay[iDisplayNo]->StopLiveDisplay();
		Acquire( iDisplayNo, iCamNo, true );
	}
#endif
}


int VProData::SetCameraPortNo(int nCameraPort)
{
#ifdef USE_VISION_PRO
	if( nCameraPort < 3 ) return nCameraPort;
	else return 3;
#endif
	return 3;
}

void VProData::ImageDisplay(int iCamNo, bool bFit)
{
#ifdef USE_VISION_PRO
	if( m_pDisplay[iCamNo] == 0 ) return;
	if( m_pImg[iCamNo] == 0 ) return;

	m_pDisplay[iCamNo]->putref_Image( m_pImg[iCamNo] );
	if( bFit )	m_pDisplay[iCamNo]->Fit( false );
#endif
}

void VProData::SetCameraPort(int nCameraPort)
{
#ifdef USE_VISION_PRO
	if( m_pAcqFifo[nCameraPort] == 0 ) return;
	m_pAcqFifo[nCameraPort]->put_CameraPort( nCameraPort );
#endif
}

bool VProData::SetDisplayWindow(int iCamNo, CWnd *pCWnd)
{
#ifdef USE_VISION_PRO
	IUnknown *pUnk;
	CComQIPtr<ICogDisplay> pDisplay;

	if( pCWnd == 0 ) return false;
	if( pUnk = pCWnd->GetControlUnknown() ) {
		if( pDisplay = pUnk )
			m_pDisplay[iCamNo] = pDisplay;
		else
			return false;
	}
	else 
		return false;
#endif
	return true;

}

void VProData::PMToolShowTrainRegion(int nID, int nCam) 
{
#ifdef USE_VISION_PRO
	if( nID < 0 || nID >= m_nPMAlignToolCount ) return;

	CComPtr<ICogInteractiveGraphicsContainer> pInteractiveGrapicContainer;
	CComPtr<ICogPMAlignPattern> pPMPattern;
	CComPtr<ICogRegion>			pTrainRegion;
	CComPtr<ICogPMAlignTool>	pPMTool;
	CComPtr<ICogRectangleAffine> pRectangleAffine;
	CComPtr<ICogCircle>			pCircle;
	CComPtr<ICogRectangle>		pRectangle;
	CComPtr<ICogPolygon>		pPolygon;
	CComPtr<ICogPointMarker>	pCross;

	m_hr = m_pDisplay[nCam]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	if( FAILED(m_hr) || pInteractiveGrapicContainer == 0 ) return;
	pInteractiveGrapicContainer->Clear();
	
	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];

	if( pPMTool == 0 ) return;

	m_hr = pPMTool->get_Pattern( &pPMPattern );
	if( FAILED(m_hr) || pPMPattern == 0 ) return;
	m_hr = pPMPattern->get_TrainRegion( &pTrainRegion );
	
	m_AutoOrgSetup = true;
	
	if (m_ShapeTypeNo >= MODEL_PATTERN) {
		CString str;
		//str.Format(_T("�������� �ڵ����� �Ͻðڽ��ϱ�?"));
		//if ( ErrMessage( str, _T("������ �ڵ�����"), MB_OKCANCEL | MB_ICONINFORMATION ) == IDOK ) {
		//	m_AutoOrgSetup = true;
		//}
		//else {
		//	m_AutoOrgSetup = false;
		//	pCross.CoCreateInstance( CLSID_CogPointMarker );
		//	pCross->SetCenterRotationSize( 75, 75, 0, 30 );
		//	pCross->put_Color( cogColorRed );
		//	pCross->put_GraphicDOFEnable ( cogPointMarkerDOFAll );
		//	pCross->put_Interactive( VARIANT_TRUE );
		//	pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCross), NULL, VARIANT_TRUE );
		//}
		m_UserWindowShapeType = eRectangleAffine;
		pRectangleAffine.CoCreateInstance( CLSID_CogRectangleAffine );
		pRectangleAffine->SetOriginLengthsRotationSkew( 100, 100, 100, 100, 0, 0 );
		pRectangleAffine->put_Color( cogColorGreen );
		pRectangleAffine->put_GraphicDOFEnable( cogRectangleAffineDOFAll );
		pRectangleAffine->put_Interactive( VARIANT_TRUE );
		CComQIPtr<ICogRegion> pCogRegion;
		pRectangleAffine->QueryInterface( &pCogRegion );
		pPMPattern->putref_TrainRegion( pCogRegion );
		
		if( FAILED(m_hr) || pTrainRegion == 0 ) {	
			m_hr = pPMPattern->get_TrainRegion( &pTrainRegion );
			if( FAILED(m_hr) || pTrainRegion == 0 ) return;
		}
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pTrainRegion), NULL, VARIANT_TRUE );
	}
	else if (gVPro.m_ShapeTypeNo == MODEL_CIRCLE) {
		m_UserWindowShapeType = eCircle;
		pCircle.CoCreateInstance( CLSID_CogCircle );
		pCircle->SetCenterRadius ( 100, 100, m_ShapeCenterA );
		pCircle->put_GraphicDOFEnable( cogCircleDOFPosition );

		pCircle->put_Color( cogColorGreen );
		pCircle->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCircle), NULL, VARIANT_TRUE );
	}
	else if (gVPro.m_ShapeTypeNo == MODEL_RECT) {
		m_UserWindowShapeType = eRectangle;
		pRectangle.CoCreateInstance( CLSID_CogRectangle );
		pRectangle->SetCenterWidthHeight ( 100, 100, 100, 100 );
		pRectangle->put_GraphicDOFEnable( cogRectangleDOFPosition );

		pRectangle->put_Color( cogColorGreen );
		pRectangle->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pRectangle), NULL, VARIANT_TRUE );
	}
	else if (gVPro.m_ShapeTypeNo == MODEL_CROSS) {
		m_UserWindowShapeType = ePolygon;
		pPolygon.CoCreateInstance( CLSID_CogPolygon );
		//pPolygon->put_VertexX (0, 200 );
		//pPolygon->put_VertexY (0, 200 );
//		pPolygon->put_Visible (VARIANT_TRUE);

		//pPolygon->SetVertex (0, 200, 200);
		pPolygon->put_LineWidthInScreenPixels ( 16846863 );
		
		pPolygon->put_GraphicDOFEnable( cogPolygonDOFAll );
			//pRectangleAffine->SetOriginLengthsRotationSkew( 100, 100, 100, 100, 0, 0 );
		

		pPolygon->put_Color( cogColorGreen );
		pPolygon->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pPolygon), NULL, VARIANT_TRUE );
	}
#endif
}



void VProData::CheckPMAlignToolInstance(int nID)
{
#ifdef USE_VISION_PRO
	if( pCogPMAlignTool[nID] == 0 ) {
		m_hr = pCogPMAlignTool[nID].CoCreateInstance( CLSID_CogPMAlignTool );
		if( SUCCEEDED(m_hr) && pCogPMAlignTool[nID] ) {
			WCHAR	Buffer[64];
			if( pCogPMAlignTool[nID] == 0 ) return;	
			swprintf_s( Buffer, L"PMAlignTool_%d", nID );
			pCogPMAlignTool[nID]->put_ToolName( Buffer );
		}
	}
#endif
}

void VProData::CreatePMAlignTool(int nCount)
{
#ifdef USE_VISION_PRO
	AllocPMAlignTool( nCount );
#endif
}

void VProData::AllocPMAlignTool(int nCount)
{
#ifdef USE_VISION_PRO
	for( int i=0; i< nCount; i++ ) {
		CheckPMAlignToolInstance( i );
		PMAlignToolAddToolGroup( i );
	}

	m_nPMAlignToolCount = CREATEVP;
#endif
}

void VProData::PMAlignToolAddToolGroup(int nID)
{
#ifdef USE_VISION_PRO
	CComQIPtr<ICogTool> pTool;
	if( pCogPMAlignTool[nID] == 0 ) return;
	
	m_hr = pCogPMAlignTool[nID].QueryInterface( &pTool);
	if( SUCCEEDED(m_hr) && pTool ) {
		if( m_pToolGroup == 0 ) m_pToolGroup.CoCreateInstance( CLSID_CogToolGroup );
		m_hr = m_pToolGroup->Add( pTool, -1 );
	}
#endif
}
BOOL VProData::PMToolSetSearchAllRegion(int nID)
{
#ifdef USE_VISION_PRO
	if( nID < 0 || nID >= m_nPMAlignToolCount ) return FALSE;
	
	CComPtr<ICogRectangle>		pRectangle;
	CComQIPtr<ICogRegion>		pRegion;
	CComPtr<ICogPMAlignTool>	pPMTool;

	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];
	if( pPMTool == 0 ) return FALSE;

	pPMTool->putref_SearchRegion ( NULL );
#endif
	return TRUE;
}

bool VProData::PMToolSetSearchRegion(int nID, int nCam, BOOL bNoView)
{
#ifdef USE_VISION_PRO
	if( nID < 0 || nID >= m_nPMAlignToolCount ) return false;

	CComPtr<ICogRectangle>		pRectangle;
	CComQIPtr<ICogRegion>		pRegion;
	CComPtr<ICogPMAlignTool>	pPMTool;
	double cx, cy, w, h;

	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];
	if( pPMTool == 0 ) return false;

	BSTR cName;
	cName = SysAllocString(L"CenterLine");
	if(!bNoView)
	{
		if( GetUserWindow(nCam, cName, &cx, &cy, &w, &h) == 0 )
		{
			SysFreeString(cName);
			return false;
		}
		SysFreeString(cName);
	}
	else
	{
		GetSearchRegion(nID, cx, cy, w, h);
	}
	m_hr = pRectangle.CoCreateInstance( CLSID_CogRectangle );
	if( FAILED(m_hr) || pRectangle == 0 ) return false;
	pRectangle->SetCenterWidthHeight( cx, cy, w, h );
	
	gVPro.m_SearchAreacx[nCam] = cx;
	gVPro.m_SearchAreacy[nCam] = cy;
	gVPro.m_SearchAreacw[nCam] = w;
	gVPro.m_SearchAreach[nCam] = h;

	m_hr = pRectangle->QueryInterface( &pRegion );
	if( FAILED(m_hr) && pRegion == 0 ) return false;
	m_hr = pPMTool->putref_SearchRegion( pRegion );
	if( FAILED(m_hr) ) return false;
#endif
	return true;
	

}

bool VProData::GetUserWindow(int nID, BSTR strName, double *cx, double *cy, double *w, double *h)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogInteractiveGraphicsContainer> pInteractiveGrapicContainer;
	CComPtr<ICogGraphicInteractive> InteractiveGraphic;
	CComPtr<ICogGraphicInteractive> InteractiveGraphic2;
	long nCnt;


	if( m_pDisplay[nID] == 0 ) return false;

	m_pDisplay[nID]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	pInteractiveGrapicContainer->get_Count( &nCnt );
	if( nCnt != 1 && nCnt != 2) return false;

	if(strName == NULL)
	{
		if ( m_AutoOrgSetup == true ){
			pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
		}
		else if ( m_AutoOrgSetup == false  ){
			pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic2 );	
			CogColorConstants ColorNum;
			InteractiveGraphic2->get_Color ( &ColorNum );

			if ( m_UserWindowShapeType == eRectangleAffine && ColorNum == cogColorRed){
				pInteractiveGrapicContainer->get_Item( 1 , &InteractiveGraphic );
			}
			else if ( m_UserWindowShapeType == eRectangleAffine && ColorNum != cogColorRed){
				pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
			}
			else if ( m_UserWindowShapeType == eCross && ColorNum == cogColorRed){
				pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
			}
			else if ( m_UserWindowShapeType == eCross && ColorNum != cogColorRed){
				pInteractiveGrapicContainer->get_Item( 1 , &InteractiveGraphic );
			}
			else if ( m_UserWindowShapeType == eRectangle){
				pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
			}
		}
	}
	else
	{
		VARIANT temp;
		temp.vt = VT_BSTR;
		temp.bstrVal = strName;
		pInteractiveGrapicContainer->FindItem(temp, cogDisplayZOrderBack, &nCnt);
		if(nCnt == 0)
			pInteractiveGrapicContainer->get_Item( 1 , &InteractiveGraphic );
		else if(nCnt == 1)
			pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
		else 
			return false;
	}
	if(nCnt == 0 || nCnt == 1)
	{

		if( m_UserWindowShapeType == eCircle  ) {
			m_hr = CComQIPtr<ICogCircle>(InteractiveGraphic)->GetCenterRadius( &m_UserWindowCX, &m_UserWindowCY, &m_UserWindowW );
			if( FAILED(m_hr) ) return false;
			//m_UserWindowW *= 2; 
			m_UserWindowH = m_UserWindowW;
			*cx = m_UserWindowCX; *cy = m_UserWindowCY; *w = m_UserWindowW; *h = m_UserWindowH;
		}
		else if( m_UserWindowShapeType == eRectangle  ) {
			m_hr = CComQIPtr<ICogRectangle>(InteractiveGraphic)->GetCenterWidthHeight( &m_UserWindowCX, &m_UserWindowCY, &m_UserWindowW, &m_UserWindowH );
			if( FAILED(m_hr) ) return false;
			*cx = m_UserWindowCX; *cy = m_UserWindowCY; *w = m_UserWindowW; *h = m_UserWindowH;
		}
		else if( m_UserWindowShapeType == eRectangleAffine  ) {
			m_hr = CComQIPtr<ICogRectangleAffine>(InteractiveGraphic)->GetOriginLengthsRotationSkew( &m_UserWindowCX, &m_UserWindowCY, &m_UserWindowW, &m_UserWindowH, 0, 0 );
			if( FAILED(m_hr) ) return false;
			*cx = m_UserWindowCX; *cy = m_UserWindowCY; *w = m_UserWindowW; *h = m_UserWindowH;
		}
		else if( m_UserWindowShapeType == eEllipse ) {
			m_hr = CComQIPtr<ICogEllipse>(InteractiveGraphic)->GetCenterXYRadiusXYRotation( &m_UserWindowCX, &m_UserWindowCY, &m_UserWindowW, &m_UserWindowH, &m_UserWindowRotate );
			if( FAILED(m_hr) ) return false;
			m_UserWindowW *= 2; m_UserWindowH *= 2;
			*cx = m_UserWindowCX; *cy = m_UserWindowCY; *w = m_UserWindowW; *h = m_UserWindowH;
		}
		else if( m_UserWindowShapeType == eCross ) {	
			m_hr = CComQIPtr<ICogPointMarker>(InteractiveGraphic)->GetCenterRotationSize( &m_UserWindowCX, &m_UserWindowCY, &m_UserWindowW, &m_UserWindowSize );
			if( FAILED(m_hr) ) return false;
			*cx = m_UserWindowCX; *cy = m_UserWindowCY; *w = m_UserWindowW; *h = m_UserWindowSize;
		}
	}
	else
	{
		*cx = m_TrainAreacx[m_nSelIndexNo];
		*cy = m_TrainAreacy[m_nSelIndexNo];
		*w  = m_TrainAreacw[m_nSelIndexNo];
		*h  = m_TrainAreach[m_nSelIndexNo];
	}

#endif
	return true;
}

void VProData::PMToolShowSearchRegion(int nID, BOOL bShow, int nCam)
{
//	if( nID < 0 || nID >= m_nPMAlignToolCount ) return;
#ifdef USE_VISION_PRO
	if(bShow == 0)
	{
		gVPro.PMToolSetSearchRegion( nID, nCam );
	}
	else
	{
		CComPtr<ICogInteractiveGraphicsContainer> pInteractiveGrapicContainer;
		CComPtr<ICogPMAlignPattern> pPMPattern;
		CComPtr<ICogRegion>			pSearchRegion;
		CComPtr<ICogRectangle>		pRectangle;
		CComPtr<ICogPMAlignTool>	pPMTool;
		double cx, cy, w, h;

		cx = gVPro.m_SearchAreacx[nCam];
		cy = gVPro.m_SearchAreacy[nCam];
		w = gVPro.m_SearchAreacw[nCam];
		h = gVPro.m_SearchAreach[nCam];

		m_pDisplay[nCam]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
		if( FAILED(m_hr) || pInteractiveGrapicContainer == 0 ) return;
		
		long nCnt;
		pInteractiveGrapicContainer->get_Count( &nCnt );

		SetUserWindow( cx, cy, w, h );	
		ShowUserWindow(nCam, bShow);
		m_bROIShow = bShow;

//		if(m_bROIShow)
		{
			CComPtr<ICogPointMarker>	pCrossLine;
			pCrossLine.CoCreateInstance( CLSID_CogPointMarker );
			pCrossLine->put_Interactive( VARIANT_TRUE );
			pCrossLine->put_GraphicType( cogPointMarkerGraphicTypeCross );
			pCrossLine->put_SizeInScreenPixels( m_ImageWidth );
			pCrossLine->put_X( m_ImageWidth/2 );
			pCrossLine->put_Y( m_ImageHeight/2 );
			pCrossLine->put_Rotation( 0 );
			pCrossLine->put_Color( cogColorPurple );
			BSTR cName;
			cName = SysAllocString(L"CenterLine");
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCrossLine), cName, VARIANT_TRUE );
			SysFreeString(cName);
			pCrossLine.Release();
		}

		pInteractiveGrapicContainer->get_Count( &nCnt );
//		pInteractiveGrapicContainer->Clear();
		pInteractiveGrapicContainer.Release();
	}
#endif
}


void VProData::SetUserWindow(double cx, double cy, double w, double h)
{
#ifdef USE_VISION_PRO
	m_UserWindowCX = cx; m_UserWindowCY = cy; m_UserWindowW = w; m_UserWindowH = h;
#endif
}

void VProData::ShowUserWindow(int nID, BOOL bShow, enum_PMPatternShapeType nType)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogInteractiveGraphicsContainer> pInteractiveGrapicContainer;
	if( m_pDisplay[nID] == 0 ) return;

	m_pDisplay[nID]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	pInteractiveGrapicContainer->Clear();
	
	if( bShow == 0 ) return;
	
	if( nType == eCircle ) {
		m_UserWindowShapeType = eCircle;
		CComPtr<ICogCircle> pInteractiveGraphic;
		pInteractiveGraphic.CoCreateInstance( CLSID_CogCircle );
		pInteractiveGraphic->SetCenterRadius ( m_UserWindowCX, m_UserWindowCY, m_UserWindowW );
		pInteractiveGraphic->put_Color( cogColorBlue );
		pInteractiveGraphic->put_GraphicDOFEnable( cogCircleDOFAll );
		pInteractiveGraphic->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pInteractiveGraphic), NULL, VARIANT_TRUE );
	}
	else if( nType == eRectangle ) {
		m_UserWindowShapeType = eRectangle;
		CComPtr<ICogRectangle> pInteractiveGraphic;
		pInteractiveGraphic.CoCreateInstance( CLSID_CogRectangle );
		pInteractiveGraphic->SetCenterWidthHeight( m_UserWindowCX, m_UserWindowCY, m_UserWindowW, m_UserWindowH );
		pInteractiveGraphic->put_Color( cogColorBlue );
		pInteractiveGraphic->put_GraphicDOFEnable( cogRectangleDOFAll );
		pInteractiveGraphic->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pInteractiveGraphic), NULL, VARIANT_TRUE );
	}
	else if( nType == eEllipse ) {
		m_UserWindowShapeType = eEllipse;
		CComPtr<ICogEllipse> pInteractiveGraphic;
		pInteractiveGraphic.CoCreateInstance( CLSID_CogEllipse );
		pInteractiveGraphic->SetCenterXYRadiusXYRotation( m_UserWindowCX, m_UserWindowCY, m_UserWindowW*0.5, m_UserWindowH*0.5, 0 );
		pInteractiveGraphic->put_Color( cogColorBlue );
		pInteractiveGraphic->put_GraphicDOFEnable( CogEllipseDOFConstants(cogEllipseDOFSize | cogEllipseDOFScale | cogEllipseDOFPosition) );
		pInteractiveGraphic->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pInteractiveGraphic), NULL, VARIANT_TRUE );
	}
#endif	
}

void VProData::ClearInteractiveGraphics(int iDisplayNo)
{
#ifdef USE_VISION_PRO
	if( m_pDisplay[iDisplayNo] == 0 ) return;

	CComPtr<ICogInteractiveGraphicsContainer> pInteractiveGrapicContainer;
	m_pDisplay[iDisplayNo]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	if(pInteractiveGrapicContainer != NULL)
		pInteractiveGrapicContainer->Clear();
#endif
}


int VProData::PMToolFind(int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag)
{
#ifdef USE_VISION_PRO
	double dCoarse = 5;
	BOOL bOverFound = TRUE;
	BOOL bScoreFail = FALSE;

	BOOL bCheckSizeAndRatioFlagError = FALSE;//20170929

	long	nFound = 0;
	double	px = 0, py = 0, rotate, score;
	double	px2 = 0, py2 = 0, rotate2, score2, scalecx, scalecy, realscalecx;
	VARIANT_BOOL	accepted;
	VARIANT_BOOL	accepted2;
	int nBestIndex = 0;
	CComPtr<ICogPMAlignResult> pPMResultArray[100];
	CComPtr<ICogTransform2DLinear> pPoseArray[100];
	double scalecxArray[100], scalecyArray[100], scoreArray[100], scaleArray[100];

	double scalecxArrayTemp[100], scalecyArrayTemp[100];

	CComQIPtr<ICogImage8Grey> pGI = m_pImg[iDisplay];
	if( iPatternNo < 0 || iPatternNo >= m_nPMAlignToolCount ) return 0;

	CComPtr<ICogInteractiveGraphicsContainer>	pInteractiveGrapicContainer;
	CComPtr<ICogRegion>							pSearchRegion;
	CComPtr<ICogGraphicLabel>					pLabel;
	CComPtr<ICogPMAlignTool>					pPMTool;
	CComPtr<ICogPMAlignPattern>					pPMPattern;
	VARIANT_BOOL								vb;
	WCHAR										Buffer[64];


	//	Get Results
	CComPtr<ICogPMAlignResult> pPMResult;
	CComPtr<ICogTransform2DLinear> pPose, pPose2;

	CComPtr<ICogPMAlignResult> pPMResult2;
	CComPtr<ICogPointMarker>	pCross2;

	//	Graphic
	CComPtr<ICogPointMarker>	pCross;
	CComPtr<ICogPointMarker>	pTrainCross;
	CComPtr<ICogPointMarker>	pCircleResult;
	CComPtr<ICogCompositeShape> CompositeShape;

	//	Get Results
	CComPtr<ICogPMAlignResults> pPMResults;


/********************** ��� �ʱ�ȭ *****************************/
//	gProcess.m_ResultData[iPatternNo].dx = 0;
//	gProcess.m_ResultData[iPatternNo].dy = 0;
	
//�ι�° �˻� ��� ���� �� ��
//	if (iPatternNo == CAM2) {
//		gProcess.m_ResultData[5].dx = 0;
//		gProcess.m_ResultData[5].dy = 0;
//	}
/******************************************************************/
//	if (patternFlag) {
		CheckPMAlignToolInstance( iPatternNo );
		pPMTool = pCogPMAlignTool[iPatternNo];
		if( pPMTool == 0 ) {
			return 0;
		}
//	}
//	else{
//		CheckPMAlignToolInstance( iPatternNo );
//		pPMTool = pCogPMAlignTool[iPatternNo];
//		if( pPMTool == 0 ) {
//			return false;
//		}
//	}

	m_hr = m_pDisplay[iDisplay]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	if( FAILED(m_hr) || pInteractiveGrapicContainer == 0 ) return 0;
	pInteractiveGrapicContainer->Clear();

	if(m_bROIShow)
	{
		CComPtr<ICogPointMarker>	pCrossLine;
		pCrossLine.CoCreateInstance( CLSID_CogPointMarker );
		pCrossLine->put_Interactive( VARIANT_TRUE );
		pCrossLine->put_GraphicType( cogPointMarkerGraphicTypeCross );
		pCrossLine->put_SizeInScreenPixels( m_ImageWidth );
		pCrossLine->put_X( m_ImageWidth/2 );
		pCrossLine->put_Y( m_ImageHeight/2 );
		pCrossLine->put_Rotation( 0 );
		pCrossLine->put_Color( cogColorPurple );
		BSTR cName;
		cName = SysAllocString(L"CenterLine");
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCrossLine), cName, VARIANT_TRUE );
		SysFreeString(cName);
		pCrossLine.Release();
	}

	pLabel.CoCreateInstance( CLSID_CogGraphicLabel );
	pLabel->put_X( 10 );
	pLabel->put_Y( 0 );
	pLabel->put_Alignment( cogGraphicLabelAlignmentTopLeft );
	pLabel->put_Color( cogColorRed );

	m_hr = pPMTool->get_Pattern( &pPMPattern );
	if( FAILED(m_hr) || pPMPattern == 0 ) {
		return 0;
	}
	m_hr = pPMPattern->get_Trained( &vb );

	CString strFile, strResult;
	strFile.Format(_T("VisionFail"));
	
	if( FAILED(m_hr) || vb == 0 ) {
		swprintf_s( Buffer, L"Not trained" );
		strResult = Buffer;
		pLabel->put_Text( Buffer );
		pLabel->put_Color( cogColorRed );
		pLabel->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
		return 0;   
	}

	if (patternFlag == true && gVPro.m_bAArea == false){
		double cx, cy, cw, ch;
		cx = gVPro.m_SearchAreacx[iDisplay];
		cy = gVPro.m_SearchAreacy[iDisplay];
		cw = gVPro.m_SearchAreacw[iDisplay];
		ch = gVPro.m_SearchAreach[iDisplay];

		CComPtr<ICogRectangle>	pRectangle;
		pRectangle.CoCreateInstance(CLSID_CogRectangle);
		pRectangle->SetCenterWidthHeight( cx, cy, cw, ch );
		pRectangle->QueryInterface( &pSearchRegion );
		pPMTool->putref_SearchRegion( pSearchRegion );
		pRectangle.Release();

		pSearchRegion->EnclosingRectangle( cogCopyShapeAll, &pRectangle );

		pRectangle->put_Color( cogColorBlue );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pRectangle), NULL, VARIANT_TRUE );
	}
	else if (patternFlag == true && gVPro.m_bAArea == true){
		pPMTool->putref_SearchRegion( NULL );
	}
	else if (patternFlag == false) {
		m_hr = pPMTool->get_SearchRegion( &pSearchRegion );
		if( SUCCEEDED(m_hr) && pSearchRegion ) {
			CComPtr<ICogRectangle>	pRectangle;
			pSearchRegion->EnclosingRectangle( cogCopyShapeAll, &pRectangle );
			pRectangle->put_Color( cogColorBlue );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pRectangle), NULL, VARIANT_TRUE );
		}
	}
	

	while (dCoarse >= 3)
	{
		//	Run Parameters
		CComPtr<ICogPMAlignRunParams> pPMRunParam;
		CComPtr<ICogPMAlignZoneScale> pZoneScale, pZoneScaleY, pZoneScaleX;
		CComPtr<ICogPMAlignZoneAngle > pZoneAngle;

		bCheckSizeAndRatioFlagError = FALSE;//20170929

		if(bOverFound)
		{
			pPMResults.Release();
			pPMResult.Release();
			pPose.Release();
			bOverFound = FALSE;
			pPMTool->get_RunParams( &pPMRunParam );
			pPMRunParam->put_AcceptThreshold ( 0.6 );
			pPMRunParam->put_ScoreUsingClutter(FALSE);
			pPMRunParam->put_GrainLimitsUsePattern(FALSE); //bskim ���� �Ѱ� ��� ���� -->�ǵμ� Ž���� ������ ũ�Ⱑ �ٸ����(�������� ����) �������־�� 
			pPMRunParam->put_GrainLimitCoarse(dCoarse); //bskim ���� ��ĥ�� ����
			pPMRunParam->put_GrainLimitFine(1);	//bskim ���� ���� ����
	
			if (patternFlag)
			{
				pPMRunParam->get_ZoneScale( &pZoneScale );
				pZoneScale->put_Configuration( cogPMAlignZoneLowHigh );
				pZoneScale->put_Low( gVPro.m_ScaleN[iPatternNo] );
				pZoneScale->put_High( gVPro.m_ScaleP[iPatternNo] );
				double dOverlap = 1;
				pZoneScale->put_Overlap(dOverlap);

				pPMRunParam->get_ZoneScaleY( &pZoneScaleY );
				pPMRunParam->get_ZoneScaleX( &pZoneScaleX );
				if(m_dXYRatio[iPatternNo] == 0)	//aspect Ratio�� 0�̸� ZoneScale Y ���� ���� �ʵ��� (fiducial ã������ 0 ����)
				{
					pZoneScaleY->put_Configuration( cogPMAlignZoneNominal );
					pZoneScaleY->put_Nominal(1);
				}
				else
				{
					pZoneScaleY->put_Configuration( cogPMAlignZoneLowHigh );
					pZoneScaleY->put_Low( 1 - m_dXYRatio[iPatternNo] );
					pZoneScaleY->put_High( 1 + m_dXYRatio[iPatternNo] );
					pZoneScaleY->put_Overlap(dOverlap);

					pZoneScaleX->put_Configuration(cogPMAlignZoneNominal);
					pZoneScaleX->put_Nominal(1);
		/*			pZoneScaleX->put_Configuration(cogPMAlignZoneLowHigh);
					pZoneScaleX->put_Low(1 - m_dXYRatio[iPatternNo]);
					pZoneScaleX->put_High(1 + m_dXYRatio[iPatternNo]);
					pZoneScaleX->put_Overlap(dOverlap);
		*/
				}

				pPMRunParam->get_ZoneAngle( &pZoneAngle );
				pZoneAngle->put_Configuration( cogPMAlignZoneLowHigh );

				if (gVPro.m_ShapeTypeNo == MODEL_CIRCLE)
				{
					pZoneAngle->put_Low( 0 );
					pZoneAngle->put_High( 0);
				}
				else
				{
					pZoneAngle->put_Low( -m_dAngle[iPatternNo] );
					pZoneAngle->put_High( m_dAngle[iPatternNo] );
				}
			}

			//	Set Image
			if( m_pImg[iDisplay] == 0 ) {
				return 0;	
			}
			
			pPMTool->putref_InputImage( pGI );
			//	Run
			m_hr = pPMTool->Run();
			if( FAILED(m_hr) ) {
				swprintf_s( Buffer, L"Pattern not found" );
				strResult = Buffer;
				pLabel->put_Text( Buffer );
				pLabel->put_Color( cogColorRed );
				pLabel->put_Interactive( VARIANT_TRUE );
				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				if( dCoarse <= 3)
					return 0;
			}
	
			m_hr = pPMTool->get_Results( &pPMResults );
			if( FAILED(m_hr) || pPMResults == 0  )  
				return 0;

			m_hr = pPMResults->get_Count( &nFound );
	
			if( FAILED(m_hr) )  
				return 0;

			if( nFound < 1 ) {
				swprintf_s( Buffer, L"Pattern not found" );
				strResult = Buffer;
				pLabel->put_Text( Buffer );
				pLabel->put_Color( cogColorRed );
				pLabel->put_Interactive( VARIANT_TRUE );
				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				return 0;
			}

			if(nFound == 1)
			{
				pPMResults->get_Item( 0, &pPMResult );
				pPMResult->GetPose( &pPose );
				pPose->get_TranslationX( &px );
				pPose->get_TranslationY( &py );
				pPose->get_Rotation( &rotate );
				pPose->get_ScalingX ( &scalecx );
				pPose->get_ScalingY ( &scalecy );
				pPMResult->get_Score( &score );
				pPMResult->get_Accepted( &accepted );

				gDProject.m_dFiducialResultScore = score;
				gDProject.m_dFiducialResultScaleX = scalecx;
				gDProject.m_dFiducialResultScaleY = scalecy;
				scalecy = scalecy - scalecx ; 
				if(m_dXYRatio[iPatternNo] < fabs(scalecy) )
				{
					swprintf_s( Buffer, L"AspectRatio Over = %.2f (%.2f)", fabs(scalecy), m_dXYRatio[iPatternNo]);
					pLabel->put_Text( Buffer );
					pLabel->put_Color( cogColorRed );
					pLabel->put_Interactive( VARIANT_TRUE );
					pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
					bOverFound = TRUE;
					strResult = Buffer;
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				}

				if(scalecx > m_ScaleP[iPatternNo] || scalecx < m_ScaleN[iPatternNo])
				{
					swprintf_s( Buffer, L"Size Over = %.3f (%.3f)", realscalecx = scalecx * gVPro.m_SizeA[iPatternNo],  gVPro.m_SizeA[iPatternNo]);
					pLabel->put_Text( Buffer );
					pLabel->put_Color( cogColorRed );
					pLabel->put_Interactive( VARIANT_TRUE );
					pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
					bOverFound = TRUE;
					strResult = Buffer;
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				}
				realscalecx = scalecx * gVPro.m_SizeA[iPatternNo];
				gDProject.m_dFiducialResultSize = realscalecx;
			}
			else
			{

				for(int i = 0; i<100; i++)
				{
					if( pPMResultArray != NULL)
						pPMResultArray[i].Release();
					if( pPoseArray != NULL)
						pPoseArray[i].Release();
				}

				gDProject.m_dFiducialResultScore = -1;
				int nLoopMax = (nFound > 100) ? 100 : nFound;
				BOOL bPass = FALSE;
				BOOL bSizeCheck = FALSE;
				BOOL bRatioCheck = FALSE;
				double dMin = 1.7976931348623158e+308;
				double dTemp;
					
				memset(pPMResultArray, 0x00, sizeof(pPMResultArray));
				memset(pPoseArray, 0x00, sizeof(pPoseArray));
				memset(scalecxArray, 0x00, sizeof(scalecxArray));
				memset(scalecyArray, 0x00, sizeof(scalecyArray));
				memset(scaleArray, 0x00, sizeof(scaleArray));
				memset(scoreArray, 0x00, sizeof(scoreArray));

				memset(scalecxArrayTemp, 0x00, sizeof(scalecxArrayTemp));
				memset(scalecyArrayTemp, 0x00, sizeof(scalecyArrayTemp));

				for(int i=0; i<nLoopMax; i++)
				{
					pPMResults->get_Item( i, &pPMResultArray[i] );
					pPMResultArray[i]->GetPose( &pPoseArray[i] );
		//			pPoseArray[i]->get_TranslationX( &px );
		//			pPoseArray[i]->get_TranslationY( &py );
		//			pPoseArray[i]->get_Rotation( &rotate );
					pPoseArray[i]->get_ScalingX ( &scalecxArray[i] );
					pPoseArray[i]->get_ScalingY ( &scalecyArray[i] );
					pPoseArray[i]->get_Scaling ( &scaleArray[i] );

			
					pPMResultArray[i]->get_Score(&scoreArray[i]);
		//			pPMResultArray[i]->get_Accepted( &accepted );

					if ((scalecxArray[i] <= m_ScaleP[iPatternNo] && scalecxArray[i] >= m_ScaleN[iPatternNo]) &&
						(scalecyArray[i] <= m_ScaleP[iPatternNo] && scalecyArray[i] >= m_ScaleN[iPatternNo]))
						bSizeCheck = TRUE;

					scalecxArrayTemp[i] = scalecxArray[i];
					scalecyArrayTemp[i] = scalecyArray[i];
					// ������ üũ
					scalecyArray[i] = scalecyArray[i] - scalecxArray[i];
					// ���� ���
					if(m_dXYRatio[iPatternNo] >= fabs(scalecyArray[i]))
						bRatioCheck = TRUE;
					// ���� üũ
			

					if (bSizeCheck && bRatioCheck)
					{
						dTemp = fabs( /*((m_ScaleP[iPatternNo] + m_ScaleN[iPatternNo])/2.0) - scalecxArray[i]*/scalecyArray[i]);

						if (dMin > dTemp)
						{
							dMin = dTemp;
							nBestIndex = i;
							bPass = TRUE;
							pLabel->put_Text( L"" );
							pLabel->put_Color( cogColorRed );
							pLabel->put_Interactive( VARIANT_TRUE );
							pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
						
						}
					}
					bSizeCheck = FALSE;
					bRatioCheck = FALSE;
				}

				if(!bPass)
				{

		

					swprintf_s( Buffer, L"SizeOver=(X:%.3f,Y:%.3f),(%.3f~%.3f),Ratio(%.2f) ", realscalecx = scalecxArrayTemp[nBestIndex] * gVPro.m_SizeA[iPatternNo],
						                                                                             scalecyArrayTemp[nBestIndex] * gVPro.m_SizeA[iPatternNo],
						                                                                             m_ScaleN[iPatternNo]*gVPro.m_SizeA[iPatternNo],
																									 m_ScaleP[iPatternNo]*gVPro.m_SizeA[iPatternNo], 
																									 scalecyArray[nBestIndex] );
					pLabel->put_Text( Buffer );
					pLabel->put_Color( cogColorRed );
					pLabel->put_Interactive( VARIANT_TRUE );
					pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
					bOverFound = TRUE;
					strResult = Buffer;
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));

					bCheckSizeAndRatioFlagError = TRUE;//20170929
				}
					

		//		dMin = 1.7976931348623158e+308;
		//
		//		for(int i = 0; i<nLoopMax; i++)
		//		{
		//			if(scalecxArray[i] <= m_ScaleP[iPatternNo] && scalecxArray[i] >= m_ScaleN[iPatternNo])
		//			{
		////				dTemp = (fabs(m_ScaleP[iPatternNo] - scalecxArray[i]) > fabs(m_ScaleN[iPatternNo] - scalecxArray[i]) ?
		////					fabs(m_ScaleN[iPatternNo] - scalecxArray[i]) : fabs(m_ScaleP[iPatternNo] - scalecxArray[i]));
		//
		//				dTemp = fabs( /*((m_ScaleP[iPatternNo] + m_ScaleN[iPatternNo])/2.0) - scalecxArray[i]*/ scalecyArray[i]);
		//
		//				if(dMin > dTemp)
		//				{
		//					dMin = dTemp;
		//					nBestIndex = i;
		//				}
		//			}
		//		}
				pPoseArray[nBestIndex]->get_TranslationX( &px );
				pPoseArray[nBestIndex]->get_TranslationY( &py );
				pPoseArray[nBestIndex]->get_Rotation( &rotate );
				pPMResultArray[nBestIndex]->get_Score( &score );
				pPMResultArray[nBestIndex]->get_Accepted( &accepted );
				realscalecx = scalecxArray[nBestIndex] * gVPro.m_SizeA[iPatternNo];

				gDProject.m_dFiducialResultScaleX = scalecxArray[nBestIndex];
				gDProject.m_dFiducialResultScaleY = scalecyArray[nBestIndex];
				gDProject.m_dFiducialResultSize = realscalecx;
				gDProject.m_dFiducialResultScore = score;
				if( bPass )
				{
				//	TRACE("PM Tool Find Cal %d , %.4f \n",nBestIndex,scalecyArray[nBestIndex]);
					break;
				}
			}
		}
		else
		{
			break;
		}

		dCoarse--;
	
	
		pPMRunParam.Release();
		pZoneScale.Release();
		pZoneScaleY.Release();
		pZoneScaleX.Release();
		pZoneAngle.Release();
//		pGI.Release();
		//	Graphic
	}
//////////////////////////////////////////////////////////////////////////////////////
	if( bShowResult ) {
		//pInteractiveGrapicContainer->Clear();

		pCross.CoCreateInstance( CLSID_CogPointMarker );
		pCross->put_Interactive( VARIANT_TRUE );
		pCross->put_GraphicType( cogPointMarkerGraphicTypeCross );
		pCross->put_SizeInScreenPixels( 30 );
		pCross->put_X( px );
		pCross->put_Y( py );
		pCross->put_Rotation( rotate );
		if( accepted )	pCross->put_Color( cogColorGreen );
		else			pCross->put_Color( cogColorGreen);//cogColorRed );

		pCircleResult.CoCreateInstance( CLSID_CogPointMarker );
		pCircleResult->put_Interactive( VARIANT_TRUE );
		pCircleResult->put_GraphicType( cogPointMarkerGraphicTypeCircle );
		pCircleResult->put_SizeInScreenPixels( (long)(realscalecx / m_CalibData[iDisplay] /2) );
		pCircleResult->put_X( px );
		pCircleResult->put_Y( py );
		pCircleResult->put_Rotation( rotate );
		if( accepted )	pCircleResult->put_Color( cogColorGreen );
		else			pCircleResult->put_Color( cogColorGreen);//cogColorRed );

		double	tx, ty;		//��ϵ� ���� ��ǥ ���÷���
		tx = gProcess.m_AlignData[iDisplay].X;
		ty = gProcess.m_AlignData[iDisplay].Y;
		pTrainCross.CoCreateInstance( CLSID_CogPointMarker );
		pTrainCross->put_Interactive( VARIANT_TRUE );
		pTrainCross->put_GraphicType( cogPointMarkerGraphicTypeCross );
		pTrainCross->put_SizeInScreenPixels( 20 );
		pTrainCross->put_X( tx );
		pTrainCross->put_Y( ty );
		pTrainCross->put_Color( cogColorOrange );

//		swprintf_s( Buffer, L"X=%.2f, Y=%.2f, Score=%.2f", px, py, score );
//		pLabel->put_Text( Buffer );
//		pLabel->put_Interactive( VARIANT_TRUE );
//		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );

		if(nFound == 1)
			pPMResult->CreateResultGraphics( CogPMAlignResultGraphicConstants(cogPMAlignResultGraphicMatchShapeModels | cogPMAlignResultGraphicMatchRegion) /*cogPMAlignResultGraphicMatchRegion*/ , &CompositeShape );
		//			pPMResult->CreateResultGraphics( cogPMAlignResultGraphicMatchRegion, &CompositeShape );
		else
			pPMResultArray[nBestIndex]->CreateResultGraphics( CogPMAlignResultGraphicConstants(cogPMAlignResultGraphicMatchShapeModels  | cogPMAlignResultGraphicMatchRegion)/*cogPMAlignResultGraphicMatchRegion*/ , &CompositeShape );
		//			pPMResultArray[nBestIndex]->CreateResultGraphics( cogPMAlignResultGraphicMatchRegion, &CompositeShape );

 		if (nFound > 1){
 			pPMResults->get_Item( 1, &pPMResult2 );
 			pPMResult2->GetPose( &pPose2 );
 			pPose2->get_TranslationX( &px2 );
 			pPose2->get_TranslationY( &py2 );
 			pPose2->get_Rotation( &rotate2 );
 			pPMResult2->get_Score( &score2 );
 			pPMResult2->get_Accepted( &accepted2 );
 
 			pCross2.CoCreateInstance( CLSID_CogPointMarker );
 			pCross2->put_Interactive( VARIANT_TRUE );
 			pCross2->put_GraphicType( cogPointMarkerGraphicTypeCross );
 			pCross2->put_SizeInScreenPixels( 30 );
 			pCross2->put_X( px2 );
 			pCross2->put_Y( py2 );
 			pCross2->put_Rotation( rotate2 );
 			if( accepted )	pCross2->put_Color( cogColorGreen );
 			else			pCross2->put_Color( cogColorGreen);//cogColorRed );
 			if (gVPro.m_ShapeTypeNo == MODEL_PATTERN) 
 				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCross2), NULL, VARIANT_TRUE );
 		}

		/********************** ����� ������ *****************************/
		double dPixelX, dPixelY;
		if(m_nCamNo == HIGH_1ST_CAM)
		{
			m_2DTrans[HIGH_1ST_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			//			dPixelX = gSystemINI.m_sSystemDevice.d1stHighPixel.x;
			//			dPixelY = gSystemINI.m_sSystemDevice.d1stHighPixel.y;
		}
		else if(m_nCamNo == LOW_1ST_CAM)
		{
			m_2DTrans[LOW_1ST_CAM].TransformPoint(px, py, dPixelX, dPixelY);
            //TRACE("PM Tool Find %.4f %.4f %.4f %.4f \n",px, py, dPixelX, dPixelY);
		}
		else if(m_nCamNo == HIGH_2ND_CAM)
		{
			m_2DTrans[HIGH_2ND_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			//			dPixelX = gSystemINI.m_sSystemDevice.d2ndHighPixel.x;
			//			dPixelY = gSystemINI.m_sSystemDevice.d2ndHighPixel.y;
		}
		else 
		{
			m_2DTrans[LOW_2ND_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			//			dPixelX = gSystemINI.m_sSystemDevice.d2ndLowPixel.x;
			//			dPixelY = gSystemINI.m_sSystemDevice.d2ndLowPixel.y;
		}


		if (iPatternNo != CAM2) {
			gProcess.m_ResultData[iDisplay].dx = dPixelX;//(px - m_ImageWidth/2.0) * dPixelX;
			gProcess.m_ResultData[iDisplay].dy = dPixelY;//(m_ImageHeight/2.0 -py) * dPixelY;
			gProcess.m_ResultData[iDisplay].dCaliDist = realscalecx;
		}
		else {
			if (py2 > py || py2 == 0 ) {
				gProcess.m_ResultData[iDisplay].dx = dPixelX;//(px - m_ImageWidth/2.0) * dPixelX;
				gProcess.m_ResultData[iDisplay].dy = dPixelY;//(m_ImageHeight/2.0 -py) * dPixelY;
				gProcess.m_ResultData[5].dx = dPixelX;//(px2 - m_ImageWidth/2.0) * dPixelX;
				gProcess.m_ResultData[5].dy = dPixelY;//(m_ImageHeight/2.0 -py2) * dPixelY;
				gProcess.m_ResultData[iDisplay].dCaliDist = realscalecx;
			}
			else {
				gProcess.m_ResultData[iDisplay].dx = dPixelX;//(px2 - m_ImageWidth/2.0) * dPixelX;
				gProcess.m_ResultData[iDisplay].dy = dPixelY;//(m_ImageHeight/2.0 -py2) * dPixelY;
				gProcess.m_ResultData[5].dx = dPixelX;//(px - m_ImageWidth/2.0) * dPixelX;
				gProcess.m_ResultData[5].dy = dPixelY;//(m_ImageHeight/2.0 -py) * dPixelY;
				gProcess.m_ResultData[iDisplay].dCaliDist = realscalecx;
			}
		}

		if(gProcessINI.m_sProcessFidFind.dResultScore <= score)
		{
			accepted = true;

			swprintf_s( Buffer, L"Score = %.3f", score);
			pLabel->put_Text( Buffer );
			pLabel->put_BackgroundColor( cogColorBlack );
			pLabel->put_Color( cogColorWhite );
			pLabel->put_Interactive( VARIANT_TRUE );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
			
		}
		else
		{
			swprintf_s( Buffer, L"Score Fail = %.3f Setting(%.3f) ", score, gProcessINI.m_sProcessFidFind.dResultScore);
			pLabel->put_Text( Buffer );
			pLabel->put_Color( cogColorRed );
			pLabel->put_Interactive( VARIANT_TRUE );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
			gProcess.m_ResultData[iDisplay].dx = 0;
			gProcess.m_ResultData[iDisplay].dy = 0;
			gProcess.m_ResultData[iDisplay].dCaliDist = 0;
			bScoreFail = TRUE;
			accepted = false;   //20130515 bskim ������ Result Score���� Score ���� ������� ���� ȭ�鿡 Score �� ǥ���ϰ� Vision �� 0���� ����
			strResult = Buffer;
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
		}
		/******************************************************************/

		if (gVPro.m_ShapeTypeNo == MODEL_PATTERN) 
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pTrainCross), NULL, VARIANT_TRUE );

		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCross), NULL, VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(CompositeShape), NULL, VARIANT_TRUE );
	}

	pPMPattern.Release();
	pPMTool.Release();
	pPMResult2.Release();
	pCross2.Release();
	pCross.Release();
	pTrainCross.Release();
	CompositeShape.Release();
	pCircleResult.Release();

	pInteractiveGrapicContainer.Release();

	for(int i = 0; i<100; i++)
	{
		if( pPMResultArray != NULL)
			pPMResultArray[i].Release();
		if( pPoseArray != NULL)
			pPoseArray[i].Release();
	}

	if(gProcessINI.m_sProcessSystem.bCheckVisionSizeError == TRUE)
	{
	   if(bCheckSizeAndRatioFlagError)//20170929
		return 0;
	}


	if(bOverFound) 
		return 10;
	if(bScoreFail) 
		return 20;
	return (accepted ? 1 : 0);
#endif
	return 1;
}



void VProData::PatternDisplay(int iPMToolNo, int iCamNo, bool bFit)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogPMAlignTool>					pPMTool;
	CComPtr<ICogPMAlignPattern>					pPMPattern;
	VARIANT_BOOL								vb;
	HRESULT										hr;
	CComQIPtr<ICogImage8Grey>					pGI;
	CString										FileName;
	

	if (m_ShapeTypeNo == MODEL_PATTERN) {
		FileName.Format(_T("Null.bmp"));
		LoadImage(FileName, true, 8);
		CheckPMAlignToolInstance( iPMToolNo );
		pPMTool = pCogPMAlignTool[iPMToolNo];
		if( pPMTool == 0 ) {
			return;
		}
		hr = pPMTool->get_Pattern( &pPMPattern );

		hr = pPMPattern->get_Trained( &vb );
		if( vb ){
			//pPMPattern->putref_TrainImage( pGI );
			if( pGI ) pGI.Release();
			pPMPattern->GetTrainedPatternImage(&pGI);
			m_pDisplay[8]->putref_Image(pGI);
			if( iCamNo > 3 )
				;//if( bFit )	m_pDisplay[9]->Fit( false );	
			else
				if( bFit )	m_pDisplay[iCamNo]->Fit( false );	
		}
	}

	else {
		if( gVPro.m_ShapeTrainBool[iPMToolNo] == MODEL_CIRCLE && gVPro.m_ShapeTypeNoData[iPMToolNo] == MODEL_CIRCLE ){
		FileName.Format(_T("Circle.bmp"));
		LoadImage(FileName, true, 8);
		}
		else if( gVPro.m_ShapeTrainBool[iPMToolNo] == MODEL_RECT && gVPro.m_ShapeTypeNoData[iPMToolNo] == MODEL_RECT ){
		FileName.Format(_T("Rectangle.bmp"));
		LoadImage(FileName, true, 8);
		}
		else if( gVPro.m_ShapeTrainBool[iPMToolNo] == MODEL_CROSS && gVPro.m_ShapeTypeNoData[iPMToolNo] == MODEL_CROSS ){
		FileName.Format(_T("Polygon.bmp"));
		LoadImage(FileName, true, 8);
		}
		else{
		FileName.Format(_T("Null.bmp"));
		LoadImage(FileName, true, 8);
		}
	}
#endif
}

bool VProData::SaveVPro(CString lpszFileName)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogMisc> Misc;
	CComBSTR aVF;
	CString FileName;

	if( lpszFileName.ReverseFind (_T('.')) >= 0  )	{
		FileName = lpszFileName.Left(lpszFileName.ReverseFind (_T('.'))) + CString(_T(".vpp"));
	}
	else	{
		FileName = lpszFileName + CString(_T(".vpp"));
	}

	Misc.CoCreateInstance(CLSID_CogMisc);

	aVF.m_str = FileName.AllocSysString();
	m_hr = Misc->SaveObjectToFile( aVF, m_pToolGroup, cogPersistOptionAll, cogPersistFormatXML, NULL );
	if( FAILED(m_hr) ) return false;
#endif
	return true;

}

bool VProData::LoadVPro(CString lpszFileName)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogMisc> Misc;
	CComBSTR aVF;
	CComBSTR Warning;
	CComPtr<IUnknown> Unknown;
	CString FileName;
	WCHAR	Buffer[64];
	
	if( lpszFileName.ReverseFind (_T('.')) >= 0  )	{
		FileName = lpszFileName.Left(lpszFileName.ReverseFind (_T('.'))) + CString(_T(".vpp"));
	}
	else	{
		FileName = lpszFileName + CString(_T(".vpp"));
	}
	
	CFileStatus status;	
	if( !CFile::GetStatus( FileName, status ) ) {
		ErrMessage(_T("Can not Find Vision Pattern Data File."), MB_TOPMOST );
		return false;
	}
	
	Misc.CoCreateInstance(CLSID_CogMisc);
	
	aVF.m_str = FileName.AllocSysString();
	m_hr = Misc->LoadObjectFromFile( aVF, m_pToolGroup, cogPersistOptionAll, cogPersistFormatXML, NULL, &Warning, &Unknown );
	//SysFreeString( aVF.m_str );
	if( FAILED(m_hr) ) return false;

	for( int i=0; i<m_nPMAlignToolCount; i++ ) {
		CComQIPtr<ICogTool> pTool;
		CComQIPtr<ICogTool> pTool2;
		if( pCogPMAlignTool[i] )	pCogPMAlignTool[i].Release();
		swprintf_s( Buffer, L"PMAlignTool_%d", i );	
		m_hr = m_pToolGroup->get_Item( CComVariant(Buffer), &pTool );
		if( FAILED(m_hr) || pTool == 0 ) return false;
		pTool->QueryInterface( &pCogPMAlignTool[i] );
		pTool.Release();
	}
#endif
	return true;

}

bool VProData::SaveProject(CString lpszFileName)
{
#ifdef USE_VISION_PRO
	SaveVPro( lpszFileName );
	SaveData( lpszFileName );
#endif
	return true;
}

bool VProData::LoadProject(CString lpszFileName)
{
#ifdef USE_VISION_PRO
	LoadVPro( lpszFileName );
	LoadData( lpszFileName );
#endif
	return true;
}

bool VProData::SaveData(CString lpszFileName)
{
#ifdef USE_VISION_PRO
		int i;
	CString FileName;
	char cApp[MAX_PATH];

	if( lpszFileName.ReverseFind (_T('.')) >= 0  )	{
		FileName = lpszFileName.Left(lpszFileName.ReverseFind (_T('.'))) + CString(_T(".ini"));
	}
	else	{
		FileName = lpszFileName + CString(_T(".ini"));
	}

	for( i=0; i<m_nPMAlignToolCount; i++ ) {
		sprintf_s( cApp, 260, _T("PMAlignTool_%d"), i );
		IniIntToFile( FileName, cApp, _T("TRAIN - Type"), gVPro.m_ShapeTypeNoData[i] );
		IniIntToFile( FileName, cApp, _T("TRAIN - Polarity"), gVPro.m_ShapePolarityData[i] );
		IniIntToFile( FileName, cApp, _T("TRAIN - Train Bool"), gVPro.m_ShapeTrainBool[i] );
		IniIntToFile( FileName, cApp, _T("TRAIN - Train All Area Bool"), gVPro.m_AAreaBool[i] );

		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area Center x"), gVPro.m_TrainAreacx[i] );
		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area Center y"), gVPro.m_TrainAreacy[i] );
		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area width"), gVPro.m_TrainAreacw[i] );
		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area height"), gVPro.m_TrainAreach[i] );
		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area Center Point x"), gVPro.m_TrainAreacpx[i] );
		IniDoubleToFile( FileName, cApp, _T("TRAIN - Train Area Center Point y"), gVPro.m_TrainAreacpy[i] );

	
		IniDoubleToFile( FileName, cApp, _T("RunParam - Accept threshold"), gVPro.m_ActScore[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - Scale low"), gVPro.m_ScaleN[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - Scale high"), gVPro.m_ScaleP[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - A"), gVPro.m_SizeA[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - B"), gVPro.m_SizeB[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - C"), gVPro.m_SizeC[i] );


	}
	for(int i = 0; i< MAX_CAMERA; i++)
	{
		IniDoubleToFile( FileName, cApp, _T("RunParam - Search Area Center x"), gVPro.m_SearchAreacx[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - Search Area Center y"), gVPro.m_SearchAreacy[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - Search Area width"), gVPro.m_SearchAreacw[i] );
		IniDoubleToFile( FileName, cApp, _T("RunParam - Search Area height"), gVPro.m_SearchAreach[i] );
		IniDoubleToFile( FileName, cApp, _T("Acquire - Calibration Data"), gVPro.m_CalibData[i] );
		IniDoubleToFile( FileName, cApp, _T("Acquire - Brightness"), gVPro.m_BrightData[i] );
		IniDoubleToFile( FileName, cApp, _T("Acquire - Contrast"), gVPro.m_ContrastData[i] );

	}
#endif	
	return true;

}

bool VProData::LoadData(CString lpszFileName)
{
#ifdef USE_VISION_PRO
	int i;
	CString FileName;
	char cApp[MAX_PATH];

	if( lpszFileName.ReverseFind (_T('.')) >= 0  )	{
		FileName = lpszFileName.Left(lpszFileName.ReverseFind (_T('.'))) + CString(_T(".ini"));
	}
	else	{
		FileName = lpszFileName + CString(_T(".ini"));
	}

	CFileStatus status;	
	if( !CFile::GetStatus( FileName, status ) ) {
		//ErrMessage( NULL, _T("Vision Data File�� ã�� �� �����ϴ�."), FileName, MB_TOPMOST );
		ErrMessage( _T("Can not Find Vision Data File."), MB_TOPMOST );
		return false;
	}

	for( i=0; i<m_nPMAlignToolCount; i++ ) {
		sprintf_s( cApp, 260, _T("PMAlignTool_%d"), i );
		
		gVPro.m_ShapeTypeNoData[i] = IniIntFormFile( FileName, cApp, _T("TRAIN - Type"), _T("0") );
		gVPro.m_ShapePolarityData[i] = IniIntFormFile( FileName, cApp, _T("TRAIN - Polarity"), _T("0")  );
		gVPro.m_ShapeTrainBool[i] = IniIntFormFile( FileName, cApp, _T("TRAIN - Train Bool"), _T("0") );
		gVPro.m_AAreaBool[i] = IniIntFormFile( FileName, cApp, _T("TRAIN - Train All Area Bool"), _T("0") );

		gVPro.m_TrainAreacx[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area Center x"), _T("200") );
		gVPro.m_TrainAreacy[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area Center y"), _T("200") );
		gVPro.m_TrainAreacw[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area width"), _T("300") );
		gVPro.m_TrainAreach[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area height"), _T("300") );
		gVPro.m_TrainAreacpx[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area Center Point x"), _T("0") );
		gVPro.m_TrainAreacpy[i] = IniDoubleFormFile( FileName, cApp, _T("TRAIN - Train Area Center Point y"), _T("0") );


	
		gVPro.m_ActScore[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Accept threshold"), _T("0.6") );
		gVPro.m_ScaleN[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Scale low"), _T("0.8") );
		gVPro.m_ScaleP[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Scale high"), _T("1.2") );
		gVPro.m_SizeA[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - A"), _T("0.5") );
		gVPro.m_SizeB[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - B"), _T("0.5") );
		gVPro.m_SizeC[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - C"), _T("0.5") );
		
	}
	for( i = 0; i< MAX_CAMERA; i++)
	{
		gVPro.m_SearchAreacx[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Search Area Center x"), _T("0") );
		gVPro.m_SearchAreacy[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Search Area Center y"), _T("0") );
		gVPro.m_SearchAreacw[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Search Area width"), _T("320") );
		gVPro.m_SearchAreach[i] = IniDoubleFormFile( FileName, cApp, _T("RunParam - Search Area height"), _T("240") );
		gVPro.m_CalibData[i] = IniDoubleFormFile( FileName, cApp, _T("Acquire - Calibration Data"), _T("0.276") );
		gVPro.m_BrightData[i] = IniDoubleFormFile( FileName, cApp, _T("Acquire - Brightness"), _T("0.5") );
		gVPro.m_ContrastData[i] = IniDoubleFormFile( FileName, cApp, _T("Acquire - Contrast"), _T("0.5") );	

	}
#endif
	return true;

}
/****************************************************/
//	Ini File ���� �Լ�

void IniDoubleToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, double Data )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	sprintf_s( str, MAX_PATH, _T("%f"), Data );
	::WritePrivateProfileString( sApp, sKey, str, sFileName );
#endif
}

double IniDoubleFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	GetPrivateProfileString( sApp, sKey, Default, str, MAX_PATH-1, sFileName );
	return atof( str );
#endif
	return 1.1;
}

void IniIntToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, int Data )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	sprintf_s( str, MAX_PATH, _T("%d"), Data );
	::WritePrivateProfileString( sApp, sKey, str, sFileName );
#endif
}

int IniIntFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	GetPrivateProfileString( sApp, sKey, Default, str, MAX_PATH-1, sFileName );
	return atoi( str );
#endif
	return 1;
}

void IniLongToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, long Data )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	sprintf_s( str, MAX_PATH, _T("%d"), Data );
	::WritePrivateProfileString( sApp, sKey, str, sFileName );
#endif
}

long IniLongFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	GetPrivateProfileString( sApp, sKey, Default, str, MAX_PATH-1, sFileName );
	return atol( str );
#endif
	return 1L; 
}

void IniStringToFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Data )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	sprintf_s( str, MAX_PATH, _T("%s"), Data );
	::WritePrivateProfileString( sApp, sKey, str, sFileName );
#endif
}

CString IniStringFormFile( LPCTSTR sFileName, LPCTSTR sApp, LPCTSTR sKey, LPCTSTR Default )
{
#ifdef USE_VISION_PRO
	char str[MAX_PATH];
	GetPrivateProfileString( sApp, sKey, Default, str, MAX_PATH-1, sFileName );
	return CString( str );
#endif
	return _T("");
}

//	Ini File ���� �Լ�
/****************************************************/

bool VProData::PMToolTrain( int nID, int nCam, bool patternFlag, BOOL bApplyParam )
{
#ifdef USE_VISION_PRO
	if( nID < 0 || nID >= m_nPMAlignToolCount ) return false;

	if(nCam == HIGH_1ST_CAM)
		m_CalibData[nCam] = m_dHighPixel.x;//*/gSystemINI.m_sSystemDevice.d1stHighPixel.x;
	else if(nCam == LOW_1ST_CAM)
		m_CalibData[nCam] = m_dLowPixel.x;//*/gSystemINI.m_sSystemDevice.d1stLowPixel.x;
	else if(nCam == HIGH_2ND_CAM)
		m_CalibData[nCam] = m_dHighPixel.x;//*/gSystemINI.m_sSystemDevice.d2ndHighPixel.x;
	else 
		m_CalibData[nCam] = m_dLowPixel.x;//*/gSystemINI.m_sSystemDevice.d2ndLowPixel.x;

	CComPtr<ICogPMAlignPattern> pPMPattern;
	CComQIPtr<ICogImage8Grey>	pGI;
	CComPtr<ICogRegion>			pTrainRegion;
	CComPtr<ICogPMAlignTool>	pPMTool;
	CComPtr<ICogRectangle>		pRectangle;
	CComPtr<ICogRectangleAffine> pRectangleAffine;
	CComPtr<ICogCircle>			pCircle;
	CComPtr<ICogPolygon>		pPolygon;
	CComPtr<ICogShapeModel>		pShapeModel;
	CComPtr<ICogShapeModelCollection> pShapeModelCollection;

	double						cx =0, cy =0, cw =0, ch =0, radius =0;
	VARIANT_BOOL				vb;
	CString						FileName;

	CComPtr<ICogTransform2DLinear> pOrigin;
	pOrigin.CoCreateInstance( CLSID_CogTransform2DLinear );
	
	if( !patternFlag) //if pattern
	{
		if(!bApplyParam)
			gVPro.GetUserWindow(nCam, NULL, &cx, &cy, &cw, &ch );
		else
			gVPro.GetTrainRegion(nID, cx, cy, cw, ch);
	}


//test 
//	if( m_pImg[nCam] == 0 )
//		return false;

	pGI = m_pImg[nCam];


	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];


	m_hr = pPMTool->get_Pattern( &pPMPattern );
	if( FAILED(m_hr) || pPMPattern == 0 ) return false;
	
	if (patternFlag == false ) {

		pRectangleAffine.CoCreateInstance( CLSID_CogRectangleAffine );
		pRectangleAffine->SetOriginLengthsRotationSkew(cx,cy,cw,ch,0,0);

		pRectangleAffine->put_GraphicDOFEnable( cogRectangleAffineDOFAll );
		pRectangleAffine->put_Interactive( VARIANT_TRUE );

		pRectangleAffine->QueryInterface( &pTrainRegion );
		pPMPattern->putref_TrainRegion( pTrainRegion );
		
		if( pPMTool == 0 ) return false;
		pPMTool->putref_InputImage( pGI );
		pPMPattern->putref_TrainImage( pGI );
		pPMPattern->Untrain();
		
		m_hr = pPMPattern->Train();	//
		if( FAILED(m_hr) )
			return false;

		gVPro.m_TrainAreacx[nID] = cx;
		gVPro.m_TrainAreacy[nID] = cy;
		gVPro.m_TrainAreacw[nID] = cw;
		gVPro.m_TrainAreach[nID] = ch;

		if ( m_AutoOrgSetup == true ){
			pRectangleAffine->get_CenterX( &cx );
			pRectangleAffine->get_CenterY( &cy );
			gProcess.GetTrainCoord(cx, cy, nID);		//��ϵ� ������ �߽��� ����
			
			pOrigin->put_TranslationX( cx );
			pOrigin->put_TranslationY( cy );
			pPMPattern->putref_Origin( pOrigin );
			
			pPMPattern->get_Trained( &vb );
			gVPro.m_TrainAreacpx[nID] = cx;
			gVPro.m_TrainAreacpy[nID] = cy;

		}
		else if ( m_AutoOrgSetup == false ){
			m_UserWindowShapeType = eCross;
			CComPtr<ICogPointMarker>	pCross;
			if(!bApplyParam)
				gVPro.GetUserWindow(nID, NULL, &cx, &cy, &cw, &ch );
			else
				gVPro.GetTrainRegion(nID, cx, cy, cw, ch);

			pCross.CoCreateInstance( CLSID_CogPointMarker ) ;
			pCross->SetCenterRotationSize( cx, cy, cw, (long)ch );
			pCross->put_GraphicDOFEnable ( cogPointMarkerDOFAll );
			pCross->put_Interactive ( VARIANT_TRUE );
			pCross->get_X ( &cx );
			pCross->get_Y ( &cy );
			gProcess.GetTrainCoord(cx, cy, nID);		//��ϵ� ������ �߽��� ����
			pOrigin->put_TranslationX( cx );
			pOrigin->put_TranslationY( cy );
			pPMPattern->putref_Origin( pOrigin );
			
			pPMPattern->get_Trained( &vb );

			gVPro.m_TrainAreacpx[nID] = cx;
			gVPro.m_TrainAreacpy[nID] = cy;
			
		}
	}
	else if (patternFlag == true ) {
		pPMPattern->put_TrainRegionMode( cogRegionModePixelAlignedBoundingBox );
		pPMPattern->put_TrainMode( cogPMAlignTrainModeShapeModelsWithTransform );
		pPMPattern->putref_TrainImage( NULL );
		pPMPattern->putref_TrainRegion( NULL );
		pPMPattern->Untrain();
		
		if ( gVPro.m_ShapeTypeNoData[nID] == MODEL_CIRCLE ) {
			FileName.Format(_T("Circle.bmp"));
			pCircle.CoCreateInstance( CLSID_CogCircle );
			pCircle->put_CenterX( 150 );
			pCircle->put_CenterY( 150 );
			
			radius = (gVPro.m_SizeA[nID] / gVPro.m_CalibData[nCam]) / 2.0;
			
			pCircle->put_Radius( radius );
			pCircle->get_CenterX ( &cx );
			pCircle->get_CenterY ( &cy );

			m_hr = pCircle->MakeShapeModel( 1, (CogShapeModelPolarityConstants)m_ShapePolarity, true, &pShapeModel );
			if( FAILED(m_hr) || pShapeModel == 0 ) return false;
			m_hr = pPMPattern->get_TrainShapeModels( &pShapeModelCollection );
			if( FAILED(m_hr) || pShapeModelCollection == 0 ) return false;
			pShapeModelCollection->Clear();
		}
		else if ( gVPro.m_ShapeTypeNoData[nID] == MODEL_RECT ) {
			FileName.Format(_T("Rectangle.bmp"));
			double ResolX, ResolY;
			pRectangleAffine.CoCreateInstance( CLSID_CogRectangleAffine );
			pRectangleAffine->put_CenterX( 150 );
			pRectangleAffine->put_CenterY( 150 );
			
			cw = gVPro.m_SizeA[nID] / gVPro.m_CalibData[nCam];

			ResolX = ResolutionX;
			ResolY = ResolutionY;
			ch = gVPro.m_SizeB[nID] / ((ResolY / ResolX * (gVPro.m_CalibData[nCam] * ResolX)) / ResolY);

			pRectangleAffine->put_SideXLength ( cw );
			pRectangleAffine->put_SideYLength ( ch );
			pRectangleAffine->get_CenterX ( &cx ) ;
			pRectangleAffine->get_CenterY ( &cy ) ;

			m_hr = pRectangleAffine->MakeShapeModel( 1, (CogShapeModelPolarityConstants)m_ShapePolarity, true, &pShapeModel );
			if( FAILED(m_hr) || pShapeModel == 0 ) return false;
			m_hr = pPMPattern->get_TrainShapeModels( &pShapeModelCollection );
			if( FAILED(m_hr) || pShapeModelCollection == 0 ) return false;
			pShapeModelCollection->Clear();
		}
		else if ( gVPro.m_ShapeTypeNoData[nID] == MODEL_CROSS ) {
			FileName.Format(_T("Polygon.bmp"));
			double ResolX, ResolY, ctw, cth;
			pPolygon.CoCreateInstance( CLSID_CogPolygon );
			
			double V0X, V0Y, V1X, V1Y, V2X, V2Y, V3X, V3Y, V4X, V4Y, V5X, V5Y;
			double V6X, V6Y, V7X, V7Y, V8X, V8Y, V9X, V9Y, V10X, V10Y, V11X, V11Y, VCX, VCY;
			cw = gVPro.m_SizeA[nID] / gVPro.m_CalibData[nCam]; //���α���
			ctw = gVPro.m_SizeC[nID] / gVPro.m_CalibData[nCam];

			ResolX = ResolutionX;
			ResolY = ResolutionY;
			ch = gVPro.m_SizeB[nID] / ((ResolY / ResolX * (gVPro.m_CalibData[nCam] * ResolX)) / ResolY);	//���α���
			cth = gVPro.m_SizeC[nID] / ((ResolY / ResolX * (gVPro.m_CalibData[nCam] * ResolX)) / ResolY);

			V0X = 150;
			V0Y = 150;
			V1X = V0X + ctw;
			V1Y = V0Y;

			V2X = V0X + ctw;
			V2Y = V0Y + ((ch/2)-(cth/2));
			V3X = V0X + ((cw/2)+(ctw/2));
			V3Y = V0Y + ((ch/2)-(cth/2));
			
			V4X = V0X + ((cw/2)+(ctw/2));
			V4Y = V0Y + ((ch/2)+(cth/2));
			V5X = V0X + ctw;
			V5Y = V0Y + ((ch/2)+(cth/2));
			
			V6X = V0X + ctw;
			V6Y = V0Y + ch;
			V7X = V0X;
			V7Y = V0Y + ch;
			
			V8X = V0X;
			V8Y = V0Y + ((ch/2)+(cth/2));
			V9X = V0X - ((cw/2)-(ctw/2));
			V9Y = V0Y + ((ch/2)+(cth/2));
			
			V10X = V0X - ((cw/2)-(ctw/2));
			V10Y = V0Y + ((ch/2)-(cth/2));
			V11X = V0X;
			V11Y = V0Y + ((ch/2)-(cth/2));

			VCX = V0X + (ctw/2);
			VCY = V0Y + (ch/2);
			
			pPolygon->put_NumVertices ( 12 );
			
			pPolygon->put_VertexX (0, V0X);
			pPolygon->put_VertexY (0, V0Y);
			pPolygon->put_VertexX (1, V1X);
			pPolygon->put_VertexY (1, V1Y);
			pPolygon->put_VertexX (2, V2X);
			pPolygon->put_VertexY (2, V2Y);
			pPolygon->put_VertexX (3, V3X);
			pPolygon->put_VertexY (3, V3Y);
			pPolygon->put_VertexX (4, V4X);
			pPolygon->put_VertexY (4, V4Y);
			pPolygon->put_VertexX (5, V5X);
			pPolygon->put_VertexY (5, V5Y);
			pPolygon->put_VertexX (6, V6X);
			pPolygon->put_VertexY (6, V6Y);
			pPolygon->put_VertexX (7, V7X);
			pPolygon->put_VertexY (7, V7Y);
			pPolygon->put_VertexX (8, V8X);
			pPolygon->put_VertexY (8, V8Y);
			pPolygon->put_VertexX (9, V9X);
			pPolygon->put_VertexY (9, V9Y);
			pPolygon->put_VertexX (10, V10X);
			pPolygon->put_VertexY (10, V10Y);
			pPolygon->put_VertexX (11, V11X);
			pPolygon->put_VertexY (11, V11Y);

			cx = VCX;
			cy = VCY;
			ch = cth;
						
			m_hr = pPolygon->MakeShapeModel( 1, (CogShapeModelPolarityConstants)m_ShapePolarity, true, &pShapeModel );
			if( FAILED(m_hr) || pShapeModel == 0 ) return false;
			m_hr = pPMPattern->get_TrainShapeModels( &pShapeModelCollection );
			if( FAILED(m_hr) || pShapeModelCollection == 0 ) return false;
			pShapeModelCollection->Clear();
			
		}
		else
		{
			return false;   //�Ⱦ��� Model ���� return false �� �����ָ� ���α׷� ����.
		}

		if( m_ShapePolarity == -1 ){
			pShapeModelCollection->Add( pShapeModel, 0 );
			pPMPattern->put_IgnorePolarity( VARIANT_FALSE );
			gVPro.m_ShapePolarityData[nID] = -1;
		}
		else if( m_ShapePolarity == 0 ){
			pShapeModelCollection->Add( pShapeModel, 0 );
			pPMPattern->put_IgnorePolarity( VARIANT_TRUE );
			gVPro.m_ShapePolarityData[nID] = 0;
		}
		else if( m_ShapePolarity == 1 ){
			pShapeModelCollection->Add( pShapeModel, 0 );
			pPMPattern->put_IgnorePolarity( VARIANT_FALSE );
			gVPro.m_ShapePolarityData[nID] = 1;
		}
		
		gVPro.m_TrainAreacx[nID] = cx;
		gVPro.m_TrainAreacy[nID] = cy;
		gVPro.m_TrainAreacw[nID] = cw;
		gVPro.m_TrainAreach[nID] = ch;

		gProcess.GetTrainCoord(cx, cy, nID);		//��ϵ� ������ �߽��� ����
		
		pOrigin->put_TranslationX( cx );
		pOrigin->put_TranslationY( cy );
		pPMPattern->putref_Origin( pOrigin );
		
		gVPro.m_TrainAreacpx[nID] = cx;
		gVPro.m_TrainAreacpy[nID] = cy;
		
		m_hr = pPMPattern->Train();	//
		if( FAILED(m_hr) ) return false;

		pPMPattern->get_Trained( &vb );
	}
	
	if( pGI ) pGI.Release();
	pPMPattern->GetTrainedPatternImage(&pGI);
	m_pDisplay[DISPLAYA]->putref_Image(pGI);
	m_pDisplay[DISPLAYB]->putref_Image(pGI);
	
	pPMPattern.Release();
	pPMTool.Release();

	if (patternFlag == true ){
		if ( gVPro.m_ShapeTypeNoData[nID] == MODEL_CIRCLE ) {
			LoadImage(FileName, true, 8);
			gVPro.m_ShapeTrainBool[nID] = MODEL_CIRCLE ;
		}
		else if( gVPro.m_ShapeTypeNoData[nID] == MODEL_RECT ) {
			LoadImage(FileName, true, 8);
			gVPro.m_ShapeTrainBool[nID] = MODEL_RECT ;
		}
		else if( gVPro.m_ShapeTypeNoData[nID] == MODEL_CROSS ) {
			LoadImage(FileName, true, 8);
			gVPro.m_ShapeTrainBool[nID] = MODEL_CROSS ;
		}
	}
	else{
		gVPro.m_ShapeTrainBool[nID] = MODEL_PATTERN ;
	}

	return (vb ? true : false );
#endif
	return TRUE;
}

bool VProData::LoadImage(CString lpszFileName, bool bDisplay, int DisplayNo)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogImageFileTool>		pImageFileTool;
	CComPtr<ICogImageFile>			pImageFile;
	CComPtr<ICogImage>				pImg;
	CComBSTR aVF;

	aVF.m_str = lpszFileName.AllocSysString();
	pImageFileTool.CoCreateInstance( CLSID_CogImageFileTool );
	pImageFileTool->get_Operator( &pImageFile );
	m_hr = pImageFile->Open( aVF, cogImageFileModeRead );
	if( FAILED(m_hr) ) return 0;
	m_hr = pImageFileTool->Run();
	if( FAILED(m_hr) ) return 0;
	m_hr = pImageFileTool->get_OutputImage( &pImg );
	if( SUCCEEDED(m_hr) ) {
		m_pImg[DisplayNo] = pImg;
		if(bDisplay) ImageDisplay(DisplayNo, true);
	}
	pImageFile->Close();
#endif
	return true;
}


void VProData::CheckPMAlignToolInstanceShape(int nID)
{

/*	if( pCogPMAlignTool2[nID] == 0 ) {
		m_hr = pCogPMAlignTool2[nID].CoCreateInstance( CLSID_CogPMAlignTool );
		if( SUCCEEDED(m_hr) && pCogPMAlignTool2[nID] ) {
			Wchar	Buffer2[64];
			if( pCogPMAlignTool2[nID] == 0 ) return;
			swprintf( Buffer2, _T("PMAlignTool_SHAPE_%d"), nID );
			pCogPMAlignTool2[nID]->put_ToolName( Buffer2 );
		}
	}
	*/
}
void VProData::PMAlignToolAddToolGroup_Shape(int nID)
{
/*		
	CComQIPtr<ICogTool> pTool;
	if( pCogPMAlignTool[nID] == 0 ) return;
	m_hr = pCogPMAlignTool2[nID].QueryInterface( &pTool );
	if( SUCCEEDED(m_hr) && pTool ) {
		if( m_pToolGroup == 0 ) m_pToolGroup.CoCreateInstance( CLSID_CogToolGroup );
		m_hr = m_pToolGroup->Add( pTool, -1 );
	}
*/

}

void VProData::ChangeCam(int nCamNo)
{
	if(nCamNo < 0 || nCamNo > 3)
		return;
	m_nCamNo = nCamNo;
}

//Pattern was Trained ?
BOOL VProData::GetTrained(int nPattern)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogPMAlignPattern> pPMPattern;
	CComPtr<ICogPMAlignTool>	pPMTool;
	VARIANT_BOOL vb;

	CheckPMAlignToolInstance( nPattern );
	pPMTool = pCogPMAlignTool[nPattern];
	if( pPMTool == 0 )
		return FALSE;
	
	m_hr = pPMTool->get_Pattern( &pPMPattern );
	m_hr = pPMPattern->get_Trained( &vb );

	return (vb ? TRUE : FALSE );
#endif 
	return TRUE;
}
//trained pattern display 
void VProData::DisplayTrainedPatten(int nPattern)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogPMAlignPattern> pPMPattern;
	CComPtr<ICogPMAlignTool>	pPMTool;
	CComQIPtr<ICogImage8Grey>	pGI;
//	VARIANT_BOOL vb;
	
	CheckPMAlignToolInstance( nPattern );
	pPMTool = pCogPMAlignTool[nPattern];
	if( pPMTool == 0 )
		return;
	
	m_hr = pPMTool->get_Pattern( &pPMPattern );

	pPMPattern->GetTrainedPatternImage(&pGI);
	m_pDisplay[DISPLAYB]->putref_Image(pGI);
	m_pDisplay[DISPLAYA]->putref_Image(pGI);
#endif
}

BOOL VProData::SetTrainRegion(int nID ,int nCam)
{
#ifdef USE_VISION_PRO
	HRESULT hr = -1;
	CComPtr<ICogInteractiveGraphicsContainer>	pInteractiveGrapicContainer;
	CComPtr<ICogGraphicInteractive>				InteractiveGraphic;
	CComPtr<ICogRectangleAffine>				tRectangleAffine;
	CComPtr<ICogRegion>							m_Region;		
	CComPtr<ICogPMAlignPattern>					pPMPattern;
	CComPtr<ICogPMAlignTool>					pPMTool;
	double	dCenterX, dCenterY, dWidth, dHeight, dRotate, dSkew;
	CComQIPtr<ICogImage8Grey>		pGI;
	
	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];
	if( pPMTool == 0 )
		return FALSE;

	hr = m_pDisplay[nCam]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	if( FAILED(hr) || pInteractiveGrapicContainer == 0 ) return FALSE;
	
	hr = pPMTool->get_Pattern (&pPMPattern);
	if( FAILED(hr) || pPMPattern == 0 ) return FALSE;
	
	hr = pInteractiveGrapicContainer->get_Item( 0 , &InteractiveGraphic );
	if( FAILED(hr) || InteractiveGraphic == 0 ) return FALSE;
	long lCount;
	pInteractiveGrapicContainer->get_Count(&lCount);

	if(lCount != 1)
		return FALSE; 

	//���⿩�� 
 	CComQIPtr<ICogRectangleAffine>(InteractiveGraphic)->GetCenterLengthsRotationSkew( &dCenterX, &dCenterY, &dWidth, &dHeight, &dRotate, &dSkew );
	
	tRectangleAffine.CoCreateInstance(CLSID_CogRectangleAffine);
	
	tRectangleAffine->SetCenterLengthsRotationSkew ( dCenterX, dCenterY, dWidth, dHeight, dRotate, dSkew);
	
	tRectangleAffine.QueryInterface( &m_Region );
	
	hr = pPMPattern->putref_TrainRegion (m_Region);
	if( FAILED(hr) || m_Region == 0 ) return FALSE;

	
	hr = pPMTool->putref_Pattern (pPMPattern);
	if( FAILED(hr) || pPMPattern == 0 ) return FALSE;
	
	tRectangleAffine.Release();
	m_Region.Release();
	pInteractiveGrapicContainer.Release();
	InteractiveGraphic.Release();
	pPMPattern.Release();
#endif
	return TRUE;
}

BOOL VProData::GrabImage(int nID, int nCam)
{
#ifdef USE_VISION_PRO
	HRESULT hr = -1;
	CComQIPtr<ICogImage8Grey>		pGI;
	CComPtr<ICogPMAlignPattern>		pPMPattern;
	CComPtr<ICogPMAlignTool>		pPMTool;
	
	CheckPMAlignToolInstance( nID );
	pPMTool = pCogPMAlignTool[nID];
	if( pPMTool == 0 )
		return FALSE;

	pGI = m_pImg[nCam];
	
	pPMTool->putref_InputImage ( pGI );					//Input Img
	
	hr = pPMTool->get_Pattern(&pPMPattern);
	if( FAILED(hr) || pPMPattern == 0 ) return FALSE;
	
	pPMPattern->putref_TrainImage( pGI );				//Train Grab Image
	
	pPMTool->putref_Pattern (pPMPattern);
	
	m_pDisplay[DISPLAYB]->putref_Image(pGI);
	m_pDisplay[DISPLAYA]->putref_Image(pGI);

	pGI.Release();
	pPMPattern.Release();
#endif
//	ClearInteractiveGraphics(nCam);
	return TRUE;
}

void VProData::GetTrainRegion(int nID, double& cx, double& cy, double& cw, double& ch)
{
#ifdef USE_VISION_PRO
	cx = gVPro.m_TrainAreacx[nID];
	cy = gVPro.m_TrainAreacy[nID];
	cw = gVPro.m_TrainAreacw[nID];
	ch = gVPro.m_TrainAreach[nID];
#endif
}

void VProData::GetSearchRegion(int nID, double &cx, double &cy, double &cw, double &ch)
{
#ifdef USE_VISION_PRO
	cx = gVPro.m_SearchAreach[nID];
	cy = gVPro.m_SearchAreacy[nID];
	cw = gVPro.m_SearchAreacw[nID];
	ch = gVPro.m_SearchAreach[nID];
#endif
}


void VProData::TransformPixel()
{
#ifdef USE_VISION_PRO
	for(int i = 0 ; i < MAX_CAMERA ; i ++ )
	{
		m_2DTrans[i].SetNumPoint(4);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][0].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][0].y, 0);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][0].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][0].y, 0);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][1].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][1].y, 1);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][1].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][1].y, 1);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][2].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][2].y, 2);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][2].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][2].y, 2);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][3].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][3].y, 3);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][3].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][3].y, 3);
		
		m_2DTrans[i].Transform();
	}
#endif
}

void VProData::CalPixelDistance()
{
#ifdef USE_VISION_PRO
	double dHighCamPixelX, dHighCamPixelY, dLowCamPixelX, dLowCamPixelY;
	double dHighFOVX, dHighFOVY, dLowFOVX, dLowFOVY;
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].x)
	{
		dHighCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].x;
		dHighFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].x; 
		m_dHighPixel.x = fabs(dHighFOVX / dHighCamPixelX);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].x)
	{
		dHighCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].x;
		dHighFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].x; 
		m_dHighPixel.x = fabs(dHighFOVX / dHighCamPixelX);
	}
	else
	{
		m_dHighPixel.x = m_dHighPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}

	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].y)
	{
		dHighCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].y;
		dHighFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].y;
		m_dHighPixel.y = fabs(dHighFOVY / dHighCamPixelY);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].y)
	{
		dHighCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].y;
		dHighFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].y;
		m_dHighPixel.y = fabs(dHighFOVY / dHighCamPixelY);
	}
	else
	{
		m_dHighPixel.x = m_dHighPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}

	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].x)
	{
		dLowCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].x;
		dLowFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].x; 
		m_dLowPixel.x = fabs(dLowFOVX / dLowCamPixelX);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].x)
	{
		dLowCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].x;
		dLowFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].x; 
		m_dLowPixel.x = fabs(dLowFOVX / dLowCamPixelX);
	}
	else
	{
		m_dLowPixel.x = m_dLowPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
	
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].y)
	{
		dLowCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].y;
		dLowFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].y;
		m_dLowPixel.y = fabs(dLowFOVY / dLowCamPixelY);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].y)
	{
		dLowCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].y;
		dLowFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].y;
		m_dLowPixel.y = fabs(dLowFOVY / dLowCamPixelY);
	}
	else
	{
		m_dLowPixel.x = m_dLowPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
#endif
}

BOOL VProData::LogicProcess(int nCam, int nImage, int nIndex, int nLogicPlrt, bool bDisplay)
{
#ifdef USE_VISION_PRO
	if(gSystemINI.m_sSystemDevice.nBlob == 0)
		return TRUE;

	HRESULT hr = -1;
	if(nCam < 0) 
		return FALSE;
	CComPtr<ICogBlobTool>		pBlobTool;
	CComPtr<ICogBlobResult>		pBlobResult;
	CComPtr<ICogBlobResults>	pBlobResults;
	CComPtr<ICogBlobResultCollection>	pBlobResultCollection;
	CComPtr<ICogBlobParams>		pBlobParams;
	CComPtr<ICogBlobSegmentationParams>	pBlobSegParams;
	CComQIPtr<ICogImage8Grey>	pGI;

	
	pGI = m_pImg[nCam];
	
	if ( pBlobTool == 0 ) pBlobTool.CoCreateInstance ( CLSID_CogBlobTool ) ;
	
	pBlobTool->putref_InputImage ( pGI );
	pBlobTool->get_RunParams ( &pBlobParams );
	pBlobParams->get_SegmentationParams ( &pBlobSegParams );
	
	if ( nLogicPlrt == 1 ) pBlobSegParams->SetSegmentationHardFixedThreshold ( 255 - gSystemINI.m_sSystemDevice.nBlob, cogBlobSegmentationPolarityDarkBlobs );
	else pBlobSegParams->SetSegmentationHardFixedThreshold ( gSystemINI.m_sSystemDevice.nBlob, cogBlobSegmentationPolarityLightBlobs );
	pBlobParams->putref_SegmentationParams ( pBlobSegParams );
	
	pBlobTool->putref_RunParams ( pBlobParams );
	
	hr = pBlobTool->Run ();
	if( FAILED(hr) || pBlobTool == 0  )  return FALSE;
	pBlobTool->get_Results ( &pBlobResults );
	
	pGI.Release ();
	pBlobResults->CreateBlobImage ( VARIANT_TRUE, VARIANT_TRUE, 0, &pGI );
	//pBlobResults->CreateSegmentedImage ( cogBlobSegmentedImage, VARIANT_TRUE, &pGI2 );
	
	if (bDisplay)	m_pDisplay[nCam]->putref_Image(pGI);
	
	m_pImg[nCam] = pGI;
	
	pBlobTool.Release();
	pBlobResult.Release();
	pBlobResults.Release();
	pBlobResultCollection.Release();
	pBlobParams.Release();
	pBlobSegParams.Release();
	pGI.Release();
#endif
	return TRUE;
}

void VProData::InitVisionPixelData(int nCam)
{
#ifdef USE_VISION_PRO

	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][0].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][0].y = 0;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][0].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][0].y = 0;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][1].y = 0;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][1].y = 0;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][2].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][2].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	
	TransformPixel();
	CalPixelDistance();
#endif
}

void VProData::InitDistancePerPixel()
{
#ifdef USE_VISION_PRO
	m_dHighPixel.x = fabs(gSystemINI.m_sSystemDevice.dHighFOVX / gSystemINI.m_sSystemDevice.nCameraPixelX);
	m_dHighPixel.y = fabs(gSystemINI.m_sSystemDevice.dHighFOVY / gSystemINI.m_sSystemDevice.nCameraPixelY);
	m_dLowPixel.x = fabs(gSystemINI.m_sSystemDevice.dLowFOVX / gSystemINI.m_sSystemDevice.nCameraPixelX);
	m_dLowPixel.y = fabs(gSystemINI.m_sSystemDevice.dLowFOVY / gSystemINI.m_sSystemDevice.nCameraPixelY);
#endif
}

bool VProData::SaveImg(int iDisplayNo, CString lpszFileName)
{
#ifdef USE_VISION_PRO
	CComPtr<ICogImageFileTool>		pImageFileTool;
	CComPtr<ICogImageFile>			pImageFile;
	CComBSTR aVF;
	
	aVF.m_str = lpszFileName.AllocSysString();
	pImageFileTool.CoCreateInstance( CLSID_CogImageFileTool );
	pImageFileTool->putref_InputImage( m_pImg[iDisplayNo] );
	pImageFileTool->get_Operator( &pImageFile );
	m_hr = pImageFile->Open( aVF, cogImageFileModeWrite );
	if( FAILED(m_hr) ) return 0;
	m_hr = pImageFileTool->Run();
	if( FAILED(m_hr) ) return 0;
	pImageFile->Close();
#endif
	return true;
}


void VProData::SetBlobValue(int nWhiteBlob)
{
	for(int i = 0; i<CREATEVP; i++)
	{
		m_nBlob[i] = nWhiteBlob;
	}
}
int VProData::PMToolFindFor4Way(int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag)
{
#ifdef USE_VISION_PRO
	double dCoarse = 5;
	BOOL bOverFound = TRUE;
	BOOL bScoreFail = FALSE;

	BOOL bCheckSizeAndRatioFlagError = FALSE;//20170929

	long	nFound = 0;
	double	px = 0, py = 0, rotate = 0, score = 0;
	double	px2 = 0, py2 = 0, rotate2 = 0, score2 = 0, scalecx = 0, scalecy = 0, realscalecx = 0;
	VARIANT_BOOL	accepted = FALSE;
	VARIANT_BOOL	accepted2 = FALSE;
	int nBestIndex = 0;
	CComPtr<ICogPMAlignResult> pPMResultArray[100];
	CComPtr<ICogTransform2DLinear> pPoseArray[100];
	double scalecxArray[100], scalecyArray[100], scoreArray[100], scaleArray[100];

	double scalecxArrayTemp[100], scalecyArrayTemp[100];

	CComQIPtr<ICogImage8Grey> pGI = m_pImg[iDisplay];
	if( iPatternNo < 0 || iPatternNo >= m_nPMAlignToolCount ) return 0;

	CComPtr<ICogInteractiveGraphicsContainer>	pInteractiveGrapicContainer;
	CComPtr<ICogRegion>							pSearchRegion;
	CComPtr<ICogGraphicLabel>					pLabel;
	CComPtr<ICogPMAlignTool>					pPMTool;
	CComPtr<ICogPMAlignPattern>					pPMPattern;
	VARIANT_BOOL								vb;
	WCHAR										Buffer[64];


	//	Get Results
	CComPtr<ICogPMAlignResult> pPMResult;
	CComPtr<ICogTransform2DLinear> pPose, pPose2;

	CComPtr<ICogPMAlignResult> pPMResult2;
	CComPtr<ICogPointMarker>	pCross2;

	//	Graphic
	CComPtr<ICogPointMarker>	pCross[100];
	CComPtr<ICogPointMarker>	pTrainCross[100];
	CComPtr<ICogPointMarker>	pCircleResult[100];
	CComPtr<ICogCompositeShape> CompositeShape[100];

	//	Get Results
	CComPtr<ICogPMAlignResults> pPMResults;


/********************** ��� �ʱ�ȭ *****************************/
//	gProcess.m_ResultData[iPatternNo].dx = 0;
//	gProcess.m_ResultData[iPatternNo].dy = 0;
	
//�ι�° �˻� ��� ���� �� ��
//	if (iPatternNo == CAM2) {
//		gProcess.m_ResultData[5].dx = 0;
//		gProcess.m_ResultData[5].dy = 0;
//	}
/******************************************************************/
//	if (patternFlag) {
		CheckPMAlignToolInstance( iPatternNo );
		pPMTool = pCogPMAlignTool[iPatternNo];
		if( pPMTool == 0 ) {
			return 0;
		}
//	}
//	else{
//		CheckPMAlignToolInstance( iPatternNo );
//		pPMTool = pCogPMAlignTool[iPatternNo];
//		if( pPMTool == 0 ) {
//			return false;
//		}
//	}

	m_hr = m_pDisplay[iDisplay]->get_InteractiveGraphics( &pInteractiveGrapicContainer );
	if( FAILED(m_hr) || pInteractiveGrapicContainer == 0 ) return 0;
	pInteractiveGrapicContainer->Clear();

	if(m_bROIShow)
	{
		CComPtr<ICogPointMarker>	pCrossLine;
		pCrossLine.CoCreateInstance( CLSID_CogPointMarker );
		pCrossLine->put_Interactive( VARIANT_TRUE );
		pCrossLine->put_GraphicType( cogPointMarkerGraphicTypeCross );
		pCrossLine->put_SizeInScreenPixels( m_ImageWidth );
		pCrossLine->put_X( m_ImageWidth/2 );
		pCrossLine->put_Y( m_ImageHeight/2 );
		pCrossLine->put_Rotation( 0 );
		pCrossLine->put_Color( cogColorPurple );
		BSTR cName;
		cName = SysAllocString(L"CenterLine");
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCrossLine), cName, VARIANT_TRUE );
		SysFreeString(cName);
		pCrossLine.Release();
	}

	pLabel.CoCreateInstance( CLSID_CogGraphicLabel );
	pLabel->put_X( 10 );
	pLabel->put_Y( 0 );
	pLabel->put_Alignment( cogGraphicLabelAlignmentTopLeft );
	pLabel->put_Color( cogColorRed );

	m_hr = pPMTool->get_Pattern( &pPMPattern );
	if( FAILED(m_hr) || pPMPattern == 0 ) {
		return 0;
	}
	m_hr = pPMPattern->get_Trained( &vb );

	CString strFile, strResult;
	strFile.Format(_T("VisionFail"));
	
	if( FAILED(m_hr) || vb == 0 ) {
		swprintf_s( Buffer, L"Not trained" );
		strResult = Buffer;
		pLabel->put_Text( Buffer );
		pLabel->put_Color( cogColorRed );
		pLabel->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
		return 0;   
	}

	if (patternFlag == true && gVPro.m_bAArea == false){
		double cx, cy, cw, ch;
		cx = gVPro.m_SearchAreacx[iDisplay];
		cy = gVPro.m_SearchAreacy[iDisplay];
		cw = gVPro.m_SearchAreacw[iDisplay];
		ch = gVPro.m_SearchAreach[iDisplay];

		CComPtr<ICogRectangle>	pRectangle;
		pRectangle.CoCreateInstance(CLSID_CogRectangle);
		pRectangle->SetCenterWidthHeight( cx, cy, cw, ch );
		pRectangle->QueryInterface( &pSearchRegion );
		pPMTool->putref_SearchRegion( pSearchRegion );
		pRectangle.Release();

		pSearchRegion->EnclosingRectangle( cogCopyShapeAll, &pRectangle );

		pRectangle->put_Color( cogColorBlue );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pRectangle), NULL, VARIANT_TRUE );
	}
	else if (patternFlag == true && gVPro.m_bAArea == true){
		pPMTool->putref_SearchRegion( NULL );
	}
	else if (patternFlag == false) {
		m_hr = pPMTool->get_SearchRegion( &pSearchRegion );
		if( SUCCEEDED(m_hr) && pSearchRegion ) {
			CComPtr<ICogRectangle>	pRectangle;
			pSearchRegion->EnclosingRectangle( cogCopyShapeAll, &pRectangle );
			pRectangle->put_Color( cogColorBlue );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pRectangle), NULL, VARIANT_TRUE );
		}
	}
	

	while (dCoarse >= 3)
	{
		//	Run Parameters
		CComPtr<ICogPMAlignRunParams> pPMRunParam;
		CComPtr<ICogPMAlignZoneScale> pZoneScale, pZoneScaleY, pZoneScaleX;
		CComPtr<ICogPMAlignZoneAngle > pZoneAngle;

		bCheckSizeAndRatioFlagError = FALSE;//20170929

		if(bOverFound)
		{
			pPMResults.Release();
			pPMResult.Release();
			pPose.Release();
			bOverFound = FALSE;
			pPMTool->get_RunParams( &pPMRunParam );
			pPMRunParam->put_AcceptThreshold ( 0.6 );
			pPMRunParam->put_ScoreUsingClutter(FALSE);
			pPMRunParam->put_GrainLimitsUsePattern(FALSE); //bskim ���� �Ѱ� ��� ���� -->�ǵμ� Ž���� ������ ũ�Ⱑ �ٸ����(�������� ����) �������־�� 
			pPMRunParam->put_GrainLimitCoarse(dCoarse); //bskim ���� ��ĥ�� ����
			pPMRunParam->put_GrainLimitFine(1);	//bskim ���� ���� ����
	
			if (patternFlag)
			{
				pPMRunParam->get_ZoneScale( &pZoneScale );
				pZoneScale->put_Configuration( cogPMAlignZoneLowHigh );
				pZoneScale->put_Low( gVPro.m_ScaleN[iPatternNo] );
				pZoneScale->put_High( gVPro.m_ScaleP[iPatternNo] );
				double dOverlap = 1;
				pZoneScale->put_Overlap(dOverlap);

				pPMRunParam->get_ZoneScaleY( &pZoneScaleY );
				pPMRunParam->get_ZoneScaleX( &pZoneScaleX );
				if(m_dXYRatio[iPatternNo] == 0)	//aspect Ratio�� 0�̸� ZoneScale Y ���� ���� �ʵ��� (fiducial ã������ 0 ����)
				{
					pZoneScaleY->put_Configuration( cogPMAlignZoneNominal );
					pZoneScaleY->put_Nominal(1);
				}
				else
				{
					pZoneScaleY->put_Configuration( cogPMAlignZoneLowHigh );
					pZoneScaleY->put_Low( 1 - m_dXYRatio[iPatternNo] );
					pZoneScaleY->put_High( 1 + m_dXYRatio[iPatternNo] );
					pZoneScaleY->put_Overlap(dOverlap);

					pZoneScaleX->put_Configuration(cogPMAlignZoneNominal);
					pZoneScaleX->put_Nominal(1);
		/*			pZoneScaleX->put_Configuration(cogPMAlignZoneLowHigh);
					pZoneScaleX->put_Low(1 - m_dXYRatio[iPatternNo]);
					pZoneScaleX->put_High(1 + m_dXYRatio[iPatternNo]);
					pZoneScaleX->put_Overlap(dOverlap);
		*/
				}

				pPMRunParam->get_ZoneAngle( &pZoneAngle );
				pZoneAngle->put_Configuration( cogPMAlignZoneLowHigh );

				if (gVPro.m_ShapeTypeNo == MODEL_CIRCLE)
				{
					pZoneAngle->put_Low( 0 );
					pZoneAngle->put_High( 0 );
				}
				else
				{
					pZoneAngle->put_Low( -m_dAngle[iPatternNo] );
					pZoneAngle->put_High( m_dAngle[iPatternNo] );
				}
			}

			//	Set Image
			if( m_pImg[iDisplay] == 0 ) {
				return 0;	
			}
			
			pPMTool->putref_InputImage( pGI );
			//	Run
			m_hr = pPMTool->Run();
			if( FAILED(m_hr) ) {
				swprintf_s( Buffer, L"Pattern not found" );
				strResult = Buffer;
				pLabel->put_Text( Buffer );
				pLabel->put_Color( cogColorRed );
				pLabel->put_Interactive( VARIANT_TRUE );
				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				if( dCoarse <= 3)
					return 0;
			}
	
			m_hr = pPMTool->get_Results( &pPMResults );
			if( FAILED(m_hr) || pPMResults == 0  )  
				return 0;

			m_hr = pPMResults->get_Count( &nFound );
	
			if( FAILED(m_hr) )  
				return 0;

			if( nFound < 1 ) {
				swprintf_s( Buffer, L"Pattern not found" );
				strResult = Buffer;
				pLabel->put_Text( Buffer );
				pLabel->put_Color( cogColorRed );
				pLabel->put_Interactive( VARIANT_TRUE );
				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
				return 0;
			}

			gVariable.InitCognixResult();



				for(int i = 0; i<100; i++)
				{
					if( pPMResultArray != NULL)
						pPMResultArray[i].Release();
					if( pPoseArray != NULL)
						pPoseArray[i].Release();
				}


				gDProject.m_dFiducialResultScore = -1;
				int nLoopMax = (nFound > 100) ? 100 : nFound;
				BOOL bPass = FALSE;
				BOOL bSizeCheck = FALSE;
				BOOL bRatioCheck = FALSE;
				double dMin = 1.7976931348623158e+308;
				double dTemp = 0;
					
				memset(pPMResultArray, 0x00, sizeof(pPMResultArray));
				memset(pPoseArray, 0x00, sizeof(pPoseArray));
				memset(scalecxArray, 0x00, sizeof(scalecxArray));
				memset(scalecyArray, 0x00, sizeof(scalecyArray));
				memset(scaleArray, 0x00, sizeof(scaleArray));
				memset(scoreArray, 0x00, sizeof(scoreArray));

				memset(scalecxArrayTemp, 0x00, sizeof(scalecxArrayTemp));
				memset(scalecyArrayTemp, 0x00, sizeof(scalecyArrayTemp));



				double dScaleForOrder[100];
				double dScaleForOrderTemp[100];
				for(int ii = 0; ii < 100; ii++)
				{
					 dScaleForOrder[ii] = 999.;
					 dScaleForOrderTemp[ii] = 999.;
				}

				for(int i=0; i<nLoopMax; i++)
				{
					pPMResults->get_Item( i, &pPMResultArray[i] );
					pPMResultArray[i]->GetPose( &pPoseArray[i] );
					//			pPoseArray[i]->get_TranslationX( &px );
					//			pPoseArray[i]->get_TranslationY( &py );
					//			pPoseArray[i]->get_Rotation( &rotate );
					pPoseArray[i]->get_ScalingX ( &scalecxArray[i] );
					pPoseArray[i]->get_ScalingY ( &scalecyArray[i] );
					pPoseArray[i]->get_Scaling ( &scaleArray[i] );


					pPMResultArray[i]->get_Score(&scoreArray[i]);
					//			pPMResultArray[i]->get_Accepted( &accepted );

					if ((scalecxArray[i] <= m_ScaleP[iPatternNo] && scalecxArray[i] >= m_ScaleN[iPatternNo]) &&
						(scalecyArray[i] <= m_ScaleP[iPatternNo] && scalecyArray[i] >= m_ScaleN[iPatternNo]))
						bSizeCheck = TRUE;

					scalecxArrayTemp[i] = scalecxArray[i];
					scalecyArrayTemp[i] = scalecyArray[i];
					// ������ üũ
					scalecyArray[i] = scalecyArray[i] - scalecxArray[i];

					if(m_dXYRatio[iPatternNo] >= fabs(scalecyArray[i]))
						bRatioCheck = TRUE;

					    dScaleForOrder[i] = fabs(scalecyArray[i]);
	
         
						  gVariable.m_CognixTemp[i].bUse = TRUE;
						  gVariable.m_CognixTemp[i].dOffsetReuslt_Pixcel.x = 0;
						  gVariable.m_CognixTemp[i].dOffsetReuslt_Pixcel.y = 0;
						  gVariable.m_CognixTemp[i].dOffsetReuslt_mm.x = 0;
						  gVariable.m_CognixTemp[i].dOffsetReuslt_mm.y = 0;
						  gVariable.m_CognixTemp[i].dScaleResult.x = scalecxArrayTemp[i];
						  gVariable.m_CognixTemp[i].dScaleResult.y = scalecyArrayTemp[i];
						  gVariable.m_CognixTemp[i].dScaleGap = scalecyArray[i];
						  gVariable.m_CognixTemp[i].dHoleSize.x = scalecxArrayTemp[i] * gVPro.m_SizeA[iPatternNo];
						  gVariable.m_CognixTemp[i].dHoleSize.y = scalecyArrayTemp[i] * gVPro.m_SizeA[iPatternNo];
						  gVariable.m_CognixTemp[i].dScoreValue = scoreArray[i];
						  gVariable.m_CognixTemp[i].bSizeCheck = bSizeCheck;
						  gVariable.m_CognixTemp[i].bRatioCheck = bRatioCheck;
						  gVariable.m_CognixTemp[i].nHoleSortIndex = -1;
						  gVariable.m_CognixTemp[i].nHoleOriginIndex = i;
						  gVariable.m_CognixTemp[i].bFinalSuccess = FALSE;
						  

				}
				


				for(int ii = 0; ii < nLoopMax; ii++)
				{
					//TRACE("Before %d \t %.5f \n",ii,dScaleForOrder[ii]);
					dScaleForOrderTemp[ii] = dScaleForOrder[ii];
				}

				gVariable.SetLineUpValue_double(ASCENDING_ORDER,dScaleForOrder,nLoopMax);
				/*
				for(int ii = 0; ii < nLoopMax; ii++)
				{
					TRACE("Cal %d \t %.5f \n",ii,dScaleForOrder[ii],scoreArray[ii]);
				}
				*/
				




				for(int ii = 0; ii < nLoopMax; ii++)
				{
					for(int jj = 0; jj < nLoopMax; jj++)
					{

						double dGap = fabs(dScaleForOrderTemp[jj]);

						if(fabs(dScaleForOrder[ii] - dGap) < 0.0001)
						{
							gVariable.m_CognixTemp[jj].nHoleSortIndex = ii;
							break;
						}
					}
				}


				int nCount = 0;
				BOOL bRepeatFind = FALSE;
				BOOL bLoopEnd = FALSE;
				for(int ii = 0; ii < nLoopMax; ii++)
				{

					bRepeatFind = FALSE;
					for(int jj = 0; jj < nLoopMax; jj++)
					{

						int nSortIndex =  gVariable.m_CognixTemp[jj].nHoleSortIndex;

						if(ii != nSortIndex)
							continue;

						BOOL bRatioCheck = gVariable.m_CognixTemp[jj].bRatioCheck;
						BOOL bSizeCheck = gVariable.m_CognixTemp[jj].bSizeCheck;


						int Origin1 = gVariable.m_CognixTemp[jj].nHoleOriginIndex;
						double dPx1,dPY1;
						pPoseArray[Origin1]->get_TranslationX( &dPx1 );
						pPoseArray[Origin1]->get_TranslationY( &dPY1 );

					//	if(!bRatioCheck || !bSizeCheck )
						//	continue;


						for(int cc = 0; cc < nCount; cc++)
						{
							int Origin2 = gVariable.m_CognixFinalResult[cc].nHoleOriginIndex;
							double dPx2,dPY2;
							pPoseArray[Origin2]->get_TranslationX( &dPx2 );
							pPoseArray[Origin2]->get_TranslationY( &dPY2 );

							double dPxGap = fabs(dPx1 - dPx2);
							double dPYGap = fabs(dPY1 - dPY2);

							if(dPxGap < 3 && dPYGap < 3)
							{
								bRepeatFind = TRUE;
								break;
							}
						}

						if(bRepeatFind)
							continue;

						gVariable.m_CognixFinalResult[nCount] = gVariable.m_CognixTemp[jj];
						nCount++;

						if(nCount == 4)
						{
							bLoopEnd = TRUE;
						}
						break;
					}

					if(bLoopEnd)
						break;
				}




		}
		else
		{
			break;
		}

		dCoarse--;
	
	
		pPMRunParam.Release();
		pZoneScale.Release();
		pZoneScaleY.Release();
		pZoneScaleX.Release();
		pZoneAngle.Release();
//		pGI.Release();
		//	Graphic
	}
//////////////////////////////////////////////////////////////////////////////////////



	for(int nShotCount = 0; nShotCount < 4; nShotCount++) //�׳� ȭ�� ǥ��
	{
		if(gVariable.m_CognixFinalResult[nShotCount].bUse == FALSE)
			continue;
		int nOrigin = gVariable.m_CognixFinalResult[nShotCount].nHoleOriginIndex;


		realscalecx = gVariable.m_CognixFinalResult[nShotCount].dScaleResult.x;
		double realscalecy = gVariable.m_CognixFinalResult[nShotCount].dScaleResult.y;
		double SclaeGap = gVariable.m_CognixFinalResult[nShotCount].dScaleGap;
		score = gVariable.m_CognixFinalResult[nShotCount].dScoreValue;
		BOOL bRatioCheck = gVariable.m_CognixFinalResult[nShotCount].bRatioCheck;
		BOOL bSizeCheck = gVariable.m_CognixFinalResult[nShotCount].bSizeCheck;


		pPoseArray[nOrigin]->get_TranslationX( &px );
		pPoseArray[nOrigin]->get_TranslationY( &py );
		pPoseArray[nOrigin]->get_Rotation( &rotate );
		pPMResultArray[nOrigin]->get_Score( &score );
		pPMResultArray[nOrigin]->get_Accepted( &accepted );

		if( bShowResult ) {
			//pInteractiveGrapicContainer->Clear();

			pCross[nShotCount].CoCreateInstance( CLSID_CogPointMarker );
			pCross[nShotCount]->put_Interactive( VARIANT_TRUE );
			pCross[nShotCount]->put_GraphicType( cogPointMarkerGraphicTypeCross );
			pCross[nShotCount]->put_SizeInScreenPixels( 30 );
			pCross[nShotCount]->put_X( px );
			pCross[nShotCount]->put_Y( py );
			pCross[nShotCount]->put_Rotation( rotate );
			if( accepted )	pCross[nShotCount]->put_Color( cogColorGreen );
			else			pCross[nShotCount]->put_Color( cogColorGreen);//cogColorRed );

			pCircleResult[nShotCount].CoCreateInstance( CLSID_CogPointMarker );
			pCircleResult[nShotCount]->put_Interactive( VARIANT_TRUE );
			pCircleResult[nShotCount]->put_GraphicType( cogPointMarkerGraphicTypeCircle );
			pCircleResult[nShotCount]->put_SizeInScreenPixels( (long)(realscalecx / m_CalibData[iDisplay] /2) );
			pCircleResult[nShotCount]->put_X( px );
			pCircleResult[nShotCount]->put_Y( py );
			pCircleResult[nShotCount]->put_Rotation( rotate );
			if( accepted )	pCircleResult[nShotCount]->put_Color( cogColorGreen );
			else			pCircleResult[nShotCount]->put_Color( cogColorGreen);//cogColorRed );

			double	tx, ty;		//��ϵ� ���� ��ǥ ���÷���
			tx = gProcess.m_AlignData[iDisplay].X;
			ty = gProcess.m_AlignData[iDisplay].Y;
			pTrainCross[nShotCount].CoCreateInstance( CLSID_CogPointMarker );
			pTrainCross[nShotCount]->put_Interactive( VARIANT_TRUE );
			pTrainCross[nShotCount]->put_GraphicType( cogPointMarkerGraphicTypeCross );
			pTrainCross[nShotCount]->put_SizeInScreenPixels( 20 );
			pTrainCross[nShotCount]->put_X( tx );
			pTrainCross[nShotCount]->put_Y( ty );
			pTrainCross[nShotCount]->put_Color( cogColorOrange );


			pPMResultArray[nOrigin]->CreateResultGraphics( CogPMAlignResultGraphicConstants(cogPMAlignResultGraphicMatchShapeModels  | cogPMAlignResultGraphicMatchRegion)/*cogPMAlignResultGraphicMatchRegion*/ , &CompositeShape[nShotCount] );
			

			/********************** ����� ������ *****************************/
			double dPixelX, dPixelY;
			if(m_nCamNo == HIGH_1ST_CAM)
			{
				m_2DTrans[HIGH_1ST_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			}
			else if(m_nCamNo == LOW_1ST_CAM)
			{
				m_2DTrans[LOW_1ST_CAM].TransformPoint(px, py, dPixelX, dPixelY);
				//TRACE("PM Tool Find 4Way %.4f %.4f %.4f %.4f \n",px, py, dPixelX, dPixelY);
			}
			else if(m_nCamNo == HIGH_2ND_CAM)
			{
				m_2DTrans[HIGH_2ND_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			}
			else 
			{
				m_2DTrans[LOW_2ND_CAM].TransformPoint(px, py, dPixelX, dPixelY);
			}

			gVariable.m_CognixFinalResult[nShotCount].dOffsetReuslt_mm.x = dPixelX;
			gVariable.m_CognixFinalResult[nShotCount].dOffsetReuslt_mm.y = dPixelY;

			//TRACE("Hole %d , %.4f %.4f \n",nShotCount,dPixelX,dPixelY);
			/******************************************************************/

			if (gVPro.m_ShapeTypeNo == MODEL_PATTERN) 
				pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pTrainCross[nShotCount]), NULL, VARIANT_TRUE );

			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pCross[nShotCount]), NULL, VARIANT_TRUE );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(CompositeShape[nShotCount]), NULL, VARIANT_TRUE );
		}
	}



	bScoreFail = FALSE;

	
	for(int nShotCount = 0; nShotCount < 4; nShotCount++) //Error ȭ�� ǥ��
	{
		if(gVariable.m_CognixFinalResult[nShotCount].bUse == FALSE || !bShowResult)
			continue;
		int nOrigin = gVariable.m_CognixFinalResult[nShotCount].nHoleOriginIndex;


		realscalecx = gVariable.m_CognixFinalResult[nShotCount].dScaleResult.x;
		double realscalecy = gVariable.m_CognixFinalResult[nShotCount].dScaleResult.y;
		double SclaeGap = gVariable.m_CognixFinalResult[nShotCount].dScaleGap;
		score = gVariable.m_CognixFinalResult[nShotCount].dScoreValue;
		BOOL bRatioCheck = gVariable.m_CognixFinalResult[nShotCount].bRatioCheck;
		BOOL bSizeCheck = gVariable.m_CognixFinalResult[nShotCount].bSizeCheck;


		pPoseArray[nOrigin]->get_TranslationX( &px );
		pPoseArray[nOrigin]->get_TranslationY( &py );
		pPoseArray[nOrigin]->get_Rotation( &rotate );
		pPMResultArray[nOrigin]->get_Score( &score );
		pPMResultArray[nOrigin]->get_Accepted( &accepted );

	

		if(!bRatioCheck || !bSizeCheck)
		{

			swprintf_s( Buffer, L"SizeOver=(X:%.3f,Y:%.3f),(%.3f~%.3f),Ratio(%.2f) ", realscalecx,
				realscalecy,
				m_ScaleN[iPatternNo]*gVPro.m_SizeA[iPatternNo],
				m_ScaleP[iPatternNo]*gVPro.m_SizeA[iPatternNo], 
				SclaeGap );
			pLabel->put_Text( Buffer );
			pLabel->put_Color( cogColorRed );
			pLabel->put_Interactive( VARIANT_TRUE );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );

			strResult = Buffer;
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));

			bCheckSizeAndRatioFlagError = TRUE;//20170929
		}
		else if(gProcessINI.m_sProcessFidFind.dResultScore > score)
		{

			swprintf_s( Buffer, L"Score Fail = %.3f Setting(%.3f) ", score, gProcessINI.m_sProcessFidFind.dResultScore);
			pLabel->put_Text( Buffer );
			pLabel->put_Color( cogColorRed );
			pLabel->put_Interactive( VARIANT_TRUE );
			pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );
			bScoreFail = TRUE;
			accepted = false;   //20130515 bskim ������ Result Score���� Score ���� ������� ���� ȭ�鿡 Score �� ǥ���ϰ� Vision �� 0���� ����
			strResult = Buffer;
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strResult));
		}
		else
		{
			gVariable.m_CognixFinalResult[nShotCount].bFinalSuccess = TRUE;

			//TRACE("PM Tool Find 4Way Cal %d , %.4f \n",gVariable.m_CognixFinalResult[nShotCount].nHoleOriginIndex,gVariable.m_CognixFinalResult[nShotCount].dScaleGap);
		}

	}

	BOOL bFinalSuccess = TRUE;
	for(int nShotCount = 0; nShotCount < 4; nShotCount++) //���� ����
	{
		if(gVariable.m_CognixFinalResult[nShotCount].bFinalSuccess == FALSE)
			bFinalSuccess = FALSE;
	}
	




	if(bFinalSuccess)
	{
		accepted = true;

		swprintf_s( Buffer, L"Score = %.3f", score);
		pLabel->put_Text( Buffer );
		pLabel->put_BackgroundColor( cogColorBlack );
		pLabel->put_Color( cogColorWhite );
		pLabel->put_Interactive( VARIANT_TRUE );
		pInteractiveGrapicContainer->Add( CComQIPtr<ICogGraphicInteractive>(pLabel), NULL, VARIANT_TRUE );

	}


	pPMPattern.Release();
	pPMTool.Release();
	pPMResult2.Release();
	pCross2.Release();

	for(int ii = 0; ii < 100; ii++)
	{
		pCross[ii].Release();
		pTrainCross[ii].Release();
		CompositeShape[ii].Release();
		pCircleResult[ii].Release();
	}


	pInteractiveGrapicContainer.Release();

	for(int i = 0; i<100; i++)
	{
		if( pPMResultArray != NULL)
			pPMResultArray[i].Release();
		if( pPoseArray != NULL)
			pPoseArray[i].Release();
	}



#endif
	return bFinalSuccess;
}