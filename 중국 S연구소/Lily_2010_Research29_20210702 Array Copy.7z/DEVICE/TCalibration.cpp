// TCalibration.cpp: implementation of the TCalibration class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TCalibration.h"
#include "..\EasyDriller.h"
#include "..\resource.h"

const char	WHOLE_T_CALIBRATION_FILE[] = _T("t.calibration");
#define BUF_SIZE	1024

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TCalibration::TCalibration()
{
	Clear();
}

TCalibration::~TCalibration()
{
	if(m_Offset)
	{
		delete [] m_Offset;
		m_Offset = NULL;
	}
}

void TCalibration::Clear()
{
	m_bIsSet = FALSE;
	m_bFirst = TRUE;
	m_nCount = 0;
	m_dInterval = 0;
	m_Offset = NULL;
}

void TCalibration::GetCalibrationOffset(double dPos, double& dOffset)
{
	if(m_bIsSet)
		GetPartialCalibrationOffset(dPos, dOffset);
	else
		dOffset = 0.;
}

void TCalibration::GetPartialCalibrationOffset(double dPos, double& dOffset)
{
	int nIndex = static_cast<int>( dPos / m_dInterval );
	double dDist = dPos - m_dInterval * nIndex;

	if (nIndex == m_nCount - 1)
		dOffset = m_Offset[nIndex];
	else
		dOffset = m_Offset[nIndex] + (m_Offset[nIndex+1] - m_Offset[nIndex]) * dDist / m_dInterval;
}

BOOL TCalibration::LoadCalibration(CString strPath)
{
	if (m_bFirst)
	{
		m_strPath = strPath;
		m_bFirst = FALSE;
	}
	
	CALDATA calData;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;

	CString strFileName;
	strFileName.Format(_T("%s%s"), strPath , WHOLE_T_CALIBRATION_FILE);
	
	if (NULL == fopen_s(&fp, strFileName, _T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return FALSE;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calData.nCount = nTemp;
		calData.dInterval = 360.0 / nTemp;

		double* dpOffset = NULL;
		TRY
		{
			dpOffset = new double[calData.nCount];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return FALSE;
		}
		END_CATCH

		double dIndex = 0.0, dOffset = 0.0;
		for (int i = 0; i < calData.nCount; i++)
		{
			if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
			{
				fclose(fp);
				delete [] dpOffset;
				return FALSE;
			}

			if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
			{
				fclose(fp);
				delete [] dpOffset;
				return FALSE;
			}
			dIndex = atof(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
			{
				fclose(fp);
				delete [] dpOffset;
				return FALSE;
			}
			dOffset = atof(token);

			dpOffset[i] = dOffset;
		}

		fclose(fp);

		calData.dOffset = dpOffset;

		UpdateCalibration(calData);
		delete [] dpOffset;
		return TRUE;
	}
	else
		return FALSE;
}

void TCalibration::SaveCalibration()
{
	FILE *fp = NULL;
	CString strFileName;
	strFileName.Format(_T("%s%s"), m_strPath , WHOLE_T_CALIBRATION_FILE);

	if (NULL == fopen_s(&fp, strFileName, _T("w")))
	{
		fprintf(fp, _T("%d\n"), m_nCount);
		
		for (int i = 0; i < m_nCount; i++)
		{
			fprintf(fp, _T("%lf\t%lf\n"),
				m_dInterval * i,
				m_Offset[i]);
		}
		
		fclose(fp);
		return;
	}
	else
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T(""));
		ErrMessage(strMsg);
		return;
	}
}

void TCalibration::SetMatrixToZero()
{
	m_nCount = 2;
	
	TRY
	{
		if(m_Offset)
		{
			delete [] m_Offset;
			m_Offset = NULL;
		}
		m_Offset = new double[m_nCount];
		m_Offset[0] = 0.;
		m_Offset[1] = 0.;

		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		Clear();
		return;
	}
	END_CATCH
}

void TCalibration::UpdateCalibration(const CALDATA& calData)
{
	m_dInterval = calData.dInterval;
	m_nCount = calData.nCount;
	
	TRY
	{
		delete [] m_Offset;
		m_Offset = NULL;
		m_Offset = new double[m_nCount];
		memcpy(m_Offset, calData.dOffset, sizeof(double) * m_nCount );
		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		Clear();
		return;
	}
	END_CATCH
}

void TCalibration::LoadData(CString strPath)
{
	if(!LoadCalibration(strPath))
		SetMatrixToZero();
}
