// DSysInput.h: interface for the DSysInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSYSINPUT_H__DA65FF08_B72C_4638_B5F1_36768D245434__INCLUDED_)
#define AFX_DSYSINPUT_H__DA65FF08_B72C_4638_B5F1_36768D245434__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DSysInput  
{
public:
	DSysInput();
	virtual ~DSysInput();

public :
	// M7000. $60200
	BOOL	m_bEmgStop;
	BOOL	m_bServoPowerOn;
	BOOL	m_bVacuumMotorOn;
	BOOL	m_bResetSwitch;
	BOOL	m_bInitSwitch;
	BOOL	m_bMpgAxisSelect1;
	BOOL	m_bMpgAxisSelect2;
	BOOL	m_bMpgAxisSelect4;
	BOOL	m_bMpgFeedSelect1;
	BOOL	m_bMpgFeedSelect2;
	BOOL	m_bMpgFeedSelect4;
	//BOOL	m_bMpgJogPlus;
	//BOOL	m_bMpgJogMinus;

	// M7001. $60201
	//BOOL	m_bMpgEnableSwitch;
	BOOL	m_bSysAirPressure;
	BOOL	m_bStageAirPressure;
	BOOL	m_bSysVacuumPressure;
	BOOL	m_bN2GasPressure;
	BOOL	m_bPolygonAirPressure;
	BOOL	m_bN2TankPressure;
	BOOL	m_bCoatingWaterLeak;
	BOOL	m_bChuckVacuumPressure;
	BOOL	m_bOpticalShutterCylinderFw;
	BOOL	m_bOpticalShutterCylinderBw;
	BOOL	m_bLPickerVacuumPressure;
	BOOL	m_bBPickerVacuumPressure;

	// M7002. $60202
	BOOL	m_bCassetteMagazineDetect;
	BOOL	m_bCassette8InchDetect;
	BOOL	m_bCassette12InchDetect;
	BOOL	m_bWaferOverloadDetect;
	BOOL	m_bWaferScan;
	BOOL	m_bAlignerWaferStatus;
	BOOL	m_bGripperWaferCatch;
	BOOL	m_bGripperWaferMissCatch;
	BOOL	m_bPrealignerCylinderFw;
	BOOL	m_bPrealignerCylinderBw;
	BOOL	m_bBufferGuideWafer8InchDetect;
	BOOL	m_bBufferGuideWafer12InchDetect;
	BOOL	m_bLPicker12InchCheck;
	BOOL	m_bLPicker8InchCheck;
	BOOL	m_bBPicker12InchCheck;
	BOOL	m_bBPicker8InchCheck;
//	BOOL	m_bSpinCover1Fw;
//	BOOL	m_bSpinCover1Bw;
//	BOOL	m_bSpinCover2Fw;
//	BOOL	m_bSpinCover2Bw;

	// M7003. $60203
	BOOL	m_bFrontDoor;
	BOOL	m_bSide1Door;
	BOOL	m_bSide2Door;
	BOOL	m_bRearDoor;
//	BOOL	m_bDoorLockConfirm;
	BOOL	m_bCoaterChuckVacuum;
	BOOL	m_bCDAPressure;
	BOOL	m_bLPickerCylinderUp;
	BOOL	m_bLPickerCylinderDown;
	BOOL	m_bShutterInterlockSensor;

	// M7004. $60204
	BOOL	m_bResetSWLamp;
	BOOL	m_bInitSWLamp;
	BOOL	m_bMpgLed;
	BOOL	m_bTowerLampRed;
	BOOL	m_bTowerLampYellow;
	BOOL	m_bTowerLampGreen;
	BOOL	m_bTowerLampBuzzer1;
	BOOL	m_bTowerLampBuzzer2;
	BOOL	m_bFluorescentLight;
	BOOL	m_bCoatingVacuumMotor;
	BOOL	m_bChuckVacuum8Inch;
	BOOL	m_bChuckVacuum;
//	BOOL	m_bChuckVacuumExhuast;
	BOOL	m_bTable8InchVacuumExhuastSol;
	BOOL	m_bHeadBlowerSol;
	BOOL	m_bGripperSol;
	BOOL	m_bPrealignerCylinderSol;
	BOOL	m_bFrontDoorLockSol;
	BOOL	m_bSideDoorLockSol;

	// M7005. $60205
	BOOL	m_bOpticalShutterCylinderSol;
	//BOOL	m_bSpinCoverSol;
	BOOL	m_bLPickerUpDownSol;
	BOOL	m_bTable12InchVacuumExhaustSol;
	BOOL	m_bLPickerVacuumSol;
	BOOL	m_bLPickerVacuumExhuastSol;
	BOOL	m_bBPickerVacuumSol;
	BOOL	m_bBPickerVacuumExhuastSol;
	BOOL	m_bHighPressurePumpAirSol;
	BOOL	m_bN2GasSupplySol;
	BOOL	m_bCoatingLiquidSupplySol;
	BOOL	m_bSpinVacuumSupplySol;
	BOOL	m_bSpinVacuumExhuastSol;
	BOOL	m_bHighPressurePumpDISupplySol;
	BOOL	m_bDIShowerSupplySol;

	// M7006. $60206
	BOOL	m_bLaserEnable;
	BOOL	m_bPickerWaferSol8Inch;
	BOOL	m_bPickerWaferSol12Inch;
	BOOL	m_bShutterInterlockSol;

	// M7008. $60208
	BOOL	m_bLaserShutterCylinderFw;
	BOOL	m_bLaserShutterCylinderBw;
	BOOL	m_bInitStageMotor;
	BOOL	m_bInitHnadlerMotor;
	BOOL	m_bInitSpinCoaterMotor;
	BOOL	m_bLotEnd;
	//BOOL	m_bCoaterZAxisStatus;
	BOOL	m_bCoaterArmPosStatus;
	BOOL	m_bCoaterReady;
	BOOL	m_bCoaterProgress;
	BOOL	m_bCoaterErr;

	// M7009. $60209
	BOOL	m_bRunStageX;
	BOOL	m_bRunStageY;
	BOOL	m_bRunStageT;
	BOOL	m_bRunStageZ;
	BOOL	m_bRunElevator;
	BOOL	m_bRunAlignRail;
	BOOL	m_bRunGripper;
	BOOL	m_bRunLPickerY;
	BOOL	m_bRunLPickerZ;
	BOOL	m_bRunBPickerY;
	BOOL	m_bRunBPickerZ;
	BOOL	m_bRunCoaterSpinT;
	//BOOL	m_bRunCoaterSpinZ;
	BOOL	m_bRunCoaterSArm;

	// M7010. $6020A
	DWORD	m_nCoaterProcessTime;

	// M7011. $6020B
	int		m_nSemiAutoRun;
};

#endif // !defined(AFX_DSYSINPUT_H__DA65FF08_B72C_4638_B5F1_36768D245434__INCLUDED_)
