// UnitLength.h: interface for the CUnitLength class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNITLENGTH_H__B248D907_7B78_4C34_8950_5C4F339601DF__INCLUDED_)
#define AFX_UNITLENGTH_H__B248D907_7B78_4C34_8950_5C4F339601DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

#define WM_UNITCHANGE		(WM_USER + 123)

enum enLength {
	lengthNone	= 0,
	lengthUM	= 1,
	lengthMM	= 2,
	lengthInch	= 3,
	NumLength	= 4,
};

typedef CTypedPtrList<CPtrList, CWnd*> CWndList;

class CUnitLength  
{
protected:
	static CWndList m_wndList;
	static const double m_dConversion[NumLength];
	static const CString m_strUnit[NumLength];
	static const CString m_strFormat[NumLength];
	static enLength m_default;

public:
	static LPCTSTR GetUnit(enLength enUnit = m_default) { return m_strUnit[enUnit]; }
	static LPCTSTR GetFormat(enLength enUnit = m_default) { return m_strFormat[enUnit]; }
	static void SetDisplayUnit(enLength enUnit);
	static enLength GetDisplayUnit() { return m_default; }
	static void AddWnd(CWnd* pWnd);
	static void RemoveWnd(CWnd* pWnd);
	static double GetDisplayValue(double dValue, enLength enUnit = m_default);
	static double GetInternalValue(double dValue, enLength enUnit = m_default);
	CUnitLength();
	virtual ~CUnitLength();
};

#endif // !defined(AFX_UNITLENGTH_H__B248D907_7B78_4C34_8950_5C4F339601DF__INCLUDED_)
