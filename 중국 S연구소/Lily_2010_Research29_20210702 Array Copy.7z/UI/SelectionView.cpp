// CSelectionView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "SelectionView.h"

#include "MGCView.h"

#include "DlgInformationBox.h"

#include "NAxis.h"

#include <cmath>

#pragma warning (disable:4189)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelectionView

IMPLEMENT_DYNCREATE(CSelectionView, CScrollView)

CSelectionView::CSelectionView() : c_nOffset(25) ,
                                   m_rectTracker(CRect(0, 0, 0, 0), CRectTracker::solidLine | CRectTracker::resizeInside)
{
	m_clrUnselectedNodeColor = RGB(0, 0, 0);
	m_clrSelectedNodeColor = RGB(255, 0, 0);

	m_bSelectionMode = FALSE;

}

CSelectionView::~CSelectionView()
{
}


BEGIN_MESSAGE_MAP(CSelectionView, CScrollView)
	//{{AFX_MSG_MAP(CSelectionView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectionView drawing

void CSelectionView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	CRect rectClient;
	GetClientRect(rectClient);

	sizeTotal.cx = rectClient.Width();
	sizeTotal.cy = rectClient.Height();

	SetScrollSizes(MM_TEXT, sizeTotal);

	m_rectSelectedInField.left = -1;
	m_rectSelectedInField.top = -1;
	m_rectSelectedInField.right = -1;
	m_rectSelectedInField.bottom = -1;

	m_nAxis = NAxis::axis_270;

	m_bRegionSelected = FALSE;
	m_bDrawRectTracker = FALSE;

	ChangeFieldToAxis();
}

void CSelectionView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	CRect rectClient;
	GetClientRect(rectClient);

	pDC->Draw3dRect(
		rectClient,
		::GetSysColor(COLOR_3DSHADOW),
		::GetSysColor(COLOR_3DLIGHT)
		);

	DrawNode(pDC);

	if(m_bDrawRectTracker == TRUE)
		m_rectTracker.Draw(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CSelectionView diagnostics

#ifdef _DEBUG
void CSelectionView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CSelectionView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSelectionView message handlers

LRESULT CALLBACK CSelectionView::WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	CSelectionView *pView = (CSelectionView *) CWnd::FromHandlePermanent(hWnd);
	if(pView == NULL)
	{
		pView = new CSelectionView;
		pView->Attach(hWnd);
	}

	VERIFY(pView);

	LRESULT lResult = AfxCallWndProc(pView, hWnd, nMsg, wParam, lParam);

	return lResult;

	return 0L;
}

BOOL CSelectionView::RegisterSelectionViewClass(HINSTANCE hInstance)
{
	WNDCLASS wc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(WHITE_BRUSH);
	wc.hCursor = (HCURSOR) ::LoadCursor(NULL, IDC_CROSS);
	wc.hIcon = NULL;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = (WNDPROC) CSelectionView::WindowProcedure;
	wc.lpszClassName = _T("SelectionViewClass");
	wc.lpszMenuName = NULL;
	wc.style = CS_GLOBALCLASS;

	BOOL bResult = (::RegisterClass(&wc) != 0);

	return bResult;

}

void CSelectionView::DrawNode(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.

	CRect rectClient;
	GetClientRect(rectClient);

	int nodeWidth = 
		int(ceil(double(rectClient.Width() - c_nOffset * 2) / 64.0));
	int nodeHeight =
		int(ceil(double(rectClient.Height() - c_nOffset * 2) / 64.0));

	int nOffsetX = (rectClient.Width() - nodeWidth * 64) / 2;
	int nOffsetY = (rectClient.Height() - nodeHeight * 64) / 2;

	pDC->SetWindowOrg(-nOffsetX, -nOffsetY);

	CRect rectField(
		0,
		0,
		nodeWidth * 64,
		nodeHeight * 64
		);

	for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
	{
		for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
		{
			int nX = 
				rectField.left + int(double(nIterX) * rectField.Width() / 64.0);
			int nY =
				rectField.top + int(double(nIterY) * rectField.Height() / 64.0);
			
			// m_rectSelectedInField �� Field ��ǥ��(65x65)����
			// ���õ� ������ ��Ÿ����.
			if(nIterX >= m_rectSelectedInField.left &&
				nIterX <= m_rectSelectedInField.right &&
				nIterY >= m_rectSelectedInField.top &&
				nIterY <= m_rectSelectedInField.bottom)
			{
				pDC->SetPixel(nX, nY, m_clrSelectedNodeColor);
			}
			else
			{
				pDC->SetPixel(nX, nY, m_clrUnselectedNodeColor);
			}
		}
	}

}

void CSelectionView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CScrollView::OnPrepareDC(pDC, pInfo);
}

void CSelectionView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(this->m_bDrawRectTracker == TRUE)
	{
		int nHitTest = m_rectTracker.HitTest(point);

		// Choi - Debug
		CWnd *pParent = GetParent();
		CMGCView *pMGCView =
			(CMGCView *)pParent->GetDlgItem(IDC_CTM_MGC_VIEW);

		if(pMGCView->getModified() == TRUE)
		{
			CDlgInformationBox dlgInformationBox;
			dlgInformationBox.SetTitleContent(
				"WARNING",
				"Data was modified.\nSave First."
				);

			dlgInformationBox.DoModal();

			return;
		}
		// Choi - Debug

		CRect rectDrag;
		CRect rectTemp;

		switch(nHitTest)
		{
		case CRectTracker::hitNothing:
			TRACE(_T("CRectTracker::hitNothing\n"));
			break;
		case CRectTracker::hitTopLeft:
		case CRectTracker::hitTopRight:
		case CRectTracker::hitBottomRight:
		case CRectTracker::hitBottomLeft:
		case CRectTracker::hitTop:
		case CRectTracker::hitRight:
		case CRectTracker::hitBottom:
		case CRectTracker::hitLeft:
		case CRectTracker::hitMiddle:
			m_rectTracker.Track(this, point, FALSE, NULL);
			m_rectTracker.GetTrueRect(&rectDrag);
			rectTemp.left = m_ptDragStart.x;
			rectTemp.top = m_ptDragStart.y;
			rectTemp.right = m_ptDragEnd.x;
			rectTemp.bottom = m_ptDragEnd.y;
			m_ptDragStart.x = rectDrag.left;
			m_ptDragStart.y = rectDrag.top;
			m_ptDragEnd.x = rectDrag.right;
			m_ptDragEnd.y = rectDrag.bottom;
			if(SelectNode() == false)
			{
				m_rectTracker.m_rect.left = rectTemp.left;
				m_rectTracker.m_rect.top = rectTemp.top;
				m_rectTracker.m_rect.right = rectTemp.right;
				m_rectTracker.m_rect.bottom = rectTemp.bottom;
			}
			break;
		}
	}
	else
	{
		SetCapture();
		m_bSelectionMode = TRUE;
		
		m_ptDragStart = point;
		m_ptDragEnd = point;
		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
		
		TRACE(_T("CSelectionView : change to Selection Mode\n"));
	}
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CSelectionView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bSelectionMode == TRUE)
	{
		::ReleaseCapture();
		m_bSelectionMode = FALSE;
		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);

		// Choi - Debug
		CWnd *pParent = GetParent();
		CMGCView *pMGCView =
			(CMGCView *)pParent->GetDlgItem(IDC_CTM_MGC_VIEW);

		if(pMGCView->getModified() == TRUE)
		{
			CDlgInformationBox dlgInformationBox;
			dlgInformationBox.SetTitleContent(
				"WARNING",
				"Data was modified.\nSave First."
				);

			dlgInformationBox.DoModal();

			return;
		}
		// Choi - Debug

		if(SelectNode() == true)
		{
			m_rectTracker.m_rect.left = m_ptDragStart.x;
			m_rectTracker.m_rect.top = m_ptDragStart.y;
			m_rectTracker.m_rect.right = m_ptDragEnd.x;
			m_rectTracker.m_rect.bottom = m_ptDragEnd.y;
		}
		
		TRACE(_T("CSelectionView : release Selection Mode\n"));
	}
	
	CScrollView::OnLButtonUp(nFlags, point);
}

void CSelectionView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bSelectionMode == TRUE)
	{
		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);

		m_ptDragEnd = point;

		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
	}
	
	CScrollView::OnMouseMove(nFlags, point);
}

void CSelectionView::SetAxis(int nAxis)
{
	m_nAxis = nAxis;

	ChangeFieldToAxis();

#ifdef _DEBUG
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		TRACE(_T("CSelectionView : Axis Change to axis_0\n"));
		break;
	case NAxis::axis_90:
		TRACE(_T("CSelectionView : Axis Change to axis_90\n"));
		break;
	case NAxis::axis_180:
		TRACE(_T("CSelectionView : Axis Change to axis_180\n"));
		break;
	case NAxis::axis_270:
		TRACE(_T("CSelectionView : Axis Change to axis_270\n"));
		break;
	}
#endif

}

void CSelectionView::DrawSelectionRect(POINT ptLeftTop, POINT ptRightBottom)
{
	CClientDC dc(this);

	dc.SetROP2(R2_NOT);
	dc.SelectStockObject(NULL_BRUSH);

	dc.Rectangle(
		ptLeftTop.x,
		ptLeftTop.y,
		ptRightBottom.x,
		ptRightBottom.y
		);

}

bool CSelectionView::SelectNode()
{
	CRect rectClient;
	GetClientRect(rectClient);

	int nodeWidth = 
		int(ceil(double(rectClient.Width() - c_nOffset * 2) / 64.0));
	int nodeHeight =
		int(ceil(double(rectClient.Height() - c_nOffset * 2) / 64.0));

	int nOffsetX = (rectClient.Width() - nodeWidth * 64) / 2;
	int nOffsetY = (rectClient.Height() - nodeHeight * 64) / 2;

	CRect rectField(
		0,
		0,
		nodeWidth * 64,
		nodeHeight * 64
		);

	CClientDC dc(this);
	OnPrepareDC(&dc);
	dc.SetWindowOrg(-nOffsetX, -nOffsetY);

	// 0���� 64���� Field ��ǥ ���� Node�� ��Ÿ����.
	POINT ptNodeFrom;
	POINT ptNodeTo;

	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptNodeFrom.x =m_ptDragStart.x;
		ptNodeTo.x = m_ptDragEnd.x;
	}
	else
	{
		ptNodeFrom.x = m_ptDragEnd.x;
		ptNodeTo.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptNodeFrom.y = m_ptDragStart.y;
		ptNodeTo.y = m_ptDragEnd.y;
	}
	else
	{
		ptNodeFrom.y = m_ptDragEnd.y;
		ptNodeTo.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptNodeFrom);
	dc.DPtoLP(&ptNodeTo);

	// ���� ������ Field ��ǥ��(64x64)�� ��ȯ �Ѵ�. - ����
	ptNodeFrom.x =
		int(ceil(double(ptNodeFrom.x) / (double(rectField.Width() / 64.0))));
	ptNodeFrom.y =
		int(ceil(double(ptNodeFrom.y) / (double(rectField.Height() / 64.0))));
	ptNodeTo.x =
		int(floor(double(ptNodeTo.x) / (double(rectField.Width() / 64.0))));
	ptNodeTo.y =
		int(floor(double(ptNodeTo.y) / (double(rectField.Height() / 64.0))));
	// ���� ������ Field ��ǥ��(64x64)�� ��ȯ �Ѵ�. - ��

	if(ptNodeFrom.x < 0)
		ptNodeFrom.x = 0;
	if(ptNodeFrom.x > 64)
		ptNodeFrom.x = 64;
	if(ptNodeFrom.y < 0)
		ptNodeFrom.y = 0;
	if(ptNodeFrom.y > 64)
		ptNodeFrom.y = 64;

	if(ptNodeTo.x < 0)
		ptNodeTo.x = 0;
	if(ptNodeTo.x > 64)
		ptNodeTo.x = 64;
	if(ptNodeTo.y < 0)
		ptNodeTo.y = 0;
	if(ptNodeTo.y > 64)
		ptNodeTo.y = 64;

	TRACE(_T("\nCSelectionView: Selection Node:\n"));
	TRACE(
		_T("Field Coord: From (%d, %d) To (%d, %d)\n"),
		ptNodeFrom.x, ptNodeFrom.y,
		ptNodeTo.x, ptNodeTo.y
		);

	if(ptNodeTo.x - ptNodeFrom.x < 5 ||
		ptNodeTo.y - ptNodeFrom.y < 5)
	{
		CDlgInformationBox dlgInformationBox;
		
		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Invalid Selection"
			);

		dlgInformationBox.DoModal();

		return false;
	}

	m_rectSelectedInField.left = ptNodeFrom.x;
	m_rectSelectedInField.top = ptNodeFrom.y;

	m_rectSelectedInField.right = ptNodeTo.x;
	m_rectSelectedInField.bottom = ptNodeTo.y;

	m_bRegionSelected = TRUE;

	Invalidate(TRUE);

	ChangeFieldToAxis();

	return true;
}

void CSelectionView::ChangeFieldToAxis()
{
	// Field ��ǥ��(65x65)�� Axis ��ǥ��(65x65)�� �ٲٱ� - ����
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		m_rectSelectedInAxis.left = m_rectSelectedInField.left;
		m_rectSelectedInAxis.top = 64 - m_rectSelectedInField.top;
		m_rectSelectedInAxis.right = m_rectSelectedInField.right;
		m_rectSelectedInAxis.bottom = 64 - m_rectSelectedInField.bottom;
		break;
	case NAxis::axis_90:
		m_rectSelectedInAxis.left = m_rectSelectedInField.top;
		m_rectSelectedInAxis.top = m_rectSelectedInField.left;
		m_rectSelectedInAxis.right = m_rectSelectedInField.bottom;
		m_rectSelectedInAxis.bottom = m_rectSelectedInField.right;
		break;
	case NAxis::axis_180:
		m_rectSelectedInAxis.left = 64 - m_rectSelectedInField.left;
		m_rectSelectedInAxis.top = m_rectSelectedInField.top;
		m_rectSelectedInAxis.right = 64 - m_rectSelectedInField.right;
		m_rectSelectedInAxis.bottom = m_rectSelectedInField.bottom;
		break;
	case NAxis::axis_270:
		m_rectSelectedInAxis.left = 64 - m_rectSelectedInField.top;
		m_rectSelectedInAxis.top = 64 - m_rectSelectedInField.left;
		m_rectSelectedInAxis.right = 64 - m_rectSelectedInField.bottom;
		m_rectSelectedInAxis.bottom = 64 - m_rectSelectedInField.right;
		break;
	case NAxis::axis_left_0:
		m_rectSelectedInAxis.left = 64 - m_rectSelectedInField.top;
		m_rectSelectedInAxis.top = m_rectSelectedInField.left;
		m_rectSelectedInAxis.right = 64 - m_rectSelectedInField.bottom;
		m_rectSelectedInAxis.bottom = m_rectSelectedInField.right;
		break;
	case NAxis::axis_left_90:
		m_rectSelectedInAxis.left = m_rectSelectedInField.left;
		m_rectSelectedInAxis.top = m_rectSelectedInField.top;
		m_rectSelectedInAxis.right = m_rectSelectedInField.right;
		m_rectSelectedInAxis.bottom = m_rectSelectedInField.bottom;
		break;
	case NAxis::axis_left_180:
		m_rectSelectedInAxis.left = m_rectSelectedInField.top;
		m_rectSelectedInAxis.top = 64 - m_rectSelectedInField.left;
		m_rectSelectedInAxis.right = m_rectSelectedInField.bottom;
		m_rectSelectedInAxis.bottom = 64 - m_rectSelectedInField.right;
		break;
	case NAxis::axis_left_270:
		m_rectSelectedInAxis.left = 64 - m_rectSelectedInField.left;
		m_rectSelectedInAxis.top = 64 - m_rectSelectedInField.top;
		m_rectSelectedInAxis.right = 64 - m_rectSelectedInField.right;
		m_rectSelectedInAxis.bottom = 64 - m_rectSelectedInField.bottom;
		break;
	}
	// Field ��ǥ�踦 Axis ��ǥ��� �ٲٱ� - ��

	TRACE(
		_T("Axis Coord: From (%d, %d) To (%d, %d)\n"),
		m_rectSelectedInAxis.left, m_rectSelectedInAxis.top,
		m_rectSelectedInAxis.right, m_rectSelectedInAxis.bottom
		);
	
	CWnd *pWnd = GetParent();
	CMGCView *pMGCView = (CMGCView *) pWnd->GetDlgItem(IDC_CTM_MGC_VIEW);

	if(pMGCView != NULL)
	{
		pMGCView->ChangeSelectedNode(
			m_rectSelectedInField,
			m_rectSelectedInAxis
			);
	}

}


void CSelectionView::setRegionSelected(BOOL bRegionSelected)
{
	m_bRegionSelected = bRegionSelected;
}

BOOL CSelectionView::getRegionSelected()
{
	return (m_bRegionSelected);
}

void CSelectionView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rectClient;
	GetClientRect(rectClient);

	int nodeWidth = 
		int(ceil(double(rectClient.Width() - c_nOffset * 2) / 64.0));
	int nodeHeight =
		int(ceil(double(rectClient.Height() - c_nOffset * 2) / 64.0));

	int nOffsetX = (rectClient.Width() - nodeWidth * 64) / 2;
	int nOffsetY = (rectClient.Height() - nodeHeight * 64) / 2;

	CRect rectField(
		0,
		0,
		nodeWidth * 64,
		nodeHeight * 64
		);

	CClientDC dc(this);
	OnPrepareDC(&dc);
	dc.SetWindowOrg(-nOffsetX, -nOffsetY);

	// 0���� 64���� Field ��ǥ ���� Node�� ��Ÿ����.
	POINT ptPoint = point;;

	dc.DPtoLP(&ptPoint);

	// ���� Field ��ǥ��(64x64)�� ��ȯ �Ѵ�. - ����
	ptPoint.x =
		int(ceil(double(ptPoint.x) / (double(rectField.Width() / 64.0))));
	ptPoint.y =
		int(ceil(double(ptPoint.y) / (double(rectField.Height() / 64.0))));
	// ���� Field ��ǥ��(64x64)�� ��ȯ �Ѵ�. - ��

	if(m_rectSelectedInField.PtInRect(ptPoint))
		m_bDrawRectTracker = TRUE;
	else
		m_bDrawRectTracker = FALSE;

	Invalidate();
	
	CScrollView::OnRButtonDown(nFlags, point);
}

BOOL CSelectionView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bDrawRectTracker == TRUE && pWnd == this && m_rectTracker.SetCursor(this, nHitTest))
	{
		return TRUE;
	}

	return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}
