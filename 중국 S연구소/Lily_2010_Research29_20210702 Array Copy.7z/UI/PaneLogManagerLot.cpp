// PaneLogManagerLot.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerLot.h"
#include "..\Model\DEasyDrillerIni.h"
#include <share.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLot

IMPLEMENT_DYNCREATE(CPaneLogManagerLot, CFormView)

CPaneLogManagerLot::CPaneLogManagerLot()
	: CFormView(CPaneLogManagerLot::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerLot)
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();
	m_strSearch = _T("");
	m_nSearchType = 0;
	//}}AFX_DATA_INIT

	m_pThread			= NULL;
	m_nListViewType		= 0;
	m_bIsView			= TRUE;

	m_pHandle[0]		= INVALID_HANDLE_VALUE;	// Thread Start event
	m_pHandle[1]		= INVALID_HANDLE_VALUE;	// Thread Stop event
	m_pHandle[2]		= INVALID_HANDLE_VALUE;	// Thread Finished event

	lstrcpy(m_lpszColumnHead[0], " Date ");
	lstrcpy(m_lpszColumnHead[1], " Start ");
	lstrcpy(m_lpszColumnHead[2], " End ");
	lstrcpy(m_lpszColumnHead[3], " Shot/PNL ");
	lstrcpy(m_lpszColumnHead[4], " Fired Hole ");
	lstrcpy(m_lpszColumnHead[5], " Lot ");
	lstrcpy(m_lpszColumnHead[6], " Total Hole ");
	lstrcpy(m_lpszColumnHead[7], " Elapsed ");
	lstrcpy(m_lpszColumnHead[8], " Average ");
	lstrcpy(m_lpszColumnHead[9], " Project ");
	lstrcpy(m_lpszColumnHead[10], " Data ");
	lstrcpy(m_lpszColumnHead[11], " Total Hole/PNL ");
	lstrcpy(m_lpszColumnHead[12], " Lot ID ");
	lstrcpy(m_lpszColumnHead[13], " User ID ");
//	lstrcpy(m_lpszColumnHead[10], " Laser Param ");

	lstrcpy(m_lpszShortDay[0], " Year ");
	lstrcpy(m_lpszShortDay[1], " Date ");
	lstrcpy(m_lpszShortDay[2], " Lot Count ");
	lstrcpy(m_lpszShortDay[3], " Fired Hole ");
	lstrcpy(m_lpszShortDay[4], " Total Hole ");
	lstrcpy(m_lpszShortDay[5], " Working Hour ");
	lstrcpy(m_lpszShortDay[6], " Working Ration(%) ");

	lstrcpy(m_lpszShortMonth[0], " Year ");
	lstrcpy(m_lpszShortMonth[1], " Month ");
	lstrcpy(m_lpszShortMonth[2], " Lot Count ");
	lstrcpy(m_lpszShortMonth[3], " Fired Hole ");
	lstrcpy(m_lpszShortMonth[4], " Total Hole ");
	lstrcpy(m_lpszShortMonth[5], " Working Hour ");
	lstrcpy(m_lpszShortMonth[6], " Working Ration(%) ");

	lstrcpy(m_lpszShortYear[0], " Year ");
	lstrcpy(m_lpszShortYear[1], " Lot Count ");
	lstrcpy(m_lpszShortYear[2], " Fired Hole ");
	lstrcpy(m_lpszShortYear[3], " Total Hole ");
	lstrcpy(m_lpszShortYear[4], " Working Hour ");
	lstrcpy(m_lpszShortYear[5], " Working Ration(%) ");

	m_strNewLine = _T("\r\n");
	m_strMicroSec = _T("us");
	m_strMicroMeter = _T("um");
	m_strHertz = _T("Hz");
	m_strPercent = _T("%");
	m_strComma = _T(", ");
}

CPaneLogManagerLot::~CPaneLogManagerLot()
{
}

void CPaneLogManagerLot::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerLot)
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_BUTTON_STAT_MONTHLY, m_btnStatMonthly);
	DDX_Control(pDX, IDC_STATIC_TOTAL_SHOT_COUNT, m_stcTotalShotCount);
	DDX_Control(pDX, IDC_STATIC_TOTAL_PCB_COUNT, m_stcTotalPCBCount);
	DDX_Control(pDX, IDC_LIST_LOT, m_listLot);
	DDX_Control(pDX, IDC_EDIT_SEARCH, m_edtSearch);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_LOT_CATEGORY, m_cmbLotCategory);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_STAT_DAILY, m_btnStatDaily);
	DDX_Control(pDX, IDC_BUTTON_STAT_ANNUAL, m_btnStatAnnual);
	DDX_Control(pDX, IDC_BUTTON_SEARCH, m_btnSearch);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_Text(pDX, IDC_EDIT_SEARCH, m_strSearch);
	DDX_CBIndex(pDX, IDC_COMBO_LOT_CATEGORY, m_nSearchType);
	DDX_Control(pDX, IDC_EDIT__HOUR_START, m_edtHourStart);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerLot, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerLot)
	ON_NOTIFY(NM_CLICK, IDC_LIST_LOT, OnClickListLot)
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_STAT_DAILY, OnButtonStatDaily)
	ON_BN_CLICKED(IDC_BUTTON_STAT_MONTHLY, OnButtonStatMonthly)
	ON_BN_CLICKED(IDC_BUTTON_STAT_ANNUAL, OnButtonStatAnnual)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLot diagnostics

#ifdef _DEBUG
void CPaneLogManagerLot::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerLot::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLot message handlers

void CPaneLogManagerLot::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitListControl();
	InitEditControl();
	InitEtcControl();
}

BOOL CPaneLogManagerLot::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneLogManagerLot::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	// Save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

	// Search
	m_btnSearch.SetFont( &m_fntBtn );
	m_btnSearch.SetFlat( FALSE );
	m_btnSearch.EnableBallonToolTip();
	m_btnSearch.SetToolTipText( _T("Search") );
	m_btnSearch.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSearch.SetBtnCursor(IDC_HAND_1);

	// Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);
	m_btnStop.EnableWindow( FALSE );

	// Daily stat.
	m_btnStatDaily.SetFont( &m_fntBtn );
	m_btnStatDaily.SetFlat( FALSE );
	m_btnStatDaily.EnableBallonToolTip();
	m_btnStatDaily.SetToolTipText( _T("Daily Stat.") );
	m_btnStatDaily.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStatDaily.SetBtnCursor(IDC_HAND_1);

	// Monthly stat.
	m_btnStatMonthly.SetFont( &m_fntBtn );
	m_btnStatMonthly.SetFlat( FALSE );
	m_btnStatMonthly.EnableBallonToolTip();
	m_btnStatMonthly.SetToolTipText( _T("Monthly Stat") );
	m_btnStatMonthly.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStatMonthly.SetBtnCursor(IDC_HAND_1);

	// Annual stat.
	m_btnStatAnnual.SetFont( &m_fntBtn );
	m_btnStatAnnual.SetFlat( FALSE );
	m_btnStatAnnual.EnableBallonToolTip();
	m_btnStatAnnual.SetToolTipText( _T("Annual Stat") );
	m_btnStatAnnual.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStatAnnual.SetBtnCursor(IDC_HAND_1);
}

void CPaneLogManagerLot::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtSearch.SetFont( &m_fntEdit );
	m_edtSearch.SetReceivedFlag( 5 ); // Alpha-Nemeric

	m_edtHourStart.SetFont( &m_fntEdit );
	m_edtHourStart.SetForeColor( BLACK_COLOR );
	m_edtHourStart.SetBackColor( WHITE_COLOR );
	m_edtHourStart.SetReceivedFlag( 1 ); 
	m_edtHourStart.SetWindowText( _T("0") );
}

void CPaneLogManagerLot::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(120, "Arial Bold");

	m_listLot.SetFont( &m_fntList );
	m_listLot.SetExtendedStyle(m_listLot.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);

	ResetColumn();

	LoadFromCurrentDate();
}

void CPaneLogManagerLot::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	m_stcTotalPCBCount.SetFont( &m_fntStatic );
	m_stcTotalPCBCount.SetForeColor( RGB(255, 0, 0) );
	m_stcTotalShotCount.SetFont( &m_fntStatic );
	m_stcTotalShotCount.SetForeColor( RGB(255, 0, 0) );

	GetDlgItem(IDC_STATIC_TIME)->SetFont( &m_fntStatic );
}

void CPaneLogManagerLot::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");

	m_cmbLotCategory.SetFont( &m_fntEtc );
	m_cmbLotCategory.SetCurSel( 0 );

	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );

	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
}

void CPaneLogManagerLot::ResetColumn()
{
	m_strLotDetailArray.RemoveAll();
	m_listLot.DeleteAllItems();

	for (int i = 14; i >= 0; i--) // 11
		m_listLot.DeleteColumn(i);

	if (m_nListViewType == 0)
		ShowDetailColumn();
	else
		ShowShortColumn();
}

void CPaneLogManagerLot::ShowDetailColumn()
{
	int nWidth = 90;
	m_listLot.InsertColumn(0, _T(""), LVCFMT_CENTER, 1);
	m_listLot.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, nWidth+5);
	m_listLot.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, nWidth-5);
	m_listLot.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, nWidth);
	m_listLot.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_RIGHT, nWidth+10);
	m_listLot.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_RIGHT, nWidth+15);

	m_listLot.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_RIGHT, nWidth-20);
	m_listLot.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_RIGHT, nWidth+15);
	m_listLot.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, nWidth);
	m_listLot.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, nWidth);
	m_listLot.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_LEFT, nWidth+30);

	m_listLot.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_LEFT, nWidth+30);
	m_listLot.InsertColumn(12, m_lpszColumnHead[11], LVCFMT_RIGHT, nWidth+30);
	m_listLot.InsertColumn(13, m_lpszColumnHead[12], LVCFMT_CENTER, nWidth+15);
	m_listLot.InsertColumn(14, m_lpszColumnHead[13], LVCFMT_CENTER, nWidth+15);
//	m_listLot.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_LEFT, nWidth);
}

void CPaneLogManagerLot::ShowShortColumn()
{
	int nWidth = 150;
	switch (m_nListViewType)
	{
	case 1:		// �Ϻ� ���
		m_listLot.InsertColumn(0, _T(" "), LVCFMT_CENTER, 20);
		m_listLot.InsertColumn(1, m_lpszShortDay[0], LVCFMT_CENTER, nWidth - 50);
		m_listLot.InsertColumn(2, m_lpszShortDay[1], LVCFMT_CENTER, nWidth - 50);
		m_listLot.InsertColumn(3, m_lpszShortDay[2], LVCFMT_RIGHT, nWidth - 50);
		m_listLot.InsertColumn(4, m_lpszShortDay[3], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(5, m_lpszShortDay[4], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(6, m_lpszShortDay[5], LVCFMT_CENTER, nWidth);
		m_listLot.InsertColumn(7, m_lpszShortDay[6], LVCFMT_RIGHT, nWidth+50);
		break;
	case 2:		// ���� ���
		m_listLot.InsertColumn(0, _T(" "), LVCFMT_CENTER, 20);
		m_listLot.InsertColumn(1, m_lpszShortMonth[0], LVCFMT_CENTER, nWidth - 50);
		m_listLot.InsertColumn(2, m_lpszShortMonth[1], LVCFMT_CENTER, nWidth - 50);
		m_listLot.InsertColumn(3, m_lpszShortMonth[2], LVCFMT_RIGHT, nWidth - 50);
		m_listLot.InsertColumn(4, m_lpszShortMonth[3], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(5, m_lpszShortMonth[4], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(6, m_lpszShortMonth[5], LVCFMT_CENTER, nWidth);
		m_listLot.InsertColumn(7, m_lpszShortMonth[6], LVCFMT_RIGHT, nWidth+50);
		break;
	case 3:		// �⵵�� ���
		m_listLot.InsertColumn(0, _T(" "), LVCFMT_CENTER, 20);
		m_listLot.InsertColumn(1, m_lpszShortYear[0], LVCFMT_CENTER, nWidth - 50);
		m_listLot.InsertColumn(2, m_lpszShortYear[1], LVCFMT_RIGHT, nWidth - 50);
		m_listLot.InsertColumn(3, m_lpszShortYear[2], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(4, m_lpszShortYear[3], LVCFMT_RIGHT, nWidth);
		m_listLot.InsertColumn(5, m_lpszShortYear[4], LVCFMT_CENTER, nWidth);
		m_listLot.InsertColumn(6, m_lpszShortYear[5], LVCFMT_RIGHT, nWidth+50);
		break;
	default:
		break;
	}
}

void CPaneLogManagerLot::LoadFromCurrentDate()
{
	CTime cTime = CTime::GetCurrentTime();
	m_listLot.DeleteAllItems();
	m_strLotDetailArray.RemoveAll();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;
	LoadFromFile(GetLogFile(cTime));
	UpdateTotalStatistic();
}


CString CPaneLogManagerLot::GetLogFile(CTime& cTime)
{
	CString strProcessLog;
	strProcessLog.Format( "%s" , gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
	CString strLogFile(strProcessLog);
	strLogFile += _T("Process");
	strLogFile += cTime.Format(_T("%Y%m%d"));

	return strLogFile;
}

void CPaneLogManagerLot::UpdateTotalStatistic()
{
	CString strData;
	CString strVal;
	strVal.Format(_T("%d"), m_nTotalPCB);
	MakeReadableNumber(strVal);
	strData.Format(_T("PNL Count : %s"), strVal);
	m_stcTotalPCBCount.SetWindowText( (LPCTSTR)strData );

	strVal.Format(_T("%I64d"), m_n64TotalShot);
	MakeReadableNumber(strVal);
	strData.Format(_T("Shot Count : %s"), strVal);
	m_stcTotalShotCount.SetWindowText( (LPCTSTR)strData );
}

void CPaneLogManagerLot::MakeReadableNumber(CString& strVal)
{
	int nLen = strVal.GetLength();
	if (nLen <= 3)
		return;
	else
	{
		for( int nComma = nLen - 3; nComma > 0; nComma -= 3)
			strVal.Insert(nComma, _T(','));
	}
}

void CPaneLogManagerLot::LoadFromFile(CString strFile, CString strSearch)
{
	if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		return;


//	::WaitForSingleObject( g_hLotFile, INFINITE );
//	::ResetEvent(g_hLotFile);
	FILE* fp;
	fp = _fsopen((LPCTSTR)strFile, _T("r+"), _SH_DENYNO);

	if (NULL == fp)
	{
//		::SetEvent(g_hLotFile);
		return;
	}
	
	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;
	CString strTemp, strVal, strDetail;
	CStringArray strItem;
	bool bShow = false;

	for(int nStart = m_listLot.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		strItem.RemoveAll();
		if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ���� ��¥
		{
			if (feof(fp))
				break;
			else
				continue;
		}
		strTemp = token;
		strTemp.TrimLeft();
		strTemp.TrimRight();
		
//		int nLen = strTemp.GetLength();
//		int nPos = strTemp.Find(_T('/')) + 1;
//		strTemp = strTemp.Right(nLen - nPos);
		strItem.Add(strTemp);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
			continue;

		strTemp = token;
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� ��¥
			continue;
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
			continue;
		
		strTemp = token;
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Shot / PCB
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		MakeReadableNumber(strTemp);
		strItem.Add(strTemp);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Total shot
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Lot count
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ɸ� �ð�
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ��� �ð�
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);

		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Project ���� �̸�
			continue;
		
		strTemp = token;
		RemoveDirectoryFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		if (m_nSearchType == 0 && !strSearch.IsEmpty())
		{
			if (NULL == StrStrI((LPCTSTR)strTemp, (LPCTSTR)strSearch))
				bShow = false;
			else
				bShow = true;
		}
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Cad data ���� �̸�
			continue;
		
		strTemp = token;
		RemoveDirectoryFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		if (m_nSearchType == 1 && !strSearch.IsEmpty())
		{
			if (NULL == StrStrI((LPCTSTR)strTemp, (LPCTSTR)strSearch))
				bShow = false;
			else
				bShow = true;
		}
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
//			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Total hole
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		MakeReadableNumber(strTemp);
		strItem.Add(strTemp);

//		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Laser parameter ���� �̸�
//			continue;
		
//		strTemp = token;
//		RemoveDirectoryFromName(strTemp);
//		RemoveEqualsFromName(strTemp);
//		strTemp.TrimLeft();
//		strTemp.TrimRight();
//		strItem.Add(strTemp);

//		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
//		{
//			fclose(fp);
//			return;
//		}

// From below for compatibility

		// Total Holes, ����� ������ line shot��, ��ü ������ line shot ��, Total Lines

		strDetail.Empty();
/*		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Total Holes
		{
			strDetail = token;
			strDetail.TrimLeft();
			strDetail.TrimRight();
			strDetail += m_strNewLine;
			strDetail += m_strNewLine;
			
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				::SetEvent(g_hLotFile);
				return;
			}
		}
*/
		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// ����� ���� line shot
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			strTemp += m_strComma;
			strDetail += strTemp;
			
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// ��ü ������ line shot
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			strTemp += m_strComma;
			strDetail += strTemp;
			
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Total Lines
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			strDetail += strTemp;
			
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return;
			}
		}
/*
		strDetail.Empty();
		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Total Holes
		{
			strDetail = token;
			strDetail.TrimLeft();
			strDetail.TrimRight();
			strDetail += m_strNewLine;
			strDetail += m_strNewLine;

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Step Period
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp += m_strMicroSec;
			strTemp += m_strComma;
			strDetail += strTemp;
				
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Jump Step
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp += m_strMicroMeter;
			strTemp += m_strComma;
			strDetail += strTemp;
					
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Jump Delay
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp += m_strMicroSec;
			strTemp += m_strComma;
			strDetail += strTemp;
						
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Pulse Frequency
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp += m_strHertz;
			strTemp += m_strComma;
			strDetail += strTemp;
							
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Laser On Delay
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp += m_strMicroSec;
			strTemp += _T("     ");
			strTemp += m_strNewLine;
			strTemp += m_strNewLine;
			strDetail += strTemp;

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Shot Mode
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			strTemp += m_strNewLine;
			strTemp += m_strNewLine;
			strDetail += strTemp;

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		int nNumTool = 0;
		if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Number of tool
		{
			strTemp = token;
			strTemp.TrimLeft();
			strTemp.TrimRight();
			nNumTool = atoi(strTemp);
			if (nNumTool < 0 || nNumTool >= MAX_TOOL_NO)
				nNumTool = 0;

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
				return;
			}
		}

		for (int nTool = 0; nTool < nNumTool; nTool++)	// loop over tool
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// T-Code
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strComma;
				strDetail += strTemp;

				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Mask Number
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strComma;
				strDetail += strTemp;

				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Hole count
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strComma;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			int nNumShot = 0;
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Shot Count
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strVal = strTemp;
				RemoveEqualsFromName(strVal);
				nNumShot = atoi(strVal);
				if (nNumShot < 0 || nNumShot > MAX_BEAM_HOLE)
					nNumShot = 0;

				strTemp += m_strComma;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Burst Shot count
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strComma;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Cycle shot count
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strNewLine;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}

			for (int nShot = 0; nShot < nNumShot; nShot++)
			{
				if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// i-th shot
				{
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();
					strTemp += m_strComma;
					strDetail += strTemp;
					
					if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						fclose(fp);
						return;
					}
				}

				if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// Duty
				{
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();
					if (nShot % 3 == 2 || nShot == nNumShot - 1)
						strTemp += m_strNewLine;
					else
						strTemp += m_strComma;
					strDetail += strTemp;
					
					if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						fclose(fp);
						return;
					}
				}
			}
			strDetail += m_strNewLine;
		}
		
		for (nTool = 0; nTool < nNumTool; nTool++)	// loop over tool
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// T-Code
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strNewLine;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}
		}
*/

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// TotalHole/PNL
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Lot ID
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLotFile);
			return;
		}

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// User ID
			continue;
		
		strTemp = token;
		RemoveEqualsFromName(strTemp);
		strTemp.TrimLeft();
		strTemp.TrimRight();
		strItem.Add(strTemp);
		
		if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			fclose(fp);
			::SetEvent(g_hLotFile);
			return;
		}

		strDetail += "\n";
		while(token != NULL) // tool info 
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// T-Code
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strNewLine;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}
		}
		strDetail += "\n";
		while(token != NULL) // tool info 
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))	// T-Code
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				strTemp += m_strNewLine;
				strDetail += strTemp;
				
				if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					fclose(fp);
					return;
				}
			}
		}

		if (strSearch.IsEmpty() || bShow == true)
		{
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return;
			}

			int n = m_listLot.InsertItem(nStart, _T(""));
			m_n64TotalShot += _atoi64(strItem[4]);
			m_n64TotalHole += _atoi64(strItem[8]);
			m_nTotalPCB += atoi(strItem[5]);
			MakeReadableNumber(strItem.ElementAt(4));
			MakeReadableNumber(strItem.ElementAt(5));
			for (int i = 0; i < 14; i++) // 11
			{	
				if( i < 6 || i >= 11)
					m_listLot.SetItemText(n, i + 1, strItem[i]);
				else if (i == 10)
					m_listLot.SetItemText(n, 7, strItem[i]);
				else
					m_listLot.SetItemText(n, i + 2, strItem[i]);
			}
			m_strLotDetailArray.Add(strDetail);
		}
		else
			nStart--;
	}
	
	fclose(fp);
//	::SetEvent(g_hLotFile);
}

void CPaneLogManagerLot::RemoveEqualsFromName(CString& strVal)
{
	int nLen = strVal.GetLength();
	int nPos = strVal.ReverseFind(_T('=')) + 1;
	strVal = strVal.Right(nLen - nPos);
}

void CPaneLogManagerLot::RemoveDirectoryFromName(CString& strVal)
{
	int nLen = strVal.GetLength();
	int nPos = strVal.ReverseFind(_T('\\')) + 1;
	strVal = strVal.Right(nLen - nPos);
}

void CPaneLogManagerLot::UpdateSaveButton()
{
	if (0 == m_listLot.GetItemCount())
		m_btnSave.EnableWindow( FALSE );
	else
		m_btnSave.EnableWindow( TRUE );
}

void CPaneLogManagerLot::OnClickListLot(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (m_nListViewType == 0)
	{
		// View detail information
		ShowDetailInformation();
	}

	*pResult = 0;
}

void CPaneLogManagerLot::ShowDetailInformation()
{
	int nSel = m_listLot.GetSelectionMark();
	if (-1 == nSel)
		return;

	CString strCaption;
	//strCaption.LoadString(IDS_TEXT_DETAIL_INFO);
	strCaption.Format(_T("Detail Information\n"));
	
	CString strDetail = m_strLotDetailArray.ElementAt(nSel);
	if (strDetail.IsEmpty())
		return;

	MessageBox(strCaption + strDetail);
	//ErrMessage(strCaption + strDetail);
}

void CPaneLogManagerLot::OnButtonView() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);
	
	m_nListViewType = 0;
	ResetColumn();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;

	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event

	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}
	
	m_bIsView = TRUE;
	m_pThread = ::AfxBeginThread(ViewListThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}
	
	::SetEvent(m_pHandle[0]);
	::Sleep(20);

	EnableNormalButton(FALSE);
}

void CPaneLogManagerLot::MakeThreadClear()
{
	m_pThread = NULL;
	if (m_pHandle[0] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[0]);
	if (m_pHandle[1] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[1]);
	if (m_pHandle[2] != INVALID_HANDLE_VALUE)
		::CloseHandle(m_pHandle[2]);
	m_pHandle[0] = m_pHandle[1]	= m_pHandle[2] = INVALID_HANDLE_VALUE;
}

void CPaneLogManagerLot::EnableNormalButton(BOOL bEnable)
{
	m_btnView.EnableWindow( bEnable );
	m_btnSearch.EnableWindow( bEnable );
	m_btnStatDaily.EnableWindow( bEnable );
	m_btnStatMonthly.EnableWindow( bEnable );
	m_btnStatAnnual.EnableWindow( bEnable );
	m_btnSave.EnableWindow( bEnable );
	m_btnStop.EnableWindow( !bEnable );
}

UINT CPaneLogManagerLot::ViewListThread(LPVOID lpVoid)
{
	CPaneLogManagerLot* pDlg = static_cast<CPaneLogManagerLot*>(lpVoid);
	DWORD dwRetCode = ::WaitForMultipleObjects(3, const_cast<HANDLE*>(pDlg->m_pHandle), FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pDlg->m_pHandle[0]);
	else
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	CString strSearch;
	if (pDlg->m_bIsView)
		strSearch.Empty();
	else
		strSearch = pDlg->m_strSearch;

//	if (pDlg->m_ctStart > pDlg->m_ctEnd)
//	{
//		pDlg->m_ctStart = pDlg->m_ctEnd;
//		pDlg->UpdateData(FALSE);
//	}

	int nStartYear = pDlg->m_ctStart.GetYear();
	int nEndYear = pDlg->m_ctEnd.GetYear();
	int nStartMonth = pDlg->m_ctStart.GetMonth();
	int nEndMonth = pDlg->m_ctEnd.GetMonth();
	int nStartDay = pDlg->m_ctStart.GetDay();
	int nEndDay = pDlg->m_ctEnd.GetDay();

	if (nStartYear == nEndYear && nStartMonth == nEndMonth)
	{
		for (int i = nStartDay; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}
	else if (nStartYear == nEndYear)
	{
		for (int i = nStartMonth; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j, nLastDayOfMonth = pDlg->GetDays(nEndYear, i);
			if (i == nStartMonth)
				j = nStartDay;
			else
				j = 1;

			for (; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
			}
		}

		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}
	else
	{
		for (int i = nStartYear; i < nEndYear; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j;
			if (i == nStartYear)
				j = nStartMonth;
			else
				j = 1;

			for (; j <= 12; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				int k, nLastDayOfMonth = pDlg->GetDays(i, j);
				if (j == nStartMonth)
					k = nStartDay;
				else
					k = 1;

				for (; k <= nLastDayOfMonth; k++)
				{
					if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pDlg->UpdateTotalStatistic();
						::SetEvent(pDlg->m_pHandle[2]);
						return 0L;
					}

					CTime cTime(i, j, k, 0, 0, 0);
					pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
				}
			}
		}

		for(int i =  1; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int nLastDayOfMonth = pDlg->GetDays(nEndYear, i);
			for (int j = 1; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
			}
		}
		
		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			pDlg->LoadFromFile(pDlg->GetLogFile(cTime), strSearch);
		}
	}

	if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	::SetEvent(pDlg->m_pHandle[2]);
	pDlg->UpdateTotalStatistic();
	pDlg->PostMessage(WM_COMMAND, IDC_BUTTON_STOP);
	return 1L;
}

int CPaneLogManagerLot::GetDays(int nYear, int nMonth)
{
	switch (nMonth)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		return 31;
	case 4:
	case 6:
	case 9:
	case 11:
		return 30;
	case 2:
		if (nYear % 4 == 0)
		{
			if (nYear % 100 == 0)
			{
				if (nYear % 400 == 0)
					return 29;
				else
					return 28;
			}
			else
				return 29;
		}
		else
			return 28;
	default:
		return 31;
	}
}

int CPaneLogManagerLot::GetDays(int nYear)
{
	if (nYear % 4 == 0)
	{
		if (nYear % 100 == 0)
		{
			if (nYear % 400 == 0)
				return 366;
			else
				return 365;
		}
		else
			return 366;
	}
	else
		return 365;
}

void CPaneLogManagerLot::OnButtonSave() 
{
	UpdateData(TRUE);
	
	if (0 == m_listLot.GetItemCount())
		return;

	TCHAR szFilter[] = _T("Log File(*.txt)|*.txt||");
	CFileDialog filedlg(FALSE, _T("txt"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);

//	filedlg.m_ofn.lpstrInitialDir = _T("C:\\");

	if(IDOK == filedlg.DoModal())
	{
		CString strSaveAsProjectFileName = filedlg.GetPathName();
		WriteLogFile(strSaveAsProjectFileName);
	}
	else
		return;
}

void CPaneLogManagerLot::WriteLogFile(CString& strSaveFileName)
{
	CStdioFile cFile;

	if (FALSE == cFile.Open(strSaveFileName, CFile::modeCreate | CFile::modeWrite))
	{
		ErrMessage(IDS_CREATE_FILE_ERR, MB_ICONERROR);
		return;
	}

	TRY
	{
		switch (m_nListViewType)
		{
		case 0:			// ����
			{
				CString strLine;
				strLine.Format(_T("%10s\t%8s\t%8s\t%8s\t%14s\t%4s\t%10s\t%8s\t%14s\t%14s\t%14s\t%14s\t%14s\t%14s\n"),
					m_lpszColumnHead[0], m_lpszColumnHead[1], m_lpszColumnHead[2],
					m_lpszColumnHead[3], m_lpszColumnHead[4], m_lpszColumnHead[5],
					m_lpszColumnHead[6], m_lpszColumnHead[7], m_lpszColumnHead[8],
					m_lpszColumnHead[9], m_lpszColumnHead[10], m_lpszColumnHead[11],
					m_lpszColumnHead[12], m_lpszColumnHead[13]);
				cFile.WriteString(strLine);

				int nMax = m_listLot.GetItemCount();
				for (int i = 0; i < nMax; i++)
				{
					strLine.Format(_T("%10s\t%8s\t%8s\t%8s\t%14s\t%14s\t%4s\t%10s\t%8s\t%14s\t%14s\t%14s\t%14s\t%14s\n"), //\t%14s\n",
						m_listLot.GetItemText(i, 1), m_listLot.GetItemText(i, 2),
						m_listLot.GetItemText(i, 3), m_listLot.GetItemText(i, 4),
						m_listLot.GetItemText(i, 5), m_listLot.GetItemText(i, 6),
						m_listLot.GetItemText(i, 7), m_listLot.GetItemText(i, 8),
						m_listLot.GetItemText(i, 9), m_listLot.GetItemText(i, 10),
						m_listLot.GetItemText(i, 11),m_listLot.GetItemText(i, 12),
						m_listLot.GetItemText(i, 13),m_listLot.GetItemText(i, 14));
					cFile.WriteString(strLine);
				}
			}
			break;
		case 1:			// �Ϻ����
			{
				CString strLine;
				strLine.Format(_T("%4s\t%5s\t%9s\t%14s\t%14s\t%8s\t%10s\n"),
					m_lpszShortDay[0], m_lpszShortDay[1], m_lpszShortDay[2],
					m_lpszShortDay[3], m_lpszShortDay[4], m_lpszShortDay[5], m_lpszShortDay[6]);
				cFile.WriteString(strLine);

				int nMax = m_listLot.GetItemCount();
				for (int i = 0; i < nMax; i++)
				{
					strLine.Format(_T("%4s\t%5s\t%9s\t%14s\t%14s\t%8s\t%10s\n"),
						m_listLot.GetItemText(i, 1), m_listLot.GetItemText(i, 2),
						m_listLot.GetItemText(i, 3), m_listLot.GetItemText(i, 4),
						m_listLot.GetItemText(i, 5), m_listLot.GetItemText(i, 6), m_listLot.GetItemText(i, 7));
					cFile.WriteString(strLine);
				}
			}
			break;
		case 2:			// �������
			{
				CString strLine;
				strLine.Format(_T("%4s\t%2s\t%14s\t%14s\t%20s\t%9s\t%10s\n"),
					m_lpszShortMonth[0], m_lpszShortMonth[1], m_lpszShortMonth[2],
					m_lpszShortMonth[3], m_lpszShortMonth[4], m_lpszShortMonth[5], m_lpszShortMonth[6]);
				cFile.WriteString(strLine);

				int nMax = m_listLot.GetItemCount();
				for (int i = 0; i < nMax; i++)
				{
					strLine.Format(_T("%4s\t%2s\t%14s\t%14s\t%20s\t%9s\t%10s\n"),
						m_listLot.GetItemText(i, 1), m_listLot.GetItemText(i, 2),
						m_listLot.GetItemText(i, 3), m_listLot.GetItemText(i, 4),
						m_listLot.GetItemText(i, 5), m_listLot.GetItemText(i, 6), m_listLot.GetItemText(i, 7));
					cFile.WriteString(strLine);
				}
			}
			break;
		case 3:			// �⺰ ���
			{
				CString strLine;
				strLine.Format(_T("%4s\t%14s\t%24s\t%24s\t%10s\t%10s\n"),
					m_lpszShortYear[0], m_lpszShortYear[1], m_lpszShortYear[2],
					m_lpszShortYear[3], m_lpszShortYear[4], m_lpszShortYear[5]);
				cFile.WriteString(strLine);

				int nMax = m_listLot.GetItemCount();
				for (int i = 0; i < nMax; i++)
				{
					strLine.Format(_T("%4s\t%14s\t%24s\t%24s\t%10s\t%10s\n"),
						m_listLot.GetItemText(i, 1), m_listLot.GetItemText(i, 2),
						m_listLot.GetItemText(i, 3), m_listLot.GetItemText(i, 4),
						m_listLot.GetItemText(i, 5), m_listLot.GetItemText(i, 6));
					cFile.WriteString(strLine);
				}
			}
			break;
		default:
			break;
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
	
	cFile.Close();
}

void CPaneLogManagerLot::OnButtonSearch() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);
	
	if (m_strSearch.IsEmpty())
		return;

	m_nListViewType = 0;
	ResetColumn();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;
	
	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event
	
	m_bIsView = FALSE;
	m_pThread = ::AfxBeginThread(ViewListThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}
	
	::SetEvent(m_pHandle[0]);
	::Sleep(20);
	
	EnableNormalButton(FALSE);
}

void CPaneLogManagerLot::OnButtonStop() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		
//		if (::WaitForSingleObject(m_pHandle[2], INFINITE) == WAIT_OBJECT_0)
		if (::WaitForSingleObject(m_pHandle[2], 1000) == WAIT_OBJECT_0)
		{
			MakeThreadClear();
			EnableNormalButton(TRUE);
		}
	}

	UpdateSaveButton();
}

void CPaneLogManagerLot::OnButtonStatDaily() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}
	
	UpdateData(TRUE);

	m_nListViewType = 1;
	ResetColumn();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;

	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}
	
	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event
	
	m_bIsView = TRUE;
	m_pThread = ::AfxBeginThread(ViewDayStatThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}
	
	::SetEvent(m_pHandle[0]);
	::Sleep(20);
	
	EnableNormalButton(FALSE);
}

UINT CPaneLogManagerLot::ViewDayStatThread(LPVOID lpVoid)
{
	CPaneLogManagerLot* pDlg = static_cast<CPaneLogManagerLot*>(lpVoid);
	DWORD dwRetCode = ::WaitForMultipleObjects(3, const_cast<HANDLE*>(pDlg->m_pHandle), FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pDlg->m_pHandle[0]);
	else
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	int nStartYear = pDlg->m_ctStart.GetYear();
	int nEndYear = pDlg->m_ctEnd.GetYear();
	int nStartMonth = pDlg->m_ctStart.GetMonth();
	int nEndMonth = pDlg->m_ctEnd.GetMonth();
	int nStartDay = pDlg->m_ctStart.GetDay();
	int nEndDay = pDlg->m_ctEnd.GetDay();

	CString strTemp;
	stWorkStat stwStat;
	stwStat.ctsAddToNext = CTimeSpan(0, 0, 0, 0);
	stwStat.n64RemainShot = 0;
	stwStat.n64RemainHole = 0;
	stwStat.nRemainPCB = 0;
	const double dOneDay = 24.0 * 60.0 * 60.0;
	CTime ctCurTime = CTime::GetCurrentTime();

	if (nStartYear == nEndYear && nStartMonth == nEndMonth)
	{
		for (int i = nStartDay; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			stwStat.nPCB = stwStat.nRemainPCB;
			stwStat.n64Shot = stwStat.n64RemainShot;
			stwStat.n64Hole = stwStat.n64RemainHole;
			stwStat.ctsWorkHour = stwStat.ctsAddToNext;
			pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);

			if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
				continue;

			pDlg->m_nTotalPCB += stwStat.nPCB;
			pDlg->m_n64TotalShot += stwStat.n64Shot;
			pDlg->m_n64TotalHole += stwStat.n64Hole;
			int nStart = pDlg->m_listLot.GetItemCount();
			int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
				
			strTemp.Format(_T("%04d"), nEndYear);
			pDlg->m_listLot.SetItemText(n, 1, strTemp);
				
			pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
				
			strTemp.Format(_T("%d"), stwStat.nPCB);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 3, strTemp);
				
			strTemp.Format(_T("%I64d"), stwStat.n64Shot);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 4, strTemp);

			strTemp.Format(_T("%I64d"), stwStat.n64Hole);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 5, strTemp);

			strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
			pDlg->m_listLot.SetItemText(n, 6, strTemp);

			if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && nEndDay == ctCurTime.GetDay() && i == nEndDay)
			{
				CTime ctMidNight(ctCurTime.GetYear(), ctCurTime.GetMonth(), ctCurTime.GetDay(), 0, 0, 0);
				CTimeSpan ctsSpan = ctCurTime - ctMidNight;
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
			else
			{
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
		}
	}
	else if (nStartYear == nEndYear)
	{
		for (int i = nStartMonth; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j;
			if (i == nStartMonth)
				j = nStartDay;
			else
				j = 1;

			int nLastDayOfMonth = pDlg->GetDays(nEndYear, i);
			for (; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				stwStat.nPCB = stwStat.nRemainPCB;
				stwStat.n64Shot = stwStat.n64RemainShot;
				stwStat.n64Hole = stwStat.n64RemainHole;
				stwStat.ctsWorkHour = stwStat.ctsAddToNext;
				pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
					
				if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
					continue;

				pDlg->m_nTotalPCB += stwStat.nPCB;
				pDlg->m_n64TotalShot += stwStat.n64Shot;
				pDlg->m_n64TotalHole += stwStat.n64Hole;
				int nStart = pDlg->m_listLot.GetItemCount();
				int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
						
				strTemp.Format(_T("%04d"), nEndYear);
				pDlg->m_listLot.SetItemText(n, 1, strTemp);
					
				pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
						
				strTemp.Format(_T("%d"), stwStat.nPCB);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 3, strTemp);
						
				strTemp.Format(_T("%I64d"), stwStat.n64Shot);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 4, strTemp);

				strTemp.Format(_T("%I64d"), stwStat.n64Hole);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 5, strTemp);

				strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
						
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
		}

		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			stwStat.nPCB = stwStat.nRemainPCB;
			stwStat.n64Shot = stwStat.n64RemainShot;
			stwStat.n64Hole = stwStat.n64RemainHole;
			stwStat.ctsWorkHour = stwStat.ctsAddToNext;
			pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
			
			if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
				continue;

			pDlg->m_nTotalPCB += stwStat.nPCB;
			pDlg->m_n64TotalShot += stwStat.n64Shot;
			pDlg->m_n64TotalHole += stwStat.n64Hole;
			int nStart = pDlg->m_listLot.GetItemCount();
			int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
				
			strTemp.Format(_T("%04d"), nEndYear);
			pDlg->m_listLot.SetItemText(n, 1, strTemp);
				
			pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
				
			strTemp.Format(_T("%d"), stwStat.nPCB);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 3, strTemp);
				
			strTemp.Format(_T("%I64d"), stwStat.n64Shot);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 4, strTemp);

			strTemp.Format(_T("%I64d"), stwStat.n64Hole);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 5, strTemp);

			strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
			pDlg->m_listLot.SetItemText(n, 6, strTemp);
				
			if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && nEndDay == ctCurTime.GetDay() && i == nEndDay)
			{
				CTime ctMidNight(ctCurTime.GetYear(), ctCurTime.GetMonth(), ctCurTime.GetDay(), 0, 0, 0);
				CTimeSpan ctsSpan = ctCurTime - ctMidNight;
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
			else
			{
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
		}
	}
	else
	{
		for (int i = nStartYear; i < nEndYear; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j;
			if (i == nStartYear)
				j = nStartMonth;
			else
				j = 1;

			for (; j <= 12; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				int k;
				if (j == nStartMonth)
					k = nStartDay;
				else
					k = 1;

				int nLastDayOfMonth = pDlg->GetDays(i, j);
				for (; k <= nLastDayOfMonth; k++)
				{
					if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pDlg->UpdateTotalStatistic();
						::SetEvent(pDlg->m_pHandle[2]);
						return 0L;
					}

					CTime cTime(i, j, k, 0, 0, 0);
					stwStat.nPCB = stwStat.nRemainPCB;
					stwStat.n64Shot = stwStat.n64RemainShot;
					stwStat.n64Hole = stwStat.n64RemainHole;
					stwStat.ctsWorkHour = stwStat.ctsAddToNext;
					pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
							
					if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
						continue;

					pDlg->m_nTotalPCB += stwStat.nPCB;
					pDlg->m_n64TotalShot += stwStat.n64Shot;
					pDlg->m_n64TotalHole += stwStat.n64Hole;
					int nStart = pDlg->m_listLot.GetItemCount();
					int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
								
					strTemp.Format(_T("%04d"), i);
					pDlg->m_listLot.SetItemText(n, 1, strTemp);
								
					pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
								
					strTemp.Format(_T("%d"), stwStat.nPCB);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 3, strTemp);
								
					strTemp.Format(_T("%I64d"), stwStat.n64Shot);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 4, strTemp);

					strTemp.Format(_T("%I64d"), stwStat.n64Hole);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 5, strTemp);

					strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
					pDlg->m_listLot.SetItemText(n, 6, strTemp);
								
					double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
			}
		}

		for(int i =  1; i < nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int nLastDayOfMonth = pDlg->GetDays(nEndYear, i);
			for (int j = 1; j <= nLastDayOfMonth; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				CTime cTime(nEndYear, i, j, 0, 0, 0);
				stwStat.nPCB = stwStat.nRemainPCB;
				stwStat.n64Shot = stwStat.n64RemainShot;
				stwStat.n64Hole = stwStat.n64RemainHole;
				stwStat.ctsWorkHour = stwStat.ctsAddToNext;
				pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
				
				if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
					continue;

				pDlg->m_nTotalPCB += stwStat.nPCB;
				pDlg->m_n64TotalShot += stwStat.n64Shot;
				pDlg->m_n64TotalHole += stwStat.n64Hole;
				int nStart = pDlg->m_listLot.GetItemCount();
				int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
					
				strTemp.Format(_T("%04d"), nEndYear);
				pDlg->m_listLot.SetItemText(n, 1, strTemp);
					
				pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
					
				strTemp.Format(_T("%d"), stwStat.nPCB);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 3, strTemp);
					
				strTemp.Format(_T("%I64d"), stwStat.n64Shot);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 4, strTemp);

				strTemp.Format(_T("%I64d"), stwStat.n64Hole);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 5, strTemp);

				strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
					
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
		}
		
		for(int i =  1; i <= nEndDay; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			CTime cTime(nEndYear, nEndMonth, i, 0, 0, 0);
			stwStat.nPCB = stwStat.nRemainPCB;
			stwStat.n64Shot = stwStat.n64RemainShot;
			stwStat.n64Hole = stwStat.n64RemainHole;
			stwStat.ctsWorkHour = stwStat.ctsAddToNext;
			pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
			
			if (stwStat.nPCB == 0 && stwStat.n64Shot == 0 && stwStat.ctsWorkHour == 0)
				continue;

			pDlg->m_nTotalPCB += stwStat.nPCB;
			pDlg->m_n64TotalShot += stwStat.n64Shot;
			pDlg->m_n64TotalHole += stwStat.n64Hole;
			int nStart = pDlg->m_listLot.GetItemCount();
			int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
				
			strTemp.Format(_T("%04d"), nEndYear);
			pDlg->m_listLot.SetItemText(n, 1, strTemp);
				
			pDlg->m_listLot.SetItemText(n, 2, stwStat.strDay);
				
			strTemp.Format(_T("%d"), stwStat.nPCB);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 3, strTemp);
				
			strTemp.Format(_T("%I64d"), stwStat.n64Shot);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 4, strTemp);

			strTemp.Format(_T("%I64d"), stwStat.n64Hole);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 5, strTemp);

			strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)stwStat.ctsWorkHour.GetTotalHours(), 2), (int)stwStat.ctsWorkHour.GetMinutes(), (int)stwStat.ctsWorkHour.GetSeconds());
			pDlg->m_listLot.SetItemText(n, 6, strTemp);
				
			if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && nEndDay == ctCurTime.GetDay() && i == nEndDay)
			{
				CTime ctMidNight(ctCurTime.GetYear(), ctCurTime.GetMonth(), ctCurTime.GetDay(), 0, 0, 0);
				CTimeSpan ctsSpan = ctCurTime - ctMidNight;
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
			else
			{
				double dWorkRatio = stwStat.ctsWorkHour.GetTotalSeconds() / dOneDay * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 7, strTemp);
			}
		}
	}

	if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	::SetEvent(pDlg->m_pHandle[2]);
	pDlg->UpdateTotalStatistic();
	pDlg->PostMessage(WM_COMMAND, IDC_BUTTON_STOP);
	return 1L;
}

BOOL CPaneLogManagerLot::CalDayStatFromFile(CString strFile, CString strNextFile, stWorkStat& stwStat)
{
	if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
		return FALSE;

//	::WaitForSingleObject( g_hLotFile, INFINITE );
//	::ResetEvent(g_hLotFile);

	int nStartHour;
	CString strEditHour;
	m_edtHourStart.GetWindowText( strEditHour );
	nStartHour = atoi((LPSTR)(LPCTSTR) strEditHour);

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;
	CString strEndDay, strTemp, strStartTime;
	bool bIsRemain = false;
	int nStartYear = 1970, nYear = 1970, nStartMon = 1, nMon = 1, nStartDay = 1, nDay = 1, nHour = 0, nMin = 0, nSec = 0;


	FILE* fp = NULL;
	fp = _fsopen((LPCTSTR)strFile, _T("r+"), _SH_DENYNO);
	if (NULL == fp)
	{
		stwStat.strDay = strFile.Right(4);
		stwStat.strDay.Insert(2, _T("/"));
		if (stwStat.strDay[0] == _T('0'))
			stwStat.strDay.SetAt(0, _T(' '));

/*		const CTimeSpan ctsOneDay(1, 0, 0, 0);
		if (stwStat.ctsWorkHour > ctsOneDay)
		{
			double dTodayRatio = ctsOneDay.GetTotalSeconds() / static_cast<double>(stwStat.ctsWorkHour.GetTotalSeconds());
			int nShotPerPCB = static_cast<int>(stwStat.n64Shot / static_cast<__int64>(stwStat.nPCB));
			int nPCBLot = static_cast<int>(stwStat.nPCB * dTodayRatio + 0.5);
			__int64 n64ShotLot = static_cast<__int64>(nPCBLot) * static_cast<__int64>(nShotPerPCB);
			
			stwStat.nRemainPCB = stwStat.nPCB - nPCBLot;
			stwStat.nPCB = nPCBLot;
			stwStat.n64RemainShot = static_cast<__int64>(stwStat.nRemainPCB) * static_cast<__int64>(nShotPerPCB);
			stwStat.n64Shot = n64ShotLot;
			stwStat.ctsAddToNext = stwStat.ctsWorkHour - ctsOneDay;
			stwStat.ctsWorkHour = ctsOneDay;

			stwStat.strDay = strFile.Right(4);
			stwStat.strDay.Insert(2, _T("/"));
			if (stwStat.strDay[0] == _T('0'))
				stwStat.strDay.SetAt(0, _T(' '));
		}
		else
		{
			stwStat.nPCB = stwStat.nRemainPCB;
			stwStat.nRemainPCB = 0;
			stwStat.n64Shot = stwStat.n64RemainShot;
			stwStat.n64RemainShot = 0;
			stwStat.ctsWorkHour = stwStat.ctsAddToNext;
			stwStat.ctsAddToNext = 0;
			
			
		}
		
		::SetEvent(g_hLotFile);
		return FALSE;
*/	}
	else
	{
		while(fgets(szBuf, 8192, fp))
		{
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ���� ��¥
			{
				if (feof(fp))
					break;
				else
					continue;
			}
		
			stwStat.strDay = token;
			stwStat.strDay.TrimLeft();
			stwStat.strDay.TrimRight();
			
			int nLen = stwStat.strDay.GetLength();
			int nPos = stwStat.strDay.Find(_T('/')) + 1;
			nStartYear = atoi(stwStat.strDay.Left(nPos - 1));
			stwStat.strDay = stwStat.strDay.Right(nLen - nPos);

			nPos = stwStat.strDay.Find(_T('/'));
			nStartMon = atoi(stwStat.strDay.Left(nPos));
			nStartDay = atoi(stwStat.strDay.Right(stwStat.strDay.GetLength() - nPos - 1));
		
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
			{
				if (feof(fp))
					break;
				else
					continue;
			}

			strStartTime = token;
			strStartTime.TrimLeft();
			strStartTime.TrimRight();
			int nTime;

			nPos = strStartTime.Find(_T(':')) + 1;
			nTime = atoi(strStartTime.Left(nPos - 1));

			if(nTime < nStartHour)
				continue;

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� ��¥
				continue;

			strEndDay = token;
			strEndDay.TrimLeft();
			strEndDay.TrimRight();
		
			nLen = strEndDay.GetLength();
			nPos = strEndDay.Find(_T('/')) + 1;
			nYear = atoi(strEndDay.Left(nPos - 1));
			strEndDay = strEndDay.Right(nLen - nPos);

	/*		if (stwStat.strDay != strEndDay)
			{
				bIsRemain = true;
				nPos = strEndDay.Find(_T('/'));
				nMon = atoi(strEndDay.Left(nPos));
				nDay = atoi(strEndDay.Right(strEndDay.GetLength() - nPos - 1));
			}
			else
	*/			bIsRemain = false;

			if (stwStat.strDay[0] == _T('0'))
				stwStat.strDay.SetAt(0, _T(' '));

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
				continue;

			if (bIsRemain)
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				int n = strTemp.Find(_T(':'));
				if (n != -1)
				{
					nHour = atoi(strTemp.Left(n));
					strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				}

				n = strTemp.Find(_T(':'));
				if (n != -1)
				{
					nMin = atoi(strTemp.Left(n));
					strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				}

				nSec = atoi(strTemp);

				CTime ctStart(nStartYear, nStartMon, nStartDay, 23, 59, 59);
				CTime ctEnd(nYear, nMon, nDay, nHour, nMin, nSec);

				stwStat.ctsAddToNext = ctEnd - ctStart;
			}
			else
				stwStat.ctsAddToNext = CTimeSpan(0, 0, 0, 0);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Shot / PCB
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			int nShotPerPCB = atoi(strTemp);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Total shot
				continue;
		
			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			__int64 n64Shot = _atoi64(strTemp);
		
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Lot count
				continue;
		
			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			int nPCB = atoi(strTemp);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fp);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ɸ� �ð�
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();

			int n = strTemp.Find(_T(':'));
			int nH = atoi(strTemp.Left(n));
			strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
			n = strTemp.Find(_T(':'));
			int nM = atoi(strTemp.Left(n));
			int nS = atoi(strTemp.Right(strTemp.GetLength() - n - 1));
			CTimeSpan ctsAdd(0, nH, nM, nS);

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ��սð�
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ������Ʈ
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ĳ�� ������
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Hole ��
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			__int64 n64Hole = _atoi64(strTemp);

			if (bIsRemain)
			{
/*				int n = strTemp.Find(_T(':'));
				int nH = atoi(strTemp.Left(n));
				strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				n = strTemp.Find(_T(':'));
				int nM = atoi(strTemp.Left(n));
				int nS = atoi(strTemp.Right(strTemp.GetLength() - n - 1));

				int nD = 0;
				if (nH >= 24)
				{
					nD = nH / 24;
					nH %= 24;
				}

				CTimeSpan ctsTotal(nD, nH, nM, nS);
				CTimeSpan ctsAdd = ctsTotal - stwStat.ctsAddToNext;

				double dTodayRatio = ctsAdd.GetTotalSeconds() / static_cast<double>(ctsTotal.GetTotalSeconds());
				int nPCBLot = static_cast<int>(nPCB * dTodayRatio + 0.5);
				__int64 n64ShotLot = static_cast<__int64>(nPCBLot) * static_cast<__int64>(nShotPerPCB);
			
				stwStat.ctsWorkHour += ctsAdd;
				stwStat.n64Shot += n64ShotLot;
				stwStat.nPCB += nPCBLot;
				stwStat.nRemainPCB = nPCB - nPCBLot;
				stwStat.n64RemainShot = static_cast<__int64>(stwStat.nRemainPCB) * static_cast<__int64>(nShotPerPCB);
*/			}
			else
			{
				

				stwStat.ctsWorkHour += ctsAdd;
				stwStat.n64Shot += n64Shot;
				stwStat.n64Hole += n64Hole;
				stwStat.nPCB += nPCB;
				stwStat.nRemainPCB = 0;
				stwStat.n64RemainShot = 0;
				stwStat.n64RemainHole = 0;
			}
		}
		fclose(fp);
	}

	// next day
	FILE* fpNext = NULL;
	if (NULL != fopen_s(&fpNext, (LPCTSTR)strNextFile, "r"))
	{
/*		const CTimeSpan ctsOneDay(1, 0, 0, 0);
		if (stwStat.ctsWorkHour > ctsOneDay)
		{
			double dTodayRatio = ctsOneDay.GetTotalSeconds() / static_cast<double>(stwStat.ctsWorkHour.GetTotalSeconds());
			int nShotPerPCB = static_cast<int>(stwStat.n64Shot / static_cast<__int64>(stwStat.nPCB));
			int nPCBLot = static_cast<int>(stwStat.nPCB * dTodayRatio + 0.5);
			__int64 n64ShotLot = static_cast<__int64>(nPCBLot) * static_cast<__int64>(nShotPerPCB);
			
			stwStat.nRemainPCB = stwStat.nPCB - nPCBLot;
			stwStat.nPCB = nPCBLot;
			stwStat.n64RemainShot = static_cast<__int64>(stwStat.nRemainPCB) * static_cast<__int64>(nShotPerPCB);
			stwStat.n64Shot = n64ShotLot;
			stwStat.ctsAddToNext = stwStat.ctsWorkHour - ctsOneDay;
			stwStat.ctsWorkHour = ctsOneDay;

			stwStat.strDay = strFile.Right(4);
			stwStat.strDay.Insert(2, _T("/"));
			if (stwStat.strDay[0] == _T('0'))
				stwStat.strDay.SetAt(0, _T(' '));
		}
		else
		{
			stwStat.nPCB = stwStat.nRemainPCB;
			stwStat.nRemainPCB = 0;
			stwStat.n64Shot = stwStat.n64RemainShot;
			stwStat.n64RemainShot = 0;
			stwStat.ctsWorkHour = stwStat.ctsAddToNext;
			stwStat.ctsAddToNext = 0;
			
			stwStat.strDay = strFile.Right(4);
			stwStat.strDay.Insert(2, _T("/"));
			if (stwStat.strDay[0] == _T('0'))
				stwStat.strDay.SetAt(0, _T(' '));
		}
		
		::SetEvent(g_hLotFile);
		return FALSE;
*/	}
	else
	{

		bIsRemain = false;
		CString strTempDay;
	//	int nStartYear = 1970, nYear = 1970, nStartMon = 1, nMon = 1, nStartDay = 1, nDay = 1, nHour = 0, nMin = 0, nSec = 0;
		while(fgets(szBuf, 8192, fpNext))
		{
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ���� ��¥
			{
				if (feof(fpNext))
					break;
				else
					continue;
			}
		
			strTempDay = token;
			strTempDay.TrimLeft();
			strTempDay.TrimRight();
			
			int nLen = strTempDay.GetLength();
			int nPos = strTempDay.Find(_T('/')) + 1;
			nStartYear = atoi(strTempDay.Left(nPos - 1));
			strTempDay = strTempDay.Right(nLen - nPos);

			nPos = strTempDay.Find(_T('/'));
			nStartMon = atoi(strTempDay.Left(nPos));
			nStartDay = atoi(strTempDay.Right(strTempDay.GetLength() - nPos - 1));
		
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
			{
				if (feof(fpNext))
					break;
				else
					continue;
			}

			strStartTime = token;
			strStartTime.TrimLeft();
			strStartTime.TrimRight();
			int nTime;

			nPos = strStartTime.Find(_T(':')) + 1;
			nTime = atoi(strStartTime.Left(nPos - 1));

			if(nTime >= nStartHour)
				continue;

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� ��¥
				continue;

			strEndDay = token;
			strEndDay.TrimLeft();
			strEndDay.TrimRight();
		
			nLen = strEndDay.GetLength();
			nPos = strEndDay.Find(_T('/')) + 1;
			nYear = atoi(strEndDay.Left(nPos - 1));
			strEndDay = strEndDay.Right(nLen - nPos);

	/*		if (strTempDay != strEndDay)
			{
				bIsRemain = true;
				nPos = strEndDay.Find(_T('/'));
				nMon = atoi(strEndDay.Left(nPos));
				nDay = atoi(strEndDay.Right(strEndDay.GetLength() - nPos - 1));
			}
			else
				bIsRemain = false;
	*/
			if (strTempDay[0] == _T('0'))
				strTempDay.SetAt(0, _T(' '));

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ���� �ð�
				continue;

			if (bIsRemain)
			{
				strTemp = token;
				strTemp.TrimLeft();
				strTemp.TrimRight();
				int n = strTemp.Find(_T(':'));
				if (n != -1)
				{
					nHour = atoi(strTemp.Left(n));
					strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				}

				n = strTemp.Find(_T(':'));
				if (n != -1)
				{
					nMin = atoi(strTemp.Left(n));
					strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				}

				nSec = atoi(strTemp);

				CTime ctStart(nStartYear, nStartMon, nStartDay, 23, 59, 59);
				CTime ctEnd(nYear, nMon, nDay, nHour, nMin, nSec);

				stwStat.ctsAddToNext = ctEnd - ctStart;
			}
			else
				stwStat.ctsAddToNext = CTimeSpan(0, 0, 0, 0);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Shot / PCB
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			int nShotPerPCB = atoi(strTemp);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Total shot
				continue;
		
			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			__int64 n64Shot = _atoi64(strTemp);
		
			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Lot count
				continue;
		
			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			int nPCB = atoi(strTemp);

			if(::WaitForSingleObject(m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				fclose(fpNext);
//				::SetEvent(g_hLotFile);
				return FALSE;
			}

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ɸ� �ð�
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();

			int n = strTemp.Find(_T(':'));
			int nH = atoi(strTemp.Left(n));
			strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
			n = strTemp.Find(_T(':'));
			int nM = atoi(strTemp.Left(n));
			int nS = atoi(strTemp.Right(strTemp.GetLength() - n - 1));
			CTimeSpan ctsAdd(0, nH, nM, nS);

			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ��սð�
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ������Ʈ
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// ĳ�� ������
				continue;
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Hole ��
				continue;

			strTemp = token;
			RemoveEqualsFromName(strTemp);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			__int64 n64Hole = _atoi64(strTemp);

			if (bIsRemain)
			{
/*				int n = strTemp.Find(_T(':'));
				int nH = atoi(strTemp.Left(n));
				strTemp = strTemp.Right(strTemp.GetLength() - n - 1);
				n = strTemp.Find(_T(':'));
				int nM = atoi(strTemp.Left(n));
				int nS = atoi(strTemp.Right(strTemp.GetLength() - n - 1));

				int nD = 0;
				if (nH >= 24)
				{
					nD = nH / 24;
					nH %= 24;
				}

				CTimeSpan ctsTotal(nD, nH, nM, nS);
				CTimeSpan ctsAdd = ctsTotal - stwStat.ctsAddToNext;

				double dTodayRatio = ctsAdd.GetTotalSeconds() / static_cast<double>(ctsTotal.GetTotalSeconds());
				int nPCBLot = static_cast<int>(nPCB * dTodayRatio + 0.5);
				__int64 n64ShotLot = static_cast<__int64>(nPCBLot) * static_cast<__int64>(nShotPerPCB);
			
				stwStat.ctsWorkHour += ctsAdd;
				stwStat.n64Shot += n64ShotLot;
				stwStat.nPCB += nPCBLot;
				stwStat.nRemainPCB = nPCB - nPCBLot;
				stwStat.n64RemainShot = static_cast<__int64>(stwStat.nRemainPCB) * static_cast<__int64>(nShotPerPCB);
*/			}
			else
			{
			

				stwStat.ctsWorkHour += ctsAdd;
				stwStat.n64Shot += n64Shot;
				stwStat.n64Hole += n64Hole;
				stwStat.nPCB += nPCB;
				stwStat.nRemainPCB = 0;
				stwStat.n64RemainShot = 0;
				stwStat.n64RemainHole = 0;
			}
		}
		fclose(fpNext);
		// next day end
	}
//	::SetEvent(g_hLotFile);
	return TRUE;
}

CString CPaneLogManagerLot::MakeFixedWidthIntString(int nVal, int nWidth)
{
	CString strVal;
	strVal.Format(_T("%d"), nVal);
	int nLen = strVal.GetLength();
	int nSpaces = nWidth - nLen;

	for (int i = 0; i < nSpaces; i++)
		strVal.Insert(0, _T(" "));

	return strVal;
}

void CPaneLogManagerLot::OnButtonStatMonthly() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);
	
	m_nListViewType = 2;
	ResetColumn();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;

	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event
	
	m_bIsView = TRUE;
	m_pThread = ::AfxBeginThread(ViewMonthStatThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}
	
	::SetEvent(m_pHandle[0]);
	::Sleep(20);
	
	EnableNormalButton(FALSE);
}

UINT CPaneLogManagerLot::ViewMonthStatThread(LPVOID lpVoid)
{
	CPaneLogManagerLot* pDlg = static_cast<CPaneLogManagerLot*>(lpVoid);
	DWORD dwRetCode = ::WaitForMultipleObjects(3, const_cast<HANDLE*>(pDlg->m_pHandle), FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pDlg->m_pHandle[0]);
	else
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	int nStartYear = pDlg->m_ctStart.GetYear();
	int nEndYear = pDlg->m_ctEnd.GetYear();
	int nStartMonth = pDlg->m_ctStart.GetMonth();
	int nEndMonth = pDlg->m_ctEnd.GetMonth();
	int nMax = 0;
	int nMin = 0;
	
	CString strMonth, strTemp;
	stWorkStat stwStat;
	stwStat.ctsAddToNext = CTimeSpan(0, 0, 0, 0);
	stwStat.nRemainPCB = 0;
	stwStat.n64RemainShot = 0;
	stwStat.n64RemainHole = 0;

	int nMonPCB;
	__int64 n64MonShot;
	__int64 n64MonHole;
	CTimeSpan ctsMonWorkHour;
	const double dOneDay = 24.0 * 60.0 * 60.0;
	CTime ctCurTime = CTime::GetCurrentTime();

	if (nStartYear == nEndYear)
	{
		for (int i = nStartMonth; i <= nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			nMonPCB = stwStat.nRemainPCB;
			n64MonShot = stwStat.n64RemainShot;
			n64MonHole = stwStat.n64RemainHole;
			ctsMonWorkHour = CTimeSpan(0, 0, 0, 0);
			if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && i == nEndMonth)
				nMax = ctCurTime.GetDay();
			else
				nMax = pDlg->GetDays(nEndYear, i);

			for (int j = 1; j <= nMax; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				stwStat.nPCB = stwStat.nRemainPCB;
				stwStat.n64Shot = stwStat.n64RemainShot;
				stwStat.n64Hole = stwStat.n64RemainHole;
				CTime cTime(nEndYear, i, j, 0, 0, 0);
				stwStat.ctsWorkHour = stwStat.ctsAddToNext;
				pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
				
				nMonPCB += stwStat.nPCB;
				n64MonShot += stwStat.n64Shot;
				n64MonHole += stwStat.n64Hole;
				ctsMonWorkHour += stwStat.ctsWorkHour;
			}
			
			if (nMonPCB > 0 && n64MonShot > 0)
			{
				pDlg->m_nTotalPCB += nMonPCB;
				pDlg->m_n64TotalShot += n64MonShot;
				pDlg->m_n64TotalHole += n64MonHole;
				
				int nStart = pDlg->m_listLot.GetItemCount();
				int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
				
				strTemp.Format(_T("%04d"), nEndYear);
				pDlg->m_listLot.SetItemText(n, 1, strTemp);
				
				strMonth = pDlg->MakeFixedWidthIntString(i, 2);
				pDlg->m_listLot.SetItemText(n, 2, strMonth);
				
				strTemp.Format(_T("%d"), nMonPCB);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 3, strTemp);
				
				strTemp.Format(_T("%I64d"), n64MonShot);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 4, strTemp);

				strTemp.Format(_T("%I64d"), n64MonHole);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 5, strTemp);

				strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)ctsMonWorkHour.GetTotalHours(), 3), (int)ctsMonWorkHour.GetMinutes(), (int)ctsMonWorkHour.GetSeconds());
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
				
				if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && i == nEndMonth)
				{
					CTime ctFirstDay(ctCurTime.GetYear(), ctCurTime.GetMonth(), 1, 0, 0, 0);
					CTimeSpan ctsSpan = ctCurTime - ctFirstDay;
					double dWorkRatio = ctsMonWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
				else
				{
					double dWorkRatio = ctsMonWorkHour.GetTotalSeconds() / (pDlg->GetDays(nEndYear, i) * dOneDay) * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
			}
		}
	}
	else
	{
		for (int i = nStartYear; i < nStartYear; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			int j;
			if (i == nStartYear)
				j = nStartMonth;
			else
				j = 1;

			for (; j <= 12; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				nMonPCB = stwStat.nRemainPCB;
				n64MonShot = stwStat.n64RemainShot;
				n64MonHole = stwStat.n64RemainHole;
				ctsMonWorkHour = CTimeSpan(0, 0, 0, 0);
				int nLastDayOfMonth = pDlg->GetDays(i, j);
				for (int k = 1; k <= nLastDayOfMonth; k++)
				{
					if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
					{
						pDlg->UpdateTotalStatistic();
						::SetEvent(pDlg->m_pHandle[2]);
						return 0L;
					}

					stwStat.nPCB = stwStat.nRemainPCB;
					stwStat.n64Shot = stwStat.n64RemainShot;
					stwStat.n64Hole = stwStat.n64RemainHole;
					CTime cTime(i, j, k, 0, 0, 0);
					stwStat.ctsWorkHour = stwStat.ctsAddToNext;
					pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);

					nMonPCB += stwStat.nPCB;
					n64MonShot += stwStat.n64Shot;
					n64MonHole += stwStat.n64Hole;
					ctsMonWorkHour += stwStat.ctsWorkHour;
				}
					
				if (nMonPCB > 0 && n64MonShot > 0)
				{
					pDlg->m_nTotalPCB += nMonPCB;
					pDlg->m_n64TotalShot += n64MonShot;
					pDlg->m_n64TotalHole += n64MonHole;
						
					int nStart = pDlg->m_listLot.GetItemCount();
					int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
						
					strTemp.Format(_T("%04d"), i);
					pDlg->m_listLot.SetItemText(n, 1, strTemp);
						
					strMonth = pDlg->MakeFixedWidthIntString(j, 2);
					pDlg->m_listLot.SetItemText(n, 2, strMonth);
						
					strTemp.Format(_T("%d"), nMonPCB);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 3, strTemp);
						
					strTemp.Format(_T("%I64d"), n64MonShot);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 4, strTemp);

					strTemp.Format(_T("%I64d"), n64MonHole);
					pDlg->MakeReadableNumber(strTemp);
					pDlg->m_listLot.SetItemText(n, 5, strTemp);

					strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)ctsMonWorkHour.GetTotalHours(), 3), (int)ctsMonWorkHour.GetMinutes(), (int)ctsMonWorkHour.GetSeconds());
					pDlg->m_listLot.SetItemText(n, 6, strTemp);
						
					double dWorkRatio = ctsMonWorkHour.GetTotalSeconds() / (pDlg->GetDays(i, j) * dOneDay) * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
			}
		}

		for(int i =  1; i <= nEndMonth; i++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			nMonPCB = stwStat.nRemainPCB;
			n64MonShot = stwStat.n64RemainShot;
			n64MonHole = stwStat.n64RemainHole;
			ctsMonWorkHour = CTimeSpan(0, 0, 0, 0);

			if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && i == nEndMonth)
				nMax = ctCurTime.GetDay();
			else
				nMax = pDlg->GetDays(nEndYear, i);

			for (int j = 1; j <= nMax; j++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				stwStat.nPCB = stwStat.nRemainPCB;
				stwStat.n64Shot = stwStat.n64RemainShot;
				stwStat.n64Hole = stwStat.n64RemainHole;
				stwStat.ctsWorkHour = stwStat.ctsAddToNext;
				CTime cTime(nEndYear, i, j, 0, 0, 0);
				pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);

				nMonPCB += stwStat.nPCB;
				n64MonShot += stwStat.n64Shot;
				n64MonHole += stwStat.n64Hole;
				ctsMonWorkHour += stwStat.ctsWorkHour;
			}
			
			if (nMonPCB > 0 && n64MonShot > 0)
			{
				pDlg->m_nTotalPCB += nMonPCB;
				pDlg->m_n64TotalShot += n64MonShot;
				pDlg->m_n64TotalHole += n64MonHole;
				
				int nStart = pDlg->m_listLot.GetItemCount();
				int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
				
				strTemp.Format(_T("%04d"), nEndYear);
				pDlg->m_listLot.SetItemText(n, 1, strTemp);
				
				strMonth = pDlg->MakeFixedWidthIntString(i, 2);
				pDlg->m_listLot.SetItemText(n, 2, strMonth);
				
				strTemp.Format(_T("%d"), nMonPCB);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 3, strTemp);
				
				strTemp.Format(_T("%I64d"), n64MonShot);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 4, strTemp);

				strTemp.Format(_T("%I64d"), n64MonHole);
				pDlg->MakeReadableNumber(strTemp);
				pDlg->m_listLot.SetItemText(n, 5, strTemp);

				strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)ctsMonWorkHour.GetTotalHours(), 3), (int)ctsMonWorkHour.GetMinutes(), (int)ctsMonWorkHour.GetSeconds());
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
				
				if (nEndYear == ctCurTime.GetYear() && nEndMonth == ctCurTime.GetMonth() && i == nEndMonth)
				{
					CTime ctFirstDay(ctCurTime.GetYear(), ctCurTime.GetMonth(), 1, 0, 0, 0);
					CTimeSpan ctsSpan = ctCurTime - ctFirstDay;
					double dWorkRatio = ctsMonWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
				else
				{
					double dWorkRatio = ctsMonWorkHour.GetTotalSeconds() / (pDlg->GetDays(nEndYear, i) * dOneDay) * 100.0;
					strTemp.Format(_T("%.1f"), dWorkRatio);
					pDlg->m_listLot.SetItemText(n, 7, strTemp);
				}
			}
		}
	}

	if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	::SetEvent(pDlg->m_pHandle[2]);
	pDlg->UpdateTotalStatistic();
	pDlg->PostMessage(WM_COMMAND, IDC_BUTTON_STOP);
	return 1L;
}

void CPaneLogManagerLot::OnButtonStatAnnual() 
{
	if (m_pThread)
	{
		::SetEvent(m_pHandle[1]);
		ErrMessage(IDS_LOG_VIEW_THREAD_ERR, MB_ICONERROR);
		return;
	}

	UpdateData(TRUE);
	
	m_nListViewType = 3;
	ResetColumn();
	m_nTotalPCB = 0;
	m_n64TotalShot = 0;
	m_n64TotalHole = 0;

	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}
	
	m_pHandle[0] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Start event
	m_pHandle[1] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Stop event
	m_pHandle[2] = ::CreateEvent(NULL, TRUE, FALSE, NULL);	// Thread Finished event
	
	m_bIsView = TRUE;
	m_pThread = ::AfxBeginThread(ViewYearStatThread, static_cast<LPVOID>(this), THREAD_PRIORITY_LOWEST);
	if (m_pThread == NULL)
	{
		MakeThreadClear();
		return;
	}
	
	::SetEvent(m_pHandle[0]);
	::Sleep(20);
	
	EnableNormalButton(FALSE);
}

UINT CPaneLogManagerLot::ViewYearStatThread(LPVOID lpVoid)
{
	CPaneLogManagerLot* pDlg = static_cast<CPaneLogManagerLot*>(lpVoid);
	DWORD dwRetCode = ::WaitForMultipleObjects(3, const_cast<HANDLE*>(pDlg->m_pHandle), FALSE, INFINITE);
	if (dwRetCode == WAIT_OBJECT_0)
		::ResetEvent(pDlg->m_pHandle[0]);
	else
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	int nStartYear = pDlg->m_ctStart.GetYear();
	int nEndYear = pDlg->m_ctEnd.GetYear();
	
	CString strYear, strTemp;
	stWorkStat stwStat;
	stwStat.ctsAddToNext = CTimeSpan(0, 0, 0, 0);
	stwStat.nRemainPCB = 0;
	stwStat.n64RemainShot = 0;
	stwStat.n64RemainHole = 0;
	int nYearPCB;
	__int64 n64YearShot;
	__int64 n64YearHole;
	CTimeSpan ctsYearWorkHour;
	const double dOneDay = 24.0 * 60.0 * 60.0;
	CTime ctCurTime = CTime::GetCurrentTime();
	
	for (int i = nStartYear, nMonMax; i <= nEndYear; i++)
	{
		if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
		{
			pDlg->UpdateTotalStatistic();
			::SetEvent(pDlg->m_pHandle[2]);
			return 0L;
		}

		nYearPCB = stwStat.nRemainPCB;
		n64YearShot = stwStat.n64RemainShot;
		n64YearHole = stwStat.n64RemainHole;
		ctsYearWorkHour = CTimeSpan(0, 0, 0, 0);
		
		if (nEndYear == ctCurTime.GetYear() && i == nEndYear)
			nMonMax = ctCurTime.GetMonth();
		else
			nMonMax = 12;
		
		for (int j = 1, nDayMax; j <= nMonMax; j++)
		{
			if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
			{
				pDlg->UpdateTotalStatistic();
				::SetEvent(pDlg->m_pHandle[2]);
				return 0L;
			}

			if (nEndYear == ctCurTime.GetYear() && i == nEndYear && j == nMonMax)
				nDayMax = ctCurTime.GetDay();
			else
				nDayMax = pDlg->GetDays(i, j);
			
			for (int k = 1; k <= nDayMax; k++)
			{
				if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
				{
					pDlg->UpdateTotalStatistic();
					::SetEvent(pDlg->m_pHandle[2]);
					return 0L;
				}

				stwStat.nPCB = stwStat.nRemainPCB;
				stwStat.n64Shot = stwStat.n64RemainShot;
				stwStat.n64Hole = stwStat.n64RemainHole;
				stwStat.ctsWorkHour = stwStat.ctsAddToNext;
				CTime cTime(i, j, k, 0, 0, 0);
				pDlg->CalDayStatFromFile(pDlg->GetLogFile(cTime), pDlg->GetLogFile(cTime + CTimeSpan(1, 0, 0, 0)), stwStat);
				
				nYearPCB += stwStat.nPCB;
				n64YearShot += stwStat.n64Shot;
				n64YearHole += stwStat.n64Hole;
				ctsYearWorkHour += stwStat.ctsWorkHour;
			}
		}
		
		if (nYearPCB > 0 && n64YearShot > 0)
		{
			pDlg->m_nTotalPCB += nYearPCB;
			pDlg->m_n64TotalShot += n64YearShot;
			pDlg->m_n64TotalHole += n64YearHole;
			
			int nStart = pDlg->m_listLot.GetItemCount();
			int n = pDlg->m_listLot.InsertItem(nStart, _T(" "));
			
			strYear.Format(_T("%04d"), i);
			pDlg->m_listLot.SetItemText(n, 1, strYear);
			
			strTemp.Format(_T("%d"), nYearPCB);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 2, strTemp);
			
			strTemp.Format(_T("%I64d"), n64YearShot);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 3, strTemp);

			strTemp.Format(_T("%I64d"), n64YearHole);
			pDlg->MakeReadableNumber(strTemp);
			pDlg->m_listLot.SetItemText(n, 4, strTemp);
			
			strTemp.Format(_T("%s:%02d:%02d"), pDlg->MakeFixedWidthIntString((int)ctsYearWorkHour.GetTotalHours(), 4), (int)ctsYearWorkHour.GetMinutes(), (int)ctsYearWorkHour.GetSeconds());
			pDlg->m_listLot.SetItemText(n, 5, strTemp);
			
			if (nEndYear == ctCurTime.GetYear() && i == nEndYear)
			{
				CTime ctNewYear(ctCurTime.GetYear(), 1, 1, 0, 0, 0);
				CTimeSpan ctsSpan = ctCurTime - ctNewYear;
				double dWorkRatio = ctsYearWorkHour.GetTotalSeconds() / static_cast<double>(ctsSpan.GetTotalSeconds()) * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
			}
			else
			{
				double dWorkRatio = ctsYearWorkHour.GetTotalSeconds() / (pDlg->GetDays(i) * dOneDay) * 100.0;
				strTemp.Format(_T("%.1f"), dWorkRatio);
				pDlg->m_listLot.SetItemText(n, 6, strTemp);
			}
		}
	}

	if(::WaitForSingleObject(pDlg->m_pHandle[1], 0) == WAIT_OBJECT_0)
	{
		pDlg->UpdateTotalStatistic();
		::SetEvent(pDlg->m_pHandle[2]);
		return 0L;
	}

	::SetEvent(pDlg->m_pHandle[2]);
	pDlg->UpdateTotalStatistic();
	pDlg->PostMessage(WM_COMMAND, IDC_BUTTON_STOP);
	return 1L;
}

void CPaneLogManagerLot::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}



