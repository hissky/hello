// DlgScheduleInfo.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgSchedualeInfo.h"
#include "..\model\dprocessini.h"
#include "..\model\DProject.h"
#include "..\EasyDrillerDlg.h"
//#include "CDlgMesInput.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\alarmmsg.h"
#include "..\model\DSystemINI.h"
#include "PaneAutoRun.h"
#include "..\model\BarcodeODBC.h"
#include "..\model\FileDialogEX.h"
#include "DlgDispatch.h"
#include "..\EasyDrillerDlg.h"
#include "..\Device\OPCsvr.h"
#include "DlgOPCResult.h"
#include "PaneAutoRunViewOPC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgScheduleInfo dialog


CDlgScheduleInfo::CDlgScheduleInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgScheduleInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgScheduleInfo)
	m_strLotInfo = _T("IDDTEST-ABCDEFGHIJKLMNOPQR-01");
	m_nNo = 0;
	m_nBarType = 2;
	m_bMes = FALSE;
	m_bMes2 = FALSE;
	m_bMes3 = FALSE;
	m_bMes4 = FALSE;
	m_bMes5 = FALSE;
	m_bMes6 = FALSE;
	m_bMes7 = FALSE;
	m_bMes8 = FALSE;
	m_bMes9 = FALSE;
	m_bMes10 = FALSE;
	m_bUseMES = FALSE;
	m_nLastIndex = 0;
	m_nDiffTool = -1;
	m_bCompareOK = TRUE;
	m_bOnlyDisplay = FALSE;
	m_nFiredCount = 0;
	m_bMESChecking = FALSE;
	//}}AFX_DATA_INIT

	for(int k = 0; k < 10; k++)
	{
		for(int i=0; i< MAX_TOOL_NO; i++)
		{
			m_pToolCode[k][i] = new CToolCodeList;
			m_pToolCode[k][i]->Initialize();
		}
	}
}

CDlgScheduleInfo::~CDlgScheduleInfo()
{
	for(int k = 0; k < 10; k++)
	{
		for(int i=0; i< MAX_TOOL_NO; i++)
		{
			delete m_pToolCode[k][i];
		}
	}
}
void CDlgScheduleInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgScheduleInfo)
	DDX_Control(pDX, IDC_COMBO1, m_cmbBarType);
	DDX_Text(pDX, IDC_EDT_LOTINFO, m_strLotInfo);
	DDV_MaxChars(pDX, m_strLotInfo, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO2, m_strLotInfo2);
	DDV_MaxChars(pDX, m_strLotInfo2, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO3, m_strLotInfo3);
	DDV_MaxChars(pDX, m_strLotInfo3, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO4, m_strLotInfo4);
	DDV_MaxChars(pDX, m_strLotInfo4, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO5, m_strLotInfo5);
	DDV_MaxChars(pDX, m_strLotInfo5, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO6, m_strLotInfo6);
	DDV_MaxChars(pDX, m_strLotInfo6, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO7, m_strLotInfo7);
	DDV_MaxChars(pDX, m_strLotInfo7, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO8, m_strLotInfo8);
	DDV_MaxChars(pDX, m_strLotInfo8, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO9, m_strLotInfo9);
	DDV_MaxChars(pDX, m_strLotInfo9, 42);
	DDX_Text(pDX, IDC_EDT_LOTINFO10, m_strLotInfo10);
	DDV_MaxChars(pDX, m_strLotInfo10, 42);
	DDX_Text(pDX, IDC_EDT_NO, m_nNo);
	DDX_Text(pDX, IDC_EDT_NO2, m_nNo2);
	DDX_Text(pDX, IDC_EDT_NO3, m_nNo3);
	DDX_Text(pDX, IDC_EDT_NO4, m_nNo4);
	DDX_Text(pDX, IDC_EDT_NO5, m_nNo5);
	DDX_Text(pDX, IDC_EDT_NO6, m_nNo6);
	DDX_Text(pDX, IDC_EDT_NO7, m_nNo7);
	DDX_Text(pDX, IDC_EDT_NO8, m_nNo8);
	DDX_Text(pDX, IDC_EDT_NO9, m_nNo9);
	DDX_Text(pDX, IDC_EDT_NO10, m_nNo10);
	DDV_MinMaxUInt(pDX, m_nNo, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo2, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo3, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo4, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo5, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo6, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo7, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo8, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo9, 0, 9999);
	DDV_MinMaxUInt(pDX, m_nNo10, 0, 9999);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo2);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo3);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo4);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo5);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo6);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo7);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo8);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo9);
	DDX_Text(pDX, IDC_EDIT_FILM_NO, m_strFilmNo10);

	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE, m_strProcessCode);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE2, m_strProcessCode2);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE3, m_strProcessCode3);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE4, m_strProcessCode4);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE5, m_strProcessCode5);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE6, m_strProcessCode6);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE7, m_strProcessCode7);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE8, m_strProcessCode8);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE9, m_strProcessCode9);
	DDX_Text(pDX, IDC_EDIT_PROCESS_CODE10, m_strProcessCode10);

	DDX_Text(pDX, IDC_EDT_PROJECT, m_strPrj1);
	DDX_Text(pDX, IDC_EDT_PROJECT2, m_strPrj2);
	DDX_Text(pDX, IDC_EDT_PROJECT3, m_strPrj3);
	DDX_Text(pDX, IDC_EDT_PROJECT4, m_strPrj4);
	DDX_Text(pDX, IDC_EDT_PROJECT5, m_strPrj5);
	DDX_Text(pDX, IDC_EDT_PROJECT6, m_strPrj6);
	DDX_Text(pDX, IDC_EDT_PROJECT7, m_strPrj7);
	DDX_Text(pDX, IDC_EDT_PROJECT8, m_strPrj8);
	DDX_Text(pDX, IDC_EDT_PROJECT9, m_strPrj9);
	DDX_Text(pDX, IDC_EDT_PROJECT10, m_strPrj10);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO_CS, m_cmbCS);
	DDX_Control(pDX, IDC_COMBO_CS10, m_cmbCS10);
	DDX_Control(pDX, IDC_COMBO_CS2, m_cmbCS2);
	DDX_Control(pDX, IDC_COMBO_CS3, m_cmbCS3);
	DDX_Control(pDX, IDC_COMBO_CS4, m_cmbCS4);
	DDX_Control(pDX, IDC_COMBO_CS5, m_cmbCS5);
	DDX_Control(pDX, IDC_COMBO_CS6, m_cmbCS6);
	DDX_Control(pDX, IDC_COMBO_CS7, m_cmbCS7);
	DDX_Control(pDX, IDC_COMBO_CS8, m_cmbCS8);
	DDX_Control(pDX, IDC_COMBO_CS9, m_cmbCS9);
	DDX_Radio(pDX, IDC_RADIO_COM, m_nComSol);
	DDX_Radio(pDX, IDC_RADIO_COM2, m_nComSol3);
	DDX_Radio(pDX, IDC_RADIO_COM3, m_nComSol5);
	DDX_Radio(pDX, IDC_RADIO_COM4, m_nComSol7);
	DDX_Radio(pDX, IDC_RADIO_COM5, m_nComSol9);
}


BEGIN_MESSAGE_MAP(CDlgScheduleInfo, CDialog)
	//{{AFX_MSG_MAP(CDlgScheduleInfo)
	ON_BN_CLICKED(IDC_BTN_MES, OnButtonMES)
	ON_BN_CLICKED(IDC_BTN_MES2, OnButtonMES2)
	ON_BN_CLICKED(IDC_BTN_MES3, OnButtonMES3)
	ON_BN_CLICKED(IDC_BTN_MES4, OnButtonMES4)
	ON_BN_CLICKED(IDC_BTN_MES5, OnButtonMES5)
	ON_BN_CLICKED(IDC_BTN_MES6, OnButtonMES6)
	ON_BN_CLICKED(IDC_BTN_MES7, OnButtonMES7)
	ON_BN_CLICKED(IDC_BTN_MES8, OnButtonMES8)
	ON_BN_CLICKED(IDC_BTN_MES9, OnButtonMES9)
	ON_BN_CLICKED(IDC_BTN_MES10, OnButtonMES10)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL, OnButtonMESCancel)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL2, OnButtonMESCancel2)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL3, OnButtonMESCancel3)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL4, OnButtonMESCancel4)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL5, OnButtonMESCancel5)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL6, OnButtonMESCancel6)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL7, OnButtonMESCancel7)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL8, OnButtonMESCancel8)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL9, OnButtonMESCancel9)
	ON_BN_CLICKED(IDC_BTN_MES_CANCEL10, OnButtonMESCancel10)
	ON_BN_CLICKED(IDC_BTN_GET_INFO, OnButtonGetInfo)
	ON_BN_CLICKED(IDC_BTN_GET_INFO2, OnButtonGetInfo2)
	ON_BN_CLICKED(IDC_BTN_GET_INFO3, OnButtonGetInfo3)
	ON_BN_CLICKED(IDC_BTN_GET_INFO4, OnButtonGetInfo4)
	ON_BN_CLICKED(IDC_BTN_GET_INFO5, OnButtonGetInfo5)
	ON_BN_CLICKED(IDC_BTN_GET_INFO6, OnButtonGetInfo6)
	ON_BN_CLICKED(IDC_BTN_GET_INFO7, OnButtonGetInfo7)
	ON_BN_CLICKED(IDC_BTN_GET_INFO8, OnButtonGetInfo8)
	ON_BN_CLICKED(IDC_BTN_GET_INFO9, OnButtonGetInfo9)
	ON_BN_CLICKED(IDC_BTN_GET_INFO10, OnButtonGetInfo10)

	ON_BN_CLICKED(IDC_BTN_OPEN, OnButtonPrjOpen)
	ON_BN_CLICKED(IDC_BTN_OPEN2, OnButtonPrjOpen2)
	ON_BN_CLICKED(IDC_BTN_OPEN3, OnButtonPrjOpen3)
	ON_BN_CLICKED(IDC_BTN_OPEN4, OnButtonPrjOpen4)
	ON_BN_CLICKED(IDC_BTN_OPEN5, OnButtonPrjOpen5)
	ON_BN_CLICKED(IDC_BTN_OPEN6, OnButtonPrjOpen6)
	ON_BN_CLICKED(IDC_BTN_OPEN7, OnButtonPrjOpen7)
	ON_BN_CLICKED(IDC_BTN_OPEN8, OnButtonPrjOpen8)
	ON_BN_CLICKED(IDC_BTN_OPEN9, OnButtonPrjOpen9)
	ON_BN_CLICKED(IDC_BTN_OPEN10, OnButtonPrjOpen10)

	ON_BN_CLICKED(IDC_CHK_USE_VALIDATION, OnCheckUseMES)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_DELETE, &CDlgScheduleInfo::OnBnClickedBtnDelete)
	ON_BN_CLICKED(IDC_BTN_DELETE2, &CDlgScheduleInfo::OnBnClickedBtnDelete2)
	ON_BN_CLICKED(IDC_BTN_DELETE3, &CDlgScheduleInfo::OnBnClickedBtnDelete3)
	ON_BN_CLICKED(IDC_BTN_DELETE4, &CDlgScheduleInfo::OnBnClickedBtnDelete4)
	ON_BN_CLICKED(IDC_BTN_DELETE5, &CDlgScheduleInfo::OnBnClickedBtnDelete5)
	ON_BN_CLICKED(IDC_RADIO_COM, &CDlgScheduleInfo::OnBnClickedRadioCom)
	ON_BN_CLICKED(IDC_RADIO_SOL, &CDlgScheduleInfo::OnBnClickedRadioSol)
	ON_BN_CLICKED(IDC_RADIO_BOTH, &CDlgScheduleInfo::OnBnClickedRadioBoth)
	ON_BN_CLICKED(IDC_RADIO_COM2, &CDlgScheduleInfo::OnBnClickedRadioCom2)
	ON_BN_CLICKED(IDC_RADIO_SOL2, &CDlgScheduleInfo::OnBnClickedRadioSol2)
	ON_BN_CLICKED(IDC_RADIO_BOTH2, &CDlgScheduleInfo::OnBnClickedRadioBoth2)
	ON_BN_CLICKED(IDC_RADIO_COM3, &CDlgScheduleInfo::OnBnClickedRadioCom3)
	ON_BN_CLICKED(IDC_RADIO_SOL3, &CDlgScheduleInfo::OnBnClickedRadioSol3)
	ON_BN_CLICKED(IDC_RADIO_BOTH3, &CDlgScheduleInfo::OnBnClickedRadioBoth3)
	ON_BN_CLICKED(IDC_RADIO_COM4, &CDlgScheduleInfo::OnBnClickedRadioCom4)
	ON_BN_CLICKED(IDC_RADIO_SOL4, &CDlgScheduleInfo::OnBnClickedRadioSol4)
	ON_BN_CLICKED(IDC_RADIO_BOTH4, &CDlgScheduleInfo::OnBnClickedRadioBoth4)
	ON_BN_CLICKED(IDC_RADIO_COM5, &CDlgScheduleInfo::OnBnClickedRadioCom5)
	ON_BN_CLICKED(IDC_RADIO_SOL5, &CDlgScheduleInfo::OnBnClickedRadioSol5)
	ON_BN_CLICKED(IDC_RADIO_BOTH5, &CDlgScheduleInfo::OnBnClickedRadioBoth5)
	ON_BN_CLICKED(IDCANCEL, &CDlgScheduleInfo::OnBnClickedCancel)
	ON_EN_SETFOCUS(IDC_EDT_LOTINFO, &CDlgScheduleInfo::OnSetfocusEdtLotinfo)
	ON_EN_SETFOCUS(IDC_EDT_LOTINFO3, &CDlgScheduleInfo::OnEnSetfocusEdtLotinfo3)
	ON_EN_SETFOCUS(IDC_EDT_LOTINFO5, &CDlgScheduleInfo::OnEnSetfocusEdtLotinfo5)
	ON_EN_SETFOCUS(IDC_EDT_LOTINFO7, &CDlgScheduleInfo::OnEnSetfocusEdtLotinfo7)
	ON_EN_SETFOCUS(IDC_EDT_LOTINFO9, &CDlgScheduleInfo::OnEnSetfocusEdtLotinfo9)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgScheduleInfo message handlers

void CDlgScheduleInfo::OnOK() 
{
	if(m_bMESChecking)
		return;

#ifdef __TEST__
//	UpdateData(FALSE);
//	CDialog::OnOK();
#endif

	if(UpdateData(TRUE) == FALSE)
		return;
	m_nLastIndex = 0;
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(m_nNo2)
			GetDlgItem(IDC_EDT_PROJECT2)->SetWindowText(m_strPrj1);
		if(m_nNo3)
			GetDlgItem(IDC_EDT_PROJECT3)->SetWindowText(m_strPrj1);
		if(m_nNo4)
			GetDlgItem(IDC_EDT_PROJECT4)->SetWindowText(m_strPrj1);
		if(m_nNo5)
			GetDlgItem(IDC_EDT_PROJECT5)->SetWindowText(m_strPrj1);
		if(m_nNo6)
			GetDlgItem(IDC_EDT_PROJECT6)->SetWindowText(m_strPrj1);
		if(m_nNo7)
			GetDlgItem(IDC_EDT_PROJECT7)->SetWindowText(m_strPrj1);
		if(m_nNo8)
			GetDlgItem(IDC_EDT_PROJECT8)->SetWindowText(m_strPrj1);
		if(m_nNo9)
			GetDlgItem(IDC_EDT_PROJECT9)->SetWindowText(m_strPrj1);
		if(m_nNo10)
			GetDlgItem(IDC_EDT_PROJECT10)->SetWindowText(m_strPrj1);

		if(m_nNo2)
			m_strPrj2.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo3)
			m_strPrj3.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo4)
			m_strPrj4.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo5)
			m_strPrj5.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo6)
			m_strPrj6.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo7)
			m_strPrj7.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo8)
			m_strPrj8.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo9)
			m_strPrj9.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo10)
			m_strPrj10.Format(_T("%s"),	m_strPrj1);

	}
#endif
	
/*	if(!m_bOnlyDisplay)
	{
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAutoRun)
		{
			if(!OpenPrj())
			{
				CString str;
				str.Format(_T("Tool of project No.%d differ from another project tool "), m_nDiffTool+1);
				ErrMessage(str);
				return;
			}
		}
	}
*/ // 20131001

	// TODO: Add extra validation here
	CString strCopyNo, str;
	m_strLotInfo.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input #1 Comp Lot ID"));
		return;
	}
	if(m_nNo <= 0)
	{
		ErrMessage(_T("Please Input #1 Comp Lot Count"));
		return;
	}
	if(m_strPrj1.GetLength() <= 0)
	{
		ErrMessage(_T("Please Input #1 Comp Project"));
		return;
	}
	if(0 != m_strLotInfo.CompareNoCase(_T("")))
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes)
			{
				str.Format(_T(" Check #1 Comp MES (LotID : %s) before start"), m_strLotInfo);
				ErrMessage(str);
				return;
			}
		}
	}
	
	// 2 
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		m_strLotInfo2 = m_strLotInfo;
		strCopyNo.Format(_T("%d"), m_nNo2);
		GetDlgItem(IDC_EDT_NO2)->SetWindowTextA(strCopyNo);
		if(0 != m_strLotInfo.CompareNoCase(_T("")) && m_strPrj2.GetLength() <= 0 && m_nComSol == 2)
		{
			ErrMessage(_T("Please Input Both Sold Project Lot Index 1"));
			return;
		}
		if(strcmp(m_strPrj2, _T("")) != 0 && strcmp(m_strPrj2, _T(" ")) != 0)
			m_nNo2 = m_nNo;
	}
	
	m_strLotInfo2.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo2.CompareNoCase(_T("")) && m_nNo2 != 0)
	{
		ErrMessage(_T("Please Input #1 Sold Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo2.CompareNoCase(_T("")) && m_nNo2 <= 0 && 
		strcmp(m_strPrj2, _T("")) != 0 && strcmp(m_strPrj2, _T(" ")) != 0)
	{
		ErrMessage(_T("Please Input #1 Sold Lot Count"));
		return;
	}
	else if(m_strPrj2.GetLength() <= 0 && m_nNo2 > 0 && m_nComSol == 2)
	{
		ErrMessage(_T("Please Input #1 Sold Project"));
		return;
	}
	if(0 != m_strLotInfo.CompareNoCase(_T("")) && m_nNo2 != 0)
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes2)
			{
				str.Format(_T(" Check #1 Sold MES (LotID : %s) before start"), m_strLotInfo2);
				ErrMessage(str);
				return;
			}
		}
	}	


	//3
	m_strLotInfo3.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo3.CompareNoCase(_T("")) && m_nNo3 != 0)
	{
		ErrMessage(_T("Please #2 Comp Input Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo3.CompareNoCase(_T("")) && m_nNo3 <= 0)
	{
		ErrMessage(_T("Please #2 Comp Input Lot Count"));
		return;
	}
	else if(m_strPrj3.GetLength() <= 0 && m_nNo3 > 0)
	{
		ErrMessage(_T("Please #2 Comp Input Project"));
		return;
	}
	if(0 != m_strLotInfo3.CompareNoCase(_T("")))
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes3)
			{
				str.Format(_T(" Check #2 Comp MES (LotID : %s) before start"), m_strLotInfo3);
				ErrMessage(str);
				return;
			}
		}
	}	

	//4
	m_strLotInfo4 = m_strLotInfo3;
	strCopyNo.Format(_T("%d"), m_nNo4);
	GetDlgItem(IDC_EDT_NO4)->SetWindowTextA(strCopyNo);
	m_strLotInfo4.Replace(_T(" "), _T(""));
	if(0 != m_strLotInfo3.CompareNoCase(_T("")) && m_strPrj4.GetLength() <= 0 && m_nComSol3 == 2)
	{
		ErrMessage(_T("Please Input Both Sold Project Lot Index 2"));
		return;
	}
	if(strcmp(m_strPrj4, _T("")) != 0 && strcmp(m_strPrj4, _T(" ")) != 0)
		m_nNo4 = m_nNo3;
	if(0 == m_strLotInfo4.CompareNoCase(_T("")) && m_nNo4 != 0)
	{
		ErrMessage(_T("Please Input #2 Sold Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo4.CompareNoCase(_T("")) && m_nNo4 <= 0 &&
		strcmp(m_strPrj4, _T("")) != 0 && strcmp(m_strPrj4, _T(" ")) != 0)
	{
		ErrMessage(_T("Please Input #2 Sold Lot Count"));
		return;
	}
	else if(m_strPrj4.GetLength() <= 0 && m_nNo4 > 0 && m_nComSol3 == 2)
	{
		ErrMessage(_T("Please Input #2 Sold Project"));
		return;
	}
	if(0 != m_strLotInfo3.CompareNoCase(_T("")) && m_nNo4 != 0)
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes4)
			{
				str.Format(_T(" Check #2 Sold MES (LotID : %s) before start"), m_strLotInfo4);
				ErrMessage(str);
				return;
			}
		}
	}	

	// 5

	m_strLotInfo5.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo5.CompareNoCase(_T("")) && m_nNo5 != 0)
	{
		ErrMessage(_T("Please Input #3 Comp Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo5.CompareNoCase(_T("")) && m_nNo5 <= 0)
	{
		ErrMessage(_T("Please Input #3 Comp Lot Count"));
		return;
	}
	else if(m_strPrj5.GetLength() <= 0 && m_nNo5 > 0)
	{
		ErrMessage(_T("Please Input #3 Comp Project"));
		return;
	}
	if(0 != m_strLotInfo5.CompareNoCase(_T("")))
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes5)
			{
				str.Format(_T(" Check #3 Comp MES (LotID : %s) before start"), m_strLotInfo5);
				ErrMessage(str);
				return;
			}
		}
	}	


	//6
	m_strLotInfo6 = m_strLotInfo5;
	strCopyNo.Format(_T("%d"), m_nNo6);
	GetDlgItem(IDC_EDT_NO6)->SetWindowTextA(strCopyNo);
	if(0 != m_strLotInfo5.CompareNoCase(_T("")) && m_strPrj6.GetLength() <= 0 && m_nComSol5 == 2)
	{
		ErrMessage(_T("Please Input Both Sold Project Lot Index 3"));
		return;
	}
	if(strcmp(m_strPrj6, _T("")) != 0 && strcmp(m_strPrj6, _T(" ")) != 0)
		m_nNo6 = m_nNo5;
	m_strLotInfo6.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo6.CompareNoCase(_T("")) && m_nNo6 != 0)
	{
		ErrMessage(_T("Please Input #3 Sold Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo6.CompareNoCase(_T("")) && m_nNo6 <= 0 &&
		strcmp(m_strPrj6, _T("")) != 0 && strcmp(m_strPrj6, _T(" ")) != 0)
	{
		ErrMessage(_T("Please Input #3 Sold Lot Count"));
		return;
	}
	else if(m_strPrj6.GetLength() <= 0 && m_nNo6 > 0 && m_nComSol5 == 2)
	{
		ErrMessage(_T("Please Input #3 Sold Project"));
		return;
	}
	if(0 != m_strLotInfo5.CompareNoCase(_T("")) && m_nNo6 != 0)
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes6)
			{
				str.Format(_T(" Check #3 Sold MES (LotID : %s) before start"), m_strLotInfo6);
				ErrMessage(str);
				return;
			}
		}
	}	
	


	// 7 
	m_strLotInfo7.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo7.CompareNoCase(_T("")) && m_nNo7 != 0)
	{
		ErrMessage(_T("Please Input #4 Comp Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo7.CompareNoCase(_T("")) && m_nNo7 <= 0)
	{
		ErrMessage(_T("Please Input #4 Comp Lot Count"));
		return;
	}
	else if(m_strPrj7.GetLength() <= 0 && m_nNo7 > 0)
	{
		ErrMessage(_T("Please Input #4 Comp Project"));
		return;
	}
	if(0 != m_strLotInfo7.CompareNoCase(_T("")))
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes7)
			{
				str.Format(_T(" Check MES #4 Comp (LotID : %s) before start"), m_strLotInfo7);
				ErrMessage(str);
				return;
			}
		}
	}	


	// 8
	m_strLotInfo8 = m_strLotInfo7;
	strCopyNo.Format(_T("%d"), m_nNo8);
	GetDlgItem(IDC_EDT_NO8)->SetWindowTextA(strCopyNo);
	if(0 != m_strLotInfo7.CompareNoCase(_T("")) && m_strPrj8.GetLength() <= 0 && m_nComSol7 == 2)
	{
		ErrMessage(_T("Please Input Both Sold Project Lot Index 4"));
		return;
	}
	if(strcmp(m_strPrj8, _T("")) != 0 && strcmp(m_strPrj8, _T(" ")) != 0)
		m_nNo8 = m_nNo7;
	m_strLotInfo8.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo8.CompareNoCase(_T("")) && m_nNo8 != 0)
	{
		ErrMessage(_T("Please Input #4 Sold Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo8.CompareNoCase(_T("")) && m_nNo8 <= 0 &&
		strcmp(m_strPrj8, _T("")) != 0 && strcmp(m_strPrj8, _T(" ")) != 0)
	{
		ErrMessage(_T("Please Input #4 Sold Lot Count"));
		return;
	}
	else if(m_strPrj8.GetLength() <= 0 && m_nNo8 > 0 && m_nComSol7 == 2 )
	{
		ErrMessage(_T("Please Input #4 Sold Project"));
		return;
	}
	if(0 != m_strLotInfo7.CompareNoCase(_T("")) && m_nNo8 != 0)
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes8)
			{
				str.Format(_T(" Check #4 Sold MES (LotID : %s) before start"), m_strLotInfo8);
				ErrMessage(str);
				return;
			}
		}
	}	
	

	// 9
	m_strLotInfo9.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo9.CompareNoCase(_T("")) && m_nNo9 != 0)
	{
		ErrMessage(_T("Please Input #5 Comp Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo9.CompareNoCase(_T("")) && m_nNo9 <= 0)
	{
		ErrMessage(_T("Please Input #5 Comp Lot Count"));
		return;
	}
	else if(m_strPrj9.GetLength() <= 0 && m_nNo9 > 0)
	{
		ErrMessage(_T("Please Input #5 Comp Project"));
		return;
	}
	if(0 != m_strLotInfo9.CompareNoCase(_T("")))
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes9)
			{
				str.Format(_T(" Check MES #5 Comp (LotID : %s) before start"), m_strLotInfo9);
				ErrMessage(str);
				return;
			}
		}
	}	

	// 10
	m_strLotInfo10 = m_strLotInfo9;
	strCopyNo.Format(_T("%d"), m_nNo10);
	GetDlgItem(IDC_EDT_NO10)->SetWindowTextA(strCopyNo);
	if(0 != m_strLotInfo9.CompareNoCase(_T("")) && m_strPrj10.GetLength() <= 0 && m_nComSol9 == 2)
	{
		ErrMessage(_T("Please Input Both Sold Project Lot Index 5"));
		return;
	}
	if(strcmp(m_strPrj10, _T("")) != 0 && strcmp(m_strPrj10, _T(" ")) != 0)
		m_nNo10 = m_nNo9;
	m_strLotInfo10.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo10.CompareNoCase(_T("")) && m_nNo10 != 0)
	{
		ErrMessage(_T("Please Input #5 Sold Lot ID"));
		return;
	}
	else if(0 != m_strLotInfo10.CompareNoCase(_T("")) && m_nNo10 <= 0 &&
		strcmp(m_strPrj10, _T("")) != 0 && strcmp(m_strPrj10, _T(" ")) != 0)
	{
		ErrMessage(_T("Please Input #5 Sold Lot Count"));
		return;
	}
	else if(m_strPrj10.GetLength() <= 0 && m_nNo10 > 0 && m_nComSol9 == 2)
	{
		ErrMessage(_T("Please Input #5 Sold Project"));
		return;
	}
	if(0 != m_strLotInfo9.CompareNoCase(_T("")) && m_nNo10 != 0)
	{
		m_nLastIndex++;

		if(m_bUseMES)
		{
			if(!m_bMes10)
			{
				str.Format(_T(" Check #5 Sold MES (LotID : %s) before start"), m_strLotInfo10);
				ErrMessage(str);
				return;
			}
		}
	}

	UpdateData(FALSE);
	CDialog::OnOK();
}

BOOL CDlgScheduleInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	
	m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
	m_dlgOPCWait.ShowWindow(SW_HIDE);


	m_nDiffTool = -1;
	m_bCompareOK = TRUE;
	int nRMSType = 2;
#ifndef __NO_USE_OPC__
	nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
#endif
	if(!gProcessINI.m_sProcessSystem.bUseScheduling && nRMSType != 0)
	{
		for(int i = 1; i < 10; i++)
		{
			strcpy(gLotInfo.szLotID[i], _T(" "));
			strcpy(gLotInfo.szPrj[i], _T(""));
			gLotInfo.bMESOK[i] = 0;
			gLotInfo.bUseOpenTool[i] = TRUE;
			gLotInfo.nLotCount[i] = 0;
			gLotInfo.nFiredLotCount[i] = 0;
			gLotInfo.nNGLotCount[i] = 0;

			if(i % 2 == 1)
				gLotInfo.nComSol[i] = 3;
			else
				gLotInfo.nComSol[i] = 2;
		}
	}
	
	// TODO: Add extra initialization here
	m_strLotInfo.Format(_T("%s"), gLotInfo.szLotID[0]);
	m_strLotInfo2.Format(_T("%s"), gLotInfo.szLotID[1]);
	m_strLotInfo3.Format(_T("%s"), gLotInfo.szLotID[2]);
	m_strLotInfo4.Format(_T("%s"), gLotInfo.szLotID[3]);
	m_strLotInfo5.Format(_T("%s"), gLotInfo.szLotID[4]);
	m_strLotInfo6.Format(_T("%s"), gLotInfo.szLotID[5]);
	m_strLotInfo7.Format(_T("%s"), gLotInfo.szLotID[6]);
	m_strLotInfo8.Format(_T("%s"), gLotInfo.szLotID[7]);
	m_strLotInfo9.Format(_T("%s"), gLotInfo.szLotID[8]);
	m_strLotInfo10.Format(_T("%s"), gLotInfo.szLotID[9]);
	

	m_strPrj1.Format(_T("%s"), gLotInfo.szPrj[0]);
	m_strPrj2.Format(_T("%s"), gLotInfo.szPrj[1]);
	m_strPrj3.Format(_T("%s"), gLotInfo.szPrj[2]);
	m_strPrj4.Format(_T("%s"), gLotInfo.szPrj[3]);
	m_strPrj5.Format(_T("%s"), gLotInfo.szPrj[4]);
	m_strPrj6.Format(_T("%s"), gLotInfo.szPrj[5]);
	m_strPrj7.Format(_T("%s"), gLotInfo.szPrj[6]);
	m_strPrj8.Format(_T("%s"), gLotInfo.szPrj[7]);
	m_strPrj9.Format(_T("%s"), gLotInfo.szPrj[8]);
	m_strPrj10.Format(_T("%s"), gLotInfo.szPrj[9]);

	
	m_bMes = gLotInfo.bMESOK[0];
	m_bMes2 = gLotInfo.bMESOK[1];
	m_bMes3 = gLotInfo.bMESOK[2];
	m_bMes4 = gLotInfo.bMESOK[3];
	m_bMes5 = gLotInfo.bMESOK[4];
	m_bMes6 = gLotInfo.bMESOK[5];
	m_bMes7 = gLotInfo.bMESOK[6];
	m_bMes8 = gLotInfo.bMESOK[7];
	m_bMes9 = gLotInfo.bMESOK[8];
	m_bMes10 = gLotInfo.bMESOK[9];

	m_bUseOpenTool	= gLotInfo.bUseOpenTool[0];
	m_bUseOpenTool2	= gLotInfo.bUseOpenTool[1];
	m_bUseOpenTool3	= gLotInfo.bUseOpenTool[2];
	m_bUseOpenTool4	= gLotInfo.bUseOpenTool[3];
	m_bUseOpenTool5 = gLotInfo.bUseOpenTool[4];
	m_bUseOpenTool6 = gLotInfo.bUseOpenTool[5];
	m_bUseOpenTool7 = gLotInfo.bUseOpenTool[6];
	m_bUseOpenTool8 = gLotInfo.bUseOpenTool[7];
	m_bUseOpenTool9 = gLotInfo.bUseOpenTool[8];
	m_bUseOpenTool10= gLotInfo.bUseOpenTool[9];

/*	m_cmbCS.SetCurSel(gLotInfo.nComSol[0]);
	m_cmbCS2.SetCurSel(gLotInfo.nComSol[1]);
	m_cmbCS3.SetCurSel(gLotInfo.nComSol[2]);
	m_cmbCS4.SetCurSel(gLotInfo.nComSol[3]);
	m_cmbCS5.SetCurSel(gLotInfo.nComSol[4]);
	m_cmbCS6.SetCurSel(gLotInfo.nComSol[5]);
	m_cmbCS7.SetCurSel(gLotInfo.nComSol[6]);
	m_cmbCS8.SetCurSel(gLotInfo.nComSol[7]);
	m_cmbCS9.SetCurSel(gLotInfo.nComSol[8]);
	m_cmbCS10.SetCurSel(gLotInfo.nComSol[9]);
	*/
	m_nComSol = gLotInfo.nComSol[0];
	m_nComSol2 = gLotInfo.nComSol[1];
	m_nComSol3 = gLotInfo.nComSol[2];
	m_nComSol4 = gLotInfo.nComSol[3];
	m_nComSol5 = gLotInfo.nComSol[4];
	m_nComSol6 = gLotInfo.nComSol[5];
	m_nComSol7 = gLotInfo.nComSol[6];
	m_nComSol8 = gLotInfo.nComSol[7];
	m_nComSol9 = gLotInfo.nComSol[8];
	m_nComSol10 = gLotInfo.nComSol[9];

	EnableComSolBoth(gLotInfo.nComSol);
#ifndef __NO_USE_OPC__
	
	if(nRMSType != 2)
		m_bUseMES = TRUE;
	else
		m_bUseMES = FALSE; //gLotInfo.bUseMES;
#else
	 nRMSType = 2;
	m_bUseMES = FALSE;
#endif
	

	m_strFilmNo.Format(_T("%s"), gLotInfo.szFilmNo[0]);
	m_strFilmNo2.Format(_T("%s"), gLotInfo.szFilmNo[1]);
	m_strFilmNo3.Format(_T("%s"), gLotInfo.szFilmNo[2]);
	m_strFilmNo4.Format(_T("%s"), gLotInfo.szFilmNo[3]);
	m_strFilmNo5.Format(_T("%s"), gLotInfo.szFilmNo[4]);
	m_strFilmNo6.Format(_T("%s"), gLotInfo.szFilmNo[5]);
	m_strFilmNo7.Format(_T("%s"), gLotInfo.szFilmNo[6]);
	m_strFilmNo8.Format(_T("%s"), gLotInfo.szFilmNo[7]);
	m_strFilmNo9.Format(_T("%s"), gLotInfo.szFilmNo[8]);
	m_strFilmNo10.Format(_T("%s"), gLotInfo.szFilmNo[9]);

	m_strProcessCode.Format(_T("%s"), gLotInfo.szProcessCode[0]);
	m_strProcessCode2.Format(_T("%s"), gLotInfo.szProcessCode[1]);
	m_strProcessCode3.Format(_T("%s"), gLotInfo.szProcessCode[2]);
	m_strProcessCode4.Format(_T("%s"), gLotInfo.szProcessCode[3]);
	m_strProcessCode5.Format(_T("%s"), gLotInfo.szProcessCode[4]);
	m_strProcessCode6.Format(_T("%s"), gLotInfo.szProcessCode[5]);
	m_strProcessCode7.Format(_T("%s"), gLotInfo.szProcessCode[6]);
	m_strProcessCode8.Format(_T("%s"), gLotInfo.szProcessCode[7]);
	m_strProcessCode9.Format(_T("%s"), gLotInfo.szProcessCode[8]);
	m_strProcessCode10.Format(_T("%s"), gLotInfo.szProcessCode[9]);

	m_cmbBarType.SetCurSel(0);

	m_nStatus = gLotInfo.nStatus[0];
	m_nStatus2 = gLotInfo.nStatus[1];
	m_nStatus3 = gLotInfo.nStatus[2];
	m_nStatus4 = gLotInfo.nStatus[3];
	m_nStatus5 = gLotInfo.nStatus[4];
	m_nStatus6 = gLotInfo.nStatus[5];
	m_nStatus7 = gLotInfo.nStatus[6];
	m_nStatus8 = gLotInfo.nStatus[7];
	m_nStatus9 = gLotInfo.nStatus[8];
	m_nStatus10 = gLotInfo.nStatus[9];
	
	m_nFireType = gLotInfo.nFireType[0];
	m_nFireType2 = gLotInfo.nFireType[1];
	m_nFireType3 = gLotInfo.nFireType[2];
	m_nFireType4 = gLotInfo.nFireType[3];
	m_nFireType5 = gLotInfo.nFireType[4];
	m_nFireType6 = gLotInfo.nFireType[5];
	m_nFireType7 = gLotInfo.nFireType[6];
	m_nFireType8 = gLotInfo.nFireType[7];
	m_nFireType9 = gLotInfo.nFireType[8];
	m_nFireType10 = gLotInfo.nFireType[9];

	m_nLastIndex = gLotInfo.nLastIndex;

	DisplayMES();



	if(m_bUseMES)
		CheckDlgButton(IDC_CHK_USE_VALIDATION, TRUE);
	else
		CheckDlgButton(IDC_CHK_USE_VALIDATION, FALSE);
	/*
	if(m_bOnlyDisplay)
		EnableControl(FALSE, TRUE);
	else if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else if(nRMSType == 2)
		*/
		EnableControl(TRUE);

	UpdateData(FALSE);

	if( m_bAutoMes )
	{
		AutoMES();
		CDialog::OnOK();
	}	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgScheduleInfo::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Schedule_Info) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	if (pMsg->message == WM_KEYDOWN)
	{
		int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
		switch (pMsg->wParam)
		{
		case VK_ESCAPE :
			return TRUE;
		case VK_RETURN :
			{
				if(nRMSType == 1)
				{
					if(m_bSetFocusLot)
					{
						OnButtonMES(); 
						return TRUE;
					}
					if(m_bSetFocusLot2)
					{
						OnButtonMES3();
						return TRUE;
					}
					if(m_bSetFocusLot3)
					{
						OnButtonMES5();
						return TRUE;
					}
					if(m_bSetFocusLot4)
					{
						OnButtonMES7();
						return TRUE;
					}
					if(m_bSetFocusLot5)
					{
						OnButtonMES9();
						return TRUE;
					}
				}
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgScheduleInfo::OnButtonMES()
{
	UpdateData(TRUE);
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	m_strLotInfo.Replace(_T(" "), _T(""));
	if( nRMSType != 0)
	{
		if(0 == m_strLotInfo.CompareNoCase(_T("")))
		{
			ErrMessage(_T("Please Input Lot ID"));
			return;
		}
	}
	GetDlgItem(IDC_BTN_MES)->EnableWindow(FALSE);

	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo, 1))
	{
		m_bMes = TRUE;
		m_bMes2 = TRUE;
	}
	else
	{
		m_bMes = FALSE;
	}
	m_bMESChecking = FALSE;
	
	if( nRMSType != 0)
		SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();

}

void CDlgScheduleInfo::OnButtonMES2()
{
	UpdateData(TRUE);
	m_strLotInfo2.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo2.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}
	GetDlgItem(IDC_BTN_MES2)->EnableWindow(FALSE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo2, 2))
	{
		m_bMes2 = TRUE;
		GetDlgItem(IDC_BTN_MES2)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(TRUE);
	}
	else
	{
		m_bMes2 = FALSE;
		GetDlgItem(IDC_BTN_MES2)->EnableWindow(TRUE);
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES3()
{
	UpdateData(TRUE);
	m_strLotInfo3.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo3.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}
	GetDlgItem(IDC_BTN_MES3)->EnableWindow(FALSE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo3, 3))
	{
		m_bMes3 = TRUE;
		m_bMes4 = TRUE;
	}
	else
	{
		m_bMes3 = FALSE;
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES4()
{
	UpdateData(TRUE);
	m_strLotInfo4.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo4.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}
	GetDlgItem(IDC_BTN_MES4)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo4, 4))
	{
		m_bMes4 = TRUE;
		GetDlgItem(IDC_BTN_MES4)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(TRUE);
	}
	else
	{
		m_bMes4 = FALSE;
		GetDlgItem(IDC_BTN_MES4)->EnableWindow(TRUE);
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES5()
{
	UpdateData(TRUE);
	m_strLotInfo5.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo5.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES5)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo5, 5))
	{
		m_bMes5 = TRUE;
		m_bMes6 = TRUE;
	}
	else
	{
		m_bMes5 = FALSE;
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES6()
{
	UpdateData(TRUE);
	m_strLotInfo6.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo6.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES6)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo6, 6))
	{
		GetDlgItem(IDC_BTN_MES6)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(TRUE);
		m_bMes6 = TRUE;
	}
	else
	{
		m_bMes6 = FALSE;
		GetDlgItem(IDC_BTN_MES6)->EnableWindow(TRUE);
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES7()
{
	UpdateData(TRUE);
	m_strLotInfo7.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo7.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES7)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo7, 7))
	{
		m_bMes7 = TRUE;
		m_bMes8 = TRUE;
	}
	else
	{
		m_bMes7 = FALSE;
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES8()
{
	UpdateData(TRUE);
	m_strLotInfo8.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo8.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES8)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo8, 8))
	{
		m_bMes8 = TRUE;
		GetDlgItem(IDC_BTN_MES8)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(TRUE);
	}
	else
	{
		m_bMes8 = FALSE;
		GetDlgItem(IDC_BTN_MES8)->EnableWindow(TRUE);
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES9()
{
	UpdateData(TRUE);
	m_strLotInfo9.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo9.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES9)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo9, 9))
	{
		m_bMes9 = TRUE;
		m_bMes10 = TRUE;
	}
	else
	{
		m_bMes9 = FALSE;
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

void CDlgScheduleInfo::OnButtonMES10()
{
	UpdateData(TRUE);
	m_strLotInfo10.Replace(_T(" "), _T(""));
	if(0 == m_strLotInfo10.CompareNoCase(_T("")))
	{
		ErrMessage(_T("Please Input Lot ID"));
		return;
	}

	GetDlgItem(IDC_BTN_MES10)->EnableWindow(TRUE);
	m_bMESChecking = TRUE;
	if(MesDataCheck(m_strLotInfo10, 10))
	{
		m_bMes10 = TRUE;
		GetDlgItem(IDC_BTN_MES10)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(TRUE);
	}
	else
	{
		m_bMes10 = FALSE;
		GetDlgItem(IDC_BTN_MES10)->EnableWindow(TRUE);
	}
	m_bMESChecking = FALSE;
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}
void CDlgScheduleInfo::OnButtonMESCancel()
{
	UpdateData(TRUE);
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 124, reinterpret_cast<LPARAM>(&strMESCancel));	//123 ����->TC MES������� ��û D_000_000003_01
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		m_bMes = FALSE;
		m_bMes2 = FALSE;
		m_nNo = 0;
		m_nNo2 = 0;
		m_strPrj1 = _T("");
		m_strPrj2 = _T("");
		
	}
	else
	{
		m_bMes = TRUE;
		m_bMes2 = TRUE;
	}
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonMESCancel2()
{
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo2, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		GetDlgItem(IDC_BTN_MES2)->SetWindowText("MES");
		GetDlgItem(IDC_BTN_MES2)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(FALSE);
		m_bMes = FALSE;
	}
	else
	{
		GetDlgItem(IDC_BTN_MES2)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(TRUE);
		m_bMes = TRUE;
	}

}

void CDlgScheduleInfo::OnButtonMESCancel3()
{
	UpdateData(TRUE);
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo3, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û	
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		m_bMes3 = FALSE;
		m_bMes4 = FALSE;
		m_nNo3 = 0;
		m_nNo4 = 0;
		m_strPrj3 = _T("");
		m_strPrj4 = _T("");
	}
	else
	{
		m_bMes3 = TRUE;
		m_bMes4 = TRUE;
	}
	EnableControlForMES(TRUE);
	SaveLotInfo();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonMESCancel4()
{
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo4, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 867, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		GetDlgItem(IDC_BTN_MES4)->SetWindowText("MES");
		GetDlgItem(IDC_BTN_MES4)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(FALSE);
		m_bMes = FALSE;
	}
	else
	{
		GetDlgItem(IDC_BTN_MES4)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(TRUE);
		m_bMes = TRUE;
	}

}

void CDlgScheduleInfo::OnButtonMESCancel5()
{
	UpdateData(TRUE);
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo5, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		m_bMes5 = FALSE;
		m_bMes6 = FALSE;
		m_nNo5 = 0;
		m_nNo6 = 0;
		m_strPrj5 = _T("");
		m_strPrj6 = _T("");
	}
	else
	{
		m_bMes5 = TRUE;
		m_bMes6 = TRUE;
	}
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonMESCancel6()
{
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo6, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		GetDlgItem(IDC_BTN_MES6)->SetWindowText("MES");
		GetDlgItem(IDC_BTN_MES6)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(FALSE);
		m_bMes = FALSE;
	}
	else
	{
		GetDlgItem(IDC_BTN_MES6)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(TRUE);
		m_bMes = TRUE;
	}

}

void CDlgScheduleInfo::OnButtonMESCancel7()
{
	UpdateData(TRUE);
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo7, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		m_bMes7 = FALSE;
		m_bMes8 = FALSE;
		m_nNo7 = 0;
		m_nNo8 = 0;
		m_strPrj7 = _T("");
		m_strPrj8 = _T("");
	}
	else
	{
		m_bMes7 = TRUE;
		m_bMes8 = TRUE;
	}
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonMESCancel8()
{
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo8, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 867, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		GetDlgItem(IDC_BTN_MES8)->SetWindowText("MES");
		GetDlgItem(IDC_BTN_MES8)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(FALSE);
		m_bMes = FALSE;
	}
	else
	{
		GetDlgItem(IDC_BTN_MES8)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(TRUE);
		m_bMes = TRUE;
	}

}

void CDlgScheduleInfo::OnButtonMESCancel9()
{
	UpdateData(TRUE);
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo9, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		m_bMes9 = FALSE;
		m_bMes10 = FALSE;
		m_nNo9 = 0;
		m_nNo10 = 0;
		m_strPrj9 = _T("");
		m_strPrj10 = _T("");
	}
	else
	{
		m_bMes9 = TRUE;
		m_bMes10 = TRUE;
	}
	SaveLotInfo();
	EnableControlForMES(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonMESCancel10()
{
	CString strMESCancel;
	strMESCancel.Format(_T("%s;%s;%s"), m_strLotInfo10, "WET", gDProject.m_strUserID );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 758, reinterpret_cast<LPARAM>(&strMESCancel));	//867 ����->TC MES������� ��û
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetMESCancelReturnData())
	{
		GetDlgItem(IDC_BTN_MES10)->SetWindowText("MES");
		GetDlgItem(IDC_BTN_MES10)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(FALSE);
		m_bMes = FALSE;
	}
	else
	{
		GetDlgItem(IDC_BTN_MES10)->SetWindowText("OK");
		GetDlgItem(IDC_BTN_MES10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(TRUE);
		m_bMes = TRUE;
	}

}

void CDlgScheduleInfo::OnCheckUseMES()
{
	m_bUseMES = IsDlgButtonChecked(IDC_CHK_USE_VALIDATION);
//	DisplayMES();
}
void CDlgScheduleInfo::OnButtonGetInfo()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo2()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo2, strLotCount, strFilmNo, strProcessCode);

	if(bResult)
	{
		m_nNo2 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO2)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE2)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo3()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo3, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo3 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO3)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE3)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo4()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo4, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo4 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO4)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE4)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo5()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo5, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo5 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO5)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE5)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo6()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo6, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo6 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO6)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE6)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo7()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo7, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo7 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO7)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE7)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo8()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo8, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo8 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO8)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE8)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo9()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo9, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo9 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO9)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE9)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
*/
}

void CDlgScheduleInfo::OnButtonGetInfo10()
{
/*	UpdateData(TRUE);
	CString strLotCount = _T("");
	CString strFilmNo = _T("");
	CString strProcessCode = _T("");
	BOOL bResult = FALSE;
	bResult = RMSDataCheck(m_strLotInfo10, strLotCount, strFilmNo, strProcessCode);
	
	if(bResult)
	{
		m_nNo10 = atoi(strLotCount);
		GetDlgItem(IDC_EDIT_FILM_NO10)->SetWindowText(strFilmNo);
		GetDlgItem(IDC_EDIT_PROCESS_CODE10)->SetWindowText(strProcessCode);
	}
	UpdateData(FALSE);
	*/
}

BOOL CDlgScheduleInfo::MesDataCheck(CString strLotID1, int nIndex, BOOL bNoDoMo)
{
	if( strcmp(strLotID1.Left(5), "Dummy") != 0 &&
		strcmp(strLotID1.Left(6), "Pdummy") != 0 && strcmp(strLotID1.Left(6), "Rdummy") != 0 &&
		strcmp(strLotID1.Left(6), "Bdummy") != 0 && strcmp(strLotID1.Left(6), "Tdummy") != 0 &&
		strcmp(strLotID1.Left(6), "Cdummy") != 0 && strcmp(strLotID1.Left(9), "E-M-P-T-Y") != 0)
	{


		int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();

		if(nRMSType == 2)
			return TRUE;

		int nComSol, nStatus; 
		if(nRMSType == 0)
		{
			nComSol =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetAIType();
			if(nComSol == 0 || nComSol == 1)
			{
				if(gLotInfo.nLastIndex + 1 == MAX_LOTID_CNT)
				{
					ErrMessage(_T("Lot Index is full"));
					return FALSE;
				}
			}
			else
			{
				if(gLotInfo.nLastIndex + 2 == MAX_LOTID_CNT)
				{
					ErrMessage(_T("Lot Index is full"));
					return FALSE;
				}
			}
			if(nComSol != 0 && nComSol != 1 && nComSol != 2 && nComSol != 3)
			{
				ErrMessage(_T("Select Com/Sol Info"));
				return FALSE;
			}
		}
		else
		{
			switch(nIndex)
			{
			case 1: nComSol = m_nComSol; break;
			case 2: nComSol = m_nComSol2; break;
			case 3: nComSol = m_nComSol3; break;
			case 4: nComSol = m_nComSol4; break;
			case 5: nComSol = m_nComSol5; break;
			case 6: nComSol = m_nComSol6; break;
			case 7: nComSol = m_nComSol7; break;
			case 8: nComSol = m_nComSol8; break;
			case 9: nComSol = m_nComSol9; break;
			}
		}
		
//		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_VALIDATION, reinterpret_cast<LPARAM>(&strLotID1)))
//			return FALSE; //20150319
		
		CString strGetManage, strGetCount, strGetLotID, strGetStatus, strGetMessage, strGetBasket, strGetResult, strLayer, strThick;
		CString strProcessCode, strBackwardLevel, strLaserComp, strLaserSold;

		strGetBasket =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBasket;
		if(bNoDoMo)
			strGetBasket.Format(_T("%s"), strLotID1);

		strGetManage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePrj;
		strGetCount = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeParam;
		strGetLotID = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeID;
		strGetStatus = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeStatus; 
		strGetMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage; 
		strGetResult =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
		strLayer = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeLayer;
		strThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialThick;
		strProcessCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProcessCode;
		strBackwardLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBackwardLevel;

		strLaserComp = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCompLaserFile;
		strLaserSold = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strSoldLaserFile;

#ifdef __TEST__
		strGetManage = _T("133-877-9T");
		strGetCount = _T("6");
		strGetLotID = _T("GGGGGGGGGG");
		strGetStatus = _T("0");
		strGetMessage = _T("");
		strGetResult =  _T("PASS");
		strLayer = _T("4");
#endif

		if(strcmp(strGetResult, "FAIL") == 0)
		{
			ErrMessage(strGetMessage);
			return FALSE;
		}

		CString strFind1, strFind2,strErr;
		if(nComSol == 2 || nComSol == 3)
		{

			strFind1 = FindProjectNameNew2(strGetLotID, strGetManage, FALSE, strProcessCode, strBackwardLevel ); //com
			strFind2 = FindProjectNameNew2(strGetLotID, strGetManage, TRUE, strProcessCode, strBackwardLevel ); //sol

			if(atoi(strGetManage.Right(2)) != 1) 
			{
				if(strFind1 == "NOEXIST" && strFind2 == "NOEXIST")
				{
					strErr.Format(_T("%s & %s_(COMP,SOLD)"),strGetManage,strGetLotID  );
					ErrMsgDlg(STDGNALM251,strErr );
					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
				}
				if(strFind1 == "NOEXIST")
				{
					strErr.Format(_T("%s & %s_(COMP)"),strGetManage,strGetLotID  );
					ErrMsgDlg(STDGNALM251,strErr );
					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
				}
				if(strFind2 == "NOEXIST")
				{
					strErr.Format(_T("%s & %s_(SOLD)"),strGetManage,strGetLotID  );
					ErrMsgDlg(STDGNALM251,strErr );
					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
				}
			}
			else
			{
				if(strFind1 == "NOEXIST")
				{
					strErr.Format(_T("%s & %s_(COMP)"),strGetManage,strGetLotID  );
					ErrMsgDlg(STDGNALM251,strErr );
					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
				}
				if(strFind2 == "NOEXIST")
				{
					strFind2 = _T(" ");
				}
			}
		}
		else
		{

			strFind1 = FindProjectNameNew2(strGetLotID, strGetManage, nComSol, strProcessCode, strBackwardLevel ); //com

			if(strFind1 == "NOEXIST")
			{
				strErr.Format(_T("%s & %s"),strGetManage,strGetLotID  );
				ErrMsgDlg(STDGNALM251,strErr );
				return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
			}
		}

		if(nRMSType == 1)
			strGetBasket = " ";

		CDlgOPCResult dlg;
		dlg.m_nProjectData = 1;
		if(nComSol == 2 || nComSol == 3)
			dlg.SetResult(strGetBasket, strGetCount, strGetManage, strGetLotID, strGetMessage, strFind1, strFind2, strGetResult, strThick);
		else if(nComSol == 1)
			dlg.SetResult(strGetBasket, strGetCount, strGetManage, strGetLotID, strGetMessage, " ", strFind1, strGetResult, strThick);
		else if(nComSol == 0)
			dlg.SetResult(strGetBasket, strGetCount, strGetManage, strGetLotID, strGetMessage, strFind1, " ", strGetResult, strThick);
	
		if(dlg.DoModal() == IDCANCEL)
		{
#ifndef	__TEST__
			return FALSE;
#endif

		}
				
		CString strLotID2 = _T("");
		CString strProcess = _T("WET");
		CString strOPCData = _T("");
		CString strRMSData = _T("");
		CString strData1 = _T("");
		CString strData2 = _T("");
		CString strData3 = _T("");
		CString strBasketID = _T("");
		BOOL bRMSReturn = FALSE;
		BOOL bOK = TRUE;
		int nErr = 0;
		
		CString strUserID = _T("");
		strUserID.Format(_T("%s"), gDProject.m_strUserID);
		strBasketID.Format(_T(""));

		if(nRMSType == 1)
		{
			strOPCData.Format(_T("%s;%s;%s"), strGetLotID, strUserID, strProcess);
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 114, reinterpret_cast<LPARAM>(&strOPCData));	//113 ����->TC MES����ó���� ���� �۾��� �Է� ���� ��û : D_000_000001_01

			if(!WaitOPCRecvMessage()) 
			{
				ErrMsgDlg(STDGNALM250);
				return FALSE;
			}

			strData1 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchMessage;
			strData2 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchMessage2;
			CString strLot = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchLot2;
			int nVal = atoi(strData1);
			int nVal2 = atoi(strData2);
			if(nVal || nVal2)
			{
				CDlgDispatch dlg;
				char szLotID[50], szLotID2[50] , szTemp[100];
				memset(&szLotID, 0, sizeof(szLotID));
				memset(&szLotID2, 0, sizeof(szLotID2));
				memset(&szTemp, 0, sizeof(szTemp));

				strcpy(szLotID, strGetLotID);
				strcpy(szLotID2, strLot);

				dlg.SetLotInfo(szLotID, szLotID2, nVal, nVal2); // current lot 
				if(dlg.DoModal() == IDCANCEL)
					return FALSE;

				dlg.GetResult(nErr, bOK, szTemp);
				CString strTemp;
				strTemp.Format(_T("%s"), szTemp);
				if(!bOK)
				{
					ErrMessage(strTemp);
					return FALSE;
				}
			}
			else if(!nVal && !nVal2)
			{
				strOPCData.Format(_T("%s;%s;;;;"), strGetLotID, strUserID);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 119, reinterpret_cast<LPARAM>(&strOPCData));	//118 ����->TC MES����ó���� ���� �۾��� �Է� ���� ��û : D_000_000002_01

				if(!WaitOPCRecvMessage())
				{
					ErrMsgDlg(STDGNALM250);
					return FALSE;
				}

				strData1 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchResult ;
				strData2 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchMessage ;
				strData3 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchErr; 
				nErr = atoi(strData3);
				strData1.MakeUpper();

				if(strcmp(strData1, "PASS") != 0)
				{
					ErrMessage(strData2);
					return FALSE;
				}
			}
		}
		else if(nRMSType == 0)
		{
			strOPCData.Format(_T("%s;%s;%s;;;;;;;;;;"), strGetBasket, strUserID, strProcess);
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 117, reinterpret_cast<LPARAM>(&strOPCData));	//116 ����->TC MES����ó���� ���� �۾��� �Է� ���� ��û : D_000_000100_01
		
			if(!WaitOPCRecvMessage())
			{
#ifndef __TEST__
				ErrMsgDlg(STDGNALM250);
				return FALSE;
#endif
			}
			int nTemp = atoi(strGetStatus.Left(1));

			if(nTemp == 1)
				nStatus = FIRE_PRE;
			if(nTemp == 0)
				nStatus = FIRE_LOT;
			if(nTemp == 2)
				nStatus = FIRE_RE;

			if(nComSol == 2 || nComSol == 3)
			{
				m_strLotInfo = strGetLotID; m_nNo = atoi(strGetCount); m_strPrj1 = strFind1; m_nFireType = nStatus;
				m_strLotInfo2 = strGetLotID; m_nNo2 = m_nNo;  m_strPrj2 = strFind2; m_nFireType2 = nStatus;
			}
			else
			{
				m_strLotInfo = strGetLotID; m_nNo = atoi(strGetCount); m_strPrj1 = strFind1; m_nFireType = nStatus;
			}

			strData1 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchResult ;
			strData2 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchMessage ;
			strData3 = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchErr; 
			nErr = atoi(strData3);
			strData1.MakeUpper();
#ifdef __TEST__
			strData1 = _T("PASS");
#endif
			if(strcmp(strData1, "PASS") != 0)
			{
				ErrMessage(strData2);
				return FALSE;
			}
		
			nComSol =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetAIType();

#ifdef __TEST__
//			m_strPrj1 = _T("AI TEST1");
//			m_strPrj2 = _T("AI TEST2");
#endif
			strcpy(gLotInfo.szBasketID[0], strGetBasket);
			strcpy(gLotInfo.szLotID[0], m_strLotInfo);
			gLotInfo.nLotCount[0] = m_nNo;
			strcpy(gLotInfo.szPrj[0], m_strPrj1);
			gLotInfo.nFireType[0] = m_nFireType;
			strcpy(gLotInfo.szBasketID[0], strLotID1);
			gLotInfo.bMESOK[0] = TRUE;
			if(nComSol == 2 || nComSol == 3)
			{
				strcpy(gLotInfo.szBasketID[1], strGetBasket);
				strcpy(gLotInfo.szLotID[1], m_strLotInfo);
				gLotInfo.nLotCount[1] = m_nNo;
				strcpy(gLotInfo.szPrj[1], m_strPrj2);
				gLotInfo.nFireType[1] = m_nFireType;
				strcpy(gLotInfo.szBasketID[1], strLotID1);
				gLotInfo.bMESOK[1] = TRUE;

				gLotInfo.nComSol[0] = 2;
				gLotInfo.nComSol[1] = 3;

				gLotInfo.nLastIndex += 2;

			}
			else
			{
				gLotInfo.nComSol[0] = nComSol;
				gLotInfo.nLastIndex += 1;
			}
		}

		int nTemp = atoi(strGetStatus.Left(1));

		if(nTemp == 1)
			nStatus = FIRE_PRE;
		if(nTemp == 0)
			nStatus = FIRE_LOT;
		if(nTemp == 2)
			nStatus = FIRE_RE;

		if(nComSol == 2)
		{
			switch(nIndex)
			{
			case 1 : m_strLotInfo = strGetLotID; m_nNo = atoi(strGetCount); m_strPrj1 = strFind1; m_nFireType = nStatus;
				m_strLotInfo2 = strGetLotID; m_nNo2 = m_nNo;  m_strPrj2 = strFind2; m_nFireType2 = nStatus; break;
			case 3 : m_strLotInfo3 = strGetLotID; m_nNo3 = atoi(strGetCount); m_strPrj3 = strFind1; m_nFireType3 = nStatus;
				m_strLotInfo4 = strGetLotID; m_nNo4 = m_nNo3;  m_strPrj4 = strFind2; m_nFireType4 = nStatus; break;
			case 5 : m_strLotInfo5 = strGetLotID; m_nNo5 = atoi(strGetCount); m_strPrj5 = strFind1; m_nFireType5 = nStatus;
				m_strLotInfo6 = strGetLotID; m_nNo6 = m_nNo5;  m_strPrj6 = strFind2; m_nFireType6 = nStatus; break;
			case 7 : m_strLotInfo7 = strGetLotID; m_nNo7 = atoi(strGetCount); m_strPrj7 = strFind1; m_nFireType7 = nStatus;
				m_strLotInfo8 = strGetLotID; m_nNo8 = m_nNo7;  m_strPrj8 = strFind2; m_nFireType8 = nStatus; break;
			case 9 : m_strLotInfo9 = strGetLotID; m_nNo9 = atoi(strGetCount); m_strPrj9 = strFind1; m_nFireType9 = nStatus;
				m_strLotInfo10 = strGetLotID; m_nNo10 = m_nNo9;  m_strPrj10 = strFind2; m_nFireType10 = nStatus; break;
			}
		}
		else
		{
			switch(nIndex)
			{
			case 1 : m_strLotInfo = strGetLotID; m_nNo = atoi(strGetCount); m_strPrj1 = strFind1; m_nFireType = nStatus; break;
			case 2 : m_strLotInfo2 = strGetLotID; m_nNo2 = atoi(strGetCount); m_strPrj2 = strFind1; m_nFireType2 = nStatus;break;
			case 3 : m_strLotInfo3 = strGetLotID; m_nNo3 = atoi(strGetCount); m_strPrj3 = strFind1; m_nFireType3 = nStatus;break;
			case 4 : m_strLotInfo4 = strGetLotID; m_nNo4 = atoi(strGetCount); m_strPrj4 = strFind1; m_nFireType4 = nStatus;break;
			case 5 : m_strLotInfo5 = strGetLotID; m_nNo5 = atoi(strGetCount); m_strPrj5 = strFind1; m_nFireType5 = nStatus;break;
			case 6 : m_strLotInfo6 = strGetLotID; m_nNo6 = atoi(strGetCount); m_strPrj6 = strFind1; m_nFireType6 = nStatus;break;
			case 7 : m_strLotInfo7 = strGetLotID; m_nNo7 = atoi(strGetCount); m_strPrj7 = strFind1; m_nFireType7 = nStatus;break;
			case 8 : m_strLotInfo8 = strGetLotID; m_nNo8 = atoi(strGetCount); m_strPrj8 = strFind1; m_nFireType8 = nStatus; break;
			case 9 : m_strLotInfo9 = strGetLotID; m_nNo9 = atoi(strGetCount); m_strPrj9 = strFind1; m_nFireType9 = nStatus;break;
			case 10 :m_strLotInfo10 = strGetLotID; m_nNo10 = atoi(strGetCount); m_strPrj10 = strFind1; m_nFireType10 = nStatus;break;
			}
		}
		if(!bNoDoMo)
			UpdateData(FALSE);
	
		return TRUE;

	}
	return TRUE;
}

BOOL CDlgScheduleInfo::RMSDataCheck(CString strLotID1, CString&strLotCount, CString& strFilmNo, CString& strProcessCode)
{
/*	CString strRMSData = _T("");
	BOOL bRMSReturn = FALSE;


	strRMSData.Format(_T("%s;;;;;;;;;;"), strLotID1);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 872, reinterpret_cast<LPARAM>(&strRMSData));	//872 ����->TC Wip Check

	bRMSReturn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetRMSReturnData(strLotCount, strFilmNo, strProcessCode);

	if(!bRMSReturn)
		return FALSE;

*/	return TRUE;
} 

void CDlgScheduleInfo::DisplayMES()
{

	int nRMSType = 0; 

#ifdef __NO_USE_OPC__
	GetDlgItem(IDC_BTN_MES)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES7)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES8)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES9)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES10)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL7)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL8)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL9)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_MES_CANCEL10)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO7)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO8)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO9)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_GET_INFO10)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHK_USE_VALIDATION)->ShowWindow(SW_HIDE);
#else
	 nRMSType = 2;
	nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	if(m_bUseMES)
	{
		GetDlgItem(IDC_BTN_MES)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_MES_CANCEL)->ShowWindow(SW_SHOW);
		if(gProcessINI.m_sProcessSystem.bUseScheduling)
		{
		//	GetDlgItem(IDC_BTN_MES2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES3)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES4)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES5)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES6)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES7)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES8)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES9)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES10)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES_CANCEL2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES_CANCEL3)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES_CANCEL4)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES_CANCEL5)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES_CANCEL6)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES_CANCEL7)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES_CANCEL8)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BTN_MES_CANCEL9)->ShowWindow(SW_SHOW);
		//	GetDlgItem(IDC_BTN_MES_CANCEL10)->ShowWindow(SW_SHOW);
		}
	}
	else
	{
		GetDlgItem(IDC_BTN_MES)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES3)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES5)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES7)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES9)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES_CANCEL)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES_CANCEL2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES_CANCEL3)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES_CANCEL4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES_CANCEL5)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES_CANCEL6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES_CANCEL7)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES_CANCEL8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MES_CANCEL9)->ShowWindow(SW_HIDE);
	//	GetDlgItem(IDC_BTN_MES_CANCEL10)->ShowWindow(SW_HIDE);
	}
#endif

	int nLotID = IDC_EDT_LOTINFO2;
	int nNoID = IDC_EDT_NO2;
	int nOpenID = IDC_BTN_OPEN2;
	int nMesID = IDC_BTN_MES2;
	int nCancleID = IDC_BTN_MES_CANCEL2;
	int nCSID = IDC_COMBO_CS2;
	int nPrjID = IDC_EDT_PROJECT;
	//int nRMSType = 0; 
	if(!gProcessINI.m_sProcessSystem.bUseScheduling && nRMSType != 0)
	{
		for(int k = 0; k < 9; k++)
		{
			GetDlgItem(nLotID + k)->EnableWindow(FALSE);
			GetDlgItem(nNoID + k)->EnableWindow(FALSE);
			GetDlgItem(nOpenID + k)->EnableWindow(FALSE);
			GetDlgItem(nMesID + k)->EnableWindow(FALSE);
			GetDlgItem(nCancleID + k)->EnableWindow(FALSE);
			GetDlgItem(nCSID + k)->EnableWindow(FALSE);
		}
		m_strLotInfo2.Format(_T(" "));
		m_strLotInfo3.Format(_T(" "));
		m_strLotInfo4.Format(_T(" "));
		m_strLotInfo5.Format(_T(" "));
		m_strLotInfo6.Format(_T(" "));
		m_strLotInfo7.Format(_T(" "));
		m_strLotInfo8.Format(_T(" "));
		m_strLotInfo9.Format(_T(" "));
		m_strLotInfo10.Format(_T(" "));

		m_strPrj2.Format(_T(""));
		m_strPrj3.Format(_T(""));
		m_strPrj4.Format(_T(""));
		m_strPrj5.Format(_T(""));
		m_strPrj6.Format(_T(""));
		m_strPrj7.Format(_T(""));
		m_strPrj8.Format(_T(""));
		m_strPrj9.Format(_T(""));
		m_strPrj10.Format(_T(""));

		m_nNo2 = 0; 
		m_nNo3 = 0; 
		m_nNo4 = 0; 
		m_nNo5 = 0; 
		m_nNo6 = 0; 
		m_nNo7 = 0; 
		m_nNo8 = 0; 
		m_nNo9 = 0; 
		m_nNo10 = 0; 

		UpdateData(FALSE);
	}
	UINT nSumCount = 0;
	m_nNo = gLotInfo.nLotCount[0];
	nSumCount += m_nNo;
	if((m_nFiredCount >= nSumCount) && nSumCount != 0 && m_nNo != 0) //���� �Էµ� ����ŭ �����߰ų� ����������Ʈ�� �������϶�
	{
		if(m_nFiredCount !=  nSumCount) // �Է¼����� �������� -> ���� ������Ʈ ������
			GetDlgItem(IDC_EDT_NO)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
	}
	else
	{
		// ���� �Ǿ��ų� ���� �Էµ� ������ ���� �������϶�
		if((m_nFiredCount > nSumCount-m_nNo) && m_nNo != 0) //������
		{
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(FALSE);
		}
		if(m_bMes) //���� Ȥ�� ���
		{
			GetDlgItem(IDC_BTN_MES)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(TRUE);
		}
	}

	m_nNo2 = gLotInfo.nLotCount[1];
	nSumCount += m_nNo2;
	if((m_nFiredCount >=  nSumCount) && nSumCount != 0 && m_nNo2 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo2 && m_nNo2 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO2)->EnableWindow(FALSE);
		}
		if(m_bMes2)
		{
			GetDlgItem(IDC_BTN_MES2)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES2)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES2)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES2)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(FALSE);
		}
	}

	m_nNo3 = gLotInfo.nLotCount[2];
	nSumCount += m_nNo3;
	if((m_nFiredCount >=  nSumCount) && nSumCount != 0 && m_nNo3 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES3)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS3)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo3 && m_nNo3 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(FALSE);
		}
		if(m_bMes3)
		{
			GetDlgItem(IDC_BTN_MES3)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM2)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES3)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM2)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(TRUE);
		}
	}

	m_nNo4 = gLotInfo.nLotCount[3];
	nSumCount += m_nNo4;
	if((m_nFiredCount >=  nSumCount)  && nSumCount != 0 && m_nNo4 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo4 && m_nNo4 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO4)->EnableWindow(FALSE);
		}
		if(m_bMes4)
		{
			GetDlgItem(IDC_BTN_MES4)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES4)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES4)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES4)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(FALSE);
		}
	}

	m_nNo5 = gLotInfo.nLotCount[4];
	nSumCount += m_nNo5;
	if((m_nFiredCount >=  nSumCount) && nSumCount != 0 && m_nNo5 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES5)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS5)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo5 && m_nNo5 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(FALSE);
		}
		if(m_bMes5)
		{
			GetDlgItem(IDC_BTN_MES5)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES5)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(TRUE);
		}
	}

	m_nNo6 = gLotInfo.nLotCount[5];
	nSumCount += m_nNo6;
	if((m_nFiredCount >=  nSumCount)  && nSumCount != 0 && m_nNo6 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo6 && m_nNo6 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO6)->EnableWindow(FALSE);
		}
		if(m_bMes6)
		{
			GetDlgItem(IDC_BTN_MES6)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES6)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES6)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES6)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(FALSE);
		}
	}

	m_nNo7 = gLotInfo.nLotCount[6];
	nSumCount += m_nNo7;
	if((m_nFiredCount >=  nSumCount)  && nSumCount != 0 && m_nNo7 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES7)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS7)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo7 && m_nNo7 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(FALSE);
		}
		if(m_bMes7)
		{
			GetDlgItem(IDC_BTN_MES7)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM4)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES7)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM4)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(TRUE);
		}
	}

	m_nNo8 = gLotInfo.nLotCount[7];
	nSumCount += m_nNo8;
	if((m_nFiredCount >=  nSumCount) && nSumCount != 0 && m_nNo8 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo8 && m_nNo8 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO8)->EnableWindow(FALSE);
		}
		if(m_bMes8)
		{
			GetDlgItem(IDC_BTN_MES8)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES8)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES8)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES8)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(FALSE);
		}
	}

	m_nNo9 = gLotInfo.nLotCount[8];
	nSumCount += m_nNo9;
	if((m_nFiredCount >= nSumCount)  && nSumCount != 0 && m_nNo9 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES9)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS9)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo9 && m_nNo9 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(FALSE);
		}
		if(m_bMes9)
		{
			GetDlgItem(IDC_BTN_MES9)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES9)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(TRUE);
		}
	}

	m_nNo10 = gLotInfo.nLotCount[9];
	nSumCount += m_nNo10;
	if((m_nFiredCount >= nSumCount)  && nSumCount != 0 && m_nNo10 != 0)
	{
		if(m_nFiredCount !=  nSumCount)
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDT_LOTINFO10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_CS10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
	}
	else
	{
		if(m_nFiredCount >  nSumCount-m_nNo10 && m_nNo10 != 0)
		{
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO10)->EnableWindow(FALSE);
		}
		if(m_bMes10)
		{
			GetDlgItem(IDC_BTN_MES10)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES10)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES10)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES10)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(FALSE);
		}
	}
	
}

void CDlgScheduleInfo::OnButtonPrjOpen()
{
	UpdateData(TRUE);
	m_strPrj1.Format(_T("%s"), GetProjectFile(m_strLotInfo));
	UpdateData(FALSE);
}

void CDlgScheduleInfo::OnButtonPrjOpen2()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj2.Format(_T("%s"), GetProjectFile(m_strLotInfo));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen3()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj3.Format(_T("%s"), GetProjectFile(m_strLotInfo3));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen4()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj4.Format(_T("%s"), GetProjectFile(m_strLotInfo3));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen5()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj5.Format(_T("%s"), GetProjectFile(m_strLotInfo5));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen6()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj6.Format(_T("%s"), GetProjectFile(m_strLotInfo5));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen7()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj7.Format(_T("%s"), GetProjectFile(m_strLotInfo7));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen8()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj8.Format(_T("%s"), GetProjectFile(m_strLotInfo7));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen9()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj9.Format(_T("%s"), GetProjectFile(m_strLotInfo9));
	UpdateData(FALSE);
}
void CDlgScheduleInfo::OnButtonPrjOpen10()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return;
	UpdateData(TRUE);
	m_strPrj10.Format(_T("%s"), GetProjectFile(m_strLotInfo9));
	UpdateData(FALSE);
}
BOOL CDlgScheduleInfo::InputToolInfo(int nIndex, DProject& mDproject)
{
	//subtool�� �ű�� ��! 
	POSITION pos;
	SUBTOOLDATA subdata;
	
	for(int i = 0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[nIndex][i]->m_SubToolData.RemoveAll();
		m_pToolCode[nIndex][i]->m_bUseTool = mDproject.m_pToolCode[i]->m_bUseTool;	
		pos = mDproject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			subdata = mDproject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
			m_pToolCode[nIndex][i]->m_SubToolData.AddTail(subdata);
		}

	}
	if(nIndex != 0)
		return CompareTool(nIndex);
	else
		return TRUE;
}

BOOL CDlgScheduleInfo::CompareTool(int nPrjIndex)
{
	int nCompareindex = nPrjIndex -1;
	BOOL bSame = TRUE;
	SUBTOOLDATA subData1, subData2;
	POSITION Pos1, Pos2;

	for(int i = 0; i< MAX_TOOL_NO; i++)
	{
		if(!m_pToolCode[nCompareindex][i]->m_bUseTool && !m_pToolCode[nPrjIndex][i]->m_bUseTool)
			continue;
		else if(m_pToolCode[nCompareindex][i]->m_bUseTool && m_pToolCode[nPrjIndex][i]->m_bUseTool)
		{
			int nPrevCount = m_pToolCode[nCompareindex][i]->m_SubToolData.GetCount();
			int nCurrentCount = m_pToolCode[nPrjIndex][i]->m_SubToolData.GetCount();

			//subtool ������ �������� ������� 
			if(nPrevCount != nCurrentCount)
			{
				m_nDiffTool = nPrjIndex;
				return FALSE;
			}
			else
			{
				Pos1 = m_pToolCode[nCompareindex][i]->m_SubToolData.GetHeadPosition();
				Pos2 = m_pToolCode[nPrjIndex][i]->m_SubToolData.GetHeadPosition();
				
				while(Pos1 && Pos2)
				{
					subData1 = m_pToolCode[nCompareindex][i]->m_SubToolData.GetNext(Pos1);
					subData2 = m_pToolCode[nPrjIndex][i]->m_SubToolData.GetNext(Pos2);

					if(!IsSameSubTool(subData1, subData2))
					{
						m_nDiffTool = nPrjIndex;
						bSame &= FALSE;
					}
					else
						bSame &= TRUE;	
				}				
			}
		}
		else 
		{
			m_nDiffTool = nPrjIndex;
			return FALSE;
		}
	}
	return bSame;
}


BOOL CDlgScheduleInfo::OpenPrj()
{
	
	DProject myDProject;
	CString str;
	int k = 0;
	for(int i = 9; i >= 0; i--)
	{
		switch(i)
		{
		case 0 :
			str = m_strPrj1; break;
		case 1 : 
			str = m_strPrj2; break;
		case 2 :
			str = m_strPrj3; break;
		case 3 :
			str = m_strPrj4; break;
		case 4 :
			str = m_strPrj5; break;
		case 5 :
			str = m_strPrj6; break;
		case 6 :
			str = m_strPrj7; break;
		case 7 :
			str = m_strPrj8; break;
		case 8 :
			str = m_strPrj9; break;
		case 9 :
			str = m_strPrj10; break;
		}

		if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		{
			if(i != 0)
				continue;
		}

		if(str.GetLength() < 1)
			continue;
		
		TRY
		{
			CStdioFile file;
			if (FALSE == file.Open(str, CFile::modeRead))
			{
				return FALSE;
			}
			
			if (file.GetLength() < 1)
			{
				return FALSE;
			}
			
			CArchiveMark ar(&file, CArchive::load);
			BOOL bRes = myDProject.Serialize(ar, 10000);	
			file.Close();
			
			if(!bRes)
				return FALSE;
		}
		CATCH (CException, e)
		{
			e->Delete();
			return FALSE;
		}
		END_CATCH

		if(!InputToolInfo(k, myDProject))
		{
			return FALSE;	
		}
		k++;
	}
	return TRUE;
}

BOOL CDlgScheduleInfo::IsSameSubTool(SUBTOOLDATA subTool1, SUBTOOLDATA subTool2)
{
	if(subTool1.nToolType != subTool2.nToolType)
		return FALSE;

	if(subTool1.nToolType == SHOT_DRILL_TYPE)
	{
		if(subTool1.nDrawStepPeriod != subTool2.nDrawStepPeriod)
			return FALSE;
		if(subTool1.nJumpStepPeriod != subTool2.nJumpStepPeriod)
			return FALSE;

		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(subTool1.dCurrent != subTool2.dCurrent)
				return FALSE;
			if(subTool1.nThermalTrack != subTool2.nThermalTrack)
				return FALSE;
			if(subTool1.dA1 != subTool2.dA1 || subTool1.dA2 != subTool2.dA2)
				return FALSE;
		}
		else
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				if(subTool1.dCurrent != subTool2.dCurrent)
					return FALSE;
			}

			if(subTool1.nMask != subTool2.nMask)
				return FALSE;
			if(subTool1.nFrequency != subTool2.nFrequency)
				return FALSE;

			if(subTool1.nTotalShot != subTool2.nTotalShot)
				return FALSE;
		}

		if(subTool1.nApertureBurst != subTool2.nApertureBurst)
			return FALSE;
		if(subTool1.dZOffset != subTool2.dZOffset)
			return FALSE;
	}
	else if(subTool1.nToolType == LINE_DRILL_TYPE || subTool1.nToolType == BARCODE_TYPE || subTool1.nToolType == MARKING_TYPE)
	{
		if(subTool1.nJumpStep != subTool2.nJumpStep)
			return FALSE;
		if(subTool1.nDrawStepPeriod != subTool2.nDrawStepPeriod)
			return FALSE;
		if(subTool1.nJumpStepPeriod != subTool2.nJumpStepPeriod)
			return FALSE;
		if(subTool1.nJumpDelay != subTool2.nJumpDelay)
			return FALSE;
		if(subTool1.nLineDelay != subTool2.nLineDelay)
			return FALSE;
		if(subTool1.nLaserOnDelay != subTool2.nLaserOnDelay)
			return FALSE;
		if(subTool1.nLaserOffDelay != subTool2.nLaserOffDelay)
			return FALSE;
		if(subTool1.nFrequency != subTool2.nFrequency)
			return FALSE;

		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(subTool1.dCurrent != subTool2.dCurrent)
				return FALSE;
			if(subTool1.nThermalTrack != subTool2.nThermalTrack)
				return FALSE;
			if(subTool1.dA1 != subTool2.dA1 || subTool1.dA2 != subTool2.dA2)
				return FALSE;
		}
		else
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				if(subTool1.dCurrent != subTool2.dCurrent)
					return FALSE;
			}

			if(subTool1.nMask != subTool2.nMask)
				return FALSE;
		}

		CString str1, str2;

		for(int i=0; i < subTool1.nTotalShot; i++)
		{
			if(subTool1.dShotDuty[i] != subTool2.dShotDuty[i])
				return FALSE;
			if(subTool1.dShotAOMDelay[i] != subTool2.dShotAOMDelay[i])
				return FALSE;
			if(subTool1.dShotAOMDuty[i] != subTool2.dShotAOMDuty[i])
				return FALSE;
			str1.Format(_T("%s"), subTool1.cAOMFilePath[i]);
			str2.Format(_T("%s"), subTool2.cAOMFilePath[i]);
			if(0 != str1.CompareNoCase(str2))
				return FALSE;
		}

		if(subTool1.bUseAperture != subTool2.bUseAperture)
			return FALSE;

		if(subTool1.dZOffset != subTool2.dZOffset)
			return FALSE;

		str1.Format(_T("%s"), subTool1.cFilePath);
		str2.Format(_T("%s"), subTool2.cFilePath);
		if(str1.CompareNoCase(str2)) // 
			return FALSE;
		
		if(subTool1.nToolType == BARCODE_TYPE)
		{
			if(subTool1.bFlipX != subTool2.bFlipX)
				return FALSE;
			if(subTool1.bFlipY != subTool2.bFlipY)
				return FALSE;
			if(subTool1.nRotate != subTool2.nRotate)
				return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}
void CDlgScheduleInfo::SetOnlyDisplay(BOOL bOnly)
{
	m_bOnlyDisplay = bOnly;
}
void CDlgScheduleInfo::EnableControl(BOOL bEnable, BOOL bOnlyDisplay)
{

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_CHK_USE_VALIDATION)->EnableWindow(bEnable);


	GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_EDT_NO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO2)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT2)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_BTN_MES)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_COMBO_CS)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS2)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_DELETE)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO4)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO3)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO4)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT3)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS3)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS4)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM2)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO6)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO5)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO6)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT5)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS5)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS6)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM3)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(bEnable);


	GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO8)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO7)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO8)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT7)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS7)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS8)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM4)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO10)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO9)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO10)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT9)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS9)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS10)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM5)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(bEnable);
}

void CDlgScheduleInfo::EnableControlForMES(BOOL bEnable, BOOL bOnlyDisplay)
{

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_CHK_USE_VALIDATION)->EnableWindow(bEnable);


	GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_EDT_NO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO2)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT2)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_BTN_MES)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL2)->EnableWindow(bEnable);

	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		GetDlgItem(IDC_COMBO_CS)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS2)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(bEnable);

//	GetDlgItem(IDC_BTN_DELETE)->EnableWindow(bEnable);

	if(m_nLastIndex < 1)
		bEnable = FALSE;

	GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO4)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO3)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO4)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT3)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES4)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL4)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS3)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS4)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM2)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(bEnable);

//	GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(bEnable);

	if(m_nLastIndex < 3)
		bEnable = FALSE;


	GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO6)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO5)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO6)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT5)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES6)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL6)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS5)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS6)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM3)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(bEnable);

//	GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(bEnable);

	if(m_nLastIndex < 5)
		bEnable = FALSE;


	GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO8)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO7)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO8)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT7)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES8)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL8)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS7)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS8)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM4)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(bEnable);

//	GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(bEnable);
	
	if(m_nLastIndex < 7)
		bEnable = FALSE;

	GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_LOTINFO10)->EnableWindow(bEnable);

	GetDlgItem(IDC_EDT_NO9)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDT_NO10)->EnableWindow(bEnable);

//	GetDlgItem(IDC_EDT_PROJECT9)->EnableWindow(bEnable);
//	GetDlgItem(IDC_EDT_PROJECT10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES10)->EnableWindow(bEnable);

	GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_MES_CANCEL10)->EnableWindow(bEnable);

	GetDlgItem(IDC_COMBO_CS9)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CS10)->EnableWindow(bEnable);

	GetDlgItem(IDC_RADIO_COM5)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(bEnable);

//	GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(bEnable);

#ifndef __NO_USE_OPC__
	
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	if(bOnlyDisplay == FALSE && nRMSType != 2)
	{
		if(m_bMes == TRUE || m_bMes2 == TRUE)
		{
			GetDlgItem(IDC_BTN_MES)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN2)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(TRUE);
		}
	}
	if(bOnlyDisplay == FALSE && nRMSType != 2 && m_nLastIndex >= 2)
	{
		if(m_bMes3 == TRUE || m_bMes4 == TRUE)
		{
			GetDlgItem(IDC_BTN_MES3)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM2)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES3)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL3)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM2)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL2)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH2)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN4)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE2)->EnableWindow(TRUE);
		}
	}
	if(bOnlyDisplay == FALSE && nRMSType != 2 && m_nLastIndex >= 4)
	{
		if(m_bMes5 == TRUE || m_bMes6 == TRUE)
		{
			GetDlgItem(IDC_BTN_MES5)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES5)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL5)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL3)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH3)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN6)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE3)->EnableWindow(TRUE);
		}
	}
	if(bOnlyDisplay == FALSE && nRMSType != 2 && m_nLastIndex >= 6)
	{
		if(m_bMes7 == TRUE || m_bMes8 == TRUE)
		{
			GetDlgItem(IDC_BTN_MES7)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM4)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES7)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL7)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO7)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM4)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL4)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH4)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN8)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO7)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE4)->EnableWindow(TRUE);
		}
	}
	if(bOnlyDisplay == FALSE && nRMSType != 2 && m_nLastIndex >= 8)
	{
		if(m_bMes9 == TRUE || m_bMes10 == TRUE)
		{
			GetDlgItem(IDC_BTN_MES9)->SetWindowText("OK");
			GetDlgItem(IDC_BTN_MES9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_COM5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_BTN_MES9)->SetWindowText("MES");
			GetDlgItem(IDC_BTN_MES9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_MES_CANCEL9)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_LOTINFO9)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_COM5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_SOL5)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_BOTH5)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_OPEN10)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDT_NO9)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_DELETE5)->EnableWindow(TRUE);
		}
	}
#endif
}
CString CDlgScheduleInfo::GetProjectFile(CString strLot)
{
	CString strReturn;
	strReturn.Format(_T(""));

	CString strManage, strCurrent;
	if(strlen(strLot) < 1)
	{
		ErrMessage(_T("Not yet input LotNumber"));
		return strReturn;
	}

	if(gSystemINI.m_sHardWare.nUseBarcodeReader != 1)
	{
		TCHAR BASED_CODE szFilter[] = _T("Project Files (*.prj)|*.prj|All Files (*.*)|*.*||");
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
		CFileDialog dlg(TRUE, _T("*.prj"), NULL, dwFlags, szFilter);
		dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
		if(IDOK == dlg.DoModal())
		{
			strReturn = dlg.GetPathName();
			return strReturn;
		}
		else
			return strReturn;
	}
	
	TCHAR pManager[256]={0,};
	TCHAR pCurrnet[256]={0,};
	CBarcodeOdbc Odbc;
	if(!Odbc.GetManageNo((LPSTR)(LPCTSTR)strLot,pManager, pCurrnet))
	{
		ErrMessage(_T("Can not open DB."));
		return strReturn;
	}
	strManage.Format(_T("%s"), pManager);
	
	if(strlen(strManage) <1)
	{
#ifdef __TEST__
		double dMax;
		int nValue;
		dMax = 2.0 * rand() / static_cast<double>(RAND_MAX);
		nValue = (int)((fabs(dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX))) * 10000.0);
		if(nValue % 3 == 2)
			strManage = _T("215-746-20");
		else if(nValue % 3 == 1)
			strManage = _T("212-746-20");
		else
			strManage = _T("209-746-20");
#else
		ErrMessage(_T("There was not as Management Number in DB"));
		return strReturn;
#endif
	}
	strCurrent.Format(_T("%s"), pCurrnet);
	strCurrent = strCurrent.Right(2);

	int nIndex = strManage.Find(_T('-'));
	if(nIndex == -1)
	{
		ErrMessage(_T("Format of Managetment Number is wrong\r\n( Format : XXX-XX... )"));
		return strReturn;
	}
	CString strManage_Del;
	CString strTemp = strManage.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	strManage_Del = strManage.Left(1) + strTemp;
	
	CString strTemp2= strManage.Mid(nIndex+1);
	
	while(TRUE)
	{
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			strManage_Del += strTemp2;
			break;
		}
		strManage_Del += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
	}

	CString strFilter, strFilter2;
	int nLength = strLot.GetLength();
	int nLength2 = strManage.GetLength();

	if(nLength == 9 && nLength2 > 0) // ����1�ڸ�+����8�ڸ� ����
	{
		strFilter.Format(_T("Outer Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.txt;%s*.txt;||")
			, strManage_Del+"_A", strManage_Del+"_1", strManage_Del+"_A", strManage_Del+"_1");
		strFilter2.Format(_T("Outer Layer ProjectFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), strManage_Del+"A", strManage_Del+"1"
			, strManage_Del+"_A", strManage_Del+"_1");
	}
	else if(nLength == 11 && nLength2 > 0) // ����1�ڸ�+����10�ڸ� ����
	{
		if(strcmp(strCurrent, "L1") == 0)
		{
			strFilter.Format(_T("Innder Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				strManage_Del+"C", strManage_Del+"3", strManage_Del+"C", strManage_Del+"3",
				strManage_Del+"_C", strManage_Del+"_3", strManage_Del+"_C", strManage_Del+"_3");
			strFilter2.Format(_T("Innder Layer ProjectFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				strManage_Del+"C", strManage_Del+"3",
				strManage_Del+"_C", strManage_Del+"_3");
		}
		else if(strcmp(strCurrent, "L2") == 0)
		{
			strFilter.Format(_T("Inner Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				strManage_Del+"5",  
				strManage_Del+"E", 
				strManage_Del+"5", 
				strManage_Del+"E",
				strManage_Del+"_5",  
				strManage_Del+"_E", 
				strManage_Del+"_5", 
				strManage_Del+"_E");
			strFilter2.Format(_T("Inner Layer ProjectFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				strManage_Del+"5",  
				strManage_Del+"E",
				strManage_Del+"_5",  
				strManage_Del+"_E");
		}
		else if(strcmp(strCurrent, "L3") == 0)
		{
			strFilter.Format(_T("Inner Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				strManage_Del+"7",  
				strManage_Del+"G", 
				strManage_Del+"7", 
				strManage_Del+"G",
				strManage_Del+"_7",  
				strManage_Del+"_G", 
				strManage_Del+"_7", 
				strManage_Del+"_G");
			strFilter2.Format(_T("Inner Layer ProjectFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				strManage_Del+"7",  
				strManage_Del+"G",
				strManage_Del+"_7",  
				strManage_Del+"_G");
		}
		else if(strcmp(strCurrent, "L4") == 0)
		{
			strFilter.Format(_T("Inner Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				strManage_Del+"9",  
				strManage_Del+"I", 
				strManage_Del+"9", 
				strManage_Del+"I",
				strManage_Del+"_9",  
				strManage_Del+"_I", 
				strManage_Del+"_9", 
				strManage_Del+"_I");
			strFilter2.Format(_T("Inner Layer ProjectFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				strManage_Del+"9",  
				strManage_Del+"I",
				strManage_Del+"_9",  
				strManage_Del+"_I");
		}
		else
		{
			strFilter.Format(_T("Inner Layer DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;||"), 
				strManage_Del+"C", strManage_Del+"E", strManage_Del+"G", strManage_Del+"I", 
				strManage_Del+"3", strManage_Del+"5", strManage_Del+"7", strManage_Del+"9", 
				strManage_Del+"C", strManage_Del+"E", strManage_Del+"G", strManage_Del+"I", 
				strManage_Del+"3", strManage_Del+"5", strManage_Del+"7", strManage_Del+"9",
				strManage_Del+"_C", strManage_Del+"_E", strManage_Del+"_G", strManage_Del+"_I", 
				strManage_Del+"_3", strManage_Del+"_5", strManage_Del+"_7", strManage_Del+"_9", 
				strManage_Del+"_C", strManage_Del+"_E", strManage_Del+"_G", strManage_Del+"_I", 
				strManage_Del+"_3", strManage_Del+"_5", strManage_Del+"_7", strManage_Del+"_9");
			strFilter2.Format(_T("Inner Layer DataFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				strManage_Del+"C", strManage_Del+"E", strManage_Del+"G", strManage_Del+"I", 
				strManage_Del+"3", strManage_Del+"5", strManage_Del+"7", strManage_Del+"9",
				strManage_Del+"_C", strManage_Del+"_E", strManage_Del+"_G", strManage_Del+"_I", 
				strManage_Del+"_3", strManage_Del+"_5", strManage_Del+"_7", strManage_Del+"_9");
		}
		
	}
	else
		strFilter.Format(_T("There is no file |NoFile.NoNo||"));

	CString strSavedDir;
	CString strDirectory;
	CString strOpenDir;

	CFileDialogEX filedlg(TRUE, "prj", NULL, OFN_HIDEREADONLY, strFilter2);
	strSavedDir = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
	strDirectory = _T("");
	strOpenDir = strSavedDir.Left(strSavedDir.ReverseFind(_T('\\')));
	strDirectory.Format(strOpenDir + _T('\\'));

	filedlg.m_ofn.lpstrInitialDir = (LPCTSTR)strDirectory;
	
	if (IDOK == filedlg.DoModal())
	{
		strReturn = filedlg.GetPathName();
		return strReturn;
	}
	else
		return strReturn;
}
BOOL CDlgScheduleInfo::WaitOPCRecvMessage()
{

#ifdef __NO_USE_OPC__
	return TRUE;
#endif
	if( ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc == NULL)
		return TRUE;

	int nWaitTime = gProcessINI.m_sProcessOption.nOPCTimeOut * 100; // sec 
	if(m_dlgOPCWait.m_hWnd == NULL)
	{
		m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
		m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
	}

	m_dlgOPCWait.ShowWindow(SW_SHOW);
	m_dlgOPCWait.StartMeasurement(nWaitTime);

	BOOL bRecv = FALSE;
	int nCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
	do
	{
		if(nCount > nWaitTime) //���Ƿ� 5��
		{
			m_dlgOPCWait.ShowWindow(SW_HIDE);
			return FALSE;
		}
		bRecv =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv;
		Sleep(10);
		nCount++;
		MessageLoop();
		m_dlgOPCWait.UpdateMeasurement(nCount);
	}while(!bRecv);
	if(bRecv)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv = FALSE;
	}
	m_dlgOPCWait.ShowWindow(SW_HIDE);
	return TRUE;
}
void CDlgScheduleInfo::ResetOPCRecvMessage()
{
#ifndef __NO_USE_OPC__
	 ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
#endif
}

void CDlgScheduleInfo::SetCurrentFiredCount(int nCount)
{
	m_nFiredCount = nCount;
}

void CDlgScheduleInfo::MessageLoop()
{
	MSG msg;

	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG )&msg);
	}
}
void CDlgScheduleInfo::OnBnClickedBtnDelete()
{
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(!((m_nStatus == 0 && m_nStatus2 == 0) || (m_nStatus == 2 && m_nStatus2 == 2)))
		{
			ErrMessage(_T("Delete on only both \"Wait\" or \"End\" status"));
			return;
		}
	}
	else
	{
		if(m_nStatus == 1)
		{
			ErrMessage(_T("Do not Delete \"Progress\" status"));
			return;
		}
	}
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	m_nNo = m_nNo3;
	m_strPrj1 = m_strPrj3;
	m_strLotInfo = m_strLotInfo3;
	m_bMes = m_bMes3;
	m_nComSol = m_nComSol3;
	m_cmbCS.SetCurSel(m_cmbCS3.GetCurSel());
	if(m_nComSol == 0)
	{
		OnBnClickedRadioCom();
	}
	else if(m_nComSol == 1)
	{
		OnBnClickedRadioSol();
	}
	else
	{
		OnBnClickedRadioBoth();
	}

	m_nNo2 = m_nNo4;
	m_strPrj2 = m_strPrj4;
	m_strLotInfo2 = m_strLotInfo4;
	m_bMes2 = m_bMes4;
	m_nComSol2 = m_nComSol4;
	m_cmbCS2.SetCurSel(m_cmbCS4.GetCurSel());
	if(m_nComSol2 == 0)
	{
		OnBnClickedRadioCom();
	}
	else if(m_nComSol2 == 1)
	{
		OnBnClickedRadioSol();
	}
	else
	{
		OnBnClickedRadioBoth();
	}

	m_nNo3 = m_nNo5;
	m_strPrj3 = m_strPrj5;
	m_strLotInfo3 = m_strLotInfo5;
	m_bMes3 = m_bMes5;
	m_nComSol3 = m_nComSol5;
	m_cmbCS3.SetCurSel(m_cmbCS5.GetCurSel());
	if(m_nComSol3 == 0)
	{
		OnBnClickedRadioCom2();
	}
	else if(m_nComSol3 == 1)
	{
		OnBnClickedRadioSol2();
	}
	else
	{
		OnBnClickedRadioBoth2();
	}
	
	m_nNo4 = m_nNo6;
	m_strPrj4 = m_strPrj6;
	m_strLotInfo4 = m_strLotInfo6;
	m_bMes4 = m_bMes6;
	m_nComSol4 = m_nComSol6;
	m_cmbCS4.SetCurSel(m_cmbCS6.GetCurSel());
	if(m_nComSol4 == 0)
	{
		OnBnClickedRadioCom2();
	}
	else if(m_nComSol4 == 1)
	{
		OnBnClickedRadioSol2();
	}
	else
	{
		OnBnClickedRadioBoth2();
	}

	m_nNo5 = m_nNo7;
	m_strPrj5 = m_strPrj7;
	m_strLotInfo5 = m_strLotInfo7;
	m_bMes5 = m_bMes7;
	m_nComSol5 = m_nComSol7;
	m_cmbCS5.SetCurSel(m_cmbCS7.GetCurSel());
	if(m_nComSol5 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol5 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo6 = m_nNo8;
	m_strPrj6 = m_strPrj8;
	m_strLotInfo6 = m_strLotInfo8;
	m_bMes6 = m_bMes8;
	m_nComSol6 = m_nComSol8;
	m_cmbCS6.SetCurSel(m_cmbCS8.GetCurSel());
	if(m_nComSol6 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol6 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo7 = m_nNo9;
	m_strPrj7 = m_strPrj9;
	m_strLotInfo7 = m_strLotInfo9;
	m_bMes7 = m_bMes9;
	m_nComSol7 = m_nComSol9;
	m_cmbCS7.SetCurSel(m_cmbCS9.GetCurSel());
	if(m_nComSol7 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol7 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo8 = m_nNo10;
	m_strPrj8 = m_strPrj10;
	m_strLotInfo8 = m_strLotInfo10;
	m_bMes8 = m_bMes10;
	m_nComSol8 = m_nComSol10;
	m_cmbCS8.SetCurSel(m_cmbCS10.GetCurSel());
	if(m_nComSol8 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol8 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo9 = 0;
	m_strPrj9 = _T("");
	m_strLotInfo9 = _T("");
	m_bMes9 = FALSE;
	m_nComSol9 = 2;
	m_cmbCS9.SetCurSel(2);
	if(m_nComSol9 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol9 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	m_nNo10 = 0;
	m_strPrj10 = _T("");
	m_strLotInfo10 = _T("");
	m_bMes10 = FALSE;
	m_nComSol10 = 3;
	m_cmbCS10.SetCurSel(2);
	if(m_nComSol10 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol10 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	UpdateData(FALSE);
	SaveLotInfo();
	if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else
		EnableControl(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
//	DisplayMES();
}


void CDlgScheduleInfo::OnBnClickedBtnDelete2()
{
	if(!((m_nStatus3 == 0 && m_nStatus4 == 0) || (m_nStatus3 == 2 && m_nStatus4 == 2)))
	{
			ErrMessage(_T("Delete on only both \"Wait\" or \"End\" status"));
		return;
	}
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	m_nNo3 = m_nNo5;
	m_strPrj3 = m_strPrj5;
	m_strLotInfo3 = m_strLotInfo5;
	m_bMes3 = m_bMes5;
	m_nComSol3 = m_nComSol5;
	m_cmbCS3.SetCurSel(m_cmbCS5.GetCurSel());
	if(m_nComSol3 == 0)
	{
		OnBnClickedRadioCom2();
	}
	else if(m_nComSol3 == 1)
	{
		OnBnClickedRadioSol2();
	}
	else
	{
		OnBnClickedRadioBoth2();
	}
	
	m_nNo4 = m_nNo6;
	m_strPrj4 = m_strPrj6;
	m_strLotInfo4 = m_strLotInfo6;
	m_bMes4 = m_bMes6;
	m_nComSol4 = m_nComSol6;
	m_cmbCS4.SetCurSel(m_cmbCS6.GetCurSel());
	if(m_nComSol4 == 0)
	{
		OnBnClickedRadioCom2();
	}
	else if(m_nComSol4 == 1)
	{
		OnBnClickedRadioSol2();
	}
	else
	{
		OnBnClickedRadioBoth2();
	}

	m_nNo5 = m_nNo7;
	m_strPrj5 = m_strPrj7;
	m_strLotInfo5 = m_strLotInfo7;
	m_bMes5 = m_bMes7;
	m_nComSol5 = m_nComSol7;
	m_cmbCS5.SetCurSel(m_cmbCS7.GetCurSel());
	if(m_nComSol5 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol5 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo6 = m_nNo8;
	m_strPrj6 = m_strPrj8;
	m_strLotInfo6 = m_strLotInfo8;
	m_bMes6 = m_bMes8;
	m_nComSol6 = m_nComSol8;
	m_cmbCS6.SetCurSel(m_cmbCS8.GetCurSel());
	if(m_nComSol6 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol6 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo7 = m_nNo9;
	m_strPrj7 = m_strPrj9;
	m_strLotInfo7 = m_strLotInfo9;
	m_bMes7 = m_bMes9;
	m_nComSol7 = m_nComSol9;
	m_cmbCS7.SetCurSel(m_cmbCS9.GetCurSel());
	if(m_nComSol7 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol7 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo8 = m_nNo10;
	m_strPrj8 = m_strPrj10;
	m_strLotInfo8 = m_strLotInfo10;
	m_bMes8 = m_bMes10;
	m_nComSol8 = m_nComSol10;
	m_cmbCS8.SetCurSel(m_cmbCS10.GetCurSel());
	if(m_nComSol8 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol8 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo9 = 0;
	m_strPrj9 = _T("");
	m_strLotInfo9 = _T("");
	m_bMes9 = FALSE;
	m_nComSol9 = 2;
	m_cmbCS9.SetCurSel(2);
	if(m_nComSol9 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol9 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	m_nNo10 = 0;
	m_strPrj10 = _T("");
	m_strLotInfo10 = _T("");
	m_bMes10 = FALSE;
	m_nComSol10 = 3;
	m_cmbCS10.SetCurSel(2);
	if(m_nComSol10 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol10 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	UpdateData(FALSE);
	SaveLotInfo();
	if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else
		EnableControl(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
//	DisplayMES();
}


void CDlgScheduleInfo::OnBnClickedBtnDelete3()
{
	if(!((m_nStatus5 == 0 && m_nStatus6 == 0) || (m_nStatus5 == 2 && m_nStatus6 == 2)))
	{
		ErrMessage(_T("Delete on only both \"Wait\" or \"End\" status"));
		return;
	}
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	
	m_nNo5 = m_nNo7;
	m_strPrj5 = m_strPrj7;
	m_strLotInfo5 = m_strLotInfo7;
	m_bMes5 = m_bMes7;
	m_nComSol5 = m_nComSol7;
	m_cmbCS5.SetCurSel(m_cmbCS7.GetCurSel());
	if(m_nComSol5 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol5 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo6 = m_nNo8;
	m_strPrj6 = m_strPrj8;
	m_strLotInfo6 = m_strLotInfo8;
	m_bMes6 = m_bMes8;
	m_nComSol6 = m_nComSol8;
	m_cmbCS6.SetCurSel(m_cmbCS8.GetCurSel());
	if(m_nComSol6 == 0)
	{
		OnBnClickedRadioCom3();
	}
	else if(m_nComSol6 == 1)
	{
		OnBnClickedRadioSol3();
	}
	else
	{
		OnBnClickedRadioBoth3();
	}

	m_nNo7 = m_nNo9;
	m_strPrj7 = m_strPrj9;
	m_strLotInfo7 = m_strLotInfo9;
	m_bMes7 = m_bMes9;
	m_nComSol7 = m_nComSol9;
	m_cmbCS7.SetCurSel(m_cmbCS9.GetCurSel());
	if(m_nComSol7 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol7 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo8 = m_nNo10;
	m_strPrj8 = m_strPrj10;
	m_strLotInfo8 = m_strLotInfo10;
	m_bMes8 = m_bMes10;
	m_nComSol8 = m_nComSol10;
	m_cmbCS8.SetCurSel(m_cmbCS10.GetCurSel());
	if(m_nComSol8 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol8 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo9 = 0;
	m_strPrj9 = _T("");
	m_strLotInfo9 = _T("");
	m_bMes9 = FALSE;
	m_nComSol9 = 2;
	m_cmbCS9.SetCurSel(2);
	if(m_nComSol9 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol9 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	m_nNo10 = 0;
	m_strPrj10 = _T("");
	m_strLotInfo10 = _T("");
	m_bMes10 = FALSE;
	m_nComSol10 = 3;
	m_cmbCS10.SetCurSel(2);
	if(m_nComSol10 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol10 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	UpdateData(FALSE);
	SaveLotInfo();
	if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else
		EnableControl(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
//	DisplayMES();
}


void CDlgScheduleInfo::OnBnClickedBtnDelete4()
{
	if(!((m_nStatus7 == 0 && m_nStatus8 == 0) || (m_nStatus7 == 2 && m_nStatus8 == 2)))
	{
		ErrMessage(_T("Delete on only both \"Wait\" or \"End\" status"));
		return;
	}
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	m_nNo7 = m_nNo9;
	m_strPrj7 = m_strPrj9;
	m_strLotInfo7 = m_strLotInfo9;
	m_bMes7 = m_bMes9;
	m_nComSol7 = m_nComSol9;
	m_cmbCS7.SetCurSel(m_cmbCS9.GetCurSel());
	if(m_nComSol7 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol7 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo8 = m_nNo10;
	m_strPrj8 = m_strPrj10;
	m_strLotInfo8 = m_strLotInfo10;
	m_bMes8 = m_bMes10;
	m_nComSol8 = m_nComSol10;
	m_cmbCS8.SetCurSel(m_cmbCS10.GetCurSel());
	if(m_nComSol8 == 0)
	{
		OnBnClickedRadioCom4();
	}
	else if(m_nComSol8 == 1)
	{
		OnBnClickedRadioSol4();
	}
	else
	{
		OnBnClickedRadioBoth4();
	}

	m_nNo9 = 0;
	m_strPrj9 = _T("");
	m_strLotInfo9 = _T("");
	m_bMes9 = FALSE;
	m_nComSol9 = 2;
	m_cmbCS9.SetCurSel(2);
	if(m_nComSol9 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol9 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	m_nNo10 = 0;
	m_strPrj10 = _T("");
	m_strLotInfo10 = _T("");
	m_bMes10 = FALSE;
	m_nComSol10 = 3;
	m_cmbCS10.SetCurSel(2);
	if(m_nComSol10 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol10 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	UpdateData(FALSE);
	SaveLotInfo();
	if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else
		EnableControl(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
//	DisplayMES();
}


void CDlgScheduleInfo::OnBnClickedBtnDelete5()
{
	if(!((m_nStatus9 == 0 && m_nStatus10 == 0) || (m_nStatus9 == 2 && m_nStatus10 == 2)))
	{
		ErrMessage(_T("Delete on only both \"Wait\" or \"End\" status"));
		return;
	}
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	m_nNo9 = 0;
	m_strPrj9 = _T("");
	m_strLotInfo9 = _T("");
	m_bMes9 = FALSE;
	m_nComSol9 = 2;
	m_cmbCS9.SetCurSel(2);
	if(m_nComSol9 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol9 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	m_nNo10 = 0;
	m_strPrj10 = _T("");   
	m_strLotInfo10 = _T("");
	m_bMes10 = FALSE;
	m_nComSol10 = 3;
	m_cmbCS10.SetCurSel(2);
	if(m_nComSol10 == 0)
	{
		OnBnClickedRadioCom5();
	}
	else if(m_nComSol10 == 1)
	{
		OnBnClickedRadioSol5();
	}
	else
	{
		OnBnClickedRadioBoth5();
	}

	UpdateData(FALSE);
	SaveLotInfo();
	if(nRMSType != 2)
		EnableControlForMES(TRUE);
	else
		EnableControl(TRUE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
//	DisplayMES();
}


BOOL CDlgScheduleInfo::DestroyWindow()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	
	return CDialog::DestroyWindow();
}


void CDlgScheduleInfo::OnBnClickedRadioCom()
{
	m_nComSol = 0;
	m_nComSol2 = 0;
	GetDlgItem(IDC_EDT_PROJECT2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN2)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioSol()
{
	m_nComSol = 1;
	m_nComSol2 = 1;
	GetDlgItem(IDC_EDT_PROJECT2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN2)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioBoth()
{
	m_nComSol = 2;
	m_nComSol2 = 3;
	GetDlgItem(IDC_EDT_PROJECT2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BTN_OPEN2)->ShowWindow(SW_SHOW);
}


void CDlgScheduleInfo::OnBnClickedRadioCom2()
{
	m_nComSol3 = 0;
	m_nComSol4 = 0;
	GetDlgItem(IDC_EDT_PROJECT4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN4)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioSol2()
{
	m_nComSol3 = 1;
	m_nComSol4 = 1;
	GetDlgItem(IDC_EDT_PROJECT4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN4)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioBoth2()
{
	m_nComSol3 = 2;
	m_nComSol4 = 3;
	GetDlgItem(IDC_EDT_PROJECT4)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BTN_OPEN4)->ShowWindow(SW_SHOW);
}


void CDlgScheduleInfo::OnBnClickedRadioCom3()
{
	m_nComSol5 = 0;
	m_nComSol6 = 0;
	GetDlgItem(IDC_EDT_PROJECT6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN6)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioSol3()
{
	m_nComSol5 = 1;
	m_nComSol6 = 1;
	GetDlgItem(IDC_EDT_PROJECT6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN6)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioBoth3()
{
	m_nComSol5 = 2;
	m_nComSol6 = 3;
	GetDlgItem(IDC_EDT_PROJECT6)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BTN_OPEN6)->ShowWindow(SW_SHOW);
}


void CDlgScheduleInfo::OnBnClickedRadioCom4()
{
	m_nComSol7 = 0;
	m_nComSol8 = 0;
	GetDlgItem(IDC_EDT_PROJECT8)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN8)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioSol4()
{
	m_nComSol7 = 1;
	m_nComSol8 = 1;
	GetDlgItem(IDC_EDT_PROJECT8)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN8)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioBoth4()
{
	m_nComSol7 = 2;
	m_nComSol8 = 3;
	GetDlgItem(IDC_EDT_PROJECT8)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BTN_OPEN8)->ShowWindow(SW_SHOW);
}


void CDlgScheduleInfo::OnBnClickedRadioCom5()
{
	m_nComSol9 = 0;
	m_nComSol10 = 0;
	GetDlgItem(IDC_EDT_PROJECT10)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN10)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioSol5()
{
	m_nComSol9 = 1;
	m_nComSol10 = 1;
	GetDlgItem(IDC_EDT_PROJECT10)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BTN_OPEN10)->ShowWindow(SW_HIDE);
}


void CDlgScheduleInfo::OnBnClickedRadioBoth5()
{
	m_nComSol9 = 2;
	m_nComSol10 = 3;
	GetDlgItem(IDC_EDT_PROJECT10)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BTN_OPEN10)->ShowWindow(SW_SHOW);
}

CString CDlgScheduleInfo::FindProjectName(CString strLotID, CString strManager, CString strProductLayer, BOOL bComSol)
{
	CString strResult;
	int nIndex = strManager.Find(_T('-'));
	
	if(nIndex == -1)
	{
		ErrMessage(_T("DB Admin numbers are not correct..\r\n( correct is : XXX-XX... )"));
		return " ";
	}
	
	// m_strLot2�� 133-877-9T�̶�� �Ѵٸ�,
	// m_strManage = 1X8779T�� �ȴ�
	// "133"���� �ڿ� 2�ڸ� "33"�� "X"�� ��ȯ�ϸ� ��
	
	CString strTemp = strManager.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	strResult = strManager.Left(1) + strTemp;
	
	CString strTemp2= strManager.Mid(nIndex+1);
	
	int nIndexCount = 0;
	while(TRUE)
	{
		if(nIndexCount == 2)
			break;
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			strResult += strTemp2;
			break;
		}
		strResult += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
		nIndexCount++;
	}
	
	CString strLayer = strManager.Right(2);
	int nLayer = atoi(strLayer);

	CString  strFilePath = _T("");
	CString  strFilePathSecond = _T("");
	char szFilter[9][50];
	char szFilterSecond[9][50];
	memset(szFilter, 0, sizeof(szFilter));
	memset(szFilterSecond, 0, sizeof(szFilterSecond));
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	strFilePath.Empty();
	int nLen = strManager.GetLength();

	CString strTempLotID = strLotID.Right(6);

	if(nLen == 10) // ����1�ڸ�+����8�ڸ� ����
	{
#ifndef __TEST__
		sprintf(szFilter[0],_T("%s_1_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_A_%s"), strResult, strTempLotID);

		sprintf(szFilter[2],_T("%s_1"), strResult); 
		sprintf(szFilter[3],_T("%s_A"), strResult);

		sprintf(szFilterSecond[0],_T("%s1_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sA_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[2],_T("%s1"), strResult); 
		sprintf(szFilterSecond[3],_T("%sA"), strResult);

#else
		sprintf(szFilter[0],_T("test")); 
		sprintf(szFilter[1],_T("test2")); 
#endif
		
		if(bComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
			{
				return strFilePath;
			}
			else if(bExistSecond)
			{
				return strFilePathSecond;
			}
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
				{
					return strFilePath;
				}
				else if(bExistSecond)
				{
					return strFilePathSecond;
				}
				else
				{
					return "NOEXIST";
				}
			}
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
			{
				return strFilePath;
			}
			else if(bExistSecond)
			{
				return strFilePathSecond;
			}
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
				{
					return strFilePath;
				}
				else if(bExistSecond)
				{
					return strFilePathSecond;
				}
				else
				{
					return "NOEXIST";
				}
			}
		}
	}
	else if(nLen == 13) // ����1�ڸ�+����10�ڸ� ����
	{
		int nProductLayer = atoi(strProductLayer);
		if(bComSol == 0) // com 
		{
			sprintf(szFilter[0],_T("%s_3"), strResult); 
			sprintf(szFilter[1],_T("%s_5"), strResult);
			sprintf(szFilter[2],_T("%s_7"), strResult); 
			sprintf(szFilter[3],_T("%s_9"), strResult);
			sprintf(szFilter[4],_T("%s_11"), strResult);
			sprintf(szFilter[5],_T("%s_13"), strResult);
			sprintf(szFilter[6],_T("%s_15"), strResult);
			sprintf(szFilter[7],_T("%s_17"), strResult);

			sprintf(szFilterSecond[0],_T("%s3"), strResult); 
			sprintf(szFilterSecond[1],_T("%s5"), strResult);
			sprintf(szFilterSecond[2],_T("%s7"), strResult); 
			sprintf(szFilterSecond[3],_T("%s9"), strResult);
			sprintf(szFilterSecond[4],_T("%s11"), strResult);
			sprintf(szFilterSecond[5],_T("%s13"), strResult);
			sprintf(szFilterSecond[6],_T("%s15"), strResult);
			sprintf(szFilterSecond[7],_T("%s17"), strResult);
			
/*			for(int i = 0; i< 4; i++)
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[i]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				if(bExist)
					nFind++;
			}
			if(nFind == 0)
				return "NOEXIST";

			else
*/
			{
				if(nProductLayer == 4)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 6)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 8)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 10)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 12)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 14)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 16)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 18)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[7]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[7]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 8)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
		else // sol
		{
			sprintf(szFilter[0],_T("%s_C"), strResult); 
			sprintf(szFilter[1],_T("%s_E"), strResult);
			sprintf(szFilter[2],_T("%s_G"), strResult); 
			sprintf(szFilter[3],_T("%s_I"), strResult); 
			sprintf(szFilter[4],_T("%s_KK"), strResult); 
			sprintf(szFilter[5],_T("%s_MM"), strResult); 
			sprintf(szFilter[6],_T("%s_OO"), strResult); 

			sprintf(szFilterSecond[0],_T("%sC"), strResult); 
			sprintf(szFilterSecond[1],_T("%sE"), strResult);
			sprintf(szFilterSecond[2],_T("%sG"), strResult); 
			sprintf(szFilterSecond[3],_T("%sI"), strResult); 
			sprintf(szFilterSecond[4],_T("%sKK"), strResult); 
			sprintf(szFilterSecond[5],_T("%sMM"), strResult); 
			sprintf(szFilterSecond[6],_T("%sOO"), strResult); 

/*			for(int i = 0; i< 3; i++)
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[i]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				if(bExist)
					nFind++;
			}
			nFind += 1;
			if(nFind == 0)
				return "NOEXIST";
			else
*/
			{
				if(nProductLayer == 6)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 8)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 10)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 12)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 14)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 16)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 18)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 8)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	return strFilePath;
}

void CDlgScheduleInfo::OnBnClickedCancel()
{
	if(m_bMESChecking)
	{
		return;
	}
	CDialog::OnCancel();
}


void CDlgScheduleInfo::OnSetfocusEdtLotinfo()
{
	// TODO: Add your control notification handler code here
	m_bSetFocusLot = TRUE;
	m_bSetFocusLot2 = FALSE;
	m_bSetFocusLot3 = FALSE;
	m_bSetFocusLot4 = FALSE;
	m_bSetFocusLot5 = FALSE;
}


void CDlgScheduleInfo::OnEnSetfocusEdtLotinfo3()
{
	// TODO: Add your control notification handler code here
	m_bSetFocusLot = FALSE;
	m_bSetFocusLot2 = TRUE;
	m_bSetFocusLot3 = FALSE;
	m_bSetFocusLot4 = FALSE;
	m_bSetFocusLot5 = FALSE;
}


void CDlgScheduleInfo::OnEnSetfocusEdtLotinfo5()
{
	// TODO: Add your control notification handler code here
	m_bSetFocusLot = FALSE;
	m_bSetFocusLot2 = FALSE;
	m_bSetFocusLot3 = TRUE;
	m_bSetFocusLot4 = FALSE;
	m_bSetFocusLot5 = FALSE;
}


void CDlgScheduleInfo::OnEnSetfocusEdtLotinfo7()
{
	// TODO: Add your control notification handler code here
	m_bSetFocusLot = FALSE;
	m_bSetFocusLot2 = FALSE;
	m_bSetFocusLot3 = FALSE;
	m_bSetFocusLot4 = TRUE;
	m_bSetFocusLot5 = FALSE;
}


void CDlgScheduleInfo::OnEnSetfocusEdtLotinfo9()
{
	// TODO: Add your control notification handler code here
	m_bSetFocusLot = FALSE;
	m_bSetFocusLot2 = FALSE;
	m_bSetFocusLot3 = FALSE;
	m_bSetFocusLot4 = FALSE;
	m_bSetFocusLot5 = TRUE;
}

void CDlgScheduleInfo::SaveLotInfo()
{
		m_nLastIndex = 0;
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(m_nNo2)
			GetDlgItem(IDC_EDT_PROJECT2)->SetWindowText(m_strPrj1);
		if(m_nNo3)
			GetDlgItem(IDC_EDT_PROJECT3)->SetWindowText(m_strPrj1);
		if(m_nNo4)
			GetDlgItem(IDC_EDT_PROJECT4)->SetWindowText(m_strPrj1);
		if(m_nNo5)
			GetDlgItem(IDC_EDT_PROJECT5)->SetWindowText(m_strPrj1);
		if(m_nNo6)
			GetDlgItem(IDC_EDT_PROJECT6)->SetWindowText(m_strPrj1);
		if(m_nNo7)
			GetDlgItem(IDC_EDT_PROJECT7)->SetWindowText(m_strPrj1);
		if(m_nNo8)
			GetDlgItem(IDC_EDT_PROJECT8)->SetWindowText(m_strPrj1);
		if(m_nNo9)
			GetDlgItem(IDC_EDT_PROJECT9)->SetWindowText(m_strPrj1);
		if(m_nNo10)
			GetDlgItem(IDC_EDT_PROJECT10)->SetWindowText(m_strPrj1);

		if(m_nNo2)
			m_strPrj2.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo3)
			m_strPrj3.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo4)
			m_strPrj4.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo5)
			m_strPrj5.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo6)
			m_strPrj6.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo7)
			m_strPrj7.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo8)
			m_strPrj8.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo9)
			m_strPrj9.Format(_T("%s"), 	m_strPrj1);
		if(m_nNo10)
			m_strPrj10.Format(_T("%s"),	m_strPrj1);

	}
#endif
	
/*	if(!m_bOnlyDisplay)
	{
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAutoRun)
		{
			if(!OpenPrj())
			{
				CString str;
				str.Format(_T("Tool of project No.%d differ from another project tool "), m_nDiffTool+1);
				ErrMessage(str);
				return;
			}
		}
	}
*/ // 20131001

	// TODO: Add extra validation here
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();

	CString strCopyNo;
	m_strLotInfo.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes == TRUE && 0 != m_strLotInfo.CompareNoCase(_T("")))
			m_nLastIndex = 1;		
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo.CompareNoCase(_T("")))
			m_nLastIndex++;		
	}


	// 2 
	if(gProcessINI.m_sProcessSystem.bUseScheduling )
	{
		m_strLotInfo2 = m_strLotInfo;
		strCopyNo.Format(_T("%d"), m_nNo2);
		GetDlgItem(IDC_EDT_NO2)->SetWindowTextA(strCopyNo);
	}
	m_strLotInfo.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes == TRUE &&  0 != m_strLotInfo.CompareNoCase(_T("")))
			m_nLastIndex = 2;	
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo.CompareNoCase(_T("")))
			m_nLastIndex++;	
	}

	if(strcmp(m_strPrj2, _T("")) != 0 && strcmp(m_strPrj2, _T(" ")) != 0)
		m_nNo2 = m_nNo;


	//3
	m_strLotInfo3.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes3 == TRUE && 0 != m_strLotInfo3.CompareNoCase(_T("")))
			m_nLastIndex = 3;		
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo3.CompareNoCase(_T("")))
			m_nLastIndex++;		
	}
	

	//4
	m_strLotInfo4 = m_strLotInfo3;
	strCopyNo.Format(_T("%d"), m_nNo4);
	GetDlgItem(IDC_EDT_NO4)->SetWindowTextA(strCopyNo);
	m_strLotInfo3.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes3 == TRUE && 0 != m_strLotInfo3.CompareNoCase(_T("")))
			m_nLastIndex = 4;		
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo3.CompareNoCase(_T("")))
			m_nLastIndex++;	
	}	
	if(strcmp(m_strPrj4, _T("")) != 0 && strcmp(m_strPrj4, _T(" ")) != 0)
		m_nNo4 = m_nNo3;

	
	// 5

	m_strLotInfo5.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes5 == TRUE && 0 != m_strLotInfo5.CompareNoCase(_T("")))
			m_nLastIndex = 5;			
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo5.CompareNoCase(_T("")))
			m_nLastIndex++;			
	}	
	


	//6
	m_strLotInfo6 = m_strLotInfo5;
	strCopyNo.Format(_T("%d"), m_nNo6);
	GetDlgItem(IDC_EDT_NO6)->SetWindowTextA(strCopyNo);
	m_strLotInfo5.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes5 == TRUE && 0 != m_strLotInfo5.CompareNoCase(_T("")))
			m_nLastIndex = 6;				
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo5.CompareNoCase(_T("")))
			m_nLastIndex++;			
	}	
		
	if(strcmp(m_strPrj6, _T("")) != 0 && strcmp(m_strPrj6, _T(" ")) != 0)
		m_nNo6 = m_nNo5;


	// 7 
	m_strLotInfo7.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes7 == TRUE && 0 != m_strLotInfo7.CompareNoCase(_T("")))
			m_nLastIndex = 7;				
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo7.CompareNoCase(_T("")))
			m_nLastIndex++;				
	}	
	


	// 8
	m_strLotInfo8 = m_strLotInfo7;
	strCopyNo.Format(_T("%d"), m_nNo8);
	GetDlgItem(IDC_EDT_NO8)->SetWindowTextA(strCopyNo);
	m_strLotInfo7.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes7 == TRUE && 0 != m_strLotInfo7.CompareNoCase(_T("")))
			m_nLastIndex = 8;				
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo7.CompareNoCase(_T("")))
			m_nLastIndex++;			
	}
	
	if(strcmp(m_strPrj8, _T("")) != 0 && strcmp(m_strPrj8, _T(" ")) != 0)
		m_nNo8 = m_nNo7;

	// 9
	m_strLotInfo9.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes9 == TRUE && 0 != m_strLotInfo9.CompareNoCase(_T("")))
			m_nLastIndex = 9;					
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo9.CompareNoCase(_T("")))
				m_nLastIndex++;		
	}
	

	// 10
	m_strLotInfo10 = m_strLotInfo9;
	strCopyNo.Format(_T("%d"), m_nNo10);
	GetDlgItem(IDC_EDT_NO10)->SetWindowTextA(strCopyNo);
	m_strLotInfo9.Replace(_T(" "), _T(""));
	if(nRMSType == 1)
	{
		if(m_bMes9 == TRUE && 0 != m_strLotInfo9.CompareNoCase(_T("")))
			m_nLastIndex = 10;					
	}
	else if(nRMSType == 2)
	{
		if(0 != m_strLotInfo9.CompareNoCase(_T("")))
			m_nLastIndex++;		
	}
	
	if(strcmp(m_strPrj10, _T("")) != 0 && strcmp(m_strPrj10, _T(" ")) != 0)
		m_nNo10 = m_nNo9;



	gLotInfo.nLastIndex = m_nLastIndex;

	strcpy_s(gLotInfo.szLotID[0], m_strLotInfo);
	strcpy_s(gLotInfo.szLotID[1], m_strLotInfo2);
	strcpy_s(gLotInfo.szLotID[2], m_strLotInfo3);
	strcpy_s(gLotInfo.szLotID[3], m_strLotInfo4);
	strcpy_s(gLotInfo.szLotID[4], m_strLotInfo5);
	strcpy_s(gLotInfo.szLotID[5], m_strLotInfo6);
	strcpy_s(gLotInfo.szLotID[6], m_strLotInfo7);
	strcpy_s(gLotInfo.szLotID[7], m_strLotInfo8);
	strcpy_s(gLotInfo.szLotID[8], m_strLotInfo9);
	strcpy_s(gLotInfo.szLotID[9], m_strLotInfo10);

	gLotInfo.nLotCount[0] = m_nNo;
	gLotInfo.nLotCount[1] = m_nNo2;
	gLotInfo.nLotCount[2] = m_nNo3;
	gLotInfo.nLotCount[3] = m_nNo4;
	gLotInfo.nLotCount[4] = m_nNo5;
	gLotInfo.nLotCount[5] = m_nNo6;
	gLotInfo.nLotCount[6] = m_nNo7;
	gLotInfo.nLotCount[7] = m_nNo8;
	gLotInfo.nLotCount[8] = m_nNo9;
	gLotInfo.nLotCount[9] = m_nNo10;

	gLotInfo.bMESOK[0] = m_bMes;
	gLotInfo.bMESOK[1] = m_bMes2;
	gLotInfo.bMESOK[2] = m_bMes3;
	gLotInfo.bMESOK[3] = m_bMes4;
	gLotInfo.bMESOK[4] = m_bMes5;
	gLotInfo.bMESOK[5] = m_bMes6;
	gLotInfo.bMESOK[6] = m_bMes7;
	gLotInfo.bMESOK[7] = m_bMes8;
	gLotInfo.bMESOK[8] = m_bMes9;
	gLotInfo.bMESOK[9] = m_bMes10;

	gLotInfo.bUseOpenTool[0] = m_bUseOpenTool;
	gLotInfo.bUseOpenTool[1] = m_bUseOpenTool2;
	gLotInfo.bUseOpenTool[2] = m_bUseOpenTool3;
	gLotInfo.bUseOpenTool[3] = m_bUseOpenTool4;
	gLotInfo.bUseOpenTool[4] = m_bUseOpenTool5;
	gLotInfo.bUseOpenTool[5] = m_bUseOpenTool6;
	gLotInfo.bUseOpenTool[6] = m_bUseOpenTool7;
	gLotInfo.bUseOpenTool[7] = m_bUseOpenTool8;
	gLotInfo.bUseOpenTool[8] = m_bUseOpenTool9;
	gLotInfo.bUseOpenTool[9] = m_bUseOpenTool10;

	gLotInfo.nComSol[0] = m_nComSol;
	gLotInfo.nComSol[1] = m_nComSol2;
	gLotInfo.nComSol[2] = m_nComSol3;
	gLotInfo.nComSol[3] = m_nComSol4;
	gLotInfo.nComSol[4] = m_nComSol5;
	gLotInfo.nComSol[5] = m_nComSol6;
	gLotInfo.nComSol[6] = m_nComSol7;
	gLotInfo.nComSol[7] = m_nComSol8;
	gLotInfo.nComSol[8] = m_nComSol9;
	gLotInfo.nComSol[9] = m_nComSol10;

	gLotInfo.bUseMES = m_bUseMES;

	strcpy_s(gLotInfo.szFilmNo[0], m_strFilmNo);
	strcpy_s(gLotInfo.szFilmNo[1], m_strFilmNo2);
	strcpy_s(gLotInfo.szFilmNo[2], m_strFilmNo3);
	strcpy_s(gLotInfo.szFilmNo[3], m_strFilmNo4);
	strcpy_s(gLotInfo.szFilmNo[4], m_strFilmNo5);
	strcpy_s(gLotInfo.szFilmNo[5], m_strFilmNo6);
	strcpy_s(gLotInfo.szFilmNo[6], m_strFilmNo7);
	strcpy_s(gLotInfo.szFilmNo[7], m_strFilmNo8);
	strcpy_s(gLotInfo.szFilmNo[8], m_strFilmNo9);
	strcpy_s(gLotInfo.szFilmNo[9], m_strFilmNo10);

	strcpy_s(gLotInfo.szProcessCode[0], m_strProcessCode);
	strcpy_s(gLotInfo.szProcessCode[1], m_strProcessCode2);
	strcpy_s(gLotInfo.szProcessCode[2], m_strProcessCode3);
	strcpy_s(gLotInfo.szProcessCode[3], m_strProcessCode4);
	strcpy_s(gLotInfo.szProcessCode[4], m_strProcessCode5);
	strcpy_s(gLotInfo.szProcessCode[5], m_strProcessCode6);
	strcpy_s(gLotInfo.szProcessCode[6], m_strProcessCode7);
	strcpy_s(gLotInfo.szProcessCode[7], m_strProcessCode8);
	strcpy_s(gLotInfo.szProcessCode[8], m_strProcessCode9);
	strcpy_s(gLotInfo.szProcessCode[9], m_strProcessCode10);

	strcpy_s(gLotInfo.szPrj[0], m_strPrj1);
	strcpy_s(gLotInfo.szPrj[1], m_strPrj2);
	strcpy_s(gLotInfo.szPrj[2], m_strPrj3);
	strcpy_s(gLotInfo.szPrj[3], m_strPrj4);
	strcpy_s(gLotInfo.szPrj[4], m_strPrj5);
	strcpy_s(gLotInfo.szPrj[5], m_strPrj6);
	strcpy_s(gLotInfo.szPrj[6], m_strPrj7);
	strcpy_s(gLotInfo.szPrj[7], m_strPrj8);
	strcpy_s(gLotInfo.szPrj[8], m_strPrj9);
	strcpy_s(gLotInfo.szPrj[9], m_strPrj10);

	gLotInfo.nFireType[0] = m_nFireType;
	gLotInfo.nFireType[1] = m_nFireType2;
	gLotInfo.nFireType[2] = m_nFireType3;
	gLotInfo.nFireType[3] = m_nFireType4;
	gLotInfo.nFireType[4] = m_nFireType5;
	gLotInfo.nFireType[5] = m_nFireType6;
	gLotInfo.nFireType[6] = m_nFireType7;
	gLotInfo.nFireType[7] = m_nFireType8;
	gLotInfo.nFireType[8] = m_nFireType9;
	gLotInfo.nFireType[9] = m_nFireType10;
}

void CDlgScheduleInfo::EnableComSolBoth(int* nComSol)
{
	if(nComSol[0] == 0)
		OnBnClickedRadioCom();
	else if(nComSol[0] == 1)
		OnBnClickedRadioSol();
	else if(nComSol[0] == 2 || nComSol[0] == 3)
		OnBnClickedRadioBoth();

	if(nComSol[3] == 0)
		OnBnClickedRadioCom2();
	else if(nComSol[3] == 1)
		OnBnClickedRadioSol2();
	else if(nComSol[3] == 2 || nComSol[3] == 3)
		OnBnClickedRadioBoth2();

	if(nComSol[5] == 0)
		OnBnClickedRadioCom3();
	else if(nComSol[5] == 1)
		OnBnClickedRadioSol3();
	else if(nComSol[5] == 2 || nComSol[5] == 3)
		OnBnClickedRadioBoth3();

	if(nComSol[7] == 0)
		OnBnClickedRadioCom4();
	else if(nComSol[7] == 1)
		OnBnClickedRadioSol4();
	else if(nComSol[7] == 2 || nComSol[7] == 3)
		OnBnClickedRadioBoth4();

	if(nComSol[9] == 0)
		OnBnClickedRadioCom5();
	else if(nComSol[9] == 1)
		OnBnClickedRadioSol5();
	else if(nComSol[9] == 2 || nComSol[9] == 3)
		OnBnClickedRadioBoth5();
}

void CDlgScheduleInfo::SetAutoMES(int nIndex, BOOL bAuto)
{
	m_nAutoIndex = nIndex;
	m_bAutoMes = bAuto;
}

void CDlgScheduleInfo::AutoMES()
{
	int nRMSType = 0;
#ifndef __NO_USE_OPC__
	nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
#endif

	{
		if(m_nAutoIndex == 0)
		{
			OnButtonMES(); 
			return;
		}
		if(m_nAutoIndex == 2)
		{
			OnButtonMES3();
			return;
		}
		if(m_nAutoIndex == 4)
		{
			OnButtonMES5();
			return;
		}
		if(m_nAutoIndex == 6)
		{
			OnButtonMES7();
			return;
		}
		if(m_nAutoIndex == 8)
		{
			OnButtonMES9();
			return;
		}
	}

}

CString CDlgScheduleInfo::FindProjectNameNew2(CString strLotID, CString strManager, int nComSol, CString strProcessCode, CString strBackwardLevel)
{
	CString strResult;
	int nIndex = strManager.Find(_T('-'));
	
	if(nIndex == -1)
	{
		ErrMessage(_T("DB Admin numbers are not correct..\r\n( correct is : XXX-XX... )"));
		return "NOEXIST";
	}
	
	// m_strLot2�� 133-877-9T�̶�� �Ѵٸ�,
	// m_strManage = 1X8779T�� �ȴ�
	// "133"���� �ڿ� 2�ڸ� "33"�� "X"�� ��ȯ�ϸ� ��
	
	CString strTemp = strManager.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	strResult = strManager.Left(1) + strTemp;
	
	CString strTemp2= strManager.Mid(nIndex+1);
	
	int nIndexCount = 0;
	while(TRUE)
	{
		if(nIndexCount == 2)
			break;
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			strResult += strTemp2;
			break;
		}
		strResult += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
		nIndexCount++;
	}
	
	CString strLayer = strManager.Right(2);
	int nLayer = atoi(strLayer);

	CString  strFilePath = _T("");
	CString  strFilePathSecond = _T("");
	char szFilter[9][50];
	char szFilterSecond[9][50];
	memset(szFilter, 0, sizeof(szFilter));
	memset(szFilterSecond, 0, sizeof(szFilterSecond));
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	strFilePath.Empty();
	int nLen = strManager.GetLength();

	CString strTempLotID = strLotID.Right(6);
	if(strBackwardLevel.CompareNoCase("1") == 0) // ����1�ڸ�+����8�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_1_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_A_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s1_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sA_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_1"), strResult); 
		sprintf(szFilter[3],_T("%s_A"), strResult);

		sprintf(szFilterSecond[2],_T("%s1"), strResult); 
		sprintf(szFilterSecond[3],_T("%sA"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}			
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("2") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_3_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_C_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s3_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sC_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_3"), strResult); 
		sprintf(szFilter[3],_T("%s_C"), strResult);

		sprintf(szFilterSecond[2],_T("%s3"), strResult); 
		sprintf(szFilterSecond[3],_T("%sC"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("3") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_5_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_E_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s5_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sE_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_5"), strResult); 
		sprintf(szFilter[3],_T("%s_E"), strResult);

		sprintf(szFilterSecond[2],_T("%s5"), strResult); 
		sprintf(szFilterSecond[3],_T("%sE"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}	
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("4") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_7_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_G_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s7_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sG_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_7"), strResult); 
		sprintf(szFilter[3],_T("%s_G"), strResult);

		sprintf(szFilterSecond[2],_T("%s7"), strResult); 
		sprintf(szFilterSecond[3],_T("%sG"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}	
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("5") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_9_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_I_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s9_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sI_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_9"), strResult); 
		sprintf(szFilter[3],_T("%s_I"), strResult);

		sprintf(szFilterSecond[2],_T("%s9"), strResult); 
		sprintf(szFilterSecond[3],_T("%sI"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}		
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("6") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_11_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_K_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s11_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sK_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_11"), strResult); 
		sprintf(szFilter[3],_T("%s_K"), strResult);

		sprintf(szFilterSecond[2],_T("%s11"), strResult); 
		sprintf(szFilterSecond[3],_T("%sK"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}	
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
					return "NOEXIST";
			}
		}
	}
	else
		return "NOEXIST";

	return strFilePath;
}

CString CDlgScheduleInfo::FindProjectNameNew(CString strFileName, CString strManagementCode)
{
	
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	CString strFilePath = _T("");
	CString strCopyFilePath = _T("");
	CString strProjectPath = _T("");

	//strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(),strFileName);
	strFilePath.Format(_T("%s%s\\%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(),strManagementCode,strFileName);
	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(bExist)
		return strFilePath;
	else
		return "NOEXIST";

	return strFilePath;
}