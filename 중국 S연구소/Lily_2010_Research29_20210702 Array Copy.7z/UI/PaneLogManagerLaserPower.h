#if !defined(AFX_PANELOGMANAGERLASERPOWER_H__AA96E78A_F950_4E6E_BFD6_401A493EEA91__INCLUDED_)
#define AFX_PANELOGMANAGERLASERPOWER_H__AA96E78A_F950_4E6E_BFD6_401A493EEA91__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManagerLaserPower.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLaserPower form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"

class CPaneLogManagerLaserPower : public CFormView
{
protected:
	CPaneLogManagerLaserPower();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManagerLaserPower)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManagerLaserPower)
	enum { IDD = IDD_DLG_LOG_MANAGER_LASER_POWER };
	CListCtrl	m_listPowerTrend;
	CDateTimeCtrl	m_dtcStart;
	CDateTimeCtrl	m_dtcEnd;
	CComboBox	m_cmbHead;
	CComboBox	m_cmbBeamPath;
	UEasyButtonEx	m_btnView;
	CTime	m_ctEnd;
	CTime	m_ctStart;
	int		m_nSelectHead;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntList;
	CFont		m_fntEtc;

	TCHAR		m_lpszColumnHead[13][35];

	CImageList	m_ImageList;

	BOOL		m_bShow;
	BOOL		m_bOnTimer;

	double		m_dMasterMax;
	double		m_dMasterMin;
	double		m_dSlaveMax;
	double		m_dSlaveMin;
	double		m_dMax;
	double		m_dMin;
	double		m_dSetMax;
	double		m_dSetMin;
	LOGFONT		m_logFont;

	int			m_nTimerID;
	int			m_nBeamPath;

// Operations
public:
	void		SetToolComboBox();
	void		InitBtnControl();
	void		InitStaticControl();
	void		InitListControl();
	void		InitEtcControl();

	void		ShowBackGround();
	void		ShowGraph();
	void		FillList();
	void		UpdateTime();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManagerLaserPower)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManagerLaserPower();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManagerLaserPower)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnButtonView();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCbnSelchangeComboBeampath();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELOGMANAGERLASERPOWER_H__AA96E78A_F950_4E6E_BFD6_401A493EEA91__INCLUDED_)
