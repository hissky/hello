// DHwOption.h: interface for the DHwOption class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DHWOPTION_H__37091D53_FD57_4209_A7CB_D61452663567__INCLUDED_)
#define AFX_DHWOPTION_H__37091D53_FD57_4209_A7CB_D61452663567__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DHwOption  
{
public:
	DHwOption();
	virtual ~DHwOption();

	int	m_nRepeatMode;
	int	m_nMGCMode;

// Operation
public :
	void	SetUseDualPanel(int nDual)			{ m_nUseDualPanel = nDual; }
	int		GetUseDualPanel()					{ return m_nUseDualPanel; }

	void	SetCalibrationType(int nType)		{ m_nCalibrationType = nType; }
	int		GetCalibrationType()				{ return m_nCalibrationType; }

	void	SetMotorType(int nType)				{ m_nMotorType = nType; }
	int		GetMotorType()						{ return m_nMotorType; }

	void	SetCameraNum(int nNum)				{ m_nCameraNum = nNum; }
	int		GetCameraNum()						{ return m_nCameraNum; }

	void	SetHeightSensorNum(int nNum)		{ m_nHeightSensorNum = nNum; }
	int		GetHeightSensorNum()				{ return m_nHeightSensorNum; }
	
	void	SetScannerHeadNum(int nNum)			{ m_nScannerHeadNum = nNum; }
	int		GetScannerHeadNum()					{ return m_nScannerHeadNum; }

	void	SetUseOnlyXY(int nUse)				{ m_nUseOnlyXY = nUse; }
	int		GetUseOnlyXY()						{ return m_nUseOnlyXY; }
	
	void	SetUsePowerMeasure(int nUse)		{ m_nUsePowerMeasure = nUse; }
	int		GetUsePowerMeasure()				{ return m_nUsePowerMeasure; }

// Attributes
protected :
	int		m_nUseDualPanel;
	int		m_nCalibrationType;
	int		m_nMotorType;
	int		m_nCameraNum;
	int		m_nHeightSensorNum;
	int		m_nScannerHeadNum;
	int		m_nUseOnlyXY;
	int		m_nUsePowerMeasure;
};

#endif // !defined(AFX_DHWOPTION_H__37091D53_FD57_4209_A7CB_D61452663567__INCLUDED_)
