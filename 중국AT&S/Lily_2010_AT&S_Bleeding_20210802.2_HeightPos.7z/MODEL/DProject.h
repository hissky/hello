// DProject.h: interface for the DProject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPROJECT_H__7A0AC780_3AE1_4A32_AA2E_20DF268CDD59__INCLUDED_)
#define AFX_DPROJECT_H__7A0AC780_3AE1_4A32_AA2E_20DF268CDD59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ToolCodeList.h"
#include "DPoint.h"
#include "ArchiveMark.h"
#include "Glyph.h"
#include "DAreaInfo.h"
#include "GlyphExcellon.h"
#include "..\Device\HVisionOmi.h"
#include "2DTransform.h"	// Added by ClassView
#include "math.h"

#define MAX_FID_NO			20
#define MAX_SHOT_NO_UV		5
#define MAX_SHOT_NO_CO2		255	
//#define MAX_PATH_LEN		255
#define DEFAULT_FID_INDEX	0
#define ADDED_FID_INDEX		1
#define MAX_FID_KIND_NO		2
#define MAX_FID_BLOCK		50 
#define ADDED_FID_TOOL		0

#define MAX_PCB_THICK			5
#define MIN_PCB_THICK			0
#define MAX_X_TABLE				1000
#define MIN_X_TABLE				0
#define MAX_Y_TABLE				1000
#define MIN_Y_TABLE				0

#define MAX_FID_SIZE			6
#define MAX_PERCENT				100
#define MAX_ANGLE				360

#define MAX_FREQ				10000
#define MIN_FREQ				1000
#define MAX_CURRENT				100
#define MAX_Z_OFFSET			5
#define MAX_SCANNER_PARAM		65535
#define MIN_SP					10

#define MISSHOT_ERROR			10
#define TABLE_MOVE_ERROR		20
#define FIDUCIAL_TRANS_ERROR	30
#define OUT_TABLE_FIRE			40
#define DATA_BLOCK_CNT_ERROR		70

#define DRAW_ALL				0
#define DRAW_SELECT				1
#define DRAW_PATH				2

#define DBL_MAX         1.7976931348623158e+308 /* max value */

#define MAX_DATA_BLOCK_COUNT	100
#define SIZE_OF_DIVIDE	250
#define SIZE_OF_CAL		4000
#define PATTERN_DIFF_VAL				3//3
#define MAX_HEAD_DIST_DIFF		1000 // 1mm �ʰ��� ������Ʈ�� ��� ��ġ�� �ٸ��� �ٸ� �������� �Ǵ��ؾ� ��


enum emToolSum		{emNoUse, emSameTool, emOneFieldTool, emOneBoardTool, emFlying, emTextOneBoard}; 
enum emInputUint	{em1um, em10um, em100um, em1000um, em1inch, em01um};
enum emTZSLZS		{emTZS, emLZS	};
enum emToolType		{emToolMark, emToolShotDrill, emToolText, emToolLineDrill, emToolFlying, emToolBarcode };
typedef enum { BURST_SHOT = 0, CYCLE_SHOT, STEP_SHOT, NORMAL_SHOT} SHOT_MODE;
enum { FIELD_NONE_CHANGE, FIELD_AXIS_CHANGE, FIELD_CHANGE};
enum emDataType		{HOLE_DATA, LINE_DATA};

struct APERTUREDATA {
	int			nFreq;
	double		dCurrent;
	int			nMask;
	double		dZOffset;
	int			nSP;
	int			nJD;
	int			nLOnD;
	int			nLOffD;
	TCHAR		cAperture[MAX_PATH_LEN];
	void operator=( APERTUREDATA myData )
	{
		nFreq		= myData.nFreq;
		dCurrent	= myData.dCurrent;
		nMask		= myData.nMask;
		dZOffset	= myData.dZOffset;
		nSP			= myData.nSP;
		nJD			= myData.nJD;
		nLOnD		= myData.nLOnD;
		nLOffD		= myData.nLOffD;
		
		for(int i = 0; i < MAX_PATH_LEN; i++)
			cAperture[i] = myData.cAperture[i];
	};
};

struct TOOLDATA {
	int				nTcodeNo;
	int				nMask;
	int				nFreq;
	COLORREF		nColor;
	int				nShotCount;
	int				nBurstShotCount;
	double			dPower[MAX_SHOT_NO_CO2];
	APERTUREDATA	Aperture[MAX_SHOT_NO_UV];
	int				nDrillMethod;
	BOOL			bUseAperture; 

	void operator=( TOOLDATA& myData )
	{
		nTcodeNo		= myData.nTcodeNo;
		nMask			= myData.nMask;
		nFreq			= myData.nFreq;
		nColor			= myData.nColor;
		nShotCount		= myData.nShotCount;
		nBurstShotCount = myData.nBurstShotCount;
		
		for(int i = 0; i < MAX_SHOT_NO_CO2; i++)
			dPower[i] = myData.dPower[i];
		for(int i = 0; i < MAX_SHOT_NO_UV; i++)
			Aperture[i] = myData.Aperture[i];

		nDrillMethod= myData.nDrillMethod;
		bUseAperture= myData.bUseAperture;

	};
};

struct TOOL_SUM_INFO {
	int		nRealToolNo;
	int		nSameAreaToolNo;
	int		nToolAtri;
	BOOL	bUsed;
	BOOL	bTextType;
};

struct AREA_SORT_DATA {
	DAreaInfo*	pAreaInfo;
	BOOL		bUsed;
	int			nSortIndex;
};
struct HOLE_SORT_DATA {
	LPFIREHOLE	pHole;
	BOOL		bUsed;
	int			nSortIndex;
};
struct LINE_SORT_DATA {
	LPFIRELINE	pLine;
	BOOL		bUsed;
	int			nSortIndex;
	BOOL		bChange;
};
struct UNIT_DATA {
	int			nMinX;
	int			nMaxX;
	int			nMinY;
	int			nMaxY;
	LPDUNIT		pUnit;
};

typedef	TOOLDATA*	LPTOOLDATA;

typedef CTypedPtrList <CPtrList, LPTOOLDATA>	ToolDataList;

typedef CTypedPtrList <CPtrList, Glyph*>	GlyphList;

typedef CTypedPtrList <CPtrList, DAreaInfo*>	AreaList;

typedef CTypedPtrList <CPtrList, UNIT_DATA*>	UnitRectList;

class DProject  
{
public:
	void RemoveProject();

	BOOL FindPattern(CPoint pt1, CPoint pt2);

	void CalScaleLimit(double dAvgScaleX, double dAvgScaleY);
	void GetHoleDistance();
	void ResetUseToolFlag();
	BOOL LoadFile10000(CArchiveMark& ar, int nVersion);
	BOOL SaveFile10000(CArchiveMark& ar, int nVersion);
	BOOL Serialize(CArchiveMark& ar, int nVersion);
	
	void operator=( DProject& myDProject );
	DProject();
	virtual ~DProject();

	CToolCodeList* m_pToolCode[MAX_TOOL_NO];
	BOOL	m_bSelectToolDraw[MAX_TOOL_NO];
	UnitList m_TempUnits;

	void InitStripIndex();
	void SortStripIndex();
	void ChangeStripIndex();

	CList <int, int>	m_listXIndex;
	CList <int, int>	m_listYIndex;

public:
	BOOL  FindLPCDataAndCheckIt(DAreaInfo* pAreaInfo, CPoint ptFilePos, int nNGType);
	DAreaInfo* FindLPCArea(int nAreaIndex);
	int GetOneBadLPCIndex(FILE* pFile, int& nAreaIndex, int& nSubToolIndex, int&nShotIndex, CPoint& ptFilePos);
	BOOL LoadLPCData(CString strFilePath);
	void DrawLPCErrorInfo(CDC *pDC, CRect rc);
	void SaveMarkingParam(DProject& myProject, CString strPrjPath);
	BOOL ChangeMarkingParam(DProject& myProject, CString strPath);
	void SaveLogTransInfo();
	BOOL CheckScalVal(double dAvgScaleX, double dAvgScaleY);
	void InitFidTolData();
	BOOL CalScale(int nRefCnt, BOOL b1st, BOOL bCoarse);
	BOOL DoTransform(int nRefCnt, BOOL b1st, int nFidType, BOOL bCoarse = FALSE);
	BOOL GetCuttedAreaForZiazag(DAreaInfo *pAreaInfo, DAreaInfo *pCreateAreaInfo, int nIndex, int nTool, BOOL bRightDirection);
	BOOL GetCuttedAreaForTornado(DAreaInfo *pAreaInfo, DAreaInfo *pCreateAreaInfo, int nIndexX, int nIndexY, int nTool, BOOL bHorizontal);
	int GetAreaCount();

	BOOL GetProximateArea(int nTool, int nFidBlock); // ������ �ǵ�ȿ� ���� ����� �ʵ� ���� 
	void DrawOnlyFiducial(CDC *pDC, CRect rc, int nPanelNo, int nFidPane);
	double GetFidScale(BOOL b1stPanel, int nFidIndex);
	DAreaInfo* GetOneArea(int nTool, int nAddLineToAreaX, int nAddLineToAreaY);
	BOOL GetLineField(int nTool, int nFidBlock);
	BOOL CanvasFillForLine(int nTool, int nFidBlock);
	void CheckDataType(int nTool);
	void GetTransformPoint(double x, double y, double& dXVal, double& dYVal, BOOL b1stPanel, int nFidBlock);
	CPoint GetDrawInPos(int nStartXum, int nStartYum, int nEndXum, int nEndYum, int nLeadInLengUm);
	void ResetTempData(int* nUseFid, BOOL& bFind, int& nTotalCnt);
	void SetUseFidIndex(LPFIREHOLE pHole, LPFIRELINE pLine, int nFidKind, BOOL bUse, int* nUseFid, BOOL& bFind, int& nTotalCnt, BOOL b1st, int nFidRank);

	void ResetMinMaxData();
	void BackupRefFidPos(); // 20091029
	BOOL CalTablePos(LONG &nTargetSX, LONG &nTargetSY, LONG &nTargetEX, // 
					LONG &nLeadInTargetX, LONG &nLeadOutTargetX,
					int nPosSX, int nPosSY, int nPosEX, int nPosEY,	// fid ���� �� ��ġ��
					int nFileSX, int nFileEX,						// fid ���� �ȵ� ��ġ : ���� ���� �Ǵ�
					int nRotatePosX, int nRotatePosY,				// theta�� ȸ�� �߽�
					int nLeadIn, int nLeadOut,
					double dFidDeg);								// fid ���� angle
	BOOL IsFireHole(int nFindMethod, LPFIREHOLE pHole, LPFIRELINE pLine, int nTOOL);
	BOOL AddSubFiducial(int nIndex);
	int IsThereFid(CPoint& pointP);
	void SetProjectStatusToExcellOpen();
	void ReCalRect(BOOL bFidContain = TRUE);
	BOOL DisunifyUnit(CPoint pt1, CPoint pt2);
	void MoveUnit(int nX, int nY);
	BOOL GetUnitPos(CPoint& ptPoint);
	void AddMoveUnitsToUndoList();
	void MoveFiducial(CPoint ptPoint, CPoint ptMove);
	void ArrayCopy(int nCopyType, int nShape, int nR, int nCOffsetX, int nCOffsetY, int nX, int nY);
	void FieldCopy(int nFieldNo, int nRepeatX, int nRepeatY, double dX, double dY);
	BOOL DeleteSelectUnit();
	BOOL IsPickUnit(CPoint ptPoint, int nFidPane = 0);
	CPoint MoveUnitDP(int nX, int nY);
	BOOL MoveUnit(int nDirection);
	BOOL CheckUnitSize();
	BOOL CollectUnitOneTool(int nTool);
	UNIT_DATA* GetMinMaxData(int nXIndex, int nYIndex, int nStartX, int nStartY);
	UNIT_DATA* SkipXUnitIndex(int nX, int nY, BOOL bRightDirect);
	int SkipYUnitIndex(int nY);
	void CreateUnitArea(int nTool);
	BOOL UnitCanvasFill(int nTool);
	void ClearUnitCanvas();
	void RemoveUnitCanvas();
	void InitToolVisable();
	void DrawToolInfoRunView(CDC *pDC, CRect rc);
	CString GetChangeValue(DProject& project1);
	double GetTransAngle(BOOL b1stPanel);
	int GetDataNo(int nTool);
	void CalculateDataCount();
	void ResetFireStatus();
	void DrawDoingFireField(CDC *pDC, CRect rc);
	void ResetFidOffset();
	BOOL IsThereSelectData();
	void GetXY(int nX, int nY, int &nTransX, int &nTransY);
	void ChangeDataWithAxis();
	BOOL PuzzleOutOnlyAxisTrans();
	int IsValidParameter();
	void OnSetRefFid(CPoint pt);
	void UnSelectAll();
	void SelectGlyphWithRect(CPoint pt1, CPoint pt2, BOOL bUnitSelect);
	CPoint GetFilePos(CPoint ptPick, BOOL bTrans = FALSE);
	BOOL m_bShowSortIndex;
	int m_bSelectDrawMode;
	int m_bPathDrawMode;
	BOOL m_bShowSelectionFid;
	void ChangeViewIndex(BOOL bShowSortIndex);
	void ChangeDrawMode();
	void ChangePathDrawMode();
	CPoint GetNoAxisChangePos(CPoint pt);
	BOOL IsDrawData(DAreaInfo* pAreaInfo, double dSx, double dSy, double dEx, double dEy);
	void RotateMode();
	void FlipMode(BOOL bX);
	int m_nAxisMode;
	int m_bShowStripNo;
	int GetChangeFieldMode(DProject& myDProject);
	void RemoveAreaList();
	void ReMoveExcellon();
	void ReMoveLPCError();
	void DrawToolInfo(CDC *pDC, CRect rc);
	BOOL CalLSBValue(double& usX, double& usY, double dPosX, double dPosY, int umSize = 0);
	C2DTransform m_1stTrans;
	C2DTransform m_2ndTrans;
	C2DTransform m_RefTrans[2][MAX_FID_BLOCK];
	C2DTransform m_TablePosTrans[2][MAX_FID_BLOCK]; // 20130312
	void DeleteFidIndex();
	
	int  OnlyTransform(int nFidKind, int nFindMethod, BOOL bSelectFire, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK);

	BOOL CalFidPosForSkive(BOOL b1Use, BOOL b2Use);//20200804

	int  ApplyFidDataToShot(int nFidKind, int nFindMethod, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode = FALSE);
	int  ApplyFidDataToShot_MultiFiducial(int nFidKind, int nFindMethod, BOOL bSelectFire, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode = FALSE);
	int  ApplyFidDataToShot_Coarse(int nFidKind, int nFindMethod, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode = FALSE);
	BOOL GetSubTool(int nTool, int nSubIndex, SUBTOOLDATA& subTool);
	void HoleDrawModeDP(CDC *pDC, CRect rc, BOOL bSkip, BOOL isThereArea);
	BOOL ShrinkArea(int nFidBlock);
	BOOL SortOneField(DAreaInfo* pAreaInfo, HOLE_SORT_DATA* pHoleInfoList, LINE_SORT_DATA* pLineInfoList, int nMaxNum, int nMaxLineNum, int nAreaNo);
	BOOL SortAllField();
	BOOL SortArea(int nFidBlock, int nIndex, int& nRtIndex);
	BOOL SortAreaTest(int nFidBlock, int nIndex, int& nRtIndex);
	AREA_SORT_DATA* m_pAreaInfoList;
	AREA_SORT_DATA* m_pAreaInfoListTemp;

	BOOL m_bIsThereArea;
	int nAreaInfoListTotal;

	BOOL NumberingArea();
	void SetRealToolInfo();
	BOOL PuzzleOut();
	BOOL CollectOneTool(int nTool, int nFidBlock);
	BOOL CollectOneToolNew(int nTool, int nFidBlock);
	void MonitoringAreaSize(int nTool);
	void MonitoringHoleCount();

	void MakeOriginAreaDataWithGrid(DAreaInfo* pAreaInfoRef);
	void RemoveOriginAreaDataWithGrid();

	OriginHoleList* m_pOriginHoleList;
	LineDataList* m_pOriginLineList;


	BOOL CollectData(int nFidBlock);
	// data ó�� �Լ�
	int SkipXIndex(int nX, int nStartY, int nEndY, BOOL bRightDirect, int& nMinRangeIndex,BOOL &bDivide,  int nTool);
	int SkipYIndex(int nX, int nY, int& nMinRangeIndex,BOOL &bDivide,  int nTool);
	int SkipYIndex(int nStartX, int nEndX, int nY, int& nMinRangeIndex,BOOL &bDivide,  int nTool);
	int SkipYIndexUseDirection(int nX, int nY, int& nMinRangeIndex,BOOL &bDivide,  int nTool, BOOL bBottomUpDirection = TRUE);
	void ResetToolSumUsedFlag();
	void InitToolSumInfo();
	void CreateArea(int nTool, int nFidBlock);
	void CreateArea2(int nTool, int nFidBlock);
	BOOL IsExistBlockData();
	void AddAreaInfo(int nIndexX, int nIndexY, int nTool, BOOL bLeftToRight, int nRealUseBlock, int nFidBlock);
	int SkipXIndexForCTF(int nX, int nStartY, int nEndY, BOOL bRightDirect, int& nMinRangeIndex,BOOL &bDivide,  int nTool, int nFlag);
	int SkipYIndexForCTF(int nX, int nY, int& nMinRangeIndex,BOOL &bDivide,  int nTool, int nFlag);
	void CreateAreaForLine(int nTool, int nFidBlock);
	
	int m_nXRightEnd;
	void GetFidBlockAreaMinMax(int nFidBlock, int& nMinX, int& nMinY, int& nMaxX, int& nMaxy);

	void ClearCanvas();
	AreaList	m_Areas[MAX_TOOL_NO];
	AreaList	m_AreasRightToLeft;
	BOOL CanvasFill(int nTool, int nFidBlock);
	BOOL CanvasFill2(int nTool, int nFidBlock);
	int m_nBlockSizeX;
	int m_nBlockSizeY;

	BOOL FieldDivide(int nFidBlock);
	BOOL*			m_pbCanvas;
	UnitRectList*	m_pUnitCanvas;
//	int				m_nCanvasMinX;
//	int				m_nCanvasMinY;
//	int				m_nCanvasMaxX;
//	int				m_nCanvasMaxY;
	TOOL_SUM_INFO	m_ToolSumInfo[MAX_TOOL_NO];
	// data ó�� �Լ� ��
	void DelFiducial(CPoint pt);
	BOOL AddFiducial(CPoint pt, int nFidKind);
	BOOL AddRandomFiducial(CPoint pt);
	BOOL AddSubFiducial(CPoint pt);
	BOOL IsFidHoleGet(BOOL& bFidList, CPoint& pt, BOOL &bSkiving, BOOL bFidDraw);
	void DeleteProject();
	BOOL GetMinPos(int & nX, int & nY);
	void Move(int nX, int nY);
	void Rotate(double dDeg);
	void Flip(BOOL bX);
	void SelectGlyph(CPoint point,int nFidpane = 0);
	void SetDrawRect(CPoint pt, int nbZoomIn, int nFidPane = 0);
	void InitialDrawRatio(CRect rc, int nFidPane = 0);
	void Draw( CDC* pDC, CRect rc, BOOL bRunView = FALSE, int nFidPane = 0, int nFidIndex = -1, BOOL bDrawOnlyFid = FALSE);
	void SetMinMaxRect();
	void InitToolData();

	int    	m_nVersion;
	TCHAR	m_szProjectName[MAX_PATH_LEN]; // Project FileName
	TCHAR 	m_szFileName[MAX_PATH_LEN]; // Data FileName
	TCHAR	m_szVisionProjectName[MAX_PATH_LEN]; //Vision Project FileName
	TCHAR	m_szLotId[MAX_PATH_LEN];
	TCHAR	m_szTempFileName[MAX_PATH_LEN];
	TCHAR	m_szToolName[MAX_PATH_LEN];

	TCHAR	m_szSite[MAX_PATH_LEN];
	TCHAR	m_szManage[MAX_PATH_LEN];
	TCHAR	m_szDate[MAX_PATH_LEN];
	TCHAR	m_sznArrayNo[MAX_PATH_LEN];

	long 	m_nRangeXDisp; // ��ü ������	
	long 	m_nRangeYDisp;		
	long 	m_nDivRangeXDisp; // �� �ʵ� ������
	long 	m_nDivRangeYDisp;
	long	m_nTextRangeXDisp;
	long	m_nTextRangeYDisp;
	double m_dScaleLimitX1Pluse; // 1�� ScaleLimit
	double m_dScaleLimitX2Pluse; // 2�� ScaleLimit
	double m_dScaleLimitY1Pluse; // 1�� ScaleLimit
	double m_dScaleLimitY2Pluse; // 2�� ScaleLimit
	double m_dScaleLimitX1Minus; // 1�� ScaleLimit Minus
	double m_dScaleLimitX2Minus; // 2�� ScaleLimit Minus
	double m_dScaleLimitY1Minus; // 1�� ScaleLimit Minus
	double m_dScaleLimitY2Minus; // 2�� ScaleLimit Minus
	double m_dScaleManual; // ������ Scale��
	double m_dScaleManualY; // ������ Scale��
	short m_nScaleMode; // Auto, Manual Mode
	double m_dScaleTolerance1;
	double m_dScaleTolerance2; 
	double	m_dMeanScale;
	double m_dRefFidOffsetX;
	double m_dRefFidOffsetY;
	BOOL   m_bUseTurn;
	BOOL   m_bUseFixedAverageScale;

	double   m_dFixedAverageScaleX;
	double   m_dFixedAverageScaleY;

	double	m_dPcbThickPosX;
	double	m_dPcbThickPosY;
//	int		m_nInputUnit; // 1um 10um ��//excellon load�� ����â�� ���
//	short	m_nTZS; // TZS LZS
//	short 	m_nABS; //abs or inc
	
//	short	m_nCheckR90; 
//	BOOL	m_bCheckXMir;
//	BOOL	m_bCheckYMir;
	double	m_dPcbThick;
	double	m_dPcbThick2;
	double	m_dSkivingThickOffset;

	BOOL	m_bUseCuDirect;
//	short	m_cToolOrder;	// �۾������� Tool����
//	short	m_AxisPref; // table �̵� ���� : default ? ����ȭ
//	short	m_ScanPref; // ��ĳ�� �̵����� : default ? ����ȭ
	short	m_nSeparation; // dual , first, second
	BOOL	m_bUnitDivide;
	int		m_nMaxFidBlock;//20111123 bskim
	short	m_nVacuumType; // a,b,c,d type
	short	m_nDummyFreeType; // a,b,c,d type
	
	TCHAR			m_szJobFilePath[MAX_PATH];
	SVISIONINFO		m_FidInfo[MAX_FID_KIND_NO];
	VISION_INFO		m_HoleInfo;
	double			m_dRefPosX; // ������ ���� position
	double			m_dRefPosY;
//	HoleDataList	m_HoleData;
	GlyphExcellon	m_Glyphs;
	
//	SHOT_MODE		m_ShotMode;

	int m_nDataType[MAX_TOOL_NO];
	int m_nDataLoadStep;

	int	m_nMinX;
	int	m_nMinY;
	int	m_nMaxX;
	int	m_nMaxY;

	int m_nRadius;
	int m_nCenterX;
	int m_nCenterY;

	double m_dScale[5];				// file save (X)
 	double m_dDrawStartX[5];		// file save (X)
	double m_dDrawStartY[5];		// file save (X)
	CRect	m_rcDraw[5];			// file save (X)
	
	int m_nTotalHole;
	int m_nSelectFireHole;
	int m_nVisibleHole;
	int m_nTotalLine;
	int m_nSelectFireLine;
	int m_nVisibleLine;
	
	int	m_nSelectFireHoleShot;
	int m_nVisibleHoleShot;
	int m_nSelectFireLineShot;
	int m_nVisibleLineShot;
	int m_nRotateInfo;
	int m_nHoleFind;

	CString m_strFirstLotID;
	CString m_strSecondLotID;
	CString m_strUserID;
	int	   m_nHoleCountDraw;

	void ChangeViewHoleIndex(BOOL bShowHoleIndex);
	void BlockFirstPositionToZero();
	void SortOriginBlockHole();


	BOOL IsHoleNumber(CPoint pt, CRect rc, int& nIndex);
	void SetSelectHole(int nIndex);
	BOOL m_bShowHoleIndex;

	BOOL IsFieldNumber(CPoint pt, CRect rc, int& nIndex);
	void SetSelectData(int nIndex, BOOL bOnlyOne);
	void SetSelectFidBlock(int nFidBlock, BOOL bSelect);
	void SetTableOffset(int nIndex, double dX, double dY);
	void GetTableOffset(int nIndex, double& dX, double& dY);
	
	void DisplayUseFiducial(int nIndex);
	void ClearFiducialIndex(int nIndex);
	BOOL AddFiducialIndex(CPoint pt, int nIndex);
	BOOL DeleteFiducialIndex(CPoint pt, int nIndex);
	
	BOOL IsValidFiducialIndex();
	CPoint m_nptRefFidPos; //20091029 set ref pos  ���۽� ref fid file ��ǥ ����.
	void SetFiducial(int nIndex, BOOL bSubFid = TRUE);
	void ResetOneFiducial(int nIndex, BOOL bSubFid = TRUE);
	void ResetAllFiducial(BOOL bSubFid = TRUE);
	
	BOOL m_bSkivingMode;
	BOOL m_bMultiFidAscentOrder;
	
	DPOINT GetQuadrangleCenter(BOOL b1stPanel, BOOL bRef, int nFidCount);

	int CalculateFidScale(BOOL b1stPanel, int nFidCount);
	double GetDistance(double x1, double y1, double x2, double y2)	{return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));}
	BOOL CalculateFidAngle(BOOL b1stPanel, int nFidCount);
	BOOL ValidateRotateFiducial(DPOINT rP1, DPOINT rP2, DPOINT rP3, DPOINT transP1, DPOINT transP2, DPOINT transP3);

	CPoint m_npNewOffset[MAX_FID_BLOCK][4];

	int* m_n1stBaseFid;
	int* m_n2ndBaseFid;
	
	int* m_n1stSubFid;
	int* m_n2ndSubFid;

	CPoint m_ptPrimaryRef[4];
	CPoint m_ptPrimaryTrans[4];
	CPoint m_ptSecondaryRef[4];
	CPoint m_ptSecondaryTrans[4];
	CPoint m_ptMidRef[4];
	CPoint m_ptMidTrans[4];

	int m_nSelectedFiducial[MAX_FID_BLOCK];

	void ResetFiducialArray();
	void CalFiducialPos(int nRefCnt, int nSubCnt, BOOL b1st, BOOL bUseMidCal);
	BOOL CalTransformAndScaleCoaseAndSlive(int nRefCnt, BOOL b1st, int nFidType, BOOL bCoarse = FALSE); // Primary Fiducial�� �ִ� ��� 2D Transform �� Scale ó��
	BOOL CalTransformAndScale(int nRefCnt, int nSubCnt, BOOL b1st, int nFiducialFindType); // Primary,Secondary Fiducial�ִ� ��� 2D Transform �� Scale ó��
	void SortFiducialPos(int nRefCnt, int SubCnt);

	BOOL m_bSaveRefFidData; // FiducialParameter �⺻ ���� ����
	LPFIDDATA m_pRefFidData; // FiducialParameter �⺻ ���ð�
	double	m_dLengFinal;
	int m_CurrentMode;
	BOOL m_bArrayCopy;

	BOOL m_bFidInfoChangeForScale;
	BOOL m_bDataHeader;

	double m_dFiducialResultScore;
	double m_dFiducialResultSize;
	double m_dFiducialResultScaleX;
	double m_dFiducialResultScaleY;
};

extern DProject	gDProject;

#endif // !defined(AFX_DPROJECT_H__7A0AC780_3AE1_4A32_AA2E_20DF268CDD59__INCLUDED_)
