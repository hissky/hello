// DEasyDrillerINI.h: interface for the DEasyDrillerINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEASYDRILLERINI_H__24D72B67_E95D_4327_B9D1_E1DB14DB4170__INCLUDED_)
#define AFX_DEASYDRILLERINI_H__24D72B67_E95D_4327_B9D1_E1DB14DB4170__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DDirPath.h"
#include "DHwOption.h"

class DEasyDrillerINI  
{
public:
	DEasyDrillerINI();
	virtual ~DEasyDrillerINI();

	DHwOption	m_clsHwOption;
	DDirPath	m_clsDirPath;
};

extern DEasyDrillerINI gEasyDrillerINI;

#endif // !defined(AFX_DEASYDRILLERINI_H__24D72B67_E95D_4327_B9D1_E1DB14DB4170__INCLUDED_)
