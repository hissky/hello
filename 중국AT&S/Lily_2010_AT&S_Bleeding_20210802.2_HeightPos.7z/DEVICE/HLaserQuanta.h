// HLaserQuanta.h: interface for the HLaserQuanta class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASERQUANTA_H__F93E0254_62D0_452A_856D_6CD7A1B8AE82__INCLUDED_)
#define AFX_HLASERQUANTA_H__F93E0254_62D0_452A_856D_6CD7A1B8AE82__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum QUANTA_POWER_STATUS { POWER_OFF, POWER_ON, POWER_SLEEP,
POWER_OFF_PROCESS, POWER_ON_PROCESS, POWER_NO_PROCESS,POWER_ON_OFF_PROCESS,
//##ModelId=403400790243
					POWER_ERROR };

#include "..\device\heocard.h"

class HLaserQuanta  
{
public:
	void setErrorIgnore(bool bErrorIgnore);
	BOOL isShutterOpen();
	QUANTA_POWER_STATUS getPowerStatus();
	void setChillerOn(bool value);
	bool isErrorIgnore();
	void setShutterOpen(bool bOpen);
	void setPowerStatus(QUANTA_POWER_STATUS powerStatus);
	bool setShutterSlaveProc(int ets, int open);
	bool setShutterMasterProc(int ets, int open);
	void SetPortNo(int Port);
	bool setApcSolidShutterProc(int ets, int open);
	void setChillerOffProc();
	bool setChillerOnProc();
	void CheckPort_C();
	void setMultiControlAddress(int nIndex);
	void TestPuls();
	bool actionCommand();
	void DoModal();
	ULONG getStatusfromAutomode();
	int getStatusfromScanner();
	bool setShutterCloseProc();
	bool setShutterOpenProc();
	bool setPowerOff(int nStep);
	bool setPowerOn(int nStep);
	BOOL setQuataParam(int nFPK, int nCurrent);
	BOOL setCurrent(int nCurrent);
	BOOL Initialize();
	HLaserQuanta();
	virtual ~HLaserQuanta();

	HEocard* m_pEOCard;

	bool m_bErrorIgnore;
	bool m_bNoError;
	int m_nLampTime;
	void setLampTime(int nLampTime) { m_nLampTime = nLampTime; }		// 2laser lamp time �������� static mode ���� 
	int getLampTime() const { return m_nLampTime; }

	int m_nAlarmTime;
	int m_nErrorTime;
	void setAlarmTime(int nAlarmTime) { m_nAlarmTime = nAlarmTime; }
	int getAlarmTime() { return m_nAlarmTime; }
	void setErrorTime(int nErrorTime) { m_nErrorTime = nErrorTime; }
	int getErrorTime() { return m_nErrorTime; }

	QUANTA_POWER_STATUS m_PowerStatus;
	int m_nSupplyIndex;//ETS4 EO & YVO4 4beam
	BOOL m_bIsPowerOnStatus;

	//added by bdwoo 2006.07.14
	BOOL m_bMinus15VError;
	BOOL m_bPlus15VError;
	
	//added by bdwoo 2007.01.31
	//##ModelId=4034007A0186
	void setNoError(bool bNoError) { m_bNoError = bNoError; }
	//##ModelId=40340079037B
	bool isNoError() { return m_bNoError; }
	void setMinus15VError(BOOL bMinus15VError) { m_bMinus15VError = bMinus15VError; }
	//##ModelId=4034007A0188
	BOOL isMinus15VError() { return m_bMinus15VError; }
	//##ModelId=4034007A0189
	void setPlus15VError(BOOL bPlus15VError) { m_bPlus15VError = bPlus15VError; }
	//##ModelId=4034007A018B
	BOOL isPlus15VError() { return m_bPlus15VError; }

	BOOL m_bInterLock;
	
	void setInterLock(BOOL bInterlock)	{m_bInterLock = bInterlock;}
	BOOL isInterLock()	{ return m_bInterLock; }
	
	void setChiller(BOOL value)	{m_bChiller = value;}
	BOOL isChiller()	{ return m_bChiller; }
	void setVswr(BOOL value)	{m_bVswr = value;}
	BOOL isVswr()	{ return m_bVswr; }
	void setHighPower(BOOL value)	{m_bHighPower = value;}
	BOOL isHighPower()	{ return m_bHighPower; }
	
	void setTherMistor(BOOL value)	{m_bTherMistor = value;}
	BOOL isTherMistor()	{ return m_bTherMistor; }
	void setWarmUp(BOOL value)	{m_bWarmUp = value;}
	BOOL isWarmUp()	{ return m_bWarmUp; }
	void setSystemOk(BOOL value)	{m_bSystemOk = value;}
	BOOL isSystemOk()	{ return m_bSystemOk; }
	void setLdDriveOk(BOOL value)	{m_bLdDriveOk = value;}
	BOOL isLdDriveOk()	{ return m_bLdDriveOk; }
	
	void setOverTemp(BOOL value)	{m_bOverTemp = value;}
	BOOL isOverTemp()	{ return m_bOverTemp; }
	void setEnableFB(BOOL value)	{m_bEnableFB = value;}
	BOOL isEnableFB()	{ return m_bEnableFB; }
	void setRfPwrOn(BOOL value)	{m_bRfPwrOn = value;}
	BOOL isRfPwrOn()	{ return m_bRfPwrOn; }
	void setRfLP(BOOL value)	{m_bRfLp = value;}
	BOOL isRfLP()	{ return m_bRfLp; }
	
	void setGuideBeam(bool bUse) { m_bGuideBeam = bUse; }
	bool isGuideBeam() { return m_bGuideBeam; }

	void setSystemReady(BOOL bReady) { m_bSystemReady = bReady; }
	BOOL isSystemReady() { return m_bSystemReady; }

	bool m_bRFFlag;//hhwang 090210
	
protected:
	BOOL m_bSystemReady;
	BOOL m_bShutterOpen;
	
	ULONG m_lPortA;
	ULONG m_lPortB;
	ULONG m_lPortC;
	ULONG m_lAutoCard;
	
	//hhwang 090210
	ULONG m_lPortAPC;
	ULONG m_nLaserStatusOld_PortC;
	
	bool m_bFlagImergency;
	ULONG m_nLaserStatusOld;
	bool m_bFlag;
	bool m_bGuideBeam;
	
	BOOL m_bChiller;
	BOOL m_bVswr;
	BOOL m_bHighPower;
	
	BOOL m_bTherMistor;
	BOOL m_bWarmUp;
	BOOL m_bSystemOk;
	BOOL m_bLdDriveOk;
	
	BOOL m_bOverTemp;
	BOOL m_bEnableFB;
	BOOL m_bRfPwrOn;
	BOOL m_bRfLp;
	
	int m_iPort;	
	
	bool m_bPowerCheck;
	bool m_bShutterCheck;
	//end hhwang
};

#endif // !defined(AFX_HLASERQUANTA_H__F93E0254_62D0_452A_856D_6CD7A1B8AE82__INCLUDED_)
