// PaneSysSetupLaserScannerLarge.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "PaneManualControl.h"
#include "PaneManualCOntrolLaser.h"
#include "PaneSysSetupLaserScannerLarge.h"

#include "PaneManualControlMotorLarge.h"

#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\Device\FParameter.h"
#include "..\device\hlaser.h"
#include "..\model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\model\deasydrillerini.h"

#include "paneautorun.h"
#include "..\model\DProcessINI.h"

#include "..\model\DProject.h"
#include "DlgTableView.h"
#include "GridCtrl_src/GridCtrl.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "DlgShotTable.h"
#include "..\model\DShotTableINI.h"
#include "..\MODEL\GlobalVariable.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define		COLOR_BEAMPATH		RGB(255, 255, 162)
#define		COLOR_POWEROFFSET	RGB(243, 255, 72)
#define		COLOR_COMPENSATION	RGB(207, 255, 36)
#define		COLOR_SCANNERFACTS	RGB(255, 202, 108)
#define		COLOR_HOLEFACTS		RGB(180, 255, 255)


#define		COLOR_RED		RGB(255, 0, 0)
#define		COLOR_GREEN		RGB(0, 255, 0)

#define		COLOR_WHITE		RGB(255, 255, 255)
#define		COLOR_YELLOW		RGB(255, 255, 0)

const int		CW_SHOT		= 0;
const int		SINGLE_SHOT	= 1;

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerPusan1

IMPLEMENT_DYNCREATE(CPaneSysSetupLaserScannerLarge, CFormView)

CPaneSysSetupLaserScannerLarge::CPaneSysSetupLaserScannerLarge()
	: CFormView(CPaneSysSetupLaserScannerLarge::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupLaserScannerLarge)
	//}}AFX_DATA_INIT
	m_bMainSht = FALSE;
	m_b1stSht = FALSE;
	m_b2ndSht = FALSE;
	m_dPulseMax = 50;
	m_dPulseMin = 0.01;
	m_bUseButtonFire = FALSE;
	m_nAbs = 0;
	m_bTargetZ1 = FALSE;
	m_bTargetZ2 = FALSE;
	m_bTargetC = FALSE;
	m_bTargetC2 = FALSE;
	m_bTargetM = FALSE;
	m_bTargetM2 = FALSE;
	m_bTargetM3	= FALSE;

	m_bTargetM4	= FALSE;
	m_bTargetRot	= FALSE;
	m_bTargetTopHat	= FALSE;

	m_bTargetA = FALSE;
	m_bTargetA2 = FALSE;
	m_nMPGMode				= 0;

	strAOMTable0[0] = "No";
	strAOMTable0[1] = "[1] On";
	strAOMTable0[2] = "[1] Off";


	//2011520
	m_bTargetA = FALSE;
	m_bTargetA2 = FALSE;
	memset(m_bScannerPos, 0 , sizeof(m_bScannerPos));

	m_nOld1stAOMOffset = 0;
	m_nOld2ndAOMOffset = 0;
	m_nGroupSelectRow = 1;
	m_nSelectRow = 1;
	m_lStatusOld = FALSE;
}

CPaneSysSetupLaserScannerLarge::~CPaneSysSetupLaserScannerLarge()
{
}

void CPaneSysSetupLaserScannerLarge::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupLaserScannerPusan1)
	DDX_Control(pDX, IDC_EDIT_SCANNER_Y, m_edtScannerY);
	DDX_Control(pDX, IDC_EDIT_SCANNER_X, m_edtScannerX);
	DDX_Control(pDX, IDC_EDIT_FREQUENCY, m_edtFrequency);
	DDX_Control(pDX, IDC_EDIT_DIODE_CURRENT, m_edtCurrent);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY, m_edtAOMDelay);
	DDX_Control(pDX, IDC_EDIT_AOM_DUTY, m_edtAOMDuty);
	DDX_Control(pDX, IDC_EDIT_AOM_DELAY2, m_edtAOMDelay2);
	DDX_Control(pDX, IDC_EDIT_AOM_PROFILE, m_edtAOMProfilePath);
	DDX_Control(pDX, IDC_EDIT_SHOT_NO, m_edtShotNo);
	DDX_Control(pDX, IDC_EDIT_THERMAL_TRACK, m_edtThermalTrack);
	DDX_Control(pDX, IDC_EDIT_PULSE_WIDTH, m_edtPulseWidth);
	DDX_Control(pDX, IDC_BUTTON_SCANNER_LINE, m_btnScannerLine);
	DDX_Control(pDX, IDC_BUTTON_AOM_PROFILE, m_btnAOMOpen);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_OPEN, m_btnMainShtOpen);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_CLOSE, m_btnMainShtClose);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_OPEN_2ND, m_btnMainShtOpen2);
	DDX_Control(pDX, IDC_BUTTON_MAIN_SHT_CLOSE_2ND, m_btnMainShtClose2);
	DDX_Control(pDX, IDC_BUTTON_2ND_PANEL_SHT_OPEN, m_btn2ndPanelShtOpen);
	DDX_Control(pDX, IDC_BUTTON_2ND_PANEL_SHT_CLOSE, m_btn2ndPanelShtClose);
	DDX_Control(pDX, IDC_BUTTON_1ST_PANEL_SHT_OPEN, m_btn1stPanelShtOpen);
	DDX_Control(pDX, IDC_BUTTON_1ST_PANEL_SHT_CLOSE, m_btn1stPanelShtClose);
	DDX_Control(pDX, IDC_BUTTON_POWER_DETECTOR_ON, m_btnPDetectorShtOpen);
	DDX_Control(pDX, IDC_BUTTON_POWER_DETECTOR_OFF, m_btnPDetectorShtClose);
	DDX_Control(pDX, IDC_BUTTON_OPEN_LASER_DLG, m_btnLaserDlgShow);
	DDX_Control(pDX, IDC_BUTTON_MOVE_ATTEN, m_btnAttenMove);
	DDX_Control(pDX, IDC_BUTTON_HOME_ATTEN, m_btnAttenHome);
	DDX_Control(pDX, IDC_BUTTON_MPG_MODE, m_btnMPG);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_MOVE2, m_btnMove2);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, m_btnManualSCalPosMove);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z1, m_bTargetZ1);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z2, m_bTargetZ2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C, m_bTargetC);
	DDX_Check(pDX, IDC_CHECK_TARGET_C2, m_bTargetC2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C7, m_bTargetC3);
	DDX_Check(pDX, IDC_CHECK_TARGET_C8, m_bTargetC4);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK, m_bTargetM);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK2, m_bTargetM2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK4, m_bTargetM3);

	DDX_Check(pDX, IDC_CHECK_TARGET_MASK7, m_bTargetM4);
	DDX_Check(pDX, IDC_CHECK_TARGET_ROT, m_bTargetRot);
	DDX_Check(pDX, IDC_CHECK_TARGET_TOPHAT, m_bTargetTopHat);



	DDX_Check(pDX, IDC_CHECK_TARGET_A1, m_bTargetA);
	DDX_Check(pDX, IDC_CHECK_TARGET_A2, m_bTargetA2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_M, m_edtTargetM);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M7, m_edtTargetM3);

	DDX_Control(pDX, IDC_EDIT_TARGET_M10, m_edtTargetM4);
	DDX_Control(pDX, IDC_EDIT_TARGET_ROT, m_edtTargetRot);
	DDX_Control(pDX, IDC_EDIT_TARGET_TOPHAT, m_edtTargetTopHat);

	DDX_Control(pDX, IDC_EDIT_TARGET_C, m_edtTargetC);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2, m_edtTargetC2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C13, m_edtTargetC3);
	DDX_Control(pDX, IDC_EDIT_TARGET_C14, m_edtTargetC4);

	DDX_Control(pDX, IDC_EDIT_TARGET_Z2_2, m_edtTargetZ2_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1_2, m_edtTargetZ1_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C1_2, m_edtTargetC1_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2_2, m_edtTargetC2_2);

	DDX_Control(pDX, IDC_EDIT_TARGET_A1, m_edtTargetA);
	DDX_Control(pDX, IDC_EDIT_TARGET_A3, m_edtTargetA2);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nAbs);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_TOPHAT2, m_chkUseTophat);
	DDX_Control(pDX, IDC_CHECK_SHOT_COUNT, m_chkUseShotCount);
	DDX_Control(pDX, IDC_CHECK_DRILL_MODE, m_chkUseDrillMode);
	
	DDX_Control(pDX, IDC_CHECK_APPLY_MOVE, m_chkApplyAsc);
	DDX_Control(pDX, IDC_EDIT_AOM_OFFSET_MASTER, m_edt1stAOMOffset);
	DDX_Control(pDX, IDC_EDIT_AOM_OFFSET_SLAVE, m_edt2ndAOMOffset);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE1, m_edtVoltage1);
	DDX_Control(pDX, IDC_EDIT_VOLTAGE2, m_edtVoltage2);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_TOPHAT3, m_chkBeamPass);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_AOM, m_chkUseAom);
	
	DDX_Control(pDX, IDC_BTN_GET_LPC_DATA, m_btnLpcGet);
	DDX_Control(pDX, IDC_BUT_LPC_DIST, m_btnLpcVerify);
	DDX_Control(pDX, IDC_BUTTON_GET_LPC_STOP, m_btnLpcStop);
	DDX_Control(pDX, IDC_COMBO_HEAD, m_cmbHead);
	DDX_GridControl(pDX, IDC_GRID_AOM, m_AOMGrid);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupLaserScannerLarge, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupLaserScannerLarge)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_OPEN, OnButtonMainShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_CLOSE, OnButtonMainShtClose)
	ON_BN_CLICKED(IDC_BUTTON_1ST_PANEL_SHT_OPEN, OnButton1stPanelShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_1ST_PANEL_SHT_CLOSE, OnButton1stPanelShtClose)
	ON_BN_CLICKED(IDC_BUTTON_2ND_PANEL_SHT_OPEN, OnButton2ndPanelShtOpen)
	ON_BN_CLICKED(IDC_BUTTON_2ND_PANEL_SHT_CLOSE, OnButton2ndPanelShtClose)
	ON_BN_CLICKED(IDC_BUTTON_SCANNER_LINE, OnButtonScannerLine)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE2, OnButtonMove2)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, OnButtonManualSCalPosMove)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_MPG_MODE, OnButtonMpgMode)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_LASER_DLG, OnButtonOpenLaserDlg)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_ATTEN, OnButtonMoveAtten)
	ON_BN_CLICKED(IDC_BUTTON_HOME_ATTEN, OnButtonHomeAtten)
	ON_BN_CLICKED(IDC_BUTTON_AOM_PROFILE, OnButtonAomProfile)
	ON_BN_CLICKED(IDC_BUTTON_POWER_DETECTOR_ON, OnButtonPowerDetectorOn)
	ON_BN_CLICKED(IDC_BUTTON_POWER_DETECTOR_OFF, OnButtonPowerDetectorOff)
	ON_BN_CLICKED(IDC_BUTTON_POS0, OnButtonPos0)
	ON_BN_CLICKED(IDC_BUTTON_POS1, OnButtonPos1)
	ON_BN_CLICKED(IDC_BUTTON_POS2, OnButtonPos2)
	ON_BN_CLICKED(IDC_BUTTON_POS3, OnButtonPos3)
	ON_BN_CLICKED(IDC_BUTTON_POS4, OnButtonPos4)
	ON_BN_CLICKED(IDC_BUTTON_POS5, OnButtonPos5)
	ON_BN_CLICKED(IDC_BUTTON_POS6, OnButtonPos6)
	ON_BN_CLICKED(IDC_BUTTON_POS7, OnButtonPos7)
	ON_BN_CLICKED(IDC_BUTTON_POS8, OnButtonPos8)
	ON_BN_CLICKED(IDC_CHECK_APPLY_MOVE, OnCheckApplyAscFile)
	ON_BN_CLICKED(IDC_BTN_GET_LPC_DATA, OnButtonGetLpcData)
	ON_BN_CLICKED(IDC_BUT_LPC_DIST, OnButLpcDist)
	ON_BN_CLICKED(IDC_BUTTON_GET_LPC_STOP, OnButtonGetLpcStop)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_TOPHAT3, &CPaneSysSetupLaserScannerLarge::OnClickedCheckSubUseTophat3)

	ON_BN_CLICKED(IDC_CHECK_SUB_USE_AOM, &CPaneSysSetupLaserScannerLarge::OnClickedCheckSubUseAom)
	
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_AOM, OnAOMGridEndEdit)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_OPEN_2ND, &CPaneSysSetupLaserScannerLarge::OnBnClickedButtonMainShtOpen2nd)
	ON_BN_CLICKED(IDC_BUTTON_MAIN_SHT_CLOSE_2ND, &CPaneSysSetupLaserScannerLarge::OnBnClickedButtonMainShtClose2nd)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerLarge diagnostics

#ifdef _DEBUG
void CPaneSysSetupLaserScannerLarge::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupLaserScannerLarge::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupLaserScannerLarge message handlers

void CPaneSysSetupLaserScannerLarge::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();

	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	BOOL bShutter = (nShutter > 0) ? TRUE : FALSE;
	m_btnMainShtOpen.SetClick(bShutter);
	m_btnMainShtOpen.SetClick(!bShutter);

	m_dPulseMin = 0.01;
	m_bIsLaserOn = FALSE;
	m_bIsLaserOnFire = FALSE;
	m_bStopFire = FALSE;
	m_bLastSignal = FALSE;
	m_nLaserMode = CW_SHOT;

	m_nTimerID = 0;
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->EnableWindow(FALSE);
		m_btn2ndPanelShtOpen.EnableWindow(FALSE);
		m_btn2ndPanelShtClose.EnableWindow(FALSE);

		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		m_edtTargetZ2.EnableWindow(FALSE);
		m_edtTargetZ2_2.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		m_edtTargetZ2.ShowWindow(SW_HIDE);
		m_edtTargetZ2_2.ShowWindow(SW_HIDE);
		m_edtTargetM.ShowWindow(SW_HIDE);
		m_edtTargetM2.ShowWindow(SW_HIDE);
		m_edtTargetC.ShowWindow(SW_HIDE);
		m_edtTargetC2.ShowWindow(SW_HIDE);
		m_edtTargetC1_2.ShowWindow(SW_HIDE);
		m_edtTargetC2_2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_CHECK_TARGET_Z2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK_TARGET_C2)->ShowWindow(SW_HIDE);
		//2011520

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			m_edtTargetZ1.ShowWindow(SW_HIDE);
			m_edtTargetZ1_2.ShowWindow(SW_HIDE);

			GetDlgItem(IDC_CHECK_TARGET_Z1)->ShowWindow(SW_HIDE);

			GetDlgItem(IDC_RADIO_ABS)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_RADIO_INC)->ShowWindow(SW_HIDE);
			
			m_btnMove.ShowWindow(SW_HIDE);
			m_btnMove2.ShowWindow(SW_HIDE);
//			m_btnStop.ShowWindow(SW_HIDE);
			
			GetDlgItem(IDC_STATIC_TARGET_POS)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_STATIC_BAR)->ShowWindow(SW_HIDE);
			m_btnMPG.ShowWindow(SW_HIDE);
		}
	}


	
		GetDlgItem(IDC_BUTTON_OPEN_LASER_DLG)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_A)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_MOVE_ATTEN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_ATTEN_POS)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_HOME_ATTEN)->ShowWindow(SW_HIDE);
	

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		GetDlgItem(IDC_EDIT_DIODE_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_DIODE_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_THERMAL_TRACK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_THERMAL_TRACK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CURRENT)->ShowWindow(SW_HIDE);
	}






		GetDlgItem(IDC_STATIC_AOM_PER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CURRENT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_OFFSET_MASTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_OFFSET_SLAVE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_OFFSET_MASTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_OFFSET_SLAVE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PER4)->ShowWindow(SW_HIDE);

		if(!gSystemINI.m_sHardWare.bUseLPC)
		{
			GetDlgItem(IDC_STATIC_GRID_SIZE)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BTN_GET_LPC_DATA)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUT_LPC_DIST)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_BUTTON_GET_LPC_STOP)->ShowWindow(SW_HIDE);
		}

		/*BOOL bUseAom = m_chkUseAom.GetCheck();
		if(bUseAom)
		{
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_SHOW);
		}
		else
		{
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
		}*/
		m_chkBeamPass.SetCheck(FALSE);
		m_chkUseAom.SetCheck(FALSE);
		m_chkUseAom.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);

}

BOOL CPaneSysSetupLaserScannerLarge::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupLaserScannerLarge::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Shutter
	m_btnLaserDlgShow.SetFont( &m_fntBtn );
	m_btnLaserDlgShow.SetFlat( FALSE );
	m_btnLaserDlgShow.EnableBallonToolTip();
	m_btnLaserDlgShow.SetToolTipText( _T("Laser Setting Dlg Open") );
	m_btnLaserDlgShow.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserDlgShow.SetBtnCursor(IDC_HAND_1);

	m_btnAttenMove.SetFont( &m_fntBtn );
	m_btnAttenMove.SetFlat( FALSE );
	m_btnAttenMove.EnableBallonToolTip();
	m_btnAttenMove.SetToolTipText( _T("Attenuator Move") );
	m_btnAttenMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAttenMove.SetBtnCursor(IDC_HAND_1);

	m_btnAttenHome.SetFont( &m_fntBtn );
	m_btnAttenHome.SetFlat( FALSE );
	m_btnAttenHome.EnableBallonToolTip();
	m_btnAttenHome.SetToolTipText( _T("Attenuator Homing") );
	m_btnAttenHome.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAttenHome.SetBtnCursor(IDC_HAND_1);

	m_btnMainShtOpen.SetFont( &m_fntBtn );
	m_btnMainShtOpen.SetRectAlign( 1 ); 
	m_btnMainShtOpen.SetToolTipText( _T("Main Shutter Open") );
	m_btnMainShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btnMainShtClose.SetFont( &m_fntBtn );
	m_btnMainShtClose.SetRectAlign( 1 ); 
	m_btnMainShtClose.SetToolTipText( _T("Main Shutter Close") );
	m_btnMainShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btnMainShtOpen2.SetFont( &m_fntBtn );
	m_btnMainShtOpen2.SetRectAlign( 1 ); 
	m_btnMainShtOpen2.SetToolTipText( _T("Main2 Shutter Open") );
	m_btnMainShtOpen2.SetBtnCursor( IDC_HAND_1 );

	m_btnMainShtClose2.SetFont( &m_fntBtn );
	m_btnMainShtClose2.SetRectAlign( 1 ); 
	m_btnMainShtClose2.SetToolTipText( _T("Main2 Shutter Close") );
	m_btnMainShtClose2.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtOpen.SetFont( &m_fntBtn );
	m_btn1stPanelShtOpen.SetRectAlign( 1 ); 
	m_btn1stPanelShtOpen.SetToolTipText( _T("1st Panel Shutter Open") );
	m_btn1stPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn1stPanelShtClose.SetFont( &m_fntBtn );
	m_btn1stPanelShtClose.SetRectAlign( 1 ); 
	m_btn1stPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn1stPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtOpen.SetFont( &m_fntBtn );
	m_btn2ndPanelShtOpen.SetRectAlign( 1 ); 
	m_btn2ndPanelShtOpen.SetToolTipText( _T("2nd Panel Shutter Open") );
	m_btn2ndPanelShtOpen.SetBtnCursor( IDC_HAND_1 );

	m_btn2ndPanelShtClose.SetFont( &m_fntBtn );
	m_btn2ndPanelShtClose.SetRectAlign( 1 ); 
	m_btn2ndPanelShtClose.SetToolTipText( _T("2nd Panel Shutter Close") );
	m_btn2ndPanelShtClose.SetBtnCursor( IDC_HAND_1 );

	m_btnPDetectorShtOpen.SetFont( &m_fntBtn );
	m_btnPDetectorShtOpen.SetRectAlign( 1 ); 
	m_btnPDetectorShtOpen.SetToolTipText( _T("Power Detector Shutter Open") );
	m_btnPDetectorShtOpen.SetBtnCursor( IDC_HAND_1 );
	
	m_btnPDetectorShtClose.SetFont( &m_fntBtn );
	m_btnPDetectorShtClose.SetRectAlign( 1 ); 
	m_btnPDetectorShtClose.SetToolTipText( _T("Power Detector Shutter Close") );
	m_btnPDetectorShtClose.SetBtnCursor( IDC_HAND_1 );

	// Scanner Position
	m_btnScannerLine.SetFont( &m_fntBtn );
	m_btnScannerLine.SetRectAlign( 0 ); 
	m_btnScannerLine.SetToolTipText( _T("Fire") );
	m_btnScannerLine.SetBtnCursor( IDC_HAND_1 );

	m_btnAOMOpen.SetFont( &m_fntBtn );
	m_btnAOMOpen.SetRectAlign( 0 ); 
	m_btnAOMOpen.SetToolTipText( _T("Open AOM Profile file") );
	m_btnAOMOpen.SetBtnCursor( IDC_HAND_1 );

	GetDlgItem(IDC_CHECK_TARGET_Z1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK4)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C7)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C8)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_A1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_A2)->SetFont( &m_fntBtn );


	GetDlgItem(IDC_CHECK_TARGET_MASK7)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_ROT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_TOPHAT)->SetFont( &m_fntBtn );
	//2011520
	GetDlgItem(IDC_RADIO_ABS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_INC)->SetFont( &m_fntBtn );
	

	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMove2.SetFont( &m_fntBtn );
	m_btnMove2.SetFlat( FALSE );
	m_btnMove2.EnableBallonToolTip();
	m_btnMove2.SetToolTipText( _T("Move Tagerget Position 2") );
	m_btnMove2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove2.SetBtnCursor(IDC_HAND_1);

	m_btnManualSCalPosMove.SetFont( &m_fntBtn );
	m_btnManualSCalPosMove.SetFlat( FALSE );
	m_btnManualSCalPosMove.EnableBallonToolTip();
	m_btnManualSCalPosMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnManualSCalPosMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualSCalPosMove.SetBtnCursor(IDC_HAND_1);
	
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop fire") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);
	m_btnStop.EnableWindow( FALSE );

	// MPG Mode
	m_btnMPG.SetFont( &m_fntBtn );
	m_btnMPG.SetFlat( FALSE );
	m_btnMPG.EnableBallonToolTip();
	m_btnMPG.SetToolTipText( _T("MPG Mode Select") );
	m_btnMPG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMPG.SetBtnCursor(IDC_HAND_1);

	//use tophat
	m_chkUseTophat.SetFont( &m_fntBtn );
	m_chkUseTophat.SetImageOrg( 10, 3 );
	m_chkUseTophat.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTophat.EnableBallonToolTip();
	m_chkUseTophat.SetToolTipText( _T("Use Top Hat") );
	m_chkUseTophat.SetBtnCursor(IDC_HAND_1);
	m_chkUseTophat.EnableWindow(TRUE);

	//use shot count
	m_chkUseShotCount.SetFont( &m_fntBtn );
	m_chkUseShotCount.SetImageOrg( 10, 3 );
	m_chkUseShotCount.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseShotCount.EnableBallonToolTip();
	m_chkUseShotCount.SetToolTipText( _T("Use Shot Count") );
	m_chkUseShotCount.SetBtnCursor(IDC_HAND_1);
	m_chkUseShotCount.EnableWindow(TRUE);

	m_chkUseDrillMode.SetFont( &m_fntBtn );
	m_chkUseDrillMode.SetImageOrg( 10, 3 );
	m_chkUseDrillMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseDrillMode.EnableBallonToolTip();
	m_chkUseDrillMode.SetToolTipText( _T("Use Drill Mode") );
	m_chkUseDrillMode.SetBtnCursor(IDC_HAND_1);
	m_chkUseDrillMode.EnableWindow(TRUE);

	
	//use tophat
	m_chkBeamPass.SetFont( &m_fntBtn );
	m_chkBeamPass.SetImageOrg( 10, 3 );
	m_chkBeamPass.SetIcon( IDI_LEDON, IDI_LEDOFF ); 
	m_chkBeamPass.EnableBallonToolTip();
	m_chkBeamPass.SetToolTipText( _T("Use Long Path") );
	m_chkBeamPass.SetBtnCursor(IDC_HAND_1);
	m_chkBeamPass.EnableWindow(TRUE);

	m_chkUseAom.SetFont( &m_fntBtn );
	m_chkUseAom.SetImageOrg( 10, 3 );
	m_chkUseAom.SetIcon( IDI_LEDON, IDI_LEDOFF ); 
	m_chkUseAom.EnableBallonToolTip();
	m_chkUseAom.SetToolTipText( _T("Use Aom") );
	m_chkUseAom.SetBtnCursor(IDC_HAND_1);
#ifdef __PKG_MODIFY__
	m_chkUseAom.EnableWindow(false);
	m_chkUseAom.SetCheck(TRUE);

	
	GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_SHOW);
#else
	m_chkUseAom.EnableWindow(TRUE);
#endif




	// ApplyAsc
	m_chkApplyAsc.SetFont( &m_fntBtn );
	m_chkApplyAsc.SetImageOrg( 10, 3 );
	m_chkApplyAsc.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkApplyAsc.EnableBallonToolTip();
	m_chkApplyAsc.SetToolTipText( _T("Apply Asc File ") );
	m_chkApplyAsc.SetBtnCursor(IDC_HAND_1);
	m_chkApplyAsc.EnableWindow(TRUE);

	m_btnLpcGet.SetFont( &m_fntBtn );
	m_btnLpcGet.SetFlat( FALSE );
	m_btnLpcGet.EnableBallonToolTip();
	m_btnLpcGet.SetToolTipText( _T("Find LPC Min. Max. Data") );
	m_btnLpcGet.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcGet.SetBtnCursor(IDC_HAND_1);

	m_btnLpcVerify.SetFont( &m_fntBtn );
	m_btnLpcVerify.SetFlat( FALSE );
	m_btnLpcVerify.EnableBallonToolTip();
	m_btnLpcVerify.SetToolTipText( _T("Verify LPC Data for Various Frequency") );
	m_btnLpcVerify.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcVerify.SetBtnCursor(IDC_HAND_1);


	m_btnLpcStop.SetFont( &m_fntBtn );
	m_btnLpcStop.SetFlat( FALSE );
	m_btnLpcStop.EnableBallonToolTip();
	m_btnLpcStop.SetToolTipText( _T("Stop Process fpr LPC") );
	m_btnLpcStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcStop.SetBtnCursor(IDC_HAND_1);


	GetDlgItem(IDC_CHECK_TARGET_MASK7)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_CHECK_TARGET_ROT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_SUB_USE_TOPHAT3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_MASK4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_TOPHAT)->ShowWindow(SW_HIDE);

#ifdef __NANYA__
	GetDlgItem(IDC_CHECK_TARGET_MASK7)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_ROT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_TOPHAT)->ShowWindow(SW_SHOW);
#endif
}

void CPaneSysSetupLaserScannerLarge::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Shutter
	GetDlgItem(IDC_STATIC_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_SHT2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_SHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ATTEN_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_DETECTOR)->SetFont( &m_fntStatic );

	// Laser Mode
	GetDlgItem(IDC_STATIC_LASER_MODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PULSE_WIDTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQUENCY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DIODE_CURRENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THERMAL_TRACK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_PROFILE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_NO)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STC_AOM_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_AOM_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HEAD_SELECT)->SetFont( &m_fntStatic );
	
	// Scanner Position
	GetDlgItem(IDC_STATIC_SCANNER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_Y)->SetFont( &m_fntStatic );

	// Grid Size
	GetDlgItem(IDC_STATIC_GRID_SIZE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_TARGET_POS)->SetFont( &m_fntStatic );

	
	GetDlgItem(IDC_STATIC_AOM_OFFSET_MASTER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_OFFSET_SLAVE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE2)->SetFont( &m_fntStatic );

	m_cmbHead.SetFont( &m_fntStatic );
	m_cmbHead.SetCurSel(0);

}
void CPaneSysSetupLaserScannerLarge::InitGrid()
{
	/*
	if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	{
		CRect rt2;
		GetDlgItem(IDC_LIST_GROUP_INFO)->GetWindowRect(rt2);
		ScreenToClient(rt2);
		m_AOMGrid.Create(rt2,this,0xffffff);
	}
	*/
	m_AOMGrid.SetEditable(TRUE);
	m_AOMGrid.SetListMode(FALSE);
	m_AOMGrid.EnableDragAndDrop(FALSE);
	m_AOMGrid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_AOMGrid.SetHeaderSort(FALSE);
	m_AOMGrid.SetSingleRowSelection(FALSE);
	m_AOMGrid.SetFixedRowCount(1);        //1���� ��
	m_AOMGrid.SetFixedColumnCount(1);    //1���� ��
	m_AOMGrid.SetRowResize(FALSE);		  //ũ�� ����
	m_AOMGrid.SetColumnResize(FALSE);	  //ũ�� ����

}
void CPaneSysSetupLaserScannerLarge::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(180, "Arial Bold");

	// Laser Mode
	m_edtPulseWidth.SetFont( &m_fntEdit );
	m_edtPulseWidth.SetForeColor( BLACK_COLOR );
	m_edtPulseWidth.SetBackColor( WHITE_COLOR );
	m_edtPulseWidth.SetReceivedFlag( 3 );

		m_edtPulseWidth.SetWindowText( _T("20") );

	m_edtFrequency.SetFont( &m_fntEdit );
	m_edtFrequency.SetForeColor( BLACK_COLOR );
	m_edtFrequency.SetBackColor( WHITE_COLOR );
	m_edtFrequency.SetReceivedFlag( 1 );

		m_edtFrequency.SetWindowText( _T("1000") );

	m_edtCurrent.SetFont( &m_fntEdit );
	m_edtCurrent.SetForeColor( BLACK_COLOR );
	m_edtCurrent.SetBackColor( WHITE_COLOR );
	m_edtCurrent.SetReceivedFlag( 3 );
	m_edtCurrent.SetWindowText( _T("90.0") );

	m_edtThermalTrack.SetFont( &m_fntEdit );
	m_edtThermalTrack.SetForeColor( BLACK_COLOR );
	m_edtThermalTrack.SetBackColor( WHITE_COLOR );
	m_edtThermalTrack.SetReceivedFlag( 1 );
	m_edtThermalTrack.SetWindowText( _T("2525") );

	m_edtAOMDelay.SetFont( &m_fntEdit );
	m_edtAOMDelay.SetForeColor( BLACK_COLOR );
	m_edtAOMDelay.SetBackColor( WHITE_COLOR );
	m_edtAOMDelay.SetReceivedFlag( 3 );
	m_edtAOMDelay.SetWindowText( _T("0.0") );

	m_edtAOMDuty.SetFont( &m_fntEdit );
	m_edtAOMDuty.SetForeColor( BLACK_COLOR );
	m_edtAOMDuty.SetBackColor( WHITE_COLOR );
	m_edtAOMDuty.SetReceivedFlag( 3 );
	m_edtAOMDuty.SetWindowText( _T("20") );

	m_edtAOMDelay2.SetFont( &m_fntEdit );
	m_edtAOMDelay2.SetForeColor( BLACK_COLOR );
	m_edtAOMDelay2.SetBackColor( WHITE_COLOR );
	m_edtAOMDelay2.SetReceivedFlag( 3 );
	m_edtAOMDelay2.SetWindowText( _T("0.0") );
	
	m_edtShotNo.SetFont( &m_fntEdit );
	m_edtShotNo.SetForeColor( BLACK_COLOR );
	m_edtShotNo.SetBackColor( WHITE_COLOR );
	m_edtShotNo.SetReceivedFlag( 1 );
	m_edtShotNo.SetWindowText( _T("1") );

//	m_edtAOMProfilePath.SetFont( &m_fntEdit );
	m_edtAOMProfilePath.EnableWindow(FALSE);
	m_edtAOMProfilePath.SetWindowText( _T("D:\\ViaHole\\AOM\\Default.AOM") );


	{
		m_edtPulseWidth.EnableWindow(FALSE);
	
			GetDlgItem(IDC_STATIC_DIODE_CURRENT)->EnableWindow(FALSE);
			m_edtCurrent.EnableWindow(FALSE);
		

		GetDlgItem(IDC_STATIC_THERMAL_TRACK)->EnableWindow(FALSE);
		m_edtThermalTrack.EnableWindow(FALSE);
	}

	// Scanner
	m_edtScannerX.SetFont( &m_fntEdit );
	m_edtScannerX.SetForeColor( BLACK_COLOR );
	m_edtScannerX.SetBackColor( WHITE_COLOR );
	m_edtScannerX.SetReceivedFlag( 1 );
	m_edtScannerX.SetWindowText( _T("32767") );

	m_edtScannerY.SetFont( &m_fntEdit );
	m_edtScannerY.SetForeColor( BLACK_COLOR );
	m_edtScannerY.SetBackColor( WHITE_COLOR );
	m_edtScannerY.SetReceivedFlag( 1 );
	m_edtScannerY.SetWindowText( _T("32767") );

	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );
	
	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );
	
	// Target M
	m_edtTargetM.SetFont( &m_fntEdit );
	m_edtTargetM.SetReceivedFlag( 3 );
	m_edtTargetM.SetWindowText( _T("0.0") );

	// Target M2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );
	
	// Target M3
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );



	m_edtTargetM4.SetFont( &m_fntEdit );
	m_edtTargetM4.SetReceivedFlag( 3 );
	m_edtTargetM4.SetWindowText( _T("0.0") );

	m_edtTargetRot.SetFont( &m_fntEdit );
	m_edtTargetRot.SetReceivedFlag( 3 );
	m_edtTargetRot.SetWindowText( _T("0.0") );

	m_edtTargetTopHat.SetFont( &m_fntEdit );
	m_edtTargetTopHat.SetReceivedFlag( 3 );
	m_edtTargetTopHat.SetWindowText( _T("0.0") );
	// Target C
	m_edtTargetC.SetFont( &m_fntEdit );
	m_edtTargetC.SetReceivedFlag( 3 );
	m_edtTargetC.SetWindowText( _T("0.0") );

	// Target C2
	m_edtTargetC2.SetFont( &m_fntEdit );
	m_edtTargetC2.SetReceivedFlag( 3 );
	m_edtTargetC2.SetWindowText( _T("0.0") );

	// Target C3
	m_edtTargetC3.SetFont( &m_fntEdit );
	m_edtTargetC3.SetReceivedFlag( 3 );
	m_edtTargetC3.SetWindowText( _T("0.0") );

	// Target C4
	m_edtTargetC4.SetFont( &m_fntEdit );
	m_edtTargetC4.SetReceivedFlag( 3 );
	m_edtTargetC4.SetWindowText( _T("0.0") );
	
	// Target A
	m_edtTargetA.SetFont( &m_fntEdit );
	m_edtTargetA.SetReceivedFlag( 3 );
	m_edtTargetA.SetWindowText( _T("0.0") );

	// Target A2
	m_edtTargetA2.SetFont( &m_fntEdit );
	m_edtTargetA2.SetReceivedFlag( 3 );
	m_edtTargetA2.SetWindowText( _T("0.0") );
	///////
	// Target Z1_2
	m_edtTargetZ1_2.SetFont( &m_fntEdit );
	m_edtTargetZ1_2.SetReceivedFlag( 3 );
	m_edtTargetZ1_2.SetWindowText( _T("0.0") );
	
	// Target Z2_2
	m_edtTargetZ2_2.SetFont( &m_fntEdit );
	m_edtTargetZ2_2.SetReceivedFlag( 3 );
	m_edtTargetZ2_2.SetWindowText( _T("0.0") );
	
	// Target C_2
	m_edtTargetC1_2.SetFont( &m_fntEdit );
	m_edtTargetC1_2.SetReceivedFlag( 3 );
	m_edtTargetC1_2.SetWindowText( _T("0.0") );

	// Target C2
	m_edtTargetC2_2.SetFont( &m_fntEdit );
	m_edtTargetC2_2.SetReceivedFlag( 3 );
	m_edtTargetC2_2.SetWindowText( _T("0.0") );
	//////

	//AOM Offset 1st
	m_edt1stAOMOffset.SetFont( &m_fntEdit );
	m_edt1stAOMOffset.SetReceivedFlag(1);
	m_edt1stAOMOffset.SetWindowText(_T("50"));
	
	//AOM Offset 2nd
	m_edt2ndAOMOffset.SetFont( &m_fntEdit );
	m_edt2ndAOMOffset.SetReceivedFlag(1);
	m_edt2ndAOMOffset.SetWindowText(_T("50"));
	
	//voltage1
	m_edtVoltage1.SetFont( &m_fntEdit );
	m_edtVoltage1.SetReceivedFlag(3);

	CString str;
	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV);
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV2);

	m_edtVoltage1.SetWindowText(str);
	
	//voltage2
	m_edtVoltage2.SetFont( &m_fntEdit );
	m_edtVoltage2.SetReceivedFlag(3);

	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby2ndV);
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		str.Format(_T("%.1f"), gSystemINI.m_sSystemDump.dStandby1stV2);
	m_edtVoltage2.SetWindowText(str);

	m_edtTargetM3.ShowWindow(SW_HIDE);
	m_edtTargetM4.ShowWindow(SW_HIDE);
	m_edtTargetRot.ShowWindow(SW_HIDE);
	m_edtTargetTopHat.ShowWindow(SW_HIDE);

#ifdef __NANYA__
	m_edtTargetM4.ShowWindow(SW_HIDE);
	m_edtTargetRot.ShowWindow(SW_HIDE);
	m_edtTargetTopHat.ShowWindow(SW_SHOW);
#endif
}

void CPaneSysSetupLaserScannerLarge::OnButtonMainShtOpen() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	gDeviceFactory.GetLaser()->ShutterOpen(TRUE,USE_HEAD_1);

	::Sleep(1500);
	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_1);
	m_btnMainShtOpen.SetClick(bOpen);
	m_btnMainShtClose.SetClick(!bOpen);
	//m_btnMainShtOpen.SetClick( TRUE );
	//m_btnMainShtClose.SetClick( FALSE );
}

void CPaneSysSetupLaserScannerLarge::OnButtonMainShtClose() 
{
	gDeviceFactory.GetLaser()->ShutterOpen(FALSE,USE_HEAD_1);

	::Sleep(1500);
	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_1);
	m_btnMainShtOpen.SetClick(bOpen);
	m_btnMainShtClose.SetClick(!bOpen);
	//m_btnMainShtOpen.SetClick( FALSE );
	//m_btnMainShtClose.SetClick( TRUE );
}

void CPaneSysSetupLaserScannerLarge::OnButton1stPanelShtOpen() 
{	
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}


	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_MASTER, TRUE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn1stPanelShtOpen.SetClick( bStatus );
	m_btn1stPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerLarge::OnButton1stPanelShtClose() 
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_MASTER, FALSE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn1stPanelShtOpen.SetClick( bStatus );
	m_btn1stPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerLarge::OnButton2ndPanelShtOpen() 
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_SLAVE, TRUE);

	::Sleep(1000);

	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;

	m_btn2ndPanelShtOpen.SetClick( bStatus );
	m_btn2ndPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerLarge::OnButton2ndPanelShtClose() 
{	
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif

	gDeviceFactory.GetMotor()->SetOutPort(nBaseAdd + PORT_SHUTTER_SLAVE, FALSE);
	
	::Sleep(1000);
	
	BOOL bStatus;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
		bStatus = TRUE;
	else
		bStatus = FALSE;
	
	m_btn2ndPanelShtOpen.SetClick( bStatus );
	m_btn2ndPanelShtClose.SetClick( !bStatus );
}

void CPaneSysSetupLaserScannerLarge::OnButtonScannerLine() 
{




#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

//	BOOL bFlag = m_btnScannerLine.GetClick();
//	m_btnScannerLine.SetClick( !bFlag );

	UpdateData(TRUE);

	HEocard* pEOCard = gDeviceFactory.GetEocard();

	EnableAllButton(FALSE);

	if(!CheckPulseWidth())
	{
		ErrMessage(_T("Duty setting Error : 0.01 <= Duty <= 50 %"));
		EnableAllButton(TRUE);
		return;
	}

	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		gDeviceFactory.GetEocard()->SetMasterSlave(TRUE);
	else
		gDeviceFactory.GetEocard()->SetMasterSlave(FALSE);

	CString strVal;
	m_edtAOMDelay.GetWindowText(strVal);
	//gVariable.m_sgToolTable.nSelectShot[0] = 0;

	gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_M[0] = atof(strVal);
	m_edtAOMDelay2.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_S[0] = atof(strVal);

	gVariable.m_sgShotGroupTable.m_sShotParam[0].nAOMNum_M[0] = 10;
	gVariable.m_sgShotGroupTable.m_sShotParam[0].nAOMNum_S[0] = 10;

	double dVoltage1 = 0, dVoltage2 = 0;
	m_edtVoltage1.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_M[0] = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_S[0] = atof(strVal);
	
/*
	if(!gDeviceFactory.GetEocard()->SetVoltage(gVariable.m_sgShotGroupTable.dVoltage_M[0], gVariable.m_sgShotGroupTable.dVoltage_S[0]))
	{
		ErrMsgDlg(STDGNALM117);
		EnableAllButton(TRUE);
		return;
	}*/

	BOOL bTophat = m_chkUseTophat.GetCheck();
	if(!gDeviceFactory.GetMotor()->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		EnableAllButton(TRUE);
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();
	BOOL bUseAom = m_chkUseAom.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		EnableAllButton(TRUE);
		return ;
	}

//	if(m_bLastSignal == FALSE)
	{
		
		double dLaserXPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_X );
		double dLaserYPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_Y );
		if(m_nUserLevel <= 2)
		{
			if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
				dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				CString strM;
				strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
					gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
					gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
				ErrMessage(strM);
				EnableAllButton(TRUE);
				return;
			}
		}
		if(dLaserXPos >= gSystemINI.m_sSystemDevice.dTableLimitMaxX ||
			dLaserXPos <= gSystemINI.m_sSystemDevice.dTableLimitMinX ||
			dLaserYPos >= gSystemINI.m_sSystemDevice.dTableLimitMaxY ||
			dLaserYPos <= gSystemINI.m_sSystemDevice.dTableLimitMinY )
		{
			CString strM;
			strM.Format(_T("Laser fire position is out of table.\n Table Min X = %.3f, Table Min Y = %.3f\n Table Max X = %.3f, Table Max Y = %.3f"),
				gSystemINI.m_sSystemDevice.dTableLimitMinX, gSystemINI.m_sSystemDevice.dTableLimitMinY, 
				gSystemINI.m_sSystemDevice.dTableLimitMaxX, gSystemINI.m_sSystemDevice.dTableLimitMaxY);
			ErrMessage(strM);
			EnableAllButton(TRUE);
			return;
		}

		m_bUseButtonFire = TRUE;
		UpdateData();
		FParameter fPara;
		pEOCard->GetParameter(&fPara);
		m_usOldPulseWidth = (unsigned short)fPara.dDuty;
		m_usOldFrequency = fPara.Frequency;
		
		double dPulseWidth;
		m_edtPulseWidth.GetWindowText(strVal);
		dPulseWidth = atof(strVal);
		
		int nFrequency, nShotNo;
		m_edtFrequency.GetWindowText(strVal);
		nFrequency = atoi(strVal);
		m_edtShotNo.GetWindowText(strVal);
		nShotNo = atoi(strVal);

		m_edtAOMProfilePath.GetWindowText(strVal);
		memcpy(fPara.cAOMFilePath, strVal, strVal.GetLength()+1);
		
		m_nOld1stAOMOffset = gSystemINI.m_sSystemDevice.nDualAom1stOffset;
		m_nOld2ndAOMOffset = gSystemINI.m_sSystemDevice.nDualAom2ndOffset;
		
		m_edt1stAOMOffset.GetWindowText(strVal);
		gSystemINI.m_sSystemDevice.nDualAom1stOffset = atoi(strVal);
		
		m_edt2ndAOMOffset.GetWindowText(strVal);
		gSystemINI.m_sSystemDevice.nDualAom2ndOffset = atoi(strVal);

		CString strMessage, strSub;
		strMessage.Format(_T("Laser Beam Hole Fire "));
		

		
			fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
			//fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
			strSub.Format(_T("| Freq. = %d | Duty = %.2f"), nFrequency, dPulseWidth);
			//fPara.dAOMDelay = dAOMDelay;
			//fPara.dAOMDuty = dAOMDuty;

//			if(fPara.dAOMDelay + fPara.dAOMDuty > dPulseWidth + 50)
//			{
//				ErrMessage(IDS_ERR_AOM);
//				EnableAllButton(TRUE);
//				return;
//			}
		
		
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strSub));
		
		//gDeviceFactory.GetMotor()->IonizerOn(TRUE);
		gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, TRUE);

/*		gDeviceFactory.GetMotor()->HoodOpen(TRUE);
		if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
		{
			gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
			ErrMessage(_T("Dust Suction Shutter On Error."));
			EnableAllButton(TRUE);
			return;
		}
*/		
		fPara.Frequency = static_cast<unsigned>(nFrequency);
		pEOCard->SetParameter(&fPara, 0, 0,0);

//		m_btnScannerLine.SetWindowText(_T("Stop"));
		m_btnScannerLine.EnableWindow(FALSE);
		m_btnStop.EnableWindow( TRUE );
		m_bLastSignal = TRUE;
		
		double dFireTime = 1.0 / nFrequency * (nShotNo - 0.5);
		double dWaitTime;


		Sleep(100);
		int nPosX, nPosY;
		
		m_edtScannerX.GetWindowText(strVal);
		nPosX = atoi(strVal);
		
		m_edtScannerY.GetWindowText(strVal);
		nPosY = atoi(strVal);
		int nSel = m_cmbHead.GetCurSel();
//		gDeviceFactory.GetEocard()->DrillMove(FALSE, nPosX, nPosY, FALSE, nPosX, nPosY, FALSE);
		gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
		
		if(m_chkUseDrillMode.GetCheck())
		{
			DrillGrid();
		}
		else
		{
			CCorrectTime MyTestTime;
			MyTestTime.StartTime();
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
			pEOCard->LaserOnOff(TRUE,m_cmbHead.GetCurSel());
			
			do 
			{
				dWaitTime = MyTestTime.PresentTime();
				if(dWaitTime > dFireTime) 
					break;
				MessageLoop();
				::Sleep(0);

			} while(!m_bStopFire);

			m_bStopFire = FALSE;

	//	}		
	//	else
	//	{
			pEOCard->LaserOnOff(FALSE,m_cmbHead.GetCurSel());
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
		}
		BOOL bOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
		{
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && bOn)
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
				{
					gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
					gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
					ErrMsgDlg(STDGNALM781);
					EnableAllButton(TRUE);
					return;
				}
			}
		}
		//gDeviceFactory.GetMotor()->IonizerOn(FALSE);
		gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);

		gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
		gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
		
		fPara.dDuty = m_usOldPulseWidth;
		fPara.Frequency = m_usOldFrequency;

		m_bLastSignal = FALSE;

		m_btnScannerLine.EnableWindow(TRUE);
		m_btnStop.EnableWindow( FALSE );

//		m_btnScannerLine.SetWindowText(_T("Fire"));
//		m_btnScannerLine.EnableWindow(TRUE);
		m_bUseButtonFire = FALSE;

/*		if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
		{
			gDeviceFactory.GetMotor()->HoodOpen(FALSE);
			if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
			{
			ErrMessage(_T("Dust Suction Shutter Off Error."));
			}
		}
*/
		EnableAllButton(TRUE);
	}
}

void CPaneSysSetupLaserScannerLarge::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	m_bStopFire = TRUE;
}

void CPaneSysSetupLaserScannerLarge::OnButtonMpgMode() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
		m_btnMPG.SetToolTipText("B1, B2, B3, B4");

	}
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 2;
		m_btnMPG.SetWindowText("MPG Mode 3");

		m_btnMPG.SetToolTipText("M1,M2");
		

	}
	else if(m_nMPGMode == 2)
	{

		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");

	}
	else if(m_nMPGMode == 3)
	{

	}
	else
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
	}

	pMotor->SetOutPort(PORT_MPG_MODE, m_nMPGMode);
}

HBRUSH CPaneSysSetupLaserScannerLarge::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_SHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HEAD_SELECT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_GRID_SIZE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TARGET_POS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupLaserScannerLarge::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupLaserScannerLarge::SetShutterStatus()
{

	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_1);
	m_btnMainShtOpen.SetClick(bOpen);
	m_btnMainShtClose.SetClick(!bOpen);
	BOOL bOpen2 = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_2);
	m_btnMainShtOpen2.SetClick(bOpen2);
	m_btnMainShtClose2.SetClick(!bOpen2);

	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
	{
		m_btn1stPanelShtOpen.SetClick(TRUE);
		m_btn1stPanelShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn1stPanelShtOpen.SetClick(FALSE);
		m_btn1stPanelShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn1stPanelShtOpen.SetClick(FALSE);
		m_btn1stPanelShtClose.SetClick(FALSE);
	}

	nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter == 1)
	{
		m_btn2ndPanelShtOpen.SetClick(TRUE);
		m_btn2ndPanelShtClose.SetClick(FALSE);
	}
	else if(nShutter == 2)
	{
		m_btn2ndPanelShtOpen.SetClick(FALSE);
		m_btn2ndPanelShtClose.SetClick(TRUE);
	}
	else
	{
		m_btn2ndPanelShtOpen.SetClick(FALSE);
		m_btn2ndPanelShtClose.SetClick(FALSE);
	}

	//
	LONG lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO3);
	

		lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO7);



		if(lStatus & 0x0020)
			m_btnPDetectorShtOpen.SetClick( 0 );
		else
			m_btnPDetectorShtOpen.SetClick( 1 );
	
		if(lStatus & 0x0010)
			m_btnPDetectorShtClose.SetClick( 0 );
		else
			m_btnPDetectorShtClose.SetClick( 1 );	
	
	//

	if(m_nTimerID == 0)
	{

		m_nMPGMode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pMotor->GetMPGMode();

//		int nMode = gDeviceFactory.GetMotor()->GetMPGMode();
//		m_nMPGMode = nMode;
	
		if(m_nMPGMode == 0)
		{

			m_btnMPG.SetWindowText("MPG Mode 2");

			m_btnMPG.SetToolTipText("B1, B2");

		}
		else if(m_nMPGMode == 1)
		{
			m_btnMPG.SetWindowText("MPG Mode 3");
			m_btnMPG.SetToolTipText("M1,M2,M3");
		}
		else if(m_nMPGMode == 2)
		{
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");

		}
		else if(m_nMPGMode == 3)
		{

		}
		else
		{
			//m_nMPGMode = 0;
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
		}
		m_nTimerID = SetTimer(111, 100, NULL);
	}



}

void CPaneSysSetupLaserScannerLarge::StopExternalLaser()
{
	if(m_nTimerID)
	{
		gDeviceFactory.GetEocard()->MoveToCenter();
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}


}

void CPaneSysSetupLaserScannerLarge::OnTimer(UINT nIDEvent) 
{
#ifndef __TEST__
	if(!m_bUseSelfShot || m_bUseButtonFire)
		return;

	HEocard* pEOCard = gDeviceFactory.GetEocard();
#ifndef __MP920_MOTOR__
	BYTE bLaserOn = gDeviceFactory.GetMotor()->GetExternalLaser();
#else
	BYTE bLaserOn = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
#endif
	BOOL bApply1 = pEOCard->GetApplyCalibrationFile(0);
	BOOL bApply2 = pEOCard->GetApplyCalibrationFile(1);

	if(bApply1 || bApply2)
		m_chkApplyAsc.SetCheck(TRUE);

	
	CString strVal;
	double dAOMDelay, dAOMDuty = 0;
	m_edtAOMDelay.GetWindowText(strVal);
	dAOMDelay = atof(strVal);
	//m_edtAOMDuty.GetWindowText(strVal);
	//dAOMDuty = atof(strVal);

	double dVoltage1, dVoltage2;
	m_edtVoltage1.GetWindowText(strVal);
	dVoltage1 = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	dVoltage2 = atof(strVal);


	m_edtVoltage1.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_M[0] = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_S[0] = atof(strVal);


#ifndef __MP920_MOTOR__
	DeviceMotor *pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(bLaserOn & 0x01)
	{
		BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
		if(nShutter == 1)
			gDeviceFactory.GetEocard()->SetMasterSlave(TRUE);
		else
			gDeviceFactory.GetEocard()->SetMasterSlave(FALSE);

/*
		if(!gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2))
		{
			ErrMsgDlg(STDGNALM117);
			return;
		}*/

		double dLaserXPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_X );
		double dLaserYPos = gDeviceFactory.GetMotor()->GetPosition( AXIS_Y );
		if(m_nUserLevel <= 2)
		{
			if(dLaserXPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserXPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
				dLaserYPos >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
				dLaserYPos <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
			{
				CString strM;
				strM.Format(_T("Laser Fire Pos Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
					gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
					gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
				ErrMessage(strM);
				EnableAllButton(TRUE);
				return;
			}
		}

		if(m_bLastSignal == FALSE)
		{
			if(!CheckPulseWidth())
			{
				ErrMessage(_T("Duty setting Error : 0.01 <= Duty <= 50 %"));
				CFormView::OnTimer(nIDEvent);
				return;
			}

			UpdateData();
			FParameter fPara;
			pEOCard->GetParameter(&fPara);
			m_usOldPulseWidth = (USHORT)fPara.dDuty;
			m_usOldFrequency = fPara.Frequency;

			double dPulseWidth;
			m_edtPulseWidth.GetWindowText(strVal);
			dPulseWidth = atof(strVal);

			int nFrequency, nShotNo;
			m_edtFrequency.GetWindowText(strVal);
			nFrequency = atoi(strVal);
			m_edtShotNo.GetWindowText(strVal);
			nShotNo = atoi(strVal);

			m_nOld1stAOMOffset = gSystemINI.m_sSystemDevice.nDualAom1stOffset;
			m_nOld2ndAOMOffset = gSystemINI.m_sSystemDevice.nDualAom2ndOffset;

			m_edt1stAOMOffset.GetWindowText(strVal);
			gSystemINI.m_sSystemDevice.nDualAom1stOffset = atoi(strVal);

			m_edt2ndAOMOffset.GetWindowText(strVal);
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = atoi(strVal);

			m_edtAOMProfilePath.GetWindowText(strVal);
			memcpy(fPara.cAOMFilePath, strVal, strVal.GetLength()+1);


			CString strVal;
			m_edtAOMDelay.GetWindowText(strVal);
			gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_M[0] = atof(strVal);
			m_edtAOMDelay2.GetWindowText(strVal);
			gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_S[0] = atof(strVal);


			CString strMessage, strSub;
			strMessage.Format(_T("Laser Beam Hole Fire "));


				fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
				//fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
				strSub.Format(_T("| Freq. = %d | Duty = %.2f"), nFrequency, dPulseWidth);
				fPara.dAOMDelay = dAOMDelay;
				fPara.dAOMDuty = dAOMDuty;
			

			fPara.Frequency = static_cast<unsigned>(nFrequency);
			pEOCard->SetParameter(&fPara);

			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strSub));

			// SelfFire�� ����
			//			gDeviceFactory.GetMotor()->HoodOpen(TRUE);
			//			if(!gDeviceFactory.GetMotor()->IsHoodOK(TRUE))
			//			{
			//				ErrMessage(_T("Dust Suction Shutter On Error."));
			//				return;
			//			}

			m_btnScannerLine.EnableWindow(FALSE);
			m_btnStop.EnableWindow( TRUE );
			m_bLastSignal = TRUE;

			double dFireTime = 1.0 / nFrequency * (nShotNo - 0.5);
			double dWaitTime;
			/*
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{

				if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
					{
						gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
						gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
						ErrMsgDlg(STDGNALM781);
						return;
					}
				}
			}
		*/
			Sleep(100);
			int nPosX, nPosY;

			m_edtScannerX.GetWindowText(strVal);
			nPosX = atoi(strVal);

			m_edtScannerY.GetWindowText(strVal);
			nPosY = atoi(strVal);

			//			gDeviceFactory.GetEocard()->DrillMove(FALSE, nPosX, nPosY, FALSE, nPosX, nPosY, FALSE);
			gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY);
			if(!m_chkUseDrillMode.GetCheck())
			{
				CCorrectTime MyTestTime;
				MyTestTime.StartTime();
				gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);
				pEOCard->LaserOnOff(TRUE);

				TRACE("Start dFireTime %.3f\n",dFireTime);
				BYTE bSelfFire;
				do 
				{
					dWaitTime = MyTestTime.PresentTime();
					if(m_chkUseShotCount.GetCheck())
					{
						if(dWaitTime > dFireTime) 
						{
							m_bStopFire = TRUE;
							TRACE("dWaitTime %.3f\n",dWaitTime);
							break;
						}
					}
					else
					{
#ifndef __MP920_MOTOR__
						bSelfFire = gDeviceFactory.GetMotor()->GetExternalLaser();
#else
						bSelfFire = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
#endif

						if(!(bSelfFire & 0x01))
							break;
					}
					//MessageLoopWait(1);
					::Sleep(1);

				} while(!m_bStopFire);

				TRACE("m_bStopFire\n");

				m_bStopFire = FALSE;

				pEOCard->LaserOnOff(FALSE);

				do 
				{
#ifndef __MP920_MOTOR__
					bSelfFire = gDeviceFactory.GetMotor()->GetExternalLaser();
#else
					bSelfFire = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
#endif

					if(!(bSelfFire & 0x01))
						break;
					MessageLoop();
					::Sleep(0);

				} while(!m_bStopFire);

			}
			else
			{
				DrillGrid();
				BYTE bSelfFire;
				do 
				{
#ifndef __MP920_MOTOR__
					bSelfFire = gDeviceFactory.GetMotor()->GetExternalLaser();
#else
					bSelfFire = gDeviceFactory.GetMotor()->GetCurrentStatus(EXTERNAL_LASER);
#endif

					if(!(bSelfFire & 0x01))
						break;
					MessageLoop();
					::Sleep(0);

				} while(!m_bStopFire);

			}
			gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);
			BOOL bOn = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pLaser->GetUserDummyOn();
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && bOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
						gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;
						ErrMsgDlg(STDGNALM781);
						return;
					}
				}
			}
			//gDeviceFactory.GetMotor()->IonizerOn(FALSE);
			gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);

			gSystemINI.m_sSystemDevice.nDualAom1stOffset = m_nOld1stAOMOffset;
			gSystemINI.m_sSystemDevice.nDualAom2ndOffset = m_nOld2ndAOMOffset;

			fPara.dDuty = m_usOldPulseWidth;
			fPara.Frequency = m_usOldFrequency;

			m_bLastSignal = FALSE;

			m_btnScannerLine.EnableWindow(TRUE);
			m_btnStop.EnableWindow( FALSE );
		}		
		//		m_bLastSignal = TRUE;
	}
/*	else
	{
		if(m_bLastSignal == TRUE)
		{
			pEOCard->LaserOnOff(FALSE);

			FParameter fPara;
			fPara.dDuty = m_usOldPulseWidth;
			fPara.Frequency = m_usOldFrequency;
			pEOCard->SetParameter(&fPara);
			m_btnScannerLine.SetWindowText(_T("Fire"));
			m_btnScannerLine.EnableWindow(TRUE);

// SelfFire�� ����
//			gDeviceFactory.GetMotor()->HoodOpen(FALSE);
//			if(!gDeviceFactory.GetMotor()->IsHoodOK(FALSE))
//			{
//				ErrMessage(_T("Dust Suction Shutter Off Error."));
//			}
		}
		m_bLastSignal = FALSE;
	}
*/	
#endif
	CString str, str2;

	CFormView::OnTimer(nIDEvent);

	switch(m_nMPGMode )
	{
		case 0:
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
			break;
		case 1:
			m_btnMPG.SetWindowText("MPG Mode 2");
			m_btnMPG.SetToolTipText("B1, B2, M2, M3");
			break;
		case 2:
			m_btnMPG.SetWindowText("MPG Mode 3");
			m_btnMPG.SetToolTipText("M1, TOP");
			break;
	}

}

BOOL CPaneSysSetupLaserScannerLarge::CheckParam()
{
	UpdateData(TRUE);
	
	BOOL bFlag = TRUE;
	
	CString strVal;
	m_edtFrequency.GetWindowText(strVal);
	int nFrequency = atoi(strVal); 
	
	m_edtCurrent.GetWindowText(strVal);
	double dCurrent = atof(strVal);
	
	return bFlag;
}

BOOL CPaneSysSetupLaserScannerLarge::CheckPulseWidth()
{
	UpdateData(TRUE);

	CString strVal;
	m_edtPulseWidth.GetWindowText(strVal);
	double dPulseWidth = atof(strVal);

	int nFrequency;
	m_edtFrequency.GetWindowText(strVal);
	nFrequency = atoi(strVal);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if (dPulseWidth / (30000 / nFrequency) >= m_dPulseMin &&
			dPulseWidth / (30000 / nFrequency) <= m_dPulseMax)
			return TRUE;
		else
			return FALSE;
	}
	return TRUE;
}

void CPaneSysSetupLaserScannerLarge::MessageLoop()
{
	MSG msg;
	
	if(::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		CRect rtPos;
		GetDlgItem(IDC_BUTTON_MAIN_SHT_OPEN)->GetWindowRect( rtPos ); // ���� �ִ� tab�� disable ���� �ʾƼ� �߰�
		if(msg.pt.y < rtPos.top)
			return; // ���� �ִ� tab�� disable ���� �ʾƼ� �߰�
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}

void CPaneSysSetupLaserScannerLarge::EnableAllButton(BOOL bEnable)
{
	EnableButton(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, !bEnable);
}

void CPaneSysSetupLaserScannerLarge::EnableButton(BOOL bUse)
{

		m_btnMainShtOpen.EnableWindow(bUse);
		m_btnMainShtClose.EnableWindow(bUse);
		m_btnMainShtOpen2.EnableWindow(bUse);
		m_btnMainShtClose2.EnableWindow(bUse);
	

		m_btn1stPanelShtOpen.EnableWindow(bUse);
		m_btn1stPanelShtClose.EnableWindow(bUse);
	
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() != 1)
	{
		m_btn2ndPanelShtOpen.EnableWindow(bUse);
		m_btn2ndPanelShtClose.EnableWindow(bUse);
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow( bUse );
	}

	m_btnPDetectorShtOpen.EnableWindow(bUse);
	m_btnPDetectorShtClose.EnableWindow(bUse);

	m_btnMPG.EnableWindow( bUse );
		


			m_edtPulseWidth.EnableWindow(bUse);
		m_edtFrequency.EnableWindow(bUse);
		m_edtAOMDelay.EnableWindow(bUse);
		m_edtAOMDuty.EnableWindow(bUse);
		m_edtShotNo.EnableWindow(bUse);
	
	
	m_edtScannerX.EnableWindow(bUse);
	m_edtScannerY.EnableWindow(bUse);
	
	m_btnScannerLine.EnableWindow(bUse);
	m_btnAOMOpen.EnableWindow(bUse);

	//
	GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C2)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C7)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C8)->EnableWindow( bUse );
	//2011520
	
	m_btnMove.EnableWindow( bUse );
	m_btnMove2.EnableWindow( bUse );
	m_btnManualSCalPosMove.EnableWindow( bUse );
	// MPG Mode
	m_btnLpcGet.EnableWindow( bUse );
	m_btnLpcStop.EnableWindow( !bUse );
}

void CPaneSysSetupLaserScannerLarge::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
		EnableButton(FALSE);
		m_bUseSelfShot = FALSE;
		break;
	case 1:
	case 2:
	case 3:
		EnableButton(TRUE);
		m_bUseSelfShot = TRUE;
		break;
	}
}

void CPaneSysSetupLaserScannerLarge::OnButtonMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if(!m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2 
		&&!m_bTargetA && !m_bTargetA2 && !m_bTargetM3&& !m_bTargetM4&& !m_bTargetRot&& !m_bTargetTopHat)		//2011520
		return;
	
	EnableAllButton( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X
	double dPosX, dPosY;
	pMotor->GetPosition(AXIS_X, dPosX);
	pMotor->GetPosition(AXIS_Y, dPosY);
	
	// Z1
	m_edtTargetZ1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2
	m_edtTargetZ2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2 
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );
	
	// M3 
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );


	m_edtTargetM4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM4 = GetMovePos( AXIS_M4, dTemp, bAbs, m_bTargetM4 );


	// C
	m_edtTargetC.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );

	//C2
	m_edtTargetC2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	//C3
	m_edtTargetC3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC3 = GetMovePos( AXIS_C3, dTemp, bAbs, m_bTargetC3 );

	//C4
	m_edtTargetC4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC4 = GetMovePos( AXIS_C4, dTemp, bAbs, m_bTargetC4 );

	// A1
	m_edtTargetA.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA1 = GetMovePos( AXIS_A1, dTemp, bAbs, m_bTargetA );

	// A2
	m_edtTargetA2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA2 = GetMovePos( AXIS_A2, dTemp, bAbs, m_bTargetA2 );

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	BOOL bTophat = m_chkUseTophat.GetCheck();

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();// = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	BOOL bUseAom = m_chkUseAom.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}


	m_edtTargetRot.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dRot = GetMovePos( AXIS_ROT, dTemp, bAbs, m_bTargetRot );

	m_edtTargetTopHat.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dTopHat = GetMovePos( AXIS_TOPHAT, dTemp, bAbs, m_bTargetTopHat );

	BOOL bRet = pMotor->MotorMoveXYZMB(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2,dPosC, dPosC2,dPosC3, dPosC4, TRUE, AUTORUN_MOVE, FALSE);
	//BOOL bRet = pMotor->MotorMoveXYZMCA3_B(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosM4, dPosC, dPosC2, dRot, dTopHat, TRUE, AUTORUN_MOVE, FALSE,TRUE);
	
	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_C1 + IND_C2 + IND_C3 + IND_C4);

	EnableAllButton(TRUE);
	
	if( FALSE != nRet )
	{
//		m_btnStop.EnableWindow( FALSE );
	}
}

void CPaneSysSetupLaserScannerLarge::OnButtonMove2() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if(!m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2 
		&&!m_bTargetA && !m_bTargetA2 && !m_bTargetM3)		//2011520
		return;
	
	EnableAllButton( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X
	double dPosX, dPosY;
	pMotor->GetPosition(AXIS_X, dPosX);
	pMotor->GetPosition(AXIS_Y, dPosY);
	
	// Z1
	m_edtTargetZ1_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2
	m_edtTargetZ2_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2 
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );
	
	// M3 
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );

	m_edtTargetM4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM4 = GetMovePos( AXIS_M4, dTemp, bAbs, m_bTargetM4 );



	// C
	m_edtTargetC1_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );

	//C2
	m_edtTargetC2_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	BOOL bTophat = m_chkUseTophat.GetCheck();

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		ErrMessage(_T("Tophat shutter move error!"));
		return;
	}
	BOOL bLaserPath = m_chkBeamPass.GetCheck();// = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	BOOL bUseAom = m_chkUseAom.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}


	m_edtTargetRot.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dRot = GetMovePos( AXIS_ROT, dTemp, bAbs, m_bTargetRot );

	m_edtTargetTopHat.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dTopHat = GetMovePos( AXIS_TOPHAT, dTemp, bAbs, m_bTargetTopHat );


	BOOL bRet = pMotor->MotorMoveXYZMCA3_B(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosM4, dPosC, dPosC2, dRot, dTopHat, TRUE, AUTORUN_MOVE, FALSE,TRUE);
	
	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A1 + IND_A2+ IND_M4 + IND_ROT + IND_TOPHAT);

	EnableAllButton(TRUE);
	
	if( FALSE != nRet )
	{
//		m_btnStop.EnableWindow( FALSE );
	}
}

double CPaneSysSetupLaserScannerLarge::GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if( FALSE == bUse )
		return pMotor->GetPosition( nAxisNo );
	
	double dPos = 0.;
	
	if( FALSE == bAbs ) // Relative Movement
	{
		dPos = dMovePos + pMotor->GetPosition( nAxisNo );
	}
	else // ABS Movement
		dPos = dMovePos;
	
	return dPos;
}

void CPaneSysSetupLaserScannerLarge::OnButtonOpenLaserDlg() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetLaser()->OpenPowerDlg();
}

void CPaneSysSetupLaserScannerLarge::OnButtonMoveAtten() 
{
	// TODO: Add your control notification handler code here

}

void CPaneSysSetupLaserScannerLarge::OnButtonHomeAtten() 
{

}

void CPaneSysSetupLaserScannerLarge::OnButtonAomProfile() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] = _T("AOM File (*.aom)|*.aom|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.aom"), NULL, dwFlags, szFilter);

	CString strPath;
	m_edtAOMProfilePath.GetWindowText(strPath);
	int nLength = strPath.GetLength();
	int nIndex;
	if(nLength > 0)
	{
		nIndex = strPath.ReverseFind(_T('\\'));
		strPath = strPath.Left(nIndex);
	}
	else
		strPath = gEasyDrillerINI.m_clsDirPath.GetRootDir() + "AOM\\";

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	m_edtAOMProfilePath.SetWindowText(dlg.GetPathName());
}

void CPaneSysSetupLaserScannerLarge::OnButtonPowerDetectorOn() 
{

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, TRUE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, TRUE, TRUE);
#endif

	::Sleep(1000);
	
	LONG lStatus = 0;

		lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO7);


		if(lStatus & 0x0020)
			m_btnPDetectorShtOpen.SetClick( 0 );
		else
			m_btnPDetectorShtOpen.SetClick( 1 );
	
		if(lStatus & 0x0010)
			m_btnPDetectorShtClose.SetClick( 0 );
		else
			m_btnPDetectorShtClose.SetClick( 1 );	

}

void CPaneSysSetupLaserScannerLarge::OnButtonPowerDetectorOff() 
{

#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->SetOutPort(PORT_POWER_METER, FALSE);
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_POWER_METER, FALSE, TRUE);
#endif
	
	::Sleep(1000);
	
	LONG lStatus = 0;

		lStatus = gDeviceFactory.GetMotor()->GetCurrentError(STATUS_IO7);
	

		if(lStatus & 0x0020)
			m_btnPDetectorShtOpen.SetClick( 0 );
		else
			m_btnPDetectorShtOpen.SetClick( 1 );
	
		if(lStatus & 0x0010)
			m_btnPDetectorShtClose.SetClick( 0 );
		else
			m_btnPDetectorShtClose.SetClick( 1 );	
}

int CPaneSysSetupLaserScannerLarge::GetMPGMode()
{
	return m_nMPGMode;
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos0()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);

}
void CPaneSysSetupLaserScannerLarge::OnButtonPos1()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);

}
void CPaneSysSetupLaserScannerLarge::OnButtonPos2()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 0;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos3()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos4()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos5()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 32767;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos6()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 0; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
		
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos7()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 32767; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}
void CPaneSysSetupLaserScannerLarge::OnButtonPos8()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	
	ResetScannerBtn();
	int nPosX = 65535; 
	int nPosY = 65535;

	CString str;
	str.Format(_T("%d"), nPosX);
	m_edtScannerX.SetWindowText( str );
	str.Format(_T("%d"), nPosY);
	m_edtScannerY.SetWindowText( str );
	int nSel = m_cmbHead.GetCurSel();
	gDeviceFactory.GetEocard()->jump_Use_vm(nPosX, nPosY, nPosX, nPosY, nPosX, nPosY, nPosX, nPosY,nSel);
	
}

void CPaneSysSetupLaserScannerLarge::ResetScannerBtn()
{
	memset(m_bScannerPos, 0 , sizeof(m_bScannerPos));

	((CButton*)GetDlgItem(IDC_BUTTON_POS0))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS1))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS3))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS4))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS5))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS6))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS7))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_BUTTON_POS8))->SetCheck(FALSE);

}
void CPaneSysSetupLaserScannerLarge::OnCheckApplyAscFile()
{
	return;

	BOOL bCheck = m_chkApplyAsc.GetCheck();
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, bCheck);
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, bCheck);

}

void CPaneSysSetupLaserScannerLarge::OnButtonManualSCalPosMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

	EnableAllButton( FALSE );


	// X, Y
	double dPosX, dPosY;
	dPosX = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2  + 10;
	dPosY = (gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY)/2;

	pMotor->MoveXY(dPosX,dPosY);

	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y);

	EnableAllButton(TRUE);

	if(!nRet)
	{
		ErrMessage(_T("Move Fail"));
	}
}



BOOL CPaneSysSetupLaserScannerLarge::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Align) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupLaserScannerLarge::OnClickedCheckSubUseTophat3()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bLaserPath = m_chkBeamPass.GetCheck();
	BOOL bUseAom = m_chkUseAom.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}
}

void CPaneSysSetupLaserScannerLarge::OnButtonGetLpcStop() 
{
	// TODO: Add your control notification handler code here
	m_bLPCStop = TRUE;
}

BOOL CPaneSysSetupLaserScannerLarge::SaveLPCFile(int nMinTime, int nMinDuty, int nTimeNo, int nDutyNo, double* pdValMin, double* pdValMax)
{
	FILE* fp = NULL;
	double dCalGap = 1.0;
	CString strFileName = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	strFileName +=  _T("LPC.table");
	
	if (NULL == fopen_s(&fp, strFileName, "w"))
	{
		fprintf(fp, "%d\t%d\t%f\n", 4, nDutyNo, dCalGap);
		
		// index = GridSize * nX + nY
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < nDutyNo; j++)
			{
				fprintf(fp, "%lf\t%lf\t%lf\t%lf\n",
					nMinTime + i * dCalGap,
					nMinDuty + j * dCalGap,
					pdValMin[0 + j * nTimeNo],
					pdValMax[0 + j * nTimeNo]);
			}
		}
		fclose(fp);
		
		gDeviceFactory.GetEocard()->UpdateLPCCalibrationFile(gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
		
		CString strEvent;
		strEvent = _T("Saved LPC Table calibration file.");
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strFileName));
		
		return TRUE;
	}
	else
	{
		ErrMessage(_T("Can not LPC write file"));
		return FALSE;
	}
}

void CPaneSysSetupLaserScannerLarge::OnButLpcDist() 
{

	// TODO: Add your control notification handler code here
	m_bLPCStop = FALSE;
	BYTE nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
	if(nShutter == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_MASTER, FALSE);

	BYTE nShutter2 = gDeviceFactory.GetMotor()->GetCurrentShutter2();
	if(nShutter2 == 1)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SHUTTER_SLAVE, FALSE);

	if(nShutter == 1 || nShutter2 == 1)
	{
		::Sleep(1000);
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter1();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 1st panel shutter"));
			return;
		}
		nShutter = gDeviceFactory.GetMotor()->GetCurrentShutter2();
		if(nShutter == 1)
		{
			ErrMessage(_T("Close 2nd panel shutter"));
			return;
		}
	}
	BOOL bAnyLaserOn;
	int nHead = 0;
	if(gDProject.m_nSeparation == USE_DUAL)
		nHead = 3;
	else if(gDProject.m_nSeparation == USE_1ST)
		nHead = 1;
	else if(gDProject.m_nSeparation == USE_2ND)
		nHead = 2;
	if(!gDeviceFactory.GetLaser()->IsPowerOn(bAnyLaserOn,nHead))
	{
		ErrMessage(_T("First Turn on Laser"));
		return;
	}

	if(gSystemINI.m_sSystemDump.nStandbyDuty / (1000000. / gSystemINI.m_sSystemDump.nStandbyMaxFreq) * 100  >
		 gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent)
	{
		ErrMessage(_T("Too high Standby Duty or Standby Max. Freq."));
		return;
	}

	// fire
	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
//	subTool.nDrawStep = 5;
	subTool.nJumpStep = 5;
	subTool.nJumpStepPeriod = 30;
	subTool.nDrawStepPeriod = 20;
	subTool.nCornerDelay = 10;
	subTool.nJumpDelay = 0;
	subTool.nLineDelay = 10;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1500;
	subTool.nFPS = 0;
	// Drill
	subTool.nShotMode = 1;
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 0;
//	subTool.dShotDuty[MAX_SHOT];
//	subTool.dShotAOMDelay[MAX_SHOT];
//	subTool.dShotAOMDuty[MAX_SHOT];
	subTool.nMask = 1;
	subTool.bUseAperture = 0;
	subTool.nApertureBurst = 1;
	subTool.nThermalTrack = 0;
	subTool.dZOffset = 0;
	subTool.bUseTophat = FALSE;
	subTool.cFilePath[0] = NULL;

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		memcpy(subTool.cAOMFilePath[i], str, str.GetLength()+1);

	// 
	int nMinDuty = gSystemINI.m_sSystemDump.nStandbyInpositionTime, nMaxDuty = gSystemINI.m_sSystemDump.nStandbyDuty;
	int nDutyNo = nMaxDuty - nMinDuty + 1;
	gDeviceFactory.GetEocard()->ShotDataReset();
	double dMinVal = 0, dMaxVal = 0;
	int	nDist[2000];

	for(int kkk = 0; kkk < 3; kkk++)
	{
		CTime ct = CTime::GetCurrentTime();
		CString strPath;
		strPath.Format(_T("%s\\LPCTable_%2d%2d%2d%2d%2d_%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetTempDir(), 
			ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(),ct.GetSecond());
		CString strLogFile;
		
		FILE* pfile;
		errno_t err = fopen_s(&pfile, strPath, "w+");
		if(err != 0)
			pfile = NULL;

		gDeviceFactory.GetEocard()->ShotDataReset();

		for(int i = 0; i < 1000; i++)
		{
			nDist[i] = (abs(rand()) * 2) % 65535;
			gDeviceFactory.GetEocard()->DownloadShotData2_Use_vm(nDist[i], 32767, 32767, 32767, TRUE, TRUE, 1);
			if(i > 0)
				TRACE("%d\n", abs(nDist[i] - nDist[i-1]));
		}

		for(int i = nMinDuty; i <= nMaxDuty; i++)
		{
			strLogFile.Format(_T("%s%d.txt"), strPath, i);
			FILE* pfile2;
			errno_t err2 = fopen_s(&pfile2, strLogFile , "w+");
			if(err2 != 0)
				pfile2 = NULL;
	
			subTool.dShotMinFreq[0] = subTool.dShotMaxFreq[0] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;
			subTool.dShotDuty[0] = i;
			subTool.dShotAOMDelay[0] = 0;
			subTool.dShotAOMDuty[0] = i;

			subTool.dShotDutyOffsetM[0] = 0;
			subTool.dShotDutyOffsetS[0] = 0;
			subTool.dShotVolOffsetM[0] = 0;
			subTool.dShotVolOffsetS[0] = 0;

			gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool, TRUE);

			gDeviceFactory.GetEocard()->FieldPreStart();
			gDeviceFactory.GetEocard()->FieldStart(FALSE);
			
			BOOL bResult = TRUE;
			::Sleep(100);
			do
			{
				::Sleep(1);
				bResult = gDeviceFactory.GetEocard()->IsDSPBusy();

				if(gDeviceFactory.GetEocard()->IsMotorFault())
				{
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Stop : Scanner Motor Fault"));
					return;
				}
					
				MessageLoop();
				if(m_bLPCStop)
				{
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Stop"));
					return;
				}
			}while(bResult); 

			if(!gDeviceFactory.GetEocard()->SetLPCDataReadReady())
			{
				ErrMessage(_T("Error SetLPCDataReadReady"));
				if(pfile) fclose(pfile);
				if(pfile2) fclose(pfile2);
				return;
			}
				
/*			TLpc_Buffer*  pLPC_Data;
			pLPC_Data = gDeviceFactory.GetEocard()->GetLPCResult();

			if(pLPC_Data == NULL)
			{
				if(pfile) fclose(pfile);
				if(pfile2) fclose(pfile2);
				ErrMessage(_T("Get data Fail"));
				return;
			}
				
			dMinVal = 1000000;
			dMaxVal = -1000000;

			for(int k = 1; k < (int)pLPC_Data->HoleCount.nCount; k++)
			{
				if(pfile2) 
				{
					fprintf(pfile2,_T("duty = \t%d\t  \t%.3f\t %.3f\t Dist LSB \t%d\t\n"), 
						i,	(double)(pLPC_Data->HoleInfo[k].nBand0_Peak),
						(double)(pLPC_Data->HoleInfo[k].nBand0_Peak) * 5. / 4096, 
						nDist[k] - nDist[k-1]);
				}
				if(dMinVal > pLPC_Data->HoleInfo[k].nBand0_Peak)
					dMinVal = pLPC_Data->HoleInfo[k].nBand0_Peak;
				if(dMaxVal < pLPC_Data->HoleInfo[k].nBand0_Peak)
					dMaxVal = pLPC_Data->HoleInfo[k].nBand0_Peak;
			}
*/
			if(pfile) 
				fprintf(pfile, _T("duty = \t%d\t  \t%.3f\t %.3f\t\n"), 
									i, dMinVal, dMaxVal);

			::Sleep(10);
			if(pfile2) fclose(pfile2);
		}
		if(pfile) fclose(pfile);
	}
	ErrMessage(_T("End"));

}


void CPaneSysSetupLaserScannerLarge::OnButtonGetLpcData() 
{

	// TODO: Add your control notification handler code here
	m_bLPCStop = FALSE;
	BOOL bAnyLaserOn;
	int nHead = 0;
	if(gDProject.m_nSeparation == USE_DUAL)
		nHead = 3;
	else if(gDProject.m_nSeparation == USE_1ST)
		nHead = 1;
	else if(gDProject.m_nSeparation == USE_2ND)
		nHead = 2;
	if(!gDeviceFactory.GetLaser()->IsPowerOn(bAnyLaserOn,nHead))
	{
		ErrMessage(_T("First Turn on Laser"));
		return;
	}

	if(gSystemINI.m_sSystemDump.nStandbyDuty / (1000000. / gSystemINI.m_sSystemDump.nStandbyMaxFreq) * 100  >
		gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent)
	{
		ErrMessage(_T("Too high Standby Duty or Standby Max. Freq."));
		return;
	}
	EnableAllButton(FALSE);
	// fire
	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
	//	subTool.nDrawStep = 5;
	subTool.nJumpStep = 5;
	subTool.nJumpStepPeriod = 30;
	subTool.nDrawStepPeriod = 20;
	subTool.nCornerDelay = 10;
	subTool.nJumpDelay = 0;
	subTool.nLineDelay = 10;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1500;
	subTool.nFPS = 0;
	// Drill
	subTool.nShotMode = 1;
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 0;
	//	subTool.dShotDuty[MAX_SHOT];
	//	subTool.dShotAOMDelay[MAX_SHOT];
	//	subTool.dShotAOMDuty[MAX_SHOT];
	subTool.nMask = 1;
	subTool.bUseAperture = 0;
	subTool.nApertureBurst = 1;
	subTool.nThermalTrack = 0;
	subTool.dZOffset = 0;
	subTool.bUseTophat = FALSE;
	subTool.cFilePath[0] = NULL;

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		memcpy(subTool.cAOMFilePath[i], str, str.GetLength()+1);

	// 
	int nMinDuty = gSystemINI.m_sSystemDump.nStandbyInpositionTime, nMaxDuty = gSystemINI.m_sSystemDump.nStandbyDuty;
	int nDutyNo = nMaxDuty - nMinDuty + 1;
	int nTimeNo = 2;
	double* pdValMin, *pdValMax;
	pdValMin = new double [nDutyNo * nTimeNo];
	pdValMax = new double [nDutyNo * nTimeNo];
	double dMinVal, dMaxVal;
	int nMaxTime = 100;//min(nMaxTime, 1000);
	int nMinTime = 100;

	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(1))
	{
		ErrMsgDlg(STDGNALM445);
		EnableAllButton(TRUE);
		return;
	}

	CTime ct = CTime::GetCurrentTime();
	CString strPath;
	strPath.Format(_T("%s\\LPCTable_%2d%2d%2d%2d%2d_%2d.txt"), gEasyDrillerINI.m_clsDirPath.GetTempDir(), 
		ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute(),ct.GetSecond());
	CString strLogFile;

	FILE* pfile;
	errno_t err = fopen_s(&pfile, strPath, "w+");
	if(err != 0)
		pfile = NULL;

	for(int i = nMinDuty; i <= nMaxDuty; i++)
	{
		strLogFile.Format(_T("%s%d.txt"), strPath, i);
		FILE* pfile2;
		errno_t err2 = fopen_s(&pfile2, strLogFile , "w+");
		if(err2 != 0)
			pfile2 = NULL;

		for(int j =0; j < nTimeNo; j++ )
		{
			if(j == 0)
			{
				gDeviceFactory.GetEocard()->ShotDataReset();
				subTool.dShotMinFreq[0] = subTool.dShotMaxFreq[0] = (gSystemINI.m_sSystemDump.nStandbyMaxFreq);
				for(int i = 0; i < 10000; i++)
				{
					gDeviceFactory.GetEocard()->DownloadShotData2_Use_vm(32767, 32767, 32767, 32767, TRUE, TRUE, 1);
				}
			}
			else
			{
				gDeviceFactory.GetEocard()->ShotDataReset();
				subTool.dShotMinFreq[0] = subTool.dShotMaxFreq[0] = (gSystemINI.m_sSystemDump.nStandbyMinFreq);
				for(int i = 0; i < 5000; i++)
				{
					gDeviceFactory.GetEocard()->DownloadShotData2_Use_vm(32767, 32767, 32767, 32767, TRUE, TRUE, 1);
				}
			}

			subTool.dShotDuty[0] = i;
			subTool.dShotAOMDelay[0] = 0;
			subTool.dShotAOMDuty[0] = i;

			subTool.dShotDutyOffsetM[0] = 0;
			subTool.dShotDutyOffsetS[0] = 0;
			subTool.dShotVolOffsetM[0] = 0;
			subTool.dShotVolOffsetS[0] = 0;

			gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool, FALSE, TRUE);

			::Sleep(1000);
			for(int nRepeat = 0; nRepeat < 1; nRepeat++)
			{
				gDeviceFactory.GetEocard()->FieldPreStart();
				gDeviceFactory.GetEocard()->FieldStart(FALSE);

				BOOL bResult = TRUE;
				::Sleep(100);
				do
				{
					::Sleep(1);
					bResult = gDeviceFactory.GetEocard()->IsDSPBusy();

					if(gDeviceFactory.GetEocard()->IsMotorFault())
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop : Scanner Motor Fault"));
						EnableAllButton(TRUE);
						return;
					}

					MessageLoop();
					if(m_bLPCStop)
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop"));
						EnableAllButton(TRUE);
						return;
					}
				}while(bResult); 

				if(!gDeviceFactory.GetEocard()->SetLPCDataReadReady())
				{
					delete pdValMax;
					delete pdValMin;
					ErrMessage(_T("Error SetLPCDataReadReady"));
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					EnableAllButton(TRUE);
					return;
				}

				do
				{
					::Sleep(100);
					bResult = gDeviceFactory.GetEocard()->IsDSPBusy();

					MessageLoop();
					if(m_bLPCStop)
					{
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Stop"));
						EnableAllButton(TRUE);
						return;
					}
				}while(bResult);

				TLpc_Buffer*  pLPC_Data;
				pLPC_Data = gDeviceFactory.GetEocard()->GetLPCResult();

				if(pLPC_Data == NULL)
				{
					delete pdValMax;
					delete pdValMin;
					if(pfile) fclose(pfile);
					if(pfile2) fclose(pfile2);
					ErrMessage(_T("Get data Fail"));
					EnableAllButton(TRUE);
					return;
				}

				dMinVal = 1000000;
				dMaxVal = -1000000;
				for(int k = 5; k < (int)pLPC_Data->HoleCount.nTotal; k++)
				{
					if(pfile2) 
					{
						fprintf(pfile2,_T("duty =\t%d\t Repeat = %d minTime = %d Val[%d] =\t %.3f \n"), 
							i, nRepeat, nMinTime + j,
							( i - nMinDuty) * nTimeNo + j,
							(double)(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16));
					}

					if(pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16 >= 4096 || pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16 < 0)
					{
						delete pdValMax;
						delete pdValMin;
						if(pfile) fclose(pfile);
						if(pfile2) fclose(pfile2);
						ErrMessage(_T("Sensor Limit Over (over 4096) : Change Sensor Position or Lenz."));
						EnableAllButton(TRUE);
						return;
					}
					if(dMinVal > pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
						dMinVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
					if(dMaxVal < pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16)
						dMaxVal = pLPC_Data->HoleInfo[k].nBand0_LaserPower_S16;
				}

				if(j == 0 && nRepeat == 0)
				{
					pdValMin[ ( i - nMinDuty) * nTimeNo + 0 ] = dMinVal;
					pdValMax[ ( i - nMinDuty) * nTimeNo + 0 ] = dMaxVal;
				}
				else
				{
					if(pdValMin[ ( i - nMinDuty) * nTimeNo + 0 ] > dMinVal)
						pdValMin[ ( i - nMinDuty) * nTimeNo + 0 ] = dMinVal;
					if(pdValMax[ ( i - nMinDuty) * nTimeNo + 0 ] < dMaxVal)
						pdValMax[ ( i - nMinDuty) * nTimeNo + 0 ] = dMaxVal;
				}
			}

			if(pfile && j != 0) 
				fprintf(pfile, _T("duty =\t%d\t minTime =\t%d\t Val[%d] =\t%.3f\t %.3f \t\n"), 
				i, nMinTime,
				( i - nMinDuty) * nTimeNo + 0,
				pdValMin[ ( i - nMinDuty) * nTimeNo + 0 ],
				pdValMax[ ( i - nMinDuty) * nTimeNo + 0 ]);

			::Sleep(10);
		}
		if(pfile2)  fclose(pfile2);
	}
	if(pfile) fclose(pfile);

	if(!SaveLPCFile(100, nMinDuty, nTimeNo, nDutyNo, pdValMin, pdValMax))
	{
		delete pdValMax;
		delete pdValMin;
		EnableAllButton(TRUE);
		return;
	}
	delete pdValMax;
	delete pdValMin;
	ErrMessage(_T("End Get LPC data"));
	EnableAllButton(TRUE);

}
void CPaneSysSetupLaserScannerLarge::InsertAOMListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_AOMGrid.SetColumnCount(SHOT_AOM_TABLE0_COLUMN_COUNT2);
		for(int i = 0 ;i < SHOT_AOM_TABLE0_COLUMN_COUNT2; i++)  
		{
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strAOMTable0[i];
			m_AOMGrid.SetItem(&Item);	
			m_AOMGrid.AutoSize();
		}
	}
	else
	{
		//error
	}
}
void CPaneSysSetupLaserScannerLarge::SetAOMDrawMember(int listcount)
{
	int i;

	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	InsertAOMListComumn(0,TABLE0);
	m_AOMGrid.SetRowCount(2 + 9);
	for( i = 9 ; i >= 0 ;i--)
	{
		InsertAOMGridValue(Item, 0, TABLE0, i);
	}

	CRect rect;
	m_AOMGrid.GetWindowRect(&rect);
	int nWidth = 0;
	for(int i = 0; i <m_AOMGrid.GetColumnCount(); i++)
	{
		nWidth += m_AOMGrid.GetColumnWidth(i);
	}

	if(nWidth == 0)
		nWidth = rect.Width();
	m_AOMGrid.SetWindowPos(NULL, 0, 0, nWidth + 5, rect.Height(), SWP_NOMOVE);

}

void CPaneSysSetupLaserScannerLarge::InsertAOMGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	GV_ITEM Gvitem1;
	GV_ITEM Gvitem2;

	COLORREF pColor1 = COLOR_GREEN;
	Gvitem1.nState = NULL;

	int nUseShotCount = gVariable.m_sgShotGroupTable.nTotalShotCount[m_nGroupSelectRow-1];

	int nUseCount = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[m_nSelectRow-1]-1;

	if(nUseCount < ColCount || nUseShotCount ==0)
	{

		pColor1 = COLOR_WHITE;
		Gvitem1.nState = GVIS_READONLY;
	}

	COLORREF pColor2 = COLOR_GREEN;
	Gvitem2.nState = NULL;

	int nUseCount2 = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[m_nSelectRow-1]-1;

	if(nUseCount2 < ColCount || nUseShotCount == 0)
	{

		pColor2 = COLOR_WHITE;
		Gvitem1.nState = GVIS_READONLY;
	}


	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;


		//strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].nInfoId[ColCount]);
		strData.Format(_T("%d"),  ColCount);



		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;


		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));

		DWORD oldMask = Gvitem.mask;
		Gvitem.mask = GVIF_TEXT|GVIF_FORMAT;
		m_AOMGrid.SetItem(&Gvitem);
		Gvitem.mask = oldMask;
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_ON_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.nState = Gvitem1.nState;

		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_AOMGrid.SetItem(&Gvitem);
//		m_AOMGrid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor1);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_OFF_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.nState = Gvitem1.nState;

		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_AOMGrid.SetItem(&Gvitem);
//		m_AOMGrid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor1);
		ColumnNo++;

	}

	m_AOMGrid.AutoSize();
}

void CPaneSysSetupLaserScannerLarge::OnAOMGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	
	CPoint posAOMClicked;

	posAOMClicked.x = pItem->iColumn;
	posAOMClicked.y = pItem->iRow - 1;
	str = m_AOMGrid.GetItemText( pItem->iRow, pItem->iColumn);

	AOMListUpdate(posAOMClicked, str);
}

void CPaneSysSetupLaserScannerLarge::AOMListUpdate(CPoint ClickedPos, CString str)
{
	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	FillAOMTable0Data(xPos,yPos, str);	
}

void CPaneSysSetupLaserScannerLarge::FillAOMTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].nInfoId[yPos] = atoi(str);
	}
	else if(xPos ==1 )
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_ON_M[yPos] = atof(str);
	}
	else if(xPos ==2 )
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_OFF_M[yPos] = atof(str);
	}


}




BOOL CPaneSysSetupLaserScannerLarge::DrillGrid()
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	
	pEoCard->ShotDataReset();
	CString	strVal;
	m_edtVoltage1.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_M[0] = atof(strVal);
	m_edtVoltage2.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.dVoltage_S[0] = atof(strVal);

	m_edtAOMDelay.GetWindowText(strVal);
//	gVariable.m_sgToolTable.nSelectShot[0] = 0;

	gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_M[0] = atof(strVal);
	m_edtAOMDelay2.GetWindowText(strVal);
	gVariable.m_sgShotGroupTable.m_sShotParam[0].dAOMWait_S[0] = atof(strVal);

	gVariable.m_sgShotGroupTable.m_sShotParam[0].nAOMNum_M[0] = 10;
	gVariable.m_sgShotGroupTable.m_sShotParam[0].nAOMNum_S[0] = 10;

	double dPulseWidth;
	m_edtPulseWidth.GetWindowText(strVal);
	dPulseWidth = atof(strVal);

	int nFrequency, nShotNo;
	m_edtFrequency.GetWindowText(strVal);
	nFrequency = atoi(strVal);
	m_edtShotNo.GetWindowText(strVal);
	nShotNo = atoi(strVal);
	FParameter fPara;
	pEoCard->GetParameter(&fPara);
	m_edtAOMProfilePath.GetWindowText(strVal);
	memcpy(fPara.cAOMFilePath, strVal, strVal.GetLength()+1);

	m_nOld1stAOMOffset = gSystemINI.m_sSystemDevice.nDualAom1stOffset;
	m_nOld2ndAOMOffset = gSystemINI.m_sSystemDevice.nDualAom2ndOffset;

	m_edt1stAOMOffset.GetWindowText(strVal);
	gSystemINI.m_sSystemDevice.nDualAom1stOffset = atoi(strVal);

	m_edt2ndAOMOffset.GetWindowText(strVal);
	gSystemINI.m_sSystemDevice.nDualAom2ndOffset = atoi(strVal);

	fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
	//fPara.dDuty = static_cast<unsigned short>(dPulseWidth);
	fPara.Frequency = static_cast<unsigned short>(nFrequency);

	gVariable.m_sgShotGroupTable.nShotFrequency[0] = fPara.Frequency;
	gVariable.m_sgShotGroupTable.nShotMinFrequency[0] = fPara.Frequency;
	gVariable.m_sgShotGroupTable.dShotLMDuty_us[0] = fPara.dDuty;


	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
	//	subTool.nDrawStep = 5;
	subTool.nJumpStep = 5;
	subTool.nJumpStepPeriod = 30;
	subTool.nDrawStepPeriod = 20;
	subTool.nCornerDelay = 10;
	subTool.nJumpDelay = 0;
	subTool.nLineDelay = 10;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1500;
	subTool.nFPS = 0;
	// Drill
	subTool.nShotMode = 1;
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 0;
	//	subTool.dShotDuty[MAX_SHOT];
	//	subTool.dShotAOMDelay[MAX_SHOT];
	//	subTool.dShotAOMDuty[MAX_SHOT];
	subTool.nMask = 0;
	subTool.bUseAperture = 0;
	subTool.nApertureBurst = 1;
	subTool.nThermalTrack = 0;
	subTool.dZOffset = 0;
	subTool.bUseTophat = FALSE;
	subTool.cFilePath[0] = NULL;
	subTool.dShotDutyOffsetM[0] = 0;
	subTool.dShotDutyOffsetS[0] = 0;

	subTool.nTotalShot = 1;

	pEoCard->DownloadOneSubTool(ALIGN_TOOL, subTool, TRUE, TRUE);

	if(!pEoCard->DownloadShotDrillScannerParam())
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD);
		strMsg.Format(strString, "Scanner Move Profile Parameter");
		ErrMessage(strMsg);
		return FALSE;
	}


	pEoCard->SetInpositionCheckINI(FALSE);
	pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);
	
	m_edtShotNo.GetWindowText(strVal);

	nShotNo = atoi(strVal);

	int nHead = m_cmbHead.GetCurSel();

	for(int i = 0; i < nShotNo; i++)	
	{
		pEoCard->DownloadShotData2_Use_vm(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, TRUE, FALSE, ALIGN_TOOL);
	}
	
	pEoCard->FieldPreStart(0,nHead);


	pEoCard->FieldStart(FALSE,nHead);

	::Sleep(100);

	WaitOneFireProcess();

	int nEocardHoleCount = pEoCard->ReadHoleCount();

	
	if( nEocardHoleCount != nShotNo)
	{
#ifndef __TEST__
		CString str;
		str.Format(_T("MissHole. DownCount : %d, EoCard Count : %d "), nShotNo, nEocardHoleCount);
		ErrMessage(str);
#endif
	}
	pEoCard->SetInpositionCheckINI(TRUE);
	return TRUE;
	
}

void CPaneSysSetupLaserScannerLarge::WaitOneFireProcess()
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	if(pEoCard == NULL)
		return;

	BOOL bIsDSPBusy = FALSE;

	do
	{
		if(pEoCard->IsDrillTimeOut())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM566);
			return;
		}
		if(pEoCard->IsMotorFault())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
			ErrMsgDlg(STDGNALM567);
			return;
		}
		if(m_bStopFire)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEoCard->EStop();
		}
		bIsDSPBusy = pEoCard->IsDSPBusy();
		MessageLoop();
#ifdef __TEST__
		bIsDSPBusy = FALSE;
#endif
	} while(bIsDSPBusy && !m_bStopFire);
}

void CPaneSysSetupLaserScannerLarge::OnClickedCheckSubUseAom()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bLaserPath = m_chkBeamPass.GetCheck();
	BOOL bUseAom = m_chkUseAom.GetCheck();
	if(!pMotor->MoveLaserBeamPath(bLaserPath, bUseAom))
	{
		ErrMessage(_T("Laser Beam Pass move error!"));
		return ;
	}
	if(bUseAom)
	{
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_SHOW);
	}
	else
	{
		GetDlgItem(IDC_STATIC_AOM_MODULATION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_GRID_AOM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STC_AOM_DELAY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_AOM_DELAY)->ShowWindow(SW_HIDE);
	}
}

void CPaneSysSetupLaserScannerLarge::OnBnClickedButtonMainShtOpen2nd()
{
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	gDeviceFactory.GetLaser()->ShutterOpen(TRUE,USE_HEAD_2);

	::Sleep(1500);
	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_2);
	m_btnMainShtOpen2.SetClick(bOpen);
	m_btnMainShtClose2.SetClick(!bOpen);
}

void CPaneSysSetupLaserScannerLarge::OnBnClickedButtonMainShtClose2nd()
{
	gDeviceFactory.GetLaser()->ShutterOpen(FALSE,USE_HEAD_2);

	::Sleep(1500);
	BOOL bOpen = gDeviceFactory.GetLaser()->IsShutterOpen(USE_HEAD_2);
	m_btnMainShtOpen2.SetClick(bOpen);
	m_btnMainShtClose2.SetClick(!bOpen);
}
