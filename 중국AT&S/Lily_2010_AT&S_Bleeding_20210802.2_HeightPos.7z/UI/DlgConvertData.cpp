// UI\DlgConvertData.cpp : implementation file
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "UI\DlgConvertData.h"
#include "afxdialogex.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\ExcellonReader.h"
#include "..\MODEL\DProject.h"

// CDlgConvertData dialog

IMPLEMENT_DYNAMIC(CDlgConvertData, CDialog)

CDlgConvertData::CDlgConvertData(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgConvertData::IDD, pParent)
{
	m_strFilePath.Empty();
	m_strNewFilePath.Empty();

	m_bIsStartHeader = FALSE;
	m_bIsHeader = FALSE;
	m_nPatternFlag = -1;
	m_nPatternCount = 0;
}

CDlgConvertData::~CDlgConvertData()
{
}

void CDlgConvertData::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK_TOOL1, m_chkTool[0]);
	DDX_Control(pDX, IDC_CHECK_TOOL2, m_chkTool[1]);
	DDX_Control(pDX, IDC_CHECK_TOOL3, m_chkTool[2]);
	DDX_Control(pDX, IDC_CHECK_TOOL4, m_chkTool[3]);
	DDX_Control(pDX, IDC_CHECK_TOOL5, m_chkTool[4]);
	DDX_Control(pDX, IDC_CHECK_TOOL6, m_chkTool[5]);
	DDX_Control(pDX, IDC_CHECK_TOOL7, m_chkTool[6]);
	DDX_Control(pDX, IDC_CHECK_TOOL8, m_chkTool[7]);
	DDX_Control(pDX, IDC_CHECK_TOOL9, m_chkTool[8]);
	DDX_Control(pDX, IDC_CHECK_TOOL10, m_chkTool[9]);
	DDX_Control(pDX, IDC_CHECK_TOOL11, m_chkTool[10]);
	DDX_Control(pDX, IDC_CHECK_TOOL12, m_chkTool[11]);
	DDX_Control(pDX, IDC_CHECK_TOOL13, m_chkTool[12]);
	DDX_Control(pDX, IDC_CHECK_TOOL14, m_chkTool[13]);
	DDX_Control(pDX, IDC_CHECK_TOOL15, m_chkTool[14]);
	DDX_Control(pDX, IDC_CHECK_TOOL16, m_chkTool[15]);
	DDX_Control(pDX, IDC_CHECK_TOOL17, m_chkTool[16]);
	DDX_Control(pDX, IDC_CHECK_TOOL18, m_chkTool[17]);
	DDX_Control(pDX, IDC_CHECK_TOOL19, m_chkTool[18]);
	DDX_Control(pDX, IDC_CHECK_TOOL20, m_chkTool[19]);
	DDX_Control(pDX, IDC_CHECK_ORIGIN_FIDUCIAL, m_chkFiducial);

	DDX_Control(pDX, IDC_COMBO_TOOL1, m_cmbTool[0]);
	DDX_Control(pDX, IDC_COMBO_TOOL2, m_cmbTool[1]);
	DDX_Control(pDX, IDC_COMBO_TOOL3, m_cmbTool[2]);
	DDX_Control(pDX, IDC_COMBO_TOOL4, m_cmbTool[3]);
	DDX_Control(pDX, IDC_COMBO_TOOL5, m_cmbTool[4]);
	DDX_Control(pDX, IDC_COMBO_TOOL6, m_cmbTool[5]);
	DDX_Control(pDX, IDC_COMBO_TOOL7, m_cmbTool[6]);
	DDX_Control(pDX, IDC_COMBO_TOOL8, m_cmbTool[7]);
	DDX_Control(pDX, IDC_COMBO_TOOL9, m_cmbTool[8]);
	DDX_Control(pDX, IDC_COMBO_TOOL10, m_cmbTool[9]);
	DDX_Control(pDX, IDC_COMBO_TOOL11, m_cmbTool[10]);
	DDX_Control(pDX, IDC_COMBO_TOOL12, m_cmbTool[11]);
	DDX_Control(pDX, IDC_COMBO_TOOL13, m_cmbTool[12]);
	DDX_Control(pDX, IDC_COMBO_TOOL14, m_cmbTool[13]);
	DDX_Control(pDX, IDC_COMBO_TOOL15, m_cmbTool[14]);
	DDX_Control(pDX, IDC_COMBO_TOOL16, m_cmbTool[15]);
	DDX_Control(pDX, IDC_COMBO_TOOL17, m_cmbTool[16]);
	DDX_Control(pDX, IDC_COMBO_TOOL18, m_cmbTool[17]);
	DDX_Control(pDX, IDC_COMBO_TOOL19, m_cmbTool[18]);
	DDX_Control(pDX, IDC_COMBO_TOOL20, m_cmbTool[19]);

	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL1, m_stcTool[0]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL2, m_stcTool[1]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL3, m_stcTool[2]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL4, m_stcTool[3]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL5, m_stcTool[4]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL6, m_stcTool[5]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL7, m_stcTool[6]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL8, m_stcTool[7]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL9, m_stcTool[8]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL10, m_stcTool[9]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL11, m_stcTool[10]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL12, m_stcTool[11]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL13, m_stcTool[12]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL14, m_stcTool[13]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL15, m_stcTool[14]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL16, m_stcTool[15]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL17, m_stcTool[16]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL18, m_stcTool[17]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL19, m_stcTool[18]);
	DDX_Control(pDX, IDC_STATIC_HOLE_COUNT_TOOL20, m_stcTool[19]);

	DDX_Control(pDX, IDC_STATIC_FIDUCIAL_COUNT_TOOL, m_stcFiducial);

	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSaveToFile);
	DDX_Control(pDX, IDOK, m_btnLoad);
	DDX_Control(pDX, IDCANCEL, m_btnClose);
}


BEGIN_MESSAGE_MAP(CDlgConvertData, CDialog)
	
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CDlgConvertData::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDOK, &CDlgConvertData::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgConvertData message handlers

BOOL CDlgConvertData::OnInitDialog()
{
	CDialog::OnInitDialog();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();

	CountHoleNumber();
	LoadToolConfig();

	return TRUE;
}

void CDlgConvertData::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_TOOL_NO)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_DATA_TYPE)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_HOLE_COUNT)->SetFont(&m_fntStatic);
	
	for(int i=0; i<MAX_CONV_TOOL; i++)
	{
		m_stcTool[i].SetFont(&m_fntStatic);
	}
	m_stcFiducial.SetFont(&m_fntStatic);

}
void CDlgConvertData::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");

	for(int i=0; i<MAX_CONV_TOOL; i++)
	{
		m_chkTool[i].SetFont(&m_fntBtn);
		m_chkTool[i].SetImageOrg( 10, 3 );
		m_chkTool[i].SetIcon( IDI_LEDON, IDI_LEDOFF );
		m_chkTool[i].SetCheck(FALSE);
	}

	m_chkFiducial.SetFont(&m_fntBtn);
	m_chkFiducial.SetImageOrg( 10, 3 );
	m_chkFiducial.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkFiducial.SetCheck(FALSE);

	m_btnLoad.SetFont( &m_fntBtn );
	m_btnLoad.SetFlat( FALSE );
	m_btnLoad.EnableBallonToolTip();
	m_btnLoad.SetToolTipText( _T("Convert Data And Load Excellon") );
	m_btnLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoad.SetBtnCursor(IDC_HAND_1);

	m_btnSaveToFile.SetFont( &m_fntBtn );
	m_btnSaveToFile.SetFlat( FALSE );
	m_btnSaveToFile.EnableBallonToolTip();
	m_btnSaveToFile.SetToolTipText( _T("Convert Data And Save to File") );
	m_btnSaveToFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSaveToFile.SetBtnCursor(IDC_HAND_1);

	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("Close") );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.SetBtnCursor(IDC_HAND_1);
}
void CDlgConvertData::InitComboControl()
{
	m_fntCombo.CreatePointFont(100, "Arial Bold");

	for(int i=0; i<MAX_CONV_TOOL; i++)
	{
		m_cmbTool[i].SetFont(&m_fntCombo);
		m_cmbTool[i].SetCurSel(0);
	}
}

void CDlgConvertData::OnBnClickedButtonSave()
{

	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt, *.dat, *.drl, *.gbr, *.dnc)|*.txt;*.dat;*.gbr;*.drl;*.dnc|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(FALSE, _T("*.txt"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();

	if(IDOK != dlg.DoModal())
	{
		SetFocus();
		return;
	}
	m_strNewFilePath.Format(_T("%s"), dlg.GetPathName());



	SaveTCode(); //Header
	SaveFiducialData(); //Fiducial
	SaveData(); //Data

	SaveToolConfig();
}

void CDlgConvertData::SaveToolConfig()
{
	CString strToolNo;
	for(int i=0; i<MAX_CONV_TOOL; i++) //Save Tool Config
	{
		BOOL bUse = m_chkTool[i].GetCheck();
		int nType;

		if(bUse)
		{
			nType = m_cmbTool[i].GetCurSel();
		}
		else
		{
			nType = -1;
		}

		strToolNo.Format(_T("%d"), i);
		::AfxGetApp()->WriteProfileInt("CONVERT_TOOL_INFO", strToolNo, nType);
	}
}

void CDlgConvertData::LoadToolConfig()
{
	CString strToolNo;
	for(int i=0; i<MAX_CONV_TOOL; i++) //Load Tool Config
	{
		strToolNo.Format(_T("%d"), i);
		int nDatatype = ::AfxGetApp()->GetProfileInt("CONVERT_TOOL_INFO", strToolNo, -1);

		if(nDatatype == -1)
		{
			continue;
		}
		else
		{
			m_chkTool[i].SetCheck(TRUE);
			m_cmbTool[i].SetCurSel(nDatatype);
		}
	}
}

void CDlgConvertData::SaveTCode()
{
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	BOOL bIsStartHead = FALSE;
	BOOL bIsHeader = TRUE;

	memset(chBuffer, 0, BUFMAX+1);

	errno_t err = fopen_s(&pFile, m_strFilePath, _T("rb"));
	if (err == NULL)
	{
		int nToolNo = -1;
		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));

			

			if( token[0] == _T('T')/* || token[0] == _T('Y')*/)
			{
				nToolNo = atoi(token + 1);
			}
			else if( token[0] == _T('%') || (token[0] == _T('M') && token[1] == _T('9') && token[2] == _T('5')))
			{
				break;
			}

			if(m_chkTool[nToolNo-1].GetCheck() == TRUE && m_cmbTool[nToolNo-1].GetCurSel() == 0)
				SaveConvData(token);
			
		};
		fclose(pFile);
	}
}

void CDlgConvertData::SaveOriginalFiducial()
{
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	BOOL FiducialData = FALSE;

	memset(chBuffer, 0, BUFMAX+1);

	errno_t err = fopen_s(&pFile, m_strFilePath, _T("rb"));
	if (err == NULL)
	{
		int nToolNo = -1;
		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));


			if(token[0] == _T('M') && token[1] == _T('7') && token[2] == _T('1'))
			{
				FiducialData = TRUE;
			}
			else if(token[0] == _T('T'))
				break;

			if(FiducialData)
			{
				SaveConvData(token);
			}
		};
		fclose(pFile);
	}
}

void CDlgConvertData::SaveFiducialData()
{
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR szData[BUFMAX];
	TCHAR *szNext;
	FILE* pFile;
	BOOL bIsStartHead = FALSE;
	BOOL bIsHeader = TRUE;
	int nCurToolNo = 0;
	
	memset(chBuffer, 0, BUFMAX+1);
	memset(szData, 0, BUFMAX);

	for(int i=0; i<MAX_CONV_TOOL; i++)
	{
		BOOL bUse = m_chkTool[i].GetCheck();
		int nType = m_cmbTool[i].GetCurSel();

		if(bUse && nType != 0) //Use Tool & Fiducial Type
		{
			errno_t err = fopen_s(&pFile, m_strFilePath, _T("rb"));
			if (err == NULL)
			{
				while (!feof(pFile))
				{
					fgets(chBuffer, BUFMAX, pFile);
					token = strtok_s(chBuffer, _T("\n"), &szNext);
					if (token == NULL)
						continue;
					for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
						*szPos = static_cast<TCHAR>(toupper(*szPos));

					if( token[0] == _T('T') )
					{
						bIsStartHead = TRUE;

						if(bIsHeader == FALSE) //Change Coordinates Data
						{
							int nCount = 0;
							int nTotalLen = strlen(token);
							for(int i = 1; i < nTotalLen; i++) //Formating
							{
								if((chBuffer[i] >= _T('0') && chBuffer[i] <= _T('9')))
								{
									szData[nCount++] = chBuffer[i];
								}
								else
								{
									szData[nCount] = _T('\0');
									break;
								}
							}
							nCurToolNo = atoi(szData);
						}
					}
					else if(token[0] == _T('X') || token[0] == _T('Y'))
					{
						if(i+1 == nCurToolNo) //���� Tool ������ �� ���
						{
							SaveConvData(token, TRUE, nType);
						}
					}
					else 
					{
						if(bIsStartHead) //Out of header
							bIsHeader = FALSE;
					}
				};
				fclose(pFile);
			}
		}

	}
}

//bIsStartHead - bIsHeader - bIsData
void CDlgConvertData::SaveData()
{
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR szData[BUFMAX];
	TCHAR *szNext;
	FILE* pFile;
	CString strTmp;

	int nCurToolNo = 0;

	for(int i=0; i<MAX_CONV_TOOL; i++)
	{
		BOOL bIsStartHead = FALSE;
		BOOL bIsHeader = TRUE;
		BOOL bIsData = FALSE;

		BOOL bUse = m_chkTool[i].GetCheck();
		int nType = m_cmbTool[i].GetCurSel();

		if(bUse && nType == 0) //Use Tool & Data
		{
			errno_t err = fopen_s(&pFile, m_strFilePath, _T("rb"));
			if (err == NULL)
			{
				while (!feof(pFile))
				{
					memset(chBuffer, 0, BUFMAX+1);
					fgets(chBuffer, BUFMAX, pFile);
					token = strtok_s(chBuffer, _T("\n"), &szNext);
					if (token == NULL)
						continue;
					for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
						*szPos = static_cast<TCHAR>(toupper(*szPos));

					if( token[0] == _T('T') )
					{
						bIsStartHead = TRUE;

						if(bIsHeader == FALSE)
						{
							int nCount = 0;
							int nTotalLen = strlen(token);

							for(int j = 1; j < nTotalLen; j++) //Formating
							{
								if((chBuffer[j] >= _T('0') && chBuffer[j] <= _T('9')))
								{
									szData[nCount++] = chBuffer[j];
								}
								else
								{
									break;
								}
							}
							szData[nCount] = _T('\0');
							nCurToolNo = atoi(szData);
							if(i+1 == nCurToolNo)
								SaveConvData(token);
							bIsData = TRUE;
						}
					}
					else if(token[0] == _T('X') || token[0] == _T('Y'))
					{
						if(i+1 == nCurToolNo) //If current Tool
						{
							SaveConvData(token);
						}
					}
					else 
					{
						if(bIsStartHead) 
						{
							bIsHeader = FALSE; //Out of header
						}

						if(i+1 == nCurToolNo && bIsData) //etc codes
						{
							strTmp.Format(_T("%s"), token);
							if(strTmp.Find(" ") == -1 && strTmp.Find(_T("M30")) == -1 ) //No write following codes(Space, M30)
							{
								SaveConvData(token);
							}
						}
					}
				};
				fclose(pFile);
			}
		}

	}

	strcpy_s(szData, _T("M30\n"));
	SaveConvData(szData);
}

void CDlgConvertData::SaveConvData(char *szBuf, BOOL bFidData, int nFidType)
{	
	if((szBuf[strlen(szBuf)-1] >= _T('0') && szBuf[strlen(szBuf)-1] <= _T('9')))
	{
		szBuf[strlen(szBuf)] = _T('\0');
	}
	else
	{
		szBuf[strlen(szBuf)-1] = _T('\0');
	}
//	szBuf[strlen(szBuf)-1] = _T('\0'); //fgets�� ���ڸ� �������� ����

	CString strBuf;
	strBuf.Empty();

	if(bFidData != TRUE)
	{
		strBuf.Format(_T("%s\n"), szBuf);
	}
	else
	{
		strBuf.Format(_T("%s%s\n"), (nFidType==1)?"A":"B", szBuf);
	}

	CStdioFile file;
	if(FALSE == file.Open(m_strNewFilePath,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	TRY 
	{
		file.SeekToEnd();
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		file.Close();
}

void CDlgConvertData::SetFilePath(CString strFilePath)
{
	m_strFilePath = strFilePath;
}

void CDlgConvertData::GetFilePath(CString &strFilePath)
{
	strFilePath = m_strNewFilePath;
}

void CDlgConvertData::CountHoleNumber()
{
	m_bIsHeader = TRUE;
	m_nFiducialCount = 0;
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	
	errno_t err = fopen_s(&pFile, m_strFilePath, _T("rb"));
	if (err == NULL)
	{

		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));

			ReadCode(token);

		};
		fclose(pFile);
	}

	POSITION pos;
	CPoint tmpToolData;

	pos = m_ToolData.GetHeadPosition();
	while(pos)
	{
		tmpToolData = m_ToolData.GetNext(pos);
		ShowHoleCount(tmpToolData.x, tmpToolData.y);
	}
}


void CDlgConvertData::ShowHoleCount(int nToolNo, int nHoleCount)
{
	CString strHoleCount, strFidCount;
	strHoleCount.Format(_T("%d"), nHoleCount);
	strFidCount.Format(_T("%d"), m_nFiducialCount);

	m_chkTool[nToolNo-1].ShowWindow(SW_SHOW);
	m_cmbTool[nToolNo-1].ShowWindow(SW_SHOW);
	m_stcTool[nToolNo-1].ShowWindow(SW_SHOW);

	m_stcTool[nToolNo-1].SetWindowText(strHoleCount);

	if(m_nFiducialCount > 0)
	{
		m_chkFiducial.ShowWindow(SW_SHOW);
		m_stcFiducial.ShowWindow(SW_SHOW);
		m_stcFiducial.SetWindowText(strFidCount);
	}
}

void CDlgConvertData::ReadCode(TCHAR *szBuffer)
{
	int nTotalLen = strlen(szBuffer);
	TCHAR szData[BUFMAX];
	int nCount = 0;

	if( szBuffer[0] == _T('T') )
	{
		m_bIsStartHeader = TRUE;

		for(int i = 1; i < nTotalLen; i++) //Formating
		{
			if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')))
			{
				szData[nCount++] = szBuffer[i];
			}
			else
			{
				szData[nCount] = _T('\0');
				break;
			}
		}

		if(m_bIsHeader == TRUE) //Define Tool Code(Header)
		{
			CPoint tmpToolData;
			tmpToolData.x = 0;
			tmpToolData.y = 0;

			tmpToolData.x = atoi(szData);
			m_ToolData.AddTail(tmpToolData);

		}
//		else //Current Tool Code(Not Header)
		{
			m_nCurToolCode = atoi(szData);
		}
	}
	else if(szBuffer[0] == _T('X') || szBuffer[0] == _T('Y')||
		(szBuffer[0] == _T('G') && szBuffer[1] == _T('8') && szBuffer[2] == _T('2') && szBuffer[3] != _T('1')) ||
		(szBuffer[0] == _T('G') && szBuffer[1] == _T('8') && szBuffer[2] == _T('3') && szBuffer[3] != _T('1')) )
	{
		if(m_nPatternFlag == emPatternBegin)
			m_nPatternCount++;

		POSITION pos;
		
		pos = m_ToolData.GetHeadPosition();
		while(pos)
		{
			CPoint *tmpToolData;
			tmpToolData = &(m_ToolData.GetNext(pos));

			if(tmpToolData->x == m_nCurToolCode) // Hole Counting
			{
				tmpToolData->y++;
				break;
			}
		}
	}
	else if((szBuffer[0] == _T('A') || szBuffer[0] == _T('B')) )
	{
		m_nFiducialCount++;
	}
	else if(szBuffer[0] == _T('M') && szBuffer[1] == _T('2') && szBuffer[2] == _T('5'))
	{
		m_nPatternFlag = emPatternBegin;
		m_nPatternCount = 0;
	}
	else if(szBuffer[0] == _T('M') && szBuffer[1] == _T('0') && szBuffer[2] == _T('1'))
	{
		m_nPatternFlag = emPatternEnd;
	}
	else if(szBuffer[0] == _T('M') && szBuffer[1] == _T('7') && szBuffer[2] == _T('1'))
	{
		m_nPatternFlag = emPatternFiducial;
	}
	else if(szBuffer[0] == _T('M') && szBuffer[1] == _T('0') && szBuffer[2] == _T('2'))
	{
		if(szBuffer[3] == _T('X') || szBuffer[3] == _T('Y'))
		{
			POSITION pos;

			pos = m_ToolData.GetHeadPosition();
			while(pos)
			{
				CPoint *tmpToolData;
				tmpToolData = &(m_ToolData.GetNext(pos));

				if(tmpToolData->x == m_nCurToolCode) // Hole Counting
				{
					tmpToolData->y += m_nPatternCount;
					break;
				}
			}
		}
	}
	else
	{
		if(m_bIsStartHeader)
			m_bIsHeader = FALSE; // Out of header
	}

}

void CDlgConvertData::OnBnClickedOk()
{
	CTime cTime = CTime::GetCurrentTime();

	m_strNewFilePath = m_strFilePath;

//	int nTrimIdx = m_strNewFilePath.Find(_T(".txt"));
//	m_strNewFilePath = m_strNewFilePath.Mid(0, nTrimIdx);
	m_strNewFilePath += cTime.Format(_T("_CONV_%Y%m%d%H%M%S.txt"));

	SaveTCode(); //Header
	if(m_chkFiducial.GetCheck())
		SaveOriginalFiducial();
	SaveFiducialData(); //Fiducial
	SaveData(); //Data

	SaveToolConfig();

	CDialog::OnOK();
}
