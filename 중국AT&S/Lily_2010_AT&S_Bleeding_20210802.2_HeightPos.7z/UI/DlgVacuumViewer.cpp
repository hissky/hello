// DlgVacuumViewer.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgVacuumViewer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgVacuumViewer dialog


CDlgVacuumViewer::CDlgVacuumViewer(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVacuumViewer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgVacuumViewer)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

void CDlgVacuumViewer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgVacuumViewer)
	DDX_Control(pDX, IDC_STATIC_VACUUM_A_1, m_stcVacuumA1);
	DDX_Control(pDX, IDC_STATIC_VACUUM_B_1, m_stcVacuumB1);
	DDX_Control(pDX, IDC_STATIC_VACUUM_C_1, m_stcVacuumC1);
	DDX_Control(pDX, IDC_STATIC_VACUUM_D_1, m_stcVacuumD1);
	DDX_Control(pDX, IDC_STATIC_VACUUM_A_2, m_stcVacuumA2);
	DDX_Control(pDX, IDC_STATIC_VACUUM_B_2, m_stcVacuumB2);
	DDX_Control(pDX, IDC_STATIC_VACUUM_C_2, m_stcVacuumC2);
	DDX_Control(pDX, IDC_STATIC_VACUUM_D_2, m_stcVacuumD2);
	DDX_Control(pDX, IDOK, m_btnClose);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgVacuumViewer, CDialog)
	//{{AFX_MSG_MAP(CDlgVacuumViewer)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgVacuumViewer message handlers
BOOL CDlgVacuumViewer::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	InitStaticControl();
	InitBtnControl();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgVacuumViewer::InitStaticControl() 
{
	// TODO: Add your control notification handler code here
	
	m_fntStatic.CreatePointFont(120, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_TABLE_VACUUM_VIEWER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_VACUUM_VIEWER_TABLE_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_VACUUM_VIEWER_TABLE_2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_B)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_D)->SetFont( &m_fntStatic );

	m_stcVacuumA1.SetFont( &m_fntStatic );
	m_stcVacuumA1.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumA1.SetBackColor( VALUE_BACK_COLOR );

	m_stcVacuumB1.SetFont( &m_fntStatic );
	m_stcVacuumB1.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumB1.SetBackColor( VALUE_BACK_COLOR );

	m_stcVacuumC1.SetFont( &m_fntStatic );
	m_stcVacuumC1.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumC1.SetBackColor( VALUE_BACK_COLOR );

	m_stcVacuumD1.SetFont( &m_fntStatic );
	m_stcVacuumD1.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumD1.SetBackColor( VALUE_BACK_COLOR );

	m_stcVacuumA2.SetFont( &m_fntStatic );
	m_stcVacuumA2.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumA2.SetBackColor( VALUE_BACK_COLOR );
	
	m_stcVacuumB2.SetFont( &m_fntStatic );
	m_stcVacuumB2.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumB2.SetBackColor( VALUE_BACK_COLOR );
	
	m_stcVacuumC2.SetFont( &m_fntStatic );
	m_stcVacuumC2.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumC2.SetBackColor( VALUE_BACK_COLOR );
	
	m_stcVacuumD2.SetFont( &m_fntStatic );
	m_stcVacuumD2.SetForeColor( VALUE_FORE_COLOR );
	m_stcVacuumD2.SetBackColor( VALUE_BACK_COLOR );
}

void CDlgVacuumViewer::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(120, "Arial Bold");

	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("Close viewer") );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.SetBtnCursor(IDC_HAND_1);
}

HBRUSH CDlgVacuumViewer::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_TABLE_VACUUM_VIEWER)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgVacuumViewer::DispValue()
{
	return;
	/*
	double dVal = 0;
	CString strData;
	
	m_pMotor->GetVacuumValue(TRUE, VACUUM_A, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumA1.SetWindowText( (LPCTSTR)strData );

	m_pMotor->GetVacuumValue(TRUE, VACUUM_B, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumB1.SetWindowText( (LPCTSTR)strData );

	m_pMotor->GetVacuumValue(TRUE, VACUUM_C, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumC1.SetWindowText( (LPCTSTR)strData );

	m_pMotor->GetVacuumValue(TRUE, VACUUM_D, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumD1.SetWindowText( (LPCTSTR)strData );

	m_pMotor->GetVacuumValue(FALSE, VACUUM_A, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumA2.SetWindowText( (LPCTSTR)strData );
	
	m_pMotor->GetVacuumValue(FALSE, VACUUM_B, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumB2.SetWindowText( (LPCTSTR)strData );
	
	m_pMotor->GetVacuumValue(FALSE, VACUUM_C, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumC2.SetWindowText( (LPCTSTR)strData );
	
	m_pMotor->GetVacuumValue(FALSE, VACUUM_D, dVal);
	strData.Format(_T("%.2f"), dVal);
	m_stcVacuumD2.SetWindowText( (LPCTSTR)strData );

	m_bTimer = FALSE;
	*/
}

void CDlgVacuumViewer::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	if(!m_bTimer)
		DispValue();
	
	CDialog::OnTimer(nIDEvent);
}

void CDlgVacuumViewer::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_bTimer = FALSE;
		m_nTimerID = SetTimer(7777, 500, NULL);
	}
}

void CDlgVacuumViewer::DestroyTimer()
{
	if(m_nTimerID)
	{
		m_bTimer = TRUE;
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CDlgVacuumViewer::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
}

void CDlgVacuumViewer::OnOK() 
{
	if(m_nTimerID)
	{
		m_bTimer = TRUE;
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
	
	CDialog::OnOK();
}
