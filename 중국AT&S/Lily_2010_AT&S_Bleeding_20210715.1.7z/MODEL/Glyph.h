// Glyph.h: interface for the Glyph class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLYPH_H__4CDDCAB3_05DF_4F83_B66F_D0642C67FC17__INCLUDED_)
#define AFX_GLYPH_H__4CDDCAB3_05DF_4F83_B66F_D0642C67FC17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ToolCodeList.h"
#include "DUnit.h"

#define DBL_MAX         1.7976931348623158e+308 /* max value */

struct LINE_CONVERT_DATA {
	LPLINEDATA	pOrigin;
	CPoint		npStartPos;
	CPoint		npEndPos;
	CDPoint		dpFidSPos1;
	CDPoint		dpFidEPos1;
	CPoint		nLeadPos1; // x: lead In y : lead out
	CDPoint		dpFidSPos2;
	CDPoint		dpFidEPos2;
	CPoint		nLeadPos2; // x: lead In y : lead out
	BOOL		bSelect;
//	int			nUnitIndex;
};
typedef LINE_CONVERT_DATA* LPFIRELINE;
typedef CTypedPtrList <CPtrList, LPFIRELINE>	FireLineList;

struct FIDUCIAL_INDEX {
	int nIndex;
};
typedef FIDUCIAL_INDEX* LPFID_INDEX;
typedef CTypedPtrList <CPtrList, LPFID_INDEX>	FidIndexList;

class Glyph : public CObject  
{
public:
	virtual BOOL OnSetRefFid(CPoint pt, int nTolerence);
	void UnSelectAll();
	virtual BOOL DelFiducial(CPoint pt, int nTolerence);
	virtual BOOL AddFiducial(CPoint pt, int nTolerence, int nFidKind);
	virtual BOOL IsFidHoleGet(BOOL &bFidList, CPoint pt, int nTolerence, BOOL &bSkiving);
//	BOOL IsSelected();
	virtual void Move(int nX, int nY);
	virtual void Rotate(double dDeg);
	virtual void Flip(BOOL bX);
//	BOOL m_bSelect;
	virtual BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual void Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode);
	virtual void DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode);
	DECLARE_SERIAL( Glyph );
	Glyph();
	virtual ~Glyph();

//	LineDataList	m_LineData;
//	HoleDataList	m_HoleData;

	int	m_nMinX;
	int	m_nMinY;
	int	m_nMaxX;
	int	m_nMaxY;

};

#endif // !defined(AFX_GLYPH_H__4CDDCAB3_05DF_4F83_B66F_D0642C67FC17__INCLUDED_)
