// SystemINIFile.cpp: implementation of the CSystemINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "SystemINIFile.h"

#include "DSystemINI.h"
#include "DProcessINI.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSystemINIFile::CSystemINIFile()
{

}

CSystemINIFile::~CSystemINIFile()
{

}

BOOL CSystemINIFile::OpenSystemINIFile(CString strFilePath, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START HARDWARE SECTION")) )
		{
			if( FALSE == ParsingSystemHardware(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingSystemHardware"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		if( 0 == strGetData.CompareNoCase(_T("// START SYSTEM DEVICE SECTION")) )
		{
			if( FALSE == ParsingSystemDevice(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingSystemDevice"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START SYSTEM COLLIMATOR SECTION")) )
		{
			if( FALSE == ParsingSystemCollimator(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingSystemCollimator"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START SYSTEM TOPHAT SECTION")) )
		{
			if( FALSE == ParsingSystemTophat(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingSystemTophat"));
				ErrMessage(strMsg);
		
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// START AXIS INFO SECTION")) )
		{
			if( FALSE == ParsingAxisInfo(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingAxisInfo"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		
		else if( 0 == strGetData.CompareNoCase(_T("// START SYSTEM COMPONENT SECTION")) )
		{
			if( FALSE == ParsingComponent(sFile, clsSystemINI) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingComponentInfo"));
				ErrMessage(strMsg);
				
	//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}

		else if( 0 == strGetData.CompareNoCase(_T("// END EASYDRILLER SYSTEM INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CSystemINIFile::ParsingComponent(CStdioFile &sFile, DSystemINI &clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	
	while(sFile.ReadString(strGetData))
	{
		if( ScanSys( strGetData, _T("COMPONENT PREACQTIME ="), clsSystemINI.m_sSystemComponent.nPreAcTime ) )
			continue;


		if( 0 == strGetData.CompareNoCase(_T("// END COMPONENT SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}


BOOL CSystemINIFile::ParsingSystemHardware(CStdioFile& sFile, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	
	while( sFile.ReadString( strGetData ) )
	{
		// Laser type : CO2, UV, CO2+UV, LV100, IPG PULSE
		if( ScanSys( strGetData, _T("LASER TYPE ="), clsSystemINI.m_sHardWare.nLaserType ) )
			continue;
		// Beam : 1, 2, 3, 4-beam
		if( ScanSys( strGetData, _T("BEAM TYPE ="), clsSystemINI.m_sHardWare.nBeamType ) )
			continue;
		// Use RS232 com : Lamp (coaxial, ring)
		if( ScanSys( strGetData, _T("USE LAMP RS232 ="), clsSystemINI.m_sHardWare.nUseLampRS232 ) )
			continue;
		// TableClamp Num
		if( ScanSys( strGetData, _T("TABLE CLAMP ="), clsSystemINI.m_sHardWare.nTableClamp ) )
			continue;
		// Vision Type : omi, matrox
		if( ScanSys( strGetData, _T("VISION TYPE ="), clsSystemINI.m_sHardWare.nVisionType ) )
			continue;
		// Beam Dumper Use 20070730
		if( ScanSys( strGetData, _T("DUMPER USE ="), clsSystemINI.m_sHardWare.nUseBeamDumper ) )
			continue;
		// Manual Machine (no use loader/unloader)
		if( ScanSys( strGetData, _T("MANUAL MACHINE ="), clsSystemINI.m_sHardWare.nManualMachine ) )
			continue;
		// Table Dust ����
		if( ScanSys( strGetData, _T("TABLE DUST REMOVE ="), clsSystemINI.m_sHardWare.nDustTableUse ) )
			continue;
		// scanner axis type
		if( ScanSys( strGetData, _T("SCANNER AXIS ="), clsSystemINI.m_sHardWare.nScannerAxisType ) )
			continue;
		// scanner axis type
		if( ScanSys( strGetData, _T("SCANNER AXIS 2 ="), clsSystemINI.m_sHardWare.nScannerAxisType2 ) )
			continue;

		if( ScanSys( strGetData, _T("EXCELLON AXIS ="), clsSystemINI.m_sHardWare.nExcellonOpenAxis ) )
			continue;
		// AOM Option
		if( ScanSys( strGetData, _T("AOM TYPE ="), clsSystemINI.m_sHardWare.nAOMType ) )
			continue;
		// EOCard Type
		if( ScanSys( strGetData, _T("EOCARD TYPE ="), clsSystemINI.m_sHardWare.nEocardType ) )
			continue;
		if( ScanSys( strGetData, _T("SCANNER USE AOD ="), clsSystemINI.m_sHardWare.nUseAOD ) )
			continue;

		if( ScanSys( strGetData, _T("AOD MS SELECT ="), clsSystemINI.m_sHardWare.nAODMSSelect ) )
			continue;
		// scanner use info
		if( ScanSys( strGetData, _T("SCANNER USE INFO ="), clsSystemINI.m_sHardWare.nUseEocardAxis ) )
			continue;
		
		if( ScanSys( strGetData, _T("AOM USE FIRST ORDER ="), clsSystemINI.m_sHardWare.nUseFirstOrder ) )
			continue;
		
		if( ScanSys( strGetData, _T("USE DUALBAND ="), clsSystemINI.m_sHardWare.nUseDualBand ) )
			continue;

		if( ScanSys( strGetData, _T("LANGUAGE TYPE ="), clsSystemINI.m_sHardWare.nLanguageType ) )
			continue;

		if( ScanSys( strGetData, _T("SCANNER POS WARN ="), clsSystemINI.m_sHardWare.dScannerWaringLevelmm ) )
			continue;
		if( ScanSys( strGetData, _T("SCANNER POS ALARM ="), clsSystemINI.m_sHardWare.dScannerAlarmLevelmm ) )
			continue;

		if(  ScanSys( strGetData, _T("USE FAST INPOSITION ="), clsSystemINI.m_sHardWare.bUseFastInposition) )
			continue;

		// short line duty offset
		if( ScanSys( strGetData, _T("SHORT LINE DUTY OFFSET ="), clsSystemINI.m_sHardWare.nShortLineDutyOffset ) )
			continue;
		if( ScanSys( strGetData, _T("SHORT LINE LENGTH ="), clsSystemINI.m_sHardWare.nShortLineLength ) )
			continue;
		if( ScanSys( strGetData, _T("TABLE VACUUM SELECT ="), clsSystemINI.m_sHardWare.bTableVacuumSelect ) )
			continue;

		// Barcode reader
		if( ScanSys( strGetData, _T("BARCODE READER ="), clsSystemINI.m_sHardWare.nUseBarcodeReader ) )
			continue;
		// Wide Monitor
		if( ScanSys( strGetData, _T("WIDE MONITOR ="), clsSystemINI.m_sHardWare.bUseWideMonitor ) )
			continue;
		
		// bUseVacummmotor
		if( ScanSys( strGetData, _T("USE VACUMM MOTOR ="), clsSystemINI.m_sHardWare.bUseVacummmotor ) )
			continue;

		// auto lock time
		if( ScanSys( strGetData, _T("AUTO LOCK TIME SEC ="), clsSystemINI.m_sHardWare.nAutoLockTime ) )
			continue;
	
		if( ScanSys( strGetData, _T("LPC MIN TOL ="), clsSystemINI.m_sHardWare.dLPCMinTolerence ) )
			continue;
		
		if( ScanSys( strGetData, _T("LPC MAX TOL ="), clsSystemINI.m_sHardWare.dLPCMaxTolerence ) )
			continue;

		if( ScanSys( strGetData, _T("PRE LPC MIN TOL ="), clsSystemINI.m_sHardWare.dPreLPCMinTolerence ) )
			continue;

		if( ScanSys( strGetData, _T("PRE LPC MAX TOL ="), clsSystemINI.m_sHardWare.dPreLPCMaxTolerence ) )
			continue;
		if( ScanSys( strGetData, _T("PRE LPC MAX VALUE OFFSET ="), clsSystemINI.m_sHardWare.dPreLPCMaxValueOffset ) )
			continue;
		if( ScanSys( strGetData, _T("LPC MINIMUM ="), clsSystemINI.m_sHardWare.nLPCMinimum ) )
			continue;
		

	


		if( ScanSys( strGetData, _T("LPC HOLE DEVIATION PERCENT ="), clsSystemINI.m_sHardWare.dLPCHoleDeviationTolPercent ) )
			continue;


		if( ScanSys( strGetData, _T("LPC START TOL PERCENT ="), clsSystemINI.m_sHardWare.dLPCStartTolerencePercent ) )
			continue;

		if( ScanSys( strGetData, _T("LPC START SKIP COUNT ="), clsSystemINI.m_sHardWare.nLPCStartSkipCount ) )
			continue;

		if( ScanSys( strGetData, _T("PRE LPC SHOT COUNT ="), clsSystemINI.m_sHardWare.nPreLPCShotCount ) )
			continue;

		if( ScanSys( strGetData, _T("USE LPC ="), clsSystemINI.m_sHardWare.bUseLPC ) )
			continue;

		if( ScanSys( strGetData, _T("MACHINE NO ="), clsSystemINI.m_sHardWare.nMachineNo ) )
			continue;

		if( ScanSys( strGetData, _T("TABLE SHOOT LIMIT ="), clsSystemINI.m_sHardWare.nTableShootLimit ) )
			continue;

		if( ScanSys( strGetData, _T("LPC MINIMUM ="), clsSystemINI.m_sHardWare.nLPCMinimum ) )
			continue;

		if( ScanSys( strGetData, _T("LASER CAL ALARM="), clsSystemINI.m_sHardWare.bLaserCalAlarm ) )
			continue;

		if( ScanSys( strGetData, _T("SAVE BUTTON LOG ="), clsSystemINI.m_sHardWare.bSaveButtonLog ) ) // 20130522
			continue;

		if( ScanSys( strGetData, _T("CHILLER SERIAL CONNECT ="), clsSystemINI.m_sHardWare.bChillerConnect ) )
			continue;

		if( ScanSys( strGetData, _T("HUMIDITY SERIAL CONNECT ="), clsSystemINI.m_sHardWare.bHumidityConnect ) ) // 20130522
			continue;

		if( ScanSys( strGetData, _T("TEMPER_COMP SERIAL CONNECT ="), clsSystemINI.m_sHardWare.bTemperCompConnect ) ) 
			continue;

		if( ScanSys( strGetData, _T("VOLTAGE IP CONNECT ="), clsSystemINI.m_sHardWare.bVoltageConnect ) ) 
			continue;
	
		if( ScanSys( strGetData, _T("LINK RS485 ="), clsSystemINI.m_sHardWare.bLinkRS485 ) ) 
			continue;

		if( ScanSys( strGetData, _T("MC MODE ="), clsSystemINI.m_sHardWare.bCheckMCMode ) ) 
			continue;

		if( ScanSys( strGetData, _T("OFFSET MODE ="), clsSystemINI.m_sHardWare.bFirstOffsetMode ) ) 
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END HARDWARE SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}

BOOL CSystemINIFile::ParsingSystemDevice(CStdioFile& sFile, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	TCHAR szTemp[BUFMAX];

	while( sFile.ReadString( strGetData ) )
	{
		// 1'st Low Vision Head Offset X, Y
		if( ScanSys( strGetData, _T("1ST LOW VISION HEAD OFFSET X ="), clsSystemINI.m_sSystemDevice.d1stLowHeadOffset.x ) )
			continue;
		if( ScanSys( strGetData, _T("1ST LOW VISION HEAD OFFSET Y ="), clsSystemINI.m_sSystemDevice.d1stLowHeadOffset.y ) )
			continue;
		// 1'st High Vision Head Offset X, Y
		if( ScanSys( strGetData, _T("1ST HIGH VISION HEAD OFFSET X ="), clsSystemINI.m_sSystemDevice.d1stHighHeadOffset.x ) )
			continue;
		if( ScanSys( strGetData, _T("1ST HIGH VISION HEAD OFFSET Y ="), clsSystemINI.m_sSystemDevice.d1stHighHeadOffset.y ) )
			continue;
		
		// 1'st Theta axis center
		if( ScanSys( strGetData, _T("1ST THETA CENTER X ="), clsSystemINI.m_sSystemDevice.d1stThetaCenter.x ) )
			continue;
		if( ScanSys( strGetData, _T("1ST THETA CENTER Y ="), clsSystemINI.m_sSystemDevice.d1stThetaCenter.y ) )
			continue;
		// 1'st Laser Height
//		if( ScanSys( strGetData, _T("1ST LASER HEIGHT ="), clsSystemINI.m_sSystemDevice.d1stLaserHeight ) )
//			continue;
		for(int i=0; i<MOTOR_MASK_MAX; i++)
		{
			strTarget.Format(_T("1ST LASER HEIGHT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemDevice.d1stLaserHeight[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}
		for(int i = 0; i<MOTOR_MASK_MAX; i++)
		{
			strTarget.Format(_T("1ST LASER HEIGHT TOPHAT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemDevice.d1stLaserHeightTophat[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}
		// 1'st Low Vision Height
		if( ScanSys( strGetData, _T("1ST LOW VISION HEIGHT ="), clsSystemINI.m_sSystemDevice.d1stLowHeight ) )
			continue;
		// 1'st High Vision Height
		if( ScanSys( strGetData, _T("1ST HIGH VISION HEIGHT ="), clsSystemINI.m_sSystemDevice.d1stHighHeight ) )
			continue;
		// 2'nd Low Vision Head Offset X, Y
		if( ScanSys( strGetData, _T("2ND LOW VISION HEAD OFFSET X ="), clsSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x ) )
			continue;
		if( ScanSys( strGetData, _T("2ND LOW VISION HEAD OFFSET Y ="), clsSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y ) )
			continue;
		// 2'nd High Vision Head Offset X, Y
		if( ScanSys( strGetData, _T("2ND HIGH VISION HEAD OFFSET X ="), clsSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x ) )
			continue;
		if( ScanSys( strGetData, _T("2ND HIGH VISION HEAD OFFSET Y ="), clsSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y ) )
			continue;
		// 2nd Theta axis center
		if( ScanSys( strGetData, _T("2ND THETA CENTER X ="), clsSystemINI.m_sSystemDevice.d2ndThetaCenter.x ) )
			continue;
		if( ScanSys( strGetData, _T("2ND THETA CENTER Y ="), clsSystemINI.m_sSystemDevice.d2ndThetaCenter.y ) )
			continue;
		// 2'nd Laser Height
//		if( ScanSys( strGetData, _T("2ND LASER HEIGHT ="), clsSystemINI.m_sSystemDevice.d2ndLaserHeight ) )
//			continue;
		for(int i = 0; i<MOTOR_MASK_MAX; i++)
		{
			strTarget.Format(_T("2ND LASER HEIGHT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemDevice.d2ndLaserHeight[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}
		for(int i = 0; i<MOTOR_MASK_MAX; i++)
		{
			strTarget.Format(_T("2ND LASER HEIGHT TOPHAT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}
		// 2'nd Low Vision Height
		if( ScanSys( strGetData, _T("2ND LOW VISION HEIGHT ="), clsSystemINI.m_sSystemDevice.d2ndLowHeight ) )
			continue;
		// 2'nd High Vision Height
		if( ScanSys( strGetData, _T("2ND HIGH VISION HEIGHT ="), clsSystemINI.m_sSystemDevice.d2ndHighHeight ) )
			continue;

		//Vision Head Offset X
		if( ScanSys(strGetData, _T("VISION OFFSET X ="), clsSystemINI.m_sSystemDevice.dHeadOffsetX ) )
			continue;

		//Vision Head Offset Y
		if( ScanSys(strGetData, _T("VISION OFFSET Y ="), clsSystemINI.m_sSystemDevice.dHeadOffsetY ) )
			continue;

		// Scanner Field Size
		if( ScanSys( strGetData, _T("FIELD SIZE X ="), clsSystemINI.m_sSystemDevice.dFieldSize.x ) )
			continue;
		if( ScanSys( strGetData, _T("FIELD SIZE Y ="), clsSystemINI.m_sSystemDevice.dFieldSize.y ) )
			continue;
		
		// Origin Scanner Field Size
		if( ScanSys( strGetData, _T("ORIGIN FIELD SIZE X ="), clsSystemINI.m_sSystemDevice.dOriginFieldSize.x ) )
			continue;
		if( ScanSys( strGetData, _T("ORIGIN FIELD SIZE Y ="), clsSystemINI.m_sSystemDevice.dOriginFieldSize.y ) )
			continue;

		// PowerMeasurement Field Size
		if( ScanSys( strGetData, _T("POWER FIELD SIZE MX ="), clsSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x ) )
			continue;
		if( ScanSys( strGetData, _T("POWER FIELD SIZE MY ="), clsSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y ) )
			continue;
		if( ScanSys( strGetData, _T("POWER FIELD SIZE SX ="), clsSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x ) )
			continue;
		if( ScanSys( strGetData, _T("POWER FIELD SIZE SY ="), clsSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y ) )
			continue;

		//

		// 1'st Height Sensor ID
		if( ScanSys( strGetData, _T("1ST HEIGHT SENSOR ID ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemDevice.sz1stHeightSensorID, 1024, _T("%s"), strTarget );
		}
		// 2'nd Height Sensor ID
		if( ScanSys( strGetData, _T("2ND HEIGHT SENSOR ID ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemDevice.sz2ndHeightSensorID, 1024, _T("%s"), strTarget );
		}
		// Powermeter Port No
		if( ScanSys( strGetData, _T("POWERMETER PORT NO ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nPortNo ) )
			continue;
		// Powermeter Baudrate
		if( ScanSys( strGetData, _T("POWERMETER BAUDRATE ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nBaudRate ) )
			continue;
		// Powermeter Databits
		if( ScanSys( strGetData, _T("POWERMETER DATA BITS ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nDataBits ) )
			continue;
		// Powermeter Parity
		if( ScanSys( strGetData, _T("POWERMETER PARITY ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nParity ) )
			continue;
		// Powermeter Stopbits
		if( ScanSys( strGetData, _T("POWERMETER STOP BITS ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nStopBits ) )
			continue;
		// Powermeter Flow Control
		if( ScanSys( strGetData, _T("POWERMETER FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nFlowControl ) )
			continue;
		// Powermeter Time Out
		if( ScanSys( strGetData, _T("POWERMETER TIME OUT ="), clsSystemINI.m_sSystemDevice.sPowermeterPort.nTimeOut ) )
			continue;
		// Servo Port No
		if( ScanSys( strGetData, _T("SERVO PORT NO ="), clsSystemINI.m_sSystemDevice.sServoPort.nPortNo ) )
			continue;
		// Servo Baudrate
		if( ScanSys( strGetData, _T("SERVO BAUDRATE ="), clsSystemINI.m_sSystemDevice.sServoPort.nBaudRate ) )
			continue;
		// Chiller Port No
		if( ScanSys( strGetData, _T("CHILLER PORT NO ="), clsSystemINI.m_sSystemDevice.sChillerPort.nPortNo ) )
			continue;
		// Chiller Baudrate
		if( ScanSys( strGetData, _T("CHILLER BAUDRATE ="), clsSystemINI.m_sSystemDevice.sChillerPort.nBaudRate ) )
			continue;
		// Chiller data bit
		if( ScanSys( strGetData, _T("CHILLER DATA BITS ="), clsSystemINI.m_sSystemDevice.sChillerPort.nDataBits ) )
			continue;
		// Chiller Parity
		if( ScanSys( strGetData, _T("CHILLER PARITY ="), clsSystemINI.m_sSystemDevice.sChillerPort.nParity ) )
			continue;
		// Chiller Stopbits
		if( ScanSys( strGetData, _T("CHILLER STOP BITS ="), clsSystemINI.m_sSystemDevice.sChillerPort.nStopBits ) )
			continue;
		// Chiller Flow Control
		if( ScanSys( strGetData, _T("CHILLER FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sChillerPort.nFlowControl ) )
			continue;
		// Chiller Time Out
		if( ScanSys( strGetData, _T("CHILLER TIME OUT ="), clsSystemINI.m_sSystemDevice.sChillerPort.nTimeOut ) )
			continue;
		// Chiller CH1 Setting value
		if( ScanSys( strGetData, _T("CHILLER CH1 SETTING VALUE ="), clsSystemINI.m_sSystemDevice.sChillerPort.dCH1 ) )
			continue;
		// Chiller CH2 Setting value
		if( ScanSys( strGetData, _T("CHILLER CH2 SETTING VALUE ="), clsSystemINI.m_sSystemDevice.sChillerPort.dCH2 ) )
			continue;
		// Humidity Port No
		if( ScanSys( strGetData, _T("HUMIDITY PORT NO ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nPortNo ) )
			continue;
		// Humidity Baudrate
		if( ScanSys( strGetData, _T("HUMIDITY BAUDRATE ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nBaudRate ) )
			continue;
		// Humidity Databits
		if( ScanSys( strGetData, _T("HUMIDITY DATA BITS ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nDataBits ) )
			continue;
		// Humidity Parity
		if( ScanSys( strGetData, _T("HUMIDITY PARITY ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nParity ) )
			continue;
		// Humidity Stopbits
		if( ScanSys( strGetData, _T("HUMIDITY STOP BITS ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nStopBits ) )
			continue;
		// Humidity Flow Control
		if( ScanSys( strGetData, _T("HUMIDITY FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nFlowControl ) )
			continue;
		// Humidity Time Out
		if( ScanSys( strGetData, _T("HUMIDITY TIME OUT ="), clsSystemINI.m_sSystemDevice.sHumidityPort.nTimeOut ) )
			continue;

		// sTemperatureCompenPort Port No
		if( ScanSys( strGetData, _T("TEMPER_COMP PORT NO ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nPortNo ) )
			continue;
		// sTemperatureCompenPort Baudrate
		if( ScanSys( strGetData, _T("TEMPER_COMP BAUDRATE ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nBaudRate ) )
			continue;
		// sTemperatureCompenPort Databits
		if( ScanSys( strGetData, _T("TEMPER_COMP DATA BITS ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nDataBits ) )
			continue;
		// sTemperatureCompenPort Parity
		if( ScanSys( strGetData, _T("TEMPER_COMP PARITY ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nParity ) )
			continue;
		// sTemperatureCompenPort Stopbits
		if( ScanSys( strGetData, _T("TEMPER_COMP STOP BITS ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nStopBits ) )
			continue;
		// sTemperatureCompenPort Flow Control
		if( ScanSys( strGetData, _T("TEMPER_COMP FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nFlowControl ) )
			continue;
		// sTemperatureCompenPort Time Out
		if( ScanSys( strGetData, _T("TEMPER_COMP TIME OUT ="), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nTimeOut ) )
			continue;

		// LAMP Port No
		if( ScanSys( strGetData, _T("LAMP PORT NO ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nPortNo ) )
			continue;
		// LAMP Baudrate
		if( ScanSys( strGetData, _T("LAMP BAUDRATE ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nBaudRate ) )
			continue;
		// LAMP Databits
		if( ScanSys( strGetData, _T("LAMP DATA BITS ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nDataBits ) )
			continue;
		// LAMP Parity
		if( ScanSys( strGetData, _T("LAMP PARITY ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nParity ) )
			continue;
		// LAMP Stopbits
		if( ScanSys( strGetData, _T("LAMP STOP BITS ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nStopBits ) )
			continue;
		// LAMP Flow Control
		if( ScanSys( strGetData, _T("LAMP FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nFlowControl ) )
			continue;
		// LAMP Time Out
		if( ScanSys( strGetData, _T("LAMP TIME OUT ="), clsSystemINI.m_sSystemDevice.sVisionLampPort.nTimeOut ) )
			continue;

		// LAMP2 Port No
		if( ScanSys( strGetData, _T("LAMP2 PORT NO ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nPortNo ) )
			continue;
		// LAMP2 Baudrate
		if( ScanSys( strGetData, _T("LAMP2 BAUDRATE ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nBaudRate ) )
			continue;
		// LAMP2 Databits
		if( ScanSys( strGetData, _T("LAMP2 DATA BITS ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nDataBits ) )
			continue;
		// LAMP2 Parity
		if( ScanSys( strGetData, _T("LAMP2 PARITY ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nParity ) )
			continue;
		// LAMP2 Stopbits
		if( ScanSys( strGetData, _T("LAMP2 STOP BITS ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nStopBits ) )
			continue;
		// LAMP2 Flow Control
		if( ScanSys( strGetData, _T("LAMP2 FLOW CONTROL ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nFlowControl ) )
			continue;
		// LAMP2 Time Out
		if( ScanSys( strGetData, _T("LAMP2 TIME OUT ="), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nTimeOut ) )
			continue;

		// 1'st Low Vision Pixel X, Y
		if( ScanSys( strGetData, _T("1ST LOW VISION PIXEL X ="), clsSystemINI.m_sSystemDevice.d1stLowPixel.x ) )
			continue;
		if( ScanSys( strGetData, _T("1ST LOW VISION PIXEL Y ="), clsSystemINI.m_sSystemDevice.d1stLowPixel.y ) )
			continue;
		// 1'st High Vision Pixel X, Y
		if( ScanSys( strGetData, _T("1ST HIGH VISION PIXEL X ="), clsSystemINI.m_sSystemDevice.d1stHighPixel.x ) )
			continue;
		if( ScanSys( strGetData, _T("1ST HIGH VISION PIXEL Y ="), clsSystemINI.m_sSystemDevice.d1stHighPixel.y ) )
			continue;
		// 2'nd Low Vision Pixel X, Y
		if( ScanSys( strGetData, _T("2ND LOW VISION PIXEL X ="), clsSystemINI.m_sSystemDevice.d2ndLowPixel.x ) )
			continue;
		if( ScanSys( strGetData, _T("2ND LOW VISION PIXEL Y ="), clsSystemINI.m_sSystemDevice.d2ndLowPixel.y ) )
			continue;
		// 2'nd High Vision Pixel X, Y
		if( ScanSys( strGetData, _T("2ND HIGH VISION PIXEL X ="), clsSystemINI.m_sSystemDevice.d2ndHighPixel.x ) )
			continue;
		if( ScanSys( strGetData, _T("2ND HIGH VISION PIXEL Y ="), clsSystemINI.m_sSystemDevice.d2ndHighPixel.y ) )
			continue;
		if( ScanSys( strGetData, _T("SCAL LOW ROI ="), clsSystemINI.m_sSystemDevice.nLowCalArea ) )
			continue;
		if( ScanSys( strGetData, _T("SCAL HIGH ROI ="), clsSystemINI.m_sSystemDevice.nHighCalArea ) )
			continue;

		// LampController ComPort
		if( ScanSys( strGetData, _T("LampController ComPort ="), clsSystemINI.m_sSystemDevice.nLampComport ) )
			continue;

		// Fiducial Find Type
		if( ScanSys( strGetData, _T("Fiducial Find Type ="), clsSystemINI.m_sSystemDevice.nFiducialFindType ) )
			continue;

		// Eocard
		if( ScanSys( strGetData, _T("CHECK DOWN ASC VALUE ="), clsSystemINI.m_sSystemDevice.bCheckDownloadASCValue ) )
			continue;
		if( ScanSys( strGetData, _T("MIN CYCLE TIME ="), clsSystemINI.m_sSystemDevice.nMinCycleTime ) )
			continue;
		if( ScanSys( strGetData, _T("MIN SHOT TIME ="), clsSystemINI.m_sSystemDevice.nMinShotTime ) )
			continue;
		if( ScanSys( strGetData, _T("SHOT DRILL TYPE ="), clsSystemINI.m_sSystemDevice.nShotDrillType ) )
			continue;
		if( ScanSys( strGetData, _T("SELF LINE DIVIDE ="), clsSystemINI.m_sSystemDevice.nSelfLineDivide ) )
			continue;
		if( ScanSys( strGetData, _T("FLY DELAY TIME ="), clsSystemINI.m_sSystemDevice.nFlyingDelayTime ) )
			continue;
		if( ScanSys( strGetData, _T("NO USE VISION ="), clsSystemINI.m_sSystemDevice.nNoUseVision ) )
			continue;
		if( ScanSys( strGetData, _T("FID FIND IN CENTER ="), clsSystemINI.m_sSystemDevice.nUseFidFindInCenter ) )
			continue;
		// beam dumper 20070730
		if( ScanSys( strGetData, _T("DUMP1 X ="), clsSystemINI.m_sSystemDump.nPtBeanDumper1.x ) )
			continue;
		if( ScanSys( strGetData, _T("DUMP1 Y ="), clsSystemINI.m_sSystemDump.nPtBeanDumper1.y ) )
			continue;
		if( ScanSys( strGetData, _T("DUMP2 X ="), clsSystemINI.m_sSystemDump.nPtBeanDumper2.x ) )
			continue;
		if( ScanSys( strGetData, _T("DUMP2 Y ="), clsSystemINI.m_sSystemDump.nPtBeanDumper2.y ) )
			continue;
		// 2-d Table compensation
		if( ScanSys( strGetData, _T("2D TABLE COMP X ="), clsSystemINI.m_sSystemDevice.d2DCompTableOffset.x ) )
			continue;
		if( ScanSys( strGetData, _T("2D TABLE COMP Y ="), clsSystemINI.m_sSystemDevice.d2DCompTableOffset.y ) )
			continue;
		
		// Avia user level
		if( ScanSys( strGetData, _T("AVIA USER LEVEL ="), clsSystemINI.m_sSystemDevice.nAviaUserLevel ) )
			continue;
		
		// Laser Eocard download Count
		if( ScanSys( strGetData, _T("EOCARD DOWN COUNT ="), clsSystemINI.m_sSystemDevice.nEocardDownCount ) )
			continue;

		// Hole data check
		if( ScanSys( strGetData, _T("HOLE DATA CHECK ="), clsSystemINI.m_sSystemDevice.bCheckHoleData ) )
			continue;

		// Hood Auto Mode
		if( ScanSys( strGetData, _T("HOOD AUTO MODE ="), clsSystemINI.m_sSystemDevice.bUseHoodAutoMode ) )
			continue;

		// Laser Eocard dummy shot Count
		if( ScanSys( strGetData, _T("EOCARD DUMMY COUNT ="), clsSystemINI.m_sSystemDump.nDummyShot ) )
			continue;
		// Laser Eocard dummy shot interval
		if( ScanSys( strGetData, _T("EOCARD DUMMY INTERVAL ="), clsSystemINI.m_sSystemDump.nDummyInterval ) )
			continue;
		// Laser Eocard dummy shot Freq
		if( ScanSys( strGetData, _T("EOCARD DUMMY FREQ ="), clsSystemINI.m_sSystemDump.nDummyFreq ) )
			continue;
		// Laser Eocard dummy shot duty
		if( ScanSys( strGetData, _T("EOCARD DUMMY DUTY ="), clsSystemINI.m_sSystemDump.nDummyDuty ) )
			continue;
		// Laser Eocard dummy shot AOM delay
		if( ScanSys( strGetData, _T("EOCARD DUMMY AOMDELAY ="), clsSystemINI.m_sSystemDump.nDummyAOMDelay ) )
			continue;
		// Laser Eocard dummy shot AOM duty
		if( ScanSys( strGetData, _T("EOCARD DUMMY AOMDUTY ="), clsSystemINI.m_sSystemDump.nDummyAOMDuty ) )
			continue;

		// Laser Eocard dummy shot Count
		if( ScanSys( strGetData, _T("EOCARD DUMMY COUNT2 ="), clsSystemINI.m_sSystemDump.nDummyShot2 ) )
			continue;
		// Laser Eocard dummy shot interval
		if( ScanSys( strGetData, _T("EOCARD DUMMY INTERVAL2 ="), clsSystemINI.m_sSystemDump.nDummyInterval2 ) )
			continue;
		// Laser Eocard dummy shot Freq
		if( ScanSys( strGetData, _T("EOCARD DUMMY FREQ2 ="), clsSystemINI.m_sSystemDump.nDummyFreq2 ) )
			continue;
		// Laser Eocard dummy shot duty
		if( ScanSys( strGetData, _T("EOCARD DUMMY DUTY2 ="), clsSystemINI.m_sSystemDump.nDummyDuty2 ) )
			continue;
		// Laser Eocard dummy shot AOM delay
		if( ScanSys( strGetData, _T("EOCARD DUMMY AOMDELAY2 ="), clsSystemINI.m_sSystemDump.nDummyAOMDelay2 ) )
			continue;
		// Laser Eocard dummy shot AOM duty
		if( ScanSys( strGetData, _T("EOCARD DUMMY AOMDUTY2 ="), clsSystemINI.m_sSystemDump.nDummyAOMDuty2 ) )
			continue;

		// Laser Eocard dummy shot after table inposition
		if( ScanSys( strGetData, _T("EOCARD DUMMY AFTER TABLE STOP ="), clsSystemINI.m_sSystemDump.nDummyStartAfterTableStop ) )
			continue;
		
		// nStandbyTime
		if( ScanSys( strGetData, _T("STANDBY TIME ="), clsSystemINI.m_sSystemDump.nStandbyTime ) )
			continue;
		// nStandbyMinFreq
		if( ScanSys( strGetData, _T("STANDBY MIN FREQ ="), clsSystemINI.m_sSystemDump.nStandbyMinFreq ) )
			continue;
		
		// nStandbyMaxFreq
		if( ScanSys( strGetData, _T("STANDBY MAX FREQ ="), clsSystemINI.m_sSystemDump.nStandbyMaxFreq ) )
			continue;
		// nStandbyInterval
		if( ScanSys( strGetData, _T("STANDBY INTERVAL ="), clsSystemINI.m_sSystemDump.nStandbyInterval ) )
			continue;
		// nStandbyDuty
		if( ScanSys( strGetData, _T("STANDBY DUTY ="), clsSystemINI.m_sSystemDump.nStandbyDuty ) )
			continue;
		// nStandbyInpositionTime
		if( ScanSys( strGetData, _T("STANDBY INPOSITION TIME ="), clsSystemINI.m_sSystemDump.nStandbyInpositionTime ) )
			continue;
		// nStandbyV
		if( ScanSys( strGetData, _T("STANDBY V1 ="), clsSystemINI.m_sSystemDump.dStandby1stV ) )
			continue;
		// nStandbyV2
		if( ScanSys( strGetData, _T("STANDBY V2 ="), clsSystemINI.m_sSystemDump.dStandby2ndV ) )
			continue;
		// Trun off time 
		if( ScanSys( strGetData, _T("STANDBY TURNOFF TIME ="), clsSystemINI.m_sSystemDump.nStandbyTurnOffTime ) )
			continue;

		if( ScanSys( strGetData, _T("STANDBY TIME SCAL ="), clsSystemINI.m_sSystemDump.nStandbyTime_Scal ) )
			continue;

		// nStandbyTime2
		if( ScanSys( strGetData, _T("STANDBY TIME2 ="), clsSystemINI.m_sSystemDump.nStandbyTime2 ) )
			continue;
		// nStandbyMinFreq2
		if( ScanSys( strGetData, _T("STANDBY MIN FREQ2 ="), clsSystemINI.m_sSystemDump.nStandbyMinFreq2 ) )
			continue;
		
		// nStandbyMaxFreq2
		if( ScanSys( strGetData, _T("STANDBY MAX FREQ2 ="), clsSystemINI.m_sSystemDump.nStandbyMaxFreq2 ) )
			continue;
		// nStandbyInterval2
		if( ScanSys( strGetData, _T("STANDBY INTERVAL2 ="), clsSystemINI.m_sSystemDump.nStandbyInterval2 ) )
			continue;
		// nStandbyDuty2
		if( ScanSys( strGetData, _T("STANDBY DUTY2 ="), clsSystemINI.m_sSystemDump.nStandbyDuty2 ) )
			continue;
		// nStandbyInpositionTime2
		if( ScanSys( strGetData, _T("STANDBY INPOSITION TIME2 ="), clsSystemINI.m_sSystemDump.nStandbyInpositionTime2 ) )
			continue;
		// nStandbyV2
		if( ScanSys( strGetData, _T("STANDBY V12 ="), clsSystemINI.m_sSystemDump.dStandby1stV2 ) )
			continue;
		// nStandbyV2_2
		if( ScanSys( strGetData, _T("STANDBY V22 ="), clsSystemINI.m_sSystemDump.dStandby2ndV2 ) )
			continue;
		// Trun off time2
		if( ScanSys( strGetData, _T("STANDBY TURNOFF TIME2 ="), clsSystemINI.m_sSystemDump.nStandbyTurnOffTime2 ) )
			continue;

		//use dummy info
		if( ScanSys( strGetData, _T("USE DUMMY TYPE ="), clsSystemINI.m_sSystemDump.nUseDummyType ) )
			continue;
		
	

		// Vision Accept Score
		if( ScanSys( strGetData, _T("VISION ACCEPT SCORE ="), clsSystemINI.m_sSystemDevice.dAcceptScore ) )
		{
			gProcessINI.m_sProcessFidFind.dAcceptScore =  clsSystemINI.m_sSystemDevice.dAcceptScore;
			continue;
		}
		if( ScanSys( strGetData, _T("VISION ROTATE HOLE ACCEPT SCORE ="), clsSystemINI.m_sSystemDevice.dRotateHoleAcceptScore ) )
		{
			gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore =  clsSystemINI.m_sSystemDevice.dRotateHoleAcceptScore;
			continue;
		}
		if( ScanSys( strGetData, _T("VISION EDGE HOLE ACCEPT SCORE ="), clsSystemINI.m_sSystemDevice.dAcceptEdgeScore ) )
		{
			gProcessINI.m_sProcessFidFind.dAcceptEdgeScore =  clsSystemINI.m_sSystemDevice.dAcceptEdgeScore;
			continue;
		}
		if( ScanSys( strGetData, _T("VISION RESULT SCORE ="), clsSystemINI.m_sSystemDevice.dResultScore ) )
		{
			gProcessINI.m_sProcessFidFind.dResultScore =  clsSystemINI.m_sSystemDevice.dResultScore;
			continue;
		}
		// Vision Exposure
		if( ScanSys( strGetData, _T("VISION EXPOSURE ="), clsSystemINI.m_sSystemDevice.dExposure ) )
		{
			gProcessINI.m_sProcessFidFind.dExposure =  clsSystemINI.m_sSystemDevice.dExposure;
			continue;
		}
		// Cal.Grid Delay
		if( ScanSys( strGetData, _T("CALGRID DELAY ="), clsSystemINI.m_sSystemDevice.nCalGridDelay ) )
			continue;
		// Cal.Grid mode
		if( ScanSys( strGetData, _T("CALGRID MODE ="), clsSystemINI.m_sSystemDevice.nCalGridMode ) )
			continue;

		// vision FOV , camera pixel
		if( ScanSys( strGetData, _T("LOW FOV X ="), clsSystemINI.m_sSystemDevice.dLowFOVX ) )
			continue;
		if( ScanSys( strGetData, _T("LOW FOV Y ="), clsSystemINI.m_sSystemDevice.dLowFOVY ) )
			continue;
		if( ScanSys( strGetData, _T("HIGH FOV X ="), clsSystemINI.m_sSystemDevice.dHighFOVX ) )
			continue;
		if( ScanSys( strGetData, _T("HIGH FOV Y ="), clsSystemINI.m_sSystemDevice.dHighFOVY ) )
			continue;
		if( ScanSys( strGetData, _T("CAMERA PIXEL X ="), clsSystemINI.m_sSystemDevice.nCameraPixelX ) )
			continue;
		if( ScanSys( strGetData, _T("CAMERA PIXEL Y ="), clsSystemINI.m_sSystemDevice.nCameraPixelY ) )
			continue;


		if( ScanSys( strGetData, _T("COGNEX COARSE LIMIT ="), clsSystemINI.m_sSystemDevice.nCognex_CoarseLimit ) )
			continue;
		if( ScanSys( strGetData, _T("COGNEX COARSE LIMIT CENTER="), clsSystemINI.m_sSystemDevice.nCognex_CoarseLimitCenter ) )
			continue;
		if( ScanSys( strGetData, _T("COGNEX FINE LIMIT ="), clsSystemINI.m_sSystemDevice.nCognex_FineLimit ) )
			continue;



		if( ScanSys( strGetData, _T("BLOB ="), clsSystemINI.m_sSystemDevice.nBlob ) )
			continue;

		// EO Card EStop
		if( ScanSys( strGetData, _T("ESTOP ="), clsSystemINI.m_sSystemDevice.nEStop ) )
			continue;


		
		// Vibration Count
		if( ScanSys( strGetData, _T("VIB COUNT ="), clsSystemINI.m_sSystemDevice.nVibrationCount ) )
			continue;

		// Vibration Delay
		if( ScanSys( strGetData, _T("VIB DELAY ="), clsSystemINI.m_sSystemDevice.dVibrationDelay ) )
			continue;

		// Vibration Loader Picker Updown Count 
		if( ScanSys( strGetData, _T("VIB LP COUNT ="), clsSystemINI.m_sSystemDevice.nVibrationLPTime ) )
			continue;
		
		// Vacuum Offset
		if( ScanSys( strGetData, _T("VACUUM OFFSET ="), clsSystemINI.m_sSystemVacuum.dVacuumOffset ) )
			continue;

		// Vacuum Offset2
		if( ScanSys( strGetData, _T("VACUUM OFFSET2 ="), clsSystemINI.m_sSystemVacuum.dVacuumOffset2 ) )
			continue;

		// Dust Suction Hood Offset
		if( ScanSys( strGetData, _T("DUST SUCTION HOOD OFFSET ="), clsSystemINI.m_sSystemVacuum.dSuctionHoodOffset ) )
			continue;
		// Dust Suction error limit
		if( ScanSys( strGetData, _T("DUST SUCTION ERROR LIMIT ="), clsSystemINI.m_sSystemVacuum.dDustErrLimit ) )
			continue;
		// Scanner air error limit
		if( ScanSys( strGetData, _T("SCANNER AIR ERROR LIMIT ="), clsSystemINI.m_sSystemVacuum.dScannerAirLimit ) )
			continue;

		// Table1 Vacuum Limit
		for(int i=0; i<4; i++)
		{
			strTarget.Format(_T("TABLE1 VACUUM LIMIT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemVacuum.dTable1Vacuum[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}

		// Table2 Vacuum Limit
		for(int i=0; i<4; i++)
		{
			strTarget.Format(_T("TABLE2 VACUUM LIMIT #%d ="), i+1);
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( szTemp, BUFMAX, _T("%s"), strTarget );
			if( ScanSys( strGetData, szTemp, clsSystemINI.m_sSystemVacuum.dTable2Vacuum[i] ) )
			{
				sFile.ReadString(strGetData);
				continue;
			}
		}

		// Jump Speed
		if( ScanSys( strGetData, _T("JUMP SPEED ="), clsSystemINI.m_sSystemDevice.dJumpSpeed ) )
			continue;
		
		// Jump Delay
		if( ScanSys( strGetData, _T("JUMP DELAY ="), clsSystemINI.m_sSystemDevice.nJumpDelay ) )
			continue;
		
		// Corner Delay
		if( ScanSys( strGetData, _T("CORNER DELAY ="), clsSystemINI.m_sSystemDevice.nCornerDelay ) )
			continue;
		
		// Line Delay
		if( ScanSys( strGetData, _T("LINE DELAY ="), clsSystemINI.m_sSystemDevice.nLineDelay ) )
			continue;

		// Premove
		if( ScanSys( strGetData, _T("PRE MOVE ="), clsSystemINI.m_sSystemDevice.nPreMove ) )
			continue;
	
		// Jump Delay
		if( ScanSys( strGetData, _T("DEFAULT JUMP DELAY ="), clsSystemINI.m_sSystemDevice.nJumpDelayShot ) )
			continue;

		// Text char gab
		if( ScanSys( strGetData, _T("DEFAULT TEXT GAP ="), clsSystemINI.m_sSystemDevice.dTextGap ) )
			continue;
		// Text char Ref Mode
		if( ScanSys( strGetData, _T("DEFAULT TEXT REF ="), clsSystemINI.m_sSystemDevice.nTextRefMode ) )
			continue;
		// Text use inner OCR Font
		if( ScanSys( strGetData, _T("USE INNER OCR FONT ="), clsSystemINI.m_sSystemDevice.bUseInnerOCRFont ) )
			continue;

		//pixel 
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #1 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].x ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #1 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].y ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #1 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #1 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #2 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #2 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #2 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #2 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].y ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #3 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #3 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #3 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #3 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].y ) )
			continue;

		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #4 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #4 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[0][3].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #4 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST HIGH PIXEL #4 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[0][3].y ) )
			continue;


		//1st low 
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #1 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #1 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #1 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #1 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #2 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #2 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #2 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #2 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #3 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #3 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #3 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #3 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #4 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #4 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[1][3].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #4 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("1ST LOW PIXEL #4 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[1][3].y ) )
			continue;

		//2nd high
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #1 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #1 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #1 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #1 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #2 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #2 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #2 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #2 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #3 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #3 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #3 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #3 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #4 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #4 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[2][3].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #4 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND HIGH PIXEL #4 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[2][3].y ) )
			continue;

		//2nd low
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #1 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #1 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #1 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][0].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #1 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][0].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #2 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #2 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #2 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][1].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #2 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][1].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #3 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #3 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #3 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][2].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #3 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][2].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #4 X1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #4 Y1 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel1[3][3].y ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #4 X2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][3].x ) )
			continue;
		
		if( ScanSys( strGetData, _T("2ND LOW PIXEL #4 Y2 ="), clsSystemINI.m_sSystemDevice.dVisionPixcel2[3][3].y ) )
			continue;

		if( ScanSys( strGetData, _T("VISION MODEL ID ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemDevice.szVisionModelID, 1024, _T("%s"), strTarget );
		}

		if( ScanSys( strGetData, _T("2D BARCODE IP ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemDevice.szVision2DBarcodeIP, 1024, _T("%s"), strTarget );
		}

		if( ScanSys( strGetData, _T("2D BARCODE UNLOAD IP ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemDevice.szVision2DBarcodeUnloadIP, 1024, _T("%s"), strTarget );
		}

		//dual aom master
		if( ScanSys( strGetData, _T("DUAL AOM 1ST OFFSET ="), clsSystemINI.m_sSystemDevice.nDualAom1stOffset ) )
			continue;
		// dual aom slave
		if( ScanSys( strGetData, _T("DUAL AOM 2ND OFFSET ="), clsSystemINI.m_sSystemDevice.nDualAom2ndOffset ) )
			continue;
		
		//Table Limit Min X
		if( ScanSys( strGetData, _T("TABLE LIMIT MIN X ="), clsSystemINI.m_sSystemDevice.dTableLimitMinX ) )
			continue;
		//Table Limit Min Y
		if( ScanSys( strGetData, _T("TABLE LIMIT MIN Y ="), clsSystemINI.m_sSystemDevice.dTableLimitMinY ) )
			continue;
		//Table Limit Max X
		if( ScanSys( strGetData, _T("TABLE LIMIT MAX X ="), clsSystemINI.m_sSystemDevice.dTableLimitMaxX ) )
			continue;
		//Table Limit Max Y
		if( ScanSys( strGetData, _T("TABLE LIMIT MAX Y ="), clsSystemINI.m_sSystemDevice.dTableLimitMaxY ) )
			continue;
		//Table Size X
		if( ScanSys( strGetData, _T("TABLE SIZE X ="), clsSystemINI.m_sSystemDevice.dTableSizeX ) )
			continue;
		//Table Size Y
		if( ScanSys( strGetData, _T("TABLE SIZE Y ="), clsSystemINI.m_sSystemDevice.dTableSizeY ) )
			continue;
		//Table Size X
		if( ScanSys( strGetData, _T("TABLE ACR SIZE X ="), clsSystemINI.m_sSystemDevice.dTableAcrSizeX ) )
			continue;
		//Table Size Y
		if( ScanSys( strGetData, _T("TABLE ACR SIZE Y ="), clsSystemINI.m_sSystemDevice.dTableAcrSizeY ) )
			continue;
		//MASK INPOS WAIT TIME MS
		if( ScanSys( strGetData, _T("MASK INPOS WAIT TIME MS ="), clsSystemINI.m_sSystemDevice.nMaskInposWait ) )
		{
			clsSystemINI.m_sSystemDevice.nMaskInposWait = 0;
			continue;
		}
		if( ScanSys( strGetData, _T("Water Flow Setting 1 ="), clsSystemINI.m_sSystemDevice.dWaterFlowSetting1 ) )
			continue;
		if( ScanSys( strGetData, _T("Water Flow Setting 2 ="), clsSystemINI.m_sSystemDevice.dWaterFlowSetting2 ) )
			continue;
		if( ScanSys( strGetData, _T("Main Air Setting ="), clsSystemINI.m_sSystemDevice.dMainAirSetting ) )
			continue;
		if( ScanSys( strGetData, _T("Dust Suction Setting ="), clsSystemINI.m_sSystemDevice.dDustSuctionSetting ) )
			continue;
		if( ScanSys( strGetData, _T("Table Vacuum Setting 1 ="), clsSystemINI.m_sSystemDevice.dTableVacuumSetting1 ) )
			continue;
		if( ScanSys( strGetData, _T("Table Vacuum Setting 2 ="), clsSystemINI.m_sSystemDevice.dTableVacuumSetting2 ) )
			continue;

		if( ScanSys( strGetData, _T("AOM Water Flow Setting 1 ="), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting1 ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Water Flow Setting 2 ="), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting2 ) )
			continue;

		if( ScanSys( strGetData, _T("AOM Water Flow Setting 3 ="), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting3 ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Water Flow Setting 4 ="), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting4 ) )
			continue;


		if( ScanSys( strGetData, _T("Water Flow Offset Setting 1 ="), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting1 ) )
			continue;
		if( ScanSys( strGetData, _T("Water Flow Offset Setting 2 ="), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting2 ) )
			continue;

		if( ScanSys( strGetData, _T("Water Flow Offset Setting 3 ="), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting3 ) )
			continue;
		if( ScanSys( strGetData, _T("Water Flow Offset Setting 4 ="), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting4 ) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END SYSTEM DEVICE SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CSystemINIFile::ParsingSystemCollimator(CStdioFile& sFile, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData, strTarget;
	int nIndex = 0;

	for(int i = 0; i < 10; i++) // initial = 0
	{
		clsSystemINI.m_sSystemCollimator.nAOMDelayOffset[i] = 0;
		clsSystemINI.m_sSystemCollimator.nAOMDutyOffset[i] = 0;
	}

	while( sFile.ReadString( strGetData ) )
	{
		// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
			continue;
		// Position
		if( ScanSys( strGetData, _T("POSITION ="), clsSystemINI.m_sSystemCollimator.sCollimatorPos[nIndex].dPositon ) )
			continue;
		//Position 2
		if( ScanSys( strGetData, _T("POSITION2 ="), clsSystemINI.m_sSystemCollimator.sCollimatorPos2[nIndex].dPositon ) )
			continue;
		//Position 3
//		if( ScanSys( strGetData, _T("POSITION3 ="), clsSystemINI.m_sSystemCollimator.sCollimatorPos3[nIndex].dPositon ) )
//			continue;
		//Position 4
//		if( ScanSys( strGetData, _T("POSITION4 ="), clsSystemINI.m_sSystemCollimator.sCollimatorPos4[nIndex].dPositon ) )
//			continue;
		// Measured Power
//		if( ScanSys( strGetData, _T("MEASURED POWER ="), clsSystemINI.m_sSystemCollimator.sCollimatorPos[nIndex].dMeasuredPower ) )
//			continue;
		// Mask Position
		if( ScanSys( strGetData, _T("MASK POSITION ="), clsSystemINI.m_sSystemCollimator.dMaskPosition[nIndex] ) )
			continue;
		// Mask Position2
//		if( ScanSys( strGetData, _T("MASK POSITION2 ="), clsSystemINI.m_sSystemCollimator.dMaskPosition2[nIndex] ) )
//			continue;
		// Mask Size
		if( ScanSys( strGetData, _T("MASK SIZE ="), clsSystemINI.m_sSystemCollimator.dMaskSize[nIndex] ) )
			continue;
		// Beam Size
		if( ScanSys( strGetData, _T("BEAM SIZE ="), clsSystemINI.m_sSystemCollimator.dBeamSize[nIndex] ) )
			continue;
		// Collimator Moving Step
//		if( ScanSys( strGetData, _T("COLLIMATOR MOVING STEP ="), clsSystemINI.m_sSystemCollimator.dCollimatorMovingStep ) )
//			continue;
		// Power Tolerance
//		if( ScanSys( strGetData, _T("POWER TOLERANCE ="), clsSystemINI.m_sSystemCollimator.dPowerTolerance ) )
//			continue;
		// Power Deviation
//		if( ScanSys( strGetData, _T("POWER DEVIATION ="), clsSystemINI.m_sSystemCollimator.dPowerDeviation ) )
//			continue;
		// Duty Offset
		if( ScanSys( strGetData, _T("Duty Offset ="), clsSystemINI.m_sSystemCollimator.nDutyOffset[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Delay Offset ="), clsSystemINI.m_sSystemCollimator.nAOMDelayOffset[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Duty Offset ="), clsSystemINI.m_sSystemCollimator.nAOMDutyOffset[nIndex] ) )
			continue;
		
		//Power Compensation
		if( ScanSys( strGetData, _T("Power Duty ="), clsSystemINI.m_sSystemCollimator.dPowerDuty[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power Freq ="), clsSystemINI.m_sSystemCollimator.nPowerFreq[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power A1 ="), clsSystemINI.m_sSystemCollimator.dAttenuator1[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power A2 ="), clsSystemINI.m_sSystemCollimator.dAttenuator2[nIndex] ) )
			continue;



		//Memo
		if( ScanSys( strGetData, _T("MEMO ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemCollimator.sMemo[nIndex].szMemo, 1024, _T("%s"), strTarget );
		}
		
		//Fixed Mask
		if( ScanSys( strGetData, _T("Fixed Mask Pos ="), clsSystemINI.m_sSystemCollimator.dFixedMask ) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END SYSTEM COLLIMATOR SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}
BOOL CSystemINIFile::ParsingSystemTophat(CStdioFile& sFile, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData, strTarget;
	int nIndex = 0;
	
	for(int i = 0; i < 10; i++) // initial = 0
	{
		clsSystemINI.m_sSystemTophat.nAOMDelayOffset[i] = 0;
		clsSystemINI.m_sSystemTophat.nAOMDutyOffset[i] = 0;
	}
	
	while( sFile.ReadString( strGetData ) )
	{
		// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
			continue;
		// Position
		if( ScanSys( strGetData, _T("POSITION ="), clsSystemINI.m_sSystemTophat.sCollimatorPos[nIndex].dPositon ) )
			continue;
		//Position 2
		if( ScanSys( strGetData, _T("POSITION2 ="), clsSystemINI.m_sSystemTophat.sCollimatorPos2[nIndex].dPositon ) )
			continue;
		// Mask Position
		if( ScanSys( strGetData, _T("MASK POSITION ="), clsSystemINI.m_sSystemTophat.dMaskPosition[nIndex] ) )
			continue;
		// Mask Size
		if( ScanSys( strGetData, _T("MASK SIZE ="), clsSystemINI.m_sSystemTophat.dMaskSize[nIndex] ) )
			continue;
		// Beam Size
		if( ScanSys( strGetData, _T("BEAM SIZE ="), clsSystemINI.m_sSystemTophat.dBeamSize[nIndex] ) )
			continue;
		// Duty Offset
		if( ScanSys( strGetData, _T("Duty Offset ="), clsSystemINI.m_sSystemTophat.nDutyOffset[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Delay Offset ="), clsSystemINI.m_sSystemTophat.nAOMDelayOffset[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("AOM Duty Offset ="), clsSystemINI.m_sSystemTophat.nAOMDutyOffset[nIndex] ) )
			continue;

		//Power Compensation
		if( ScanSys( strGetData, _T("Power Duty ="), clsSystemINI.m_sSystemTophat.dPowerDuty[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power Freq ="), clsSystemINI.m_sSystemTophat.nPowerFreq[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power A1 ="), clsSystemINI.m_sSystemTophat.dAttenuator1[nIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("Power A2 ="), clsSystemINI.m_sSystemTophat.dAttenuator2[nIndex] ) )
			continue;

		//Memo
		if( ScanSys( strGetData, _T("MEMO ="), strTarget ) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsSystemINI.m_sSystemTophat.sMemo[nIndex].szMemo, 1024, _T("%s"), strTarget );
		}
				
		if( 0 == strGetData.CompareNoCase(_T("// END SYSTEM TOPHAT SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}
	
	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}
BOOL CSystemINIFile::ParsingAxisInfo(CStdioFile& sFile, DSystemINI& clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;

	int nIndex;
	CString strAxis;

	while( sFile.ReadString( strGetData ) )
	{
		// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
		{
			strAxis = "";

			switch(nIndex)
			{

			case 0: strAxis.Format(_T("X")); break;
			case 1: strAxis.Format(_T("Y")); break;
			case 2: strAxis.Format(_T("Z1")); break;
			case 3: strAxis.Format(_T("Z2")); break;
			case 4: strAxis.Format(_T("Mask1")); break;
			case 5: strAxis.Format(_T("Mask2")); break;
			case 6: strAxis.Format(_T("BET1")); break;
			case 7: strAxis.Format(_T("BET2")); break;
			case 8: strAxis.Format(_T("BET3")); break;
			case 9: strAxis.Format(_T("BET4")); break;
			}
			continue;
		}

		strcpy_s(clsSystemINI.m_sAxisInfo[nIndex].szName, strAxis);
		if( ScanSys( strGetData, _T("Scale ="), clsSystemINI.m_sAxisInfo[nIndex].dScale) )
			continue;
		if( ScanSys( strGetData, _T("TableFeedRate ="), clsSystemINI.m_sAxisInfo[nIndex].dTableFeedRate ) )
			continue;
		if( ScanSys( strGetData, _T("TableAcceleration ="), clsSystemINI.m_sAxisInfo[nIndex].dTableAcceleration ) )
			continue;
		if( ScanSys( strGetData, _T("TableSCurve ="), clsSystemINI.m_sAxisInfo[nIndex].dTableSCurve ) )
			continue;
		
		if( ScanSys( strGetData, _T("TableAccelerationPre ="), clsSystemINI.m_sAxisInfo[nIndex].dTableAccelerationPre ) )
			continue;
		if( ScanSys( strGetData, _T("TableSCurvePre ="), clsSystemINI.m_sAxisInfo[nIndex].dTableSCurvePre ) )
			continue;
		if( ScanSys( strGetData, _T("TableAccelerationNext ="), clsSystemINI.m_sAxisInfo[nIndex].dTableAccelerationNext ) )
			continue;
		if( ScanSys( strGetData, _T("TableSCurveNext ="), clsSystemINI.m_sAxisInfo[nIndex].dTableSCurveNext ) )
			continue;

		if( ScanSys( strGetData, _T("LimitPlus ="), clsSystemINI.m_sAxisInfo[nIndex].dLimitPlus ) )
			continue;
		if( ScanSys( strGetData, _T("LimitMinus ="), clsSystemINI.m_sAxisInfo[nIndex].dLimitMinus ) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END AXIS INFO SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CSystemINIFile::SaveSystemINIFile(CString strFilePath, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
//		CString strMsg;

//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
//		ErrMessage(strMsg, MB_ICONERROR);

		return bRet;
	}

	CString strSetData;

	strSetData.Format(_T("// START EASYDRILLER SYSTEM INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );

	SaveHardware( sFile, clsSystemINI );
	SaveSystemDevice( sFile, clsSystemINI );
	SaveSystemCollimator( sFile, clsSystemINI );
	SaveSystemTophat( sFile, clsSystemINI );
	SaveAxisInfo( sFile, clsSystemINI );
	SaveComponent(sFile,clsSystemINI);
	

	strSetData.Format(_T("// END EASYDRILLER SYSTEM INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	sFile.Close();
	bRet = TRUE;

	return bRet;
}


BOOL CSystemINIFile::SaveComponent(CStdioFile &sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	CString strTemp;

	strSetData.Format(_T("// START SYSTEM COMPONENT SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );	

	//preacq time
	strSetData.Format(_T("COMPONENT PREACQTIME = %d\n"), clsSystemINI.m_sSystemComponent.nPreAcTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END COMPONENT SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	return bRet;
}


BOOL CSystemINIFile::SaveHardware(CStdioFile& sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	CString strTemp;

	strSetData.Format(_T("// START HARDWARE SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser type : CO2, UV, CO2+UV, LV100, IPG PULSE
	strSetData.Format(_T("LASER TYPE = %d\n"), clsSystemINI.m_sHardWare.nLaserType);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Beam : 1, 2, 3, 4-beam
	strSetData.Format(_T("BEAM TYPE = %d\n"), clsSystemINI.m_sHardWare.nBeamType);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use RS232 com : Lamp (coaxial, ring)
	strSetData.Format(_T("USE LAMP RS232 = %d\n"), clsSystemINI.m_sHardWare.nUseLampRS232);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// TableClamp Num
	strSetData.Format(_T("TABLE CLAMP = %d\n"), clsSystemINI.m_sHardWare.nTableClamp);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vision Type : omi, matrox
	strSetData.Format(_T("VISION TYPE = %d\n"), clsSystemINI.m_sHardWare.nVisionType);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Beam Dumper Use 20070730
	strSetData.Format(_T("DUMPER USE = %d\n"), clsSystemINI.m_sHardWare.nUseBeamDumper);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Manual Machine (no use loader/unloader)
	strSetData.Format(_T("MANUAL MACHINE = %d\n"), clsSystemINI.m_sHardWare.nManualMachine);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Table Dust ����
	strSetData.Format(_T("TABLE DUST REMOVE = %d\n"), clsSystemINI.m_sHardWare.nDustTableUse);
	sFile.WriteString( (LPCTSTR)strSetData );

	// scanner axis type
	strSetData.Format(_T("SCANNER AXIS = %d\n"), clsSystemINI.m_sHardWare.nScannerAxisType);
	sFile.WriteString( (LPCTSTR)strSetData );

	// scanner axis type
	strSetData.Format(_T("SCANNER AXIS 2 = %d\n"), clsSystemINI.m_sHardWare.nScannerAxisType2);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("EXCELLON AXIS = %d\n"), clsSystemINI.m_sHardWare.nExcellonOpenAxis);
	sFile.WriteString( (LPCTSTR)strSetData );

	// AOM Option
	strSetData.Format(_T("AOM TYPE = %d\n"), clsSystemINI.m_sHardWare.nAOMType);
	sFile.WriteString( (LPCTSTR)strSetData );

	// EOCard Type
	strSetData.Format(_T("EOCARD TYPE = %d\n"), clsSystemINI.m_sHardWare.nEocardType);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCANNER USE AOD = %d\n"), clsSystemINI.m_sHardWare.nUseAOD);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("AOD MS SELECT = %d\n"), clsSystemINI.m_sHardWare.nAODMSSelect);
	sFile.WriteString( (LPCTSTR)strSetData );

	// scanner use info
	strSetData.Format(_T("SCANNER USE INFO = %d\n"), clsSystemINI.m_sHardWare.nUseEocardAxis);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("AOM USE FIRST ORDER = %d\n"), clsSystemINI.m_sHardWare.nUseFirstOrder);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("USE DUALBAND = %d\n"), clsSystemINI.m_sHardWare.nUseDualBand);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LANGUAGE TYPE = %d\n"), clsSystemINI.m_sHardWare.nLanguageType);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCANNER POS WARN = %.4f\n"), clsSystemINI.m_sHardWare.dScannerWaringLevelmm);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("SCANNER POS ALARM = %.4f\n"), clsSystemINI.m_sHardWare.dScannerAlarmLevelmm);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE FAST INPOSITION = %d\n"), clsSystemINI.m_sHardWare.bUseFastInposition);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SHORT LINE DUTY OFFSET = %d\n"), clsSystemINI.m_sHardWare.nShortLineDutyOffset);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SHORT LINE LENGTH = %d\n"), clsSystemINI.m_sHardWare.nShortLineLength);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("TABLE VACUUM SELECT = %d\n"), clsSystemINI.m_sHardWare.bTableVacuumSelect);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Barcode Reader
	strSetData.Format(_T("BARCODE READER = %d\n"), clsSystemINI.m_sHardWare.nUseBarcodeReader);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Wide Monitor
	strSetData.Format(_T("WIDE MONITOR = %d\n"), clsSystemINI.m_sHardWare.bUseWideMonitor);
	sFile.WriteString( (LPCTSTR)strSetData );

	// bUseVacummmotor
	strSetData.Format(_T("USE VACUMM MOTOR = %d\n"), clsSystemINI.m_sHardWare.bUseVacummmotor);
	sFile.WriteString( (LPCTSTR)strSetData );

	// auto lock time
	strSetData.Format(_T("AUTO LOCK TIME SEC = %d\n"), clsSystemINI.m_sHardWare.nAutoLockTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LPC MIN TOL = %.2f\n"), clsSystemINI.m_sHardWare.dLPCMinTolerence);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LPC MAX TOL = %.2f\n"), clsSystemINI.m_sHardWare.dLPCMaxTolerence);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PRE LPC MIN TOL = %.2f\n"), clsSystemINI.m_sHardWare.dPreLPCMinTolerence);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PRE LPC MAX TOL = %.2f\n"), clsSystemINI.m_sHardWare.dPreLPCMaxTolerence);
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("PRE LPC MAX VALUE OFFSET = %.2f\n"), clsSystemINI.m_sHardWare.dPreLPCMaxValueOffset);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LPC MINIMUM = %d\n"), clsSystemINI.m_sHardWare.nLPCMinimum);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LPC START TOL PERCENT = %.2f\n"), clsSystemINI.m_sHardWare.dLPCStartTolerencePercent);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LPC HOLE DEVIATION PERCENT = %.2f\n"), clsSystemINI.m_sHardWare.dLPCHoleDeviationTolPercent);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LPC START SKIP COUNT = %d\n"), clsSystemINI.m_sHardWare.nLPCStartSkipCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PRE LPC SHOT COUNT = %d\n"), clsSystemINI.m_sHardWare.nPreLPCShotCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("USE LPC = %d\n"), clsSystemINI.m_sHardWare.bUseLPC);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MACHINE NO = %d\n"), clsSystemINI.m_sHardWare.nMachineNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("TABLE SHOOT LIMIT = %d\n"), clsSystemINI.m_sHardWare.nTableShootLimit);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LASER CAL ALARM = %d\n"), clsSystemINI.m_sHardWare.bLaserCalAlarm);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SAVE BUTTON LOG = %d\n"), clsSystemINI.m_sHardWare.bSaveButtonLog); // 20130522
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("CHILLER SERIAL CONNECT = %d\n"), clsSystemINI.m_sHardWare.bChillerConnect);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("HUMIDITY SERIAL CONNECT = %d\n"), clsSystemINI.m_sHardWare.bHumidityConnect); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("TEMPER_COMP SERIAL CONNECT = %d\n"), clsSystemINI.m_sHardWare.bTemperCompConnect); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VOLTAGE IP CONNECT = %d\n"), clsSystemINI.m_sHardWare.bVoltageConnect); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LINK RS485 = %d\n"), clsSystemINI.m_sHardWare.bLinkRS485); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MC MODE = %d\n"), clsSystemINI.m_sHardWare.bCheckMCMode); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("OFFSET MODE = %d\n"), clsSystemINI.m_sHardWare.bFirstOffsetMode); 
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END HARDWARE SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );


	return bRet;
}

BOOL CSystemINIFile::SaveSystemDevice(CStdioFile& sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	CString strTemp;

	strSetData.Format(_T("// START SYSTEM DEVICE SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Low Vision Head Offset X, Y
	strSetData.Format(_T("1ST LOW VISION HEAD OFFSET X = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stLowHeadOffset.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("1ST LOW VISION HEAD OFFSET Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stLowHeadOffset.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st High Vision Head Offset X, Y
	strSetData.Format(_T("1ST HIGH VISION HEAD OFFSET X = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stHighHeadOffset.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("1ST HIGH VISION HEAD OFFSET Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stHighHeadOffset.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Theta center 
	strSetData.Format(_T("1ST THETA CENTER X = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stThetaCenter.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("1ST THETA CENTER Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stThetaCenter.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Laser Height
//	strSetData.Format(_T("1ST LASER HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stLaserHeight);
//	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i=0; i<MOTOR_MASK_MAX; i++)
	{
		strTemp.Format(_T("1ST LASER HEIGHT #%d"), i+1);
		strSetData.Format(_T("%s = %.3f\n"), strTemp, clsSystemINI.m_sSystemDevice.d1stLaserHeight[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	for(int i = 0; i<MOTOR_MASK_MAX; i++)
	{
		strTemp.Format(_T("1ST LASER HEIGHT TOPHAT #%d"), i+1);
		strSetData.Format(_T("%s = %.3f\n"), strTemp, clsSystemINI.m_sSystemDevice.d1stLaserHeightTophat[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	// 1'st Low Vision Height
	strSetData.Format(_T("1ST LOW VISION HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stLowHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st High Vision Height
	strSetData.Format(_T("1ST HIGH VISION HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d1stHighHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Low Vision Head Offset X, Y
	strSetData.Format(_T("2ND LOW VISION HEAD OFFSET X = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2ND LOW VISION HEAD OFFSET Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd High Vision Head Offset X, Y
	strSetData.Format(_T("2ND HIGH VISION HEAD OFFSET X = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2ND HIGH VISION HEAD OFFSET Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2nd Theta center 
	strSetData.Format(_T("2ND THETA CENTER X = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndThetaCenter.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2ND THETA CENTER Y = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndThetaCenter.y);
	sFile.WriteString( (LPCTSTR)strSetData );


	// 2'nd Laser Height
//	strSetData.Format(_T("2ND LASER HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndLaserHeight);
//	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i = 0; i<MOTOR_MASK_MAX; i++)
	{
		strTemp.Format(_T("2ND LASER HEIGHT #%d"), i+1);
		strSetData.Format(_T("%s = %.3f\n"), strTemp, clsSystemINI.m_sSystemDevice.d2ndLaserHeight[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	for(int i = 0; i<MOTOR_MASK_MAX; i++)
	{
		strTemp.Format(_T("2ND LASER HEIGHT TOPHAT #%d"), i+1);
		strSetData.Format(_T("%s = %.3f\n"), strTemp, clsSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}	

	// 2'nd Low Vision Height
	strSetData.Format(_T("2ND LOW VISION HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndLowHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd High Vision Height
	strSetData.Format(_T("2ND HIGH VISION HEIGHT = %.3f\n"), clsSystemINI.m_sSystemDevice.d2ndHighHeight);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Vision Head Offset X 
	strSetData.Format(_T("VISION OFFSET X = %.3f\n"), clsSystemINI.m_sSystemDevice.dHeadOffsetX);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Vision Head Offset Y
	strSetData.Format(_T("VISION OFFSET Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dHeadOffsetY);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Scanner Field Size
	strSetData.Format(_T("FIELD SIZE X = %.3f\n"), clsSystemINI.m_sSystemDevice.dFieldSize.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FIELD SIZE Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dFieldSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Origin Scanner Field Size
	strSetData.Format(_T("ORIGIN FIELD SIZE X = %.3f\n"), clsSystemINI.m_sSystemDevice.dOriginFieldSize.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("ORIGIN FIELD SIZE Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dOriginFieldSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// PowerMeasurement Field Size
	strSetData.Format(_T("POWER FIELD SIZE MX = %.3f\n"), clsSystemINI.m_sSystemDevice.dPowerMeasurementMSize.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("POWER FIELD SIZE MY = %.3f\n"), clsSystemINI.m_sSystemDevice.dPowerMeasurementMSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("POWER FIELD SIZE SX = %.3f\n"), clsSystemINI.m_sSystemDevice.dPowerMeasurementSSize.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("POWER FIELD SIZE SY = %.3f\n"), clsSystemINI.m_sSystemDevice.dPowerMeasurementSSize.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st Height Sensor ID
	strSetData.Format(_T("1ST HEIGHT SENSOR ID = %s\n"), clsSystemINI.m_sSystemDevice.sz1stHeightSensorID);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd Height Sensor ID
	strSetData.Format(_T("2ND HEIGHT SENSOR ID = %s\n"), clsSystemINI.m_sSystemDevice.sz2ndHeightSensorID);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Port No
	strSetData.Format(_T("POWERMETER PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Baudrate
	strSetData.Format(_T("POWERMETER BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Databits
	strSetData.Format(_T("POWERMETER DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Parity
	strSetData.Format(_T("POWERMETER PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Stopbits
	strSetData.Format(_T("POWERMETER STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Flow Control
	strSetData.Format(_T("POWERMETER FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Powermeter Time Out
	strSetData.Format(_T("POWERMETER TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sPowermeterPort.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Servo Port No
	strSetData.Format(_T("SERVO PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sServoPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Servo Baudrate
	strSetData.Format(_T("SERVO BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sServoPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Port No
	strSetData.Format(_T("CHILLER PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Baudrate
	strSetData.Format(_T("CHILLER BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Parity
	strSetData.Format(_T("CHILLER PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Stopbits
	strSetData.Format(_T("CHILLER STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Flow Control
	strSetData.Format(_T("CHILLER FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Time Out
	strSetData.Format(_T("CHILLER TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller Data bit
	strSetData.Format(_T("CHILLER DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sChillerPort.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller CH1 Setting value
	strSetData.Format(_T("CHILLER CH1 SETTING VALUE = %.3f\n"), clsSystemINI.m_sSystemDevice.sChillerPort.dCH1);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Chiller CH2 Setting value
	strSetData.Format(_T("CHILLER CH2 SETTING VALUE = %.3f\n"), clsSystemINI.m_sSystemDevice.sChillerPort.dCH2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Port No
	strSetData.Format(_T("HUMIDITY PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Baudrate
	strSetData.Format(_T("HUMIDITY BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Databits
	strSetData.Format(_T("HUMIDITY DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Parity
	strSetData.Format(_T("HUMIDITY PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Stopbits
	strSetData.Format(_T("HUMIDITY STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Flow Control
	strSetData.Format(_T("HUMIDITY FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Humidity Time Out
	strSetData.Format(_T("HUMIDITY TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sHumidityPort.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );


	// sTemperatureCompenPort Port No
	strSetData.Format(_T("TEMPER_COMP PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Baudrate
	strSetData.Format(_T("TEMPER_COMP BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Databits
	strSetData.Format(_T("TEMPER_COMP DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Parity
	strSetData.Format(_T("TEMPER_COMP PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Stopbits
	strSetData.Format(_T("TEMPER_COMP STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Flow Control
	strSetData.Format(_T("TEMPER_COMP FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// sTemperatureCompenPort Time Out
	strSetData.Format(_T("TEMPER_COMP TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sTemperatureCompenPort.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Port No
	strSetData.Format(_T("LAMP PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Baudrate
	strSetData.Format(_T("LAMP BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Databits
	strSetData.Format(_T("LAMP DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Parity
	strSetData.Format(_T("LAMP PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Stopbits
	strSetData.Format(_T("LAMP STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Flow Control
	strSetData.Format(_T("LAMP FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Time Out
	strSetData.Format(_T("LAMP TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp Port No
	strSetData.Format(_T("LAMP2 PORT NO = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nPortNo);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Baudrate
	strSetData.Format(_T("LAMP2 BAUDRATE = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nBaudRate);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Databits
	strSetData.Format(_T("LAMP2 DATA BITS = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nDataBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Parity
	strSetData.Format(_T("LAMP2 PARITY = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nParity);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Stopbits
	strSetData.Format(_T("LAMP2 STOP BITS = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nStopBits);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Flow Control
	strSetData.Format(_T("LAMP2 FLOW CONTROL = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nFlowControl);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Lamp2 Time Out
	strSetData.Format(_T("LAMP2 TIME OUT = %d\n"), clsSystemINI.m_sSystemDevice.sVisionLampPort2.nTimeOut);
	sFile.WriteString( (LPCTSTR)strSetData );


	// 1'st Low Vision Pixel X, Y
	strSetData.Format(_T("1ST LOW VISION PIXEL X = %.10f\n"), clsSystemINI.m_sSystemDevice.d1stLowPixel.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("1ST LOW VISION PIXEL Y = %.10f\n"), clsSystemINI.m_sSystemDevice.d1stLowPixel.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1'st High Vision Pixel X, Y
	strSetData.Format(_T("1ST HIGH VISION PIXEL X = %.10f\n"), clsSystemINI.m_sSystemDevice.d1stHighPixel.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("1ST HIGH VISION PIXEL Y = %.10f\n"), clsSystemINI.m_sSystemDevice.d1stHighPixel.y);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// 2'nd Low Vision Pixel X, Y
	strSetData.Format(_T("2ND LOW VISION PIXEL X = %.10f\n"), clsSystemINI.m_sSystemDevice.d2ndLowPixel.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2ND LOW VISION PIXEL Y = %.10f\n"), clsSystemINI.m_sSystemDevice.d2ndLowPixel.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2'nd High Vision Pixel X, Y
	strSetData.Format(_T("2ND HIGH VISION PIXEL X = %.10f\n"), clsSystemINI.m_sSystemDevice.d2ndHighPixel.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2ND HIGH VISION PIXEL Y = %.10f\n"), clsSystemINI.m_sSystemDevice.d2ndHighPixel.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCAL LOW ROI = %d\n"), clsSystemINI.m_sSystemDevice.nLowCalArea);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("SCAL HIGH ROI = %d\n"), clsSystemINI.m_sSystemDevice.nHighCalArea);
	sFile.WriteString( (LPCTSTR)strSetData );

	// LampController Port
	strSetData.Format(_T("LampController ComPort = %d\n"), clsSystemINI.m_sSystemDevice.nLampComport);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Fiducial Find Type
	strSetData.Format(_T("Fiducial Find Type = %d\n"), clsSystemINI.m_sSystemDevice.nFiducialFindType);
	sFile.WriteString( (LPCTSTR)strSetData);
	
	// Eocard
	strSetData.Format(_T("CHECK DOWN ASC VALUE = %d\n"), clsSystemINI.m_sSystemDevice.bCheckDownloadASCValue);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MIN CYCLE TIME = %d\n"), clsSystemINI.m_sSystemDevice.nMinCycleTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("MIN SHOT TIME = %d\n"), clsSystemINI.m_sSystemDevice.nMinShotTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SHOT DRILL TYPE = %d\n"), clsSystemINI.m_sSystemDevice.nShotDrillType);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SELF LINE DIVIDE = %d\n"), clsSystemINI.m_sSystemDevice.nSelfLineDivide);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FLY DELAY TIME = %d\n"), clsSystemINI.m_sSystemDevice.nFlyingDelayTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NO USE VISION = %d\n"), clsSystemINI.m_sSystemDevice.nNoUseVision);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FID FIND IN CENTER = %d\n"), clsSystemINI.m_sSystemDevice.nUseFidFindInCenter);
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2-d Table compensation
	strSetData.Format(_T("2D TABLE COMP X = %.4f\n"), clsSystemINI.m_sSystemDevice.d2DCompTableOffset.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("2D TABLE COMP Y = %.4f\n"), clsSystemINI.m_sSystemDevice.d2DCompTableOffset.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Avia user level
	strSetData.Format(_T("AVIA USER LEVEL = %d\n"), clsSystemINI.m_sSystemDevice.nAviaUserLevel);
	sFile.WriteString( (LPCTSTR)strSetData );

	// beam dumper 20070730
	strSetData.Format(_T("DUMP1 X = %d\n"), clsSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("DUMP1 Y = %d\n"), clsSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("DUMP2 X = %d\n"), clsSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("DUMP2 Y = %d\n"), clsSystemINI.m_sSystemDump.nPtBeanDumper2.y);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard download Count
	strSetData.Format(_T("EOCARD DOWN COUNT = %d\n"), clsSystemINI.m_sSystemDevice.nEocardDownCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Hole data check
	strSetData.Format(_T("HOLE DATA CHECK = %d\n"), clsSystemINI.m_sSystemDevice.bCheckHoleData);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Hood Auto Mode
	strSetData.Format(_T("HOOD AUTO MODE = %d\n"), clsSystemINI.m_sSystemDevice.bUseHoodAutoMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot Count
	strSetData.Format(_T("EOCARD DUMMY COUNT = %d\n"), clsSystemINI.m_sSystemDump.nDummyShot);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot interval
	strSetData.Format(_T("EOCARD DUMMY INTERVAL = %d\n"), clsSystemINI.m_sSystemDump.nDummyInterval);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot Freq
	strSetData.Format(_T("EOCARD DUMMY FREQ = %d\n"), clsSystemINI.m_sSystemDump.nDummyFreq);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot duty
	strSetData.Format(_T("EOCARD DUMMY DUTY = %d\n"), clsSystemINI.m_sSystemDump.nDummyDuty);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot AOM delay
	strSetData.Format(_T("EOCARD DUMMY AOMDELAY = %d\n"), clsSystemINI.m_sSystemDump.nDummyAOMDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot AOM duty
	strSetData.Format(_T("EOCARD DUMMY AOMDUTY = %d\n"), clsSystemINI.m_sSystemDump.nDummyAOMDuty);
	sFile.WriteString( (LPCTSTR)strSetData );


	// Laser Eocard dummy shot Count
	strSetData.Format(_T("EOCARD DUMMY COUNT2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyShot2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot interval
	strSetData.Format(_T("EOCARD DUMMY INTERVAL2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyInterval2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot Freq
	strSetData.Format(_T("EOCARD DUMMY FREQ2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyFreq2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot duty
	strSetData.Format(_T("EOCARD DUMMY DUTY2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyDuty2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot AOM delay
	strSetData.Format(_T("EOCARD DUMMY AOMDELAY2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyAOMDelay2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Laser Eocard dummy shot AOM duty
	strSetData.Format(_T("EOCARD DUMMY AOMDUTY2 = %d\n"), clsSystemINI.m_sSystemDump.nDummyAOMDuty2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Laser Eocard dummy shot after table inposition
	strSetData.Format(_T("EOCARD DUMMY AFTER TABLE STOP = %d\n"), clsSystemINI.m_sSystemDump.nDummyStartAfterTableStop);
	sFile.WriteString( (LPCTSTR)strSetData );

	// nStandbyTime
	strSetData.Format(_T("STANDBY TIME = %d\n"), clsSystemINI.m_sSystemDump.nStandbyTime);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyMinFreq
	strSetData.Format(_T("STANDBY MIN FREQ = %d\n"), clsSystemINI.m_sSystemDump.nStandbyMinFreq);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyMaxFreq
	strSetData.Format(_T("STANDBY MAX FREQ = %d\n"), clsSystemINI.m_sSystemDump.nStandbyMaxFreq);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyInterval
	strSetData.Format(_T("STANDBY INTERVAL = %d\n"), clsSystemINI.m_sSystemDump.nStandbyInterval);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyDuty
	strSetData.Format(_T("STANDBY DUTY = %d\n"), clsSystemINI.m_sSystemDump.nStandbyDuty);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyInpositionTime
	strSetData.Format(_T("STANDBY INPOSITION TIME = %d\n"), clsSystemINI.m_sSystemDump.nStandbyInpositionTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// nStandbyV
	strSetData.Format(_T("STANDBY V1 = %.2f\n"), clsSystemINI.m_sSystemDump.dStandby1stV);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyV2
	strSetData.Format(_T("STANDBY V2 = %.2f\n"), clsSystemINI.m_sSystemDump.dStandby2ndV);
	sFile.WriteString( (LPCTSTR)strSetData );

	// nTurnOff Time
	strSetData.Format(_T("STANDBY TURNOFF TIME = %d\n"), clsSystemINI.m_sSystemDump.nStandbyTurnOffTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("STANDBY TIME SCAL = %d\n"), clsSystemINI.m_sSystemDump.nStandbyTime_Scal);
	sFile.WriteString( (LPCTSTR)strSetData );

	// nStandbyTime2
	strSetData.Format(_T("STANDBY TIME2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyTime2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyMinFreq2
	strSetData.Format(_T("STANDBY MIN FREQ2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyMinFreq2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyMaxFreq2
	strSetData.Format(_T("STANDBY MAX FREQ2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyMaxFreq2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyInterval2
	strSetData.Format(_T("STANDBY INTERVAL2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyInterval2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyDuty2
	strSetData.Format(_T("STANDBY DUTY2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyDuty2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyInpositionTime2
	strSetData.Format(_T("STANDBY INPOSITION TIME2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyInpositionTime2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyV2
	strSetData.Format(_T("STANDBY V12 = %.2f\n"), clsSystemINI.m_sSystemDump.dStandby1stV2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nStandbyV2_2
	strSetData.Format(_T("STANDBY V22 = %.2f\n"), clsSystemINI.m_sSystemDump.dStandby2ndV2);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// nTurnOff Time2
	strSetData.Format(_T("STANDBY TURNOFF TIME2 = %d\n"), clsSystemINI.m_sSystemDump.nStandbyTurnOffTime2);
	sFile.WriteString( (LPCTSTR)strSetData );

	//use dummy info
	strSetData.Format(_T("USE DUMMY TYPE = %d\n"), clsSystemINI.m_sSystemDump.nUseDummyType);
	sFile.WriteString( (LPCTSTR)strSetData );

;


	// Vision Accept Score // process �� �ű� 
/*	strSetData.Format(_T("VISION ACCEPT SCORE = %.2f\n"), clsSystemINI.m_sSystemDevice.dAcceptScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION ROTATE HOLE ACCEPT SCORE = %.2f\n"), clsSystemINI.m_sSystemDevice.dRotateHoleAcceptScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION EDGE HOLE ACCEPT SCORE = %.2f\n"), clsSystemINI.m_sSystemDevice.dAcceptEdgeScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION RESULT SCORE = %.2f\n"), clsSystemINI.m_sSystemDevice.dResultScore);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("VISION EXPOSURE = %.2f\n"), clsSystemINI.m_sSystemDevice.dExposure);
	sFile.WriteString( (LPCTSTR)strSetData );
	*/

	
	// Cal.Grid Delay
	strSetData.Format(_T("CALGRID DELAY = %d\n"), clsSystemINI.m_sSystemDevice.nCalGridDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Cal.Grid mode
	strSetData.Format(_T("CALGRID MODE = %d\n"), clsSystemINI.m_sSystemDevice.nCalGridMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// EO Card EStop
	strSetData.Format(_T("ESTOP = %d\n"), clsSystemINI.m_sSystemDevice.nEStop);
	sFile.WriteString( (LPCTSTR)strSetData );

	// vision FOV , camera pixel
	strSetData.Format(_T("LOW FOV X = %.2f\n"), clsSystemINI.m_sSystemDevice.dLowFOVX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("LOW FOV Y = %.2f\n"), clsSystemINI.m_sSystemDevice.dLowFOVY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HIGH FOV X = %.2f\n"), clsSystemINI.m_sSystemDevice.dHighFOVX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("HIGH FOV Y = %.2f\n"), clsSystemINI.m_sSystemDevice.dHighFOVY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("CAMERA PIXEL X = %d\n"), clsSystemINI.m_sSystemDevice.nCameraPixelX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("CAMERA PIXEL Y = %d\n"), clsSystemINI.m_sSystemDevice.nCameraPixelY);
	sFile.WriteString( (LPCTSTR)strSetData );



	strSetData.Format(_T("COGNEX COARSE LIMIT = %d\n"), clsSystemINI.m_sSystemDevice.nCognex_CoarseLimit);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("COGNEX COARSE LIMIT CENTER = %d\n"), clsSystemINI.m_sSystemDevice.nCognex_CoarseLimitCenter);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("COGNEX FINE LIMIT = %d\n"), clsSystemINI.m_sSystemDevice.nCognex_FineLimit);
	sFile.WriteString( (LPCTSTR)strSetData );



	strSetData.Format(_T("BLOB = %d\n"), clsSystemINI.m_sSystemDevice.nBlob);
	sFile.WriteString( (LPCTSTR)strSetData );


	// Vibration Count
	strSetData.Format(_T("VIB COUNT = %d\n"), clsSystemINI.m_sSystemDevice.nVibrationCount);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vibration Delay
	strSetData.Format(_T("VIB DELAY = %.1f\n"), clsSystemINI.m_sSystemDevice.dVibrationDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Vibration Loader Picker Updown Count 
	strSetData.Format(_T("VIB LP COUNT = %d\n"), clsSystemINI.m_sSystemDevice.nVibrationLPTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vacuum Offset
	strSetData.Format(_T("VACUUM OFFSET = %.2f\n"), clsSystemINI.m_sSystemVacuum.dVacuumOffset);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vacuum Offset2
	strSetData.Format(_T("VACUUM OFFSET2 = %.2f\n"), clsSystemINI.m_sSystemVacuum.dVacuumOffset2);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Dust Suction Hood Offset
	strSetData.Format(_T("DUST SUCTION HOOD OFFSET = %.2f\n"), clsSystemINI.m_sSystemVacuum.dSuctionHoodOffset);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Dust Suction ERR LIMIT
	strSetData.Format(_T("DUST SUCTION ERROR LIMIT = %.2f\n"), clsSystemINI.m_sSystemVacuum.dDustErrLimit);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Scanner Air ERR LIMIT
	strSetData.Format(_T("SCANNER AIR ERROR LIMIT = %.2f\n"), clsSystemINI.m_sSystemVacuum.dScannerAirLimit);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Table1 Vacuum Limit
	for(int i = 0; i<4; i++)
	{
		strTemp.Format(_T("TABLE1 VACUUM LIMIT #%d"), i+1);
		strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemVacuum.dTable1Vacuum[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}
	
	// Table2 Vacuum Limit
	for(int i = 0; i<4; i++)
	{
		strTemp.Format(_T("TABLE2 VACUUM LIMIT #%d"), i+1);
		strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemVacuum.dTable2Vacuum[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	// Jump Speed
	strSetData.Format(_T("JUMP SPEED = %.2f\n"), clsSystemINI.m_sSystemDevice.dJumpSpeed);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Jump Delay
	strSetData.Format(_T("JUMP DELAY = %d\n"), clsSystemINI.m_sSystemDevice.nJumpDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Corner Delay
	strSetData.Format(_T("CORNER DELAY = %d\n"), clsSystemINI.m_sSystemDevice.nCornerDelay);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	//Line Delay
	strSetData.Format(_T("LINE DELAY = %d\n"), clsSystemINI.m_sSystemDevice.nLineDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Pre move 
	strSetData.Format(_T("PRE MOVE = %d\n"), clsSystemINI.m_sSystemDevice.nPreMove);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Jump Delay
	strSetData.Format(_T("DEFAULT JUMP DELAY = %d\n"), clsSystemINI.m_sSystemDevice.nJumpDelayShot);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Text char gab
	strSetData.Format(_T("DEFAULT TEXT GAP = %.2f\n"), clsSystemINI.m_sSystemDevice.dTextGap);
	sFile.WriteString( (LPCTSTR)strSetData );
	// Text char Ref Mode
	strSetData.Format(_T("DEFAULT TEXT REF = %d\n"), clsSystemINI.m_sSystemDevice.nTextRefMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Text use inner OCR Font
	strSetData.Format(_T("USE INNER OCR FONT = %d\n"), clsSystemINI.m_sSystemDevice.bUseInnerOCRFont);
	sFile.WriteString( (LPCTSTR)strSetData );

	CString strTemp2;
	for(int i=0; i<MAX_CAMERA; i++)
	{
		switch(i)
		{
		case 0: strTemp2.Format(_T("1ST HIGH PIXEL")); break;
		case 1: strTemp2.Format(_T("1ST LOW PIXEL")); break;
		case 2: strTemp2.Format(_T("2ND HIGH PIXEL")); break;
		case 3: strTemp2.Format(_T("2ND LOW PIXEL")); break;
		}
		for(int j = 0; j<4; j++)
		{
			strTemp.Format(_T("%s #%d X1"), strTemp2, j+1);
			strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemDevice.dVisionPixcel1[i][j].x);
			sFile.WriteString( (LPCTSTR)strSetData );
			
			strTemp.Format(_T("%s #%d Y1"), strTemp2, j+1);
			strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemDevice.dVisionPixcel1[i][j].y);
			sFile.WriteString( (LPCTSTR)strSetData );
			
			strTemp.Format(_T("%s #%d X2"), strTemp2, j+1);
			strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemDevice.dVisionPixcel2[i][j].x);
			sFile.WriteString( (LPCTSTR)strSetData );
			
			strTemp.Format(_T("%s #%d Y2"), strTemp2, j+1);
			strSetData.Format(_T("%s = %.2f\n"), strTemp, clsSystemINI.m_sSystemDevice.dVisionPixcel2[i][j].y);
			sFile.WriteString( (LPCTSTR)strSetData );
		}
	}

	strSetData.Format(_T("VISION MODEL ID = %s\n"), clsSystemINI.m_sSystemDevice.szVisionModelID);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("2D BARCODE IP = %s\n"), clsSystemINI.m_sSystemDevice.szVision2DBarcodeIP);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("2D BARCODE UNLOAD IP = %s\n"), clsSystemINI.m_sSystemDevice.szVision2DBarcodeUnloadIP);
	sFile.WriteString( (LPCTSTR)strSetData );

	//dual aom master
	strSetData.Format(_T("DUAL AOM 1ST OFFSET = %d\n"), clsSystemINI.m_sSystemDevice.nDualAom1stOffset);
	sFile.WriteString( (LPCTSTR)strSetData );
	
	//dual aom slave
	strSetData.Format(_T("DUAL AOM 2ND OFFSET = %d\n"), clsSystemINI.m_sSystemDevice.nDualAom2ndOffset);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Limit Min X
	strSetData.Format(_T("TABLE LIMIT MIN X = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableLimitMinX);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Limit Min Y
	strSetData.Format(_T("TABLE LIMIT MIN Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableLimitMinY);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Limit Max X
	strSetData.Format(_T("TABLE LIMIT MAX X = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableLimitMaxX);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Limit Max Y
	strSetData.Format(_T("TABLE LIMIT MAX Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableLimitMaxY);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Size X
	strSetData.Format(_T("TABLE SIZE X = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableSizeX);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Size Y
	strSetData.Format(_T("TABLE SIZE Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableSizeY);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Size X
	strSetData.Format(_T("TABLE ACR SIZE X = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableAcrSizeX);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Table Size Y
	strSetData.Format(_T("TABLE ACR SIZE Y = %.3f\n"), clsSystemINI.m_sSystemDevice.dTableAcrSizeY);
	sFile.WriteString( (LPCTSTR)strSetData );

	//MASK INPOS WAIT TIME MS
	strSetData.Format(_T("MASK INPOS WAIT TIME MS = %d\n"), clsSystemINI.m_sSystemDevice.nMaskInposWait);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water Flow Setting 
	strSetData.Format(_T("Water Flow Setting 1 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowSetting1);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water flow setting 2
	strSetData.Format(_T("Water Flow Setting 2 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowSetting2);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Main air
	strSetData.Format(_T("Main Air Setting = %.1f\n"), clsSystemINI.m_sSystemDevice.dMainAirSetting);
	sFile.WriteString( (LPCTSTR)strSetData );

	//dust suction setting 
	strSetData.Format(_T("Dust Suction Setting = %.1f\n"), clsSystemINI.m_sSystemDevice.dDustSuctionSetting);
	sFile.WriteString( (LPCTSTR)strSetData );

	//table vacuum setting 
	strSetData.Format(_T("Table Vacuum Setting 1 = %.1f\n"), clsSystemINI.m_sSystemDevice.dTableVacuumSetting1);
	sFile.WriteString( (LPCTSTR)strSetData );

	//table vacuum setting 
	strSetData.Format(_T("Table Vacuum Setting 2 = %.1f\n"), clsSystemINI.m_sSystemDevice.dTableVacuumSetting2);
	sFile.WriteString( (LPCTSTR)strSetData );


	//Water Flow Setting 
	strSetData.Format(_T("AOM Water Flow Setting 1 = %.1f\n"), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting1);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water flow setting 2
	strSetData.Format(_T("AOM Water Flow Setting 2 = %.1f\n"), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting2);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water Flow Setting 
	strSetData.Format(_T("AOM Water Flow Setting 3 = %.1f\n"), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting3);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water flow setting 2
	strSetData.Format(_T("AOM Water Flow Setting 4 = %.1f\n"), clsSystemINI.m_sSystemDevice.dAOMWaterFlowSetting4);
	sFile.WriteString( (LPCTSTR)strSetData );


	//Water Flow Offset Setting 
	strSetData.Format(_T("Water Flow Offset Setting 1 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting1);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water flow Offset setting 2
	strSetData.Format(_T("Water Flow Offset Setting 2 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting2);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water Flow Offset Setting 
	strSetData.Format(_T("Water Flow Offset Setting 3 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting3);
	sFile.WriteString( (LPCTSTR)strSetData );

	//Water flow Offset setting 2
	strSetData.Format(_T("Water Flow Offset Setting 4 = %.1f\n"), clsSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting4);
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("// END SYSTEM DEVICE SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

BOOL CSystemINIFile::SaveSystemCollimator(CStdioFile& sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START SYSTEM COLLIMATOR SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	for( int i = 0 ; i < 10 ; i++ )
	{
		// Index
		strSetData.Format(_T("INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Position
		strSetData.Format(_T("POSITION = %.1f\n"), clsSystemINI.m_sSystemCollimator.sCollimatorPos[i].dPositon);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Position2
		strSetData.Format(_T("POSITION2 = %.1f\n"), clsSystemINI.m_sSystemCollimator.sCollimatorPos2[i].dPositon);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Position
//		strSetData.Format(_T("POSITION3 = %.1f\n"), clsSystemINI.m_sSystemCollimator.sCollimatorPos3[i].dPositon);
//		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Position2
//		strSetData.Format(_T("POSITION4 = %.1f\n"), clsSystemINI.m_sSystemCollimator.sCollimatorPos4[i].dPositon);
//		sFile.WriteString( (LPCTSTR)strSetData );


		// Measured Power
//		strSetData.Format(_T("MEASURED POWER = %.3f\n"), clsSystemINI.m_sSystemCollimator.sCollimatorPos[i].dMeasuredPower);
//		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Mask Position
		strSetData.Format(_T("MASK POSITION = %.1f\n"), clsSystemINI.m_sSystemCollimator.dMaskPosition[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Mask Position2
//		strSetData.Format(_T("MASK POSITION2 = %.1f\n"), clsSystemINI.m_sSystemCollimator.dMaskPosition2[i]);
//		sFile.WriteString( (LPCTSTR)strSetData );

		// Mask Size
		strSetData.Format(_T("MASK SIZE = %.3f\n"), clsSystemINI.m_sSystemCollimator.dMaskSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Beam Size
		strSetData.Format(_T("BEAM SIZE = %.0f\n"), clsSystemINI.m_sSystemCollimator.dBeamSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Duty Offset
		strSetData.Format(_T("Duty Offset = %d\n"), clsSystemINI.m_sSystemCollimator.nDutyOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AOM Delay Offset = %d\n"), clsSystemINI.m_sSystemCollimator.nAOMDelayOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("AOM Duty Offset = %d\n"), clsSystemINI.m_sSystemCollimator.nAOMDutyOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//Power Compensation
		strSetData.Format(_T("Power Duty = %.2f\n"), clsSystemINI.m_sSystemCollimator.dPowerDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("Power Freq = %d\n"), clsSystemINI.m_sSystemCollimator.nPowerFreq[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("Power A1 = %.0f\n"), clsSystemINI.m_sSystemCollimator.dAttenuator1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("Power A2 = %.0f\n"), clsSystemINI.m_sSystemCollimator.dAttenuator2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("MEMO = %s\n"), clsSystemINI.m_sSystemCollimator.sMemo[i].szMemo);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	strSetData.Format(_T("Fixed Mask Pos = %.3f\n"), clsSystemINI.m_sSystemCollimator.dFixedMask);
	sFile.WriteString( (LPCTSTR)strSetData );

	// Collimator Moving Step
//	strSetData.Format(_T("COLLIMATOR MOVING STEP = %.3f\n"), clsSystemINI.m_sSystemCollimator.dCollimatorMovingStep);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Power Tolerance
//	strSetData.Format(_T("POWER TOLERANCE = %.3f\n"), clsSystemINI.m_sSystemCollimator.dPowerTolerance);
//	sFile.WriteString( (LPCTSTR)strSetData );

	// Power Deviation
//	strSetData.Format(_T("POWER DEVIATION = %.3f\n"), clsSystemINI.m_sSystemCollimator.dPowerDeviation);
//	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END SYSTEM COLLIMATOR SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}
BOOL CSystemINIFile::SaveSystemTophat(CStdioFile& sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	
	strSetData.Format(_T("// START SYSTEM TOPHAT SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	for( int i = 0 ; i < 10 ; i++ )
	{
		// Index
		strSetData.Format(_T("INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Position
		strSetData.Format(_T("POSITION = %.1f\n"), clsSystemINI.m_sSystemTophat.sCollimatorPos[i].dPositon);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Position2
		strSetData.Format(_T("POSITION2 = %.1f\n"), clsSystemINI.m_sSystemTophat.sCollimatorPos2[i].dPositon);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Mask Position
		strSetData.Format(_T("MASK POSITION = %.1f\n"), clsSystemINI.m_sSystemTophat.dMaskPosition[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Mask Size
		strSetData.Format(_T("MASK SIZE = %.3f\n"), clsSystemINI.m_sSystemTophat.dMaskSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Beam Size
		strSetData.Format(_T("BEAM SIZE = %.0f\n"), clsSystemINI.m_sSystemTophat.dBeamSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Duty Offset
		strSetData.Format(_T("Duty Offset = %d\n"), clsSystemINI.m_sSystemTophat.nDutyOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("AOM Delay Offset = %d\n"), clsSystemINI.m_sSystemTophat.nAOMDelayOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("AOM Duty Offset = %d\n"), clsSystemINI.m_sSystemTophat.nAOMDutyOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//Power Compensation
		strSetData.Format(_T("Power Duty = %.2f\n"), clsSystemINI.m_sSystemTophat.dPowerDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("Power Freq = %d\n"), clsSystemINI.m_sSystemTophat.nPowerFreq[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("Power A1 = %.0f\n"), clsSystemINI.m_sSystemTophat.dAttenuator1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("Power A2 = %.0f\n"), clsSystemINI.m_sSystemTophat.dAttenuator2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("MEMO = %s\n"), clsSystemINI.m_sSystemTophat.sMemo[i].szMemo);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	strSetData.Format(_T("// END SYSTEM TOPHAT SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	return bRet;
}
BOOL CSystemINIFile::SaveAxisInfo(CStdioFile& sFile, DSystemINI clsSystemINI)
{
	BOOL bRet = FALSE;
	CString strSetData;

	strSetData.Format(_T("// START AXIS INFO SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i=0; i<MOTOR_AXIS_MAX; i++)
	{
		// Index
		strSetData.Format(_T("INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Scale
		strSetData.Format(_T("Scale = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dScale);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Table FeedRate
		strSetData.Format(_T("TableFeedRate = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableFeedRate);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Table Acceleration
		strSetData.Format(_T("TableAcceleration = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableAcceleration);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Table S Curve
		strSetData.Format(_T("TableSCurve = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableSCurve);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Table Acceleration
		strSetData.Format(_T("TableAccelerationPre = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableAccelerationPre);
		sFile.WriteString( (LPCTSTR)strSetData );
		// Table S Curve
		strSetData.Format(_T("TableSCurvePre = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableSCurvePre);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		// Table Acceleration
		strSetData.Format(_T("TableAccelerationNext = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableAccelerationNext);
		sFile.WriteString( (LPCTSTR)strSetData );
		// Table S Curve
		strSetData.Format(_T("TableSCurveNext = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dTableSCurveNext);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Limit Plus
		strSetData.Format(_T("LimitPlus = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dLimitPlus);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Limit Minus
		strSetData.Format(_T("LimitMinus = %.3f\n"), clsSystemINI.m_sAxisInfo[i].dLimitMinus);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	strSetData.Format(_T("// END AXIS INFO SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}

void CSystemINIFile::WriteLog(CString strLog)
{
	CString strPathName = _T("D:\\ViaHole\\ErrorLog\\");
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}


