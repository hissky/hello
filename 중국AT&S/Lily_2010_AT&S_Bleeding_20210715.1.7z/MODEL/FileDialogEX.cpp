// FileDialogEX.cpp : implementation file
//

#include "stdafx.h"
//#include "jasmine.h"
#include "FileDialogEX.h"
#include "dlgs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileDialogEX

IMPLEMENT_DYNAMIC(CFileDialogEX, CFileDialog)

CFileDialogEX::CFileDialogEX(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CFileDialogEX, CFileDialog)
	//{{AFX_MSG_MAP(CFileDialogEX)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CFileDialogEX::OnInitDone()
{	
	// 080603
	HideControl(edt1);
	HideControl(stc3);
}
