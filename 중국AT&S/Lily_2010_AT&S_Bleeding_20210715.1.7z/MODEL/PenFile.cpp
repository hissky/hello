// PenFile.cpp: implementation of the CPenFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "PenFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPenFile::CPenFile()
{

}

CPenFile::~CPenFile()
{

}

BOOL CPenFile::OpenPenFile(CString strFilePath, SPENDATA& sPenData)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);
		
		return bRet;
	}

	CString strGetData;

	while( sFile.ReadString( strGetData ) )
	{
		if( ScanSys( strGetData, _T("DRAW STEP ="), sPenData.dDrawStep ) )
			continue;
		if( ScanSys( strGetData, _T("STEP PERIOD ="), sPenData.nStepPeriod ) )
			continue;
		if( ScanSys( strGetData, _T("JUMP STEP ="), sPenData.nJumpStep ) )
			continue;
		if( ScanSys( strGetData, _T("JUMP DELAY ="), sPenData.nJumpDelay ) )
			continue;
		if( ScanSys( strGetData, _T("LASER ON DELAY ="), sPenData.nLaserOnDelay ) )
			continue;
		if( ScanSys( strGetData, _T("LASER OFF DELAY ="), sPenData.nLaserOffDelay ) )
			continue;
		if( ScanSys( strGetData, _T("CYCLE TIME ="), sPenData.nCycleTime ) )
			continue;
		if( ScanSys( strGetData, _T("SCANNER JUMP DELAY ="), sPenData.nScannerJDelay ) )
			continue;
		if( ScanSys( strGetData, _T("PULSE FREQUENCY ="), sPenData.nPulseFrequency ) )
			continue;
		if( 0 == strGetData.CompareNoCase(_T("// END LASER PARAMETER SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CPenFile::SavePenFile(CString strFilePath, SPENDATA sPenData)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_SAVE);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

		return bRet;
	}

	CString strSetData;

	strSetData.Format(_T("// START LASER PARAMETER SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );

	strSetData.Format(_T("DRAW STEP = %.2f\n"), sPenData.dDrawStep);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("STEP PERIOD = %d\n"), sPenData.nStepPeriod);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("JUMP STEP = %d\n"), sPenData.nJumpStep);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("JUMP DELAY = %d\n"), sPenData.nJumpDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LASER ON DELAY = %d\n"), sPenData.nLaserOnDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("LASER OFF DELAY = %d\n"), sPenData.nLaserOffDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("CYCLE TIME = %d\n"), sPenData.nCycleTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("SCANNER JUMP DELAY = %d\n"), sPenData.nScannerJDelay);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("PULSE FREQUENCY = %d\n"), sPenData.nPulseFrequency);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END LASER PARAMETER SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	sFile.Close();

	bRet = 1;

	return bRet;
}