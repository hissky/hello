// DUodoRedo.h: interface for the DUodoRedo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DUODOREDO_H__61A32B69_26C9_40A4_8262_E02E89285F57__INCLUDED_)
#define AFX_DUODOREDO_H__61A32B69_26C9_40A4_8262_E02E89285F57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DUnit.h"
#include "DProject.h"

#define DO_CMD_ADD		0
#define DO_CMD_DEL		1
#define DO_CMD_MOVE		2
#define DO_CMD_FLIP_X	3
#define DO_CMD_FLIP_Y	4
#define DO_CMD_ROTATE	5
#define DO_CMD_SCALE	6

typedef CTypedPtrList<CPtrList, DUnit*>  UnitList;

struct DODATA {
	UnitList	units;
	CPoint		ptMove;
	int			cmd;
};

typedef CTypedPtrList<CPtrList, DODATA*>  DoList;

class DUodoRedo  
{
public:
	void DeleteUnit(DODATA *pDoData, BOOL bDel);
	DProject* m_pProject;
	void Initialize(DProject* pProject);
//	void ScaleGlyphs(double dScale);
//	void RotateGlyphs(double dAngle);
//	void FlipYGlyphs();
//	void FlipXGlyphs();
	void Clear();
	void AddRedoList(DODATA *pDodata);
	void ChangeGlyph(DODATA* pDoData, int nCmd);
	void AddUndoList(DODATA* pDodata);
	void RemoveAllRedoCmd();
	void AddGlyphtoList(DUnit* pUnit);
	void RemoveAllGlyphs();
	void Redo();
	void Undo();
	void MoveGlyphs(CPoint ptMove);
	void DelGlyph();
	void AddGlyph();
	DUodoRedo();
	virtual ~DUodoRedo();

	DoList	m_UndoCmds;
	DoList	m_RedoCmds;
	UnitList  m_units;
};

extern DUodoRedo	gDUndoRedo;

#endif // !defined(AFX_DUODOREDO_H__61A32B69_26C9_40A4_8262_E02E89285F57__INCLUDED_)
