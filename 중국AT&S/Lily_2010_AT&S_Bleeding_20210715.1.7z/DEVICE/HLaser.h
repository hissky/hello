// HLaser.h: interface for the HLaser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_)
#define AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HLaserIPGPulse.h"
#include "HLaserCO2.h"
#include "HLaserUV.h"
#include "HLaserQuanta.h"
#include "HLaserTCP.h"

class HLaser  
{
public:
	void EnableOn(int nHeadNo = USE_ALL_HEAD);
	BOOL IsFireOK();
	BOOL setQuataParam(int nFPK, int nCurrent);
	void LaserDoModal();
	int GetAviaTriggerMode(); // 20090629 Front Mode error
	HLaser();
	virtual ~HLaser();
	
	void Create();

	BOOL IsTempReady();
	void OpenPowerDlg();
	int IsPowerOn(BOOL& bAnyLaserOn, int nHeadNo = USE_ALL_HEAD);
	int IsShutterOpen(int nHeadNo = USE_ALL_HEAD);
	BOOL IsPulseOpen();
	BOOL ChangeAviaDiodeCurrent(double dDiodeCurrent, long lFreq, int nThermalTrack = -1);
	void PowerOn(BOOL bFlag, int nHeadNo = USE_ALL_HEAD);
	void ShutterOpen(BOOL bFlag, int nHeadNo = USE_ALL_HEAD);
	void PulseOpen(BOOL bFlag);
	BOOL IsDutyError(int nHeadNo = USE_ALL_HEAD);
	BOOL IsDigitalReflectError(int nHeadNo = USE_ALL_HEAD);
	BOOL IsVSWRError(int nHeadNo = USE_ALL_HEAD);

	POWER_STATUS GetStatus(int nHeadNo = USE_ALL_HEAD);

	HLaserIPGPulse* m_pLaserIPGPulse;
	HLaserCO2* m_pLaserCO2[MAX_LASER_NO];
	HLaserUV*  m_pLaserUV;
	HLaserQuanta* m_pLaserQuanta;
	
	int	m_nLaserType;

	BOOL SetCurrent(double dCurrent);

	BOOL GuideBeamOnOff(BOOL bOn);

	HLaserTCP * m_pLaserTCP[MAX_LASER_NO];
	BOOL ReConnect_Congex(int nHeadNo = USE_ALL_HEAD);
	BOOL GetLaserTCPConnection(int nHeadNo = USE_ALL_HEAD);
	int	GetLaserTCPReceiveCount(int nHeadNo = USE_ALL_HEAD);
	BOOL ReConnect(int nHeadNo = USE_ALL_HEAD);
	CString GetLaserTCPTemp(int nHeadNo = USE_ALL_HEAD,int nTempIndex = 0);
	int GetLaserTCPStatus(int nHeadNo = USE_ALL_HEAD);
	void CloseSocket(int nHeadNo = USE_ALL_HEAD);
};

#endif // !defined(AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_)
