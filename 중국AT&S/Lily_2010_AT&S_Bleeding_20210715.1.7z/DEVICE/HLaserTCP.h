// HLaserTCP.h: interface for the HLaserTCP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLaserTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)
#define AFX_HLaserTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CClientSock_Laser;

class HLaserTCP
{
public:


	BOOL ReConnect();
	BOOL InitLaserTCP(int nHead = 0);
	BOOL ConnectStatus();
	CString GetLaserTCPTemp(int nTempIndex);
	int GetLaserTCPStatus();
	int ReceiveCount();
	void CloseSocket();
	HLaserTCP();
	virtual ~HLaserTCP();

	CClientSock_Laser*	m_pClientSock_Laser;
};

#endif // !defined(AFX_HLaserTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)
