#if !defined(AFX_ClientSock_Cognex_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
#define AFX_ClientSock_Cognex_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientSock_Cognex.h : header file
//
#include "PacketProcess_Cognex.h"
#include <afxsock.h>
#include "..\Model\DPoint.h"
#include "..\Model\DFidData.h"
#include "HvisionOmi.h"


#define WM_CLIENT_CONNECT			WM_USER + 773
#define WM_CLIENT_RECEIVE			WM_USER + 774
#define WM_CLIENT_CLOSE				WM_USER + 775

#define SEND_OK_			0
#define TIME_OUT_			100
#define SEND_FAIL_			101
#define RETURN_FAIL_		102

/////////////////////////////////////////////////////////////////////////////
// CClientSock_Cognex command target

class CClientSock_Cognex : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	BOOL	m_bConnect;
	CPacketProcess_Cognex m_PacketProc;
	
	void SetWnd(HWND hWnd);

	CClientSock_Cognex();
	virtual ~CClientSock_Cognex();

// Overrides
public:
	void SendACK();
	void SendNAK();
	int ReceiveData();
	BOOL Connect(LPCTSTR lpszHostAddress, UINT nHostPort);
	void ReConnectTry();






	//Socket

	int OnCamChange(int nCamNo);
	int OnAcquire(int nCamNo);
	int OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness);
	int OnContrast(int nCamNo, double dContrast);
	int OnBrightness(int nCamNo, double dBrightness);
	int SaveImg(int nCamNo, CString strFilePathName);
	int OnLive(int nCamNo, BOOL bIsLive);
	int OnApplyVisionParameter(int nID, int nCamNo, VISION_INFO sVisionInfo);
	int OnApplyVisionParam(int nID,  int nCamNo, SVISIONINFO sVisionInfo);
	int LoadOptionFile(int nType);
	//int GetRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pChar, BOOL bFindPattern);
	int ShowArea(int nShow, int nPatternNo, int nCam);
	int SetInspectionArea(int nSize, int nCam);
	int SetInspectionAreaPercent(double nPercent, int nCam);
	int SetAcceptScore(double dVal);
	int GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo);
	int ClearInteractiveGraphics(int nCam);
	int TransformPixel();
	int PMToolFind(int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag );
	int InitVisionPixelData(int nCam);
	int InitDistancePerPixel();
	int GetNoGrabRealPosFor4Way(int nCam, int nIndex);

	BOOL Pasing_GetDispParam(SVISIONINFO *pVisionInfo);
	BOOL Pasing_PMToolFind(int nCam);
	BOOL Pasing_GetNoGrabRealPosFor4Way();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientSock_Cognex)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CClientSock_Cognex)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:

private:
	HWND m_hWnd;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ClientSock_Cognex_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
