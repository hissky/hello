// HVision.h: interface for the HVision class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVISION_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_)
#define AFX_HVISION_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_

#include "HvisionOmi.h"
#include "HvisionMatrox.h"
#include "HVisionTCP.h"
#include "HVision2DBarcode.h"
#include "DevVisionController.h"
#include "..\Model\2DTransform.h"
#include "MVisionLamp.h"
#include "HVisionTCP_Cognex.h"

#ifndef USE_VISION_PRO
	#include "aculnk.h"             // The OMI interface definition header file
#endif

#include "MVisionLamp.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HVision  
{
public:
	BOOL CheckOmiHandle();

	void InitDistancePerPixel();
	void InitVisionPixelData(int nCam);

	int OnFindFiducialNoGrab(int nCamNo, int nIndex, CString &strMsg);
	int OnFindFiducialNoGrabFor4Way(int nCamNo, int nIndex, CString &strMsg);
	BOOL ReConnect_Congex();
	BOOL LoadOptionFile(int nType);
	BOOL GetVisionConnection();
	BOOL ReConnect();


	int GetNoGrabRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pChar, double& dFoundSize);
	int GetNoGrabRealPosFor4Way(int nCam, int nIndex);

	void TransformPixel();
	void ClearInteractiveGraphics(int nCam);
	void PMToolShowTrainRegion(int nPatternNo, int nCam);


	void GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo);
	void SetSelIndex(int nIndex);

	void ShowTrainRegion(int nNum, int nCamNo);


	void SaveProject(CString strPath);
	void SetAcceptScore(double dVal);
	void SetCalTansData();
	C2DTransform ResultCalTrans[4];
	void ConnectPatternUI(int nDisplay, CWnd* pWnd);
	void SetInspectArea(DPOINT dpStart, DPOINT dpEnd);
	void SetOmiView(int nCamNo, COmiView* pView);
	BOOL LoadProject(CString strDir);
	void OnConnectView();
	void OnCamChange(int nCamNo);
	void OnAcquire(int nCamNo);
	void OnContrastAndBrightness(int nCamNo,	double dContrast, double dBrightness);
	void OnContrast(int nCamNo, double dContrast);
	void OnBrightness(int nCamNo, double dBrightness);
	void SaveImg(int nCamNo, CString strFilePathName);
	void OnLive(int nCamNo, BOOL bIsLive);
	void OnApplyVisionParam(int nID, int nCamNo, SVISIONINFO sVisionInfo);
	void OnApplyVisionParameter(int nID,int nCamNo, VISION_INFO sVisionInfo);

	BOOL CompareVPro(int nID, int nCamNo, VISION_INFO sVisionInfo);
	void SetApplyParamFlagForVPro();
	void CopyToVProTemp(int nID, int nCamNo);

	void UpdateMinMax(double dSizeA, double dSizeB, double dSizeC);
	int OnFindFiducial(int nCamNo, int nIndex, CString& strMsg, BOOL bFindPattern = FALSE, int nPatternNo = 0, BOOL bCoarseLimitChange = FALSE);
	BOOL OnFindHole(int nCamNo, int nIndex, CString& strMsg);
	void OnLightAll(int nCamNo, int nCoaxial, int nRing, int nIR);
	void OnLightEach(int nCamNo, int nChannel, int nValue);
	void GetLampValue(int nCamNo, CString &strCoaxial, CString &strRing, CString &strIR);
	void OnLight(int nCamNo, int nType, int nVal);
	void SetVisionZoom(int nCamNo, int nZoom=50);
	void SetPixel(int nCamNo, DPOINT dPixel);
	int GetRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pchar = NULL, BOOL bFindPattern = FALSE, BOOL bCoarseLimitChange = FALSE);
	void ShowArea(int nShow, int nPatternNo, int nCam);
	void SetInspectionArea(int nSize, int nCam);
	void SetInspectionAreaPercent(double nSize, int nCam);
	void SetViewHandle(HWND* pHwnd);
	void ShowVisionDialog(BOOL bShow = TRUE);
	void SetLevel(BOOL bSuperUser);
	void ConnectOmiVision();
	void Get2DBarcode(char* szResult, BOOL bLoad);
	void LampOn();
	BOOL Initialize();
	HVision();
	virtual ~HVision();

	MVisionLamp* m_clsLamp;
	CDevVisionController* m_VisionLamp;
	CDevVisionController* m_VisionLamp2;
	HVisionOmi*	m_pOmi;
	HVisionMatrox* m_pMatrox;
	HVisionTCP* m_pMatroxTCP;
	HVision2DBarcode* m_p2D;
	HVision2DBarcode* m_p2DUnload;
	CWnd*		m_pVisionHandle;
	HVisionTCP_Cognex*    m_pMatroxTCP_Cognex;
	int m_nCamNo;
	
	static volatile __int64 m_n64Count;

};

#endif // !defined(AFX_HVISION_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_)
