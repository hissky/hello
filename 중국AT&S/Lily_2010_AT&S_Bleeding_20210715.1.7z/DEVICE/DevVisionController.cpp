// DevVisionController.cpp: implementation of the CDevVisionController class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DevVisionController.h"
#include "..\EasyDriller.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const char STX = 0x02;
const char ETX = 0x03;

//extern HINSTANCE g_hDllDeviceCom;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevVisionController::CDevVisionController()
	: CAsyncComm()
{

}

CDevVisionController::~CDevVisionController()
{

}

BOOL CDevVisionController::Create()
{
	InitializeCriticalSection(&m_csCommunicationSync);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
	SetPort((TPort)m_nPortNo);
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(300);
	SetEventChar(0x0d);
	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);

	OpenComm();
	if(PortOpened())
	{

		char szCmd[7];
		SetCmdSize(6);
		CString strChannel;

		for(int ii = 0; ii < 10; ii++)
		{
			if(ii == 9)
				strChannel = "A";
			else 
				strChannel.Format("%d",ii+1);
			sprintf_s(szCmd, 7, _T("%s%sON"), strChannel, strChannel);
			Sleep(10);
			QueryCommand(szCmd);
		}

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevVisionController::Destroy()
{
	CloseComm();
	DeleteCriticalSection(&m_csCommunicationSync);
}
#ifdef __NANYA__
BOOL CDevVisionController::LampOut(CString strChannel, int nValue)
{

	char szCmd[30];
	CString strBrightness = _T("");
	strBrightness.Format(_T("%d"), nValue);
	
	sprintf_s(szCmd, 30, _T("setbrightness %s %s"), strChannel, strBrightness);

	//TRACE("%s \n",szCmd);
	if (QueryCommand(szCmd))
		return TRUE;
	return FALSE;


}
#else
BOOL CDevVisionController::LampOut(CString strChannel, int nValue)
{

	char szCmd[7];
	SetCmdSize(6);
	CString strBrightness = _T("");

	strBrightness.Format(_T("%03d"), nValue);
	
	sprintf_s(szCmd, 7, _T("%s%s"), strChannel, strBrightness);

	//TRACE("%s\n",szCmd);
	if (QueryCommand(szCmd))
		return TRUE;
	return FALSE;

}
#endif
BOOL CDevVisionController::UseRemoteControl(BOOL bRemote)
{
	if (bRemote)
	{
		if (QueryCommand((LPSTR)(LPCTSTR)_T("E001")))
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if (QueryCommand((LPSTR)(LPCTSTR)_T("E000")))
			return TRUE;
		else
			return FALSE;
	}
}

CString CDevVisionController::GetLampValue(CString strChannel)
{

	char szCmd[1024];
	SetCmdSize(6);
	TCHAR szRet[1024];
	memset(szCmd, 0x00, sizeof(szCmd));
	memset(szRet, 0x00, sizeof(szRet));
	CString strValue = _T("");
#ifdef __NANYA__
   	sprintf_s(szCmd, 1024, _T("getbrightness %s"), strChannel);
#else
	sprintf_s(szCmd, 1024, _T("%sRET"), strChannel);
#endif
	strcpy_s(szRet, QueryCommandForReturn(szCmd));
	strValue = ParsingValue(szRet);
	
	return strValue;

}

CString CDevVisionController::ParsingValue(TCHAR* szTemp)
{

	CString str;

	for (int i = 0 ; i < 1024  ; i++)
	{
		if(szTemp[i] == 0x02  ||  szTemp[i] == 0x06)
			continue;
		if( szTemp[i] == 0x03)
			break;
		str += szTemp[i];
	}
	CString strChnnel = str.Left(1);
	str.TrimLeft();
	str.TrimRight();
#ifdef __NANYA__
	int nIndex = str.ReverseFind(_T(' '));
	int nLength = str.GetLength();
	str = str.Mid(nIndex+1,3);

#else
	int nLength = str.GetLength();

	str = str.Right(3);
#endif
	return str;

}

BOOL CDevVisionController::GetLampIsOn(int nChannel)
{
	char szCmd[7];
	SetCmdSize(6);
	char szRet[7];
	CString strValue = _T("");
//	UseRemoteControl(TRUE);
	sprintf_s(szCmd, 7, _T("%d%dRT"), nChannel, nChannel);
	strcpy_s(szRet, QueryCommandForReturn(szCmd));

	if (szRet[2] == 'N')
		return TRUE;
	else
		return FALSE;
}



BOOL CDevVisionController::QueryCommand(char *szCmd)
{
	if (!PortOpened())
		return FALSE;

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;
		PurgeComm( FHandle, PURGE_TXCLEAR);
		PurgeComm( FHandle, PURGE_RXABORT + PURGE_RXCLEAR );
#ifdef __NANYA__
      		sprintf_s(szTrans, 1024, _T("%s\r"), szCmd); 
#else
		sprintf_s(szTrans, 1024, _T("%c%s%c\r\n"),STX, szCmd, ETX); 
#endif
		SetCmdSize(strlen(szTrans));   


		WriteString(szTrans);
		strcpy_s(szRet, ReadString());
		/*wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(150); // ���� ������ ���� ������ bhlee : ���� �� �ȳѾ� �´ٸ� �� �־����.
#endif
			strcpy_s(szRet, ReadString());

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return FALSE;
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return FALSE;
			}
		}
		else
		{
			FireTimeOut();       
    		LeaveCriticalSection(&m_csCommunicationSync);
			return FALSE;
	    }
		*/
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	if (szRet[1] == 0x06)
		return TRUE;
	else
		return FALSE;
}

char* CDevVisionController::QueryCommandForReturn(char *szCmd)
{
	if (!PortOpened())
		return "";

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

	EnterCriticalSection(&m_csCommunicationSync);

	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;
#ifdef __NANYA__
		sprintf_s(szTrans, 1024, _T("%s\r"), szCmd);
#else
		sprintf_s(szTrans, 1024, _T("%c%s%c\r\n"), STX, szCmd, ETX);
#endif
		SetCmdSize(strlen(szTrans));

		WriteString(szTrans);
		::Sleep(50);
		strcpy_s(szRet, ReadString());
/*		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(150); // ���� ������ ���� ������ bhlee : ���� �� �ȳѾ� �´ٸ� �� �־����.
#endif
			strcpy_s(szRet, ReadString());
			int i = strlen(szRet);
			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return &szRet[0];
			}
			else
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return _T("");
			}
		}
		else
		{
			FireTimeOut();
			LeaveCriticalSection(&m_csCommunicationSync);
			return _T("");
		}
		*/
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	return &szRet[0];
}

void CDevVisionController::ProcessMonitor()
{

}

void CDevVisionController::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevVisionController::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}

void CDevVisionController::LampOn()
{

	//QueryCommand((LPSTR)(LPCTSTR)_T("setonex ffffffff"));

}