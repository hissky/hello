// CalViaHole.cpp: implementation of the CCalViaHole class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include "CalViaHole.h"
#include "..\model\DEasyDrillerINI.h"
//#include "..\resource.h"

#include <cmath>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCalViaHole::CCalViaHole()
{
	m_bIsFileOK = FALSE;
}

CCalViaHole::~CCalViaHole()
{
}

void CCalViaHole::LoadBeamTextFile()
{
	///////////////////////////////////////////////
	//Read vision position & offset value
	int nLineNum, nMaxLineNum;	//Data number
	char buf[100];				//buffer
	int i,j=0;
	int nx=0, ny=0;				//array position
	int nMsize;					//Matrix Size

	/////////////////////////////
	//for file open... 

	char *cFileView = NULL, *data = NULL;

	CString pFilePath = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	pFilePath += _T("CalOffset.txt");

	// �б� ���� ���� ����
	CFile file;
	if(!file.Open(pFilePath, CFile::modeRead|CFile::shareDenyWrite))
	{
		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFilePath);
		ErrMessage(strMsg);
		return;
	}

	DWORD dwFileSize;							//File size
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new char[dwFileSize + 2];		// ����ũ�� ��ŭ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;
		
		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFilePath);
		ErrMessage(strMsg);
		return;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFilePath);
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, pFilePath);
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	cFileView[dwFileSize] = _T('\n');
	cFileView[dwFileSize+1] = _T('\0');

	///////////////////////////////////////////////
	//to the end of file checking ','  for line number
	while (*data!=_T('\0'))
	{
		if(*data==_T(',')) j++;		
		data++;
	}
	
	//calculate line number
	if((j%3)!=0) 
	{
		delete [] cFileView;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, "");
		ErrMessage(strMsg);
		m_bIsFileOK = FALSE;
		return ;
	}
	
	nLineNum=j/3;		//total line num.
	nMaxLineNum=nLineNum;	//store Max Line Num.
	

	/////////////////////////////////////////////////
	//Calculate Matrix size.
	nMsize=(int)(sqrt((double)nLineNum/2));	// devide master & slave	

	if((nMsize*nMsize)!=(nLineNum/2))
	{
		delete [] cFileView;
		ErrMessage(IDS_ERR_CAL_DATA);
		m_bIsFileOK = FALSE;
		return ;
	}

	m_InterpolCal.m_nMatrixSize=nMsize;

	nLineNum=0;						//Line check �� ������ �ʱ�ȭ
	data=cFileView;					// access�� ������ �ʱ�ȭ
	i=0;							//array variable �ʱ�ȭ

	CCalPoint OffsetPoint;
	nx=nMsize-1; //upper line
	while (*data!=_T('\0'))	//EOF	//to the end of file
	{
		//check the end of line
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		nLineNum++;
		i=0;						//buffer pointer initialize.
		data++;
		
		////////////////////////
		// for master... 
		if(nLineNum<(nMsize*nMsize+1))
		{
			//position.
			while(buf[i]!=_T('('))i++;
			while(buf[i]!=_T(','))i++;

			//offset value.
			while(buf[i]!=_T('('))i++;
			OffsetPoint.PosX=atof(buf+i+1);
			while(buf[i]!=_T(','))i++;
			OffsetPoint.PosY=atof(buf+i+1);
			
			if(buf[0]==_T('T')) m_InterpolCal.IsSuccess[nx][ny]=TRUE;
			else m_InterpolCal.IsSuccess[nx][ny]=FALSE;

			/////////////////////////////////////////////////////////
			// change matrix position

			m_InterpolCal.OffsetPoint[nx--][ny]=OffsetPoint; 
			
			if (nx<0)		// change line
			{
				nx=nMsize-1;	//return upper line
				ny++;
			}
		}

		////////////////////////
		// for slave... 
		else
		{
			if(nLineNum==(nMsize*nMsize+1))
			{
				nx=nMsize-1;
				ny=0;
			}
			//position.
			while(buf[i]!=_T('('))i++;
			while(buf[i]!=_T(','))i++;

			//offset value.
			while(buf[i]!=_T('('))i++;
			OffsetPoint.PosX=atof(buf+i+1);
			while(buf[i]!=_T(','))i++;
			OffsetPoint.PosY=atof(buf+i+1);
			
			if(buf[0]==_T('T')) m_InterpolCal.IsSuccess2[nx][ny]=TRUE;
			else m_InterpolCal.IsSuccess2[nx][ny]=FALSE;

			m_InterpolCal.OffsetPoint2[nx--][ny]=OffsetPoint; 
			
			if (nx<0)		// change line
			{
				nx=nMsize-1;	//return upper line
				ny++; // 2ȣ��new 
			}
		}
		i=0;
	}
	delete [] cFileView;	

	if (nLineNum < nMsize * nMsize * 2 + 1)
	{
		m_bIsFileOK = FALSE;
		return;
	}

	m_InterpolCal.FalseInterpolation();		//interpolation FALSE data...

	return;
}

void CCalViaHole::LoadCalibrationData()
{
	//////////////////////////////////////////////////////////
	//CalibrationFile == ASC file���� ���� data

	char *cFileView = NULL, *data = NULL;
	char buf[80];				//buffer
	int nLineNum=0;

	char pFileMasterPath[MAX_PATH];
	lstrcpy(pFileMasterPath, (LPCTSTR)gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());

	// �б� ���� ���� ����
	CFile file;
	if(!file.Open(pFileMasterPath, CFile::modeRead|CFile::shareDenyWrite))
	{
		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("1stCalibration"));
		ErrMessage(strMsg);
		return;
	}

	//////////////////////////////
	// preparation for file reading
	DWORD dwFileSize;			//File size
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new char[dwFileSize + 1];			// ������ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("1stCalibration"));
		ErrMessage(strMsg);
		return;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("1stCalibration"));
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("1stCalibration"));
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	int nx=0, ny=0, i=0;;
	cFileView[dwFileSize] = _T('\0');
	while (*data!=_T('\0')/*EOF*/)		//to the end of file
	{
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		i=0;						//buffer pointer initialize.
		data++;
		nLineNum++;

		if(nLineNum==1 || nLineNum== 8452) continue;	//pass first line and last line...

		////////////////////////////////
		//transfer data to array
		if (nLineNum<4227)
			m_InterpolCal.CalibrationFile[nx++][ny].PosY=atof(buf);
		else
			m_InterpolCal.CalibrationFile[nx++][ny].PosX=atof(buf);

		//change line
		if(nx==MAX_CAL_X)
		{
			ny++;
			if(ny==MAX_CAL_Y) ny=0;
			nx=0;
		}
	}
	delete [] cFileView;
	cFileView = NULL;

	if (nLineNum != 8452)
	{
		m_bIsFileOK = FALSE;
		delete [] cFileView;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("ASC"));
		ErrMessage(strMsg);
		return;
	}
	
	//////////////////////////////////////
	//for slave 
	char pFileSlavePath[MAX_PATH];

	lstrcpy(pFileSlavePath, (LPCTSTR)gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		lstrcpy(pFileSlavePath, (LPCTSTR)gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath()); // 090516
	
	if(!file.Open(pFileSlavePath, CFile::modeRead|CFile::shareDenyWrite))
	{
		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("2ndCalibration"));
		ErrMessage(strMsg);
		return;
	}

	nLineNum=0;

	//////////////////////////////
	// preparation for file reading
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new char[dwFileSize + 1];			// ������ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("2ndCalibration"));
		ErrMessage(strMsg);
		return;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("2ndCalibration"));
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("2ndCalibration"));
		ErrMessage(strMsg);
		return;
	}
	END_CATCH

	cFileView[dwFileSize] = _T('\0');

	while (*data!=_T('\0')/*EOF*/)		//to the end of file
	{
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		i=0;						//buffer pointer initialize.
		data++;
		nLineNum++;

		if(nLineNum==1 || nLineNum== 8452) continue;	//pass first line and last line...

		////////////////////////////////
		//transfer data to array
		if (nLineNum<4227)
			m_InterpolCal.CalibrationFile2[nx++][ny].PosY=atof(buf);
		else
			m_InterpolCal.CalibrationFile2[nx++][ny].PosX=atof(buf);

		//change line
		if(nx==MAX_CAL_X)
		{
			ny++;
			if(ny==MAX_CAL_Y) ny=0;
			nx=0;
		}
	}
	delete [] cFileView;

	if (nLineNum != 8452)
	{
		m_bIsFileOK = FALSE;
		delete [] cFileView;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("ASC"));
		ErrMessage(strMsg);
		return;
	}
	////////////////////////////////////////
	//ASC File read End
}

void CCalViaHole::LoadLowCalibrationFile()
{
	//////////////////////////////////////////////////////////
	//CalibrationFile == ASC file���� ���� data

	char *cFileView = NULL, *data = NULL;
	char buf[80];				//buffer
	int nLineNum=0;

	CString strPath;
	strPath.Format(_T("%sMasterRoot.asc"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	// �б� ���� ���� ����
	CFile file;
	if(!file.Open(strPath, CFile::modeRead|CFile::shareDenyWrite))
	{
		m_bIsFileOK = FALSE;
 		ErrMessage(_T("Can not open 1st Panel Calibration file!"), MB_OK ,0 );
		return;
	}

	//////////////////////////////
	// preparation for file reading
	DWORD dwFileSize;			//File size
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new char[dwFileSize + 1];			// ������ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 1st Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 1st Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 1st Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	END_CATCH

	int nx=0, ny=0, i=0;;
	cFileView[dwFileSize] = _T('\0');
	while (*data!=_T('\0')/*EOF*/)		//to the end of file
	{
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		i=0;						//buffer pointer initialize.
		data++;
		nLineNum++;

		if(nLineNum==1 || nLineNum== 8452) continue;	//pass first line and last line...

		////////////////////////////////
		//transfer data to array
		if (nLineNum<4227)
			m_InterpolCal.CalFileLowMaster[nx++][ny].PosY=atof(buf);
		else
			m_InterpolCal.CalFileLowMaster[nx++][ny].PosX=atof(buf);

		//change line
		if(nx==MAX_CAL_X)
		{
			ny++;
			if(ny==MAX_CAL_Y) ny=0;
			nx=0;
		}
	}
	delete [] cFileView;
	cFileView = NULL;

	if (nLineNum != 8452)
	{
		m_bIsFileOK = FALSE;
		delete [] cFileView;
		ErrMessage(_T("There is error in asc file"));
		return;
	}
	
	//////////////////////////////////////
	//for slave 

	if(!gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
		strPath.Format(_T("%sSlaveRoot.asc"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	if(!file.Open(strPath, CFile::modeRead|CFile::shareDenyWrite))
	{
		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 2nd Panel Calibration file!"), MB_OK ,0 );
		return;
	}

	nLineNum=0;

	//////////////////////////////
	// preparation for file reading
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new char[dwFileSize + 1];			// ������ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 2nd Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 2nd Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		m_bIsFileOK = FALSE;
		ErrMessage(_T("Can not open 2nd Panel Calibration file!"), MB_OK ,0 );
		return;
	}
	END_CATCH

	cFileView[dwFileSize] = _T('\0');

	while (*data!=_T('\0')/*EOF*/)		//to the end of file
	{
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		i=0;						//buffer pointer initialize.
		data++;
		nLineNum++;

		if(nLineNum==1 || nLineNum== 8452) continue;	//pass first line and last line...

		////////////////////////////////
		//transfer data to array
		if (nLineNum<4227)
			m_InterpolCal.CalFileLowSlave[nx++][ny].PosY=atof(buf);
		else
			m_InterpolCal.CalFileLowSlave[nx++][ny].PosX=atof(buf);

		//change line
		if(nx==MAX_CAL_X)
		{
			ny++;
			if(ny==MAX_CAL_Y) ny=0;
			nx=0;
		}
	}
	delete [] cFileView;

	if (nLineNum != 8452)
	{
		m_bIsFileOK = FALSE;
		delete [] cFileView;
		ErrMessage(_T("There is error in asc file"));
		return;
	}
	////////////////////////////////////////
	//ASC File read End
}

void CCalViaHole::CalculateCalibrationAndSave()
{
	if(m_InterpolCal.m_nMatrixSize < 5) 
		m_InterpolCal.Calibration();
	else
		m_InterpolCal.BicubicCalibration();
}

BOOL CCalViaHole::Calibration()
{
	m_bIsFileOK = TRUE;
	
	LoadBeamTextFile();
	if (m_bIsFileOK)
	{
		LoadCalibrationData();
//		LoadLowCalibrationFile(); // 20100928
	}
	if (m_bIsFileOK)
		CalculateCalibrationAndSave();

	return m_bIsFileOK;
}
