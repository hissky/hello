// DlgLaserStatus.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgLaserStatus.h"
#include "afxdialogex.h"
#include "..\easydrillerdlg.h"
#include "..\device\hdevicefactory.h"
#include "..\Device\HEoCard.h"
#include "..\device\devicemotor.h"
#include "..\Device\HLaser.h"
#include "..\model\dsystemini.h"
#include "..\alarmmsg.h"
// CDlgLaserStatus ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgLaserStatus, CDialog)

CDlgLaserStatus::CDlgLaserStatus(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserStatus::IDD, pParent)
{
	m_nTimerID					= 0;
	memset(m_bLaserStatus,0,sizeof(m_bLaserStatus));
}

CDlgLaserStatus::~CDlgLaserStatus()
{
}

void CDlgLaserStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_CHECK_VSWR, m_ledVSMRLimit);
	DDX_Control(pDX, IDC_CHECK_TEMP_FAULT, m_ledTempFault);
	DDX_Control(pDX, IDC_CHECK_SYSTEM_FAULT, m_ledSystemFault);
	DDX_Control(pDX, IDC_CHECK_ENABLE, m_ledEnable);
	DDX_Control(pDX, IDC_CHECK_DUTY_CYCLE, m_ledDutyCycleLimit);
	DDX_Control(pDX, IDC_CHECK_SHUTTER_FAULT, m_ledShutterFault);
	DDX_Control(pDX, IDC_CHECK_SHUTTER_INTERLOCK, m_ledShutterInterlock);
	DDX_Control(pDX, IDC_CHECK_SYSTEM_INTERLOCK, m_ledSystemInterlock);
}


BEGIN_MESSAGE_MAP(CDlgLaserStatus, CDialog)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CDlgLaserStatus �޽��� ó�����Դϴ�.


void CDlgLaserStatus::OnTimer(UINT_PTR nIDEvent)
{

	BOOL bLaserTCPConnect = gDeviceFactory.GetLaser()->GetLaserTCPConnection(m_nLaserNo);
	CString strMsg,strMsg2;
	int	nLaserStatus;

	if(bLaserTCPConnect == FALSE)
	{
		strMsg = "DisConnect";
		strMsg2 = "DisConnect";
	}
	else
	{
		strMsg = gDeviceFactory.GetLaser()->GetLaserTCPTemp(m_nLaserNo,0);
		strMsg2 = gDeviceFactory.GetLaser()->GetLaserTCPTemp(m_nLaserNo,1);
		nLaserStatus = gDeviceFactory.GetLaser()->GetLaserTCPStatus(m_nLaserNo);
		LaserStatus(nLaserStatus);
	}

	GetDlgItem(IDC_STATIC_LASER_TEMP_VALUE)->SetWindowText(strMsg);
	GetDlgItem(IDC_STATIC_LASER_TEMP2_VALUE)->SetWindowText(strMsg2);

	CDialog::OnTimer(nIDEvent);
}

void CDlgLaserStatus::InitTimer()
{	
	if(m_nTimerID == 0)
		m_nTimerID = SetTimer(100, 500, NULL);
}

void CDlgLaserStatus::InitBtnControl()
{	
	m_fntBtn.CreatePointFont(90, "Arial Bold");
	// VSMR
	m_ledVSMRLimit.SetFont( &m_fntBtn );
	m_ledVSMRLimit.SetImage( IDB_LEDCOLOR, 15 );
	m_ledVSMRLimit.Depress( TRUE );

	// Temp Fault
	m_ledTempFault.SetFont( &m_fntBtn );
	m_ledTempFault.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTempFault.Depress( TRUE );

	// System Fault
	m_ledSystemFault.SetFont( &m_fntBtn );
	m_ledSystemFault.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSystemFault.Depress( TRUE );

	// Enable
	m_ledEnable.SetFont( &m_fntBtn );
	m_ledEnable.SetImage( IDB_LEDCOLOR, 15 );
	m_ledEnable.Depress( TRUE );

	// Duty Cycle Limit
	m_ledDutyCycleLimit.SetFont( &m_fntBtn );
	m_ledDutyCycleLimit.SetImage( IDB_LEDCOLOR, 15 );
	m_ledDutyCycleLimit.Depress( TRUE );

	// ShutterFault
	m_ledShutterFault.SetFont( &m_fntBtn );
	m_ledShutterFault.SetImage( IDB_LEDCOLOR, 15 );
	m_ledShutterFault.Depress( TRUE );

	// ShutterInterlock
	m_ledShutterInterlock.SetFont( &m_fntBtn );
	m_ledShutterInterlock.SetImage( IDB_LEDCOLOR, 15 );
	m_ledShutterInterlock.Depress( TRUE );

	// SystemInterlock
	m_ledSystemInterlock.SetFont( &m_fntBtn );
	m_ledSystemInterlock.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSystemInterlock.Depress( TRUE );
}

BOOL CDlgLaserStatus::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitTimer();
	InitBtnControl();
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BOOL CDlgLaserStatus::DestroyWindow()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
	return CDialog::DestroyWindow();
}

void CDlgLaserStatus::LaserStatus(int nStatus)
{
	//m_bLaserStatus
	//bit 0: VSWR Limit
	//bit 1: Temperature Fault
	//bit 2: System Fault
	//bit 3: Enable
	//bit 4: Duty Cycle Limit
	//bit 5: Shutter Fault
	//bit 6: Shutter Interlock
	//bit 7: System Interlock(128)
	if(nStatus < 256 && nStatus >= 0)
	{
		for(int i = 0; i < 8; i++)
		{
			if((nStatus >> i) & 0x01)
				m_bLaserStatus[i] = TRUE;
			else
				m_bLaserStatus[i] = FALSE;
		}

		m_ledVSMRLimit.Depress( !m_bLaserStatus[0] );
		m_ledTempFault.Depress( !m_bLaserStatus[1] );
		m_ledSystemFault.Depress( !m_bLaserStatus[2] );
		m_ledEnable.Depress( !m_bLaserStatus[3] );
		m_ledDutyCycleLimit.Depress( !m_bLaserStatus[4] );
		m_ledShutterFault.Depress( !m_bLaserStatus[5] );
		m_ledShutterInterlock.Depress( !m_bLaserStatus[6] );
		m_ledSystemInterlock.Depress( !m_bLaserStatus[7] );
	}

}


void CDlgLaserStatus::SetLaserNo(int nNo)
{
	m_nLaserNo = nNo;
}