#if !defined(AFX_DLGMARKINGPARAM_H__DDF4C215_5840_44A5_AAAB_AF7ED7223D2E__INCLUDED_)
#define AFX_DLGMARKINGPARAM_H__DDF4C215_5840_44A5_AAAB_AF7ED7223D2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgMarkingParam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgMarkingParam dialog

#include "UEasyButton.h"
#include "ColorEdit.h"


class CDlgMarkingParam : public CDialog
{
// Construction
public:
	CDlgMarkingParam(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgMarkingParam)
	enum { IDD = IDD_DLG_MARKING_PARAM };
	int		m_nJumpDelay;
	int		m_nCornerDelay;
	double		m_dJumpSpeed;
	int		m_nLineDelay;
	int		m_nPreMove;
	int		m_nJumpDelayShot;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgMarkingParam)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
	void ChangeDisplay();
	void GetData(double &nJumpSpeed, int &nJumpDelay, int &nCornerDelay, int &nLineDelay, int &nPremove, int &nJumpDelayShot);
	void SetData(double nJumpSpeed, int nJumpDelay, int nCornerDelay, int nLineDelay, int nPremove, int nJumpDelayShot);
	void InitEditControl();
	void InitStaticControl();
	CColorEdit	m_edtJumpSpeed;
	CColorEdit	m_edtCornerDelay;
	CColorEdit	m_edtJumpDelay;
	CColorEdit  m_edtLineDelay;
	CColorEdit	m_edtPreMove;
	CColorEdit	m_edtJumpDelayShot;
	CFont m_fntStatic;
	CFont m_fntEdit;
// 	int m_nJumpSpeed;
// 	int	m_nJumpDelay;
// 	int	m_nCornerDelay;
// 	int m_nLineDelay;
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgMarkingParam)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMARKINGPARAM_H__DDF4C215_5840_44A5_AAAB_AF7ED7223D2E__INCLUDED_)
