#pragma once

#include "UEasyButtonEx.h"
#include "..\MODEL\DAreaInfo.h"
#include "..\DEVICE\CalibrationPath.h"
#include "..\DEVICE\alAGC.h"
// CDlgIdleMode ��ȭ �����Դϴ�.


class CDlgIdleMode : public CDialog
{
	DECLARE_DYNAMIC(CDlgIdleMode)

public:
	CDlgIdleMode(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgIdleMode();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_IDLE_MODE };
public:
	CFont m_fntStatic;
	CFont m_fntStatic2;
	CFont m_fntList;
	CFont m_fntBtn;

	CListCtrl m_listScannerTool;
	CListCtrl m_listScannerResult;
	CListCtrl	m_listPowerTool;
	CListBox	m_lboxResult;
	CProgressCtrl m_progMeasure;
	CColorStatic	m_stcVisionResult;
	UEasyButtonEx m_btnStart;
	UEasyButtonEx m_btnExit;

	CColorEdit	m_edtScalIntervalTime;
	CColorEdit	m_edtPowerIntervalTime;
	int	m_nScalIntervalTime;
	int m_nPowerIntervalTime;
	
	double m_d1stTemper;
	double m_d2ndTemper;
	double m_d1stSBTemper;
	double m_d2ndSBTemper;

	BOOL m_bTimeThread;
	BOOL m_bRunIdleModeThread;
	BOOL m_bDoAutoPower;
	BOOL m_bDoAutoSCal;
	BOOL m_bUserDummyOn;
	BOOL m_bStop;
	BOOL m_bOldPanel;
	BOOL m_bCtrlInit;
	BOOL m_bIdleRun;
	int	 m_nApplyCount;
	double m_dMaxOffsetMasterX;
	double m_dMaxOffsetMasterY;
	double m_dMaxOffsetMasterR;
	double m_dMaxOffsetSlaveX;
	double m_dMaxOffsetSlaveY;
	double m_dMaxOffsetSlaveR;
	double m_dFoundSize;
	CWinThread*	m_pTimeThread;
	CWinThread* m_pRunThread;
	
	CCalibrationPath m_CalMasterPath;
	CCalibrationPath m_CalSlavePath;

	CalAGC m_calAGCMaster;
	CalAGC m_calAGCSlave;


	int m_nBeamPath;
	int m_nErrID;
	int m_nMeasureCount;
	int m_nBeamPathBackup;
	int m_nTimer;
	DPOINT visionResult;
	
	TCHAR myResultChar[512];
	void InitBtnControl();
	void InitListControl();
	void InitStaticControl();
	void StartMeasurement(int nPos);
	void UpdateMeasurement(int nPos);
	int GetFirstBeamPath();
	BOOL IsAvailableArea(DAreaInfo *pAreaInfo, int nToolNo, int nFidBlock);
	void OnMoveVisionView();
	void MessageLoop();
	void IdleStopProcess();
	void IdleStartProcess();
	void IdleEndProcess();
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	BOOL UpdateNewParam();
	void GetBeamPathLaserInfo(SUBTOOLDATA &subTool);
	BOOL ChangeBeamPath(int nToolType);
	BOOL SavePowerAuto(BOOL bSaveOri, double d1stMeasureResult, double d2ndMeasureResult, double dZ1, double dZ2, int nMask, int nFrequency, double dDuty, double dAOMDelay, double dAOMDuty);
	void SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
		int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
		int ndiff, int nJobType);
	BOOL DoSCalProcess();
	BOOL DoPowerProcess();
	BOOL CheckPowerAuto();
	BOOL OnDoPowerMeasurement();
	void GetLaserParam(SUBTOOLDATA &subTool);
	BOOL DoSCalAuto() ;
	BOOL DownScalParam();
	BOOL ControlDeviceForScal(BOOL bStart);
	BOOL DownloadASC();
	BOOL InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave);
	BOOL DoFindPreviousHole(BOOL bUseLowCam);
	BOOL CheckMotorPositionValidity();
	BOOL IsOutOfAxisValidity(int nAxis, double dVal);
	void CalculateAutoStartPosition();
	BOOL FindPreviousShot(double dZ1, double dZ2, emHEAD emHead);
	BOOL FindPreviousShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd);
	BOOL FindShot(double dZ1, double dZ2, emHEAD emHead = emMaster, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);
	BOOL FindShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, bool bSave = true, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);
	BOOL FindCurrentShot(double dZ1, double dZ2, emHEAD emHead = emMaster, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL);
	BOOL FindCurrentShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos = NULL, DPOINT* pdOffset = NULL, bool* pSuccess = NULL, DPOINT* pdPos2 = NULL, DPOINT* pdOffset2 = NULL, bool* pSuccess2 = NULL);

	BOOL DoFireCalibrationHole(int nSelHead, BOOL bUseLowCam);
	int GetPointIndex(int nCountX, int nCountY, int nDivision);
	BOOL FireCalibrationHole(bool bFire, bool b1stPanel);
	CCalibrationPath* GetMasterPath()	{return &m_CalMasterPath;};
	CCalibrationPath* GetSlavePath()	{return &m_CalSlavePath;};
	void SaveSCalResult();
	void SaveScalTime(BOOL b1st, BOOL bOnlyTime);
	BOOL DoFindCurrentShot(BOOL bUseLowCam);
	void InsertInfo(int nType);
	void InsertSCalResult(double dMaxX, double dMaxY ,double dMaxX2, double dMaxY2);
	void InsertPowerResult2(BOOL b1st, double dVal);
	void InsertPowerResult(double dResult, int nIndex, BOOL b1st, BOOL bAvg);
	BOOL CheckStatus();
	BOOL DoApplySCalResult();
	BOOL HeatingScannerBlockUsingIdleInfo();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
		DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonExit();
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT ChangeVisionParameter(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT GetVisionResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetVisionLamp(WPARAM wParam, LPARAM lParam);
	virtual BOOL DestroyWindow();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual INT_PTR DoModal();
	afx_msg void OnMove(int x, int y);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
