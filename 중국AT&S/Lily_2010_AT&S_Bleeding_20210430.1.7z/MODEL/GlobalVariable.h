// GlobalVariable.h: interface for the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)
#define AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\model\ToolCodeList.h"
#include "..\model\RefuseList.h"
#define		SECRET_KEY		'@'

#include "..\Device\CorrectTime.h"


struct COGNIX_VISION_RESULT {
	   BOOL bUse;
       CDPoint dOffsetReuslt_Pixcel;
	   CDPoint dOffsetReuslt_mm;
	   CDPoint dScaleResult;
	   double dScaleGap;
	   CDPoint dHoleSize;
	   double dScoreValue;
	   BOOL bSizeCheck;
	   BOOL bRatioCheck;
	   BOOL bFinalSuccess;

	   int nHoleOriginIndex;
	   int nHoleSortIndex;
};

class GlobalVariable  
{
public:
	void SetPath();
	GlobalVariable();
	virtual ~GlobalVariable();
	void Initialize();

	SGLOBALVARIABLE		m_sGlobal;
	CToolCodeList* m_pToolCode[MAX_TOOL_NO];

	CString m_strPath;
	int m_nVersion;
	void SaveTableCalLog(BOOL b1st);
	BOOL SaveGlobalTool();
	BOOL LoadGlobalTool();
	void Serialize(CArchiveMark& ar, int nVersion, int nMode = 0);

	CRefuseList* m_pRefuse;

	CString m_strPath2;
	int m_nVersion2;


	BOOL m_bOpenProject;

	BOOL m_bApplyScalFlag;
	CString DoEncrypt(CString strOrigin,BOOL bUseDecryt = FALSE);
	BOOL CreateEncryptionFile(CString strPathOld);


	BOOL SaveRefuseList();
	BOOL LoadRefuseList();

	BOOL m_bStartEasyDrillerDlg;
	int m_nGlobalDummyType;
    CString m_strProcessStatus;

	BOOL m_bGrobalDutyOffsetCompenMode;

	BOOL IsOkLotSchedule();
	BOOL m_bDrillingCheck;
	double m_dGlobalChillerTemp1;
	double m_dGlobalChillerTemp2;
	double m_dGlobalChillerFlow1;
	double m_dGlobalChillerFlow2;
	double m_dGlobalChillerPressure1;
	double m_dGlobalChillerPressure2;

	int m_nMachineMode;



	CString m_strBackupLaserComp;
	CString m_strBackupLaserSold;
	CString m_strBackupRecipeComp;
	CString m_strBackupRecipeSold;
	SSHOTGROUPTABLE		m_sgShotGroupTable;
	SSHOTGROUPTABLE		m_sgTempShotGroupTable;
	SSHOTGROUPTABLE		m_sgShotGroupTablePower;


	SBEAMPATH		m_sgBeamPath;
	SBEAMPATH		m_sgTempBeamPath;


	int m_nLineUpOrder;
	int m_nLineUpType;

	BOOL m_bDo4WayScal;
	int m_nFireCountFor4Way;
	

	CDPoint m_dVisionOffsetFor4Way_mm[4];

	void InitVisionOffsetFor4Way();
	void InitCognixResult();
	void SetLineUpValue_int(int nOrder,int * nArray,int nSize);
	void SetLineUpValue_double(int nOrder,double * dArray,int nSize);
	BOOL IsValidVisionOffsetFor4Way(double dCenterOffsetX ,double dCenterOffsetY,CString &strErr,DPOINT & dFinalReuslt);
	COGNIX_VISION_RESULT	m_CognixTemp[100];
	COGNIX_VISION_RESULT	m_CognixFinalResult[4];

	BOOL m_bLPCRangeReset;
	BOOL m_bExsitPreLPCTable;
	BOOL m_bDoingPreHeat;




	double GetLMDuty_us(int nFrq ,double dDutyPercent);//20160627
	void GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax);
	BOOL  IsValidateTableModulationData(SBEAMPATH sBeampath,SSHOTGROUPTABLE sShotGroupTable,BOOL bPowerCompen = FALSE);
	BOOL  IsValidateTableModulationPowerCompen(int nHeadMode,double dNewDutyOffset1,double dNewDutyOffset2,int nToolTableNo, double dNewOntimeOffset1, double dNewOntimeOffset2);
	
	
		BOOL m_bMarkingCavity;
    int m_nShotNoForCavity;
	BOOL m_bShowBlockOnly;
	BOOL m_bShowNoBlockOnly;
	BOOL m_bShowSelectAreaOnly;
	int m_nUseTable;
	int m_nSelectArea;
	int m_nChangeDisplayLogMode;


	BOOL m_bShowSelectFidBlockOnly;
	int m_nSelectFidBlock;

	BOOL m_bShowBlockNo;

	int	m_nMachineNo;

	CCorrectTime CognexTactTime1;
	CCorrectTime CognexTactTime2;

	double m_dGlobal_FidScaleX[2];
	double m_dGlobal_FidScaleY[2];

	BOOL m_bDoorFlag;
};

extern GlobalVariable gVariable;

#endif // !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)
