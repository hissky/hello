// ScannerCompensation.cpp: implementation of the ScannerCompensation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "ScannerCompensation.h"
#include "math.h"
#include "float.h"
#include "..\model\DEasyDrillerINI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
ScannerCompensation gScannerCompensation;

ScannerCompensation::ScannerCompensation()
{
	m_pMScannerGrid = NULL;
	m_pSScannerGrid = NULL;
	m_pMSideOffset	= NULL;
	m_pSSideOffset	= NULL;
	InitData();
}

ScannerCompensation::~ScannerCompensation()
{
	InitData();
}

void ScannerCompensation::SetReferencePoint(double x, double y, int nIndex)
{
	if(nIndex < 0 || nIndex > 3)
		return;

	m_ptRef[nIndex].x = x;
	m_ptRef[nIndex].y = y;
}

void ScannerCompensation::SetTransformedPoint(double x, double y, int nIndex)
{
	if(nIndex < 0 || nIndex > 3)
		return;
	
	m_ptTran[nIndex].x = x;
	m_ptTran[nIndex].y = y;
}

BOOL ScannerCompensation::Transform()
{
	double pdMat[16];
	int    pnVec[4];
		
	int nParity = 1;
		
	// Pseudo Affine Transformation
	// X' = a + bX + cY + dXY
	// Y' = A + BX + CY + DXY
	for(int i =  0; i < 4; i++)
	{
		pdMat[i * 4 + 0] = 1.0;
		pdMat[i * 4 + 1] = m_ptRef[i].x;
		pdMat[i * 4 + 2] = m_ptRef[i].y;
		pdMat[i * 4 + 3] = m_ptRef[i].x * m_ptRef[i].y;
		m_XCal[i] = m_ptTran[i].x;
		m_YCal[i] = m_ptTran[i].y;
	}
	
	if (!LUDecomp(pdMat, pnVec, nParity, 4))
	{
		return FALSE;
	}
	LUGetVal(pdMat, pnVec, m_XCal, 4);
	LUGetVal(pdMat, pnVec, m_YCal, 4);
	
	return TRUE;
}

bool ScannerCompensation::LUDecomp(double *Mat, int *Vec, int &nParity, int nDim)
{
	int iMax = 0, j, k, n = nDim;
	double big, dum, sum, temp;
	double vv[4];
		
	nParity = 1;
	
	for(int i =  0; i < n; i++)
	{
		big = 0.0;
		for (j = 0; j < n; j++)
		{
			if ((temp = fabs(Mat[i * n + j])) > big)
				big = temp;
		}
		if (big == 0.0)
		{
			return false;
		}
		vv[i] = 1.0 / big;
	}
	
	for (j = 0; j < n; j++)
	{
		for(int i =  0; i < j; i++)
		{
			sum = Mat[i * n + j];
			for (k = 0; k < i; k++)
				sum -= Mat[i * n + k] * Mat[k * n + j];
			Mat[i * n + j] = sum;
		}
		
		big = 0.0;
		for(int i =  j; i < n; i++)
		{
			sum = Mat[i * n + j];
			for (k = 0; k < j; k++)
				sum -= Mat[i * n + k] * Mat[k * n + j];
			Mat[i * n + j] = sum;
			
			if ((dum = vv[i] * fabs(sum)) >= big)
			{
				big = dum;
				iMax = i;
			}
		}
		
		if (j != iMax)
		{
			for (k = 0; k < n; k++)
			{
				dum = Mat[iMax * n + k];
				Mat[iMax * n + k] = Mat[j * n + k];
				Mat[j * n + k] = dum;
			}
			nParity = -nParity;
			vv[iMax] = vv[j];
		}
		
		Vec[j] = iMax;
		
		// This is bad conditioned matrix
		//		if (Mat[j * m_nCalDim + j] == 0.0)
		if (fabs(Mat[j * n + j]) <= DBL_EPSILON)
		{
			return false;
		}
		
		if (j != n - 1)
		{
			dum = 1.0 / Mat[j * n + j];
			for(int i =  j + 1; i < n; i++)
				Mat[i * n + j] *= dum;
		}
	}
	
	return true;
}

bool ScannerCompensation::LUGetVal(double *Mat, int *Vec, double *Cal, int nDim)
{
	int ii = 0, ip, j, n = nDim;
	double sum;
	
	for(int i =  0; i < n; i++)
	{
		ip = Vec[i];
		sum = Cal[ip];
		Cal[ip] = Cal[i];
		if (ii != 0)
		{
			for (j = ii - 1; j < i; j++)
				sum -= Mat[i * n + j] * Cal[j];
		}
		else if (sum != 0.0)
			ii = i + 1;
		Cal[i] = sum;
	}
	
	for(int i =  n - 1; i >= 0; i--)
	{
		sum = Cal[i];
		for (j = i + 1; j < n; j++)
			sum -= Mat[i * n + j] * Cal[j];
		Cal[i] = sum / Mat[i * n + i];
	}
	
	return true;
}

void ScannerCompensation::AffineTransformPoint(const double x, const double y, double &dXVal, double &dYVal)
{
	if(!m_bTransOK)
	{
		dXVal = x;
		dYVal = y;
	}
	else
	{
		dXVal = m_XCal[0] + m_XCal[1] * x + m_XCal[2] * y + m_XCal[3] * x * y;
		dYVal = m_YCal[0] + m_YCal[1] * x + m_YCal[2] * y + m_YCal[3] * x * y;
	}
}

BOOL ScannerCompensation::OpenData()
{
	CString strCalPath;
	strCalPath.Format(_T("%sscannerGrid.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	InitData();

	FILE* fileStream;
	errno_t err;
	TRY
	{
		err = fopen_s(&fileStream, strCalPath, _T("r"));
		if(err != NULL)
		{
			return FALSE;		
		}
		CString str;
		
		//  master -------------------------------
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dMStartX = atof(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dMStartY = atof(str);

		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nMGridX = atoi(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nMGridY = atoi(str);

		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dMGap = atof(str);

		m_dMEndX = m_dMStartX + m_dMGap * (m_nMGridX - 1);
		m_dMEndY = m_dMStartY + m_dMGap * (m_nMGridY - 1);

		m_pMScannerGrid = new SCANNER_GRID[m_nMGridX * m_nMGridY];
		for(int i = 0; i < m_nMGridX * m_nMGridY; i++)
		{
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dLBx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dLBy = atof(str);

			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dLTx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dLTy = atof(str);

			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dRBx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dRBy = atof(str);

			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dRTx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pMScannerGrid[i].dRTy = atof(str);
		}
		
		//  slave  ------------------------------------
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dSStartX = atof(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dSStartY = atof(str);
		
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nSGridX = atoi(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nSGridY = atoi(str);
		
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dSGap = atof(str);

		m_dSEndX = m_dSStartX + m_dSGap * (m_nSGridX - 1);
		m_dSEndY = m_dSStartY + m_dSGap * (m_nSGridY - 1);
		
		m_pSScannerGrid = new SCANNER_GRID[m_nSGridX * m_nSGridY];
		for(int i = 0; i < m_nSGridX * m_nSGridY; i++)
		{
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dLBx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dLBy = atof(str);
			
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dLTx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dLTy = atof(str);
			
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dRBx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dRBy = atof(str);
			
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dRTx = atof(str);
			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_pSScannerGrid[i].dRTy = atof(str);
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		return FALSE;
	}
	END_CATCH

	fclose(fileStream);
	return TRUE;
}

void ScannerCompensation::InitData()
{
	m_dMStartX = m_dMStartY = m_dMGap = 0;
	m_dSStartX = m_dSStartY = m_dSGap = 0;
	m_nMGridX = m_nMGridY = m_nSGridX = m_nSGridY = 0;
	if(m_pMScannerGrid)
	{
		delete[] m_pMScannerGrid;
		m_pMScannerGrid = NULL;
	}
	if(m_pSScannerGrid)
	{
		delete[] m_pSScannerGrid;
		m_pSScannerGrid = NULL;
	}

	if(m_pMSideOffset)
	{
		delete[] m_pMSideOffset;
		m_pMSideOffset = NULL;
	}
	if(m_pSSideOffset)
	{
		delete[] m_pSSideOffset;
		m_pSSideOffset = NULL;
	}
	m_bTransOK = FALSE;
}

BOOL ScannerCompensation::SaveData(int nMode)
{
	CString strCalPath, strData;
	strCalPath.Format(_T("%sscannerGrid.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	strData.Format(_T("%sDatascannerGrid.txt"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());

	FILE* fileStream, *dataStream;
	errno_t err;
	TRY
	{
		err = fopen_s(&fileStream, strCalPath, _T("w+"));
		if(err != NULL)
		{
			return FALSE;		
		}

		err = fopen_s(&dataStream, strData, _T("w+"));
		if(err != NULL)
		{
			return FALSE;		
		}
		CString str;
		
		//  master -------------------------------
		fprintf(fileStream, _T("%.4f\n"), m_dMStartX);
		fprintf(fileStream, _T("%.4f\n"), m_dMStartY);

		fprintf(fileStream, _T("%d\n"), m_nMGridX);
		fprintf(fileStream, _T("%d\n"), m_nMGridY);

		fprintf(fileStream, _T("%.4f\n"), m_dMGap);
		
		for(int i = 0; i < m_nMGridX * m_nMGridY; i++)
		{
			if(nMode != 0)
			{
				getData(i, TRUE);
				for(int j = 0; j < 32; j++)
				{
					fprintf(dataStream, _T("%d %.4f %.4f\n"), i, m_pMSideOffset[i].dpOffset[j].x, m_pMSideOffset[i].dpOffset[j].y);
				}
			}
			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dLBx);
			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dLBy);

			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dLTx);
			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dLTy);

			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dRBx);
			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dRBy);

			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dRTx);
			fprintf(fileStream, _T("%.4f\n"), m_pMScannerGrid[i].dRTy);
		}
		
		//  slave  ------------------------------------
		fprintf(fileStream, _T("%.4f\n"), m_dSStartX);
		fprintf(fileStream, _T("%.4f\n"), m_dSStartY);
		
		fprintf(fileStream, _T("%d\n"), m_nSGridX);
		fprintf(fileStream, _T("%d\n"), m_nSGridY);
		
		fprintf(fileStream, _T("%.4f\n"), m_dSGap);
		
		for(int i = 0; i < m_nSGridX * m_nSGridY; i++)
		{
			if(nMode != 0)
			{
				getData(i, FALSE);
				for(int j = 0; j < 32; j++)
				{
					fprintf(dataStream, _T("%d %.4f %.4f\n"), i, m_pSSideOffset[i].dpOffset[j].x, m_pSSideOffset[i].dpOffset[j].y);
				}
			}
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dLBx);
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dLBy);
			
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dLTx);
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dLTy);
			
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dRBx);
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dRBy);
			
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dRTx);
			fprintf(fileStream, _T("%.4f\n"), m_pSScannerGrid[i].dRTy);
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		return FALSE;
	}
	END_CATCH

	fclose(fileStream);
	fclose(dataStream);
	return TRUE;
}

void ScannerCompensation::MakeDataMemory()
{
	if(m_nMGridX * m_nMGridY > 0)
	{
		if(m_pMScannerGrid)
		{
			delete[] m_pMScannerGrid;
			m_pMScannerGrid = NULL;
		}
		m_pMScannerGrid = new SCANNER_GRID[m_nMGridX * m_nMGridY];
	}

	if(m_nSGridX * m_nSGridY > 0)
	{
		if(m_pSScannerGrid)
		{
			delete[] m_pSScannerGrid;
			m_pSScannerGrid = NULL;
		}
		m_pSScannerGrid = new SCANNER_GRID[m_nSGridX * m_nSGridY];
	}
}

void ScannerCompensation::Make2DTrans(double dTableX1, double dTableY1, double dTableX2, double dTableY2, BOOL bMaster)
{
	int nX1, nY1, nX2, nY2;

	m_bTransOK = FALSE;

	if(m_pMScannerGrid == NULL && bMaster)
		return;
	if(m_pSScannerGrid == NULL && !bMaster)
		return;

	GetIndex(dTableX1, dTableY1, nX1, nY1, bMaster);
	GetIndex(dTableX2, dTableY2, nX2, nY2, bMaster);

	if(bMaster)
	{
		SetReferencePoint(-25, -25, 0);
		SetReferencePoint(-25,	25, 1);
		SetReferencePoint( 25, -25, 2);
		SetReferencePoint( 25,	25, 3);

		SetTransformedPoint(-25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dLBx - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dLBx),
							-25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dLBy - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dLBy), 0);
		SetTransformedPoint(-25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dLTx - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dLTx),
							 25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dLTy - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dLTy), 1);
		SetTransformedPoint( 25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dRBx - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dRBx),
							-25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dRBy - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dRBy), 2);
		SetTransformedPoint( 25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dRTx - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dRTx),
							 25 - (m_pMScannerGrid[nX2 + nY2 * m_nMGridX].dRTy - m_pMScannerGrid[nX1 + nY1 * m_nMGridX].dRTy), 3);
	}
	else
	{
		SetReferencePoint(-25, -25, 0);
		SetReferencePoint(-25,	25, 1);
		SetReferencePoint( 25, -25, 2);
		SetReferencePoint( 25,	25, 3);
		
		SetTransformedPoint(-25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dLBx - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dLBx),
							-25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dLBy - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dLBy), 0);
		SetTransformedPoint(-25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dLTx - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dLTx),
							 25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dLTy - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dLTy), 1);
		SetTransformedPoint( 25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dRBx - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dRBx),
							-25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dRBy - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dRBy), 2);
		SetTransformedPoint( 25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dRTx - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dRTx),
							 25 - (m_pSScannerGrid[nX2 + nY2 * m_nMGridX].dRTy - m_pSScannerGrid[nX1 + nY1 * m_nMGridX].dRTy), 3);
	}
	Transform();
	m_bTransOK = TRUE;
}

void ScannerCompensation::GetIndex(double dTableX, double dTableY, int &nX, int &nY, BOOL bMaster)
{
	if(bMaster)
	{
		if(m_nMGridX == 0 || m_nMGridY == 0)
		{
			nX = 0;
			nY = 0;
		}
		else
		{
			if(dTableX <= m_dMStartX)
				nX = 0;
			else if(dTableX >= m_dMEndX)
				nX = m_nMGridX - 1;
			else
				nX = (int)((dTableX - m_dMStartX) / m_dMGap + 0.5);

			if(dTableY <= m_dMStartY)
				nY = 0;
			else if(dTableY >= m_dMEndY)
				nY = m_nMGridY - 1;
			else
				nY = (int)((dTableY - m_dMStartY) / m_dMGap + 0.5);
		}
	}
	else
	{
		if(m_nSGridX == 0 || m_nSGridY == 0)
		{
			nX = 0;
			nY = 0;
		}
		else
		{
			if(dTableX <= m_dSStartX)
				nX = 0;
			else if(dTableX >= m_dSEndX)
				nX = m_nSGridX - 1;
			else
				nX = (int)((dTableX - m_dSStartX) / m_dSGap + 0.5);
			
			if(dTableY <= m_dSStartY)
				nY = 0;
			else if(dTableY >= m_dSEndY)
				nY = m_nSGridY - 1;
			else
				nY = (int)((dTableY - m_dSStartY) / m_dSGap + 0.5);
		}
	}
}

void ScannerCompensation::SetInitData(double dStartX, double dStartY, double dGap, int nXStep, int nYStep, int nMS)
{
	if(nMS == MASTER_ONLY || nMS == MS_BOTH)
	{
		if(m_pMScannerGrid)
		{
			delete[] m_pMScannerGrid;
			m_pMScannerGrid = NULL;
		}

		if(m_pMSideOffset)
		{
			delete[] m_pMSideOffset;
			m_pMSideOffset = NULL;
		}

		m_nMGridX = nXStep;
		m_nMGridY = nYStep;
		
		m_dMStartX = dStartX;
		m_dMStartY = dStartY;
		
		m_dMGap = dGap;
		
		m_dMEndX = m_dMStartX + m_dMGap * (m_nMGridX - 1);
		m_dMEndY = m_dMStartY + m_dMGap * (m_nMGridY - 1);
		
		m_pMScannerGrid = new SCANNER_GRID[m_nMGridX * m_nMGridY];
		m_pMSideOffset	= new OUTER_SCANDATA[m_nMGridX * m_nMGridY];
	}
	
	if(nMS == SLAVE_ONLY || nMS == MS_BOTH)
	{
		if(m_pSScannerGrid)
		{
			delete[] m_pSScannerGrid;
			m_pSScannerGrid = NULL;
		}

		if(m_pSSideOffset)
		{
			delete[] m_pSSideOffset;
			m_pSSideOffset = NULL;
		}

		m_nSGridX = nXStep;
		m_nSGridY = nYStep;
		
		m_dSStartX = dStartX;
		m_dSStartY = dStartY;
		
		m_dSGap = dGap;
		
		m_dSEndX = m_dSStartX + m_dSGap * (m_nSGridX - 1);
		m_dSEndY = m_dSStartY + m_dSGap * (m_nSGridY - 1);
		
		m_pSScannerGrid = new SCANNER_GRID[m_nSGridX * m_nSGridY];
		m_pSSideOffset	= new OUTER_SCANDATA[m_nMGridX * m_nMGridY];
	}
	m_bTransOK = FALSE;

	
}

void ScannerCompensation::getData(int nIndex, BOOL bMaster)
{
	double a[4], b[4];
	double sx, sy, sxx, sxy, d;
	int nStart, nEnd;


	//----
	if(bMaster)
	{
		m_pMSideOffset[nIndex].dpOffset[32] = m_pMSideOffset[nIndex].dpOffset[0];
		for(int k = 0; k < 4; k++)
		{
			nStart = k * 8;
			nEnd = nStart + 9;
			sx = sy = sxx = sxy = 0;
			for(int i = nStart; i < nEnd; i++)	sx += m_pMSideOffset[nIndex].dpOffset[i].x;
			for(int i = nStart; i < nEnd; i++)	sy += m_pMSideOffset[nIndex].dpOffset[i].y;
			for(int i = nStart; i < nEnd; i++)	sxx += m_pMSideOffset[nIndex].dpOffset[i].x * m_pMSideOffset[nIndex].dpOffset[i].x;
			for(int i = nStart; i < nEnd; i++)	sxy += m_pMSideOffset[nIndex].dpOffset[i].x * m_pMSideOffset[nIndex].dpOffset[i].y;

			d = 9 * sxx - sx * sx;
			if(d == 0)
			{
				a[k] = DBL_MAX;
				b[k] = m_pMSideOffset[nIndex].dpOffset[0].x;
			}
			else
			{
				b[k] = (sxx * sy - sx * sxy)/d;
				a[k] = (9 * sxy - sx * sy)/d;
			}
		}
		GetInterSection(a[0], b[0], a[1], b[1], m_pMScannerGrid[nIndex].dLTx, m_pMScannerGrid[nIndex].dLTy);
		m_pMScannerGrid[nIndex].dLTy -= 50;
		GetInterSection(a[1], b[1], a[2], b[2], m_pMScannerGrid[nIndex].dLBx, m_pMScannerGrid[nIndex].dLBy);
		GetInterSection(a[2], b[2], a[3], b[3], m_pMScannerGrid[nIndex].dRBx, m_pMScannerGrid[nIndex].dRBy);
		m_pMScannerGrid[nIndex].dRBx -= 50;
		GetInterSection(a[3], b[3], a[0], b[0], m_pMScannerGrid[nIndex].dRTx, m_pMScannerGrid[nIndex].dRTy);
		m_pMScannerGrid[nIndex].dRTx -= 50; m_pMScannerGrid[nIndex].dRTy -= 50;
	}
	else
	{
		m_pSSideOffset[nIndex].dpOffset[32] = m_pSSideOffset[nIndex].dpOffset[0];
		for(int k = 0; k < 4; k++)
		{
			nStart = k * 8;
			nEnd = nStart + 9;
			sx = sy = sxx = sxy = 0;
			for(int i = nStart; i < nEnd; i++)	sx += m_pSSideOffset[nIndex].dpOffset[i].x;
			for(int i = nStart; i < nEnd; i++)	sy += m_pSSideOffset[nIndex].dpOffset[i].y;
			for(int i = nStart; i < nEnd; i++)	sxx += m_pSSideOffset[nIndex].dpOffset[i].x * m_pSSideOffset[nIndex].dpOffset[i].x;
			for(int i = nStart; i < nEnd; i++)	sxy += m_pSSideOffset[nIndex].dpOffset[i].x * m_pSSideOffset[nIndex].dpOffset[i].y;
			
			d = 9 * sxx - sx * sx;
			if(d == 0)
			{
				a[k] = DBL_MAX;
				b[k] = m_pSSideOffset[nIndex].dpOffset[0].x;
			}
			else
			{
				b[k] = (sxx * sy - sx * sxy)/d;
				a[k] = (9 * sxy - sx * sy)/d;
			}
		}
		GetInterSection(a[0], b[0], a[1], b[1], m_pSScannerGrid[nIndex].dLTx, m_pSScannerGrid[nIndex].dLTy);
		m_pSScannerGrid[nIndex].dLTy -= 50;
		GetInterSection(a[1], b[1], a[2], b[2], m_pSScannerGrid[nIndex].dLBx, m_pSScannerGrid[nIndex].dLBy);
		GetInterSection(a[2], b[2], a[3], b[3], m_pSScannerGrid[nIndex].dRBx, m_pSScannerGrid[nIndex].dRBy);
		m_pSScannerGrid[nIndex].dRBx -= 50;
		GetInterSection(a[3], b[3], a[0], b[0], m_pSScannerGrid[nIndex].dRTx, m_pSScannerGrid[nIndex].dRTy);
		m_pSScannerGrid[nIndex].dRTx -= 50; m_pSScannerGrid[nIndex].dRTy -= 50;
	}
	
}

void ScannerCompensation::GetInterSection(double a1, double b1, double a2, double b2, double &dx, double &dy)
{
	if(a1 == 0)
	{
		if(a2 == DBL_MAX)
		{
			dx = b2; dy = b1;
		}
		else
		{
			dy = b1; dx = (dy - b2) / a2;
		}
	}
	else if(a1 == DBL_MAX)
	{
		if(a2 == 0)
		{
			dx = b1; dy = b2;
		}
		else
		{
			dx = b1; dy = a2 * dx + b2;
		}
	}
	else
	{
		if(a2 == DBL_MAX)
		{
			dx = b2; dy = a1 * dx + b1;
		}
		else if(a2 == 0)
		{
			dy = b2; dx = (dy - b1) / a1;
		}
		else
		{
			dx = (b2 - b1) / (a1 - a2);
			dy = a1 * dx + b1;
		}
	}
}
