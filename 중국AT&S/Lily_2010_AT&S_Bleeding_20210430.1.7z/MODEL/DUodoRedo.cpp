// DUodoRedo.cpp: implementation of the DUodoRedo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DUodoRedo.h"
#include "DProject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define UNDO_CMD		0
#define REDO_CMD		1
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DUodoRedo	gDUndoRedo;

DUodoRedo::DUodoRedo()
{
	m_pProject = NULL;
}

DUodoRedo::~DUodoRedo()
{
	Clear();
}

void DUodoRedo::AddGlyph()
{
	POSITION pos = m_units.GetHeadPosition();

	if(pos == NULL)
	{
		ErrMessage(IDS_ERR_NO_ADD_UNDO);
		return;
	}

	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_ADD;
	
	while (pos)
	{
		pDoData->units.AddTail(m_units.GetNext(pos));
	}

	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::DelGlyph()
{
	POSITION pos = m_units.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(IDS_ERR_NO_ADD_UNDO);
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_DEL;
	
	while (pos)
	{
		pDoData->units.AddTail(m_units.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::MoveGlyphs(CPoint ptMove)
{
	POSITION pos = m_units.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(IDS_ERR_NO_ADD_UNDO);
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_MOVE;
	pDoData->ptMove = ptMove;
	
	while (pos)
	{
		pDoData->units.AddTail(m_units.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::Undo()
{
	DODATA* tempDodata;
	POSITION pos = m_UndoCmds.GetHeadPosition();
	if(pos)
	{
		tempDodata = m_UndoCmds.GetNext(pos);
		ChangeGlyph(tempDodata, UNDO_CMD);
		AddRedoList(tempDodata);
		m_UndoCmds.RemoveHead();
	}
	else
	{
		ErrMessage(IDS_ERR_NO_UNDO);
		return;
	}
}

void DUodoRedo::Redo()
{
	DODATA* tempDodata;
	POSITION pos = m_RedoCmds.GetHeadPosition();
	if(pos)
	{
		tempDodata = m_RedoCmds.GetNext(pos);
		ChangeGlyph(tempDodata, REDO_CMD);
		AddUndoList(tempDodata);
		m_RedoCmds.RemoveHead();
	}
	else
	{
		ErrMessage(IDS_ERR_NO_REDO);
		return;
	}
}

void DUodoRedo::RemoveAllGlyphs()
{
	m_units.RemoveAll();
}

void DUodoRedo::AddGlyphtoList(DUnit* pUnit)
{
	m_units.AddTail(pUnit);
}

void DUodoRedo::RemoveAllRedoCmd()
{
	DODATA* tempDodata;
	POSITION pos = m_RedoCmds.GetHeadPosition();
	while (pos)
	{
		tempDodata = m_RedoCmds.GetNext(pos);
		delete tempDodata;
	}
	m_RedoCmds.RemoveAll();
}

void DUodoRedo::AddUndoList(DODATA *pDodata)
{
	int nUndoNo = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("UndoNo"), 20);
	m_UndoCmds.AddHead(pDodata);
	if(m_UndoCmds.GetCount() > nUndoNo)
	{
		DODATA* tempDodata;
		POSITION pos = m_UndoCmds.GetTailPosition();
		tempDodata = m_UndoCmds.GetAt(pos);
		delete tempDodata;
		m_UndoCmds.RemoveTail();
	}
}

void DUodoRedo::AddRedoList(DODATA *pDodata)
{
	int nUndoNo = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("UndoNo"), 20);
	m_RedoCmds.AddHead(pDodata);
	if(m_RedoCmds.GetCount() > nUndoNo)
	{
		DODATA* tempDodata;
		POSITION pos = m_RedoCmds.GetTailPosition();
		tempDodata = m_RedoCmds.GetAt(pos);
		delete tempDodata;
		m_RedoCmds.RemoveTail();
	}
}

void DUodoRedo::ChangeGlyph(DODATA *pDoData, int nCmd)
{
	if(m_pProject == NULL)
		return;

	if(pDoData->cmd == DO_CMD_ADD)
	{
		if(nCmd == UNDO_CMD)
			DeleteUnit(pDoData, TRUE);
		else
			DeleteUnit(pDoData, FALSE);
	}
	else if(pDoData->cmd == DO_CMD_DEL)
	{
		if(nCmd == UNDO_CMD)
			DeleteUnit(pDoData, FALSE);
		else
			DeleteUnit(pDoData, TRUE);
	}
	else if(pDoData->cmd == DO_CMD_MOVE)
	{
		DUnit* pUnit;
		POSITION pos;
		pos = pDoData->units.GetHeadPosition();
		while (pos) 
		{
			pUnit = pDoData->units.GetNext(pos);
			if(nCmd == UNDO_CMD)
				pUnit->Move(-pDoData->ptMove.x, -pDoData->ptMove.y);
			else
				pUnit->Move(pDoData->ptMove.x, pDoData->ptMove.y);
		}
	}

/*	else if(pDoData->cmd == DO_CMD_FLIP_X)
	{
		pos = pDoData->glyphs.GetHeadPosition();
		while (pos) 
		{
			pGlyph = pDoData->glyphs.GetNext(pos);
			pGlyph->flipX(TRUE);

			if(pGlyph->getRotAngle() == 0 || pGlyph->getRotAngle() == 180 )
				pGlyph->m_bFlipX = !pGlyph->m_bFlipX;
			else
				pGlyph->m_bFlipY = !pGlyph->m_bFlipY;
		}
		gDProject.GenerateHoles();
	}
	else if(pDoData->cmd == DO_CMD_FLIP_Y)
	{
		pos = pDoData->glyphs.GetHeadPosition();
		while (pos) 
		{
			pGlyph = pDoData->glyphs.GetNext(pos);
			pGlyph->flipY(TRUE);

			if(pGlyph->getRotAngle() == 0 || pGlyph->getRotAngle() == 180 )
				pGlyph->m_bFlipY = !pGlyph->m_bFlipY;
			else
				pGlyph->m_bFlipX = !pGlyph->m_bFlipX;
		}
		gDProject.GenerateHoles();
	}
	else if(pDoData->cmd == DO_CMD_ROTATE)
	{
		pos = pDoData->glyphs.GetHeadPosition();
		while (pos) 
		{
			pGlyph = pDoData->glyphs.GetNext(pos);
			if(nCmd == UNDO_CMD)
				pGlyph->rotate(-pDoData->dpMove.x, TRUE);
			else
				pGlyph->rotate(pDoData->dpMove.x, TRUE);
			
			pGlyph->ChangeFilpXY();
//			pGlyph->m_bFlipY = !pGlyph->m_bFlipY;
		}
		gDProject.GenerateHoles();
	}
	else if(pDoData->cmd == DO_CMD_SCALE)
	{
		pos = pDoData->glyphs.GetHeadPosition();
		while (pos) 
		{
			pGlyph = pDoData->glyphs.GetNext(pos);
			if(nCmd == UNDO_CMD)
				pGlyph->scale(1/pDoData->dpMove.x, TRUE);
			else
				pGlyph->scale(pDoData->dpMove.x, TRUE);
		}
		gDProject.GenerateHoles();
	}
*/	else
	{
	}
}

void DUodoRedo::Clear()
{
	DODATA* tempDodata;
	POSITION pos = m_UndoCmds.GetHeadPosition();
	POSITION posUnit;
	DUnit* pUnit;
	while (pos)
	{
		tempDodata = m_UndoCmds.GetNext(pos);
		if(tempDodata->cmd == DO_CMD_DEL)
		{
			posUnit = tempDodata->units.GetHeadPosition();
			while(posUnit)
			{
				pUnit = tempDodata->units.GetNext(posUnit);
				delete pUnit;
			}
		}
		tempDodata->units.RemoveAll();
		delete tempDodata;
	}
	m_UndoCmds.RemoveAll();
	
	pos = m_RedoCmds.GetHeadPosition();
	while (pos)
	{
		tempDodata = m_RedoCmds.GetNext(pos);
		if(tempDodata->cmd == DO_CMD_ADD)
		{
			posUnit = tempDodata->units.GetHeadPosition();
			while(posUnit)
			{
				pUnit = tempDodata->units.GetNext(posUnit);
				delete pUnit;
			}
		}
		tempDodata->units.RemoveAll();
		delete tempDodata;
	}
	m_RedoCmds.RemoveAll();
}
/*
void DUodoRedo::FlipXGlyphs()
{
	POSITION pos = m_glyphs.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(_T("Undo list�� �߰��� �����Ͱ� �����ϴ�."));
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_FLIP_X;
	
	while (pos)
	{
		pDoData->glyphs.AddTail(m_glyphs.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::FlipYGlyphs()
{
	POSITION pos = m_glyphs.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(_T("Undo list�� �߰��� �����Ͱ� �����ϴ�."));
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_FLIP_Y;
	
	while (pos)
	{
		pDoData->glyphs.AddTail(m_glyphs.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::RotateGlyphs(double dAngle)
{
	POSITION pos = m_glyphs.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(_T("Undo list�� �߰��� �����Ͱ� �����ϴ�."));
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_ROTATE;
	pDoData->dpMove.x = dAngle;
	
	while (pos)
	{
		pDoData->glyphs.AddTail(m_glyphs.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}

void DUodoRedo::ScaleGlyphs(double dScale)
{
	POSITION pos = m_glyphs.GetHeadPosition();
	
	if(pos == NULL)
	{
		ErrMessage(_T("Undo list�� �߰��� �����Ͱ� �����ϴ�."));
		return;
	}
	
	DODATA* pDoData = new DODATA();
	pDoData->cmd = DO_CMD_SCALE;
	pDoData->dpMove.x = dScale;
	
	while (pos)
	{
		pDoData->glyphs.AddTail(m_glyphs.GetNext(pos));
	}
	
	AddUndoList(pDoData);
	RemoveAllRedoCmd();
	RemoveAllGlyphs();
}*/

void DUodoRedo::Initialize(DProject *pProject)
{
	Clear();
	m_pProject = pProject;
}

void DUodoRedo::DeleteUnit(DODATA *pDoData, BOOL bDel)
{
	DUnit *pUnit, *pUnitProject;
	POSITION pos = pDoData->units.GetHeadPosition();
	POSITION posProject, posOldProject;
	posProject = posOldProject = m_pProject->m_Glyphs.m_Units.GetHeadPosition();
	while (pos) 
	{
		pUnit = pDoData->units.GetNext(pos);
		if(bDel)
		{
			while(posProject)
			{
				pUnitProject = m_pProject->m_Glyphs.m_Units.GetNext(posProject);
				if(pUnitProject == pUnit)
				{
					m_pProject->m_Glyphs.m_Units.RemoveAt(posOldProject);
					posOldProject = posProject;
					break;
				}
				posOldProject = posProject;
			}
		}
		else
		{
			m_pProject->m_Glyphs.m_Units.AddTail(pUnit);
		}
	}
}
