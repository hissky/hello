// ScannerCompensation.h: interface for the ScannerCompensation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCANNERCOMPENSATION_H__BC3E072A_9A60_4A6D_95AC_9988F781F037__INCLUDED_)
#define AFX_SCANNERCOMPENSATION_H__BC3E072A_9A60_4A6D_95AC_9988F781F037__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "dpoint.h"

struct SCANNER_GRID
{
	double dLBx;
	double dLBy;
	double dRBx;
	double dRBy;
	double dLTx;
	double dLTy;
	double dRTx;
	double dRTy;
};

struct OUTER_SCANDATA
{
	DPOINT dpOffset[33];
};

#define MASTER_ONLY		0
#define SLAVE_ONLY		1
#define MS_BOTH			2

class ScannerCompensation  
{
public:
	void GetInterSection(double a1, double b1, double a2, double b2, double& dx, double& dy);
	void getData(int nIndex, BOOL bMaster);
	void SetInitData(double dStartX, double dStartY, double dGap, int nXStep, int nYStep, int nMS);
	void GetIndex(double dTableX, double dTableY, int& nX, int& nY, BOOL bMaster);
	void Make2DTrans(double dTableX1, double dTableY1, double dTableX2, double dTableY2, BOOL bMaster);
	void MakeDataMemory();
	BOOL SaveData(int nMode);
	void InitData();
	BOOL OpenData();
	
	ScannerCompensation();
	~ScannerCompensation();

	double	m_dMStartX;
	double	m_dMStartY;
	int		m_nMGridX;
	int		m_nMGridY;
	double	m_dMEndX;
	double	m_dMEndY;
	double	m_dMGap;
	SCANNER_GRID*	m_pMScannerGrid;
	OUTER_SCANDATA* m_pMSideOffset;

	double	m_dSStartX;
	double	m_dSStartY;
	int		m_nSGridX;
	int		m_nSGridY;
	double	m_dSEndX;
	double	m_dSEndY;
	double	m_dSGap;
	SCANNER_GRID*	m_pSScannerGrid;
	OUTER_SCANDATA* m_pSSideOffset;

	//------------------------------------------
	DPOINT	m_ptRef[4];
	DPOINT	m_ptTran[4];
	double  m_XCal[4];
	double	m_YCal[4];
	BOOL	m_bTransOK;
	void AffineTransformPoint(const double x, const double y, double& dXVal, double& dYVal);
	bool LUGetVal(double* Mat, int* Vec, double* Cal, int nDim);
	bool LUDecomp(double* Mat, int* Vec, int& nParity, int nDim);
	BOOL Transform();
	void SetTransformedPoint(double x, double y, int nIndex);
	void SetReferencePoint(double x, double y, int nIndex);

};

extern ScannerCompensation gScannerCompensation;

#endif // !defined(AFX_SCANNERCOMPENSATION_H__BC3E072A_9A60_4A6D_95AC_9988F781F037__INCLUDED_)
