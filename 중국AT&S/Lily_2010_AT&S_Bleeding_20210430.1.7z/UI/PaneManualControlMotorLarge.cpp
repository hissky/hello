// PaneManualControlMotorLarge.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlMotorLarge.h"

#include "..\device\hdevicefactory.h"

#include "..\device\HEocard.h"
//#include "..\device\devicemotor.h"
#include "..\alarmmsg.h"
#include "..\device\DeviceMotor.h"
#include "..\model\dprocessini.h"
#include "..\model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "PaneSysSetup.h"

#include "..\Model\DTemperCompensation.h"


	#include "PaneSysSetupLaserScannerLarge.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorLarge

IMPLEMENT_DYNCREATE(CPaneManualControlMotorLarge, CFormView)

CPaneManualControlMotorLarge::CPaneManualControlMotorLarge()
	: CFormView(CPaneManualControlMotorLarge::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlMotorLarge)
	m_nAbs = 0;
	m_bTargetX = FALSE;
	m_bTargetY = FALSE;
	m_bTargetZ1 = FALSE;
	m_bTargetZ2 = FALSE;
	m_bTargetC = FALSE;
	m_bTargetC2 = FALSE;
	m_bTargetC3 = FALSE;
	m_bTargetC4 = FALSE;
	m_bTargetM = FALSE;
	m_bTargetM2 = FALSE;
	m_bTargetA = FALSE;	//2011519
	m_bTargetA2 = FALSE;
	m_bTargetM3 = FALSE;

	m_bTargetM4 = FALSE;
	m_bTargetRot = FALSE;
	m_bTargetTopHat = FALSE;


	m_bTableMotor = FALSE;
	m_nMasterSlave = 1;
	//}}AFX_DATA_INIT
	m_bMasterSuction		= FALSE;
	m_bSlaveSuction			= FALSE;
	m_bAcrylMasterSuction   = FALSE;
	m_bAcrylSlaveSuction    = FALSE;
	m_bVacuumMotor			= FALSE;
	m_nMPGMode				= 0;
	m_bSafetyMode			= FALSE;
	m_bDoorBypass			= FALSE;
	m_bTableClamp1			= FALSE;
	m_bTableClamp2			= FALSE;

	//2011524
	m_nRadioVacuumTable = 0;
}

CPaneManualControlMotorLarge::~CPaneManualControlMotorLarge()
{
}

void CPaneManualControlMotorLarge::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlMotorLarge)
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL, m_stcSpeedM);
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL2, m_stcSpeedM2);
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL3, m_stcSpeedM3);
	DDX_Control(pDX, IDC_STATIC_SPEED_COLLIMATOR_VAL, m_stcSpeedC);
	DDX_Control(pDX, IDC_STATIC_SPEED_COLLIMATOR_VAL2, m_stcSpeedC2);
	DDX_Control(pDX, IDC_STATIC_SPEED_COLLIMATOR_VAL3, m_stcSpeedC3);
	DDX_Control(pDX, IDC_STATIC_SPEED_COLLIMATOR_VAL4, m_stcSpeedC4);
	DDX_Control(pDX, IDC_STATIC_SPEED_Z2_VAL, m_stcSpeedZ2);
	DDX_Control(pDX, IDC_STATIC_SPEED_Z1_VAL, m_stcSpeedZ1);
	DDX_Control(pDX, IDC_STATIC_SPEED_Y_VAL, m_stcSpeedY);
	DDX_Control(pDX, IDC_STATIC_SPEED_X_VAL, m_stcSpeedX);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL2, m_stcPosC2);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL3, m_stcPosC3);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL4, m_stcPosC4);


	

	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL2, m_stcPosM2);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL3, m_stcPosM3);

	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL4, m_stcPosM4);
	DDX_Control(pDX, IDC_STATIC_SPEED_MASK_VAL4, m_stcSpeedM4);

	DDX_Control(pDX, IDC_STATIC_POS_ROT_VAL, m_stcPosRot);
	DDX_Control(pDX, IDC_STATIC_SPEED_ROT_VAL, m_stcSpeedRot);
	DDX_Control(pDX, IDC_STATIC_POS_TOPHAT_VAL, m_stcPosTopHat);
	DDX_Control(pDX, IDC_STATIC_SPEED_TOPHAT_VAL, m_stcSpeedTopHat);


	DDX_Control(pDX, IDC_STATIC_POS_Z2_VAL, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VAL, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VAL, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_X_VAL, m_stcPosX);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_HOMING, m_btnUnloaderHoming);
	DDX_Control(pDX, IDC_BUTTON_LOADER_HOMING, m_btnLoaderHoming);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_HOMING, m_btnMotorHoming);
	DDX_Control(pDX, IDC_BUTTON_POS_UNLOADING, m_btnUnloadingPos);
	DDX_Control(pDX, IDC_BUTTON_POS_LOADING, m_btnLoadingPos);
	DDX_Control(pDX, IDC_CHECK_SLAVE_ON, m_chkSlaveOn);
	DDX_Control(pDX, IDC_CHECK_MASTER_ON, m_chkMasterOn);
	DDX_Control(pDX, IDC_CHECK_SLAVE_ACRYL_ON, m_chkSlaveAcrylOn);
	DDX_Control(pDX, IDC_CHECK_MASTER_ACRYL_ON, m_chkMasterAcrylOn);
	DDX_Control(pDX, IDC_CHECK_MASTER_ACRYLIC_ON, m_chkMasterAcrOn);
	DDX_Control(pDX, IDC_CHECK_SLAVE_ACRYLIC_ON, m_chkSlaveAcrOn);
	DDX_Control(pDX, IDC_CHECK_VACUUM_MOTOR, m_chkVacuumMotorOn);
	DDX_Control(pDX, IDC_CHECK_SAFETY_MODE, m_chkSafetyOn);
	DDX_Control(pDX, IDC_CHECK_DOOR_BYPASS, m_chkDoorBypass);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_chkTableClamp1);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_chkTableClamp2);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_UNLOAD, m_btnUnloaderUnload);
	DDX_Control(pDX, IDC_BUTTON_MPG_MODE, m_btnMPG);
	DDX_Control(pDX, IDC_BUTTON_REJECT, m_btnReject);
	DDX_Control(pDX, IDC_BUTTON_LOADER_REJECT, m_btnLoaderReject);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_REJECT, m_btnUnloaderReject);
	DDX_Control(pDX, IDC_BUTTON_ALL_REJECT, m_btnAllReject);
	DDX_Control(pDX, IDC_BUTTON_LOADER_LOAD, m_btnLoaderLoad);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN, m_btnLoaderAlign);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN_LOAD, m_btnLoaderAlignLoad);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_MOVE2, m_btnMove2);
	DDX_Control(pDX, IDC_BUTTON_MOVE_INPOS, m_btnMoveInpos);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_Y, m_edtTargetY);
	DDX_Control(pDX, IDC_EDIT_TARGET_M, m_edtTargetM);
	DDX_Control(pDX, IDC_EDIT_TARGET_C, m_edtTargetC);
	DDX_Control(pDX, IDC_EDIT_TARGET_X, m_edtTargetX);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z4, m_edtTargetZ4);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z3, m_edtTargetZ3);
	DDX_Control(pDX, IDC_EDIT_TARGET_Y2, m_edtTargetY2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_C2, m_edtTargetC2);
	DDX_Control(pDX, IDC_EDIT_TARGET_X2, m_edtTargetX2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M3, m_edtTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_M4, m_edtTargetM4);
	DDX_Control(pDX, IDC_EDIT_TARGET_M5, m_edtTargetM5);
	DDX_Control(pDX, IDC_EDIT_TARGET_M6, m_edtTargetM6);

	DDX_Control(pDX, IDC_EDIT_TARGET_M8, m_edtTargetM4_1);
	DDX_Control(pDX, IDC_EDIT_TARGET_M9, m_edtTargetM4_2);
	DDX_Control(pDX, IDC_EDIT_TARGET_ROT1, m_edtTargetRot1);
	DDX_Control(pDX, IDC_EDIT_TARGET_ROT2, m_edtTargetRot2);
	DDX_Control(pDX, IDC_EDIT_TARGET_TOPHAT1, m_edtTargetTophat1);
	DDX_Control(pDX, IDC_EDIT_TARGET_TOPHAT2, m_edtTargetTophat2);

	DDX_Control(pDX, IDC_EDIT_REPEAT, m_edtRep);
	DDX_Control(pDX, IDC_EDIT_DELAY, m_edtDelay);


	DDX_Radio(pDX, IDC_RADIO_ABS, m_nAbs);
	DDX_Check(pDX, IDC_CHECK_TARGET_X, m_bTargetX);
	DDX_Check(pDX, IDC_CHECK_TARGET_Y, m_bTargetY);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z1, m_bTargetZ1);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z2, m_bTargetZ2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C, m_bTargetC);
	DDX_Check(pDX, IDC_CHECK_TARGET_C2, m_bTargetC2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C3, m_bTargetC3);
	DDX_Check(pDX, IDC_CHECK_TARGET_C4, m_bTargetC4);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK, m_bTargetM);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK2, m_bTargetM2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK3, m_bTargetM3);
	
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK5, m_bTargetM4);
	DDX_Check(pDX, IDC_CHECK_TARGET_ROT, m_bTargetRot);
	DDX_Check(pDX, IDC_CHECK_TARGET_TOPHAT, m_bTargetTopHat);
	DDX_Radio(pDX, IDC_RADIO_UNLOAD_MS, m_nMasterSlave);
	DDX_Control(pDX, IDC_EDIT_TARGET_C3, m_edtTargetC3);
	DDX_Control(pDX, IDC_EDIT_TARGET_C4, m_edtTargetC4);

	DDX_Control(pDX, IDC_EDIT_TARGET_C7, m_edtTargetC5);
	DDX_Control(pDX, IDC_EDIT_TARGET_C8, m_edtTargetC6);
	DDX_Control(pDX, IDC_EDIT_TARGET_C9, m_edtTargetC7);
	DDX_Control(pDX, IDC_EDIT_TARGET_C10, m_edtTargetC8);

	//2011519
	DDX_Control(pDX, IDC_STATIC_POS_ATTEUNA_VAL1, m_stcPosA);
	DDX_Control(pDX, IDC_STATIC_POS_ATTEUNA_VAL2, m_stcPosA2);
	DDX_Control(pDX, IDC_STATIC_SPEED_ATTEUNATOR_VAL1, m_stcSpeedA);
	DDX_Control(pDX, IDC_STATIC_SPEED_ATTEUNATOR_VAL2, m_stcSpeedA2);

	DDX_Check(pDX, IDC_CHECK_TARGET_A, m_bTargetA );
	DDX_Check(pDX, IDC_CHECK_TARGET_A2, m_bTargetA2 );

	DDX_Control(pDX, IDC_EDIT_TARGET_A, m_edtTargetA);
	DDX_Control(pDX, IDC_EDIT_TARGET_A2, m_edtTargetA2);
	DDX_Control(pDX, IDC_EDIT_TARGET_A3, m_edtTargetA3);
	DDX_Control(pDX, IDC_EDIT_TARGET_A4, m_edtTargetA4);
	
	DDX_Control(pDX, IDC_CHECK_CHANGE, m_chkChangeDirection);
	//2011524
	DDX_Radio(pDX, IDC_RADIO_TABLE_A, m_nRadioVacuumTable);
	DDX_Control(pDX, IDC_BUTTON_LOADER_OUT_BASKET, m_btnLDBasketOut);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_OUT_BASKET, m_btnUDBasketOut);

	DDX_Control(pDX, IDC_BUTTON_POS_TC_CLEAN, m_btnTCCleanPos);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlMotorLarge, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlMotorLarge)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE2, OnButtonMove2)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_INPOS, OnButtonMoveInpos)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN, OnButtonLoaderAlign)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN_LOAD, OnButtonLoaderAlignLoad)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_LOAD, OnButtonLoaderLoad)
	ON_BN_CLICKED(IDC_CHECK_MASTER_ON, OnCheckMasterOn)
	ON_BN_CLICKED(IDC_CHECK_SLAVE_ON, OnCheckSlaveOn)
	ON_BN_CLICKED(IDC_CHECK_MASTER_ACRYL_ON, OnCheckAcrylMasterOn)
	ON_BN_CLICKED(IDC_CHECK_SLAVE_ACRYL_ON, OnCheckAcrylSlaveOn)
	ON_BN_CLICKED(IDC_CHECK_VACUUM_MOTOR, OnCheckVacuumMotorOn)
	ON_BN_CLICKED(IDC_CHECK_SAFETY_MODE, OnCheckSafetyOn)
	ON_BN_CLICKED(IDC_CHECK_DOOR_BYPASS, OnCheckDoorBypass)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP1, OnCheckTableClamp1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP2, OnCheckTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_POS_LOADING, OnButtonPosLoading)
	ON_BN_CLICKED(IDC_BUTTON_POS_UNLOADING, OnButtonPosUnloading)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_UNLOAD, OnButtonUnloaderUnload)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_HOMING, OnButtonMotorHoming)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_HOMING, OnButtonLoaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_HOMING, OnButtonUnloaderHoming)
	ON_BN_CLICKED(IDC_BUTTON_MPG_MODE, OnButtonMPG)
	ON_BN_CLICKED(IDC_BUTTON_REJECT, OnButtonReject)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_REJECT, OnButtonLoaderReject)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_REJECT, OnButtonUnloaderReject)
	ON_BN_CLICKED(IDC_BUTTON_ALL_REJECT, OnButtonAllReject)
	ON_BN_CLICKED(IDC_RADIO_TABLE_A,OnRadioTable1A)
	ON_BN_CLICKED(IDC_RADIO_TABLE_B,OnRadioTable1B)
	ON_BN_CLICKED(IDC_RADIO_TABLE_C,OnRadioTable1C)
	ON_BN_CLICKED(IDC_RADIO_TABLE_D,OnRadioTable1D)
	ON_BN_CLICKED(IDC_CHECK_MASTER_ACRYLIC_ON, OnCheckMasterAcrylicOn)
	ON_BN_CLICKED(IDC_CHECK_SLAVE_ACRYLIC_ON, OnCheckSlaveAcrylicOn)
	ON_BN_CLICKED(IDC_RADIO_UNLOAD_M, OnRadioUnloadM)
	ON_BN_CLICKED(IDC_RADIO_UNLOAD_S, OnRadioUnloadS)
	ON_BN_CLICKED(IDC_RADIO_UNLOAD_MS, OnRadioUnloadMs)
	ON_BN_CLICKED(IDC_CHECK_CHANGE, OnCheckChangeDirection)
//	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_OUT_BASKET, OnButtonUDBasketOut)
//	ON_BN_CLICKED(IDC_BUTTON_LOADER_OUT_BASKET, OnButtonLDBasketOut)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_LOADER_OUT_BASKET, OnButtonLDBasketOut)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_OUT_BASKET,OnButtonUDBasketOut)
	ON_BN_CLICKED(IDC_BUTTON_POS_TC_CLEAN, &CPaneManualControlMotorLarge::OnBnClickedButtonPosTcClean)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorLarge diagnostics

#ifdef _DEBUG
void CPaneManualControlMotorLarge::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlMotorLarge::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlMotorLarge message handlers

void CPaneManualControlMotorLarge::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();

	DispVelocity();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{	
		GetDlgItem(IDC_CHECK_SLAVE_ON)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TABLE_USE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_M)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_S)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_UNLOAD_MS)->ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);

		GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_M2)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_MASK_VAL2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_MASK_VAL2)->EnableWindow(FALSE);


		//2011519 ?? check
		GetDlgItem(IDC_CHECK_TARGET_A)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_A)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_A2)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_POS_ATTEUNATOR1)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_ATTEUNA_VAL1)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_ATTEUNATOR2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_ATTEUNA_VAL2)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR1)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR_VAL1)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR_VAL2)->EnableWindow(FALSE);



		GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_C)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_C2)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->EnableWindow(FALSE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_TARGET_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_TARGET_Z3)->EnableWindow(FALSE);
			
			GetDlgItem(IDC_STATIC_POS_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_POS_Z1_VAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_SPEED_Z1)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_SPEED_Z1_VAL)->EnableWindow(FALSE);
		}
	}



#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	GetDlgItem(IDC_STATIC_POS_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK_VAL3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK_VAL3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M6)->ShowWindow(SW_HIDE);
#ifndef __SERVO_MOTOR__
	GetDlgItem(IDC_STATIC_POS_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK_VAL3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK_VAL3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M6)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK_VAL2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK_VAL2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_TARGET_M4)->ShowWindow(SW_HIDE);
#endif

//	m_nTimerID = SetTimer( 38, 300, NULL );
	m_nTimerID = 0;
}

BOOL CPaneManualControlMotorLarge::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlMotorLarge::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Position
	GetDlgItem(IDC_STATIC_MOTOR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_X_VAL)->SetFont( &m_fntStatic );
	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Y_VAL)->SetFont( &m_fntStatic );
	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Z1_VAL)->SetFont( &m_fntStatic );
	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_Z2_VAL)->SetFont( &m_fntStatic );
	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_MASK_VAL)->SetFont( &m_fntStatic );
	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->SetFont( &m_fntStatic );
	
	m_stcPosM2.SetFont( &m_fntStatic );
	m_stcPosM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK2)->SetFont( &m_fntStatic );

	m_stcPosM3.SetFont( &m_fntStatic );
	m_stcPosM3.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM3.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK3)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_POS_MASK4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SPEED_MASK4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_ROT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SPEED_ROT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_TOPHAT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SPEED_TOPHAT)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR4)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcPosC2.SetFont( &m_fntStatic );
	m_stcPosC2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC3.SetFont( &m_fntStatic );
	m_stcPosC3.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC3.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC4.SetFont( &m_fntStatic );
	m_stcPosC4.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC4.SetBackColor( VALUE_BACK_COLOR );
	
#ifdef __PKG_MODIFY__
	GetDlgItem(IDC_STATIC_POS_TOPHAT)->SetWindowText("Collimator");
	GetDlgItem(IDC_STATIC_SPEED_TOPHAT)->SetWindowText("Collimator");
#else
	GetDlgItem(IDC_STATIC_POS_TOPHAT)->SetWindowText("TopHat");
	GetDlgItem(IDC_STATIC_SPEED_TOPHAT)->SetWindowText("TopHat");
#endif
	m_stcPosM4.SetFont( &m_fntStatic );
	m_stcPosM4.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM4.SetBackColor( VALUE_BACK_COLOR );
	m_stcSpeedM4.SetFont( &m_fntStatic );
	m_stcSpeedM4.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM4.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosRot.SetFont( &m_fntStatic );
	m_stcPosRot.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosRot.SetBackColor( VALUE_BACK_COLOR );
	m_stcSpeedRot.SetFont( &m_fntStatic );
	m_stcSpeedRot.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedRot.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosTopHat.SetFont( &m_fntStatic );
	m_stcPosTopHat.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosTopHat.SetBackColor( VALUE_BACK_COLOR );
	m_stcSpeedTopHat.SetFont( &m_fntStatic );
	m_stcSpeedTopHat.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedTopHat.SetBackColor( VALUE_BACK_COLOR );
	//2011519
	GetDlgItem(IDC_STATIC_POS_ATTEUNATOR1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_ATTEUNA_VAL1)->SetFont( &m_fntStatic );
	m_stcPosA.SetFont( &m_fntStatic );
	m_stcPosA.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosA.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_ATTEUNATOR2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_POS_ATTEUNA_VAL2)->SetFont( &m_fntStatic );
	m_stcPosA2.SetFont( &m_fntStatic );
	m_stcPosA2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosA2.SetBackColor( VALUE_BACK_COLOR );


	GetDlgItem(IDC_STATIC_REPEAT)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_DELAY)->SetFont(&m_fntStatic);
	// Speed
	GetDlgItem(IDC_STATIC_MOTOR_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SPEED_X)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_X_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedX.SetFont( &m_fntStatic );
	m_stcSpeedX.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedX.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Y)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Y_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedY.SetFont( &m_fntStatic );
	m_stcSpeedY.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedY.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Z1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Z1_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedZ1.SetFont( &m_fntStatic );
	m_stcSpeedZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedZ1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_Z2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedZ2.SetFont( &m_fntStatic );
	m_stcSpeedZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedZ2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_MASK)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_MASK_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedM.SetFont( &m_fntStatic );
	m_stcSpeedM.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR)->SetFont( &m_fntStatic );

	m_stcSpeedM2.SetFont( &m_fntStatic );
	m_stcSpeedM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_MASK2)->SetFont( &m_fntStatic );

	m_stcSpeedM3.SetFont( &m_fntStatic );
	m_stcSpeedM3.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedM3.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_MASK3)->SetFont( &m_fntStatic );

	//GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedC.SetFont( &m_fntStatic );
	m_stcSpeedC.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedC.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR_VAL)->SetFont( &m_fntStatic );
	m_stcSpeedC2.SetFont( &m_fntStatic );
	m_stcSpeedC2.SetForeColor( VALUE_FORE_COLOR ); 
	m_stcSpeedC2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR3)->SetFont( &m_fntStatic );
	m_stcSpeedC3.SetFont( &m_fntStatic );
	m_stcSpeedC3.SetForeColor( VALUE_FORE_COLOR ); 
	m_stcSpeedC3.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_COLLIMATOR4)->SetFont( &m_fntStatic );
	m_stcSpeedC4.SetFont( &m_fntStatic );
	m_stcSpeedC4.SetForeColor( VALUE_FORE_COLOR ); 
	m_stcSpeedC4.SetBackColor( VALUE_BACK_COLOR );
	//2011519
	GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR1)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR_VAL1)->SetFont( &m_fntStatic );
	m_stcSpeedA.SetFont( &m_fntStatic );
	m_stcSpeedA.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedA.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR2)->SetFont( &m_fntStatic );
	//GetDlgItem(IDC_STATIC_SPEED_ATTEUNATOR_VAL2)->SetFont( &m_fntStatic );
	m_stcSpeedA2.SetFont( &m_fntStatic );
	m_stcSpeedA2.SetForeColor( VALUE_FORE_COLOR );
	m_stcSpeedA2.SetBackColor( VALUE_BACK_COLOR );


	// Target Pos
	GetDlgItem(IDC_STATIC_TARGET_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1_GROUP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2_GROUP)->SetFont( &m_fntStatic );

	// Loader
	GetDlgItem(IDC_STATIC_LOADER)->SetFont( &m_fntStatic );
	
	// Unloader
	GetDlgItem(IDC_STATIC_UNLOADER)->SetFont( &m_fntStatic );

	// Table Suction
	GetDlgItem(IDC_STATIC_TABLE_SUCTION)->SetFont( &m_fntStatic );

	// Table Use
	GetDlgItem(IDC_STATIC_TABLE_USE)->SetFont( &m_fntStatic );

	// MPG Mode
	GetDlgItem(IDC_STATIC_MPG_MODE)->SetFont( &m_fntStatic );

	// Table Reject
	GetDlgItem(IDC_STATIC_REJECT)->SetFont(&m_fntStatic);

	// Vacuum Motor
	GetDlgItem(IDC_STATIC_VACUUM_MOTOR)->SetFont( &m_fntStatic );

	// Safety Mode
	GetDlgItem(IDC_STATIC_SAFETY_MODE)->SetFont( &m_fntStatic );

	// Door by pass
	GetDlgItem(IDC_STATIC_DOOR_BYPASS)->SetFont( &m_fntStatic );

	// Loading / Unloading Position
	GetDlgItem(IDC_STATIC_LOADING_UNLOADING_POS)->SetFont( &m_fntStatic );

	// Table Clamp
	GetDlgItem(IDC_STATIC_TABLE_CLAMP)->SetFont( &m_fntStatic );
	
	// Homing
	GetDlgItem(IDC_STATIC_HOMING)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_POS_TOPHAT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_TOPHAT_VAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_TOPHAT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_TOPHAT_VAL)->ShowWindow(SW_HIDE);

#ifdef __PKG_MODIFY__
	GetDlgItem(IDC_STATIC_POS_MASK4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_ROT)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_MASK_VAL4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK_VAL4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_ROT_VAL)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_SPEED_ROT_VAL)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_SPEED_MASK4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_ROT)->ShowWindow(SW_SHOW);
#else

	GetDlgItem(IDC_STATIC_POS_MASK4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_ROT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK_VAL4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK_VAL4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_ROT_VAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_ROT_VAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_MASK4)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SPEED_ROT)->ShowWindow(SW_HIDE);
#endif

}

void CPaneManualControlMotorLarge::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Target Position
	GetDlgItem(IDC_CHECK_TARGET_X)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Y)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_Z2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->SetFont( &m_fntBtn );

	GetDlgItem(IDC_CHECK_TARGET_MASK5)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_ROT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_TOPHAT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C3)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_C4)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_ABS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_INC)->SetFont( &m_fntBtn );
	//2011519
	GetDlgItem(IDC_CHECK_TARGET_A)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_CHECK_TARGET_A2)->SetFont( &m_fntBtn );


	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMove2.SetFont( &m_fntBtn );
	m_btnMove2.SetFlat( FALSE );
	m_btnMove2.EnableBallonToolTip();
	m_btnMove2.SetToolTipText( _T("Move Tagerget Position2") );
	m_btnMove2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove2.SetBtnCursor(IDC_HAND_1);
	
	m_btnMoveInpos.SetFont( &m_fntBtn );
	m_btnMoveInpos.SetFlat( FALSE );
	m_btnMoveInpos.EnableBallonToolTip();
	m_btnMoveInpos.SetToolTipText( _T("XY Table Inposition Test") );
	m_btnMoveInpos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveInpos.SetBtnCursor(IDC_HAND_1);

	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop Tagerget Position") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	// Loader
	m_btnLoaderAlign.SetFont( &m_fntBtn );
	m_btnLoaderAlign.SetFlat( FALSE );
	m_btnLoaderAlign.EnableBallonToolTip();
	m_btnLoaderAlign.SetToolTipText( _T("Loader Align") );
	m_btnLoaderAlign.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlign.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderAlignLoad.SetFont( &m_fntBtn );
	m_btnLoaderAlignLoad.SetFlat( FALSE );
	m_btnLoaderAlignLoad.EnableBallonToolTip();
	m_btnLoaderAlignLoad.SetToolTipText( _T("Loader Align && Load") );
	m_btnLoaderAlignLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlignLoad.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderLoad.SetFont( &m_fntBtn );
	m_btnLoaderLoad.SetFlat( FALSE );
	m_btnLoaderLoad.EnableBallonToolTip();
	m_btnLoaderLoad.SetToolTipText( _T("Loader Load") );
	m_btnLoaderLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderLoad.SetBtnCursor(IDC_HAND_1);

	// Unloader
	m_btnUnloaderUnload.SetFont( &m_fntBtn );
	m_btnUnloaderUnload.SetFlat( FALSE );
	m_btnUnloaderUnload.EnableBallonToolTip();
	m_btnUnloaderUnload.SetToolTipText( _T("Unloader Unload") );
	m_btnUnloaderUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderUnload.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_RADIO_UNLOAD_M)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_UNLOAD_S)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_UNLOAD_MS)->SetFont( &m_fntBtn );

	// Table Suction
	m_chkMasterOn.SetFont( &m_fntBtn );
	m_chkMasterOn.SetImageOrg( 10, 3 );
	m_chkMasterOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkMasterOn.EnableBallonToolTip();
	m_chkMasterOn.SetToolTipText( _T("Master On") );
	m_chkMasterOn.SetBtnCursor(IDC_HAND_1);

	m_chkSlaveOn.SetFont( &m_fntBtn );
	m_chkSlaveOn.SetImageOrg( 10, 3 );
	m_chkSlaveOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSlaveOn.EnableBallonToolTip();
	m_chkSlaveOn.SetToolTipText( _T("Slave On") );
	m_chkSlaveOn.SetBtnCursor(IDC_HAND_1);

	m_chkMasterAcrylOn.SetFont( &m_fntBtn );
	m_chkMasterAcrylOn.SetImageOrg( 10, 3 );
	m_chkMasterAcrylOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkMasterAcrylOn.EnableBallonToolTip();
	m_chkMasterAcrylOn.SetToolTipText( _T("Master Acr On/Off") );
	m_chkMasterAcrylOn.SetBtnCursor(IDC_HAND_1);
	
	m_chkSlaveAcrylOn.SetFont( &m_fntBtn );
	m_chkSlaveAcrylOn.SetImageOrg( 10, 3 );
	m_chkSlaveAcrylOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSlaveAcrylOn.EnableBallonToolTip();
	m_chkSlaveAcrylOn.SetToolTipText( _T("Slave Acr On/Off") );
	m_chkSlaveAcrylOn.SetBtnCursor(IDC_HAND_1);

	// Table Suction
	m_chkMasterAcrOn.SetFont( &m_fntBtn );
	m_chkMasterAcrOn.SetImageOrg( 10, 3 );
	m_chkMasterAcrOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkMasterAcrOn.EnableBallonToolTip();
	m_chkMasterAcrOn.SetToolTipText( _T("Vacuum Motor On/Off") );
	m_chkMasterAcrOn.SetBtnCursor(IDC_HAND_1);
	
	m_chkSlaveAcrOn.SetFont( &m_fntBtn );
	m_chkSlaveAcrOn.SetImageOrg( 10, 3 );
	m_chkSlaveAcrOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSlaveAcrOn.EnableBallonToolTip();
	m_chkSlaveAcrOn.SetToolTipText( _T("Slave Acrylic On") );
	m_chkSlaveAcrOn.SetBtnCursor(IDC_HAND_1);

	// Vacuum Motor
	m_chkVacuumMotorOn.SetFont( &m_fntBtn );
	m_chkVacuumMotorOn.SetImageOrg( 10, 3 );
	m_chkVacuumMotorOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVacuumMotorOn.EnableBallonToolTip();
	m_chkVacuumMotorOn.SetToolTipText( _T("Vacuum Motor On") );
	m_chkVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	// Safety Mode
	m_chkSafetyOn.SetFont( &m_fntBtn );
	m_chkSafetyOn.SetImageOrg( 10, 3 );
	m_chkSafetyOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSafetyOn.EnableBallonToolTip();
	m_chkSafetyOn.SetToolTipText( _T("Safety Mode") );
	m_chkSafetyOn.SetBtnCursor(IDC_HAND_1);

	// Door Bypass
	m_chkDoorBypass.SetFont( &m_fntBtn );
	m_chkDoorBypass.SetImageOrg( 10, 3 );
	m_chkDoorBypass.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkDoorBypass.EnableBallonToolTip();
	m_chkDoorBypass.SetToolTipText( _T("Door Bypass") );
	m_chkDoorBypass.SetBtnCursor(IDC_HAND_1);

	// Table Clamp 1
	m_chkTableClamp1.SetFont( &m_fntBtn );
	m_chkTableClamp1.SetImageOrg( 10, 3 );
	m_chkTableClamp1.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkTableClamp1.EnableBallonToolTip();
	m_chkTableClamp1.SetBtnCursor(IDC_HAND_1);

	// Table Clamp 2
	m_chkTableClamp2.SetFont( &m_fntBtn );
	m_chkTableClamp2.SetImageOrg( 10, 3 );
	m_chkTableClamp2.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkTableClamp2.EnableBallonToolTip();
	m_chkTableClamp2.SetToolTipText( _T("Right Table Clamp") );
	m_chkTableClamp2.SetBtnCursor(IDC_HAND_1);

	m_chkChangeDirection.SetFont( &m_fntBtn );
	m_chkChangeDirection.SetImageOrg( 10, 3 );
	m_chkChangeDirection.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkChangeDirection.EnableBallonToolTip();
	m_chkChangeDirection.SetToolTipText( _T("Set Handler Direction") );
	m_chkChangeDirection.SetBtnCursor(IDC_HAND_1);
	if(gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		m_chkTableClamp1.ShowWindow(SW_HIDE);
		m_chkTableClamp2.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		m_chkTableClamp1.ShowWindow(SW_SHOW);
		m_chkTableClamp2.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_SHOW);
	}
	else
	{
		m_chkTableClamp1.ShowWindow(SW_SHOW);
		m_chkTableClamp2.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->ShowWindow(SW_SHOW);
	}

	// Loading / Unloading Position
	m_btnLoadingPos.SetFont( &m_fntBtn );
	m_btnLoadingPos.SetFlat( FALSE );
	m_btnLoadingPos.EnableBallonToolTip();
	m_btnLoadingPos.SetToolTipText( _T("Loading Position") );
	m_btnLoadingPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadingPos.SetFont( &m_fntBtn );
	m_btnUnloadingPos.SetFlat( FALSE );
	m_btnUnloadingPos.EnableBallonToolTip();
	m_btnUnloadingPos.SetToolTipText( _T("Unloading Position") );
	m_btnUnloadingPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadingPos.SetBtnCursor(IDC_HAND_1);

	// Homing
	m_btnMotorHoming.SetFont( &m_fntBtn );
	m_btnMotorHoming.SetFlat( FALSE );
	m_btnMotorHoming.EnableBallonToolTip();
	m_btnMotorHoming.SetToolTipText( _T("Motor Homing") );
	m_btnMotorHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMotorHoming.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderHoming.SetFont( &m_fntBtn );
	m_btnLoaderHoming.SetFlat( FALSE );
	m_btnLoaderHoming.EnableBallonToolTip();
	m_btnLoaderHoming.SetToolTipText( _T("Loader Homing") );
	m_btnLoaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderHoming.SetBtnCursor(IDC_HAND_1);

	m_btnUnloaderHoming.SetFont( &m_fntBtn );
	m_btnUnloaderHoming.SetFlat( FALSE );
	m_btnUnloaderHoming.EnableBallonToolTip();
	m_btnUnloaderHoming.SetToolTipText( _T("Unloader Homing") );
	m_btnUnloaderHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderHoming.SetBtnCursor(IDC_HAND_1);

	// MPG Mode
	m_btnMPG.SetFont( &m_fntBtn );
	m_btnMPG.SetFlat( FALSE );
	m_btnMPG.EnableBallonToolTip();
	m_btnMPG.SetToolTipText( _T("MPG Mode Select") );
	m_btnMPG.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMPG.SetBtnCursor(IDC_HAND_1);

	// Table Reject
	m_btnReject.SetFont( &m_fntBtn );
	m_btnReject.SetFlat( FALSE );
	m_btnReject.EnableBallonToolTip();
	m_btnReject.SetToolTipText( _T("Table Reject") );
	m_btnReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReject.SetBtnCursor(IDC_HAND_1);

	// Loader Reject
	m_btnLoaderReject.SetFont( &m_fntBtn );
	m_btnLoaderReject.SetFlat( FALSE );
	m_btnLoaderReject.EnableBallonToolTip();
	m_btnLoaderReject.SetToolTipText( _T("Loader Reject") );
	m_btnLoaderReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderReject.SetBtnCursor(IDC_HAND_1);

	// Unloader Reject
	m_btnUnloaderReject.SetFont( &m_fntBtn );
	m_btnUnloaderReject.SetFlat( FALSE );
	m_btnUnloaderReject.EnableBallonToolTip();
	m_btnUnloaderReject.SetToolTipText( _T("Unloader Reject") );
	m_btnUnloaderReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderReject.SetBtnCursor(IDC_HAND_1);

	// All Reject
	m_btnAllReject.SetFont( &m_fntBtn );
	m_btnAllReject.SetFlat( FALSE );
	m_btnAllReject.EnableBallonToolTip();
	m_btnAllReject.SetToolTipText( _T("Table&Loader&Unloader Reject") );
	m_btnAllReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAllReject.SetBtnCursor(IDC_HAND_1);
	m_btnAllReject.SetColorType(1);


	m_btnLDBasketOut.SetFont( &m_fntBtn );
	m_btnLDBasketOut.SetFlat( FALSE );
	m_btnLDBasketOut.EnableBallonToolTip();
	m_btnLDBasketOut.SetToolTipText( _T("Out LD Basket") );
	m_btnLDBasketOut.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLDBasketOut.SetBtnCursor(IDC_HAND_1);

	m_btnUDBasketOut.SetFont( &m_fntBtn );
	m_btnUDBasketOut.SetFlat( FALSE );
	m_btnUDBasketOut.EnableBallonToolTip();
	m_btnUDBasketOut.SetToolTipText( _T("Out UD Basket") );
	m_btnUDBasketOut.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUDBasketOut.SetBtnCursor(IDC_HAND_1);

	m_btnTCCleanPos.SetFont( &m_fntBtn );
	m_btnTCCleanPos.SetFlat( FALSE );
	m_btnTCCleanPos.EnableBallonToolTip();
	m_btnTCCleanPos.SetToolTipText( _T("T/C Lens Cleaning Position") );
	m_btnTCCleanPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTCCleanPos.SetBtnCursor(IDC_HAND_1);

	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		m_btnLoaderLoad.EnableWindow(FALSE);
		m_btnUnloaderUnload.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
	}

	if(gSystemINI.m_sHardWare.bTableVacuumSelect)
	{
		m_chkMasterAcrOn.ShowWindow(SW_SHOW);
	}
	else
	{
		m_chkMasterAcrOn.ShowWindow(SW_HIDE);
	}
	GetDlgItem(IDC_CHECK_TARGET_TOPHAT)->ShowWindow(SW_HIDE);
#ifdef __PKG_MODIFY__
	GetDlgItem(IDC_CHECK_TARGET_MASK5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_ROT)->ShowWindow(SW_SHOW);
#else

	GetDlgItem(IDC_CHECK_TARGET_MASK5)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_ROT)->ShowWindow(SW_HIDE);
#endif
	m_btnTCCleanPos.ShowWindow(SW_SHOW);


}

void CPaneManualControlMotorLarge::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(160, "Arial Bold");

	// RepeatNo
	m_edtRep.SetFont( &m_fntEdit );
	m_edtRep.SetReceivedFlag( 1 );
	m_edtRep.SetWindowText( _T("0") );

	m_edtDelay.SetFont( &m_fntEdit );
	m_edtDelay.SetReceivedFlag( 1 );
	m_edtDelay.SetWindowText( _T("0") );

	// Target X
	m_edtTargetX.SetFont( &m_fntEdit );
	m_edtTargetX.SetReceivedFlag( 3 );
	m_edtTargetX.SetWindowText( _T("0.0") );

	// Target Y
	m_edtTargetY.SetFont( &m_fntEdit );
	m_edtTargetY.SetReceivedFlag( 3 );
	m_edtTargetY.SetWindowText( _T("0.0") );

	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );

	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );

	// Target M
	m_edtTargetM.SetFont( &m_fntEdit );
	m_edtTargetM.SetReceivedFlag( 3 );
	m_edtTargetM.SetWindowText( _T("0.0") );
	

	// Target C
	m_edtTargetC.SetFont( &m_fntEdit );
	m_edtTargetC.SetReceivedFlag( 3 );
	m_edtTargetC.SetWindowText( _T("0.0") );

	// Target X'2
	m_edtTargetX2.SetFont( &m_fntEdit );
	m_edtTargetX2.SetReceivedFlag( 3 );
	m_edtTargetX2.SetWindowText( _T("0.0") );
	
	// Target Y'2
	m_edtTargetY2.SetFont( &m_fntEdit );
	m_edtTargetY2.SetReceivedFlag( 3 );
	m_edtTargetY2.SetWindowText( _T("0.0") );
	
	// Target Z1'2
	m_edtTargetZ3.SetFont( &m_fntEdit );
	m_edtTargetZ3.SetReceivedFlag( 3 );
	m_edtTargetZ3.SetWindowText( _T("0.0") );
	
	// Target Z2'2
	m_edtTargetZ4.SetFont( &m_fntEdit );
	m_edtTargetZ4.SetReceivedFlag( 3 );
	m_edtTargetZ4.SetWindowText( _T("0.0") );
	
	// Target M'2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );
	
	// Target C'2
	m_edtTargetC2.SetFont( &m_fntEdit );
	m_edtTargetC2.SetReceivedFlag( 3 );
	m_edtTargetC2.SetWindowText( _T("0.0") );

	// Target C'3  : 
	m_edtTargetC3.SetFont( &m_fntEdit );
	m_edtTargetC3.SetReceivedFlag( 3 );
	m_edtTargetC3.SetWindowText( _T("0.0") );

	// Target C'4 
	m_edtTargetC4.SetFont( &m_fntEdit );
	m_edtTargetC4.SetReceivedFlag( 3 );
	m_edtTargetC4.SetWindowText( _T("0.0") );

	// Target C'5 
	m_edtTargetC5.SetFont( &m_fntEdit );
	m_edtTargetC5.SetReceivedFlag( 3 );
	m_edtTargetC5.SetWindowText( _T("0.0") );

	// Target C'6 
	m_edtTargetC6.SetFont( &m_fntEdit );
	m_edtTargetC6.SetReceivedFlag( 3 );
	m_edtTargetC6.SetWindowText( _T("0.0") );

	// Target C'7 
	m_edtTargetC7.SetFont( &m_fntEdit );
	m_edtTargetC7.SetReceivedFlag( 3 );
	m_edtTargetC7.SetWindowText( _T("0.0") );

	// Target C'8 
	m_edtTargetC8.SetFont( &m_fntEdit );
	m_edtTargetC8.SetReceivedFlag( 3 );
	m_edtTargetC8.SetWindowText( _T("0.0") );

	// Target M'3  : 
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );
	
	// Target M'4 
	m_edtTargetM4.SetFont( &m_fntEdit );
	m_edtTargetM4.SetReceivedFlag( 3 );
	m_edtTargetM4.SetWindowText( _T("0.0") );

	// Target M'5  : 
	m_edtTargetM5.SetFont( &m_fntEdit );
	m_edtTargetM5.SetReceivedFlag( 3 );
	m_edtTargetM5.SetWindowText( _T("0.0") );
	
	// Target M'6 
	m_edtTargetM6.SetFont( &m_fntEdit );
	m_edtTargetM6.SetReceivedFlag( 3 );
	m_edtTargetM6.SetWindowText( _T("0.0") );


	m_edtTargetM4_1.SetFont( &m_fntEdit );
	m_edtTargetM4_1.SetReceivedFlag( 3 );
	m_edtTargetM4_1.SetWindowText( _T("0.0") );

	m_edtTargetM4_2.SetFont( &m_fntEdit );
	m_edtTargetM4_2.SetReceivedFlag( 3 );
	m_edtTargetM4_2.SetWindowText( _T("0.0") );

	m_edtTargetRot1.SetFont( &m_fntEdit );
	m_edtTargetRot1.SetReceivedFlag( 3 );
	m_edtTargetRot1.SetWindowText( _T("0.0") );

	m_edtTargetRot2.SetFont( &m_fntEdit );
	m_edtTargetRot2.SetReceivedFlag( 3 );
	m_edtTargetRot2.SetWindowText( _T("0.0") );

	m_edtTargetTophat1.SetFont( &m_fntEdit );
	m_edtTargetTophat1.SetReceivedFlag( 3 );
	m_edtTargetTophat1.SetWindowText( _T("0.0") );

	m_edtTargetTophat2.SetFont( &m_fntEdit );
	m_edtTargetTophat2.SetReceivedFlag( 3 );
	m_edtTargetTophat2.SetWindowText( _T("0.0") );




	//2011519
	// Target A
	m_edtTargetA.SetFont( &m_fntEdit );
	m_edtTargetA.SetReceivedFlag( 3 );
	m_edtTargetA.SetWindowText( _T("0.0") );

	// Target A'2
	m_edtTargetA2.SetFont( &m_fntEdit );
	m_edtTargetA2.SetReceivedFlag( 3 );
	m_edtTargetA2.SetWindowText( _T("0.0") );
	
	// Target A'3  : 
	m_edtTargetA3.SetFont( &m_fntEdit );
	m_edtTargetA3.SetReceivedFlag( 3 );
	m_edtTargetA3.SetWindowText( _T("0.0") );
	
	// Target A'4 
	m_edtTargetA4.SetFont( &m_fntEdit );
	m_edtTargetA4.SetReceivedFlag( 3 );
	m_edtTargetA4.SetWindowText( _T("0.0") );


	m_edtTargetM4_1.ShowWindow(SW_HIDE);
	m_edtTargetM4_2.ShowWindow(SW_HIDE);
#ifdef __PKG_MODIFY__
	m_edtTargetRot1.ShowWindow(SW_SHOW);
	m_edtTargetRot2.ShowWindow(SW_SHOW);
#else
	m_edtTargetRot1.ShowWindow(SW_HIDE);
	m_edtTargetRot2.ShowWindow(SW_HIDE);
#endif

	m_edtTargetTophat1.ShowWindow(SW_HIDE);
	m_edtTargetTophat2.ShowWindow(SW_HIDE);

}

HBRUSH CPaneManualControlMotorLarge::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MOTOR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR_SPEED)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TARGET_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POS1_GROUP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POS2_GROUP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOADER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOADER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_SUCTION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VACUUM_MOTOR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_USE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MPG_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_REJECT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOADING_UNLOADING_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_CLAMP)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HOMING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SAFETY_MODE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DOOR_BYPASS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );

//	if( GetDlgItem(IDC_STATIC_BACKGROUND)->GetSafeHwnd() == pWnd->m_hWnd)
//		pDC->SetBkColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlMotorLarge::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlMotorLarge::EnableAllBtn(BOOL bEnable)
{
	// Target Position
	GetDlgItem(IDC_CHECK_TARGET_X)->EnableWindow( bEnable );
	GetDlgItem(IDC_CHECK_TARGET_Y)->EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 0)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_MASK2)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_MASK3)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_C2)->EnableWindow( bEnable );
		//2011519
		GetDlgItem(IDC_CHECK_TARGET_A)->EnableWindow( bEnable );
		GetDlgItem(IDC_CHECK_TARGET_A2)->EnableWindow( bEnable );
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 1)
		GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bEnable );

	GetDlgItem(IDC_RADIO_ABS)->EnableWindow( bEnable );
	GetDlgItem(IDC_RADIO_INC)->EnableWindow( bEnable );
		
	m_btnMove.EnableWindow( bEnable );

	m_btnMove2.EnableWindow( bEnable );

	m_btnMoveInpos.EnableWindow( bEnable );

	m_btnStop.EnableWindow( bEnable );

	// Loader
	m_btnLoaderAlign.EnableWindow( bEnable );
	m_btnLoaderAlignLoad.EnableWindow( bEnable );
	m_btnLoaderLoad.EnableWindow( bEnable );

	// Unloader
	m_btnUnloaderUnload.EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1)
	{
		GetDlgItem(IDC_RADIO_UNLOAD_M)->EnableWindow( bEnable );
		GetDlgItem(IDC_RADIO_UNLOAD_S)->EnableWindow( bEnable );
		GetDlgItem(IDC_RADIO_UNLOAD_MS)->EnableWindow( bEnable );
	}

	// Table Suction
	m_chkMasterOn.EnableWindow( bEnable );
	m_chkMasterAcrylOn.EnableWindow( bEnable );


	m_chkSlaveOn.EnableWindow( bEnable );
	m_chkSlaveAcrylOn.EnableWindow( bEnable );
	
	// Vacuum Motor
	m_chkVacuumMotorOn.EnableWindow( bEnable );

	// Safety Mode
	m_chkSafetyOn.EnableWindow( bEnable );

	// Door Bypass
//	m_chkDoorBypass.EnableWindow( bEnable );

	// TableClamp
	if(gSystemINI.m_sHardWare.nTableClamp > 0)
		m_chkTableClamp1.EnableWindow( bEnable );
	if(gSystemINI.m_sHardWare.nTableClamp > 1)
		m_chkTableClamp2.EnableWindow( bEnable );

	// Loading / Unloading Position
	m_btnLoadingPos.EnableWindow( bEnable );

	m_btnUnloadingPos.EnableWindow( bEnable );

	// Homing
	m_btnMotorHoming.EnableWindow( bEnable );

	m_btnLoaderHoming.EnableWindow( bEnable );

	m_btnUnloaderHoming.EnableWindow( bEnable );

	// MPG Mode
	m_btnMPG.EnableWindow( bEnable );

	m_chkMasterAcrOn.EnableWindow( bEnable );
	m_chkSlaveAcrOn.EnableWindow( bEnable );

	GetDlgItem(IDC_RADIO_TABLE_A)->EnableWindow( bEnable );
	GetDlgItem(IDC_RADIO_TABLE_B)->EnableWindow( bEnable );
	GetDlgItem(IDC_RADIO_TABLE_C)->EnableWindow( bEnable );

	m_btnReject.EnableWindow( bEnable );
	m_btnLoaderReject.EnableWindow( bEnable );
	m_btnUnloaderReject.EnableWindow( bEnable );
	m_btnAllReject.EnableWindow( bEnable );
	m_chkChangeDirection.EnableWindow( bEnable );
	m_btnLDBasketOut.EnableWindow( bEnable );
	m_btnUDBasketOut.EnableWindow( bEnable );

	m_btnTCCleanPos.EnableWindow( bEnable );

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_TARGET_Z4)->EnableWindow(FALSE);

		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_POS_Z2_VAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SPEED_Z2_VAL)->EnableWindow(FALSE);
	}

	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		m_btnLoaderLoad.EnableWindow(FALSE);
		m_btnUnloaderUnload.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
	}

	
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
}

void CPaneManualControlMotorLarge::OnButtonMove() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);
#ifndef __SERVO_MOTOR__
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2
		&&!m_bTargetA &&!m_bTargetA2)		//2011519
		return;
#else
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2 &&!m_bTargetC3 && !m_bTargetC4)
		return;
#endif
	EnableAllBtn( FALSE );
//	m_btnStop.EnableWindow( TRUE );

	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;

	// X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	// Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// Z1
	m_edtTargetZ1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );

	// Z2
	m_edtTargetZ2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );

	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );

	//M3
	m_edtTargetM5.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );


	// M4 
	m_edtTargetM4_1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM4 = GetMovePos( AXIS_M4, dTemp, bAbs, m_bTargetM4 );

	// Rot 
	m_edtTargetRot1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosRot = GetMovePos( AXIS_ROT, dTemp, bAbs, m_bTargetRot );


	// TopHat 
	m_edtTargetTophat1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosTopHat = GetMovePos( AXIS_TOPHAT, dTemp, bAbs, m_bTargetTopHat );
	// C
	m_edtTargetC.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );
	
	// C2
	m_edtTargetC3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	// C3
	m_edtTargetC5.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC3 = GetMovePos( AXIS_C3, dTemp, bAbs, m_bTargetC3 );

	// C4
	m_edtTargetC7.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC4 = GetMovePos( AXIS_C4, dTemp, bAbs, m_bTargetC4 );

	//2011519
	// A	//m_edtTargetA �߰�����  MoveXYZMC2->MoveXYZMC2A() �Լ� �ʿ�
	m_edtTargetA.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA = GetMovePos( AXIS_A1, dTemp, bAbs, m_bTargetA );
	
	// A2
	m_edtTargetA3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA2 = GetMovePos( AXIS_A2, dTemp, bAbs, m_bTargetA2 );
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	// Move


	//BOOL bRet = pMotor->MotorMoveXYZMCA3_B(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosM4, dPosC, dPosC2, dPosRot, dPosTopHat, TRUE, AUTORUN_MOVE, FALSE,TRUE);
	BOOL bRet = pMotor->MotorMoveXYZMB(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2,dPosC, dPosC2,dPosC3, dPosC4, TRUE, AUTORUN_MOVE, FALSE);
	if(bRet)
		bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 +  IND_C1 + IND_C2 + IND_C3 + IND_C4);
	//bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A1 + IND_A2+ IND_M4 + IND_ROT + IND_TOPHAT);

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}

void CPaneManualControlMotorLarge::OnButtonMove2() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);

#ifndef __SERVO_MOTOR__
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2
		&&!m_bTargetA &&!m_bTargetA2)		//2011519
		return;
#else
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2 &&!m_bTargetC3 && !m_bTargetC4)
		return;
#endif
	
	EnableAllBtn( FALSE );
//	m_btnStop.EnableWindow( TRUE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;
	
	// X'2
	m_edtTargetX2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	
	// Y'2
	m_edtTargetY2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

/*	pMotor->SetOutPort((int)(dPosX + 0.01), (int)(dPosY + 0.01));

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
	return;
*/	
	// Z1'2
	m_edtTargetZ3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );
	
	// Z2'2
	m_edtTargetZ4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );
	
	// M'2
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2'2
	m_edtTargetM4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );

	//M3
	m_edtTargetM6.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M3, dTemp, bAbs, m_bTargetM3 );


	// M4 
	m_edtTargetM4_2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM4 = GetMovePos( AXIS_M4, dTemp, bAbs, m_bTargetM4 );

	// Rot 
	m_edtTargetRot2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosRot = GetMovePos( AXIS_ROT, dTemp, bAbs, m_bTargetRot );


	// TopHat 
	m_edtTargetTophat2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosTopHat = GetMovePos( AXIS_TOPHAT, dTemp, bAbs, m_bTargetTopHat );


	// C'2
	m_edtTargetC2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );
	
	// C2'2
	m_edtTargetC4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	// C3'2
	m_edtTargetC6.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC3 = GetMovePos( AXIS_C3, dTemp, bAbs, m_bTargetC3 );

	// C4'2
	m_edtTargetC8.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC4 = GetMovePos( AXIS_C4, dTemp, bAbs, m_bTargetC4 );

	//2011519	//	MoveXYZMC2A �Լ� �ʿ�
	// A'2
	m_edtTargetA2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA = GetMovePos( AXIS_A1, dTemp, bAbs, m_bTargetA );
	
	// A2'2
	m_edtTargetA4.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA2 = GetMovePos( AXIS_A2, dTemp, bAbs, m_bTargetA2 );

	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	//BOOL bRet = pMotor->MotorMoveXYZMCA3_B(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosM4, dPosC, dPosC2, dPosRot, dPosTopHat, TRUE, AUTORUN_MOVE, FALSE,TRUE);
	BOOL bRet = pMotor->MotorMoveXYZMB(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2,dPosC, dPosC2,dPosC3, dPosC4, TRUE, AUTORUN_MOVE, FALSE);
	if(bRet)
		bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 +  IND_C1 + IND_C2 + IND_C3 + IND_C4);
		//bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A1 + IND_A2+ IND_M4 + IND_ROT + IND_TOPHAT);


	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}

/*
void CPaneManualControlMotorLarge::OnButtonMoveInpos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		::AfxMessageBox(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if( (!m_bTargetX && !m_bTargetY) || (m_bTargetX && m_bTargetY) )
	{
		::AfxMessageBox(IDS_SELECT_XY);
		return;
	}

	EnableAllBtn( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;

	if(!bAbs)
		return;
	
	double dPosX, dPosX2, dPosY, dPosY2;

	// Start,End X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	m_edtTargetX2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX2 = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );
	
	// Start,End Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	m_edtTargetY2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY2 = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// StartPos
	BOOL bRet = pMotor->MoveXY(dPosX, dPosY, TRUE);
	if(bRet)
	{	
		bRet = pMotor->InPositionIO(IND_X + IND_Y);
	}

	// TimeCheck
	// time save 
	CString strPath;
	strPath.Format(_T("%sTemp\\TableTime.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
		
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strPath, "w+");

	int nRepeat = 1;
	if(m_bTargetX)
		nRepeat = (dPosX2 - dPosX) ;
	else
		nRepeat = (dPosY2 - dPosY) ;
	for(int kk = 44; kk < nRepeat; kk++)
	{
		if(bRet)
		{
			m_edtRep.GetWindowText( strData );
			int nRep = atoi( (LPSTR)(LPCTSTR)strData );
			int nCnt = 0;
			double dWaitTime = 0.0, dInposTime = 0, dTempTime;
			CCorrectTime MyTestTime;
			if(m_bTargetX)
			{
				MyTestTime.StartTime();

				do {
					if(nCnt%2)
						bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX, TRUE);
					else
						bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX + (kk + 1) , TRUE);
					CCorrectTime MyInposTime;
					MyInposTime.StartTime();

					if(bRet)
					{	
						bRet = pMotor->InPositionIO(IND_X);
					}
					if(!bRet)
					{
						::AfxMessageBox(_T("Axis-X Error"));
						break;
					}
					dTempTime = MyInposTime.PresentTime();
					dInposTime += dTempTime;
					nCnt++;
				} while(nCnt < nRep);
			}
			else if(m_bTargetY)
			{
				MyTestTime.StartTime();
			
				do {
					if(nCnt%2)
						bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY, TRUE);
					else
						bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY + (kk + 1) , TRUE);

					CCorrectTime MyInposTime;
					MyInposTime.StartTime();
					if(bRet)
					{	
						bRet = pMotor->InPositionIO(IND_Y);
					}
					if(!bRet)
					{
						::AfxMessageBox(_T("Axis-Y Error"));
						break;
					}
					dTempTime = MyInposTime.PresentTime();
					dInposTime += dTempTime;
					nCnt++;
				} while(nCnt < nRep);
			}

			dWaitTime = MyTestTime.PresentTime();
			strData.Format(_T(" Inposition time : %d (%.3f) \n"), (kk + 1) , dWaitTime );
//			::AfxMessageBox(strData);

			
		
			if(err == NULL)
			{
				fprintf(pFile, (LPCTSTR)strData);

				for(int i = 0; i< 10; i++)
				{
			//		strData.Format(_T("Inpos Time %d : %.3f\n"), i, dEachTime[i]);
			//		fprintf(pFile, (LPCTSTR)strData);
			///		strData.Format(_T("Read Mem Time %d : %.3f\n"), i, dReadTime[i]);
			//		fprintf(pFile, (LPCTSTR)strData);
				}
				
			}
		}

	}

	fclose(pFile);

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}
*/
void CPaneManualControlMotorLarge::OnButtonMoveInpos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	UpdateData(TRUE);
	
	if( (!m_bTargetX && !m_bTargetY) || (m_bTargetX && m_bTargetY) )
	{
		ErrMessage(IDS_SELECT_XY);
		return;
	}

	EnableAllBtn( FALSE );
	
	CString strData;
	double dTemp = 0;
	BOOL bAbs = !m_nAbs;

	if(!bAbs)
		return;
	
	double dPosX, dPosX2, dPosY, dPosY2;

	// Start,End X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	m_edtTargetX2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosX2 = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );
	
	// Start,End Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	m_edtTargetY2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	dPosY2 = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// StartPos
	BOOL bRet = pMotor->MoveXY(dPosX, dPosY, TRUE);
	if(bRet)
	{	
		bRet = pMotor->InPositionIO(IND_X + IND_Y);
	}

	// TimeCheck
	if(bRet)
	{
		m_edtRep.GetWindowText( strData );
		int nRep = atoi( (LPSTR)(LPCTSTR)strData );

		m_edtDelay.GetWindowText( strData );
		int nDelay = atoi( (LPSTR)(LPCTSTR)strData );

		

		int nCnt = 0;
		double dWaitTime = 0.0, dInposTime = 0, dTempTime;
		CCorrectTime MyTestTime;
		if(m_bTargetX)
		{
			MyTestTime.StartTime();

			do {
				if(nCnt%2)
					bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX, TRUE);
				else
					bRet = pMotor->MotorMoveAxis(AXIS_X, dPosX2, TRUE);
				CCorrectTime MyInposTime;
				MyInposTime.StartTime();

				if(bRet)
				{	
					bRet = pMotor->InPositionIO(IND_X);
				}
				if(!bRet)
				{
					ErrMessage(_T("Axis-X Error"));
					break;
				}
				dTempTime = MyInposTime.PresentTime();
				dInposTime += dTempTime;
				Sleep(nDelay);
				nCnt++;
			} while(nCnt < nRep);
		}
		else if(m_bTargetY)
		{
			MyTestTime.StartTime();
			
			do {
				if(nCnt%2)
					bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY, TRUE);
				else
					bRet = pMotor->MotorMoveAxis(AXIS_Y, dPosY2, TRUE);

				CCorrectTime MyInposTime;
				MyInposTime.StartTime();
				if(bRet)
				{	
					bRet = pMotor->InPositionIO(IND_Y);
				}
				if(!bRet)
				{
					ErrMessage(_T("Axis-Y Error"));
					break;
				}
				dTempTime = MyInposTime.PresentTime();
				dInposTime += dTempTime;
				Sleep(nDelay);
				nCnt++;
			} while(nCnt < nRep);
		}

		dWaitTime = MyTestTime.PresentTime();
		strData.Format(_T(" Inposition time : %.3f (%.3f) "), dWaitTime, dInposTime );
		ErrMessage(strData);

		// time save 
		CString strPath;
		strPath.Format(_T("%sTemp\\TableTime.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
		
		FILE* pFile;
		errno_t err = fopen_s(&pFile, strPath, "r");
		
		if(err == NULL)
		{
			fprintf(pFile, (LPCTSTR)strData);

			for(int i = 0; i< 10; i++)
			{
		//		strData.Format(_T("Inpos Time %d : %.3f\n"), i, dEachTime[i]);
		//		fprintf(pFile, (LPCTSTR)strData);
		///		strData.Format(_T("Read Mem Time %d : %.3f\n"), i, dReadTime[i]);
		//		fprintf(pFile, (LPCTSTR)strData);
			}
			fclose(pFile);
		}
	}

	EnableAllBtn(TRUE);
	m_btnStop.EnableWindow( FALSE );
}

void CPaneManualControlMotorLarge::OnButtonStop() 
{
	EnableAllBtn(TRUE);
	m_bStop = TRUE;

	m_btnStop.EnableWindow( FALSE );
}

double CPaneManualControlMotorLarge::GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( FALSE == bUse )
		return pMotor->GetPosition( nAxisNo );

	double dPos = 0.;

	if( FALSE == bAbs ) // Relative Movement
	{
		dPos = dMovePos + pMotor->GetPosition( nAxisNo );
	}
	else // ABS Movement
		dPos = dMovePos;

	return dPos;
}

void CPaneManualControlMotorLarge::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dPos = 0;
	CString strData; 

//	m_nVacuumType = pMotor->GetTableVacuumType();

	if(pMotor->IsTable1PCBExist() || pMotor->IsTable2PCBExist())
		m_btnReject.SetSelection(TRUE);
	else
		m_btnReject.SetSelection(FALSE);

	if(pMotor->IsTable1PCBExist() || pMotor->IsTable2PCBExist())
		m_btnAllReject.SetSelection(TRUE);
	else
		m_btnAllReject.SetSelection(FALSE);
	
	// X
	dPos = pMotor->GetPosition( AXIS_X );
	strData.Format(_T("%.4f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );

	// Y
	dPos = pMotor->GetPosition( AXIS_Y );
	strData.Format(_T("%.4f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );

	// Z1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_Z1 );

	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );

	// Z2

		if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
			gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
			dPos = 0.0;
		else
			dPos = pMotor->GetPosition( AXIS_Z2 );
	
		
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );

	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M );
	

		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );
	
	// M2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M2 );
	

		strData.Format(_T("%.1f"), dPos);
	m_stcPosM2.SetWindowText( (LPCTSTR)strData );

	// M3
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M3 );
	

		strData.Format(_T("%.1f"), dPos);
	m_stcPosM3.SetWindowText( (LPCTSTR)strData );


	dPos = pMotor->GetPosition( AXIS_M4 );
	strData.Format(_T("%.1f"), dPos);
	m_stcPosM4.SetWindowText( (LPCTSTR)strData );


	dPos = pMotor->GetPosition( AXIS_ROT );
	strData.Format(_T("%.1f"), dPos);
	m_stcPosRot.SetWindowText( (LPCTSTR)strData );

	dPos = pMotor->GetPosition( AXIS_TOPHAT );
	strData.Format(_T("%.1f"), dPos);
	m_stcPosTopHat.SetWindowText( (LPCTSTR)strData );



	// C

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		{
			dPos = 0.0;
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC.SetWindowText( (LPCTSTR)strData );
			m_stcPosC2.SetWindowText( (LPCTSTR)strData );
			m_stcPosC3.SetWindowText( (LPCTSTR)strData );
			m_stcPosC4.SetWindowText( (LPCTSTR)strData );
		}
		else
		{
			dPos = pMotor->GetPosition( AXIS_C );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC.SetWindowText( (LPCTSTR)strData );

			dPos = pMotor->GetPosition( AXIS_C2 );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC2.SetWindowText( (LPCTSTR)strData );

			dPos = pMotor->GetPosition( AXIS_C3 );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC3.SetWindowText( (LPCTSTR)strData );

			dPos = pMotor->GetPosition( AXIS_C4 );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC4.SetWindowText( (LPCTSTR)strData );
		}
	

	//2011519		// A1,A2 ��� ���Ǹ���?
	// A1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_A1 );
	

		strData.Format(_T("%.1f"), dPos);
	m_stcPosA.SetWindowText( (LPCTSTR)strData );
	
	// A2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_A2 );
	

		strData.Format(_T("%.1f"), dPos);
	m_stcPosA2.SetWindowText( (LPCTSTR)strData );


		// Table Suction
		int nSuction = pMotor->GetCurrentSuction();
		BOOL bMotor = pMotor->GetCurrentSuctionMotor();
		
		m_bMasterSuction = nSuction & 0x01;
		m_bSlaveSuction = nSuction & 0x02;

		if(nSuction & 0x01)
			m_chkMasterOn.SetCheck(TRUE);
		else
			m_chkMasterOn.SetCheck(FALSE);
		
		if(nSuction & 0x02)
			m_chkSlaveOn.SetCheck(TRUE);
		else
			m_chkSlaveOn.SetCheck(FALSE);
		
		m_chkMasterAcrOn.SetCheck(m_bTableMotor);

		m_bAcrylMasterSuction = pMotor->GetCurrentAcrylSuction(TRUE);
		m_chkMasterAcrylOn.SetCheck(m_bAcrylMasterSuction);

		m_bAcrylSlaveSuction = pMotor->GetCurrentAcrylSuction(FALSE);
		m_chkSlaveAcrylOn.SetCheck(m_bAcrylSlaveSuction);

		
		if(bMotor > 0)
			m_chkMasterAcrOn.SetCheck(TRUE);
		else
			m_chkMasterAcrOn.SetCheck(FALSE);


		m_bSafetyMode = pMotor->IsSafetyMode();
		m_chkSafetyOn.SetCheck(m_bSafetyMode);

		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			m_bTableClamp1 = pMotor->GetCurrentTableClamp(TRUE, TRUE);
			m_chkTableClamp1.SetCheck(m_bTableClamp1);
		}

		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			m_bTableClamp2 =pMotor->GetCurrentTableClamp(FALSE, TRUE);
			m_chkTableClamp2.SetCheck(m_bTableClamp2);
		}

	BOOL bChange = pMotor->GetReverseDirection();
	m_chkChangeDirection.SetCheck(bChange);

	switch(m_nMPGMode )
	{
		case 0:
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
			break;
		case 1:
			m_btnMPG.SetWindowText("MPG Mode 2");
#ifdef __NANYA__
	m_btnMPG.SetToolTipText(" B1, B2, M2,M3");
#else
			m_btnMPG.SetToolTipText(" B1, B2, M1, M2");
#endif
			break;
					
		case 2:
			m_btnMPG.SetWindowText("MPG Mode 3");

			m_btnMPG.SetToolTipText(" M1, Top");

			break;
		case 3:
			break;
					
		case 4:
			break;
	}
}

void CPaneManualControlMotorLarge::DispVelocity()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dSpeed = 0;
	CString strData = _T("");

	// X
	dSpeed = pMotor->GetMoveSpeed( AXIS_X );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedX.SetWindowText( (LPCTSTR)strData );

	// Y
	dSpeed = pMotor->GetMoveSpeed( AXIS_Y );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedY.SetWindowText( (LPCTSTR)strData );

	// Z1
	dSpeed = pMotor->GetMoveSpeed( AXIS_Z1 );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedZ1.SetWindowText( (LPCTSTR)strData );

	// Z2
	dSpeed = pMotor->GetMoveSpeed( AXIS_Z2 );

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedZ2.SetWindowText( (LPCTSTR)strData );

	// M
	dSpeed = pMotor->GetMoveSpeed( AXIS_M );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM.SetWindowText( (LPCTSTR)strData );

	//M2
	dSpeed = pMotor->GetMoveSpeed( AXIS_M2 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM2.SetWindowText( (LPCTSTR)strData );

	//M3
	dSpeed = pMotor->GetMoveSpeed( AXIS_M3 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM3.SetWindowText( (LPCTSTR)strData );




	dSpeed = pMotor->GetMoveSpeed( AXIS_M3 );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM3.SetWindowText( (LPCTSTR)strData );

	dSpeed = pMotor->GetMoveSpeed( AXIS_M4 );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedM4.SetWindowText( (LPCTSTR)strData );

	dSpeed = pMotor->GetMoveSpeed( AXIS_ROT );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedRot.SetWindowText( (LPCTSTR)strData );

	dSpeed = pMotor->GetMoveSpeed( AXIS_TOPHAT );
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedTopHat.SetWindowText( (LPCTSTR)strData );
	// C
	dSpeed = pMotor->GetMoveSpeed( AXIS_C );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedC.SetWindowText( (LPCTSTR)strData );

	//C2
	dSpeed = pMotor->GetMoveSpeed( AXIS_C2 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedC2.SetWindowText( (LPCTSTR)strData );

	//C3
	dSpeed = pMotor->GetMoveSpeed( AXIS_C3 );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedC3.SetWindowText( (LPCTSTR)strData );

	//C4
	dSpeed = pMotor->GetMoveSpeed( AXIS_C4 );

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;

	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedC4.SetWindowText( (LPCTSTR)strData );


	//2011519
	// A1
	dSpeed = pMotor->GetMoveSpeed( AXIS_A1 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedA.SetWindowText( (LPCTSTR)strData );
	
	//A2
	dSpeed = pMotor->GetMoveSpeed( AXIS_A2 );
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dSpeed = 0.0;
	
	strData.Format(_T("%.2f"), dSpeed);
	m_stcSpeedA2.SetWindowText( (LPCTSTR)strData );

}

void CPaneManualControlMotorLarge::OnTimer(UINT nIDEvent) 
{
	DispStatus();

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlMotorLarge::OnButtonLoaderAlign() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(!pMotor->IsStartMode())
	{
		ErrMsgDlg(STDGNALM1152);
		return;
	}

	// 110610 Start
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
	{
		ErrMessage(_T("Align is in progress.\r\nAlign Command Reject."));
		return;
	}
	

	if(pMotor->IsLoadCartNoPCB())
	{
		ErrMessage(_T("There is no PCB in Loader.\r\nAlign Command Reject."));
		return;
	}

	//UpdateData(TRUE);

	int nCmd = m_nMasterSlave;
//	if(m_nMasterSlave < 2)
//		nCmd = m_nMasterSlave + 1;
//	else
//		nCmd = 0;


	pMotor->SetOutPort(PORT_PCB_SINGLE, m_nMasterSlave);


	EnableAllBtn( FALSE );

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);

	::Sleep(1000);

//	pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, TRUE);

	if(!WaitHandler(HANDLER_ALIGNERSTOP))
	{
		if(pMotor->IsLoadCartNoPCB())
			ErrMsgDlg(STDGNALM715);
		else
			ErrMsgDlg(STDGNALM721);
		pMotor->SetOutPort(PORT_ALARM, 1);
		Sleep(100);
		pMotor->SetOutPort(PORT_ALARM, 0);
	}

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);

	EnableAllBtn( TRUE );
}

void CPaneManualControlMotorLarge::OnButtonLoaderAlignLoad() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	// 110610 Start
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
	{
		ErrMessage(_T("Align is in progress.\r\nAlign Command Reject."));
		return;
	}
	// 110610 End

	if(pMotor->IsLoadCartNoPCB())
	{
		ErrMessage(_T("There is no PCB in Loader.\r\nAlign Command Reject."));
		return;
	}
	
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nLoad Command Reject."));
		return;
	}
	
	UpdateData(TRUE);
	
	int nCmd;
	if(m_nMasterSlave < 2)
		nCmd = m_nMasterSlave + 1;
	else
		nCmd = 0;
	

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

	
	EnableAllBtn( FALSE );
	
	//pMotor->HandlerOperation(HANDLER_LOADER_ALIGN_LOAD);

	::Sleep(500);
	
//	pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, TRUE);
	
	if(!WaitHandler(HANDLER_LOADSTOP))
	{
		ErrMsgDlg(STDGNALM719);
	}
	
	EnableAllBtn( TRUE );
}

void CPaneManualControlMotorLarge::OnButtonLoaderLoad() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(!pMotor->IsStartMode())
	{
		ErrMsgDlg(STDGNALM1152);
		return;
	}

	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}

	m_bStop = FALSE;
	m_btnStop.EnableWindow( TRUE );
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110610 Start
	if(!pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, TRUE, FALSE ))
	{
		ErrMessage(_T("Not Align Complete.\r\nLoad Command Reject."));
		return;
	}

	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nLoad Command Reject."));
		return;
	}

//	UpdateData(TRUE);

	int nCmd = m_nMasterSlave;
	//if(m_nMasterSlave < 2)
	//	nCmd = m_nMasterSlave + 1;
	//else
	//	nCmd = 0;	

	BOOL bRes = FALSE;
	BOOL bTable1 = pMotor->IsTable1PCBExist();
	BOOL bTable2 = pMotor->IsTable2PCBExist();

	BOOL b1st, b2nd;
	int nSuction;
	nSuction = pMotor->GetCurrentSuction();
	
	if(nSuction & 0x01)
		b1st = TRUE;
	else
		b1st = FALSE;
	if(nSuction & 0x02)
		b2nd = TRUE;
	else
		b2nd = FALSE;
	
	switch(m_nMasterSlave)
	{
	case 0:
		if(!bTable1 && !b1st)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 1:
		if(!bTable2 && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 2:
		if(!bTable1 && !bTable2 && !b1st && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	}

	if(!bRes)
	{
		ErrMessage(_T("There is PCB On Table.\r\nLoading Command Reject."));
		return;
	}
	// 110610 End
	

	pMotor->SetOutPort(PORT_PCB_SINGLE, m_nMasterSlave);


	EnableAllBtn( FALSE );
	if(!pMotor->SetLoadPickerDownOK(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM719);
		EnableAllBtn(TRUE);
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		return;
	}
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, TRUE);
	if(!pMotor->GetReverseDirection())
	{
		pMotor->MoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX,gProcessINI.m_sProcessAutoSetting.dLoadPosY );
	}
	else
	{
		pMotor->MoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX2, gProcessINI.m_sProcessAutoSetting.dLoadPosY2 );
	}

	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		return;
	}
	BOOL bPicker1, bPicker2;
	if(nCmd == 0 )
	{
		bPicker1 = TRUE;
		bPicker2 = TRUE;
	}
	else if( nCmd == 1)
	{
		bPicker1 = TRUE;
		bPicker2 = FALSE;
	}
	else
	{
		bPicker1 = FALSE;
		bPicker2 = TRUE;
	}
	if(!pMotor->SetLoadPickerDownOK(bPicker1, bPicker2))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM719);
		EnableAllBtn(TRUE);
		return;
	}
	::Sleep(500);
	if(!WaitHandler(HANDLER_LOAD_PICKER_DOWN, bPicker1,bPicker2 ))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM719);
		EnableAllBtn(TRUE);
		return;
	}
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, bPicker1);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, bPicker2);
	}
	if(!pMotor->SetTablePCBExist(bPicker1, bPicker2))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM993);
		EnableAllBtn(TRUE);
		return ;
	}
//	pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, TRUE, TRUE );

	if(!WaitHandler(HANDLER_LOADSTOP))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM719);
		pMotor->SetOutPort(PORT_ALARM, 1);
		Sleep(100);
		pMotor->SetOutPort(PORT_ALARM, 0);
	}
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	EnableAllBtn( TRUE );
	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}
//BOOL SetOutportTableVacuum(BOOL b1st, BOOL b2nd, BYTE nVacuum1, BYTE nVacuum2, WORD wOnOff)


void CPaneManualControlMotorLarge::SetTableSuction(BOOL bTable, BOOL bAcryl)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(!bAcryl)
	{
		if(bTable)
		{
			if( FALSE == m_bMasterSuction)
			{
				pMotor->SetOutPort( PORT_TABLE_SUCTION1, 0);
			}
			else if( TRUE == m_bMasterSuction)
			{
				pMotor->SetOutPort( PORT_TABLE_SUCTION1, 1 );	
			}
		}
		else
		{
			if(FALSE == m_bSlaveSuction )
			{
				pMotor->SetOutPort( PORT_TABLE_SUCTION2, 0 );
			}
			else if(TRUE == m_bSlaveSuction)// TRUE, TRUE
			{
				pMotor->SetOutPort( PORT_TABLE_SUCTION2, 1);
			}
		}
	}
	else
	{
		if(bTable)
		{
			if( FALSE == m_bAcrylMasterSuction)
			{
				pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 0);
			}
			else if( TRUE == m_bAcrylMasterSuction)
			{
				pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION, 1 );	
			}
		}
		else
		{
			if(FALSE == m_bAcrylSlaveSuction )
			{
				pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 0 );
			}
			else if(TRUE == m_bAcrylSlaveSuction)// TRUE, TRUE
			{
				pMotor->SetOutPort( PORT_ACRYL_TABLE_SUCTION2, 1);
			}
		}
	}
}

void CPaneManualControlMotorLarge::OnCheckMasterOn() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}

	if(m_bMasterSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, FALSE);
	}
	else
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, TRUE);
	}
	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneManualControlMotorLarge::OnCheckSlaveOn() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}

	if(m_bSlaveSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);
	}
	else
	{	
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, TRUE);
	}
	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneManualControlMotorLarge::OnCheckAcrylMasterOn() 
{
//	m_bAcrylMasterSuction = !m_bAcrylMasterSuction;
	
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, !m_bAcrylMasterSuction);
}

void CPaneManualControlMotorLarge::OnCheckAcrylSlaveOn() 
{
//	m_bAcrylSlaveSuction = !m_bAcrylSlaveSuction;
	
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, !m_bAcrylSlaveSuction);
}


//2011524
void CPaneManualControlMotorLarge::OnRadioTable1A()
{
	m_nRadioVacuumTable = 0;
	//gDeviceFactory.GetMotor()->SetOutportTableVacuum(FALSE);

	gDeviceFactory.GetMotor()->SetOutPort(PORT_TABLE_B_USE,TRUE);
	UpdateData(FALSE);
}
void CPaneManualControlMotorLarge::OnRadioTable1B()
{
	m_nRadioVacuumTable = 1;
	//gDeviceFactory.GetMotor()->SetOutportTableVacuum(TRUE);

	gDeviceFactory.GetMotor()->SetOutPort(PORT_TABLE_B_USE,FALSE);
	UpdateData(FALSE);
}

void CPaneManualControlMotorLarge::OnRadioTable1C()
{
	m_nRadioVacuumTable = 2;
//	gDeviceFactory.GetMotor()->SetOutportTableVacuum(m_nRadioVacuumTable, TRUE);
	UpdateData(FALSE);
}
void CPaneManualControlMotorLarge::OnRadioTable1D()
{
//	m_nRadioVacuumTable = 3;
//	gDeviceFactory.GetMotor()->SetOutportTableVacuum(m_nRadioVacuumTable, TRUE);
}

void CPaneManualControlMotorLarge::ClearMsterTableVacumm()
{
	m_nRadioVacuumTable = 0;
	
	CheckRadioButton(IDC_RADIO_TABLE_A,IDC_RADIO_TABLE_D,IDC_RADIO_TABLE_A);
}

void CPaneManualControlMotorLarge::OnCheckVacuumMotorOn()
{
//	m_bVacuumMotor = !m_bVacuumMotor;
	
//	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
//	pMotor->Table1VacuumMotor(m_bVacuumMotor);
}

void CPaneManualControlMotorLarge::OnCheckSafetyOn()
{
	m_bSafetyMode = !m_bSafetyMode;

	// NORMAL_MODE, SAFETY_MODE, IDLE_MODE
	int nMode;
	if(m_bSafetyMode)
	{
		nMode = 4;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, SAFETY_MODE);
	}
	else
	{
		nMode = 1;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->SetOutPort(PORT_MODE_SELECT, nMode);
}

void CPaneManualControlMotorLarge::OnCheckTableClamp1()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}
	
	m_bTableClamp1 = !m_bTableClamp1;

	pMotor->TableClamp(m_bTableClamp1, TRUE);
}

void CPaneManualControlMotorLarge::OnCheckTableClamp2()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}
	
	m_bTableClamp2 = !m_bTableClamp2;

	pMotor->TableClamp(m_bTableClamp2, FALSE);
}

void CPaneManualControlMotorLarge::OnCheckDoorBypass()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}
	
	m_bDoorBypass = !m_bDoorBypass;

	pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, m_bDoorBypass);
}

void CPaneManualControlMotorLarge::OnButtonPosLoading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();

	if(!bReverse)
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX2, gProcessINI.m_sProcessAutoSetting.dLoadPosY2, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
		}
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{

		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}

void CPaneManualControlMotorLarge::OnButtonPosUnloading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();

	if(!bReverse)
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX2, gProcessINI.m_sProcessAutoSetting.dUnloadPosY2, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
		}
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{

		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}

void CPaneManualControlMotorLarge::OnButtonUnloaderUnload() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}

	if(!pMotor->IsStartMode())
	{
		ErrMsgDlg(STDGNALM1152);
		return;
	}

	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}


	m_bStop = FALSE;
	m_btnStop.EnableWindow( TRUE );
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110610 Start
/*	if(!pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, TRUE, FALSE ))
	{
		ErrMessage(_T("Load �Ϸ� ���°� �ƴմϴ�.\r\nUnload Command Reject."));
		return;
	}
*/	
	pMotor->SetNGPanel(0);

	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}

	if(pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Unloading is in progress.\r\nUnload Command Reject."));
		return;
	}
	
//	UpdateData(TRUE);

	int nCmd = m_nMasterSlave;
//	if(m_nMasterSlave < 2)
//		nCmd = m_nMasterSlave + 1;
//	else
//		nCmd = 0;


	pMotor->SetOutPort(PORT_PCB_SINGLE, m_nMasterSlave);


	EnableAllBtn( FALSE );
	if(!pMotor->SetUnloadPickerDownOK(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM719);
		EnableAllBtn(TRUE);
		return;
	}
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE);
	if(!pMotor->GetReverseDirection())
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			return;
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX2, gProcessINI.m_sProcessAutoSetting.dUnloadPosY2, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableAllBtn(TRUE);
			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			return;
		}
	}


	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}

	BOOL bPicker1, bPicker2;
	if(nCmd == 0 )
	{
		bPicker1 = TRUE;
		bPicker2 = TRUE;
	}
	else if( nCmd == 1)
	{
		bPicker1 = TRUE;
		bPicker2 = FALSE;
	}
	else
	{
		bPicker1 = FALSE;
		bPicker2 = TRUE;
	}
	if(!pMotor->SetUnloadPickerDownOK(bPicker1, bPicker2))
	{
		ErrMsgDlg(STDGNALM726);
		EnableAllBtn(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}
	::Sleep(500);
	if(!WaitHandler(HANDLER_UNLOAD_PICKER_DOWN, bPicker1, bPicker2))
	{
		ErrMsgDlg(STDGNALM726);
		EnableAllBtn(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);
	}
	if(!pMotor->SetTablePCBExist(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM993);
		pMotor->SetOutPort(PORT_ALARM, 1);
		Sleep(100);
		pMotor->SetOutPort(PORT_ALARM, 0);
	}
//	pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, TRUE, TRUE );

	if(!WaitHandler(HANDLER_UNLOADSTOP))
	{
		ErrMsgDlg(STDGNALM726);
		pMotor->SetOutPort(PORT_ALARM, 1);
		Sleep(100);
		pMotor->SetOutPort(PORT_ALARM, 0);
	}
	
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
	EnableAllBtn( TRUE );

	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneManualControlMotorLarge::OnButtonMotorHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	pMotor->SetOrigin();
	
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	BOOL bInOrigin = FALSE;
	BOOL bInPosition = FALSE;

	for( int i = 0 ; i < 600 ; i++ )
	{

		bInOrigin = pMotor->IsInOrigin( -1, FALSE );
//		bInPosition = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);

		if( bInOrigin ) // && bInPosition )
			break;

		if( 599 == i )
		{
			pMotor->IsInOrigin(-1);
//			pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1);
		}
	}
}


void CPaneManualControlMotorLarge::OnButtonLoaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	pMotor->HandlerOperation(HANDLER_LOADER_HOMING);
}

void CPaneManualControlMotorLarge::OnButtonUnloaderHoming() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	pMotor->HandlerOperation(HANDLER_UNLOADER_HOMING);
}

void CPaneManualControlMotorLarge::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nMPGMode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pSysSetup->m_pLaserScanner->GetMPGMode();
	/*	int nMode = 0;//gDeviceFactory.GetMotor()->GetMPGMode();
		m_nMPGMode = nMode;
		switch(nMode)
		{
		case 0:
			m_btnMPG.SetWindowText("MPG Mode 1");
			m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
			break;
		case 1:
			m_btnMPG.SetWindowText("MPG Mode 2");
			m_btnMPG.SetToolTipText("M1, M2, B1, B2");
			break;
		case 2:
			m_btnMPG.SetWindowText("MPG Mode 3");
			m_btnMPG.SetToolTipText("LC, UC");
			break;
		}
*/
//		m_nRadioVacuumTable = gDeviceFactory.GetMotor()->GetTableVacuumType(); // ó�� �ѹ� �� ����
		UpdateData(FALSE);
		m_nTimerID = SetTimer( 38, 300, NULL );
	
	}
}

void CPaneManualControlMotorLarge::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneManualControlMotorLarge::OnButtonReject()
{
	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(3000);
	BOOL b1st, b2nd;
	int nVal = gDeviceFactory.GetMotor()->GetCurrentSuction();
	b1st = nVal & 0x01;
	b2nd = nVal & 0x02;
	if(!gDeviceFactory.GetMotor()->SetTablePCBExist(b1st, b2nd))
	{
		ErrMsgDlg(STDGNALM993);
		return ;
	}
}

void CPaneManualControlMotorLarge::OnButtonMPG()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(m_nMPGMode == 0)
	{
		m_nMPGMode = 1;
		m_btnMPG.SetWindowText("MPG Mode 2");
		m_btnMPG.SetToolTipText("B1, B2, M2, M3");

	}
#ifdef __NANYA__
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 2;
		m_btnMPG.SetWindowText("MPG Mode 3");

		m_btnMPG.SetToolTipText("M1 ,Top");

	}
#else
	else if(m_nMPGMode == 1)
	{
		m_nMPGMode = 2;
		m_btnMPG.SetWindowText("MPG Mode 3");
		m_btnMPG.SetToolTipText("M1,Top");

	}
	else if(m_nMPGMode == 2)
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");

	}
	else if(m_nMPGMode == 3)
	{

	}
#endif
	else
	{
		m_nMPGMode = 0;
		m_btnMPG.SetWindowText("MPG Mode 1");
		m_btnMPG.SetToolTipText("X, Y, Z1, Z2");
	}
	
	pMotor->SetOutPort(PORT_MPG_MODE, m_nMPGMode);
}

void CPaneManualControlMotorLarge::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
		m_chkSafetyOn.EnableWindow(FALSE);
//		m_chkDoorBypass.EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_REPEAT)->ShowWindow(SW_HIDE);
		m_edtRep.ShowWindow(SW_HIDE);
		m_btnMoveInpos.ShowWindow(SW_HIDE);
#ifdef __NANYA_NEW__
		GetDlgItem(IDC_BUTTON_MOVE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_MOVE2)->EnableWindow(FALSE);
#endif
		break;
	case 1:
	case 2:
	case 3:
		m_chkSafetyOn.EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_REPEAT)->ShowWindow(SW_SHOW);
		m_edtRep.ShowWindow(SW_SHOW);
		m_btnMoveInpos.ShowWindow(SW_SHOW);
//		m_chkDoorBypass.EnableWindow(TRUE);
#ifdef __NANYA_NEW__
		GetDlgItem(IDC_BUTTON_MOVE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_MOVE2)->EnableWindow(TRUE);
#endif

		break;
	}
}
BOOL CPaneManualControlMotorLarge::WaitHandler(int nCmd, BOOL b1st, BOOL b2nd)
{
#ifdef __TEST__
	return TRUE;
#endif

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nGetTargetVal = 0;
	if(b1st) nGetTargetVal += 0x01;
	if(b2nd) nGetTargetVal += 0x02;
	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	int nWaitTime;
	if(nCmd == HANDLER_ALIGNERSTOP)
		nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000 / 200; 
	else if(nCmd == HANDLER_LOADSTOP || nCmd == HANDLER_LOAD_PICKER_DOWN)
		nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 200; 
	else
		nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000 / 200; 
	int nCnt = 0;
	LONG lError = 0;
	BOOL bNoCartPCB;
	do {
		::Sleep(200);
		MessageLoop();
		
		enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
			HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM,
			HANDLER_ALIGNERSTOP, HANDLER_LOADSTOP, HANDLER_UNLOADSTOP, HANDLER_UNLOAD_TO_LOADSTART};		

		switch(nCmd)
		{
		case HANDLER_ALIGNERSTOP:
		

			bNoCartPCB = pMotor->IsLoadCartNoPCB();
			
			if(bNoCartPCB == TRUE)
				return FALSE;

			if(pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE) &&
			!pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
				return TRUE;

			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
			

			break;
		case HANDLER_LOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
				return TRUE;

			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}

		
			if(GetTableSuctionErr())
				return FALSE;
			break;
		case HANDLER_UNLOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
				return TRUE;

			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}

			
			if(GetTableSuctionErr())
				return FALSE;
			break;
		case HANDLER_UNLOAD_TO_LOADSTART:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE))
				return TRUE;

			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}

			break;
		case HANDLER_LOAD_PICKER_DOWN:
			if(nGetTargetVal == pMotor->IsHandlerOperation(HANDLER_LOAD_PICKER_DOWN, TRUE))
				return TRUE;


			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}

			break;
		case HANDLER_UNLOAD_PICKER_DOWN:
			if(nGetTargetVal == pMotor->IsHandlerOperation(HANDLER_UNLOAD_PICKER_DOWN, TRUE))
				return TRUE;

			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}

			break;
		}
		nCnt++;

		if( pMotor ->IsAnyError() )
		{
			return FALSE;
		}
		
		if(nCnt > nWaitTime)
		{
			return FALSE;
		}
	} while(TRUE);
	return FALSE;
}

void CPaneManualControlMotorLarge::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}
void CPaneManualControlMotorLarge::OnButtonUnloaderReject()
{
	gDeviceFactory.GetMotor()->UnLoaderPCBReset();
	::Sleep(1000);
}
void CPaneManualControlMotorLarge::OnButtonLoaderReject()
{
	gDeviceFactory.GetMotor()->LoaderPCBReset();
	::Sleep(1000);
}

void CPaneManualControlMotorLarge::OnButtonAllReject()
{
	// 110610

		gDeviceFactory.GetMotor()->Table1VacuumMotor(TRUE);

	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(100);


	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);

	gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
//	gDeviceFactory.GetMotor()->LoaderPCBReset();
//	::Sleep(100);
//	gDeviceFactory.GetMotor()->UnloaderPCBReset();
//	::Sleep(3000);
}

void CPaneManualControlMotorLarge::OnCheckMasterAcrylicOn() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	if(bMotor)
	{
		pMotor->Table1VacuumMotor(FALSE);
	}
	else
	{
		pMotor->Table1VacuumMotor(TRUE);
	}

	::Sleep(300);
	m_bTableMotor = pMotor->GetCurrentSuctionMotor();
	
/*	BOOL bCheck = m_chkMasterAcrOn.GetCheck();
	if(!bCheck)
	{
		BOOL bSuction1;
		bSuction1 = pMotor->GetCurrentSuction();
		
		if(bSuction1)
		{
			ErrMessage(_T("Table Vacuum�� �����ֽ��ϴ�."));
			return;
		}
	}
	pMotor->Table1VacuumMotor(bCheck);
	m_bTableMotor = bCheck;
*/
}

void CPaneManualControlMotorLarge::OnCheckSlaveAcrylicOn() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	BOOL bCheck = m_chkSlaveAcrOn.GetCheck();
	if(bCheck)
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
	else
		pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
}

void CPaneManualControlMotorLarge::OnRadioUnloadM() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	UpdateData(TRUE);
	
	m_nMasterSlave = 1;
	int nCmd = m_nMasterSlave;
	//if(m_nMasterSlave < 2)
	//	nCmd = m_nMasterSlave + 1;
	//else
	//	nCmd = 0;
	

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

}

void CPaneManualControlMotorLarge::OnRadioUnloadS() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	UpdateData(TRUE);
	m_nMasterSlave = 2;

	int nCmd = m_nMasterSlave;
	//if(m_nMasterSlave < 2)
	//	nCmd = m_nMasterSlave + 1;
	//else
	//	nCmd = 0;
	

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

}

void CPaneManualControlMotorLarge::OnRadioUnloadMs() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	UpdateData(TRUE);
	
	m_nMasterSlave = 0;
	int nCmd = m_nMasterSlave;
//	if(m_nMasterSlave < 2)
//		nCmd = m_nMasterSlave + 1;
//	else
//		nCmd = 0;
	

	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);

}

int CPaneManualControlMotorLarge::GetMPGMode()
{
	return m_nMPGMode;
}

void CPaneManualControlMotorLarge::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}

BOOL CPaneManualControlMotorLarge::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Motor) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneManualControlMotorLarge::OnCheckChangeDirection()
{
	if(gDeviceFactory.GetMotor()->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}

	if(gDeviceFactory.GetMotor()->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Unloading is in progress.\r\nUnload Command Reject."));
		return;
	}
	
	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();

	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(1000);

	if(bReverse)
	{
		gDeviceFactory.GetMotor()->SetReverseDirection(FALSE);
	}
	else
	{
		gDeviceFactory.GetMotor()->SetReverseDirection(TRUE);
	}
	
}
void CPaneManualControlMotorLarge::OnButtonLDBasketOut()
{
	gDeviceFactory.GetMotor()->SetOutputBasket(TRUE);
}

void CPaneManualControlMotorLarge::OnButtonUDBasketOut()
{
	gDeviceFactory.GetMotor()->SetOutputBasket(FALSE);
}

BYTE CPaneManualControlMotorLarge::GetTableSuctionErr()
{
	long lErrorOthers1New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS);

	BYTE cVal = 0x00;
	if(lErrorOthers1New & 0x0010 || lErrorOthers1New & 0x0020)
		cVal += 0x01;
	if(lErrorOthers1New & 0x0040 || lErrorOthers1New & 0x0080)
		cVal += 0x02;
	return cVal;
}

void CPaneManualControlMotorLarge::OnBnClickedButtonPosTcClean()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please error reset")); // 110603
		return;
	}

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);


	if(!pMotor->MotorMoveXYZ(gProcessINI.m_sProcessAutoSetting.dTCCleanPosX, gProcessINI.m_sProcessAutoSetting.dTCCleanPosY, 
		gProcessINI.m_sProcessAutoSetting.dTCCleanPosZ1, gProcessINI.m_sProcessAutoSetting.dTCCleanPosZ2, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}


	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}
