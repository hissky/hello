#pragma once



// CPaneAutoRunViewStatus �� ���Դϴ�.

class CPaneAutoRunViewStatus : public CFormView
{
	DECLARE_DYNCREATE(CPaneAutoRunViewStatus)

protected:
	CPaneAutoRunViewStatus();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CPaneAutoRunViewStatus();

public:
	enum { IDD = IDD_DLG_AUTORUN_VIEW_STATUS };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
	int m_nCount;
	double m_dMainAir;
	double m_dChillerTemp1;
	double m_dChillerTemp2;
	double m_dHumidity;
	double m_dTemperatur;
	double m_dCurrent;
	double m_dVoltage;
	double m_dPower;
	double m_dTableVacuum1;
	double m_dTableVacuum2;
	double m_dDustSuction;
	double m_dWaterFlowLaser;
	double m_dWaterFlowAom;
	double m_dWaterFlowScanner1;
	double m_dWaterFlowScanner2;
	double m_dWaterFlowLaser1;
	double m_dWaterFlowLaser2;
	double m_dLDMainAir;
	double m_dLDPick1Vacuum;
	double m_dLDPick2Vacuum;
	double m_dUNMainAir;
	double m_dUNPick1Vacuum;
	double m_dUNPick2Vacuum;

	BOOL	m_bWaterFlowError;
	BOOL	m_bWaterFlowErrorOld;
	BOOL	m_bDustValueErr;
	BOOL	m_bDustValueErrOld;
	int		m_nErrorCount;
	int		m_nDustErrorCount;
	CPaneAutoRun* pRun;
public:
	CFont m_fntStatic;
	int m_nTimer;
	void InitStaticControl();
	void ChangeDisplay();
	double m_dOldVals[10];
	void SaveStatus();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual void OnInitialUpdate();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
};


