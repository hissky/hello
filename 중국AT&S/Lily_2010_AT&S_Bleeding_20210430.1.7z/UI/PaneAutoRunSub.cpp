// PaneAutoRunSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunSub.h"
#include "DlgAlarm.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\model\dprocessini.h"

#include "PaneRecipeGen.h"
#include "PaneRecipeGenFiducialNew.h"

#include "DlgShotTable.h"
#include "DlgBeamPathTable.h"

#include "..\MODEL\GlobalVariable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunSub

IMPLEMENT_DYNCREATE(CPaneAutoRunSub, CFormView)

CPaneAutoRunSub::CPaneAutoRunSub()
	: CFormView(CPaneAutoRunSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo		= 0;
	m_nUserLevel = 0;
}

CPaneAutoRunSub::~CPaneAutoRunSub()
{
}

void CPaneAutoRunSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunSub)
	DDX_Control(pDX, IDC_BUTTON_DUST_SUCTION, m_btnDustSuction);
	DDX_Control(pDX, IDC_BUTTON_FIDUCIAL_SETTING, m_btnFiducialSetting);
	DDX_Control(pDX, IDC_BUTTON_RECIPE_GEN, m_btnRecipeGen);
	DDX_Control(pDX, IDC_BUTTON_MOVE_SCALE_LOG, m_btnMoveScaleLog);
	DDX_Control(pDX, IDC_BUTTON_DRILL_DISPLAY, m_btnDrillDisplay);
	DDX_Control(pDX, IDC_BUTTON_DRILL_ONECYCLE_STOP, m_btnDrillOneCycleStop);
	DDX_Control(pDX, IDC_BUTTON_DRILL_PAUSE, m_btnDrillPause);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	DDX_Control(pDX, IDC_BUTTON_IDEL, m_btnIdle);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunSub, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_BN_CLICKED(IDC_BUTTON_RECIPE_GEN, OnButtonRecipeGen)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_SCALE_LOG, OnButtonMoveScaleLog)
	ON_BN_CLICKED(IDC_BUTTON_DRILL_DISPLAY, OnButtonDrillDisplay)
	ON_BN_CLICKED(IDC_BUTTON_FIDUCIAL_SETTING, OnButtonFiducialSetting)
	ON_BN_CLICKED(IDC_BUTTON_DUST_SUCTION, OnButtonDustSuction)
	ON_BN_CLICKED(IDC_BUTTON_DRILL_ONECYCLE_STOP, OnButtonDrillOnecycleStop)
	ON_BN_CLICKED(IDC_BUTTON_DRILL_PAUSE, OnButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_IDEL, OnButtonIdle)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN_BEAMPATH_TABLE, &CPaneAutoRunSub::OnBnClickedButtonOpenBeampathTable)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_SHOT_TABLE, &CPaneAutoRunSub::OnBnClickedButtonOpenShotTable)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunSub diagnostics

#ifdef _DEBUG
void CPaneAutoRunSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunSub message handlers

void CPaneAutoRunSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();

}

void CPaneAutoRunSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(130, "Arial Bold");

	// Drill Start
	m_btnStart.SetFont( &m_fntBtn2 );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.SetImageOrg( 10, 3 );
	m_btnStart.SetIcon( IDI_MANUALDRILLSTART );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Drill Start") );
	m_btnStart.SetBtnCursor( IDC_HAND_1 );

	// Drill Pause
	m_btnDrillPause.SetFont( &m_fntBtn2 );
	m_btnDrillPause.SetFlat( FALSE );
	m_btnDrillPause.SetImageOrg( 10, 3 );
	m_btnDrillPause.SetIcon( IDI_MANUALDRILLSTOP );
	m_btnDrillPause.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDrillPause.EnableBallonToolTip();
	m_btnDrillPause.SetToolTipText( _T("Drill Pause") );
	m_btnDrillPause.SetBtnCursor( IDC_HAND_1 );

	// Drill One Cycle Stop
	m_btnDrillOneCycleStop.SetFont( &m_fntBtn2 );
	m_btnDrillOneCycleStop.SetFlat( FALSE );
	m_btnDrillOneCycleStop.SetImageOrg( 10, 3 );
	m_btnDrillOneCycleStop.SetIcon( IDI_ONECYCLESTOP );
	m_btnDrillOneCycleStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDrillOneCycleStop.EnableBallonToolTip();
	m_btnDrillOneCycleStop.SetToolTipText( _T("Drill One Cycle Stop") );
	m_btnDrillOneCycleStop.SetBtnCursor( IDC_HAND_1 );

	// Drill Stop
	m_btnStop.SetFont( &m_fntBtn2 );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.SetImageOrg( 10, 3 );
	m_btnStop.SetIcon( IDI_STOP, 32, 32 );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Drill Stop") );
	m_btnStop.SetBtnCursor( IDC_HAND_1 );

	// Recipe Gen
	m_btnRecipeGen.SetFont( &m_fntBtn );
	m_btnRecipeGen.SetFlat( FALSE );
	m_btnRecipeGen.SetImageOrg( 10, 3 );
	m_btnRecipeGen.SetIcon( IDI_SAVE, 32, 32 );
	m_btnRecipeGen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRecipeGen.EnableBallonToolTip();
	m_btnRecipeGen.SetToolTipText( _T("Recipe Generation and Save") );
	m_btnRecipeGen.SetBtnCursor( IDC_HAND_1 );

	// Recipe Gen
	m_btnMoveScaleLog.SetFont( &m_fntBtn );
	m_btnMoveScaleLog.SetFlat( FALSE );
	m_btnMoveScaleLog.SetImageOrg( 10, 3 );
	m_btnMoveScaleLog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveScaleLog.EnableBallonToolTip();
	m_btnMoveScaleLog.SetToolTipText( _T("Move Scale Log") );
	m_btnMoveScaleLog.SetBtnCursor( IDC_HAND_1 );

	// Idle 
	m_btnIdle.SetFont( &m_fntBtn );
	m_btnIdle.SetFlat( FALSE );
	m_btnIdle.SetImageOrg( 10, 3 );
	m_btnIdle.SetIcon( IDI_SETREF, 32, 32 );
	m_btnIdle.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnIdle.EnableBallonToolTip();
	m_btnIdle.SetToolTipText( _T("Idle Mode") );
	m_btnIdle.SetBtnCursor( IDC_HAND_1 );

	// Drill Display
	m_btnDrillDisplay.SetFont( &m_fntBtn );
	m_btnDrillDisplay.SetFlat( FALSE );
	m_btnDrillDisplay.SetImageOrg( 10, 3 );
	m_btnDrillDisplay.SetIcon( IDI_DRILLDISPLAY, 32, 32 );
	m_btnDrillDisplay.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDrillDisplay.EnableBallonToolTip();
	m_btnDrillDisplay.SetToolTipText( _T("Drill Data Display") );
	m_btnDrillDisplay.SetBtnCursor( IDC_HAND_1 );

	// Fiducial Setting
	m_btnFiducialSetting.SetFont( &m_fntBtn );
	m_btnFiducialSetting.SetFlat( FALSE );
	m_btnFiducialSetting.SetImageOrg( 10, 3 );
	m_btnFiducialSetting.SetIcon( IDI_FIDUCIALSETTING, 32, 32 );
	m_btnFiducialSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFiducialSetting.EnableBallonToolTip();
	m_btnFiducialSetting.SetToolTipText( _T("Fiducial Setting") );
	m_btnFiducialSetting.SetBtnCursor( IDC_HAND_1 );

	// Dust Suction
	m_btnDustSuction.SetFont( &m_fntBtn );
	m_btnDustSuction.SetFlat( FALSE );
	m_btnDustSuction.SetImageOrg( 10, 3 );
	m_btnDustSuction.SetIcon( IDI_MANUAL, 32, 32 );
	m_btnDustSuction.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDustSuction.EnableBallonToolTip();
	m_btnDustSuction.SetToolTipText( _T("Dust Suction") );
	m_btnDustSuction.SetBtnCursor( IDC_HAND_1 );

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
	m_btnBack.ShowWindow( SW_HIDE );


	

	EnableButton(TRUE, FALSE, FALSE, FALSE, FALSE);

//	if(!gSystemINI.m_sHardWare.nDustTableUse)
		m_btnDustSuction.ShowWindow(SW_HIDE);
	
	if(gSystemINI.m_sHardWare.nManualMachine)
		m_btnDrillOneCycleStop.ShowWindow(SW_HIDE);


	m_btnMoveScaleLog.ShowWindow(SW_HIDE);


//#ifndef __KUNSAN_SAMSUNG_LARGE__
//	m_btnIdle.ShowWindow(SW_HIDE);
//#endif
}

void CPaneAutoRunSub::OnButtonBack() 
{
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneAutoRunSub::OnButtonRecipeGen() 
{
	// 110621
/*	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus())
	{
		if(gProcessINI.m_sProcessCal.nScalMethod != 2 && gProcessINI.m_sProcessCal.nPowerMethod != 2)
		{
			if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
				return;
		}
		
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = FALSE;	
		::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
	}
*/

	WPARAM wParam = RECIPE_GEN;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneAutoRunSub::OnButtonMoveScaleLog() 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->MoveScaleLog();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->LogCopy();
}

void CPaneAutoRunSub::OnButtonDrillDisplay() 
{
	WPARAM wParam = DRILL_DISPLAY;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneAutoRunSub::OnButtonFiducialSetting() 
{
	// 110621
/*	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus())
	{
		if(gProcessINI.m_sProcessCal.nScalMethod != 2 && gProcessINI.m_sProcessCal.nPowerMethod != 2)
		{
			if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
				return;
		}
		
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = FALSE;	
		::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
	}
*/	
	WPARAM wParam = FIDUCIAL_SETTING;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneAutoRunSub::OnButtonDustSuction()
{
	if(IDYES == ErrMessage(_T("Do you want to run this process?"), MB_YESNO))
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->DustSuction();
}

void CPaneAutoRunSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneAutoRunSub::OnButtonStart() 
{
/*	CString strErrCode		= _T("ERR_EASY_DRILLER_001");
	CString strErrReason	= _T("Only Testing....");
	CString strErrSolution	= _T("Testing Testing Testing.");

	CDlgAlarm	dlg;

	//dlg.SetErrMsg( strErrCode, strErrReason, strErrSolution );
	 //dlg.SetErrMsg( strErrCode, _T(""), strErrSolution );
	//dlg.SetErrMsg( strErrCode,strErrReason, _T("") );
	 dlg.SetErrMsg( strErrCode, _T(""), _T("") );
	dlg.DoModal();*/

//	ErrMsgDlg( STDGNALM102 );

#ifndef __TEST__

	if(gVariable.m_bDoorFlag == FALSE)
	{
		ErrMessage(_T("The door is open,please close it first!!!"));
		return;
	}

#endif

	if( gDeviceFactory.GetMotor()->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(gVariable.m_nMachineMode != 0) //Only idle mode drill start
	{
		ErrMessage(_T("Please Change Manchine IDLE Mode")); // 110603
		return;
	}
	
	// 110621
/*	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus())
	{
//		if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
//			return;
		
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = FALSE;	
		::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
	}
*/
	::AfxGetMainWnd()->SendMessage( DRILL_START );
}

void CPaneAutoRunSub::OnButtonDrillOnecycleStop() 
{
	//BOOL bSel = m_btnDrillOneCycleStop.GetSelection();
	
	//m_btnDrillOneCycleStop.SetSelection( !bSel );

	::AfxGetMainWnd()->SendMessage( DRILL_ONE_CYCLE );
}

void CPaneAutoRunSub::OnButtonPause()
{
	::AfxGetMainWnd()->SendMessage( DRILL_PAUSE );
}

void CPaneAutoRunSub::OnButtonStop()
{
	::AfxGetMainWnd()->SendMessage( DRILL_STOP, TRUE );
}

void CPaneAutoRunSub::EnableButton(BOOL bStart, BOOL bOne, BOOL bPause, BOOL bStop, BOOL bRun)
{
	m_btnStart.EnableWindow(bStart);

	m_btnDrillOneCycleStop.EnableWindow(bOne);
	m_btnDrillPause.EnableWindow(bPause);
	m_btnStop.EnableWindow(bStop);
	if(!bStart)
		m_btnDrillPause.SetFocus();
	
	m_btnRecipeGen.EnableWindow(!bRun);
	m_btnFiducialSetting.EnableWindow(!bRun);

	m_btnDustSuction.EnableWindow(!bRun);

	m_btnIdle.EnableWindow(!bRun);

}

void CPaneAutoRunSub::SetOneCycleStopText(BOOL bStop)
{
	if(bStop)
		m_btnDrillOneCycleStop.SetWindowText(_T("ReStart"));
	else
		m_btnDrillOneCycleStop.SetWindowText(_T("Drill one\ncycle stop"));
}


BOOL CPaneAutoRunSub::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Drill_Sub) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneAutoRunSub::OnButtonIdle()
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	::AfxGetMainWnd()->SendMessage(UM_IDLE_MODE);
#endif
	
}

void CPaneAutoRunSub::OnBnClickedButtonOpenBeampathTable()
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		return;
	}
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDlgBeamPathTable dlg;

	dlg.SetBeamPath(gBeamPathINI.m_sBeampath);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}


void CPaneAutoRunSub::OnBnClickedButtonOpenShotTable()
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		return;
	}
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDlgShotTable dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}

void CPaneAutoRunSub::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		break;
	case 2:
	case 3:
		break;
	}
}