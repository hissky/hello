// System Definistion

#undef __TEST__

//EES ����͸� ��
#undef __MCCDAQ_USE_FOR_TEMPERATURE__
#undef __USE_MEASURE_VOLTAGE__
#undef __USE_TEMPERATURE_COMP__

#define TEST_TOOL			1

#define  MAX_BLOCK_FOR_CTF			16
#define MAX_LASER_HEAD_CNT		4

#define	MAX_LASER_NO					2
#define USE_ALL_HEAD						0x03

#define __USE_ONLY_LOW_CAM__

#define __KUNSAN_SAMSUNG_LARGE__ // ��� �Ｚ���� large panel
#define __PKG_MODIFY__
#undef  __NANYA__
#define  __NANYA_NEW__
#undef __NO_USE_HEIGHT_SENSER_USB__ 
#ifdef	__TEST__
	#undef	__SERVER_PC__
#endif


#ifdef __KUNSAN_SAMSUNG_LARGE__
	#define __SERVO_MOTOR__
	#define __NO_USE_OPC__ 
	#undef	__MP920_MOTOR__
	#define	__ADD_MELSEC_MOTOR__
    #define  __NO_USE_INIT_LASER_IF__
	#define  __FST_CHILLER_TYPE__
#endif

#undef __PKG_MODIFY__

enum { USE_HEAD_1 = 1, USE_HEAD_2 = 2 ,USE_HEAD_3 = 4,USE_HEAD_4 = 8,USE_HEAD_ALL = 15 };

enum emHEAD_USE_INFO { USE_LEFT_BOTTOM = 1, USE_RIGHT_BOTTOM = 2, USE_LEFT_TOP = 4, USE_RIGHT_TOP = 8};


#undef	__NO_USE_HEIGHT_SENSOR__
#define __NO_USE_MATROX_VISION__



#include "model\DPoint.h"

enum { ASCENDING_ORDER = 0, DECASCENDING_ORDER};
enum { INT_TYPE = 0, DOUBLE_TYPE};

// define section
#define		BUFMAX		256
#define	CHANGE_PANE			WM_USER+200
#define CHANGE_SUB_PANE		WM_USER+201
#define GET_BACK_PANE_NO	WM_USER+202
#define PROCESS_APPLY		WM_USER+203
#define SYSTEM_APPLY		WM_USER+204
#define UM_LOG_MESSAGE		WM_USER+205
#define DRILL_START			WM_USER+206
#define DRILL_ONE_CYCLE		WM_USER+207
#define DRILL_PAUSE			WM_USER+208
#define DRILL_STOP			WM_USER+209
#define SEND_ERR_MSG		WM_USER+210
#define AUTO_MSG			WM_USER+211
#define UM_SAVE_INIFILE		WM_USER+212
#define UM_SYSTEMSUB_UI_CHANGE WM_USER+213
#define UM_CHANGE_DATAFILE  WM_USER+214
#define UM_SET_ERR_MSG		WM_USER+215
#define UM_CONTROL_TAB_ENABLE WM_USER+216
#define UM_DO_CALIBRATION	WM_USER+217
#define UM_MODE_CHANGE		WM_USER+218
#define VISION_INSPECTION	WM_USER+219
#define VISION_LIVE			WM_USER+220
#define UM_SET_ERR_MSG_ID	WM_USER+221
#define UM_WRITE_LOG		WM_USER+222
#define UM_POWER_MEASURE	WM_USER+223
#define  UM_POWER_CHECK		WM_USER+224
#define  UM_RESET_SWITCH	WM_USER+225
#define	UM_COMPONENT_PREACQTIME WM_USER+226
#define UM_DO_POWERMEASUREMENT WM_USER+227
#define UM_CHILLER_ALARM WM_USER+228
#define UM_FID_FIND_RESULT WM_USER+229
#define UM_CHANGE_VIEW WM_USER+230
#define UM_CHANGE_PREWORK_STATUS WM_USER+231
#define UM_POWER_RESULT WM_USER+232
#define UM_SCANNER_RESULT WM_USER+233
#define UM_DRAW_DOING_PREWORK WM_USER+234
#define UM_DO_SCANNER_CALIBRATION	WM_USER+235
#define UM_DO_APPLY_SCAL_RESULT		WM_USER+236
#define UM_DO_CHAGNE_SCAL_PREWORK	WM_USER+237
#define UM_ANY_PREWORK	WM_USER+238
#define DRILL_ONE_CYCLE_NOUNLOAD		WM_USER+239
#define UM_INI_UI_UPDATE				WM_USER+240	
#define UM_WINDOW_READY_FOR_FID_CAP		WM_USER+241
#define UM_SAFETY_MODE					WM_USER+242
#define UM_RESORT_AREA					WM_USER+243
#define UM_SIDE_WINDOW					WM_USER+244
#define UM_MAINUI_MOVE_TOPLEFT			WM_USER+245
#define UM_PRJ_BACKUP_DELETE			WM_USER+246
#define UM_RESIZE_VISION				WM_UNDO+247
#define UM_OMI_RECONNECT				WM_USER+200
#define UM_INPUT_FID_IMAGE				WM_USER+248
#define UM_CAL_AUTO_SCAL_POS			WM_USER+251
#define UM_TABLE_MODE					WM_USER+252
#define UM_IDLE_MODE					WM_USER+253
#define UM_BUTTOM_MESSAGE				WM_USER+254 // 20130522
#define UM_UPDATE_TAG					WM_USER+255
#define UM_UPDATE_ERROR					WM_USER+256
#define UM_UPDATE_ERROR_CLEAR		    WM_USER+257
#define UM_SET_CURRENT_LOTID			WM_USER+258
#define UM_UPDATE_RECIPE				WM_USER+259
#define UM_OPC_STATUS					WM_USER+260
#define UM_GET_ATTEN_POWER				WM_USER+261
#define PROJECT_CHANGE					WM_USER+262
#define UPDATE_OPC_DISPLAY				WM_USER+263

#define UM_LOCK_BUTTON							WM_USER+268
#define UM_REDRAW_TABLE_DATA							WM_USER+269
#define UM_SET_FID_BLOCK							WM_USER+270
#define UM_IDEL_POWER_START				WM_USER+271
#define UM_IDEL_SCAL_START				WM_USER+272
#define UM_SHOW_4WAY				WM_USER+273
#define PROJECT_LPC_SAVE				WM_USER+274
#define UM_IDEL_PREHEAT_START				WM_USER+275
#define UM_SHOW_AUTOLOADER_INTERFACE		WM_USER+276

#define UM_SET_PANE_NO					WM_USER+277
#define UM_SET_JOB_TIME					WM_USER+278
#define UM_AUTO_BTN_CONTROL				WM_USER+279


///////////////////////////////////////////////////////////////////////////

#define MAX_TOOL_NO			28
#define POWER_TOOL			MAX_TOOL_NO - 2
#define DUMMY_TOOL			MAX_TOOL_NO	- 1
#define SCANNER_CAL_TOOL	MAX_TOOL_NO
#define ONE_HOLE_TOOL		SCANNER_CAL_TOOL + 1
#define ALIGN_TOOL			MAX_TOOL_NO - 3

#define FIND_ALL_FID		3
#define FIND_SELECT_ONLY	1
#define FIND_VISIBLE_ONLY	2
#define DOWNLOAD_MAX_HOLE	34000
#define ASC_AXIS_SIZE			65

#define  PCB_NONE		0x00
#define  PCB_ALIGN		0x01
#define  PCB_LOADER		0x02


enum {LEFT_TO_RIGHT, RIGHT_TO_LEFT, BOTTOM_TO_TOP, TOP_TO_BOTTOM};
enum {LEFT_TOP, RIGHT_TOP, LEFT_BOTTOM, RIGHT_BOTTOM};

enum {AREA_SORT_NONE, AREA_SORT_TOP, AREA_SORT_LEFT};
/*
//Field 72 Pitch 620
#define MAX_AUTOCAL_TOTAL_COUNT	196
#define MAX_AUTOCAL_X_COUNT	14
#define MAX_AUTOCAL_Y_COUNT	14
#define AUTOCAL_HOLE_DISTANCE	0.62
#define MAX_VISIONCAL_TOTAL_COUNT	3364

//Field 72 Pitch 1240
#define MAX_AUTOCAL_TOTAL_COUNT_4WAY	49
#define MAX_AUTOCAL_X_COUNT_4WAY	7
#define MAX_AUTOCAL_Y_COUNT_4WAY	7
#define AUTOCAL_HOLE_DISTANCE_4WAY	1.240
#define MAX_VISIONCAL_TOTAL_COUNT_4WAY	841
*/


/////////////////////////////////////////////
#define MAX_LOTID_CNT		10
#define BEAMPATH_COUNT	100

#define SHOT_GROUP_COUNT	100
#define SHOT_COUNT	15

#define AOM_COUNT	10

#define AUTO_DRILL_MODE 0
#define MANUAL_DRILL_MODE 1
#define NONE_DRILL_MODE 2

#define MAX_CAMERA			4	// ī�޶��� �ִ� ����
#define MODEL_CIRCLE		1
#define MODEL_RECT			5
#define MODEL_CROSS			2
#define MODEL_PATTERN		7

#define	DISPLAYA		5 // vision control 
#define	DISPLAYB		4 

// enum section
enum emHEAD {emMaster, emSlave, emNone};
enum VACUUM_TYPE { VACUUM_A = 0, VACUUM_B, VACUUM_C, VACUUM_D, VACUUM_E, VACUUM_F };
enum DUMMY_FREE_TYPE { DUMMY_FREE_1 = 0, DUMMY_FREE_2 };
//enum PANEL_SEPARATION { USE_DUAL = 0, USE_1ST, USE_2ND };
enum PANEL_SEPARATION { USE_DUAL = 0, USE_1ST = 1, USE_2ND = 2 };
enum HOLE_FIND {NO_FIND, PRE_FIND, POST_FIND};


#ifdef __PKG_MODIFY__
	const int MOTOR_AXIS_MAX			= 0x0D; // Motor Axis Max 



	enum MOTOR_AXIS		{ AXIS_X = 0, AXIS_Y, AXIS_Z1, AXIS_Z2, AXIS_M, AXIS_M2, AXIS_M3, AXIS_C, AXIS_C2, AXIS_L_CARRIER, AXIS_UL_CARRIER,
		AXIS_TOPHAT,AXIS_ROT,AXIS_M4, 
		AXIS_LP1, AXIS_LP2, AXIS_UP1, AXIS_UP2, AXIS_A1,AXIS_A2,
		AXIS_LC, AXIS_LP3, AXIS_UC, AXIS_UP3 };

#else

		const int MOTOR_AXIS_MAX			= 0x0A; // Motor Axis Max 


enum MOTOR_AXIS		{ AXIS_X = 0, AXIS_Y, AXIS_Z1, AXIS_Z2, AXIS_M, AXIS_M2, AXIS_C, AXIS_C2, AXIS_C3, AXIS_C4, AXIS_L_CARRIER, AXIS_UL_CARRIER,
		AXIS_TOPHAT, AXIS_M3, AXIS_M4, AXIS_ROT, 
		AXIS_LP1, AXIS_LP2, AXIS_UP1, AXIS_UP2, AXIS_A1,AXIS_A2,
		AXIS_LC, AXIS_LP3, AXIS_UC, AXIS_UP3 };


#endif
enum MOTOR_AXIS_SINGLE { SINGLE_X, SINGLE_Y, SINGLE_Z, SINGLE_M, SINGLE_C };
enum MOTOR_TABLE {TABLE_A, TABLE_B, TABLE_C, TABLE_D, TABLE_ALL};
#ifdef __PKG_MODIFY__
  enum {  EZ_SERVO_C1  = 0, EZ_SERVO_C2,EZ_SERVO_M1, EZ_SERVO_M2, EZ_SERVO_M3, EZ_SERVO_TOPHAT , EZ_SERVO_ROT , EZ_SERVO_M4};
#else
enum {  EZ_SERVO_C1  = 0, EZ_SERVO_C2, EZ_SERVO_C3, EZ_SERVO_C4, EZ_SERVO_M1, EZ_SERVO_M2, EZ_SERVO_M3, EZ_SERVO_TOPHAT, EZ_SERVO_M4 , EZ_SERVO_ROT };

#endif

	enum { OPTION_NONE = 0, OPTION_SEPERATE,OPTION_ALL};

enum { DRILL=0, RECIPE_GEN, MANUAL_CONTROL, PROCESS_SETUP, 
	   SYSTEM_SETUP, LOG_MANAGER, DRILL_DISPLAY, 
	   USER_ACCOUNT, FIDUCIAL_SETTING, LOGOUT, MOTOR_SETUP };

enum { DRILL_SUB = 0, RECIPE_GEN_SUB, FIDUCIAL_SETTING_SUB, MANUAL_CONTROL_SUB, 
	   PROCESS_SETUP_SUB, SYSTEM_SETUP_SUB, LOG_MANAGER_SUB, USER_ACCOUNT_SUB, DRILL_DISPLAY_SUB,
	   MOTOR_SETUP_SUB };

enum { FIDUCIAL_ALL_VIEW = 0};
enum { HANDLER_LOADER_ALIGN = 0, HANDLER_LOADER_LOAD, HANDLER_LOADER_HOMING, HANDLER_LOADER_PICKER, 
		HANDLER_UNLOADER_UNLOAD, HANDLER_UNLOADER_HOMING, HANDLER_UNLOADER_PICKER,
		HANDLER_UNLOADER_TO_LOAD_START, HANDLER_UNLOADER_CHECK, UI_DIRLL_STATUS_SET};

typedef enum { FID_LAYOUT_NONE,
			   FID_LEFT_TOP, 
			   FID_LEFT_BOTTOM, 
			   FID_RIGHT_TOP, 
			   FID_RIGHT_BOTTOM, 
			   FID_HORIZONTAL, 
			   FID_VERTICAL, 
			   FID_SEPARATE} FID_LAYOUT;

enum { MAIN_VISION_VIEW = 0, TEACHING_VISION_VIEW, SCANNER_CAL_VISION_VIEW, ONE_HOLE_VISION_VIEW, TABLE_CAL_VISION_VIEW, SCANNER_CAL_POS_VISION_VIEW, THETA_CAL_VISION_VIEW };

enum MOTOR_AXIS_EACH{	IND_X = 0x01, 
	IND_Y = 0x02,
	IND_Z1 = 0x04, 
	IND_Z2 = 0x08, 
	IND_M1 = 0x10, 
	IND_C1 = 0x20, 
	IND_M2 = 0x40, 
	IND_C2 = 0x80,
	IND_A1 = 0x100,		
	IND_A2 = 0x200,
	IND_M3 = 0x400,
	IND_M4 = 0x800,
	IND_ROT = 0x1000,
	IND_TOPHAT = 0x2000,
	IND_C3 = 0x4000,
	IND_C4 = 0x8000,
};


typedef enum { 
	OCS_ESTOP,		OCS_SHIFT,		OCS_CLAMP,		OCS_ENTER,		OCS_BLOCK,		OCS_FEEDHOLD,		OCS_BEAM,
	OCS_STOP,		OCS_START,		OCS_STEP,		OCS_HALT, 		OCS_RESET,		OCS_RESTART,		OCS_DRYRUN,
	OCS_SERVOON,	OCS_CYCLESTOP,	OCS_CYCLESTART,	OCS_FREESHEET,	OCS_FRAME,		OCS_JOG,			OCS_HOME,
	OCS_SHUTTER,	OCS_GAS,		OCS_AUTORUN,	OCS_XAXIS,		OCS_YAXIS,		OCS_ZAXIS,			OCS_IDLE
} OCSMODE;




enum SCANNER_AXIS{PX_PY = 0, NX_PY, PX_NY, NX_NY, PY_PX, NY_PX, PY_NX, NY_NX};
enum EOCARD_TYPE{ ETS4_TYPE = 0, ETS5_TYPE};
enum EOCARD_AXIS_USE{EO_USE_1ST = 1, EO_USE_2ND = 2, EO_USE_3RD = 4, EO_USE_4TH = 8};
enum CHANGE_VIEW{VIEW_DATA, VIEW_FIDUCIAL, VIEW_PREHEAT, VIEW_POWER, VIEW_SCANNER};
//enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
//		HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM};

enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
		HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM,
		HANDLER_ALIGNERSTOP, HANDLER_LOADSTOP, HANDLER_UNLOADSTOP, HANDLER_UNLOAD_TO_LOADSTART, HANDLER_UNLOADRUNSTOP,
		HANDLER_LOAD_PICKER_DOWN, HANDLER_UNLOAD_PICKER_DOWN};
//////////////////////////////////////////////////////////////////////////////
enum { NORMAL_MODE, SAFETY_MODE, IDLE_MODE };
enum { JUST_MOVE, AUTORUN_MOVE, SHOT_MOVE};
enum { NOT_USE_FIND_FID, USE_FIND_FID};
enum { LASER_CO2, LASER_UV, LASER_HYBRID, LASER_LV100, LASER_IPGPULSE, LASER_SLV263G};
enum { SHOT_DRILL_ORIGIN, SHOT_DRILL_DIVIDE};
enum { HEAD1_BEAM1_LASER1, HEAD2_BEAM1_LASER1, HEAD2_BEAM2_LASER2, HEAD2_BEAM2_1_LASER2, HEAD2_BEAM1_2_LASER2};
enum { MOVE_XYZ, MOVE_XYZMC, MOVE_XY, MOVE_XYMC, MOVE_XYMCA};
enum { HIGH_1ST_CAM, LOW_1ST_CAM, HIGH_2ND_CAM, LOW_2ND_CAM};
enum { LOW_CAM_FIND_FID, HIGH_CAM_FIND_FID, LOW_TO_HIGH_FIND_FID, USE_CAM_BY_PRJ};
enum { HIGH_CAM, LOW_CAM, LOW_TO_HIGH_CAM };
enum { NON_EXCELLON, LOAD_EXCELLON, FIELD_DIVIED, SET_FID_ORIGIN = 4, APPLY_FID = 12};//20091029
enum { X_Y, MX_Y, X_MY, MX_MY, Y_X, MY_X, Y_MX, MY_MX};
enum { VALID_PARAM, DIFF_SUB_TYPE, LINE_DOT_MISMATCH, NONE_SUBPARAM, BARCODE_SIZE_ERROR, APERTURE_COUNT_ERROR,BLOCK_DATA_ERROR};
enum { NO_FIRE, DOING_FIRE, DONE_FIRE};
enum { EASYDRILL_INI, PROCESS_INI, SYSTEM_INI,BEAMPATH_INI, TEMP_INI, SHOT_INI };
enum { OMI_VISION, MATROX_VISION , MATROXTCP_VISION, OMI_VISION_PRO = 10};
enum { MOTOR_MP, MOTOR_UMAC, MOTOR_COMIZOA, MOTOR_PMAC, MOTOR_UMAC_PROGRAM};
enum { FID_PRIMARY = 0x0001,
		FID_SECONDARY = 0x0002,
		FID_FIND = 0x0010,
		FID_DRILL = 0x0020,
		FID_VERIFY = 0x0100
		};
enum { DEFAULT_SORT, NO_USE_SORT, ZIGZAG_SORT, TONADO_SORT, SELECT_TOOL_SORT};

enum HANDLER_AXIS		{ HANDLER_LC = 0, HANDLER_LP1, HANDLER_LP2, HANDLER_LP3, HANDLER_UC, HANDLER_UP1, HANDLER_UP2, HANDLER_UP3 };
enum PREWORK {DO_PREHEAT, DO_POWER, DO_SCANNER, DO_DRILL, DO_NOTING};
enum INI_UI { UI_ALL = 0,
				PROCESS_POSITION = 1, PROCESS_PREWORK = 2, PROCESS_OPTION = 4, PROCESS_SYSTEM = 8, PROCESS_FIDUCIAL = 16,
				SYSTEM_PATH = 0x0010, SYSTEM_DEVICE = 0x0020, SYSTEM_BEAMPATH = 0x0040, SYSTEM_DUMPER = 0x0080};
enum { ROT_NONE, ROT_90, ROT_180, ROT_270, ROT_M90};
enum USE_DUMMY {DUMMY_FREE, DUMPER_SHOT, NO_USE};
enum WIDE_MONITOR {WIDE_VISION, WIDE_MOTOR, WIDE_FIDUCIALVIEW, WIDE_TABLE, WIDE_LPC};
enum WIDE_TABLE_WINDOW {TABLE_ONEHOLE, TABLE_AUTOSCAL, TABLE_MANUALSCAL, TABLE_ELSE };
enum COM_SET_MODE {MODE_POWER, MODE_SERVO};
enum JOB_LOG_TYPE {PREHEAT_JOB, SCAL_JOB, POWER_JOB, DRILL_JOB, OPERATION_JOB, PM_JOB, REPAIR_JOB, ERROR_JOB};
enum DUMMY_3RD {DUMMY_3RD_NO_USE, DUMMY_3RD_FIELD, DUMMY_3RD_ALL}; // 3rd dummy all : field + hole dummy 
enum PORT_DIVICE {PORT_CHILLER, PORT_HUMIDITY, PORT_TEMPER_COMP, PORT_VOLTAGE}; 
enum RMS_TYPE {RMS_CREATE, RMS_CHANGE, RMS_DELETE, RMS_VALIDATION, RMS_UPDATE, RMS_DOWNLOAD, RMS_LIST, RMS_TAG, RMS_INFO, RMS_DATAVALIDATION};
enum RMS_STATUS {STATUS_WAIT, STATUS_PROGRESS, STATUS_END};
enum RMS_FIRE_TYPE {FIRE_LOT, FIRE_PRE, FIRE_RE};
enum OPC_PARAM { N_POWER, N_VACUUM, N_HEIGHT, N_SCALE, N_TOOL, N_HEAD, N_SWITCH};
enum OPC_PARAM2 {N_SWITCH_AUTORUN, N_SWITCH_MELSEC_START, N_SWITCH_RMS_TYPE, N_SWITCH_SCHEDULE, N_SWITCH_DATA, N_SWITCH_PRJ, N_SWITCH_LOGIN};
enum ATTEN_MODE { NO_USE_ATTEN, USE_ATTEN_1ST, USE_ATTEN_2ND, USE_ATTEN_DUAL};
enum FID_NG_TYPE { FID_NG_NO, FID_NG_SCALE, FID_NG_LENGH, FID_NG_LENGH2, FID_NG_ANGLE }; 
enum FID_VIEW { FID_CLOSE_ALL, FID_OPEN_ALL, FID_RESET_ALL }; 
enum DUMMY_TYPE{ DUMMY_NONE, DUMMY_FIELD, DUMMY_ALL};
// constant section

	const short SCREEN_PIXEL_X			= 760;
	const short SCREEN_PIXEL_Y			= 574;

const int ALL_AXIS_OK				= -1; //motor �̵� �� ��� �� �Ϸ�� -1 		
const int MAX_PARAM_TOOL			= 2;
const int BUF_SIZE					= 1024;
const int MAX_BEAM_HOLE				= 15;
const int MOTOR_MASK_MAX			= 0x0A;			// Motor Mask 
const int MAXMASKNO					= 10; // ���� �Ⱦ���
const int MAX_AUTODATA				= 10000;			// �ڵ�����϶� �ִ� ����
const TCHAR TABLE_CALIBRATION_FILE[]	= _T("via.table");
const TCHAR DEF_FONT_FACE_NAME[]		= _T("Arial");
const TCHAR DEF_COLOR_TEXT_HEIGHT    = 14;

const int REG_DATA_MAX				= 512;	// MP920 Data Register Max=512
const int COMI_AXIS_MAX				= 0x02;
const int PMAC_AXIS_MAX				= 0x03;
const double MAX_STOPOVER_TIME		= 25.0;	// ������ �ִ� ��ٸ� �ð�

const WORD ADD0B_INDEX_POSITION		= 1020;	// Index position
const WORD ADD0B_WRITE_OUTPORT		= 1500;	// Write Outport
const WORD ADD0B_LOAD_COMMAND		= 1001;	// Mp920 load command 
const WORD ADD0B_UNLOAD_COMMAND		= 1002;	// Mp920 unload command
const WORD ADD0B_ORIGIN_OFFSET		= 1060;	// Origin offset
const WORD ADD0B_LOAD_READY_RESET	= 1514; // unload end --> load request reset
const WORD ADD0B_INDEX_SPEED		= 2020;	// Index speed
const WORD ADD0B_ORIGIN_SPEED		= 2060;	// Origin speed
const WORD ADD0B_AXISZ_LIMIT_POS    = 1084;			// AxisZ Limit Position 
const WORD ADD0B_LOADER_UNLOADER_POS= 1076;			// Loader & Unloader Position
const WORD ADD0B_LOADER_UNLOADER_POS2= 1092;			// Loader & Unloader Position

const WORD ADD09_START				= 5000;
const WORD ADD09_STATUS				= 5000;	// Status start address
const WORD ADD09_LOADUNLOAD			= 5010; // Load & Unload start address
const WORD ADD09_COMMAND			= 5020;
const WORD ADD09_ENCODER			= 5040;
const WORD ADD09_INPUT				= 5060;/*5050;*/// Input start address
const WORD ADD09_ERROR				= 5080;/*5070;*/	// Error start address
const WORD LEN09_ERROR				= 6;
const WORD ADD09_SERVO				= 5090;/*5080*/	// SERVO start address
const WORD LEN09_SERVO				= 7;			// SERVO Error address length

#ifdef __MP920_MOTOR__
	const unsigned char MODE_MPG	= 0x03;
	const unsigned char MODE_MANUAL	= 0x02;
	const unsigned char MODE_AUTO	= 0x04;
	const unsigned char MODE_OFF	= 0x05;
	const unsigned char MODE_SAFE	= 0x06;
	const unsigned char MODE_HOME	= 0x07;
#else
	const unsigned char MODE_OFF	= 0x00;
	const unsigned char MODE_MPG	= 0x01;
	const unsigned char MODE_HOME	= 0x02;
	const unsigned char MODE_MANUAL	= 0x03;
	const unsigned char MODE_AUTO	= 0x04;
	const unsigned char MODE_SAFE	= 0x06;
#endif
	
const int MAX_FIDUCIAL		= 100;

const int		NUMLSB				= 65536;
const unsigned short	MAXLSB		= 65535;
const unsigned short	HALFLSB		= static_cast<unsigned short>(NUMLSB / 2);
const unsigned short	QUARTERLSB	= static_cast<unsigned short>(NUMLSB / 4);
const unsigned short	OCTALSB		= static_cast<unsigned short>(NUMLSB / 8);
const int SCANNER_FIELD_SIZE		= 50;

///////////////////////////////////////////////////////////////////////////////////////////

// user define type section
typedef enum
{
	ERROR_IO				= 0x0010,
	ERROR_LOAD				= 0x0020,
	ERROR_UNLOAD			= 0x0021,
	ERROR_LOAD2				= 0x0022,
	ERROR_UNLOAD2			= 0x0023,
	ERROR_LOAD3				= 0x0024,
	ERROR_UNLOAD3			= 0x0025,
	ERROR_LOAD4				= 0x0026,
	ERROR_UNLOAD4			= 0x0027,
	ERROR_ALIGN				= 0x0030,
	ERROR_TABLELIMIT		= 0x0040,
	ERROR_OTHERLIMIT		= 0x0041,
	ERROR_TABLE				= 0x0050,
	ERROR_LASER				= 0x0060,
	ERROR_OTHERS			= 0x0070,
	ERROR_OTHERS2			= 0x0071,
	ERROR_OTHERS3			= 0x0072,
	ERROR_OTHERS4			= 0x0073,
	ERROR_OTHERS5			= 0x0074,	//2011517 
	ERROR_OTHERS6			= 0x0075,	//2011526

	ERROR_LOADER_PICKER1			= 0x0076,	
	ERROR_UNLOADER_PICKER1			= 0x0077,	


	STATUS_IO1				= 0x0080,
	STATUS_IO2				= 0x0081,
	STATUS_IO3				= 0x0082,
	STATUS_IO4				= 0x0083,
	STATUS_IO5				= 0x0084,	//2011517
	STATUS_IO6				= 0x0085,
	STATUS_IO7				= 0x0086,
	STATUS_IO8				= 0x0087,

	STATUS_MELSEC			= 0x0088,

	// 110704
	ERROR_HANDLER_MAIN		= 0x0000,
	ERROR_HANDLER_LOADER	= 0x0001,
	ERROR_HANDLER_UNLOADER	= 0x0002,
	ERROR_HANDLER_ETC1		= 0x0003,
	ERROR_HANDLER_ETC2		= 0x0004,
	STATUS_HANDLER_LOADER	= 0x0005,
	STATUS_HANDLER_UNLOADER	= 0x0006,

	//20160613
	ERROR_HANDLER_1060		= 0x0100,
	ERROR_HANDLER_1061		= 0x0101,
	ERROR_HANDLER_1062		= 0x0102,
	ERROR_HANDLER_1063		= 0x0103,
	ERROR_HANDLER_1064		= 0x0104,
	ERROR_HANDLER_1065		= 0x0105,
	ERROR_HANDLER_1066		= 0x0106,
	ERROR_HANDLER_1067		= 0x0107,


	//20171110
	ERROR_HANDLER_LOADER1		= 0x0110,
	ERROR_HANDLER_LOADER2		= 0x0111,
	ERROR_HANDLER_LOADER3		= 0x0112,
	ERROR_HANDLER_LOADER4		= 0x0113,
	ERROR_HANDLER_UNLOADER1		= 0x0114,
	ERROR_HANDLER_UNLOADER2		= 0x0115,
	ERROR_HANDLER_UNLOADER3		= 0x0116,
	ERROR_HANDLER_UNLOADER4		= 0x0117

} ERRORCOMMAND;

typedef enum
{
	CURRENT_MODE = 0,
	CURRENT_CYCLE,
	CURRENT_SYSTEM,
	CURRENT_EMSTOP,
	CURRENT_SHUTTER1,
	CURRENT_SHUTTER2,
	CURRENT_SUCTION,
	CURRENT_LOADDETECT,
	CURRENT_UNLOADDETECT,
	CURRENT_DUSTSUCTION,
	EXTERNAL_LASER,
	CURRENT_HEIGHT,
	CURRENT_CHILLER,
	CURRENT_HEIGHT2,
	CURRENT_CLAMP1,
	CURRENT_CLAMP2

} CURRENTSTATUS;

typedef enum
{
	IS_READY = 0,
	IS_SCANNER_FAULT,
	IS_CLOSED_HS,
	IS_OPEN_LASER_SHUTTER,
	IS_FLOW_WATER,
	IS_LOADER_STOP,
	IS_UNLOADER_STOP,
	IS_SYSTEM_ALARM_OFF_ERROR,
	IS_SYSTEM_DOOR_BYPASS,
	IS_MAIN_DOOR_STOP,
	IS_OPTICS_DOOR_STOP,
	IS_MAIN_DOOR_OPEN,
	IS_LOADER_DOOR_OPEN,
	IS_UNLOADER_DOOR_OPEN,
	IS_OPTICS_DOOR_OPEN,
	IS_BYPASS_ON
} ISSTATUS;

typedef enum
{
//	PORT_LASER_POWER		= 0x0000,			// Address 1500
	PORT_TABLE_SUCTION1		= 0x0001,
	PORT_TABLE_SUCTION2		= 0x0002,			// Ring Blow
	PORT_HEIGHT_SENSOR		= 0x0003,			// Height Sensor
	PORT_POWER_METER		= 0x0004,			// Power Meter
	PORT_SHUTTER_MASTER		= 0x0005,			// High Shutter #1
	PORT_SHUTTER_SLAVE		= 0x0006,			// High Shutter #2
	PORT_CYCLE_LAMP			= 0x0007,			// Cycle Lamp
	PORT_LOADER_LOCK		= 0x0008,
	PORT_UNLOAD_LOCK		= 0x0009,
	PORT_ALARM				= 0x000A,			// Alarm On Off
	PORT_PARTICLE_BLOW		= 0x000B,
	PORT_LU_DOOR_LOCK		= 0x000C,
	PORT_SYSTEM_DOOR_BYPASS	= 0x000D,
	PORT_DRILL_START		= 0x000E,			// Drill Start
	PORT_PCB_SINGLE			= 0x000F,
	PORT_PC_BUZZER		    = 0x0011,           // PC Buzzer On (for just alarm)
	PORT_INITIAL_RESET		= 0x0012,			// initial or reset

	PORT_MODE_SELECT		= 0x0013,			// manual, auto, safety

	PORT_CYCLE_MODE			= 0x0014,			// start, temp stop, cycle stop, pause
	PORT_MPG_MODE			= 0x0015,
	PORT_LAMP				= 0x0016,
	PORT_LASER_BYPASS		= 0x0017,
	PORT_HEIGHT_SENSOR_2	= 0x0018,			// Height Sensor 2
	PORT_FROMT_DOOR_LOCK	= 0x0019,
	PORT_LOAD_DOOR_LOCK		= 0x001A,
	PORT_LASER_PASS_TOP		= 0x001B,			// Laser Beam Pass Tophat On/Off

	PORT_TABLE1_VACUUM_MOTOR = 0x001C,			//Table1 Vaccum Motor ON

	PORT_TABLE2_VACUUM_MOTOR = 0x001D,			//Table2 Vaccum Motor ON
	PORT_AOM_POWER			 = 0x001E,			//AOM Power on
	PORT_DEFAULT_TABLE_SUCTION1 = 0x001F,
	PORT_DEFAULT_TABLE_SUCTION2 = 0x0020,
	PORT_LASER_HEAD_PURGE	= 0x0021,
	PORT_AUTO_MPG			= 0x0022,
	PORT_TABLE_SUCTION		= 0x0023,
	PORT_ACRYL_TABLE_SUCTION = 0x0024,
	PORT_ACRYL_TABLE_SUCTION2 = 0x0025,
	PORT_LASER_BEAM_PASS1	= 0x0026,
	PORT_SUCTION_HOOD_SOL		= 0x0027,
	PORT_LASER_SIGNAL		= 0x0028,
	PORT_TABLE_CLAMP		= 0x0029,
	PORT_VIBRATION			= 0x002A,
	PORT_NG_PCB				= 0x002B,
	PORT_CHILLER_REMOTE		= 0x002C,
	PORT_LPC				= 0x002D,
	PORT_LOT_END			= 0x002E,
	PORT_USE_LOAD_UNLOAD	= 0x002F,
	PORT_DRYRUN_NO_PCB		= 0x0030,
	

	//0�� �߰�
	PORT_CHILLER1_REMOTE_ON		= 0x0031,
	PORT_CHILLER2_REMOTE_ON		= 0x0032,
	PORT_RING_BLOWER_REMOTE_RUN		= 0x0033,
	PORT_RING_BLOWER_VAC_POWER		= 0x0034,
	PORT_SCANNER_POWER_REMOTE_ON		= 0x0035,
	PORT_RING_BLOWER_SOL_VALVE_ON		= 0x0036,

	PORT_TABLE1_CLAMP		= 0x0037,
	PORT_TABLE2_CLAMP		= 0x0038,
	//1�� �߰�
	PORT_LASER_BEAM_PASS2		= 0x0039,
	PORT_TABLE_B_USE		= 0x003A,
	PORT_SUCTION_HOOD_BOLWER		= 0x003B,
	PORT_MASK_BLOW_SOL		= 0x003C,
	PORT_OPTIC_BLOW_SOL		= 0x003D,
	PORT_WARNING_ON		= 0x003E,
	PORT_AUTO_LUBRICATOR_REMOTE	= 0x003F,
	PORT_USE_TABLE_CLAMP		= 0x0040,
	PORT_TOWER_LAMP_OFF			= 0x0041,
	PORT_WARNING				= 0x0042,
	PORT_MARKING_START				= 0x0043,
	PORT_MANUAL_MODE_ON		= 0x0044,			// manual, auto
		PORT_DOOR_LOCK		= 0x0045,
		
		//20170828 ��������
	PORT_IO_CHECK		= 0x0046,
	PORT_LASER_ETHERNET_CON		= 0x0047,
	PORT_LASER_SHUTTER_CON		= 0x0048,
	PORT_NO_USE_CHILLER		= 0x0049,

	PORT_AOM_NA_BEAMPATH_CYL_UP		= 0x0050,
	PORT_AOM_USE_BEAMPATH_CYL_UP		= 0x0051,
	PORT_SAFETY_MODE_ON		= 0x0052,			// safety mode

	PORT_ML3_RESET		= 0x0053,			
	
} PORTCOMMAND;

typedef enum
{
	COMMAND_POSITION		= 0x10,
	COMMAND_READY			= 0x20,
	COMMAND_INORIGIN		= 0x30,
	COMMAND_INPOSITION		= 0x40,
	COMMAND_SHUTTER			= 0x60,
	COMMAND_ERROR			= 0x50,


	COMMAND_LOAD			= 0x80,
	COMMAND_LOADSTOP		= 0x81,
	COMMAND_LOADMOVING		= 0x82,
	COMMAND_LOAD_DETECT		= 0x83,
	COMMAND_LOAD_ERROR		= 0x84,

	COMMAND_UNLOAD				= 0x90,
	COMMAND_UNLOADSTOP			= 0x91,
	COMMAND_UNLOADMOVING		= 0x92,
	COMMAND_UNLOAD_DETECT		= 0x93,
	COMMAND_UNLOAD_ERROR		= 0x94,
	COMMAND_UNLOAD_TO_LOADSTART	= 0x95,
	COMMAND_UNLOAD_END			= 0x99,

	COMMAND_ALIGNER			= 0xA0,
	COMMAND_ALIGNERSTOP		= 0xA1,
	COMMAND_ALIGNERMOVING	= 0xA2,
	COMMAND_ALIGNER_ERROR	= 0xA3,

	COMMAND_UNLOAD_CHECK	= 0xA4
} MOTORCOMMAND;

typedef enum
{
	INDEX_NULL			= 0x0000,
	INDEX_INDIVIDUAL	= 0x0001,
	INDEX_INTERPOLATION	= 0x0002,
	INDEX_ORIGIN		= 0x0003,
}INDEXCOMMAND;			// Mp920 Index Command

typedef enum
{
	LOADER_NULL			= 0x0000,
	LOADER_ORIGIN		= 0x0003,
	LOADER_ALIGN		= 0x0004,
	LOADER_LOADING		= 0x0005,
	LOADER_PICKER_UP	= 0x0006,
	LOADER_PICKER_DOWN	= 0x0007,
}LOADERCOMMAND;			// Mp920 Load Command

typedef enum
{
	UNLOADER_NULL		= 0x0000,
	UNLOADER_ORIGIN		= 0x0003,
	UNLOADER_UNLOADING1	= 0x0006,
	UNLOADER_UNLOADING2	= 0x0007,
	UNLOADER_PICKER_UP	= 0x0008,
	UNLOADER_PICKER_DOWN = 0x0009,
	UNLOADER_PICKER_LEFT = 0x000A,
	UNLOADER_PICKER_RIGHT = 0x000B,
}UNLOADERCOMMAND;			// Mp920 UnLoad Command

struct MP920INDEX
{
	BOOL	bIsReady[MOTOR_AXIS_MAX];	// Is Ready Axis
	BOOL	bIsError[MOTOR_AXIS_MAX];	// Is Error Axis
	BOOL	bIsOrigin[MOTOR_AXIS_MAX];	// Is Origin Axis
	BOOL	bIsPosition[MOTOR_AXIS_MAX];// Is Stop Axis
	WORD	wStatus[MOTOR_AXIS_MAX];	// Is Status Axis;
	long	lCommand[MOTOR_AXIS_MAX];	// Encoder Position Value
	long	lEncoder[MOTOR_AXIS_MAX];	// Encoder Position Value
	double	dPosition[MOTOR_AXIS_MAX];	// Command Position Value
};

struct MP920LOAD
{
	WORD	wStatus;
	BOOL	bLoaderRun;
	BOOL	bLoaderStop;
	BOOL	bAlignRun;
	BOOL	bAlignStop;
};

struct MP920UNLOAD
{
	WORD	wStatus;
	BOOL	bUnloadRun;
	BOOL	bUnloadStop;
	BOOL	bUnloadToLoadStart;
};

struct MP920IO
{
	BYTE	nMode;
	BYTE	nPower;
	BYTE	nCycle;
	BYTE	nSystem;
	BYTE	nEMStop;
	BYTE	nHighShutter1;
	BYTE	nHighShutter2;
	BYTE	nIsPcbLoad;
	BYTE	nIsPcbUnload;
	BYTE	nIsSuction;
	BYTE	nDustSuction;
	BYTE	nExternalLaser;
	BYTE	nTableClamp;
	BYTE    nChillerAlarm;
	BYTE	nVacuumMotor;
	
	LONG	lError[10];
	LONG	lErrorServo[7];
	LONG	lErrorIo;
	LONG	lErrorLoad;
	LONG	lErrorUnload;
	LONG	lErrorAligner;
	LONG	lErrorTableLimit;
	LONG	lErrorOtherLimit;
	LONG	lErrorTable;
	LONG	lErrorLaser;
};

struct MP920DATA
{
	MP920INDEX	Index;					// Table Struct
	MP920LOAD	Load;					// Load Struct
	MP920UNLOAD	UnLoad;					// UnLoad Struct
	MP920IO		IO;						// IO Struct
};

typedef struct tagAXISINFO
{
//	int		nNo;
	TCHAR	szName[BUFMAX];
	double	dScale;
	double	dTableFeedRate;
	double	dTableAcceleration;
	double	dTableSCurve;
	double	dTableAccelerationPre;
	double	dTableSCurvePre;
	double	dTableAccelerationNext;
	double	dTableSCurveNext;
	double	dLimitPlus;
	double	dLimitMinus;
} SAXISINFO;

typedef struct tagCOMPORT 
{
	int		nPortNo;
	int		nBaudRate;
	int		nDataBits;
	int		nParity;
	int		nStopBits;
	int		nFlowControl;
	int		nTimeOut;
	double  dCH1;
	double  dCH2;
} SCOMPORT;

typedef struct tagHEIGHTSENSOR
{
	double	dManualX;
	double	dManualY;
	double	dAutoX;
	double	dAutoY;
	double	dOffsetX;
	double	dOffsetY;
	double	dHeadZ;
	double	dBaseZ;
} SHEIGHTSENSOR;

typedef struct tagLOTINFO
{
	TCHAR	szBasketID[MAX_LOTID_CNT][255];
	TCHAR	szLotID[MAX_LOTID_CNT][255];
	TCHAR	szDrillData[MAX_LOTID_CNT][255];
	int		nLotCount[MAX_LOTID_CNT];
	int		nFiredLotCount[MAX_LOTID_CNT];
	int		nNGLotCount[MAX_LOTID_CNT];
	TCHAR	szPrj[MAX_LOTID_CNT][255];
	BOOL	bMESOK[MAX_LOTID_CNT];
	BOOL	bUseMES;
	TCHAR	szFilmNo[MAX_LOTID_CNT][255];
	TCHAR	szProcessCode[MAX_LOTID_CNT][255];
	int		nStatus[MAX_LOTID_CNT]; // 0: ���, 1: ����, 2: �Ϸ�
	int		nFireType[MAX_LOTID_CNT]; // 0: ��Lot , 1: ����, 2:���۾�
	int		nLastIndex;
	int		nTotalFireCount;
	int		nComSol[MAX_LOTID_CNT]; // 0 : Com, 1: Sol 2: Both_Com 3: Both_Sol
	int		nDrillTest[MAX_LOTID_CNT]; // 0 : Drill, 1:Test
	BOOL	bUseOpenTool[MAX_LOTID_CNT];
	
} SLOTINFO;

typedef struct tagAUTOSETTING				// Auto Mode���� ����
{
	// Load Position
	double	dLoadPosX;							// Load X�� ��ġ
	double	dLoadPosY;							// Load Y�� ��ġ

	double	dLoadPosX2;							// Load#2 X�� ��ġ
	double	dLoadPosY2;							// Load#2 Y�� ��ġ

	// Unload Position
	double	dUnloadPosX;						// Unload X�� ��ġ
	double	dUnloadPosY;						// Unload Y�� ��ġ

	double	dUnloadPosX2;						// Unload#2 X�� ��ġ
	double	dUnloadPosY2;						// Unload#2 Y�� ��ġ

	// Fiducial Standby Position	
	double	dFiducialX;							// Fiducial Standby X�� ��ġ
	double	dFiducialY;							// Fiducial Standby Y�� ��ġ

	// Table Offset
	double	dTableOffsetX;						// Table�̵��� X�� ��ġ
	double	dTableOffsetY;						// Table�̵��� Y�� ��ġ

	// 1'st, 2'nd Height Sensor
	SHEIGHTSENSOR sHeightSensor[2];				// Use Array For Dual Panel

	// 1'st, 2'nd Powermeter Position
	DPOINT	dPowermeterPos[2];					// Use Array For Dual Panel	

//	double	dMaskPosition[MOTOR_MASK_MAX];		// Mask Position

	double	dLoaderCartPos;					// �δ� īƮ ��ġ
	double	dLoaderCartPos2;					// �δ� īƮ ��ġ
	double	dLoaderLoadPos;					// �δ� �ε� ��ġ
	double	dLoaderLoadPos2;				// �δ� �ε� ��ġ2
	double	dLoaderAlignPos;
	double	dUnloaderCartPos;				// ��δ� īƮ ��ġ
	double	dUnloaderUnloadPos;				// ��δ� ��ε� ��ġ
	double	dUnloaderUnloadPos2;				// ��δ� ��ε� ��ġ2
	double	dUnloaderAlignPos;


	double dLoaderPicker1UpPos;				//�δ� ��Ŀ1 �� ��ġ
	double dLoaderPicker1AlignPos;			//�δ� ��Ŀ1 ����� ��ġ
	double dLoaderPicker1TablePos;			//�δ� ��Ŀ1 ���̺� ��ġ
	double dLoaderPicker2UpPos;				//�δ� ��Ŀ2 �� ��ġ
	double dLoaderPicker2AlignPos;			//�δ� ��Ŀ2 ����� ��ġ
	double dLoaderPicker2TablePos;			//�δ� ��Ŀ2 ���̺� ��ġ
	double dLoaderPicker2CartPos;			//�δ� ��Ŀ2 īƮ ��ġ

	double dUnloaderPicker1UpPos;				//��δ� ��Ŀ1 �� ��ġ
	double dUnloaderPicker1AlignPos;			//��δ� ��Ŀ1 ����� ��ġ
	double dUnloaderPicker1TablePos;			//��δ� ��Ŀ1 ���̺� ��ġ
	double dUnloaderPicker2UpPos;				//��δ� ��Ŀ2 �� ��ġ
	double dUnloaderPicker2AlignPos;			//��δ� ��Ŀ2 ����� ��ġ
	double dUnloaderPicker2TablePos;			//��δ� ��Ŀ2 ���̺� ��ġ
	double dUnloaderPicker1CartPos;			//��δ� ��Ŀ1 īƮ ��ġ


	double	dUnclampLimitY;					// Unclamp ���� ��ġ

	double  dDustSuctionMin;
	double  dDustSuctionMax;
	
	double	dAutoCalMinTablePosX;
	double	dAutoCalMinTablePosY;
	double	dAutoCalMaxTablePosX;
	double	dAutoCalMaxTablePosY;

	int		nOpticMX;
	int		nOpticSX;
	int		nOpticMY;
	int		nOpticSY;

	double	dIdleShotTablePosX;
	double	dIdleShotTablePosY;
	double	dIdleShotTablePosZ1;
	double	dIdleShotTablePosZ2;
	int		nIdleShotBeamPathNo;
	int		nIdleShotBeamPathNoForMotor; // ù��° ���� ���͸� �������� �ð�����
	int		nIdleTimeResetLimit;
	int		nIdleShotRepeatCount;

	double dTCCleanPosX;
	double dTCCleanPosY;
	double dTCCleanPosZ1;
	double dTCCleanPosZ2;

} SAUTOSETTING;

typedef struct tagAUTODATAXY				// �ڵ�����϶� XY ������
{
	double	dX;									// �̵� X��ǥ
	double	dY;									// �̵� Y��ǥ
} SAUTODATAXY;

typedef struct tagAUTODATA					// �ڵ�����϶� ������
{
	SAUTODATAXY	dMoveXY[MAX_AUTODATA];
	double		dMoveZ1;						// �̵� Z1��ǥ
	double		dMoveZ2;						// �̵� Z2��ǥ
} SAUTODATA;

typedef struct tagPENDATA
{
	double	dDrawStep;
	int		nStepPeriod;
	int		nJumpStep;
	int		nJumpDelay;
	int		nLaserOnDelay;
	int		nLaserOffDelay;
	int		nCycleTime;
	int		nScannerJDelay;
	int		nPulseFrequency;
} SPENDATA;

typedef struct tagProcessLaserScanner
{
//	TCHAR	szPenName[BUF_SIZE];
//	SPENDATA	sPenData;
//	__int64	nShotCount;
//	int		nXYOrder;
//	int		n1stCalTime;
//	int		n2ndCalTime;
//	int		nPreheatModulationTime;
//	int		nPreheatTime;
//	int		nPreheatSpeedXY;
//	int		nPreheatSpeedZ1Z2;
} SPROCESSLASERSCANNER;

typedef struct tagPROCESSOPTION
{
	int		nAlignTime;
	int		nLoadTime;
	int		nUnloadTime;
	double	dPCBHeihtAutoTol;
	double	d1stPCBHeightMin;
	double	d1stPCBHeightMax;
	double	d2ndPCBHeightMin;
	double	d2ndPCBHeightMax;
	BOOL	bCheckSuctionError;
	BOOL	bRejectSuctionOff;
	BOOL	bCheckLPCError;
	int		nLPCLogsaveDate;
	int		nLPCErrorCount;
	int		nChillerErrCount;
	BOOL	bLPCLogDetail;
	BOOL	bMarkingDualMode;
	BOOL	bSlaveMeasureStart;
	BOOL	bFullScheduling;

	BOOL	bNoUseTopHat;
	double dDutyLimit;
	__int64	nShotCount;
//	int		nPreheatSpeedZ1Z2;
	int		nValidMeasureTime;
	int		nAlignDualTime;
	int		nAlignSingleTime;
	int		nAlignDualTimeOnlyPCB;
	int		nAlignSingleTimeOnlyPCB;
	int nVacuumMotorOffTime;
	int		nAlignStartPer;
	double  dCCLSize;
	double	dPPGSize;
	double	dVerifySize;
	// Temperature compensation options
	BOOL	bWaitTemperDownForAGC;
	BOOL	bTemperCompensationMode;
	BOOL	nTemperMeasureMode;
	BOOL	bTemperVerifyMode;
	BOOL bTempVerifyLowCam;
	BOOL	bTemperDetailLog;
	int			nOCRMoveOffset; 
	int			nTempRepeatCompenLotCount; // 1, 2 ,4, 8 �̷������� if 5�� 1 + 4 : ù��� 3��°�忡�� ������.
	int			nTempCompenVerifyLotCount; // �Է��� ���� ������� �˻���. if 3, 3�� ��� lot������ �˻�. 10000�̷������� �Է��ϸ� �˻� ����.
	int			nTemperCompenEveryPnl;
	int			nTemperCompenFireCountForVisionCompen; // ��Ȧ�� �ѹ��� �������� �˻�(ù�常 �˻�) ù��° 
	int			nTemperCompenFireCountForVisionCompen2; // ��Ȧ�� �ѹ��� �������� �˻�(ù�常 �˻�) �ι���
	int			nTemperCompenFireCountForVisionCompen3; // ��Ȧ�� �ѹ��� �������� �˻�(ù�常 �˻�) ����°
	int			nTemperCompenFireCountForVisionCompen4; // ��Ȧ�� �ѹ��� �������� �˻�(ù�常 �˻�) �׹�°
	int			nTemperCompenFireCountForVisionCompen5; // ��Ȧ�� �ѹ��� �������� �˻�(ù�常 �˻�) �ټ���°

	int			nTemperCompenGridNo; // 2 or 3
	double	dTemperDeltaT;
	double  dTemperVerifyContrast;
	double  dTemperVerifyBrightness;
	int			nTemperCompenTimeoutMin; // ��
	int			nTemperCompenRepeatNo;
	int			nTableMoveWaitTimeMS;
	int			nSBTemperLongWaitTime;
	int			nTCMasterCH1;
	int			nTCMasterCH2;
	int			nTCSlaveCH1;
	int			nTCSlaveCH2;
	int			nSBMasterCH1;
	int			nSBMasterCH2;
	int			nSBSlaveCH1;
	int			nSBSlaveCH2;

	BOOL	bTemper2DLinearMode;
	double	dTemperMinTLimit;
	double	dTemperMaxTLimit;

	double	dTemperEndT;
	double	dTemperTransT;

	double	dTemperDetaTLimit;
	double	dTemperMinusDetaTLimit;
	double	dTemperTWaitScal; // sec
	double	dTemperDifferTLimit;

	int nTemperStartDuty;
	int nTemperStepDuty;
	int  nTemperDutyStepNo;
	int nTemperStartPower;
	int nTemperEndPower;

	int nOPCTimeOut;
	int nTabelInposCount;
	int		nOpcLogSaveData;
	int		nLpcLogSaveData;
    int		nLogCopyTime;
	double dWaterFlowLaser;
	double dWaterScannerFlow;
	double dWaterFlowScanner1;
	double dWaterFlowScanner2;
	BOOL	bWaterFlowErrorCheck;
	BOOL	bDustLimitCheck;
	double dChillerPressure1;
	double dChillerPressure2;

	int	nFieldFireTimeLimit;
	int		nCavityDrawInOffset;
	int		nCavityDrawOutOffset;
} SPROCESSOPTION;

typedef struct tagPROCESSCALIBRATION
{
	int		n1stToleranceX; // apply limit
	int		n1stToleranceY;
	int		n1stToleranceR;
	int		n2ndToleranceX; // drilling limit
	int		n2ndToleranceY;
	int		n2ndToleranceR;
	int		n1stPreworkToleranceX;
	int		nPostDoPreworkMinimumCount;
	int		n1stPreworkToleranceY;
	int		n2ndPreworkToleranceX;
	int		n2ndPreworkToleranceY;
	int		n1stPreworkToleranceR;
	int		n2ndPreworkToleranceR;
	int		nAutoCalibrationCount;
	int		nAutoCalibrationFieldCount;
	int		nVisionCalibrationFieldCount;
	double	dCalibrationHoleGap;
	int		nVisionCalibrationXCount;
	int		nVisionCalibrationYCount;
	int		nAutoCalibrationXCount;
	int		nAutoCalibrationYCount;

	BOOL	bUseLaserPowerMeasurement;
	BOOL	bMeasurementNewFileOpen;
	int		nValidTime;
//	int		nValidError;
//	int		nProcessOption;
	BOOL	bUseApplyTolerance;
//	int		nApplyTolerance;
	BOOL	bSkipBoardCheck;
	int		nXYOrder;
	int		n1stCalTime;
	int		n2ndCalTime;
	int		nValidMeasureTime;
	
	int		nScalAbsTime;
	int		nScalRelTime;
	int		nScalCountTime;
	int		nScalCountTimeForSkive;
	int		nScalCountTime2;




	int		nPowerAbsTime;
	int		nPowerRelTime;
	int		nPowerCountTime;
	int		nPreheatAbsTime;
	int		nPreheatRelTime;
	int		nPreheatCountTime;
	int		nDrillEndTime;
	BOOL	bUsePNLCountUnit;
	int		nScalMethod;
	int		nPowerMethod;
	int		nPreheatMethod;

	int		nStartScalTime; // �� �ʱ�ȭ �Ǵ� Laser&Shutter&AOM �κ� On/Off�� ���� -> ����簡�� �������� �Ǵ�
	int		nStartPowerTime; // �� �ʱ�ȭ �Ǵ� Laser&Shutter&AOM �κ� On/Off�� ���� -> ����簡�� �������� �Ǵ�
	int		nStartPreheatTime;
	BOOL	bPowerEndLot;
	BOOL	bUsePowerCompensationMode;
	int		nPreheatEndTime;
	int		nPreheatModulationTime;
	int		nPreheatTime;
	int		nAutoRunPreheatTime;
	int		nPreheatSpeedXY;
	int		nPreheatFreq;
	int		nAutoRunPreheatFreq;
	int		nAutoRunPreheatJumpDelay;



	double	dPreheatDuty;
	double  dAutoRunPreheatDuty;
	int			nVisionCalMode;
	int		nIdleBeamPath;
} SPROCESSCALIBRATION;

typedef struct PROCESSSYSTEM
{
	BOOL	bUsePreLPRLimit;
	BOOL	bLoaderUnloaderCartLock;
	BOOL	bDryRun;
	BOOL	bNoUseLoaderUnloader;
	BOOL	bLoaderUnloaderDoorLock;
	BOOL	bShowScannerPath;
	BOOL	bNoUseSuction;
	BOOL	bNoUseFiducialFind;
	BOOL	bNoUseScanner;
	BOOL	bNoUseDustSuction;
	BOOL	bNoSortArea;
	int	nAreaSortMode;
	double	dSortAreaYRatio;
	int		nNoSortHole; // 0: All sort, 1: no sort, 2: zigzag sort, 3: tonado sort 4; Select Tool Sort
	int		nHoleSortPitch; 
	int		nHoleDistancePitch;

	BOOL	bRecipeHoleSort;
	BOOL	bToolHoleSort[MAX_TOOL_NO];


	BOOL	bNoSortLine;
	BOOL	bUseManualFidSet;
	BOOL	bNoDivideUnit;
	BOOL	bNoUseAOMAlarm;		//2011526
	BOOL	bNoUseZCal;	
	BOOL	bNoUseLaserCal;	
	BOOL	bNoUseTCal;	
	BOOL	bNoUsePowerCheck;
	BOOL	bFieldMinimumDivide;
	BOOL	bNoUseRollUpDown;
	BOOL	bNoUsePaper;
//	BOOL	bPowerCheckMode;
//	BOOL	bSCalCheckMode;
	BOOL	bNoUseApplyScal;
	BOOL	bNoUsePrework;
	BOOL	bNoUseChangeView;
	BOOL	bCheckPreworkData;
	BOOL	bNoUseChillerAlarm;
	BOOL	bUseTextMarking;
	BOOL	bUseSaveFidImage;
	BOOL	bUseFindSecondFid;
	BOOL	bEveryPanelThicknessMeasurement;
	BOOL	bEveryPanelVisionHeadOffsetCheck;
	BOOL	bUseScheduling; 
	BOOL	bUseAIMode;
	BOOL	bUseNewParameter3;


	BOOL	bUseSpeedUp;
	BOOL	bUseAllFidFind;
	BOOL	bUseDetailLog;


	BOOL	bUseNewBarcodeContents; 
	BOOL	bUseAllToolScal; 
	BOOL	bUseAllToolPower; 

	BOOL	bUseOriginalInspectionMode;
	BOOL	bUse1stPanelStop;
	BOOL	bNoUseMelsecInterface;
	BOOL	bCheckHoleCount;
	BOOL	bLaserErrorCheck;
	BOOL	bUse4WayScalMain;
	BOOL	bUseGetHighCamOffset;
	BOOL	bUsePatternDevide;
	BOOL	bUseApplyScalToEocard;
	BOOL	bUseShotScale;
	BOOL	bUse1PointVisionCompen;
	BOOL	bUseAutoPreHeat;
	BOOL	bUseAutoMonitoring;
	BOOL	bUseSheetSuction;

	BOOL	bShowAllFidImage;
	BOOL	bFailFidCountinue;
	BOOL	bUseOpenTool;
	BOOL	bNoUseNGBox;
	BOOL	bUseTurnPanel;
	BOOL	bDryRunNoPCB;
	BOOL	bLineToShotFireMode; // 20131028
	BOOL	bLineToShotSameLength;
	BOOL	bPassMode;
	BOOL    bCheckVisionSizeError;
	BOOL	bUseSpare1;
} SPROCESSSYSTEM;

typedef struct _tagAOMTable
{

	//Table 0

	BOOL		bSelectedList[AOM_COUNT];
	int			nInfoId[AOM_COUNT];

	//Table 1
	
	double		dAOM_ON_M[AOM_COUNT];
	double		dAOM_OFF_M[AOM_COUNT];
	double		dAOM_ON_S[AOM_COUNT];
	double		dAOM_OFF_S[AOM_COUNT];


} SAOMTABLE;
typedef struct _tagShotTable
{

	//Table 0
	int			nLastIndex;
	BOOL		bSelectedList[SHOT_COUNT];
	int			nInfoId[SHOT_COUNT];




	//Table 1
	
	double		dOnTime_M[SHOT_COUNT];
	double		dOnTime_S[SHOT_COUNT];
	//int         nFrqeuncy[SHOT_COUNT];


	//Table 2
	int		nAOMNum_M[SHOT_COUNT];
	double		dAOMWait_M[SHOT_COUNT];
	int		nAOMNum_S[SHOT_COUNT];
	double		dAOMWait_S[SHOT_COUNT];


	double		dRefPower[SHOT_COUNT];
	double		dPower_Tol[SHOT_COUNT];

	double		dTargetMax_M[SHOT_COUNT];
	double		dTargetMin_M[SHOT_COUNT];

	double		dOntimeOffset_M[SHOT_COUNT];
	double		dOntimeOffset_S[SHOT_COUNT];

	double		dOntimeOffset2_M[SHOT_COUNT];
	double		dOntimeOffset2_S[SHOT_COUNT];

	double		dShotScaleX_um_M[SHOT_COUNT];
	double		dShotScaleY_um_M[SHOT_COUNT];

	double		dShotScaleX_um_S[SHOT_COUNT];
	double		dShotScaleY_um_S[SHOT_COUNT];

	SAOMTABLE    m_sAOMParam[SHOT_COUNT];

	double		dTargetLPCMax_M[SHOT_COUNT];
	double		dTargetLPCMin_M[SHOT_COUNT];
	double		dTargetLPCMax_S[SHOT_COUNT];
	double		dTargetLPCMin_S[SHOT_COUNT];

} SSHOTTABLE;

typedef struct _tagShotGroupTable
{
	//Table 0 
	int			nGroupLastIndex;
	BOOL		bGroupSelectedList[SHOT_GROUP_COUNT];
	int			nGroupInfoId[SHOT_GROUP_COUNT];
	TCHAR 		strInfoName[SHOT_GROUP_COUNT][256];
	SSHOTTABLE		m_sShotParam[SHOT_GROUP_COUNT];
	
	//Table 1 
	int			nToolType[SHOT_GROUP_COUNT];	
	int			nShotMode[SHOT_GROUP_COUNT];
	int			nFirstWaitMode[SHOT_GROUP_COUNT];

	int			nShotFrequency[SHOT_GROUP_COUNT];
	int			nShotMinFrequency[SHOT_GROUP_COUNT]; //20160812

	double			dShotDuty_Percent[SHOT_GROUP_COUNT];
	double			dShotLMDuty_us[SHOT_GROUP_COUNT];

	int			nTotalShotCount[SHOT_GROUP_COUNT]; //��Ȱ��ȭ , �ڵ� ����
	int			nBurstShotCount[SHOT_GROUP_COUNT]; //Burt �϶� Ȱ��ȭ, Cycle 1


	double			dVoltage_M[SHOT_GROUP_COUNT];
	double			dVoltage_S[SHOT_GROUP_COUNT];
	BOOL        bUseAperture[SHOT_GROUP_COUNT];
	TCHAR		strAperturePath[SHOT_GROUP_COUNT][256];

	BOOL			bUseAom[SHOT_GROUP_COUNT];
	int				nDummyType[SHOT_GROUP_COUNT];	

	int			nTextSizeX[SHOT_GROUP_COUNT];
	int			nTextSizeY[SHOT_GROUP_COUNT];

	int			nCavityDrawInOffset[SHOT_GROUP_COUNT];
	int			nCavityDrawOutOffset[SHOT_GROUP_COUNT];


	//Table 2  // Marking �� ���� Ȱ��ȭ
	int         nLaserOnDelay[SHOT_GROUP_COUNT];
	int         nLaserOffDelay[SHOT_GROUP_COUNT];
	int         nDrawSpeed[SHOT_GROUP_COUNT];
	int         nJumpSpeed[SHOT_GROUP_COUNT];
	int         nConerDelay[SHOT_GROUP_COUNT];
	int         nJumpDelay[SHOT_GROUP_COUNT];
	int         nLineDelay[SHOT_GROUP_COUNT];



	
} SSHOTGROUPTABLE;

typedef struct tagPROCESSFIDFIND
{
	int		nFidErrorBeforeProcess;
//	BOOL	bUseRemoveFid;
//	int		nRemoveFid;
//	int		nFidVisionCount;
	int		nFidFindMethod[2];
	int		nFidTotalRetrial;
	int		nFidErrorAfterProcess;
	double	dPCBLenTolerance;
	double	dPCBLenTolerance2;
	double  dRefScale;
	double  dRefLengthTol;
	double  dRefLengthTol2;
	double  dPCBLenTolOperatorRunLimit; // 20130404 bhlee 
	BOOL	bOperatorCanRunForScaleOver;
	BOOL	bAutoFidTolerance;
	DPOINT	dMoveLowVision;
	DPOINT	dMoveHighVision;
	BOOL	bAutoFidRecheck;
	double	dRecheckTolerance;
	int		nCalHigh;
	int		nHoleHigh;
	double	dFidAngleLimit;
	double	dRefPosX;
	double	dRefPosY;
	double	dRefPosX2;
	double	dRefPosY2;
	double	dRefPosX3;
	double	dRefPosY3;
	double	dNearPosX;
	double	dNearPosY;
	double	dNearPosX2;
	double	dNearPosY2;
	int		nAcceptSize;
	int		nAcceptRatio;
	BOOL	bUseAllControl;
	BOOL	bMultiFidAscentOrder;
	int		nFidImgSaveData;
	int		nLogSaveData;
	int		nHolePreLimit;
	int		nHolePostLimit;
	double	dScaleMinusLimit;
	double  dScalePlusLimit;

	double dDiagonalScaleMinusLimit;
	double dDiagonalScalePlusLimit;

	BOOL	bUseProportionCompensation; //�ǵ�Ⱥ�ʺ��� 
	BOOL	bHoleFindAreaPos[9];
	BOOL	bHoleFindHolePos[9];

	double	dAcceptScore;
	double  dAcceptEdgeScore;
	double  dRotateHoleAcceptScore;
	double	dResultScore;
	double	dExposure;
	double  dFidFindExposure;

} SPROCESSFIDFIND;

typedef struct tagPROCESSSCANNERCAL
{
	int		nAutoDivision;
	int		nAutoMask;
	int		nAutoHead;
	double	dAutoPulseWidth;
	double	dAuto1stThickness;
	double	dAuto2ndThickness;
	DPOINT	dAutoStart;
	
	int		nManualDivision;
	int		nManualMask;
	int		nManualHead;
	double	dManualPulseWidth;
	double	dManual1stThickness;
	double	dManual2ndThickness;
	DPOINT	dManualStart;

	double	dModelSize;
	double	dModelOrientation;
	int		nModelPolarity;

	double	dSizeTolerance;
	double	dAngleTolerance;
	double	dAspectRatio;

	int		nCoaxial[4];
	int		nRing[4];
	int		nIR[4];
	double	dContrast[4];
	double	dBrightness[4];	

	int		nCountAuto;
	int		nVisionCountAuto;
	int		nCountCheckHeadOffsetAuto;

	double	dScanXTemp;
	double	dScanYTemp;
	
	double	dScanMasterX;
	double	dScanMasterY;
	double	dScanSlaveX;
	double	dScanSlaveY;

	double	dMaxOffsetMasterX;
	double	dMaxOffsetMasterY;
	double  dMaxOffsetSlaveX;
	double  dMaxOffsetSlaveY;

	double	dMasterCalTablePosX;
	double	dMasterCalTablePosY;
	double	dSlaveCalTablePosX;
	double	dSlaveCalTablePosY;
	
	double	dVisionZOffset;

	TCHAR	szJobFilePath[MAX_PATH];
	int		nUseTool;

	int		nShotCount;
	double	dDuty;
	double	dAOMDelay;
	double	dAOMDuty;
	BOOL	bIsSkipCheckBoard;
	BOOL	bDefaultLow;
	BOOL	bUseDummy;
} SPROCESSSCANNERCAL;

typedef struct tagPROCESSPOWERMEASURE
{
	double	dMinAllowable;
	double	dMaxAllowable;
	int		nHead;
//	int		nMeasureMode;
	double	d1stHeight;
	double	d2ndHeight;
	int		nLongTermTotalTime;
	int		nLongTermPeriod;
	int		nLongTermDummyOnTime;
	int		nFrequency;
	double	dPulseWidth;
	int		nMask; // beam path
	BOOL	bTophat;
	BOOL	bCompensation;
	BOOL	bLongTermCheck;
	BOOL	b1stPower[25];
	BOOL	b2ndPower[25];
	int		nMeasureTime;
	int		nMeasureWaitTime;
	double	dCurrent;
	int		nThermalTrack;
	double	dAttenuator1;
	double	dAttenuator2;
	double  dAOMDelay;
	double  dAOMDuty;
	TCHAR	cAOMFilePath[255];
	double	dCompensationTarget;
	int		nCompensationDutyLimitPercent;
	int		nConpensationLimitCount;
	double	dCompensationDutyPerWatt;

	//double	dPowerStep;
	int		nCompensationPowerSpecPercent;
	double	dCompensationWaitLimit;

	double		dPowerStep;
	int		nUseTool;
	int		nPulseNum;

	double	dDutyOffset;  // add 2011.09.15
	double	dDutyOffset2;
	double	dAOMDelayOffset;
	double	dAOMDutyOffset;

	double	dVoltage_M;
	double	dVoltage_S;

} SPROCESSPOWERMEASURE;

typedef struct tagHARDWAREINFO
{
	int		nLaserType; // CO2, UV, CO2-UV, UV-CO2
	int		nBeamType;  // 1, 2, 3, 4-beam
	int		nUseLampRS232; // use rs232 comunication (0:no use)
	int		nTableClamp; // clamp number (0:no use)
	int		nVisionType; // 0:OMI, 1:Matrox
	int		nUseBeamDumper; // 20070730 beam dumper
	int		nManualMachine; // there is no loader/unloader
	int		nDustTableUse; // IDD UV���� ����
	int		nScannerAxisType; // 8���� ������
	int		nScannerAxisType2; // 8���� ������
	int		nAOMType;	// 0 : no use, 1 : AOM delay, duty, 
	int		nEocardType; // 0 : ETS4, 1 : ETS5
	int		nUseEocardAxis; // inposition �ޱ� 1, 2, 4, 8
	int		nShortLineDutyOffset;
	int		nShortLineLength;
	int		nUseBarcodeReader; // ���ڵ帮����� ���� (1:use)
	BOOL	bTableVacuumSelect;
	int		nUseAOD;
	int		nAODMSSelect;
	int		nUseFirstOrder;
	int		nUseDualBand;
	int		nLanguageType;
	double	dScannerWaringLevelmm;
	double	dScannerAlarmLevelmm;
	int		nExcellonOpenAxis;
	BOOL	bUseWideMonitor;
	int		nAutoLockTime;
	BOOL	bUseVacummmotor; // ���� __PUSAN2__ ��길 �̻��ϰ� �׻� ���̾ �߰�
	double	dLPCMinTolerence;
	double  dLPCMaxTolerence;
	double	dPreLPCMinTolerence;
	double  dPreLPCMaxTolerence;
	double	dPreLPCMaxValueOffset;
	int		nLPCStartSkipCount;
	double	dLPCStartTolerencePercent;
	double	dLPCHoleDeviationTolPercent;
	int		nPreLPCShotCount;

	BOOL	bUseFastInposition;
	BOOL	bUseLPC;
	int		nMachineNo;
	int		nTableShootLimit;
	int		nLPCMinimum;

	BOOL	bLaserCalAlarm;
	BOOL	bSaveButtonLog; // 20130522
	BOOL	bChillerConnect;
	BOOL	bHumidityConnect;
	BOOL	bTemperCompConnect;
	BOOL	bVoltageConnect;
	BOOL	bLinkRS485;
	BOOL	bCheckMCMode;
	BOOL	bFirstOffsetMode;
	int		nMaxLotCount;
	
} SHARDWAREINFO;

typedef struct tagSYSTEMDEVICE
{
	// 1'st Panel
	DPOINT	d1stLowHeadOffset;
	DPOINT	d1stHighHeadOffset;
	double  d1stLaserHeight[MOTOR_MASK_MAX];
	double	d1stLowHeight;
	double	d1stHighHeight;
	DPOINT	d1stThetaCenter;
	double  d1stLaserHeightTophat[MOTOR_MASK_MAX];

	// 2'nd Panel
	DPOINT	d2ndLowHeadOffset;
	DPOINT	d2ndHighHeadOffset;
	double  d2ndLaserHeight[MOTOR_MASK_MAX];
	double	d2ndLowHeight;
	double	d2ndHighHeight;
	DPOINT	d2ndThetaCenter;
	double  d2ndLaserHeightTophat[MOTOR_MASK_MAX];
	
	//Head Offset
	double dHeadOffsetX;
	double dHeadOffsetY;

	// Drill Field Size
	DPOINT	dFieldSize;
	DPOINT	dOriginFieldSize;

	// PowerMeasurement Field Size
	DPOINT dPowerMeasurementMSize;
	DPOINT dPowerMeasurementSSize;



	// Vibration Setting
	int		nVibrationCount; // pusan1 : count -> times
	double	dVibrationDelay;
	int		nVibrationLPTime; 

	// Height Sensor ID
	TCHAR	sz1stHeightSensorID[BUF_SIZE];
	TCHAR	sz2ndHeightSensorID[BUF_SIZE];

	
	TCHAR	szMachineNo[BUF_SIZE];

	// Powermeter Port
	SCOMPORT	sPowermeterPort;
	SCOMPORT	sServoPort;
	SCOMPORT	sChillerPort;
	SCOMPORT	sHumidityPort;
	SCOMPORT	sTemperatureCompenPort;
	SCOMPORT	sVisionLampPort;
	SCOMPORT	sVisionLampPort2;

	// Vision Pixel
	DPOINT	d1stLowPixel;
	DPOINT	d1stHighPixel;
	DPOINT	d2ndLowPixel;
	DPOINT	d2ndHighPixel;

	int		nLowCalArea;
	int		nHighCalArea;
	
	double	dAcceptScore;
	double  dAcceptEdgeScore;
	double  dRotateHoleAcceptScore;
	double	dResultScore;
	double	dExposure;

	// LampController Port
	int		nLampComport;
	int		nFiducialFindType;	// fiducial find type ���� (0=MID, 1=MULTI, 2=COARSE)
	
	// Eocard
	BOOL	bCheckDownloadASCValue;
	int		nMinCycleTime; // ms
	int		nMinShotTime; // us
	int		nShotDrillType; // burst-cycle ���� ��� ���� (11,1,1) or (11,11,1) burst2, cycle 3 : total 5
	int		nSelfLineDivide; // TRUE : aperture �߿���� ���� �߶� ����
	int		nFlyingDelayTime; //us
	
	int		nNoUseVision; // UV �����̶� fiducial ����
	int		nUseFidFindInCenter;
	
	int		nAviaUserLevel;

//	CPoint	nPtBeanDumper1; // beam dumper pos 20070730
//	CPoint	nPtBeanDumper2;
	
	DPOINT	d2DCompTableOffset; // umac 2-d table compensation ��������� �Ÿ�

	int		nEocardDownCount;
	BOOL	bCheckHoleData;
	BOOL	bUseHoodAutoMode;
//	int		nDummyShot;
//	int		nDummyInterval;
//	int		nDummyFreq;
//	int		nDummyDuty;
//	int		nDummyAOMDelay;
//	int		nDummyAOMDuty;
//	int		nDummyStartAfterTableStop;

	int		nCalGridDelay;
	int		nCalGridMode;	

	int		nEStop;

	double	dLowFOVX;
	double	dLowFOVY;
	double	dHighFOVX;
	double	dHighFOVY;
	int		nCameraPixelX;
	int		nCameraPixelY;
	int		nCognex_CoarseLimit;
	int		nCognex_CoarseLimitCenter;
	int		nCognex_FineLimit;



	DPOINT	dVisionPixcel1[4][4]; //[cam][position] 
	DPOINT	dVisionPixcel2[4][4];

	int		nBlob;

	//Laser Marking Param
	double	dJumpSpeed;
	int		nJumpDelay;
	int		nCornerDelay;
	int		nLineDelay;
	int		nPreMove;
	int		nJumpDelayShot;

	TCHAR	szVisionModelID[BUF_SIZE];
	TCHAR	szVision2DBarcodeIP[BUF_SIZE];
	TCHAR	szVision2DBarcodeUnloadIP[BUF_SIZE];
	double	dTextGap;
	int		nTextRefMode;
	BOOL	bUseInnerOCRFont;

	int		nDualAom1stOffset;
	int		nDualAom2ndOffset;

	double	dTableLimitMinX;
	double	dTableLimitMinY;
	double	dTableLimitMaxX;
	double	dTableLimitMaxY;
	double	dTableSizeX;
	double	dTableSizeY;
	double	dTableAcrSizeX;
	double	dTableAcrSizeY;
	int		nMaskInposWait;

	double dWaterFlowSetting1;
	double dWaterFlowSetting2;
	double dMainAirSetting;
	double dDustSuctionSetting;
	double dTableVacuumSetting1;
	double dTableVacuumSetting2;

	double dAOMWaterFlowSetting1;
	double dAOMWaterFlowSetting2;
	double dAOMWaterFlowSetting3;
	double dAOMWaterFlowSetting4;

	double dWaterFlowOffsetSetting1;
	double dWaterFlowOffsetSetting2;
	double dWaterFlowOffsetSetting3;
	double dWaterFlowOffsetSetting4;
} SSYSTEMDEVICE;

typedef struct tagSYSTEMPVAUUM
{
	double	dVacuumOffset; // ���������� ���а����� ����
	double	dVacuumOffset2;
	double	dSuctionHoodOffset;
	double	dDustErrLimit;
	double	dTable1Vacuum[4]; // A,B,C,D
	double	dTable2Vacuum[4]; // A,B,C,D
} SSYSTEMVACUUM;

typedef struct tagSYSTEMDUMP
{
	CPoint	nPtBeanDumper1; // beam dumper pos 20070730
	CPoint	nPtBeanDumper2;

	int		nDummyShot;
	int		nDummyInterval;
	int		nDummyFreq;
	int		nDummyDuty;
	int		nDummyAOMDelay;
	int		nDummyAOMDuty;
	int		nDummyStartAfterTableStop;
	
	int		nDummyShot2;
	int		nDummyInterval2;
	int		nDummyFreq2;
	int		nDummyDuty2;
	int		nDummyAOMDelay2;
	int		nDummyAOMDuty2;
	
	int		nStandbyTime;
	int		nStandbyMinFreq;
	int		nStandbyMaxFreq;
	int		nStandbyInterval;
	int		nStandbyDuty;
	int		nStandbyInpositionTime;	
	double	dStandby1stV;
	double	dStandby2ndV;
	int		nStandbyTurnOffTime;

	int		nStandbyTime_Scal;

	int		nStandbyTime2;
	int		nStandbyMinFreq2;
	int		nStandbyMaxFreq2;
	int		nStandbyInterval2;
	int		nStandbyDuty2;
	int		nStandbyInpositionTime2;	
	double	dStandby1stV2;
	double	dStandby2ndV2;
	int		nStandbyTurnOffTime2;
	
	int		nUseDummyType;
	//int		n3RDDummyType;
} SSYSTEMDUMP;

typedef struct tagCOLLIMATORPOS
{
	double	dPositon;
	double	dMeasuredPower;
} SCOLLIMATORPOS;

typedef struct tagMASKMEMO
{
	TCHAR	szMemo[BUF_SIZE];
} SMASKMEMO;

typedef struct tagSYSTEMCOLLIMATOR
{
	SCOLLIMATORPOS	sCollimatorPos[10];
	SCOLLIMATORPOS	sCollimatorPos2[10];

	double			dMaskPosition[10];
//	double			dCollimatorMovingStep;
//	double			dPowerTolerance;
//	double			dPowerDeviation;
	int				nDutyOffset[10];
	int				nAOMDelayOffset[10];
	int				nAOMDutyOffset[10];
//	SCOLLIMATORPOS  sCollimatorPos2[10];
	double			dMaskSize[10];
	double			dBeamSize[10];
	double			dFixedMask;
	double			dPowerDuty[10];
	int				nPowerFreq[10];
	double			dAttenuator1[10];
	double			dAttenuator2[10];

	double			dPowerMin[10];
	double			dPowerMax[10];
//	int				nPowerFreq[10];
	double			dPowerWidth[10];
	double			dPowerAOMDelay[10];
	double			dPowerAOMDuty[10];

	SMASKMEMO		sMemo[10];
} SSYSTEMCOLLIMATOR;

typedef struct tagSYSTEMTOPHAT
{
	SCOLLIMATORPOS	sCollimatorPos[10];
	SCOLLIMATORPOS	sCollimatorPos2[10];
	double			dMaskPosition[10];
	double			dMaskSize[10];
	double			dBeamSize[10];
	int				nDutyOffset[10];
	int				nAOMDelayOffset[10];
	int				nAOMDutyOffset[10];
	double			dPowerDuty[10];
	int				nPowerFreq[10];
	double			dAttenuator1[10];
	double			dAttenuator2[10];
	
	SMASKMEMO		sMemo[10];
} SSYSTEMTOPHAT;


//201164
typedef struct tagSYSTEMCOMPONENT
{
	int				nPreAcTime;
}SYSTEMCOMPONENT;


typedef struct tagGLOBALVARIABLE
{
	BOOL	bCalFalse;
	BOOL	bAutoRun;
	
} SGLOBALVARIABLE;

typedef struct tagTEMPTIME
{
	int nAutoScalEndTime[50][2];
	double dAutoScalTemperature[50][2];
	double dAutoScalEndTemperature[50][2];
	int nAutoPreheatEndTime;
	int nAutoPowerEndTime[50][2];

	double d1stFidSecondPosX;
	double d1stFidSecondPosY;
	double d2ndFidFirstPosX;
	double d2ndFidFirstPosY;
	double d2ndFidSecondPosX;
	double d2ndFidSecondPosY;
}TEMPTIME;

struct POWER_STATUS
{
//	BOOL bDigitalForward;
	BOOL bDigitalReflect;
	BOOL bMVSWR;
	BOOL bDutyCycleFlect;
	BOOL bShutterOn;
	BOOL bShutterOff;
	BOOL bWaterAlarm;
//	BOOL bPowerFail;
	BOOL bPowerOn;
};

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _tagSYSDOOR
{
	BOOL	bFrontDoor1;		// no use
	BOOL	bFrontDoor2;		// no use
	BOOL	bFrontDoor3;		// no use
	BOOL	bLeftDoor1;		// no use
	BOOL	bLeftDoor2;		// no use
	BOOL	bRearDoor1;		// no use
	BOOL	bRearDoor2;		// no use
	BOOL	bRightDoor1;		// no use
} SSYSDOOR;

typedef struct _tagSYSAIR
{
	BOOL	bSysAir;				// no use
	BOOL	bHandlerAir;			// no use
	BOOL	bStageAir;				// no use
	BOOL	bTableAirBearing;		// no use
	BOOL	bPolygonAir;			// no use
	BOOL	bN2GasPressureSensor;		// no use
	BOOL	bSysVacuumPressureSensor;		// no use
} SSYSAIR;

typedef struct _tagSTAGESENSOR
{
	BOOL	bVacuum;			// no use
	BOOL	bN2Gas;				// no use
	BOOL	bUVLaser;			// no use
	BOOL	bChamberSuction;	// no use
	BOOL	bHeadSuction;		// no use
	BOOL	bMaskPicker;		// no use
	BOOL	bMaskVacuum;		// no use
	BOOL	bHeadBlower;		// no use
	BOOL	bOpticalShutter;	// no use
} SSTAGESENSOR;

typedef struct _tagCASSETTESENSOR
{
	BOOL	bLowCassetteDoor;		// no use
	BOOL	bHighCassetteDoor;		// no use
	BOOL	bCupboardDoor;			// no use
	BOOL	bLowCassettePresenceCheck;		// no use
	BOOL	bHighCassettePresenceCheck;		// no use
	BOOL	bCupboardWaferPresenceCheck;	// no use
	BOOL	bWaferPresenceCheckInRail;		// no use
} SCASSETTESENSOR;

typedef struct _tagPREALIGNSENSOR
{
	BOOL	bCassetteScaning;						// no use
	BOOL	bWaferPresenceCheckInPrealignZone;		// no use
	BOOL	bWaferPresenceCheckInBufferZone;		// no use
	BOOL	bPrealignCylinderForword;		// no use
	BOOL	bPrealignCylinderBackword;		// no use
	BOOL	bWaferGrip;						// no use
	BOOL	bWaferHoldingAssurance;			// no use
	BOOL	bGripperCylinder;				// no use
} SPREALIGNSENSOR;

typedef struct _tagSTAGEPICKERSENSOR
{
	BOOL	bVacuum;			// no use
	BOOL	bCylinderUp;		// no use
	BOOL	bCylinderDown;		// no use
	BOOL	bShutterOpen;		// no use
	BOOL	bShutterClose;		// no use
} SSTAGEPICKERSENSOR;

typedef struct _tagCOATERPICKERSENSOR
{
	BOOL	bVacuum;			// no use
} SCOATERPICKERSENSOR;

typedef struct _tagOTHERPARAM
{
	int		nFirstDir;		// no use
	int		nSecondDir;		// no use
} SOTHERPARAM;

typedef struct _tagDHANDLERPOS
{
	double	dPreAlignerX;		// no use
	double	dPreAlignerZ;		// no use
	double	dCoaterPickerY;		// no use
	double	dCoaterPickerZ;		// no use
	double	dStagePickerX;		// no use
	
	double	dElevator;		// no use
	double	dGripper;		// no use
	double	dAlignRail;		// no use
	double	dLPickerY;		// no use
	double	dLPickerZ;		// no use
	double	dBPickerY;		// no use
	double	dBPickerZ;		// no use
	double	dSpinT;			// no use
	double	dSpinZ;			// no use
	double	dCoaterArm;		// no use
} DHANDLERPOS;

//////////////////////////////////////////////////////////////////////////////
typedef struct _tagDSTAGEPOS
{
	double	x;  // X-Axis Position
	double	y;	// Y-Axis Position
	double	z;	// Z-Axis Position
	double	t;	// T-Axis Position
	double	p;	// Polgong Mirror Velocity(RPM)		// no use
} DSTAGEPOS;

typedef struct _tagMOTORERR
{
	BOOL	bDriveFault;
	BOOL	bFollowingErr;
	BOOL	bOpenLoop;
	BOOL	bMinusLimit;
	BOOL	bPlusLimit;
	BOOL	bHomeTimeOver;
	BOOL	bHoming;
	BOOL	bHomeEnd;
} SMOTORERR;

typedef struct _tagSTAGEIF
{
	BOOL	bMachineReady;
	BOOL	bAllInitializing;
	BOOL	bAllInitialEnd;
	BOOL	bDustCollectorAlarm;
	BOOL	bStageStart;		// no use
	BOOL	bStageReady;		// no use
	BOOL	bStageProgress;		// no use
	BOOL	bStageEnd;			// no use
	BOOL	bStageError;		// no use
} SSTAGEIF;

typedef struct _tagSYSSENSOR
{
	BOOL	bEmergencySwitch;
	BOOL	bSystemAirPressure;
	BOOL	bTableVacuumSensor;
	int		nMPGMode;
	
	BOOL	bTowerLampRedOn;
	BOOL	bTowerLampYellowOn;
	BOOL	bTowerLampGreenOn;
	BOOL	bTowerLampBuzzerOn;
	BOOL	bTableVacuumOnSol;
	BOOL	bTableExhaustSol;
	BOOL	bIonizerAirBlowerSol;
	BOOL	bFrontDoorLockSol;
	BOOL	bLoadingDoorLockSol;
	BOOL	bDoorBypass;
	BOOL	bDustCollectorOn;
	BOOL	bMainLampOn;
	
	BOOL	bMainPower;			// no use
	BOOL	bLaserPower;		// no use
	BOOL	bServoPower;		// no use
	BOOL	bCircuitProtector;	// no use
	BOOL	bBypassKeySwitch;	// no use
	BOOL	bResetSwitch;		// no use
	BOOL	bInitialSwitch;		// no use
	BOOL	bStartSwitch;		// no use
	BOOL	bStopSwitch;		// no use
} SSYSSENSOR;

typedef struct _tagBeamPath
{
	int			nLastIndex;
	BOOL		bSelectedList[BEAMPATH_COUNT];
	//Information
	int			nInfoId[BEAMPATH_COUNT];
	TCHAR 		strInfoName[BEAMPATH_COUNT][256];
	double		dInfoMaskSize[BEAMPATH_COUNT];
	
	//�����
	double		dBeamPathBetPos1[BEAMPATH_COUNT];
	double		dBeamPathBetPos2[BEAMPATH_COUNT];
	double		dBeamPathBetPos3[BEAMPATH_COUNT];
	double		dBeamPathBetPos4[BEAMPATH_COUNT];

	int			nBeamPathMaskPos1[BEAMPATH_COUNT];
	int			nBeamPathMaskPos2[BEAMPATH_COUNT];
	int			nBeamPathMaskPos3[BEAMPATH_COUNT];
	int			nBeamPathMaskPos4[BEAMPATH_COUNT];//20170721
	double			dBeamPathRotator[BEAMPATH_COUNT];
	double			dBeamPathTopHat[BEAMPATH_COUNT];

	int			nBeamPathAttenuatePos1[BEAMPATH_COUNT];
	int			nBeamPathAttenuatePos2[BEAMPATH_COUNT];
	double		dBeamPathZAxisPos1[BEAMPATH_COUNT];
	double		dBeamPathZAxisPos2[BEAMPATH_COUNT];
	BOOL		bBeamPathUseTophat[BEAMPATH_COUNT];
	BOOL		bBeamPathLaserPath[BEAMPATH_COUNT];
	//BOOL		bBeamPathUseAom[BEAMPATH_COUNT];
	TCHAR		strBeamPathAscFile[BEAMPATH_COUNT][256];
	double		dBeamPathVoltage1[BEAMPATH_COUNT];
	double		dBeamPathVoltage2[BEAMPATH_COUNT];
	
	//Power Offset
	double		dPowOffsetDuty[BEAMPATH_COUNT];
	double		dPowOffsetAomDelay[BEAMPATH_COUNT];
	double		dPowOffsetAomDuty[BEAMPATH_COUNT];
	double		dPowOffsetAomDual1[BEAMPATH_COUNT];
	double		dPowOffsetAomDual2[BEAMPATH_COUNT];
	double		dPowOffsetVoltage1[BEAMPATH_COUNT];
	double		dPowOffsetVoltage2[BEAMPATH_COUNT];

	
	//Power Compensation
	int			nSelectShot[BEAMPATH_COUNT];
	int			nPowCompensationFrequency[BEAMPATH_COUNT];
	double		dPowCompensationDuty[BEAMPATH_COUNT];
	double		dPowCompensationAomDelay[BEAMPATH_COUNT];
	double		dPowCompensationAomDuty[BEAMPATH_COUNT];
	double		dPowCompensationTargetMax[BEAMPATH_COUNT];
	double		dPowCompensationTargetMin[BEAMPATH_COUNT];
	double		dPowCompensationDutyOffset[BEAMPATH_COUNT];
	double		dPowCompensationTarget[BEAMPATH_COUNT];
	double		dPowCompensationTargetPercent[BEAMPATH_COUNT];
	TCHAR		strPowCompensationAomFile[256];
	
	//Scanner ���� 
	double		dScannerDuty[BEAMPATH_COUNT];

	double		dScannerFrq[BEAMPATH_COUNT];


//	double		dScannerAom[BEAMPATH_COUNT];
	double		dScannerAomDuty[BEAMPATH_COUNT];
	double		dScannerAomdelay[BEAMPATH_COUNT];
	int			nScannerTotalShot[BEAMPATH_COUNT];
//	double		dScannerHoleSize[BEAMPATH_COUNT];
	int			nScannerVisionCam[BEAMPATH_COUNT];				// ���� ī�޶�
	double		dScannerVisionModelSize[BEAMPATH_COUNT];
	int			nScannerPolarity[BEAMPATH_COUNT];
	double		dScannerAcceptScoreSize[BEAMPATH_COUNT];
	double		dScannerAcceptScoreRatio[BEAMPATH_COUNT];
	double		dScannerContrast[BEAMPATH_COUNT];
	double		dScannerBrightness[BEAMPATH_COUNT];


	int			nScannerRing[BEAMPATH_COUNT];
	int			nScannerCoaxial[BEAMPATH_COUNT];
	int			nScannerIR[BEAMPATH_COUNT];

	int			nScannerRing2[BEAMPATH_COUNT];
	int			nScannerCoaxial2[BEAMPATH_COUNT];
	int			nScannerIR2[BEAMPATH_COUNT];


	int			nScannerRing3[BEAMPATH_COUNT];
	int			nScannerCoaxial3[BEAMPATH_COUNT];
	int			nScannerIR3[BEAMPATH_COUNT];

	int			nScannerRing4[BEAMPATH_COUNT];
	int			nScannerCoaxial4[BEAMPATH_COUNT];
	int			nScannerIR4[BEAMPATH_COUNT];




	double		dScannerJumpDelay;				//1000����
	//int			nScannerDrillMethod;
	
	//Hole Find
	int			nHoleVisionCam[BEAMPATH_COUNT];				// ���� ī�޶�
	double		dHoleVisionModelSize[BEAMPATH_COUNT];
	int			nHolePolarity[BEAMPATH_COUNT];
	double		dHoleAcceptScoreSize[BEAMPATH_COUNT];
	double		dHoleAcceptScoreRatio[BEAMPATH_COUNT];
	double		dHoleContrast[BEAMPATH_COUNT];
	double		dHoleBrightness[BEAMPATH_COUNT];
	int			nHoleRing[BEAMPATH_COUNT];
	int			nHoleCoaxial[BEAMPATH_COUNT];
	int			nHoleIR[BEAMPATH_COUNT];


	int			nFixedMask;						//Fixed mask2 Position ��ü��
	
} SBEAMPATH;

