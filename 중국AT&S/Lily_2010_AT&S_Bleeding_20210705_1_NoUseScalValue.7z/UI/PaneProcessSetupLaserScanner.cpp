// PaneProcessSetupLaserScanner.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupLaserScanner.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\PenFile.h"
#include "..\model\DProcessINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupLaserScanner

IMPLEMENT_DYNCREATE(CPaneProcessSetupLaserScanner, CFormView)

CPaneProcessSetupLaserScanner::CPaneProcessSetupLaserScanner()
	: CFormView(CPaneProcessSetupLaserScanner::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupLaserScanner)
	//}}AFX_DATA_INIT

//	m_sProcessLaserScanner.sPenData.nDrawStep		= 20;
//	m_sProcessLaserScanner.sPenData.nStepPeriod		= 20;
//	m_sProcessLaserScanner.sPenData.nJumpStep		= 200;
//	m_sProcessLaserScanner.sPenData.nJumpDelay		= 600;
//	m_sProcessLaserScanner.sPenData.nLaserOnDelay	= 400;
//	m_sProcessLaserScanner.sPenData.nLaserOffDelay	= 350;
//	m_sProcessLaserScanner.sPenData.nCycleTime		= 1;
//	m_sProcessLaserScanner.sPenData.nScannerJDelay  = 1000;
//	m_sProcessLaserScanner.sPenData.nPulseFrequency  = 1000;
//	m_sProcessLaserScanner.nShotCount		= 0;
	m_strTotalShot			= _T("0");
}

CPaneProcessSetupLaserScanner::~CPaneProcessSetupLaserScanner()
{
}

void CPaneProcessSetupLaserScanner::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupLaserScanner)
//	DDX_Control(pDX, IDC_EDIT_STEP_PERIOD, m_edtStepPeriod);
//	DDX_Control(pDX, IDC_EDIT_LASER_ON_DELAY, m_edtLaserOnDelay);
//	DDX_Control(pDX, IDC_EDIT_JUMP_STEP, m_edtJumpStep);
//	DDX_Control(pDX, IDC_EDIT_JUMP_DELAY, m_edtJumpDelay);
//	DDX_Control(pDX, IDC_EDIT_CYCLE_TIME, m_edtCycleTime);
//	DDX_Control(pDX, IDC_EDIT_SCANNER_JUMP_DELAY, m_edtScannerJDelay);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_MODULATION_TIME, m_edtPreheatModulationTime);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_TIME, m_edtPreheatTime);
//	DDX_Control(pDX, IDC_EDIT_PULSE_FREQUENCY, m_edtPulseFrequency);
//	DDX_Control(pDX, IDC_STATIC_PEN_PATH, m_stcPenPath);
	DDX_Control(pDX, IDC_BUTTON_RESET_TOTAL_SHOTS, m_btnResetTotalShots);
//	DDX_Control(pDX, IDC_BUTTON_PARAM_SAVE, m_btnPenSave);
//	DDX_Control(pDX, IDC_BUTTON_PARAM_OPEN, m_btnPenOpen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupLaserScanner, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupLaserScanner)
//	ON_BN_CLICKED(IDC_BUTTON_PARAM_OPEN, OnButtonParamOpen)
//	ON_BN_CLICKED(IDC_BUTTON_PARAM_SAVE, OnButtonParamSave)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOTAL_SHOTS, OnButtonResetTotalShots)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupLaserScanner diagnostics

#ifdef _DEBUG
void CPaneProcessSetupLaserScanner::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupLaserScanner::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupLaserScanner message handlers

void CPaneProcessSetupLaserScanner::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
}

BOOL CPaneProcessSetupLaserScanner::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupLaserScanner::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Pen Open
//	m_btnPenOpen.SetFont( &m_fntBtn );
//	m_btnPenOpen.SetFlat( FALSE );
	//m_btnPenOpen.SetImageOrg( 10, 3 );
//	m_btnPenOpen.SetIcon( IDI_OPEN, 32, 32 );
//	m_btnPenOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
//	m_btnPenOpen.EnableBallonToolTip();
//	m_btnPenOpen.SetToolTipText( _T("Pen File Open") );
//	m_btnPenOpen.SetBtnCursor( IDC_HAND_1 );

	// Pen Save
//	m_btnPenSave.SetFont( &m_fntBtn );
//	m_btnPenSave.SetFlat( FALSE );
	//m_btnPenSave.SetImageOrg( 10, 3 );
//	m_btnPenSave.SetIcon( IDI_SAVE, 32, 32 );
//	m_btnPenSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
//	m_btnPenSave.EnableBallonToolTip();
//	m_btnPenSave.SetToolTipText( _T("Pen File Save") );
//	m_btnPenSave.SetBtnCursor( IDC_HAND_1 );

	// Reset Total Shots
	m_btnResetTotalShots.SetFont( &m_fntBtn );
	m_btnResetTotalShots.SetFlat( FALSE );
	m_btnResetTotalShots.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTotalShots.EnableBallonToolTip();
	m_btnResetTotalShots.SetToolTipText( _T("Reset total shots") );
	m_btnResetTotalShots.SetBtnCursor( IDC_HAND_1 );
}

void CPaneProcessSetupLaserScanner::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Power Setting
//	GetDlgItem(IDC_STATIC_PARAM_SETTING)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_STEP_PERIOD)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_JUMP_STEP)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_JUMP_DELAY)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_LASER_ON_DELAY)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_CYCLE_TIME)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_SCANNER_JUMP_DELAY)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_PULSE_FREQUENCY)->SetFont( &m_fntStatic );
//	m_stcPenPath.SetFont( &m_fntStatic );
//	m_stcPenPath.SetForeColor( VALUE_FORE_COLOR );
//	m_stcPenPath.SetBackColor( VALUE_BACK_COLOR );

	// Total Shots Setting
	GetDlgItem(IDC_STATIC_TOTAL_SHOTS_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_SHOTS_MSG)->SetFont( &m_fntStatic );

	// Laser Preheat
	GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_MODULATION_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME)->SetFont( &m_fntStatic );
}

void CPaneProcessSetupLaserScanner::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Step Period
//	m_edtStepPeriod.SetFont( &m_fntEdit );
//	m_edtStepPeriod.SetForeColor( BLACK_COLOR );
//	m_edtStepPeriod.SetBackColor( WHITE_COLOR );
//	m_edtStepPeriod.SetReceivedFlag( 1 );
//	m_edtStepPeriod.SetWindowText( _T("20") );

	// Jump Step
//	m_edtJumpStep.SetFont( &m_fntEdit );
//	m_edtJumpStep.SetForeColor( BLACK_COLOR );
//	m_edtJumpStep.SetBackColor( WHITE_COLOR );
//	m_edtJumpStep.SetReceivedFlag( 1 );
//	m_edtJumpStep.SetWindowText( _T("200") );

	// Jump Delay
//	m_edtJumpDelay.SetFont( &m_fntEdit );
//	m_edtJumpDelay.SetForeColor( BLACK_COLOR );
//	m_edtJumpDelay.SetBackColor( WHITE_COLOR );
//	m_edtJumpDelay.SetReceivedFlag( 1 );
//	m_edtJumpDelay.SetWindowText( _T("600") );

	// Laser On Delay
//	m_edtLaserOnDelay.SetFont( &m_fntEdit );
//	m_edtLaserOnDelay.SetForeColor( BLACK_COLOR );
//	m_edtLaserOnDelay.SetBackColor( WHITE_COLOR );
//	m_edtLaserOnDelay.SetReceivedFlag( 1 );
//	m_edtLaserOnDelay.SetWindowText( _T("400") );

	// Cycle Time
//	m_edtCycleTime.SetFont( &m_fntEdit );
//	m_edtCycleTime.SetForeColor( BLACK_COLOR );
//	m_edtCycleTime.SetBackColor( WHITE_COLOR );
//	m_edtCycleTime.SetReceivedFlag( 1 );
//	m_edtCycleTime.SetWindowText( _T("1") );

	// Scanner Jump Delay
//	m_edtScannerJDelay.SetFont( &m_fntEdit );
//	m_edtScannerJDelay.SetForeColor( BLACK_COLOR );
//	m_edtScannerJDelay.SetBackColor( WHITE_COLOR );
//	m_edtScannerJDelay.SetReceivedFlag( 1 );
//	m_edtScannerJDelay.SetWindowText( _T("1000") );
	
	// Pulse Frequency
//	m_edtPulseFrequency.SetFont( &m_fntEdit );
//	m_edtPulseFrequency.SetForeColor( BLACK_COLOR );
//	m_edtPulseFrequency.SetBackColor( WHITE_COLOR );
//	m_edtPulseFrequency.SetReceivedFlag( 1 );
//	m_edtPulseFrequency.SetWindowText( _T("1000") );

	// Preheat Modulation Time
	m_edtPreheatModulationTime.SetFont( &m_fntEdit );
	m_edtPreheatModulationTime.SetForeColor( BLACK_COLOR );
	m_edtPreheatModulationTime.SetBackColor( WHITE_COLOR );
	m_edtPreheatModulationTime.SetReceivedFlag( 1 );
	m_edtPreheatModulationTime.SetWindowText( _T("8") );

	// Preheat Time
	m_edtPreheatTime.SetFont( &m_fntEdit );
	m_edtPreheatTime.SetForeColor( BLACK_COLOR );
	m_edtPreheatTime.SetBackColor( WHITE_COLOR );
	m_edtPreheatTime.SetReceivedFlag( 1 );
	m_edtPreheatTime.SetWindowText( _T("60") );
}

/*
void CPaneProcessSetupLaserScanner::OnButtonParamOpen() 
{
	TCHAR BASED_CODE szFilter[] = _T("Pen Files (*.pen)|*.pen|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, _T("*.pen"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();

	if(IDOK != dlg.DoModal())
	{
		return;
	}

	CPenFile clsPen;
	SPENDATA sPenData;

	memset( &sPenData, 0, sizeof(sPenData) );
	if( FALSE == clsPen.OpenPenFile( dlg.GetPathName(), sPenData ) )
		return;

	memcpy( &m_sProcessLaserScanner.sPenData, &sPenData, sizeof(sPenData) );

	SetPenData();

	m_stcPenPath.SetWindowText( (LPCTSTR)dlg.GetPathName() );
	_stprintf_s( m_sProcessLaserScanner.szPenName, "%s", dlg.GetPathName() );
}

void CPaneProcessSetupLaserScanner::OnButtonParamSave() 
{
	TCHAR BASED_CODE szFilter[] = _T("Pen Files (*.pen)|*.pen|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(FALSE, _T("*.pen"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();

	if(IDOK != dlg.DoModal())
	{
		return;
	}

	GetPenData();

	CPenFile clsPen;

	if( FALSE == clsPen.SavePenFile( dlg.GetPathName(), m_sProcessLaserScanner.sPenData ) )
		return;

	m_stcPenPath.SetWindowText( (LPCTSTR)dlg.GetPathName() );
	_stprintf_s( m_sProcessLaserScanner.szPenName, "%s", dlg.GetPathName() );
}
*/

void CPaneProcessSetupLaserScanner::OnButtonResetTotalShots() 
{
	if( IDNO == ErrMessage(IDS_RESET_TOTAL_SHOTS, MB_YESNO | MB_ICONQUESTION) )
		return;

	CString strData, strMessage;
	strMessage.Format(_T("Reset Total Shots to 0"));

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));
				
	strData.Format(_T("0"));
	SetDlgItemText(IDC_STATIC_TOTAL_SHOTS_MSG, strData );
}

HBRUSH CPaneProcessSetupLaserScanner::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_TOTAL_SHOTS_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
//			GetDlgItem(IDC_STATIC_PARAM_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneProcessSetupLaserScanner::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupLaserScanner::SetProcessLaserScannerData(SPROCESSLASERSCANNER sData)
{
	memcpy( &m_sProcessLaserScanner, &sData, sizeof(sData) );

	DispProcessLaserScannerData();
}

void CPaneProcessSetupLaserScanner::GetProcessLaserScannerData(SPROCESSLASERSCANNER* pData)
{
	memcpy( pData, &m_sProcessLaserScanner, sizeof(m_sProcessLaserScanner) );
}

void CPaneProcessSetupLaserScanner::SetPenData()
{
	CString strData;

	// Step Period
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nStepPeriod);
//	m_edtStepPeriod.SetWindowText( (LPCTSTR)strData );

	// Jump Step
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nJumpStep);
//	m_edtJumpStep.SetWindowText( (LPCTSTR)strData );

	// Jump Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nJumpDelay);
//	m_edtJumpDelay.SetWindowText( (LPCTSTR)strData );

	// Laser On Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nLaserOnDelay);
//	m_edtLaserOnDelay.SetWindowText( (LPCTSTR)strData );

	// Cycle Time
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nCycleTime);
//	m_edtCycleTime.SetWindowText( (LPCTSTR)strData );

	// Scanner Jump Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nScannerJDelay);
//	m_edtScannerJDelay.SetWindowText( (LPCTSTR)strData );

	// Pulse Frequency
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nPulseFrequency);
//	m_edtPulseFrequency.SetWindowText( (LPCTSTR)strData );

	// Preheat Modulation Time
//	strData.Format(_T("%d"), m_sProcessLaserScanner.nPreheatModulationTime);
//	m_edtPreheatModulationTime.SetWindowText( (LPCTSTR)strData );
	
	// Preheat Time
//	strData.Format(_T("%d"), m_sProcessLaserScanner.nPreheatTime);
//	m_edtPreheatTime.SetWindowText( (LPCTSTR)strData );
}

void CPaneProcessSetupLaserScanner::GetPenData()
{
	CString strData;

	// Step Period
//	m_edtStepPeriod.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nStepPeriod		= atoi( (LPSTR)(LPCTSTR)strData );

	// Jump Step
//	m_edtJumpStep.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nJumpStep		= atoi( (LPSTR)(LPCTSTR)strData );

	// Jump Delay
//	m_edtJumpDelay.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nJumpDelay		= atoi( (LPSTR)(LPCTSTR)strData );

	// Laser On Delay
//	m_edtLaserOnDelay.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nLaserOnDelay	= atoi( (LPSTR)(LPCTSTR)strData );

	// Cycle Time
//	m_edtCycleTime.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nCycleTime		= atoi( (LPSTR)(LPCTSTR)strData );

	// Scanner Jump Delay
//	m_edtScannerJDelay.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nScannerJDelay	= atoi( (LPSTR)(LPCTSTR)strData );

	// Pulse Frequency
//	m_edtPulseFrequency.GetWindowText( strData );
//	m_sProcessLaserScanner.sPenData.nPulseFrequency	= atoi( (LPSTR)(LPCTSTR)strData );

	// Preheat Modulation Time
//	m_edtPreheatModulationTime.GetWindowText( strData );
//	m_sProcessLaserScanner.nPreheatModulationTime = atoi( (LPSTR)(LPCTSTR)strData );

	// Preheat Time
//	m_edtPreheatTime.GetWindowText( strData );
//	m_sProcessLaserScanner.nPreheatTime = atoi( (LPSTR)(LPCTSTR)strData );
}

void CPaneProcessSetupLaserScanner::InitTotalShot()
{
	CString strTotalShot = _T("0");

	::AfxGetApp()->WriteProfileString("TOTAL SHOT", "TOTAL SHOT", (LPCTSTR)strTotalShot);
}

CString CPaneProcessSetupLaserScanner::GetTotalShot()
{
	CString strTotalShot;

	strTotalShot = ::AfxGetApp()->GetProfileString("TOTAL SHOT", "TOTAL SHOT", _T("0"));

	return strTotalShot;
}

void CPaneProcessSetupLaserScanner::MakeReadableNumber(CString& strVal)
{
	int nLen = strVal.GetLength();

	if (nLen <= 3)
		return;
	else
	{
		for( int nComma = nLen - 3; nComma > 0; nComma -= 3)
			strVal.Insert(nComma, _T(','));
	}
}

void CPaneProcessSetupLaserScanner::DispProcessLaserScannerData()
{
	CString strData;

	// Parameter Setting
//	m_stcPenPath.SetWindowText( m_sProcessLaserScanner.szPenName );

	// Step Period
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nStepPeriod);
//	m_edtStepPeriod.SetWindowText( (LPCTSTR)strData );

	// Jump Step
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nJumpStep);
//	m_edtJumpStep.SetWindowText( (LPCTSTR)strData );

	// Jump Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nJumpDelay);
//	m_edtJumpDelay.SetWindowText( (LPCTSTR)strData );

	// Laser On Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nLaserOnDelay);
//	m_edtLaserOnDelay.SetWindowText( (LPCTSTR)strData );

	// Cycle Time
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nCycleTime);
//	m_edtCycleTime.SetWindowText( (LPCTSTR)strData );

	// Scanner Jump Delay
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nScannerJDelay);
//	m_edtScannerJDelay.SetWindowText( (LPCTSTR)strData );

	// Pulse Frequency
//	strData.Format(_T("%d"), m_sProcessLaserScanner.sPenData.nPulseFrequency);
//	m_edtPulseFrequency.SetWindowText( (LPCTSTR)strData );

	// Total Shot
//	strData.Format(_T("%I64d"), m_sProcessLaserScanner.nShotCount);
	MakeReadableNumber( strData );
	SetDlgItemText(IDC_STATIC_TOTAL_SHOTS_MSG, (LPCTSTR)strData );

	// Preheat Modulation TIme
//	strData.Format(_T("%d"), m_sProcessLaserScanner.nPreheatModulationTime);
	m_edtPreheatModulationTime.SetWindowText( (LPCTSTR)strData );

	// Preheat Time
//	strData.Format(_T("%d"), m_sProcessLaserScanner.nPreheatTime);
	m_edtPreheatTime.SetWindowText( (LPCTSTR)strData );
}

void CPaneProcessSetupLaserScanner::OnApply()
{
	UpdateData(TRUE);

	CString strData;

	// Pen File Path
//	m_stcPenPath.GetWindowText( strData );
//	_stprintf_s( m_sProcessLaserScanner.szPenName, "%s", strData );

//	GetPenData();
}

CString CPaneProcessSetupLaserScanner::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	
	return strMessage;
}
