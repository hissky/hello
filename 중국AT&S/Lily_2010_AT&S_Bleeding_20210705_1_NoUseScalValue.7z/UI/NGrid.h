#ifndef __NGrid
#define __NGrid
namespace NGrid
{
	enum enumGrid { grid3x3, grid5x5, grid9x9, grid17x17, grid33x33, grid65x65 };
};
#endif // __NGrid