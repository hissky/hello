// DlgAddFiducial.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAddFiducial.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAddFiducial dialog


CDlgAddFiducial::CDlgAddFiducial(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAddFiducial::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAddFiducial)
	m_dX = 0.0;
	m_dY = 0.0;
	//}}AFX_DATA_INIT
}


void CDlgAddFiducial::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAddFiducial)
	DDX_Text(pDX, IDC_EDT_X, m_dX);
	DDX_Text(pDX, IDC_EDT_Y, m_dY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAddFiducial, CDialog)
	//{{AFX_MSG_MAP(CDlgAddFiducial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAddFiducial message handlers

void CDlgAddFiducial::OnOK() 
{
	// TODO: Add extra validation here
	
	UpdateData();
	CDialog::OnOK();
}

void CDlgAddFiducial::SetData(int nX, int nY)
{
	m_dX = ((int)(nX / 1000.0 * 1000)) / 1000.0;
	m_dY = ((int)(nY / 1000.0 * 1000)) / 1000.0;
}

BOOL CDlgAddFiducial::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
