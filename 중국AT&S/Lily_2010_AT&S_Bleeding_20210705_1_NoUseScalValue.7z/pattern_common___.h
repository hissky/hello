#pragma once

#define MAX_OPC_CONTROL_ITEM		(256)

#define OPC_TAG_NONE				0
#define OPC_TAG_DISCRETE			1
#define OPC_TAG_ANALOG				2
#define OPC_TAG_ASCII				3
#define OPC_TAG_VARIANT				4

#define MAX_STR_LEN_QUE				1024*10

typedef struct _stOPCServer {
	int nItem;
	int nInvalidItem;
	int nClient; // current OPC clinet ����
	int nDllAttach; // PATTERN ������ RUN 
} ST_OPCSERVER;

typedef struct _stTag {
	int nIndex;
	int nInvalid;
	int nTagType;
	char szName[64];
	
	int nQuality; // 1(GOOD), 0(BAD)
	double d_value;
	char c_value[MAX_STR_LEN_QUE];

	int nUpdate; // dll���� ������...
	DWORD dwUpdate;

	void *pTag; // opc server(exe)������ ���, dll������ ������..
} ST_TAG;

typedef struct _stCtrlItem {
	int nIndex;
	int nTagType;
	double d_value;
	char c_value[MAX_STR_LEN_QUE];
} ST_CTRL_ITEM, *LPST_CTRL_STRING;

typedef struct _stControlQueue {
	int		nHead;
	int		nTail;
	ST_CTRL_ITEM Item[MAX_OPC_CONTROL_ITEM];
} ST_CONTROL_QUEUE, *LPST_CONTROL_QUEUE;