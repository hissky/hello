// DHwOption.cpp: implementation of the DHwOption class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DHwOption.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DHwOption::DHwOption()
{
	m_nUseDualPanel			= 1; // 0 : Single, 1 : Dual
	m_nCalibrationType		= 1; // 0 : BiLinear, 1 : BiCubic, 2 : BiCubicSpline
	m_nMotorType			= 1; // 0 : MP-Series, 1 : UMAC, 2 : ComiZoa
	m_nCameraNum			= 4;
	m_nHeightSensorNum		= 1;
	m_nScannerHeadNum		= 2;
	
	m_nRepeatMode = 1; //  Repeat ��� On : ���α׷� ���۽� �ڵ����� ���� file�� �����Ѵ�.
	m_nMGCMode = 0;
}

DHwOption::~DHwOption()
{

}
