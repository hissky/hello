// BicubicInterpolation.h: interface for the CBicubicInterpolation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BICUBICINTERPOLATION_H__C945CEC1_B473_4254_B5D1_6E528AD370CB__INCLUDED_)
#define AFX_BICUBICINTERPOLATION_H__C945CEC1_B473_4254_B5D1_6E528AD370CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

struct COEF
{
	DPOINT dCoef[4][4];
};

class CBicubicInterpolation : public CCalibration  
{
public:
	CBicubicInterpolation();
	virtual ~CBicubicInterpolation();

protected:
	DPOINT* m_XGradient;
	DPOINT* m_YGradient;
	DPOINT* m_CrossDeriv;

	COEF* m_Coef;

	DPOINT *m_d1, *m_d2, *m_d3, *m_d4;
	int m_nXStart, m_nXEnd, m_nYStart, m_nYEnd;

	void UpdateWholeCalibration();
	
	void GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	void GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);

	BOOL MakeDerivatives();
	BOOL MakeCoefficient();
	void SetCoefficient(double* dVal, double* dXGra, double* dYGra, double* dCross, int nX, int nY, bool bIsX);

	void DeleteMemory();
};

#endif // !defined(AFX_BICUBICINTERPOLATION_H__C945CEC1_B473_4254_B5D1_6E528AD370CB__INCLUDED_)
