// HHeightSensor.h: interface for the HHeightSensor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HHEIGHTSENSOR_H__225A0DAB_46BC_4706_8709_17F7722B1003__INCLUDED_)
#define AFX_HHEIGHTSENSOR_H__225A0DAB_46BC_4706_8709_17F7722B1003__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HeightTypes.h"
#include "HeightGlobal.h"

class HHeightSensor  
{
public:
	HHeightSensor();
	virtual ~HHeightSensor();

public :
	BOOL	InitHeightSensor();
	BOOL	Load();
	BOOL	UnLoad();
	BOOL	Reset(int nNetNumber=0);

	int		Reading(double& dValue, int nNetNumber=0, int nAddress=1);
	int		SetAddress(char* chID = _T("130A129P01"), int nNetNumber = 0, int nAddress = 1);
	BOOL	GetHeightFunctionAddresses();
	int		ChoseNetwork(int nNetworks, int nNumber);

	void	SetSensorID(int nNumber, char* pID);

protected :
	HINSTANCE		m_hHeightLib;
	char			m_szSensorID[BUF_SIZE];	// Height sense ID
	char			m_szSensorID2[BUF_SIZE];	// Height sense ID

	tOrbitRst		FunReset;				// Height sense reset
	tOrbitSetaddr	FunSetAddress;			// Height sense address setting
	tOrbitRead1		FunRead;				// Height sense reading #1

	tConnectToOrbitNetworks			FunConnectNetwork;
	tGetOrbitNetworkNameAndType		FunGetNetworkNameAndType;
	tDisconnectFromOrbitNetworks	FunDisconnectFromNetworks;
};

#endif // !defined(AFX_HHEIGHTSENSOR_H__225A0DAB_46BC_4706_8709_17F7722B1003__INCLUDED_)
