/*START**************************************************************
[D:\EdgeExposureWorks\EdgeExposure\Device\VisionDll_Interface.h]
[2005/10/18 22:44] by jhheo(heo junghyun).
purpose : Vision use only release mode.
*********************************************************************/
//#ifdef _DEBUG
//#define  NO_VISION_MODE_
//#else
//#undef NO_VISION_MODE_
//#endif
/*END****************************************************************/


typedef struct 
{
	double CenterX;
	double CenterY;
	int Result;
} ReturnData;

typedef struct
{
	int status; // 0:pass , 1:fail
	char strResult[50];
} OCRReturnData;

extern ReturnData gReturnData;
extern OCRReturnData gOCRReturnData;

extern "C" int PASCAL EXPORT  StartVisionDLL(WPARAM wParam, LPARAM lParam);
extern "C" int PASCAL EXPORT  CloseVisionDLL(WPARAM wParam, LPARAM lParam);

extern "C" int PASCAL EXPORT  ViewVisionDlg(WPARAM wParam, LPARAM lParam);
extern "C" int PASCAL EXPORT  HideVisionDlg(WPARAM wParam, LPARAM lParam);

extern "C" int PASCAL EXPORT  DetectFiducial(WPARAM wParam, LPARAM lParam);
extern "C" int PASCAL EXPORT  DoInspection(HWND *pWnd, LPCTSTR strFileName, BOOL bIsRun);

extern "C" ReturnData& PASCAL EXPORT  Trigger(WPARAM wParam, LPARAM lParam, int ZoomX, int ZoomY);
extern "C" ReturnData& PASCAL EXPORT  Trigger_Agc(WPARAM wParam, LPARAM lParam, int ZoomX, int ZoomY, int startX, int startY, int szX, int szY);

extern "C" int PASCAL EXPORT  Grab(WPARAM wParam, int ZoomX, int ZoomY);
extern "C" void PASCAL EXPORT LiveStop();
extern "C" int PASCAL EXPORT LiveImage(HWND hViewWnd, UINT uChannel, int ZoomFactor, BOOL bLive);
extern "C" void PASCAL EXPORT GrabContinuous(WPARAM wParam, int ZoomX, int ZoomY);
extern "C" int PASCAL EXPORT DisplayLiveMode(WPARAM wParam, int Number);
extern "C" void PASCAL EXPORT Refresh(WPARAM wParam, int Number, int ZoomX, int ZoomY);

extern "C" int PASCAL EXPORT LoadJobFile(char *strFullPath);
extern "C" int PASCAL EXPORT  LoadMapFile(char* strFullPath);
extern "C" char* PASCAL EXPORT JobFileName();
extern "C" void PASCAL EXPORT CenterOffset(double CenterOffX, double CenterOffY);

extern "C" int PASCAL EXPORT SaveImageFile(char *strFullPath, int sceneNumber);
extern "C" int PASCAL EXPORT ChangeChannel(WPARAM wParam, LPARAM lParam);
extern "C" int PASCAL EXPORT SaveAllImageFile(char *strFullPath);

extern "C" void EXPORT SuperUser(BOOL bUser);

#define UM_VISION_DLL_SETUP_PANE_IS_DISPLAYED (WM_USER + 301)

