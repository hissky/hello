#if !defined(AFX_PROCESSDATA_H__46003D1A_AEE3_4A1C_BE11_5EF8764B22CF__INCLUDED_)
#define AFX_PROCESSDATA_H__46003D1A_AEE3_4A1C_BE11_5EF8764B22CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProcessData.h : header file

typedef struct _CAM_NO {
	int			CamNo[4];  //display�� 4��
} CAM_NO;
//

typedef struct _PMALIGN_DATA {
	double						X;
	double						Y;
	double						DisXOffsetHigh;
	double						DisXOffsetLow;
	double						DisYOffsetHigh;
	double						DisYOffsetLow;
} PMALIGN_DATA;

typedef struct _RESULT_DATA {
	double						dx;
	double						dy;
	double						dDistanceX;
	double						dDistanceY;
	double						dCaliDist;
} RESULT_DATA;

/////////////////////////////////////////////////////////////////////////////
// ProcessData window

class ProcessData : public CWnd
{
// Construction
public:
	ProcessData();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ProcessData)
	//}}AFX_VIRTUAL

// Implementation
public:
	PMALIGN_DATA	m_AlignData[MAX_CAMERA+2];
	RESULT_DATA		m_ResultData[MAX_CAMERA+2];
	CAM_NO			m_CamNo;
	CString m_strFileName;
	void GetTrainCoord(double cx, double cy, int PatternNo);
	virtual ~ProcessData();

	// Generated message map functions
protected:
	//{{AFX_MSG(ProcessData)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROCESSDATA_H__46003D1A_AEE3_4A1C_BE11_5EF8764B22CF__INCLUDED_)
