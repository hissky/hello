// HVisionTCP_Cognex.h: interface for the HVisionTCP_Cognex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVisionTCP_Cognex_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)
#define AFX_HVisionTCP_Cognex_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CClientSock_Cognex;

class HVisionTCP_Cognex  
{
public:


	BOOL OnCamChange(int nCamNo);
	BOOL OnAcquire(int nCamNo);
	BOOL OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness);
	BOOL OnContrast(int nCamNo, double dContrast);
	BOOL OnBrightness(int nCamNo, double dBrightness);
	BOOL SaveImg(int nCamNo, CString strFilePathName);
	BOOL OnLive(int nCamNo, BOOL bIsLive);
	BOOL OnApplyVisionParameter(int nID, int nCamNo, VISION_INFO sVisionInfo);
	BOOL OnApplyVisionParam(int nID,  int nCamNo, SVISIONINFO sVisionInfo);
	BOOL LoadOptionFile(int nType);
	//int GetRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pChar, BOOL bFindPattern);
	BOOL ShowArea(int nShow, int nPatternNo, int nCam);
	BOOL SetInspectionArea(int nSize, int nCam);
	BOOL SetInspectionAreaPercent(double nPercent, int nCam);
	BOOL SetAcceptScore(double dVal);
	BOOL GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo);
	BOOL ClearInteractiveGraphics(int nCam);
	BOOL TransformPixel();
	BOOL PMToolFind(int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag );
	BOOL InitVisionPixelData(int nCam);
	BOOL InitDistancePerPixel();
	BOOL GetNoGrabRealPosFor4Way(int nCam, int nIndex);


	BOOL ReConnect();
	BOOL InitMatroxTCP();
	BOOL ConnectStatus();

	HVisionTCP_Cognex();
	virtual ~HVisionTCP_Cognex();

	CClientSock_Cognex*	m_pClientSock_Cognex;
};

#endif // !defined(AFX_HVisionTCP_Cognex_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)
