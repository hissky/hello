// HLaserAttenuator.h: interface for the HLaserAttenuator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASERATTENUATOR_H__8F0CFA62_F4B1_4DAD_A145_EA3E3F63BB29__INCLUDED_)
#define AFX_HLASERATTENUATOR_H__8F0CFA62_F4B1_4DAD_A145_EA3E3F63BB29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#ifdef __MP920_MOTOR__
	class HMotor;
#else
	class DeviceMotor;
#endif
class HLaserAttenuator  
{
public:
	BOOL MoveIndex(int nIndex);
	CString GetError();
	BOOL IsInposition();
	int GetCurrentStatus();
	int GetCurrentPos();
	BOOL MoveStop();
	BOOL Move(int nPulse);
	BOOL HomingCmd();
	BOOL ChangePort();

#ifdef __MP920_MOTOR__
	HMotor* m_pMotor;
	BOOL Initialize(HMotor* pMotor);
#else
	DeviceMotor* m_pMotor;
	BOOL Initialize(DeviceMotor* pMotor);
#endif
	HLaserAttenuator();
	virtual ~HLaserAttenuator();

	BOOL		m_bInit;
	BOOL		m_bAutoRun;
	BOOL		m_bDryRunMode;
	int			m_nCmdPos;

};

#endif // !defined(AFX_HLASERATTENUATOR_H__8F0CFA62_F4B1_4DAD_A145_EA3E3F63BB29__INCLUDED_)
