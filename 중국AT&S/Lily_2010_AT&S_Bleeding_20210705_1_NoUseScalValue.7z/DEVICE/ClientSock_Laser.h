#if !defined(AFX_ClientSock_Laser_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
#define AFX_ClientSock_Laser_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientSock_Laser.h : header file
//

#include <afxsock.h>


#define WM_CLIENT_CONNECT			WM_USER + 776
#define WM_CLIENT_RECEIVE			WM_USER + 777
#define WM_CLIENT_CLOSE				WM_USER + 778

#define SEND_OK_			0
#define TIME_OUT_			100
#define SEND_FAIL_			101
#define RETURN_FAIL_		102

/////////////////////////////////////////////////////////////////////////////
// CClientSock_Laser command target

class CClientSock_Laser : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	BOOL	m_bConnect;
	int		m_nLaserNo;
	
	void SetWnd(HWND hWnd);

	CClientSock_Laser();
	virtual ~CClientSock_Laser();

// Overrides
public:
	CString PasingResult(CString strReceive, int nIndex);
	int PasingStatusResult(CString strReceive, int nIndex);
	
	CString GetLaserTCPTemp(int nTempIndex = 0);
	int GetLaserTCPStatus();
	void SendACK();
	void SendNAK();
	int ReceiveData();
	BOOL Connect(LPCTSTR lpszHostAddress, UINT nHostPort);
	void ReConnectTry();
	void CloseSocket();
	CString m_strLaserStatus;
	CString m_strLaserStatus2;
	int		m_nLaserStatus;
	int m_nReceiveCount;
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientSock_Laser)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CClientSock_Laser)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:

private:
	HWND m_hWnd;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ClientSock_Laser_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
