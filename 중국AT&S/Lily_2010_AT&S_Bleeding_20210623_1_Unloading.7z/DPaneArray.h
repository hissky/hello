// DPaneArray.h: interface for the DPaneArray class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPANEARRAY_H__B2E5AB1A_DB94_4A62_A92E_CAE714F1D73A__INCLUDED_)
#define AFX_DPANEARRAY_H__B2E5AB1A_DB94_4A62_A92E_CAE714F1D73A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef CTypedPtrArray<CPtrArray, CFormView *> CPaneArray;

class DPaneArray  
{
public:
	DPaneArray();
	virtual ~DPaneArray();

public :	// Operation
	void		SetCurrentPaneIndex(int nIdx)	{ m_nCurrentPaneIndex = nIdx; }
	int			GetCurrentPaneIndex()			{ return m_nCurrentPaneIndex; }

	CFormView*	CreatePane(CWnd* pParentWnd, CRect rcPanePos, CRuntimeClass* pRuntimeClass, UINT nIndex);
	void		SelectPane(int nIdx);

	void		AddPane(CFormView* pPane);
	int			GetPaneSize()					{ return m_aryPane.GetSize(); }
	CFormView*	GetPane(int nIdx);

protected :	// Operation

protected :	// Attribute
	CPaneArray		m_aryPane;
	CFormView*		m_pCurrentPane;
	int				m_nCurrentPaneIndex;
};

#endif // !defined(AFX_DPANEARRAY_H__B2E5AB1A_DB94_4A62_A92E_CAE714F1D73A__INCLUDED_)
