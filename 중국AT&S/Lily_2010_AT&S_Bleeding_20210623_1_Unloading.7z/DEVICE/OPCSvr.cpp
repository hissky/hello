// OPCSvr.cpp : implementation file
//

#include "stdafx.h"
#include "OPCSvr.h"
#include "..\EasyDriller.h"
#include "..\EasyDrillerDlg.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "..\MODEL\DSystemINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define SQLMAXLEN 2048

OPCPARAM gOPCParam;

#define UM_WRITE_OPC_LOG	WM_USER+260

UINT GetControlThread(LPVOID pParam)
{
	COPCSvr* pMain = (COPCSvr*)pParam;
	CString strValue = _T("");
	CString strRecipe = _T("");
	ST_CTRL_ITEM ctrl;
	CString strLog;
	int nConnect1 = 0, nConnect2 = 0;
	int nOldConnect1 = -1, nOldConnect2 = -1;
	int nResetCount1 = 0, nResetCount2 = 0;
	do  //1�ʿ� 2�� 
	{

		int nVal = pMain->pGetControl(&ctrl); 
		if(	nVal > 0)
		{
			ctrl.nIndex +=1; //������ +1 �ٶ� -1 �ؾ� index�� ���� 
#ifdef __TEST__
	//	ctrl.nIndex = 28;
	//	strcpy(ctrl.cValue, "121553;AAAAAAAAA;PASS;;2;MES ������ ���������� Ȯ���Ͽ����ϴ�!!;0;A11-111-11;B1;;;;;;;;;;;;;;;;;;;;");

		//
	//	ctrl.nIndex = 118;
	//	strcpy(ctrl.cValue, "124311;1;ZZ7654321;1;;;;;;;;;;;;;;;;;;;");
	
	//		ctrl.nIndex = 123;
	//		strcpy(ctrl.cValue, "124319;PASS;;0");

			
#endif
			if(ctrl.nIndex == 107)  // 107 = Terminal Message : T_000_000000_00
			{
				pMain->TerminalMessage(ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE); 
			}
			else if(ctrl.nIndex == 10) //10 = Loss Error : L_000_000000_02
			{
				pMain->ParsingLossMessage(ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 12 || ctrl.nIndex == 14) // 11 = Loss Error modify L_000_000010_02 ,13 = L_000_000011_02
			{
				pMain->ModifyLossMessage(ctrl.cValue, ctrl.nIndex );
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 110)   //109 = Status S_000_000000_00
			{
//				pMain->m_strStatus = ctrl.cValue;
				pMain->ParsingStatusMessage(ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 362)	//364 = EES ���� Recipe ���� ��û
			{
				pMain->m_strRecipeDeleteFromEES = ctrl.cValue;
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->DeleteRecipeFromEES(pMain->m_strRecipeDeleteFromEES);
				pMain->m_bRecv = TRUE;
			}

			else if(ctrl.nIndex == 864)   //864 = MES ���� ó���� ���� �۾��ڰ� �Է¹޾ƾ� �ϴ� ����
			{
				pMain->m_strData1 = ctrl.cValue;
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 866)	//866 = MES ����ó����û��� ��ȯ
			{
				pMain->m_strData2 = ctrl.cValue;
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 127) // 126 MES ���� ��� ��� D_000_000003_02
			{
				pMain->m_strMESCancel = ctrl.cValue;
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 873)
			{
				pMain->m_RMSReturnData = ctrl.cValue;
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
				pMain->m_bRecv = TRUE;
			}
		/*	else if(ctrl.nIndex == 16 || ctrl.nIndex == 18)  //650 = Recipe ���� �㰡 : R_01_02, 652 : R_01_04 �̻�� 
			{
				pMain->ParsingRecipeMessage(RMS_CREATE, ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			
			else if(ctrl.nIndex == 20 || ctrl.nIndex == 22)  //461 = Recipe ���� �㰡 (01,02) : R_02_02, 650 : R_02_04
			{
				pMain->ParsingRecipeMessage(RMS_CHANGE, ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			else if(ctrl.nIndex == 24)  //23 = Recipe  ���� ���� (01,02) : R_03_02, 671 : R_13_02
			{ // ���α׷����� �������� ����
				//pMain->ParsingRecipeMessage(RMS_DELETE, ctrl.nIndex, ctrl.cValue); 
			//	pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			*/
			else if(ctrl.nIndex == 28 || ctrl.nIndex == 30) //|| ctrl.nIndex == 666 || ctrl.nIndex == 668)  //656 = Recipe  ��ȿ�� �㰡 (01,02) : R_04_08, R_04_10, // R_14_08, R_14_10,
			{
				pMain->ParsingRecipeMessage(RMS_VALIDATION,  ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 34)  //663 = Recipe  ���ε� ���� (01,02) : R_05_02
			{
				pMain->ParsingRecipeMessage(RMS_UPDATE,  ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 51)
			{
				pMain->ParsingRecipeMessage(RMS_VALIDATION,  ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
		/*	else if(ctrl.nIndex == 37 || ctrl.nIndex == 39)  //36 = Recipe �ٿ�ε� ���� (01,02) : R_06_02, R_06_04
			{
				pMain->ParsingRecipeMessage(RMS_DOWNLOAD,  ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			else if(ctrl.nIndex == 41)  //40 = Recipe List ���� (01,02) : R_07_02
			{
				pMain->ParsingRecipeMessage(RMS_LIST, ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			else if(ctrl.nIndex == 148 || ctrl.nIndex == 149)  //148 = Basket �㰡 ���� : I_000_001131_02, I_000_002131_02, I_000_001231_02, I_000_002231_02
			{
				pMain->ParsingBasketMessage(ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
			}
			*/else if(ctrl.nIndex == 461)  //461 = Basket Alarm : I_000_001131_02, I_000_002131_02, I_000_001231_02, I_000_002231_02
			{
				pMain->ParsingInOutAlarmMessage(ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 118)  //117 = Dispatch �㰡 ���� : D_000_000001_02, 
			{
				pMain->ParsingDispatchData(1, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 123 || ctrl.nIndex == 122)  //746 = Dispatch �㰡 ���� : D_000_0000002_02, D_000_000100_02
			{
				pMain->ParsingDispatchData(2, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 150 || ctrl.nIndex == 152)
			{
				pMain->ParsingHandlerAlarm(ctrl.nIndex, ctrl.cValue);
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			else if(ctrl.nIndex == 108)   // C_000_000001_00
			{
				nConnect1 = atoi(ctrl.cValue);
				//check connection 
				if(nConnect1 == nOldConnect1)
				{
					if(nResetCount1 > 20)
					{
						pMain->m_bConnection1 = FALSE;
						strLog.Format(_T("TC -> EQ | Disconnect1"));
						pMain->SaveLog(strLog);
					}
					else
						nResetCount1++;
				}
				else
				{
					pMain->m_bConnection1 = TRUE;
					nResetCount1 = 0;
					nOldConnect1 = nConnect1;
				}
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
			}
			else if(ctrl.nIndex == 109)  // C_000_000002_00
			{
				nConnect2 = atoi(ctrl.cValue);
				if(nConnect2 == nOldConnect2)
				{
					if(nResetCount2 > 20)
					{
						pMain->m_bConnection2 = FALSE;
						strLog.Format(_T("TC -> EQ | Disconnect2"));
						pMain->SaveLog(strLog);
					}
					else
						nResetCount2++;
				}
				else
				{
					pMain->m_bConnection2 = TRUE;
					nResetCount2 = 0;
					nOldConnect2 = atoi(ctrl.cValue);
				}
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue, FALSE);
			}
			else
			{
				pMain->GetTagMessage(ctrl.nIndex, ctrl.cValue);
				pMain->m_bRecv = TRUE;
			}
			if(pMain->m_bRecv)
			{
				strLog.Format(_T("TC -> EQ | %d : %s"), ctrl.nIndex, ctrl.cValue);
				pMain->SaveLog(strLog);
			}
		}
	

	} while (pMain->m_bEndThread == FALSE);

	return 0U;
}
/////////////////////////////////////////////////////////////////////////////
// COPCSvr dialog


COPCSvr::COPCSvr(CWnd* pParent /*=NULL*/)
	: CDialog(COPCSvr::IDD, pParent)
{
	//{{AFX_DATA_INIT(COPCSvr)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bPNLCheck = FALSE;

	m_nRMSType = 2;

	m_pOPC = NULL;
	m_pThread = NULL;
	m_bEndThread = FALSE;
	m_CtrlItem.nIndex = 0;
	m_CtrlItem.nTagType = 0;
	m_CtrlItem.dValue = 0;
//	m_CtrlItem.cValue = _T("");
	memset(m_CtrlItem.cValue, 0, sizeof(m_CtrlItem.cValue));
	memset(m_stOPCINI, 0, sizeof(m_stOPCINI));
//	::InitializeCriticalSection( &m_CritLog );
	m_bRecv = FALSE;
	m_nAIType = 2;
}


void COPCSvr::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COPCSvr)
//	DDX_Control(pDX, IDC_EVOPCXCTRL1, m_OpcCtrl);   20100629 bskim
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COPCSvr, CDialog)
	//{{AFX_MSG_MAP(COPCSvr)
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_MESSAGE(UM_WRITE_OPC_LOG, OnWriteOPCLog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COPCSvr message handlers

void COPCSvr::CreateActiveX()		
{
//	m_OpcCtrl.Create("OPC SERVER", WS_CHILD | WS_VISIBLE, CRect(0, 0, 100, 100), this, IDC_EVOPCXCTRL1);
//	m_OpcCtrl.ShowWindow(SW_SHOW);
}

void COPCSvr::Initialize()
{
/*	m_pOPC = &m_OpcCtrl;
	char szExe[512];
	GetModuleFileName(NULL, szExe, sizeof(szExe));
	m_pOPC->Initialize("{CE8D45AB-136C-4D2F-8DE2-785A70065355}", "SEM.OPC", "OPC SERVER", szExe"");	
*/
}

void COPCSvr::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
/*	if(m_pOPC->GetClientCount() > 0)
	{
		SetTimer(1, 100, NULL);
		return;
	}
	m_pOPC->UnInitialize();
	m_pOPC->Close();
*/
//	CDialog::OnClose();
}

void COPCSvr::TerminalMessage(CString strTerminalMessage)
{
	char szStr[1000];
	char* pToken = NULL;
	memset(szStr, 0, sizeof(szStr));
	strcpy(szStr, strTerminalMessage);
	
	int nIndex;
	nIndex = strTerminalMessage.Find(';');
	CString strTemp;
	strTemp = strTerminalMessage.Mid(nIndex+1);

	strTemp.Replace(_T(";"), _T("  "));
	CString strMessage;
	strMessage = _T("Terminal Message\n") + strTemp;
	m_dlgMessageBox.GetDlgItem(IDC_EDIT_MESSAGE)->SetWindowText(strMessage);
	m_dlgMessageBox.ShowWindow(SW_SHOW);
//	ErrMessage(_T("Terminal Message\n") + strTemp, MB_OK | MB_TOPMOST );


/*	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString str;


	if(pToken == 
	while(pToken !=NULL)
	{
		pToken == NULL;
		str.Empty();
		str.Format(_T("%s"), pToken);
		if(nCount >= 1 )
		{
			ErrMessage(_T("Terminal Message\n") + str, MB_OK | MB_TOPMOST );
			break;
		}
		nCount++;
		pToken = strtok(NULL, ";");
	}
	*/
	
}

void COPCSvr::ParsingDispatchData(int nIndex,CString strDispatch)
{
	char szStr[1000];
	char* pToken;
	strcpy(szStr, strDispatch);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString str1, str2, str3,str4;
	CString strMessage;

	while(pToken !=NULL)
	{
		if(nCount == 1 )
			str1.Format("%s", pToken);
		else if(nCount == 2)
			str2.Format("%s", pToken);
		else if(nCount == 3)
			str3.Format("%s", pToken);
		else if(nCount == 4)
			str4.Format("%s", pToken);

		nCount++;
		pToken = strtok(NULL, ";");
	}
	if(nIndex == 1) // :D_000_000001_02
	{
		m_strDispatchMessage =  str1;  //���� �Է�
		m_strDispatchMessage2 = str3; // ���� �Է�
		m_strDispatchLot2 = str2;
	}
	else if(nIndex == 2) // D_000_000002_02
	{
		m_strDispatchResult = str1;
		m_strDispatchMessage = str2;
		m_strDispatchErr = str3;
		m_strDispatchLot2 = str2;
	}
	else if(nIndex == 3) // D_O00_000003_02 �������
	{
		m_strDispatchResult = str2;
	}
	else 
	{
		m_strDispatchResult = str2;
	}

}
void COPCSvr::ParsingBasketMessage(CString strBasketMessage)
{
	char szStr[1000];
	char* pToken;
	strcpy(szStr, strBasketMessage);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString strPass;
	CString strMessage;

	while(pToken !=NULL)
	{
		if(nCount == 1 )
			strPass.Format("%s", pToken);
		else if(nCount == 2)
			strMessage.Format("%s", pToken);
		nCount++;
		pToken = strtok(NULL, ";");
	}
	m_strBasket = strPass;
	m_strMessage = strMessage;
}
void COPCSvr::ParsingLossMessage(CString strLossMessage)
{	
	m_strLossError = _T("");
	m_strLossPass = _T("");
	m_strLossResult= _T("");

	char szStr[1000];
	char* pToken;
	strcpy(szStr, strLossMessage);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString strLossCode;
	CString strPass;
	CString strResult;
		
	while(pToken !=NULL)
	{
		if(nCount == 2 )
			strLossCode.Format("%s", pToken);
		else if(nCount == 4)
			strPass.Format("%s", pToken);
		else if(nCount == 5)
			strResult.Format("%s", pToken);
		
		nCount++;
		pToken = strtok(NULL, ";");
	}
	m_strLossError = strLossCode;
	m_strLossPass = strPass;
	m_strLossResult = strResult;
}

void COPCSvr::ModifyLossMessage(CString strModifyMessage, int nIndex)
{	
	char szStr[3000];
	char* pToken;
	strcpy(szStr, strModifyMessage);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString strLossNo = _T("");
	CString strDescription = _T("");
	CString strCode = _T("");
	CString strOpcLossInfo = _T("");
	CString strPopupMessage = _T("Change Loss Info \n");
	CString strSendLossInfo = _T("");
	CString strReadLossInfo = _T("");
	CStdioFile file, file2;

	if(gSystemINI.m_sHardWare.nLanguageType == 0)
	{
		if(file.Open("d:\\viahole\\OPCLossInfo.ini", CFile::modeReadWrite| CFile::modeCreate) == FALSE)
		{
			ErrMessage(_T("OPCLossInfo.ini is wrong or can not open "));
			return;
		}
		if(file2.Open("d:\\viahole\\OPCLossInfo_backup.ini", CFile::modeReadWrite) == FALSE)
		{
			ErrMessage(_T("OPCLossInfo.ini is wrong or can not open "));
			return;
		}
		
	}
	else if(gSystemINI.m_sHardWare.nLanguageType == 1)
	{
		if(file.Open("d:\\viahole\\OPCLossInfo_C.ini", CFile::modeReadWrite| CFile::modeCreate) == FALSE)
		{
			ErrMessage(_T("OPCLossInfo.ini is wrong or can not open "));
			return;
		}
		if(file2.Open("d:\\viahole\\OPCLossInfo_backup_C.ini", CFile::modeReadWrite) == FALSE)
		{
			ErrMessage(_T("OPCLossInfo.ini is wrong or can not open "));
			return;
		}
	}
	
	
	while(pToken !=NULL)
	{
		if((nCount - 1) % 3 == 0 )
			strLossNo.Format("%s", pToken);
		else if((nCount - 1) % 3 == 1)
			strCode.Format("%s", pToken);
		else if((nCount - 1) % 3 == 2)
			strDescription.Format("%s", pToken);
		
		if(strcmp(strLossNo, "") != 0 && strcmp(strDescription, "") != 0 && strcmp(strCode, "") != 0)
		{
			
			int nNextStepLength = 0;
			int nReadCount = 0;
			BOOL bSet = FALSE;
			while(file2.ReadString(strReadLossInfo))
			{
				int nFindNo = strReadLossInfo.Find("::", 0);
				CString strReadLossNo = strReadLossInfo.Mid(0, nFindNo);
				if(strcmp(strLossNo, strReadLossNo) == 0)
				{
					strOpcLossInfo.Format("%s::%s::%s\r\n", strLossNo, strDescription, strCode);
					file.WriteString(strOpcLossInfo);
					
					CString strData;
					strData.Format("No = %s, Code Name = %s, Code = %s\n", strLossNo, strDescription, strCode);
					strPopupMessage += strData;
					
					strData.Format("%s;%s;%s", strLossNo, strCode, "Pass");
					strSendLossInfo += strData + ";";
					
					strLossNo = _T("");
					strDescription = _T("");
					strCode = _T("");
					bSet = TRUE;
				}
				else
				{
					file.WriteString(strReadLossInfo + "\r\n");
				}
				nNextStepLength += strReadLossInfo.GetLength();
				nReadCount++;
			}
			if(nReadCount == 0) //���Ͽ� ������ �ϳ��� ������
			{
				strOpcLossInfo.Format("%s::%s::%s\r\n", strLossNo, strDescription, strCode);
				file.WriteString(strOpcLossInfo);
				
				CString strData;
				strData.Format("No = %s, Code Name = %s, Code = %s\n", strLossNo, strDescription, strCode);
				strPopupMessage += strData;
				
				strData.Format("%s;%s;%s", strLossNo, strCode, "Pass");
				strSendLossInfo += strData + ";";
				
				strLossNo = _T("");
				strDescription = _T("");
				strCode = _T("");
				bSet = TRUE;
			}
			if(!bSet)
			{
				strOpcLossInfo.Format("%s::%s::%s\r\n", strLossNo, strDescription, strCode);
				file.WriteString(strOpcLossInfo);
				
				CString strData;
				strData.Format("No = %s, Code Name = %s, Code = %s\n", strLossNo, strDescription, strCode);
				strPopupMessage += strData;
				
				strData.Format("%s;%s;%s", strLossNo, strCode, "Pass");
				strSendLossInfo += strData + ";";
				
				strLossNo = _T("");
				strDescription = _T("");
				strCode = _T("");
			}
		}
		nCount++;
		pToken = strtok(NULL, ";");
	}

	file2.Close();
	file.SeekToBegin();
	if(file2.Open("d:\\viahole\\OPCLossInfo_backup.ini", CFile::modeReadWrite | CFile::modeCreate) == FALSE)
	{
		ErrMessage(_T("OPCLossInfo.ini is wrong or can not open"));
		return;
	}
	while(file.ReadString(strReadLossInfo))
	{
		file2.WriteString(strReadLossInfo + "\r\n");
	}
	file.Close();
	file2.Close();
	if(strlen((LPCTSTR)strSendLossInfo) > 1)
		strSendLossInfo = strSendLossInfo.Mid(0, strSendLossInfo.GetLength() - 1);
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex -1, reinterpret_cast<LPARAM>(&strSendLossInfo));	//10  ����->TC �����ڵ� ��Ī ���濡 ���� ����: L_000_000010_01 12 : L_000_000011_01
	ErrMessage(strPopupMessage);
}

void COPCSvr::ParsingInOutAlarmMessage(CString strInOutAlarm)
{
	char szStr[3000];
	char* pToken;
	strcpy(szStr, strInOutAlarm);
	pToken = strtok(szStr, ";");
	int nCount = 0;

	while(pToken !=NULL)
	{
		if(nCount == 1)
			m_strAlarmCode.Format("%s", pToken);
		else if(nCount == 2)
			m_strAlarmMessage.Format("%s", pToken);
		nCount++;
		pToken = strtok(NULL, ";");
	}
}
void COPCSvr::ParsingStatusMessage(CString strStatusMessage)
{
	char szStr[3000];
	char* pToken;
	strcpy(szStr, strStatusMessage);
	pToken = strtok(szStr, ";");
	int nCount = 0;

	while(pToken !=NULL)
	{
		if(nCount == 1)
			m_strStatusCode.Format("%s", pToken);
		else if(nCount == 2)
			m_strStatus.Format("%s", pToken);
		nCount++;
		pToken = strtok(NULL, ";");
	}
}
void COPCSvr::ParsingRecipeMessage(int nType, int nIndex, CString strRecipeMessage)
{
	m_strRecipePass = _T("");;
	m_strBasket = _T("");;
	m_strRecipePrj = _T("");;
	m_strRecipeParam = _T("");;
	m_strRecipeID = _T("");;
	m_strRecipeMessage = _T("");;
	m_strRecipePass = _T("");
	m_strRecipeTag = _T("");
	m_strRecipeLayer = _T("");
	m_strLayUpCode = _T("");
	m_strMaterialGroup = _T("");
	m_strMaterialMaker = _T("");
	m_strMaterialKind = _T("");
	m_strMaterialThick = _T("");
	m_strTrimFinalThick = _T("");
	m_strNextPnProcess = _T("");
	m_strCurrentProcess = _T("");
	m_strPPGThick = _T("");
	m_strDongbakThick = _T("");

	m_strCompLaserFile = _T("");
	m_strSoldLaserFile = _T("");
	m_strCompRecipeFile = _T("");
	m_strSoldRecipeFile = _T("");

	//20170405 MES3.0 Update
	m_strCopperThick = _T("");
	m_strProcessCode = _T("");
	m_strBackwardLevel = _T("");
	m_strCustomerCode = _T("");
	m_strPrevProcessCode = _T("");

	char szStr[3000];
	char* pToken;

	//strRecipeMessage.Format(_T("140256;M7314485001;PASS;;24;;0;135-P38-68-01;F0T;1ZP3868_11,1ZP3868_KK,,;810;610;;12;;0.05,0.065;,;;;;;;12YNW;CCL;Doosan;GR(FR4)C3_RTF;;0.065;12,12"));


	int nDuplicate = strRecipeMessage.Find(";;", 0);
	CString strFirst = _T("");
	CString strSecond = _T("");


	while(nDuplicate != -1)
	{
		strFirst = strRecipeMessage.Left(nDuplicate + 1);
		strSecond = " " + strRecipeMessage.Mid(nDuplicate + 1, strRecipeMessage.GetLength() );
		strRecipeMessage = strFirst + strSecond;
		nDuplicate = strRecipeMessage.Find(";;", 0);
	}


	strcpy(szStr, strRecipeMessage);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	int nRMSType = m_nRMSType;
	BOOL bAI;
	if(m_nRMSType == 0)
		bAI = TRUE;
	else
		bAI = FALSE;
	m_nRecipeIndex = nIndex;
	CString strPars1, strPars2, strPars3, strPars4, strPars5, strPars6, strPars7,
		strPars8, strPars9, strPars10, strPars11, strPars12, strPars13, strPars14,
		 strPars15, strPars16, strPars17, strPars18, strPars19, strPars20, strPars21, strPars22,strPars23, strPars30, strPars31, strPars32, strPars33;


	CString str;
	str = strRecipeMessage;
	int nIndex1 = str.Find(";");
	int nIndex2 = 0;
	/*
	if(bAI)
	{
		strPars1 = str.Left(nIndex1);

		nIndex2 = str.Find(";",nIndex+1);
		strPars2 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars3 = str.Mid(nIndex1+1, nIndex2 - nIndex1);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars4 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars5 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars6 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars7 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars8 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars9 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex1);
		strPars10 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars11 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;

		nIndex2 = str.Find(";",nIndex+1);
		strPars12 = str.Mid(nIndex1+1, nIndex2);
		nIndex1 = nIndex2;
	}
	*/
	while(pToken !=NULL)
	{
		if(nType == RMS_DOWNLOAD)
		{
			if(nCount == 1)
				strPars1.Format("%s", pToken);
			if(nCount >= 2)
			{
				strPars3.Format("%s;", pToken);
				strPars2 = strPars2 + strPars3;
			}

		}
		else
		{
			if(bAI)
			{
				if(nCount == 1)
					strPars1.Format("%s", pToken);
				if(nCount == 2)
					strPars2.Format("%s", pToken);
				if(nCount == 3)
					strPars3.Format("%s", pToken);
				if(nCount == 4)
					strPars4.Format("%s", pToken);
				if(nCount == 5)
					strPars5.Format("%s", pToken);
				if(nCount == 6)
					strPars6.Format("%s", pToken);
				if(nCount == 7)
					strPars7.Format("%s", pToken);
				if(nCount == 8)
					strPars8.Format("%s", pToken);
				if(nCount == 9)
					strPars9.Format("%s", pToken);
				if(nCount == 10)
					strPars10.Format("%s", pToken);
				if(nCount == 11)
					strPars11.Format("%s", pToken);
				if(nCount == 12)
					strPars12.Format("%s", pToken);
				if(nCount == 13)
					strPars13.Format("%s", pToken);
				if(nCount == 14)
					strPars14.Format("%s", pToken);
				if(nCount == 19)
					strPars15.Format("%s", pToken);
				if(nCount == 20)
					strPars16.Format("%s", pToken);
				if(nCount == 21)
					strPars17.Format("%s", pToken);
				if(nCount == 22)
					strPars18.Format("%s", pToken);
				if(nCount == 23)
					strPars19.Format("%s", pToken);
				if(nCount == 24)
					strPars20.Format("%s", pToken);
				if(nCount == 25)
					strPars21.Format("%s", pToken);
			}
			else
			{
				if(nCount == 1)
					strPars1.Format("%s", pToken);
				if(nCount == 2)
					strPars2.Format("%s", pToken);
				if(nCount == 3)
					strPars3.Format("%s", pToken);
				if(nCount == 4)
					strPars4.Format("%s", pToken);
				if(nCount == 5)
					strPars5.Format("%s", pToken);
				if(nCount == 6)
					strPars6.Format("%s", pToken);
				if(nCount == 7)
					strPars7.Format("%s", pToken);
				if(nCount == 8)
					strPars8.Format("%s", pToken);
				if(nCount == 9)
					strPars9.Format("%s", pToken);
				if(nCount == 10)
					strPars10.Format("%s", pToken);
				if(nCount == 11)
					strPars11.Format("%s", pToken);
				if(nCount == 12)
					strPars12.Format("%s", pToken);
				if(nCount == 13)
					strPars13.Format("%s", pToken);
				if(nCount == 14)
					strPars14.Format("%s", pToken);

				if(nCount == 15)
					strPars22.Format("%s", pToken); // PPG �β�

				if(nCount == 29)
					strPars23.Format("%s", pToken); // ���� �β�

				if(nCount == 22)
					strPars15.Format("%s", pToken);
				if(nCount == 23)
					strPars16.Format("%s", pToken);
				if(nCount == 24)
					strPars17.Format("%s", pToken);
				if(nCount == 25)
					strPars18.Format("%s", pToken);
				if(nCount == 26)
					strPars19.Format("%s", pToken);
				if(nCount == 27)
					strPars20.Format("%s", pToken);
				if(nCount == 28)
					strPars21.Format("%s", pToken);
			}

		}

		nCount++;
		pToken = strtok(NULL, ";");
	}
	
	if(nType == RMS_VALIDATION ) //Recipe ��ȿ�� ����
	{
		if(bAI)
		{
/*			if(nCount == 9)
			{
				m_strRecipePass = strPars3;
				m_strRecipeTag = " ";
				m_strRecipeID = strPars2;
				m_strRecipeParam = strPars4; // count 
				m_strRecipePrj = strPars7;
				m_strBasket = strPars1;
				m_strRecipeMessage = strPars5;
				m_strRecipeStatus = strPars6;
			}
			else if(nCount == 8)
			{
				m_strRecipePass = strPars3;
				m_strRecipeTag = " ";
				m_strRecipeID = strPars2;
				m_strRecipeParam = strPars4; // count 
				m_strRecipePrj = strPars6;
				m_strBasket = strPars1;
				m_strRecipeMessage = " ";
				m_strRecipeStatus = strPars5;
			}
*/
			m_strRecipePass = strPars3; // fail, pass
			m_strRecipeTag = " "; // 
			m_strBasket = strPars1;
			m_strRecipeID = strPars2; //Lot ID
			m_strRecipeParam = strPars7; // count 
			m_strRecipePrj = strPars10; // film no.
			m_strRecipeMessage = strPars8; // message
			m_strRecipeStatus = strPars9; // Lot Fire...
			m_strRecipeLayer = strPars12; // Layer
			m_strLayUpCode = strPars15;     // Type
			m_strMaterialGroup = strPars16;	// CCL/PPG
			m_strMaterialMaker = strPars17;	// ��ü��
			m_strMaterialKind = strPars18;	// ��������
			m_strMaterialThick = strPars19;	// ����β�
			m_strTrimFinalThick = strPars20;// ��ǰ�β�
			m_strNextPnProcess = strPars21;	// ���� ���� ����Code
			m_strCurrentProcess = strPars11; // ���� ���� Code
#ifdef __TEST__
			m_strTrimFinalThick.Format(_T("0.4"));
#endif
		}
		else
		{
			m_strRecipePass = strPars2; // fail, pass
			m_strRecipeTag = " "; // 
			m_strRecipeID = strPars1; //Lot ID
			m_strRecipeParam = strPars4; // count 
			m_strRecipePrj = strPars7; // film no.
			m_strRecipeMessage = strPars5; // message
			m_strRecipeStatus = strPars6; // Lot Fire...
			m_strRecipeLayer = strPars13; // Layer
			m_strLayUpCode = strPars15;     // Type
			m_strMaterialGroup = strPars16;	// CCL/PPG
			m_strMaterialMaker = strPars17;	// ��ü��
			m_strMaterialKind = strPars18;	// ��������
			m_strMaterialThick = strPars19;	// ����β�
			m_strTrimFinalThick = strPars20;// ��ǰ�β�
			m_strNextPnProcess = strPars21;	// ���� ���� ����Code
			m_strCurrentProcess = strPars8;	// ���� ���� Code
			//m_strPPGThick = strPars22;
			m_strDongbakThick = strPars21;
			

//			char szStr3[3000];
//			strcpy(szStr3, strPars22);
//			pToken = strtok(szStr3, ",");
//			nCount = 0;
//
//			/*int nToken = strPars22.Find(_T(",");
//
//			m_strPPGThick = strPars22.Mid(nToken,strPars22.GetLength());
//			m_strPPGThick.TrimLeft();
//			m_strPPGThick.TrimRight();
//*/
//			while(pToken !=NULL)
//			{
//				if(nCount == 1)
//					m_strPPGThick.Format("%s", pToken);
//				nCount++;
//				pToken = strtok(NULL, ",");
//			}

			int nToken = strPars22.Find(_T(","));

			m_strPPGThick = strPars22.Mid(nToken+1,strPars22.GetLength());
			m_strPPGThick.TrimLeft();
			m_strPPGThick.TrimRight();


			char szStr2[3000];
			strcpy(szStr2, strPars9);
			pToken = strtok(szStr2, ",");
			nCount = 0;
			while(pToken !=NULL)
			{
				if(nCount == 0)
					strPars30.Format("%s", pToken);
				if(nCount == 1)
					strPars31.Format("%s", pToken);
				if(nCount == 2)
					strPars32.Format("%s", pToken);
				if(nCount == 3)
					strPars33.Format("%s", pToken);

				nCount++;
				pToken = strtok(NULL, ",");
			}

			 m_strCompLaserFile = strPars30;
			 m_strSoldLaserFile = strPars31;
			 m_strCompRecipeFile = strPars32;
			 m_strSoldRecipeFile = strPars33;
		}
	}
	else if(nType == RMS_UPDATE) //Recipe ���ε� ��û
	{
		m_strRecipePass = " ";
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_UPDATE, reinterpret_cast<LPARAM>(&m_strRecipeID));
	}
	else if(nType == RMS_DATAVALIDATION)
	{
		m_strRecipePass = strPars2; // fail, pass
		m_strRecipeTag = " "; // 
		m_strRecipeID = strPars1; //Lot ID
		m_strRecipeParam =  " "; //  
		m_strRecipePrj = strPars4; // film no.
		m_strRecipeMessage = strPars10; // message
		m_strRecipeStatus = " "; // 
		m_strRecipeLayer = strPars8; // Layer
	
	}
/*	if(nType == RMS_CREATE ) //Recipe ���� ����
	{
		//�̻��
		m_strRecipePass = strPars2;
		m_strRecipeTag = strPars3;
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
	}
	else if(nType == RMS_CHANGE ) //Recipe ���� ����
	{
		m_strRecipePass = strPars2;
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
	}
	else if(nType == RMS_DELETE) //Recipe ����
	{
		// UI���� ���� ���� ���� 
		m_strRecipePass = " ";
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_DELETE, reinterpret_cast<LPARAM>(&m_strRecipeID));
	}
	else
	*/
/*	else if(nType == RMS_DOWNLOAD) //Recipe �ٿ�ε� ��û 
	{
		m_strRecipePass = " ";
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = strPars2;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_DOWNLOAD, reinterpret_cast<LPARAM>(&m_strRecipeID));
	}
	else if(nType == RMS_LIST) //Recipe ����Ʈ ��û 
	{
		m_strRecipePass = " ";
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_LIST, reinterpret_cast<LPARAM>(&m_strRecipeID));
	}
	else if(nType )//Recipe �޼��� ���� 
	{
		m_strRecipePass = " ";
		m_strRecipeTag = " ";
		m_strRecipeID = strPars1;
		m_strRecipeParam = " ";
	}
	else if(nType )// Recipe ���� ����
	{
	}
*/
}
BOOL COPCSvr::OpenTagFile(LPCTSTR szFile)
{
	int nRegister = m_pOPC->OpenTagFile(1, szFile);
	
	if(nRegister < 0)
		return FALSE;
	return TRUE;
}

long COPCSvr::CreateTag(LPCTSTR szName, LPCTSTR szDesc, LPCTSTR szData)
{
	return m_pOPC->CreateTagString(szName, szDesc, 3, 0, 1, szData);  //string data, client unwritable, nQuality = 1
}

CString COPCSvr::BstrToCString(BSTR bstr)
{

	return "";
}

BOOL COPCSvr::GetTagMessage(long nIndex, LPCTSTR szData, BOOL bAddTime)
{
	CTime EventTime = CTime::GetCurrentTime();
	CString strTime, strData;
	if(!bAddTime)
	{
		strData.Format("%s",szData);
	}
	else
	{
		strTime.Format("%02d%02d%02d",
			EventTime.GetHour(), EventTime.GetMinute(), EventTime.GetSecond());
		
		strData.Format("%s;%s", strTime, szData);
	}

/*	char szTag[20];
	memset(szTag, 0, sizeof(szTag));
	GetOPCTag(nIndex, szTag);
	*/
	nIndex -=1;
	BOOL bResult =	pUpdateTagMessage(nIndex, strData, 1);
	if(bResult)
	{
		CString strFile, strLog;
		strLog.Format(_T("TC <- EQ | %d : %s"), nIndex, szData);
		SaveLog(strLog);
	//	SendMessage(UM_WRITE_OPC_LOG,reinterpret_cast<WPARAM>(&strLog));
	}
	return TRUE;
}
BOOL COPCSvr::UpdateTag(long nIndex, LPCTSTR szData)
{
//	if(!m_pOPC)
//		return FALSE;
//	if(m_pOPC->UpdateTagString(nIndex, szData, 1) < 0)
//		return FALSE;
	
/*	char szTag[20];
	memset(szTag, 0, sizeof(szTag));
	GetOPCTag(nIndex, szTag);
	*/
	nIndex -=1;
	return pUpdateTagMessage(nIndex, szData, 1);
	
	return TRUE;
}

void COPCSvr::OnDestroy() 
{
//	::DeleteCriticalSection( &m_CritLog );
/*	m_pOPC->Close();
	MSG msg;
	while(m_pOPC->GetClientCount() > 0)
	{
		if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
		{
			::TranslateMessage((LPMSG)&msg);
			::DispatchMessage((LPMSG)&msg);
		}
	}
	if(m_pOPC->GetClientCount() == 0)
	{
		PostMessage(WM_CLOSE);
	}
	m_pOPC->UnInitialize();
	

//	if(m_pOPC->GetClientCount() > 0)
//	{
//		
//		SetTimer(1, 100, NULL);
//		return;
//	}

//	CDialog::OnClose();
*/

//#ifndef __TEST__
	
	m_bEndThread = TRUE;
	
	Sleep(1000);

	if(m_pThread != NULL)
		::WaitForSingleObject(m_pThread, INFINITE);

	pUnInitOPC();
	
	FreeLibrary(hDll);
//#endif

	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void COPCSvr::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
/*	if(1 == nIDEvent)
	{
		if(m_pOPC->GetClientCount() == 0)
		{
			KillTimer(nIDEvent);
			PostMessage(WM_CLOSE);
		}
	}

	CDialog::OnTimer(nIDEvent);
*/
}

void COPCSvr::SetUpdateRate(long lUpdateRate)
{
//	m_pOPC->SetUpdateRate(lUpdateRate);
}

void COPCSvr::DeleteFromRegistry()
{
//	m_pOPC->UnRegister();
}

CEVOpcX* COPCSvr::GetOPC()
{
	return m_pOPC;
}

BOOL COPCSvr::OnInitDialog() 
{
	m_hEnv			= NULL;
	m_hDbc			= NULL;
	m_hStmt			= NULL;
	m_strWorkingDir	= _T("D:\\ViaHole\\");
	m_strLossError  = "";
	m_strStatus		= "";
	m_strStatusCode = "";
	m_bConnection1 = FALSE;
	m_bConnection2 = FALSE;
	m_strRecipeCreate = "";
	m_strRecipeDelete = "";
	m_strRecipeUpdate = "";
	m_strRecipeValidation = "";
	m_strRecipeUpload = "";
	m_strRecipeDownLoad = "";
	m_strRecipeIDCreate = "";
	m_strRecipeDeleteFromEES = "";
	m_strData1 = "";
	m_strData2 = "";
	m_strMESCancel = "";
	m_RMSReturnData = "";
	m_strRecipePass = "";
	m_strRecipeTag = " ";
	m_strRecipeID = " ";
	m_strRecipeParam = " ";
	CDialog::OnInitDialog();
	//ReadOPCINI();
	// TODO: Add extra initialization here 
	hDll = LoadLibrary("D:\\ViaHole\\PTOpcItfc.dll");

	pUpdateTagMessage=(lUpdateTagMessage)GetProcAddress(hDll, "Pt_UpdateTagString");
	
	pInitOPC = (InitOPC)GetProcAddress(hDll, "Pt_InitOpc");

	pUnInitOPC = (UnInitOPC)GetProcAddress(hDll, "Pt_UnInitOpc");

	pGetControl = (GetControl)GetProcAddress(hDll, "Pt_GetControl");
	
	char szTemp[20];
	strcpy(szTemp, "PtOpcSvr");

	pInitOPC(); 
//	pInitOPC(szTemp);
//	Pt_InitOpc(szTemp);

	m_dlgMessageBox.Create(IDD_DLG_MESSAGEBOX);
	m_dlgMessageBox.ShowWindow(SW_HIDE);


	m_pThread = ::AfxBeginThread(GetControlThread, this, THREAD_PRIORITY_NORMAL);

	
//	Initialize();
//	OpenTagFile("D:\\ViaHole\\OPC_Tag_List.ini");
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL COPCSvr::DBConnect()
{
	SQLCHAR		InCon[255];
	SQLCHAR		OutCon[1024];
	SQLSMALLINT	cbOutCon;
	char Dir[255] = {0,};
	SQLRETURN	bRet;
	
	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;
	
	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;
	
	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;
	
	// Connect mdb file
	CString strDBPath;
	
	strDBPath.Format("%s\\OPCCheckList.mdb", m_strWorkingDir);
	sprintf( Dir, "%s", strDBPath );
	wsprintf( (char*)InCon, "DRIVER={Microsoft Access Driver (*.mdb)};"
		"DBQ=%s;PWD=", Dir);
	
	bRet = ::SQLDriverConnect( m_hDbc, NULL, InCon, sizeof(InCon), OutCon, sizeof(OutCon),
		&cbOutCon, SQL_DRIVER_NOPROMPT );
	
	if( bRet != SQL_SUCCESS )
		return FALSE;
	
	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;
	
	return TRUE;
}

void COPCSvr::DBDisconnect()
{
	// Free Stmt Handle
	if( NULL != m_hStmt )
	{
		::SQLFreeHandle( SQL_HANDLE_STMT, m_hStmt );
		m_hStmt = NULL;
	}
	
	// Free Dbc Handle
	if( NULL != m_hDbc )
	{
		// Disconnect
		::SQLDisconnect(m_hDbc);
		::SQLFreeHandle( SQL_HANDLE_DBC, m_hDbc );
		m_hDbc = NULL;
	}
	
	// Free Env Handle
	if( NULL != m_hEnv )
	{
		::SQLFreeHandle( SQL_HANDLE_ENV, m_hEnv );
		m_hEnv = NULL;
	}
}

BOOL COPCSvr::SearchTagItem(int nErrorCode, CString& strTagItem)
{
	CStdioFile OpcCheckFile;
	CString strErrorCode = _T("");
	char* pToken;
	char szStr[400] = {0,};
	int nCount = 0;

	if(OpcCheckFile.Open("d:\\viahole\\OPCCheckList.ini", CFile::modeReadWrite|CFile::shareDenyNone) == FALSE)
	{
		ErrMessage(_T("Can not open OPCCheckList.ini"));
		return FALSE;
	}

	while(OpcCheckFile.ReadString(strErrorCode))
	{
		BOOL bCheckOK = FALSE;
		strcpy(szStr, strErrorCode);
		pToken = strtok(szStr, "::");

		while(pToken != NULL)
		{

			if(nCount == 0 && atoi(pToken) == nErrorCode)
			{
				pToken = strtok(NULL, "::");
				strTagItem.Format("%s", pToken);
				OpcCheckFile.Close();
				return TRUE;
			}
			else
			{
				break;
			}

			pToken = strtok(NULL, "::");
		}
	}
	OpcCheckFile.Close();
	return FALSE;
}

void COPCSvr::GetDiagonostics()
{
	int			nDiag = 0;
	SQLINTEGER	nNativeError;
	SQLCHAR		szSqlState[6];
	SQLCHAR		szMsg[SQLMAXLEN];
	SQLSMALLINT	nMsgLen;
	
	::SQLGetDiagField( SQL_HANDLE_STMT, m_hStmt, 0, SQL_DIAG_NUMBER, &nDiag, 0, &nMsgLen );
	
	SQLRETURN nRet;
	
	nDiag = 1;
	while( 1 )
	{
		nRet = ::SQLGetDiagRec( SQL_HANDLE_STMT, m_hStmt, nDiag, szSqlState, &nNativeError, szMsg, sizeof(szMsg), &nMsgLen );
		if( nRet == SQL_NO_DATA )
			break;
		ErrMessage( (LPCTSTR)szMsg );
		nDiag++;
	}
}

BEGIN_EVENTSINK_MAP(COPCSvr, CDialog)
    //{{AFX_EVENTSINK_MAP(COPCSvr)
//	ON_EVENT(COPCSvr, IDC_EVOPCXCTRL1, 2 /* ControlString */, OnControlStringEvopcxctrl, VTS_I4 VTS_BSTR VTS_PI4)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void COPCSvr::OnControlStringEvopcxctrl(long nIndex, LPCTSTR szValue, long FAR* lResult) 
{
	// TODO: Add your control notification handler code here
	if(nIndex == 343)  // 343 = Terminal Message
	{
		CString strMsg;
		strMsg.Format(_T("Terminal Message\n%s"),szValue);
		ErrMessage(strMsg, MB_OK | MB_TOPMOST );
		*lResult = 1;
// 		UpdateTagMessage(343, szValue);
		return;
	}
	if(nIndex == 344)  // 344 = Connection Check
	{

		*lResult = 1;
		m_bConnection1 = TRUE;
// 		UpdateTagMessage(344, szValue);

	}
	if(nIndex == 345)
	{
		*lResult = 1;
		m_bConnection2 = TRUE;
// 		UpdateTagMessage(345, szValue);

	}
	if(nIndex == 335) // 335 = Loss Error 
	{
		m_strLossError = szValue;
		*lResult = 1;
// 		UpdateTagMessage(335, szValue);
		return;
	}
	if(nIndex == 346)   //346 = Status
	{
		m_strStatus = szValue;
		*lResult = 1;
// 		UpdateTagMessage(346, szValue);
		return;
	}
	if(nIndex == 348)  //348 = Recipe ���� �㰡 (03,04)
	{
		*lResult = 1;
		m_strRecipeCreate = szValue;
// 		UpdateTagMessage(348, szValue);
		return;
	}
	if(nIndex == 350)  //350 = Recipe ���� �㰡 (03,04)
	{
		*lResult = 1;
		m_strRecipeUpdate = szValue;
// 		UpdateTagMessage(350, szValue);
		return;
	}
	if(nIndex == 352)  //352 = Recipe ���� �㰡
	{
		*lResult = 1;
		m_strRecipeDelete = szValue;
// 		UpdateTagMessage(352, szValue);
		return;
	}
	if(nIndex == 354)  //354 = Recipe Validation �㰡
	{
		*lResult = 1;
		m_strRecipeValidation = szValue;
// 		UpdateTagMessage(354, szValue);
		return;
	}
	if(nIndex == 356)  //356 = Recipe Upload ��û
	{
		*lResult = 1;
		m_strRecipeUpload = szValue;
		CString strRecipe = _T("");
		strRecipe = GetRecipeValue(m_strRecipeUpload);
// 		UpdateTagMessage(356, szValue);
// 		UpdateTagMessage(355,strRecipe);
		return;
	}
	if(nIndex == 358)  //358 = Recipe DownLoad
	{
		*lResult = 1;
//		m_strRecipeDownLoad = szValue;
//		UpdateTagMessage(358, szValue);
// 		DownLoadRecipe(m_strRecipeDownLoad);   // 20100519 bskim ������
		return;
	}
	if(nIndex == 360)   //360 = Recipe List
	{
		*lResult = 1;
// 		UpdateTagMessage(360, szValue);
//		UploadRecipeList();
		return;
	}

/*	if(nIndex == 362)	//362 = Recipe ID ����
	{
		*lResult = 1;
		m_strRecipeIDCreate = szValue;
		UpdateTagMessage(362, szValue);
		return;
	}*/

	if(nIndex == 362)	//364 = EES ���� Recipe ���� ��û
	{
		*lResult = 1;
		m_strRecipeDeleteFromEES = szValue;
//		UpdateTagMessage(362, szValue);
// 		DeleteRecipeFromEES(m_strRecipeDeleteFromEES);
		return;
	}
	if(nIndex == 384)   //384 = MES ���� ó���� ���� �۾��� �Է³��� ��û
	{
		*lResult = 1;
		m_strData1 = szValue;
//		UpdateTagMessage(384, szValue);
	}
	if(nIndex == 386)	//386 = MES ����ó����û��� ��ȯ
	{
		*lResult = 1;
		m_strData2 = szValue;
//		UpdateTagMessage(386, szValue);
	}
	if(nIndex == 459)  //459 = Recipe ���� �㰡 (01,02)
	{
		*lResult = 1;
		m_strRecipeCreate = szValue;
//		UpdateTagMessage(459, szValue);
		return;
	}
	if(nIndex == 461)  //461 = Recipe ���� �㰡 (01,02)
	{
		*lResult = 1;
		m_strRecipeUpdate = szValue;
//		UpdateTagMessage(461, szValue);
		return;
	}
	*lResult = 0;
//	m_bConnection2 = FALSE;
//	m_bConnection1 = FALSE;
}
void COPCSvr::DeleteRecipeFromEES(CString RecipeID)
{
	CString strFile;
	strFile = RecipeID.Mid(7);
	strFile.TrimLeft();
	strFile.TrimRight();
	
	CString strPath;
	strPath.Format("D:\\ViaHole\\Aperture\\%s.apl", strFile);
	
	BOOL bExist = IsFileExist(strPath);
	
	if(bExist)
	{
		CStdioFile fileAperture;
		fileAperture.Remove(strPath);
		
		GetTagMessage(361, "PASS;");
	}
	else
		GetTagMessage(361, "FAIL;��ϵ� Recipe�� �����ϴ�.");
}
bool COPCSvr::IsFileExist(const CString &strFilePath)
{
	WIN32_FIND_DATA wfd32;
	
	HANDLE hSrch = ::FindFirstFile(strFilePath, &wfd32);
	
	if(hSrch == INVALID_HANDLE_VALUE)
	{
		TRACE(_T("%s is not exist\n"), strFilePath);
		
		return false;
	}
	
	::FindClose(hSrch);
	
	return true;
}

CString COPCSvr::GetRecipeValue(CString RecipeID)
{
	CString strRecipe = _T("");
	CString strRecipeReturn = _T("");
	CString strRead;
	CString strValue;
	
	CString strInnerRadius;
	CString strOuterRadius;
	CString strRadiusPitch;
	CString strInitialEntryAngle;
	CString strLineDivisionType;
	CString strLineStepLength;
	CString strSpiralRepeat;
	CString strOuterCircle;
	CString strExtAngle;
	CString strExtRdRatio;
	CString strInnerLineStepLength;
	CString strVectorNo;
	CStdioFile file;

	if(RecipeID.GetLength() > 7)
		RecipeID = RecipeID.Mid(7);
	strRecipeReturn = "FAIL";//;�ش��ϴ� Recipe�� �������� �ʽ��ϴ�.";
	if(file.Open("D:\\Viahole\\Aperture\\" + RecipeID + ".apl", CFile::modeRead|CFile::shareDenyNone) == FALSE)
	{
		return strRecipeReturn;
	}
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("HEADER"), strValue) == FALSE)
		return strRecipeReturn;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("TYPE\t:"), strValue) == FALSE)
		return strRecipeReturn;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("IN_RADIUS\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strInnerRadius = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("OUT_RADIUS\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strOuterRadius = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("RADIUS_PITCH\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strRadiusPitch = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("ENTRY_ANGLE\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strInitialEntryAngle = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("ERROR_TYPE\t:"), strValue) == FALSE)
		return strRecipeReturn;
//	str = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("ERROR_LENGTH\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strLineStepLength = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("REPEAT\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strSpiralRepeat = strValue;

	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("USE_OUTER_CIRCLE\t:"), strValue) == FALSE)
		return strRecipeReturn;
//	strInnerRadius = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("EXT_ANGLE\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strExtAngle = strValue;
	
	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("EXT_RD_RATIO\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strExtRdRatio = strValue;

	if(file.ReadString(strRead) && ParseHeaderItem(strRead, _T("INNER_LINE_LENGTH\t:"), strValue) == FALSE)
		return strRecipeReturn;
	strInnerLineStepLength = strValue;

	int nVectorCount = 0;
	CString strAperture = _T("");
	file.SeekToBegin();
	while(file.ReadString(strAperture))
	{
		if(strAperture.Find("PU") != -1 ||strAperture.Find("PD") != -1 )
			nVectorCount++;
	}
	strVectorNo.Format("%d", nVectorCount);

	strRecipeReturn = RecipeID + ";01=SPIRAL;02=" + strInnerRadius + ";03=" + strOuterRadius + ";04=" + strRadiusPitch
		+ ";05=" + strInitialEntryAngle + ";06=" + strLineStepLength + ";07=" + strSpiralRepeat + ";08=" + strExtAngle
		+ ";09=" + strExtRdRatio + ";10=" + strInnerLineStepLength + ";11=" + strVectorNo;

	return strRecipeReturn;
}

BOOL COPCSvr::ParseHeaderItem(CString strRead, CString strHeaderItem, CString &strValue)
{
	if(strHeaderItem.Find(_T("HEADER")) == 0)
		return TRUE;
	
	if(strHeaderItem.Find(_T("TYPE\t:")) == 0)
		return TRUE;
	
	if(strRead.Find(strHeaderItem) == 0)
	{
		strValue = strRead.Right(strRead.GetLength() - strHeaderItem.GetLength());
		strValue.TrimLeft();
		strValue.TrimRight();
		return TRUE;
	}
	
	return FALSE;
}

void COPCSvr::DownLoadRecipe(CString RecipeValue)
{
//	WriteLog("OPC_RECIPE", "DownLoadRecipe 1");
	
/*	MSpiral spiral;
	
	char szStr[1000];
	char* pToken;
	strcpy(szStr, RecipeValue);
	pToken = strtok(szStr, ";");
	int nCount = 0;
	CString strRecipeID = _T("");
	double dInnerRadius = 0;
	double dOuterRadius = 0;
	double dRadiusPitch = 0;
	double dInitialEntryAngle = 0;
	double dLineStepLength = 0;
	double dSpiralRepeat = 0;
	double dExtAngle = 0;
	double dExtRdRatio = 0;
	double dInnerLineStepLength = 0;

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 2");
		
	while(pToken !=NULL)
	{
		if(nCount ==1 )
			strRecipeID.Format("%s", pToken);
		else if(nCount == 3)
			dInnerRadius = atof(pToken + 3);
		else if(nCount == 4)
			dOuterRadius = atof(pToken + 3);
		else if(nCount == 5)
			dRadiusPitch = atof(pToken + 3);
		else if(nCount == 6)
			dInitialEntryAngle = atof(pToken + 3);
		else if(nCount == 7)
			dLineStepLength = atof(pToken + 3);
		else if(nCount == 8)
			dSpiralRepeat = atof(pToken + 3);
		else if(nCount == 9)
			dExtAngle = atof(pToken + 3);
		else if(nCount == 10)
			dExtRdRatio = atof(pToken + 3);
		else if(nCount == 11)
			dInnerLineStepLength = atof(pToken + 3);
		
		nCount++;
		pToken = strtok(NULL, ";");
	}

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 3");
		
	spiral.SetGeometry(dOuterRadius, dInnerRadius, dRadiusPitch, dInitialEntryAngle, dExtAngle, dExtRdRatio,
		dInnerLineStepLength, dLineStepLength, 0);

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 4");
		
	spiral.SetSpiralRepeat(dSpiralRepeat);

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 5");
		
	spiral.GenerateApeture();

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 6");
	
	CString strID;
	strID.Format("%s", strRecipeID);
	
	strRecipeID.Format("D:\\ViaHole\\Aperture\\%s", strID + ".apl");
	spiral.SaveApetureFile(strRecipeID);

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 7");
	
	GetTagMessage(357, strID + ";PASS;���� ���� ����");

//	WriteLog("OPC_RECIPE", "DownLoadRecipe 8");
*/
}

void COPCSvr::UploadRecipeList()
{
//	CStdioFile RMSFile;
	CString	strRecipeList = _T("");
	CString strRecipeValue = _T("");
	CString strRealValue = _T("");
// 	if(RMSFile.Open("d:\\viahole\\aperture\\RMS.ini", CFile::modeRead |CFile::shareDenyNone) == FALSE)
// 	{
// 		UpdateTagMessage(359,"FAIL;���� ����� RMS ������ �� �� �����ϴ�.");
// 		return;
// 	}

// 	char* pToken;
// 	char szStr[300] = {0,};
// 
// 	while(RMSFile.ReadString(strRecipeList))
// 	{
// 		sprintf(szStr, "%s", strRecipeList);
// 		pToken = strtok(szStr, ";");
// 		if(pToken != NULL && strcmp(strRecipeList, "\n") != 0 && pToken[0] != 13)
// 		{
// 			strRecipeValue.Format(";%s", pToken);
// 			pToken = strtok(NULL, ";");
// 			strRealValue += strRecipeValue;
// 		}
// 	}

	CFileFind finder;

	BOOL bWorking = finder.FindFile("D:\\ViaHole\\Aperture\\*.apl");

	while(bWorking)
	{
		bWorking = finder.FindNextFile();

		if(!finder.IsDirectory())
		{
			strRecipeList = finder.GetFileName();
			strRecipeList.Replace(".apl","");
			strRealValue += strRecipeList + ";";
		}
	}

	if(strRealValue.GetLength() <= 0)
		strRealValue = "FAIL;Recipe�� �������� �ʽ��ϴ�.";

	int a = strRealValue.GetLength();
	if(strRealValue.GetLength() > 500)
	{
		GetTagMessage(359, strRealValue.Mid(0, 500));
		for(int i = 0; i<strRealValue.GetLength() / 500; i++)
		{
			GetTagMessage(363 + i, strRealValue.Mid(500*(i + 1), 500));
		}
	}
	else
		GetTagMessage(359, strRealValue);
}

BOOL COPCSvr::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

BOOL COPCSvr::GetConnection1()
{
	return m_bConnection1;
}

BOOL COPCSvr::GetConnection2()
{
	return m_bConnection2;
}

void COPCSvr::SetPNLCheck(BOOL bCheck)
{
	m_bPNLCheck = bCheck;
}
void COPCSvr::SetRMSType(int nType)
{
	m_nRMSType = nType;
}
int COPCSvr::GetRMSType()
{
	return m_nRMSType;
}
BOOL COPCSvr::GetPNLCheck()
{
	return m_bPNLCheck;
}
LRESULT COPCSvr::OnWriteOPCLog(WPARAM wParam, LPARAM lParam)
{

//	::EnterCriticalSection( &m_CritLog );
	CString strPathName;
	CTime ct = CTime::GetCurrentTime();
	strPathName.Format(_T("%sOPCLog%d%d%d"), gEasyDrillerINI.m_clsDirPath.GetImportantLogDir(), ct.GetYear(), ct.GetMonth(), ct.GetDay());
	
	CString* strLog = reinterpret_cast<CString*>(wParam);
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
//		::LeaveCriticalSection( &m_CritLog );
		return 0L;
	}
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		ct.GetHour(),
		ct.GetMinute(),
		ct.GetSecond(),
		*strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
//		::LeaveCriticalSection( &m_CritLog );
		return 0L;
	}
	END_CATCH
		
//	::LeaveCriticalSection( &m_CritLog );

return 1L;
}
void COPCSvr::SaveLog(CString strTag)
{
	CString strPathName;
	CTime ct = CTime::GetCurrentTime();
	strPathName.Format(_T("%sOPCLog%d%d%d"), gEasyDrillerINI.m_clsDirPath.GetImportantLogDir(), ct.GetYear(), ct.GetMonth(), ct.GetDay());
	

	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
//		::LeaveCriticalSection( &m_CritLog );
		return ;
	}
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		ct.GetHour(),
		ct.GetMinute(),
		ct.GetSecond(),
		strTag);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
//		::LeaveCriticalSection( &m_CritLog );
		return ;
	}
	END_CATCH
		
}
void COPCSvr::ResetRecvSignal()
{
	m_bRecv = FALSE;
}
void COPCSvr::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG )&msg);
	}
}
void COPCSvr::ParsingHandlerAlarm(long nIndex, LPCTSTR szValue)
{ 
	char szStr[3000];
	char* pToken;
	strcpy(szStr, szValue);
	pToken = strtok(szStr, ";");
	int nCount = 0;

	while(pToken !=NULL)
	{
		if(nCount == 1)
			m_strAlarmCode.Format("%s", pToken);
		else if(nCount == 2)
			m_strAlarmMessage.Format("%s", pToken);
		nCount++;
		pToken = strtok(NULL, ";");
	}

	if(ErrMessage(m_strAlarmMessage, MB_OK) == IDOK)
	{
		int nSendIndex = nIndex +1;

		CString strOPCTag;
		strOPCTag.Format(_T(" "));
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nSendIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		
	}

}
void COPCSvr::SetAIType(int nType)
{
	m_nAIType = nType;
}
int	COPCSvr::GetAIType()
{
	return m_nAIType;
}

void COPCSvr::ReadOPCINI()
{
	memset(m_stOPCINI, 0, sizeof(m_stOPCINI));

	CStdioFile OpcCheckFile;
	CString strErrorCode = _T("");
	char* pToken;
	char szStr[400] = {0,};
	int nCount = 0;
	if(OpcCheckFile.Open("d:\\viahole\\OpcINIList.ini", CFile::modeReadWrite|CFile::shareDenyNone) == FALSE)
	{
		ErrMessage(_T("Can not open OpcINIList.ini"));
		return;
	}

	while(OpcCheckFile.ReadString(strErrorCode))
	{
		BOOL bCheckOK = FALSE;
		strcpy(szStr, strErrorCode);
		pToken = strtok(szStr, "::");

		while(pToken != NULL)
		{
			m_stOPCINI[nCount].nIndex = atoi(pToken);
			pToken = strtok(NULL, "::");
			strcpy(m_stOPCINI[nCount].szCode, pToken);
			break;
		}
		nCount++;
	}
	OpcCheckFile.Close();
	return ;
}

void COPCSvr::GetOPCTag(int nIndex, char* pTag)
{
	for(int i = 0; i<= nIndex; i++)
	{
		if(m_stOPCINI[i].nIndex == nIndex)
		{
			strcpy(pTag, m_stOPCINI[i].szCode);
			return;
		}
	}
}