// DlgApertureSet.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgApertureSet.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgApertureSet dialog


CDlgApertureSet::CDlgApertureSet(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgApertureSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgApertureSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgApertureSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgApertureSet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_APERTURE_PARAM, m_listAperture);
	DDX_Control(pDX, IDC_BUTTON_APERTURE_OPEN, m_btnSetting);
	DDX_Control(pDX, IDC_BUTTON_APERTURE_DEL, m_btnFileDel);
	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE, m_btnUpdate);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_COMBO_MASK_NO, m_cmbMask);
	DDX_Control(pDX, IDC_EDIT_CUR, m_edtCurrent);
	DDX_Control(pDX, IDC_EDIT_FREQ, m_edtFreq);
	DDX_Control(pDX, IDC_EDIT_Z_OFFSET, m_edtZOffset);
	DDX_Control(pDX, IDC_EDIT_SP, m_edtSP);
	DDX_Control(pDX, IDC_EDIT_JD, m_edtJD);
	DDX_Control(pDX, IDC_EDIT_LOND, m_edtLOND);
	DDX_Control(pDX, IDC_EDIT_LOFFD, m_edtLOFFD);
	DDX_Control(pDX, IDC_EDIT_FILE, m_edtFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgApertureSet, CDialog)
	//{{AFX_MSG_MAP(CDlgApertureSet)
	ON_BN_CLICKED(IDC_BUTTON_APERTURE_OPEN, OnButtonApertureOpen)
	ON_BN_CLICKED(IDC_BUTTON_APERTURE_DEL, OnButtonApertureDel)
	ON_NOTIFY(NM_CLICK, IDC_LIST_APERTURE_PARAM, OnClickListApertureParam)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE, OnButtonParamUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgApertureSet message handlers

BOOL CDlgApertureSet::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();
	InitEditControl();
	LoadData();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgApertureSet::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(120, "Arial Bold");
	
	m_listAperture.SetFont( &m_fntList );
	
	const int nMaxColumnNum = 9;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};
	int ColumnHeadSize[9] = {100, 100, 100, 100, 100, 100, 100, 100, 160};
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("   Current"));
			break;
		case 1 :
			strText.Format(_T("Mask No"));
			break;
		case 2 :
			strText.Format(_T("Frequency"));
			break;
		case 3 :
			strText.Format(_T("Z Offset"));
			break;
		case 4 :
			strText.Format(_T("Step Period"));
			break;
		case 5 :
			strText.Format(_T("Jump Delay"));
			break;
		case 6 :
			strText.Format(_T("LaserOnDelay"));
			break;
		case 7 :
			strText.Format(_T("LaserOffDelay"));
			break;
		case 8 :
			strText.Format(_T("File"));
			break;
		}
		
		_stprintf_s( szText, "%s", strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		lvcolumn.cx = ColumnHeadSize[i];
		
		m_listAperture.InsertColumn(i, &lvcolumn);
	}
	
	DWORD dwStyle = m_listAperture.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_listAperture.SetExtendedStyle( dwStyle );
}

void CDlgApertureSet::InitStaticControl()
{
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_CUR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASK_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Z)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_JD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOND)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOFFD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FILE)->SetFont( &m_fntStatic );
}

void CDlgApertureSet::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// Aperture file path
	m_btnSetting.SetFont( &m_fntBtn );
	m_btnSetting.SetFlat( FALSE );
	m_btnSetting.EnableBallonToolTip();
	m_btnSetting.SetToolTipText( _T("...") );
	m_btnSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetting.SetBtnCursor(IDC_HAND_1);

	// Aperture file path Delete
	m_btnFileDel.SetFont( &m_fntBtn );
	m_btnFileDel.SetFlat( FALSE );
	m_btnFileDel.EnableBallonToolTip();
	m_btnFileDel.SetToolTipText( _T("Del") );
	m_btnFileDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFileDel.SetBtnCursor(IDC_HAND_1);

	// Data update
	m_btnUpdate.SetFont( &m_fntBtn );
	m_btnUpdate.SetFlat( FALSE );
	m_btnUpdate.EnableBallonToolTip();
	m_btnUpdate.SetToolTipText( _T("Update") );
	m_btnUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);

	// OK
	m_btnOK.SetFont( &m_fntBtn );
	m_btnOK.SetFlat( FALSE );
	m_btnOK.EnableBallonToolTip();
	m_btnOK.SetToolTipText( _T("OK") );
	m_btnOK.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOK.SetBtnCursor(IDC_HAND_1);

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);
}

void CDlgApertureSet::InitComboControl()
{
	m_fntCombo.CreatePointFont(130, "Arial Bold");
	
	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbMask.SetCurSel(0);
}

void CDlgApertureSet::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
	// Current
	m_edtCurrent.SetFont( &m_fntEdit );
	m_edtCurrent.SetForeColor( BLACK_COLOR );
	m_edtCurrent.SetBackColor( WHITE_COLOR );
	m_edtCurrent.SetReceivedFlag( 3 ); // float
	
	// Frequency
	m_edtFreq.SetFont( &m_fntEdit );
	m_edtFreq.SetForeColor( BLACK_COLOR );
	m_edtFreq.SetBackColor( WHITE_COLOR );
	m_edtFreq.SetReceivedFlag( 1 ); // Integer
	m_edtFreq.SetWindowText( _T("1000") );
	
	// Z Offset
	m_edtZOffset.SetFont( &m_fntEdit );
	m_edtZOffset.SetForeColor( BLACK_COLOR );
	m_edtZOffset.SetBackColor( WHITE_COLOR );
	m_edtZOffset.SetReceivedFlag( 3 ); // float
	m_edtZOffset.SetWindowText( _T("3") );
	
	// SP
	m_edtSP.SetFont( &m_fntEdit );
	m_edtSP.SetForeColor( BLACK_COLOR );
	m_edtSP.SetBackColor( WHITE_COLOR );
	m_edtSP.SetReceivedFlag( 1 ); // Integer
	m_edtSP.SetWindowText( _T("3") );

	// JD
	m_edtJD.SetFont( &m_fntEdit );
	m_edtJD.SetForeColor( BLACK_COLOR );
	m_edtJD.SetBackColor( WHITE_COLOR );
	m_edtJD.SetReceivedFlag( 1 ); // Integer
	m_edtJD.SetWindowText( _T("3") );

	// Laser on delay
	m_edtLOND.SetFont( &m_fntEdit );
	m_edtLOND.SetForeColor( BLACK_COLOR );
	m_edtLOND.SetBackColor( WHITE_COLOR );
	m_edtLOND.SetReceivedFlag( 1 ); // Integer
	m_edtLOND.SetWindowText( _T("3") );

	// Laser off delay
	m_edtLOFFD.SetFont( &m_fntEdit );
	m_edtLOFFD.SetForeColor( BLACK_COLOR );
	m_edtLOFFD.SetBackColor( WHITE_COLOR );
	m_edtLOFFD.SetReceivedFlag( 1 ); // Integer
	m_edtLOFFD.SetWindowText( _T("3") );
	
	// Aperture File Path
	m_edtFile.SetFont( &m_fntEdit );
	m_edtFile.SetForeColor( BLACK_COLOR );
	m_edtFile.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtFile.SetWindowText( _T("") );
	m_edtFile.EnableWindow( FALSE );
}

void CDlgApertureSet::OnButtonApertureOpen() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listAperture.GetSelectionMark();
	if(-1 == sel || sel >= MAX_SHOT_NO_UV) 
	{
		ErrMessage(_T("Please select item what you want change."));
		return;
	}
	
	TCHAR BASED_CODE szFilter[] = _T("APL File (*.apl)|*.apl|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.apl"), NULL, dwFlags, szFilter);
	
	if(IDOK != dlg.DoModal())
	{
		m_listAperture.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listAperture.SetFocus();
		m_listAperture.EnsureVisible(sel, TRUE );
		return;
	}
	
	CString strPath;
	
	strPath.Format(_T("%s"), dlg.GetPathName());
	m_edtFile.SetWindowText( (LPCTSTR)strPath );
	EnableAllItem(TRUE);
	
	m_listAperture.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listAperture.SetFocus();
	m_listAperture.EnsureVisible(sel, TRUE );
}

void CDlgApertureSet::OnButtonApertureDel() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listAperture.GetSelectionMark();
	if(-1 == sel || sel >= MAX_SHOT_NO_UV) 
	{
		ErrMessage(_T("Please select item what you want change."));
		return;
	}
	
	m_edtFile.SetWindowText("");
	EnableAllItem(FALSE);

	m_listAperture.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listAperture.SetFocus();
	m_listAperture.EnsureVisible(sel, TRUE );
}

void CDlgApertureSet::LoadData()
{
	m_listAperture.DeleteAllItems();
	
	for(int i = 0; i < MAX_SHOT_NO_UV; i++)
		AddData(i);

	ChangeDisplay(0);
	m_listAperture.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
	m_listAperture.SetFocus();
	m_listAperture.EnsureVisible( 0, TRUE );
}

void CDlgApertureSet::AddData(int nIndex)
{
	LV_ITEM lvItem;
	CString strText;
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.iItem = nIndex;
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	//Tool No
	lvItem.iSubItem = 0;
	strText.Format(_T("%.2f"), m_ApertureData[nIndex].dCurrent);
	lvItem.pszText = (LPSTR)(LPCSTR)strText;//szText;
	nIndex = m_listAperture.InsertItem(&lvItem);
	
	strText.Format(_T("%.2f"), m_ApertureData[nIndex].dCurrent);
	m_listAperture.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nMask);
	m_listAperture.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nFreq);
	m_listAperture.SetItemText(nIndex, 2, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%.3f"), m_ApertureData[nIndex].dZOffset);
	m_listAperture.SetItemText(nIndex, 3, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), m_ApertureData[nIndex].nSP);
	m_listAperture.SetItemText(nIndex, 4, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), m_ApertureData[nIndex].nJD);
	m_listAperture.SetItemText(nIndex, 5, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), m_ApertureData[nIndex].nLOnD);
	m_listAperture.SetItemText(nIndex, 6, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), m_ApertureData[nIndex].nLOffD);
	m_listAperture.SetItemText(nIndex, 7, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%s"), m_ApertureData[nIndex].cAperture);
	m_listAperture.SetItemText(nIndex, 8, (LPSTR)(LPCSTR)strText);
	
}

void CDlgApertureSet::ChangeDisplay(int nIndex)
{
	CString str;

	str.Format(_T("%.2f"), m_ApertureData[nIndex].dCurrent);
	m_edtCurrent.SetWindowText(str);
	
	m_cmbMask.SetCurSel(m_ApertureData[nIndex].nMask);
	
	str.Format(_T("%d"), m_ApertureData[nIndex].nFreq);
	m_edtFreq.SetWindowText(str);
	
	str.Format(_T("%.3f"), m_ApertureData[nIndex].dZOffset);
	m_edtZOffset.SetWindowText(str);
	
	str.Format(_T("%d"), m_ApertureData[nIndex].nSP);
	m_edtSP.SetWindowText(str);
	
	str.Format(_T("%d"), m_ApertureData[nIndex].nJD);
	m_edtJD.SetWindowText(str);
	
	str.Format(_T("%d"), m_ApertureData[nIndex].nLOnD);
	m_edtLOND.SetWindowText(str);
	
	str.Format(_T("%d"), m_ApertureData[nIndex].nLOffD);
	m_edtLOFFD.SetWindowText(str);

	str.Format(_T("%s"), m_ApertureData[nIndex].cAperture);
	m_edtFile.SetWindowText(str);
	
	if(str.CompareNoCase("") == 0)
		EnableAllItem(FALSE);
	else
		EnableAllItem(TRUE);

	UpdateData(FALSE);
}

void CDlgApertureSet::EnableAllItem(BOOL bEnable)
{
	GetDlgItem(IDC_EDIT_CUR)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_Z_OFFSET)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SP)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_JD)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_LOND)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_LOFFD)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APERTURE_DEL)->EnableWindow(bEnable);
	GetDlgItem(IDC_LIST_APERTURE_PARAM)->EnableWindow(TRUE);
}

void CDlgApertureSet::OnClickListApertureParam(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int sel = m_listAperture.GetSelectionMark();
	if(-1 == sel || sel >= MAX_SHOT_NO_UV) 
	{
		ErrMessage(_T("Please select item what you want change."));
		return;
	}
	
	ChangeDisplay(sel);

	m_listAperture.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listAperture.SetFocus();
	m_listAperture.EnsureVisible(sel, TRUE );

	*pResult = 0;
}

void CDlgApertureSet::OnButtonParamUpdate() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listAperture.GetSelectionMark();
	if(-1 == sel || sel >= MAX_SHOT_NO_UV) 
	{
		ErrMessage(_T("Please select item what you want change."));
		return;
	}
	
	ChangeData(sel);
	UpdateList(sel);
	
	m_listAperture.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listAperture.SetFocus();
	m_listAperture.EnsureVisible(sel, TRUE );
}

void CDlgApertureSet::ChangeData(int nIndex)
{
	CString str;

	APERTUREDATA ApertureData;
	
	m_edtFile.GetWindowText(str);
	strcpy_s(ApertureData.cAperture, str);
	
	m_edtCurrent.GetWindowText(str);
	ApertureData.dCurrent = atof(str);
	if(ApertureData.dCurrent > MAX_CURRENT || ApertureData.dCurrent <= 0)
	{
		m_edtCurrent.SetFocus();
		ErrMessage(_T("Current must be under 100%."));
		return;
	}
	
	ApertureData.nMask = m_cmbMask.GetCurSel();

	m_edtFreq.GetWindowText(str);
	ApertureData.nFreq = atoi(str);
	if(ApertureData.nFreq > MAX_FREQ || ApertureData.nFreq < MIN_FREQ)
	{
		m_edtFreq.SetFocus();
		ErrMessage(_T("Freq. is between 1000 ~ 10000hz."));
		return;
	}
	
	m_edtZOffset.GetWindowText(str);
	ApertureData.dZOffset = atof(str);
	if(fabs(ApertureData.dZOffset) > MAX_Z_OFFSET)
	{
		m_edtZOffset.SetFocus();
		ErrMessage(_T("Offset must be under +- 5mm ."));
		return;
	}
	
	m_edtSP.GetWindowText(str);
	ApertureData.nSP = atoi(str);
	if(ApertureData.nSP > MAX_SCANNER_PARAM || ApertureData.nSP < MIN_SP)
	{
		m_edtSP.SetFocus();
		ErrMessage(_T("Step period is between 10 ~ 65535."));
		return;
	}
	
	m_edtJD.GetWindowText(str);
	ApertureData.nJD = atoi(str);
	if(ApertureData.nJD > MAX_SCANNER_PARAM || ApertureData.nJD < 0)
	{
		m_edtJD.SetFocus();
		ErrMessage(_T("Jump Delay is between 0 ~ 65535."));
		return;
	}

	m_edtLOND.GetWindowText(str);
	ApertureData.nLOnD = atoi(str);
	if(ApertureData.nLOnD > MAX_SCANNER_PARAM || ApertureData.nLOnD < 0)
	{
		m_edtLOND.SetFocus();
		ErrMessage(_T("Laser On Delay is between 0 ~ 65535."));
		return;
	}

	m_edtLOFFD.GetWindowText(str);
	ApertureData.nLOffD = atoi(str);
	if(ApertureData.nLOffD > MAX_SCANNER_PARAM || ApertureData.nLOffD < 0)
	{
		m_edtLOFFD.SetFocus();
		ErrMessage(_T("Laser Off Delay is between 0 ~ 65535"));
		return;
	}

	m_ApertureData[nIndex] = ApertureData;
}

void CDlgApertureSet::UpdateList(int nIndex)
{
	CString strText;
	
	strText.Format(_T("%.2f"), m_ApertureData[nIndex].dCurrent);
	m_listAperture.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nMask);
	m_listAperture.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nFreq);
	m_listAperture.SetItemText(nIndex, 2, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%.3f"), m_ApertureData[nIndex].dZOffset);
	m_listAperture.SetItemText(nIndex, 3, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nSP);
	m_listAperture.SetItemText(nIndex, 4, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nJD);
	m_listAperture.SetItemText(nIndex, 5, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nLOnD);
	m_listAperture.SetItemText(nIndex, 6, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), m_ApertureData[nIndex].nLOffD);
	m_listAperture.SetItemText(nIndex, 7, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%s"), m_ApertureData[nIndex].cAperture);
	m_listAperture.SetItemText(nIndex, 8, (LPSTR)(LPCSTR)strText);
}

BOOL CDlgApertureSet::DestroyWindow()
{
	m_fntList.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	
	return CDialog::DestroyWindow();
}