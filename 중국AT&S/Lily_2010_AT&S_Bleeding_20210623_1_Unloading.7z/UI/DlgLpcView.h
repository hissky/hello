#if !defined(AFX_DLGLPCVIEW_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_)
#define AFX_DLGLPCVIEW_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLpcView.h : header file
//
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButton.h"
#include "UEasyButtonEx.h"
#include "..\MODEL\DProject.h"
//class DProject;
//class CPaneRecipeGenData;
/////////////////////////////////////////////////////////////////////////////
// CDlgLpcView dialog

class CDlgLpcView : public CDialog
{
// Construction
public:
	void SetTableSuction();
	void DispStatus();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	void DrawData();
	void InitialDrawRatio();
	void SetProject(DProject* pProject);
	CDlgLpcView(CWnd* pParent = NULL);   // standard constructor
	void ChangePosInfo(CPoint ptPick);

	CColorStatic m_stcView;	

	CColorEdit	m_edtPAth;

	UEasyButtonEx	m_btnOpen;
	UEasyButtonEx	m_btnErrorSelect;
	UEasyButtonEx	m_btnSelectView;
	UEasyButtonEx	m_btnPrev;
	UEasyButtonEx	m_btnStart;
	UEasyButtonEx	m_btnNext;
	UEasyButtonEx	m_btnReset;

	int		m_nTimer1;

	CSize	m_siNormalSize;
	CSize	m_siExtendSize;
	CFont			m_fntStatic;
	CFont			m_fntBtn;
	CFont			m_fntEdit;
	
	CPoint  m_ptFidPosition;
	CPoint  m_ptTotalMove;
	CPoint	m_ptDrawRectBack1;
	CPoint	m_ptDrawRectBack2;
	CPoint	m_ptFidPos;
	CPoint	m_ptMoveStart;
	CPoint  m_ptDrawStart;

	CPoint  m_ptOldHolePos;
	BOOL	m_bSearch;
	BOOL	m_bFirstSearch;
	BOOL	m_bPrevStart;
	BOOL	m_bNextStart;
	BOOL	m_bSelect;

	BOOL	m_bDrawMoveStart;
	BOOL	m_bUnitMoveStart;
	BOOL	m_bDisunifyMode;
	BOOL	m_bAddSubFidMode;
	BOOL	m_bSelectFire;

	// ������ Fiducial ���� ����
	BOOL	m_bSetMainFidMode;
	BOOL	m_bResetOneMainFidMode;
	BOOL	m_bSetSubFidMode;
	BOOL	m_bResetOneSubFidMode;

	BOOL m_bViewerMoveMode;
	BOOL IsCheckPathViewMode(CPoint ptPick);
	BOOL IsCheckSelectViewMode(CPoint ptPick);
	BOOL IsPickToolVisible(CPoint ptPick);
	BOOL IsPickUnit(CPoint ptPoint);
	void DrawSelectionRect(CDC* pDC);
	void DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2);
	void MoveToDataPos();
	int GetErrorCount();
	BOOL m_bSelectFidBlock[MAX_FID_BLOCK];
	BOOL m_bShowSortIndex;
	int m_nFieldIndex;
	int m_nCount;
	int m_nErrorMaxCnt;
//	CPaneRecipeGenData* m_pRecipeGenData;
	DProject* m_pProject;
// Dialog Data
	//{{AFX_DATA(CDlgLpcView)
	enum { IDD = IDD_DLG_LPC_VIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


	void EnableAllBtn(BOOL bUse);
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLpcView)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgLpcView)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnButtonFileOpen();
	afx_msg void OnButtonErrorSelect();
	afx_msg void OnBUttonSelectView();
	afx_msg void OnButtonPrev();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonNext();
	afx_msg void OnButtonReset();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLPCVIEW_H__65619F52_DA84_4FBA_91C7_38DC57447DF5__INCLUDED_)
