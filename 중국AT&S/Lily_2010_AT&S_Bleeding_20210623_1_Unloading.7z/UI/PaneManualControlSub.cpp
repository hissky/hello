// PaneManualControlSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlSub.h"
#include "..\easydrillerdlg.h"
#include "paneautorun.h"
#include "..\Model\DSystemINI.h"

#include "DlgShotTable.h"
#include "DlgBeamPathTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlSub

IMPLEMENT_DYNCREATE(CPaneManualControlSub, CFormView)

CPaneManualControlSub::CPaneManualControlSub()
	: CFormView(CPaneManualControlSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo			= 0;
	m_nUserLevel = 0;
}

CPaneManualControlSub::~CPaneManualControlSub()
{
}

void CPaneManualControlSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlSub)
	DDX_Control(pDX, IDC_BUTTON_SET_REF, m_btnSetRef);
	DDX_Control(pDX, IDC_BUTTON_MOVE_REF, m_btnMoveRef);
	DDX_Control(pDX, IDC_BUTTON_FIND_FIDUCIAL, m_btnFindFiducial);
	DDX_Control(pDX, IDC_BUTTON_APPLY_REF, m_btnApplyRef);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	DDX_Control(pDX, IDC_BTN_GO_FIDUCIAL, m_btnGoFiducial);
	DDX_Control(pDX, IDC_BTN_GO_PARAMETER, m_btnGoParameter);

	DDX_Control(pDX, IDC_BUTTON_OPEN_BEAMPATH_TABLE, m_btnOpenBeampath);
	DDX_Control(pDX, IDC_BUTTON_OPEN_SHOT_TABLE, m_btnOpenShot);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlSub, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_BN_CLICKED(IDC_BTN_GO_FIDUCIAL, OnBtnGoFiducial)
	ON_BN_CLICKED(IDC_BTN_GO_PARAMETER, OnBtnGoParameter)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN_BEAMPATH_TABLE, &CPaneManualControlSub::OnBnClickedButtonOpenBeampathTable)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_SHOT_TABLE, &CPaneManualControlSub::OnBnClickedButtonOpenShotTable)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlSub diagnostics

#ifdef _DEBUG
void CPaneManualControlSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlSub message handlers

void CPaneManualControlSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneManualControlSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(130, "Arial Bold");

	// Move Reference Position
	m_btnMoveRef.SetFont( &m_fntBtn2 );
	m_btnMoveRef.SetFlat( FALSE );
	m_btnMoveRef.SetImageOrg( 10, 3 );
	m_btnMoveRef.SetIcon( IDI_MOVEREF );
	m_btnMoveRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveRef.EnableBallonToolTip();
	m_btnMoveRef.SetToolTipText( _T("Move Reference Position") );
	m_btnMoveRef.SetBtnCursor( IDC_HAND_1 );
	m_btnMoveRef.ShowWindow(SW_HIDE);

	// Set Reference Position
	m_btnSetRef.SetFont( &m_fntBtn2 );
	m_btnSetRef.SetFlat( FALSE );
	m_btnSetRef.SetImageOrg( 10, 3 );
	m_btnSetRef.SetIcon( IDI_SETREF, 32, 32 );
	m_btnSetRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetRef.EnableBallonToolTip();
	m_btnSetRef.SetToolTipText( _T("Set Reference Position") );
	m_btnSetRef.SetBtnCursor( IDC_HAND_1 );
	m_btnSetRef.ShowWindow(SW_HIDE);

	// Find Fiducial
	m_btnFindFiducial.SetFont( &m_fntBtn2 );
	m_btnFindFiducial.SetFlat( FALSE );
	m_btnFindFiducial.SetImageOrg( 10, 3 );
	m_btnFindFiducial.SetIcon( IDI_FINDFIDUCIAL, 32, 32 );
	m_btnFindFiducial.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFindFiducial.EnableBallonToolTip();
	m_btnFindFiducial.SetToolTipText( _T("Find Fiducial Mark") );
	m_btnFindFiducial.SetBtnCursor( IDC_HAND_1 );
	m_btnFindFiducial.ShowWindow(SW_HIDE);

	// Apply Reference Position
	m_btnApplyRef.SetFont( &m_fntBtn2 );
	m_btnApplyRef.SetFlat( FALSE );
	m_btnApplyRef.SetImageOrg( 10, 3 );
	m_btnApplyRef.SetIcon( IDI_APPLYREF, 32, 32 );
	m_btnApplyRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyRef.EnableBallonToolTip();
	m_btnApplyRef.SetToolTipText( _T("Apply Reference Position") );
	m_btnApplyRef.SetBtnCursor( IDC_HAND_1 );
	m_btnApplyRef.ShowWindow(SW_HIDE);

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );

	// Go Fiducial
	m_btnGoFiducial.SetFont( &m_fntBtn );
	m_btnGoFiducial.SetFlat( FALSE );
	m_btnGoFiducial.SetImageOrg( 10, 3 );
	m_btnGoFiducial.SetIcon( IDI_PROCESSSETUP, 48, 48 );
	m_btnGoFiducial.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGoFiducial.EnableBallonToolTip();
	m_btnGoFiducial.SetToolTipText( _T("Move ProcessSetup - Fiducial") );
	m_btnGoFiducial.SetBtnCursor( IDC_HAND_1 );
	m_btnGoFiducial.ShowWindow(SW_HIDE);

	// Go Parameter
	m_btnGoParameter.SetFont( &m_fntBtn );
	m_btnGoParameter.SetFlat( FALSE );
	m_btnGoParameter.SetImageOrg( 10, 3 );
	m_btnGoParameter.SetIcon( IDI_PROCESSSETUP, 48, 48 );
	m_btnGoParameter.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGoParameter.EnableBallonToolTip();
	m_btnGoParameter.SetToolTipText( _T("Move Manual - Parameter") );
	m_btnGoParameter.SetBtnCursor( IDC_HAND_1 );
	m_btnGoParameter.ShowWindow(SW_HIDE);

	m_btnOpenBeampath.SetFont( &m_fntBtn );
	m_btnOpenBeampath.SetFlat( FALSE );
	m_btnOpenBeampath.SetImageOrg( 10, 3 );
	m_btnOpenBeampath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenBeampath.EnableBallonToolTip();
	m_btnOpenBeampath.SetToolTipText( _T("Open Beampath") );
	m_btnOpenBeampath.SetBtnCursor( IDC_HAND_1 );

	m_btnOpenShot.SetFont( &m_fntBtn );
	m_btnOpenShot.SetFlat( FALSE );
	m_btnOpenShot.SetImageOrg( 10, 3 );
	m_btnOpenShot.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenShot.EnableBallonToolTip();
	m_btnOpenShot.SetToolTipText( _T("Open Shot") );
	m_btnOpenShot.SetBtnCursor( IDC_HAND_1 );
	
}

void CPaneManualControlSub::OnButtonBack() 
{
	// 110621
/*	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus() && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bLaser && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bInit)
	{
//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
		{		
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = TRUE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
		}
	}
	*/
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );
	
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneManualControlSub::ShowBtnControl(int nCmdShow)
{
//	m_btnMoveRef.ShowWindow(nCmdShow);
//	m_btnSetRef.ShowWindow(nCmdShow);
//	m_btnFindFiducial.ShowWindow(nCmdShow);
//	m_btnApplyRef.ShowWindow(nCmdShow);

	if(nCmdShow == 1)
	{
		m_btnGoFiducial.ShowWindow( SW_HIDE );
		m_btnGoParameter.ShowWindow( SW_HIDE );
	}
	else if(nCmdShow == 2)
	{
		m_btnGoFiducial.ShowWindow( SW_HIDE );
		m_btnGoParameter.ShowWindow( SW_HIDE );
	}
	else
	{
		m_btnGoFiducial.ShowWindow( SW_HIDE );
		m_btnGoParameter.ShowWindow( SW_HIDE );
	}
}

void CPaneManualControlSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlSub::SetBackButton(BOOL bEnable)
{
	m_btnBack.EnableWindow(bEnable);
}

void CPaneManualControlSub::OnBtnGoFiducial() 
{
	WPARAM wParam = PROCESS_SETUP;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 5 ); // Fiducial Tab
}

void CPaneManualControlSub::OnBtnGoParameter() 
{
	WPARAM wParam = MANUAL_CONTROL;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 7 ); // Parameter Tab

	::AfxGetMainWnd()->PostMessage( CHANGE_SUB_PANE, wParam, 7 ); // Parameter Tab
}

BOOL CPaneManualControlSub::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Control_Sub) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneManualControlSub::OnBnClickedButtonOpenBeampathTable()
{
	CDlgBeamPathTable dlg;

	dlg.SetBeamPath(gBeamPathINI.m_sBeampath);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}


void CPaneManualControlSub::OnBnClickedButtonOpenShotTable()
{
	CDlgShotTable dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}

void CPaneManualControlSub::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
	//	m_btnOpenBeampath.ShowWindow( SW_HIDE );
	//	m_btnOpenShot.ShowWindow( SW_HIDE );
		break;
	case 2:
	case 3:
		//m_btnOpenBeampath.ShowWindow( SW_SHOW );
		//m_btnOpenShot.ShowWindow( SW_SHOW );
		break;
	}
}
