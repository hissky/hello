#if !defined(AFX_PANERECIPEGENSUB_H__01AC535B_9752_4344_B9B8_D1F795E6AB79__INCLUDED_)
#define AFX_PANERECIPEGENSUB_H__01AC535B_9752_4344_B9B8_D1F795E6AB79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneRecipeGenSub : public CFormView
{
protected:
	CPaneRecipeGenSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenSub)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenSub)
	enum { IDD = IDD_DLG_RECIPE_GEN_SUB };
	UEasyButtonEx	m_btnPrjOpen;
	UEasyButtonEx	m_btnGoVision;
	UEasyButtonEx	m_btnGoFiducial;
	UEasyButtonEx	m_btnPrjSave;
	UEasyButtonEx	m_btnPrjSave2;
	UEasyButtonEx	m_btnPrjInit;

	UEasyButtonEx	m_btnPrjApply;
	UEasyButtonEx	m_btnBack;

	UEasyButtonEx	m_btnOpenBeampath;
	UEasyButtonEx	m_btnOpenShot;

	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		EnableButton(BOOL bEnable);
	BOOL		CheckSameName(CString strPath);
	void		InitBtnControl();
	void		ShowBtnControl(int nCmdShow);
	void		SetBackPaneNo(int nPaneNo)		{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

	void SetAuthorityByLevel(int nLevel);
	int				m_nUserLevel;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenSub)
	public:
	virtual void OnInitialUpdate();
		afx_msg void OnButtonPrjSave2();
		afx_msg void OnButtonPrjApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenSub)
	afx_msg void OnButtonBack();
	afx_msg void OnButtonPrjSave();

	afx_msg void OnBtnGoVision();
	afx_msg void OnBtnGoFiducial();
	afx_msg void OnButtonPrjOpen();
	afx_msg void OnDestroy();
	
	afx_msg void OnButtonDivide();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonOpenBeampathTable();
	afx_msg void OnBnClickedButtonOpenShotTable();
	afx_msg void OnBnClickedButtonPrjInit();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENSUB_H__01AC535B_9752_4344_B9B8_D1F795E6AB79__INCLUDED_)
