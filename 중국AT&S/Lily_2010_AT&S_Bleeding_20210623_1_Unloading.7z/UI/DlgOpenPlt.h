#if !defined(AFX_DLGOPENPLT_H__494C84AC_182A_482C_B76A_7CC0B2166DE4__INCLUDED_)
#define AFX_DLGOPENPLT_H__494C84AC_182A_482C_B76A_7CC0B2166DE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgOpenPlt.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenPlt dialog

class CDlgOpenPlt : public CDialog
{
// Construction
public:
	CDlgOpenPlt(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgOpenPlt)
	enum { IDD = IDD_DLG_OPEN_PLT };
	UINT	m_nFieldSize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgOpenPlt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgOpenPlt)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGOPENPLT_H__494C84AC_182A_482C_B76A_7CC0B2166DE4__INCLUDED_)
