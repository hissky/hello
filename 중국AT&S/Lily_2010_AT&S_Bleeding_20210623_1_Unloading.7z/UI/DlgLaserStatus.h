#pragma once

#include "..\device\devicemotor.h"
#include "UEasyButtonEx.h"
#include "LedButton.h"
// CDlgLaserStatus ��ȭ �����Դϴ�.

class CDlgLaserStatus : public CDialog
{
	DECLARE_DYNAMIC(CDlgLaserStatus)

public:
	CDlgLaserStatus(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgLaserStatus();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_LASER_STATUS };
public:
	void	InitTimer();
	int		m_nTimerID;
	BOOL	m_bLaserStatus[8];
	int		m_nLaserNo;
	void	LaserStatus(int nStatus);
	void	InitBtnControl();
	void	SetLaserNo(int nNo = 0);
	CFont m_fntBtn;
	CLedButton m_ledVSMRLimit;
	CLedButton m_ledTempFault;
	CLedButton m_ledSystemFault;
	CLedButton m_ledEnable;
	CLedButton m_ledDutyCycleLimit;
	CLedButton m_ledShutterFault;
	CLedButton m_ledShutterInterlock;
	CLedButton m_ledSystemInterlock;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL OnInitDialog();
	virtual BOOL DestroyWindow();
};
