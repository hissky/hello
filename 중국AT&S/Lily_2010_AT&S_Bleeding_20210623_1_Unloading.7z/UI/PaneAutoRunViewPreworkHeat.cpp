// PaneAutoRunViewPreworkHeat.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewPreworkHeat.h"
#include "..\model\DProcessINI.h"
#include "..\model\DTempINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkHeat

IMPLEMENT_DYNCREATE(CPaneAutoRunViewPreworkHeat, CFormView)

CPaneAutoRunViewPreworkHeat::CPaneAutoRunViewPreworkHeat()
	: CFormView(CPaneAutoRunViewPreworkHeat::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewPreworkHeat)
		// NOTE: the ClassWizard will add member initialization here
	m_bPreheat = FALSE;
	//}}AFX_DATA_INIT
}

CPaneAutoRunViewPreworkHeat::~CPaneAutoRunViewPreworkHeat()
{
}

void CPaneAutoRunViewPreworkHeat::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewPreworkHeat)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewPreworkHeat, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewPreworkHeat)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkHeat diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewPreworkHeat::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewPreworkHeat::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkHeat message handlers

BOOL CPaneAutoRunViewPreworkHeat::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewPreworkHeat::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
}

void CPaneAutoRunViewPreworkHeat::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_MODULATION_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_FREQ)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PREHEAT_DUTY_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_FREQ_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME_VAL1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetFont( &m_fntStatic );
}

HBRUSH CPaneAutoRunViewPreworkHeat::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->GetSafeHwnd() == pWnd->m_hWnd  )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}



void CPaneAutoRunViewPreworkHeat::ChangeDisplay()
{
	CString str;
	
	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nPreheatModulationTime);
	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetWindowText(str);
	
	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nAutoRunPreheatTime);
	GetDlgItem(IDC_STATIC_PREHEAT_TIME_VAL1)->SetWindowText(str);

	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nAutoRunPreheatFreq);
	GetDlgItem(IDC_STATIC_PREHEAT_FREQ_VAL)->SetWindowText(str);

	str.Format(_T("%.2f"), gProcessINI.m_sProcessCal.dAutoRunPreheatDuty);
	GetDlgItem(IDC_STATIC_PREHEAT_DUTY_VAL)->SetWindowText(str);

	time_t timeNow;
	time(&timeNow);
	
	time_t timeEnd;
	timeEnd = gTempINI.m_sTempTime.nAutoPreheatEndTime;
	
	double dNowTime;
	
	dNowTime = difftime(timeNow, timeEnd); //sec

	dNowTime = dNowTime / 60 / 60 ; // hour  
	str.Format(_T("%.1f"), dNowTime);
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetWindowText(str);

}

void CPaneAutoRunViewPreworkHeat::ActiveStaticForKeyboardError()
{
	GetDlgItem(IDC_STATIC_PREHEAT_TIME)->SetFocus();
}
