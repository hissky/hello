// PaneUserAccount.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneUserAccount.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccount

IMPLEMENT_DYNCREATE(CPaneUserAccount, CFormView)

CPaneUserAccount::CPaneUserAccount()
	: CFormView(CPaneUserAccount::IDD)
{
	//{{AFX_DATA_INIT(CPaneUserAccount)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneUserAccount::~CPaneUserAccount()
{
}

void CPaneUserAccount::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneUserAccount)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneUserAccount, CFormView)
	//{{AFX_MSG_MAP(CPaneUserAccount)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccount diagnostics

#ifdef _DEBUG
void CPaneUserAccount::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneUserAccount::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccount message handlers

void CPaneUserAccount::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	
}
