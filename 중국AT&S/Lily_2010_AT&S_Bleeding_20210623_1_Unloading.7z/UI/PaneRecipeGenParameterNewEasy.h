#if !defined(AFX_PaneRecipeGenParameterNewEasyEASY_H__D409146F_5466_4DBF_892C_444BD7369BDA__INCLUDED_)
#define AFX_PaneRecipeGenParameterNewEasyEASY_H__D409146F_5466_4DBF_892C_444BD7369BDA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenParameterNewEasy.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNewEasy form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "..\model\DProject.h"
#include "..\model\ToolCodeList.h"
#include "..\model\globalvariable.h"
#include "DlgLaserMeasurement.h"
#include "..\device\CorrectTime.h"
class CPaneRecipeGenParameterNewEasy : public CFormView
{
protected:
	CPaneRecipeGenParameterNewEasy();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenParameterNewEasy)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenParameterNewEasy)
	enum { IDD = IDD_DLG_RECIPE_GEN_PARAMETER_NEW_EASY };
	CTreeCtrl	m_ctrTreeTool;
	CListCtrl		m_listMainTool;
	CListCtrl		m_listSubTool;
	CColorComboEx	m_cmbColor;
	CComboBox		m_cmbDrillMethod;
	CComboBox		m_cmbToolType;
	CComboBox		m_cmbBarcodeMatrix;
	CComboBox		m_cmbMask;
	CComboBox		m_cmbCam;
	UEasyButtonEx	m_chkHoleFind;
	UEasyButtonEx	m_chkHoleSorting;
	UEasyButtonEx	m_chkUseTool;
	UEasyButtonEx	m_chkUseToolOrder;
	UEasyButtonEx	m_chkUsePrePower;
	UEasyButtonEx	m_chkUseAperture;

	UEasyButtonEx	m_chkUseBarcodeLineDrill;

	
	UEasyButtonEx	m_chkUseTophat;
	UEasyButtonEx	m_btnUpdateMain;
	UEasyButtonEx	m_btnOpenMainTool;
	UEasyButtonEx	m_btnSaveMainTool;
	UEasyButtonEx	m_btnUpdate;
	UEasyButtonEx	m_btnAdd;
	UEasyButtonEx	m_btnDelete;
	UEasyButtonEx	m_btnSetting;
	UEasyButtonEx	m_btnFileOpen;
	UEasyButtonEx	m_btnScannerProfileOpen;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnFire;
	UEasyButtonEx	m_btnPower;	
	UEasyButtonEx	m_chkUseFlipX;
	UEasyButtonEx	m_chkUseFlipY;
	UEasyButtonEx	m_chkAllShowTool;
	UEasyButtonEx	m_btnPowerStop;
	CColorEdit		m_edtMainTcode;
	CColorEdit		m_edtSubTcode;
	CColorEdit		m_edtToolSize;
	CColorEdit		m_edtSubNo;
	CColorEdit		m_edtDrawStep;
	CColorEdit		m_edtJumpStep;
	CColorEdit		m_edtDrawStepPeriod;
	CColorEdit		m_edtJumpStepPeriod;
	CColorEdit		m_edtCornerDelay;
	CColorEdit		m_edtJumpDelay;
	CColorEdit		m_edtLineDelay;
	CColorEdit		m_edtLaserOnDelay;
	CColorEdit		m_edtLaserOffDelay;
	CColorEdit		m_edtFrequency;
	CColorEdit		m_edtFPS;
	CColorEdit		m_edtCurrent;
	CColorEdit		m_edtA1;
	CColorEdit		m_edtA2;
	CColorEdit		m_edtTotalShot;
	CColorEdit		m_edtBurstShot;
	CColorEdit		m_edtLeadIn;
	CColorEdit		m_edtLeadOut;
	CColorEdit		m_edtTableSpeed;
	CColorEdit		m_edtRotate;
	CColorEdit		m_edtAperturePath;
	CColorEdit		m_edtScannerProfilePath;
	CColorEdit		m_edtApertureBurst;
	CColorEdit		m_edtMinShotTime;
	CColorEdit		m_edtThermalTrack;
	CColorEdit		m_edtZOffset;
	CColorEdit		m_edtMemo;
	CColorEdit		m_edtMinPower;
	CColorEdit		m_edtMaxPower;
	CColorEdit		m_edtHoleSize;
	CColorEdit		m_edtGridX;
	CColorEdit		m_edtGridY;
	CColorEdit		m_edtFieldSize;
	CColorEdit		m_edtPowerResult;
	CColorEdit		m_edtLotID;
	CColorEdit		m_edtFontSize;
	CColorEdit		m_edtToolPath;
	//}}AFX_DATA

// Attributes
public:
	CToolCodeList* m_pToolCode[MAX_TOOL_NO];

	CCorrectTime	m_StandbyTime;
	int				m_nUserLevel;
	double			m_dDuty[MAX_BEAM_HOLE];
	double			m_dAOMDelay[MAX_BEAM_HOLE];
	double			m_dAOMDuty[MAX_BEAM_HOLE];
	double			m_dMinFreq[MAX_BEAM_HOLE];
	double			m_dMaxFreq[MAX_BEAM_HOLE];

	double			m_dDutyOffsetM[MAX_BEAM_HOLE];
	double			m_dDutyOffsetS[MAX_BEAM_HOLE];
	double			m_dVolOffsetM[MAX_BEAM_HOLE];
	double			m_dVolOffsetS[MAX_BEAM_HOLE];

	TCHAR			m_cAOMFilePath[MAX_BEAM_HOLE][255];
	double			m_dPowerMin[MAX_BEAM_HOLE];
	double			m_dPowerMax[MAX_BEAM_HOLE];

	BOOL			m_bUseTool;
	BOOL			m_bToolOrder;
	BOOL			m_bUseAperture;
	BOOL			m_bUseBarcodeLineDrill;
	BOOL			m_bUseFlipX;
	BOOL			m_bUseFlipY;
	BOOL			m_bUsePrePower;

	BOOL			m_bGlobalParam;
	BOOL			m_bConnectVision;
	CString			m_strPath;
	int				m_nToolIndex;
	int				m_nSubIndex;
	int				m_nFieldSize;
	int				m_nGridX;
	int				m_nGridY;
	CString			m_strMemo;
	double			m_dMin[MAX_TOOL_NO];
	double			m_dMax[MAX_TOOL_NO];
	double			m_dMeasuredPower;
	BOOL			m_bUserDummyOn;
	CDlgLaserMeasurement m_dlgMeasurement;
	double			m_dBaseZ1;
	double			m_dBaseZ2;
	BOOL			m_bStop;
	BOOL			m_bPowerStop;
	CWinThread*		m_pThread;
	TCHAR			m_szToolName[125];
// Operations
public:
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	void SetFirstSubShot(SUBTOOLDATA& subData);
	BOOL CheckLaserDutyLimit(SUBTOOLDATA subData);
	void StopProcess();
	void CheckAnyDoPrework();
	BOOL CheckStatus(BOOL bPower);
	void OnMoveVisionView();
	BOOL UpdateNewParam(SUBTOOLDATA subTool);
	void ShowControl(BOOL bGlobal);
	void MessageLoop();
	void WaitOneFireProcess();
	BOOL MoveVisionFoucs(BOOL b1st, BOOL bHighCam);
	BOOL InPositionCheck();
	BOOL ChangeOneSubTool(SUBTOOLDATA subTool, BOOL bPower = FALSE);
	BOOL LaserFire();
	BOOL ShutterMove(BOOL bMaster, BOOL bSlave);
	void ConnectView();
	void ApertureControlEnable(BOOL bShow);
	void ChangeBeamPathData();
	void SetEditBoxActive(int i);
	void DrawBarcode();
	BOOL SetData(GlobalVariable& mGlobal, int nMainTool = 0);
	BOOL CheckSubTool(SUBTOOLDATA subData, int nToolNum);
	int GetUseToolIndex(int nIndex);
	void UpdateList(int nMainIndex, int nSubIndex);
	BOOL ChangeDataMain(int nMainIndex);
	void ChangeData(int nMainIndex, int nSubIndex);
	void ChangeDisplay(int nMainIndex, int nSubIndex);
	void AddParameter(int nMainIndex);
	BOOL SetData(DProject& mDproject);
	BOOL GetData(DProject& tempDProject);
	void InitListControl();
	void InitStaticControl();
	void InitBtnControl();
	void InitComboControl();
	void InitEditControl();

	void GetColor(int nIndex, CString& strText);

	void EnableControl(BOOL bUse);

	void SetAuthorityByLevel(int nLevel);
	void ChangeLotID(CString strLotID);
	BOOL ParameterOpen(BOOL bComSol);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenParameterNewEasy)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenParameterNewEasy();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntEdit2;
	CFont		m_fntBtn;
	CFont		m_fntBtn2;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenParameterNewEasy)
	afx_msg void OnClickListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelChangeComboColor();
	afx_msg void OnSelChangeComboDrillMethod();
	afx_msg void OnSelChangeCombobBarcodeMatrix();
	afx_msg void OnSelChangeComboToolType();
	afx_msg void OnSelChangeComboMask();
	afx_msg void OnButtonApertureOpen();
	afx_msg void OnButtonSetting();
	afx_msg void OnButtonParamAdd();
	afx_msg void OnButtonParamDelete();
	afx_msg void OnButtonParamUpdate();
	afx_msg void OnButtonParamUpdateMain();
	afx_msg void OnButtonFire();
	afx_msg void OnCheckUseTool();
	afx_msg void OnCheckUseToolOrder();
	afx_msg void OnCheckUseAperture();
	afx_msg void OnCheckUseBarcodeLineDrill();
	afx_msg void OnCheckUsePrePower();
	afx_msg void OnCheckUseHoleFind();
	afx_msg void OnCheckUseHoleSorting();
	afx_msg void OnDestroy();
	afx_msg void OnButtonSubProfileOpen();
	afx_msg void OnChangeEditSubTotalShot();
	afx_msg void OnItemchangingListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangingListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCheckSubXFlip();
	afx_msg void OnCheckSubYFlip();
	afx_msg void OnPaint();
	afx_msg void OnChangeEditSubRotate();
	afx_msg void OnButtonParamOpen();
	afx_msg void OnButtonParamSave();
	afx_msg void OnSelchangedTreeTool(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeEditSubDrawStep();
	afx_msg void OnChangeEditSubFrequency();
	afx_msg void OnChangeEditSubLaserOffDelay();
	afx_msg void OnChangeEditSubLaserOnDelay();
	afx_msg void OnChangeEditSubBurstShot();
	afx_msg void OnChangeEditSubApertureBurst();
	afx_msg void OnChangeEditSize();
	afx_msg void OnChnageEditMax();
	afx_msg void OnChnageEditMin();
	afx_msg void OnChnageEditMarkingSize();
	afx_msg void OnChangeEditSubMinShotTime();
	afx_msg void OnChnageEditLotID();
	afx_msg void OnCheckShowTool();
	afx_msg void OnDropdownComboSubMask();
	afx_msg void OnButtonStop();
	afx_msg LRESULT OnInspection(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButtonPower();
	afx_msg LRESULT OnPowerMeasure(WPARAM wParam = NULL, LPARAM lParam = NULL);	
	afx_msg void OnSelchangeComboCamera();
	afx_msg void OnButtonPowerStop();
	afx_msg void OnKillfocusEditLotId();
	afx_msg void OnKillfocusEditMarkingSize();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PaneRecipeGenParameterNewEasy_H__D409146F_5466_4DBF_892C_444BD7369BDA__INCLUDED_)
