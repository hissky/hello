// PaneSysSetupZCal.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupZCal.h"
#include "..\EasyDrillerDlg.h"
#include "..\device\hdevicefactory.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\model\DSystemINI.h"
#include <fstream>
#include "..\device\devicemotor.h"
#include <math.h>
#include "..\device\HHeightSensor.h"
#include "..\alarmmsg.h"
#include "paneautorun.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupZCal

IMPLEMENT_DYNCREATE(CPaneSysSetupZCal, CFormView)

CPaneSysSetupZCal::CPaneSysSetupZCal()
	: CFormView(CPaneSysSetupZCal::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupZCal)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneSysSetupZCal::~CPaneSysSetupZCal()
{
	ClearMem();
}

void CPaneSysSetupZCal::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupZCal)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_STATIC_RANGE_MIN, m_stcRangeMin);
	DDX_Control(pDX, IDC_STATIC_RANGE_MAX, m_stcRangeMax);
	DDX_Control(pDX, IDC_EDIT_GRID_X, m_edtGridX);
	DDX_Control(pDX, IDC_EDIT_GRID_Y, m_edtGridY);
	DDX_Control(pDX, IDC_EDIT_LENGTH, m_edtLength);
	DDX_Control(pDX, IDC_EDIT_AXIS_Z, m_edtAxisZ);
	DDX_Control(pDX, IDC_BUTTON_TEST_Z, m_btnTestZ);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BUTTON_PROOF, m_btnProof);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_COMBO_HEAD, m_cmbHead);

	DDX_Control(pDX, IDC_EDIT_HEIGHT_OFFSETX, m_edtHeightOffsetX);
	DDX_Control(pDX, IDC_EDIT_HEIGHT_OFFSETY, m_edtHeightOffsetY);
	

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupZCal, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupZCal)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_TEST_Z, OnButtonTestZ)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_PROOF, OnButtonProof)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_HEIGHT_UP, &CPaneSysSetupZCal::OnBnClickedButtonHeightUp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupZCal diagnostics

#ifdef _DEBUG
void CPaneSysSetupZCal::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupZCal::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupZCal message handlers

void CPaneSysSetupZCal::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitListBoxControl();

	m_CalHead.dOffset = NULL;
	m_bStop = FALSE;
	m_bFinish = FALSE;

//	SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
}

void CPaneSysSetupZCal::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));

	// Group
	GetDlgItem(IDC_STATIC_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAL_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MEASURE_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_GRID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MEASURE_LENGTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AXIS_Z)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HEAD)->SetFont( &m_fntStatic );
	
	// Range
	m_stcRangeMin.SetFont( &m_fntStatic );
	m_stcRangeMin.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeMin.SetBackColor( WHITE_COLOR );
	m_stcRangeMin.SetWindowText( _T("0.0") );

	m_stcRangeMax.SetFont( &m_fntStatic );
	m_stcRangeMax.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeMax.SetBackColor( WHITE_COLOR );
	m_stcRangeMax.SetWindowText( _T("0.0") );
}

void CPaneSysSetupZCal::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130,_T("Arial Bold"));

	// Test Z
	m_btnTestZ.SetFont( &m_fntBtn );
	m_btnTestZ.SetFlat( FALSE );
	m_btnTestZ.EnableBallonToolTip();
	m_btnTestZ.SetToolTipText( _T("Test Z") );
	m_btnTestZ.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTestZ.SetBtnCursor(IDC_HAND_1);

	// Start
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Calibration Start") );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.SetBtnCursor( IDC_HAND_1 );

	// Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Calibration Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor( IDC_HAND_1 );

	// Apply
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// Proof
	m_btnProof.SetFont( &m_fntBtn );
	m_btnProof.SetFlat( FALSE );
	m_btnProof.EnableBallonToolTip();
	m_btnProof.SetToolTipText( _T("Proof") );
	m_btnProof.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProof.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupZCal::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150,_T("Arial Bold"));

	// Grid
	m_edtGridX.SetFont( &m_fntEdit );
	m_edtGridX.SetForeColor( BLACK_COLOR );
	m_edtGridX.SetBackColor( WHITE_COLOR );
	m_edtGridX.SetReceivedFlag( 1 );
	m_edtGridX.SetWindowText( _T("5") );

	m_edtGridY.SetFont( &m_fntEdit );
	m_edtGridY.SetForeColor( BLACK_COLOR );
	m_edtGridY.SetBackColor( WHITE_COLOR );
	m_edtGridY.SetReceivedFlag( 1 );
	m_edtGridY.SetWindowText( _T("5") );

	// Length
	m_edtLength.SetFont( &m_fntEdit );
	m_edtLength.SetForeColor( BLACK_COLOR );
	m_edtLength.SetBackColor( WHITE_COLOR );
	m_edtLength.SetReceivedFlag( 3 );
	m_edtLength.SetWindowText( _T("100.0") );


	m_edtHeightOffsetX.SetFont( &m_fntEdit );
	m_edtHeightOffsetX.SetForeColor( BLACK_COLOR );
	m_edtHeightOffsetX.SetBackColor( WHITE_COLOR );
	m_edtHeightOffsetX.SetReceivedFlag( 3 );
	m_edtHeightOffsetX.SetWindowText( _T("0.0") );

	m_edtHeightOffsetY.SetFont( &m_fntEdit );
	m_edtHeightOffsetY.SetForeColor( BLACK_COLOR );
	m_edtHeightOffsetY.SetBackColor( WHITE_COLOR );
	m_edtHeightOffsetY.SetReceivedFlag( 3 );
	m_edtHeightOffsetY.SetWindowText( _T("0.0") );

	// Axis Z
	m_edtAxisZ.SetFont( &m_fntEdit );
	m_edtAxisZ.SetForeColor( BLACK_COLOR );
	m_edtAxisZ.SetBackColor( WHITE_COLOR );
	m_edtAxisZ.SetReceivedFlag( 3 );
	m_edtAxisZ.SetWindowText( _T("10.0") );

	m_cmbHead.SetFont( &m_fntEdit );
	m_cmbHead.SetCurSel(0);

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 1)
	{
		m_cmbHead.EnableWindow(FALSE);
	}
}

void CPaneSysSetupZCal::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(130,_T("Arial Bold"));
	
//	m_lboxResult.SetFont( &m_fntListBox );
}

BOOL CPaneSysSetupZCal::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

HBRUSH CPaneSysSetupZCal::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_RESULT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MEASURE_RESULT)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupZCal::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntListBox.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneSysSetupZCal::OnButtonTestZ()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);

	SetButtonControl(FALSE, FALSE, FALSE, FALSE, FALSE);

	UpdateData(TRUE);

	CString strData;
	m_edtAxisZ.GetWindowText( strData );
	double dPosZ = _tstof(strData);
	
	int nHead = m_cmbHead.GetCurSel();

	if(nHead == 0)
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#endif	
		if (!GetHeightSensor(TRUE, TRUE))	// Down Error
		{
			SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
			return;
		}
	}
	else
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#endif	
		if (!GetHeightSensor(FALSE, TRUE))	// Down Error
		{
			SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
			return;
		}
	}

	if(!gDeviceFactory.GetMotor()->MoveZ(dPosZ, dPosZ, TRUE))
	{
		SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
		return;
	}
	if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_Z1 + IND_Z2))
	{
		SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
		return;
	}
	
	::Sleep(1000);
	
	AddList("Start test measurement.");
	
	double dValue;
	CString strVal;
	int nStatus = gDeviceFactory.GetHeightSensor()->Reading(dValue, nHead);
	if(nStatus == 0)
	{
		strVal.Format(_T("Result : %.3f"),dValue);
		AddList(strVal);
	}
	else if(nStatus == PROBE_UNDER_RANGE)
	{
		strVal = _T("Height is too low.");
		AddList(strVal);
	}
	else if(nStatus == PROBE_OVER_RANGE)
	{
		strVal = _T("Height is too high.");
		AddList(strVal);
	}
	else
	{
		strVal = _T("There is an error.");
		AddList(strVal);
	}
	SetButtonControl(TRUE, TRUE, FALSE, TRUE, FALSE);

	if(nHead == 0)
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif			if (!GetHeightSensor(TRUE, FALSE))	// Up Error
		{
			SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
			return;
		}
	}
	else
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
		if (!GetHeightSensor(FALSE, FALSE))	// Up Error
		{
			SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
			return;
		}
	}

	SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
}

BOOL CPaneSysSetupZCal::GetHeightSensor(BOOL bFirst, BOOL bDown)
{
	int nCount = 0;
	while(TRUE)
	{
		if(gDeviceFactory.GetMotor()->GetCurrentHeight(bFirst, bDown))
			return TRUE;
		if(nCount > 50)	// 5 Sec
			return FALSE;
		nCount++;
#ifndef __TEST__
		Sleep(100);
#endif
	}
	return FALSE;
}

void CPaneSysSetupZCal::AddList(CString strList)
{
	if(m_lboxResult.GetCount() > 100)
		m_lboxResult.DeleteString(0);
	
	m_lboxResult.AddString(strList);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
}

void CPaneSysSetupZCal::OnButtonStart()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);

	if(!InitStart())
		return;

	CString strData;
	m_edtAxisZ.GetWindowText( strData );
	double dPosZ = _tstof(strData);

	int nHead = m_cmbHead.GetCurSel();

	double dStartX, dStartY;
	pMotor->GetPosition(AXIS_X, dStartX);
	pMotor->GetPosition(AXIS_Y, dStartY);

#ifdef __TEST__
	dStartX = 500.0;
	dStartY = 500.0;
#endif

	m_edtGridX.GetWindowText( strData );
	int nGridX = atoi(strData);
	m_edtGridY.GetWindowText( strData );
	int nGridY = atoi(strData);
	m_edtLength.GetWindowText( strData );
	double dDistance = _tstof(strData);


	m_edtHeightOffsetX.GetWindowText( strData );
	double dHeightOffsetX = _tstof(strData);

	m_edtHeightOffsetY.GetWindowText( strData );
	double dHeightOffsetY = _tstof(strData);	

//	m_stcRangeMin.GetWindowText( strData );
	double dMin = INT_MAX;
//	m_stcRangeMax.GetWindowText( strData );
	double dMax = INT_MIN;

	if(!pMotor->MoveZ(dPosZ, dPosZ, TRUE))
	{
		ErrMessage(_T("Can't move Z-axis. Please check z-position value you put in."));
		SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
		return;	
	}
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Z-axis inposition error."));
		SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
		return;
	}
	AddList("Start measurement.");

	DPOINT* dpOffset = NULL;
	DPOINT* dpPos = NULL;
	TRY
	{
		dpOffset = new DPOINT[nGridX * nGridY];
		dpPos = new DPOINT[nGridX * nGridY];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		ErrMessage(_T("Can't create Data."));
		SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
		return;
	}
	END_CATCH
	

	double dXPos, dYPos;
	for(int j = 0; j < nGridY; j++)
	{
		for(int i = 0; i < nGridX; i++)
		{
			if(j%2)
				dXPos = dStartX - dDistance * (nGridX - 1 - i);
			else
				dXPos = dStartX - dDistance * i;
			dYPos = dStartY - dDistance * j;

			if (!pMotor->MoveXY(dXPos, dYPos))
			{
				if (!pMotor->MoveXY(dXPos, dYPos))
				{
					ErrMessage(_T("Can't move table."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;	
				}
				if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("Inposition error."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;	
				}
			}
			else
			{
				if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("Inposition error."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;	
				}
			}
			
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				delete [] dpOffset;
				delete [] dpPos;
				return;		
			}

			if(nHead == 0)
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#endif	
				if (!GetHeightSensor(TRUE, TRUE))	// Down Error
				{
					ErrMessage(_T("Can't move Height sensor block down."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;
				}
			}
			else
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#endif	
				if (!GetHeightSensor(FALSE, TRUE))	// Down Error
				{
					ErrMessage(_T("Can't move Height sensor block down."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;
				}
			}
	

			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				delete [] dpOffset;
				delete [] dpPos;
				return;		
			}
#ifndef __TEST__	
			MessageLoopWait(1000);
			//::Sleep(1000);
#endif			
			double dValue, nCount = 0, dTotalValue = 0;
			for(int k = 0; k < 3; k++)
			{
				int nStatus = gDeviceFactory.GetHeightSensor()->Reading(dValue, nHead);
				if(nStatus == 0)
				{
					CString str;
					str.Format(_T("%.3f (%.3f, %.3f)"),dValue, dXPos, dYPos);
					AddList(str);
					dTotalValue += dValue;
					nCount++;
				}
				else if(nStatus == PROBE_UNDER_RANGE)
				{
					CString strVal, str;
					strVal = _T("Height is too low.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				else if(nStatus == PROBE_OVER_RANGE)
				{
					CString strVal, str;
					strVal = _T("Height is too high.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				else
				{
					CString strVal, str;
					strVal = _T("There is an error.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				MessageLoop();
				if(m_bStop)
				{
					ErrMessage(_T("You clicked the stop button."));
					StopProcess();
					delete [] dpOffset;
					return;	
				}
#ifndef __TEST__
				MessageLoopWait(200);
//				::Sleep(200);
#endif
			}

			if(nCount == 0)
			{
				ErrMessage(_T("Fail to measure."));
				StopProcess();
				delete [] dpOffset;
				delete [] dpPos;
				return;
			}
			else
			{
				if(j%2)
					dpOffset[i * nGridY + (nGridY - 1 - j)].x = dTotalValue/nCount;
				else
					dpOffset[(nGridX - 1 - i) * nGridY + (nGridY - 1 - j)].x = dTotalValue/nCount;

				if(j%2)
				{
					dpPos[i * nGridY + (nGridY - 1 - j)].x = dXPos;
					dpPos[i * nGridY + (nGridY - 1 - j)].y = dYPos;
				}
				else
				{
					dpPos[(nGridX - 1 - i) * nGridY + (nGridY - 1 - j)].x = dXPos;
					dpPos[(nGridX - 1 - i) * nGridY + (nGridY - 1 - j)].y = dYPos;
				}

				CString str2;
				str2.Format(_T(" %.3f, %.3f, %.3f"), dXPos, dYPos,dTotalValue/nCount);
				TRACE("%s\n",str2);
			}

			if(dTotalValue/nCount < dMin) dMin = dTotalValue/nCount;
			if(dTotalValue/nCount > dMax) dMax = dTotalValue/nCount;

			if(nHead == 0)
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	
				if (!GetHeightSensor(TRUE, FALSE))	// Up Error
				{
					ErrMessage(_T("Can't move Height sensor block up."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;
				}
			}
			else
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
				if (!GetHeightSensor(FALSE, FALSE))	// Up Error
				{
					ErrMessage(_T("Can't move Height sensor block up."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					delete [] dpOffset;
					delete [] dpPos;
					return;
				}
			}
	
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				delete [] dpOffset;
				delete [] dpPos;
				return;	
			}
		}
	}




	CString strFile,strVal2;
	strFile.Format(_T("ZCalLog"));

	strVal2.Format(_T("Start Pos (%.3f,%.3f) , Grid (%d,%d),BaseZ(%.3f), Max Z ( %.3f)"), dStartX, dStartY,nGridX,nGridY,dPosZ,dMax);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
	TRACE("%s\n",strVal2);

	for(int j =  0; j < nGridY; j++)
	{
		for(int i = 0; i < nGridX; i++)
		{
			double dTemp = dpOffset[i * nGridY + j].x;
			dpOffset[i * nGridY + j].x = dMax - dpOffset[i * nGridY + j].x;

				double dTempXPos = dpPos[i * nGridY + j].x;
			    double dTempYPos = dpPos[i * nGridY + j].y;


		     strVal2.Format(_T("%d\t%d\t%.3f\t%.3f\t%.3f"), i, j,dTempXPos,dTempYPos,dpOffset[i * nGridY + j].x);
	          ::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strVal2));
			  TRACE("%s , %.3f\n",strVal2,dTemp);

		}
	}

	m_bFinish = TRUE;

	m_CalHead.dGap = dDistance;

	if(m_CalHead.dOffset)
	{
		delete [] m_CalHead.dOffset;
	}

	m_CalHead.dOffset = dpOffset;
	m_CalHead.dXStart = dStartX - (nGridX - 1) * dDistance;// - gProcessINI.m_sProcessFidFind.dRefPosX3;
	m_CalHead.dYStart = dStartY - (nGridY - 1) * dDistance;// - gProcessINI.m_sProcessFidFind.dRefPosY3;
	m_CalHead.nGridX = nGridX;
	m_CalHead.nGridY = nGridY;

	strData.Format(_T("%.3f"), dMin);
	m_stcRangeMin.SetWindowText( strData );
	strData.Format(_T("%.3f"), dMax);
	m_stcRangeMax.SetWindowText( strData );

	SetButtonControl(TRUE, TRUE, FALSE, TRUE, FALSE);
}

BOOL CPaneSysSetupZCal::InitStart()
{
	m_bStop = FALSE;
	m_bFinish = FALSE;
	UpdateData(TRUE);

	double dStartX, dStartY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dStartX);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dStartY);

#ifdef __TEST__
	dStartX = 500.0;
	dStartY = 500.0;
#endif

	CString strData;	
	m_edtGridX.GetWindowText( strData );
	int nGridX = _ttoi(strData);
	m_edtGridY.GetWindowText( strData );
	int nGridY = _ttoi(strData);
	m_edtLength.GetWindowText( strData );
	double dDistance = _tstof(strData);

	m_edtHeightOffsetX.GetWindowText( strData );
	double dHeightOffsetX = _tstof(strData);

	m_edtHeightOffsetY.GetWindowText( strData );
	double dHeightOffsetY = _tstof(strData);	

			
	if(dStartX < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || dStartX > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus || 
		dStartX - dDistance * (nGridX - 1) < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || dStartX - dDistance * (nGridX - 1) > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus)
	{
		ErrMessage(_T("Axis-X position is out of software-limit."));
		return FALSE;
	}
	if(dStartY < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || dStartY > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus || 
		dStartY - dDistance * (nGridY - 1) < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || dStartY - dDistance * (nGridY - 1) > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
	{
		ErrMessage(_T("Axis-Y position is out of software-limit."));
		return FALSE;
	}
	
	SetButtonControl(FALSE, FALSE, TRUE, FALSE, FALSE);
	
	return TRUE;
}

void CPaneSysSetupZCal::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CPaneSysSetupZCal::StopProcess()
{
	int nHead = m_cmbHead.GetCurSel();

	if(nHead == 0)
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	
		if (!GetHeightSensor(TRUE, FALSE))	// Up Error
		{
			ErrMessage(_T("Can't move Height sensor block up."));
			return;
		}
	}
	else
	{
#ifdef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
		if (!GetHeightSensor(FALSE, FALSE))	// Up Error
		{
			ErrMessage(_T("Can't move Height sensor block up."));
			return;
		}
	}

	SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
}

void CPaneSysSetupZCal::OnButtonStop()
{
	m_bStop = TRUE;
	
	SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
}

void CPaneSysSetupZCal::OnButtonApply()
{
	SetButtonControl(FALSE, FALSE, FALSE, FALSE, FALSE);
	
	if(!m_bFinish)
	{
		ErrMessage(_T("You don't need to apply."));
		return;
	}

	int nHead = m_cmbHead.GetCurSel();
	

	if(nHead == 0)
		gDeviceFactory.GetMotor()->UpdateZCalibrationFile(m_CalHead, TRUE);
	else
		gDeviceFactory.GetMotor()->UpdateZCalibrationFile(m_CalHead, FALSE);
	
	m_bFinish = FALSE;
	
	SetButtonControl(TRUE, TRUE, FALSE, FALSE, TRUE);
}

void CPaneSysSetupZCal::OnButtonProof()
{
	UpdateData(TRUE);

	double dOffset;
	double m_dMax = 0;
	double m_dMin = 1000;

	AddList("Start measurement.");

	CString strPath;
	strPath.Format(_T("%sTemp\\ZProof.txt"), gEasyDrillerINI.m_clsDirPath.GetRootDir());

	FILE * pfile;
	errno_t err = fopen_s(&pfile, strPath, _T("w+"));


	CString strData;
	m_edtAxisZ.GetWindowText( strData );
	double dPosZ = _tstof(strData);
	
	double dStartX, dStartY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dStartX);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dStartY);
	
	m_edtGridX.GetWindowText( strData );
	int nGridX = atoi(strData);
	m_edtGridY.GetWindowText( strData );
	int nGridY = atoi(strData);
	m_edtLength.GetWindowText( strData );
	double dDistance = _tstof(strData);

	m_edtHeightOffsetX.GetWindowText( strData );
	double dHeightOffsetX = _tstof(strData);

	m_edtHeightOffsetY.GetWindowText( strData );
	double dHeightOffsetY = _tstof(strData);	
	
	m_stcRangeMin.GetWindowText( strData );
	double dMin = _tstof(strData);
	m_stcRangeMax.GetWindowText( strData );
	double dMax = _tstof(strData);
	int nHead = m_cmbHead.GetCurSel();

	double dXPos, dYPos;
	for(int j = 0; j < nGridY; j++)
	{
		for(int i = 0; i < nGridX; i++)
		{
			if(j%2)
				dXPos = dStartX - dDistance * (nGridX - 1 - i);
			else
				dXPos = dStartX - dDistance * i;
			dYPos = dStartY - dDistance * j;

			if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
			{
				if (!gDeviceFactory.GetMotor()->MoveXY(dXPos, dYPos))
				{
					ErrMessage(_T("Can't move table."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;	
				}
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("Inposition error."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;	
				}
			}
			else
			{
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
				{
					ErrMessage(_T("Inposition error."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;	
				}
			}

			if(!gDeviceFactory.GetMotor()->MoveZ(dPosZ, dPosZ, FALSE))
			{
				ErrMessage(_T("Can't move Z-axis. Please check z-position value you put in."));
				SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
				if(err == NULL)
						fclose(pfile);
				return;	
			}
			if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_Z1 + IND_Z2))
			{
				ErrMessage(_T("Z-axis inposition error."));
				SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
				if(err == NULL)
						fclose(pfile);
				return;
			}
			
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				if(err == NULL)
						fclose(pfile);
				return;		
			}

			if(nHead == 0)
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, TRUE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
#endif	
				if (!GetHeightSensor(TRUE, TRUE))	// Down Error
				{
					ErrMessage(_T("Can't move Height sensor block down."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;
				}
			}
			else
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, TRUE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
#endif	
				if (!GetHeightSensor(FALSE, TRUE))	// Down Error
				{
					ErrMessage(_T("Can't move Height sensor block down."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;
				}
			}
			

			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				if(err == NULL)
						fclose(pfile);
				return;		
			}
#ifndef __TEST__			
			::Sleep(1000);
#endif			
			double dValue, nCount = 0, dTotalValue = 0;
			for(int k = 0; k < 5; k++)
			{
				int nStatus = gDeviceFactory.GetHeightSensor()->Reading(dValue, nHead);
				if(nStatus == 0)
				{
					CString str;
					str.Format(_T("%.3f (%.3f, %.3f)"),dValue, dXPos, dYPos);
					AddList(str);
					dTotalValue += dValue;
					nCount++;
				}
				else if(nStatus == PROBE_UNDER_RANGE)
				{
					CString strVal, str;
					strVal = _T("Height is too low.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				else if(nStatus == PROBE_OVER_RANGE)
				{
					CString strVal, str;
					strVal = _T("Height is too high.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				else
				{
					CString strVal, str;
					strVal = _T("There is an error.");
					str.Format(_T(" (%.3f, %.3f)"), dXPos, dYPos);
					strVal = strVal + str;
					AddList(strVal);
				}
				MessageLoop();
				if(m_bStop)
				{
					ErrMessage(_T("You clicked the stop button."));
					StopProcess();
					if(err == NULL)
						fclose(pfile);
					return;	
				}
#ifndef __TEST__
				::Sleep(200);
#endif
			}

			if(nCount == 0)
				dOffset = 0.0;
			else
				dOffset = dTotalValue/nCount;

			if(dOffset < m_dMin) m_dMin = dOffset;
			if(dOffset > m_dMax) m_dMax = dOffset;
			if(err == NULL)
				fprintf_s(pfile, "XPOS=%.3f\tYPOS=%.3f\tXOffset=%.3f\n", dXPos, dYPos, dOffset);

			UpdateData(FALSE);

			if(nHead == 0)
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR, FALSE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
#endif	
				if (!GetHeightSensor(TRUE, FALSE))	// Up Error
				{
					ErrMessage(_T("Can't move Height sensor block up."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;
				}
			}
			else
			{
#ifdef __MP920_MOTOR__
				gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT +PORT_HEIGHT_SENSOR_2, FALSE);
#else
				gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
#endif	
				if (!GetHeightSensor(FALSE, FALSE))	// Up Error
				{
					ErrMessage(_T("Can't move Height sensor block up."));
					SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
					if(err == NULL)
						fclose(pfile);
					return;
				}
			}
	
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("You clicked the stop button."));
				StopProcess();
				if(err == NULL)
						fclose(pfile);
				return;	
			}
		}
	}
	if(err == NULL)
		fclose(pfile);
	SetButtonControl(TRUE, TRUE, FALSE, FALSE, FALSE);
}

void CPaneSysSetupZCal::ClearMem()
{
	if(m_CalHead.dOffset)
	{
		delete [] m_CalHead.dOffset;
		m_CalHead.dOffset = NULL;
	}
}

void CPaneSysSetupZCal::SetButtonControl(BOOL bTest, BOOL bStart, BOOL bStop, BOOL bApply, BOOL bProof)
{
	GetDlgItem(IDC_BUTTON_TEST_Z)->EnableWindow(bTest);
	GetDlgItem(IDC_BUTTON_START)->EnableWindow(bStart);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(bStop);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bApply);
	GetDlgItem(IDC_BUTTON_PROOF)->EnableWindow(bProof);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bStart);
}

BOOL CPaneSysSetupZCal::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_ZCal) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupZCal::SetAuthorityByLevel(int nLevel)
{
#ifndef __KUNSAN_SAMSUNG_LARGE__
	return;
#endif
	switch(nLevel)
	{
	case 0:
	case 1:
	case 2:
		EnableControl(FALSE);
		break;
	case 3:
		EnableControl(TRUE);
		break;
	}

}
void CPaneSysSetupZCal::EnableControl(BOOL bEnable)
{
	GetDlgItem(IDC_COMBO_HEAD)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_X)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_GRID_Y)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_LENGTH)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_AXIS_Z)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_TEST_Z)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_START)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_PROOF)->EnableWindow(bEnable);		
}

void CPaneSysSetupZCal::OnBnClickedButtonHeightUp()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
}
