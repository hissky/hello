#if !defined(AFX_DRILLDATAVIEW_H__93F17560_25DC_42AE_B1D5_1CB1AA603441__INCLUDED_)
#define AFX_DRILLDATAVIEW_H__93F17560_25DC_42AE_B1D5_1CB1AA603441__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DrillDataView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDrillDataView view

class CDrillDataView : public CScrollView
{
public :
	CDrillDataView();           // protected constructor used by dynamic creation
	virtual ~CDrillDataView();

protected:
	DECLARE_DYNCREATE(CDrillDataView)

// Attributes
public:

// Attributes
protected :
	CRect	m_rtView;
	CSize	m_ViewSize;

// Operations
public:
	BOOL	CreateView(CWnd* pParent);
	void	SetViewSize(CRect rt);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrillDataView)
	public:
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CDrillDataView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRILLDATAVIEW_H__93F17560_25DC_42AE_B1D5_1CB1AA603441__INCLUDED_)
