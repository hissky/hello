// MonoCubicInterpolation.cpp: implementation of the CMonoCubicInterpolation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MonoCubicInterpolation.h"
#include "math.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMonoCubicInterpolation::CMonoCubicInterpolation()
{
	m_d1 = m_d2 = m_d3 = m_d4 = NULL;
	m_nXStart = m_nXEnd = m_nYStart = m_nYEnd = 0;
}

CMonoCubicInterpolation::~CMonoCubicInterpolation()
{
	DeleteMemory();
}

void CMonoCubicInterpolation::UpdateWholeCalibration()
{
	if (!m_bIsSet)
		return;
	
	m_nXStart = m_dXStart > MIN_TABLE ? (fmod(m_dXStart, 1.0) == 0.0 ? static_cast<int>(m_dXStart) : static_cast<int>(m_dXStart + 1)) : MIN_TABLE;
	m_nXEnd = m_dXEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dXEnd);
	m_nYStart = m_dYStart > MIN_TABLE ? (fmod(m_dYStart, 1.0) == 0.0 ? static_cast<int>(m_dYStart) : static_cast<int>(m_dYStart + 1)) : MIN_TABLE;
	m_nYEnd = m_dYEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dYEnd);

	MonoCubicX();

	MonoCubicY();

	TRY
	{
		m_d1 = new DPOINT[m_nXEnd - m_nXStart + 1];
		m_d2 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d3 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d4 = new DPOINT[m_nXEnd - m_nXStart + 1];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		DeleteMemory();
		
		return;
	}
	END_CATCH
		
	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		m_d1[nX - m_nXStart].x = m_Matrix[nX][m_nYStart].x;
		m_d1[nX - m_nXStart].y = m_Matrix[nX][m_nYStart].y;
		
		m_d4[nX - m_nXStart].x = m_Matrix[nX][m_nYEnd].x;
		m_d4[nX - m_nXStart].y = m_Matrix[nX][m_nYEnd].y;
	}
	
	for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
	{
		m_d2[nY - m_nYStart].x = m_Matrix[m_nXStart][nY].x;
		m_d2[nY - m_nYStart].y = m_Matrix[m_nXStart][nY].y;
		
		m_d3[nY - m_nYStart].x = m_Matrix[m_nXEnd][nY].x;
		m_d3[nY - m_nYStart].y = m_Matrix[m_nXEnd][nY].y;
	}
	
	for (nX = MIN_TABLE; nX <= MAX_TABLE; nX++)
	{
		for (int nY = MIN_TABLE; nY <= MAX_TABLE; nY++)
		{
			if (!IsPartialInside(nX, nY))
			{
				double dX, dY;
				GetEdgeCalibrationOffset(nX, nY, dX, dY);
				m_Matrix[nX][nY].x += static_cast<float>(dX);
				m_Matrix[nX][nY].y += static_cast<float>(dY);
			}
		}
	}
	DeleteMemory();
}

double CMonoCubicInterpolation::her00(double t)
{
	return 2*t*t*t - 3*t*t +1;
}

double CMonoCubicInterpolation::her01(double t)
{
	return t*t*(3-2*t);
}

double CMonoCubicInterpolation::her10(double t)
{
	return t*(1-t)*(1-t); 
}

double CMonoCubicInterpolation::her11(double t)
{
	return t*t*(t-1);
}

void CMonoCubicInterpolation::MonoCubicX()
{
	double dGetInterval = 1./m_dGap;
	int nGap = (int)(0.1 + m_dGap);
	double* dM, *dM2;
	dM = new double[m_nGridX];
	dM2 = new double[m_nGridX];
	for(int i = 0; i < m_nGridY; i++)
	{
		dM[0] = m_Offset[m_nGridY + i].x - m_Offset[i].x;
		dM[m_nGridX-1] = m_Offset[m_nGridY * (m_nGridX-1) + i].x - m_Offset[m_nGridY * (m_nGridX-2) + i].x;
		dM2[0] = m_Offset[m_nGridY + i].y - m_Offset[i].y;
		dM2[m_nGridX-1] = m_Offset[m_nGridY * (m_nGridX-1) + i].y - m_Offset[m_nGridY * (m_nGridX-2) + i].y; 

		for(int j = 1; j < m_nGridX - 1; j++)
		{
			dM[j] = (m_Offset[m_nGridY * (j) + i].x - m_Offset[m_nGridY * (j-1) + i].x)/2. + (m_Offset[m_nGridY * (j+1) + i].x - m_Offset[m_nGridY * (j) + i].x)/2.;
			dM2[j] = (m_Offset[m_nGridY * (j) + i].y - m_Offset[m_nGridY * (j-1) + i].y)/2. + (m_Offset[m_nGridY * (j+1) + i].y - m_Offset[m_nGridY * (j) + i].y)/2.;
		}

		double dDeltaK, dAk, dBk;
		for(j = 1; j < m_nGridX - 1; j++)
		{
			dDeltaK = (m_Offset[m_nGridY * (j+1) + i].x - m_Offset[m_nGridY * (j) + i].x);
			if(fabs(dDeltaK) < 0.0000001)
			{
				dM[j] = dM[j+1] = 0.;
			}
			else
			{
				dAk = dM[j]/dDeltaK;
				dBk = dM[j+1]/dDeltaK;
				if(dAk*dAk + dBk*dBk > 9)
				{
//					dM[j] = 3/sqrt(dAk*dAk + dBk*dBk)*dAk*dDeltaK;
//					dM[j+1] = 3/sqrt(dAk*dAk + dBk*dBk)*dBk*dDeltaK;
				}
			}

			dDeltaK = (m_Offset[m_nGridY * (j+1) + i].y - m_Offset[m_nGridY * (j) + i].y);
			if(fabs(dDeltaK) < 0.0000001)
			{
				dM2[j] = dM2[j+1] = 0.;
			}
			else
			{
				dAk = dM2[j]/dDeltaK;
				dBk = dM2[j+1]/dDeltaK;
				if(dAk*dAk + dBk*dBk > 9)
				{
//					dM2[j] = 3/sqrt(dAk*dAk + dBk*dBk)*dAk*dDeltaK;
//					dM2[j+1] = 3/sqrt(dAk*dAk + dBk*dBk)*dBk*dDeltaK;
				}
			}
		}
		
		double dCurX, dNextX, dCurVal, dNextVal, dH, dIndex, dT, dResult;
		int nSubIndex;
		for(j = 0; j < m_nGridX - 1; j++)
		{
			dCurX = (double)((int)(0.5 + j));
			dNextX = (double)(j+1);
			dCurVal = m_Offset[m_nGridY * (j) + i].x;
			dNextVal = m_Offset[m_nGridY * (j+1) + i].x;
			dH = dNextX - dCurX;
			dIndex = 0;
			nSubIndex = 0;
			for(dIndex = dCurX; dIndex < dNextX; dIndex+=dGetInterval)
			{
				dT = (dIndex - dCurX)/dH;
				dResult = dCurVal * her00(dT) + dH * dM[j] * her10(dT) + dNextVal * her01(dT) + dH * dM[j+1] * her11(dT);
				m_Matrix[m_nXStart + j*nGap + nSubIndex][m_nYStart + i*nGap].x = dResult;
				nSubIndex++;
			}
			if(j == m_nGridX - 2)
				m_Matrix[m_nXStart + j*nGap + nSubIndex][m_nYStart + i*nGap].x = dNextVal;

			dCurX = (double)((int)(0.5 + j));
			dNextX = (double)(j+1);
			dCurVal = m_Offset[m_nGridY * (j) + i].y;
			dNextVal = m_Offset[m_nGridY * (j+1) + i].y;
			dH = dNextX - dCurX;
			dIndex = 0;
			nSubIndex = 0;
			for(dIndex = dCurX; dIndex < dNextX; dIndex+=dGetInterval)
			{
				dT = (dIndex - dCurX)/dH;
				dResult = dCurVal * her00(dT) + dH * dM2[j] * her10(dT) + dNextVal * her01(dT) + dH * dM2[j+1] * her11(dT);
				m_Matrix[m_nXStart + j*nGap + nSubIndex][m_nYStart + i*nGap].y = dResult;
				nSubIndex++;
			}
			if(j == m_nGridX - 2)
				m_Matrix[m_nXStart + j*nGap + nSubIndex][m_nYStart + i*nGap].y = dNextVal;
		}
	}
	delete [] dM;
	delete [] dM2;
}

void CMonoCubicInterpolation::MonoCubicY()
{
	double dGetInterval = 1./m_dGap;
	int nGap = (int)(0.1 + m_dGap);
	double* dM, *dM2;
	dM = new double[m_nGridY];
	dM2 = new double[m_nGridY];
//	FILE* pf, *pf2;
//	pf = fopen("D:\\Master.txt", "w");
//	pf2 = fopen("D:\\Slave.txt", "w");

	for(int i = 0; i <= m_nXEnd - m_nXStart; i++)
	{
		dM[0] = m_Matrix[m_nXStart + i][m_nYStart + nGap].x - m_Matrix[m_nXStart + i][m_nYStart].x;
		dM[m_nGridY-1] = m_Matrix[m_nXStart + i][m_nYStart + (m_nGridY - 1) * nGap].x - m_Matrix[m_nXStart + i][m_nYStart + (m_nGridY - 2) * nGap].x;
		dM2[0] = m_Matrix[m_nXStart + i][m_nYStart + nGap].y - m_Matrix[m_nXStart + i][m_nYStart].y;
		dM2[m_nGridY-1] = m_Matrix[m_nXStart + i][m_nYStart + (m_nGridY - 1) * nGap].y - m_Matrix[m_nXStart + i][m_nYStart + (m_nGridY - 2) * nGap].y;
		
		for(int j = 1; j < m_nGridY - 1; j++)
		{
			dM[j] = (m_Matrix[m_nXStart + i][m_nYStart + j * nGap].x - m_Matrix[m_nXStart + i][m_nYStart + (j - 1) * nGap].x)/2. 
					+ (m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].x - m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].x)/2.;
			dM2[j] = (m_Matrix[m_nXStart + i][m_nYStart + j * nGap].y - m_Matrix[m_nXStart + i][m_nYStart + (j - 1) * nGap].y)/2. 
					+ (m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].y - m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].y)/2.;
		}
		
		double dDeltaK, dAk, dBk;
		for(j = 1; j < m_nGridY - 1; j++)
		{
			dDeltaK = (m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].x - m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].x);
			if(fabs(dDeltaK) < 0.0000001)
			{
				dM[j] = dM[j+1] = 0.;
			}
			else
			{
				dAk = dM[j]/dDeltaK;
				dBk = dM[j+1]/dDeltaK;
				if(dAk*dAk + dBk*dBk > 9)
				{
//					dM[j] = 3/sqrt(dAk*dAk + dBk*dBk)*dAk*dDeltaK;
//					dM[j+1] = 3/sqrt(dAk*dAk + dBk*dBk)*dBk*dDeltaK;
				}
			}
			
			dDeltaK = (m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].y - m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].y);
			if(fabs(dDeltaK) < 0.0000001)
			{
				dM2[j] = dM2[j+1] = 0.;
			}
			else
			{
				dAk = dM2[j]/dDeltaK;
				dBk = dM2[j+1]/dDeltaK;
				if(dAk*dAk + dBk*dBk > 9)
				{
//					dM2[j] = 3/sqrt(dAk*dAk + dBk*dBk)*dAk*dDeltaK;
//					dM2[j+1] = 3/sqrt(dAk*dAk + dBk*dBk)*dBk*dDeltaK;
				}
			}
		}
		
		double dCurX, dNextX, dCurVal, dNextVal, dH, dIndex, dT, dResult;
		int nSubIndex;
		for(j = 0; j < m_nGridY - 1; j++)
		{
			dCurX = (double)((int)(0.5 + j));
			dNextX = (double)(j+1);
			dCurVal = m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].x;
			dNextVal = m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].x;
			dH = dNextX - dCurX;
			dIndex = 0;
			nSubIndex = 0;
			for(dIndex = dCurX; dIndex < dNextX; dIndex+=dGetInterval)
			{
				dT = (dIndex - dCurX)/dH;
				dResult = dCurVal * her00(dT) + dH * dM[j] * her10(dT) + dNextVal * her01(dT) + dH * dM[j+1] * her11(dT);
				m_Matrix[m_nXStart + i][m_nYStart + j*nGap + nSubIndex].x = dResult;
//				TRACE("%.3f\n", /*m_nXStart + i, m_nYStart + j*nGap + nSubIndex,*/ dResult);
//				fprintf(pf, "%.3f\n", dResult);
//				::Sleep(10);
				nSubIndex++;
			}
			if(j == m_nGridY - 2)
			{
				m_Matrix[m_nXStart + i][m_nYStart + j*nGap + nSubIndex].x = dNextVal;
//				TRACE("%.3f\n", /*m_nXStart + i, m_nYStart + j*nGap + nSubIndex,*/ dNextVal);
//				fprintf(pf, "%.3f\n", dNextVal);
//				::Sleep(10);
			}
			
			dCurX = (double)((int)(0.5 + j));
			dNextX = (double)(j+1);
			dCurVal = m_Matrix[m_nXStart + i][m_nYStart + (j) * nGap].y;
			dNextVal = m_Matrix[m_nXStart + i][m_nYStart + (j+1) * nGap].y;
			dH = dNextX - dCurX;
			dIndex = 0;
			nSubIndex = 0;
			for(dIndex = dCurX; dIndex < dNextX; dIndex+=dGetInterval)
			{
				dT = (dIndex - dCurX)/dH;
				dResult = dCurVal * her00(dT) + dH * dM2[j] * her10(dT) + dNextVal * her01(dT) + dH * dM2[j+1] * her11(dT);
				m_Matrix[m_nXStart + i][m_nYStart + j*nGap + nSubIndex].y = dResult;
//				fprintf(pf2, "%.3f\n", dResult);
//				TRACE("[%d][%d] = %.3f\n", m_nXStart + i, m_nYStart + j*nGap + nSubIndex, dResult);
//				::Sleep(10);
				nSubIndex++;
			}
			if(j == m_nGridY - 2)
			{
				m_Matrix[m_nXStart + i][m_nYStart + j*nGap + nSubIndex].y = dNextVal;
//				fprintf(pf2, "%.3f\n", dNextVal);
//				TRACE("[%d][%d] = %.3f\n", m_nXStart + i, m_nYStart + j*nGap + nSubIndex, dNextVal);
//				::Sleep(10);
			}
		}
	}
//	fclose(pf);
//	fclose(pf2);
	delete [] dM;
	delete [] dM2;
}

void CMonoCubicInterpolation::DeleteMemory()
{
	if(m_d1)
	{
		delete [] m_d1;			m_d1 = NULL;
	}
	if(m_d2)
	{
		delete [] m_d2;			m_d2 = NULL;
	}
	if(m_d3)
	{
		delete [] m_d3;			m_d3 = NULL;
	}
	if(m_d4)
	{
		delete [] m_d4;			m_d4 = NULL;
	}
}

void CMonoCubicInterpolation::GetEdgeCalibrationOffset(double dX, double dY, double &dXOffset, double &dYOffset)
{
	if (dX < m_dXStart && dY < m_dYStart)
	{
		dXOffset = m_d1[0].x;
		dYOffset = m_d1[0].y;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d1[nX].x;
		dYOffset = m_d1[nX].y;
	}
	else if (dX > m_dXEnd && dY < m_dYStart)
	{
		dXOffset = m_d1[m_nXEnd - m_nXStart].x;
		dYOffset = m_d1[m_nXEnd - m_nXStart].y;
	}
	else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d2[nY].x;
		dYOffset = m_d2[nY].y;
	}
	else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d3[nY].x;
		dYOffset = m_d3[nY].y;
	}
	else if (dX < m_dXStart && dY > m_dYEnd)
	{
		dXOffset = m_d4[0].x;
		dYOffset = m_d4[0].y;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d4[nX].x;
		dYOffset = m_d4[nX].y;
	}
	else if (dX > m_dXEnd && dY > m_dYEnd)
	{
		dXOffset = m_d4[m_nXEnd - m_nXStart].x;
		dYOffset = m_d4[m_nXEnd - m_nXStart].y;
	}
	else
		dXOffset = dYOffset = 0.0;
}
