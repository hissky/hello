// BiLinear.h: interface for the CBiLinear class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BILINEAR_H__0229B39B_32A2_4103_BB58_59172CFE8FBB__INCLUDED_)
#define AFX_BILINEAR_H__0229B39B_32A2_4103_BB58_59172CFE8FBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

class CBiLinear : public CCalibration  
{
public:
	CBiLinear();
	virtual ~CBiLinear();

protected:
	void UpdateWholeCalibration();

	void GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
};

#endif // !defined(AFX_BILINEAR_H__0229B39B_32A2_4103_BB58_59172CFE8FBB__INCLUDED_)
