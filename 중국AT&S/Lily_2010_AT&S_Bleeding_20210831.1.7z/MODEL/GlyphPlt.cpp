// GlyphPlt.cpp: implementation of the GlyphPlt class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "GlyphPlt.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(GlyphPlt, Glyph, 1)
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GlyphPlt::GlyphPlt():Glyph()
{

}

GlyphPlt::~GlyphPlt()
{
}

void GlyphPlt::Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode)
{
/*	int nPenSize, nSkipNo = 1;
	int nX, nY;
	
	nPenSize = (int)(ceil(4 / dScale)); // 500um  ũ��
	nPenSize = max(nPenSize, 1);
	
	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor, OldColor = RGB(255, 255, 255);
	
	POSITION pos = m_LineData.GetHeadPosition();
	LPLINEDATA pData;
	
	while (pos) 
	{
		pData = m_LineData.GetNext(pos);
		
		nX = static_cast<int>((pData->npStartPos.x - dDrawStartX) / dScale);
		nY = static_cast<int>((dDrawStartY - (pData->npStartPos.y)) / dScale);
		
//		if(pData->bSelect)
//			pColor = RGB(255, 0, 0);
//		else
			pColor = RGB(0, 230, 128);
		
		if (OldColor != pColor)
		{
			if (pOldPen != NULL)
			{
				pDC->SelectObject(pOldPen);
				pen.DeleteObject();
			}
			pen.CreatePen(PS_SOLID, nPenSize, pColor);
			pOldPen = pDC->SelectObject(&pen);
		}
		
		pDC->MoveTo(nX, nY);
		nX = static_cast<int>((pData->npEndPos.x - dDrawStartX) / dScale);
		nY = static_cast<int>((dDrawStartY - (pData->npEndPos.y)) / dScale);
		pDC->LineTo(nX, nY);

		OldColor = pColor;
	}

	if (pOldPen != NULL)
	{
		pDC->SelectObject(pOldPen);
		pen.DeleteObject();
	}

	pen.CreatePen(PS_DOT, 1, pColor);
	pOldPen = pDC->SelectObject(&pen);

	nX = static_cast<int>((m_nMinX -5 - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - (m_nMinY - 5)) / dScale);
	pDC->MoveTo(nX, nY);
	nX = static_cast<int>((m_nMinX +5 - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - (m_nMinY - 5)) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMinX +5 - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - (m_nMinY + 5)) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMinX -5 - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - (m_nMinY + 5)) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMinX -5 - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - (m_nMinY - 5)) / dScale);
	pDC->LineTo(nX, nY);

	nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - m_nMinY) / dScale);
	pDC->MoveTo(nX, nY);
	nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - m_nMinY) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMaxX - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - m_nMaxY) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - m_nMaxY) / dScale);
	pDC->LineTo(nX, nY);
	nX = static_cast<int>((m_nMinX - dDrawStartX) / dScale);
	nY = static_cast<int>((dDrawStartY - m_nMinY) / dScale);
	pDC->LineTo(nX, nY);
	
	pDC->SelectObject(pOldPen);
	pen.DeleteObject();
*/
}

BOOL GlyphPlt::IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	return Glyph::IsSelect(point, nTolerence, pToolCodes, bSelectOnlyView);
}
BOOL GlyphPlt::IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	return Glyph::IsSelect(point1, point2, pToolCodes, bSelectOnlyView);
}

void GlyphPlt::Flip(BOOL bX)
{
//	if(!m_bSelect)
//		return;
	
	Glyph::Flip(bX);
}

void GlyphPlt::Rotate(double dDeg)
{
//	if(!m_bSelect)
//		return;
	Glyph::Rotate(dDeg);
}

void GlyphPlt::Move(int nX, int nY)
{
//	if(!m_bSelect)
//		return;

/*	nX = nX - m_nMinX;
	nY = nY - m_nMinY;
	
	LPLINEDATA pLine;
	POSITION pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		pLine->npStartPos.x += nX;
		pLine->npStartPos.y += nY;
		pLine->npEndPos.x += nX;
		pLine->npEndPos.y += nY;
	}

	m_nMaxX += nX;
	m_nMinX += nX;
	m_nMaxY += nY;
	m_nMinY += nY;
*/
}
