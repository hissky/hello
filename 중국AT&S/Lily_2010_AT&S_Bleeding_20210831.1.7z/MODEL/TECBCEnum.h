
#ifndef __TBarCode_ATL_h__

#ifndef __TECBCEnum_H
#define __TECBCEnum_H
/*////////////////////////////////////////////////////////////////////////////////////////////
//
//	Helpstring macro - expands to ["My String"] if compiling .ODL file
//
////////////////////////////////////////////////////////////////////////////////////////////*/
#ifndef TECIT_NO_HELPSTRINGS
#  define	TECIT_HS(s)	[helpstring(s)]
#else
#  undef	TECIT_HS
#  define	TECIT_HS(s)
#endif

/*////////////////////////////////////////////////////////////////////////////////////////////
//
//	Standard print ratios
//
//	1B, 2B, 3B, 4B    .....   bar widths 
//	1S, 2S, 3S, 4S    .....   space widths 
//
////////////////////////////////////////////////////////////////////////////////////////////*/
/* eBC_None,				Print ratios								 					standard check digit								*/
																											
/* eBC_Code11,				1:2.24:3.48:1:2.24			(1B:2B:3B:1S:2S)		 			eCDNone												*/
/* eBC_2OF5,				1:3:4.5:1:3					(1B:2B:3B:1S:2S)					eCDNone												*/
/* eBC_2OF5IL,				1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_2OF5IATA,			1:3:1						(1B:2B:1S)				 			eCDNone												*/
/* eBC_2OF5M,				1:3:4.5:1:3					(1B:2B:3B:1S:2S)		 			eCDNone												*/
/* eBC_2OF5DL,				1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_2OF5IND,				1:3:1						(1B:2B:1S)				 			eCDNone												*/
/* eBC_3OF9,				1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_3OF9A,				1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_EAN8,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN8												*/
/* eBC_EAN8P2,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN8												*/
/* eBC_EAN8P5,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN8												*/
/* eBC_EAN13,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN13											*/
/* eBC_EAN13P2,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN13											*/
/* eBC_EAN13P5,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN13											*/
/* eBC_EAN128,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_UPC12,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCA												*/
/* eBC_CodaBar2,			1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_CodaBar18,			-------												 			----												*/
/* eBC_Code128,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_Code128A,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_Code128B,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_Code128C,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_DPLeit,				1:3:1:3						(1B:2B:1S:2S)			 			eCDDPLeit											*/
/* eBC_DPIdent,				1:3:1:3						(1B:2B:1S:2S)			 			eCDDPIdent											*/
/* eBC_Code16K,				-------												 			----												*/
/* eBC_49,					-------												 			----												*/
/* eBC_9OF3,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCD2Mod47											*/
/* eBC_UPC25,				-------												 			----												*/
/* eBC_UPCD1,				-------												 			----												*/
/* eBC_Flattermarken,		1:1							(1B:1S)					 			eCDNone												*/
/* eBC_RSS14,				1:2:3:4:5:6:7:8:9:			(1B:2B:3B:4B:5B:6B:7B:8B:9B:		eCDNone												*/
/*							1:2:3:4:5:6:7:8:9			 1S:2S:3S:4S:5S:6S:7S:8S:9S)															*/
/* eBC_RSSLtd,				-------												 			----												*/
/* eBC_RSSExp,				-------												 			----												*/
/* eBC_UPCSCC,				-------												 			----												*/
/* eBC_UCC128,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_UPCA,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCA												*/
/* eBC_UPCAP2,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCA												*/
/* eBC_UPCAP5,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCA												*/
/* eBC_UPCE,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCE												*/
/* eBC_UPCEP2,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCE												*/
/* eBC_UPCEP5,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDUPCE												*/
/* eBC_PostNet5,			1:1							(1B:1S)  				 			eCDPostNet											*/
/* eBC_PostNet6,			1:1							(1B:1S)  				 			eCDPostNet											*/
/* eBC_PostNet8,			1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_PostNet10,			1:1							(1B:1S)  				 			eCDPostNet											*/
/* eBC_PostNet11,			1:1							(1B:1S)  				 			eCDPostNet											*/
/* eBC_PostNet12,			1:1							(1B:1S)  				 			eCDPostNet											*/
/* eBC_Plessey,				1:2:1:2						(1B:2B:1S:2S)			 			eCDPlessey											*/
/* eBC_MSI,					1:2:1:2						(1B:2B:1S:2S)			 			eCDMSI1												*/
/* eBC_SSCC18,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDMod10											*/
/* eBC_FIM,					-------												 			----												*/
/* eBC_LOGMARS,				1:3:1:3						(1B:2B:1S:2S)			 			eCDNone												*/
/* eBC_Pharma1,				1:3:2:4:2:3					(1B:2B:1C:2C:1S:2S)	 				eCDNone												*/
/* eBC_PZN,					1:2.5:1:2.5					(1B:2B:1S:2S)			 			eCDPZN											    */
/* eBC_Pharma2,				1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_GP,					-------											 				----												*/
/* eBC_PDF417,				1:2:3:4:5:6:7:8:			(1B:2B:3B:4B:5B:6B:7B:8B:																
							1:2:3:4:5:6					1S:2S:3S:4S:5S:6S)		 			eCDNone												*/
/* eBC_PDF417Trunc,			1:2:3:4:5:6:7:8:			(1B:2B:3B:4B:5B:6B:7B:8B:																
							1:2:3:4:5:6					1S:2S:3S:4S:5S:6S)		 			eCDNone												*/
/* eBC_MAXICODE,			-------											 				----												*/
/* eBC_QRCode,				1:1							(1B:1S)				 				----												*/
/* eBC_Code128A,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_Code128B,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_Code128C,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCode128											*/
/* eBC_9OF3A,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCD2Mod47											*/
/* eBC_AusPostCustom,		1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_AusPostCustom2,		1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_AusPostCustom3,		1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_AusPostReplyPaid,	1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_AusPostRouting,		1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_AusPostRedirect,		1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_ISBN,				1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDEAN13											*/
/* eBC_RM4SCC,				1:1							(1B:1S)  				 			eCDNone												*/
/* eBC_DataMatrix,			-------															----												*/
/* eBC_EAN14,				-------												 			eCDEAN14											*/
/* eBC_CODABLOCK_E,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCodablockE										*/
/* eBC_CODABLOCK_F,			1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDCodablockF										*/
/* eBC_NVE18,	    		1:2:3:4:1:2:3:4				(1B:2B:3B:4B:1S:2S:3S:4S)			eCDMod10											*/


/*/////////////////////////////////////////////////////////////////////////////
//
//	Supported Barcodes
//
/////////////////////////////////////////////////////////////////////////////*/
typedef	enum	tag_BarCType
{
	TECIT_HS(_T("None"))						  	eBC_None,					/* No valid barcode type						*/
	TECIT_HS(_T("Code 11"))							eBC_Code11,					/* Code 11										*/
	TECIT_HS(_T("Code 2OF5 Standard"))				eBC_2OF5,					/* Code 2 of 5 (standard)						*/
	TECIT_HS(_T("Code 2OF5 Interleaved"))			eBC_2OF5IL,					/* Interleaved 2 of 5 (standard)				*/
	TECIT_HS(_T("Code 2OF5 IATA"))					eBC_2OF5IATA,				/* Code 2 of 5 IATA								*/
	TECIT_HS(_T("Code 2OF5 Matrix"))				eBC_2OF5M,					/* Code 2 of 5 Matrix							*/
	TECIT_HS(_T("Code 2OF5 DataLogic"))				eBC_2OF5DL,					/* Code 2 of 5 Data Logic						*/
	TECIT_HS(_T("Code 2OF5 Industry"))				eBC_2OF5IND,				/* Code 2 of 5 Industrial						*/
	TECIT_HS(_T("Code 39"))						    eBC_3OF9,					/* Code 3 of 9 (Code 39)						*/
	TECIT_HS(_T("Code 39 Full ASCII"))				eBC_3OF9A,					/* Code 3 of 9 (Code 39) Ascii 					*/
	TECIT_HS(_T("EAN8"))							eBC_EAN8,					/* EAN8											*/
	TECIT_HS(_T("EAN8P2"))							eBC_EAN8P2,					/* EAN8	 - 2 digits add on						*/
	TECIT_HS(_T("EAN8P5"))							eBC_EAN8P5,					/* EAN8	 - 5 digits add on						*/
	TECIT_HS(_T("EAN13"))							eBC_EAN13,					/* EAN13										*/
	TECIT_HS(_T("EAN13P2"))							eBC_EAN13P2,				/* EAN13 - 2 digits add on						*/
	TECIT_HS(_T("EAN13P5"))							eBC_EAN13P5,				/* EAN13 - 5 digits add on						*/
	TECIT_HS(_T("EAN128"))							eBC_EAN128,					/* EAN128										*/
	TECIT_HS(_T("UPC12"))							eBC_UPC12,					/* UPC 12 Digits								*/
	TECIT_HS(_T("CodaBar 2 Widths"))				eBC_CodaBar2,				/* CodaBar (2 width)							*/
	TECIT_HS(_T("CodaBar 18 Widths"))				eBC_CodaBar18,				/* unsupported CodaBar (18 widths)				*/
	TECIT_HS(_T("Code128"))							eBC_Code128,				/* Code128										*/
	TECIT_HS(_T("DP Leitcode"))						eBC_DPLeit,					/* Deutsche Post Leitcode						*/
	TECIT_HS(_T("DP Identcode"))					eBC_DPIdent,				/* Deutsche Post Identcode						*/
	TECIT_HS(_T("Code 16K"))						eBC_Code16K,				/* unsupported									*/
	TECIT_HS(_T("Code 49"))							eBC_49,						/* unsupported									*/
	TECIT_HS(_T("Code 93"))							eBC_9OF3,					/* Code 93										*/
	TECIT_HS(_T("UPC25"))							eBC_UPC25,					/* identical to eBC_UPCA						*/
	TECIT_HS(_T("UPCD1"))							eBC_UPCD1,					/* unsupported									*/
	TECIT_HS(_T("Flattermarken"))					eBC_Flattermarken,			/* Flattermarken								*/
	TECIT_HS(_T("RSS-14"))							eBC_RSS14,					/* RSS-14										*/
	TECIT_HS(_T("RSS Limited"))						eBC_RSSLtd,					/* RSS Limited									*/
	TECIT_HS(_T("RSS Expanded"))					eBC_RSSExp,					/* RSS Expanded									*/
	TECIT_HS(_T("UPCSCC"))							eBC_UPCSCC,					/* unsupported									*/
	TECIT_HS(_T("UCC128"))							eBC_UCC128,					/* same as EAN128								*/
	TECIT_HS(_T("UPCA"))							eBC_UPCA,					/* UPC A										*/
	TECIT_HS(_T("UPCAP2"))							eBC_UPCAP2,					/* UPC A - 2 digit add on						*/
	TECIT_HS(_T("UPCAP5"))							eBC_UPCAP5,					/* UPC A - 5 digit add on						*/
	TECIT_HS(_T("UPCE"))							eBC_UPCE,					/* UPC E 										*/
	TECIT_HS(_T("UPCEP2"))							eBC_UPCEP2,					/* UPC E - 2 digit add on						*/
	TECIT_HS(_T("UPCEP5"))							eBC_UPCEP5,					/* UPC E - 5 digit add on						*/
	TECIT_HS(_T("PostNet5"))						eBC_PostNet5,				/* PostNet ZIP (5 digits)						*/
	TECIT_HS(_T("PostNet6"))						eBC_PostNet6,				/* PostNet ZIP (5 digits + check digit)			*/
	TECIT_HS(_T("PostNet8"))						eBC_PostNet8,				/* PostNet ZIP (8 digits)						*/
	TECIT_HS(_T("PostNet10"))						eBC_PostNet10,				/* PostNet ZIP+4 (5 digits + 4 digits + CD)		*/
	TECIT_HS(_T("PostNet11"))						eBC_PostNet11,				/* PostNet DPBC  (5 d. + 4 d. + 2 d.)			*/
	TECIT_HS(_T("PostNet12"))						eBC_PostNet12,				/* PostNet DPBC  (5 d. + 4 d. + 2 d. + CD)		*/
	TECIT_HS(_T("Plessey"))							eBC_Plessey,				/* Plessey Code									*/
	TECIT_HS(_T("MSI"))								eBC_MSI,					/* MSI Plessey Code								*/
	TECIT_HS(_T("SSCC-18"))							eBC_SSCC18,					/* Serial Shipping Container Code 18			*/
	TECIT_HS(_T("FIM"))								eBC_FIM,					/* unsupported									*/
	TECIT_HS(_T("LOGMARS"))							eBC_LOGMARS,				/* LOGMARS										*/
	TECIT_HS(_T("Pharmacode One-Track"))			eBC_Pharma1,				/* Pharmacode (one-track)						*/
	TECIT_HS(_T("PZN"))								eBC_PZN,				    /* PZN (Pharma Zentral Nummer Germany)		    */
	TECIT_HS(_T("Pharmacode Two-Track"))			eBC_Pharma2,				/* Pharmacode (two-track)						*/
	TECIT_HS(_T("General Parcel"))					eBC_GP,						/* unsupported									*/
	TECIT_HS(_T("PDF417"))							eBC_PDF417,					/* PDF417   									*/
	TECIT_HS(_T("PDF417 Truncated"))				eBC_PDF417Trunc,			/* PDF417 Truncated								*/
	TECIT_HS(_T("MaxiCode"))						eBC_MAXICODE,				/* Maxi Code									*/
	TECIT_HS(_T("QR-Code"))							eBC_QRCode,					/* QR-Code										*/
	TECIT_HS(_T("Code128A"))						eBC_Code128A,				/* Code128 Subset A								*/
	TECIT_HS(_T("Code128B"))						eBC_Code128B,				/* Code128 Subset B								*/
	TECIT_HS(_T("Code128C"))						eBC_Code128C,				/* Code128 Subset C								*/
	TECIT_HS(_T("Code 93 Full ASCII"))				eBC_9OF3A,					/* Code 93	Ascii								*/
	TECIT_HS(_T("Australian Post Custom"))			eBC_AusPostCustom,			/* Australian Post standard customer barcode	*/
	TECIT_HS(_T("Australian Post Custom2"))			eBC_AusPostCustom2,			/* Australian Post customer barcode 2			*/
	TECIT_HS(_T("Australian Post Custom3"))			eBC_AusPostCustom3,			/* Australian Post customer barcode 3			*/
	TECIT_HS(_T("Australian Post Reply Paid"))		eBC_AusPostReplyPaid,		/* Australian Post Reply Paid barcode			*/
	TECIT_HS(_T("Australian Post Routing"))			eBC_AusPostRouting,			/* Australian Post Routing barcode				*/
	TECIT_HS(_T("Australian Post Redirect"))		eBC_AusPostRedirect,		/* Australian Post Redirection barcode			*/
	TECIT_HS(_T("ISBN"))					        eBC_ISBN,					/* ISBN											*/
	TECIT_HS(_T("Royal Mail 4 State (RM4SCC)"))		eBC_RM4SCC,					/* Royal Mail 4 State customer code				*/
	TECIT_HS(_T("Data Matrix"))						eBC_DataMatrix,				/* Data Matrix									*/
	TECIT_HS(_T("EAN14"))							eBC_EAN14,				    /* EAN-14									    */
	TECIT_HS(_T("CODABLOCK-E"))						eBC_CODABLOCK_E,			/* CODABLOCK-E									*/
	TECIT_HS(_T("CODABLOCK-F"))						eBC_CODABLOCK_F,			/* CODABLOCK-F									*/
	TECIT_HS(_T("NVE-18"))							eBC_NVE18,				  	/* Nummer der Versandeinheit (=SSCC-18)			*/

} e_BarCType;


///////////////////////////////////////////////////////////////////////////////
//
//	Supported Check Digit Methods
//
///////////////////////////////////////////////////////////////////////////////
typedef	enum	tag_CDMethod
{
	TECIT_HS(_T("None"))								eCDNone			= 0,		/* No check digit calculation is performed		*/
	TECIT_HS(_T("Standard"))							eCDStandard		,			/* standard check digit method will be applied	*/
	TECIT_HS(_T("Modulo 10"))							eCDMod10		,			/*												*/
	TECIT_HS(_T("Modulo 43"))							eCDMod43		,			/*												*/
	TECIT_HS(_T("Modulo 47 (2 digits)"))				eCD2Mod47		,			/*												*/
	TECIT_HS(_T("DP Leitcode"))							eCDDPLeit		,			/*												*/
	TECIT_HS(_T("DP Identcode"))						eCDDPIdent		,			/*												*/
	TECIT_HS(_T("Code11 (1 digit)"))					eCD1Code11		,			/*												*/
	TECIT_HS(_T("Code11 (2 digits)"))					eCD2Code11		,			/*												*/
	TECIT_HS(_T("Postnet"))								eCDPostnet		,			/*												*/
	TECIT_HS(_T("MSI (1 digit)"))						eCDMSI1			,			/*												*/
	TECIT_HS(_T("MSI (2 digits)"))						eCDMSI2			,			/*												*/
	TECIT_HS(_T("Plessey"))								eCDPlessey		,			/*												*/
	TECIT_HS(_T("EAN 8"))								eCDEAN8			,			/*												*/
	TECIT_HS(_T("EAN 13"))								eCDEAN13		,			/*												*/
	TECIT_HS(_T("UPC A"))								eCDUPCA			,			/*												*/
	TECIT_HS(_T("UPC E"))								eCDUPCE			,			/*												*/
	TECIT_HS(_T("EAN 128"))								eCDEAN128		,			/*												*/
	TECIT_HS(_T("Code 128"))							eCDCode128		,			/*												*/
	TECIT_HS(_T("Royal Mail 4 State"))					eCDRM4SCC		,			/*												*/
	TECIT_HS(_T("Mod-11 (PZN)"))					    eCDPZN		    ,		    /*												*/
    TECIT_HS(_T("Mod-11 (W=7)"))				        eCDMod11W7	    ,		    /*												*/
    TECIT_HS(_T("EAN 14"))						        eCDEAN14	    ,		    /*												*/
} e_CDMethod;

///////////////////////////////////////////////////////////////////////////////
//
//	Orientation
//
///////////////////////////////////////////////////////////////////////////////
typedef enum tag_Degree
{
	TECIT_HS(_T("0 degrees"))							deg0			= 0,
	TECIT_HS(_T("90 degrees"))							deg90			= 1,
	TECIT_HS(_T("180 degrees"))							deg180			= 2,
	TECIT_HS(_T("270 degrees"))							deg270			= 3
}
e_Degree;

///////////////////////////////////////////////////////////////////////////////
//
//	measure units
//
///////////////////////////////////////////////////////////////////////////////
typedef enum tag_MUnit
{													
	TECIT_HS(_T("Default"))								eMUDefault		= 0,
	TECIT_HS(_T("Pixel"))								eMUPixel		,
	TECIT_HS(_T("mm"))									eMUMM			,
} e_MUnit;

// Quietzone Units
typedef enum tag_QZMUnit
{													
	TECIT_HS(_T("No quiet zone"))						eQZMUNone		= 0,
	TECIT_HS(_T("Modules"))								eQZMUModules,
	TECIT_HS(_T("mm"))									eQZMUMM		, // not implemented
	TECIT_HS(_T("mils"))								eQZMUMils	, // not implemented
	TECIT_HS(_T("Pixel"))								eQZMUPixel	, // not implemented
} e_QZMUnit;

///////////////////////////////////////////////////////////////////////////////
//
//	Image Types
//  (Inserted gk, 05-02-2000)
//
///////////////////////////////////////////////////////////////////////////////
typedef enum tag_ImageType
{
	TECIT_HS(_T("BMP"))									eIMBmp			= 0,
	TECIT_HS(_T("EMF"))									eIMEmf			,
	TECIT_HS(_T("EPS"))									eIMEps			,
	TECIT_HS(_T("GIF"))									eIMGif			,
	TECIT_HS(_T("JPG"))									eIMJpg			,
	TECIT_HS(_T("PCX"))									eIMPcx			,
	TECIT_HS(_T("PNG"))									eIMPng			,
	TECIT_HS(_T("TIF"))									eIMTif			,
	TECIT_HS(_T("PSVECTOR"))							eIMPsVector		,
} e_IMType;

///////////////////////////////////////////////////////////////////////////////
//
//	alignment
//  (Inserted TN, 27-03-2003)
//
///////////////////////////////////////////////////////////////////////////////
typedef enum tag_Align
{
	TECIT_HS(_T("Default"))								eAlDefault		,
	TECIT_HS(_T("Left"))								eAlLeft			,
	TECIT_HS(_T("Right"))								eAlRight		,
	TECIT_HS(_T("Center"))								eAlCenter		,
} e_BCAlign;

///////////////////////////////////////////////////////////////////////////////
//
//	License Enumerations
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//

//	Product
//
///////////////////////////////////////////////////////////////////////////////
#ifdef TEC_UNIX
typedef enum tag_licProduct
{
	TECIT_HS(_T("TBarCode 1D (standard)"))				eLicProd1D		= 100,
	TECIT_HS(_T("TBarCode 2D (1D + 2D symbolgies)"))	eLicProd2D		,
}
e_licProduct;
#else
typedef enum tag_licProduct
{
	TECIT_HS(_T("Invalid product ID"))					eLicInvalid		= -1,
	TECIT_HS(_T("TBarCode 1D (standard)"))				eLicProd1D		= 13,
	TECIT_HS(_T("TBarCode 2D (1D + 2D symbologies)"))	eLicProd2D		,
}
e_licProduct;
#endif

///////////////////////////////////////////////////////////////////////////////
//
//	Product
//
///////////////////////////////////////////////////////////////////////////////
typedef enum tag_licKind
{
	TECIT_HS(_T("Single (Einzellizenz)"))				eLicKindSingle	= 1,
	TECIT_HS(_T("Site (Firmenlizenz)"))					eLicKindSite,
	TECIT_HS(_T("Developer (Entwicklerlizenz)"))		eLicKindDeveloper,
}
e_licKind;

///////////////////////////////////////////////////////////////////////////////
//
//	Data Matrix Sizes
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_DMSizes
{
	TECIT_HS(_T("Default"))								eDMSz_Default,
	// Sqaures										
	TECIT_HS(_T("10  x 10"))							eDMSz_10x10,
	TECIT_HS(_T("12  x 12"))							eDMSz_12x12,
	TECIT_HS(_T("14  x 14"))							eDMSz_14x14,
	TECIT_HS(_T("16  x 16"))							eDMSz_16x16,
	TECIT_HS(_T("18  x 18"))							eDMSz_18x18,
	TECIT_HS(_T("20  x 20"))							eDMSz_20x20,
	TECIT_HS(_T("22  x 22"))							eDMSz_22x22,
	TECIT_HS(_T("24  x 24"))							eDMSz_24x24,
	TECIT_HS(_T("26  x 26"))							eDMSz_26x26,
	TECIT_HS(_T("32  x 32"))							eDMSz_32x32,
	TECIT_HS(_T("36  x 36"))							eDMSz_36x36,
	TECIT_HS(_T("40  x 40"))							eDMSz_40x40,
	TECIT_HS(_T("44  x 44"))							eDMSz_44x44,
	TECIT_HS(_T("48  x 48"))							eDMSz_48x48,
	TECIT_HS(_T("52  x 52"))							eDMSz_52x52,
	TECIT_HS(_T("64  x 64"))							eDMSz_64x64,
	TECIT_HS(_T("72  x 72"))							eDMSz_72x72,
	TECIT_HS(_T("80  x 80"))							eDMSz_80x80,
	TECIT_HS(_T("88  x 88"))							eDMSz_88x88,
	TECIT_HS(_T("96  x 96"))							eDMSz_96x96,
	TECIT_HS(_T("104 x 104"))							eDMSz_104x104,
	TECIT_HS(_T("120 x 120"))							eDMSz_120x120,
	TECIT_HS(_T("132 x 132"))							eDMSz_132x132,
	TECIT_HS(_T("144 x 144"))							eDMSz_144x144,
	// Rectangles									
	TECIT_HS(_T("8   x 18"))							eDMSz_8x18,
	TECIT_HS(_T("8   x 32"))							eDMSz_8x32,
	TECIT_HS(_T("12  x 26"))							eDMSz_12x26,
	TECIT_HS(_T("12  x 36"))							eDMSz_12x36,
	TECIT_HS(_T("16  x 36"))							eDMSz_16x36,
	TECIT_HS(_T("16  x 48"))							eDMSz_16x48,
} e_DMSizes;

///////////////////////////////////////////////////////////////////////////////
//
//	Data Matrix Formats
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_DMFormat
{
	TECIT_HS(_T("Default"))								eDMPr_Default,
	TECIT_HS(_T("UCC/EAN"))								eDMPr_UCCEAN,
	TECIT_HS(_T("Industry"))							eDMPr_Industry,
	TECIT_HS(_T("Format 05"))							eDMPr_Macro05,
	TECIT_HS(_T("Format 06"))							eDMPr_Macro06,
}  e_DMFormat;

///////////////////////////////////////////////////////////////////////////////
//
//	QR Code Versions (symbol sizes)
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_QRVersion
{
	TECIT_HS(_T("Default"))								eQRVers_Default,
	TECIT_HS(_T("(1) 21 x 21"))							eQRVers_1 ,
	TECIT_HS(_T("(2) 25 x 25"))							eQRVers_2 ,
	TECIT_HS(_T("(3) 29 x 29"))							eQRVers_3 ,
	TECIT_HS(_T("(4) 33 x 33"))							eQRVers_4 ,
	TECIT_HS(_T("(5) 37 x 37"))							eQRVers_5 ,
	TECIT_HS(_T("(6) 41 x 41"))							eQRVers_6 ,
	TECIT_HS(_T("(7) 45 x 45"))							eQRVers_7 ,
	TECIT_HS(_T("(8) 49 x 49"))							eQRVers_8 ,
	TECIT_HS(_T("(9) 53 x 53"))							eQRVers_9 ,
	TECIT_HS(_T("(10) 57 x 57"))						eQRVers_10,
	TECIT_HS(_T("(11) 61 x 61"))						eQRVers_11,
	TECIT_HS(_T("(12) 65 x 65"))						eQRVers_12,
	TECIT_HS(_T("(13) 69 x 69"))						eQRVers_13,
	TECIT_HS(_T("(14) 73 x 73"))						eQRVers_14,
	TECIT_HS(_T("(15) 77 x 77"))						eQRVers_15,
	TECIT_HS(_T("(16) 81 x 81"))						eQRVers_16,
	TECIT_HS(_T("(17) 85 x 85"))						eQRVers_17,
	TECIT_HS(_T("(18) 89 x 89"))						eQRVers_18,
	TECIT_HS(_T("(19) 93 x 93"))						eQRVers_19,
	TECIT_HS(_T("(20) 97 x 97"))						eQRVers_20,
	TECIT_HS(_T("(21) 101 x 101"))						eQRVers_21,
	TECIT_HS(_T("(22) 105 x 105"))						eQRVers_22,
	TECIT_HS(_T("(23) 109 x 109"))						eQRVers_23,
	TECIT_HS(_T("(24) 113 x 113"))						eQRVers_24,
	TECIT_HS(_T("(25) 117 x 117"))						eQRVers_25,
	TECIT_HS(_T("(26) 121 x 121"))						eQRVers_26,
	TECIT_HS(_T("(27) 125 x 125"))						eQRVers_27,
	TECIT_HS(_T("(28) 129 x 129"))						eQRVers_28,
	TECIT_HS(_T("(29) 133 x 133"))						eQRVers_29,
	TECIT_HS(_T("(30) 137 x 137"))						eQRVers_30,
	TECIT_HS(_T("(31) 141 x 141"))						eQRVers_31,
	TECIT_HS(_T("(32) 145 x 145"))						eQRVers_32,
	TECIT_HS(_T("(33) 149 x 149"))						eQRVers_33,
	TECIT_HS(_T("(34) 153 x 153"))						eQRVers_34,
	TECIT_HS(_T("(35) 157 x 157"))						eQRVers_35,
	TECIT_HS(_T("(36) 161 x 161"))						eQRVers_36,
	TECIT_HS(_T("(37) 165 x 165"))						eQRVers_37,
	TECIT_HS(_T("(38) 169 x 169"))						eQRVers_38,
	TECIT_HS(_T("(39) 173 x 173"))						eQRVers_39,
	TECIT_HS(_T("(40) 177 x 177"))						eQRVers_40,
} e_QRVersion;
 
///////////////////////////////////////////////////////////////////////////////
//
//	QR Code Formats
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_QRFormat
{
	TECIT_HS(_T("Default"))								eQRPr_Default,
	TECIT_HS(_T("UCC/EAN"))								eQRPr_UCCEAN,
	TECIT_HS(_T("Industry"))							eQRPr_Industry,
}  e_QRFormat;

///////////////////////////////////////////////////////////////////////////////
//
//	QR Code Error Correction Levels
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_QRECLevel
{
	TECIT_HS(_T("(L)ow"))								eQREC_Low,
	TECIT_HS(_T("(M)edium"))							eQREC_Medium,
	TECIT_HS(_T("(Q)uartil"))							eQREC_Quartil,
	TECIT_HS(_T("(H)igh"))								eQREC_High,
}  e_QRECLevel;

///////////////////////////////////////////////////////////////////////////////
//
//	QR Code Error Correction Levels
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_QRMask
{
	TECIT_HS(_T("Default"))								eQRMsk_Default = -1,
	TECIT_HS(_T("Mask 0"))								eQRMsk_0,
	TECIT_HS(_T("Mask 1"))								eQRMsk_1,
	TECIT_HS(_T("Mask 2"))								eQRMsk_2,
	TECIT_HS(_T("Mask 3"))								eQRMsk_3,
	TECIT_HS(_T("Mask 4"))								eQRMsk_4,
	TECIT_HS(_T("Mask 5"))								eQRMsk_5,
	TECIT_HS(_T("Mask 6"))								eQRMsk_6,
	TECIT_HS(_T("Mask 7"))								eQRMsk_7,
}  e_QRMask;


///////////////////////////////////////////////////////////////////////////////
//
//	CodablockF Code Formats
//
///////////////////////////////////////////////////////////////////////////////
typedef enum	tagE_CBFFormat
{
	TECIT_HS(_T("Default"))								eCBFPr_Default,
	TECIT_HS(_T("UCC/EAN"))								eCBFPr_UCCEAN,
}  e_CBFFormat;


#endif
#endif


