// DTempINI.h: interface for the DTempINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DTEMPINI_H__8A21A6D9_E5ED_4BE3_A117_96854495D91B__INCLUDED_)
#define AFX_DTEMPINI_H__8A21A6D9_E5ED_4BE3_A117_96854495D91B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class DTempINI  
{
public:
	DTempINI();
	virtual ~DTempINI();
	TEMPTIME	m_sTempTime;
};

extern DTempINI gTempINI;

#endif // !defined(AFX_DTEMPINI_H__8A21A6D9_E5ED_4BE3_A117_96854495D91B__INCLUDED_)
