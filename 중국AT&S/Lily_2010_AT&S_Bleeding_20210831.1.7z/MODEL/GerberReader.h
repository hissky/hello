// GerberReader.h: interface for the GerberReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GERBERREADER_H__257B5289_0D85_4655_99CF_1E68C8A1C459__INCLUDED_)
#define AFX_GERBERREADER_H__257B5289_0D85_4655_99CF_1E68C8A1C459__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DProject.h"
#include "GlyphExcellon.h"

class GerberReader  
{
public:
	LPDUNIT m_pDuplexUnit;
	BOOL	m_bUseDuplex;
	double	m_dDuplexLenX;
	int		m_nLineSortDirection;
	void CopyDuplexData();

	BOOL CalLine();
	void MessageLoop();
	BOOL m_bCycle;
	void CalCurvLine(CDPoint StartP, CDPoint EndP, CDPoint OffsetP);
	void ReadCCode();
	void ReadLine();
	void ReadTCode();
	void IsTzs(int nCount);
	BOOL GetRepeatAxisInfo(char *szBuffer);
	int GetXYPos(char *szBuffer, double &dParam1, double &dParam2, BOOL &bUse1, BOOL &bUse2);
	BOOL GetParam(char* szBuffer, double &dParam1, double &dParam2, double &dParam3, double &dParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4);
	void InitData(short nTzs, int nInputUnit);
	BOOL IsNumber(char cNumber);
	BOOL GetValid(char character, char* szString);
	BOOL IsFiducialMarkExist(double dX, double dY);
	void ReadFiducial(int nFidKind);
	void ReadPosition();
	BOOL ReadDuplicatePos();
	void SetMetric();
	void ReadNums(char* szBuffer);
	int Read(CString strPath, short nLzs, int nInputUnit, GlyphExcellon* pExcellon, DProject* pProject, int nDivide);
	void ToolComparison();
	void ToolRestore();
	void FirstToolType(CString strCmd);

	LPDUNIT m_pUnit;
	
	CString m_strOldDCmd;
	int		m_nCurrentToolType;
	BOOL m_bCorrectTool;
	BOOL m_bRepeatXFlip;
	BOOL m_bRepeatYFlip;
	BOOL m_bRepeatSwap;

	BOOL	m_bReadStart;
	byte	m_nOldTCode;
	byte	m_nNewTCode;
	byte	m_nNewMCode;
	int		m_nHoleSize;
	int		m_nStartX;
	int		m_nStartY;
	int		m_nPositionX;
	int		m_nPositionY;
	int		m_nDupliMovX;
	int		m_nDupliMovY;
	int		m_nRRepeatX;
	int		m_nRRepeatY;
	int		m_nRDupliMX;
	int		m_nRDupliMY;
	BOOL	m_bRandM2;
	double		m_dMetric;
	long	m_lTzsLzs;
	int		m_nLength;
	
	BOOL	m_bRepeat;
	BOOL	m_bIsSwap;
	BOOL	m_bStoreData;
	int		m_nMirrorX;
	int		m_nMirrorY;
	BOOL	m_bIsRead;
	BOOL	m_bSetFid;
	BOOL	m_bSetFid2;
	int		m_nMinX;
	int		m_nMinY;
	int		m_nMaxX;
	int		m_nMaxY;
	
	short	m_nLzs;
	int		m_nInputUnit;
	int		m_nToolCnt; //  
	int		m_nToolMatch[27][2]; // tool1~ 27�� ����ؾ� �ϹǷ� gerber tool(1~ 999)�� ��Ī 
	int		m_nCurrentTool;
	int		m_nToolFirstType[MAX_TOOL_NO];
	BOOL	m_bOldLine; // Repeat�Ҷ� ���� LineData�� �־����� Ȯ�� 
	char	m_szData[1024];
	double		m_dDivide;
	CDPoint	m_dStartPos; //x/y�� �����ϰų� ��cmd�� movecmd�� �ƴҰ�� ��� 
	BOOL	m_bCW; // �ð���� 
	BOOL	m_bOverlapXY;
	BOOL	m_nFidBlock;
	
	CList <HOLEDATA, HOLEDATA>	m_listData;
	CList <LINEDATA, LINEDATA>	m_listLineData;
	
	CList <HOLEDATA, HOLEDATA>	m_RepeatlistData;
	CList <LINEDATA, LINEDATA>	m_RepeatlistLineData;

	GlyphExcellon*	m_pGlyphExcell;
	DProject*		m_pDProject;

	GerberReader();
	virtual ~GerberReader();

};

#endif // !defined(AFX_GERBERREADER_H__257B5289_0D85_4655_99CF_1E68C8A1C459__INCLUDED_)
