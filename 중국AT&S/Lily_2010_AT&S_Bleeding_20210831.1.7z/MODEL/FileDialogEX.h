#if !defined(AFX_FILEDIALOGEX_H__D6234E17_B315_4AD8_BF6B_6D555DC88701__INCLUDED_)
#define AFX_FILEDIALOGEX_H__D6234E17_B315_4AD8_BF6B_6D555DC88701__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileDialogEX.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFileDialogEX dialog

class CFileDialogEX : public CFileDialog
{
	DECLARE_DYNAMIC(CFileDialogEX)

public:
	CFileDialogEX(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CFileDialogEX)
	afx_msg void OnInitDone();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEDIALOGEX_H__D6234E17_B315_4AD8_BF6B_6D555DC88701__INCLUDED_)
