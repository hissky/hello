// PaneManualControlLaserUV.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlLaserUV.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hlaser.h"
#include "DlgLaserWarmUp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaserUV

IMPLEMENT_DYNCREATE(CPaneManualControlLaserUV, CFormView)

CPaneManualControlLaserUV::CPaneManualControlLaserUV()
	: CFormView(CPaneManualControlLaserUV::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlLaserUV)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneManualControlLaserUV::~CPaneManualControlLaserUV()
{
}

void CPaneManualControlLaserUV::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlLaserUV)
	DDX_Control(pDX, IDC_BUTTON_LASER_WARM_UP, m_btnLaserWarmUp); 
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlLaserUV, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlLaserUV)
	ON_BN_CLICKED(IDC_BUTTON_LASER_WARM_UP, OnButtonLaserWarmUp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaserUV diagnostics

#ifdef _DEBUG
void CPaneManualControlLaserUV::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlLaserUV::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaserUV message handlers

void CPaneManualControlLaserUV::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();
}

void CPaneManualControlLaserUV::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Laser Warm-Up
	m_btnLaserWarmUp.SetFont( &m_fntBtn );
	m_btnLaserWarmUp.SetFlat( FALSE );
	m_btnLaserWarmUp.EnableBallonToolTip();
	m_btnLaserWarmUp.SetToolTipText( _T("Laser Warm Up") );
	m_btnLaserWarmUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserWarmUp.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlLaserUV::CallDialog()
{
	gDeviceFactory.GetLaser()->OpenPowerDlg();
}

void CPaneManualControlLaserUV::OnButtonLaserWarmUp() 
{
	// TODO: Add your control notification handler code here
	CDlgLaserWarmUp Dlg;
	
	Dlg.DoModal();
}
