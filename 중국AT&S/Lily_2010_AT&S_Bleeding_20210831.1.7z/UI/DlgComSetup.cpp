// DlgComSetup.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgComSetup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgComSetup dialog


CDlgComSetup::CDlgComSetup(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgComSetup::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgComSetup)
	m_nTimeOut = 1000;
	//}}AFX_DATA_INIT
	memset( &m_sComPort, 0, sizeof(m_sComPort) );
	m_sComPort.nPortNo		= 0;		// COM1
	m_sComPort.nBaudRate	= 19200;
	m_sComPort.nDataBits	= 8;
	m_sComPort.nParity		= 0;		// NONE
	m_sComPort.nStopBits	= 0;
	m_sComPort.nFlowControl	= 0;		// NONE
	m_sComPort.nTimeOut		= 4000;
	m_nMode = MODE_POWER;
}


void CDlgComSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgComSetup)
	DDX_Control(pDX, IDC_EDIT_TIMEOUT, m_edtTimeOut);
	DDX_Control(pDX, IDC_COMBO_FLOWCONTROL, m_cmbFlowControl);
	DDX_Control(pDX, IDC_COMBO_STOPBIT, m_cmbStopbit);
	DDX_Control(pDX, IDC_COMBO_PARITY, m_cmbParity);
	DDX_Control(pDX, IDC_COMBO_DATABIT, m_cmbDatabit);
	DDX_Control(pDX, IDC_COMBO_BAUDRATE, m_cmbBaudRate);
	DDX_Control(pDX, IDC_COMBO_PORT, m_cmbPort);
	DDX_Text(pDX, IDC_EDIT_TIMEOUT, m_nTimeOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgComSetup, CDialog)
	//{{AFX_MSG_MAP(CDlgComSetup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgComSetup message handlers

BOOL CDlgComSetup::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//memcpy( &m_sComPort, &gAviaParam.m_sComPort, sizeof(m_sComPort) );
	Init_Control();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgComSetup::Init_Control()
{
	CString strData;

	// Port No
	m_cmbPort.SetCurSel( m_sComPort.nPortNo );
	
	// Baud Rate
//	strData.Format(_T("%d"), m_sComPort.nBaudRate);
//	int nIdx = m_cmbBaudRate.FindString(0, (LPCTSTR)strData);
//	if( CB_ERR == nIdx )
//		m_cmbBaudRate.SetCurSel( 2 );
//	else
//		m_cmbBaudRate.SetCurSel( nIdx );
	m_cmbBaudRate.SetCurSel( m_sComPort.nBaudRate );
	//m_cmbBaudRate.EnableWindow( FALSE );
	
	// Data bit
//	strData.Format(_T("%d"), m_sComPort.nDataBits);
//	nIdx = m_cmbDatabit.FindString(0, (LPCTSTR)strData);
//	if( CB_ERR == nIdx )
//		m_cmbDatabit.SetCurSel( 3 );
//	else
//		m_cmbDatabit.SetCurSel( nIdx );
	m_cmbDatabit.SetCurSel( m_sComPort.nDataBits );
	//m_cmbDatabit.EnableWindow( FALSE );
	
	// Parity
	m_cmbParity.SetCurSel( m_sComPort.nParity );
	//m_cmbParity.EnableWindow( FALSE );

	// Stop Bit
//	strData.Format(_T("%d"), m_sComPort.nStopBits);
//	nIdx = m_cmbStopbit.FindString( 0, (LPCTSTR)strData );
//	if( CB_ERR == nIdx )
//		m_cmbStopbit.SetCurSel( 0 );
//	else
//		m_cmbStopbit.SetCurSel( nIdx );
	m_cmbStopbit.SetCurSel( m_sComPort.nStopBits );
	//m_cmbStopbit.EnableWindow( FALSE );

	// Flow Control
	m_cmbFlowControl.SetCurSel( m_sComPort.nFlowControl );
	//m_cmbFlowControl.EnableWindow( FALSE );

	// Time Out
	/*m_edtTimeOut.SetUnitText("ms");
	strData.Format(_T("%d"), m_sComPort.nTimeOut);
	m_edtTimeOut.SetWindowText( strData );*/
	m_edtTimeOut.SetReceivedFlag(1);
	strData.Format(_T("%d"), m_sComPort.nTimeOut);
	m_edtTimeOut.SetWindowText( (LPCTSTR)strData );

	if(m_nMode == MODE_SERVO) //set port & br 
	{
		m_edtTimeOut.EnableWindow(FALSE);
		m_cmbFlowControl.EnableWindow(FALSE);
		m_cmbStopbit.EnableWindow(FALSE);
		m_cmbParity.EnableWindow(FALSE);
		m_cmbDatabit.EnableWindow(FALSE);
	}
	UpdateData(TRUE);
}

void CDlgComSetup::OnOK() 
{
	// TODO: Add extra validation here
	SavePortInfo();
	//memcpy( &gAviaParam.m_sComPort, &m_sComPort, sizeof(m_sComPort) );
	
	CDialog::OnOK();
}

void CDlgComSetup::SavePortInfo()
{
	// Port
	m_sComPort.nPortNo = m_cmbPort.GetCurSel();

	// Baud Rate
	CString strData;

//	m_cmbBaudRate.GetLBText( m_cmbBaudRate.GetCurSel(), strData );
//	m_sComPort.nBaudRate = atoi( (LPCSTR)(LPCTSTR)strData );
	m_sComPort.nBaudRate = m_cmbBaudRate.GetCurSel();

	// Data bit
//	m_cmbDatabit.GetLBText( m_cmbDatabit.GetCurSel(), strData );
//	m_sComPort.nDataBits = atoi( (LPCSTR)(LPCTSTR)strData );
	m_sComPort.nDataBits = m_cmbDatabit.GetCurSel();

	// Parity
	m_sComPort.nParity = m_cmbParity.GetCurSel();

	// Stop Bit
	m_sComPort.nStopBits = m_cmbStopbit.GetCurSel();

	// Flow Control
	m_sComPort.nFlowControl = m_cmbFlowControl.GetCurSel();

	// Time Out
	m_edtTimeOut.GetWindowText( strData );
	m_sComPort.nTimeOut = atoi( (LPCSTR)(LPCTSTR)strData );
}

void CDlgComSetup::SetComPortData(SCOMPORT* psComPort)
{
	memcpy( &m_sComPort, psComPort, sizeof(m_sComPort) );
}

void CDlgComSetup::GetComPortData(SCOMPORT* psComPort)
{
	memcpy( psComPort, &m_sComPort, sizeof(m_sComPort) );
}

void CDlgComSetup::SetMode(int nMode)
{
	m_nMode = nMode;
}
