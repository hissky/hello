// DPaneArray.cpp: implementation of the DPaneArray class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EasyDriller.h"
#include "DPaneArray.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DPaneArray::DPaneArray()
{
	m_pCurrentPane			= NULL;
	m_nCurrentPaneIndex		= -1;
}

DPaneArray::~DPaneArray()
{

}

CFormView* DPaneArray::CreatePane(CWnd* pParentWnd, CRect rcPanePos, CRuntimeClass* pRuntimeClass, UINT nIndex)
{
	ASSERT( pRuntimeClass );

	if( NULL == pRuntimeClass )
		return NULL;

	CWnd* pWnd	= DYNAMIC_DOWNCAST( CWnd, pRuntimeClass->CreateObject() );

	ASSERT( pWnd );
	if( NULL == pWnd )
		return NULL;

	pWnd->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), pParentWnd, nIndex, NULL );

	CFormView* pPane	= DYNAMIC_DOWNCAST( CFormView, pWnd );

	ASSERT( pPane );
	if( NULL == pPane )
	{
		delete pWnd;
		return NULL;
	}

	CSize szSize = pPane->GetTotalSize();
	CRect rcPane;

	rcPane.top		= rcPanePos.top;
	rcPane.left		= rcPanePos.left;
	rcPane.right	= rcPanePos.left + szSize.cx;
	rcPane.bottom	= rcPanePos.top + szSize.cy;

	pPane->MoveWindow( rcPane );

	return pPane;
}

void DPaneArray::SelectPane(int nIdx)
{
	if( m_nCurrentPaneIndex == nIdx )
		return;

	int nPaneSize = m_aryPane.GetSize();

	if( nIdx > nPaneSize )
		return;

	if( NULL != m_pCurrentPane )
		m_pCurrentPane->ShowWindow( SW_HIDE );

	if( -1 != nIdx )
	{
		m_pCurrentPane = m_aryPane.GetAt( nIdx );

		if( NULL != m_pCurrentPane )
			m_pCurrentPane->ShowWindow( SW_SHOW );
	}

	m_nCurrentPaneIndex = nIdx;
}

void DPaneArray::AddPane(CFormView* pPane)
{
	if( NULL == pPane )
		return;

	m_aryPane.Add( pPane );
}

CFormView* DPaneArray::GetPane(int nIdx)
{
	int nSize = GetPaneSize();

	if( nIdx > nSize )
		return NULL;

	CFormView* pPane = m_aryPane.GetAt( nIdx );

	return pPane;
}
