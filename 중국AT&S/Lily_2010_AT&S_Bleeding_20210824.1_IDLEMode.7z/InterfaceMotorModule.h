
#define DLLAPI	extern "C" __declspec( dllexport )

namespace MOTOR_M
{
	DLLAPI BOOL Servo_Connect_E(BYTE niP1, BYTE niP2, BYTE niP3, BYTE niP4, BYTE nAxis);

	DLLAPI BOOL Servo_GetPosError(BYTE nAxis, long * lGetPos);
	DLLAPI BOOL Servo_GetEnable(BYTE nAxis);
	DLLAPI BOOL Servo_IsSlaveExist(BYTE nAxis);
	DLLAPI BOOL Servo_ServoEnable(BYTE nAxis, BOOL bUse);
	DLLAPI BOOL Servo_GetCommandPos(BYTE nAxis, long * lGetPos);
	DLLAPI BOOL Servo_SetCommandPos(BYTE nAxis, long lPos);
	DLLAPI BOOL Servo_GetActualPos(BYTE nAxis, long * lGetPos);
	DLLAPI BOOL Servo_MoveSingleAxisAbsPos(BYTE nAxis, long lPos, DWORD lSpeed);
	DLLAPI BOOL Servo_Connect(BYTE nPort, DWORD dwBaudrate);
	DLLAPI BOOL Servo_AllMoveOriginSingleAxis();
	DLLAPI BOOL Servo_MoveOriginSingleAxis(BYTE nAxis);
	DLLAPI void Servo_Disconnect();
	DLLAPI BOOL Servo_IsOrigin(BYTE nAxis);
	DLLAPI void Servo_SetReconnect(BOOL bReconnect);
	DLLAPI void Servo_AlarmReset();
}

using namespace MOTOR_M;