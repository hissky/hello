#if !defined(AFX_DLGLASERHEIGHTSET_H__A2B6D78C_83EE_41DB_849E_7F317A67C304__INCLUDED_)
#define AFX_DLGLASERHEIGHTSET_H__A2B6D78C_83EE_41DB_849E_7F317A67C304__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLaserHeightSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserHeightSet dialog

class CDlgLaserHeightSet : public CDialog
{
// Construction
public:
	CDlgLaserHeightSet(CWnd* pParent = NULL);   // standard constructor

	void SetData(double* d1stHeight, double* d2ndHeight, double* d1stHeightTophat, double* d2ndHeightTophat);
	void GetData(double* d1stHeight, double* d2ndHeight, double* d1stHeightTophat, double* d2ndHeightTophat);

// Dialog Data
	//{{AFX_DATA(CDlgLaserHeightSet)
	enum { IDD = IDD_DLG_LASER_HEIGHT };
	double m_d1stLaserHeight[MOTOR_MASK_MAX];
	double m_d2ndLaserHeight[MOTOR_MASK_MAX];
	double m_d1stLaserHeightTophat[MOTOR_MASK_MAX];
	double m_d2ndLaserHeightTophat[MOTOR_MASK_MAX];
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLaserHeightSet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgLaserHeightSet)
		// NOTE: the ClassWizard will add member functions here
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLASERHEIGHTSET_H__A2B6D78C_83EE_41DB_849E_7F317A67C304__INCLUDED_)
