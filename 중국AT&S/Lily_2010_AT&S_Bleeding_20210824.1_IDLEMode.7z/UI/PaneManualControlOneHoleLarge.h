#if !defined(AFX_PANEMANUALCONTROLONEHOLELARGE_H__7D76619D_7E54_4B27_85EA_C75C74B7AF48__INCLUDED_)
#define AFX_PANEMANUALCONTROLONEHOLELARGE_H__7D76619D_7E54_4B27_85EA_C75C74B7AF48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlOneHoleLarge.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlOneHoleLarge form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\device\heocard.h"
#include "..\device\CorrectTime.h"
#include "..\model\HOLEDATA.h"

class CPaneManualControlOneHoleLarge : public CFormView
{
protected:
	CPaneManualControlOneHoleLarge();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlOneHoleLarge)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlOneHoleLarge)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_ONEHOLE_LARGE };
	CColorEdit	m_edtPath;
	CColorEdit	m_edtScannerPosY;
	CColorEdit	m_edtScannerPosX;
	CColorStatic	m_stcPosY;
	CColorStatic	m_stcPosX;
	CColorEdit	m_edtGridX;
	CColorEdit	m_edtGridY;
	CColorEdit	m_edtFieldSize;
	CListBox	m_lboxResult;
	CColorEdit	m_edtThickness;
	CColorEdit	m_edtShotCount;
	CColorEdit	m_edtBurstCount;
	CColorEdit	m_edtAperturePath;
	CColorEdit	m_edtHeadOffsetX;
	CColorEdit	m_edtHeadOffsetY;
	CColorEdit	 m_edtFreq;
//	CColorEdit	 m_edtDuty;
	CColorEdit	 m_edtAOMDelay;
	CColorEdit	 m_edtAOMDuty;
	CComboBox	m_cmbMask;
	CComboBox	m_cmbCam;
	UEasyButtonEx	m_chkInspArea;
	UEasyButtonEx	m_btnSetCurPosZeroY;
	UEasyButtonEx	m_btnSetCurPosZeroX;
	UEasyButtonEx	m_btnPulseWidth;
	UEasyButtonEx	m_btnMeasure;
	UEasyButtonEx	m_chkLineFire;
	UEasyButtonEx	m_btnFileOpen;
	UEasyButtonEx	m_btnFire;
	UEasyButtonEx   m_btnPattern;
	UEasyButtonEx	m_btnManualSCalPosMove;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnJobFile;
	UEasyButtonEx	m_btnHeadOffset;
	UEasyButtonEx	m_btnApplyToBeampath;
	UEasyButtonEx	m_btnVariousFire;
	UEasyButtonEx	m_btnApplyZ;
	UEasyButtonEx	m_chkTopHat;
	UEasyButtonEx	m_chkUseParam;
	UEasyButtonEx	m_chkBeamPath;
	UEasyButtonEx	m_btnFindHole;
	CColorStatic	m_stcVisionResult;
	CColorStatic	m_stcGridSizeY;
	CColorStatic	m_stcGridSizeX;
	int				m_nFireType;



	CComboBox		m_cmbTool;
	CComboBox		m_cmbGrid;
	
	CColorEdit		m_edtZGap;
	CColorEdit	m_edtVoltage1;
	CColorEdit	m_edtVoltage2;

	CColorEdit	m_edtShotDuty;
	CColorEdit	m_edtShotFrequency;
	CColorEdit	m_edtAomWaitMaster;
	CColorEdit	m_edtAomWaitSlave;
	CColorEdit	m_edtAomNumMaster;
	CColorEdit	m_edtAomNumSlave;

	CColorEdit		m_edtPitch;

	UEasyButtonEx	m_btnZMinus5;
	UEasyButtonEx	m_btnZMinus4;
	UEasyButtonEx	m_btnZMinus3;
	UEasyButtonEx	m_btnZMinus2;
	UEasyButtonEx	m_btnZMinus1;
	UEasyButtonEx	m_btnZNone;
	UEasyButtonEx	m_btnZPlus1;
	UEasyButtonEx	m_btnZPlus2;
	UEasyButtonEx	m_btnZPlus3;
	UEasyButtonEx	m_btnZPlus4;
	UEasyButtonEx	m_btnZPlus5;

	UEasyButtonEx	m_btnLeftTop;
	UEasyButtonEx	m_btnRightTop;
	UEasyButtonEx	m_btnCenter;
	UEasyButtonEx	m_btnLeftBottom;
	UEasyButtonEx	m_btnRightBottom;
	UEasyButtonEx	m_btnFire2;
	//}}AFX_DATA

// Attributes
public:
	CCorrectTime	m_StandbyTime;
	BOOL			m_bVariousZ;
	double			m_dFirePosX;
	double			m_dFirePosY;
	int				m_nZIndex;
	int				m_nXScanIndex;
	int				m_nYScanIndex;
	int				m_nSelectTool;
	BOOL			m_bLineFire;
	BOOL			m_bTopHat;
	BOOL			m_bBeamPass;
	MARKDATA		m_MarkingData;

	CWinThread*		m_pOneHole;

	BOOL			m_bStop;
	BOOL			m_bHeadOffsetMode;
	CString			m_strPath;
	double			m_dHeadOffsetX;
	double			m_dHeadOffsetY;
	double			m_dHeadOffsetResX;
	double			m_dHeadOffsetResY;
	double			m_dBaseZ1;
	double			m_dBaseZ2;
	double			m_dHalfField;
	int				m_nFieldSize;
	long			m_lTzsLzs;
	int				m_nPattern;
	int			m_nIncrementalFirstPosX;
	int			m_nIncrementalFirstPosY;
	BOOL			m_bFindHoleMode;
	double			m_dLaserOffsetX;
	double			m_dLaserOffsetY;

	double m_dStartPosX;
	double m_dStartPosY;
	double m_dGridGapX;
	double m_dGridGapY;
	int		m_nTableGridX;
	int		m_nTableGridY;
	CString m_strResult;
	int m_nSelectShotIndex;	
// Attributes
protected:
	CFont			m_fntStatic;
	CFont			m_fntBtn;
	CFont			m_fntBtn2;
	CFont			m_fntEdit;
	CFont			m_fntEdit2;
	CFont			m_fntEdit3;
	CFont			m_fntCombo;
	CFont			m_fntListBox;

	int				m_nCamNo;
	UINT			m_nTimerID;
	BOOL			m_bIsLive;

	double			m_dBaseX;
	double			m_dBaseY;
	

	double			m_dHoleSet[MAX_BEAM_HOLE];
	int				m_nUserLevel;
	CDPoint		m_dFoundOffset[4];
	int				m_nGridX;
	int				m_nGridY;


	int m_nSelectBeamPathIndex;//20160404
	

// Operations
public:
	BOOL m_bContinuousFind;
	int  m_nAxisMode;
	BOOL MarkingGrid(int nGridX, int nGridY, int nMoveX, int nMoveY, int nGridSize, int nHead);
	BOOL DrillGrid(int nGridX, int nGridY, int nMoveX, int nMoveY, int nGridSize, int nHead, int nScannerIndex);
	void GetHeadOffsets(double& dHeadOffsetX, double& dHeadOffsetY, int nCam);
	BOOL IsValidLaserFirePos(double dLaserXPos, double dLaserYPos);
	BOOL TableMoveAndFire(double dLaserXPos, double dLaserYPos);
public:
	void EndProcess(BOOL bEnable = TRUE);
	void FindFireHole();
	void SetDefaultZScan();
	void UnSelectScannerButton();
	void UnSelectAllZButton();
	void SetAuthorityByLevel(int nLevel);
	void ChangeParam(int nIndex);
	void SetToolComboBox();
	void SetHeadOffsetRes();
	BOOL ShutterMove(BOOL bMaster, BOOL bSlave);
	BOOL InPositionCheck();
	BOOL ChangeOneSubTool(SUBTOOLDATA subTool, int nZIndex);
	void ReadNums(TCHAR* szBuffer);
	BOOL GetXYPos(TCHAR* szBuffer, int &nPosX, int &nPosY);
	void IsTzs(int nCount);
	void DeleteData();
	BOOL ReaseFileAndMem(CFile* pFileOri, CFile* pFileResult, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2);
	BOOL FindShot();
	BOOL GetOffsetFromVisionData(double dMoveX, double dMoveY, int nCountX, int nCountY, BOOL bUseLowCam, emHEAD em1st, emHEAD em2nd, bool bSave, DPOINT* pdPos1, DPOINT* pdOffset1, bool* pSuccess1, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2);
	int GetPointIndex(int nCountX, int nCountY, int nDivision, emHEAD emHead);
	BOOL			FindShotGrid(double dStartPosX, double dStartPosY);

	HoleDataList m_HolePatternList;
	int				XUMtoLSB(double dXPos);
	int				XUMtoLSBAbs(double dXPos);
	int				YUMtoLSB(double dYPos);
	int				YUMtoLSBAbs(double dXPos);
	void			InitStaticControl();
	void			InitBtnControl();
	void			InitEditControl();
	void			InitComboControl();
	void			InitListBoxControl();

	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			OnLive(int nCamNo, BOOL bOnOff);
	void			ResetLive();
	BOOL			GetIsLive()		{ return m_bIsLive; }
	void			OnMoveVisionView();

	void			MessageLoop();
	void			EnableAllButton(BOOL bEnable);
	BOOL			SpinMask(int nMaskNo);

	BOOL			LaserFire(int nZIndex,  int nScannerIndex);
	BOOL			MoveZ1LaserFocus();
	BOOL			MoveZ1VisionFocus(BOOL bLarge = TRUE);	
	BOOL			MoveZ2LaserFocus();
	BOOL			MoveZ2VisionFocus(BOOL bLarge = TRUE);

	void			WaitOneFireProcess();
	BOOL		FindOneHole(int nCam);

	void			SetHeadOffset();
	void			GetNextRetryFiducialPoint(DPOINT& ptStart, DPOINT& ptEnd, int& nDirection);
	void            GetVisionLampInfo(int nCamNo,VISION_INFO &sVisionInfo);

	BOOL DummyShotOn(BOOL bUseAom);
	BOOL PreCheckDummyShotOn(int nMask,BOOL bUseAom);
	BOOL WaitDummyShot();
	BOOL DoStandby(double dDiffTime);
	BOOL m_bUserDummyOn;
	BOOL m_bUseManualDrillDummy;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlOneHoleLarge)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlOneHoleLarge();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlOneHoleLarge)
	afx_msg void OnCheckLineFire();
	afx_msg void OnButtonApertureOpen();
	afx_msg void OnButtonFire();
	afx_msg void OnButtonPattern();
	afx_msg void OnButtonManualSCalPosMove();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonPulseWidth();
	afx_msg void OnButtonMeasure();
	afx_msg void OnButtonBurst();
	afx_msg void OnStartPosX();
	afx_msg void OnStartPosY();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeComboCam();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonJobFileOpen();
	afx_msg void OnButtonHeadOffset();
	afx_msg void OnEditchangeComboTool();
	afx_msg void OnEditchangeComboGrid();
	afx_msg void OnButtonApply();
	afx_msg void OnCheckTophat();
	afx_msg void OnButtonVfire();
	afx_msg void OnBtnApplyZ();
	afx_msg void OnBtnZ1();
	afx_msg void OnBtnZ2();
	afx_msg void OnBtnZ3();
	afx_msg void OnBtnZ4();
	afx_msg void OnBtnZ5();
	afx_msg void OnBtnZ6();
	afx_msg void OnBtnZ7();
	afx_msg void OnBtnZ8();
	afx_msg void OnBtnZ9();
	afx_msg void OnBtnZ10();
	afx_msg void OnBtnZ11();
	afx_msg void OnBtnUpleft();
	afx_msg void OnBtnUpright();
	afx_msg void OnBtnCenter();
	afx_msg void OnBtnDownleft();
	afx_msg void OnBtnDownright();
	afx_msg void OnButtonDefaultMode();
	afx_msg void OnButtonPatternMode();
	//}}AFX_MSG
	afx_msg LRESULT OnInspection(WPARAM wParam, LPARAM lParam = FALSE);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnChangeAxis();
	afx_msg void OnBnClickedBtnFindHole();
	afx_msg void OnBnClickedCheckContinue();
	afx_msg void OnBnClickedBtnFindStop();
	afx_msg void OnButtonFire2();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonOpenToolTable();

	afx_msg void OnBnClickedButtonShoewSelectedToolInfo();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLONEHOLELARGE_H__7D76619D_7E54_4B27_85EA_C75C74B7AF48__INCLUDED_)
