// DlgChangeAxis.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgChangeAxis.h"

#include "NAxis.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeAxis dialog


CDlgChangeAxis::CDlgChangeAxis(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChangeAxis::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChangeAxis)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgChangeAxis::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChangeAxis)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChangeAxis, CDialog)
	//{{AFX_MSG_MAP(CDlgChangeAxis)
	ON_BN_CLICKED(IDC_BTN_AXIS_0, OnBtnAxis0)
	ON_BN_CLICKED(IDC_BTN_AXIS_90, OnBtnAxis90)
	ON_BN_CLICKED(IDC_BTN_AXIS_180, OnBtnAxis180)
	ON_BN_CLICKED(IDC_BTN_AXIS_270, OnBtnAxis270)
	ON_BN_CLICKED(IDC_BTN_AXIS_LEFT_0, OnBtnAxisLeft0)
	ON_BN_CLICKED(IDC_BTN_AXIS_LEFT_90, OnBtnAxisLeft90)
	ON_BN_CLICKED(IDC_BTN_AXIS_LEFT_180, OnBtnAxisLeft180)
	ON_BN_CLICKED(IDC_BTN_AXIS_LEFT_270, OnBtnAxisLeft270)
	ON_BN_CLICKED(IDC_BTN_CURRENT_AXIS, OnBtnCurrentAxis)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeAxis message handlers

BOOL CDlgChangeAxis::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	HBITMAP hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_0));
	CButton *pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_0);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_90));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_90);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_180));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_180);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_270));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_270);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_LEFT_0));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_LEFT_0);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_LEFT_90));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_LEFT_90);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_LEFT_180));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_LEFT_180);
	pBtn->SetBitmap(hBmp);

	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_AXIS_LEFT_270));
	pBtn = (CButton *) GetDlgItem(IDC_BTN_AXIS_LEFT_270);
	pBtn->SetBitmap(hBmp);
	
	setButtonFont();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgChangeAxis::OnBtnAxis0() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_0;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxis90() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_90;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxis180() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_180;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxis270() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_270;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxisLeft0() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_left_0;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxisLeft90() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_left_90;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxisLeft180() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_left_180;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnAxisLeft270() 
{
	// TODO: Add your control notification handler code here
	m_nAxis = NAxis::axis_left_270;

	CDialog::OnOK();
}

void CDlgChangeAxis::OnBtnCurrentAxis() 
{
	// TODO: Add your control notification handler code here
	EndDialog(IDCANCEL);
	
}

void CDlgChangeAxis::setButtonFont()
{
	LOGFONT lf;
	::ZeroMemory((void *) &lf, sizeof(lf));
	lf.lfHeight = 16;
	lf.lfWidth = 0;
	lf.lfEscapement = 0;
	lf.lfOrientation = 0;
	lf.lfWeight = 700;
	lf.lfItalic = 0;
	lf.lfUnderline = 0;
	lf.lfStrikeOut = 0;
	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfOutPrecision = 3;
	lf.lfClipPrecision = 2;
	lf.lfQuality = 1;
	lf.lfPitchAndFamily = 34;
	::lstrcpy(lf.lfFaceName, DEF_FONT_FACE_NAME);

	m_fontBtn.CreateFontIndirect(&lf);

	GetDlgItem(IDC_BTN_CURRENT_AXIS)->SetFont(&m_fontBtn);
}
