// DrillDataView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DrillDataView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDrillDataView

IMPLEMENT_DYNCREATE(CDrillDataView, CScrollView)

CDrillDataView::CDrillDataView()
{
	m_ViewSize.cx		= 500;
	m_ViewSize.cy		= 500;
}

CDrillDataView::~CDrillDataView()
{
}


BEGIN_MESSAGE_MAP(CDrillDataView, CScrollView)
	//{{AFX_MSG_MAP(CDrillDataView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrillDataView drawing

void CDrillDataView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	// TODO: calculate the total size of this view
	SetScrollSizes(MM_TEXT, m_ViewSize);
}

void CDrillDataView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CDrillDataView diagnostics

#ifdef _DEBUG
void CDrillDataView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CDrillDataView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDrillDataView message handlers

void CDrillDataView::SetViewSize(CRect rt)
{
	m_rtView = rt;
}

BOOL CDrillDataView::CreateView(CWnd* pParent)
{
	BOOL bRet = Create( NULL, NULL, WS_VISIBLE | WS_CHILD | WS_BORDER, m_rtView, pParent, NULL, NULL );

	return bRet;
}

void CDrillDataView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	SetScrollSizes(MM_TEXT, m_ViewSize);
	
	CScrollView::OnPrepareDC(pDC, pInfo);
}

void CDrillDataView::PostNcDestroy() 
{
	TRACE("CDrillDataView::PostNcDestroy()\n");
//	CScrollView::PostNcDestroy();
}
