#if !defined(AFX_PANEDRILLDISPLAYSUB_H__82849791_E537_469A_9C52_1007078E3A2E__INCLUDED_)
#define AFX_PANEDRILLDISPLAYSUB_H__82849791_E537_469A_9C52_1007078E3A2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneDrillDisplaySub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplaySub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneDrillDisplaySub : public CFormView
{
protected:
	CPaneDrillDisplaySub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneDrillDisplaySub)

// Form Data
public:
	//{{AFX_DATA(CPaneDrillDisplaySub)
	enum { IDD = IDD_DLG_DRILL_DISPLAY_SUB };
	UEasyButtonEx	m_btnZoomOut;
	UEasyButtonEx	m_btnZoomIn;
	UEasyButtonEx	m_btnWindow;
	UEasyButtonEx	m_btnPosition;
	UEasyButtonEx	m_btnOriginal;
	UEasyButtonEx	m_btnField;
	UEasyButtonEx	m_btnConvert;
	UEasyButtonEx	m_btnClear;
	UEasyButtonEx	m_btnBack;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		InitBtnControl();
	void		SetBackPaneNo(int nPaneNo)		{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneDrillDisplaySub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneDrillDisplaySub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneDrillDisplaySub)
	afx_msg void OnButtonBack();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEDRILLDISPLAYSUB_H__82849791_E537_469A_9C52_1007078E3A2E__INCLUDED_)
