// ui\DlgFiducialView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "ui\DlgFiducialView.h"
#include "afxdialogex.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#include "..\model\DProject.h"

// CDlgFiducialView dialog

IMPLEMENT_DYNCREATE(CDlgFiducialView, CFormView)

CDlgFiducialView::CDlgFiducialView()
	: CFormView(CDlgFiducialView::IDD)
{
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		for(int j = 0; j < 2; j++)
		{
			for(int k = 0; k < 4; k++)
			{
				m_hBitmap[i][j][k] = NULL;
			}
		}
	}

	m_nFocusUIIndex = -1;
	m_bFiducialAllViewDlgShow = FALSE;
}

CDlgFiducialView::~CDlgFiducialView()
{
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		for(int j = 0; j < 2; j++)
		{
			for(int k = 0; k < 4; k++)
			{
				if(m_hBitmap[i][j][k] != NULL)
				{
					DeleteObject(m_hBitmap[i][j][k]);
					m_hBitmap[i][j][k] = NULL;
				}
			}
		}
	}
}

void CDlgFiducialView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SELECT_FIDBLOCK, m_cmbSelectFidBlock);
}

void CDlgFiducialView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	CRect rect;
			
	GetWindowRect(rect);
	m_siExtendSize = rect.Size(); 

	rect.bottom -= 335; //

//	GetDlgItem(IDC_STATIC_NORMAL)->GetWindowRect(rect);
	m_siNormalSize = rect.Size();

	return;
}
void CDlgFiducialView::SetReSize(BOOL bExt)
{
	if( bExt ) // Extend
	{
		GetDlgItem(IDC_STATIC_NORMAL)->ShowWindow(SW_SHOW);
//		this->SetWindowPos( NULL, 0, 0, m_siExtendSize.cx, m_siExtendSize.cy, SWP_NOMOVE|SWP_NOZORDER );
	}
	else // Normal
	{
		GetDlgItem(IDC_STATIC_NORMAL)->ShowWindow(SW_HIDE);
//		this->SetWindowPos( NULL, 0, 0, m_siNormalSize.cx, m_siNormalSize.cy, SWP_NOMOVE|SWP_NOZORDER );
	}
}

void CDlgFiducialView::SetBitMap(HBITMAP hBitmap, BOOL bFirst, int nFidIndex, int nFidBlock)
{
	int nMasterSlave = 1;
	if(bFirst)
		nMasterSlave = 0;

	if(nFidBlock < 0 || nFidBlock >= MAX_FID_BLOCK)
	{
		::DeleteObject(hBitmap);
		return;
	}
	if(nFidIndex < 0 || nFidIndex >= 4)
	{
		::DeleteObject(hBitmap);
		return;
	}

	if(m_hBitmap[nFidBlock][nMasterSlave][nFidIndex])
		DeleteObject(m_hBitmap[nFidBlock][nMasterSlave][nFidIndex]);
	m_hBitmap[nFidBlock][nMasterSlave][nFidIndex] = hBitmap;

	CString strFile, strLog;
	strFile.Format(_T("FidViewIndex"));
	strLog.Format(_T("FidBlock[%d] FidMS[%d] FidIndex[%d]"),nFidBlock,nMasterSlave,nFidIndex);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	Invalidate(FALSE);
}

void CDlgFiducialView::ResetAllBitMap()
{
	CString strCmbString = _T("");
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		for(int j = 0; j < 2; j++)
		{
			for(int k = 0; k < 4; k++)
			{
				if(m_hBitmap[i][j][k] != NULL)
				{
					DeleteObject(m_hBitmap[i][j][k]);
					m_hBitmap[i][j][k] = NULL;
				}
			}
		}
	}
	m_cmbSelectFidBlock.ResetContent();
	for(int i = 0; i <= gDProject.m_nMaxFidBlock; i++)
	{
		strCmbString.Format("Fiducial Block %d", i);
		m_cmbSelectFidBlock.AddString(strCmbString);
	}
	m_cmbSelectFidBlock.SetCurSel(0);
	Invalidate(FALSE);
}

BEGIN_MESSAGE_MAP(CDlgFiducialView, CFormView)

	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_CLOSE()
	ON_WM_SETFOCUS()
END_MESSAGE_MAP()


// CDlgFiducialView message handlers



void CDlgFiducialView::OnPaint()// 20130404 bhlee
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	DrawFidFimage();
}

void CDlgFiducialView::DrawFidFimage()// 20130404 bhlee
{
	int nResourceID = IDC_STATIC_FIDUCIAL_VIEW_LT;
	BOOL bFirst = TRUE;
	int nFidIndex = m_nFocusUIIndex;

	for(int i = 0; i < 8; i++)
	{
		switch(i)
		{
		case 0 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_LT;
			break;
		case 1 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_RT;
			break;
		case 2 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_LB;
			break;
		case 3 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_RB;
			break;

		case 4 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_LT2;
			break;
		case 5 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_RT2;
			break;
		case 6 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_LB2;
			break;
		case 7 :
			nResourceID = IDC_STATIC_FIDUCIAL_VIEW_RB2;
			break;
		}

		CClientDC dc(GetDlgItem(nResourceID));
		CDC BufferDC;
		CRect cRect;
		GetDlgItem(nResourceID)->GetClientRect(&cRect);
	
		BufferDC.CreateCompatibleDC(&dc);
		CBitmap bmpBuffer;
		bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
		CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
		CBrush cBr(RGB(0, 0, 0));
		BufferDC.FrameRect(&cRect, &cBr);
		BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
		CRgn cRgn;
		cRgn.CreateRectRgnIndirect(&cRect);
		BufferDC.SelectClipRgn(&cRgn);
	
		//	SetDCCoord(&BufferDC);
	
		int nPenSize;
		nPenSize = 3;
	
		CPen pen;
		CPen* pOldPen;
		CBrush cBr2;
		CBrush* pOldBrush;
	
		pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
		pOldPen = BufferDC.SelectObject(&pen);
	
		cBr2.CreateSolidBrush(RGB(0, 0, 200));
		pOldBrush = BufferDC.SelectObject(&cBr2);
	
		// draw
		bFirst = TRUE;
		nFidIndex = i;
		if(i > 3)
		{
			bFirst = FALSE;
			nFidIndex = nFidIndex - 4;
		}

		int nFidBlock = m_cmbSelectFidBlock.GetCurSel(); //20130516 bskim

		DrawBmp(&BufferDC, cRect, bFirst, nFidIndex, nFidBlock);
		// draw end
	
		BufferDC.SelectObject(pOldBrush);
		BufferDC.SelectObject(pOldPen);
	
		//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
		dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
		BufferDC.SelectObject(pOldBitmap);
	}

	if(m_nFocusUIIndex >= 0) // ���콺�� �� �ö����..
	{
		CClientDC dc(GetDlgItem(IDC_STATIC_NORMAL));
		CDC BufferDC;
		CRect cRect;
		GetDlgItem(IDC_STATIC_NORMAL)->GetClientRect(&cRect);
	
		BufferDC.CreateCompatibleDC(&dc);
		CBitmap bmpBuffer;
		bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
		CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
		CBrush cBr(RGB(0, 0, 0));
		BufferDC.FrameRect(&cRect, &cBr);
		BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
		CRgn cRgn;
		cRgn.CreateRectRgnIndirect(&cRect);
		BufferDC.SelectClipRgn(&cRgn);
	
		//	SetDCCoord(&BufferDC);
	
		int nPenSize;
		nPenSize = 3;
	
		CPen pen;
		CPen* pOldPen;
		CBrush cBr2;
		CBrush* pOldBrush;
	
		pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
		pOldPen = BufferDC.SelectObject(&pen);
	
		cBr2.CreateSolidBrush(RGB(0, 0, 200));
		pOldBrush = BufferDC.SelectObject(&cBr2);
	
		// draw
		bFirst = TRUE;
		nFidIndex = m_nFocusUIIndex;
		if(m_nFocusUIIndex > 3)
		{
			bFirst = FALSE;
			nFidIndex = nFidIndex - 4;
		}

		int nFidBlock = m_cmbSelectFidBlock.GetCurSel(); //20130516 bskim

		DrawBmp(&BufferDC, cRect, bFirst, nFidIndex, nFidBlock);
		// draw end
	
		BufferDC.SelectObject(pOldBrush);
		BufferDC.SelectObject(pOldPen);
	
		//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
		dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
		BufferDC.SelectObject(pOldBitmap);
	}
}

void CDlgFiducialView::DrawBmp(CDC *pDC, CRect rc, BOOL bFirst, int nIndex, int nFidBlock)// 20130404 bhlee
{
	int nMasterSlave = 1;
	if(bFirst)
		nMasterSlave = 0;
	if(m_hBitmap[nFidBlock][nMasterSlave][nIndex] == NULL)
		return;
	if(nFidBlock == -1)
		return;

	BITMAP bm;
	::GetObject(m_hBitmap[nFidBlock][nMasterSlave][nIndex], sizeof(BITMAP), &bm);
	
	CDC dc;
	dc.CreateCompatibleDC(pDC);
	HGDIOBJ hOldBitmap = ::SelectObject(dc.m_hDC, m_hBitmap[nFidBlock][nMasterSlave][nIndex]);
	
	pDC->StretchBlt(0, 0, rc.Width(), rc.Height(),
//					(int)(-(m_ptStart.y + dStep*bm.bmHeight - centerP.y)/dScale*nHalfY)+nHalfY,
//					int(dStep*bm.bmWidth/dScale*nHalfY),
//					int(dStep*bm.bmHeight/dScale*nHalfY),
					&dc, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
	
	::SelectObject(dc.m_hDC, hOldBitmap);
	dc.DeleteDC();
}


void CDlgFiducialView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CPoint pointOrigin = point;
	CRect rect;

	int nOldFocusIndex = m_nFocusUIIndex;

	for(int i = 0; i < 8; i++)
	{
		point = pointOrigin;
		switch(i)
		{
		case 0 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_LT)->GetWindowRect(&rect);
			break;
		case 1 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_RT)->GetWindowRect(&rect);
			break;
		case 2 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_LB)->GetWindowRect(&rect);
			break;
		case 3 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_RB)->GetWindowRect(&rect);
			break;

		case 4 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_LT2)->GetWindowRect(&rect);
			break;
		case 5 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_RT2)->GetWindowRect(&rect);
			break;
		case 6 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_LB2)->GetWindowRect(&rect);
			break;
		case 7 :
			GetDlgItem(IDC_STATIC_FIDUCIAL_VIEW_RB2)->GetWindowRect(&rect);
			break;
		}
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			m_nFocusUIIndex = i;
			if(nOldFocusIndex != m_nFocusUIIndex)
				Invalidate(FALSE);
			CFormView::OnMouseMove(nFlags, point);
			return;
		}
	}

	m_nFocusUIIndex = -1;
	if(nOldFocusIndex != m_nFocusUIIndex)
		Invalidate(FALSE);

	CFormView::OnMouseMove(nFlags, point);
}


void CDlgFiducialView::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_bFiducialAllViewDlgShow = FALSE;

	if(gSystemINI.m_sHardWare.bUseWideMonitor)
	{
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus())
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
	}
	CFormView::OnClose();
}



void CDlgFiducialView::OnSetFocus(CWnd* pOldWnd)
{
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SetFocus();
//	CDialog::OnSetFocus(pOldWnd);
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

void CDlgFiducialView::GetVisionRect(CRect &cRect)
{
	GetDlgItem(IDC_STATIC_NORMAL)->GetClientRect(&cRect);
}