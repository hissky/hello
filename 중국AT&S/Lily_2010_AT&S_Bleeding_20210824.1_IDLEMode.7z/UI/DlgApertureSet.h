#if !defined(AFX_DLGAPERTURESET_H__6FBF1491_411E_4334_9967_C0EE41E7CA4A__INCLUDED_)
#define AFX_DLGAPERTURESET_H__6FBF1491_411E_4334_9967_C0EE41E7CA4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgApertureSet.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgApertureSet dialog
#include "..\model\DProject.h"

class CDlgApertureSet : public CDialog
{
// Construction
public:
	void ChangeData(int nIndex);
	void UpdateList(int nIndex);
	void EnableAllItem(BOOL bEnable);
	void ChangeDisplay(int nIndex);
	void AddData(int nIndex);
	void LoadData();
	void InitEditControl();
	void InitComboControl();
	void InitBtnControl();
	void InitStaticControl();
	void InitListControl();
	APERTUREDATA m_ApertureData[MAX_SHOT_NO_UV];
	CDlgApertureSet(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgApertureSet)
	enum { IDD = IDD_APERTURE_SET };
	CListCtrl	m_listAperture;
	UEasyButtonEx	m_btnSetting;
	UEasyButtonEx	m_btnFileDel;
	UEasyButtonEx	m_btnUpdate;
	UEasyButtonEx	m_btnOK;
	UEasyButtonEx	m_btnCancel;
	CComboBox		m_cmbMask;
	CColorEdit		m_edtCurrent;
	CColorEdit		m_edtFreq;
	CColorEdit		m_edtZOffset;
	CColorEdit		m_edtSP;
	CColorEdit		m_edtJD;
	CColorEdit		m_edtLOND;
	CColorEdit		m_edtLOFFD;
	CColorEdit		m_edtFile;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgApertureSet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;

	// Generated message map functions
	//{{AFX_MSG(CDlgApertureSet)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonApertureOpen();
	afx_msg void OnButtonApertureDel();
	afx_msg void OnClickListApertureParam(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonParamUpdate();
	afx_msg BOOL DestroyWindow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGAPERTURESET_H__6FBF1491_411E_4334_9967_C0EE41E7CA4A__INCLUDED_)
