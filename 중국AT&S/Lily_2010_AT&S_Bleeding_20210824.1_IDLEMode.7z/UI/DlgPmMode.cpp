// DlgPmMode.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgPmMode.h"
#include "afxdialogex.h"


// DlgPmMode ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(DlgPmMode, CDialog)

DlgPmMode::DlgPmMode(CWnd* pParent /*=NULL*/)
	: CDialog(DlgPmMode::IDD, pParent)
{
	m_nMode = 0;
}

DlgPmMode::~DlgPmMode()
{
}

void DlgPmMode::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Radio(pDX, IDC_RADIO_IDLE, m_nMode);
}


BEGIN_MESSAGE_MAP(DlgPmMode, CDialog)
END_MESSAGE_MAP()


// DlgPmMode �޽��� ó�����Դϴ�.

int DlgPmMode::GetMode()
{
	return m_nMode;
}

void	DlgPmMode::SetMode(int nMode)
{
	m_nMode = nMode;
}

void DlgPmMode::InitControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_RADIO_IDLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_PM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_REPAIR)->SetFont( &m_fntBtn );

	GetDlgItem(IDC_STATIC_PM)->SetFont( &m_fntBtn );
	
}


BOOL DlgPmMode::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitControl();

	return TRUE;  // return TRUE unless you set the focus to a control
}
