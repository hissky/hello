// PaneSysSetupDir.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupDir.h"
#include "DirDialog.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\DProcessINI.h"
#include "..\model\DSystemINI.h"
#include "..\model\DBeampathINI.h"
#include "..\Device\HEocard.h"
#include "..\Device\HDeviceFactory.h"
#include "..\model\EasyDrillerINIFile.h"
#include "..\model\SystemINIFile.h"
#include "..\model\BeamPathINIFile.h"
#include "..\model\ProcessINIFile.h"
#include "..\EasyDrillerDlg.h"
#include "..\MODEL\GlobalVariable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupDir

IMPLEMENT_DYNCREATE(CPaneSysSetupDir, CFormView)

CPaneSysSetupDir::CPaneSysSetupDir()
	: CFormView(CPaneSysSetupDir::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupDir)
	//}}AFX_DATA_INIT
	m_strRoot					= _T("D:\\ViaHole\\");
	m_strParam					= _T("D:\\ViaHole\\Parameter\\");
	m_strCorrect				= _T("D:\\ViaHole\\Correct\\");
	m_strProject				= _T("D:\\ViaHole\\Project\\");
	m_strData					= _T("D:\\ViaHole\\Data\\");
	m_strConverted				= _T("D:\\ViaHole\\Converted\\");
	m_strImage					= _T("D:\\ViaHole\\Image\\");
	m_strErrorlog				= _T("D:\\ViaHole\\ErrorLog\\");
	m_strProcesslog				= _T("D:\\ViaHole\\ProcessLog\\");
	m_strBackup					= _T("D:\\ViaHole\\Backup\\");
	m_strSystem					= _T("D:\\ViaHole\\System\\");
	m_strAperture				= _T("D:\\ViaHole\\Aperture\\");
	m_strScaleLog				= _T("Z:\\");
	m_strNetwork				= _T("D:\\ViaHole\\System\\");
	m_str1stCalFilePath			= _T("D:\\ViaHole\\System\\Easy.ini");
	m_str1stSlaveCalFilePath	= _T("D:\\ViaHole\\System\\Process.ini");
	m_str2ndCalFilePath			= _T("D:\\ViaHole\\System\\System.ini");
	m_str2ndSlaveCalFilePath	= _T("D:\\ViaHole\\System\\BeamPath.ini");
	m_strScannerProfilePath		= _T("D:\\ViaHole\\Correct\\Default.pro");
	m_strBarcodeFilePath		= _T("D:\\ViaHole\\System\\LotDB.mdb");
	m_strImportantLog			= _T("D:\\ViaHole\\ImportantLog\\");
	m_strDataTest					= _T("D:\\ViaHole\\Data\\");
	
}

CPaneSysSetupDir::~CPaneSysSetupDir()
{
}

void CPaneSysSetupDir::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupDir)
	DDX_Control(pDX, IDC_EDIT_SCALELOG, m_edtScaleLog);
	DDX_Control(pDX, IDC_EDIT_NETWORK, m_edtNetWork);
	DDX_Control(pDX, IDC_BUTTON_SCALELOG, m_btnScaleLog);
	DDX_Control(pDX, IDC_BUTTON_NETWORK, m_btnNetwork);
	DDX_Control(pDX, IDC_EDIT_APERTURE, m_edtAperture);
	DDX_Control(pDX, IDC_BUTTON_APERTURE, m_btnAperture);
	DDX_Control(pDX, IDC_EDIT_SYSTEM, m_edtSystem);
	DDX_Control(pDX, IDC_BUTTON_SYSTEM, m_btnSystem);
	DDX_Control(pDX, IDC_BUTTON_BARCODE, m_btnBarcodeFile);
	DDX_Control(pDX, IDC_EDIT_1ST_CAL_FILE_PATH, m_edt1stCalFilePath);
	DDX_Control(pDX, IDC_EDIT_ROOT, m_edtRoot);
	DDX_Control(pDX, IDC_EDIT_PROJECT, m_edtProject);
	DDX_Control(pDX, IDC_EDIT_PROCESS_LOG, m_edtProcesslog);
	DDX_Control(pDX, IDC_EDIT_PARAM, m_edtParam);
	DDX_Control(pDX, IDC_EDIT_IMAGE, m_edtImage);
	DDX_Control(pDX, IDC_EDIT_ERROR_LOG, m_edtErrorlog);
	DDX_Control(pDX, IDC_EDIT_DATA, m_edtData);
	DDX_Control(pDX, IDC_EDIT_CORRECT, m_edtCorrect);
	DDX_Control(pDX, IDC_EDIT_CONVERTED, m_edtConverted);
	DDX_Control(pDX, IDC_EDIT_BACKUP, m_edtBackup);
	DDX_Control(pDX, IDC_EDIT_SCANNER_PROFILE, m_edtScannerProfilePath);
	DDX_Control(pDX, IDC_EDIT_BARCODE, m_edtBarcodeFile);
	DDX_Control(pDX, IDC_EDIT_EES, m_edtEES);
	DDX_Control(pDX, IDC_EDIT_DATA_TEST, m_edtDataTest);
	DDX_Control(pDX, IDC_BUTTON_ROOT, m_btnRoot);
	DDX_Control(pDX, IDC_BUTTON_PROJECT, m_btnProject);
	DDX_Control(pDX, IDC_BUTTON_PROCESS_LOG, m_btnProcesslog);
	DDX_Control(pDX, IDC_BUTTON_PARAM, m_btnParam);
	DDX_Control(pDX, IDC_BUTTON_IMAGE, m_btnImage);
	DDX_Control(pDX, IDC_BUTTON_ERROR_LOG, m_btnErrorlog);
	DDX_Control(pDX, IDC_BUTTON_DATA, m_btnData);
	DDX_Control(pDX, IDC_BUTTON_CORRECT, m_btnCorrect);
	DDX_Control(pDX, IDC_BUTTON_CONVERTED, m_btnConverted);
	DDX_Control(pDX, IDC_BUTTON_BACKUP, m_btnBackup);
	DDX_Control(pDX, IDC_BUTTON_1ST_CAL_FILE, m_btn1stCalFile);
	DDX_Control(pDX, IDC_BUTTON_1ST_CAL_FILE2, m_btnEasyBackup);
	DDX_Control(pDX, IDC_BUTTON_SCANNER_PROFILE, m_btnScannerProfileFile);
	DDX_Control(pDX, IDC_BUTTON_EES, m_btnEES);
	DDX_Control(pDX, IDC_BUTTON_DATA_TEST, m_btnDataTest);
	DDX_Control(pDX, IDC_COMBO_MACHINE_NO, m_cmbMachineNo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupDir, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupDir)
	ON_BN_CLICKED(IDC_BUTTON_ROOT, OnButtonRoot)
	ON_BN_CLICKED(IDC_BUTTON_PARAM, OnButtonParam)
	ON_BN_CLICKED(IDC_BUTTON_CORRECT, OnButtonCorrect)
	ON_BN_CLICKED(IDC_BUTTON_PROJECT, OnButtonProject)
	ON_BN_CLICKED(IDC_BUTTON_DATA, OnButtonData)
	ON_BN_CLICKED(IDC_BUTTON_CONVERTED, OnButtonConverted)
	ON_BN_CLICKED(IDC_BUTTON_IMAGE, OnButtonImage)
	ON_BN_CLICKED(IDC_BUTTON_ERROR_LOG, OnButtonErrorLog)
	ON_BN_CLICKED(IDC_BUTTON_PROCESS_LOG, OnButtonProcessLog)
	ON_BN_CLICKED(IDC_BUTTON_BACKUP, OnButtonBackup)
	ON_BN_CLICKED(IDC_BUTTON_1ST_CAL_FILE, OnButton1stCalFile)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_SYSTEM, OnButtonSystem)
	ON_BN_CLICKED(IDC_BUTTON_APERTURE, OnButtonAperture)
	ON_BN_CLICKED(IDC_BUTTON_SCANNER_PROFILE, OnButtonScannerProfile)
	ON_BN_CLICKED(IDC_BUTTON_BARCODE, OnButtonBarcodeFile)
	ON_BN_CLICKED(IDC_BUTTON_1ST_CAL_FILE2, OnButtonEasyBackup)
	ON_BN_CLICKED(IDC_BUTTON_SCALELOG, OnButtonScalelog)
	ON_BN_CLICKED(IDC_BUTTON_NETWORK, OnButtonNetwork)
	ON_BN_CLICKED(IDC_BUTTON_EES, OnButtonEES)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_DATA_TEST, &CPaneSysSetupDir::OnBnClickedButtonDataTest)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupDir diagnostics

#ifdef _DEBUG
void CPaneSysSetupDir::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupDir::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupDir message handlers

void CPaneSysSetupDir::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	SetDirData();

	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitComboControl();

	m_cmbMachineNo.ShowWindow(SW_HIDE);

}

void CPaneSysSetupDir::SetDirData()
{
	m_strRoot					= gEasyDrillerINI.m_clsDirPath.GetRootDir();
	m_strParam					= gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	m_strCorrect				= gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	m_strProject				= gEasyDrillerINI.m_clsDirPath.GetProjectDir();
	m_strData					= gEasyDrillerINI.m_clsDirPath.GetDataDir();
	m_strConverted				= gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	m_strImage					= gEasyDrillerINI.m_clsDirPath.GetImageDir();
	m_strErrorlog				= gEasyDrillerINI.m_clsDirPath.GetErrorLogDir();
	m_strProcesslog				= gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	m_strBackup					= gEasyDrillerINI.m_clsDirPath.GetBackupDir();
	m_strSystem					= gEasyDrillerINI.m_clsDirPath.GetSystemDir();
	m_strAperture				= gEasyDrillerINI.m_clsDirPath.GetApertureDir();
	m_strScaleLog				= gEasyDrillerINI.m_clsDirPath.GetScaleLogDir();
	m_strNetwork				= gEasyDrillerINI.m_clsDirPath.GetNetworkDir();
	m_str1stCalFilePath			= gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath();
	m_str1stSlaveCalFilePath	= gEasyDrillerINI.m_clsDirPath.Get1stSlaveCalFilePath();
	m_str2ndCalFilePath			= gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath();
	m_str2ndSlaveCalFilePath	= gEasyDrillerINI.m_clsDirPath.Get2ndSlaveCalFilePath();
	m_strScannerProfilePath		= gEasyDrillerINI.m_clsDirPath.GetScannerProfileFilePath();
	m_strBarcodeFilePath		= gEasyDrillerINI.m_clsDirPath.GetBarcodeDir();
	m_strImportantLog			= gEasyDrillerINI.m_clsDirPath.GetImportantLogDir();
	m_strDataTest					= gEasyDrillerINI.m_clsDirPath.GetDataTestDir();

	m_edtRoot.SetWindowText( (LPCTSTR)m_strRoot );
	m_edtParam.SetWindowText( (LPCTSTR)m_strParam );
	m_edtCorrect.SetWindowText( (LPCTSTR)m_strCorrect );
	m_edtProject.SetWindowText( (LPCTSTR)m_strProject );
	m_edtData.SetWindowText( (LPCTSTR)m_strData );
	m_edtConverted.SetWindowText( (LPCTSTR)m_strConverted );
	m_edtImage.SetWindowText( (LPCTSTR)m_strImage );
	m_edtErrorlog.SetWindowText( (LPCTSTR)m_strErrorlog );
	m_edtProcesslog.SetWindowText( (LPCTSTR)m_strProcesslog );
	m_edtBackup.SetWindowText( (LPCTSTR)m_strBackup );
	m_edtSystem.SetWindowText( (LPCTSTR)m_strSystem );
	m_edtAperture.SetWindowText( (LPCTSTR)m_strAperture );
	m_edtBarcodeFile.SetWindowText( (LPCTSTR)m_strBarcodeFilePath);
	m_edtScaleLog.SetWindowText( (LPCTSTR)m_strScaleLog );
	m_edtNetWork.SetWindowText( (LPCTSTR)m_strNetwork );
	m_edtScannerProfilePath.SetWindowText( (LPCTSTR)m_strScannerProfilePath );
	m_edtEES.SetWindowText( (LPCTSTR)m_strImportantLog );
	m_edtDataTest.SetWindowText( (LPCTSTR)m_strDataTest );
	CString str;
	CTime ct = CTime::GetCurrentTime();
	str.Format(_T("%02d%02d%02d"), ct.GetYear(),ct.GetMonth(), ct.GetDay());
	m_edt1stCalFilePath.SetWindowText(str);

}

void CPaneSysSetupDir::GetDirData()
{
	// Root
	m_edtRoot.GetWindowText( m_strRoot );
	gEasyDrillerINI.m_clsDirPath.SetRootDir( m_strRoot );

	// Parameter
	m_edtParam.GetWindowText( m_strParam );
	gEasyDrillerINI.m_clsDirPath.SetParameterDir( m_strParam );

	// Correct
	m_edtCorrect.GetWindowText( m_strCorrect );
	gEasyDrillerINI.m_clsDirPath.SetCorrectDir( m_strCorrect );

	// Project
	m_edtProject.GetWindowText( m_strProject );
	gEasyDrillerINI.m_clsDirPath.SetProjectDir( m_strProject );

	// Data
	m_edtData.GetWindowText( m_strData );
	gEasyDrillerINI.m_clsDirPath.SetDataDir( m_strData );

	// Data Test
	m_edtDataTest.GetWindowText( m_strDataTest );
	gEasyDrillerINI.m_clsDirPath.SetDataTestDir( m_strDataTest );

	// Converted
	m_edtConverted.GetWindowText( m_strConverted );
	gEasyDrillerINI.m_clsDirPath.SetConvertedDir( m_strConverted );

	// Image
	m_edtImage.GetWindowText( m_strImage );
	gEasyDrillerINI.m_clsDirPath.SetImageDir( m_strImage );

	// Error Log
	m_edtErrorlog.GetWindowText( m_strErrorlog );
	gEasyDrillerINI.m_clsDirPath.SetErrorLogDir( m_strErrorlog );

	// Process Log
	m_edtProcesslog.GetWindowText( m_strProcesslog );
	gEasyDrillerINI.m_clsDirPath.SetProcessLogDir( m_strProcesslog );

	// Backup
	m_edtBackup.GetWindowText( m_strBackup );
	gEasyDrillerINI.m_clsDirPath.SetBackupDir( m_strBackup );

	// System
	m_edtSystem.GetWindowText( m_strSystem );
	gEasyDrillerINI.m_clsDirPath.SetSystemDir( m_strSystem );

	// Aperture
	m_edtAperture.GetWindowText( m_strAperture );
	gEasyDrillerINI.m_clsDirPath.SetApertureDir( m_strAperture );

	m_edtScaleLog.GetWindowText( m_strScaleLog );
	gEasyDrillerINI.m_clsDirPath.SetScaleLogDir( m_strScaleLog );

	m_edtNetWork.GetWindowText( m_strNetwork );
	gEasyDrillerINI.m_clsDirPath.SetNetworkDir( m_strNetwork );

	// 1st Master Calibration File Path
	m_edt1stCalFilePath.GetWindowText(  m_str1stCalFilePath );
	gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath( m_str1stCalFilePath );

	m_edtScannerProfilePath.GetWindowText( m_strScannerProfilePath );
	gEasyDrillerINI.m_clsDirPath.SetScannerProfileFilePath( m_strScannerProfilePath );

	m_edtBarcodeFile.GetWindowText( m_strBarcodeFilePath );
	gEasyDrillerINI.m_clsDirPath.SetBarcodeDir( m_strBarcodeFilePath );

	TCHAR sz1stFile[255], sz2ndFile[255];
	lstrcpy(sz1stFile, gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
	lstrcpy(sz2ndFile, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
	
	HEocard* pEoCard = gDeviceFactory.GetEocard();
/*	if(!pEoCard->LoadCalibrationFile(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, _T("ASC"));
		ErrMessage(strMsg);
		
		CString strTemp;
		strTemp.Format(_T("%s or %s"), gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath(), gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));

		return;
#endif
	}
*/
}

void CPaneSysSetupDir::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, _T("Arial Bold"));

	// Working Directory
	GetDlgItem(IDC_STATIC_WORK_DIR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ROOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PARAM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CORRECT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PROJECT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DATA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONVERTED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IMAGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ERROR_LOG)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PROCESS_LOG)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BACKUP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SYSTEM)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_APERTURE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCALE_LOG)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NETWORK)->SetFont( &m_fntStatic );

	// Calibration Files
	GetDlgItem(IDC_STATIC_CAL_FILE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_PROFILE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CAL_FILE_PATH2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BARCODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_EES)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DATA_TEST)->SetFont( &m_fntStatic );
}

void CPaneSysSetupDir::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, _T("Arial Bold"));

	// Working Directory
	m_edtRoot.SetFont( &m_fntEdit );
	m_edtRoot.SetForeColor( BLACK_COLOR );
	m_edtRoot.SetBackColor( WHITE_COLOR );
	m_edtRoot.SetWindowText( (LPCTSTR)m_strRoot );

	m_edtParam.SetFont( &m_fntEdit );
	m_edtParam.SetForeColor( BLACK_COLOR );
	m_edtParam.SetBackColor( WHITE_COLOR );
	m_edtParam.SetWindowText( (LPCTSTR)m_strParam );

	m_edtCorrect.SetFont( &m_fntEdit );
	m_edtCorrect.SetForeColor( BLACK_COLOR );
	m_edtCorrect.SetBackColor( WHITE_COLOR );
	m_edtCorrect.SetWindowText( (LPCTSTR)m_strCorrect );

	m_edtProject.SetFont( &m_fntEdit );
	m_edtProject.SetForeColor( BLACK_COLOR );
	m_edtProject.SetBackColor( WHITE_COLOR );
	m_edtProject.SetWindowText( (LPCTSTR)m_strProject );

	m_edtData.SetFont( &m_fntEdit );
	m_edtData.SetForeColor( BLACK_COLOR );
	m_edtData.SetBackColor( WHITE_COLOR );
	m_edtData.SetWindowText( (LPCTSTR)m_strData );

	m_edtConverted.SetFont( &m_fntEdit );
	m_edtConverted.SetForeColor( BLACK_COLOR );
	m_edtConverted.SetBackColor( WHITE_COLOR );
	m_edtConverted.SetWindowText( (LPCTSTR)m_strConverted );

	m_edtImage.SetFont( &m_fntEdit );
	m_edtImage.SetForeColor( BLACK_COLOR );
	m_edtImage.SetBackColor( WHITE_COLOR );
	m_edtImage.SetWindowText( (LPCTSTR)m_strImage );

	m_edtErrorlog.SetFont( &m_fntEdit );
	m_edtErrorlog.SetForeColor( BLACK_COLOR );
	m_edtErrorlog.SetBackColor( WHITE_COLOR );
	m_edtErrorlog.SetWindowText( (LPCTSTR)m_strErrorlog );

	m_edtProcesslog.SetFont( &m_fntEdit );
	m_edtProcesslog.SetForeColor( BLACK_COLOR );
	m_edtProcesslog.SetBackColor( WHITE_COLOR );
	m_edtProcesslog.SetWindowText( (LPCTSTR)m_strProcesslog );

	m_edtBackup.SetFont( &m_fntEdit );
	m_edtBackup.SetForeColor( BLACK_COLOR );
	m_edtBackup.SetBackColor( WHITE_COLOR );
	m_edtBackup.SetWindowText( (LPCTSTR)m_strBackup );

	m_edtSystem.SetFont( &m_fntEdit );
	m_edtSystem.SetForeColor( BLACK_COLOR );
	m_edtSystem.SetBackColor( WHITE_COLOR );
	m_edtSystem.SetWindowText( (LPCTSTR)m_strSystem );

	m_edtAperture.SetFont( &m_fntEdit );
	m_edtAperture.SetForeColor( BLACK_COLOR );
	m_edtAperture.SetBackColor( WHITE_COLOR );
	m_edtAperture.SetWindowText( (LPCTSTR)m_strAperture );

	m_edtScaleLog.SetFont( &m_fntEdit );
	m_edtScaleLog.SetForeColor( BLACK_COLOR );
	m_edtScaleLog.SetBackColor( WHITE_COLOR );
	m_edtScaleLog.SetWindowText( (LPCTSTR)m_strScaleLog );

	m_edtNetWork.SetFont( &m_fntEdit );
	m_edtNetWork.SetForeColor( BLACK_COLOR );
	m_edtNetWork.SetBackColor( WHITE_COLOR );
	m_edtNetWork.SetWindowText( (LPCTSTR)m_strNetwork );

	// Calibration Files
	m_edt1stCalFilePath.SetFont( &m_fntEdit );
	m_edt1stCalFilePath.SetForeColor( BLACK_COLOR );
	m_edt1stCalFilePath.SetBackColor( WHITE_COLOR );
	m_edt1stCalFilePath.SetWindowText( _T("") );

	// Scanner move profile
	m_edtScannerProfilePath.SetFont( &m_fntEdit );
	m_edtScannerProfilePath.SetForeColor( BLACK_COLOR );
	m_edtScannerProfilePath.SetBackColor( WHITE_COLOR );
	m_edtScannerProfilePath.SetWindowText( (LPCTSTR)m_strScannerProfilePath );

	//barcode
	m_edtBarcodeFile.SetFont( &m_fntEdit );
	m_edtBarcodeFile.SetForeColor( BLACK_COLOR );
	m_edtBarcodeFile.SetBackColor( WHITE_COLOR );
	m_edtBarcodeFile.SetWindowText( (LPCTSTR)m_strBarcodeFilePath );

	//barcode
	m_edtEES.SetFont( &m_fntEdit );
	m_edtEES.SetForeColor( BLACK_COLOR );
	m_edtEES.SetBackColor( WHITE_COLOR );
	m_edtEES.SetWindowText( (LPCTSTR)m_strImportantLog );

	//Test Data
	m_edtDataTest.SetFont( &m_fntEdit );
	m_edtDataTest.SetForeColor( BLACK_COLOR );
	m_edtDataTest.SetBackColor( WHITE_COLOR );
	m_edtDataTest.SetWindowText( (LPCTSTR)m_strDataTest );
}

void CPaneSysSetupDir::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(120, _T("Arial Bold"));

	// Working Directory
	m_btnRoot.SetFont( &m_fntBtn );
	m_btnRoot.SetFlat( FALSE );
	m_btnRoot.EnableBallonToolTip();
	m_btnRoot.SetToolTipText( _T("Root Directory Selection") );
	m_btnRoot.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRoot.SetBtnCursor(IDC_HAND_1);

	m_btnParam.SetFont( &m_fntBtn );
	m_btnParam.SetFlat( FALSE );
	m_btnParam.EnableBallonToolTip();
	m_btnParam.SetToolTipText( _T("Parameter Directory Selection") );
	m_btnParam.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnParam.SetBtnCursor(IDC_HAND_1);

	m_btnCorrect.SetFont( &m_fntBtn );
	m_btnCorrect.SetFlat( FALSE );
	m_btnCorrect.EnableBallonToolTip();
	m_btnCorrect.SetToolTipText( _T("Correct Directory Selection") );
	m_btnCorrect.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCorrect.SetBtnCursor(IDC_HAND_1);

	m_btnProject.SetFont( &m_fntBtn );
	m_btnProject.SetFlat( FALSE );
	m_btnProject.EnableBallonToolTip();
	m_btnProject.SetToolTipText( _T("Project Directory Selection") );
	m_btnProject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProject.SetBtnCursor(IDC_HAND_1);

	m_btnData.SetFont( &m_fntBtn );
	m_btnData.SetFlat( FALSE );
	m_btnData.EnableBallonToolTip();
	m_btnData.SetToolTipText( _T("Data Directory Selection") );
	m_btnData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnData.SetBtnCursor(IDC_HAND_1);

	m_btnConverted.SetFont( &m_fntBtn );
	m_btnConverted.SetFlat( FALSE );
	m_btnConverted.EnableBallonToolTip();
	m_btnConverted.SetToolTipText( _T("Converted Directory Selection") );
	m_btnConverted.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnConverted.SetBtnCursor(IDC_HAND_1);

	m_btnImage.SetFont( &m_fntBtn );
	m_btnImage.SetFlat( FALSE );
	m_btnImage.EnableBallonToolTip();
	m_btnImage.SetToolTipText( _T("Image Directory Selection") );
	m_btnImage.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnImage.SetBtnCursor(IDC_HAND_1);

	m_btnErrorlog.SetFont( &m_fntBtn );
	m_btnErrorlog.SetFlat( FALSE );
	m_btnErrorlog.EnableBallonToolTip();
	m_btnErrorlog.SetToolTipText( _T("Error Log Directory Selection") );
	m_btnErrorlog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnErrorlog.SetBtnCursor(IDC_HAND_1);

	m_btnProcesslog.SetFont( &m_fntBtn );
	m_btnProcesslog.SetFlat( FALSE );
	m_btnProcesslog.EnableBallonToolTip();
	m_btnProcesslog.SetToolTipText( _T("Process Log Directory Selection") );
	m_btnProcesslog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProcesslog.SetBtnCursor(IDC_HAND_1);

	m_btnBackup.SetFont( &m_fntBtn );
	m_btnBackup.SetFlat( FALSE );
	m_btnBackup.EnableBallonToolTip();
	m_btnBackup.SetToolTipText( _T("Backup Directory Selection") );
	m_btnBackup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBackup.SetBtnCursor(IDC_HAND_1);

	m_btnSystem.SetFont( &m_fntBtn );
	m_btnSystem.SetFlat( FALSE );
	m_btnSystem.EnableBallonToolTip();
	m_btnSystem.SetToolTipText( _T("System Directory Selection") );
	m_btnSystem.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSystem.SetBtnCursor(IDC_HAND_1);

	m_btnAperture.SetFont( &m_fntBtn );
	m_btnAperture.SetFlat( FALSE );
	m_btnAperture.EnableBallonToolTip();
	m_btnAperture.SetToolTipText( _T("Aperture Directory Selection") );
	m_btnAperture.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAperture.SetBtnCursor(IDC_HAND_1);

	m_btnScaleLog.SetFont( &m_fntBtn );
	m_btnScaleLog.SetFlat( FALSE );
	m_btnScaleLog.EnableBallonToolTip();
	m_btnScaleLog.SetToolTipText( _T("Fiducial Scale Log Directory Selection") );
	m_btnScaleLog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScaleLog.SetBtnCursor(IDC_HAND_1);

	m_btnNetwork.SetFont( &m_fntBtn );
	m_btnNetwork.SetFlat( FALSE );
	m_btnNetwork.EnableBallonToolTip();
	m_btnNetwork.SetToolTipText( _T("Network Directory for public files") );
	m_btnNetwork.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNetwork.SetBtnCursor(IDC_HAND_1);

	// Calibration Files
	m_btn1stCalFile.SetFont( &m_fntBtn );
	m_btn1stCalFile.SetFlat( FALSE );
	m_btn1stCalFile.EnableBallonToolTip();
	m_btn1stCalFile.SetToolTipText( _T("INI File Reload") );
	m_btn1stCalFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btn1stCalFile.SetBtnCursor(IDC_HAND_1);

	m_btnEasyBackup.SetFont( &m_fntBtn );
	m_btnEasyBackup.SetFlat( FALSE );
	m_btnEasyBackup.EnableBallonToolTip();
	m_btnEasyBackup.SetToolTipText( _T("INI File Reload") );
	m_btnEasyBackup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnEasyBackup.SetBtnCursor(IDC_HAND_1);
	
	m_btnScannerProfileFile.SetFont( &m_fntBtn );
	m_btnScannerProfileFile.SetFlat( FALSE );
	m_btnScannerProfileFile.EnableBallonToolTip();
	m_btnScannerProfileFile.SetToolTipText( _T("Scanner Move Profile file Selection") );
	m_btnScannerProfileFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScannerProfileFile.SetBtnCursor(IDC_HAND_1);

	m_btnBarcodeFile.SetFont( &m_fntBtn );
	m_btnBarcodeFile.SetFlat( FALSE );
	m_btnBarcodeFile.EnableBallonToolTip();
	m_btnBarcodeFile.SetToolTipText( _T("Barcode MDB file Selection") );
	m_btnBarcodeFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBarcodeFile.SetBtnCursor(IDC_HAND_1);

	m_btnEES.SetFont( &m_fntBtn );
	m_btnEES.SetFlat( FALSE );
	m_btnEES.EnableBallonToolTip();
	m_btnEES.SetToolTipText( _T("Important Log Folder Selection") );
	m_btnEES.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnEES.SetBtnCursor(IDC_HAND_1);

	m_btnDataTest.SetFont( &m_fntBtn );
	m_btnDataTest.SetFlat( FALSE );
	m_btnDataTest.EnableBallonToolTip();
	m_btnDataTest.SetToolTipText( _T("Test Data Folder Selection") );
	m_btnDataTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDataTest.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupDir::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(120,_T("Arial Bold"));

	m_cmbMachineNo.SetFont( &m_fntCombo );

	m_cmbMachineNo.ResetContent();
	m_cmbMachineNo.AddString("28");
	m_cmbMachineNo.AddString("29");
	m_cmbMachineNo.AddString("30");
	m_cmbMachineNo.SetCurSel( 0 );
}

BOOL CPaneSysSetupDir::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupDir::OnButtonRoot() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Root Directory");
	dirDlg.m_strSelDir = m_strRoot;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strRoot.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtRoot.SetWindowText( (LPCTSTR)m_strRoot );
//		gEasyDrillerINI.m_clsDirPath.SetRootDir( m_strRoot );
	}
}

void CPaneSysSetupDir::OnButtonParam() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Parameter Directory");
	dirDlg.m_strSelDir = m_strParam;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strParam.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtParam.SetWindowText( (LPCTSTR)m_strParam );
//		gEasyDrillerINI.m_clsDirPath.SetParameterDir( m_strParam );
	}
}

void CPaneSysSetupDir::OnButtonCorrect() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Correct Directory");
	dirDlg.m_strSelDir = m_strCorrect;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strCorrect.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtCorrect.SetWindowText( (LPCTSTR)m_strCorrect );
//		gEasyDrillerINI.m_clsDirPath.SetCorrectDir( m_strCorrect );
	}
}

void CPaneSysSetupDir::OnButtonProject() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Project Directory");
	dirDlg.m_strSelDir = m_strProject;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strProject.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtProject.SetWindowText( (LPCTSTR)m_strProject );
//		gEasyDrillerINI.m_clsDirPath.SetProjectDir( m_strProject );
	}
}

void CPaneSysSetupDir::OnButtonData() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Data Directory");
	dirDlg.m_strSelDir = m_strData;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strData.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtData.SetWindowText( (LPCTSTR)m_strData );
//		gEasyDrillerINI.m_clsDirPath.SetDataDir( m_strData );
	}
}

void CPaneSysSetupDir::OnButtonConverted() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Converted Directory");
	dirDlg.m_strSelDir = m_strConverted;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strConverted.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtConverted.SetWindowText( (LPCTSTR)m_strConverted );
//		gEasyDrillerINI.m_clsDirPath.SetConvertedDir( m_strConverted );
	}
}

void CPaneSysSetupDir::OnButtonImage() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Image Directory");
	dirDlg.m_strSelDir = m_strImage;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strImage.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtImage.SetWindowText( (LPCTSTR)m_strImage );
//		gEasyDrillerINI.m_clsDirPath.SetImageDir( m_strImage );
	}
}

void CPaneSysSetupDir::OnButtonErrorLog() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Error Log Directory");
	dirDlg.m_strSelDir = m_strErrorlog;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strErrorlog.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtErrorlog.SetWindowText( (LPCTSTR)m_strErrorlog );
//		gEasyDrillerINI.m_clsDirPath.SetErrorLogDir( m_strErrorlog );
	}
}

void CPaneSysSetupDir::OnButtonProcessLog() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Process Log Directory");
	dirDlg.m_strSelDir = m_strProcesslog;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strProcesslog.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtProcesslog.SetWindowText( (LPCTSTR)m_strProcesslog );
//		gEasyDrillerINI.m_clsDirPath.SetProcessLogDir( m_strProcesslog );
	}
}

void CPaneSysSetupDir::OnButtonBackup() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Backup Directory");
	dirDlg.m_strSelDir = m_strBackup;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strBackup.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtBackup.SetWindowText( (LPCTSTR)m_strBackup );
//		gEasyDrillerINI.m_clsDirPath.SetBackupDir( m_strBackup );
	}
}

void CPaneSysSetupDir::OnButton1stCalFile() 
{
	//easy ini load 

	CEasyDrillerINIFile clsINI;
	CString strFilePath;
	//strFilePath.Format(_T("%sEasy.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	//if( FALSE == clsINI.OpenINIFile( strFilePath, gEasyDrillerINI ) )
	//{
	//	CString strString, strMsg;
	//	strString.LoadString(IDS_ERR_FILE_OPEN);
	//	strMsg.Format(strString,_T("Easy.ini"));
	//	ErrMessage(strMsg);
	//	return;
	//}

	//CSystemINIFile clsSystemINI;
	//
	//strFilePath.Format(_T("%sSystem.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	//
	//if( FALSE == clsSystemINI.OpenSystemINIFile( strFilePath, gSystemINI ) )
	//{
	//	CString strString, strMsg;
	//	strString.LoadString(IDS_ERR_FILE_OPEN);
	//	strMsg.Format(strString,_T("System.ini"));
	//	ErrMessage(strMsg);
	//	return ;
	//}
	//else
	//{
	//	if(gSystemINI.m_sHardWare.nManualMachine)
	//	{
	//		gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader = TRUE;
	//	}
	//	if(!gSystemINI.m_sHardWare.nDustTableUse)
	//	{
	//		gProcessINI.m_sProcessSystem.bNoUseDustSuction = TRUE;
	//	}
	//}

	//CProcessINIFile clsProcessINI;
	//strFilePath.Format(_T("%sProcess.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	//if( FALSE == clsProcessINI.OpenProcessINIFile( strFilePath, gProcessINI ) )
	//{
	//	CString strString, strMsg;
	//	strString.LoadString(IDS_ERR_FILE_OPEN);
	//	strMsg.Format(strString,_T("Process.ini"));
	//	ErrMessage(strMsg);
	//	return ;
	//}

	CString strMachineNo;
	int nMachineNoIndex = m_cmbMachineNo.GetCurSel();
	m_cmbMachineNo.GetLBText(nMachineNoIndex,strMachineNo);
	int nMachineNo = atoi(strMachineNo);
	//beam path ini
	gVariable.m_nMachineNo = nMachineNo;
	CBeamPathINIFile clsSBeamPathINI;
	strFilePath.Format(_T("%sBeamPath.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	if( FALSE == clsSBeamPathINI.OpenBeamPathINIFile( strFilePath, gBeamPathINI ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString,_T("BeamPath.ini"));
		ErrMessage(strMsg);
		return ;
	}

	CShotTableINIFile clsSShotTableINI;

	strFilePath.Format(_T("%sShotTable.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

	
	if( FALSE == clsSShotTableINI.OpenShotTableINIFile( strFilePath, gShotTableINI ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString,_T("ShotTable.ini"));
		ErrMessage(strMsg);
		return ;
	}
	
	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, UI_ALL);
	

}

HBRUSH CPaneSysSetupDir::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_WORK_DIR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_FILE_PATH)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_FILE_PATH2)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupDir::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupDir::OnButtonSystem() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller System Directory");
	dirDlg.m_strSelDir = m_strSystem;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strSystem.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtSystem.SetWindowText( (LPCTSTR)m_strSystem );
//		gEasyDrillerINI.m_clsDirPath.SetSystemDir( m_strSystem );
	}
}

void CPaneSysSetupDir::OnButtonAperture() 
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Aperture Directory");
	dirDlg.m_strSelDir = m_strAperture;
	
	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		
		
		m_strAperture.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtAperture.SetWindowText( (LPCTSTR)m_strAperture );
//		gEasyDrillerINI.m_clsDirPath.SetApertureDir( m_strAperture );
	}
}

void CPaneSysSetupDir::OnButtonScannerProfile() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] =_T("Calibration Files (*.pro)|*.pro|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE,_T("*.pro"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = m_strCorrect;
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	
	m_strScannerProfilePath.Format(_T("%s"), dlg.GetPathName() );
	m_edtScannerProfilePath.SetWindowText( (LPCTSTR)m_strScannerProfilePath );
}
void CPaneSysSetupDir::OnButtonBarcodeFile() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] =_T("Database Files (*.mdb)|*.mdb|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE,_T("*.mdb"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = m_strCorrect;
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	
	m_strBarcodeFilePath.Format(_T("%s"), dlg.GetPathName() );
	m_edtBarcodeFile.SetWindowText( (LPCTSTR)m_strBarcodeFilePath );
}
CString CPaneSysSetupDir::GetChangeValueStr()
{
	CString strMessage, strTemp, strPath1, strPath2;
	strMessage.Format(_T(""));

	// Root
	m_edtRoot.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetRootDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Root : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Parameter
	m_edtParam.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Parameter : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Correct
	m_edtCorrect.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Correct : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Project
	m_edtProject.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Project : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Data
	m_edtData.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetDataDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Data : %s "), strPath1);
		strMessage += strTemp;
	}

	// Data Test
	m_edtDataTest.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetDataTestDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Data Test : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Converted
	m_edtConverted.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Converted : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Image
	m_edtImage.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetImageDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Image : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Error Log
	m_edtErrorlog.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetErrorLogDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| ErrorLog : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Process Log
	m_edtProcesslog.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| ProcessLog : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Backup
	m_edtBackup.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetBackupDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Backup : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// System
	m_edtSystem.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetSystemDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| System : %s "), strPath1);
		strMessage += strTemp;
	}
	
	// Aperture
	m_edtAperture.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetApertureDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Aperture : %s "), strPath1);
		strMessage += strTemp;
	}

	// Barcode
	m_edtBarcodeFile.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetBarcodeDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Barcode : %s "), strPath1);
		strMessage += strTemp;
	}

	m_edtScaleLog.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetScaleLogDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Scale Log : %s "), strPath1);
		strMessage += strTemp;
	}

	m_edtNetWork.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetNetworkDir();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| Network : %s "), strPath1);
		strMessage += strTemp;
	}

	m_edtScannerProfilePath.GetWindowText( strPath1 );
	strPath2 = gEasyDrillerINI.m_clsDirPath.GetScannerProfileFilePath();
	if(0 != strPath1.CompareNoCase(strPath2))
	{
		strTemp.Format(_T("| S. Profile : %s "), strPath1);
		strMessage += strTemp;
	}

	return strMessage;

}

void CPaneSysSetupDir::EnableControl(BOOL bUse)
{
	m_edtRoot.EnableWindow(bUse);
	m_edtParam.EnableWindow(bUse);
	m_edtCorrect.EnableWindow(bUse);
	m_edtProject.EnableWindow(bUse);
	m_edtData.EnableWindow(bUse);
	m_edtConverted.EnableWindow(bUse);
	m_edtImage.EnableWindow(bUse);
	m_edtErrorlog.EnableWindow(bUse);
	m_edtProcesslog.EnableWindow(bUse);
	m_edtBackup.EnableWindow(bUse);
	m_edtSystem.EnableWindow(bUse);
	m_edtAperture.EnableWindow(bUse);
	m_edtScaleLog.EnableWindow(bUse);
	m_edtNetWork.EnableWindow(bUse);
	m_edt1stCalFilePath.EnableWindow(bUse);
	m_edtScannerProfilePath.EnableWindow(bUse);
	m_edtBarcodeFile.EnableWindow(bUse);
	m_btnRoot.EnableWindow(bUse);
	m_btnParam.EnableWindow(bUse);
	m_btnCorrect.EnableWindow(bUse);
	m_btnProject.EnableWindow(bUse);
	m_btnData.EnableWindow(bUse);
	m_btnConverted.EnableWindow(bUse);
	m_btnImage.EnableWindow(bUse);
	m_btnErrorlog.EnableWindow(bUse);
	m_btnProcesslog.EnableWindow(bUse);
	m_btnBackup.EnableWindow(bUse);
	m_btnSystem.EnableWindow(bUse);
	m_btnAperture.EnableWindow(bUse);
	m_btnScaleLog.EnableWindow(bUse);
	m_btnNetwork.EnableWindow(bUse);
	m_btn1stCalFile.EnableWindow(bUse);
	m_btnScannerProfileFile.EnableWindow(bUse);
	m_edtDataTest.EnableWindow(bUse);
}

void CPaneSysSetupDir::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		break;
	case 1:
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}

void CPaneSysSetupDir::OnButtonEasyBackup() 
{
	CString strBackupPath,temp,strOri;
	m_edt1stCalFilePath.GetWindowText(temp);
	
	if(temp.GetLength() <= 0)
	{
		ErrMessage(_T("Write Backup Name"));
		return;
	}

	CString str;
	str.Format(_T("%s"),gEasyDrillerINI.m_clsDirPath.GetSystemDir() + _T("Backup"));

	//backup���� Ȯ�� 
	if(!(GetFileAttributes(str) == FILE_ATTRIBUTE_DIRECTORY))
		CreateDirectory(str, NULL);

	strOri.Format(_T("%sEasy.ini"),gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	strBackupPath.Format(_T("%s%sEasy.ini"), str+_T("\\"), temp);
	CopyFile(strOri, strBackupPath, FALSE);

	strOri.Format(_T("%sProcess.ini"),gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	strBackupPath.Format(_T("%s%sProcess.ini"), str+_T("\\"), temp);
	CopyFile(strOri, strBackupPath, FALSE);

	strOri.Format(_T("%sSystem.ini"),gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	strBackupPath.Format(_T("%s%sSystem.ini"), str+_T("\\"), temp);
	CopyFile(strOri, strBackupPath, FALSE);

	strOri.Format(_T("%sBeamPath.ini"),gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	strBackupPath.Format(_T("%s%sBeamPath.ini"), str+_T("\\"), temp);
	CopyFile(strOri, strBackupPath, FALSE);

}

void CPaneSysSetupDir::OnButtonScalelog() 
{
	// TODO: Add your control notification handler code here
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Fiducial Scale Log Directory");
	dirDlg.m_strSelDir = m_strScaleLog;
	
	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		
		
		m_strScaleLog.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtScaleLog.SetWindowText( (LPCTSTR)m_strScaleLog );
	}
}

void CPaneSysSetupDir::OnButtonNetwork() 
{
	// TODO: Add your control notification handler code here
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Network Directory");
	dirDlg.m_strSelDir = m_strNetwork;
	
	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		
		
		m_strNetwork.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtNetWork.SetWindowText( (LPCTSTR)m_strNetwork );
	}
}




BOOL CPaneSysSetupDir::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
		if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_DIR) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneSysSetupDir::OnButtonEES()
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Network Directory");
	dirDlg.m_strSelDir = m_strImportantLog;
	
	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		
		
		m_strImportantLog.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtEES.SetWindowText( (LPCTSTR)m_strImportantLog );
	}
}

void CPaneSysSetupDir::OnBnClickedButtonDataTest()
{
	CDirDialog dirDlg;
	dirDlg.m_strTitle = _T("Choose Driller Data Directory");
	dirDlg.m_strSelDir = m_strDataTest;

	if (dirDlg.DoBrowse(this))
	{
		if (dirDlg.m_strPath.IsEmpty()) 
			return;		

		m_strDataTest.Format(_T("%s\\"), dirDlg.m_strPath);
		m_edtDataTest.SetWindowText( (LPCTSTR)m_strDataTest );
	}
}
