// DHandlerMonitor.h: interface for the DHandlerMonitor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DHANDLERMONITOR_H__F7F18005_F4BF_49A3_9E31_1E3140ED19C7__INCLUDED_)
#define AFX_DHANDLERMONITOR_H__F7F18005_F4BF_49A3_9E31_1E3140ED19C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct _tagLOTEND
{
	BOOL	bLotEndSignal;
	BOOL	bCheckLotEnd;
} SLOTEND;

class DHandlerMonitor  
{
public:
	DHandlerMonitor();
	virtual ~DHandlerMonitor();

	void	SetSensorMonitoring(DWORD* pData);
	void	SetMotorPosition(DWORD* pData);
	void	SetCassetteSlotStatus(DWORD* pData, BOOL bLow=TRUE);
	void	SetHandlerError(DWORD* pData, int nOffset=1);
	void	SetStageIF(DWORD dwData);
	void	SetWaferStatus(DWORD* pData);
	void	SetBarcodeIF(DWORD dwData);
	void	SetOneShotIF(DWORD dwData);

	// Chuck Interface between Stage and PLC
	SSTAGEIF	m_sStageIF;

	// Barcode Interface between Application and PLC
	SSTAGEIF		m_sBarcodeIF;

	// One Shot Vision Interface between Application and PLC
	SSTAGEIF		m_sOneShotIF;

	// System Switch & Power
	SSYSSENSOR		m_sSysSensor;

	// System Door
	SSYSDOOR		m_sSysDoor;

	// System Air
	SSYSAIR			m_sSysAir;

	// Stage Sensor
	SSTAGESENSOR	m_sStageSensor;

	// Cassette Sensor
	SCASSETTESENSOR	m_sCassetteSensor;

	// Pre Aligner Sensor
	SPREALIGNSENSOR	m_sPrealignSensor;

	// Stage Picker
	SSTAGEPICKERSENSOR	m_sStagePickerSensor;

	// Coater Picker
	SCOATERPICKERSENSOR	m_sCoaterPickerSensor;

	// Stage Position
	DSTAGEPOS		m_sStagePos;

	// Handler Position
	DHANDLERPOS		m_sHandlerPos;

	// Cassette Slot Status
	DWORD			m_nCassetteSlotStatus[27];

	// High Cassette Slot Status
	DWORD			m_nHighCassetteSlotStatus[25];

	// Handler Error
	DWORD			m_nHandlerError[19];

	// Wafer Status
	DWORD			m_nWaferStatus[7];

	// Wafer Slot
	DWORD			m_nWaferSlot[7];

	// LOT END
	SLOTEND			m_sLotEnd;

	// Polygon RPM
	double			m_dPolygonSpeed;
};

extern DHandlerMonitor gHandlerMonitor;

#endif // !defined(AFX_DHANDLERMONITOR_H__F7F18005_F4BF_49A3_9E31_1E3140ED19C7__INCLUDED_)
