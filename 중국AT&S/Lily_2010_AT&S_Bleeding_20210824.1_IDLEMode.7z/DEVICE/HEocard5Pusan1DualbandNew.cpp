// HEocard5Pusan1DualbandNew.cpp: implementation of the HEocard5Pusan1DualbandNew class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\EasyDriller.h"
#include "HEocard5Pusan1DualbandNew.h"
//#include "..\sysdef.h"
#include "..\Model\DSystemINI.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DProject.h"
#include "..\model\DProcessINI.h"
#include "..\MODEL\DShotTableINI.h"
#include "..\MODEL\GlobalVariable.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HEocard5Pusan1DualbandNew::HEocard5Pusan1DualbandNew()
{
	m_cCO2Laser = 0xFF;
	m_TDrillParam.bDryRun = TRUE;
	m_TDrillParam.eDrillMode = (EDrillMode)STEP_DIVIDE_MODE;
	m_TDrillParam.nMinShotLoopTime = 1000; 
	m_TDrillParam.nDotBatch_inPtn = 65535;
	m_TDrillParam.nTimeAfterInpos = 0; // jump delay�� ��ü
	m_TDrillParam.nTimeAfterShot = 0; // ?
	m_TDrillParam.nHoleCount = 0;



	m_TDrillParam.DumperPos.Pos[0].x = 0;
	m_TDrillParam.DumperPos.Pos[0].y = 0;
	m_TDrillParam.DumperPos.Pos[1].x = 0;
	m_TDrillParam.DumperPos.Pos[1].y = 0;

	m_TAomParam.bUse_DualBand = gSystemINI.m_sHardWare.nUseDualBand;
	m_TAomParam.nSel_Band0Band1 = 0;

	gSystemINI.m_sHardWare.nUseFirstOrder = TRUE;
	m_TAomParam.bUse_FirstOrderBeam = TRUE;

	m_bStandbyShotRun = FALSE;

	m_pDriver = NULL;

	m_pM1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pM2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pS1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pS2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];

	memset(m_pM1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pM2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pS1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pS2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);

	memset(m_ToolInfo, 0, sizeof(TDrillToolInfo) * 32);

	m_b4Beam		= FALSE;
	m_nApertureMode = STEP_ORIGIN_MODE;
	m_nBurstShotNo	= 3000;

	m_nDownHoleCount = 0;

	m_pBackUpData = new TDrillHoleData[DOWNLOAD_MAX_HOLE * 2];
	memset(m_pBackUpData, 0, sizeof(TDrillHoleData)*DOWNLOAD_MAX_HOLE * 2);
	m_nBackupCount = 0;
	m_nAOMDutyOffsetBackup = 0;
	memset(m_nHoleCnt, 0, sizeof(int)*64);

	m_pLPC_Monitor = new TLpc_Buffer;
	memset(m_pLPC_Monitor, NULL, sizeof(TLpc_Buffer));

	m_CalLPC = NULL;
	m_CalLPC = new CBicubicInterpolation;
	m_CalLPC->SetMaster(TRUE);

	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	LoadLPCCalibrationFile(strCalPath + _T("\\LPC.Cal"));


	m_nToolOldNo = -1;
	m_nBackUpIndex = 1;
	m_nSameShotPrestartCount = 0;

	m_nCardNo = 0;
}

HEocard5Pusan1DualbandNew::~HEocard5Pusan1DualbandNew()
{
	if(m_pDriver)
	{
		delete m_pDriver;
		m_pDriver = NULL;
	}

	if(m_pBackUpData)
	{
		delete[] m_pBackUpData;
		m_pBackUpData = NULL;
	}

	delete[] m_pM1Asc;
	delete[] m_pM2Asc;
	delete[] m_pS1Asc;
	delete[] m_pS2Asc;

	if(m_CalLPC)
	{
		delete m_CalLPC;
		m_CalLPC = NULL;
	}

	delete m_pLPC_Monitor;
}

void HEocard5Pusan1DualbandNew::SetCardNo(int nNo)
{
	m_nCardNo = nNo;
}

BOOL HEocard5Pusan1DualbandNew::InitCard()
{
#ifdef __TEST__
	return TRUE;
#endif
//	return TRUE;

	m_pDriver = new CETSx_API();
	BOOL bOpen = m_pDriver->PortOpen(m_nCardNo); // 0 index card loading

	if(!bOpen)
	{
		ErrMessage(_T("Eocard Port Open Error"), MB_OK);
		delete m_pDriver;
		m_pDriver = NULL;
		return FALSE;
	}

	//---------

	m_UsedBeam.v = 0;

	m_UsedBeam.bit.beam1 = TRUE;
	m_UsedBeam.bit.beam2 = FALSE;
	m_UsedBeam.bit.beam3 = FALSE;
	m_UsedBeam.bit.beam4 = FALSE;

	m_pDriver->ScanCfg_SetMoveBeam(&m_UsedBeam);

	m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	m_pDriver->Drill_SetParaAll(&m_TDrillParam);

	
	m_TAomParam.bUse_DualBand = gSystemINI.m_sHardWare.nUseDualBand;

	m_TAomParam.bUse_FirstOrderBeam = TRUE;
	m_pDriver->Drill_SetAomPara(&m_TAomParam);
	m_pDriver->ScanPara_SetEach(EETSx_FieldSize_mm, gSystemINI.m_sSystemDevice.dFieldSize.x , TRUE);

	SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);

	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
		OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}

	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}


	EChannelCfg dach[MAX_DA_CHANNEL] = {
		OUT_AnalogFps, OUT_RfOffLevel, OUT_LaserPower, OUT_Da1
	};
	
	CScanParaCmd Sp; 
//	CScanParaAux SpAux;
//	TLaserPara Lp;
	Sp.Init();
	Sp.fFieldSize_mm = (int)gSystemINI.m_sSystemDevice.dFieldSize.x;

	TLaserType lasertype;	
	lasertype.v = 0;
//	lasertype.bit.Ipg = 0;

	lasertype.bit.StandbyPulse = 0;

	lasertype.bit.Analog_FPS = 0;

//	m_pDriver->SetLaserType(lasertype);

#ifndef __NO_USE_INIT_LASER_IF__
	m_pDriver->LaserCtrl_SetEnableIO(FALSE);
#endif

	m_pDriver->BoardIO_SetTopBoard(1);						// Top Board �⺻Type ���� User Mode�� ���

	// Hsif0�� 1�� �ϵ���� �������� �ܶ��Ǿ��ִ�.
	// 0�� 1�� ������ ��ȣ.
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 0, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 1, SIG_GATE, 0);
///	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 2, SIG_AOM, 0);

	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 0, SIG_FPS, FALSE);
	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 1, SIG_LM, FALSE);

	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 0, SIG_LOAD_DATA0, 0); // laser enable
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 1, SIG_LOAD_DATA1, 0); // shutter open/close
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 2, SIG_LOAD_DATA2, 0); // laser power on/off


//	m_pDriver->SetIOInversion(0, 0);							//0: OutLif
//	m_pDriver->SetIOInversion(1, 4);							//1: InLif
//	m_pDriver->SetIOInversion(2, 0);							//2: OutHif

	m_pDriver->BoardIO_SetPinMux(Pin_IN_Laser_IF, 2, SIG_INPUT, TRUE);

								
//	m_pDriver->ScanCtrl_SetNumOfBeam(2);						
	m_pDriver->ScanCfg_SetNumOfBeam(2); // 100825						
	m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch); //
	m_pDriver->BoardIO_SetChannel(EETSx_DA_Channel, dach);				//�ϵ���� ä�� ����
#ifndef __NO_USE_INIT_LASER_IF__
	SetFunction(65535); // CO2 high : laser power on  (X)
#endif
	m_pDriver->LaserCtrl_SetEnableIO(TRUE);

	BOOL bXReverse, bYReverse, bAxisCange = FALSE;

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(0, bXReverse, bYReverse, 0, TRUE);
	//m_pDriver->ScanCfg_SetAxis(0, bXReverse, bYReverse, 0, TRUE); // 100825

	//---------------------------------------------------------
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(1, bXReverse, bYReverse, 0, TRUE);
	//m_pDriver->ScanCfg_SetAxis(1, bXReverse, bYReverse, 0, TRUE); // 100825

//	m_pDriver->List_ConfigSize(8192,8192);							// ����Ʈ ���� ����
//	m_pDriver->List_SetMode(LISTMODE_Rotary); // m_pDriver->SetListMode(LISTMODE_Rotary); //LISTMODE_Auto_Change);				// ����Ʈ �ڵ� �����Ͽ� ����

	m_pDriver->ScanPara_SetCmdAll(Sp, TRUE);			//��ĳ�� �Ķ���� ����
//	m_pDriver->ScanPara_SetAuxAll(SpAux, TRUE);
//	m_pDriver->LaserPara_SetAll(Lp, TRUE);			//������ �Ķ���� ����
	m_pDriver->Timer_UpdateTime();
#ifndef __NO_USE_INIT_LASER_IF__
	ResetCO2Laser();
#endif

	//for(int ii = 0; ii < MAX_TOOL_NO; ii++)
	//InitShotScale(ii);
	return TRUE;  // return TRUE unless you set the focus to a control
}

BOOL HEocard5Pusan1DualbandNew::SetParameter(FParameter *pParam, int nMask,int nToolType, double dAOMOffset1, double dAOMOffset2,int ShotIndex, double dInserted_WaitOffsetM, double dInserted_WaitOffsetS)
{

	if(!m_pDriver)
		return TRUE;

	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nMask];

	BOOL bResult;

	if(pParam->dDuty <= 0)
	{
		ErrMessage(_T("Error : Laser Duty  <= 0. Check Offset."));
		return FALSE;
	}

	double dSpeedRate = 1000 * gSystemINI.m_sSystemDevice.dFieldSize.x / 65535.;
	bResult = m_pDriver->ScanPara_SetEach(EETSx_DrawSpeed_ms, pParam->DrawStep/1000. , TRUE); // mm/s
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpSpeed_ms, gSystemINI.m_sSystemDevice.dJumpSpeed/1000., TRUE);
	
	if(nToolType == MARKING_TYPE)
	{
		bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpSpeed_ms, pParam->JumpStep/1000., TRUE);
		bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_CornerDelay_us, pParam->CornerDelay, TRUE);
		bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LineDelay_us, pParam->LineDelay, TRUE);

		if(gVariable.m_bDoingPreHeat )
			bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpDelay_us, gProcessINI.m_sProcessCal.nAutoRunPreheatJumpDelay, TRUE);
		else
			bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpDelay_us, pParam->JumpDelay, TRUE);
	}
	else
	{
	//	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpSpeed_ms, gSystemINI.m_sSystemDevice.dJumpSpeed/1000., TRUE);
		bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_CornerDelay_us, gSystemINI.m_sSystemDevice.nCornerDelay, TRUE);
		bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LineDelay_us, gSystemINI.m_sSystemDevice.nLineDelay, TRUE);

		if(gVariable.m_bDoingPreHeat )
			bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpDelay_us, gProcessINI.m_sProcessCal.nAutoRunPreheatJumpDelay, TRUE);
		else
			bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpDelay_us, gSystemINI.m_sSystemDevice.nJumpDelay, TRUE);
	}





	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LaserOffDelay_us, pParam->LaserOffDelay, TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LaserOnDelay_us, pParam->LaserOnDelay, TRUE);
//	bResult = bResult & m_pDriver->SetParaShortJumpDelay(Sp.ShortJumpDelay, TRUE);  ?
//	bResult = bResult & m_pDriver->SetParaShortJumpSpeed1(Sp.ShortJumpSpeed1, TRUE);
//	bResult = bResult & m_pDriver->SetParaShortJumpSpeed2(Sp.ShortJumpSpeed2, TRUE);

//	bResult = bResult & m_pDriver->SetParaLaserPower(Lp.LaserPower, TRUE);			//������ �Ķ���� ����
//	if(pParam->dDuty/100. >= 100 || pParam->dDuty/100. <= 0)
//		return FALSE;

	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, pParam->Frequency, TRUE);
	//bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, pParam->dDuty/100., TRUE);
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, pParam->dDuty, TRUE);//20170328
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_FPSDelay_us, 0, TRUE); // ?
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_FPSOnTime_us, 10 /*Lp.FPS_OnTime (us)*/, TRUE); // ?
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_StandbyPulseFreq_Hz, 1000, TRUE); // for CO2 Lp.StandbyPulse_Freq, 
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_StandbyPulseDuty_us, 0.2, TRUE); // for CO2 Lp.StandbyPulse_Duty(%), TRUE);

//	bResult = bResult & m_pDriver->SetAOMPara(pParam->dAOMDelay, pParam->dAOMDuty);
	CString str;
	str.Format(_T("%s"), pParam->cAOMFilePath);
	m_Parameter.DrawStep = pParam->DrawStep;
	m_Parameter.JumpStep = pParam->JumpStep;
	m_Parameter.StepPeriod = pParam->StepPeriod;
	m_Parameter.CornerDelay = pParam->CornerDelay;
	m_Parameter.JumpDelay = pParam->JumpDelay;
	m_Parameter.LineDelay = pParam->LineDelay;
	m_Parameter.LaserOnDelay = pParam->LaserOnDelay;
	m_Parameter.LaserOffDelay = pParam->LaserOffDelay;
	m_Parameter.FPSDelay = pParam->FPSDelay;
	m_Parameter.dDuty = pParam->dDuty;
	m_Parameter.Frequency = pParam->Frequency;
	m_Parameter.DrawStepPeriod = pParam->DrawStepPeriod;
	m_Parameter.dAOMDelay = pParam->dAOMDelay;
	m_Parameter.dAOMDuty = pParam->dAOMDuty;

	bResult = bResult & DownloadAOMProfile(-1, ShotIndex, str, 0, 0, 0, 0, dInserted_WaitOffsetM, dInserted_WaitOffsetS, 0, 0, nMask, dAOMOffset1, dAOMOffset2);//20160627															

	memcpy(m_Parameter.cAOMFilePath, pParam->cAOMFilePath, 255);

	if(bResult)
	{
		m_TDrillParam.nMinShotLoopTime = pParam->CycleTime * 1000; // ?
//		m_TDrillParam.eDrillMode = UV_LINE_MODE;
//		m_TDrillParam.nDotBatch_inPtn = 65535;
	
		m_TAomParam.bUse_DualBand = gSystemINI.m_sHardWare.nUseDualBand;

		m_TAomParam.bUse_FirstOrderBeam = TRUE;

		bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);
		bResult &= m_pDriver->Drill_SetAomPara(&m_TAomParam);
		return bResult;
	}
	else
		return FALSE;

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SetMinCycleTime(int us)
{
	if(!m_pDriver)
		return TRUE;

	if(us < 10)
		us = 0;

	m_TDrillParam.nMinShotLoopTime = us; 
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1DualbandNew::SetSelfLineDivide(BOOL bOn) // use ?
{
	if(!m_pDriver)
		return TRUE;

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SetMinShotTime(int us)
{
	return TRUE;
/*
	if(!m_pDriver)
		return TRUE;

	if(us < 10)
		us = 0;

	m_TDrillParam.nMinShotTime = us; 
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
*/}

void HEocard5Pusan1DualbandNew::jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	BOOL bUseFirmwareCal = FALSE;

	if(!bUseFirmwareCal)
	{
		int nX, nY;
		nX = x;
		nY = y;
		GetApplyCalPos(nX, nY, MASTER_1);
		x = nX;
		y = nY;
		nX = xS;
		nY = yS;
		GetApplyCalPos(nX, nY, SLAVE_1);
		xS = nX;
		yS = nY;
	}
//	m_pDriver->ScanCtrl_aJump(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(xS);
	posdata.Pos[1].y = GetUmData(yS);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1DualbandNew::mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;
	
	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	BOOL bUseFirmwareCal = FALSE;

	if(!bUseFirmwareCal)
	{
		int nX, nY;
		nX = x;
		nY = y;
		GetApplyCalPos(nX, nY, MASTER_1);
		x = nX;
		y = nY;
		nX = xS;
		nY = yS;
		GetApplyCalPos(nX, nY, SLAVE_1);
		xS = nX;
		yS = nY;
	}

//	m_pDriver->ScanCtrl_aDraw(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(xS);
	posdata.Pos[1].y = GetUmData(yS);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;
	

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

	if(bWaitEnd)
		StatusOK(IDLE);
}



void HEocard5Pusan1DualbandNew::jump_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}
	BOOL bUseFirmwareCal = FALSE;

	if(gVariable.m_bMarkingCavity == TRUE)
		bUseFirmwareCal = TRUE;

	if(!bUseFirmwareCal)
	{
		double dX, dY;
		dX = x;
		dY = y;
		GetApplyCalPos_Use_vm(dX, dY, MASTER_1);
		x = dX;
		y = dY;
		dX = xS;
		dY = yS;
		GetApplyCalPos_Use_vm(dX, dY, SLAVE_1);
		xS = dX;
		yS = dY;
	}
	
	//	m_pDriver->ScanCtrl_aJump(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData_New(x);
	posdata.Pos[0].y = GetUmData_New(y);
	posdata.Pos[1].x = GetUmData_New(xS);
	posdata.Pos[1].y = GetUmData_New(yS);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;


	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1DualbandNew::mark_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	BOOL bUseFirmwareCal = FALSE;

	if(gVariable.m_bMarkingCavity == TRUE)
		bUseFirmwareCal = TRUE;

	if(!bUseFirmwareCal)
	{
		double dX, dY;
		dX = x;
		dY = y;
		GetApplyCalPos_Use_vm(dX, dY, MASTER_1);
		x = dX;
		y = dY;
		dX = xS;
		dY = yS;
		GetApplyCalPos_Use_vm(dX, dY, SLAVE_1);
		xS = dX;
		yS = dY;
	}
	//	m_pDriver->ScanCtrl_aDraw(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData_New(x);
	posdata.Pos[0].y = GetUmData_New(y);
	posdata.Pos[1].x = GetUmData_New(xS);
	posdata.Pos[1].y = GetUmData_New(yS);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;


	m_pDriver->ScanCtrl_aDraw4B(&posdata);

	if(bWaitEnd)
		StatusOK(IDLE);
}

BOOL HEocard5Pusan1DualbandNew::MoveDrillCenterPos()
{
	if(!m_pDriver)
		return TRUE;

//	m_pDriver->Cal_SetEnableEach(0, FALSE);
//	m_pDriver->Cal_SetEnableEach(1, FALSE);

	TArrayPos3D posdata;
	posdata.Pos[0].x = 0;
	posdata.Pos[0].y = 0;
	posdata.Pos[1].x = 0;
	posdata.Pos[1].y = 0;
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825


	StatusOK(IDLE);
	
//	m_pDriver->Cal_SetEnableEach(0, TRUE);
//	m_pDriver->Cal_SetEnableEach(1, TRUE);
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::ApertureDataReset(int nToolNo) // toon no �ƴ�, nToolNo) // aperturn = pattern
{
	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_ResetPtn(nToolNo);// ���� �ؾ� ��. nToolNo); ***
}

BOOL HEocard5Pusan1DualbandNew::DownloadAperture(int nToolNo, int nX, int nY, int nAction)
{
	if(!m_pDriver)
		return TRUE;

		return m_pDriver->Drill_SetPtnDot32(nToolNo, m_PtnInfo.nPtnDotCnt[nToolNo], m_PtnInfo.PtnDot);

	
}

BOOL HEocard5Pusan1DualbandNew::DownloadShotDataDummy(	unsigned short usMasterX,
										unsigned short usMasterY,
										unsigned short usSlaveX,
										unsigned short usSlaveY,
										BOOL bApplyCalibrationMaster,
										BOOL bApplyCalibrationSlave,
										int nTCode)
{
	if(m_nCardNo == 1) // 2'nd EoCard
	{
		usMasterX = usSlaveX;
		usMasterY = usSlaveY;
		bApplyCalibrationMaster = bApplyCalibrationSlave;
	}
	if(!m_pDriver)
		return TRUE;

	m_DummyPos.Pos[0].x = GetUmData(usMasterX);
	m_DummyPos.Pos[0].y = GetUmData(usMasterY);
	m_DummyPos.Pos[1].x = GetUmData(usSlaveX);
	m_DummyPos.Pos[1].y = GetUmData(usSlaveY);
	m_DummyPos.Pos[2].x = 0;
	m_DummyPos.Pos[2].y = 0;
	m_DummyPos.Pos[3].x = 0;
	m_DummyPos.Pos[3].y = 0;

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadShotData2_Use_vm( double dMasterX,
										  double dMasterY,
										  double dSlaveX,
										  double dSlaveY,
										  BOOL bApplyCalibrationMaster, // ? use ??
										  BOOL bApplyCalibrationSlave,
										  int nTCode,
										   int nShotFilePosForLPCX,
											int nShotFilePosForLPCY,
											BOOL bUseFirmwareCal, BOOL bBackUpLPCPos)
{
	if(!m_pDriver)
		return TRUE;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		dMasterX = dSlaveX;
		dMasterY = dSlaveY;
		bApplyCalibrationMaster = bApplyCalibrationSlave;
	}
	if(!gVariable.m_bApplyScalFlag)
	{
		double dX, dY;
		dX = dMasterX;
		dY = dMasterY;
		GetApplyCalPos_Use_vm(dX, dY, MASTER_1);
		dMasterX = dX;
		dMasterY = dY;
		dX = dSlaveX;
		dY = dSlaveY;
		GetApplyCalPos_Use_vm(dX, dY, SLAVE_1);
		dSlaveX = dX;
		dSlaveY = dY;
	}

	
	

	m_ptData[m_nDownHoleCount].nToolNum = nTCode;
	m_ptData[m_nDownHoleCount].HolePos[0].x = GetUmData_New(dMasterX);
	m_ptData[m_nDownHoleCount].HolePos[0].y = GetUmData_New(dMasterY);
	m_ptData[m_nDownHoleCount].HolePos[1].x = GetUmData_New(dSlaveX);
	m_ptData[m_nDownHoleCount].HolePos[1].y = GetUmData_New(dSlaveY);

	m_ptData[m_nDownHoleCount].HolePos[2].x = 0;
	m_ptData[m_nDownHoleCount].HolePos[2].y = 0;
	m_ptData[m_nDownHoleCount].HolePos[3].x = 0;
	m_ptData[m_nDownHoleCount].HolePos[3].y = 0;

	m_ptData[m_nDownHoleCount].nUseAngle = 0;
	m_ptData[m_nDownHoleCount].fSine = 0;
	m_ptData[m_nDownHoleCount].fCosine = 1;

	int nIndex = m_nBackUpIndex * DOWNLOAD_MAX_HOLE + m_nBackupCount;
	if(bBackUpLPCPos)
	{
		m_pBackUpData[nIndex].nToolNum = nTCode;
		m_pBackUpData[nIndex].HolePos[0].x = GetUmData_New(dMasterX);
		m_pBackUpData[nIndex].HolePos[0].y = GetUmData_New(dMasterY);
		m_pBackUpData[nIndex].HolePos[1].x = GetUmData_New(dSlaveX);
		m_pBackUpData[nIndex].HolePos[1].y = GetUmData_New(dSlaveY);
		m_pBackUpData[nIndex].HolePos[2].x = 0;
		m_pBackUpData[nIndex].HolePos[2].y = 0;
		m_pBackUpData[nIndex].HolePos[3].x = nShotFilePosForLPCX;
		m_pBackUpData[nIndex].HolePos[3].y = nShotFilePosForLPCY;
		m_pBackUpData[nIndex].nUseAngle = 0;
		m_pBackUpData[nIndex].fSine = 0;
		m_pBackUpData[nIndex].fCosine = 1;
	}
	m_nBackupCount++;

	m_nHoleCnt[nTCode]++;

	m_nDownHoleCount++;

	TDrillPara Para; 
	BOOL bResult;
	int nRetry = 0;
	int nOnceDownCount = gSystemINI.m_sSystemDevice.nEocardDownCount;
	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		nOnceDownCount = 100;



	if(m_nDownHoleCount == nOnceDownCount) // 100�� ������ downloading
	{
		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			bResult = m_pDriver->Drill_GetPara(&Para);
			if(!bResult)
				return FALSE;
		}
		m_nDownHoleCount = 0;

		bResult = m_pDriver->Drill_AddHoleData(nOnceDownCount, m_ptData);
		
//		if(!gSystemINI.m_sSystemDevice.bCheckHoleData)
			return bResult;

/*		if(!bResult)
			return FALSE;
		while(nRetry <= 3)
		{
			bResult = m_pDriver->Drill_GetPara(&Para2);
			if(bResult)
			{
				if((int)(Para2.nHoleCount - Para.nHoleCount) == nOnceDownCount)
					break;
			}
			::Sleep(1);
			nRetry++;
		}
		if(nRetry > 3)
			return FALSE;

		bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
		if(!bResult)
			return FALSE;
		return IsSameHoleData(HoleData100, nOnceDownCount);
*/	}
	else
		return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadShotData2( unsigned short usMasterX,
										  unsigned short usMasterY,
										  unsigned short usSlaveX,
										  unsigned short usSlaveY,
										  BOOL bApplyCalibrationMaster, // ? use ??
										  BOOL bApplyCalibrationSlave,
										  int nTCode,
										   int nShotFilePosForLPCX,
											int nShotFilePosForLPCY,
											BOOL bUseFirmwareCal, BOOL bBackUpLPCPos)
{

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		usMasterX = usSlaveX;
		usMasterY = usSlaveY;
		bApplyCalibrationMaster = bApplyCalibrationSlave;
	}

	if(!gVariable.m_bApplyScalFlag)
	{
		int nX, nY;
		nX = usMasterX;
		nY = usMasterY;
		GetApplyCalPos(nX, nY, MASTER_1);
		usMasterX = nX;
		usMasterY = nY;
		nX = usSlaveX;
		nY = usSlaveY;
		GetApplyCalPos(nX, nY, SLAVE_1);
		usSlaveX = nX;
		usSlaveY = nY;
	}

	if(!m_pDriver)
		return TRUE;

	m_ptData[m_nDownHoleCount].nToolNum = nTCode;
	m_ptData[m_nDownHoleCount].HolePos[0].x = GetUmData(usMasterX);
	m_ptData[m_nDownHoleCount].HolePos[0].y = GetUmData(usMasterY);
	m_ptData[m_nDownHoleCount].HolePos[1].x = GetUmData(usSlaveX);
	m_ptData[m_nDownHoleCount].HolePos[1].y = GetUmData(usSlaveY);
	m_ptData[m_nDownHoleCount].HolePos[2].x = 0;
	m_ptData[m_nDownHoleCount].HolePos[2].y = 0;
	m_ptData[m_nDownHoleCount].HolePos[3].x = 0;
	m_ptData[m_nDownHoleCount].HolePos[3].y = 0;

	m_ptData[m_nDownHoleCount].nUseAngle = 0;
	m_ptData[m_nDownHoleCount].fSine = 0;
	m_ptData[m_nDownHoleCount].fCosine = 1;

	int nIndex = m_nBackUpIndex * DOWNLOAD_MAX_HOLE + m_nBackupCount;
	if(bBackUpLPCPos)
	{
		m_pBackUpData[nIndex].nToolNum = nTCode;
		m_pBackUpData[nIndex].HolePos[0].x = GetUmData(usMasterX);
		m_pBackUpData[nIndex].HolePos[0].y = GetUmData(usMasterY);
		m_pBackUpData[nIndex].HolePos[1].x = GetUmData(usSlaveX);
		m_pBackUpData[nIndex].HolePos[1].y = GetUmData(usSlaveY);
		m_pBackUpData[nIndex].HolePos[2].x = 0;
		m_pBackUpData[nIndex].HolePos[2].y = 0;
		m_pBackUpData[nIndex].HolePos[3].x = nShotFilePosForLPCX;
		m_pBackUpData[nIndex].HolePos[3].y = nShotFilePosForLPCY;
		m_pBackUpData[nIndex].nUseAngle = 0;
		m_pBackUpData[nIndex].fSine = 0;
		m_pBackUpData[nIndex].fCosine = 1;
	}
	m_nBackupCount++;

	m_nHoleCnt[nTCode]++;
	
	m_nDownHoleCount++;

	TDrillPara Para; 
	BOOL bResult;
	int nRetry = 0;
	int nOnceDownCount = gSystemINI.m_sSystemDevice.nEocardDownCount;
	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		nOnceDownCount = 100;

	if(m_nDownHoleCount == nOnceDownCount) // 100�� ������ downloading
	{
		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			bResult = m_pDriver->Drill_GetPara(&Para);
			if(!bResult)
				return FALSE;
		}
		m_nDownHoleCount = 0;
		bResult = m_pDriver->Drill_AddHoleData(nOnceDownCount, m_ptData);
		
//		if(!gSystemINI.m_sSystemDevice.bCheckHoleData)
			return bResult;

/*		if(!bResult)
			return FALSE;
		while(nRetry <= 3)
		{
			bResult = m_pDriver->Drill_GetPara(&Para2);
			if(bResult)
			{
				if((int)(Para2.nHoleCount - Para.nHoleCount) == nOnceDownCount)
					break;
			}
			::Sleep(1);
			nRetry++;
		}
		if(nRetry > 3)
			return FALSE;

		bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
		if(!bResult)
			return FALSE;
		return IsSameHoleData(HoleData100, nOnceDownCount);
*/	}
	else
		return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::ShotDataReset()
{
	if(!m_pDriver)
		return TRUE;

	m_nSameShotPrestartCount = 0;
	if(m_nBackUpIndex == 1)
		m_nBackUpIndex = 0;
	else
		m_nBackUpIndex = 1;

	m_nDownHoleCount = 0;
	m_nBackupCount = 0;
	memset(m_nHoleCnt, 0, sizeof(int)*64);

	BOOL bVal = m_pDriver->Drill_ResetFiredCount();
	return bVal & m_pDriver->Drill_ResetHole();
}

BOOL HEocard5Pusan1DualbandNew::SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode)
{
	if(!m_pDriver)
		return TRUE;

	if(DSP_ONLY == nDownmode || DSP_CONST_ONLY == nDownmode)
		return TRUE;

	if(nDownmode == DSP_ONLY)
	{
//		m_TDrillParam.b4Beam = m_b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)m_nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = m_nBurstShotNo;
	}

	if(nDownmode == DSP_CONST_ONLY)
	{
//		m_TDrillParam.b4Beam = m_b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)m_nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = m_nBurstShotNo;
	}
	else if(nDownmode == ALL_DOWN)
	{
//		m_TDrillParam.b4Beam = b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;

		m_b4Beam		= b4Beam;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}
	else
	{
//		m_TDrillParam.b4Beam = b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;

		m_b4Beam		= b4Beam;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}

//	m_TDrillParam.b4Beam = b4Beam;
//	m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
//	m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;
	
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1DualbandNew::DownloadTcode(TCODE_INFO *pToolInfo) // no used
{
	return TRUE;
/*	TDrillToolInfo	ToolConfig;

	pToolInfo->dDuty

	ToolConfig.nFreq = pToolInfo->nFreq;
	ToolConfig.nDuty[MAX_SHOTCNT];	// 1.5% --> 150 (100��)
	ToolConfig.nAOMDelay;	// 1 --> 0.05us
	ToolConfig.nAOMDuty;	// 1 --> 0.05us
	ToolConfig.nShotCnt;	// �� Pattern�� ��� shot�ؾ��ϴ°�? �Ǵ� �̹��� ��� Shot�ؾ��ϴ°�(MCCMD�ؼ��ҋ� CListItem�� ��Ҥ��� ���)
	ToolConfig.nBurstShot;		
	ToolConfig.bUsePtn;
	ToolConfig.nIndex;
*/
}

void HEocard5Pusan1DualbandNew::EStop()
{
	if(!m_pDriver)
		return;


	m_pDriver->Emergency_Cmd(Emergency_Stop);

}

BOOL HEocard5Pusan1DualbandNew::FieldStart(BOOL bDryRun)
{
	if(!m_pDriver)
		return TRUE;


	if(!bDryRun)
	{
		if(!m_pDriver->Drill_ClearLPCData())
			return FALSE;
		if(!m_pDriver->Lpc_SetEnable(gSystemINI.m_sHardWare.bUseLPC/*gProcessINI.m_sProcessOption.bCheckLPCError*/))
			return FALSE;
	}

//	if(IsDrillTimeOut())
//	{
//		EStop();
//		return FALSE;
//	}
//	if(IsMotorFault())
//	{
//		EStop();
//		return FALSE;
//	}
	BOOL bScannerCableError = IsScannerCableError();
	BOOL bScannerMotorFault = IsMotorFault();
	BOOL bScannerDrillTimeOut = IsDrillTimeOut();
	CString strErrorMsg = _T("");
	if(bScannerCableError)
	{
		EStop();
		ErrMessage(_T("Check scanner cable."));
		return FALSE;
	}
	else if(bScannerMotorFault)
	{
		if(bScannerMotorFault & 0x01)
			strErrorMsg += _T("Scanner Master X Motor Fault\n");
		if(bScannerMotorFault & 0x02)
			strErrorMsg += _T("Scanner Master Y Motor Fault\n");
		if(bScannerMotorFault & 0x04)
			strErrorMsg += _T("Scanner Slave X Motor Fault\n");
		if(bScannerMotorFault & 0x08)
			strErrorMsg += _T("Scanner Slave Y Motor Fault\n");

		EStop();
		ErrMessage(strErrorMsg);
		return FALSE;
	}
	else if(bScannerDrillTimeOut)
	{
		if(bScannerDrillTimeOut & 0x01)
			strErrorMsg += _T("Scanner Master X Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x02)
			strErrorMsg += _T("Scanner Master Y Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x04)
			strErrorMsg += _T("Scanner Slave X Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x08)
			strErrorMsg += _T("Scanner Slave Y Drill Time Out\n");

		EStop();
		ErrMessage(strErrorMsg);
		return FALSE;
	}
	return m_pDriver->Drill_Start(bDryRun);
}

int HEocard5Pusan1DualbandNew::ReadHoleCount()
{
	if(!m_pDriver)
		return 0;

	TDrillPara Para;
	if(!m_pDriver->Drill_GetPara(&Para))
	{
		::Sleep(10);
		if(!m_pDriver->Drill_GetPara(&Para))
			return -1; // false
	}

	return Para.nHoleCount;
}

void HEocard5Pusan1DualbandNew::DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
								 int xS, int yS, BOOL bS1ApplyCal,
								 int x_2, int y_2, BOOL bM2ApplyCal,
								 int xS_2, int yS_2, BOOL bS2ApplyCal, BOOL bWaitEnd)
{

}

void HEocard5Pusan1DualbandNew::DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd)
{

}

void HEocard5Pusan1DualbandNew::GetApplyCalPos(int &nX, int &nY, int nScannerNo)
{
	int nRefX, nRefY, nDiffX, nDiffY;
	BOOL bXChange = FALSE, bYChange = FALSE;
	nRefX = nDiffX = nX;
	nRefY = nDiffY = nY;

	if(nX < 0)
	{
		nRefX = 0;
		nDiffX = nRefX - nX;
		bXChange = TRUE;
	}
	if(nX > FIELD_LSB)
	{
		nRefX = FIELD_LSB;
		nDiffX = FIELD_LSB + nRefX - nX;
		bXChange = TRUE;
	}

	if(nY < 0)
	{
		nRefY = 0;
		nDiffY = nRefY - nY;
		bYChange = TRUE;
	}
	if(nY > FIELD_LSB)
	{
		nRefY = FIELD_LSB;
		nDiffY = FIELD_LSB + nRefY - nY;
		bYChange = TRUE;
	}

	if(bXChange || bYChange) // 0 ~ 65535 ����� ��� (��迡���� aperture �����Ҷ� �߻�, �ַ� ��ĳ�� ����������)
	{
		GetASCPos(nRefX, nRefY, nScannerNo);
		GetASCPos(nDiffX, nDiffY, nScannerNo);

		if(bXChange)
			nX = nRefX + nRefX - nDiffX;
		else
			nX = nRefX;
		if(bYChange)
			nY = nRefY + nRefY - nDiffY;
		else
			nY = nRefY;
	}
	else
	{
		GetASCPos(nX, nY, nScannerNo);
	}
}
void HEocard5Pusan1DualbandNew::GetApplyCalPos_Use_vm(double &dX, double &dY, int nScannerNo)
{
	double dRefX, dRefY, dDiffX, dDiffY;
	BOOL bXChange = FALSE, bYChange = FALSE;
	dRefX = dDiffX = dX;
	dRefY = dDiffY = dY;

	if(dX < 0)
	{
		dRefX = 0;
		dDiffX = dRefX - dX;
		bXChange = TRUE;
	}
	if(dX > FIELD_LSB)
	{
		dRefX = FIELD_LSB;
		dDiffX = FIELD_LSB + dRefX - dX;
		bXChange = TRUE;
	}

	if(dY < 0)
	{
		dRefY = 0;
		dDiffY = dRefY - dY;
		bYChange = TRUE;
	}
	if(dY > FIELD_LSB)
	{
		dRefY = FIELD_LSB;
		dDiffY = FIELD_LSB + dRefY - dY;
		bYChange = TRUE;
	}

	if(bXChange || bYChange) // 0 ~ 65535 ����� ��� (��迡���� aperture �����Ҷ� �߻�, �ַ� ��ĳ�� ����������)
	{
		GetASCPos_Use_vm(dRefX, dRefY, nScannerNo);
		GetASCPos_Use_vm(dDiffX, dDiffY, nScannerNo);

		if(bXChange)
			dX = dRefX + dRefX - dDiffX;
		else
			dX = dRefX;
		if(bYChange)
			dY = dRefY + dRefY - dDiffY;
		else
			dY = dRefY;
	}
	else
	{
		GetASCPos_Use_vm(dX, dY, nScannerNo);
	}
}
void HEocard5Pusan1DualbandNew::GetASCPos(int &nX, int &nY, int nScannerNo)
{
	DOUBLE_POINT* pOffsetData;
	unsigned int i, j;
	int n_x, n_y;
	int a0, a1, a2, b0, b1, b2, c0;

	if(nScannerNo == MASTER_1) pOffsetData = m_pM1Asc;
	else if(nScannerNo == MASTER_2) pOffsetData = m_pM2Asc;
	else if(nScannerNo == SLAVE_1) pOffsetData = m_pS1Asc;
	else pOffsetData = m_pS2Asc;


	int nOldX = nX;
	int nOldY = nY;
/*
	double dX2 = nX;
	double dY2 = nY;
	GetASCPos2(dX2, dY2, nScannerNo);
*/

	i = ((unsigned int)nX >> 10);	// ������ 1024�� ��
	j = ((unsigned int)nY >> 10);	// ������ 1024�� ��
	
	n_x = nX - (i<<10);				// ������ 1024�� ������
	n_y = nY - (j<<10);				// ������ 1024�� ������
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dX);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dX);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dX);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dX);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nX;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nX = ROUND_0_FFFF(c0);		// ���Ѱ� ó��
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dY);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dY);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dY);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dY);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nY;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nY = ROUND_0_FFFF(c0);		// ���Ѱ� ó��
}



void HEocard5Pusan1DualbandNew::GetASCPos_Use_vm(double &dX, double &dY, int nScannerNo)
{
	DOUBLE_POINT* pOffsetData;
	unsigned int i, j;
	double d_x, d_y;
	double a0, a1, a2, b0, b1, b2, c0;

	if(nScannerNo == MASTER_1) pOffsetData = m_pM1Asc;
	else if(nScannerNo == MASTER_2) pOffsetData = m_pM2Asc;
	else if(nScannerNo == SLAVE_1) pOffsetData = m_pS1Asc;
	else pOffsetData = m_pS2Asc;


	int nOldX = (int)dX;
	int nOldY = (int)dY;

	i = ((unsigned int)nOldX >> 10);	// ������ 1024�� ��
	j = ((unsigned int)nOldY >> 10);	// ������ 1024�� ��

	d_x = dX - (i<<10);				// ������ 1024�� ������
	d_y = dY - (j<<10);				// ������ 1024�� ������

	
	a0 = (pOffsetData[i * ASC_AXIS_SIZE + j].dX);
	a1 = (pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dX);
	b0 = (pOffsetData[i * ASC_AXIS_SIZE + j + 1].dX);        
	b1 = (pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dX);

	a2 = a0 + (d_x*(a1-a0)/1024.);
	b2 = b0 + (d_x*(b1-b0)/1024.);
	c0 = a2 + (d_y*(b2-a2)/1024.);

	dX = c0 + dX;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.


	a0 = (pOffsetData[i * ASC_AXIS_SIZE + j].dY);
	a1 = (pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dY);
	b0 = (pOffsetData[i * ASC_AXIS_SIZE + j + 1].dY);        
	b1 = (pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dY);

	a2 = a0 + (d_x*(a1-a0)/1024.);
	b2 = b0 + (d_x*(b1-b0)/1024.);
	c0 = a2 + (d_y*(b2-a2)/1024.);

     dY = c0 + dY;

	//TRACE("%d %d %.3f %.3f \n",nOldX,nOldY,dX,dY);
}

BOOL HEocard5Pusan1DualbandNew::LoadCalibrationFile(char *strM1path, char *strS1path, char *strM2path, char *strS2path)
{
	DOUBLE_POINT* pOffsetData;
	if(!m_pDriver)
		return TRUE;
	ts32 cal_data_x[MAX_PACKET_CALDATA_SIZE][MAX_PACKET_CALDATA_SIZE];		//���� �������� ��Ŷ ������ 33*33
	ts32 cal_data_y[MAX_PACKET_CALDATA_SIZE][MAX_PACKET_CALDATA_SIZE];
	TPos3D calReadData[MAX_PACKET_CALDATA_SIZE][MAX_PACKET_CALDATA_SIZE];

	int k, i, j;
	float data;
	char buf[256];	
	FILE* fp;
	errno_t err;
	fp = NULL;
	for(int kk = 0; kk < 4; kk++)
	{
		if(kk == MASTER_1) 
		{
			pOffsetData = m_pM1Asc;
			if(strM1path == NULL)
				continue;
			err = fopen_s(&fp, strM1path,_T("r"));	
		}
		else if(kk == MASTER_2) 
		{
			pOffsetData = m_pM2Asc;
			if(strM2path == NULL)
				continue;
			err = fopen_s(&fp, strM2path,_T("rt"));
		}
		else if(kk == SLAVE_1) 
		{
			pOffsetData = m_pS1Asc;
			if(strS1path == NULL)
				continue;
			err = fopen_s(&fp, strS1path,_T("rt"));
		}
		else 
		{
			pOffsetData = m_pS2Asc;
			if(strS2path == NULL)
				continue;
			err = fopen_s(&fp, strS2path,_T("rt"));
		}

		if(NULL != err)
			return FALSE;
		
		fgets(buf, sizeof(buf), fp);	
		for (k=0; k < 2; k++) 
		{
			for  (j=0; j<65; j++) 
			{
				for (i=0; i<65; i++)   
				{
					switch(k) {
					case  0:
						fscanf(fp, _T("%f"), &data);
						cal_data_y[i][j]  = (int)data;
						pOffsetData[i * ASC_AXIS_SIZE + j].dY  = data;
						break;
					case  1:
						fscanf(fp, _T("%f"), &data);
						cal_data_x[i][j]  = (int)data;
						pOffsetData[i * ASC_AXIS_SIZE + j].dX  = data;
						break;
					default:  break;
					}
				}//  for (i)
			}//  for (j)
		} //  for (k)	
		fclose(fp);
//		
 		if(gVariable.m_bApplyScalFlag == TRUE)
		{
			int nX = cal_data_x[0][0];
			int nY = cal_data_y[0][0];

			/*
			int nChangeX = (nX / 65535. * gSystemINI.m_sSystemDevice.dFieldSize.x) * 1000;
			int nChangeY = (nY / 65535. * gSystemINI.m_sSystemDevice.dFieldSize.x) * 1000;
			
			TRACE("%d %d %d %d \n",nX,nY,nChangeX,nChangeY);
			cal_data_x[i][j]  = nChangeX;
			cal_data_y[i][j]  = nChangeY;
			*/


			if(!m_pDriver->Cal_LoadData(kk, 0, &cal_data_x[0][0]))		//x�� ���� ������
				return FALSE;
			if(!m_pDriver->Cal_LoadData(kk, 1, &cal_data_y[0][0]))		//y�� ���� ������
				return FALSE;

			/*
			if(!m_pDriver->Cal_LoadData(kk, 0, &cal_data_x[0][0]))		//x�� ���� ������
				return FALSE;
			if(!m_pDriver->Cal_LoadData(kk, 1, &cal_data_y[0][0]))		//y�� ���� ������
				return FALSE;
			*/
		}

		if(gVariable.m_bMarkingCavity == TRUE)
		{
			if(!m_pDriver->Cal_LoadData(kk, 0, &cal_data_x[0][0]))		//x�� ���� ������
				return FALSE;
			if(!m_pDriver->Cal_LoadData(kk, 1, &cal_data_y[0][0]))		//y�� ���� ������
				return FALSE;
		}


	}
	return TRUE;
}

void HEocard5Pusan1DualbandNew::CO2LaserEnable(BOOL bEnable)
{
	if(bEnable)
		m_cCO2Laser = m_cCO2Laser & 0xFA;
	else
		m_cCO2Laser = m_cCO2Laser | 0x05;

	SetFunction(m_cCO2Laser);
	return;
}

BOOL HEocard5Pusan1DualbandNew::CO2LaserMainShutter(BOOL bOn)
{
	if(bOn)
		m_cCO2Laser = m_cCO2Laser & 0xFD;
	else
		m_cCO2Laser = m_cCO2Laser | 0x02;

	SetFunction(m_cCO2Laser);
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::GetParameter(FParameter *pParam)
{
	pParam->DrawStep		= m_Parameter.DrawStep;
	pParam->JumpStep		= m_Parameter.JumpStep;
	pParam->StepPeriod		= m_Parameter.StepPeriod;
	pParam->CornerDelay		= m_Parameter.CornerDelay;
	pParam->JumpDelay		= m_Parameter.JumpDelay;
	pParam->LineDelay		= m_Parameter.LineDelay;
	pParam->LaserOnDelay	= m_Parameter.LaserOnDelay;
	pParam->LaserOffDelay	= m_Parameter.LaserOffDelay;
	pParam->FPSDelay		= m_Parameter.FPSDelay;
	pParam->dDuty			= m_Parameter.dDuty;
	pParam->Frequency		= m_Parameter.Frequency;
	pParam->DrawStepPeriod	= m_Parameter.DrawStepPeriod;
	pParam->dAOMDelay		= m_Parameter.dAOMDelay;
	pParam->dAOMDuty		= m_Parameter.dAOMDuty;
	memcpy(pParam->cAOMFilePath, m_Parameter.cAOMFilePath, 255);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::Create()
{
	if(!m_pDriver)
		return TRUE;
//	if(gSystemINI.m_sSystemDevice.nSelfLineDivide) ????????????????
//	m_TDrillParam.eDrillMode = (EDrillMode)STEP_DIVIDE_MODE;
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture)
{
	if(!m_pDriver)
		return TRUE;

	BOOL bResult=TRUE;

	m_ToolInfo[nToolNo].nNumUsedSubTool = 1;
	m_ToolInfo[nToolNo].nUsedSubToolId[0] = nToolNo;


	m_SubToolConfig[nToolNo].nFreq = nFreq;
	m_SubToolConfig[nToolNo].nDotBurstShotCnt = nBurstShot;
	m_SubToolConfig[nToolNo].nDotTotalShotCnt = nTotalShot;
	
	if(!bUseAperture)
	{
		m_SubToolConfig[nToolNo].nUsedPtnId = -1;

	}
	else
	{
		m_SubToolConfig[nToolNo].nUsedPtnId = nToolNo; //bUseAperture;
	}
	
	if(bResult) bResult = bResult & m_pDriver->Drill_SetToolInfo(nToolNo, &m_ToolInfo[nToolNo]);
	if(bResult) bResult = bResult & m_pDriver->Drill_SetSubTool(nToolNo, &m_SubToolConfig[nToolNo]);
	return bResult;

}

BOOL HEocard5Pusan1DualbandNew::DownloadDutyAOM(unsigned int nToolNo, unsigned int nShotIndex, double dDuty, double dAOMDelay, double dAOMDuty)
{
	if(!m_pDriver)
		return TRUE;

	BOOL bReturnVal;
	if((dDuty) / (10000. / m_SubToolConfig[nToolNo].nFreq) >= 100 || dDuty <= 0)
	{
		ErrMessage(_T("Error : Laser Duty  <= 0. Check Duty and Offset."));
		return FALSE;
	}

	m_SubToolConfig[nToolNo].fDuty_us[nShotIndex] = dDuty;			// us
	m_SubToolConfig[nToolNo].nAomInfoId[nShotIndex] = nToolNo * 15 + nShotIndex;
//	m_PtnInfo[nToolNo].PtnConfig.fAOMDelay[nShotIndex] = dAOMDelay; // us
//	m_PtnInfo[nToolNo].PtnConfig.fAOMDuty_us[nShotIndex] = dAOMDuty;	// us

	bReturnVal = m_pDriver->Drill_SetSubTool(nToolNo, &m_SubToolConfig[nToolNo]);
	return bReturnVal;

}

void HEocard5Pusan1DualbandNew::jump(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(x);
	posdata.Pos[1].y = GetUmData(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1DualbandNew::mark(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;
	
	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(x);
	posdata.Pos[1].y = GetUmData(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

}
void HEocard5Pusan1DualbandNew::jump_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;

	}
	BOOL bUseFirmwareCal = FALSE;

	if(gVariable.m_bMarkingCavity == TRUE)
		bUseFirmwareCal = TRUE;

	if(!bUseFirmwareCal)
	{
		double dX, dY;
		dX = x;
		dY = y;
		GetApplyCalPos_Use_vm(dX, dY, MASTER_1);
		x = dX;
		y = dY;
		dX = xS;
		dY = yS;
		GetApplyCalPos_Use_vm(dX, dY, SLAVE_1);
		xS = dX;
		yS = dY;
	}
	
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData_New(x);
	posdata.Pos[0].y = GetUmData_New(y);
	posdata.Pos[1].x = GetUmData_New(x);
	posdata.Pos[1].y = GetUmData_New(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;


	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1DualbandNew::mark_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

	if(m_nCardNo == 1) // 2'nd EoCard
	{
		x = xS;
		y = yS;
	}

	BOOL bUseFirmwareCal = FALSE;

	if(gVariable.m_bMarkingCavity == TRUE)
		bUseFirmwareCal = TRUE;

	if(!bUseFirmwareCal)
	{
		double dX, dY;
		dX = x;
		dY = y;
		GetApplyCalPos_Use_vm(dX, dY, MASTER_1);
		x = dX;
		y = dY;
		dX = xS;
		dY = yS;
		GetApplyCalPos_Use_vm(dX, dY, SLAVE_1);
		xS = dX;
		yS = dY;
	}
	
	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData_New(x);
	posdata.Pos[0].y = GetUmData_New(y);
	posdata.Pos[1].x = GetUmData_New(x);
	posdata.Pos[1].y = GetUmData_New(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

}
BOOL HEocard5Pusan1DualbandNew::IsDSPBusy()
{
	if(!m_pDriver) 
		return TRUE;

	TRunStatus dData;

	m_pDriver->List_GetRunStatus(&dData);
	return dData.bit.Busy;
}
BOOL HEocard5Pusan1DualbandNew::ResetScannerStatusErrorCount()
{
	if(!m_pDriver) 
		return TRUE;
		
	return m_pDriver->Error_Reset_ScanErrorStatusCount();
			
}
BOOL HEocard5Pusan1DualbandNew::IsDrillTimeOut()
{
	if(!m_pDriver) 
		return TRUE;
	
//	TRunStatus dData;
	
//	m_pDriver->List_GetRunStatus(&dData);
//	return dData.bit.TimeOut;
	TErrorStatus dError;
	m_pDriver->Error_GetErrorStatus(&dError);
	int nErrorBit = 0;
	if(dError.TimeOutCnt[0] > 0)//�迭�� index �� 0 = Master X, 1 = Master Y, 2 = Slave X, 3 = Slave Y   --> return ���� Bit ������ �Ѱ��ٰ���
	{
		nErrorBit = nErrorBit | 0x1;
	}
	if(dError.TimeOutCnt[1] > 0)
	{
		nErrorBit = nErrorBit | 0x2;
	}
	if(dError.TimeOutCnt[2] > 0)
	{
		nErrorBit = nErrorBit | 0x4;
	}
	if(dError.TimeOutCnt[3] > 0)
	{
		nErrorBit = nErrorBit | 0x8;
	}
	return nErrorBit;
}



BOOL HEocard5Pusan1DualbandNew::IsMotorFault()
{
	if(!m_pDriver) 
		return TRUE;
	
	//	return 0;
	
//	TRunStatus dData;
	
//	m_pDriver->List_GetRunStatus(&dData);
//	return dData.bit.MotorFault;
	TErrorStatus dError;
	m_pDriver->Error_GetErrorStatus(&dError);
	int nErrorBit = 0;
	if(dError.MotorFaultCnt[0] > 0)//�迭�� index �� 0 = Master X, 1 = Master Y, 2 = Slave X, 3 = Slave Y   --> return ���� Bit ������ �Ѱ��ٰ���
	{
		nErrorBit = nErrorBit | 0x1;
	}
	if(dError.MotorFaultCnt[1] > 0)
	{
		nErrorBit = nErrorBit | 0x2;
	}
	if(dError.MotorFaultCnt[2] > 0)
	{
		nErrorBit = nErrorBit | 0x4;
	}
	if(dError.MotorFaultCnt[3] > 0)
	{
		nErrorBit = nErrorBit | 0x8;
	}
	return nErrorBit;
}
BOOL HEocard5Pusan1DualbandNew::IsScannerCableError()
{
	if(!m_pDriver) 
		return TRUE;


		TErrorStatus dError;
		m_pDriver->Error_GetErrorStatus(&dError);
		return dError.nGsbStsSigErrCnt;


}
void HEocard5Pusan1DualbandNew::MakeInpositionTable()
{


	
}

void HEocard5Pusan1DualbandNew::SaveInposTimeTable()
{
	if(!m_pDriver) 
		return;

		unsigned int time_X[MAX_DRILL_INPOSTIME_DATA+1];
		unsigned int time_Y[MAX_DRILL_INPOSTIME_DATA+1];
		m_pDriver->Drill_GetInposTimeTable(&time_X[0], &time_Y[0]);

		time_t timer = time(NULL);
		struct tm *pTime = localtime(&timer);

		char szPath[30];
		sprintf(szPath,"D:\\ETS5_Log");
		CreateDirectory(szPath,NULL);

		char szfilename[100];

		sprintf(szfilename,"%s\\InposTimeTable_%4d%02d%02d%02d%02d%02d.txt",szPath,pTime->tm_year+1900,pTime->tm_mon+1,pTime->tm_mday,pTime->tm_hour, pTime->tm_min, pTime->tm_sec);

		FILE* stream = fopen(szfilename, "a+t");	
		fseek(stream, 0L, SEEK_SET);

		fprintf(stream, "Position,	X,		Y\n"); 
		double fdistance = gSystemINI.m_sSystemDevice.dFieldSize.x/512.0;
		for(int i=0; i<MAX_DRILL_INPOSTIME_DATA; i++)
		{
			double fdistance_vm; 
			fdistance_vm = fdistance*i*10000;
			fprintf(stream, "%d,		%d,		%d\n", (int)fdistance_vm, time_X[i], time_Y[i]); 
		}
		fclose(stream);

}

void HEocard5Pusan1DualbandNew::GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY)
{
	usDumpMX = 65535;
	usDumpMY = 32767;
	usDumpSX = 65535;
	usDumpSY = 32767;
}

BOOL HEocard5Pusan1DualbandNew::LaserOnOff(BOOL bOn)
{
	if(!m_pDriver) 
		return TRUE;
	if(bOn)
		return m_pDriver->LaserCtrl_LaserOnOff(TRUE);
	else
		return m_pDriver->LaserCtrl_LaserOnOff(FALSE);
}

BOOL HEocard5Pusan1DualbandNew::jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return FALSE;

	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(x);
	posdata.Pos[1].y = GetUmData(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825


	if(bWaitEnd)
		StatusOK(IDLE);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return TRUE;

	TArrayPos3D posdata;
	posdata.Pos[0].x = GetUmData(x);
	posdata.Pos[0].y = GetUmData(y);
	posdata.Pos[1].x = GetUmData(x);
	posdata.Pos[1].y = GetUmData(y);
	posdata.Pos[2].x = 0;
	posdata.Pos[2].y = 0;
	posdata.Pos[3].x = 0;
	posdata.Pos[3].y = 0;

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

	if(bWaitEnd)
		StatusOK(IDLE);

	return TRUE;
}

void HEocard5Pusan1DualbandNew::MoveToCenter()
{
//	jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
}

BOOL HEocard5Pusan1DualbandNew::ResetSubToolForAllTool()
{

	for(int i = 0; i < 32 ; i++)
	{
		m_ToolInfo[i].nNumUsedSubTool = 1;
		m_ToolInfo[i].nUsedSubToolId[0] = i;
		m_SubToolConfig[i].nFreq = 1000;
		m_SubToolConfig[i].nDotBurstShotCnt = 0;
		m_SubToolConfig[i].nDotTotalShotCnt = 0;
		m_SubToolConfig[i].nUsedPtnId = -1;
	}

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadOneSubTool(int nTool, SUBTOOLDATA subTool,  BOOL bSetPowerLevel,  BOOL bMakeLPCTable)
{
	if(!m_pDriver) 
		return TRUE;

	BOOL bResult;
	BOOL bUseAom = FALSE;
	FParameter Para;
	GetParameter(&Para);
//	BOOL bTophat = subTool.bUseTophat;

	m_nToolOldNo = nTool;
	memcpy(&m_subToolOld, &subTool, sizeof(SUBTOOLDATA));

	

	for(int i = 0; i <15; i++)
	{

		m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMinLmPeriod_us = (int)(1000000 / 1000);
		m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMaxLmPeriod_us = (int)(1000000 / 1000);
	
	}

	

	double dMaskDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
	double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subTool.nMask];
	double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subTool.nMask];
	double dPowerDutyOffset = 0;//gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];

	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];

	double dVoltage1 = gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex];
	double dVoltage2 = gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex];

	//double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask];
	//double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask];
	InitShotScale(nTool);

	if(nTool != SCANNER_CAL_TOOL)
	{
		if(nTool == ONE_HOLE_TOOL || nTool == ALIGN_TOOL)
		{
			//nShotIndex = gVariable.m_sgToolTable.nSelectShot[subTool.nMask];//gToolTableINI.m_sToolTable.nSelectShot[subTool.nMask];
			nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];
			dVoltage1 = gVariable.m_sgShotGroupTable.dVoltage_M[nShotIndex];
			dVoltage2 = gVariable.m_sgShotGroupTable.dVoltage_S[nShotIndex];

			subTool.nToolType = gVariable.m_sgShotGroupTable.nToolType[nShotIndex];
			subTool.nCornerDelay = gVariable.m_sgShotGroupTable.nConerDelay[nShotIndex];
			subTool.nJumpDelay = gVariable.m_sgShotGroupTable.nJumpDelay[nShotIndex];
			subTool.nJumpStep = gVariable.m_sgShotGroupTable.nJumpSpeed[nShotIndex];
			subTool.dDrawStep = gVariable.m_sgShotGroupTable.nDrawSpeed[nShotIndex];
			//subTool.nLineDelay = gVariable.m_sgShotGroupTable.nLineDelay[nShotIndex];
			subTool.nLaserOnDelay = gVariable.m_sgShotGroupTable.nLaserOnDelay[nShotIndex];
			subTool.nLaserOffDelay = gVariable.m_sgShotGroupTable.nLaserOffDelay[nShotIndex];

			subTool.nFrequency = gVariable.m_sgShotGroupTable.nShotFrequency[nShotIndex];
			subTool.dShotDuty[0] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.dShotAOMDelay[0] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dAOMWait_M[0];
			subTool.dShotAOMDuty[0] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.bUseAperture = gVariable.m_sgShotGroupTable.bUseAperture[nShotIndex];
			strcpy(subTool.cFilePath,gVariable.m_sgShotGroupTable.strAperturePath[nShotIndex]);
			subTool.nBurstShot = gVariable.m_sgShotGroupTable.nBurstShotCount[nShotIndex];
			subTool.nTotalShot = gVariable.m_sgShotGroupTable.nTotalShotCount[nShotIndex];
			bUseAom = gVariable.m_sgShotGroupTable.bUseAom[nShotIndex];
			bUseAom = FALSE;
			for(int i = 0; i < subTool.nTotalShot; i++)
			{
				if(bUseAom)
				{
					subTool.dShotMaxFreq[i] = gVariable.m_sgShotGroupTable.nShotFrequency[nShotIndex];
					subTool.dShotMinFreq[i] = gVariable.m_sgShotGroupTable.nShotMinFrequency[nShotIndex];

					subTool.dShotDuty[i] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nShotIndex];
					subTool.dShotDutyOffsetM[i] = 0;
				}
				else
				{
					subTool.dShotMaxFreq[i] = gVariable.m_sgShotGroupTable.nShotFrequency[nShotIndex];
					subTool.dShotMinFreq[i] = subTool.dShotMaxFreq[i];
					if(m_nCardNo == 0)
					{
						subTool.dShotDuty[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOnTime_M[i];
					}
					else
					{
						subTool.dShotDuty[i] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOnTime_S[i];
					}
					subTool.dShotDutyOffsetM[i] = 0;//gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i] + gVariable.m_sgShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset2_M[i];
				}
			}
		}
		else
		{
			nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];

			dVoltage1 = gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotIndex];
			dVoltage2 = gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotIndex];

			subTool.nToolType = gShotTableINI.m_sShotGroupTable.nToolType[nShotIndex];
			subTool.nCornerDelay = gShotTableINI.m_sShotGroupTable.nConerDelay[nShotIndex];
			subTool.nJumpDelay = gShotTableINI.m_sShotGroupTable.nJumpDelay[nShotIndex];
			subTool.nJumpStep = gShotTableINI.m_sShotGroupTable.nJumpSpeed[nShotIndex];
			subTool.dDrawStep = gShotTableINI.m_sShotGroupTable.nDrawSpeed[nShotIndex];
			subTool.nLineDelay = gShotTableINI.m_sShotGroupTable.nLineDelay[nShotIndex];
			subTool.nLaserOnDelay = gShotTableINI.m_sShotGroupTable.nLaserOnDelay[nShotIndex];
			subTool.nLaserOffDelay = gShotTableINI.m_sShotGroupTable.nLaserOffDelay[nShotIndex];
			subTool.nFrequency = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
			subTool.dShotDuty[0] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.dShotAOMDelay[0] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dAOMWait_M[0];
			subTool.dShotAOMDuty[0] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

			subTool.bUseAperture = gShotTableINI.m_sShotGroupTable.bUseAperture[nShotIndex];
			strcpy(subTool.cFilePath,gShotTableINI.m_sShotGroupTable.strAperturePath[nShotIndex]);
			subTool.nBurstShot = gShotTableINI.m_sShotGroupTable.nBurstShotCount[nShotIndex];
			subTool.nTotalShot = gShotTableINI.m_sShotGroupTable.nTotalShotCount[nShotIndex];
			subTool.nApertureBurst = 1;
			bUseAom = gShotTableINI.m_sShotGroupTable.bUseAom[nShotIndex];
			bUseAom = FALSE;
			gOPCParam.nSubToolCount = subTool.nTotalShot;

			for(int i = 0; i < subTool.nTotalShot; i++)
			{
				if(bUseAom)
				{
					subTool.dShotMaxFreq[i] = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
					subTool.dShotMinFreq[i] = gShotTableINI.m_sShotGroupTable.nShotMinFrequency[nShotIndex];
					subTool.dShotDuty[i] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];
					subTool.dShotDutyOffsetM[i] = 0;
				}
				else
				{
					subTool.dShotMaxFreq[i] = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
					subTool.dShotMinFreq[i] = subTool.dShotMaxFreq[i];
					if(m_nCardNo == 0)
					{
						subTool.dShotDuty[i] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOnTime_M[i];
						subTool.dShotDutyOffsetM[i] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_M[i] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset2_M[i];
					}
					else
					{
						subTool.dShotDuty[i] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOnTime_S[i];
						subTool.dShotDutyOffsetM[i] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset_S[i] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOntimeOffset2_S[i];
					}
				}

				gOPCParam.dShotDuty[i] = subTool.dShotDuty[i];
				gOPCParam.nShotFreq[i] = (int)subTool.dShotMaxFreq[i];

				if(gProcessINI.m_sProcessSystem.bUseApplyScalToEocard && gProcessINI.m_sProcessSystem.bUseShotScale)
				{
					CDPoint dOffsetM;
					CDPoint dOffsetS;
					dOffsetM.x = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dShotScaleX_um_M[i];
					dOffsetM.y = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dShotScaleX_um_M[i];
					dOffsetS.x = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dShotScaleX_um_S[i];
					dOffsetS.y = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dShotScaleX_um_S[i];

					SetShotScale(nTool , i , dOffsetM , dOffsetS);
				}
			}
		}
	}
	else if( nTool = SCANNER_CAL_TOOL)
	{
		subTool.nJumpStep = (int)gSystemINI.m_sSystemDevice.dJumpSpeed;
	}

	if(bMakeLPCTable)
	{
		dMaskDutyOffset = dMaskAOMDelayOffset = dMaskAOMDutyOffset = dPowerDutyOffset = 0;
	}

	if(subTool.nToolType == MARKING_TYPE)
	{
		Para.DrawStep = (int)subTool.dDrawStep;
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; // Mark default
		Para.StepPeriod = subTool.nJumpStepPeriod;
		Para.CornerDelay = subTool.nCornerDelay;
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);

		Para.dDuty = subTool.dShotDuty[0] + subTool.dShotDutyOffsetM[0];
		Para.FPSDelay = subTool.nFPS;
		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, 2 /* line mode */, 1 /* not use */, EXCEPT_DSP); // marker use only DSP.
	
		int nCavityShotIndex = 0;
		if(gVariable.m_bMarkingCavity == TRUE)
			nCavityShotIndex = gVariable.m_nShotNoForCavity;


		if(bResult) bResult = bResult & SetParameter(&Para,subTool.nMask,subTool.nToolType, 0,  0);
		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);
	
		return bResult;
	}
	else if(subTool.nToolType == SHOT_DRILL_TYPE || subTool.nToolType == BARCODE_TYPE || subTool.nToolType == TEXT_TYPE)
	{
		CString str;
		// Para.DrawStep = subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		// Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = Para.LaserOnDelay; 
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0];
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);

		Para.FPSDelay = subTool.nFPS;
		Para.MinShotTime = gSystemINI.m_sSystemDevice.nMinShotTime;
		Para.CycleTime = gSystemINI.m_sSystemDevice.nMinCycleTime;

		Para.dDuty = subTool.dShotDuty[0];
		if(subTool.bUseAperture)
		subTool.nApertureBurst = 1000000;

		if(gSystemINI.m_sSystemDevice.nShotDrillType == SHOT_DRILL_ORIGIN)
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_ORIGIN_MODE, subTool.nApertureBurst, EXCEPT_DSP); 
		else
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_DIVIDE_MODE, subTool.nApertureBurst, EXCEPT_DSP); 

		if( subTool.nToolType == BARCODE_TYPE && subTool.bBarcodeLineDrill == TRUE)
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, 2 /* line mode */, 1 /* not use */, EXCEPT_DSP); // marker use only DSP.

	    if(bResult) bResult = bResult & SetParameter(&Para,subTool.nMask,subTool.nToolType, 0,  0);
		if(bResult) bResult = bResult & SetMinShotTime(Para.MinShotTime);
		if(bResult) bResult = bResult & SetMinCycleTime(Para.CycleTime * 1000);


			if(!ApertureDataReset(nTool))
		return FALSE;

		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
		}
		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 
												subTool.nBurstShot, 
												subTool.nTotalShot,
												subTool.bUseAperture);
		if(bResult) bResult = bResult & DownloadTCode(DUMMY_TOOL, gSystemINI.m_sSystemDump.nDummyFreq, 
														1, //subTool.nBurstShot, 
														1, //subTool.nTotalShot,
														FALSE);//subTool.bUseAperture );
		for(int i = 0; i < subTool.nTotalShot; i++)
		{

			if(nTool == SCANNER_CAL_TOOL)
			{
				m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMinLmPeriod_us = (int)(1000000 / 1000);
				m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMaxLmPeriod_us = (int)(1000000 / 1000);
			}
			else
			{
				m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMinLmPeriod_us = (int)(1000000 / subTool.dShotMaxFreq[i]);
				m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMaxLmPeriod_us = (int)(1000000 / subTool.dShotMinFreq[i]);
			}

			str.Format(_T("%s"), subTool.cAOMFilePath[i]);
			if(!gSystemINI.m_sHardWare.bFirstOffsetMode)
			{
				if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i],  
					subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
					subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
			}
			else
			{
				if(i == 0)
				{
					if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset,
						subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
						subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
				}
				else
				{
					if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + subTool.dShotDutyOffsetM[i],  
						subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
						subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
				}
			}

			if(bResult) bResult = bResult & DownloadAOMProfile(nTool, i, str, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset, 
																				subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
																				subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset, 
																				dMaskAOMDutyOffset + dPowerDutyOffset, 
																				subTool.dShotDutyOffsetM[i],
																				0, //subTool.dShotDutyOffsetM[i]
																				subTool.dShotVolOffsetM[i] + dVoltage1,
																				subTool.dShotVolOffsetS[i] + dVoltage2,
																				subTool.nMask,
																				0,
																				0);

			if(bSetPowerLevel)
			{
				double dLPCValLow, dLPCValHigh, dMinLPC, dMaxLPC;
				m_CalLPC->GetCalibrationOffset(100, subTool.dShotDuty[i]+ dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]/* + subTool.dShotDutyOffsetS[i]*/, dLPCValLow, dLPCValHigh); // 100�� freq. �� �����ϹǷ� 100 �ܼ� �ϵ��ڵ�
					
				int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];

				dLPCValLow = subTool.dShotLPCMin_M[i];
				dLPCValHigh = subTool.dShotLPCMax_M[i];
					
				if(gVariable.m_bExsitPreLPCTable)//20160821
				{
					dMinLPC = dLPCValLow * gSystemINI.m_sHardWare.dPreLPCMinTolerence;// + 2048;
					dMaxLPC = dLPCValHigh * gSystemINI.m_sHardWare.dPreLPCMaxTolerence * gSystemINI.m_sHardWare.dPreLPCMaxValueOffset;//dLPCVal * (2 - gSystemINI.m_sHardWare.dLPCTolerence);// + 2048;
				}
				else
				{
					dMinLPC = dLPCValLow * gSystemINI.m_sHardWare.dLPCMinTolerence;// + 2048; 
					dMaxLPC = dLPCValHigh * gSystemINI.m_sHardWare.dLPCMaxTolerence;//dLPCVal * (2 - gSystemINI.m_sHardWare.dLPCTolerence);// + 2048;
				}
				if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, dMinLPC, dMaxLPC);

				CString strFile, strLog;
				strFile.Format(_T("DownloadLPCLimit"));
				strLog.Format(_T("ToolNo : %d, ShotNo : %d, MinLimit : %.3f, MaxLimit : %.3f"), nTool, i, dMinLPC, dMaxLPC);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
			else
			{
				if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, 0, 0);//gSystemINI.m_sHardWare.nLPCMinDefault, gSystemINI.m_sHardWare.nLPCMaxDefault);
			}

			if(bResult) bResult = bResult & DownloadDutyAOM(DUMMY_TOOL, i,			gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty);
			if(bResult) bResult = bResult & DownloadAOMProfile(DUMMY_TOOL, i, str,	gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty, 0, 0, 0, dVoltage1, dVoltage2, subTool.nMask,0,0);
			
		}
		if(bResult) bResult = bResult & DownloadStartPowerTolerence(gSystemINI.m_sHardWare.nLPCStartSkipCount, gSystemINI.m_sHardWare.dLPCStartTolerencePercent, gSystemINI.m_sHardWare.dLPCStartTolerencePercent);



	
		if(bResult) bResult = bResult & DownloadDummyFreeInfo();
	
		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
		}
//		str.Format(_T("%s"), subTool.cMoveProfileFilePath);
//		if(bResult) bResult = bResult & DownloadProfileFile(str);

		if( subTool.nToolType == BARCODE_TYPE && subTool.bBarcodeLineDrill == TRUE)
			if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);
		else
			if(bResult) bResult = bResult & SetInpositionCheckINI(TRUE);
		
		return bResult;
	}
	else if(subTool.nToolType == LINE_DRILL_TYPE )
	{
		CString str;
		if(gSystemINI.m_sSystemDevice.nSelfLineDivide)
			Para.DrawStep = (int)subTool.dDrawStep; 
		else
			Para.DrawStep = 65535; // subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);

		Para.dDuty = subTool.dShotDuty[0];

		Para.FPSDelay = subTool.nFPS;
		Para.MinShotTime = gSystemINI.m_sSystemDevice.nMinShotTime;
		Para.CycleTime = gSystemINI.m_sSystemDevice.nMinCycleTime;

		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, UV_LINE_MODE, 1 /* Line drill not use */, EXCEPT_DSP); 
		if(bResult) bResult = bResult & SetParameter(&Para,subTool.nMask,subTool.nToolType, 0,  0);
		if(bResult) bResult = bResult & SetMinShotTime(Para.MinShotTime);
		if(bResult) bResult = bResult & SetMinCycleTime(Para.CycleTime * 1000);

		if(!ApertureDataReset(nTool))
			return FALSE;

		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 1, 1, subTool.bUseAperture ); // Total shot �׻� 1
		
		if(bResult) bResult = bResult & DownloadTCode(DUMMY_TOOL, gSystemINI.m_sSystemDump.nDummyFreq, 
			1, //subTool.nBurstShot, 
			1, //subTool.nTotalShot,
			FALSE);//subTool.bUseAperture );

		for(int i = 0; i < subTool.nTotalShot; i++)
		{


				if(nTool == SCANNER_CAL_TOOL)
				{
					m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMinLmPeriod_us = (int)(1000000 / 1000);
					m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMaxLmPeriod_us = (int)(1000000 / 1000);
				}
				else
				{

					m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMinLmPeriod_us = (int)(1000000 / subTool.dShotMaxFreq[i]);
					m_SubToolConfig[nTool].DrillDummyfreeInfo[i].nMaxLmPeriod_us = (int)(1000000 / subTool.dShotMinFreq[i]);

				}

				str.Format(_T("%s"), subTool.cAOMFilePath[i]);
				if(!gSystemINI.m_sHardWare.bFirstOffsetMode)
				{
					if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i],  
						subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
						subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
				}
				else
				{
					if(i == 0)
					{
						if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset,
							subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
							subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
					}
					else
					{
						if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + subTool.dShotDutyOffsetM[i],  
							subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
							subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]);
					}
				}

				//				if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i] + subTool.dShotDutyOffsetS[i],  
				//																  subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
				//																  subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i] + subTool.dShotDutyOffsetS[i]);
				if(bResult) bResult = bResult & DownloadAOMProfile(nTool, i, str, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset, 
					subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
					subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset, 
					dMaskAOMDutyOffset + dPowerDutyOffset, 
					subTool.dShotDutyOffsetM[i],
					0, //subTool.dShotDutyOffsetM[i]
					subTool.dShotVolOffsetM[i] + dVoltage1,
					subTool.dShotVolOffsetS[i] + dVoltage2,
					subTool.nMask,
					0,
					0);

				if(bSetPowerLevel)
				{
					double dLPCValLow, dLPCValHigh, dMinLPC, dMaxLPC;
					m_CalLPC->GetCalibrationOffset(100, subTool.dShotDuty[i]+ dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i]/* + subTool.dShotDutyOffsetS[i]*/, dLPCValLow, dLPCValHigh); // 100�� freq. �� �����ϹǷ� 100 �ܼ� �ϵ��ڵ�
					if(gVariable.m_bExsitPreLPCTable)//20160821
					{
						dMinLPC = dLPCValLow * gSystemINI.m_sHardWare.dPreLPCMinTolerence;// + 2048;
						dMaxLPC = dLPCValHigh * gSystemINI.m_sHardWare.dPreLPCMaxTolerence * gSystemINI.m_sHardWare.dPreLPCMaxValueOffset;//dLPCVal * (2 - gSystemINI.m_sHardWare.dLPCTolerence);// + 2048;
					}
					else
					{
						dMinLPC = dLPCValLow * gSystemINI.m_sHardWare.dLPCMinTolerence;// + 2048; 
						dMaxLPC = dLPCValHigh * gSystemINI.m_sHardWare.dLPCMaxTolerence;//dLPCVal * (2 - gSystemINI.m_sHardWare.dLPCTolerence);// + 2048;
					}
					if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, dMinLPC, dMaxLPC);

					CString strFile, strLog;
					strFile.Format(_T("DownloadLPCLimit"));
					strLog.Format(_T("ToolNo : %d, ShotNo : %d, MinLimit : %.3f, MaxLimit : %.3f"), nTool, i, dMinLPC, dMaxLPC);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
				else
				{
					if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, 0, 0);//gSystemINI.m_sHardWare.nLPCMinDefault, gSystemINI.m_sHardWare.nLPCMaxDefault);
				}

				if(bResult) bResult = bResult & DownloadDutyAOM(DUMMY_TOOL, i,			gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty);
				if(bResult) bResult = bResult & DownloadAOMProfile(DUMMY_TOOL, i, str,	gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty, 0, 0, 0, dVoltage1, dVoltage2, subTool.nMask,0,0);
			
		}
		if(bResult) bResult = bResult & DownloadStartPowerTolerence(gSystemINI.m_sHardWare.nLPCStartSkipCount, gSystemINI.m_sHardWare.dLPCStartTolerencePercent, gSystemINI.m_sHardWare.dLPCStartTolerencePercent);


		if(bResult) bResult = bResult & DownloadDummyFreeInfo();


		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
		}

		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);

		return bResult;
	}
	else if(subTool.nToolType == FLYING_TYPE)
	{
		Para.LaserOnDelay = 0;
		Para.LaserOffDelay = 0;
		Para.FPSDelay = subTool.nFPS;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);

			Para.dDuty = subTool.dShotDuty[0];// * 100 + dMaskDutyOffset * 100 + (dPowerDutyOffset * 100.0); // unit 0.01% (0 index ���)

		bResult = TRUE; 
		if(bResult) bResult = bResult & SetParameter(&Para,subTool.nMask,subTool.nToolType, 0,  0);

		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);
		
		return bResult;
	}
	else
		return FALSE;

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadOneAperture(CString str, int nToolNo)
{
	//if(!m_pDriver) 
		//return TRUE;//20170926


		if(!ApertureDataReset(nToolNo))
			return FALSE;
		m_MarkingData.RemoveAll();
		MARKING_DATA markingData;
	
		char szBuf[256];
		CString strRead;
		strRead.Format(_T(""));
		CString strXPos, strYPos;
		strXPos.Format(_T("")); strYPos.Format(_T(""));
		int nchar = 0;
	
		CString strPath;
		strPath.Format("%s\%s",gEasyDrillerINI.m_clsDirPath.GetApertureDir(),str);


		FILE* fp;
		errno_t err;
		err = fopen_s(&fp, strPath, _T("r"));
		if(err != NULL)
		{
			return FALSE;
		}

		m_PtnInfo.nPtnDotCnt[nToolNo] = 0;
	
		while(!feof(fp))
		{
		
			fgets(szBuf, 255, fp);
			strRead = (CString) szBuf;
			strRead.TrimLeft();
			strRead.TrimRight();
			if(strRead.GetAt(0) == _T('P') && strRead.GetAt(2) == _T(';'))
			{
				if(strRead.GetAt(1) == _T('D') || strRead.GetAt(1) == _T('U') || strRead.GetAt(1) == _T('M') || strRead.GetAt(1) == _T('L'))
				{
					if(strRead.Find(_T(',')) == -1)
					{
						break;
					}
					else
					{
						for(nchar = 3; nchar < strRead.Find(_T(',')); ++nchar)
							strXPos += strRead.GetAt(nchar);
						for(nchar = strRead.Find(_T(','))+1; nchar < strRead.GetLength()-1; ++nchar)
							strYPos += strRead.GetAt(nchar);
					
						if(strRead.GetAt(1) == _T('D'))
							markingData.nAction = MICRO_STEP_DRAW;//ONE_STEP_DRAW;//MARK_DRAW;
						else if(strRead.GetAt(1) == _T('M'))
							markingData.nAction = MICRO_STEP_DRAW;//MARK_DRAW;
						else if(strRead.GetAt(1) == _T('L'))
							markingData.nAction = MICRO_STEP_JUMP;//ONE_STEP_JUMP;//_DRAW;
						else
							markingData.nAction = MICRO_STEP_JUMP ; // MARK_JUMP;
						markingData.nPoint.x = (int) (atof(strXPos) * 10);// ���� vm // 65535 / (gSystemINI.m_sSystemDevice.dFieldSize.x*1000));
						markingData.nPoint.y = (int) (atof(strYPos) * 10);// ���� vm //  65535 / (gSystemINI.m_sSystemDevice.dFieldSize.y*1000));	
						m_MarkingData.Add(markingData);

						m_PtnInfo.PtnDot[m_PtnInfo.nPtnDotCnt[nToolNo]].dx = markingData.nPoint.x;  //20130613
						m_PtnInfo.PtnDot[m_PtnInfo.nPtnDotCnt[nToolNo]].dy = markingData.nPoint.y;
						m_PtnInfo.PtnDot[m_PtnInfo.nPtnDotCnt[nToolNo]].eMoveCmd = (EDrillMoveCmd)markingData.nAction;
						m_PtnInfo.nPtnDotCnt[nToolNo]++;
	//					if(!DownloadAperture(nTool, markingData.nPoint.x, markingData.nPoint.y, markingData.nAction))
	//					{
	//						ApertureDataReset(nTool);
	//						fclose(fp);
	//						return FALSE;
	//					}
						strXPos.Format(_T(""));
						strYPos.Format(_T(""));							
					}						 
				}			
			}
		}
		if(!DownloadAperture(nToolNo, 0, 0, 0))
		{
			ApertureDataReset(nToolNo);
			fclose(fp);
			return FALSE;
		}
		fclose(fp);


	
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadShotDrillScannerParam(int nJumpDelayPlus)// nJumpDelay 1 = 1 X Draw step Period
{


	if(nJumpDelayPlus == 0)
		m_TDrillParam.nTimeAfterInpos = gSystemINI.m_sSystemDevice.nJumpDelayShot;
	else
		m_TDrillParam.nTimeAfterInpos = nJumpDelayPlus;

		if(gVariable.m_bDoingPreHeat )
	     m_TDrillParam.nTimeAfterInpos = gProcessINI.m_sProcessCal.nAutoRunPreheatJumpDelay;


		m_TDrillParam.nScannerPreMoveTime_us = gSystemINI.m_sSystemDevice.nPreMove;


		if(!m_pDriver) 
			return TRUE;
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1DualbandNew::SetFunction(USHORT Value)
{
	m_usFunction = Value;

	if(!m_pDriver) 
		return TRUE;
	
	unsigned char ucValue = static_cast<unsigned char>(Value);

	m_pDriver->BoardIO_WriteOut(EETSx_WriteOut_INOUT_LaserPower_IF, Value, TRUE);
	
	return TRUE;
}

USHORT HEocard5Pusan1DualbandNew::GetFunction()
{
	return (m_usFunction);
}

BOOL HEocard5Pusan1DualbandNew::GetStatus(WORD *pStat) const
{
	if(!m_pDriver)
		return TRUE;

	int nVal;
	m_pDriver->BoardIO_ReadIn(EETSx_ReadIn_Laser_IF, &nVal);
//	WORD nVal = m_pDriver->ReadInLif(); // 1bit : chiller error feedback, 3bit : shutter status
//	int nReturn = 0;
//	nReturn = (nVal & 0x04) << 2;
//	nReturn = nReturn | ((nVal & 0x01) << 6);
//	*pStat = nReturn; //  ���� 0bit �� 3bit�� �ͼ� ȣȯ�� ���� ����
	*pStat = nVal;
	return TRUE; 
}



BOOL HEocard5Pusan1DualbandNew::SetQuantaParam(int nFPK, int nCurrent)
{
	// ??
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::FlyingModeEnable(BOOL bEnable)
{
	// ??
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::StatusOK(int nStatus)
{
//	return TRUE;
#ifndef __TEST__
	TRunStatus dData; 
	
	if(nStatus == QUEUEFULL || nStatus == BUSY) // wait until QueueFull or Busy is unlocked
	{
		if(nStatus == QUEUEFULL)
			return FALSE;

		m_pDriver->List_GetRunStatus(&dData);

		while (!dData.bit.Busy) // readStatus() : running --> return 1
		{
			Sleep(0);
			m_pDriver->List_GetRunStatus(&dData);
		}
	}
	else
	{
		m_pDriver->List_GetRunStatus(&dData);

		while ( dData.bit.Busy) // wait until Idle
		{
			Sleep(0);
			m_pDriver->List_GetRunStatus(&dData);
		}
	}
#endif
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::FieldPreStart(int nShotNo)
{
	if(!m_pDriver)
		return TRUE;

//	m_TDrillParam.nMinDummyShotCnt = nShotNo;
//	m_TDrillParam.nDummyShotInterval = gSystemINI.m_sSystemDump.nDummyInterval / 20 * 20; 
	BOOL bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);

	if(!bResult)
		return FALSE;

	TDrillPara Para;

	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
	{
		bResult = m_pDriver->Drill_GetPara(&Para);
		if(!bResult)
			return FALSE;
	}

	int nRetry = 0;

	BOOL bVal = TRUE;
	if(m_nDownHoleCount > 0)
	{
		bResult = m_pDriver->Drill_AddHoleData(m_nDownHoleCount, m_ptData);
		if(!bResult)
			return FALSE;

/*		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			while(nRetry <= 3)
			{
				bResult = m_pDriver->Drill_GetPara(&Para2);
				if(bResult)
				{
					if((Para2.nHoleCount - Para.nHoleCount) == (UINT)m_nDownHoleCount)
						break;
				}
				::Sleep(1);
				nRetry++;
			}
			if(nRetry > 3)
				return FALSE;

			bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
			if(!bResult)
				return FALSE;
			bResult = IsSameHoleData(HoleData100, m_nDownHoleCount);
		}
*/		m_nDownHoleCount = 0;

//		return bResult;
	}

	m_nSameShotPrestartCount++;
	nRetry = 0;
	while(TRUE)
	{
		::Sleep(10);// wait for down complete
		int nCount = ReadHoleCount();
		if(nCount == m_nBackupCount)
			return m_pDriver->Drill_PreStart();

		nRetry++;
		if(nRetry >= 3)
			break;

//		ReDownloadHole();	

	}
	return FALSE;
}

BOOL HEocard5Pusan1DualbandNew::ReDownloadHole()
{
	int nCount = 0, nDownTotal = m_nBackupCount;

	TDrillPara Para;
	BOOL bResult;
	int nRetry = 0;

	m_pDriver->Drill_ResetHole();

	int nOnceDownCount = gSystemINI.m_sSystemDevice.nEocardDownCount;
	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		nOnceDownCount = 100;

	int nIndex;
	for(int i = 0; i < nDownTotal; i++)
	{
		nIndex = m_nBackUpIndex * DOWNLOAD_MAX_HOLE + i;
		m_ptData[nCount].nToolNum = m_pBackUpData[nIndex].nToolNum;
		m_ptData[nCount].HolePos[0].x = m_pBackUpData[nIndex].HolePos[0].x;
		m_ptData[nCount].HolePos[0].y = m_pBackUpData[nIndex].HolePos[0].y;
		m_ptData[nCount].HolePos[1].x = m_pBackUpData[nIndex].HolePos[1].x;
		m_ptData[nCount].HolePos[1].y = m_pBackUpData[nIndex].HolePos[1].y;
		m_ptData[nCount].HolePos[2].x = 0;
		m_ptData[nCount].HolePos[2].y = 0;
		m_ptData[nCount].HolePos[3].x = 0;
		m_ptData[nCount].HolePos[3].y = 0;

		m_ptData[nCount].nUseAngle = 0;
		m_ptData[nCount].fSine = 0;
		m_ptData[nCount++].fCosine = 1;


		TDrillPara Para;
//		TDrillHoleData HoleData100[100];
		BOOL bResult;
		int nRetry = 0;

		if(m_nDownHoleCount == nOnceDownCount) // 100�� ������ downloading
		{
			nCount = 0;
			if(gSystemINI.m_sSystemDevice.bCheckHoleData)
			{
				bResult = m_pDriver->Drill_GetPara(&Para);
				if(!bResult)
					return FALSE;
			}

			bResult = m_pDriver->Drill_AddHoleData(nOnceDownCount, m_ptData);
			if(!bResult)
				return FALSE;

/*			if(gSystemINI.m_sSystemDevice.bCheckHoleData)
			{
				while(nRetry <= 3)
				{
					bResult = m_pDriver->Drill_GetPara(&Para2);
					if(bResult)
					{
						if((Para2.nHoleCount - Para.nHoleCount) == (UINT)nOnceDownCount)
							break;
					}
					::Sleep(1);
					nRetry++;
				}
				if(nRetry > 3)
					return FALSE;

				bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
				if(!bResult)
					return FALSE;
				if(!IsSameHoleData(HoleData100, nOnceDownCount))
					return FALSE;
			}
*/		}
	}
	
	if(nCount > 0) 
	{
		nRetry = 0;
		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			bResult = m_pDriver->Drill_GetPara(&Para);
			if(!bResult)
				return FALSE;
		}

		bResult = m_pDriver->Drill_AddHoleData(nCount, m_ptData);
		if(!bResult)
			return FALSE;

/*		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			while(nRetry <= 3)
			{
				bResult = m_pDriver->Drill_GetPara(&Para2);
				if(bResult)
				{
					if((Para2.nHoleCount - Para.nHoleCount) == (UINT)nCount)
						break;
				}
				::Sleep(1);
				nRetry++;
			}
			if(nRetry > 3)
				return FALSE;

			bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
			if(!bResult)
				return FALSE;
			bResult = IsSameHoleData(HoleData100, nCount);
		}
*/		nCount = 0;
		return bResult;
	}
	else
		return TRUE;
}

void HEocard5Pusan1DualbandNew::ResetCO2Laser()
{
	m_cCO2Laser = 0xFF;
	SetFunction(m_cCO2Laser);
}

void HEocard5Pusan1DualbandNew::ReloadDevice()
{
	if(!m_pDriver)
		return;


	m_pDriver->PortClose();

	m_pDriver = new CETSx_API();
	BOOL bOpen = m_pDriver->PortOpen(0); // 0 index card loading

	if(!bOpen)
	{
		ErrMessage(_T("Eocard Port Open Error"), MB_OK);
		delete m_pDriver;
		m_pDriver = NULL;
		return;
	}

	//---------

	m_UsedBeam.v = 0;

	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST)
		m_UsedBeam.bit.beam1 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND)
		m_UsedBeam.bit.beam2 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_3RD)
		m_UsedBeam.bit.beam3 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_4TH)
		m_UsedBeam.bit.beam4 = TRUE;
	
	m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	m_pDriver->Drill_SetParaAll(&m_TDrillParam);


	m_TAomParam.bUse_DualBand = gSystemINI.m_sHardWare.nUseDualBand;

	m_TAomParam.bUse_FirstOrderBeam = TRUE;
	m_pDriver->Drill_SetAomPara(&m_TAomParam);

	//---------
	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
		OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}

	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}


	EChannelCfg dach[MAX_DA_CHANNEL] = {
		OUT_AnalogFps, OUT_RfOffLevel, OUT_LaserPower, OUT_Da1
	};
	
	CScanParaCmd Sp; 
//	CScanParaAux SpAux;
//	TLaserPara Lp;
	Sp.Init();
	Sp.fFieldSize_mm = (int)gSystemINI.m_sSystemDevice.dFieldSize.x;

	TLaserType lasertype;	
	lasertype.v = 0;
//	lasertype.bit.Ipg = 0;

	lasertype.bit.StandbyPulse = 0;

	lasertype.bit.Analog_FPS = 0;

//	m_pDriver->SetLaserType(lasertype);
#ifndef __NO_USE_INIT_LASER_IF__
	m_pDriver->LaserCtrl_SetEnableIO(FALSE);
#endif
	m_pDriver->BoardIO_SetTopBoard(1);						// Top Board �⺻Type ���� User Mode�� ���

	// Hsif0�� 1�� �ϵ���� �������� �ܶ��Ǿ��ִ�.
	// 0�� 1�� ������ ��ȣ.
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 0, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 1, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 2, SIG_AOM, 0);

	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 0, SIG_FPS, FALSE);
	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 1, SIG_LM, FALSE);

	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 0, SIG_LOAD_DATA0, 0); // laser enable
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 1, SIG_LOAD_DATA1, 0); // shutter open/close
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 2, SIG_LOAD_DATA2, 0); // laser power on/off


//	m_pDriver->SetIOInversion(0, 0);							//0: OutLif
//	m_pDriver->SetIOInversion(1, 4);							//1: InLif
//	m_pDriver->SetIOInversion(2, 0);							//2: OutHif

	m_pDriver->BoardIO_SetPinMux(Pin_IN_Laser_IF, 2, SIG_INPUT, TRUE);
								
//	m_pDriver->ScanCtrl_SetNumOfBeam(2);						
	m_pDriver->ScanCfg_SetNumOfBeam(2);	// 100825
	m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch); //
	m_pDriver->BoardIO_SetChannel(EETSx_DA_Channel, dach);				//�ϵ���� ä�� ����
#ifndef __NO_USE_INIT_LASER_IF__
	SetFunction(65535); // CO2 high : laser power on  (X)
#endif
	m_pDriver->LaserCtrl_SetEnableIO(TRUE);

	BOOL bXReverse, bYReverse, bAxisCange = FALSE;

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(0, bXReverse, bYReverse, 0, TRUE);
	//m_pDriver->ScanCfg_SetAxis(0, bXReverse, bYReverse, 0, TRUE); // 100825

	//---------------------------------------------------------
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(1, bXReverse, bYReverse, 0, TRUE);
	//m_pDriver->ScanCfg_SetAxis(1, bXReverse, bYReverse, 0, TRUE); // 100825

//	m_pDriver->List_ConfigSize(8192,8192);							// ����Ʈ ���� ����
//	m_pDriver->List_SetMode(LISTMODE_Rotary); // m_pDriver->SetListMode(LISTMODE_Rotary); //LISTMODE_Auto_Change);				// ����Ʈ �ڵ� �����Ͽ� ����

	m_pDriver->ScanPara_SetCmdAll(Sp, TRUE);			//��ĳ�� �Ķ���� ����
//	m_pDriver->ScanPara_SetAuxAll(SpAux, TRUE);
//	m_pDriver->LaserPara_SetAll(Lp, TRUE);			//������ �Ķ���� ����
	m_pDriver->Timer_UpdateTime();

	if(!DummyParamSet())
	{
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Dump Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Error : Dummy shot parameter download Failure"));
	}

	if(!StandbyParamSet())
	{
#ifndef __TEST__
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Standby Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Error : Standby shot parameter download Failure"));
#endif
	}

}
//first order
BOOL HEocard5Pusan1DualbandNew::DownloadAOMProfile(int nTool, int nSubTool, CString strPath, double dDuty, double dAOMDelay, double dAOMDuty, double dAOMOffset, double dInserted_WaitOffsetM, double dInserted_WaitOffsetS, double dVolOffsetM, double dVolOffsetS, int nMask, double dOnOffsetM, double dOnOffsetS)
{

	return TRUE; //AOM NO use

	TDrillAomInfo tempAOMInfo;
	double dTotalTime = 0;
#ifndef __TEST__
	if(!m_pDriver) 
		return TRUE;
#endif
	double dOntimeOffsetM[MAX_NUM_OF_AOM_TIME_ITEM];
	double dOntimeOffsetS[MAX_NUM_OF_AOM_TIME_ITEM];
	for(int k =  0; k < MAX_NUM_OF_AOM_TIME_ITEM; k++)
	{
		tempAOMInfo.Aom[0].fAOM_CloseTime_us[k] = 0;
		tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = 0;
		tempAOMInfo.Aom[1].fAOM_CloseTime_us[k] = 0;
		tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = 0;
		dOntimeOffsetM[k] = 0;
		dOntimeOffsetS[k] = 0;
	}

	if(nTool == SCANNER_CAL_TOOL)
	{
		int nShotNo = gBeamPathINI.m_sBeampath.nSelectShot[nMask];

		

		int nMAOM_ModulationNo = 1;
		int nSAOM_ModulationNo = 1;
		tempAOMInfo.Aom[0].fAOM_CloseTime_us[0] = 0;
		tempAOMInfo.Aom[1].fAOM_CloseTime_us[0] = 0;
		
		dOntimeOffsetM[0] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_M[nSubTool] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_M[nSubTool];
		dOntimeOffsetS[0] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_S[nSubTool] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_S[nSubTool];

		for(int k = 0; k < nMAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = gBeamPathINI.m_sBeampath.dScannerDuty[nMask];
				tempAOMInfo.Aom[0].fAOM_CloseTime_us[k+1] = 0;
			}
		}
		for(int k = 0; k < nSAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = gBeamPathINI.m_sBeampath.dScannerDuty[nMask];
				tempAOMInfo.Aom[1].fAOM_CloseTime_us[k+1] = 0;
			}
		}
		//tempAOMInfo.Aom[0].fDA_percent = gBeamPathINI.m_sBeampath.dPowOffsetVoltage1[nMask];
		//tempAOMInfo.Aom[1].fDA_percent = gBeamPathINI.m_sBeampath.dPowOffsetVoltage2[nMask];

		tempAOMInfo.Aom[0].fDA_percent = gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotNo];
		tempAOMInfo.Aom[1].fDA_percent = gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotNo];

		SetVoltage(tempAOMInfo.Aom[0].fDA_percent, tempAOMInfo.Aom[1].fDA_percent);
#ifndef __TEST__
		return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
#endif
	}
	else if(nTool == ONE_HOLE_TOOL || nTool == -1 || nTool == ALIGN_TOOL)
	{

	    int nShotNo = gBeamPathINI.m_sBeampath.nSelectShot[nMask];
		
		if(nTool == -1 && nTool == ALIGN_TOOL)
		{
			//nShotNo =0;
		}
		
		
		int nMAOM_ModulationNo = gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].nAOMNum_M[nSubTool];
		int nSAOM_ModulationNo = gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].nAOMNum_S[nSubTool];

		double dDutyOffsetMaster = 0;//20160615
		double dDutyOffsetSlave = 0;
		double dWaitOffsetM = 0;
		double dWaitOffsetS = 0;
		if(nTool == ONE_HOLE_TOOL || nTool == ALIGN_TOOL)
		{
			 dDutyOffsetMaster = 0;//gVariable.m_sgToolTable.dMasterDutyOffset[nMask];
			 dDutyOffsetSlave = 0;//gVariable.m_sgToolTable.dSlaveDutyOffset[nMask];
			for(int k = 0; k < nMAOM_ModulationNo; k++)
			{
				dOntimeOffsetM[k] = (gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_M[nSubTool] + gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_M[nSubTool])/ nMAOM_ModulationNo;
			}
			for(int k = 0; k < nSAOM_ModulationNo; k++)
			{
				dOntimeOffsetS[k] = (gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_S[nSubTool] + gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_S[nSubTool]) / nSAOM_ModulationNo;
			}
		}
		else
		{
			dWaitOffsetM = dInserted_WaitOffsetM;
			dWaitOffsetS = dInserted_WaitOffsetS;
			for(int k = 0; k < nMAOM_ModulationNo; k++)
			{
				dOntimeOffsetM[k] = dOnOffsetM / nMAOM_ModulationNo;
			}
			for(int k = 0; k < nSAOM_ModulationNo; k++)
			{
				dOntimeOffsetS[k] = dOnOffsetS / nSAOM_ModulationNo;
			}
		}
		/////////

		tempAOMInfo.Aom[0].fAOM_CloseTime_us[0] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dAOMWait_M[nSubTool] + dWaitOffsetM;
		tempAOMInfo.Aom[1].fAOM_CloseTime_us[0] = gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].dAOMWait_S[nSubTool] + dWaitOffsetS;

		

		for(int k = 0; k < nMAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				if(k ==0) //20160615
					tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_M[k] + dDutyOffsetMaster + dOntimeOffsetM[k]);
				else
					tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_M[k] + dOntimeOffsetM[k]);

				tempAOMInfo.Aom[0].fAOM_CloseTime_us[k+1] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_OFF_M[k]);
			}
		}
		for(int k = 0; k < nSAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				if(k ==0) //20160615
					tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_S[k] + dDutyOffsetSlave + dOntimeOffsetS[k]);
				else
					tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_S[k] + dOntimeOffsetS[k]);

				tempAOMInfo.Aom[1].fAOM_CloseTime_us[k+1] = max(0, gVariable.m_sgShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_OFF_S[k]);
			}
		}

	
		tempAOMInfo.Aom[0].fDA_percent = gVariable.m_sgShotGroupTable.dVoltage_M[nShotNo];
		tempAOMInfo.Aom[1].fDA_percent = gVariable.m_sgShotGroupTable.dVoltage_S[nShotNo];

		SetVoltage(tempAOMInfo.Aom[0].fDA_percent, tempAOMInfo.Aom[1].fDA_percent);

		

#ifndef __TEST__
		if(nTool == -1)
		{
			return m_pDriver ->Drill_SetManualAOMInfo(&tempAOMInfo);
		}
		else
		{
			return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
		}
#endif
	}
	else if(nTool == DUMMY_TOOL)
	{
		tempAOMInfo.Aom[0].fDA_percent = gSystemINI.m_sSystemDump.dStandby1stV;
		tempAOMInfo.Aom[1].fDA_percent = gSystemINI.m_sSystemDump.dStandby2ndV;
		tempAOMInfo.Aom[0].fAOM_CloseTime_us[0] = gSystemINI.m_sSystemDump.nDummyAOMDelay;
		tempAOMInfo.Aom[1].fAOM_CloseTime_us[0] = gSystemINI.m_sSystemDump.nDummyAOMDelay;

		for(int i = 0; i < MAX_NUM_OF_AOM_TIME_ITEM; i++)
		{
			tempAOMInfo.Aom[0].fAOM_OpenTime_us[i] = 0;
			tempAOMInfo.Aom[0].fAOM_CloseTime_us[i+1] = 0;
			tempAOMInfo.Aom[1].fAOM_OpenTime_us[i] = 0;
			tempAOMInfo.Aom[1].fAOM_CloseTime_us[i+1] = 0;
		}
#ifndef __TEST__
		return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
#endif
		
	}
	else
	{
		int nShotNo = gBeamPathINI.m_sBeampath.nSelectShot[nMask];
		int nMAOM_ModulationNo = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].nAOMNum_M[nSubTool];
		int nSAOM_ModulationNo = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].nAOMNum_S[nSubTool];

		tempAOMInfo.Aom[0].fAOM_CloseTime_us[0] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dAOMWait_M[nSubTool];
		tempAOMInfo.Aom[1].fAOM_CloseTime_us[0] = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dAOMWait_S[nSubTool];

		double dDutyOffsetMaster = 0;//gToolTableINI.m_sToolTable.dMasterDutyOffset[nMask];//20160615
		double dDutyOffsetSlave = 0;//gToolTableINI.m_sToolTable.dSlaveDutyOffset[nMask];

		for(int k = 0; k < nMAOM_ModulationNo; k++)
		{
			dOntimeOffsetM[k] =	(gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_M[nSubTool] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_M[nSubTool]) / nMAOM_ModulationNo;
		}
		for(int k = 0; k < nSAOM_ModulationNo; k++)
		{
			dOntimeOffsetS[k] = (gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset_S[nSubTool] + gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].dOntimeOffset2_S[nSubTool]) / nSAOM_ModulationNo;
		}

		for(int k = 0; k < nMAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				if(k ==0) //20160615
					tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_M[k] + dDutyOffsetMaster + dOntimeOffsetM[k]);
				else
					tempAOMInfo.Aom[0].fAOM_OpenTime_us[k] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_M[k] + dOntimeOffsetM[k]);


				tempAOMInfo.Aom[0].fAOM_CloseTime_us[k+1] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_OFF_M[k]);
			}
		}
		for(int k = 0; k < nSAOM_ModulationNo; k++)
		{
			if(k < 10)
			{
				if(k ==0) //20160615
				     tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_S[k] + dDutyOffsetSlave + dOntimeOffsetS[k]);
				else
					tempAOMInfo.Aom[1].fAOM_OpenTime_us[k] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_ON_S[k] + dOntimeOffsetS[k]);

				tempAOMInfo.Aom[1].fAOM_CloseTime_us[k+1] = max(0, gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotNo].m_sAOMParam[nSubTool].dAOM_OFF_S[k]);
			}
		}
		tempAOMInfo.Aom[0].fDA_percent = gShotTableINI.m_sShotGroupTable.dVoltage_M[nShotNo];
		tempAOMInfo.Aom[1].fDA_percent = gShotTableINI.m_sShotGroupTable.dVoltage_S[nShotNo];

		if(m_nCardNo == 1)
		{
			tempAOMInfo.Aom[0] = tempAOMInfo.Aom[1];
		}
		SetVoltage(tempAOMInfo.Aom[0].fDA_percent, tempAOMInfo.Aom[1].fDA_percent);
#ifndef __TEST__
		if(nTool == -1)
			return m_pDriver->Drill_SetManualAOMInfo(&tempAOMInfo);
		else
		{
			//return m_pDriver->Drill_SetAOMInfo('k' * 15 + nSubTool, &tempAOMInfo);//20160514
			return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
		}
#endif
	}
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::IsFireCntOK(int& nDownCnt, int& nReadCnt)
{
	if(!m_pDriver)
		return FALSE;

	int nTotal=0;
	for(int i = 0; i < 64; i++)
	{
		if(m_SubToolConfig[i].nUsedPtnId != -1)
			nTotal += (m_PtnInfo.nPtnDotCnt[i] * m_SubToolConfig[i].nDotTotalShotCnt * m_nHoleCnt[i]);
		else
			nTotal += (m_SubToolConfig[i].nDotTotalShotCnt * m_nHoleCnt[i]);
	}

	nDownCnt = nTotal;
	nReadCnt = -1;

	TDrillMonitor Para; 
	if(!m_pDriver->Drill_GetMonitor(&Para))
	{
		::Sleep(10);
		if(!m_pDriver->Drill_GetMonitor(&Para))
			return FALSE; // false
	}


	nReadCnt = Para.nFiredLaserShotCnt_Req;

	if(Para.nFiredLaserShotCnt_Req != (UINT)nTotal)
		return FALSE;
	else
		return TRUE;


}


BOOL HEocard5Pusan1DualbandNew::DummyFieldStart(int nShotNo, BOOL bDryRun)
{
	if(!m_pDriver)
		return TRUE;
//	m_TDrillParam.nMinDummyShotCnt = nShotNo;
//	m_TDrillParam.nDummyShotInterval = gSystemINI.m_sSystemDevice.nDummyInterval/20; // 1 --> 20us
//	BOOL bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);
	return TRUE;
//	return m_pDriver->Drill_DummyShot_Start(bDryRun);//, &m_DummyPos);
}

BOOL HEocard5Pusan1DualbandNew::DummyStopAndDataShotStart(BOOL bDryRun)
{
if(!m_pDriver)
		return TRUE;
	
	if(!bDryRun)
	{
		if(!m_pDriver->Drill_ClearLPCData())
			return FALSE;
		if(!m_pDriver->Lpc_SetEnable(gSystemINI.m_sHardWare.bUseLPC/*gProcessINI.m_sProcessOption.bCheckLPCError*/))
			return FALSE;
	}

//	if(IsDrillTimeOut())
//	{
//		EStop();
//		return FALSE;
//	}
//	if(IsMotorFault())
//	{
//		EStop();
//		return FALSE;
//	}
	BOOL bScannerCableError = IsScannerCableError();
	BOOL bScannerMotorFault = IsMotorFault();
	BOOL bScannerDrillTimeOut = IsDrillTimeOut();
	CString strErrorMsg = _T("");
	if(bScannerCableError)
	{
		EStop();
		ErrMessage(_T("Check scanner cable."));
		return FALSE;
	}
	else if(bScannerMotorFault)
	{
		if(bScannerMotorFault & 0x01)
			strErrorMsg += _T("Scanner Master X Motor Fault\n");
		if(bScannerMotorFault & 0x02)
			strErrorMsg += _T("Scanner Master Y Motor Fault\n");
		if(bScannerMotorFault & 0x04)
			strErrorMsg += _T("Scanner Slave X Motor Fault\n");
		if(bScannerMotorFault & 0x08)
			strErrorMsg += _T("Scanner Slave Y Motor Fault\n");

		EStop();
		ErrMessage(strErrorMsg);
		return FALSE;
	}
	else if(bScannerDrillTimeOut)
	{
		if(bScannerDrillTimeOut & 0x01)
			strErrorMsg += _T("Scanner Master X Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x02)
			strErrorMsg += _T("Scanner Master Y Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x04)
			strErrorMsg += _T("Scanner Slave X Drill Time Out\n");
		if(bScannerDrillTimeOut & 0x08)
			strErrorMsg += _T("Scanner Slave Y Drill Time Out\n");

		EStop();
		ErrMessage(strErrorMsg);
		return FALSE;
	}
	return m_pDriver->Drill_Start(bDryRun);
}

BOOL HEocard5Pusan1DualbandNew::DummyParamSet(BOOL bPowervia)
{


	if(!m_pDriver)
		return TRUE;

	BOOL bResult = FALSE;

	m_DummyPos.Pos[0].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	m_DummyPos.Pos[0].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	m_DummyPos.Pos[1].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	m_DummyPos.Pos[1].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.y);
	m_DummyPos.Pos[2].x = 0;
	m_DummyPos.Pos[2].y = 0;
	m_DummyPos.Pos[3].x = 0;
	m_DummyPos.Pos[3].y = 0;

	return TRUE;

/*	bResult = m_pDriver->Drill_DummyShot_SetPara(&m_DummyPos, 
										(int)(gSystemINI.m_sSystemDump.nDummyInterval/20*20),
										gSystemINI.m_sSystemDump.nDummyShot, 
										gSystemINI.m_sSystemDump.nDummyDuty);

	if(!bResult) 
		return FALSE;

	::Sleep(100);

	TDrillDummyShotPara tempPara;
	bResult = m_pDriver->Drill_GetDummyShotPara(&tempPara);

	if(!bResult) 
		return FALSE;

	if(tempPara.DummyShotData.Pos[0].x != m_DummyPos.Pos[0].x ||
		tempPara.DummyShotData.Pos[0].y != m_DummyPos.Pos[0].y ||
		tempPara.DummyShotData.Pos[1].x != m_DummyPos.Pos[1].x ||
		tempPara.DummyShotData.Pos[1].y != m_DummyPos.Pos[1].y ||
		(int)(gSystemINI.m_sSystemDump.nDummyInterval/20*20) != tempPara.nDummyShotInterval ||
		(UINT)gSystemINI.m_sSystemDump.nDummyDuty != tempPara.nDummyShotDuty_us ||
		(UINT)gSystemINI.m_sSystemDump.nDummyShot != tempPara.nMinDummyShotCnt)
		return FALSE;

	CString strFile, strLog;
	strFile.Format(_T("ReadHole"));

	strLog.Format(_T("Dump1 (%d, %d), Dump2 (%d, %d), DummyShot (%d), Frequency (%d), Interval (%d), Duty (%d), AOMDelay (%d), AOMDuty (%d) "), 
			gSystemINI.m_sSystemDump.nPtBeanDumper1.x,
			gSystemINI.m_sSystemDump.nPtBeanDumper1.y,
			gSystemINI.m_sSystemDump.nPtBeanDumper2.x,
			gSystemINI.m_sSystemDump.nPtBeanDumper2.y,
			gSystemINI.m_sSystemDump.nDummyShot,
			gSystemINI.m_sSystemDump.nDummyFreq,
			gSystemINI.m_sSystemDump.nDummyInterval,
			gSystemINI.m_sSystemDump.nDummyDuty,
			gSystemINI.m_sSystemDump.nDummyAOMDelay,
			gSystemINI.m_sSystemDump.nDummyAOMDuty);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


	return TRUE;
*/
}

BOOL HEocard5Pusan1DualbandNew::IsSameHoleData(TDrillHoleData* DrillHoleData, int nCount)
{
	for(int i = 0; i < nCount; i++)
	{
		if(m_ptData[i].nToolNum != DrillHoleData[i].nToolNum)
			return FALSE;
		if(m_ptData[i].HolePos[0].x != DrillHoleData[i].HolePos[0].x)
			return FALSE;
		if(m_ptData[i].HolePos[0].y != DrillHoleData[i].HolePos[0].y)
			return FALSE;
		if(m_ptData[i].HolePos[1].x != DrillHoleData[i].HolePos[1].x)
			return FALSE;
		if(m_ptData[i].HolePos[1].y != DrillHoleData[i].HolePos[1].y)
			return FALSE;
	}
	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SetInpositionCheckINI(BOOL bUseFile)
{

	return TRUE;

	if(!m_pDriver)
		return TRUE;

	m_UsedBeam.v = 0;
	m_UsedBeam.bit.beam1 = FALSE;
	m_UsedBeam.bit.beam2 = FALSE;
	m_UsedBeam.bit.beam3 = FALSE;
	m_UsedBeam.bit.beam4 = FALSE;

	if(bUseFile)
	{
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST)
			m_UsedBeam.bit.beam1 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND)
			m_UsedBeam.bit.beam2 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_3RD)
			m_UsedBeam.bit.beam3 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_4TH)
			m_UsedBeam.bit.beam4 = TRUE;
	}
		

	return m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::StandbyParamSet()
{

	if(!m_pDriver)
		return TRUE;
	
	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
	{
//		m_TDrillParam.nMinLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMaxFreq;		// shot�� �ּ� �ֱ�.	// 2011-09-28
//		m_TDrillParam.nMaxLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMinFreq;		// shot�� �ִ� �ֱ�.
		m_TDrillParam.nStandbyLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyInterval;	// standby ���¿��� LM period, �Ϲ������� nStandbyLmPeriod_us = (nMinLmPeriod_us + nMaxLmPeriod_us)/2
		m_TDrillParam.nStandbyLmOntime_us = gSystemINI.m_sSystemDump.nStandbyDuty;	// standby ���¿��� LM ontime
		m_TDrillParam.nError_EstInposTime_us = gSystemINI.m_sSystemDump.nStandbyInpositionTime;
	}
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
	{
//		m_TDrillParam.nMinLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMaxFreq2;		// shot�� �ּ� �ֱ�.	// 2011-09-28
//		m_TDrillParam.nMaxLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMinFreq2;		// shot�� �ִ� �ֱ�.
		m_TDrillParam.nStandbyLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyInterval2;	// standby ���¿��� LM period, �Ϲ������� nStandbyLmPeriod_us = (nMinLmPeriod_us + nMaxLmPeriod_us)/2
		m_TDrillParam.nStandbyLmOntime_us = gSystemINI.m_sSystemDump.nStandbyDuty2;	// standby ���¿��� LM ontime
		m_TDrillParam.nError_EstInposTime_us = gSystemINI.m_sSystemDump.nStandbyInpositionTime2;
	}

	m_TDrillParam.DumperPos.Pos[0].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	m_TDrillParam.DumperPos.Pos[0].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	m_TDrillParam.DumperPos.Pos[1].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	m_TDrillParam.DumperPos.Pos[1].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.y);

	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}



BOOL HEocard5Pusan1DualbandNew::StandbyParamSetNew(int nMask)
{

	if(!m_pDriver)
		return TRUE;


	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nMask];
	BOOL bUseAom = gShotTableINI.m_sShotGroupTable.bUseAom[nShotIndex];
	bUseAom = FALSE;

	int nFrq = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
	double dDuty = 0;


	if(bUseAom)
		dDuty = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];
	else
		dDuty = gShotTableINI.m_sShotGroupTable.m_sShotParam[nShotIndex].dOnTime_M[0];


	m_TDrillParam.nStandbyLmPeriod_us = 1000000 / nFrq;	// standby ���¿��� LM period, �Ϲ������� nStandbyLmPeriod_us = (nMinLmPeriod_us + nMaxLmPeriod_us)/2
	m_TDrillParam.nStandbyLmOntime_us = (int)dDuty;	// standby ���¿��� LM ontime
	m_TDrillParam.nError_EstInposTime_us = gSystemINI.m_sSystemDump.nStandbyInpositionTime;

	m_TDrillParam.DumperPos.Pos[0].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	m_TDrillParam.DumperPos.Pos[0].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	m_TDrillParam.DumperPos.Pos[1].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	m_TDrillParam.DumperPos.Pos[1].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.y);

	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1DualbandNew::DrillStandbyShotStart(BOOL bStart, BOOL bUserStop)
{
	
	if(gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
		bStart = FALSE;

	if(gVariable.m_bMarkingCavity == TRUE)
	{
		bStart = FALSE;
	}
	m_bStandbyShotRun = bStart;

	if(!m_pDriver)
		return TRUE;

//	if(gSystemINI.m_sSystemDump.nStandbyTime == 0)
//		return TRUE;
	
	BOOL bResult = TRUE;


	if(bStart)
	{
		if(gVariable.m_nGlobalDummyType == DUMMY_3RD_ALL)
		{

			bResult =  m_pDriver->Drill_SetStandbyDummyShotMode(TRUE);
			if(bResult)
			{
				bResult = DrillStandbyShotStartHole(TRUE);
			}
		}

		else if(gVariable.m_nGlobalDummyType == DUMMY_3RD_FIELD)
		{
			bResult =  m_pDriver->Drill_SetStandbyDummyShotMode(TRUE);
			bResult =  DrillStandbyShotStartHole(FALSE);
		}
	}
	else
	{
		bResult =  m_pDriver->Drill_SetStandbyDummyShotMode(FALSE);
		bResult = DrillStandbyShotStartHole(FALSE);
	}





    if(!bStart)
	{
		if(!gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
		{
			if(gVariable.m_bMarkingCavity == false)
			{
				bResult = bResult & m_pDriver->Cal_SetEnableEach(0, FALSE);
				bResult = bResult & m_pDriver->Cal_SetEnableEach(1, FALSE);
			}
		}
		//if(bUserStop)
			m_StandbyTime.Finish();
	}
	else
	{
		//if(bUserStop)
			m_StandbyTime.StartTime();
	}
	
	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("DrillStandbyShotStart : %d, Return %d"), bStart, bResult);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	return bResult;

	return TRUE;
}
BOOL HEocard5Pusan1DualbandNew::DrillStandbyShotStartHole(BOOL bStart)
{

	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_SetHole2HoleDummyShotMode(bStart);

}
int HEocard5Pusan1DualbandNew::IsStannbyShotRun()
{
	if(!m_pDriver)
		return m_bStandbyShotRun;

	if(gVariable.m_nGlobalDummyType == DUMMY_3RD_NO_USE)
	{
		return m_bStandbyShotRun;
	}

	BOOL bResult = m_pDriver->Drill_GetDummyShotMode(&m_TDummyMode);

	m_bUse_StandbyDummyShot_Old = m_TDummyMode.bUse_StandbyDummyShot;
	m_bUse_Hole2HoleDummyShot_Old = m_TDummyMode.bUse_Hole2HoleDummyShot;

		return m_TDummyMode.bUse_StandbyDummyShot + (m_TDummyMode.bUse_Hole2HoleDummyShot<<1 & 0x02);


	return TRUE;
}



BOOL HEocard5Pusan1DualbandNew::IsSameDumyStatus()
{
	if(!m_pDriver)
		return m_bStandbyShotRun;

	BOOL bResult = m_pDriver->Drill_GetDummyShotMode(&m_TDummyMode);


	if(gVariable.m_nGlobalDummyType == DUMMY_3RD_NO_USE)
	{
		return m_bStandbyShotRun;
	}
	else if(gVariable.m_nGlobalDummyType == DUMMY_3RD_FIELD)
	{
		if(m_TDummyMode.bUse_StandbyDummyShot && !m_TDummyMode.bUse_Hole2HoleDummyShot)
			return TRUE;
	}
	else if(gVariable.m_nGlobalDummyType == DUMMY_3RD_ALL)
	{
		if(m_TDummyMode.bUse_StandbyDummyShot && m_TDummyMode.bUse_Hole2HoleDummyShot)
			return TRUE;
	}

	return FALSE;
}


BOOL HEocard5Pusan1DualbandNew::StartMarkDummy()
{

	if(gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
		return TRUE;

	if(gSystemINI.m_sSystemDump.nDummyShot == 0 || !m_pDriver)
		return TRUE;




	if(!gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
	{
		if(!m_pDriver->Cal_SetEnableEach(0, FALSE))
			return FALSE;
		if(!m_pDriver->Cal_SetEnableEach(1, FALSE))
			return FALSE;
	}

	m_dDutyBackup = m_Parameter.dDuty;
	m_dAOMDelayBackup = m_Parameter.dAOMDelay;
	m_dAOMDutyBackup = m_Parameter.dAOMDuty;
	m_usFreqBackup = m_Parameter.Frequency;

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	m_Parameter.Frequency = (unsigned int)(1000000 / gSystemINI.m_sSystemDump.nDummyInterval);
		m_Parameter.dDuty = gSystemINI.m_sSystemDump.nDummyDuty;
	m_Parameter.dAOMDelay = gSystemINI.m_sSystemDump.nDummyAOMDelay;
	m_Parameter.dAOMDuty = gSystemINI.m_sSystemDump.nDummyAOMDuty;

	if(!m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, m_Parameter.Frequency, TRUE))
		return FALSE;
	if(!m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty, TRUE))
		return FALSE;

	//if(!DownloadAOMProfile(-1, -1, str, 0, 0, 0, 0, 0, 0, 0, 0, -1))
		//return FALSE;

	if(!DownloadAOMProfile(DUMMY_TOOL, 0, str, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0))
		return FALSE;

	TArrayPos3D pt3D;
	pt3D.Pos[0].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	pt3D.Pos[0].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	pt3D.Pos[1].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	pt3D.Pos[1].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.y);
	pt3D.Pos[2].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.x);
	pt3D.Pos[2].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper1.y);
	pt3D.Pos[3].x = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.x);
	pt3D.Pos[3].y = GetUmData((USHORT)gSystemINI.m_sSystemDump.nPtBeanDumper2.y);
	
	if(!m_pDriver->ScanCtrl_aJump4B(&pt3D))
		return FALSE;

	// sleep �ʿ�ġ �ʳ�?	// jhsho

	BOOL bBusy = TRUE;
	while(bBusy)
	{
		bBusy = IsDSPBusy();
	}

	if(!m_pDriver->LaserCtrl_LaserOnOff(TRUE))
	{
		m_pDriver->LaserCtrl_LaserOnOff(FALSE);
		return FALSE;
	}

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::EndMarkDummy()
{

	if(gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
		return TRUE;

	if(gSystemINI.m_sSystemDump.nDummyShot == 0)
		return TRUE;


	if(m_pDriver == NULL)
		return TRUE;

	
	if(!m_pDriver->LaserCtrl_LaserOnOff(FALSE))
	{
		::Sleep(100);
		m_pDriver->LaserCtrl_LaserOnOff(FALSE);
		return FALSE;
	}

	if(m_nToolOldNo != -1)
	{
		if(!DownloadOneSubTool(m_nToolOldNo, m_subToolOld))
			return FALSE;
	}
	// laser qu�� ���� busy check�� �����Ǿ� ���� �����ϱ� sleep�� �ִ°� ����?	// jhsho
/*	CString str;
	str.Format(_T("%s"), m_Parameter.cAOMFilePath);
	m_Parameter.Frequency = m_usFreqBackup;
	m_Parameter.dDuty = m_dDutyBackup;
	m_Parameter.dAOMDelay = m_dAOMDelayBackup;
	m_Parameter.dAOMDuty = m_dAOMDutyBackup;

	if(!m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, m_Parameter.Frequency, TRUE))
		return FALSE;
	if(!m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty/100., TRUE))
		return FALSE;

	if(!DownloadAOMProfile(-1, -1, str, 0, 0, 0, m_nAOMDutyOffsetBackup))
		return FALSE;
*/


	TArrayPos3D pt3D;
	pt3D.Pos[0].x = 0;
	pt3D.Pos[0].y = 0;
	pt3D.Pos[1].x = 0;
	pt3D.Pos[1].y = 0;
	pt3D.Pos[2].x = 0;
	pt3D.Pos[2].y = 0;
	pt3D.Pos[3].x = 0;
	pt3D.Pos[3].y = 0;
	
	if(!m_pDriver->ScanCtrl_aJump4B(&pt3D))
		return FALSE;

	BOOL bBusy = TRUE;
	while(bBusy)
	{
		bBusy = IsDSPBusy();
	}

		if(!gProcessINI.m_sProcessSystem.bUseApplyScalToEocard)
		{
	if(!m_pDriver->Cal_SetEnableEach(0, FALSE))
		return FALSE;
	if(!m_pDriver->Cal_SetEnableEach(1, FALSE))
		return FALSE;
		}
/*	CCorrectTime myTime;
	myTime.StartTime();
	while(TRUE)
	{
		double dTime = myTime.PresentTime();
		if(dTime > 0.10)
			break;
	}
*/

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SetParameterCavityDuty(BOOL bShortLine)
{
	if(!m_pDriver)
		return FALSE;
	if(bShortLine)
		return m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty + gSystemINI.m_sHardWare.nShortLineDutyOffset, FALSE);
	else
		return m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty, FALSE);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SubDownloadReset(int nIndex)
{
	if(!m_pDriver)
		return FALSE;
	
	BOOL ret = m_pDriver->List_LoadSubr(nIndex);
	return ret;
}

BOOL HEocard5Pusan1DualbandNew::SubDownloadStop()
{
	if(!m_pDriver)
		return FALSE;
	
	BOOL ret = m_pDriver->List_SubReturn();
	return ret;
}

BOOL HEocard5Pusan1DualbandNew::SubCallStart(int nIndex, BOOL bDryrun)
{
	if(!m_pDriver)
		return FALSE;
	BOOL ret = m_pDriver->LaserCtrl_SetVirtualMode(bDryrun, FALSE);
	if(!ret)
		return FALSE;
	
	ret = m_pDriver->List_SubCall(nIndex);
	return ret;
}

double HEocard5Pusan1DualbandNew::GetDummyFreeStart()
{
	if(!IsStannbyShotRun())
		return 0;
	return m_StandbyTime.PresentTime();
}

BOOL HEocard5Pusan1DualbandNew::SetApplyCalibrationFile(int nBeam, BOOL bOn)
{	
	if(!m_pDriver) // dummy free�� ���� �۵� �ȵ�.
		return TRUE;
	//bOn = TRUE;
	gVariable.m_bApplyScalFlag = bOn;

//	if(GetApplyCalibrationFile(nBeam) == bOn)
	//	return TRUE;

	if(!bOn)
	{
		int a = 0;
	}


	BOOL bRet =  m_pDriver->Cal_SetEnableEach(nBeam, bOn);

	return bRet;

}	

BOOL HEocard5Pusan1DualbandNew::GetApplyCalibrationFile(int nBeam)
{
	if(!m_pDriver)
		return TRUE;

	UINT pBeam[4] = {0,};


	m_pDriver->Cal_GetCalBeam(pBeam);

	return pBeam[nBeam];

}

BOOL HEocard5Pusan1DualbandNew::SetVoltage(double d1st, double d2nd)
{


	if(!m_pDriver)
		return TRUE;
	
	if(d1st > 100.)
		d1st = 100.;
	else if(d1st < 0)
		d1st = 0;
	
	if(d2nd > 100.)
		d2nd = 100.;
	else if(d2nd < 0)
		d2nd = 0;
	

	BOOL bResult;
	bResult = m_pDriver->BoardDA_WriteOut(EETSx_WriteOut_DA2, d2nd);
	bResult = bResult & m_pDriver->BoardDA_WriteOut(EETSx_WriteOut_DA1, d1st);
	Sleep(10);

	return TRUE;;
}

BOOL HEocard5Pusan1DualbandNew::ChangeScannerAxis()
{
	if(!m_pDriver)
		return TRUE;
	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
			OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};
	
	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}
	
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}
	

	return m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch);

	return TRUE;
}

int HEocard5Pusan1DualbandNew::GetUmData(USHORT usLSB)
{
	return (int)( usLSB * (gSystemINI.m_sSystemDevice.dFieldSize.x * 10000)/FIELD_LSB - gSystemINI.m_sSystemDevice.dFieldSize.x * 5000);
}
int HEocard5Pusan1DualbandNew::GetUmData_New(double dLSB)
{

	double dReturn = dLSB * (gSystemINI.m_sSystemDevice.dFieldSize.x * 10000.)/FIELD_LSB - gSystemINI.m_sSystemDevice.dFieldSize.x * 5000.;
	int nReturn = (int)dReturn;
	return nReturn;
}
BOOL HEocard5Pusan1DualbandNew::SetMasterSlave(BOOL bMaster)
{
	if(!m_pDriver)
		return TRUE;


	if(bMaster)
		m_TAomParam.nSel_Band0Band1 = 0;
	else
		m_TAomParam.nSel_Band0Band1 = 1;
	return m_pDriver->Drill_SetAomPara(&m_TAomParam);

	return FALSE;
}

BOOL HEocard5Pusan1DualbandNew::SetFieldSizeToEocard()
{
	if(!m_pDriver)
		return TRUE;
	

	return m_pDriver->ScanPara_SetEach(EETSx_FieldSize_mm, gSystemINI.m_sSystemDevice.dFieldSize.x , TRUE);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::SetScannerErrorLevel(double dWarning_mm, double dAlarm_mm)
{
	if(!m_pDriver)
		return TRUE;


	return m_pDriver->ScanCfg_SetPosError(dWarning_mm, dAlarm_mm);

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::ResetScannerPosErrorCount()
{
	if(!m_pDriver)
		return TRUE;


	return m_pDriver->Error_ScanPos_Reset();

	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::GetScannerError(int& nWarningNo, int& nAlarmNo, int& nMaxValue, int&  nInposMissNo)
{
	if(!m_pDriver)
		return TRUE;

	TPos_Error stPosError;
	TInposMissCnt stMissCnt;
	BOOL bReturn = TRUE;

	bReturn = bReturn & m_pDriver->Error_GetScanPos(&stPosError, 0);
	//nWarningNo[i] = stPosError[i].nCnt_Alarm;
	//nAlarmNo[i] = stPosError[i].nCnt_Warning;
	
	nAlarmNo = stPosError.nCnt_Alarm;//20170926
	nWarningNo = stPosError.nCnt_Warning;
	nMaxValue = stPosError.nError_Max;

	bReturn = bReturn & m_pDriver->Error_GetInposMissCnt(&stMissCnt);
	nInposMissNo = stMissCnt.Beam[0];
	return bReturn;

	return TRUE;
}

void HEocard5Pusan1DualbandNew::UpdateLPCCalibrationFile(CString strPath, int nHeadNo)
{
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;
	CString strFileName;
	strFileName.Format(_T("%sLPC%d.table"), strPath, nHeadNo);
	
	if (NULL == fopen_s(&fp, strFileName, "rb"))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return;
		}
		END_CATCH

		double dX = 0.0, dY = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1000.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dX = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dY = atof(token);

//				if (fabs(dX) > 1.0 || fabs(dY) > 1.0)
//				{
//					fclose(fp);
//					delete [] dpOffset;
//					return;
//				}

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = dY;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		m_CalLPC->SetMatrixToZero();
		m_CalLPC->UpdateCalibration(calHead);
		delete [] dpOffset;
	}
}


	TLpc_Buffer* HEocard5Pusan1DualbandNew::GetLPCResult()
	{
		if(!m_pDriver)
			return NULL;

		m_pDriver->Drill_GetLPCData(m_pLPC_Monitor);
		return m_pLPC_Monitor;
	}


CPoint HEocard5Pusan1DualbandNew::GetDownHoleFirePos(int nIndex)
{
	CPoint cPoint;
	cPoint.x = cPoint.y = INT_MAX;

	if(nIndex >= DOWNLOAD_MAX_HOLE)
		return cPoint;

	int	 nDBNo;
	if(m_nSameShotPrestartCount > 1) // 2���� backupDB�߿�  ���� �ٿ�ε��̴�)
	{
		nDBNo = m_nBackUpIndex;
	}
	else
	{
		if(m_nBackUpIndex == 0) 
			nDBNo = 1;
		else
			nDBNo = 0;
	}
	cPoint.x = m_pBackUpData[nDBNo * DOWNLOAD_MAX_HOLE + nIndex].HolePos[3].x;
	cPoint.y = m_pBackUpData[nDBNo * DOWNLOAD_MAX_HOLE + nIndex].HolePos[3].y;
	return cPoint;
}

BOOL HEocard5Pusan1DualbandNew::SetLPCDataReadReady()
{
	if(!gSystemINI.m_sHardWare.bUseLPC)
		return TRUE;
	
	if(!m_pDriver)
		return TRUE;

	int nResult;
	nResult = m_pDriver->Drill_ChangeLPCBuffer();
	return nResult;

}

void HEocard5Pusan1DualbandNew::LoadLPCCalibrationFile(CString strPath)
{
	if(!gSystemINI.m_sHardWare.bUseLPC)
		return;
	
	if(m_CalLPC)
		m_CalLPC->LoadCalibration(strPath);
	
}

BOOL HEocard5Pusan1DualbandNew::DownloadPowerLevel(unsigned int nToolNo, unsigned int nShotIndex, double dMinVal, double dMAxVal)
{
	if(!gSystemINI.m_sHardWare.bUseLPC)
		return TRUE;
	
	
	if(!m_pDriver)
		return TRUE;
	
		BOOL bReturnVal;
		m_SubToolConfig[nToolNo].LPC_SetPara[nShotIndex].nLPC_SetMin = (ts16)dMinVal;			// us
		m_SubToolConfig[nToolNo].LPC_SetPara[nShotIndex].nLPC_SetMax = (ts16)dMAxVal;
		
		bReturnVal = m_pDriver->Drill_SetSubTool(nToolNo, &m_SubToolConfig[nToolNo]);
		
		return bReturnVal;


	return TRUE;
}

BOOL HEocard5Pusan1DualbandNew::DownloadStartPowerTolerence(unsigned int nShotCount, double dMinPer, double dMaxPer)
{
	if(!gSystemINI.m_sHardWare.bUseLPC)
		return TRUE;


	if(!m_pDriver)
		return TRUE;

		BOOL bReturnVal;
		m_LPCTolerence.nCount = (tu32)nShotCount;
		m_LPCTolerence.fMin_Percent = dMinPer;
		m_LPCTolerence.fMax_Percent = dMaxPer;
		bReturnVal = m_pDriver->Drill_SetLPCTolerance(&m_LPCTolerence);
		return bReturnVal;
	

	return TRUE;
}
BOOL HEocard5Pusan1DualbandNew::DownloadDummyFreeInfo()
{
	if(!m_pDriver)
		return TRUE;

	return TRUE;
}
BOOL HEocard5Pusan1DualbandNew::IsDrillTimeOutType()
{
	if(!m_pDriver)
		return FALSE;

	TTimeOutStatus pTimeOutStat;
	m_pDriver->List_GetTimeOutStatus(&pTimeOutStat);

	if(pTimeOutStat.bit.Unknown)
		return 0x01;
	if(pTimeOutStat.bit.Mccmd_Drill)
		return 0x02;
	if(pTimeOutStat.bit.Mccmd_Lpc)
		return 0x04;

	return FALSE;
}

BOOL HEocard5Pusan1DualbandNew::GetAOMStatus(WORD *pStat) const
{
	if(!m_pDriver)
		return TRUE;

	int nVal;
	m_pDriver->BoardIO_ReadIn(EETSx_ReadIn_HighSpeed_IF, &nVal);
	*pStat = nVal;
	//*pStat = 0;
	return TRUE; 
}

void HEocard5Pusan1DualbandNew::InitShotScale(int nTool)
{
	if(!m_pDriver)
		return;
	/*

		TDrillSubToolScaleInfo m_SubToolShotScale;
		m_SubToolShotScale.Enable.bit.beam1 = FALSE;
		m_SubToolShotScale.Enable.bit.beam2 = FALSE;

		for(int jj = 0; jj < 2; jj++)
		{

			for(int kk = 0; kk < MAX_SHOT_LOOP_CNT; kk++)
			{
				m_SubToolShotScale.nScale_vm[jj][kk].x = 0;
				m_SubToolShotScale.nScale_vm[jj][kk].y = 0;
			}
		}

		m_pDriver->Drill_SetSubToolScale(nTool, &m_SubToolShotScale);
		*/


}

void HEocard5Pusan1DualbandNew::SetShotScale(int nTool,int nShotNo,CDPoint dOffsetM , CDPoint dOffsetS)
{
	/*
	if(!m_pDriver)
		return;

		TDrillSubToolScaleInfo m_SubToolShotScale;
		m_SubToolShotScale.Enable.bit.beam1 = TRUE;
		m_SubToolShotScale.Enable.bit.beam2 = TRUE;

	
		m_SubToolShotScale.nScale_vm[0][nShotNo].x = (int)dOffsetM.x * 10;
		m_SubToolShotScale.nScale_vm[0][nShotNo].y = (int)dOffsetM.y * 10;
	
		m_SubToolShotScale.nScale_vm[1][nShotNo].x = (int)dOffsetS.x * 10;
		m_SubToolShotScale.nScale_vm[1][nShotNo].y = (int)dOffsetS.y * 10;

		m_pDriver->Drill_SetSubToolScale(nTool, &m_SubToolShotScale);
	*/

}