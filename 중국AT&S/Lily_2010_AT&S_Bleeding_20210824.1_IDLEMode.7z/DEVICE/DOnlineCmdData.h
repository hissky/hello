// DOnlineCmdData.h: interface for the DOnlineCmdData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DONLINECMDDATA_H__E2F9CF44_E993_4E1A_B1B8_F74675414A7B__INCLUDED_)
#define AFX_DONLINECMDDATA_H__E2F9CF44_E993_4E1A_B1B8_F74675414A7B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DOnlineCmdData  
{
public:
	DOnlineCmdData();
	virtual ~DOnlineCmdData();

// Operation
public:
	// Online Command
	char*	GetOnlineCmd()			{ return m_szOnlineCmd; }
	int		GetOnlineCmdLen()		{ return m_nLen; }
	void	SetOnlineCmd(char* szCmd);
	BOOL	IsOnlineData()			{ return m_bDPRamFlag; }

	// Float DPRAM Command
	void	SetDPRamFloatData(int nSize, DWORD dwOffset, float* pfMemData);
	float*	GetDPRamFloatData()			{ return m_pfMemData; }

	// DWORD DPRAM Command
	void	SetDPRamDWORDData(int nSize, DWORD dwOffset, DWORD* pMemData, BOOL bRead=FALSE, int nDataType=0);
	DWORD*	GetDPRamDWORDData()			{ return m_pMemData; }

	// DPRAM Memory Size and Offset and Flag
	int		GetMemSize()				{ return m_nMemSize; }
	DWORD	GetMemOffset()				{ return m_dwOffset; }
	BOOL	GetReadDPRam()				{ return m_bReadDPRam; }
	BOOL	GetIsFloat()				{ return m_bIsFloat; }

	// DPRAM Data Type
	void	SetDataType(int nType)		{ m_nDataType = nType; }
	int		GetDataType()				{ return m_nDataType; }

// Attribute
protected:
	// Online Command
	char	m_szOnlineCmd[100];
	int		m_nLen;

	// Float DPRAM Command
	float*	m_pfMemData;
	
	// DWORD DPRAM Command
	DWORD*	m_pMemData;
	
	// DPRAM Size Flag Offset and Flag
	int		m_nMemSize;
	DWORD	m_dwOffset;
	BOOL	m_bDPRamFlag;
	BOOL	m_bReadDPRam;
	BOOL	m_bIsFloat;

	// DPRAM Data Type
	int		m_nDataType;
};

#endif // !defined(AFX_DONLINECMDDATA_H__E2F9CF44_E993_4E1A_B1B8_F74675414A7B__INCLUDED_)
