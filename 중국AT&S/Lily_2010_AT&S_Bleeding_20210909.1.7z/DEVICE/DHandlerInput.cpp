// DHandlerInput.cpp: implementation of the DHandlerInput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DHandlerInput.h"
//#include "DRecipeData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DHandlerInput gHandlerInput;

DHandlerInput::DHandlerInput()
{
	memset( &m_sStageX, 0, sizeof(m_sStageX) );
	memset( &m_sStageY, 0, sizeof(m_sStageY) );
	memset( &m_sStageZ, 0, sizeof(m_sStageZ) );
	memset( &m_sStageT, 0, sizeof(m_sStageT) );
	memset( &m_sElevator, 0, sizeof(m_sElevator) );
	memset( &m_sGripper, 0, sizeof(m_sGripper) );
	memset( &m_sLPickerY, 0, sizeof(m_sLPickerY) );
	memset( &m_sLPickerZ, 0, sizeof(m_sLPickerZ) );
	memset( &m_sBPickerY, 0, sizeof(m_sBPickerY) );
	memset( &m_sBPickerZ, 0, sizeof(m_sBPickerZ) );
	memset( &m_sSpinT, 0, sizeof(m_sSpinT) );
	memset( &m_sSpinZ, 0, sizeof(m_sSpinZ) );
	memset( &m_sCoaterArm, 0, sizeof(m_sCoaterArm) );
	memset( &m_sStagePos, 0, sizeof(m_sStagePos) );
	memset( &m_sHandlerPos, 0, sizeof(m_sHandlerPos) );
	memset( &m_nSysInput, 0, sizeof(m_nSysInput) );
	memset( &m_nMotorErr, 0, sizeof(m_nMotorErr) );
	memset( &m_nSysErr, 0, sizeof(m_nSysErr) );
	memset( &m_nEtcErr, 0, sizeof(m_nEtcErr) );
	memset( &m_nMotorPos, 0, sizeof(m_nMotorPos) );
	memset( &m_nCassetteSlotStatus, 0, sizeof(m_nCassetteSlotStatus) );
	memset( &m_nWaferStatus, 0, sizeof(m_nWaferStatus) );
	memset( &m_nWaferSlot, 0, sizeof(m_nWaferSlot) );
	memset( &m_nPCOutput, 0, sizeof(m_nPCOutput) );
	memset( &m_sSysSensor, 0, sizeof(m_sSysSensor) );

	for(int i = 0 ; i < 25 ; i++ )
		m_nCassetteSlotStatus[i] = -1;

	for(int i = 0 ; i < 6 ; i++ )
	{
		m_nWaferSlot[i] = -1;
		m_nWaferStatus[i] = -1;
	}
}

DHandlerInput::~DHandlerInput()
{

}

void DHandlerInput::SetSysInput(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 11 ; i++ ) // 60500 ~60510
	{
		dwData = *(pData+i);
		//if( dwData != m_nSysInput[i] )
		{
			m_nSysInput[i] = dwData;
			UpdateSysInput( i, dwData );
		}
	}
}

void DHandlerInput::UpdateSysInput(int nAddrIndex, DWORD dwData)
{
	BOOL bFlag = 0;
	int nMask = 1, nMode = 0;

	switch( nAddrIndex )
	{
	case 0 : // M7000
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_sStageIF.bMachineReady = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_sStageIF.bAllInitializing = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageX.bHoming = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageY.bHoming = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageT.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageZ.bHoming = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsPCOutput.m_sStageIF.bAllInitialEnd = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_sStageX.bHomeEnd = bFlag;
			
			bFlag = ( dwData >> 8 ) & nMask;
			m_sStageY.bHomeEnd = bFlag;
			
			bFlag = ( dwData >> 9 ) & nMask;
			m_sStageT.bHomeEnd = bFlag;
			
			bFlag = ( dwData >> 10 ) & nMask;
			m_sStageZ.bHomeEnd = bFlag;
		}
		break;
	case 2 : // 60502
		{
			bFlag = dwData & nMask;
			m_sSysSensor.bEmergencySwitch = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_sSysSensor.bSystemAirPressure = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_sSysSensor.bTableVacuumSensor = bFlag;

			nMode = ( dwData >> 11 ) & 7;
			m_sSysSensor.nMPGMode = nMode;

		}
		break;
	case 4 : // 60504
		{
			bFlag = ( dwData >> 4 ) & nMask;
			m_sSysSensor.bTowerLampRedOn = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sSysSensor.bTowerLampYellowOn = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_sSysSensor.bTowerLampGreenOn = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_sSysSensor.bTowerLampBuzzerOn = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_sSysSensor.bTableVacuumOnSol = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_sSysSensor.bTableExhaustSol = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_sSysSensor.bIonizerAirBlowerSol = bFlag;

			bFlag = ( dwData >> 12 ) & nMask;
			m_sSysSensor.bFrontDoorLockSol = bFlag;

			bFlag = ( dwData >> 13 ) & nMask;
			m_sSysSensor.bLoadingDoorLockSol = bFlag;
		}
		break;
	case 5 : // 60505
		{
			bFlag = dwData & nMask;
			m_sSysSensor.bDoorBypass = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sSysSensor.bDustCollectorOn = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sSysSensor.bMainLampOn = bFlag;
		}
		break;
	case 10 : // 60510
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_sStageIF.bDustCollectorAlarm = bFlag;
		}
		break;
	}
}

void DHandlerInput::SetMotorErr(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 5 ; i++ )
	{
		dwData = *(pData+i + 11); // 60501
//		if( i != 4 )
//		{
			m_nMotorErr[i] = dwData;
			UpdateMotorErr( i, dwData );
//		}
//		else
//		{
//			UpdateSysInput( 0, dwData );
//		}
	}
}

void DHandlerInput::UpdateMotorErr(int nAddrIndex, DWORD dwData)
{
	BOOL bFlag = 0;
	int nMask = 1;

	switch( nAddrIndex )
	{
	case 0 : // 60511
		{
			bFlag = dwData & nMask;
			m_sStageX.bDriveFault = bFlag;
			
			bFlag = ( dwData >> 1 ) & nMask;
			m_sStageX.bFollowingErr = bFlag;
			
			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageX.bOpenLoop = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageX.bPlusLimit = bFlag;
			
			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageX.bMinusLimit = bFlag;
			
			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageX.bHomeTimeOver = bFlag;
		}
		break;
	case 1 : // 60512
		{
			bFlag = dwData & nMask;
			m_sStageY.bDriveFault = bFlag;
			
			bFlag = ( dwData >> 1 ) & nMask;
			m_sStageY.bFollowingErr = bFlag;
			
			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageY.bOpenLoop = bFlag;
			
			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageY.bPlusLimit = bFlag;
			
			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageY.bMinusLimit = bFlag;
			
			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageY.bHomeTimeOver = bFlag;
		}
		break;
	case 2 : // 60513
		{
			bFlag = dwData & nMask;
			m_sStageT.bDriveFault = bFlag;
			
			bFlag = ( dwData >> 1 ) & nMask;
			m_sStageT.bFollowingErr = bFlag;
			
			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageT.bOpenLoop = bFlag;
			
			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageT.bPlusLimit = bFlag;
			
			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageT.bMinusLimit = bFlag;
			
			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageT.bHomeTimeOver = bFlag;
		}
		break;
	case 3 : // 60514
		{
			bFlag = dwData & nMask;
			m_sStageZ.bDriveFault = bFlag;
			
			bFlag = ( dwData >> 1 ) & nMask;
			m_sStageZ.bFollowingErr = bFlag;
			
			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageZ.bOpenLoop = bFlag;
			
			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageZ.bPlusLimit = bFlag;
			
			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageZ.bMinusLimit = bFlag;
			
			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageZ.bHomeTimeOver = bFlag;
		}
		break;
/*	case 4 : // M7036
		{
			bFlag = dwData & nMask;
			m_sAlignRail.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sAlignRail.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sAlignRail.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sAlignRail.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sAlignRail.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sAlignRail.bHomeEnd = bFlag;
		}
		break;
	case 5 : // M7037
		{
			bFlag = dwData & nMask;
			m_sGripper.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sGripper.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sGripper.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sGripper.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sGripper.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sGripper.bHomeEnd = bFlag;
		}
		break;
	case 6 : // M7038
		{
			bFlag = dwData & nMask;
			m_sLPickerY.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sLPickerY.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sLPickerY.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sLPickerY.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sLPickerY.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sLPickerY.bHomeEnd = bFlag;
		}
		break;
	case 7 : // M7039
		{
			bFlag = dwData & nMask;
			m_sLPickerZ.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sLPickerZ.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sLPickerZ.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sLPickerZ.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sLPickerZ.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sLPickerZ.bHomeEnd = bFlag;
		}
		break;
	case 8 : // M7040
		{
			bFlag = dwData & nMask;
			m_sBPickerY.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sBPickerY.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sBPickerY.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sBPickerY.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sBPickerY.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sBPickerY.bHomeEnd = bFlag;
		}
		break;
	case 9 : // M7041
		{
			bFlag = dwData & nMask;
			m_sBPickerZ.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sBPickerZ.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sBPickerZ.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sBPickerZ.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sBPickerZ.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sBPickerZ.bHomeEnd = bFlag;
		}
		break;
	case 10 : // M7042
		{
			bFlag = dwData & nMask;
			m_sSpinT.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sSpinT.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sSpinT.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sSpinT.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sSpinT.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sSpinT.bHomeEnd = bFlag;
		}
		break;
	case 11 : // M7043
		break;
	case 12 : // M7044
		{
			bFlag = dwData & nMask;
			m_sStageZ.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sStageZ.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sStageZ.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sStageZ.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sStageZ.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sStageZ.bHomeEnd = bFlag;
		}
		break;
	case 13 : // M7045
		{
			bFlag = dwData & nMask;
			m_sCoaterArm.bDriveFault = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_sCoaterArm.bFollowingErr = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_sCoaterArm.bLimit = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_sCoaterArm.bOpenLoop = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_sCoaterArm.bHoming = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_sCoaterArm.bHomeEnd = bFlag;
		}
		break;
*/	}
}

void DHandlerInput::SetSysErr(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 2 ; i++ )
	{
		//if( 1 == i || 2 == i || 3 == i )
		//	continue;

		dwData = *(pData+i);
		//if( dwData != m_nSysErr[i] )
		{
			m_nSysErr[i] = dwData;
			UpdateSysErr( i, dwData );
		}
	}
}

void DHandlerInput::UpdateSysErr(int nAddrIndex, DWORD dwData)
{
	BOOL bFlag = 0;
	int nMask = 1;

	switch( nAddrIndex )
	{
	case 0 : // M7016
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bDoorInterlock = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bInitialReq = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bSysAirLow = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bStageAirLow = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bSysVacuumLow = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsSysErr.m_bN2GasLow = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsSysErr.m_bPolygonAirLow = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsSysErr.m_bN2TankAirLow = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsSysErr.m_bMpgOnStatus = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_clsSysErr.m_bGripperCatch = bFlag;

			bFlag = ( dwData >> 11 ) & nMask;
			m_clsSysErr.m_bLPickerWaferCatch = bFlag;

			bFlag = ( dwData >> 12 ) & nMask;
			m_clsSysErr.m_bBPickerWaferCatch = bFlag;

			bFlag = ( dwData >> 13 ) & nMask;
			m_clsSysErr.m_bWaferExistRailInit = bFlag;

			bFlag = ( dwData >> 14 ) & nMask;
			m_clsSysErr.m_bWaferOverload = bFlag;

			bFlag = ( dwData >> 15 ) & nMask;
			m_clsSysErr.m_bAlignRailWafer = bFlag;
		}
		break;
	case 1 : // M7017
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bCoaterWaferCheck = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bStageWaferCheck = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bBufferWaferCheck = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bOmit8InchCassette = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bOmit12InchCassette = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsSysErr.m_bServoPower = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsSysErr.m_bEmgSw = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsSysErr.m_bPolygonAmpFault = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_clsSysErr.m_bPolygonOpenLoop = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsSysErr.m_bIncorrectPickerWaferSize = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_clsSysErr.m_bPickerWafer = bFlag;

			bFlag = ( dwData >> 11 ) & nMask;
			m_clsSysErr.m_bGripperCatchWaferErr = bFlag;

		}
		break;
	}
}

void DHandlerInput::SetEtcErr(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 7 ; i++ )
	{
		dwData = *(pData+i);
		//if( dwData != m_nEtcErr[i] )
		{
			m_nEtcErr[i] = dwData;
			UpdateEtcErr( i, dwData );
		}
	}
}

void DHandlerInput::UpdateEtcErr(int nAddrIndex, DWORD dwData)
{
	BOOL bFlag = 0;
	int nMask = 1;

	switch( nAddrIndex )
	{
	case 0 : // M7096
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bGripperCylinderFw = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bGripperCylinderBw = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bBufferAlignerCylinderFw = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bBufferAlignerCylinderBw = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bLaserShutterCylinderFw = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsSysErr.m_bLaserShutterCylinderBw = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsSysErr.m_bPickerZCylinderFw = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsSysErr.m_bPickerZCylinderBw = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_clsSysErr.m_bPickerWaferSizeFw = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsSysErr.m_bPickerWaferSizeBw = bFlag;
		}
		break;
	case 1 : // M7097
		break;
	case 2 : // M7098
		break;
	case 3 : // M7099
		break;
	case 4 : // M7100
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bCoater	= bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bArmMotionErr	= bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bSpinThetaVacuum	= bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bTankEmpty	= bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bCoaterWaterLeak	= bFlag;
		}
		break;
	case 5 : // M7101
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bInit = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bScanCassette = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bCassetteToAligner = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bAlignerToCassette = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bAlignerToLPicker = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsSysErr.m_bLPickerToCoater = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsSysErr.m_bCoaterToLPicker = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsSysErr.m_bLPickerToChuck = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_clsSysErr.m_bChuckToLPicker = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsSysErr.m_bLPickerToAligner = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_clsSysErr.m_bLPickerToBuffer = bFlag;

			bFlag = ( dwData >> 11 ) & nMask;
			m_clsSysErr.m_bBufferToBPicker = bFlag;

			bFlag = ( dwData >> 12 ) & nMask;
			m_clsSysErr.m_bBPickerToChuck = bFlag;

			bFlag = ( dwData >> 13 ) & nMask;
			m_clsSysErr.m_bCoating = bFlag;

			bFlag = ( dwData >> 14 ) & nMask;
			m_clsSysErr.m_bCleaning = bFlag;
		}
		break;
	case 6 : // M7102
		{
			bFlag = dwData & nMask;
			m_clsSysErr.m_bAlignRailZone = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsSysErr.m_bCoaterZone = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsSysErr.m_bLPickerZone = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsSysErr.m_bBufferZone = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsSysErr.m_bStageZone = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsSysErr.m_bBufferPickerZone = bFlag;
		}
		break;
	}
}

void DHandlerInput::SetMotorPos(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 4 ; i++ )
	{
		dwData = *(pData+i);
		m_nMotorPos[i] = dwData;
		UpdateMotorPos( i, dwData );
	}
}

void DHandlerInput::UpdateMotorPos(int nAddrIndex, DWORD dwData)
{
	long nTemp = dwData;
	
	switch( nAddrIndex )
	{
	case 0 : // M60550
			m_sStagePos.x			= nTemp;
		break;
	case 1 : // M60551
			m_sStagePos.y			= nTemp;
		break;
	case 2 : // M60552
			m_sStagePos.t			= nTemp;
		break;
	case 3 : // M60553
		m_sStagePos.z				= nTemp;
		break;
/*	case 3 : // M7067
			m_sHandlerPos.dElevator	= nTemp;
		break;
	case 4 : // M7068
		m_sHandlerPos.dAlignRail = nTemp;
		break;
	case 5 : // M7069
		m_sHandlerPos.dGripper = nTemp;
		break;
	case 6 : // M7070
		m_sHandlerPos.dLPickerY	= nTemp;
		break;
	case 7 : // M7071
		m_sHandlerPos.dLPickerZ = nTemp;
		break;
	case 8 : // M7072
		m_sHandlerPos.dBPickerY = nTemp;
		break;
	case 9 : // M7073
		m_sHandlerPos.dBPickerZ	= nTemp;
		break;
	case 10 : // M7074
			m_sHandlerPos.dSpinT	= nTemp;
		break;
	case 11 : // M7075
		m_sHandlerPos.dSpinZ	= nTemp;
		break;
	case 12 : // M7076
		m_sStagePos.z			= nTemp;
		break;
	case 13 : // M7077
		m_sHandlerPos.dCoaterArm = nTemp;
		break;
	case 14 : // M7078
		//m_sStagePos.p			= nTemp; // Use PG
		break;
*/	}
}

void DHandlerInput::SetCassetteSlotStatus(DWORD* pData)
{
	memcpy( m_nCassetteSlotStatus, pData, sizeof(m_nCassetteSlotStatus) );
}

void DHandlerInput::SetWaferStatus(DWORD* pData)
{
	memcpy( m_nWaferStatus, pData, sizeof(m_nWaferStatus) );
	memcpy( m_nWaferSlot, pData+8, sizeof(m_nWaferSlot) );
}

void DHandlerInput::SetPCOutputStatus(DWORD* pData)
{
	DWORD dwData = 0;

	for( int i = 0 ; i < 16 ; i++ )
	{
		if( 1 == i || 2 == i || 3 == i || 7 == i || 8 == i || 9 == i ||
			12 == i || 13 == i || 14 == i )
			continue;

		dwData = *(pData+i);
		//if( dwData != m_nPCOutput[i] )
		{
			m_nPCOutput[i] = dwData;
			UpdatePCOutput( i, dwData );
		}
	}
}

void DHandlerInput::UpdatePCOutput(int nAddrIndex, DWORD dwData)
{
	BOOL bFlag = 0;
	int nMask = 1;

	switch( nAddrIndex )
	{
	case 0 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_bSysStart = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_bSysStop = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_bSysAlarmClearReq = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsPCOutput.m_bDoorByPass = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsPCOutput.m_bNotUseBuzzer = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsPCOutput.m_bNewCassetteChangeReq = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsPCOutput.m_bCoatingParamDownReq = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsPCOutput.m_bCleaningParamDownReq = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_clsPCOutput.m_bHandlerPosDownReq = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsPCOutput.m_bCoaterPosDownReq = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_clsPCOutput.m_bWaferSize = bFlag;

			bFlag = ( dwData >> 11 ) & nMask;
			m_clsPCOutput.m_bWorkingTool = bFlag;

			bFlag = ( dwData >> 12 ) & nMask;
			m_clsPCOutput.m_bAllInitIgnoreErr = bFlag;
		}
		break;
	case 1 :
		break;
	case 4 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_sStageIF.bStageReady = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_sStageIF.bStageStart = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_sStageIF.bStageProgress = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsPCOutput.m_sStageIF.bStageError = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsPCOutput.m_sStageIF.bStageEnd = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsPCOutput.m_bHandlerRun = bFlag;
		}
		break;
	case 5 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_bAllInitReq = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_bOnlyHanadlerInitReq = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_bOnlyStageInitReq = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsPCOutput.m_bOnlyCoaterInitReq = bFlag;
		}
		break;
	case 6 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_bFullDryRun = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_bNoWaferFullDryRun = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_bSkipCoaterRun = bFlag;

		}
		break;
	case 10 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_bRailZoneWaferStatusClearReq = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_bCoaterZoneWaferStatusClearReq = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_bLPickerZoneWaferStatusClearReq = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsPCOutput.m_bBufferZoneWaferStatusClearReq = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsPCOutput.m_bChuckZoneWaferStatusClearReq = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsPCOutput.m_bBPickerZoneWaferStatusClearReq = bFlag;
		}
		break;
	case 11 :
		{
			bFlag = dwData & nMask;
			m_clsPCOutput.m_bCassetteSlotWaferStatusChangeReq = bFlag;

			bFlag = ( dwData >> 1 ) & nMask;
			m_clsPCOutput.m_bSlot[0] = bFlag;

			bFlag = ( dwData >> 2 ) & nMask;
			m_clsPCOutput.m_bSlot[1] = bFlag;

			bFlag = ( dwData >> 3 ) & nMask;
			m_clsPCOutput.m_bSlot[2] = bFlag;

			bFlag = ( dwData >> 4 ) & nMask;
			m_clsPCOutput.m_bSlot[3] = bFlag;

			bFlag = ( dwData >> 5 ) & nMask;
			m_clsPCOutput.m_bSlot[4] = bFlag;

			bFlag = ( dwData >> 6 ) & nMask;
			m_clsPCOutput.m_bSlot[5] = bFlag;

			bFlag = ( dwData >> 7 ) & nMask;
			m_clsPCOutput.m_bSlot[6] = bFlag;

			bFlag = ( dwData >> 8 ) & nMask;
			m_clsPCOutput.m_bSlot[7] = bFlag;

			bFlag = ( dwData >> 9 ) & nMask;
			m_clsPCOutput.m_bSlot[8] = bFlag;

			bFlag = ( dwData >> 10 ) & nMask;
			m_clsPCOutput.m_bSlot[9] = bFlag;

			bFlag = ( dwData >> 11 ) & nMask;
			m_clsPCOutput.m_bSlot[10] = bFlag;

			bFlag = ( dwData >> 12 ) & nMask;
			m_clsPCOutput.m_bSlot[11] = bFlag;

			bFlag = ( dwData >> 13 ) & nMask;
			m_clsPCOutput.m_bSlot[12] = bFlag;
		}
		break;
	case 15 :
		m_clsPCOutput.m_nMpgMode = dwData;
		break;
	}
}

BOOL DHandlerInput::IsMotorErr(int nAxis, CString& strMsg)
{
	BOOL bRet = FALSE;

	switch( nAxis )
	{
	case 0 : // Stage X
		if( 0 == m_sStageX.bHomeEnd )
		{
			if( m_sStageX.bDriveFault || m_sStageX.bFollowingErr || m_sStageX.bHoming || 
				m_sStageX.bPlusLimit || m_sStageX.bMinusLimit || m_sStageX.bOpenLoop )
			{
				strMsg.Format(_T("Stage X Motor Error"));
				bRet = 1;
			}
		}
		else
		{
			strMsg.Format(_T("Stage X Motor Error"));
			bRet = 1;
		}
		break;
	case 1 : // Stage Y
		if( 0 == m_sStageY.bHomeEnd )
		{
			if( m_sStageY.bDriveFault || m_sStageY.bFollowingErr ||
				m_sStageY.bHoming || m_sStageY.bPlusLimit || m_sStageY.bMinusLimit || m_sStageY.bOpenLoop )
			{
				strMsg.Format(_T("Stage Y Motor Error"));
				bRet = 2;
			}
		}
		else
		{
			strMsg.Format(_T("Stage Y Motor Error"));
			bRet = 2;
		}
		break;
	case 2 : // Stage Z
		if( 0 == m_sStageZ.bHomeEnd )
		{
			if( m_sStageZ.bDriveFault || m_sStageZ.bFollowingErr ||
				m_sStageZ.bHoming || m_sStageZ.bPlusLimit || m_sStageZ.bMinusLimit || m_sStageZ.bOpenLoop )
			{
				strMsg.Format(_T("Stage Z Motor Error"));
				bRet = 3;
			}
		}
		else
		{
			strMsg.Format(_T("Stage Z Motor Error"));
			bRet = 3;
		}
		break;
	case 3 : // Stage T
		if( 0 == m_sStageT.bHomeEnd )
		{
			if( m_sStageT.bDriveFault || m_sStageT.bFollowingErr ||
				m_sStageT.bHoming || m_sStageT.bPlusLimit || m_sStageT.bMinusLimit || m_sStageT.bOpenLoop )
			{
				strMsg.Format(_T("Stage T Motor Error"));
				bRet = 4;
			}
		}
		else
		{
			strMsg.Format(_T("Stage T Motor Error"));
			bRet = 4;
		}
		break;
/*	case 4 : // Elevator
		if( 0 == m_sElevator.bHomeEnd )
		{
			if( m_sElevator.bDriveFault || m_sElevator.bFollowingErr ||
				m_sElevator.bHoming || m_sElevator.bLimit || m_sElevator.bOpenLoop )
			{
				strMsg.Format(_T("Elevator Motor Error"));
				bRet = 5;
			}
		}
		else
		{
			strMsg.Format(_T("Elevator Motor Error"));
			bRet = 5;
		}
		break;
	case 5 : // Align Rail
		if( 0 == m_sAlignRail.bHomeEnd )
		{
			if( m_sAlignRail.bDriveFault || m_sAlignRail.bFollowingErr ||
				m_sAlignRail.bHoming || m_sAlignRail.bLimit || m_sAlignRail.bOpenLoop )
			{
				strMsg.Format(_T("Align Rail Motor Error"));
				bRet = 6;
			}
		}
		else
		{
			strMsg.Format(_T("Align Rail Motor Error"));
			bRet = 6;
		}
		break;
	case 6 : // Gripper
		if( 0 == m_sGripper.bHomeEnd )
		{
			if( m_sGripper.bDriveFault || m_sGripper.bFollowingErr ||
				m_sGripper.bHoming || m_sGripper.bLimit || m_sGripper.bOpenLoop )
			{
				strMsg.Format(_T("Gripper Motor Error"));
				bRet = 7;
			}
		}
		else
		{

		}
		break;
	case 7 : // Loader Picker Y
		if( 0 == m_sLPickerY.bHomeEnd )
		{
			if( m_sLPickerY.bDriveFault || m_sLPickerY.bFollowingErr ||
				m_sLPickerY.bHoming || m_sLPickerY.bLimit || m_sLPickerY.bOpenLoop )
			{
				strMsg.Format(_T("Loader Picker Y Motor Error"));
				bRet = 8;
			}
		}
		else
		{
				strMsg.Format(_T("Loader Picker Y Motor Error"));
				bRet = 8;
		}
		break;
	case 8 : // Loader Picker Z
		if( 0 == m_sLPickerZ.bHomeEnd )
		{
			if( m_sLPickerZ.bDriveFault || m_sLPickerZ.bFollowingErr ||
				m_sLPickerZ.bHoming || m_sLPickerZ.bLimit || m_sLPickerZ.bOpenLoop )
			{
				strMsg.Format(_T("Loader Picker Z Motor Error"));
				bRet = 9;
			}
		}
		else
		{
			strMsg.Format(_T("Loader Picker Z Motor Error"));
			bRet = 9;
		}
		break;
	case 9 : // Buffer Picker Y
		if( 0 ==  m_sBPickerY.bHomeEnd )
		{
			if( m_sBPickerY.bDriveFault || m_sBPickerY.bFollowingErr ||
				m_sBPickerY.bHoming || m_sBPickerY.bLimit || m_sBPickerY.bOpenLoop )
			{
				strMsg.Format(_T("Buffer Picker Y Motor Error"));
				bRet = 10;
			}
		}
		else
		{
			strMsg.Format(_T("Buffer Picker Y Motor Error"));
			bRet = 10;
		}
		break;
	case 10 : // Buffer Picker Z
		if( 0 == m_sBPickerZ.bHomeEnd )
		{
			if( m_sBPickerZ.bDriveFault || m_sBPickerZ.bFollowingErr ||
				m_sBPickerZ.bHoming || m_sBPickerZ.bLimit || m_sBPickerZ.bOpenLoop )
			{
				strMsg.Format(_T("Buffer Picker Z Motor Error"));
				bRet = 11;
			}
		}
		else
		{
			strMsg.Format(_T("Buffer Picker Z Motor Error"));
			bRet = 11;
		}
		break;
	case 11 : // Spin T
		if( 0 == m_sSpinT.bHomeEnd )
		{
			if( m_sSpinT.bDriveFault || m_sSpinT.bFollowingErr ||
				m_sSpinT.bHoming || m_sSpinT.bLimit || m_sSpinT.bOpenLoop )
			{
				strMsg.Format(_T("Spin T Motor Error"));
				bRet = 12;
			}
		}
		else
		{
			strMsg.Format(_T("Spin T Motor Error"));
			bRet = 12;
		}
		break;
	case 12 : // Spin Z
		if( 0 == m_sSpinZ.bHomeEnd )
		{
			if( m_sSpinZ.bDriveFault || m_sSpinZ.bFollowingErr ||
				m_sSpinZ.bHoming || m_sSpinZ.bLimit || m_sSpinZ.bOpenLoop )
			{
				strMsg.Format(_T("Spin Z Motor Error"));
				bRet = 13;
			}
		}
		else
		{
			strMsg.Format(_T("Spin Z Motor Error"));
			bRet = 13;
		}
		break;
	case 13 : // Coater Arm
		if( 0 == m_sCoaterArm.bHomeEnd )
		{
			if( m_sCoaterArm.bDriveFault || m_sCoaterArm.bFollowingErr ||
				m_sCoaterArm.bHoming || m_sCoaterArm.bLimit || m_sCoaterArm.bOpenLoop )
			{
				strMsg.Format(_T("Coater Arm Motor Error"));
				bRet = 14;
			}
		}
		else
		{
			strMsg.Format(_T("Coater Arm Motor Error"));
			bRet = 14;
		}
		break;
*/	}

	return bRet;
}

BOOL DHandlerInput::IsStageMotorErr(CString& strMsg)
{
	BOOL bRet = FALSE;
	CString str;
	BOOL bErr = FALSE;

	for( int i = 0 ; i < 4 ; i++ )
	{
		bErr = IsMotorErr(i, str);
		if( bErr )
		{
			strMsg += str;
			strMsg += _T("\n");
			str.Format(_T(""));
			bRet = bErr;
		}
	}

	return bRet;
}

BOOL DHandlerInput::IsCoaterMotorErr(CString& strMsg)
{
	BOOL bRet = FALSE;
	CString str;
	BOOL bErr = FALSE;

	for( int i = 11 ; i < 14 ; i++ )
	{
		if( 11 == i )
			continue; 

		bErr = IsMotorErr(i, str);
		if( bErr )
		{
			strMsg += str;
			strMsg += _T("\n");
			str.Format(_T(""));
			bRet = bErr;
		}
	}

	return bRet;
}

BOOL DHandlerInput::IsHandlerMotorErr(CString& strMsg)
{
	BOOL bRet = FALSE;
	CString str;
	BOOL bErr = FALSE;

	for( int i = 4 ; i < 11 ; i++ )
	{
		bErr = IsMotorErr(i, str);
		if( bErr )
		{
			strMsg += str;
			strMsg += _T("\n");
			str.Format(_T(""));
			bRet = bErr;
		}
	}

	return bRet;
}

BOOL DHandlerInput::IsHandlerErr(int nCheckErrSection, CString& strMsg)
{
	BOOL bRet = FALSE;

	CString str;

	switch( nCheckErrSection )
	{
	case 0 : // System Error
		if( m_clsSysErr.m_bDoorInterlock )
		{
			strMsg.Format(_T("Door Interlock Error"));
			bRet = 1;
		}

		if( m_clsSysErr.m_bInitialReq )
		{
			strMsg.Format(_T("Initialize Request Error"));
			bRet = 2;
		}

		if( m_clsSysErr.m_bSysAirLow )
		{
			strMsg.Format(_T("System Air Low Error"));
			bRet = 3;
		}

		if( m_clsSysErr.m_bStageAirLow )
		{
			strMsg.Format(_T("Stage Air Low Error"));
			bRet = 4;
		}

		if( m_clsSysErr.m_bSysVacuumLow )
		{
			strMsg.Format(_T("System Vacuum Low Error"));
			bRet = 5;
		}

		if( m_clsSysErr.m_bN2GasLow )
		{
			strMsg.Format(_T("N2 Gas Low Error"));
			bRet = 6;
		}

		if( m_clsSysErr.m_bPolygonAirLow )
		{
			strMsg.Format(_T("Polygon Air Low Error"));
			bRet = 7;
		}

		if( m_clsSysErr.m_bN2TankAirLow )
		{
			strMsg.Format(_T("N2 Tank Air Low Error"));
			bRet = 8;
		}
		if( m_clsSysErr.m_bCoaterWaterLeak )
		{
			strMsg.Format(_T("Coater Water Leak Error"));
			bRet = 9;
		}

		if( m_clsSysErr.m_bMpgOnStatus )
		{
			strMsg.Format(_T("MPG On Status Error"));
			bRet = 10;
		}
		if( m_clsSysErr.m_bGripperCatch )
		{
			strMsg.Format(_T("Gripper Catch State Error"));
			bRet = 11;
		}
		if( m_clsSysErr.m_bLPickerWaferCatch )
		{
			strMsg.Format(_T("Loader Picker Wafer Catch State Error"));
			bRet = 12;
		}
		if( m_clsSysErr.m_bBPickerWaferCatch )
		{
			strMsg.Format(_T("Buffer Picker Wafer Catch State Error"));
			bRet = 13;
		}
		if( m_clsSysErr.m_bWaferExistRailInit )
		{
			strMsg.Format(_T("Wafer exist on the rail when mahcine inialize"));
			bRet = 14;
		}
		if( m_clsSysErr.m_bWaferOverload )
		{
			strMsg.Format(_T("Wafer Overload Error"));
			bRet = 15;
		}
		if( m_clsSysErr.m_bAlignRailWafer )
		{
			strMsg.Format(_T("Align Rail Wafer Check Sensor Error"));
			bRet = 16;
		}
		if( m_clsSysErr.m_bCoaterWaferCheck )
		{
			strMsg.Format(_T("Coater Wafer Check Sensor Error"));
			bRet = 17;
		}
		if( m_clsSysErr.m_bStageWaferCheck )
		{
			strMsg.Format(_T("Stage Wafer Check Sensor Error"));
			bRet = 18;
		}
		if( m_clsSysErr.m_bBufferWaferCheck )
		{
			strMsg.Format(_T("Buffer Wafer Check Sensor Error"));
			bRet = 19;
		}
		if( m_clsSysErr.m_bOmit8InchCassette )
		{
			strMsg.Format(_T("There is no 8 Inch Cassette"));
			bRet = 20;
		}
		if( m_clsSysErr.m_bOmit12InchCassette )
		{
			strMsg.Format(_T("There is no 12 Inch Cassette"));
			bRet = 21;
		}

		if( m_clsSysErr.m_bServoPower )
		{
			strMsg.Format(_T("Servo Power Off"));
			bRet = 22;
		}

		if( m_clsSysErr.m_bEmgSw )
		{
			strMsg.Format(_T("Emergency Switch On"));
			bRet = 23;
		}

		if( m_clsSysErr.m_bIncorrectPickerWaferSize )
		{
			strMsg.Format(_T("Incorrect Picker\'s wafer size"));
			bRet = 54;
		}

		if( m_clsSysErr.m_bPickerWafer )
		{
			strMsg.Format(_T("Can not change picker size because picker already have wafer"));
			bRet = 55;
		}
		break;
	case 1 : // Wafer State & Cyclinder Error
		if( m_clsSysErr.m_bAlignRailZone )
		{
			strMsg.Format(_T("Align Rail Zone Wafer Error"));
			bRet = 24;
		}

		if( m_clsSysErr.m_bCoaterZone )
		{
			strMsg.Format(_T("Coater Zone Wafer Error"));
			bRet = 25;
		}

		if( m_clsSysErr.m_bLPickerZone )
		{
			strMsg.Format(_T("Loader Picker Zone Wafer Error"));
			bRet = 26;
		}

		if( m_clsSysErr.m_bBufferZone )
		{
			strMsg.Format(_T("Buffer Zone Wafer Error"));
			bRet = 27;
		}

		if( m_clsSysErr.m_bStageZone )
		{
			strMsg.Format(_T("Chuck Zone Wafer Error"));
			bRet = 28;
		}

		if( m_clsSysErr.m_bBufferPickerZone )
		{
			strMsg.Format(_T("Buffer Picker Zone Error"));
			bRet = 29;
		}

		if( m_clsSysErr.m_bGripperCylinderFw )
		{
			strMsg.Format(_T("Gripper Cylinder Forward Error"));
			bRet = 30;
		}

		if( m_clsSysErr.m_bGripperCylinderBw )
		{
			strMsg.Format(_T("Gripper Cylinder Backward Error"));
			bRet = 31;
		}

		if( m_clsSysErr.m_bBufferAlignerCylinderFw )
		{
			strMsg.Format(_T("Buffer Aligner Cylinder Forward Error"));
			bRet = 32;
		}

		if( m_clsSysErr.m_bBufferAlignerCylinderBw )
		{
			strMsg.Format(_T("Buffer Aligner Cylinder Backward Error"));
			bRet = 33;
		}

		if( m_clsSysErr.m_bLaserShutterCylinderFw )
		{
			strMsg.Format(_T("Laser Shutter Cylinder Forward Error"));
			bRet = 34;
		}

		if( m_clsSysErr.m_bLaserShutterCylinderFw )
		{
			strMsg.Format(_T("Laser Shutter Cylinder Backward Error"));
			bRet = 35;
		}

		if( m_clsSysErr.m_bSpinThetaSpeed )
		{
			strMsg.Format(_T("Spin Theta Axis Speed Error"));
			bRet = 38;
		}
		break;
	case 2 : // Cycle Error
		if( m_clsSysErr.m_bInit )
		{
			strMsg.Format(_T("Initialize Error"));
			bRet = 39;
		}

		if( m_clsSysErr.m_bScanCassette )
		{
			strMsg.Format(_T("Cassette Scan cycle Error"));
			bRet = 40;
		}

		if( m_clsSysErr.m_bCassetteToAligner )
		{
			strMsg.Format(_T("Cassette to aligner cycle Error"));
			bRet = 41;
		}

		if( m_clsSysErr.m_bAlignerToCassette )
		{
			strMsg.Format(_T("Align to cassette cycle Error"));
			bRet = 42;
		}

		if( m_clsSysErr.m_bAlignerToLPicker )
		{
			strMsg.Format(_T("Aligner to loader picker cycle Error"));
			bRet = 43;
		}

		if( m_clsSysErr.m_bLPickerToCoater )
		{
			strMsg.Format(_T("Loader picker to coater cycle Error"));
			bRet = 44;
		}

		if( m_clsSysErr.m_bCoaterToLPicker )
		{
			strMsg.Format(_T("Coater to loader picker cycle Error"));
			bRet = 45;
		}

		if( m_clsSysErr.m_bLPickerToChuck )
		{
			strMsg.Format(_T("Loader picker to chuck cycle Error"));
			bRet = 46;
		}

		if( m_clsSysErr.m_bChuckToLPicker )
		{
			strMsg.Format(_T("Chuck to loader picker cycle Error"));
			bRet = 47;
		}

		if( m_clsSysErr.m_bLPickerToAligner )
		{
			strMsg.Format(_T("Loader picker to aligner cycle Error"));
			bRet = 48;
		}

		if( m_clsSysErr.m_bLPickerToBuffer )
		{
			strMsg.Format(_T("Loader Picker to buffer cycle Error"));
			bRet = 49;
		}

		if( m_clsSysErr.m_bBufferToBPicker )
		{
			strMsg.Format(_T("Buffer to buffer picker cycle Error"));
			bRet = 50;
		}

		if( m_clsSysErr.m_bBPickerToChuck )
		{
			strMsg.Format(_T("Buffer picker to chuck cycle Error"));
			bRet = 51;
		}

		if( m_clsSysErr.m_bCoating )
		{
			strMsg.Format(_T("Coating Error"));
			bRet = 52;
		}

		if( m_clsSysErr.m_bCleaning )
		{
			strMsg.Format(_T("Cleaning Error"));
			bRet = 53;
		}
		break;
	}

	return bRet;
}

BOOL DHandlerInput::IsSysErr(CString& strMsg)
{
	BOOL bRet = FALSE;
	CString str;
	BOOL bErr = FALSE;

	for( int i = 0 ; i < 3 ; i++ )
	{
		bErr = IsHandlerErr( i, str );
		if( bErr )
		{
			bRet = bErr;
			strMsg += str;
			strMsg += _T("\n");
			str.Format(_T(""));
		}
	}

	return bRet;
}

BOOL DHandlerInput::IsMPG()
{
	BOOL bRet = 0;

	if( m_sSysSensor.nMPGMode > 0 )
		bRet = TRUE;
	else
		bRet = FALSE;

	return bRet;
}

