#ifndef __HIGHRESOLUTION_TIMER__
#define __HIGHRESOLUTION_TIMER__

class CTimer
{
private :
	BOOL	_Available;
	__int64 _Frequency;
	__int64 _start, _finish;

public :
	CTimer() : _start(0), _finish(0)
	{
		// get the frequency of the counter
		_Available = QueryPerformanceFrequency((LARGE_INTEGER *)&_Frequency);
	}

	BOOL Start()    // start timing
	{
		if (!_Available)
			return FALSE;   // error - couldn't get frequency
		// get the starting counter value
		return QueryPerformanceCounter((LARGE_INTEGER*)&_start);
	}

    double Finish()    // stop timing and get elapsed time in seconds
	{
		if (!_Available || 0 == _start)
			return 0.0;
		// get the ending counter value
		QueryPerformanceCounter((LARGE_INTEGER *)&_finish);
		// convert counts to time in seconds and return it
		return (double)(_finish - _start)/_Frequency;
	}

	BOOL Available()	{ return _Available; }

    __int64 Frequency()	{ return _Frequency; }
};
extern CTimer gInspectionTimer;

#endif // __HIGHRESOLUTION_TIMER__
