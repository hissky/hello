// BicubicSpline.h: interface for the CBicubicSpline class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BICUBICSPLINE_H__F18043D2_6A70_4FBA_BB3A_68A864E9013A__INCLUDED_)
#define AFX_BICUBICSPLINE_H__F18043D2_6A70_4FBA_BB3A_68A864E9013A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

class CBicubicSpline : public CCalibration  
{
public:
	CBicubicSpline();
	virtual ~CBicubicSpline();

protected:
	DPOINT* m_Deriv;
	double *m_dVal, *m_dDeriv, *m_yytmp, *m_ytmp, *m_u;

	DPOINT *m_d1, *m_d2, *m_d3, *m_d4;
	int m_nXStart, m_nXEnd, m_nYStart, m_nYEnd;

	void UpdateWholeCalibration();
	
	void GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	void GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	
	void Spline1D(double* dOffset, const double& dStartDeriv, const double& dEndDeriv, double* dDeriv, int nSize);
	void GetSpline1D(double* dOffset, double* dDeriv, const double& dStart, const double& dPos, double& dVal, int nSize);
	BOOL Spline2D();

	void MemoryDelete();
};

#endif // !defined(AFX_BICUBICSPLINE_H__F18043D2_6A70_4FBA_BB3A_68A864E9013A__INCLUDED_)
