#if !defined(AFX_DLGMEASURINGPCBTHICKNESS_H__56FFB696_DEF2_48BA_9DD0_C58021969A3E__INCLUDED_)
#define AFX_DLGMEASURINGPCBTHICKNESS_H__56FFB696_DEF2_48BA_9DD0_C58021969A3E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgMeasuringPCBThickness.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "..\model\dpoint.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgMeasuringPCBThickness dialog

#include "..\alarmmsg.h"
#include "..\device\HHeightSensor.h"

class CDlgMeasuringPCBThickness : public CDialog
{
// Construction
public:
	int			m_nSelectHead;
	CDlgMeasuringPCBThickness(CWnd* pParent = NULL);   // standard constructor

	BOOL		m_bZCalEnable;
	BOOL		m_bEnableHeadSelect;
	BOOL		m_bChangeAcryl;

	void		InitBtnControl();
	void		InitStaticControl();
	void		InitEditControl();
	void		InitListBoxControl();
	void		InitComboControl();

	double		GetMeasuringThickness()		{ return m_dThickness; }
	void		SetMeasurementPos(DPOINT* pdPos);

	void		SetBaseZ(double dBaseZ, double dBaseZ2);
	void		SetPosition(double dX, double dY, double dZ1, double dZ2);
	double		GetHeight(BOOL b1st = TRUE);
	void		AutoStart();

	void		AutoSelectHead(int nHead);
	void		SelectHead(int nHead);
	void		ChangeHeadSelectStatus(BOOL bEnable);

	void		SetupText();
	void		DisplayHeight(double dValue, BOOL b1st = TRUE);
	void		AddList(CString strList);
	BOOL		GetHeightSensor(BOOL bFirst, BOOL bDown);
	void		OnCheckStop(STDGNALM nID);

// Dialog Data
	//{{AFX_DATA(CDlgMeasuringPCBThickness)
	enum { IDD = IDD_DLG_MEASURING_PCB_THICKNESS };
	CColorEdit	m_edtPosY;
	CColorEdit	m_edtPosX;
	CComboBox	m_cmbSelectHead;
	CColorEdit	m_edt2ndThickness;
	UEasyButtonEx	m_btnClose;
	UEasyButtonEx	m_btnCancel;
	CListBox	m_lboxMsg;
	CColorEdit	m_edtThickness;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnStart;
	UEasyButtonEx	m_btnPosition;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgMeasuringPCBThickness)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntListBox;
	CFont		m_fntCombo;

	double		m_dThickness;
	double		m_d2ndThickness;

	DPOINT		m_dMeasurementPos;

	
	int			m_nSensorNum;
	int			m_nSelectHeadAuto;

	CString				m_strStatus[10];
	CString				m_strError[2];

	BOOL				m_bAutoStart;	
	BOOL				m_bIsHeight;
	int					m_nTimeID;
	int					m_nRunCount;
	int					m_nHeightPos;
	int					m_nHeightPos2;
//	int					m_nSleepCount;
	double				m_dHeight;
	double				m_dHeight2;
	double				m_dBaseZ;
	double				m_dBaseZ2;

	double				m_dOldX;
	double				m_dOldY;
	double				m_dOldZ;
	double				m_dOldZ2;
	double				m_dNewX;
	double				m_dNewY;
	double				m_dNewZ1;
	double				m_dNewZ2;

	BOOL				m_bOnTimer;
	double				m_dMinMaxValue[4];  //0 = 1st min, 1 = 1st max, 2 = 2nd min, 3 = 2nd max

	// Generated message map functions
	//{{AFX_MSG(CDlgMeasuringPCBThickness)
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonMeasuringStart();
	afx_msg void OnButtonMeasuringStop();
	virtual void OnOK();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	afx_msg void OnButtonPosition();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMEASURINGPCBTHICKNESS_H__56FFB696_DEF2_48BA_9DD0_C58021969A3E__INCLUDED_)
