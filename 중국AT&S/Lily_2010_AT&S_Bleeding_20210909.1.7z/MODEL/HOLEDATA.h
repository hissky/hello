// HOLEDATA.h: interface for the HOLEDATA class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_)
#define AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxtempl.h>
#define  MAX_UNIT_NO		1000
#define  MAX_UNIT_NOM		9999
class HOLEDATA  
{
public:
//	void operator delete(void* p);
//	void* operator new(size_t nSize);
//	void* operator new(size_t nSize, LPCSTR lpszFileName, int nLine);
//	void  operator delete(void* p, LPCSTR lpszFileName, int nLine);

	HOLEDATA();
	virtual ~HOLEDATA()
	{
	};

	int		nBlockName2;
	char		cIsPattern;
	int		nToolNo;
	CPoint		npPos;

	int		nUnitIndex;
	int		nRotate;
	int		nFidIndex[4][2]; // 4�� Fiducial�� Main, Sub index
	BOOL		bSelect;

	HOLEDATA*   pNext;
	HOLEDATA*	pBefore;
	int			nFidBlock; //20111123 bskim 
	int			nOCRType;
};

typedef HOLEDATA*	LPHOLEDATA;
typedef CTypedPtrList <CPtrList, LPHOLEDATA>	OriginHoleList;

class HOLEDATAUNIT  
{
public:
	HOLEDATAUNIT()
	{
		m_nUnitCount = 0;
	}
	virtual ~HOLEDATAUNIT()
	{
	};
	HOLEDATA m_HoleUnitList[MAX_UNIT_NO];
	int m_nUnitCount;
};
typedef HOLEDATAUNIT*	LPHOLEDATAUNIT;  

typedef CArray <LPHOLEDATAUNIT, LPHOLEDATAUNIT>	CHoleList;

class HoleDataList
{
public:
	void RemoveAt(POSITION pos);
	void RemoveAll();
	LPHOLEDATA AddTail(HOLEDATA pData);
	LPHOLEDATA GetNext(POSITION& pos);
	POSITION GetHeadPosition();
	int GetCount();
	HoleDataList();
	virtual ~HoleDataList();

private:
	HOLEDATA* m_pHeadHoleData;
	HOLEDATA* m_pTailHoleData;
	CHoleList m_List;
	int m_nCount;
	int m_nAddCount;
};

#endif // !defined(AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_)
