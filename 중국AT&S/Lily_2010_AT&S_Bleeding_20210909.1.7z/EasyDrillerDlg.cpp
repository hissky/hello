	// EasyDrillerDlg.cpp : implementation file
	//

	#include "stdafx.h"
	#include "EasyDriller.h"
	#include "EasyDrillerDlg.h"
	#include <direct.h>
	#include "atlImage.h"

	#include "ui\DlgLogin.h"
	#include "ui\DlgIniInfo.h"

	#include "model\DEasyDrillerINI.h"
	#include "model\DSystemINI.h" 
	#include "model\DProcessINI.h"
	#include "model\EasyDrillerINIFile.h"
	#include "model\ProcessINIFile.h"
	#include "model\SystemINIFile.h"
	#include "model\BeamPathINIFile.h"
	#include "model\DBeampathINI.h"
	#include "model\DTempINI.h"
	#include "model\TempINIFile.h"
	#include "model\ShotTableINIFile.h"
	#include "model\DShotTableINI.h"

	#include "UI\DlgShotTable.h"
	#include "UI\DlgBeamPathTable.h"	
	#include "UI\DlgMotorMove.h"	

	// Main Pane
	#include "UI\PaneMainMenu.h"
	#include "UI\PaneRecipeGen.h"
	#include "UI\PaneAutoRun.h"
	#include "UI\PaneManualControl.h"
	#include "UI\PaneProcessSetup.h"
	#include "UI\PaneSysSetup.h"
	#include "UI\PaneLogManager.h"
	#include "UI\PaneUserAccount.h"
	#include "UI\PaneDrillDisplay.h"

	// Sub Pane
	#include "UI\PaneAutoRunSub.h"
	#include "UI\PaneRecipeGenSub.h"
	#include "UI\PaneManualDrillSub.h"
	#include "UI\PaneManualControlSub.h"
	#include "UI\PaneProcessSetupSub.h"
	#include "UI\PaneSysSetupSub.h"
	#include "UI\PaneLogManagerSub.h"
	#include "UI\PaneUserAccountSub.h"
	#include "UI\PaneDrillDisplaySub.h"
	#include "UI\PaneMotorSetupSub.h"


	// Sub Pane2
	#include "UI\DlgFiducialView.h"


		#include "UI\PaneSubMotorPositionLarge.h"
		#include "UI\PaneSysSetupLaserScannerLarge.h"
		




		#include "ui\DlgAlarmPLCLarge.h"
	


#include "UI\PaneManualControlMotorLarge.h"

	#include "ui\PaneAutoRunViewData.h"
	#include "UI\DlgVisionView.h"
	#include "UI\DlgMatroxVisionView.h"
	#include "UI\DlgVisionProView.h"
	#include "UI\DlgMelsecIO.h"

	#include "InterfaceUserAccountModule.h"
	#include "InterfaceErrListModule.h"
	#include "InterfaceMP920Module.h"

	#include "device\HDeviceFactory.h"
	
	#include "device\DeviceMotor.h"
	#include "device\HVision.h"
	#include "device\HVisionOmi.h"

	#include "UI\PaneManualControlPowerMeasurement.h"
	#include "UI\PaneManualControlIO.h"
	#include "UI\PaneManualControlDevice.h"
	#include "UI\PaneManualControlScannerCalibration.h"
	#include "UI\PaneManualControlVision.h"

	#include "UI\PaneManualControlOneHoleLarge.h"
	
	#include "UI\PaneManualControlLaserUV.h"
	#include "UI\PaneSysSetupTableCal.h"

	#include "UI\PaneSysSetupZCal.h"
	#include "UI\PaneSysSetupThetaCal.h"
	#include "UI\PaneSysSetupComponentTime.h"
	#include "UI\PaneSysSetupComponentTimeAlarm.h"
	#include "UI\DlgCalResult.h"
	#include "UI\PaneRecipeGenFiducialNew.h"
	#include "UI\PaneAutoRunViewFiducial.h"



	#include "UI\PaneManualControlIO.h"

	#include "device\DeviceMotor.h"
	#include "alarmmsg.h"

	#include <math.h>

	#include "ui\MGCView.h"
	#include "ui\SelectionView.h"
	#include "ui\TestThumnailView.h"
	#include "ui\DlgInformationBox.h"

	#include "ui\PaneManualControlLaser.h"

	#include "ui\PaneAutoRunViewPrework.h"
	#include "ui\PaneAutoRunViewPreworkPower.h"
	#include "ui\PaneAutoRunViewPreworkScanner.h"
	#include "ui\PaneAutoRunViewSystem.h"
	#include "model\globalvariable.h"
	#include "device\hlaser.h"
	#include "device\CalViaHole.h"
	#include "ui\ProgressWnd.h"

	#include "ui\DlgInputTemp.h"

#include "Tlhelp32.h"
#include <io.h> //2015.06.25 ���丮 �˻��� ����

	#ifdef _DEBUG
	#define new DEBUG_NEW
	#undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
	#endif

	#define LILY_SIZE 1280
	#define FIDUCIAL_ALL_VIEW_SIZE 470
	HANDLE g_hLogFile = ::CreateEvent(NULL, TRUE, TRUE, NULL);
	HANDLE g_hLotFile = ::CreateEvent(NULL, TRUE, TRUE, NULL);
	BOOL CEasyDrillerDlg::m_bOPCFirst = TRUE;

	/////////////////////////////////////////////////////////////////////////////
	// CAboutDlg dialog used for App About

	class CAboutDlg : public CDialog
	{
	public:
		CAboutDlg();

	// Dialog Data
		//{{AFX_DATA(CAboutDlg)
		enum { IDD = IDD_ABOUTBOX };
		//}}AFX_DATA

		// ClassWizard generated virtual function overrides
		//{{AFX_VIRTUAL(CAboutDlg)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		//{{AFX_MSG(CAboutDlg)
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()
	};

	CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
	{
		//{{AFX_DATA_INIT(CAboutDlg)
		//}}AFX_DATA_INIT
	}

	void CAboutDlg::DoDataExchange(CDataExchange* pDX)
	{
		CDialog::DoDataExchange(pDX);
		//{{AFX_DATA_MAP(CAboutDlg)
		//}}AFX_DATA_MAP
	}

	BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
		//{{AFX_MSG_MAP(CAboutDlg)
			// No message handlers
		//}}AFX_MSG_MAP
	END_MESSAGE_MAP()

	/////////////////////////////////////////////////////////////////////////////
	// CEasyDrillerDlg dialog

	CEasyDrillerDlg::CEasyDrillerDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CEasyDrillerDlg::IDD, pParent)
	{
		//{{AFX_DATA_INIT(CEasyDrillerDlg)
			// NOTE: the ClassWizard will add member initialization here
		//}}AFX_DATA_INIT
		// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
		m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

		// Main Pane
		m_pMainMenu			= NULL;
		m_pRecipeGen		= NULL;
		m_pAutoRun			= NULL;
		m_pManualControl	= NULL;
		m_pProcessSetup		= NULL;
		m_pSysSetup			= NULL;
		m_pLog				= NULL;
		m_pUserAccount		= NULL;
		m_hUserAccount		= NULL;
		m_pDrillDisplay		= NULL;
		m_hMotorSetup		= NULL;

		// Sub Pane
		m_pAutoRunSub		= NULL;
		m_pRecipeGenSub		= NULL;
		m_pManualDrillSub	= NULL;
		m_pManualControlSub	= NULL;
		m_pProcessSetupSub	= NULL;
		m_pSysSetupSub		= NULL;
		m_pLogManagerSub	= NULL;
		m_pUserAccountSub	= NULL;
		m_pDrillDisplaySub	= NULL;
		m_pMotorSetupSub	= NULL;

		m_pVisionView		= NULL;
		m_pVisionProView	= NULL;
		m_pMatroxVisionView = NULL;

		m_pDlgShow4Way = NULL;
		m_dlgFiducialAllView = NULL;
		m_pOpc = NULL;

		m_nUserLevel		= 0;
		hidden_point		= 0;
		m_bRegenIO			= FALSE;
		m_nTimer1			= -1;
		m_nBMInitialCount	= 0;
		m_nLockCnt			= 0;
		m_nLogCopyCnt		= 0;
		m_bLocked			= FALSE;
		m_bLogIned			= FALSE;
		m_bVisionSide		= FALSE;
		m_bShowIdleDlg		= FALSE;
		m_bLogCopy			= TRUE;
		m_ctTime			= CTime::GetCurrentTime();
		m_nStartTime		= m_ctTime.GetHour();
		m_nIdleRepeatCount	= 20;
		m_pOPCHandle		= NULL;
		::InitializeCriticalSection( &m_CritLog );
		theDlg				= this;
		m_bShowEasyTestDlg = FALSE;
	}

	void CEasyDrillerDlg::DoDataExchange(CDataExchange* pDX)
	{
		CDialog::DoDataExchange(pDX);
		//{{AFX_DATA_MAP(CEasyDrillerDlg)
		DDX_Control(pDX, IDC_BUTTON_MOTOR_SETUP, m_btnMotorSetup);
		DDX_Control(pDX, IDC_BUTTON_ERR_LIST, m_btnErrList);
		DDX_Control(pDX, IDC_BUTTON_INI_CHANGE, m_btnIniChange);
		DDX_Control(pDX, IDC_STATIC_CAD_FILE, m_stcCadFileName);
		DDX_Control(pDX, IDC_BUTTON_SYSTEM_SETUP, m_btnSystemSetup);
		DDX_Control(pDX, IDC_BUTTON_PROCESS_SETUP, m_btnProcessSetup);
		DDX_Control(pDX, IDC_BUTTON_MANUAL_OPERATION, m_btnManualOperation);
		DDX_Control(pDX, IDC_BUTTON_LOCK, m_btnLock);
		DDX_Control(pDX, IDC_BUTTON_LOGOUT, m_btnLogout);
		DDX_Control(pDX, IDC_BUTTON_LOG_MANAGER, m_btnLogManager);
		DDX_Control(pDX, IDC_BUTTON_DRILL, m_btnDrill);
		DDX_Control(pDX, IDC_STATIC_CAD_NAME, m_stcCadName);
		DDX_Control(pDX, IDC_STATIC_PRJ_NAME, m_stcPrjName);
		DDX_Control(pDX, IDC_STATIC_MSG, m_stcMsg);
		DDX_Control(pDX, IDC_STATIC_MSG_IDLE, m_stcMsgIdle);
		DDX_Control(pDX, IDC_STATIC_SAFETY_MSG, m_stcSafety);
		DDX_Control(pDX, IDOK, m_btnExit);
		DDX_Control(pDX, IDC_BUTTON_USER_ACCOUNT, m_btnUserAccount);
		DDX_Control(pDX, IDC_BUTTON_LOGIN, m_btnLogin);
		DDX_Control(pDX, IDC_STATIC_TIME, m_stcDigitTime);
		DDX_Control(pDX, IDC_BUTTON_ALARM, m_btnAlarm);
		DDX_Control(pDX, IDC_BUTTON_PLC_ERROR, m_btnErrPLC);

		DDX_Control(pDX, IDC_BUTTON_OPEN_BEAMPATH_TABLE, m_btnBeampath);
		DDX_Control(pDX, IDC_BUTTON_OPEN_SHOT_TABLE, m_btnShot);
		DDX_Control(pDX, IDC_BUTTON_OPEN_MOVE_MOTOR, m_btnMoveMotor);
		
	//	DDX_Control(pDX, IDC_COMIMOTIONCTRL1, m_ctrlMotion);
	//	DDX_Control(pDX, IDC_COMIDAQCTRL1, m_ctrlDaq);
		//}}AFX_DATA_MAP
	}

	BEGIN_MESSAGE_MAP(CEasyDrillerDlg, CDialog)
		//{{AFX_MSG_MAP(CEasyDrillerDlg)
		ON_WM_SYSCOMMAND()
		ON_WM_PAINT()
		ON_WM_QUERYDRAGICON()
		ON_BN_CLICKED(IDC_BUTTON_LOGIN, OnButtonLogin)
		ON_BN_CLICKED(IDC_BUTTON_USER_ACCOUNT, OnButtonUserAccount)
		ON_BN_CLICKED(IDC_BUTTON_DRILL, OnButtonDrill)
		ON_BN_CLICKED(IDC_BUTTON_MANUAL_OPERATION, OnButtonManualOperation)
		ON_BN_CLICKED(IDC_BUTTON_PROCESS_SETUP, OnButtonProcessSetup)
		ON_BN_CLICKED(IDC_BUTTON_SYSTEM_SETUP, OnButtonSystemSetup)
		ON_BN_CLICKED(IDC_BUTTON_LOG_MANAGER, OnButtonLogManager)
		ON_BN_CLICKED(IDC_BUTTON_LOGOUT, OnButtonLogout)
		ON_BN_CLICKED(IDC_BUTTON_LOCK, OnButtonLock)
		ON_BN_CLICKED(IDC_BUTTON_ERR_LIST, OnButtonErrList)
		ON_BN_CLICKED(IDC_BUTTON_INI_CHANGE, OnButtonIniChange)
		ON_BN_CLICKED(IDC_BUTTON_MOTOR_SETUP, OnButtonMotorSetup)
		ON_BN_CLICKED(IDC_BUTTON_ALARM, OnButtonErrorClear)
		ON_BN_CLICKED(IDC_BUTTON_PLC_ERROR, OnButtonErrPLC)
		ON_WM_LBUTTONDOWN()
		ON_WM_MOVE()
		ON_COMMAND(IDC_CHANGE_CAMERA1STHIGH, CameraChangeHigh1st)
		ON_COMMAND(IDC_CHANGE_CAMERA1STLOW, CameraChangeLow1st)
		ON_COMMAND(IDC_CHANGE_CAMERA2NDHIGH, CameraChangeHigh2nd)
		ON_COMMAND(IDC_CHANGE_CAMERA2NDLOW, CameraChangeLow2nd)
		//}}AFX_MSG_MAP
		ON_MESSAGE( CHANGE_PANE, OnChangePane )
		ON_MESSAGE( CHANGE_SUB_PANE, OnChangeSubPane )
		ON_MESSAGE( GET_BACK_PANE_NO, OnGetBackPaneNo )
		ON_MESSAGE( PROCESS_APPLY, OnApplyProcess )
		ON_MESSAGE( SYSTEM_APPLY, OnApplySystem )
		ON_MESSAGE(UM_LOG_MESSAGE, OnLogMessage)
		ON_MESSAGE( DRILL_START, OnDrillStart)
		ON_MESSAGE( DRILL_ONE_CYCLE, OnDrillOneCycle )
		ON_MESSAGE( DRILL_PAUSE, OnDrillPause )
		ON_MESSAGE( DRILL_STOP, OnDrillStop )
		ON_MESSAGE( SEND_ERR_MSG, OnSendErrMsg )
		ON_MESSAGE( UM_SAVE_INIFILE, OnSaveINIFile )
		ON_MESSAGE( UM_SYSTEMSUB_UI_CHANGE, OnSystemSubUIChange )
		ON_MESSAGE( UM_CHANGE_DATAFILE, OnChangeDataFile )
		ON_MESSAGE( UM_SET_ERR_MSG, OnSetErrMsg )
		ON_MESSAGE( UM_CONTROL_TAB_ENABLE, OnControlTabEnable )
		ON_MESSAGE( UM_DO_CALIBRATION, OnDoCalibration )
		ON_MESSAGE( UM_MODE_CHANGE, OnModeChange ) // 0: Normal, 1: SafetyMode, 2: IdleMode(AutoScal,Power���డ�� �����̸� Manual���� �Ұ�����)
		ON_MESSAGE( UM_SET_ERR_MSG_ID, OnSetErrMsgID )
		ON_MESSAGE( UM_WRITE_LOG, OnWriteLog )



		ON_MESSAGE( VISION_LIVE, OnVisionLive )
		ON_MESSAGE( UM_POWER_MEASURE, OnAutoPowerMeasure )
		ON_MESSAGE( UM_RESET_SWITCH, OnResetSwitch )
		ON_MESSAGE( UM_COMPONENT_PREACQTIME, OnComponentPreAcq )
		ON_MESSAGE( UM_DO_POWERMEASUREMENT, OnDoPowerMeasurement )
		ON_MESSAGE( UM_CHILLER_ALARM, OnChillerAlarm )
		ON_MESSAGE( UM_FID_FIND_RESULT, OnAddFidResult)
		ON_MESSAGE( UM_CHANGE_VIEW, OnChangeView )
		ON_MESSAGE( UM_CHANGE_PREWORK_STATUS, OnChangePrework )
		ON_MESSAGE( UM_POWER_RESULT , OnPowerResult )
		ON_MESSAGE( UM_SCANNER_RESULT, OnScannerResult )
		ON_MESSAGE( UM_DRAW_DOING_PREWORK, OnPreDoingDraw )
		ON_MESSAGE( UM_DO_APPLY_SCAL_RESULT, OnDoApplySCalResult )
		ON_MESSAGE( UM_DO_CHAGNE_SCAL_PREWORK, OnDoChangeSCalPreWorkInfo )
		ON_MESSAGE( UM_ANY_PREWORK, OnSetAnyPrework )
		ON_MESSAGE( DRILL_ONE_CYCLE_NOUNLOAD, OnDrillOneCycleNoUnload )
		ON_MESSAGE( UM_INI_UI_UPDATE, OnIniUIUpdate )
		ON_MESSAGE( UM_WINDOW_READY_FOR_FID_CAP, OnWindowReadyForFidCap)
		ON_MESSAGE( UM_SAFETY_MODE, OnEnableSafetyMode )
		ON_MESSAGE( UM_RESORT_AREA, OnResortArea)
		ON_MESSAGE( UM_SIDE_WINDOW, OnSideWindowShowHide)


		ON_MESSAGE( UM_REDRAW_TABLE_DATA, OnReDrawTableData)
		
		ON_MESSAGE( UM_SET_FID_BLOCK, OnSetFidBlock)

		ON_MESSAGE( UM_SET_PANE_NO, OnSetPaneNo)
		ON_MESSAGE( UM_SET_JOB_TIME, OnSetJobTime )
		ON_MESSAGE( UM_AUTO_BTN_CONTROL, OnAutoBtnControl )
		ON_MESSAGE( UM_STATR_BTN_CONTROL, StartBtnControl )

		ON_MESSAGE( UM_MAINUI_MOVE_TOPLEFT, OnMainUIMoveTopLeft)
		ON_MESSAGE( UM_PRJ_BACKUP_DELETE, OnOldProjectBackUpAndDelete)
		ON_MESSAGE( UM_RESIZE_VISION, OnResizeVision)
		ON_MESSAGE( UM_INPUT_FID_IMAGE, OnInputFidImage)
		ON_MESSAGE( UM_CAL_AUTO_SCAL_POS, OnCalAutoScalPos)
		ON_MESSAGE( UM_TABLE_MODE, OnChangeTableMode)
		ON_MESSAGE( UM_IDLE_MODE, OnIdleMode)
		ON_MESSAGE( UM_BUTTOM_MESSAGE, OnButtonMessage )


		ON_MESSAGE( UM_IDEL_POWER_START, OnIdlePower)
		ON_MESSAGE( UM_IDEL_SCAL_START, OnIdleScal)
		ON_MESSAGE( UM_IDEL_PREHEAT_START, OnIdlePreHeat)

		ON_MESSAGE( UM_SHOW_4WAY, OnShow4Way)

		ON_MESSAGE( UM_UPDATE_TAG, OnUpdateTag )
		ON_MESSAGE( UM_UPDATE_ERROR, OnUpdateError)
		ON_MESSAGE( UM_UPDATE_ERROR_CLEAR, OnUpdateErrorClear)
		ON_MESSAGE( UM_UPDATE_RECIPE, OnUpdateRecipe)
		ON_MESSAGE( UM_SET_CURRENT_LOTID, OnSetCurrentLotID )
		ON_MESSAGE( UM_OPC_STATUS, OnOPCStatus )
		ON_MESSAGE( UM_LOCK_BUTTON, OnLockButton )
		ON_BN_CLICKED(IDC_BUTTON_CHANGE_SIZE, &CEasyDrillerDlg::OnBnClickedButtonChangeSize)
		ON_BN_CLICKED(IDC_BUTTON_OPEN_BEAMPATH_TABLE, &CEasyDrillerDlg::OnBnClickedButtonOpenBeampathTable)
		ON_BN_CLICKED(IDC_BUTTON_OPEN_SHOT_TABLE, &CEasyDrillerDlg::OnBnClickedButtonOpenShotTable)
		ON_BN_CLICKED(IDC_BUTTON_OPEN_MOVE_MOTOR, &CEasyDrillerDlg::OnBnClickedButtonOpenMoveMotor)
		ON_MESSAGE(UM_SHOW_AUTOLOADER_INTERFACE, OnShowAutoLoaderInterface)
	END_MESSAGE_MAP()

	/////////////////////////////////////////////////////////////////////////////
	// CEasyDrillerDlg message handlers

	BOOL CEasyDrillerDlg::OnInitDialog()
	{
		CDialog::OnInitDialog();

		// Add "About..." menu item to system menu.

		// IDM_ABOUTBOX must be in the system command range.
		ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
		ASSERT(IDM_ABOUTBOX < 0xF000);

		CMenu* pSysMenu = GetSystemMenu(FALSE);
		if (pSysMenu != NULL)
		{
			CString strAboutMenu;
			strAboutMenu.LoadString(IDS_ABOUTBOX);
			if (!strAboutMenu.IsEmpty())
			{
				pSysMenu->AppendMenu(MF_SEPARATOR);
				pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
			}
		}

		memset(m_cButtonInfo, NULL, 256); // 20130522
		// Set the icon for this dialog.  The framework does this automatically
		//  when the application's main window is not a dialog
		SetIcon(m_hIcon, TRUE);			// Set big icon
		SetIcon(m_hIcon, FALSE);		// Set small icon
	
		// TODO: Add extra initialization here
		// Initialize Device Factory
	//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	//		gDeviceFactory.InitializeDevice(&m_ctrlMotion, &m_ctrlDaq);
	//	else
		if(gSystemINI.m_sSystemDevice.nCalGridMode)
			ErrMessage(_T("Calgrid Mode : Check system.ini [CALGRID MODE]"));

	#ifndef __NO_USE_OPC__	
		m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
		if(m_pOPCHandle == NULL)
		{
			ShellExecute(NULL, _T("open"), _T("C:\\SemOPCServer\\PtOpcSvr.exe"), NULL, NULL, SW_HIDE);
			Sleep(300);
		}
		else
		{
			DWORD ProcessID;
			GetWindowThreadProcessId(m_pOPCHandle->m_hWnd, &ProcessID);
			HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcessID);
			::TerminateProcess(hProcess, 0);

			while(m_pOPCHandle != NULL)
			{
				m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
				Sleep(100);
			}
			ShellExecute(NULL, _T("open"), _T("C:\\SemOPCServer\\PtOpcSvr.exe"), NULL, NULL, SW_HIDE);
			Sleep(300);
		}

		while(m_pOPCHandle == NULL)
		{
			m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
			Sleep(100);
		}
	
	#endif
		gDeviceFactory.InitializeDevice(NULL, NULL);
		WriteProcessLog(_T("Initialize Device End"), _T(""));
		// Custom Class ��� - ����
	

		if(m_bOPCFirst == TRUE)
		{
			m_pOpc = new COPCSvr;
			m_pOpc->Create(this);
			m_pOpc->ShowWindow(SW_HIDE);
			m_pOpc->Initialize();
		
			m_bOPCFirst = FALSE;
		}

		WriteProcessLog(_T("OPC End"), _T(""));

		if (CMGCView::RegisterMGCViewClass(::AfxGetApp()->m_hInstance) == FALSE)
		{
			CDlgInformationBox dlgInformationBox;
			dlgInformationBox.SetTitleContent(_T("ERROR"), _T("Cannot Register MGCView Class."));
		
			dlgInformationBox.DoModal();
		
			return FALSE;
		}
	
		if (CSelectionView::RegisterSelectionViewClass(::AfxGetApp()->m_hInstance) == FALSE)
		{
			CDlgInformationBox dlgInformationBox;
			dlgInformationBox.SetTitleContent(_T("ERROR"), _T("Cannot Register SelectionView Class."));
		
			dlgInformationBox.DoModal();
		
			return FALSE;
		}
	
		if (CTestThumnailView::RegisterTestThumnailViewClass(::AfxGetApp()->m_hInstance) == FALSE)
		{
			CDlgInformationBox dlgInformationBox;
			dlgInformationBox.SetTitleContent(_T("ERROR"), _T("Cannot Register TestThumbnail Class."));
		
			dlgInformationBox.DoModal();
		
			return FALSE;
		}
		// Custom Class ��� - ��
		WriteProcessLog(_T("Custom Class Regist End"), _T(""));
		// Create Vision
		if( NULL == m_pVisionView && gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
		{
			//		m_pVisionView = new CDlgVisionView;
			//		m_pVisionView->Create( this );
			//		m_pVisionView->ShowWindow(SW_HIDE);
			m_pVisionView = gDeviceFactory.GetVision()->m_pVisionHandle;
			m_pVisionView->ShowWindow(SW_HIDE);
			//		m_pVisionView->SetWindowPos(&this->wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
		}

		if( NULL == m_pVisionProView && gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
			m_pVisionProView = new CDlgVisionProView;
			m_pVisionProView->Create( this );
			m_pVisionProView->ShowWindow(SW_HIDE);
		}

		// Create matrox vision
		if( NULL == m_pMatroxVisionView && gSystemINI.m_sHardWare.nVisionType == MATROX_VISION )
		{
			m_pMatroxVisionView = new CDlgMatroxVisionView;
			m_pMatroxVisionView->Create( this );
			m_pMatroxVisionView->ShowWindow(SW_HIDE);
		}

		WriteProcessLog(_T("Vision Pro View End"), _T(""));
		

		//create motor class & wide vision dlg
	//	m_dlgSideVision.Create(IDD_DLG_SIDE_VISION);
	//	m_dlgSideVision.ShowWindow(SW_HIDE);
	
		m_dlgSideMotor.Create(IDD_DLG_MOTOR_MOVE);
		m_dlgSideMotor.SetDisplayOn(FALSE);
		m_dlgSideMotor.ShowWindow(SW_HIDE);

		m_dlgLpc.Create(IDD_DLG_LPC_VIEW);
		m_dlgLpc.ShowWindow(SW_HIDE);



	//	m_dlgFiducialAllView.Create(IDD_DLG_FIDUCIAL_VIEWER);
	//	m_dlgFiducialAllView.ShowWindow(SW_HIDE);

		m_dlgTable.Create(IDD_DLG_TABLE_VIEW);
		m_dlgTable.SetDisplayOn(FALSE);
		m_dlgTable.ShowWindow(SW_HIDE);



		m_dlgSelectedToolEdit.Create(IDD_DLG_SELECTED_TOOL_TABLE);
		m_dlgSelectedToolEdit.ShowWindow(SW_HIDE);

		m_dlgAutoLoaderInterface.Create(IDD_DLG_AUTO_LOADER_IF_SIGNAL);
		m_dlgAutoLoaderInterface.ShowWindow(SW_HIDE);

		memcpy( &gVariable.m_sgBeamPath, &gBeamPathINI.m_sBeampath, sizeof(gVariable.m_sgBeamPath) );	
		memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );	

		gDProject.m_nDivRangeXDisp = AfxGetApp()->GetProfileInt(_T("Settings"), _T("DivRangeX"), 65);
		gDProject.m_nDivRangeYDisp = AfxGetApp()->GetProfileInt(_T("Settings"), _T("DivRangeY"), 65);

		InitBtnControl();
		InitStaticControl();
		InitPaneControl();
		InitSubPaneControl();
		InitSubPaneUtilityControl();
		InitSubPaneMotorPosition();

		WriteProcessLog(_T("Pane Add End"), _T(""));
	
		// Initialize Error List Database
		InitErrListDll(gSystemINI.m_sHardWare.nLanguageType);

		WriteProcessLog(_T("Init Err List Dll End"), _T(""));
		// Connect Omi Vision View
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnConnectView();
		pVision->OnCamChange( 0 );

		m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
		m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
		m_dlgOPCWait.ShowWindow(SW_HIDE);

		hidden_point = 0;
		GetDlgItem(IDC_STATIC_PRJ_NAME)->GetWindowRect(hidden_rect);
		GetDlgItem(IDC_STATIC_EOTECHNICS)->GetWindowRect(hidden_rect2);
		GetDlgItem(IDC_STATIC_CAD_NAME)->GetWindowRect(hidden_rect3);

		ScreenToClient( hidden_rect );
		ScreenToClient( hidden_rect2 );
		ScreenToClient( hidden_rect3 );

	#ifndef __MP920_MOTOR__
		GetDlgItem(IDC_BUTTON_MOTOR_SETUP)->EnableWindow(FALSE);
	#else
		GetDlgItem(IDC_BUTTON_MOTOR_SETUP)->EnableWindow(TRUE);
	#endif


		m_pDlgShow4Way = new CDlgShow4Way;
		m_pDlgShow4Way->Create( this );
		m_pDlgShow4Way->ShowWindow(SW_HIDE);

		WriteProcessLog(_T("Show 4Way End"), _T(""));

		if(m_pManualControl->m_pPowerMeasurement != NULL)
			m_pManualControl->m_pPowerMeasurement->ConnectPort();

		m_pAutoRun->InitTimer();
	
		if(gEasyDrillerINI.m_clsHwOption.m_nRepeatMode)
		{
			// file open
			CString strFile;
			strFile = ::AfxGetApp()->GetProfileString(_T("Files"), _T("Recent File"), _T(""));
			OpenRecentProject(strFile);
		}

		WriteProcessLog(_T("### Start Program ###"), _T(""));

	//	//old log file backup and del
		BackupOldLogFile();

		// 090805 shutter close
		ShutterMove(FALSE, FALSE);
	
		if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
		{
			gDeviceFactory.GetMotor()->HoodOpen(TRUE);
		}

		if(gSystemINI.m_sHardWare.nTableClamp == 0)
			gDeviceFactory.GetMotor()->NoUseClamp(TRUE);
		else
			gDeviceFactory.GetMotor()->NoUseClamp(FALSE);
	
		m_nTimer1 = ::SetTimer(this->m_hWnd, 529, 1000, NULL);

		::AfxGetMainWnd()->PostMessage(UM_MAINUI_MOVE_TOPLEFT);
		::AfxGetMainWnd()->SendMessage(UM_CAL_AUTO_SCAL_POS);
		// Set Window Title(version)
		SetLilyVersion();

		m_nIdleFireStatus = 0; // do not anything

		gVariable.m_bStartEasyDrillerDlg = TRUE;
		memset(&gLotInfo, 0, sizeof(gLotInfo));

		for(int k = 0; k<10; k++)
		{
			if(k%2 == 1)
				gLotInfo.nComSol[k] = 3;
			else
				gLotInfo.nComSol[k] = 2;

			
			gLotInfo.bUseOpenTool[k] = TRUE;
			
		}
		
		return TRUE;  // return TRUE  unless you set the focus to a control
	}

	void CEasyDrillerDlg::OnSysCommand(UINT nID, LPARAM lParam)
	{
		if ((nID & 0xFFF0) == IDM_ABOUTBOX)
		{
			CAboutDlg dlgAbout;
			dlgAbout.DoModal();
		}
		else
		{
			CDialog::OnSysCommand(nID, lParam);
		}
	}

	// If you add a minimize button to your dialog, you will need the code below
	//  to draw the icon.  For MFC applications using the document/view model,
	//  this is automatically done for you by the framework.

	void CEasyDrillerDlg::OnPaint() 
	{
		if (IsIconic())
		{
			CPaintDC dc(this); // device context for painting

			SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

			// Center icon in client rectangle
			int cxIcon = GetSystemMetrics(SM_CXICON);
			int cyIcon = GetSystemMetrics(SM_CYICON);
			CRect rect;
			GetClientRect(&rect);
			int x = (rect.Width() - cxIcon + 1) / 2;
			int y = (rect.Height() - cyIcon + 1) / 2;

			// Draw the icon
			dc.DrawIcon(x, y, m_hIcon);
		}
		else
		{
			CDialog::OnPaint();
		}
	}

	// The system calls this to obtain the cursor to display while the user drags
	//  the minimized window.
	HCURSOR CEasyDrillerDlg::OnQueryDragIcon()
	{
		return (HCURSOR) m_hIcon;
	}

	void CEasyDrillerDlg::OnCancel() 
	{
	//	CDialog::OnCancel();
	}

	BOOL CEasyDrillerDlg::	PreTranslateMessage(MSG* pMsg) 
	{
		if( WM_KEYDOWN == pMsg->message )
		{
			switch( pMsg->wParam )
			{
			case VK_RETURN :
				pMsg->wParam = 0;
				break;
			case VK_TAB :
				if( NULL != m_hUserAccount )
				{
					if( FALSE != ::IsWindowVisible( m_hUserAccount ) )
					{
						HWND hWnd = ::GetFocus();
						HWND hNextWnd = ::GetNextDlgTabItem( m_hUserAccount, hWnd, FALSE );
						::SetFocus( hNextWnd );

						return TRUE;
					}
				}
				break;
			}
		}
	
		if( WM_TIMER == pMsg->message  && this->m_hWnd == pMsg->hwnd)
		{

			if(!m_pAutoRun->IsDrilling() && gDeviceFactory.GetEocard()->IsStannbyShotRun() && gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				double dDummyTime = gDeviceFactory.GetEocard()->GetDummyFreeStart(); // sec
				double dTurnOffTime = gSystemINI.m_sSystemDump.nStandbyTurnOffTime * 60;
			
				double dMinTime = min(dDummyTime, m_pAutoRun->m_nDrillEndTime);
			
				if(dMinTime >= dTurnOffTime)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
					{
						ErrMsgDlg(STDGNALM781);
						return TRUE;
					}
	//				m_pAutoRun->m_nDrillEndTime = 0; // 20130819 bhLee �ǹ̾��� ������. �µ� �ɼ¿��� �̿��ϱ� ���� �ּ�ó��
					CString strMessage;
					strMessage.Format(_T("PCB Drill operation Time out : Turn Off DummyFree"));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));
				}	
			}

			if(!gDeviceFactory.GetMotor()->IsBMMotorHomeEnd())
			{
				m_nBMInitialCount++;
				if(gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_nBMInitialCount > 3)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
					{
						ErrMsgDlg(STDGNALM781);
						return TRUE;
					}
					m_nBMInitialCount = 0;
					CString strMessage;
					strMessage.Format(_T("B, M Initial : Turn Off DummyFree"));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));
				}
			}
			else
			{
				m_nBMInitialCount = 0;
			}
			m_nLockCnt++;
			if(m_nLockCnt > gSystemINI.m_sHardWare.nAutoLockTime && m_bLogIned)
			{
				OnButtonLock();
				m_nLockCnt = 0;
			}


			CTime ctNowtime = CTime::GetCurrentTime();//20130410 jghan
			int EndTime;
			EndTime= ctNowtime.GetHour();
			if(m_nStartTime == EndTime)
			{
				m_nStartTime = ctNowtime.GetHour();
#ifdef __NANYA_NEW__
				if (m_nStartTime == gProcessINI.m_sProcessOption.nLogCopyTime)
#else
                if (m_nStartTime == 8)
#endif				
				{
					m_bLogCopy = TRUE;
				}
				if(m_nStartTime == 23)
					m_nStartTime = 0;
				else
					m_nStartTime++;
			}
			if(!m_pAutoRun->IsDrilling() && m_bLogCopy)
			{	
					//LogCopy();
					m_bLogCopy = FALSE;
			}

			m_nLogCopyCnt++;
			if(m_nLogCopyCnt > 3600) //30 Min
			{
				//LogCopyDaily();
				m_nLogCopyCnt = 0;			
			}

			return TRUE;
		}

		if( WM_MOUSEMOVE == pMsg->message )
			m_nLockCnt = 0;
		return CDialog::PreTranslateMessage(pMsg);
	}

	void CEasyDrillerDlg::InitBtnControl()
	{
		// Set Button Font
		m_fntBtn.CreatePointFont(150, _T("Arial Bold"));
		m_fntBtnSmall.CreatePointFont(130, _T("Arial Bold"));
		m_fntBtnSmall2.CreatePointFont(110, _T("Arial Bold"));

		m_btnBeampath.SetFont( &m_fntBtnSmall2 );
		m_btnBeampath.SetFlat( FALSE );
		m_btnBeampath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnBeampath.EnableBallonToolTip();
		m_btnBeampath.SetToolTipText( _T("Show BeamPath Table") );
		m_btnBeampath.SetBtnCursor(IDC_HAND_1);

		m_btnShot.SetFont( &m_fntBtnSmall2 );
		m_btnShot.SetFlat( FALSE );
		m_btnShot.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnShot.EnableBallonToolTip();
		m_btnShot.SetToolTipText( _T("Show Shot Table") );
		m_btnShot.SetBtnCursor(IDC_HAND_1);

		m_btnMoveMotor.SetFont( &m_fntBtnSmall2 );
		m_btnMoveMotor.SetFlat( FALSE );
		m_btnMoveMotor.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnMoveMotor.EnableBallonToolTip();
		m_btnMoveMotor.SetToolTipText( _T("Show MoveMotor") );
		m_btnMoveMotor.SetBtnCursor(IDC_HAND_1);

		m_btnErrPLC.SetFont( &m_fntBtnSmall );
		m_btnErrPLC.SetFlat( FALSE );
		m_btnErrPLC.SetImageOrg( 8, 3 );
		m_btnErrPLC.SetIcon( IDI_ERRLIST );
		m_btnErrPLC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnErrPLC.EnableBallonToolTip();
		m_btnErrPLC.SetToolTipText( _T("Show PLC Alarm") );
		m_btnErrPLC.SetBtnCursor(IDC_HAND_1);

		m_btnAlarm.SetFont( &m_fntBtnSmall );
		m_btnAlarm.SetFlat( FALSE );
		m_btnAlarm.SetImageOrg( 8, 3 );
		m_btnAlarm.SetIcon( IDI_SOUND );
		m_btnAlarm.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnAlarm.EnableBallonToolTip();
		m_btnAlarm.SetToolTipText( _T("Error Clear") );
		m_btnAlarm.SetBtnCursor(IDC_HAND_1);

		m_btnLogin.SetFont( &m_fntBtn );
		m_btnLogin.SetFlat( FALSE );
		m_btnLogin.SetImageOrg( 15, 3 );
		m_btnLogin.SetIcon( IDI_LOGIN );
		m_btnLogin.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnLogin.EnableBallonToolTip();
		m_btnLogin.SetToolTipText( _T("User Login") );
		m_btnLogin.SetBtnCursor(IDC_HAND_1);

		m_btnUserAccount.SetFont( &m_fntBtn );
		m_btnUserAccount.SetFlat( FALSE );
		m_btnUserAccount.SetImageOrg( 15, 3 );
		m_btnUserAccount.SetIcon( IDI_USERACCOUNT );
		m_btnUserAccount.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnUserAccount.EnableBallonToolTip();
		m_btnUserAccount.SetToolTipText( _T("User Account") );
		m_btnUserAccount.SetBtnCursor(IDC_HAND_1);

		m_btnExit.SetFont( &m_fntBtn );
		m_btnExit.SetFlat( FALSE );
		m_btnExit.SetImageOrg( 15, 3 );
		m_btnExit.SetIcon( IDI_EXIT );
		m_btnExit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnExit.EnableBallonToolTip();
		m_btnExit.SetToolTipText( _T("Exit") );
		m_btnExit.SetBtnCursor(IDC_HAND_1);

		m_btnErrList.SetFont( &m_fntBtn );
		m_btnErrList.SetFlat( FALSE );
		m_btnErrList.SetImageOrg( 15, 3 );
		m_btnErrList.SetIcon( IDI_ERRLIST );
		m_btnErrList.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnErrList.EnableBallonToolTip();
		m_btnErrList.SetToolTipText( _T("Error List") );
		m_btnErrList.SetBtnCursor(IDC_HAND_1);
		m_btnErrList.ShowWindow( SW_HIDE );

		m_btnIniChange.SetFont( &m_fntBtn );
		m_btnIniChange.SetFlat( FALSE );
		m_btnIniChange.SetImageOrg( 15, 3 );
		m_btnIniChange.SetIcon( IDI_SYSSETUP48 );
		m_btnIniChange.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnIniChange.EnableBallonToolTip();
		m_btnIniChange.SetToolTipText( _T("Change critical Ini Value") );
		m_btnIniChange.SetBtnCursor(IDC_HAND_1);
		m_btnIniChange.ShowWindow( SW_HIDE );

		m_btnMotorSetup.SetFont( &m_fntBtn );
		m_btnMotorSetup.SetFlat( FALSE );
		m_btnMotorSetup.SetImageOrg( 15, 3 );
		m_btnMotorSetup.SetIcon( IDI_MANUAL );
		m_btnMotorSetup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnMotorSetup.EnableBallonToolTip();
		m_btnMotorSetup.SetToolTipText( _T("Motor Setup") );
		m_btnMotorSetup.SetBtnCursor(IDC_HAND_1);
		m_btnMotorSetup.ShowWindow( SW_HIDE );

		m_btnDrill.SetFont( &m_fntBtn );
		m_btnDrill.SetFlat( FALSE );
		m_btnDrill.SetImageOrg( 10, 3 );
		m_btnDrill.SetIcon( IDI_DRILL );
		m_btnDrill.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnDrill.EnableBallonToolTip();
		m_btnDrill.SetToolTipText( _T("Drill") );
		m_btnDrill.SetBtnCursor( IDC_HAND_1 );
		m_btnDrill.ShowWindow( SW_HIDE );

		m_btnManualOperation.SetFont( &m_fntBtn );
		m_btnManualOperation.SetFlat( FALSE );
		m_btnManualOperation.SetImageOrg( 10, 3 );
		m_btnManualOperation.SetIcon( IDI_MANUAL );
		m_btnManualOperation.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnManualOperation.EnableBallonToolTip();
		m_btnManualOperation.SetToolTipText( _T("Device Manual Control") );
		m_btnManualOperation.SetBtnCursor( IDC_HAND_1 );
		m_btnManualOperation.ShowWindow( SW_HIDE );

		m_btnProcessSetup.SetFont( &m_fntBtn );
		m_btnProcessSetup.SetFlat( FALSE );
		m_btnProcessSetup.SetImageOrg( 10, 3 );
		m_btnProcessSetup.SetIcon( IDI_PROCESSSETUP );
		m_btnProcessSetup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnProcessSetup.EnableBallonToolTip();
		m_btnProcessSetup.SetToolTipText( _T("Process Setup") );
		m_btnProcessSetup.SetBtnCursor( IDC_HAND_1 );
		m_btnProcessSetup.ShowWindow( SW_HIDE );

		m_btnSystemSetup.SetFont( &m_fntBtn );
		m_btnSystemSetup.SetFlat( FALSE );
		m_btnSystemSetup.SetImageOrg( 15, 3 );
		m_btnSystemSetup.SetIcon( IDI_SYSSETUP48, 48, 48 );
		m_btnSystemSetup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnSystemSetup.EnableBallonToolTip();
		m_btnSystemSetup.SetToolTipText( _T("System Setup") );
		m_btnSystemSetup.SetBtnCursor( IDC_HAND_1 );
		m_btnSystemSetup.ShowWindow( SW_HIDE );

		m_btnLock.SetFont( &m_fntBtn );
		m_btnLock.SetFlat( FALSE );
		m_btnLock.SetImageOrg( 15, 3 );
		m_btnLock.SetIcon( IDI_LOGOUT, 48, 48 );
		m_btnLock.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnLock.EnableBallonToolTip();
		m_btnLock.SetToolTipText( _T("System Lock") );
		m_btnLock.SetBtnCursor( IDC_HAND_1 );
		m_btnLock.ShowWindow( SW_HIDE );

		m_btnLogManager.SetFont( &m_fntBtn );
		m_btnLogManager.SetFlat( FALSE );
		m_btnLogManager.SetImageOrg( 15, 3 );
		m_btnLogManager.SetIcon( IDI_LOGMANAGER );
		m_btnLogManager.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnLogManager.EnableBallonToolTip();
		m_btnLogManager.SetToolTipText( _T("Log Manager") );
		m_btnLogManager.SetBtnCursor( IDC_HAND_1 );
		m_btnLogManager.ShowWindow( SW_HIDE );

		m_btnLogout.SetFont( &m_fntBtn );
		m_btnLogout.SetFlat( FALSE );
		m_btnLogout.SetImageOrg( 15, 3 );
		m_btnLogout.SetIcon( IDI_LOGOUT );
		m_btnLogout.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnLogout.EnableBallonToolTip();
		m_btnLogout.SetToolTipText( _T("Logout") );
		m_btnLogout.SetBtnCursor( IDC_HAND_1 );
		m_btnLogout.ShowWindow( SW_HIDE );

		GetDlgItem(IDC_STATIC_MENU)->ShowWindow( SW_HIDE );
		
	}

	void CEasyDrillerDlg::InitStaticControl()
	{
		// Set Static Font
		m_fntStatic.CreatePointFont(130, _T("Arial Bold"));
		m_fntStatic2.CreatePointFont(180, _T("Arial Bold"));

		// Pane Static
		GetDlgItem(IDC_STATIC_MAIN_PANE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_PANEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_PANEL_2ND)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUB_PANEL_3RD)->ShowWindow(SW_HIDE);

		// Digital Time
	//	m_stcDigitTime.SetStyle(CXJWDigitClock::XDC_SECOND);
	//	m_stcDigitTime.SetAlarm(FALSE);
	//	m_stcDigitTime.SetColor(RGB(0, 255, 0));
		m_stcDigitTime.Start(IDB_CLOCKST_PANE, IDB_CLOCKST_BIG, IDB_CLOCKST_SMALL);

		// Project Name
	//	m_stcPrjName.SetFont( &m_fntStatic );
		m_stcPrjName.SetForeColor( VALUE_FORE_COLOR );
		m_stcPrjName.SetBackColor( VALUE_BACK_COLOR );
		m_stcPrjName.SetWindowText( _T("Untitle.prj") );

		// Cad File Name
	//	m_stcCadFileName.SetFont( &m_fntStatic );
		m_stcCadFileName.SetForeColor( VALUE_FORE_COLOR );
		m_stcCadFileName.SetBackColor( VALUE_BACK_COLOR );
		m_stcCadFileName.SetWindowText( _T("Untitle.txt") );

		// Cad Name
		m_stcCadName.SetFont( &m_fntStatic );
		m_stcCadName.SetForeColor( VALUE_FORE_COLOR );
		m_stcCadName.SetBackColor( VALUE_BACK_COLOR );
		m_stcCadName.SetWindowText( _T("Operator Level") );

		// Message
		m_stcMsg.SetFont( &m_fntStatic );
		m_stcMsg.SetForeColor( RGB(255,0,0) );
		m_stcMsg.SetBackColor( LIGHT_BLUE_COLOR );
		m_stcMsg.SetWindowText( _T("No Message") );

		// Safety Message
		m_stcSafety.SetFont( &m_fntStatic2 );
		m_stcSafety.SetForeColor( RGB(255,0,0) );
		m_stcSafety.SetBackColor( LIGHT_BLUE_COLOR );
		m_stcSafety.SetWindowText( _T("Safety Mode On") );
		m_stcSafety.ShowWindow(FALSE);

		// Idle Message
		m_stcMsgIdle.SetFont( &m_fntStatic );
		m_stcMsgIdle.SetForeColor( RGB(255,0,0) );
		m_stcMsgIdle.SetBackColor( LIGHT_BLUE_COLOR );
		m_stcMsgIdle.SetWindowText( _T("**** Idle Mode ****") );
		m_stcMsgIdle.ShowWindow(FALSE);
	}

	void CEasyDrillerDlg::InitPaneControl()
	{
		CFormView* pPane = NULL;
		CRect rcPanePos;

		GetDlgItem(IDC_STATIC_MAIN_PANE)->GetWindowRect( rcPanePos );
		ScreenToClient( &rcPanePos );

		// Drill
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneAutoRun), DRILL );
		m_clsPaneArray.AddPane( pPane );
		m_pAutoRun		= DYNAMIC_DOWNCAST( CPaneAutoRun, pPane );
		m_pAutoRun->OnInitialUpdate();

		// Recipe Gen
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneRecipeGen), RECIPE_GEN );
		m_clsPaneArray.AddPane( pPane );
		m_pRecipeGen	= DYNAMIC_DOWNCAST( CPaneRecipeGen, pPane );
		m_pRecipeGen->OnInitialUpdate();

		// Motor Setup
		m_hMotorSetup = CreateMP920Setup( this->m_hWnd );
		if( NULL != m_hMotorSetup )
		{
			CRect rcPos;

			::GetWindowRect( m_hMotorSetup, &rcPos );
			ScreenToClient( &rcPos );
			rcPos += CPoint( rcPanePos.left, rcPanePos.top );
			::MoveWindow( m_hMotorSetup, rcPos.left, rcPos.top, rcPos.Width(), rcPos.Height(), TRUE );
			ShowMP920Setup(SW_HIDE);
		}

		// Manual Control
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneManualControl), MANUAL_CONTROL);
		m_clsPaneArray.AddPane( pPane );
		m_pManualControl	= DYNAMIC_DOWNCAST( CPaneManualControl, pPane );
		m_pManualControl->OnInitialUpdate();

		// Process Setup
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneProcessSetup), PROCESS_SETUP);
		m_clsPaneArray.AddPane( pPane );
		m_pProcessSetup	= DYNAMIC_DOWNCAST( CPaneProcessSetup, pPane );
		m_pProcessSetup->OnInitialUpdate();

		// System Setup
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneSysSetup), SYSTEM_SETUP);
		m_clsPaneArray.AddPane( pPane );
		m_pSysSetup	= DYNAMIC_DOWNCAST( CPaneSysSetup, pPane );
		m_pSysSetup->OnInitialUpdate();
		m_nBeamDumperNo = m_pSysSetup->m_nBeamDumperNo;

		// Log Manager
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneLogManager), LOG_MANAGER);
		m_clsPaneArray.AddPane( pPane );
		m_pLog	= DYNAMIC_DOWNCAST( CPaneLogManager, pPane );
		m_pLog->OnInitialUpdate();

		// Drill Display
		pPane = m_clsPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneDrillDisplay), DRILL_DISPLAY );
		m_clsPaneArray.AddPane( pPane );
		m_pDrillDisplay	= DYNAMIC_DOWNCAST( CPaneDrillDisplay, pPane );
		m_pDrillDisplay->OnInitialUpdate();

		// User Account
		m_hUserAccount = CreateUserAccount( this->m_hWnd );
		if( NULL != m_hUserAccount )
		{
			CRect rcPos;

			::GetWindowRect( m_hUserAccount, &rcPos );
			ScreenToClient( &rcPos );
			rcPos += CPoint( rcPanePos.left, rcPanePos.top );
			::MoveWindow( m_hUserAccount, rcPos.left, rcPos.top, rcPos.Width(), rcPos.Height(), TRUE );
			ShowUserAccount(SW_HIDE);
		}
	}

	void CEasyDrillerDlg::InitSubPaneControl()
	{
		CFormView* pPane = NULL;
		CRect rcPanePos;
	
		GetDlgItem(IDC_STATIC_SUB_PANEL)->GetWindowRect( rcPanePos );
		ScreenToClient( &rcPanePos );

		// Drill Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneAutoRunSub), DRILL_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pAutoRunSub	= DYNAMIC_DOWNCAST( CPaneAutoRunSub, pPane );
		m_pAutoRunSub->OnInitialUpdate();
	
		// Recipe Gen Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneRecipeGenSub), RECIPE_GEN_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pRecipeGenSub	= DYNAMIC_DOWNCAST( CPaneRecipeGenSub, pPane );
		m_pRecipeGenSub->OnInitialUpdate();

		// Fiducial Setting Sub 
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneManualDrillSub), FIDUCIAL_SETTING_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pManualDrillSub	= DYNAMIC_DOWNCAST( CPaneManualDrillSub, pPane );
		m_pManualDrillSub->OnInitialUpdate();
		m_pManualDrillSub->SetVisionTab(m_pManualControl->GetVisionTab());

		// Manual Control Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CPaneManualControlSub), MANUAL_CONTROL_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pManualControlSub	= DYNAMIC_DOWNCAST( CPaneManualControlSub, pPane );
		m_pManualControlSub->OnInitialUpdate();

		// Process Setup Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneProcessSetupSub ), PROCESS_SETUP_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pProcessSetupSub = DYNAMIC_DOWNCAST( CPaneProcessSetupSub, pPane );
		m_pProcessSetupSub->OnInitialUpdate();

		// System Setup Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneSysSetupSub ), SYSTEM_SETUP_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pSysSetupSub	= DYNAMIC_DOWNCAST( CPaneSysSetupSub, pPane );
		m_pSysSetupSub->OnInitialUpdate();
		m_pSysSetupSub->m_nBeamDumperNo = m_nBeamDumperNo;

		// Log Manager Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneLogManagerSub ), LOG_MANAGER_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pLogManagerSub	= DYNAMIC_DOWNCAST( CPaneLogManagerSub, pPane );
		m_pLogManagerSub->OnInitialUpdate();

		// User Account Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneUserAccountSub ), USER_ACCOUNT_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pUserAccountSub	= DYNAMIC_DOWNCAST( CPaneUserAccountSub, pPane );
		m_pUserAccountSub->OnInitialUpdate();

		// Drill Display Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneDrillDisplaySub ), DRILL_DISPLAY_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pDrillDisplaySub	= DYNAMIC_DOWNCAST( CPaneDrillDisplaySub, pPane );
		m_pDrillDisplaySub->OnInitialUpdate();

		// Motor Setup Sub
		pPane = m_clsSubPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS( CPaneMotorSetupSub ), MOTOR_SETUP_SUB );
		m_clsSubPaneArray.AddPane( pPane );
		m_pMotorSetupSub = DYNAMIC_DOWNCAST( CPaneMotorSetupSub, pPane );
		m_pMotorSetupSub->OnInitialUpdate();
	}

	void CEasyDrillerDlg::InitSubPaneUtilityControl()
	{
		CFormView* pPane = NULL;
		CRect rcPanePos;

		GetDlgItem(IDC_STATIC_SUB_PANEL_3RD)->GetWindowRect( rcPanePos );
		ScreenToClient( &rcPanePos );

		// Fiducial all view
		pPane = m_clsUtiliyPaneArray.CreatePane( this, rcPanePos, RUNTIME_CLASS(CDlgFiducialView), FIDUCIAL_ALL_VIEW );
		m_clsUtiliyPaneArray.AddPane( pPane );
		m_dlgFiducialAllView = DYNAMIC_DOWNCAST( CDlgFiducialView, pPane );
		m_dlgFiducialAllView->OnInitialUpdate();

		m_clsUtiliyPaneArray.SelectPane(0);

		ChangeLilySize(FALSE);
	}

	void CEasyDrillerDlg::InitSubPaneMotorPosition()
	{
		CFormView* pPane = NULL;
		CRect rcPanePos;
	
		GetDlgItem(IDC_STATIC_SUB_PANEL_2ND)->GetWindowRect( rcPanePos );
		ScreenToClient( &rcPanePos );


	#ifdef __KUNSAN_SAMSUNG_LARGE__ 
		CWnd* pWnd	= DYNAMIC_DOWNCAST( CWnd, RUNTIME_CLASS(CPaneSubMotorPositionLarge)->CreateObject() );		
		pWnd->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), this, 0x01, NULL );
		pPane	= DYNAMIC_DOWNCAST( CFormView, pWnd );
	
		CSize szSize = pPane->GetTotalSize();
		CRect rcPane;
	
		rcPane.top		= rcPanePos.top;
		rcPane.left		= rcPanePos.left;
		rcPane.right	= rcPanePos.left + szSize.cx;
		rcPane.bottom	= rcPanePos.top + szSize.cy;
	
		pPane->MoveWindow( rcPane );
	
		m_pSubMotorPosition = DYNAMIC_DOWNCAST( CPaneSubMotorPositionLarge, pPane );
		m_pSubMotorPosition->OnInitialUpdate();
	#endif

	}

	void CEasyDrillerDlg::SetErrorMsg(CString strMsg)
	{
		m_stcMsg.SetWindowText( (LPCTSTR)strMsg );
		WriteProcessLog(strMsg, _T(""), TRUE);
	}

	void CEasyDrillerDlg::SetPrjName(CString strName)
	{
		m_stcPrjName.SetWindowText( (LPCTSTR)strName );
		strcpy_s(m_pAutoRun->m_cPrjName, strName);
	}
	CString CEasyDrillerDlg::GetPrjName()
	{
		CString strName;
		m_stcPrjName.GetWindowText(strName);
		return strName;
	}
	void CEasyDrillerDlg::SetDataName(CString strName)
	{
		m_stcCadFileName.SetWindowText( (LPCTSTR)strName );
	}

	CString CEasyDrillerDlg::GetDataName()
	{
		CString m_strCadFileName;
		m_stcCadFileName.GetWindowText(m_strCadFileName);
		return m_strCadFileName;
	}

	void CEasyDrillerDlg::ShowBtnControl(BOOL bShow)
	{
		if( FALSE == bShow )
		{
			m_btnLogin.ShowWindow( SW_HIDE );
#ifndef __SERVER_PC__
			m_btnUserAccount.ShowWindow( SW_HIDE );
#endif
			m_btnExit.ShowWindow( SW_HIDE );
			m_btnErrList.ShowWindow( SW_HIDE );
			m_btnIniChange.ShowWindow( SW_HIDE );
			m_btnMotorSetup.ShowWindow( SW_HIDE );
			m_pSubMotorPosition->DestroyTimer();

			/*m_btnDrill.ShowWindow( SW_SHOW );
			m_btnManualOperation.ShowWindow( SW_SHOW );
			m_btnProcessSetup.ShowWindow( SW_SHOW );
			m_btnSystemSetup.ShowWindow( SW_SHOW );
			m_btnLogManager.ShowWindow( SW_SHOW );
			m_btnLogout.ShowWindow( SW_SHOW );
			GetDlgItem(IDC_STATIC_MENU)->ShowWindow( SW_SHOW );*/
		}
		else
		{
			m_btnLogin.ShowWindow( SW_SHOW );
#ifndef __SERVER_PC__
			m_btnUserAccount.ShowWindow( SW_SHOW );
#endif
			m_btnExit.ShowWindow( SW_SHOW );
			m_btnErrList.ShowWindow( SW_HIDE );
			m_btnIniChange.ShowWindow( SW_HIDE );
			m_btnMotorSetup.ShowWindow( SW_HIDE );
			m_pSubMotorPosition->InitTimer();
			/*m_btnDrill.ShowWindow( SW_HIDE );
			m_btnManualOperation.ShowWindow( SW_HIDE );
			m_btnProcessSetup.ShowWindow( SW_HIDE );
			m_btnSystemSetup.ShowWindow( SW_HIDE );
			m_btnLogManager.ShowWindow( SW_HIDE );
			m_btnLogout.ShowWindow( SW_HIDE );
			GetDlgItem(IDC_STATIC_MENU)->ShowWindow( SW_HIDE );*/
		}
	}

	void CEasyDrillerDlg::ShowMenuBtnControl(BOOL bShow)
	{
		if( FALSE == bShow )
		{
			m_btnDrill.ShowWindow( SW_HIDE );
			m_btnManualOperation.ShowWindow( SW_HIDE );
			m_btnProcessSetup.ShowWindow( SW_HIDE );
			m_btnSystemSetup.ShowWindow( SW_HIDE );
			m_btnLogManager.ShowWindow( SW_HIDE );
			m_btnLogout.ShowWindow( SW_HIDE );
			m_btnLock.ShowWindow( SW_HIDE );
			GetDlgItem(IDC_STATIC_MENU)->ShowWindow( SW_HIDE );
			m_pSubMotorPosition->ShowWindow(FALSE);
			m_pSubMotorPosition->DestroyTimer();
		}
		else
		{

			m_btnDrill.ShowWindow( SW_SHOW );
			m_btnManualOperation.ShowWindow( SW_SHOW );
			m_btnProcessSetup.ShowWindow( SW_SHOW );
			m_btnSystemSetup.ShowWindow( SW_SHOW );
			m_btnLogManager.ShowWindow( SW_SHOW );
			m_btnLogout.ShowWindow( SW_SHOW );
			m_btnLock.ShowWindow( SW_SHOW );
			GetDlgItem(IDC_STATIC_MENU)->ShowWindow( SW_SHOW );
			m_pSubMotorPosition->ShowWindow(TRUE);
			m_pSubMotorPosition->InitTimer();

		}
	}

	void CEasyDrillerDlg::SetMenuBtn(int nID)
	{
		switch( nID )
		{
		case DRILL :
			m_btnDrill.SetSelection( 1 );
			m_btnManualOperation.SetSelection( 0 );
			m_btnProcessSetup.SetSelection( 0 );
			m_btnSystemSetup.SetSelection( 0 );
			m_btnLogManager.SetSelection( 0 );
			m_btnLogout.SetSelection( 0 );
			break;
		case MANUAL_CONTROL :
			m_btnDrill.SetSelection( 0 );
			m_btnManualOperation.SetSelection( 1 );
			m_btnProcessSetup.SetSelection( 0 );
			m_btnSystemSetup.SetSelection( 0 );
			m_btnLogManager.SetSelection( 0 );
			m_btnLogout.SetSelection( 0 );
			break;
		case PROCESS_SETUP :
			m_btnDrill.SetSelection( 0 );
			m_btnManualOperation.SetSelection( 0 );
			m_btnProcessSetup.SetSelection( 1 );
			m_btnSystemSetup.SetSelection( 0 );
			m_btnLogManager.SetSelection( 0 );
			m_btnLogout.SetSelection( 0 );
			break;
		case SYSTEM_SETUP :
			m_btnDrill.SetSelection( 0 );
			m_btnManualOperation.SetSelection( 0 );
			m_btnProcessSetup.SetSelection( 0 );
			m_btnSystemSetup.SetSelection( 1 );
			m_btnLogManager.SetSelection( 0 );
			m_btnLogout.SetSelection( 0 );
			break;
		case LOG_MANAGER :
			m_btnDrill.SetSelection( 0 );
			m_btnManualOperation.SetSelection( 0 );
			m_btnProcessSetup.SetSelection( 0 );
			m_btnSystemSetup.SetSelection( 0 );
			m_btnLogManager.SetSelection( 1 );
			m_btnLogout.SetSelection( 0 );
			break;
		case LOGOUT :
			m_btnDrill.SetSelection( 0 );
			m_btnManualOperation.SetSelection( 0 );
			m_btnProcessSetup.SetSelection( 0 );
			m_btnSystemSetup.SetSelection( 0 );
			m_btnLogManager.SetSelection( 0 );
			m_btnLogout.SetSelection( 1 );
			break;
		}
	}

	void CEasyDrillerDlg::OnButtonLogin() 
	{
		CDlgLogin dlg;

		if( IDOK != dlg.DoModal() )
			return;

		if(dlg.GetUserLevel() < 3)
			WriteProcessLog(_T("User entry on main"), _T(""));

	#ifdef __MP920_MOTOR__
		// Initialize MP920
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		// Initialize UMAC
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#endif

		switch( dlg.GetUserLevel() )
		{
		case 0 :
			m_stcCadName.SetWindowText( _T("Operator") );
			break;
		case 1 :
			m_stcCadName.SetWindowText( _T("Engineer") );
			break;
		case 2 :
			m_stcCadName.SetWindowText( _T("EO Engineer") );
			break;
		case 3 :
			m_stcCadName.SetWindowText( _T("Super Engineer"));
			break;
		}

		m_nUserLevel	= dlg.GetUserLevel();
		if(m_nUserLevel < 2)
		{
			gProcessINI.m_sProcessSystem.bNoUseApplyScal = FALSE;
	//		if(m_pAutoRun->m_tabAutoRunView.DeleteItem(4))
	//			m_pAutoRun->m_pSystem = NULL;

			if(m_nUserLevel < 1)
			{
				gProcessINI.m_sProcessSystem.nNoSortHole = FALSE;
				gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader = FALSE;
				gProcessINI.m_sProcessSystem.bDryRun = FALSE;
				gProcessINI.m_sProcessSystem.bNoUseSuction = FALSE;
				gProcessINI.m_sProcessSystem.bNoUseFiducialFind = FALSE;
				gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement = TRUE;
				gProcessINI.m_sProcessSystem.bLaserErrorCheck = TRUE;
	#ifndef __NANYA__
				gProcessINI.m_sProcessSystem.bNoUseChillerAlarm = FALSE;
#endif

	//			gProcessINI.m_sProcessSystem.bNoUsePrework = FALSE;
				gProcessINI.m_sProcessSystem.bCheckPreworkData = FALSE;

				gSystemINI.m_sHardWare.bUseFastInposition = TRUE;
//				gSystemINI.m_sSystemDevice.nUseFidFindInCenter = FALSE;
				//gSystemINI.m_sSystemDevice.nEStop = FALSE;
	#ifdef __KUNSAN_SAMSUNG_LARGE__
				gProcessINI.m_sProcessSystem.bUseScheduling = TRUE;
	#endif
			}
		}

	#ifdef __KUNSAN_SAMSUNG_LARGE__
		gDeviceFactory.GetMotor()->SetNoUseLoadUnload(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader);
		gDeviceFactory.GetMotor()->SetNoUseSuction(!gProcessINI.m_sProcessSystem.bNoUseSuction);
		gDeviceFactory.GetMotor()->SetUseNGBox(!gProcessINI.m_sProcessSystem.bNoUseNGBox);
		gDeviceFactory.GetMotor()->SetUsePaperBox(!gProcessINI.m_sProcessSystem.bNoUsePaper);
		gDeviceFactory.GetMotor()->SetLoaderCartPCB(FALSE);
	#endif
		if(m_nUserLevel < 1)
			gProcessINI.m_sProcessCal.bUseApplyTolerance = 1;

		SetAuthorityByLevel();

	

		ShowBtnControl( FALSE );
	
		// 110621
	/*	if(!m_pAutoRun->IsIdleStatus() && m_pAutoRun->m_bLaser && m_pAutoRun->m_bInit)
		{
	//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
			{
				m_pAutoRun->m_bIdleStatus = TRUE;	
				::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
			}
		}
	*/

		WPARAM wParam = DRILL;
		LPARAM lParam = m_nUserLevel;
		OnChangePane( wParam, 0);//lParam );
		m_bLogIned = TRUE;
	}

	LRESULT CEasyDrillerDlg::OnChangePane(WPARAM wParam, LPARAM lParam)
	{
		int nIndex = wParam;
		
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, FALSE);
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, FALSE);
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_LPC, FALSE);
	
		m_dlgSelectedToolEdit.ShowWindow(SW_HIDE);

		if(!m_bVisionSide)  //bUseWideMonitor �� TRUE �� ȭ���� �Ȼ������ �Ǵ°� �ƴ���? bskim 
		{
		
			//ejpark ȭ�� �Ȼ����! 
		
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
	

		//align ȭ�� asc �����
		//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, TRUE);
		//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, TRUE);
	
		if( FIDUCIAL_SETTING == nIndex )
			m_clsPaneArray.SelectPane( MANUAL_CONTROL );
		else
		{
			switch( nIndex )
			{
			case USER_ACCOUNT :
				{
					ShowBtnControl( FALSE );
					ShowUserAccount(SW_SHOW);
					int nLevel = lParam;
					ShowControlLevel( nLevel );
					::SetFocus( m_hUserAccount );
				}
				break;
			case MOTOR_SETUP :
				{
					ShowBtnControl( FALSE );
					ShowMP920Setup(SW_SHOW);
					::SetFocus( m_hMotorSetup );
				}
				break;
			case DRILL :
				{
					m_clsPaneArray.SelectPane( nIndex );
					ShowUserAccount(SW_HIDE);
					ShowMP920Setup(SW_HIDE);
					ShowMenuBtnControl(SW_SHOW);
					SetMenuBtn( DRILL );
				}
				break;
			default :
				{
					ShowMenuBtnControl(SW_SHOW);
					m_clsPaneArray.SelectPane( nIndex );
					ShowUserAccount(SW_HIDE);
					ShowMP920Setup(SW_HIDE);
				}
				break;
			}
		}

		if( -1 == nIndex )
		{
			ShowBtnControl( SW_SHOW );
			ShowMenuBtnControl( SW_HIDE );
			m_stcCadName.SetWindowText( _T("Operator") );
		}

		ActiveStaticForKeyboardError();
		int nOldPane;

		switch( nIndex )
		{
		case DRILL :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( DRILL_SUB );
			m_pAutoRun->ChangeProjectInfo();
			m_pAutoRun->CheckTab();							// check
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
	//		m_pAutoRunSub->SetBackPaneNo( lParam );
			break;
		case RECIPE_GEN :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( RECIPE_GEN_SUB );
	//		m_pRecipeGenSub->SetBackPaneNo( lParam );
			m_pRecipeGen->SetData();
			m_pRecipeGen->SetFocusViewer();
			m_pRecipeGen->ShowTabPane( m_pRecipeGen->GetShowPane());
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		case DRILL_DISPLAY :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( DRILL_DISPLAY_SUB );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
	//		m_pDrillDisplaySub->SetBackPaneNo( lParam );
			break;
		case MANUAL_CONTROL :
			nOldPane = m_pManualControl->GetShowPane();
			m_pManualControl->EnableTab(TRUE);
			m_clsSubPaneArray.SelectPane( MANUAL_CONTROL_SUB );
	//		m_pManualControlSub->SetBackPaneNo( lParam );
			m_pManualControl->SetData(nOldPane);
			if(lParam == 1)
			{
				if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
					m_pManualControl->ShowTabPane( 4, TRUE );
				else
					m_pManualControl->ShowTabPane( 3, TRUE );
			}
			else if(lParam == 2 || lParam == 3 || lParam == 7)
				m_pManualControl->ShowTabPane( lParam, TRUE );
			else if(lParam == 0 && m_nUserLevel < 2)
				m_pManualControl->ShowTabPane( lParam, TRUE);
			else
				m_pManualControl->ShowTabPane( m_pManualControl->GetShowPane(), TRUE );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		case FIDUCIAL_SETTING :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( FIDUCIAL_SETTING_SUB );
			m_pManualDrillSub->SetBackPaneNo( lParam );
			m_pManualDrillSub->ShowHoleFind(TRUE);
			m_pManualControl->m_pVision->VisionSetting(DEFAULT_FID_INDEX);
			if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
				m_pManualControl->ShowTabPane( 5, TRUE );
			else
				m_pManualControl->ShowTabPane( 4, TRUE );
		
			m_pManualControl->EnableTab(FALSE);
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		case PROCESS_SETUP :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( PROCESS_SETUP_SUB );

			if(lParam == 4)
				m_pProcessSetup->ShowTabPane( 4 );

			m_pProcessSetup->ChangeTab();
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
	//		m_pProcessSetupSub->SetBackPaneNo( lParam );
			break;
		case SYSTEM_SETUP :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( SYSTEM_SETUP_SUB );
			m_pSysSetup->ChangeTab();
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
	//		m_pSysSetupSub->SetBackPaneNo( lParam );
			break;
		case LOG_MANAGER :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( LOG_MANAGER_SUB );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		case USER_ACCOUNT :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( USER_ACCOUNT_SUB );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		case MOTOR_SETUP :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( MOTOR_SETUP_SUB );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		default :
			if(m_pManualControl->m_pIO != NULL)
				m_pManualControl->m_pIO->KillSubTimer();
			if(m_pManualControl->m_pMotor != NULL)
				m_pManualControl->m_pMotor->DestroyTimer();
	//		if(m_pManualControl->m_pPowerMeasurement != NULL)
	//			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			m_clsSubPaneArray.SelectPane( -1 );
			m_pRecipeGen->m_pFiducialNew->DestroyTimer();
			m_pManualControl->m_pVision->DestroyTimer();
			m_pAutoRun->m_pFiducial->DestroyTimer();
			break;
		}

		for(int i =0; i<MAX_CAMERA; i++)
			gDeviceFactory.GetVision()->ClearInteractiveGraphics(i);

			OnVisionView(nIndex);


		if(nIndex != -1)
		{
			if(m_nUserLevel < 2)
			{
				m_btnSystemSetup.ShowWindow(SW_HIDE);
			}
			else
			{
				m_btnSystemSetup.ShowWindow(SW_SHOW);
			}
		}
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnChangeSubPane(WPARAM wParam, LPARAM lParam)
	{
		int nIndex = wParam;
		int nSubIndex = lParam;

		switch( nIndex )
		{
		case RECIPE_GEN :
			//if( 3 == nSubIndex )	
				//m_pRecipeGenSub->ShowBtnControl(SW_SHOW);
			//else
			//	m_pRecipeGenSub->ShowBtnControl(SW_HIDE);
			break;
		case MANUAL_CONTROL :
			if( 5 == nSubIndex )
				m_pManualControlSub->ShowBtnControl(1);
			else if(/* 3 == nSubIndex || 4 == nSubIndex || */6 == nSubIndex )
				m_pManualControlSub->ShowBtnControl(2);
			else
				m_pManualControlSub->ShowBtnControl(0);
			break;
		}

		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnGetBackPaneNo(WPARAM wParam, LPARAM lParam)
	{
		OnResetLive();
	
		int nBackPaneNo = 0;
		int nIndex = wParam;

		switch( nIndex )
		{
		case DRILL :
			nBackPaneNo = m_pAutoRunSub->GetBackPaneNo( );
			break;
		case RECIPE_GEN :
			nBackPaneNo = m_pRecipeGenSub->GetBackPaneNo();
			break;
		case MANUAL_CONTROL :
			nBackPaneNo = m_pManualControlSub->GetBackPaneNo( );
			break;
		case FIDUCIAL_SETTING :
			nBackPaneNo = m_pManualDrillSub->GetBackPaneNo( );
			break;
		case PROCESS_SETUP :
			nBackPaneNo = m_pProcessSetupSub->GetBackPaneNo( );
			break;
		case SYSTEM_SETUP :
			nBackPaneNo = m_pSysSetupSub->GetBackPaneNo( );
			break;
		case DRILL_DISPLAY :
			nBackPaneNo = m_pDrillDisplaySub->GetBackPaneNo();
			break;
		}

		return nBackPaneNo;
	}

	void CEasyDrillerDlg::OnButtonUserAccount() 
	{
		CDlgLogin dlg;

		if( IDOK != dlg.DoModal() )
			return;

		WriteProcessLog(_T("User entry on main"), _T(""));

		LPARAM lParam = dlg.GetUserLevel();

		OnChangePane(USER_ACCOUNT, lParam);
	}

	void CEasyDrillerDlg::OnButtonDrill() 
	{
	/*	// 110621
		if(!m_pAutoRun->IsIdleStatus() && m_pAutoRun->m_bLaser && m_pAutoRun->m_bInit)
		{
	//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
			{
				m_pAutoRun->m_bIdleStatus = TRUE;	
				::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
			}
		}
	*/	
		OnResetLive();

		OnChangePane(DRILL, 0);
		SetMenuBtn( DRILL );
	}

	void CEasyDrillerDlg::OnButtonManualOperation() 
	{
		if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}
	
		// 110621
	/*	if(m_pAutoRun->IsIdleStatus())
		{
			if(gProcessINI.m_sProcessCal.nScalMethod != 2 && gProcessINI.m_sProcessCal.nPowerMethod != 2)
			{
				if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
					return;
			}
		
			m_pAutoRun->m_bIdleStatus = FALSE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
		}
	*/
		OnChangePane(MANUAL_CONTROL, 0);
		SetMenuBtn( MANUAL_CONTROL );
	}

	void CEasyDrillerDlg::OnButtonProcessSetup() 
	{
		if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}

	/*	if(m_pAutoRun->IsIdleStatus())
		{
			if(gProcessINI.m_sProcessCal.nScalMethod != 2 && gProcessINI.m_sProcessCal.nPowerMethod != 2)
			{
				if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
					return;
			}
		
			m_pAutoRun->m_bIdleStatus = FALSE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
		}
	*/
		OnResetLive();

		OnChangePane(PROCESS_SETUP, 0);
		SetMenuBtn( PROCESS_SETUP );
	}

	void CEasyDrillerDlg::OnButtonSystemSetup() 
	{
		if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}

		// 110621
	/*	if(m_pAutoRun->IsIdleStatus())
		{
			if(gProcessINI.m_sProcessCal.nScalMethod != 2 && gProcessINI.m_sProcessCal.nPowerMethod != 2)
			{
				if(IDNO == ErrMessage(IDS_IDLE_CHANGE_OFF, MB_YESNO))
					return;
			}
		
			m_pAutoRun->m_bIdleStatus = FALSE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
		}
	*/
		OnResetLive();

		OnChangePane(SYSTEM_SETUP, 0);
		SetMenuBtn( SYSTEM_SETUP );
	}

	void CEasyDrillerDlg::OnButtonLogManager() 
	{
	/*	if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}
	*/
		OnResetLive();

		OnChangePane( LOG_MANAGER, 0 );
		SetMenuBtn( LOG_MANAGER );
	}

	void CEasyDrillerDlg::OnButtonLogout() 
	{
		if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}

		// 110621
	/*	if(m_pAutoRun->IsIdleStatus())
		{
			m_pAutoRun->m_bIdleStatus = FALSE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
		}
	*/
		OnResetLive();
		if(m_nUserLevel != 3)
		{
			CString strLog;
			strLog.Format(_T("User LogOut"));
			WriteProcessLog(strLog, _T(""));
		}
		WPARAM wParam = -1;
	
		OnChangePane( wParam, 0 );
		m_bLogIned = FALSE;
	}

	void CEasyDrillerDlg::OnButtonLock()
	{
		if(m_bLocked)
		{
			return;
		}

		this->SetFocus();
		m_bLocked = TRUE;

		CString strLog;
		strLog.Format(_T("To be Lock from main"));
		WriteProcessLog(strLog, _T(""));

		//
		CDlgLogin dlg;
		dlg.m_bLock = TRUE;

		if( IDOK != dlg.DoModal() )
			return;

		if(dlg.GetUserLevel() < 3)
			WriteProcessLog(_T("User entry on main"), _T(""));

	#ifdef __MP920_MOTOR__
		// Initialize MP920
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		// Initialize UMAC
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#endif

		switch( dlg.GetUserLevel() )
		{
		case 0 :
			m_stcCadName.SetWindowText( _T("Operator") );
			break;
		case 1 :
			m_stcCadName.SetWindowText( _T("Engineer") );
			break;
		case 2 :
			m_stcCadName.SetWindowText( _T("EO Engineer") );
			break;
		case 3 :
			m_stcCadName.SetWindowText( _T("Super Engineer"));
			break;
		}

		m_nUserLevel	= dlg.GetUserLevel();

		if(m_nUserLevel < 2)
		{
			gProcessINI.m_sProcessSystem.bNoUseApplyScal = FALSE;
	//		if(m_pAutoRun->m_tabAutoRunView.DeleteItem(4))
	//			m_pAutoRun->m_pSystem = NULL;

			if(m_nUserLevel < 1)
			{
				gProcessINI.m_sProcessSystem.nNoSortHole = 0;
				gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader = FALSE;
				gProcessINI.m_sProcessSystem.bDryRun = FALSE;
				gProcessINI.m_sProcessSystem.bNoUseSuction = FALSE;
				gProcessINI.m_sProcessSystem.bNoUseFiducialFind = FALSE;


	//			gProcessINI.m_sProcessSystem.bNoUsePrework = FALSE;
				gProcessINI.m_sProcessSystem.bCheckPreworkData = FALSE;
			}
		}
		else
		{
			if(m_pAutoRun->m_pSystem == NULL)
			{
				//System
	//			BOOL bRet = m_pAutoRun->m_tabAutoRunView.AddPane( _T(" System "), RUNTIME_CLASS(CPaneAutoRunViewSystem) );
	//			if( FALSE != bRet )
	//			{
	//				m_pAutoRun->m_pSystem = static_cast<CPaneAutoRunViewSystem*>(m_pAutoRun->m_tabAutoRunView.GetPane(4));
				//	m_pAutoRun->m_pSystem->OnInitialUpdate();
	//			}
			}
		}
	
		if(m_nUserLevel < 1)
			gProcessINI.m_sProcessCal.bUseApplyTolerance = 1;

	#ifdef __KUNSAN_SAMSUNG_LARGE__
		gDeviceFactory.GetMotor()->SetNoUseLoadUnload(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader);
		gDeviceFactory.GetMotor()->SetNoUseSuction(!gProcessINI.m_sProcessSystem.bNoUseSuction);
		gDeviceFactory.GetMotor()->SetUseNGBox(!gProcessINI.m_sProcessSystem.bNoUseNGBox);
		gDeviceFactory.GetMotor()->SetUsePaperBox(!gProcessINI.m_sProcessSystem.bNoUsePaper);
	#endif

		SetAuthorityByLevel(); // �ּ� Ǯ�� ���� ���. �����߿� ���ʹݴ� �� �ⱸ�� ������ �̷������ �ʴ��� �� �Լ��� ���� ���� �� ������Ͻÿ�.

	

	//	ShowBtnControl( FALSE );

		if(m_nUserLevel < 2)
		{
			m_btnSystemSetup.ShowWindow(SW_HIDE);
		}
		else
		{
			m_btnSystemSetup.ShowWindow(SW_SHOW);
		}

		m_bLocked = FALSE;
	
		//	WPARAM wParam = DRILL;
	//	LPARAM lParam = m_nUserLevel;
	//	OnChangePane( wParam, 0);//lParam );
	}

	BOOL CEasyDrillerDlg::DestroyWindow() 
	{
		if(m_pManualControl->m_pPowerMeasurement != NULL)
			m_pManualControl->m_pPowerMeasurement->DisconnectPort();
	
		m_pSubMotorPosition->DestroyTimer();
		if(m_pManualControl->m_pLaser != NULL)
			m_pManualControl->m_pLaser->DestroyTimer();
		if(m_pManualControl->m_pMotor != NULL)
			m_pManualControl->m_pMotor->DestroyTimer();
		m_pAutoRun->DestroyTimer();

		m_fntBtn.DeleteObject();
		m_fntStatic.DeleteObject();
		m_fntStatic2.DeleteObject();

		gDeviceFactory.DestroyDevice();

		if( NULL != m_pVisionView )
		{
	//		m_pVisionView->DestroyWindow();
	//		delete m_pVisionView;
			m_pVisionView->SendMessage(WM_CLOSE);
			m_pVisionView = NULL;
		}

		if( NULL != m_pVisionProView )
		{
			m_pVisionProView->DestroyWindow();
			delete m_pVisionProView;
			m_pVisionProView = NULL;
		} 

		if( NULL != m_pMatroxVisionView )
		{
			m_pMatroxVisionView->DestroyWindow();
			delete m_pMatroxVisionView;
			m_pMatroxVisionView = NULL;
		}

		if( NULL != m_pDlgShow4Way )
		{
			m_pDlgShow4Way->DestroyWindow();
			delete m_pDlgShow4Way;
			m_pDlgShow4Way = NULL;
		}

		if(m_pOpc != NULL)
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError = _T("");
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossPass = _T("");
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossResult = _T("");
			CString strLossError = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLossError;
	
			CTime EventTime = CTime::GetCurrentTime();
			CString strTime, strLotID, strLotID2, strPrj1, strPrj2;
			strTime.Format("%04d%02d%02d%02d%02d%02d",
				EventTime.GetYear(), EventTime.GetMonth(), EventTime.GetDay(),
				EventTime.GetHour(), EventTime.GetMinute(), EventTime.GetSecond());

			((CEasyDrillerDlg*)::AfxGetMainWnd())->GetCurrentLotID(strLotID, strLotID2, strPrj1, strPrj2);
			CString strUserID = gDProject.m_strUserID;
			CString strComment;

			CString strMode;
			strMode.Format(_T("G0142"));
			CString strOPC = _T("");
			strOPC.Format("%s;%s;%s;%s;%s;%s", "000", strMode, strTime, strUserID , strComment, strLotID);

			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 9, reinterpret_cast<LPARAM>(&strOPC));	//8 ����->TC �� �������� ���� : L_000_000000_01

			m_pOpc->DestroyWindow();
			delete m_pOpc;
			m_pOpc = NULL;
		}
		::DeleteCriticalSection( &m_CritLog );
	
	#ifndef __NO_USE_OPC__
		if(m_pOPCHandle  != NULL)
		{
			DWORD ProcessID;
			GetWindowThreadProcessId(m_pOPCHandle->m_hWnd, &ProcessID);
			HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcessID);
			::TerminateProcess(hProcess, 0);

			while(m_pOPCHandle != NULL)
			{
				m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
				Sleep(100);
			}
		}
	#endif

		return CDialog::DestroyWindow();
	}

	void CEasyDrillerDlg::OnButtonErrList() 
	{
		CDlgLogin dlg;

		if( IDOK != dlg.DoModal() )
			return;

		ShowErrListDlg();
	}

	void CEasyDrillerDlg::OnOK() 
	{
	#ifndef __MP920_MOTOR__
		// Destory UMAC
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
		if( NULL != pMotor )
		{
			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				pMotor->TableClamp(TRUE);
			}
			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				pMotor->TableClamp(TRUE, FALSE);
			}

#ifndef __NO_USE_INIT_LASER_IF__
			pMotor->SetAOMPowerON(FALSE);
#endif


	//		pMotor->ScannerPower(FALSE);
		}
		///////////////////////////////////////////////
	#else
		// Destroy MP920
		HMotor* pMotor = gDeviceFactory.GetMotor();
		if( NULL != pMotor )
		{
			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				pMotor->TableClamp(TRUE);
			}
			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				pMotor->TableClamp(TRUE, FALSE);
			}
		}
		///////////////////////////////////////////////
	#endif

		if(gDeviceFactory.GetEocard()->IsDSPBusy())
			gDeviceFactory.GetEocard()->EStop();

		BOOL bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			::Sleep(100);
			bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
		}

		WriteProcessLog(_T("### End Program ###"), _T(""));
		CDialog::OnOK();
	}

	void CEasyDrillerDlg::OnButtonMotorSetup() 
	{
	#ifdef __MP920_MOTOR__
		CDlgLogin dlg;

		if( IDOK != dlg.DoModal() )
			return;

	#ifndef __MP920_MOTOR__
		// Destory UMAC
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
		if( NULL != pMotor )
			pMotor->DestroyMotor();
		///////////////////////////////////////////////
	#else
		// Destroy MP920
		HMotor* pMotor = gDeviceFactory.GetMotor();
		if( NULL != pMotor )
			pMotor->DestroyMotor();
		///////////////////////////////////////////////
	#endif

		// Destory IO Panel
		if( NULL != m_pManualControl )
		{
	#ifndef __MP920_MOTOR__
			if( NULL != m_pManualControl->m_pIO )
				m_pManualControl->m_pIO->DestroyIO();
	#endif
		}
		////////////////////////////////////////////////

		LPARAM lParam = dlg.GetUserLevel();

		OnChangePane(MOTOR_SETUP, 0);//lParam);
	#else
		return;
	#endif
	}

	void CEasyDrillerDlg::OnLButtonDown(UINT nFlags, CPoint point) 
	{
		if ( hidden_point > 1 ) return;

		switch( --nFlags )
		{
		case MK_CONTROL :
			if( hidden_rect.PtInRect(point) )
			{
				hidden_point++;
				m_btnErrList.ShowWindow(SW_SHOW);
				m_btnIniChange.ShowWindow( SW_SHOW );
	//			m_btnMotorSetup.ShowWindow(SW_SHOW);
				hidden_point = 0;
			}
			if(  hidden_rect2.PtInRect(point) )
			{
				CString Str;
				Str.Format(_T(" Pre Move = %d \n\r Jump Delay = %d \n\r Min Cycle Time = %d \n\r Min Shot Time = %d ")
					, gSystemINI.m_sSystemDevice.nPreMove, gSystemINI.m_sSystemDevice.nJumpDelayShot,
					gSystemINI.m_sSystemDevice.nMinCycleTime, gSystemINI.m_sSystemDevice.nMinShotTime);
				ErrMessage(Str);
			}
			if( hidden_rect3.PtInRect(point) ) 
			{
				CDlgMelsecIO dlg;
				dlg.DoModal();
			}
			break;
		case MK_SHIFT :
			Capture();
			break;
		}
	
		CDialog::OnLButtonDown(nFlags, point);
	}

	LRESULT CEasyDrillerDlg::OnApplyProcess(WPARAM wParam, LPARAM lParam)
	{
		if( NULL != m_pProcessSetup )
			m_pProcessSetup->OnApply();

		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnApplySystem(WPARAM wParam, LPARAM lParam)
	{
		if( NULL != m_pSysSetup )
			m_pSysSetup->OnApply();

		return 0L;
	}

	BOOL CEasyDrillerDlg::SaveProject(CString strPath)
	{
		BOOL bSuccess;

		bSuccess =  m_pRecipeGen->SaveProject(strPath);


		m_pAutoRun->LPCLimitSave();

		return bSuccess;
	}

	BOOL CEasyDrillerDlg::OpenProject(CString strPath, BOOL bUseOpenTool)
	{
		gProcessINI.m_sProcessSystem.bUseOpenTool = bUseOpenTool;
		
		BOOL bSuccess;

			bSuccess = m_pRecipeGen->OpenProject(strPath);
		return bSuccess;
	}

	BOOL CEasyDrillerDlg::ApplyProject()
	{

		    return m_pRecipeGen->ApplyProject();
	}

	void CEasyDrillerDlg::SetFileOpen(BOOL bOpen)
	{
		m_pRecipeGen->m_bProjectOpen = bOpen;
	}

	BOOL CEasyDrillerDlg::GetFileOpen()
	{
		if(m_pRecipeGen == NULL)
			return FALSE;
		return m_pRecipeGen->m_bProjectOpen;
	}

	BOOL CEasyDrillerDlg::GetLaserPower()
	{
		return m_pManualControl->GetLaserPower();
	}

	void CEasyDrillerDlg::OnVisionView(int nIndex)
	{

		BOOL bSideVision = GetSideStatus();
		switch( nIndex )
		{
		case DRILL :
			{
				m_pSysSetup->m_pLaserScanner->StopExternalLaser();
			
				//110907 ejpark ���ο� �ִ� vision ��� No
				//			m_pAutoRun->ConnectView();
				break;
			}
		case RECIPE_GEN :
			{
				break;
			}
		case MANUAL_CONTROL :
			{
				m_pSysSetup->m_pLaserScanner->StopExternalLaser();
			
				int nSel = m_pManualControl->GetTabCurSel();
			
				if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
				{
					switch( nSel )
					{
					case 2 :
						m_pManualControl->m_pDevice->SetDeviceStatus();
						break;
					case 4 : // Scanner Calibration
						if(!bSideVision)
							m_pManualControl->m_pScannerCalibration->ConnectView();
						break;
					case 5 : // Vision Teaching
						if(!bSideVision)
							m_pManualControl->m_pVision->ConnectView();
						break;
					case 6 : // One Hole
						if(!bSideVision)
							m_pManualControl->m_pOneHole->ConnectView();
						m_pManualControl->m_pOneHole->SetDefaultZScan();
						break;
						//			case 7 : // Scanner Calibration'2
						//				m_pManualControl->m_pScannerCalibrationPos->ConnectView();
						//				break;
					default :
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								m_pVisionProView->ShowWindow(SW_HIDE);
						}
						switch(gSystemINI.m_sHardWare.nLaserType)
						{
						case LASER_UV:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						case LASER_SLV263G:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						case LASER_HYBRID:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						}
						break;
					}
				}
				else
				{
					switch( nSel )
					{
					case 2 :
						m_pManualControl->m_pDevice->SetDeviceStatus();
						break;
					case 3 : // Scanner Calibration
						if(!bSideVision)
							m_pManualControl->m_pScannerCalibration->ConnectView();
						break;
					case 4 : // Vision Teaching
						if(!bSideVision)
							m_pManualControl->m_pVision->ConnectView();
						break;
					case 5 : // One Hole
						if(!bSideVision)
							m_pManualControl->m_pOneHole->ConnectView();
						m_pManualControl->m_pOneHole->SetDefaultZScan();
						break;
						//				case 6 : // Scanner Calibration'2
						//					m_pManualControl->m_pScannerCalibrationPos->ConnectView();
						//					break;
					default :
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								m_pVisionProView->ShowWindow(SW_HIDE);
						}
						switch(gSystemINI.m_sHardWare.nLaserType)
						{
						case LASER_UV:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						case LASER_SLV263G:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						case LASER_HYBRID:
							if(nSel == 0)
								m_pManualControl->m_pLaserUV->CallDialog();
							break;
						}
						break;
					}
				}
			}
			break;
		case SYSTEM_SETUP :
			{
				int nSel = m_pSysSetup->GetTabCurSel();
			
				switch( nSel )
				{
				case 1:
					m_pSysSetup->m_pLaserScanner->SetShutterStatus();
					if(!bSideVision)
					{
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow(SW_HIDE);
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow(SW_HIDE);
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow(SW_HIDE);
					}
					break;
				case 3:
					if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC ||
						gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								m_pVisionProView->ShowWindow(SW_HIDE);
						}
					}
					else
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
							m_pSysSetup->m_pTableCal->ConnectView();
					}
					break;
				case 6:
					if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
							m_pSysSetup->m_pThetaCal->ConnectView();
					}
					else
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
						}
					}
					break;
				case 7:
					if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						((gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0) ||
						(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)))
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
							m_pSysSetup->m_pThetaCal->ConnectView();
					}
					else
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
						}
					}
					break;
				case 8:
					if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0)
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
							m_pSysSetup->m_pThetaCal->ConnectView();
					}
					else
					{
						m_pSysSetup->m_pLaserScanner->StopExternalLaser();
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
						}
					}
					break;
				default:
					m_pSysSetup->m_pLaserScanner->StopExternalLaser();
					if(!bSideVision)
					{
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow(SW_HIDE);
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow(SW_HIDE);
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow(SW_HIDE);
					}
					break;
				}
			}
			break;
		case FIDUCIAL_SETTING :
			{
				m_pSysSetup->m_pLaserScanner->StopExternalLaser();
			
				int nSel = m_pManualControl->GetTabCurSel();
			
				if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
				{
					switch( nSel )
					{
					case 4 : // Scanner Calibration
						m_pManualControl->m_pScannerCalibration->ConnectView();
						break;
					case 5 : // Vision Teaching
						if(!bSideVision)
							m_pManualControl->m_pVision->ConnectView();
						break;
					case 6 : // One Hole
						if(!bSideVision)
							m_pManualControl->m_pOneHole->ConnectView();
						m_pManualControl->m_pOneHole->SetDefaultZScan();
						break;
						//				case 7 : // Scanner Calibration'2
						//					m_pManualControl->m_pScannerCalibrationPos->ConnectView();
						//					break;
					default :
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								m_pMatroxVisionView->ShowWindow(SW_HIDE);
						}
						break;
					}
				}
				else
				{
					switch( nSel )
					{
					case 3 : // Scanner Calibration
						m_pManualControl->m_pScannerCalibration->ConnectView();
						break;
					case 4 : // Vision Teaching
						if(!bSideVision)
							m_pManualControl->m_pVision->ConnectView();
						break;
					case 5 : // One Hole
						if(!bSideVision)
							m_pManualControl->m_pOneHole->ConnectView();
						m_pManualControl->m_pOneHole->SetDefaultZScan();
						break;
						//				case 6 : // Scanner Calibration'2
						//					m_pManualControl->m_pScannerCalibrationPos->ConnectView();
						//					break;
					default :
						if(!bSideVision)
						{
							if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
								m_pVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
								m_pMatroxVisionView->ShowWindow(SW_HIDE);
							else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
								m_pVisionProView->ShowWindow(SW_HIDE);
						}
						break;
					}
				}
			}
			break;
		default :
			{
				m_pSysSetup->m_pLaserScanner->StopExternalLaser();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			}
		}
	}

	void CEasyDrillerDlg::OnResetLive()
	{
		if( TRUE == m_pManualControl->m_pScannerCalibration->GetIsLive() )
			m_pManualControl->m_pScannerCalibration->ResetLive();
		if( TRUE == m_pManualControl->m_pVision->GetIsLive() )
			m_pManualControl->m_pVision->ResetLive();
		if( TRUE == m_pManualControl->m_pOneHole->GetIsLive() )
			m_pManualControl->m_pOneHole->ResetLive();
	}

	void CEasyDrillerDlg::OnMove(int x, int y) 
	{
		CDialog::OnMove(x, y);
	
		// TODO: Add your message handler code here
		OnMoveVisionView();
	}
	LRESULT CEasyDrillerDlg::OnInputFidImage(WPARAM wParam, LPARAM lParam)
	{
		return 1; // 20130404 bhlee
	}
	void CEasyDrillerDlg::OnMoveVisionView()
	{
	
		if(gSystemINI.m_sHardWare.bUseWideMonitor && m_bVisionSide )
		{
			int nXScreen = ::GetSystemMetrics(SM_CXSCREEN);
			int nYScreen = ::GetSystemMetrics(SM_CYSCREEN);
		
			CRect rt;
			CRect rtPos;
		
			int nSubStartX;
			int nSubStartY;
			int nWide, nHeight;

			if(m_dlgFiducialAllView->m_bFiducialAllViewDlgShow)
			{
				m_dlgFiducialAllView->GetWindowRect(&rt);
				nSubStartX = rt.left + 35;
				nSubStartY = rt.bottom + 20 - 335;
			}
			else
			{
				GetWindowRect(&rt); // EasyDriller 
				nSubStartX = rt.right;
				nSubStartY = rt.top;
			}

			m_pVisionProView->GetWindowRect(&rtPos);	
			nWide = rtPos.right - rtPos.left;
			nHeight = rtPos.bottom - rtPos.top;
			rtPos.top = nSubStartY; 
			rtPos.bottom = nSubStartY + nHeight;
			rtPos.left = nSubStartX;
			rtPos.right = nSubStartX + nWide;
			Sleep(10);
			m_pVisionProView->MoveWindow( &rtPos );
			m_pVisionProView->ShowWindow( SW_SHOW );

			return;
		}
		else
		{
			int nSel = m_clsPaneArray.GetCurrentPaneIndex();
		
			switch( nSel )
			{
			case DRILL :
				m_pAutoRun->OnMoveVisionView();
				break;
			case MANUAL_CONTROL :
				{
					int nSel = m_pManualControl->GetTabCurSel();
				
					switch( nSel )
					{
					case 4 : // Scanner Calibration
						m_pManualControl->m_pScannerCalibration->OnMoveVisionView();
						break;
					case 5 : // Vision Teaching
						m_pManualControl->m_pVision->OnMoveVisionView();
						break;
					case 6 : // One Hole
						m_pManualControl->m_pOneHole->OnMoveVisionView();
						break;
		//			case 7 : // Scanner Calibration'2
		//				m_pManualControl->m_pScannerCalibrationPos->OnMoveVisionView();
		//				break;
					default:
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow( SW_HIDE );
					

						break;
					}
				}
				break;
			case SYSTEM_SETUP :
				{
					int nSel = m_pSysSetup->GetTabCurSel();
				
					if( 3 == nSel &&
						gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC &&
						gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA) // Table Calibration
						m_pSysSetup->m_pTableCal->OnMoveVisionView();
					else if( 6 == nSel &&
						gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)
					{
						m_pSysSetup->m_pThetaCal->OnMoveVisionView();
					}
					else if( 7 == nSel &&
						gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						((gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0) ||
						(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)))
					{
						m_pSysSetup->m_pThetaCal->OnMoveVisionView();
					}
					else if( 8 == nSel &&
						gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
						gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0)
					{
						m_pSysSetup->m_pThetaCal->OnMoveVisionView();
					}
					else
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow( SW_HIDE );
				}
				break;
			case FIDUCIAL_SETTING :
				{
					int nSel = m_pManualControl->GetTabCurSel();
				
					switch( nSel )
					{
					case 4 : // Scanner Calibration
						m_pManualControl->m_pScannerCalibration->OnMoveVisionView();
						break;
					case 5 : // Vision Teaching
						m_pManualControl->m_pVision->OnMoveVisionView();
						break;
					case 6 : // One Hole
						m_pManualControl->m_pOneHole->OnMoveVisionView();
						break;
						//			case 7 : // Scanner Calibration'2
						//				m_pManualControl->m_pScannerCalibrationPos->OnMoveVisionView();
						//				break;
					default:
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow( SW_HIDE );
						break;

					}
				}
				break;
			case RECIPE_GEN :
				{
					int nSel = m_pRecipeGen->GetShowPane();
					if(nSel == 3)
						m_pRecipeGen->OnMoveVisionView();
					else
						if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
							m_pVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
							m_pMatroxVisionView->ShowWindow( SW_HIDE );
						else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
							m_pVisionProView->ShowWindow( SW_HIDE );
					break;
				}
			default :
				if(m_pVisionView)
					m_pVisionView->ShowWindow( SW_HIDE );
				if(m_pMatroxVisionView)
					m_pMatroxVisionView->ShowWindow( SW_HIDE );
				if(m_pVisionProView)
					m_pVisionProView->ShowWindow( SW_HIDE );
				break;
			}
		}
	}

	LRESULT CEasyDrillerDlg::OnLogMessage(WPARAM wParam, LPARAM lParam)
	{
 		if (wParam == NULL)
			return 0L;
	
		CString* pstrEvent = reinterpret_cast<CString*>(wParam);
		CString* pstrInfo = reinterpret_cast<CString*>(lParam);
	
		if (lParam)
			WriteProcessLog(*pstrEvent, *pstrInfo);
		else
			WriteProcessLog(*pstrEvent, _T(""));

		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnSetErrMsgID(WPARAM wParam, LPARAM lParam)
	{
		if (wParam == NULL)
			return 0L;

		if(m_pAutoRun)	
			m_pAutoRun->m_nErrMsgID = (int)wParam;

		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnWriteLog(WPARAM wParam, LPARAM lParam)
	{
		if (wParam == NULL || lParam == NULL)
			return 0L;
	
		CString* pstrFile = reinterpret_cast<CString*>(wParam);
		CString* pstrMsg = reinterpret_cast<CString*>(lParam);
	
		WriteLog(*pstrFile, *pstrMsg);
	
		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnSetErrMsg(WPARAM wParam, LPARAM lParam)
	{
		if (wParam == NULL)
			return 0L;

		CString* strMsg = reinterpret_cast<CString*>(wParam);
		BOOL bError = (BOOL)lParam;

		m_stcMsg.SetWindowText( *strMsg );
		WriteProcessLog(*strMsg, _T(""), bError);
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnSetJobTime(WPARAM wParam, LPARAM lParam)
	{
		if (wParam == NULL)
			return 0L;

		double dErrorTime = (double)wParam;
		int	 nJobType = (int)lParam;
		SaveJobTimeLog((int)dErrorTime, nJobType);
		return 0L;
	}

	void CEasyDrillerDlg::SaveJobTimeLog(int ndiff, int nJobType)
	{
		CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
		if(nJobType >= OPERATION_JOB)
			strpathName+=_T("JobViewTime");
		else
			strpathName+=_T("JobTime");
		CTime  curDate = CTime::GetCurrentTime();
		CString strCurTime;
		strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());

		strpathName+=strCurTime;

		//�켱 ���� �˻�
		CStdioFile file;
		if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
			return ;

		TRY 
		{
			file.SeekToEnd();
			CString strBuf, strType;
			if(nJobType == PREHEAT_JOB)
				strType.Format(_T("H"));
			else if(nJobType == SCAL_JOB)
				strType.Format(_T("S"));
			else if(nJobType == POWER_JOB)
				strType.Format(_T("P"));
			else if(nJobType == DRILL_JOB)
				strType.Format(_T("D"));
			else if(nJobType == OPERATION_JOB)
				strType.Format(_T("O"));
			else if(nJobType == PM_JOB)
				strType.Format(_T("M"));
			else if(nJobType == REPAIR_JOB)
				strType.Format(_T("R"));
			else if(nJobType == ERROR_JOB)
				strType.Format(_T("E"));
			else
				strType.Format(_T("I"));

			strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
				strType,
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(), curDate.GetHour(), curDate.GetMinute(), curDate.GetSecond(), 
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(), curDate.GetHour(), curDate.GetMinute(), curDate.GetSecond(),
				ndiff);


			file.Write(strBuf, strBuf.GetLength());
		}
		CATCH (CMemoryException, e)
		{
			file.Close();
			e->Delete();
			return;
		}
		END_CATCH

			file.Close();

	}

	void CEasyDrillerDlg::WriteProcessLog(CString strEvent, CString strInfo, BOOL bIsError)
	{
		CTime EventTime = CTime::GetCurrentTime();
		CStdioFile cFile;
		CString strVal;
		CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	
	//	::WaitForSingleObject( g_hLogFile, INFINITE );
	//	::ResetEvent(g_hLogFile);
	
		CString strCurLogFileName = _T("Log");
		strCurLogFileName += EventTime.Format(_T("%Y%m%d"));
	
		if (FALSE == cFile.Open(strPathName + strCurLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite | CFile::shareDenyNone))
		{
	//		::SetEvent(g_hLogFile);
			return;
		}
	
		if (bIsError)
			strVal = _T("E | ");
		else
			strVal = _T("I | ");
	
		CString strTime;
		strTime.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d |"),
			EventTime.GetYear(),
			EventTime.GetMonth(),
			EventTime.GetDay(),
			EventTime.GetHour(),
			EventTime.GetMinute(),
			EventTime.GetSecond());
	
		strVal += strTime;

		if(gDProject.m_CurrentMode == AUTO_DRILL_MODE)
		{
			strVal += _T("Auto Drill	|");
		}
		else if(gDProject.m_CurrentMode == MANUAL_DRILL_MODE)
		{
			strVal += _T("Manual Drill	|");
		}
		else
		{
			strVal += _T("None Drill	|");
		}
	
		if(gVariable.m_nChangeDisplayLogMode == 2)
		{
			CString strWrite;
			strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
				EventTime.GetHour(),
				EventTime.GetMinute(),
				EventTime.GetSecond(),
				strEvent);
			m_dlgAutoLoaderInterface.DisplayStatus(strWrite);
		}







		strEvent.TrimLeft();
		strEvent.TrimRight();
		if (!strEvent.IsEmpty())
		{
			strEvent.Insert(0, _T(' '));
			if (_T('\r') == strEvent.GetAt(strEvent.GetLength()-1)
				&& _T('\n') == strEvent.GetAt(strEvent.GetLength()-1))
				strEvent.SetAt(strEvent.GetLength()-1, _T(' '));
		}
	
		int nLen = strEvent.GetLength();
		if (nLen < 60)
		{
			int nRemain = 60 - nLen;
			for (int i = 0; i < nRemain; i++)
				strEvent += _T(" ");
		}
		strEvent += _T(" |");
	
		strVal += strEvent;

		strInfo.TrimLeft();
		strInfo.TrimRight();
		if (strInfo.IsEmpty())
			strInfo = _T(" \n");
		else
		{
			strInfo.Insert(0, _T(' '));
			if (_T('\r') != strInfo.GetAt(strInfo.GetLength()-1)
				&& _T('\n') != strInfo.GetAt(strInfo.GetLength()-1))
				strInfo += _T("\n");
		}
	
		strVal += strInfo;
	
		TRY
		{
			cFile.SeekToEnd();
			cFile.Write(strVal, strVal.GetLength());
			cFile.Close();
		}
		CATCH (CFileException, e)
		{
			e->Delete();
	//		::SetEvent(g_hLogFile);
			return;
		}
		END_CATCH

	//	::SetEvent(g_hLogFile);
	}

	BOOL CEasyDrillerDlg::ShutterMove(BOOL bMaster, BOOL bSlave, BOOL bShowMessage)
	{
	#ifdef __TEST__
		return TRUE;
	#endif

	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif

		BYTE nReStart = TRUE;
		if (pMotor != NULL)
		{
			// return value of GetCurrentShutter[1-2] : 1 = Open, 2 = Close, 3 = Center
			BYTE nShutter1 = pMotor->GetCurrentShutter1();
			BYTE nShutter2 = pMotor->GetCurrentShutter2();

			if (nShutter1 == 1)	
				nShutter1 = TRUE;
			else if (nShutter1 == 2)
				nShutter1 = FALSE;
			else	
				nShutter1 = 3;
		
			if (nShutter2 == 1)
				nShutter2 = TRUE;
			else if (nShutter2 == 2)
				nShutter2 = FALSE;
			else	
				nShutter2 = 3;
		
			if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
				nShutter2 = bSlave;

			if (bMaster == nShutter1 && bSlave == nShutter2)
				return TRUE;

	RESHUTTER:
			int nCount = 0;
			pMotor->MotorShutterAll(bMaster, bSlave);
			::Sleep(20);

			do
			{
				nShutter1 = pMotor->GetCurrentShutter1();
				nShutter2 = pMotor->GetCurrentShutter2();

				if (nShutter1 == 1)
					nShutter1 = TRUE;
				else if (nShutter1 == 2)
					nShutter1 = FALSE;
				else
					nShutter1 = 3;
			
				if (nShutter2 == 1)
					nShutter2 = TRUE;
				else if (nShutter2 == 2)
					nShutter2 = FALSE;
				else
					nShutter2 = 3;

				if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
					nShutter2 = bSlave;

				if (nShutter1 == bMaster && nShutter2 == bSlave)
				{
					return TRUE;
				}

				if (++nCount > 500)	//5 Sec
					break;

				::Sleep(10);
			} while (TRUE);

			nShutter1 = pMotor->GetCurrentShutter1();
			nShutter2 = pMotor->GetCurrentShutter2();

			if (nShutter1 == 1)			nShutter1 = TRUE;
			else if (nShutter1 == 2)	nShutter1 = FALSE;
			else						nShutter1 = 3;
		
			if (nShutter2 == 1)			nShutter2 = TRUE;
			else if (nShutter2 == 2)	nShutter2 = FALSE;
			else						nShutter2 = 3;

			if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
				nShutter2 = bSlave;

			if (nReStart == TRUE && (nShutter1 != bMaster || nShutter2 != bSlave))
			{
				nReStart = FALSE;
				goto RESHUTTER;
			}

			if (nShutter1 != bMaster)
			{
				if (bMaster)		// Open Error
				{
					if(bShowMessage)
						ErrMsgDlg(STDGNALM413);
					return FALSE;
				}
				else					// Close Error
				{
					if(bShowMessage)
						ErrMsgDlg(STDGNALM415);
					return FALSE;
				}
			}
			else if (nShutter2 != bSlave)
			{
				if (bSlave)		// Open Error
				{
					if(bShowMessage)
						ErrMsgDlg(STDGNALM414);
					return FALSE;
				}
				else					// Close Error
				{
					if(bShowMessage)
						ErrMsgDlg(STDGNALM416);
					return FALSE;
				}
			}
			else
				return FALSE;
		}
		else
			return FALSE;
	
		return TRUE;
	}

	void CEasyDrillerDlg::CameraChangeHigh1st()
	{
		gDeviceFactory.GetVision()->OnCamChange(0);
	}

	void CEasyDrillerDlg::CameraChangeLow1st()
	{
		gDeviceFactory.GetVision()->OnCamChange(1);
	}

	void CEasyDrillerDlg::CameraChangeHigh2nd()
	{
		gDeviceFactory.GetVision()->OnCamChange(2);
	}

	void CEasyDrillerDlg::CameraChangeLow2nd()
	{
		gDeviceFactory.GetVision()->OnCamChange(3);
	}

	LRESULT CEasyDrillerDlg::OnDrillStart(WPARAM wParam, LPARAM lParam)
	{
		m_pManualControl->m_pScannerCalibration->m_bAutoPause = FALSE;

		if( NULL != m_pAutoRunSub )
			m_pAutoRunSub->EnableButton(FALSE, TRUE, TRUE, TRUE, TRUE);

		if( NULL != m_pAutoRun )
		{
			m_pAutoRun->DrillStart();
		}
	
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnDrillOneCycle(WPARAM wParam, LPARAM lParam)
	{
		if( NULL != m_pAutoRunSub )
			m_pAutoRunSub->EnableButton(FALSE, FALSE, FALSE, TRUE, TRUE);
			//m_pAutoRunSub->EnableButton(FALSE, FALSE, TRUE, TRUE, TRUE);

		if( NULL != m_pAutoRun )
	
			//m_pAutoRun->DrillOneCycleNoUnloadPause();
			m_pAutoRun->DrillOneCycle();

		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnDrillPause(WPARAM wParam, LPARAM lParam)
	{
		m_pManualControl->m_pScannerCalibration->m_bAutoPause = TRUE;
		if( NULL != m_pAutoRunSub )
			m_pAutoRunSub->EnableButton(TRUE, FALSE, FALSE, TRUE, TRUE);

		if( NULL != m_pAutoRun )
			m_pAutoRun->DrillPause();

		m_pManualControl->m_pScannerCalibration->m_bAutoCalStop = TRUE;
 
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnDrillStop(WPARAM wParam, LPARAM lParam)
	{
		if( NULL != m_pAutoRunSub )
			m_pAutoRunSub->EnableButton(FALSE, FALSE, FALSE, FALSE, TRUE);

		if( NULL != m_pAutoRun )
		{
			m_pAutoRun->SetUserStop((BOOL)wParam);
	//		if((BOOL)wParam)
	//			return 0L;

			m_pAutoRun->DrillStop();
		}
		m_pManualControl->m_pScannerCalibration->m_bAutoCalStop = TRUE;

		if( NULL != m_pAutoRunSub )
			m_pAutoRunSub->EnableButton(TRUE, FALSE, FALSE, FALSE, FALSE);

		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnSendErrMsg(WPARAM wParam, LPARAM lParam)
	{
		CString* strPlus = reinterpret_cast<CString*>(lParam);
		CString strErPlus = _T("");
		if(lParam != 0)
		{
			strErPlus = *strPlus;
			if(lParam == NULL || strcmp(strErPlus, "-1") == 0)
			{
				strErPlus = _T("");
			}
		}
	
		ErrMsgDlg((int)wParam, strErPlus);

		return 0L;
	}

	BOOL CEasyDrillerDlg::CheckCalibrationTime()
	{	
		time_t	timeNow;
		time(&timeNow);
		int nHour = gProcessINI.m_sProcessCal.nScalRelTime;
		double dHalfDay = nHour * 60.0;
		double dNowTime;
	
		BOOL b1st = TRUE, b2nd= TRUE;
		time_t	time1st, time2nd;

		int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
		for(int i =0; i<= nCount; i++)
		{
			if(!m_pAutoRun->m_bASCTool[i])
				continue;

			time1st = gTempINI.m_sTempTime.nAutoScalEndTime[i][0]; //master
			time2nd = gTempINI.m_sTempTime.nAutoScalEndTime[i][1]; //slave

			dNowTime = difftime(timeNow, time1st);
			if (dNowTime > dHalfDay)
				b1st &= FALSE;
			else
				b1st &= TRUE;
		
			dNowTime = difftime(timeNow, time2nd);
			if (dNowTime > dHalfDay)
				b2nd &= FALSE;
			else
				b2nd &= TRUE;
		}


		if(gDProject.m_nSeparation == USE_1ST)
			return b1st;
		else if(gDProject.m_nSeparation == USE_2ND)
			return b2nd;
		else
			return (b1st & b2nd);
	}

	BOOL CEasyDrillerDlg::CheckPowerMeasureTime()
	{
		time_t timeNow;
		time(&timeNow);
		BOOL b1st= TRUE, b2nd = TRUE;
		time_t timeMeasure, timeMeasure2;
	
		for(int i = 0 ; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
		{
			if(!m_pAutoRun->m_bPowerTool[i])
				continue;

			timeMeasure = gTempINI.m_sTempTime.nAutoPowerEndTime[i][0];
			timeMeasure2 = gTempINI.m_sTempTime.nAutoPowerEndTime[i][1];

			int nHour = gProcessINI.m_sProcessCal.nPowerRelTime;
			double dHalfDay = nHour * 60.0; //sec 
			double dNowTime, dNowTime2;

			dNowTime = difftime(timeNow, timeMeasure);
			dNowTime2 = difftime(timeNow, timeMeasure2);

			if (dNowTime > dHalfDay)
				b1st &= FALSE;
			if (dNowTime2 > dHalfDay)
				b2nd &= FALSE;
		}

		if(gDProject.m_nSeparation == USE_DUAL)
			return b1st && b2nd;
		else if(gDProject.m_nSeparation == USE_1ST)
			return b1st;
		else
			return b2nd;

	}

	BOOL CEasyDrillerDlg::CheckLaserPreheatTime()
	{
		time_t timeNow;
		time(&timeNow);

		time_t timeEnd;
		timeEnd = gTempINI.m_sTempTime.nAutoPreheatEndTime;//gProcessINI.m_sProcessCal.nPreheatEndTime;

		int nHour = gProcessINI.m_sProcessCal.nPreheatRelTime;
		double dHalfDay = nHour * 60.0;
		double dNowTime;

		dNowTime = difftime(timeNow, timeEnd);
		if (dNowTime > dHalfDay)
			return FALSE;

		return TRUE;
	}

	void CEasyDrillerDlg::OnButtonErrorClear()
	{
		if(m_pAutoRun->IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			return;
		}

		if(m_pManualDrillSub->IsVisionWorking())
		{
			ErrMsgDlg(STDGNALM203);
			return;
		}
	
		gDeviceFactory.GetMotor()->MainReset(TRUE);
	//	gDeviceFactory.GetMotor()->SetTowerLampBuzzer(NULL, FALSE);

		m_stcMsg.SetWindowText( _T("No Message") );
	}

	void CEasyDrillerDlg::OnButtonErrPLC()
	{


		CDlgAlarmPLCLarge pDlg;


		pDlg.DoModal();
	}

	LRESULT CEasyDrillerDlg::OnSaveINIFile(WPARAM wParam, LPARAM lParam)
	{
		int nIndex = wParam;
		CString strFilePath;
		CEasyDrillerINIFile clsINI;
		CProcessINIFile clsProcessINI;
		CSystemINIFile clsSystemINI;
		CBeamPathINIFile clsBeamPathINI;
		CTempINIFile clsTempINI;
		CShotTableINIFile clsShotTableINI;

		BOOL bResult = FALSE;
	//	int i;

		CString strBackupPath;
		CTime cTime = CTime::GetCurrentTime();

		BOOL bExist;
		switch( nIndex )
		{
		case EASYDRILL_INI :
			// Save Easy Driller INI File
			strFilePath.Format(_T("%sEasy.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
			bExist = IsFileExist(strFilePath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\Easy%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
				bExist = CopyFile(strFilePath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}

			for(int i = 0; i < 5; i++)
			{
				bResult = clsINI.SaveINIFile( strFilePath, gEasyDrillerINI );
				if(bResult)
					break;
				::Sleep(100);
			}
			if(bExist && !bResult)
				CopyFile(strBackupPath, strFilePath,FALSE);

			break;
		case PROCESS_INI :
			// Save Process INI File
			strFilePath.Format(_T("%sProcess.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
			bExist = IsFileExist(strFilePath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\Process%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
				bExist = CopyFile(strFilePath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}

			for(int i = 0; i < 5; i++)
			{
				bResult = clsProcessINI.SaveProcessINIFile( strFilePath, gProcessINI );
				if(bResult)
						break;
					::Sleep(100);
			}
			if(bExist && !bResult)
				CopyFile(strBackupPath, strFilePath,FALSE);

			if(bResult)
				gDeviceFactory.GetVision()->LoadOptionFile(1);
			break;
		case SYSTEM_INI :
			// Save System INI File
			strFilePath.Format(_T("%sSystem.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

			bExist = IsFileExist(strFilePath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\System%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
				bExist = CopyFile(strFilePath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}

			for(int i = 0; i < 5; i++)
			{
				bResult = clsSystemINI.SaveSystemINIFile( strFilePath, gSystemINI );
				if(bResult)
					break;
				::Sleep(100);
			}
			if(bExist && !bResult)
				CopyFile(strBackupPath, strFilePath,FALSE);

			if(bResult)
				gDeviceFactory.GetVision()->LoadOptionFile(0);

			break;

		case BEAMPATH_INI :
			// Save System INI File
			strFilePath.Format(_T("%sBeamPath.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

			bExist = IsFileExist(strFilePath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\BeamPath%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
				bExist = CopyFile(strFilePath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}
		
			for(int i = 0; i < 5; i++)
			{
				bResult = clsBeamPathINI.SaveBeamPathNIFile( strFilePath, gBeamPathINI );
				if(bResult)
					break;
				::Sleep(100);
			}
			if(bExist && !bResult)
				CopyFile(strBackupPath, strFilePath,FALSE);
		
			break;
		case TEMP_INI :
			// Save Temp INI File
			strFilePath.Format(_T("%sTemp.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
		
			bExist = IsFileExist(strFilePath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\Temp%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
				bExist = CopyFile(strFilePath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}
		
			for(int i = 0; i < 5; i++)
			{
				bResult = clsTempINI.SaveTempINIFile( strFilePath, gTempINI );
				if(bResult)
					break;
				::Sleep(100);
			}
			if(bExist && !bResult)
				CopyFile(strBackupPath, strFilePath,FALSE);
		
			break;
			case SHOT_INI :
		// Save Shot INI File
		strFilePath.Format(_T("%sShotTable.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());

		bExist = IsFileExist(strFilePath);
		if(bExist)
		{
			strBackupPath.Format(_T("%sBackup\\ShotTable%s.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), cTime.Format(_T("%Y%m%d%H")));
			bExist = CopyFile(strFilePath, strBackupPath, FALSE);
			if(!bExist)
				return FALSE;
		}

		for(int i = 0; i < 5; i++)
		{


			bResult = clsShotTableINI.SaveShotTableNIFile( strFilePath, gShotTableINI );
			if(bResult)
				break;
			::Sleep(100);
		}
		if(bExist && !bResult)
			CopyFile(strBackupPath, strFilePath,FALSE);

		break;

		}
		//������ ������� ����
	//	CString strFilePath;
		strFilePath.Format(_T("%sBackup"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
		CheckOldINIFile(strFilePath);
	
		if(!bResult && (BOOL)!lParam)
		{
			ErrMessage(_T("Failed to save ini file"));
		}

		return bResult;
	}

	LRESULT CEasyDrillerDlg::OnSystemSubUIChange(WPARAM wParam, LPARAM lParam)
	{
		int nIndex = wParam;
		m_pSysSetupSub->ViewApplyButton(nIndex);
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnChangeDataFile(WPARAM wParam, LPARAM lParam)
	{
		BOOL bApply = (BOOL)wParam;
		if(bApply)
		{
			CString strTemp = (CString)gDProject.m_szFileName;
			int nIndex = strTemp.ReverseFind(_T('\\'));
			CString strFile = strTemp.Mid(nIndex+1);
			SetDataName((LPCTSTR)strTemp);
		}
		else
		{
			CString* strFile = reinterpret_cast<CString*>(lParam);	
			CString strTemp = *strFile;
			SetDataName(strTemp);
		}
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnControlTabEnable(WPARAM wParam, LPARAM lParam)
	{
		BOOL bEnable = (BOOL)wParam;
		BOOL bDrill = (BOOL)lParam;
		m_pManualControl->EnableTab(bEnable);
		m_pSysSetup->EnableTab(bEnable);
		m_pRecipeGen->EnableTab(bEnable);
		m_pRecipeGenSub->EnableButton(bEnable);



		m_pManualControlSub->SetBackButton(bEnable);
		m_pSysSetupSub->SetBackButton(bEnable);
	
		m_btnManualOperation.EnableWindow(bEnable);
		m_btnProcessSetup.EnableWindow(bEnable);
		m_btnSystemSetup.EnableWindow(bEnable);
		m_btnLogout.EnableWindow(bEnable);

		m_btnBeampath.EnableWindow(bEnable);
		m_btnShot.EnableWindow(bEnable);
		m_btnMoveMotor.EnableWindow(bEnable);

		if(!gSystemINI.m_sHardWare.bUseWideMonitor || !bDrill)
		{
			m_btnDrill.EnableWindow(bEnable);
			m_btnLogManager.EnableWindow(bEnable);
		}
	
		
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnAutoBtnControl(WPARAM wParam, LPARAM lParam)
	{
		BOOL bEnable = (BOOL)wParam;
		//BOOL bRun = (BOOL)lParam;

		m_pAutoRunSub->EnableButton(bEnable,bEnable,bEnable,bEnable,!bEnable);

		return 0L;
	}

	LRESULT CEasyDrillerDlg::StartBtnControl(WPARAM wParam, LPARAM lParam)
	{
		BOOL bEnable = (BOOL)wParam;
		//BOOL bRun = (BOOL)lParam;

		m_pAutoRunSub->EnableStartButton(bEnable);

		return 0L;
	}
	
	void CEasyDrillerDlg::ReDrawData_WhenTableChange()
	{
		if(m_pManualControl != NULL)
			m_pManualControl->ReDrawData_WhenTableChange();
	}
	

	void CEasyDrillerDlg::SetAuthorityByLevel()
	{
		if(m_pAutoRun != NULL)
			m_pAutoRun->SetAuthorityByLevel(m_nUserLevel);

		if(m_pManualControl != NULL)
			m_pManualControl->SetAuthorityByLevel(m_nUserLevel);

		if(m_pProcessSetup != NULL)
			m_pProcessSetup->SetAuthorityByLevel(m_nUserLevel);

		if(m_pRecipeGen != NULL)
			m_pRecipeGen->SetAuthorityByLevel(m_nUserLevel);

		if(m_pSysSetup != NULL)
			m_pSysSetup->SetAuthorityByLevel(m_nUserLevel);

		if(m_pAutoRunSub != NULL)
			m_pAutoRunSub->SetAuthorityByLevel(m_nUserLevel);

		if(m_pManualControlSub != NULL)
			m_pManualControlSub->SetAuthorityByLevel(m_nUserLevel);

		if(m_pProcessSetupSub != NULL)
			m_pProcessSetupSub->SetAuthorityByLevel(m_nUserLevel);

		if(m_pRecipeGenSub != NULL)
			m_pRecipeGenSub->SetAuthorityByLevel(m_nUserLevel);

		if(m_pSysSetupSub != NULL)
			m_pSysSetupSub->SetAuthorityByLevel(m_nUserLevel);
		
	}

	LRESULT CEasyDrillerDlg::OnDoCalibration(WPARAM wParam, LPARAM lParam)
	{
		BOOL bDryRunCheck = (BOOL)wParam;
	
		OnChangePane(MANUAL_CONTROL, 3);

		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
		::Sleep(500);

		gDeviceFactory.GetMotor()->TableClamp(TRUE, TRUE);
		gDeviceFactory.GetMotor()->TableClamp(TRUE, FALSE);

		if(bDryRunCheck)
		{
			//DryRun Check->
			//Change Pane No
			//Apply No & Just Log 
		
			m_pManualControl->m_pScannerCalibration->m_bDryRunCheck = TRUE;
			m_pManualControl->m_pScannerCalibration->SetAutoCalibration();
		
			if(!m_pManualControl->m_pScannerCalibration->CalibrationStart())
			{
				OnChangePane(DRILL, 0);
				m_pAutoRun->m_bWorkingAutoSCal = FALSE;
				m_pManualControl->m_pScannerCalibration->m_bDryRunCheck = FALSE;

				gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);

				return 0L;
			}
		
			m_pManualControl->m_pScannerCalibration->WaitingThreadEnd();
		
			OnChangePane(DRILL, 0);
		
			m_pAutoRun->m_bWorkingAutoSCal = FALSE;
		
			m_pManualControl->m_pScannerCalibration->m_bDryRunCheck = FALSE;

			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);

			if(gVariable.m_sGlobal.bCalFalse)
				return 0L;
			else
				return 1L;
		}
		else
		{
			for(int i=0; i<1; i++) //gProcessINI.m_sProcessCal.nAutoCalibrationCount; i++)
			{
				m_pManualControl->m_pScannerCalibration->SetAutoCalibration();
			
				if(!m_pManualControl->m_pScannerCalibration->CalibrationStart())
					continue;
			
				m_pManualControl->m_pScannerCalibration->WaitingThreadEnd();

				::Sleep(500);
				MessageLoop();
			
				if(gVariable.m_sGlobal.bCalFalse || m_pManualControl->m_pScannerCalibration->m_bAutoCalStop || !m_pManualControl->m_pScannerCalibration->m_bAutoCalibration)
				{
					TRACE(_T("Break\r\n"));
					break;				
				}
				else
				{
					TRACE(_T("Continue\r\n"));
					continue;
				}
			}

			m_pAutoRun->m_bWorkingAutoSCal = FALSE;
			OnChangePane(DRILL, 0);

			m_pManualControl->m_pScannerCalibration->m_bDryRunCheck = FALSE;

			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
		
			if(gVariable.m_sGlobal.bCalFalse || m_pManualControl->m_pScannerCalibration->m_bAutoCalStop)
				return 0L;

			return 1L;
		}
	}

	LRESULT CEasyDrillerDlg::OnModeChange(WPARAM wParam, LPARAM lParam)
	{
		switch((int)wParam)
		{
		case 0: // Normal
			GetDlgItem(IDC_STATIC_PRJ_NAME)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_CAD_FILE)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_CAD_NAME)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_MSG)->ShowWindow(TRUE);

			GetDlgItem(IDC_STATIC_SAFETY_MSG)->ShowWindow(FALSE);

			GetDlgItem(IDC_STATIC_MSG_IDLE)->ShowWindow(FALSE);
			break;
		case 1: // Safety mode
			GetDlgItem(IDC_STATIC_PRJ_NAME)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC_CAD_FILE)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC_CAD_NAME)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC_MSG)->ShowWindow(FALSE);
		
			GetDlgItem(IDC_STATIC_SAFETY_MSG)->ShowWindow(TRUE);

			GetDlgItem(IDC_STATIC_MSG_IDLE)->ShowWindow(FALSE);
			break;
		case 2: // Idle,Ready mode (available auto scal & power measurement)
			GetDlgItem(IDC_STATIC_PRJ_NAME)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_CAD_FILE)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_CAD_NAME)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_MSG)->ShowWindow(FALSE);
		
			GetDlgItem(IDC_STATIC_SAFETY_MSG)->ShowWindow(FALSE);

			GetDlgItem(IDC_STATIC_MSG_IDLE)->ShowWindow(TRUE);
			break;
		}

		return 1L;
	}

	bool CEasyDrillerDlg::IsFileExist(CString &strFilePath)
	{
		WIN32_FIND_DATA wfd32;
	
		HANDLE hSrch = ::FindFirstFile(strFilePath, &wfd32);
	
		if(hSrch == INVALID_HANDLE_VALUE)
		{
			TRACE(_T("%s is not exist\n"), strFilePath);
		
			return false;
		}
	
		::FindClose(hSrch);
	
		return true;
	}

	LRESULT CEasyDrillerDlg::OnVisionLive(WPARAM wParam, LPARAM lParam)
	{
		gDeviceFactory.GetVision()->OnLive((int)wParam, (BOOL)lParam);

		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnAutoPowerMeasure(WPARAM wParam, LPARAM lParam)
	{
		double dVal = m_pManualControl->m_pPowerMeasurement->MeasuerPower();
		m_pAutoRun->m_dMeasuredPower[(int)wParam] = dVal;
		int nTool = (int)lParam;
		BOOL b1st;
		if((int)wParam == 0)
			b1st = TRUE;
		else
			b1st = FALSE;

#ifdef __TEST__
		int nRand = rand()%10;
		dVal = 5 + nRand * 0.1;
#endif

		if(m_pAutoRun->m_pPrework)
			m_pAutoRun->m_pPrework->m_pPower->InsertPowerResult(dVal, b1st, nTool);

		m_pAutoRun->m_dMeasuredPower[(int)wParam] = dVal;

		return (LRESULT)(dVal * 1000);
	}

	LRESULT CEasyDrillerDlg::OnResetSwitch(WPARAM wParam, LPARAM lParam)
	{
		gDeviceFactory.GetMotor()->SetError(FALSE);

		m_stcMsg.SetWindowText( _T("No Message") );
	
		return 1L;
	}

	//20110604
	LRESULT CEasyDrillerDlg::OnComponentPreAcq(WPARAM wParam, LPARAM lParam)
	{
		m_pSysSetup->CheckComponentPreAcq();
		return 1L;
	}

	void CEasyDrillerDlg::WriteLog(CString strFile, CString strLog)	
	{

		if(strFile == "Cognex_Tact1" || strFile == "Cognex_Tact2")
			return;

		::EnterCriticalSection( &m_CritLog );

		CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
		CTime EventTime = CTime::GetCurrentTime();
		strPathName += strFile;
#ifndef	__NANYA_NEW__
		strPathName += EventTime.Format(_T("_%y%m%d"));

		CStdioFile cFile;
		if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		{
			::LeaveCriticalSection( &m_CritLog );
			return;
		}

		CString strWrite;
		strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
			EventTime.GetHour(),
			EventTime.GetMinute(),
			EventTime.GetSecond(),
			strLog);
#else
		strPathName += EventTime.Format(_T("_%Y%m%d"));
	
		CStdioFile cFile;
		if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		{
			::LeaveCriticalSection( &m_CritLog );
			return;
		}
	
		CString strWrite;
		strWrite.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s |"),
			EventTime.GetYear(),
			EventTime.GetMonth(),
			EventTime.GetDay(),
			EventTime.GetHour(),
			EventTime.GetMinute(),
			EventTime.GetSecond(),
			strLog);

		if(gDProject.m_CurrentMode == AUTO_DRILL_MODE)
		{
			strWrite += _T("Auto Drill\n");
		}
		else if(gDProject.m_CurrentMode == MANUAL_DRILL_MODE)
		{
			strWrite += _T("Manual Drill\n");
		}
		else
		{
			strWrite += _T("None Drill\n");
		}
#endif


		if(gVariable.m_nChangeDisplayLogMode == 1)
		{
			if(strFile == "AutorunTrace")
				m_dlgAutoLoaderInterface.DisplayStatus(strWrite);
		}



		TRY
		{
			cFile.SeekToEnd();		
			cFile.Write(strWrite, strWrite.GetLength());
			cFile.Close();
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			::LeaveCriticalSection( &m_CritLog );
			return;
		}
		END_CATCH

			::LeaveCriticalSection( &m_CritLog );
	}



	LRESULT CEasyDrillerDlg::OnDoApplySCalResult(WPARAM wParam, LPARAM lParam)
	{
	#ifdef __TEST__
		return TRUE;
	#endif
		::Sleep(100);
		CDlgCalResult DlgCalResult;
		DlgCalResult.SetToolIndex(m_pAutoRun->m_nDoASCTool);
		DlgCalResult.SetTablePos(m_pAutoRun->m_dCalculateStartXAuto, m_pAutoRun->m_dCalculateStartYAuto);

		CString strMaster, strSlave;
		strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_pAutoRun->m_nDoASCTool]);
		strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_pAutoRun->m_nDoASCTool]);
	
		gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(strMaster);
		gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(strSlave);

		int nResultASC;
		nResultASC = m_pAutoRun->m_calAGCMaster.CreateAGCFile();
		if(0 != nResultASC)
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_CREATE);
			strMsg.Format(strString, strMaster, _T("ASC Calibration"));
	//		ErrMessage(strMsg);
		
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return FALSE;
		}
		nResultASC = m_pAutoRun->m_calAGCSlave.CreateAGCFile();
		if(0 != nResultASC)
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_CREATE);
			strMsg.Format(strString, strSlave, _T("ASC Calibration"));
	//		ErrMessage(strMsg);
		
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return FALSE;
		}
	
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, _T("ASC"));

		if(!gDeviceFactory.GetEocard()->LoadCalibrationFile((LPSTR)(LPCTSTR)strMaster, (LPSTR)(LPCTSTR)strSlave))
		{
			CString strTemp;
			strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
			strMsg.Format(strString, strTemp);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return FALSE;
		}
		return 1L;
	}
	LRESULT CEasyDrillerDlg::OnSetAnyPrework(WPARAM wParam, LPARAM lParam)
	{
		int nType = (int)wParam;
	
		if(nType == DO_POWER)
		{
			m_pAutoRun->m_bAnyDoAutoPower = TRUE;
			ResetPowerScannerCalTime(FALSE, TRUE);
		}
	
		if(nType == DO_SCANNER)
		{
			m_pAutoRun->m_bAnyDoAutoSCal = TRUE;
			ResetPowerScannerCalTime(TRUE, FALSE);
		}

		if(nType == DO_POWER + DO_SCANNER)
		{
			m_pAutoRun->m_bAnyDoAutoPower = TRUE;
			m_pAutoRun->m_bAnyDoAutoSCal = TRUE;
			ResetPowerScannerCalTime(TRUE, TRUE);
		}
	
		return 1L;
	}

	void CEasyDrillerDlg::ResetPowerScannerCalTime(BOOL bScanner, BOOL bPower)
	{
	#ifndef __KUNSAN_SAMSUNG_LARGE__
		if(gProcessINI.m_sProcessSystem.bNoUsePrework)
			return;
	#endif

		if(bScanner)
		{
			for(int i = 0; i < BEAMPATH_COUNT; i++)
			{
				gTempINI.m_sTempTime.nAutoScalEndTime[i][0] = 0; //master
				gTempINI.m_sTempTime.nAutoScalEndTime[i][1] = 0; //slave
			}
		}

		if(bPower)
		{
			for(int i = 0; i < BEAMPATH_COUNT; i++)
			{
				gTempINI.m_sTempTime.nAutoPowerEndTime[i][0] = 0; //master
				gTempINI.m_sTempTime.nAutoPowerEndTime[i][1] = 0; //slave
			}

		}
		if(bScanner || bPower)
			OnSaveINIFile(TEMP_INI);
	}


	LRESULT CEasyDrillerDlg::OnDoPowerMeasurement(WPARAM wParam, LPARAM lParam)
	{	
		gDeviceFactory.GetMotor()->TableClamp(TRUE, TRUE);
		gDeviceFactory.GetMotor()->TableClamp(TRUE, FALSE);

		BOOL bRet = m_pAutoRun->CheckPowerAuto();

		m_pAutoRun->m_dlgMeasurement.ShowWindow(SW_HIDE);
	
		if(bRet)
			return 1L;

		return 0L;
	}

	void CEasyDrillerDlg::MessageLoop()
	{
		MSG msg;
	
		if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
		{
			::TranslateMessage((LPMSG)&msg);
			::DispatchMessage((LPMSG )&msg);
		}
	}

	LRESULT CEasyDrillerDlg::OnChillerAlarm(WPARAM wParam, LPARAM lParam)
	{
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnAddFidResult(WPARAM wParam, LPARAM lParam)
	{
		if(m_pAutoRun)
		{
			m_pAutoRun->InsertFidList((int)wParam);
		}

		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnChangeView(WPARAM wParam, LPARAM lParam)
	{
		int nChangePane = (int)wParam;
		BOOL bCapture = (BOOL)lParam;
		if(m_pAutoRun)
			m_pAutoRun->ChangeView(nChangePane, bCapture);

		return 1L;
	}
	LRESULT CEasyDrillerDlg::OnChangePrework(WPARAM wParam, LPARAM lParam)
	{
		if(gProcessINI.m_sProcessSystem.bNoUsePrework)
			return TRUE;

		int nStep = (int)wParam;

		if(!m_pAutoRun->m_pPrework)
			return 1L;
		switch (nStep)
		{
		case DO_PREHEAT : 
			m_pAutoRun->m_pPrework->SetPreworkStatus(TRUE, FALSE, FALSE, FALSE);
			break;
		case DO_POWER : 
			m_pAutoRun->m_pPrework->SetPreworkStatus(FALSE, TRUE, FALSE, FALSE);
			break;
		case DO_DRILL : 
			m_pAutoRun->m_pPrework->SetPreworkStatus(FALSE, FALSE, FALSE, TRUE);
			break;
		case DO_SCANNER : 
			m_pAutoRun->m_pPrework->SetPreworkStatus(FALSE, FALSE, TRUE, FALSE);
			break;
		case DO_NOTING :
			m_pAutoRun->m_pPrework->SetPreworkStatus(FALSE, FALSE, FALSE, FALSE);
			break;
		}

		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnPowerResult(WPARAM wParam, LPARAM lParam)
	{
		int nToolNo = (int)wParam;
		double dVal = (double)lParam /1000.;

		if(m_pAutoRun->m_pPrework)
			m_pAutoRun->m_pPrework->m_pPower->InsertAvgResult(nToolNo, dVal);
		return 1L;
	}
	LRESULT CEasyDrillerDlg::OnScannerResult(WPARAM wParam, LPARAM lParam)
	{
	
		double* pResult = reinterpret_cast<double*>(wParam);
		if(m_pAutoRun->m_pPrework)
			m_pAutoRun->m_pPrework->m_pScanner->InsertScalResult(pResult, (int)lParam);
	
		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnPreDoingDraw(WPARAM wParam, LPARAM lParam)
	{
		if(gProcessINI.m_sProcessSystem.bNoUsePrework)
			return TRUE;

		if(!m_pAutoRun->m_pPrework)
			return 1L;
		BOOL bStart = (BOOL)wParam;
		if(bStart)
			m_pAutoRun->m_pPrework->InitTimer();
		else
			m_pAutoRun->m_pPrework->DestroyTimer();

		return 1L;
	}

	BOOL CEasyDrillerDlg::OpenRecentProject(CString strPath)
	{
		if(FALSE == OpenProject( strPath ))
		{
			ErrMsgDlg(STDGNALM113, _T("Recent file : ") + strPath);
			return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
		}
		SetPrjName( strPath );
	
	
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, FALSE, reinterpret_cast<LPARAM>(&strPath));
	
		//������ ������Ʈ ���½� �н� 
		m_pAutoRun->m_bAnyDoAutoPower = TRUE;
		m_pAutoRun->m_bAnyDoAutoSCal = TRUE;
	
		strcpy_s(gDProject.m_szProjectName, strPath);
	
		CString strMessage,str,strTemp;
		HVision* pVision =gDeviceFactory.GetVision();
		str.Format(_T("%s"),gDProject.m_szVisionProjectName);
		int nlen, n = str.Find(_T("D:"));
		nlen = strlen(str);
		if(n != -1) //TCHAR finding ���ϸ� return = -1
		{
			strTemp = str.Mid(n, nlen-n);
			memset(gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
			strcpy_s(gDProject.m_szVisionProjectName, strTemp);
		
			nlen = strlen(gDProject.m_szVisionProjectName);
			if(nlen > 0)
			{
				if(pVision->LoadProject(strTemp))
				{
					m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText((LPCTSTR)strTemp);
					m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText((LPCTSTR)strTemp);
				}
			}
		}
		else
		{
			memset(&gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
			m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText(_T(""));
			m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText(_T(""));
		}
	
		strcpy_s(gDProject.m_szTempFileName, gDProject.m_szFileName);
		strMessage.Format(_T("Project ( %s ) is opened"), strPath);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
	
		SetFileOpen(TRUE);
		m_pAutoRun->SetPreworkInfo();
	
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER + DO_SCANNER);

		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		return TRUE;
	}

	LRESULT CEasyDrillerDlg::OnDoChangeSCalPreWorkInfo(WPARAM wParam, LPARAM lParam)
	{
		m_pAutoRun->SetPreworkInfo();
		return 1L;
	}
	LRESULT CEasyDrillerDlg::OnDrillOneCycleNoUnload(WPARAM wParam, LPARAM lParam)
	{
		if( NULL != m_pAutoRunSub )
		{
			if(wParam == 0)
				m_pAutoRunSub->EnableButton(FALSE, TRUE, FALSE, TRUE, TRUE);
			else if(wParam == 1)
				m_pAutoRunSub->EnableButton(FALSE, TRUE, TRUE, TRUE, TRUE);
			else if(wParam == 3)
				m_pAutoRunSub->SetOneCycleStopText(TRUE);
			else if(wParam == 4)
				m_pAutoRunSub->SetOneCycleStopText(FALSE);
		}
	
		//	if( NULL != m_pAutoRun )
		//		m_pAutoRun->DrillOneCycleNoUnloadPause();
	
		return 0L;
	}

	LRESULT CEasyDrillerDlg::OnIniUIUpdate(WPARAM wParam, LPARAM lParam)
	{
		m_pProcessSetup->UpdateIniUI(wParam);
		m_pSysSetup->UpdateIniUI(wParam);
		//ReDrawData_WhenTableChange();
		return 1L;
	}

	BOOL CEasyDrillerDlg::CheckOldINIFile(CString strFilePath)
	{
		CFileFind finder;
		int Index = 180;    // �Ⱓ�� ���� ��
	
		CString strFile, strTempFilePath;
		CTime nowTime, Createtime;     
	
		nowTime = CTime::GetCurrentTime();
		// ���� ��¥���� Index ��¥ ��ŭ ����
		nowTime = nowTime - CTimeSpan(Index, 0, 0, 0);
	
		strTempFilePath.Format(_T("%s\\*.*"), strFilePath);
		BOOL bFind = finder.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...
	
		while(bFind)
		{
			bFind = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else if(finder.IsDirectory()) // Delete all sub item.
			{
				strFile = finder.GetFileName();
				// ���� ���� �ð��� ������
				finder.GetCreationTime(Createtime);
			
				// ���� �ð����� Index ��¥ ���� ������ ��� ����
				if(nowTime >= Createtime)
				{
					CString strTemp;
					strTemp.Format(_T("%s\\%s"), strFilePath, strFile);
					CheckOldINIFile(strTemp);   // <---- ���ȣ�� (�ڽ��� �ٽúθ�)
				
					::RemoveDirectory((LPCTSTR)finder.GetFilePath());
				}
			}
			else
			{
				strFile = finder.GetFileName();
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);
			
				// ���� �ð����� Index ��¥ ���� ������ ��� ����
				if(nowTime >= Createtime)
				{
					CString strTemp;
					strTemp.Format(_T("%s\\%s"), strFilePath, strFile);
					::DeleteFile(strTemp);
				}			
			}
		}
		finder.Close();
	
		return TRUE;
	}

	LRESULT CEasyDrillerDlg::OnWindowReadyForFidCap(WPARAM wParam, LPARAM lParam)
	{
		int nChanged = 0;
		if (this->m_hWnd != ::GetForegroundWindow()) // Ÿ���� ���� �۵����� �������̸� ����.
		{
			SetActiveWindow();
			UpdateWindow();
		
			DWORD dwID;
		
			::GetWindowThreadProcessId(::GetForegroundWindow(), &dwID);
			::AttachThreadInput(dwID, ::GetCurrentThreadId(), TRUE);
		
			::ShowWindow(this->m_hWnd, SW_SHOWNORMAL);
			::BringWindowToTop(this->m_hWnd); // �Ʒ� ������� ��ü
		
			::GetWindowThreadProcessId(::GetForegroundWindow(), &dwID);
			::AttachThreadInput(dwID, ::GetCurrentThreadId(), FALSE);
		
			::UpdateWindow(this->m_hWnd);
	//		::SetWindowPos(this->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE);
		
	//		::SetWindowPos(this->m_hWnd, HWND_NOTOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE);
		
		
		
			nChanged = 1;
		}
		CRect rcPanePos;
		this->GetWindowRect( rcPanePos );
		if(rcPanePos.left != 0 || rcPanePos.top != 0)
		{
			rcPanePos.right -= rcPanePos.left;
			rcPanePos.bottom -= rcPanePos.top;
			rcPanePos.left = 0;
			rcPanePos.top = 0;
			this->MoveWindow( &rcPanePos );
			nChanged = 1;
		}
	
		DWORD nHideVisionView = 0;
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
			nHideVisionView = m_pVisionView->GetStyle();
		else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
			nHideVisionView = m_pMatroxVisionView->GetStyle();
		else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			nHideVisionView = m_pVisionProView->GetStyle();
	
		if(!(WS_VISIBLE & nHideVisionView))
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				m_pVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				m_pMatroxVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				m_pVisionProView->ShowWindow(SW_SHOW);
			nChanged = 1;
		}
		//	m_pAutoRun->ConnectView();
		return nChanged;
	}

	void CEasyDrillerDlg::OnTimer(UINT nIDEvent) 
	{
		// TODO: Add your message handler code here and/or call default
	/*	if(nIDEvent == m_nTimer1)
		{
		}
	*/
		CDialog::OnTimer(nIDEvent);
	}

	LRESULT CEasyDrillerDlg::OnEnableSafetyMode(WPARAM wParam, LPARAM lParam)
	{
		GetDlgItem(IDC_STATIC_PRJ_NAME)->ShowWindow(!(BOOL)wParam);
		GetDlgItem(IDC_STATIC_CAD_FILE)->ShowWindow(!(BOOL)wParam);
		GetDlgItem(IDC_STATIC_CAD_NAME)->ShowWindow(!(BOOL)wParam);
		GetDlgItem(IDC_STATIC_MSG)->ShowWindow(!(BOOL)wParam);
	
		GetDlgItem(IDC_STATIC_SAFETY_MSG)->ShowWindow((BOOL)wParam);
	
		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnResortArea(WPARAM wParam, LPARAM lParam)
	{
		if(gProcessINI.m_sProcessSystem.bNoSortArea)
			return TRUE;

		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->SortArea();
		return TRUE;
	}

	void CEasyDrillerDlg::OnButtonIniChange() 
	{
		CDlgLogin dlgLogin;
	
		if( IDOK != dlgLogin.DoModal() )
			return;

		if(dlgLogin.GetUserLevel() != 2)
			return;
	
		CDlgIniInfo dlg;
	
		if( IDOK != dlg.DoModal() )
			return;
	
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
		{
			ErrMsgDlg(STDGNALM110);
		}
		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, UI_ALL);
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
			ErrMsgDlg(STDGNALM108);
		}

		::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, UI_ALL);

		if(dlg.m_bScannerChange)
		{
			if(!gDeviceFactory.GetEocard()->ChangeScannerAxis())
			{
				ErrMessage(_T("Can't change scanner axis"));
				CString strTitle, strMessage;
				strMessage.Format(_T("Can't change scanner axis"));
				strTitle.Format(_T("Eocard error"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strTitle), reinterpret_cast<WPARAM>(&strMessage));
			}
		}

		gDeviceFactory.GetMotor()->SetTemeratureLimits();
	
	}

	LRESULT CEasyDrillerDlg::OnSideWindowShowHide(WPARAM wParam, LPARAM lParam)
	{
		int nDlgType = (int)wParam;
		BOOL bOpen = (BOOL)lParam;

		if(lParam == FID_RESET_ALL && nDlgType == WIDE_FIDUCIALVIEW)
		{
			m_dlgFiducialAllView->ResetAllBitMap();
			return 0;
		}
		if(WIDE_TABLE != nDlgType && WIDE_MOTOR != nDlgType)
		{
			if(!gSystemINI.m_sHardWare.bUseWideMonitor) // 20130404 bhlee
			{
				if(nDlgType != WIDE_FIDUCIALVIEW)
					return 0;
			}
		}
	//	if(gSystemINI.m_sHardWare.bUseWideMonitor && nDlgType == WIDE_FIDUCIALVIEW) // wide ����Ϳ��� fid all view �� ���� ���� ��ɰ� �ߺ��ǹǷ� ���ƾ�����.
	//		return 0;

		int nXScreen = ::GetSystemMetrics(SM_CXSCREEN);
		int nYScreen = ::GetSystemMetrics(SM_CYSCREEN);

		CRect rt;
		CRect rtPos;

		if(bOpen && nDlgType != WIDE_VISION)
		{
			if(nDlgType == WIDE_FIDUCIALVIEW)
				ChangeLilySize(TRUE);
			else
				ChangeLilySize(FALSE);
		}
		GetWindowRect(&rt); // EasyDriller size
	
		int nSubStartX = rt.right;
		int nSubStartY = rt.top;
		int nWide, nHeight; 
	
		if(bOpen)
		{
			if(nDlgType == WIDE_VISION)
			{
				m_bVisionSide = TRUE;
				m_pVisionProView->m_bTopMost = TRUE;

				// wide vision�� �����鼭
				if(m_dlgFiducialAllView->m_bFiducialAllViewDlgShow)
					m_dlgFiducialAllView->SetReSize(FALSE);
			
				OnMoveVisionView();
			}

			if(nDlgType == WIDE_MOTOR)
			{
				m_dlgSideMotor.GetWindowRect(&rtPos);	
				nWide = rtPos.right - rtPos.left;
				nHeight = rtPos.bottom - rtPos.top;
				if(gSystemINI.m_sHardWare.bUseWideMonitor)
				{
					rtPos.top = rt.bottom - rtPos.Height(); 
					rtPos.bottom = rt.bottom;
					rtPos.left = nSubStartX;
					rtPos.right = nSubStartX + nWide;
				}
				else
				{
					rtPos.top = rt.top + rt.Height()/2 - nHeight/2;
					rtPos.bottom = rtPos.top + nHeight;
					rtPos.left = rt.left + rt.Width()/2 - nWide/2;
					rtPos.right = rtPos.left + nWide;
				}
				m_dlgSideMotor.MoveWindow( &rtPos );
				m_dlgSideMotor.ShowWindow(SW_SHOW);
				m_dlgSideMotor.SetDisplayOn(TRUE);
			}

			if(nDlgType == WIDE_FIDUCIALVIEW)
			{
	/*			m_dlgFiducialAllView->GetWindowRect(&rtPos);	
				nWide = rtPos.right - rtPos.left;
				nHeight = rtPos.bottom - rtPos.top;
				rtPos.top = nSubStartY;// + nYScreen/2; 
				rtPos.bottom = nSubStartY + nHeight;// + nYScreen/2;
				rtPos.left = nSubStartX;
				rtPos.right = nSubStartX + nWide;
				m_dlgFiducialAllView->MoveWindow( &rtPos );
				m_dlgFiducialAllView->ShowWindow(SW_SHOW);
	*/

				m_dlgFiducialAllView->m_bFiducialAllViewDlgShow = TRUE;
				if(GetSideStatus()) // wide vision�� ���� ������
					m_dlgFiducialAllView->SetReSize(FALSE);
				else
					m_dlgFiducialAllView->SetReSize(TRUE);
			//	m_dlgFiducialAllView.ResetAllBitMap();

				OnMoveVisionView(); // vision�� �����ִٸ� fiducial all dlg ��ġ�� �̵�
			
			}
			if(nDlgType == WIDE_TABLE)
			{
				m_dlgTable.GetWindowRect(&rtPos);	
				nWide = rtPos.right - rtPos.left;
				nHeight = rtPos.bottom - rtPos.top;
			
				if(gSystemINI.m_sHardWare.bUseWideMonitor)
				{
					rtPos.top = nSubStartY; 
					rtPos.bottom = nSubStartY + nHeight;
					rtPos.left = nSubStartX;
					rtPos.right = nSubStartX + nWide;
				}
				else
				{
					rtPos.top = rt.top + rt.Height()/2 - nHeight/2;
					rtPos.bottom = rtPos.top + nHeight;
					rtPos.left = rt.left + rt.Width()/2 - nWide/2;
					rtPos.right = rtPos.left + nWide;
				}
				m_dlgTable.MoveWindow( &rtPos );
				m_dlgTable.ShowWindow(SW_SHOW);
				m_dlgTable.SetDisplayOn(TRUE);
			}

			if(nDlgType == WIDE_LPC)
			{
				m_dlgLpc.GetWindowRect(&rtPos);	
				nWide = rtPos.right - rtPos.left;
				nHeight = rtPos.bottom - rtPos.top;
				if(gSystemINI.m_sHardWare.bUseWideMonitor)
				{
					rtPos.top = rt.bottom - rtPos.Height(); 
					rtPos.bottom = rt.bottom;
					rtPos.left = nSubStartX;
					rtPos.right = nSubStartX + nWide;
				}
				else
				{
					rtPos.top = rt.top + rt.Height()/2 - nHeight/2;
					rtPos.bottom = rtPos.top + nHeight;
					rtPos.left = rt.left + rt.Width()/2 - nWide/2;
					rtPos.right = rtPos.left + nWide;
				}
				m_dlgLpc.MoveWindow( &rtPos );
				m_dlgLpc.ShowWindow(SW_SHOW);
				m_dlgSideMotor.SetDisplayOn(FALSE);
				m_dlgSideMotor.ShowWindow(SW_HIDE);
			}
		
		}
		else if(!bOpen)
		{
			if(nDlgType == WIDE_VISION)
			{
				m_bVisionSide = FALSE;
				m_pVisionProView->m_bTopMost = FALSE;
				OnMoveVisionView();
				m_bVisionSide = FALSE;

				if(m_dlgFiducialAllView->m_bFiducialAllViewDlgShow) // ũ�⸦ Ű���.
					m_dlgFiducialAllView->SetReSize(TRUE);
		
			}
			if(nDlgType == WIDE_MOTOR)
			{
				m_dlgSideMotor.SetDisplayOn(FALSE);
				m_dlgSideMotor.ShowWindow(SW_HIDE);
			}

			if(nDlgType == WIDE_LPC)
				m_dlgLpc.ShowWindow(SW_HIDE);

			if(nDlgType == WIDE_FIDUCIALVIEW)
			{
	//			m_dlgFiducialAllView->ShowWindow(SW_HIDE);
				m_dlgFiducialAllView->m_bFiducialAllViewDlgShow = FALSE;

				OnMoveVisionView(); // vision�� �����ִٸ� ���� ��ġ�� ����
			}
			if(nDlgType == WIDE_TABLE)
			{
				m_dlgTable.SetDisplayOn(FALSE);
				m_dlgTable.ShowWindow(SW_HIDE);
			}
		}
	
		return TRUE;
	}



	LRESULT CEasyDrillerDlg::OnReDrawTableData(WPARAM wParam, LPARAM lParam)
	{

        ReDrawData_WhenTableChange();

		return 1;
	}

	void CEasyDrillerDlg::SetBitMap(HBITMAP hBitmap, BOOL bFirst, int nFidIndex, int nFidBlock) // 20130404 bhlee
	{
		m_dlgFiducialAllView->SetBitMap(hBitmap, bFirst, nFidIndex, nFidBlock);
	}

	void CEasyDrillerDlg::ResetAllBitMap()
	{
		m_dlgFiducialAllView->ResetAllBitMap();
	}

	LRESULT CEasyDrillerDlg::OnMainUIMoveTopLeft(WPARAM wParam, LPARAM lParam)
	{
		if(gSystemINI.m_sHardWare.bUseWideMonitor)
		{
			CRect rcPanePos;
			this->GetWindowRect( rcPanePos );
			if(rcPanePos.left != 0 || rcPanePos.top != 0)
			{
				rcPanePos.right -= rcPanePos.left;
				rcPanePos.bottom -= rcPanePos.top;
				rcPanePos.left = 0;
				rcPanePos.top = 0;
				this->MoveWindow( &rcPanePos );
			}
		}
		return TRUE;
	}

	LRESULT CEasyDrillerDlg::OnOldProjectBackUpAndDelete(WPARAM wParam, LPARAM lParam)
	{
		CString* strFilePath = reinterpret_cast<CString*>(lParam);
		CString strBackupPath;
		CString strPath = *strFilePath;
		int nIndex = strPath.ReverseFind(_T('\\')) + 1;
		CString strName = strPath.Mid(nIndex);
		BOOL bExist;
	
		//delete or backup
		BOOL bDelete = (BOOL)wParam;
	
		if(bDelete)
		{
			CFileFind finder;
			//		int Index = 180;    // �Ⱓ�� ���� ��
		
			CString strFile, strTempFilePath;
		
			strTempFilePath.Format(_T("%sBackup\\*.prj"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
			BOOL bFind = finder.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...
		
			while(bFind)
			{
				bFind = finder.FindNextFile();
				if(finder.IsDots())
					continue;
				else
				{
					strFile = finder.GetFileName();
				
					CString strTemp;
					strTemp.Format(_T("%sBackup\\%s"),gEasyDrillerINI.m_clsDirPath.GetRootDir(), strName);
					::DeleteFile(strTemp);
				
				}
			}
			finder.Close();
		
		}
		else
		{
		
			bExist = IsFileExist(strPath);
			if(bExist)
			{
				strBackupPath.Format(_T("%sBackup\\%s"), gEasyDrillerINI.m_clsDirPath.GetRootDir(),strName);
				bExist = CopyFile(strPath, strBackupPath, FALSE);
				if(!bExist)
					return FALSE;
			}
		}
	
		return 1;
	}

	void CEasyDrillerDlg::ResetProject()
	{

	}

	void CEasyDrillerDlg::SetLilyVersion()
	{
		CString strVersion;
		CString strMachineNo;

		strVersion.Format(_T("Lily DPS200 - EO Technics Co., Ltd. "));

		CString strVerTemp;

		strVerTemp.Format("Ver. 2021/09/09.1 New Ver [2010]");
		strVersion += strVerTemp;

		CString strSite = " AT&S";

		strVersion += strSite;

		strMachineNo.Format(_T(" - MachineNo : %d"),gSystemINI.m_sHardWare.nMachineNo);
		strVersion += strMachineNo;

#ifdef __USE_COGNEX_7_LIB__
		strVersion += " - Cognex 7.2";
#else
		strVersion += " - Cognex 9.2";
#endif

#ifdef __USE_COGNEX_SOCKET__
		strVersion += " (TCP/IP)";
#endif



		SetWindowText((LPCTSTR)strVersion);

		WriteProcessLog(strVersion, _T(""));
	}

	BOOL CEasyDrillerDlg::GetSideStatus()
	{
		return m_bVisionSide;
	}
	LRESULT CEasyDrillerDlg::OnResizeVision(WPARAM wParam, LPARAM lParam)
	{
		int* nRect = (int *)wParam;
		CRect rc;
		rc.left = nRect[0];
		rc.right = nRect[1];
		rc.top = nRect[2];
		rc.bottom = nRect[3]; 

		if(m_pVisionProView)
			m_pVisionProView->ReSize(rc);
		return 1;
	}

	void CEasyDrillerDlg::BackupOldLogFile(void)
	{
		CProgressWnd wndProgress(NULL, _T("Data Backup"), TRUE);
		wndProgress.GoModal();
		wndProgress.SetRange(0, 0);
		wndProgress.SetText(_T("Data Backup"));
		// backup dir
		if( 0 != _chdir( _T("D:\\ViaHole_OldLog\\") ) )
			_mkdir( _T("D:\\ViaHole_OldLog\\") ); // Create 

		int Index = gProcessINI.m_sProcessFidFind.nLogSaveData;    // �Ⱓ�� ���� ��
	
		CString strFile, strTempFilePath;
		CTime nowTime, Createtime;     
	
		nowTime = CTime::GetCurrentTime();
		// ���� ��¥���� Index ��¥ ��ŭ ����
		nowTime = nowTime - CTimeSpan(Index, 0, 0, 0); // 90��
	
		CFileFind finder1;
		strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetBackupDir());
		BOOL bFind = finder1.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...
	
		while(bFind)
		{
			bFind = finder1.FindNextFile();
			if(finder1.IsDirectory())
				continue;
			else
			{
				strFile = finder1.GetFileName();
				// ���� ���� �ð��� ������
				finder1.GetLastWriteTime(Createtime);
			
				// ���� �ð����� Index ��¥ ���� ������ ��� ����
				if(nowTime >= Createtime)
				{
					CString strTempOrigin, strMovePath;
					strTempOrigin.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetBackupDir(), strFile);

					strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
					CopyFile(strTempOrigin, strMovePath, FALSE);

					::DeleteFile(strTempOrigin);
				}
			}
		}
		finder1.Close();

		CFileFind finder2;
		strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		bFind = finder2.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...
	
		while(bFind)
		{
			bFind = finder2.FindNextFile();
			if(finder2.IsDirectory())
				continue;
			else
			{
				strFile = finder2.GetFileName();
				// ���� ���� �ð��� ������
				finder2.GetLastWriteTime(Createtime);
			
				// ���� �ð����� Index ��¥ ���� ������ ��� ����
				if(nowTime >= Createtime)
				{
					CString strTempOrigin, strMovePath;
					strTempOrigin.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);

					strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
					CopyFile(strTempOrigin, strMovePath, FALSE);

					::DeleteFile(strTempOrigin);
				}
			}
		}
		finder2.Close();

		CFileFind finder3;
		strTempFilePath.Format(_T("%sBackup\\*"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
		bFind = finder3.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...
	
		while(bFind)
		{
			bFind = finder3.FindNextFile();
			if(finder3.IsDirectory())
				continue;
			else
			{
				strFile = finder3.GetFileName();
				// ���� ���� �ð��� ������
				finder3.GetLastWriteTime(Createtime);
			
				// ���� �ð����� Index ��¥ ���� ������ ��� ����
				if(nowTime >= Createtime)
				{
					CString strTempOrigin, strMovePath;
					strTempOrigin.Format(_T("%sBackup\\%s"), gEasyDrillerINI.m_clsDirPath.GetSystemDir(), strFile);

					strMovePath.Format(_T("D:\\ViaHole_OldLog\\%s"), strFile);
					CopyFile(strTempOrigin, strMovePath, FALSE);

					::DeleteFile(strTempOrigin);
				}
			}
		}
		finder3.Close();
		wndProgress.SetParentWinActive();
	}

	void CEasyDrillerDlg::ActiveStaticForKeyboardError()
	{
		if(gProcessINI.m_sProcessSystem.bNoUsePrework)
			return; 

		if(m_pAutoRun->m_pPrework != NULL)
			m_pAutoRun->m_pPrework->ActiveStaticForKeyboardError();
	}
#ifndef __NANYA_NEW__
	void CEasyDrillerDlg::LogCopy() //20130410 jghan
	{
		CString strFile2, strLog;
		strFile2.Format(_T("LogCopy"));
		strLog.Format(_T("Daily Log Copy Start "));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
		// delete file
		CFileFind finder;
		CString strFile, strTempFilePath;
		CTime nowTime, Createtime;     

		nowTime = CTime::GetCurrentTime();
		// ���� ��¥���� Index ��¥ ��ŭ ����

		CString strFolder, strSaveFile, strLoadFile;


#ifdef __NANYA__
		strFolder.Format(_T("%sSystem\\ProcessLog\\%03d\\log"),gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), 1 /*gSystemINI.m_sHardWare.nMachineNo*/);
#else
		strFolder.Format(_T("%slog"),gEasyDrillerINI.m_clsDirPath.GetScaleLogDir());
#endif


		if( 0 != _chdir( strFolder ))
			_mkdir(strFolder);
		
		if( 0 != _chdir( strFolder ))
			_mkdir(strFolder);

		nowTime = CTime::GetCurrentTime();
		//	nowTime = nowTime - CTimeSpan(30, 0, 0, 0); 

		strTempFilePath.Format(_T("%sJobTime*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind1 = finder.FindFile(strTempFilePath);

		while(blogFind1)
		{
			blogFind1 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetMonth() -1 == Createtime.GetMonth() ||  nowTime.GetMonth() == Createtime.GetMonth())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sLog*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind2 = finder.FindFile(strTempFilePath);

		while(blogFind2)
		{
			blogFind2 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		strTempFilePath.Format(_T("%sPrework*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind3 = finder.FindFile(strTempFilePath);

		while(blogFind3)
		{
			blogFind3 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();


		nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sProcess*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind4 = finder.FindFile(strTempFilePath);

		while(blogFind4)
		{
			blogFind4 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();
	
	}
#else

	void CEasyDrillerDlg::LogCopy() //20130410 jghan
	{
		CString strFile2, strLog;
		strFile2.Format(_T("LogCopy"));
		strLog.Format(_T("Daily Log Copy Start "));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
		// delete file
		CFileFind finder;
		CString strFile, strTempFilePath;
		CTime nowTime, Createtime;     

		nowTime = CTime::GetCurrentTime();
		// ���� ��¥���� Index ��¥ ��ŭ ����

		CString strFolder, strSaveFile, strLoadFile;


#ifdef __NANYA_NEW__
		strFolder.Format(_T("%s\\ProcessLog\\%03d\\log"),gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo);
#else
		strFolder.Format(_T("%s\\ProcessLog\\%03d\\log"),gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), 1 /*gSystemINI.m_sHardWare.nMachineNo*/);
		//strFolder.Format(_T("%slog"),gEasyDrillerINI.m_clsDirPath.GetScaleLogDir());
#endif

		if( 0 != _chdir( strFolder ))
			_mkdir(strFolder);

		nowTime = CTime::GetCurrentTime();
		//	nowTime = nowTime - CTimeSpan(30, 0, 0, 0); 

		strTempFilePath.Format(_T("%sJobViewTime*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind1 = finder.FindFile(strTempFilePath);

		while(blogFind1)
		{
			blogFind1 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetMonth() -1 == Createtime.GetMonth() ||  nowTime.GetMonth() == Createtime.GetMonth())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sErrorID*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind2 = finder.FindFile(strTempFilePath);

		while(blogFind2)
		{
			blogFind2 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		//strTempFilePath.Format(_T("%sPrework*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		//BOOL blogFind3 = finder.FindFile(strTempFilePath);

		//while(blogFind3)
		//{
		//	blogFind3 = finder.FindNextFile();
		//	if(finder.IsDots())
		//		continue;
		//	else
		//	{
		//		strFile = finder.GetFileName();
		//		strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
		//		strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
		//		// ���� ���� �ð��� ������
		//		finder.GetLastWriteTime(Createtime);

		//		if( nowTime <= Createtime)
		//		{
		//			CopyFile(strLoadFile, strSaveFile, FALSE);

		//		}
		//	}
		//}
		//finder.Close();


		nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sProcess*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind4 = finder.FindFile(strTempFilePath);

		while(blogFind4)
		{
			blogFind4 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();


		strTempFilePath.Format(_T("%sPowerTrend"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind5 = finder.FindFile(strTempFilePath);

		while(blogFind5)
		{
			blogFind5 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		strTempFilePath.Format(_T("%sSCalLog*"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
		BOOL blogFind6 = finder.FindFile(strTempFilePath);

		while(blogFind6)
		{
			blogFind6 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();


		strTempFilePath.Format(_T("%sFiducialScale*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind7 = finder.FindFile(strTempFilePath);

		while(blogFind7)
		{
			blogFind7 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);
				int nFileLen;
				nFileLen = strFile.GetLength();
				if((nFileLen - 13) > 6)
					continue;
				if( nowTime <= Createtime)
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		strLog.Format(_T("Daily Log Copy End "));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
	}

#endif



	void CEasyDrillerDlg::LogCopyDaily()
	{
		CString strFile2, strLog;
		strFile2.Format(_T("LogCopy"));
		strLog.Format(_T("30 Min Log Copy Start "));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
		// delete file
		CFileFind finder;
		CString strFile, strTempFilePath;
		CTime nowTime, Createtime;     

		nowTime = CTime::GetCurrentTime();
		// ���� ��¥���� Index ��¥ ��ŭ ����

		CString strFolder, strSaveFile, strLoadFile;


#ifdef __NANYA_NEW__
		strFolder.Format(_T("%s\\ProcessLog\\%03d\\log"),gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo);
#else
		strFolder.Format(_T("%s\\ProcessLog\\%03d\\log"),gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), 1 /*gSystemINI.m_sHardWare.nMachineNo*/);
		//strFolder.Format(_T("%slog"),gEasyDrillerINI.m_clsDirPath.GetScaleLogDir());
#endif


		if( 0 != _chdir( strFolder ))
			_mkdir(strFolder);

		nowTime = CTime::GetCurrentTime();
		//	nowTime = nowTime - CTimeSpan(30, 0, 0, 0); 

		strTempFilePath.Format(_T("%sJobViewTime*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind1 = finder.FindFile(strTempFilePath);

		while(blogFind1)
		{
			blogFind1 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		//nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sErrorID*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind2 = finder.FindFile(strTempFilePath);

		while(blogFind2)
		{
			blogFind2 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		//strTempFilePath.Format(_T("%sPrework*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		//BOOL blogFind3 = finder.FindFile(strTempFilePath);

		//while(blogFind3)
		//{
		//	blogFind3 = finder.FindNextFile();
		//	if(finder.IsDots())
		//		continue;
		//	else
		//	{
		//		strFile = finder.GetFileName();
		//		strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
		//		strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
		//		// ���� ���� �ð��� ������
		//		finder.GetLastWriteTime(Createtime);

		//		if( nowTime <= Createtime)
		//		{
		//			CopyFile(strLoadFile, strSaveFile, FALSE);

		//		}
		//	}
		//}
		//finder.Close();


		//nowTime = nowTime - CTimeSpan(30, 0, 0, 0);
		strTempFilePath.Format(_T("%sProcess*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind4 = finder.FindFile(strTempFilePath);

		while(blogFind4)
		{
			blogFind4 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();


		strTempFilePath.Format(_T("%sPowerTrend"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind5 = finder.FindFile(strTempFilePath);

		while(blogFind5)
		{
			blogFind5 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		strTempFilePath.Format(_T("%sSCalLog*"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
		BOOL blogFind6 = finder.FindFile(strTempFilePath);

		while(blogFind6)
		{
			blogFind6 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();


		strTempFilePath.Format(_T("%sFiducialScale*"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
		BOOL blogFind7 = finder.FindFile(strTempFilePath);

		while(blogFind7)
		{
			blogFind7 = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
				// ���� ���� �ð��� ������
				finder.GetLastWriteTime(Createtime);

				if( nowTime.GetYear() == Createtime.GetYear() && nowTime.GetMonth() == Createtime.GetMonth() &&  nowTime.GetDay() == Createtime.GetDay())
				{
					CopyFile(strLoadFile, strSaveFile, FALSE);

				}
			}
		}
		finder.Close();

		strLog.Format(_T("30 Min Log Copy End "));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
	}



	LRESULT CEasyDrillerDlg::OnCalAutoScalPos(WPARAM wParam, LPARAM lParam)
	{
		double dStartX = gProcessINI.m_sProcessScannerCal.dAutoStart.x;
		double dStartY = gProcessINI.m_sProcessScannerCal.dAutoStart.y;
		double dField = gSystemINI.m_sSystemDevice.dFieldSize.x;
		int nUseFieldCount = gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount;
		int nUseVisionFieldCount = gProcessINI.m_sProcessCal.nVisionCalibrationFieldCount;
		gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX = dStartX - dField/2; // start pos -> scanner center pos, add half field 
		gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY = dStartY - dField/2;

		gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX = dStartX + (nUseFieldCount) * (dField + 10) + dField/2 +
			nUseVisionFieldCount * (gSystemINI.m_sSystemDevice.dFieldSize.x + 30);
		gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY = dStartY + dField/2; 
		
		//::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, UI_ALL);
		return TRUE;
	}
	LRESULT CEasyDrillerDlg::OnChangeTableMode(WPARAM wParam, LPARAM lParam)
	{
		int nType = (int)wParam;
		int nCam = (int)lParam;
		m_dlgTable.SetMode(nType, nCam);
		return 1L;
	}
	void CEasyDrillerDlg::Capture() //20130416 jghan
	{
		int nx =0, ny = 0;
		CImage capImage;
		CRect rect;
		CWnd *pDesktopWnd = GetActiveWindow();
		HDC hDC = NULL; 
		if(!pDesktopWnd)
			return;
		CWindowDC DeskTopDC(pDesktopWnd);
		GetActiveWindow()->GetWindowRect(&rect);
		if(!capImage.Create(rect.Width(), rect.Height(), 32))
			return;
		hDC = capImage.GetDC(); 
		BitBlt(hDC, 0,0, rect.Width(), rect.Height(), DeskTopDC.m_hDC, 0, 0, SRCCOPY);
		CString strPath;
		CTime cTime = CTime::GetCurrentTime();
		strPath.Format(_T("%s\\%s.jpg"),gEasyDrillerINI.m_clsDirPath.GetImageDir(),cTime.Format(_T("%Y%m%d_%H%M%S")));

		capImage.Save(strPath, Gdiplus::ImageFormatJPEG);
		capImage.ReleaseDC();
	
		/*
		CRect rtPos; 
		CString strFile;
		GetActiveWindow()->GetWindowRect(&rtPos);
		CTime cTime = CTime::GetCurrentTime();
		strFile.Format(_T("%s\\%s"),gEasyDrillerINI.m_clsDirPath.GetImageDir(),cTime.Format(_T("%Y%m%d_%H%M%S")));

		HDC h_screen_dc = ::GetDC(NULL);
		// ���� ��ũ���� �ػ󵵸� ��´�.
		int width = rtPos.Width();//::GetDeviceCaps(h_screen_dc, HORZRES);
		int height = rtPos.Height();//::GetDeviceCaps(h_screen_dc, VERTRES);

		// DIB�� ������ �����Ѵ�.
		BITMAPINFO dib_define;
		dib_define.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		dib_define.bmiHeader.biWidth = width;
		dib_define.bmiHeader.biHeight = height;
		dib_define.bmiHeader.biPlanes = 1;
		dib_define.bmiHeader.biBitCount = 24;
		dib_define.bmiHeader.biCompression = BI_RGB;
		dib_define.bmiHeader.biSizeImage = (((width * 24 + 31) & ~31) >> 3) * height;
		dib_define.bmiHeader.biXPelsPerMeter = 0;
		dib_define.bmiHeader.biYPelsPerMeter = 0;
		dib_define.bmiHeader.biClrImportant = 0;
		dib_define.bmiHeader.biClrUsed = 0;

		// DIB�� ���� �̹��� ��Ʈ ������ ������ ������ ����
		BYTE *p_image_data = NULL;

		// dib_define�� ���ǵ� �������� DIB�� �����Ѵ�.
		HBITMAP h_bitmap = ::CreateDIBSection(h_screen_dc, &dib_define, DIB_RGB_COLORS, (void **)&p_image_data, 0, 0);

		// �̹��� �����ϱ� ���ؼ� ���� DC ����. ���� DC������ ���������� ��Ʈ�ʿ� �����Ͽ�
		// �̹��� ������ ���� �� ���� �����̴�.
		HDC h_memory_dc = ::CreateCompatibleDC(h_screen_dc);

		// ���� DC�� �̹����� ������ ��Ʈ���� �����Ѵ�.
		HBITMAP h_old_bitmap = (HBITMAP)::SelectObject(h_memory_dc, h_bitmap);

		// ���� ��ũ�� ȭ���� ĸ���Ѵ�.
		::BitBlt(h_memory_dc, 0, 0, width, height, h_screen_dc, rtPos.left, rtPos.top, SRCCOPY);

		// ������ ��Ʈ������ �����Ѵ�.
		::SelectObject(h_memory_dc, h_old_bitmap);

		// ���� DC�� �����Ѵ�.
		DeleteDC(h_memory_dc);

		// DIB ������ ��� ������ �����Ѵ�.
		BITMAPFILEHEADER dib_format_layout;
		ZeroMemory(&dib_format_layout, sizeof(BITMAPFILEHEADER));
		dib_format_layout.bfType = *(WORD*)"BM";
		dib_format_layout.bfSize = sizeof(BITMAPFILEHEADER) + 
			sizeof(BITMAPINFOHEADER) + dib_define.bmiHeader.biSizeImage;
		dib_format_layout.bfOffBits = sizeof(BITMAPFILEHEADER) +
			sizeof(BITMAPINFOHEADER);

	//���� ���丮���� �� ������ �������� [data]\\save\\ ������ ����
		CString directory;


		// DIB ������ �����Ѵ�.
		FILE *p_file;
		errno_t err = fopen_s(&p_file, strFile, "wb");
		if(err == NULL){
			fwrite(&dib_format_layout, 1, sizeof(BITMAPFILEHEADER), p_file);
			fwrite(&dib_define, 1, sizeof(BITMAPINFOHEADER), p_file);
			fwrite(p_image_data, 1, dib_define.bmiHeader.biSizeImage, p_file);
			fclose(p_file);
		}

		if(NULL != h_bitmap) DeleteObject(h_bitmap);


		if(NULL != h_screen_dc) ::ReleaseDC(NULL, h_screen_dc);
		*/
	}

	LRESULT CEasyDrillerDlg::OnIdleMode(WPARAM wParam, LPARAM lParam)
	{
		m_bShowIdleDlg = TRUE;

		CDlgIdleMode dlg;
		dlg.DoModal();
	
		m_bShowIdleDlg = FALSE;

		OnMoveVisionView();
		return 1;

	}
	LRESULT CEasyDrillerDlg::OnIdlePower(WPARAM wParam, LPARAM lParam)
	{
		

		BOOL bRet =  m_pAutoRun->DoIdleModePower();

		if(!bRet)
		{
			if(m_pAutoRun->m_nErrMsgID != 0)
			{
				m_pAutoRun->SetErrMsg();
			}

		}
		return bRet;
	}


	LRESULT CEasyDrillerDlg::OnShow4Way(WPARAM wParam, LPARAM lParam)
	{

		if (wParam == NULL)
			return 0L;

		CString* strDisplay = reinterpret_cast<CString*>(wParam);

		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgShow4Way->DisplayShow4Way(*strDisplay);
		return 0;
	}
LRESULT CEasyDrillerDlg::OnIdleScal(WPARAM wParam, LPARAM lParam)
	{


		BOOL bRet =  m_pAutoRun->DoIdleModeSCal();

		if(!bRet)
		{
			if(m_pAutoRun->m_nErrMsgID != 0)
			{
				m_pAutoRun->SetErrMsg();
			}

		}
		return bRet;
	}

LRESULT CEasyDrillerDlg::OnIdlePreHeat(WPARAM wParam, LPARAM lParam)
{


	BOOL bRet =  m_pAutoRun->DoIdleModePreHeat();

	if(!bRet)
	{
		if(m_pAutoRun->m_nErrMsgID != 0)
		{
			m_pAutoRun->SetErrMsg();
		}

	}
	return bRet;
}


	LRESULT CEasyDrillerDlg::OnButtonMessage(WPARAM wParam, LPARAM lParam) // 20130522
	{
 		CString pstrEvent;

		pstrEvent.GetBuffer(256);
		pstrEvent.Format(_T("%s"), m_cButtonInfo);
		pstrEvent.ReleaseBuffer();
		if(pstrEvent.GetLength() <= 0)
			return 1L;

		WriteProcessLog(pstrEvent, _T(""));
		return 1L;
	}

	void CEasyDrillerDlg::SetButtonInfo(CString str)
	{
		memset(m_cButtonInfo, NULL, 256);
		memcpy(m_cButtonInfo, str, str.GetLength());

		for(int i = 0; i < str.GetLength(); i++)
		{
			if(m_cButtonInfo[i] == _T('\r'))
				m_cButtonInfo[i] =  _T(' ');
			else if(m_cButtonInfo[i] == _T('\n'))
				m_cButtonInfo[i] =  _T(' ');
		}
	}

	LRESULT CEasyDrillerDlg::OnUpdateTag(WPARAM wParam, LPARAM lParam)
	{
	#ifndef __NO_USE_OPC__
		//m_pProcessSetup->UpdateIniUI(wParam);
		ResetOPCRecvMessage();
			CString* pstrMsg = reinterpret_cast<CString*>(lParam);
		UpdateTagMessage((long)wParam, *pstrMsg);
	#endif
		return 1L;
	}

	void CEasyDrillerDlg::UpdateTagMessage(long nIndex, LPCTSTR szData)
	{
	#ifndef __NO_USE_OPC__
		CString strTime, strData;
		strData.Format("%s",szData);
		CTime EventTime = CTime::GetCurrentTime();

		strTime.Format("%02d%02d%02d",
			EventTime.GetHour(), EventTime.GetMinute(), EventTime.GetSecond());
		
		if(nIndex == 52 ||
		   nIndex == 53 ||
		   nIndex == 54 ||
		   nIndex == 55 ||
		   nIndex == 56 ||
		   nIndex == 91 ||
		   (nIndex >= 94 && nIndex <= 106))	//M_Tag�� �ð� ���� ����
		{
			strData.Format("%s", szData);
		}
		else
			strData.Format("%s;%s", strTime, szData);	
	
		m_pOpc->GetTagMessage(nIndex, strData);
	#endif
	}

	BOOL CEasyDrillerDlg::GetOPCConnection1()
	{
		return m_pOpc->GetConnection1();
	}

	BOOL CEasyDrillerDlg::GetOPCConnection2()
	{
		return m_pOpc->GetConnection2();
	}

	CString CEasyDrillerDlg::GetOPCStatus(int nNum)
	{
		if(nNum == 1)
			return m_pOpc->m_strStatusCode;
		else if(nNum == 2)
			return m_pOpc->m_strStatus;

		return "";
	}


	int CEasyDrillerDlg::GetCurrentLotID(CString& strLotID1, CString& strLotID2, CString& strPrj1, CString& strPrj2)
	{
	/*	int nIndex = 0;
		int nLotTotalCnt[MAX_LOTID_CNT];
		for(int i = 0; i < MAX_LOTID_CNT; i++)
		{
			if(i == 0)
				nLotTotalCnt[i] = gLotInfo.nLotCount[i];
			else
				nLotTotalCnt[i] = nLotTotalCnt[i-1] + gLotInfo.nLotCount[i];
		}

		for(int i = 0; i < MAX_LOTID_CNT; i++)
		{
			if(m_pAutoRun->m_nCurrentLotCount + 1 <= nLotTotalCnt[i] || i == MAX_LOTID_CNT - 1)
			{
				nIndex = i;
				break;
			}
		}
	*/
		int nIndex = 0;
		int nTotalLotCount = 0;
		for(int i = 0; i < MAX_LOTID_CNT; i++)
		{
			nTotalLotCount += (gLotInfo.nLotCount[i] - gLotInfo.nNGLotCount[i]);
			if(m_pAutoRun->m_nTotalCurrentLotCount < nTotalLotCount)
			{
				nIndex = i;
				break;
			}
		}

		strLotID1.Format("%s", gLotInfo.szLotID[nIndex]); //current
		strLotID2.Format("%s", gLotInfo.szLotID[nIndex]);
		strPrj1.Format("%s", gLotInfo.szPrj[nIndex]);
		strPrj2.Format("%s", gLotInfo.szPrj[nIndex]);


		return nIndex;
	}
	BOOL CEasyDrillerDlg::GetRMSReturnData(CString& strLotCount, CString& strFilmNo, CString& strProcessCode)
	{
		int nTimeOut = 0;
		BOOL bTimeOut = FALSE;
		MSG msg;
		CString strData1 = _T("");
		while(strcmp(m_pOpc->m_RMSReturnData,"") == 0)
		{
			Sleep(1);
			if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
			{
				::TranslateMessage((LPMSG)&msg);
				::DispatchMessage((LPMSG)&msg);
			}
		
			if(nTimeOut > 5000)
			{
				bTimeOut = TRUE;
				break;
			}
			nTimeOut++;
		}
	
		if(bTimeOut == TRUE)
		{
			ErrMessage(_T("MES Time out"));
			return FALSE;
		}
		CString strGetResult = _T("");
		CString strGetMessage = _T("");
		CString strGetLotID = _T("");
		CString strGetLotNo = _T("");
		CString strGetFilmNo = _T("");
		CString strGetMESCode = _T("");

		char* pToken;
		char szStr[500] = {0,};
		int nCount = 0;
		int nDuplicate = m_pOpc->m_RMSReturnData.Find(";;", 0);
		CString strFirst = _T("");
		CString strSecond = _T("");

		while(nDuplicate != -1)
		{
			strFirst = m_pOpc->m_RMSReturnData.Left(nDuplicate + 1);
			strSecond = " " + m_pOpc->m_RMSReturnData.Mid(nDuplicate + 1, m_pOpc->m_RMSReturnData.GetLength() );
			m_pOpc->m_RMSReturnData = strFirst + strSecond;
			nDuplicate = m_pOpc->m_RMSReturnData.Find(";;", 0);
		}

		sprintf(szStr, "%s", m_pOpc->m_RMSReturnData);
		m_pOpc->m_RMSReturnData = "";
		pToken = strtok(szStr, ";");
		while(pToken != NULL)
		{
			if(nCount == 1)
			{
				strGetLotID.Format("%s", pToken);
			}
			if(nCount == 2)
			{
				strGetResult.Format("%s", pToken);
			}
			if(nCount == 4)
			{
				strGetLotNo.Format("%s", pToken);
			}
			if(nCount == 5)
			{
				strGetMessage.Format("%s", pToken);
			}
			if(nCount == 7)
			{
				strGetFilmNo.Format("%s", pToken);
			}
			if(nCount == 8)
			{
				strGetMESCode.Format("%s", pToken);
			}

			pToken = strtok(NULL, ";");
			nCount++;
		}
	#ifdef __TEST__
		strGetResult.Format(_T("pass"));
	#endif
		strGetResult.MakeUpper();
		if(strcmp(strGetResult, "PASS") == 0)
		{
			strLotCount = strGetLotNo;
			strFilmNo = strGetFilmNo;
			strProcessCode = strGetMESCode;
			return TRUE;
		}
		else if(strcmp(strGetResult, "FAIL") == 0)
		{
			CString strMessage;
			strMessage.Format("Lot ID : %s\nFail Message : %s\nLot No : %s\nFilm No : %s\nMES Code : %s\n", strGetLotID, strGetMessage, strGetLotNo, strGetFilmNo, strGetMESCode);
			ErrMessage(_T("FAIL\n") + strMessage, MB_YESNO | MB_TOPMOST );
			return FALSE;
		}
		else 
			return FALSE;

		return TRUE;
	}
	CString CEasyDrillerDlg::GetMESReturnData1()
	{
		int nTimeOut = 0;
		BOOL bTimeOut = FALSE;
		MSG msg;
		CString strData1 = _T("");
		while(strcmp(m_pOpc->m_strData1,"") == 0)
		{
			Sleep(1);
			if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
			{
				::TranslateMessage((LPMSG)&msg);
				::DispatchMessage((LPMSG)&msg);
			}
		
			if(nTimeOut > 5000)
			{
				bTimeOut = TRUE;
				break;
			}
			nTimeOut++;
		}
	
		if(bTimeOut == TRUE)
		{
			ErrMessage(_T("MES Time out"));
			return "";
		}

		if(m_pOpc->m_strData1.GetLength() > 8)
		{
			strData1.Format("%s", m_pOpc->m_strData1.Mid(7));
		}
		m_pOpc->m_strData1 = "";
		return strData1;
	}

	BOOL CEasyDrillerDlg::GetMESReturnData2(CString strLotID)
	{
		int nTimeOut = 0;
		BOOL bTimeOut = FALSE;
		MSG msg;
		CString strData1 = _T("");
		while(strcmp(m_pOpc->m_strData2,"") == 0)
		{
			Sleep(1);
			if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
			{
				::TranslateMessage((LPMSG)&msg);
				::DispatchMessage((LPMSG)&msg);
			}
		
			if(nTimeOut > 5000)
			{
				bTimeOut = TRUE;
				break;
			}
			nTimeOut++;
		}
	
		if(bTimeOut == TRUE)
		{
			ErrMessage(_T("MES Time out"));
			return FALSE;
		}

		CString strGetResult = _T("");
		CString strGetMessage = _T("");
		CString strGetError = _T("");

		char* pToken;
		char szStr[500] = {0,};
		int nCount = 0;
		sprintf(szStr, "%s", m_pOpc->m_strData2);
		m_pOpc->m_strData2 = "";
		pToken = strtok(szStr, ";");
		while(pToken != NULL)
		{
			if(nCount == 1)
			{
				strGetResult.Format("%s", pToken);
			}
			if(nCount == 2)
			{
				strGetMessage.Format("%s", pToken);
			}
			if(nCount == 3)
			{
				strGetError.Format("%s", pToken);
			}

			pToken = strtok(NULL, ";");
			nCount++;
		}
	#ifdef __TEST__
		strGetResult.Format(_T("pass"));
	#endif
		strGetResult.MakeUpper();
		if(strcmp(strGetResult, "PASS") == 0)
		{
			ErrMessage(_T(" PASS\nMES OK ") , MB_OK | MB_TOPMOST );
			return TRUE;
		}
		else if(strcmp(strGetResult, "FAIL") == 0)
		{
			if(strcmp(strGetError, "-7") == 0)// 20120228 bskim ErrorCode �� -7�ϰ�� Lot Hold ����
			{
				CString strLotHoldResult;
				if(ErrMessage( _T("MES Fail\n") + strGetMessage + _T("\nif you unlock Lot Hold?"), MB_YESNO | MB_TOPMOST ) == IDYES)
				{
					strLotHoldResult.Format("%s;PASS", strLotID);
					((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 869, reinterpret_cast<LPARAM>(&strLotHoldResult)); //869 Lot Hold ����
				}
			}
			else if(strcmp(strGetError, "-99") == 0) // Lot ������ �Ǿ�� ��
			{
				ErrMessage( _T("MES Fail\n") + strGetMessage, MB_YESNO | MB_TOPMOST );
			}
			return FALSE;
		}
		else 
			return FALSE;
	}

	BOOL CEasyDrillerDlg::GetMESCancelReturnData()
	{
		int nTimeOut = 0;
		BOOL bTimeOut = FALSE;
		CString strData1 = _T("");
	
		if(!WaitOPCRecvMessage())
		{
			ErrMsgDlg(STDGNALM250);
			bTimeOut = TRUE;
		}
	
		if(bTimeOut == TRUE)
		{
			CString strMessage;
			strMessage.Format("MES Time Out \n If you wanner forcibly cancle?");
			if(ErrMessage(_T("FAIL\n") + strMessage, MB_YESNO | MB_TOPMOST ) ==IDYES)
				return TRUE;
			else
				return FALSE;
		}
	
		CString strGetLotID = _T("");
		CString strGetResult = _T("");
		CString strGetMessage = _T("");
	
		char* pToken;
		char szStr[500] = {0,};
		int nCount = 0;
		sprintf(szStr, "%s", m_pOpc->m_strMESCancel);
		m_pOpc->m_strMESCancel = "";
		pToken = strtok(szStr, ";");
		while(pToken != NULL)
		{
			if(nCount == 1)
			{
				strGetLotID.Format("%s", pToken);
			}
			if(nCount == 2)
			{
				strGetResult.Format("%s", pToken);
			}
			if(nCount == 3)
			{
				strGetMessage.Format("%s", pToken);
			}
		
			pToken = strtok(NULL, ";");
			nCount++;
		}
	#ifdef __TEST__
		strGetResult.Format(_T("pass"));
	#endif
		strGetResult.MakeUpper();
		if(strcmp(strGetResult, "PASS") == 0)
		{
			CString strMessage;
			strMessage.Format("Lot ID : %s\nMessage : %s\nMES canceled ", strGetLotID, strGetMessage);
			ErrMessage( _T(" PASS \n") + strMessage, MB_OK | MB_TOPMOST );
			return TRUE;
		}
		else if(strcmp(strGetResult, "FAIL") == 0)
		{
			CString strMessage;
			strMessage.Format("Lot ID : %s\nMessage : %s\nIf you wanner forcibly cancle?", strGetLotID, strGetMessage);
			if(ErrMessage(_T("FAIL") + strMessage, MB_YESNO | MB_TOPMOST ) ==IDYES)
				return TRUE;
			else
				return FALSE;
		}
		else 
			return FALSE;
	}

	LRESULT CEasyDrillerDlg::OnUpdateError(WPARAM wParam, LPARAM lParam)
	{
	#ifndef __NO_USE_OPC__
		int nID = (int)wParam;
		CString strOPCIndex;
		long nIndex = -1;
		BOOL bSetErrorTag = FALSE;
		CString strLog;
		CString strTagData;
	
		if(m_pOpc->SearchTagItem((int)nID, strOPCIndex) && strcmp(strOPCIndex, "") != 0)
		{
	
			bSetErrorTag = TRUE;
			nIndex = atol(strOPCIndex);
			CString strLotID = _T("");
			CString strLotID2 = _T("");
			CString strPrj1 = _T("");
			CString strPrj2 = _T("");
			((CEasyDrillerDlg*)::AfxGetMainWnd())->GetCurrentLotID(strLotID, strLotID2, strPrj1, strPrj2);
			if(strcmp(strLotID, strLotID2) == 0)
				strTagData = strLotID + ";";
			else
				strTagData.Format("%s;%s", strLotID, strLotID2); //Alarm :A_XXX_XXXXXX_01

			if(strcmp(strTagData, "") == 0)
				strTagData.Format(_T(";"));

			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strTagData));
		}
	#endif//bskim
		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnUpdateErrorClear(WPARAM wParam, LPARAM lParam)
	{
	#ifndef __NO_USE_OPC__
		int nID = (int)wParam;
		CString strOPCIndex;
		long nIndex = -1;
		BOOL bSetErrorTag = FALSE;
		CString strLog;
		CString strTagData;
	
		if(m_pOpc->SearchTagItem((int)nID, strOPCIndex) && strcmp(strOPCIndex, "") != 0)
		{
			bSetErrorTag = TRUE;
			nIndex = atol(strOPCIndex);
			CString strLotID = _T("");
			CString strLotID2 = _T("");
			CString strPrj1 = _T("");
			CString strPrj2 = _T("");
			((CEasyDrillerDlg*)::AfxGetMainWnd())->GetCurrentLotID(strLotID, strLotID2, strPrj1, strPrj2);
			if(strcmp(strLotID, strLotID2) == 0)
				strTagData = strLotID + ";";
			else
				strTagData.Format("%s;%s", strLotID, strLotID2);

			if(strcmp(strTagData, "") == 0)
				strTagData.Format(_T(";"));

			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex + 1, reinterpret_cast<LPARAM>(&strTagData)); //Alarm Clear :A_XXX_XXXXXX_02 
		}
	#endif//bskim
		return 1L;
	}

	LRESULT CEasyDrillerDlg::OnSetCurrentLotID(WPARAM wParam, LPARAM lParam)
	{
	#ifndef __NO_USE_OPC__
		//m_pProcessSetup->UpdateIniUI(wParam);
		CString strPrj1 = _T("");
		CString strPrj2 = _T("");
		//	GetCurrentLotID(gDProject.m_strFirstLotID, gDProject.m_strSecondLotID, strPrj1, strPrj2);
	#endif
		return 1L;
	}

	BOOL CEasyDrillerDlg::OPCRecipeCreate(CString strPrj, BOOL bChange)
	{
	#ifndef __NO_USE_OPC__
		CString strTemp, strTemp2, strTemp3, strTemp4, strTemp5;
		CString strOPCtag;
		POSITION pos;
		SUBTOOLDATA subtool;
		int nIndex =0;
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			if(!gDProject.m_pToolCode[i]->m_bUseTool)
				continue;
			pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			while(pos)
			{
				nIndex++;
				subtool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
				strTemp.Format(_T("01=%d;02=%d;03=%d;04=%d;05=%d;06=%d;07=%d;08=%d;09=%d;10=%d;"),
					i,nIndex, subtool.nToolType, subtool.nMask, subtool.nShotMode, subtool.nTotalShot,
					subtool.nBurstShot, subtool.nFrequency, subtool.nLaserOnDelay, subtool.nLaserOffDelay);
				strTemp2.Format(_T("11=%d;12=%d;13=%d;14=%d;15=%d;16=%s;17=%d;18=%d;19=%d;20=%d;"),
					subtool.nDrawStepPeriod*100, subtool.nJumpStepPeriod*100, subtool.nCornerDelay, 
					subtool.nJumpDelay,subtool.nLineDelay, subtool.cFilePath, gDProject.m_nDummyFreeType, 
					subtool.dShotMaxFreq[0], subtool.dShotMaxFreq[1], subtool.dShotMaxFreq[2]);
				strTemp3.Format(_T("21=%.0f;22=%.0f;23=%.0f;24=%.0f;25=%.0f;26=%.0f;27=%.0f;28=%.0f;29=%.0f;30=%.0f;"),
					subtool.dShotMaxFreq[3], subtool.dShotMaxFreq[4], subtool.dShotMaxFreq[5],
					subtool.dShotMaxFreq[6], subtool.dShotMaxFreq[7], subtool.dShotMaxFreq[8],
					subtool.dShotMaxFreq[9], subtool.dShotMaxFreq[10], subtool.dShotMaxFreq[11],
					subtool.dShotMaxFreq[12]);
				strTemp4.Format(_T("31=%.0f;32=%.0f;33=%.0f;34=%.0f;35=%.0f;36=%.0f;37=%.0f;38=%.0f;39=%.0f;40=%.0f;"),
					subtool.dShotMaxFreq[13], subtool.dShotMaxFreq[14], subtool.dShotDuty[0],
					subtool.dShotDuty[1], subtool.dShotDuty[2], subtool.dShotDuty[3],
					subtool.dShotDuty[4], subtool.dShotDuty[5], subtool.dShotDuty[6],
					subtool.dShotDuty[7]);
				strTemp5.Format(_T("41=%.0f;42=%.0f;43=%.0f;44=%.0f;45=%.0f;46=%.0f;47=%.0f;"),
					subtool.dShotDuty[8],subtool.dShotDuty[9], subtool.dShotDuty[10],
					subtool.dShotDuty[11], subtool.dShotDuty[12], subtool.dShotDuty[13],
					subtool.dShotDuty[14]);

				strOPCtag = strPrj+ _T(";") + strTemp + strTemp2 + strTemp3 + strTemp4 + strTemp5;
				if(strOPCtag.GetLength()>2000)
					return FALSE;

				if(bChange)
					nIndex = 21;// 18 : R_02_01, 20 : R_02_03 
				else
					nIndex = 17;// 14 : R_01_01, 16 : R_01_03 
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCtag));

				if(!WaitOPCRecvMessage())
				{
					ErrMsgDlg(STDGNALM250);
					return FALSE;
				}
				CString strGetResult, strGetMessage;
				strGetResult = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
				strGetMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage;
	#ifdef __TEST__
				strGetResult.Format(_T("pass"));
	#endif
				strGetResult.MakeUpper();
				if(strcmp(strGetResult, "PASS") == 0)
					continue;
				else if(strcmp(strGetResult, "FAIL") == 0)
				{
					ErrMessage(strGetMessage);
					return FALSE;
				}
			}
		}
	#endif
		return TRUE;

	}
	BOOL CEasyDrillerDlg::OPCRecipeDelete()
	{
	#ifndef __NO_USE_OPC__
		CString strPrj;
		strPrj.Format(_T("%s"), m_pOpc->m_strRecipeID);

		CFileFind finder;
		CString strFile, strTempFilePath;

		strTempFilePath.Format(_T("%s\\"), gEasyDrillerINI.m_clsDirPath.GetProjectDir());
		BOOL bFind = finder.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...

		BOOL bDelete = FALSE;
		while(bFind)
		{
			bFind = finder.FindNextFile();
			if(finder.IsDots())
				continue;
			else
			{
				strFile = finder.GetFileName();
				if(strcmp(strFile, strPrj) == 0)
				{
					::DeleteFile(strFile);
					bDelete = TRUE;
				}
			}
		}

		finder.Close();
		CString strOPCTag;
		CString strMessage;
		int nIndex;
		if(bDelete)
		{
			strMessage.Format(_T("Successful Delete "));
			strOPCTag.Format(_T("%s;Pass;%s"),strPrj, strMessage);
		}
		else
		{
			if(!bFind)
				strMessage.Format(_T("There is not file"));
			else
				strMessage.Format(_T("Fail to Delete"));
			strOPCTag.Format(_T("%s;Pass;%s"),strPrj, strMessage);		
		}

		nIndex = 44;// R_13_01
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
	#endif
		return TRUE;
	}
	BOOL CEasyDrillerDlg::OPCRecipeValidation(CString strLotID)
	{
	#ifndef __NO_USE_OPC__
		char szStr[500] = {0,};
		int nCount = 0;
		int nIndex;
		CString strOPCTag;
		BOOL bUseAI;
		int nPrj;
		CString strGetLotID, strGetBasketID, strGetResult,strGetMessage, strGetPrj, strGetCount, strGetFireType, strPNL;
		CString strPrj1, strPrj2, strLotID1, strLotID2;
		nPrj = GetCurrentLotID(strLotID1, strLotID2, strPrj1, strPrj2);


		int nType = m_pOpc->GetRMSType();
		if(nType == 0)
			bUseAI = TRUE;
		else if(nType == 1)
			bUseAI = FALSE;
		else 
			return TRUE;
		BOOL bCheck =  TRUE;
	
	/*	if(gLotInfo.nComSol[nPrj] == 0 )
			strPNL.Format(_T("COM"));
		else
			strPNL.Format(_T("SOL"));
			*/
		if(!bUseAI)
		{
			strOPCTag.Format(_T("%s;;;;;;;;;;"), strLotID);
			nIndex = 27;// 26 : R_04_07 R_14_07
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
		else
		{
			strOPCTag.Format(_T("%s;;;;;;;;;;"), strLotID);
			nIndex = 29;// 663 : R_04_09 R_14_09
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
		
		if(!WaitOPCRecvMessage())
		{
			ErrMsgDlg(STDGNALM250);
			return FALSE;
		}

	
		/*strGetResult = m_pOpc->m_strRecipePass;
		strGetBasketID = m_pOpc->m_strBasket;
		strGetPrj = m_pOpc->m_strRecipePrj;
		strGetCount = m_pOpc->m_strRecipeParam;
		strGetLotID = m_pOpc->m_strRecipeID;
		strGetMessage = m_pOpc->m_strRecipeMessage;
		
		strOPCTag.Format("* RMS Result *\nResult : %s\nBasketID : %s\nLotID : %s\nFileNo : %s\nCount : %s\nMessage :%s\n",
			strGetResult,strGetBasketID, strGetLotID, strGetPrj, strGetCount, strGetMessage);
		ErrMessage(strOPCTag);
			*/	

		if(!bCheck)
			return FALSE;

		return TRUE;
	#else
		return TRUE;
	#endif
	}
	BOOL CEasyDrillerDlg::SendOPCRecipeInfo(int nType, DProject& myProject, CString strLotID)
	{
	#ifndef __NO_USE_OPC__
		CString strOPCTag;
		CString strPrj;
		int nIndex;
		strPrj.Format(_T("%s"),myProject.m_szProjectName);

		nIndex = strPrj.ReverseFind('\\');
		strPrj = strPrj.Mid(nIndex+1);
		nIndex = strPrj.ReverseFind('.');
		strPrj = strPrj.Left(nIndex);

		if(nType == RMS_VALIDATION)
		{
			if(!OPCRecipeValidation(strLotID))
				return FALSE;
		}
		else if(nType == RMS_UPDATE)
		{
			if(!OPCRecipeUpdate())
				return FALSE;
			return TRUE;
		}
		else if(nType == RMS_DATAVALIDATION)
		{
			if(!OPCRecipeDataValidation(strLotID))
				return FALSE;
		}
		/*if(nType == RMS_CREATE)
		{
			if(!OPCRecipeCreate(strPrj, FALSE))
				return FALSE;
		}
		if(nType == RMS_CHANGE)
		{
			if(!OPCRecipeCreate(strPrj, TRUE))
				return FALSE;
		}
		if(nType == RMS_DELETE)
		{
			if(!OPCRecipeDelete())
				return FALSE;
		}*/
	
		/*if(nType == RMS_TAG)
		{
		}
		if(nType == RMS_INFO)
		{
		}*/
	
		/*if(nType == RMS_DOWNLOAD)
		{
			if(!OPCRecipeDown())
				return FALSE;
			return TRUE;
		}
		*/
		/*if(nType == RMS_LIST)
		{
			OPCRecipeList();
			return TRUE;
		}
		*/
		int nCount = 0;

		CString strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
		CString strMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage;

		CTime StartTime = CTime::GetCurrentTime();
		CTime EndTime;

		while(strcmp(strPass, _T("")) == 0)
		{
			EndTime = CTime::GetCurrentTime();
			Sleep(1);
			MessageLoop();

			if(EndTime - StartTime > 5)
			{
				ErrMessage(_T("OPC TimeOut"));
				break;
			}

			strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
			strMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage;

		}
	#ifdef __TEST__
		strPass.Format(_T("pass"));
	#endif
		strPass.MakeUpper();
		if(strcmp(strPass, "PASS") != 0)
		{
			ErrMessage(strMessage);
			return FALSE;
		}
	#endif
		return TRUE;

	}

	BOOL CEasyDrillerDlg::RecvOPCRecipeInfo(int nType)
	{
	#ifndef __NO_USE_OPC__
		CString strOPCTag;
		CString strPrj;
		CString strParam;
		int nIndex;
		strPrj.Format(_T("%s"),gDProject.m_szProjectName);

		nIndex = strPrj.ReverseFind('\\');
		strPrj = strPrj.Mid(nIndex);
		nIndex = strPrj.ReverseFind('.');
		strPrj = strPrj.Left(nIndex);

		strParam.Format(_T("%s"));
		int nCount = 0;

		CString strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
		CString strMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage;

		CTime StartTime = CTime::GetCurrentTime();
		CTime EndTime;

		while(strcmp(strPass, _T("")) == 0)
		{
			EndTime = CTime::GetCurrentTime();
			Sleep(1);
			MessageLoop();

			if(EndTime - StartTime > 5)
			{
				ErrMessage(_T("OPC TimeOut"));
				break;
			}
			strPass = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePass;
			strMessage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeMessage;
		}
	#ifdef __TEST__
		strPass.Format(_T("pass"));
	#endif
		strPass.MakeUpper();
		if(strcmp(strPass, "PASS") != 0)
		{
			ErrMessage(strMessage);
			return FALSE;
		}
	#endif
		return TRUE;

	}

	BOOL CEasyDrillerDlg::OPCRecipeUpdate()
	{
	#ifndef __NO_USE_OPC__
		DProject myProject; 
		CString strOPCTag;
		CString strTemp, strTemp2, strTemp3, strTemp4, strTemp5;
		POSITION pos;
		SUBTOOLDATA subtool;
		CString strPrj =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeID;
		int nIndex = 0;
		//myProject = gDProject;
	
		strTemp.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), strPrj);

		if(stricmp(strTemp, gDProject.m_szProjectName) != 0 )
		{
			CStdioFile file;
			if (FALSE == file.Open(strTemp, CFile::modeRead))
			{
				ErrMessage(_T("Can not open project"));
				strOPCTag = strPrj +_T(";Fail");
				nIndex = 36; // R_05_01
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
				return FALSE;
			}
			
			if (file.GetLength() < 1)
			{
				ErrMessage(_T("Can not open project"));
				strOPCTag = strPrj +_T(";Fail");
				nIndex = 36; // R_05_01
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
				return FALSE;
			}
			
			CArchiveMark ar(&file, CArchive::load);
			BOOL bRes = myProject.Serialize(ar, 10000);	
			file.Close();
			
			if(!bRes)
			{
				ErrMessage(_T("Can not open project"));
				strOPCTag = strPrj +_T(";Fail");
				nIndex = 36; // R_05_01
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
				return FALSE;
			}
		}
		else
			myProject = gDProject;

		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			if(!myProject.m_pToolCode[i]->m_bUseTool)
				continue;
			pos = myProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			while(pos)
			{
				nIndex++;
				subtool = myProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
				strTemp.Format(_T("01=%d;02=%d;03=%d;04=%d;05=%d;06=%d;07=%d;08=%d;09=%d;10=%d;"),
					i,nIndex, subtool.nToolType, subtool.nMask, subtool.nShotMode, subtool.nTotalShot,
					subtool.nBurstShot, subtool.nFrequency, subtool.nLaserOnDelay, subtool.nLaserOffDelay);
				strTemp2.Format(_T("11=%d;12=%d;13=%d;14=%d;15=%d;16=%s;17=%d;18=%.0f;19=%.0f;20=%.0f;"),
					subtool.nDrawStepPeriod*100, subtool.nJumpStepPeriod*100, subtool.nCornerDelay, 
					subtool.nJumpDelay,subtool.nLineDelay, subtool.cFilePath, gDProject.m_nDummyFreeType, 
					subtool.dShotMaxFreq[0], subtool.dShotMaxFreq[1], subtool.dShotMaxFreq[2]);
				strTemp3.Format(_T("21=%.0f;22=%.0f;23=%.0f;24=%.0f;25=%.0f;26=%.0f;27=%.0f;28=%.0f;29=%.0f;30=%.0f;"),
					subtool.dShotMaxFreq[3], subtool.dShotMaxFreq[4],subtool.dShotMaxFreq[5],
					subtool.dShotMaxFreq[6], subtool.dShotMaxFreq[7],subtool.dShotMaxFreq[8],
					subtool.dShotMaxFreq[9], subtool.dShotMaxFreq[10],subtool.dShotMaxFreq[11],
					subtool.dShotMaxFreq[12]);
				strTemp4.Format(_T("31=%.0f;32=%.0f;33=%.0f;34=%.0f;35=%.0f;36=%.0f;37=%.0f;38=%.0f;39=%.0f;40=%.0f;"),
					subtool.dShotMaxFreq[13], subtool.dShotMaxFreq[14], subtool.dShotDuty[0],
					subtool.dShotDuty[1],subtool.dShotDuty[2], subtool.dShotDuty[3],
					subtool.dShotDuty[4], subtool.dShotDuty[5], subtool.dShotDuty[6],
					subtool.dShotDuty[7]);
				strTemp5.Format(_T("41=%.0f;42=%.0f;43=%.0f;44=%.0f;45=%.0f;46=%.0f;47=%.0f;"),
					subtool.dShotDuty[8], subtool.dShotDuty[9],subtool.dShotDuty[10],
					subtool.dShotDuty[11],subtool.dShotDuty[12], subtool.dShotDuty[13],
					subtool.dShotDuty[14]);

				strOPCTag = strPrj +_T(";") + strTemp + strTemp2 + strTemp3 + strTemp4 + strTemp5;
				if(strOPCTag.GetLength()>2000)
					return FALSE;

				nIndex = 36; // R_05_01
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			}
		}
	#endif
		return TRUE;
	}
	BOOL CEasyDrillerDlg::OPCRecipeDown()
	{
	#ifndef __NO_USE_OPC__
		DProject myProject;
		CString strVal, strNo, strOPCTag, strPath;
		char szStr[3000];
		char* pToken;

		CString strPrj =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeID;
		CString strParam = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeParam;
		int nRecvIndex = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_nRecipeIndex;
		CString strTemp, strTemp2, strTemp3, strTemp4, strTemp5;
		POSITION pos;
		SUBTOOLDATA subtool;
		int nIndex;
	
		strPath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), strPrj);

		
		CStdioFile file;
		if (FALSE == file.Open(strPath, CFile::modeRead))
		{
			ErrMessage(_T("Can not open project"));
			strOPCTag.Format(_T("%s;Fail;Fail to open file"), strPrj);
			nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			return FALSE;
		}
			
		if (file.GetLength() < 1)
		{
			ErrMessage(_T("Can not open project"));
			strOPCTag.Format(_T("%s;Fail;Fail to open file"), strPrj);
			nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			return FALSE;
		}
			
		CArchiveMark ar(&file, CArchive::load);
		BOOL bRes = myProject.Serialize(ar, 10000);	
		file.Close();
			
		if(!bRes)
		{
			ErrMessage(_T("Can not open project"));
			strOPCTag.Format(_T("%s;Fail;Fail to open file"), strPrj);
			nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			return FALSE;
		}

		int nNo, nVal, nSubCount, nTool, nSubTool;

		sprintf(szStr, (LPCTSTR)strParam);
		pToken = strtok(szStr, ";");
	
		for(int k = 0; k<2; k++)
		{
			strTemp.Format(_T("%s"), pToken);
			nIndex = strTemp.Find('=');
			strNo = strTemp.Left(nIndex);
			strVal = strTemp.Mid(nIndex+1);
			strNo.TrimLeft(); strNo.TrimRight();
			strVal.TrimLeft(); strVal.TrimRight();

			nNo = atoi((LPCTSTR)strNo);
			nVal = atoi((LPCTSTR)strVal);
			if(nNo == 1)
				nTool = nVal;
			else if(nNo == 2)
				nSubTool = nVal;
			pToken = strtok(NULL, ";");
		}
		BOOL bToolExist = FALSE;
		nSubCount = 0;
		pos = myProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		if(pos == NULL)
		{
			strOPCTag.Format(_T("%s;Fail;Tool have not subtool"), strPrj);
			nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			return FALSE;
		}
		while(pos)
		{
			if(nSubCount == nSubTool-1)
			{
				subtool= myProject.m_pToolCode[nTool]->m_SubToolData.GetAt(pos);
				bToolExist = TRUE;
				break;
			}
			nSubCount++;
			myProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);

		}
		if(!bToolExist)
		{
			strOPCTag.Format(_T("%s;Fail;Tool have not subtool"), strPrj);
			nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
			return FALSE;
		}
		while(pToken !=NULL)
		{
			strTemp.Format(_T("%s"), pToken);
			nIndex = strTemp.Find('=');
			strNo = strTemp.Left(nIndex);
			strVal = strTemp.Right(nIndex+1);
			strNo.TrimLeft(); strNo.TrimRight();
			strVal.TrimLeft(); strVal.TrimRight();
			nNo = atoi((LPCTSTR)strNo);
	
			if(nNo != 16)
				nVal = atoi((LPCTSTR)strVal);
		
			switch(nNo)
			{
			case 3: subtool.nToolType  = nVal; break; 
			case 4: subtool.nMask = nVal; break;
			case 5: subtool.nShotMode = nVal; break;
			case 6: subtool.nTotalShot = nVal; break;
			case 7: subtool.nBurstShot = nVal; break;
			case 8: subtool.nFrequency = nVal; break;
			case 9: subtool.nLaserOnDelay = nVal; break;
			case 10: subtool.nLaserOffDelay = nVal; break;
			case 11: subtool.nDrawStepPeriod = nVal/100; break;
			case 12: subtool.nJumpStepPeriod = nVal/100; break;
			case 13: subtool.nCornerDelay = nVal; break;
			case 14: subtool.nJumpDelay = nVal; break;
			case 15: subtool.nLineDelay = nVal; break;
			case 16: strcpy(subtool.cFilePath, strVal); break;
			case 17: myProject.m_nDummyFreeType = nVal; break;
			case 18: subtool.dShotMaxFreq[0] = nVal; break; 
			case 19: subtool.dShotMaxFreq[1] = nVal; break; 
			case 20: subtool.dShotMaxFreq[2] = nVal; break; 
			case 21: subtool.dShotMaxFreq[3] = nVal; break; 
			case 22: subtool.dShotMaxFreq[4] = nVal; break; 
			case 23: subtool.dShotMaxFreq[5] = nVal; break; 
			case 24: subtool.dShotMaxFreq[6] = nVal; break; 
			case 25: subtool.dShotMaxFreq[7] = nVal; break; 
			case 26: subtool.dShotMaxFreq[8] = nVal; break; 
			case 27: subtool.dShotMaxFreq[9] = nVal; break; 
			case 28: subtool.dShotMaxFreq[10] = nVal; break; 
			case 29: subtool.dShotMaxFreq[11] = nVal; break; 
			case 30: subtool.dShotMaxFreq[12] = nVal; break; 
			case 31: subtool.dShotMaxFreq[13] = nVal; break; 
			case 32: subtool.dShotMaxFreq[14] = nVal; break; 
			case 33: subtool.dShotDuty[0] = nVal; break;  
			case 34: subtool.dShotDuty[1] = nVal; break; 
			case 35: subtool.dShotDuty[2] = nVal; break;
			case 36: subtool.dShotDuty[3] = nVal; break;
			case 37: subtool.dShotDuty[4] = nVal; break;
			case 38: subtool.dShotDuty[5] = nVal; break;
			case 39: subtool.dShotDuty[6] = nVal; break;
			case 40: subtool.dShotDuty[7] = nVal; break;
			case 41: subtool.dShotDuty[8] = nVal; break;
			case 42: subtool.dShotDuty[9] = nVal; break;
			case 43: subtool.dShotDuty[10] = nVal; break;
			case 44: subtool.dShotDuty[11] = nVal; break;
			case 45: subtool.dShotDuty[12] = nVal; break;
			case 46: subtool.dShotDuty[13] = nVal; break;
			case 47: subtool.dShotDuty[14] = nVal; break;
			default:
				{
					strOPCTag.Format(_T("%s;Fail;Parameter is not matched"), strPrj);
					nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
					((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
					return FALSE;
				}
			}

			pToken = strtok(NULL, ";");
		}
		
		if (FALSE == file.Open(strPath, CFile::modeWrite|CFile::modeCreate))
		{
			strOPCTag.Format(_T("%s;Fail;Save Fail"), strPrj);
				nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
				return FALSE;
		}
		
		CArchiveMark ar2(&file, CArchive::store);
		myProject.Serialize(ar2, 10000);

		strOPCTag.Format(_T("%s;Pass;"), strPrj);
		nIndex = 38;//37 Working Table�� ����PNL ���� : R_06_01 R_06_03
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
	#endif
		return TRUE;
	}
	BOOL CEasyDrillerDlg::OPCRecipeList()
	{
	#ifndef __NO_USE_OPC__
		int nIndex;

		CString strFile, strTempFilePath;
		CString strOPCTag = _T("");
		CFileFind finder1;
		strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetProjectDir());
		BOOL bFind = finder1.FindFile(strTempFilePath);  // ���� ã���� �ϴ� ������ ���� �̸�...

		while(bFind)
		{
			bFind = finder1.FindNextFile();
			if(finder1.IsDirectory())
				continue;
			else
			{
				strFile = finder1.GetFileName();
				nIndex = strFile.ReverseFind('.');
				strFile = strFile.Left(nIndex);
				strOPCTag += strFile + ";";
			}
		}
		finder1.Close();

		nIndex = 42;//41 Working Table�� ����PNL ���� : R_07_01
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));

		return TRUE;
	#else
		return TRUE;
	#endif
	}
	BOOL CEasyDrillerDlg::OPCInOutAlarm()
	{
	#ifndef __NO_USE_OPC__
		CString strAlarmCode;
		CString strAlarmMessage;

		strAlarmCode = m_pOpc->m_strAlarmCode;
		strAlarmMessage = m_pOpc->m_strAlarmMessage;
		CString strTag;
		strTag.Format(_T("%s\n%s"),strAlarmCode, strAlarmMessage);
		ErrMessage(strTag);
	#endif
		return TRUE;
	}

	LRESULT CEasyDrillerDlg::OnUpdateRecipe(WPARAM wParam, LPARAM lParam)
	{
	#ifndef __NO_USE_OPC__
		int nType  = (int) wParam;
		CString* strLotID = reinterpret_cast<CString*>(lParam);
		if(lParam == NULL)
			strLotID->Format(" ");
		return SendOPCRecipeInfo(nType, gDProject, *strLotID);
	#else
		return 1L;
	#endif
	}

	BOOL CEasyDrillerDlg::WaitOPCRecvMessage()
	{
	#ifdef __TEST__
		return TRUE;
	#endif
	#ifdef __NO_USE_OPC__
		return TRUE;
	#endif
		if(m_pOpc == NULL)
			return TRUE;
	
		int nWaitTime = gProcessINI.m_sProcessOption.nOPCTimeOut * 100; // sec 

		m_dlgOPCWait.ShowWindow(SW_SHOW);
		m_dlgOPCWait.StartMeasurement(nWaitTime);

		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
		BOOL bRecv = FALSE;
		int nCount = 0;
		do
		{
			if(nCount > nWaitTime) //���Ƿ� 5��
			{
				m_dlgOPCWait.ShowWindow(SW_HIDE);
				return FALSE;
			}
			bRecv = m_pOpc->m_bRecv;
			MessageLoop();
			Sleep(10);
			nCount++;
			m_dlgOPCWait.UpdateMeasurement(nCount);
		}while(!bRecv);

		m_dlgOPCWait.ShowWindow(SW_HIDE);
		return TRUE;
	}
	void CEasyDrillerDlg::ResetOPCRecvMessage()
	{
	#ifndef __NO_USE_OPC__
		m_pOpc->ResetRecvSignal();
	#endif
	}
	 LRESULT CEasyDrillerDlg::OnOPCStatus(WPARAM wParam, LPARAM lParam)
	 {
		 int nType = (int)wParam;
		 int nType2 = (int)lParam;
		 m_pAutoRun->OPCUpdateParameter(nType, nType2);
		 return 1L;
	 }
	 void CEasyDrillerDlg::ChangeLilySize(BOOL bBig)
	 {

		 if(bBig)
		 {
			 CRect rt, rtPos;
			 GetWindowRect(&rt); // EasyDriller 
			 this->SetWindowPos(NULL, rt.left, rt.top, LILY_SIZE + FIDUCIAL_ALL_VIEW_SIZE, rt.bottom - rt.top, NULL);
		 }
		 else
		 {
			 CRect rt, rtPos;
			 GetWindowRect(&rt); // EasyDriller 

			 this->SetWindowPos(NULL, rt.left, rt.top, LILY_SIZE, rt.bottom - rt.top, NULL);

			 OnMoveVisionView();
		 }
	 }

	 void CEasyDrillerDlg::OnBnClickedButtonChangeSize()
	 {
		 // TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
		 CRect rt, rtPos;
		 GetWindowRect(&rt); // EasyDriller 

		 if(rt.Width() > 1700)
		 {
			 ChangeLilySize(FALSE);
		 }
		 else
		 {
			 ChangeLilySize(TRUE);
		 }
	 }

	  void CEasyDrillerDlg::GetVisionPosRect(CRect &rc)
	{
			int nXScreen = ::GetSystemMetrics(SM_CXSCREEN);
			int nYScreen = ::GetSystemMetrics(SM_CYSCREEN);

			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->GetWindowRect(&rc);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->GetWindowRect(&rc);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->GetWindowRect(&rc);
		
	/*		CRect rt;
			CRect rtPos;
		
			int nSubStartX;
			int nSubStartY;
			int nWide, nHeight;

			if(m_dlgFiducialAllView->m_bFiducialAllViewDlgShow)
			{
				m_dlgFiducialAllView->GetWindowRect(&rt);
				nSubStartX = rt.left + 35;
				nSubStartY = rt.bottom + 20 - 335;
			}
			else
			{
				GetWindowRect(&rt); // EasyDriller 
				nSubStartX = rt.right;
				nSubStartY = rt.top;
			}

			m_pVisionProView->GetWindowRect(&rtPos);	
			nWide = rtPos.right - rtPos.left;
			nHeight = rtPos.bottom - rtPos.top;
			rtPos.top = nSubStartY; 
			rtPos.bottom = nSubStartY + nHeight;
			rtPos.left = nSubStartX;
			rtPos.right = nSubStartX + nWide;
			Sleep(10);
			m_pVisionProView->MoveWindow( &rtPos );
			m_pVisionProView->ShowWindow( SW_SHOW );
	*/
	}

	  void CEasyDrillerDlg::OPCServerRunCheck()
	  {
#ifndef __NO_USE_OPC__
		  m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
		  if(m_pOPCHandle == NULL)
		  {
			  ShellExecute(NULL, _T("open"), _T("C:\\SemOPCServer\\PtOpcSvr.exe"), NULL, NULL, SW_HIDE);
			  Sleep(300);
			  CProgressWnd wndProgress(NULL, _T("OPC Server open..."), TRUE);
			  wndProgress.GoModal();
			  wndProgress.SetRange(0, 0);
			  wndProgress.SetText(_T("OPC Server open..."));
			  while(m_pOPCHandle == NULL)
			  {
				  m_pOPCHandle = CWnd::FindWindowA(NULL, _T("OPC DA2.0 Server for SEM PATTERN Process"));
				  Sleep(100);
			  }
		  }
#endif
	  }

	  BOOL CEasyDrillerDlg::OPCRecipeDataValidation(CString strLotID)
	  {
#ifndef __NO_USE_OPC__
		  int nIndex;
		  CString strOPCTag;

		  strOPCTag.Format(_T("%s;"), strLotID);
		  nIndex = 50;// 663 : R_11_03
		  ((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));


		  if(!WaitOPCRecvMessage())
		  {
			  ErrMsgDlg(STDGNALM250);
			  return FALSE;
		  }

		  return TRUE;
#else
		  return TRUE;
#endif
	  }


	  void CEasyDrillerDlg::OnBnClickedButtonOpenBeampathTable()
	  {
		  CDlgBeamPathTable dlg;

		  dlg.SetBeamPath(gBeamPathINI.m_sBeampath);
		  dlg.SetAuthorityByLevel(m_nUserLevel);
		  if(dlg.DoModal() == IDOK)
		  {

		  }
	  }


	  void CEasyDrillerDlg::OnBnClickedButtonOpenShotTable()
	  {
		  CDlgShotTable dlg;

		  dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
		  dlg.SetAuthorityByLevel(m_nUserLevel);
		  if(dlg.DoModal() == IDOK)
		  {

		  }
	  }


	  void CEasyDrillerDlg::OnBnClickedButtonOpenMoveMotor()
	  {
		  CDlgMotorMove dlg;
		  dlg.SetDisplayOn(TRUE);
		  dlg.DoModal();
	  }

	  LRESULT CEasyDrillerDlg::OnLockButton(WPARAM wParam, LPARAM lParam)
	  {
			BOOL bEnable = (BOOL)wParam;
			if(bEnable)
			{
				m_btnBeampath.EnableWindow(FALSE);
				m_btnShot.EnableWindow(FALSE);
				m_btnMoveMotor.EnableWindow(FALSE);
			}
			else
			{
				m_btnBeampath.EnableWindow(TRUE);
				m_btnShot.EnableWindow(TRUE);
				m_btnMoveMotor.EnableWindow(TRUE);
			}
			return 1;
	  }

	LRESULT CEasyDrillerDlg::OnSetFidBlock(WPARAM wParam, LPARAM lParam)
	{
		int nFidBlock = (int)wParam;
        m_dlgFiducialAllView->m_cmbSelectFidBlock.SetCurSel(nFidBlock);

		return 1;
	}
	
	LRESULT CEasyDrillerDlg::OnSetPaneNo(WPARAM wParam, LPARAM lParam)
{
	int nPaneNo = (int)wParam;
	m_pRecipeGen->SetShowPane(nPaneNo);
	return 1;
}

	LRESULT CEasyDrillerDlg::OnShowAutoLoaderInterface(WPARAM wParam, LPARAM lParam)
	{
		m_dlgAutoLoaderInterface.ShowWindow(TRUE);
		return 1U;
	}
	bool CEasyDrillerDlg::IsProcessAble(CString strProcessName)
	{
		HANDLE         hProcessSnap = NULL; 
		BOOL           bRet      = FALSE; 
		PROCESSENTRY32 pe32      = {0}; 

		hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); 

		if (hProcessSnap == (HANDLE)-1) 
			return false;

		pe32.dwSize = sizeof(PROCESSENTRY32); 

		//���μ����� �޸𸮻� ������ ù��° ���μ����� ��´�
		if (Process32First(hProcessSnap, &pe32)) 
		{ 
			BOOL          bCurrent = FALSE; 
			MODULEENTRY32 me32       = {0}; 

			do 
			{ 
				bCurrent = GetProcessModule(pe32.th32ProcessID,strProcessName);
				if(bCurrent) 
				{ 
					HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID); 
					if(hProcess)
					{
						return true;
					}
				} 
			} 
			while (Process32Next(hProcessSnap, &pe32)); //���� ���μ����� ������ ���Ͽ� ������ ������ ����.
		}
		CloseHandle (hProcessSnap); 
		return FALSE;
	}

	bool CEasyDrillerDlg::IsProcessAble64Bit(CString strProcessName)
	{
         
		CWnd* m_pOPCHandle = NULL;
		m_pOPCHandle = CWnd::FindWindowA(NULL, _T("VisionTest"));
		
		if(m_pOPCHandle == NULL)
		 return FALSE;

		return TRUE;
	}

	bool CEasyDrillerDlg::ProcessKill(CString strProcessName)
	{
		HANDLE         hProcessSnap = NULL; 
		BOOL           bRet      = FALSE; 
		PROCESSENTRY32 pe32      = {0}; 

		hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); 

		if (hProcessSnap == (HANDLE)-1) 
			return false;

		pe32.dwSize = sizeof(PROCESSENTRY32); 

		//���μ����� �޸𸮻� ������ ù��° ���μ����� ��´�
		if (Process32First(hProcessSnap, &pe32)) 
		{ 
			BOOL          bCurrent = FALSE; 
			MODULEENTRY32 me32       = {0}; 

			do 
			{ 
				bCurrent = GetProcessModule(pe32.th32ProcessID,strProcessName);
				if(bCurrent) 
				{ 
					HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID); 
					if(hProcess)
					{
						if(TerminateProcess(hProcess, 0))
						{
							unsigned long nCode; //���μ��� ���� ���� 
							GetExitCodeProcess(hProcess, &nCode);
						}
						printf("process exit\n");
						CloseHandle(hProcess);
						return true;
					}
				} 
			} 
			while (Process32Next(hProcessSnap, &pe32)); //���� ���μ����� ������ ���Ͽ� ������ ������ ����.
		}
		CloseHandle (hProcessSnap); 
		return true;
	}



	bool CEasyDrillerDlg::GetProcessModule(DWORD dwPID,CString sProcessName)
	{ 
		HANDLE        hModuleSnap = NULL; 
		MODULEENTRY32 me32        = {0}; 
		hModuleSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwPID); 

		if (hModuleSnap == (HANDLE)-1) 
			return (FALSE); 

		me32.dwSize = sizeof(MODULEENTRY32); 

		//�ش� ���μ����� ��⸮��Ʈ�� ������ ������ ���μ����̸��� �����ϸ� 
		//true�� �����Ѵ�.

		if(Module32First(hModuleSnap, &me32)) 
		{ 
			do 
			{ 
				printf("process name : %s\n", me32.szModule);

				if(me32.szModule == sProcessName)
				{ 
					CloseHandle (hModuleSnap); 
					return true;
				} 

			} 
			while(Module32Next(hModuleSnap, &me32)); 
		} 

		CloseHandle (hModuleSnap); 
		return false;
	}
