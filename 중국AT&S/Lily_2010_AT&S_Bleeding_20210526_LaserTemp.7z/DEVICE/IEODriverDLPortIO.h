// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_IEODRIVEDLPORTIO_3E80FD4E02DE_INCLUDED
#define _INC_IEODRIVEDLPORTIO_3E80FD4E02DE_INCLUDED

#include "IEODriver.h"
#include "FParameter.h"

#define QUEUEFULL	(0X02)
#define BUSY		(0X01)
#define IDLE		(0)

#define FIRST_EO_CARD_ADDRESS		(0x310)
#define SECOND_EO_CARD_ADDRESS		(0x310)
#define THIRD_EO_CARD_ADDRESS		(0x350)
#define FOURTH_EO_CARD_ADDRESS		(0x360)
#define COMMON_EO_CARD_ADDRESS		(0x310)

#define STEP_ORIGIN_MODE			0
#define STEP_DIVIDE_MODE			1
#define UV_LINE_MODE				2

#define FIELD_LSB				65535
#define MAX_TCODE_2BEAM			30

#define MASTER_1				0
#define SLAVE_1					1
#define MASTER_2				2
#define SLAVE_2					3

#define MAX_PROFILE_NUM			8

//##ModelId=4034007E0148
class IEODriverDLPortIO : 
public IEODriver  
  
{
public:
	short m_cCO2Laser;
	unsigned short m_usFunction;
public:
	BOOL FlyingModeEnable(BOOL bEnable);
	BOOL SetQuantaParam(int nFPK, int nCurrent);
	BOOL markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	BOOL SetFunction(unsigned short usValue);
	unsigned short GetFunction();
	void DrillMove(BOOL bMark, int x, int y, int x2, int y2, BOOL bMaster, BOOL bWaitEnd);
	BOOL jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	void GetDumperPosition(USHORT &usDumpMX, USHORT& usDumpMY, USHORT& usDumpSX, USHORT& usDumpSY );
	void SetDumperPosition(USHORT usDumpMX, USHORT usDumpMY, USHORT usDumpSX, USHORT usDumpSY );
	BOOL DownloadShotData(unsigned short usX,unsigned short usY,BOOL bIsMaster,BOOL bApplyCalibration,int nTCode);
	BOOL DownloadDuty(unsigned int nToolNo, unsigned int nShotIndex, double dDuty);
	BOOL DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture);
	BOOL GetParameter(FParameter *Para);
	void CO2LaserMainShutter(BOOL bOn);
	void CO2LaserEnable(BOOL bEnable);
	void ResetCO2Laser();
	void Init8255();
	ULONG ReadHoleCount();
	BOOL MoveDrillCenterPos();
	BOOL SetRunMode(BOOL b4Beam, int nSP, int nApertureMode,  int nBurstShotNo);
	BOOL SetMinCycleTime(int us);
	BOOL SetSelfLineDivide(BOOL bOn);
	BOOL SetMinShotTime(int us);
	BOOL DownloadAperture(int nToolNo, int nX, int nY, int nAction);
	BOOL ApertureDataReset(int nToolNo);
	BOOL FieldStart(BOOL bDryRun);
	BOOL DownloadTcode(TCODE_INFO* pToolInfo);
	BOOL DownloadProfileJumpDelay(int nIndex, int nValue);
	BOOL SetMoveProfileLength(int nIndex, int nLength);
	BOOL DownloadProfile(int nIndex, int nValue);
	BOOL MoveProfileReset(int nIndex);
	BOOL ShotCountReset();
	BOOL ShotDataReset();
	BOOL DownloadShotData4(	unsigned short usMasterX,
							unsigned short usMasterY,
							unsigned short usSlaveX,
							unsigned short usSlaveY,
							unsigned short usMasterX2,
							unsigned short usMasterY2,
							unsigned short usSlaveX2,
							unsigned short usSlaveY2,
							BOOL bApplyCalibrationMaster,
							BOOL bApplyCalibrationSlave,
							BOOL bApplyCalibrationMaster2,
							BOOL bApplyCalibrationSlave2,
							int nTCode);
	BOOL DownloadShotData2(	unsigned short usMasterX,
							unsigned short usMasterY,
							unsigned short usSlaveX,
							unsigned short usSlaveY,
							BOOL bApplyCalibrationMaster,
							BOOL bApplyCalibrationSlave,
							int nTCode);
	BOOL writePortDWord(WORD portA, DWORD PortB, DWORD PortC = 0, DWORD PortD = 0, DWORD PortE = 0, bool bWaitFlag = TRUE);
	BOOL SetParameter(FParameter* pParam, BOOL bUpdate = TRUE);
	void MarkShot(int count);
	void Drillmark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	void Drilljump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	void mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	BOOL StatusOK(int nStatus);
	BOOL writePortMove(	WORD command, BOOL bWaitEnd = FALSE, WORD posX = HALF_LSB, WORD posY = HALF_LSB, WORD posSX = HALF_LSB, WORD posSY = HALF_LSB, 
						WORD posX_2 = HALF_LSB, WORD posY_2 = HALF_LSB, WORD posSX_2 = HALF_LSB, WORD posSY_2 = HALF_LSB, WORD TcodeInfo = 0);
	void jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	void RestartMark();
	void PauseMark();
	void EStop();
	BOOL write(const ULONG port, const ULONG data, const char type= _T('b'));
	BOOL writePort(WORD  PortA  , WORD  PortB = 0, WORD  PortC = 0, WORD PortD = 0, bool  WaitFlag = true,  int EOCardIndex = 0 ,bool progress = true);
	BOOL DownloadASCData(WORD  PortX  , WORD  PortY, WORD  PortIndex, bool  WaitFlag = true,  int EOCardIndex = 0 ,bool progress = true);
	BOOL LaserOnOff(BOOL bOn);
	WORD readStatus();
	void SetBaseAddress(UINT nBase);
	BOOL GetStatus(WORD* pStat) const;

	UINT		m_nBaseAdd;
	BOOL		m_bInitialized;
	FParameter	m_Parameter;
	//##ModelId=4034007E014A
	virtual bool readIFCard( ULONG port, ULONG& data, const char type = _T('b'));

	//##ModelId=4034007E0158
	virtual bool writeIFCard(const ULONG port, const ULONG data, const char type= _T('b'));

	//##ModelId=4034007E015D
	IEODriverDLPortIO();

	//##ModelId=4034007E015E
	virtual ~IEODriverDLPortIO();

	USHORT			m_usDumpMX;
	USHORT			m_usDumpMY;
	USHORT			m_usDumpSX;
	USHORT			m_usDumpSY;
	USHORT			m_usCurMX;
	USHORT			m_usCurMY;
	USHORT			m_usCurSX;
	USHORT			m_usCurSY;

};

#endif /* _INC_IEODRIVEDLPORTIO_3E80FD4E02DE_INCLUDED */
