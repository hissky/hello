// FCalibration.cpp: implementation of the FCalibration class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCalibration.h"

FCalibration::FCalibration()
{
	Reset() ;
}

FCalibration::~FCalibration()
{

}

void FCalibration::Reset()
{
	for(int x = 0; x < MAX_CAL_X; x++)
	{
		for(int y = 0; y < MAX_CAL_Y; y++)
		{
			CalM[x][y][0] = 0;
			CalM[x][y][1] = 0;
			CalS[x][y][0] = 0;
			CalS[x][y][1] = 0;
		}
	}
}

void FCalibration::Copy(FCalibration *ptr)
{
	for(int x = 0; x < MAX_CAL_X; x++)
	{
		for(int y = 0; y < MAX_CAL_Y; y++)
		{
			CalM[x][y][0] = ptr -> CalM[x][y][0] ;
			CalM[x][y][1] = ptr -> CalM[x][y][1] ;
			CalS[x][y][0] = ptr -> CalS[x][y][0] ;
			CalS[x][y][1] = ptr -> CalS[x][y][1] ;
		}
	}

}
