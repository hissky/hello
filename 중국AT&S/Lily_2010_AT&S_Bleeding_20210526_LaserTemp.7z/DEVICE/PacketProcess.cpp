// PacketProcess.cpp: implementation of the CPacketProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PacketProcess.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPacketProcess::CPacketProcess()
{
	ClearInPacket();
	ClearOutPacket();
}

CPacketProcess::~CPacketProcess()
{
}

void CPacketProcess::ClearInPacket()
{
	memset(m_stInPacket.sMachineID, 0, 4);
	memset(m_stInPacket.sCMD, 0, 3);
	memset(m_stInPacket.sTimeStamp, 0, 5);
	m_stInPacket.nLength = -1;
	memset(m_stInPacket.sLength, 0, 4);
	memset(m_stInPacket.sData, 0, MAX_SIZE);
}

void CPacketProcess::ClearOutPacket()
{
	memset(m_stOutPacket.sMachineID, 0, 4);
	memset(m_stOutPacket.sCMD, 0, 3);
	memset(m_stOutPacket.sTimeStamp, 0, 5);
	m_stOutPacket.nLength = -1;
	memset(m_stOutPacket.sLength, 0, 4);
	memset(m_stOutPacket.sData, 0, MAX_SIZE);
}

void * CPacketProcess::MakePacket(char *pCMD, char *pData)
{
	// Header
	strncpy_s(m_stOutPacket.sMachineID, 4, _T("0003"), 4);
	strncpy_s(m_stOutPacket.sCMD, 3, pCMD, 3);

	if ( m_stInPacket.sTimeStamp == NULL )
	{
		strncpy_s(m_stOutPacket.sTimeStamp, 5, _T("00001"), 5);
	}
	else
	{
		strncpy_s(m_stOutPacket.sTimeStamp, 5, m_stInPacket.sTimeStamp, 5);
	}

	// Data
	if (pData == NULL)
	{
		strncpy_s(m_stOutPacket.sLength, _T("0000"), 4);
		memset(m_stOutPacket.sData, 0, MAX_SIZE);
	}
	else
	{
		sprintf_s(m_stOutPacket.sLength, 4, _T("%04d"), strlen(pData));
		sprintf_s(m_stOutPacket.sData, 10000, _T("%s"), pData);
	}

	return &m_stOutPacket;
}

int CPacketProcess::ParsePacket(char *pPacket)
{
	// STX
	if ( pPacket[0] != STX )
	{
		m_strMsg.Format(_T("STX is wrong [%c]"), pPacket[0]);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Machine ID
	strncpy_s(m_stInPacket.sMachineID, 4, pPacket + 1, 4);
	m_stInPacket.ID.Format(_T("%s"),m_stInPacket.sMachineID);

	if (strcmp(m_stInPacket.sMachineID, _T("0002")) != 0)
	{
		m_strMsg.Format(_T("Machine ID is wrong [%s]"), m_stInPacket.sMachineID);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Command
	strncpy_s(m_stInPacket.sCMD, 3, pPacket + 5, 3);
	m_stInPacket.CMD.Format(_T("%s"),m_stInPacket.sCMD);
	
//	if ((strcmp(m_stInPacket.sCMD, _T(("OPF") != 0) && (strcmp(m_stInPacket.sCMD, _T("ADS") != 0) && (strcmp(m_stInPacket.sCMD, _T("IDS"))) != 0)
//		&& (strcmp(m_stInPacket.sCMD, _T("MSC")) != 0))
	if((strcmp(m_stInPacket.sCMD, _T("ACK")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("NAK")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("ADS")) != 0))
	{
		m_strMsg.Format(_T("Command is wrong [%s]"), m_stInPacket.sCMD);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Time Stamp
	strncpy_s(m_stInPacket.sTimeStamp, 5, pPacket + 8, 5);
	m_stInPacket.TS.Format(_T("%s"),m_stInPacket.sTimeStamp);
	
	// Length
	m_stInPacket.nLength = -1;
	strncpy_s(m_stInPacket.sLength, 5, pPacket + 13, 4);
	m_stInPacket.LT.Format(_T("%s"),m_stInPacket.sLength);
	
	m_stInPacket.nLength = atoi(m_stInPacket.sLength);
	if (m_stInPacket.nLength == -1)
	{
		m_strMsg.Format(_T("Length is wrong [%s]"), m_stInPacket.sLength);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Get Data
	memset(m_stInPacket.sData, 0, MAX_SIZE);
	strncpy_s(m_stInPacket.sData, 10000, pPacket + 17, m_stInPacket.nLength + 1);
	if ( m_stInPacket.sData[m_stInPacket.nLength] != ETX)
	{
		m_strMsg.Format(_T("ETX is wrong [%s]"), m_stInPacket.sData);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Except ETX
	memset(m_stInPacket.sData, 0, MAX_SIZE);
	strncpy_s(m_stInPacket.sData, 10000, pPacket + 17, m_stInPacket.nLength );

	if (strncmp(m_stInPacket.sCMD, _T("OPF"), 3) == 0)
	{
		return RECEIVE_OPF_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("ADS"), 3) == 0)
	{
		return RECEIVE_ADS_MSG;
	}
//	else if (strncmp(m_stInPacket.sCMD, _T("IDS"), 3) == 0)
//	{
//		return RECEIVE_IDS_MSG;
//	}
	else if (strncmp(m_stInPacket.sCMD, _T("ACK"), 3) == 0)
	{
		return RECEIVE_ACK_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("MSC"), 3) == 0)
	{
		if (strncmp(m_stInPacket.sData, _T("START"), 5) == 0)
			return RECIEVE_MSC_START_MSG;
		if (strncmp(m_stInPacket.sData, _T("STOP"), 4) == 0)
			return RECIEVE_MSC_STOP_MSG;

		return RECEIVE_WRONG_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("NAK"), 3) == 0)
	{
		return RECEIVE_NAK_MSG;
	}


	return RECEIVE_WRONG_MSG;
}

