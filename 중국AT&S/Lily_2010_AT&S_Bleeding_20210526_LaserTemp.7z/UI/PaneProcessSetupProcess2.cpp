// PaneProcessSetupProcess2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupProcess2.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HMotor.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
#include "..\model\DProcessINI.h"
#include "..\model\dsystemini.h"
#include "..\MODEL\DBeampathINI.h"
#include "..\EasyDrillerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcess2

IMPLEMENT_DYNCREATE(CPaneProcessSetupProcess2, CFormView)

CPaneProcessSetupProcess2::CPaneProcessSetupProcess2()
	: CFormView(CPaneProcessSetupProcess2::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupProcess2)
	//}}AFX_DATA_INIT
}

CPaneProcessSetupProcess2::~CPaneProcessSetupProcess2()
{
}

void CPaneProcessSetupProcess2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupProcess2)

	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER1_UP, m_edtLP1Up);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER1_ALIGN, m_edtLP1Align);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER1_TABLE, m_edtLP1Table);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER2_UP, m_edtLP2Up);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER2_ALIGN, m_edtLP2Align);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER2_TABLE, m_edtLP2Table);
	DDX_Control(pDX, IDC_EDIT_LOAD_PICKER2_CART, m_edtLP2Cart);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER1_UP, m_edtUP1Up);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER1_ALIGN, m_edtUP1Align);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER1_TABLE, m_edtUP1Table);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER2_UP, m_edtUP2Up);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER2_ALIGN, m_edtUP2Align);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER2_TABLE, m_edtUP2Table);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_PICKER2_CART, m_edtUP1Cart);


	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER1_UP, m_btnLP1Up);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER1_ALIGN, m_btnLP1Align);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER1_TABLE, m_btnLP1Table);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER2_UP, m_btnLP2Up);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER2_ALIGN, m_btnLP2Align);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER2_TABLE, m_btnLP2Table);
	DDX_Control(pDX, IDC_BUTTON_LOAD_PICKER2_CART, m_btnLP2Cart);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER1_UP, m_btnUP1Up);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER1_ALIGN, m_btnUP1Align);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER1_TABLE, m_btnUP1Table);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER2_UP, m_btnUP2Up);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER2_ALIGN, m_btnUP2Align);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER2_TABLE, m_btnUP2Table);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_PICKER2_CART, m_btnUP2Cart);
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupProcess2, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupProcess2)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER1_UP, &CPaneProcessSetupProcess2::OnBnClickedButtonLP1Up)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER1_ALIGN, &CPaneProcessSetupProcess2::OnBnClickedButtonLP1Align)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER1_TABLE, &CPaneProcessSetupProcess2::OnBnClickedButtonLP1Table)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER2_UP, &CPaneProcessSetupProcess2::OnBnClickedButtonLP2Up)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER2_ALIGN, &CPaneProcessSetupProcess2::OnBnClickedButtonLP2Align)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER2_TABLE, &CPaneProcessSetupProcess2::OnBnClickedButtonLP2Table)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PICKER2_CART, &CPaneProcessSetupProcess2::OnBnClickedButtonLP2Cart)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER1_UP, &CPaneProcessSetupProcess2::OnBnClickedButtonUP1Up)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER1_ALIGN, &CPaneProcessSetupProcess2::OnBnClickedButtonUP1Align)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER1_TABLE, &CPaneProcessSetupProcess2::OnBnClickedButtonUP1Table)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER2_UP, &CPaneProcessSetupProcess2::OnBnClickedButtonUP2Up)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER2_ALIGN, &CPaneProcessSetupProcess2::OnBnClickedButtonUP2Align)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER2_TABLE, &CPaneProcessSetupProcess2::OnBnClickedButtonUP2Table)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_PICKER2_CART, &CPaneProcessSetupProcess2::OnBnClickedButtonUP2Cart)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcess2 diagnostics

#ifdef _DEBUG
void CPaneProcessSetupProcess2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupProcess2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcess2 message handlers

void CPaneProcessSetupProcess2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
	InitListControl();
	InitComboControl();
}

BOOL CPaneProcessSetupProcess2::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupProcess2::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");

	GetDlgItem(IDC_STATIC_LOAD_PICKER1_UP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER1_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER1_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER2_UP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER2_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER2_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_PICKER2_CART)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER1_UP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER1_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER1_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER2_UP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER2_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER2_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_PICKER2_CART)->SetFont( &m_fntStatic );

}

void CPaneProcessSetupProcess2::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtLP1Up.SetFont( &m_fntEdit );
	m_edtLP1Up.SetForeColor( BLACK_COLOR );
	m_edtLP1Up.SetBackColor( WHITE_COLOR );
	m_edtLP1Up.SetReceivedFlag( 3 );
	m_edtLP1Up.SetWindowText( _T("0.0") );

	m_edtLP1Align.SetFont( &m_fntEdit );
	m_edtLP1Align.SetForeColor( BLACK_COLOR );
	m_edtLP1Align.SetBackColor( WHITE_COLOR );
	m_edtLP1Align.SetReceivedFlag( 3 );
	m_edtLP1Align.SetWindowText( _T("0.0") );

	m_edtLP1Table.SetFont( &m_fntEdit );
	m_edtLP1Table.SetForeColor( BLACK_COLOR );
	m_edtLP1Table.SetBackColor( WHITE_COLOR );
	m_edtLP1Table.SetReceivedFlag( 3 );
	m_edtLP1Table.SetWindowText( _T("0.0") );

	m_edtLP2Up.SetFont( &m_fntEdit );
	m_edtLP2Up.SetForeColor( BLACK_COLOR );
	m_edtLP2Up.SetBackColor( WHITE_COLOR );
	m_edtLP2Up.SetReceivedFlag( 3 );
	m_edtLP2Up.SetWindowText( _T("0.0") );

	m_edtLP2Align.SetFont( &m_fntEdit );
	m_edtLP2Align.SetForeColor( BLACK_COLOR );
	m_edtLP2Align.SetBackColor( WHITE_COLOR );
	m_edtLP2Align.SetReceivedFlag( 3 );
	m_edtLP2Align.SetWindowText( _T("0.0") );

	m_edtLP2Table.SetFont( &m_fntEdit );
	m_edtLP2Table.SetForeColor( BLACK_COLOR );
	m_edtLP2Table.SetBackColor( WHITE_COLOR );
	m_edtLP2Table.SetReceivedFlag( 3 );
	m_edtLP2Table.SetWindowText( _T("0.0") );

	m_edtLP2Cart.SetFont( &m_fntEdit );
	m_edtLP2Cart.SetForeColor( BLACK_COLOR );
	m_edtLP2Cart.SetBackColor( WHITE_COLOR );
	m_edtLP2Cart.SetReceivedFlag( 3 );
	m_edtLP2Cart.SetWindowText( _T("0.0") );

	m_edtUP1Up.SetFont( &m_fntEdit );
	m_edtUP1Up.SetForeColor( BLACK_COLOR );
	m_edtUP1Up.SetBackColor( WHITE_COLOR );
	m_edtUP1Up.SetReceivedFlag( 3 );
	m_edtUP1Up.SetWindowText( _T("0.0") );

	m_edtUP1Align.SetFont( &m_fntEdit );
	m_edtUP1Align.SetForeColor( BLACK_COLOR );
	m_edtUP1Align.SetBackColor( WHITE_COLOR );
	m_edtUP1Align.SetReceivedFlag( 3 );
	m_edtUP1Align.SetWindowText( _T("0.0") );

	m_edtUP1Table.SetFont( &m_fntEdit );
	m_edtUP1Table.SetForeColor( BLACK_COLOR );
	m_edtUP1Table.SetBackColor( WHITE_COLOR );
	m_edtUP1Table.SetReceivedFlag( 3 );
	m_edtUP1Table.SetWindowText( _T("0.0") );

	m_edtUP2Up.SetFont( &m_fntEdit );
	m_edtUP2Up.SetForeColor( BLACK_COLOR );
	m_edtUP2Up.SetBackColor( WHITE_COLOR );
	m_edtUP2Up.SetReceivedFlag( 3 );
	m_edtUP2Up.SetWindowText( _T("0.0") );

	m_edtUP2Align.SetFont( &m_fntEdit );
	m_edtUP2Align.SetForeColor( BLACK_COLOR );
	m_edtUP2Align.SetBackColor( WHITE_COLOR );
	m_edtUP2Align.SetReceivedFlag( 3 );
	m_edtUP2Align.SetWindowText( _T("0.0") );

	m_edtUP2Table.SetFont( &m_fntEdit );
	m_edtUP2Table.SetForeColor( BLACK_COLOR );
	m_edtUP2Table.SetBackColor( WHITE_COLOR );
	m_edtUP2Table.SetReceivedFlag( 3 );
	m_edtUP2Table.SetWindowText( _T("0.0") );

	m_edtUP1Cart.SetFont( &m_fntEdit );
	m_edtUP1Cart.SetForeColor( BLACK_COLOR );
	m_edtUP1Cart.SetBackColor( WHITE_COLOR );
	m_edtUP1Cart.SetReceivedFlag( 3 );
	m_edtUP1Cart.SetWindowText( _T("0.0") );
}

void CPaneProcessSetupProcess2::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnLP1Up.SetFont( &m_fntBtn );
	m_btnLP1Up.SetFlat( FALSE );
	m_btnLP1Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP1Up.EnableBallonToolTip();
	m_btnLP1Up.SetToolTipText( _T("") );
	m_btnLP1Up.SetBtnCursor( IDC_HAND_1 );

	m_btnLP1Align.SetFont( &m_fntBtn );
	m_btnLP1Align.SetFlat( FALSE );
	m_btnLP1Align.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP1Align.EnableBallonToolTip();
	m_btnLP1Align.SetToolTipText( _T("") );
	m_btnLP1Align.SetBtnCursor( IDC_HAND_1 );

	m_btnLP1Table.SetFont( &m_fntBtn );
	m_btnLP1Table.SetFlat( FALSE );
	m_btnLP1Table.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP1Table.EnableBallonToolTip();
	m_btnLP1Table.SetToolTipText( _T("") );
	m_btnLP1Table.SetBtnCursor( IDC_HAND_1 );

	m_btnLP2Up.SetFont( &m_fntBtn );
	m_btnLP2Up.SetFlat( FALSE );
	m_btnLP2Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP2Up.EnableBallonToolTip();
	m_btnLP2Up.SetToolTipText( _T("") );
	m_btnLP2Up.SetBtnCursor( IDC_HAND_1 );

	m_btnLP2Align.SetFont( &m_fntBtn );
	m_btnLP2Align.SetFlat( FALSE );
	m_btnLP2Align.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP2Align.EnableBallonToolTip();
	m_btnLP2Align.SetToolTipText( _T("") );
	m_btnLP2Align.SetBtnCursor( IDC_HAND_1 );

	m_btnLP2Table.SetFont( &m_fntBtn );
	m_btnLP2Table.SetFlat( FALSE );
	m_btnLP2Table.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP2Table.EnableBallonToolTip();
	m_btnLP2Table.SetToolTipText( _T("") );
	m_btnLP2Table.SetBtnCursor( IDC_HAND_1 );

	m_btnLP2Cart.SetFont( &m_fntBtn );
	m_btnLP2Cart.SetFlat( FALSE );
	m_btnLP2Cart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLP2Cart.EnableBallonToolTip();
	m_btnLP2Cart.SetToolTipText( _T("") );
	m_btnLP2Cart.SetBtnCursor( IDC_HAND_1 );

	m_btnUP1Up.SetFont( &m_fntBtn );
	m_btnUP1Up.SetFlat( FALSE );
	m_btnUP1Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP1Up.EnableBallonToolTip();
	m_btnUP1Up.SetToolTipText( _T("") );
	m_btnUP1Up.SetBtnCursor( IDC_HAND_1 );

	m_btnUP1Align.SetFont( &m_fntBtn );
	m_btnUP1Align.SetFlat( FALSE );
	m_btnUP1Align.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP1Align.EnableBallonToolTip();
	m_btnUP1Align.SetToolTipText( _T("") );
	m_btnUP1Align.SetBtnCursor( IDC_HAND_1 );

	m_btnUP1Table.SetFont( &m_fntBtn );
	m_btnUP1Table.SetFlat( FALSE );
	m_btnUP1Table.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP1Table.EnableBallonToolTip();
	m_btnUP1Table.SetToolTipText( _T("") );
	m_btnUP1Table.SetBtnCursor( IDC_HAND_1 );

	m_btnUP2Up.SetFont( &m_fntBtn );
	m_btnUP2Up.SetFlat( FALSE );
	m_btnUP2Up.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP2Up.EnableBallonToolTip();
	m_btnUP2Up.SetToolTipText( _T("") );
	m_btnUP2Up.SetBtnCursor( IDC_HAND_1 );

	m_btnUP2Align.SetFont( &m_fntBtn );
	m_btnUP2Align.SetFlat( FALSE );
	m_btnUP2Align.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP2Align.EnableBallonToolTip();
	m_btnUP2Align.SetToolTipText( _T("") );
	m_btnUP2Align.SetBtnCursor( IDC_HAND_1 );

	m_btnUP2Table.SetFont( &m_fntBtn );
	m_btnUP2Table.SetFlat( FALSE );
	m_btnUP2Table.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP2Table.EnableBallonToolTip();
	m_btnUP2Table.SetToolTipText( _T("") );
	m_btnUP2Table.SetBtnCursor( IDC_HAND_1 );

	m_btnUP2Cart.SetFont( &m_fntBtn );
	m_btnUP2Cart.SetFlat( FALSE );
	m_btnUP2Cart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUP2Cart.EnableBallonToolTip();
	m_btnUP2Cart.SetToolTipText( _T("") );
	m_btnUP2Cart.SetBtnCursor( IDC_HAND_1 );

}
void CPaneProcessSetupProcess2::InitComboControl()
{
	m_fntCombo.CreatePointFont(130, _T("Arial Bold"));
}
void CPaneProcessSetupProcess2::SetToolComboBox()
{

}
void CPaneProcessSetupProcess2::InitListControl()
{

}

HBRUSH CPaneProcessSetupProcess2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_LOAD_PICKER1)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOAD_PICKER2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOAD_PICKER2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOAD_PICKER1)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0,0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneProcessSetupProcess2::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntList.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupProcess2::SetProcessPosition(SAUTOSETTING sAutoSetting)
{
	memcpy( &m_sAutoSetting, &sAutoSetting, sizeof(m_sAutoSetting) );

	DispProcessPosition();
}

void CPaneProcessSetupProcess2::GetProcessPosition(SAUTOSETTING* pAutoSetting)
{
	if( 0 == memcmp( pAutoSetting, &m_sAutoSetting, sizeof(m_sAutoSetting) ) )
		return;

	//memcpy( pAutoSetting, &m_sAutoSetting, sizeof(m_sAutoSetting) );
	pAutoSetting->dLoaderPicker1UpPos = m_sAutoSetting.dLoaderPicker1UpPos;
	pAutoSetting->dLoaderPicker1AlignPos = m_sAutoSetting.dLoaderPicker1AlignPos;
	pAutoSetting->dLoaderPicker1TablePos = m_sAutoSetting.dLoaderPicker1TablePos;
	pAutoSetting->dLoaderPicker2UpPos = m_sAutoSetting.dLoaderPicker2UpPos;
	pAutoSetting->dLoaderPicker2AlignPos = m_sAutoSetting.dLoaderPicker2AlignPos;
	pAutoSetting->dLoaderPicker2TablePos = m_sAutoSetting.dLoaderPicker2TablePos;
	pAutoSetting->dLoaderPicker2CartPos = m_sAutoSetting.dLoaderPicker2CartPos;

	pAutoSetting->dUnloaderPicker1UpPos = m_sAutoSetting.dUnloaderPicker1UpPos;
	pAutoSetting->dUnloaderPicker1AlignPos = m_sAutoSetting.dUnloaderPicker1AlignPos;
	pAutoSetting->dUnloaderPicker1TablePos = m_sAutoSetting.dUnloaderPicker1TablePos;
	pAutoSetting->dUnloaderPicker2UpPos = m_sAutoSetting.dUnloaderPicker2UpPos;
	pAutoSetting->dUnloaderPicker2AlignPos = m_sAutoSetting.dUnloaderPicker2AlignPos;
	pAutoSetting->dUnloaderPicker2TablePos = m_sAutoSetting.dUnloaderPicker2TablePos;
	pAutoSetting->dUnloaderPicker1CartPos = m_sAutoSetting.dUnloaderPicker1CartPos;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( NULL == pMotor )
		return;

	pMotor->SetAutoSetting( m_sAutoSetting );
	pMotor->DownloadAutoSetting();
}

void CPaneProcessSetupProcess2::DispProcessPosition()
{
	CString strData;

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker1UpPos);
	m_edtLP1Up.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker1AlignPos);
	m_edtLP1Align.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker1TablePos);
	m_edtLP1Table.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker2UpPos);
	m_edtLP2Up.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker2AlignPos);
	m_edtLP2Align.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker2TablePos);
	m_edtLP2Table.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderPicker2CartPos);
	m_edtLP2Cart.SetWindowText( (LPCTSTR)strData );


	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker1UpPos);
	m_edtUP1Up.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker1AlignPos);
	m_edtUP1Align.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker1TablePos);
	m_edtUP1Table.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker2UpPos);
	m_edtUP2Up.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker2AlignPos);
	m_edtUP2Align.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker2TablePos);
	m_edtUP2Table.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderPicker1CartPos);
	m_edtUP1Cart.SetWindowText( (LPCTSTR)strData );				
}

BOOL CPaneProcessSetupProcess2::OnApply()
{
	CString strData;
	m_edtLP1Up.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker1UpPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP1Align.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker1AlignPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP1Table.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker1TablePos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP2Up.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker2UpPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP2Align.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker2AlignPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP2Table.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker2TablePos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtLP2Cart.GetWindowText( strData );
	m_sAutoSetting.dLoaderPicker2CartPos = atof( (LPSTR)(LPCTSTR)strData );


	m_edtUP1Up.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker1UpPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP1Align.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker1AlignPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP1Table.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker1TablePos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP2Up.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker2UpPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP2Align.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker2AlignPos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP2Table.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker2TablePos = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUP1Cart.GetWindowText( strData );
	m_sAutoSetting.dUnloaderPicker1CartPos = atof( (LPSTR)(LPCTSTR)strData );

	return TRUE;

}

CString CPaneProcessSetupProcess2::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	if(m_sAutoSetting.dLoaderPicker1UpPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1UpPos ||
		m_sAutoSetting.dLoaderPicker1UpPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1UpPos)
	{
		strTemp.Format(_T("| LP1 Up Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoaderPicker1UpPos,
			m_sAutoSetting.dLoaderPicker1UpPos);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker1AlignPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1AlignPos ||
		m_sAutoSetting.dLoaderPicker1AlignPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1AlignPos)
	{
		strTemp.Format(_T("| LP1 ALign Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker1TablePos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1TablePos ||
		m_sAutoSetting.dLoaderPicker1TablePos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker1TablePos)
	{
		strTemp.Format(_T("| LP1 Table Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker2UpPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2UpPos ||
		m_sAutoSetting.dLoaderPicker2UpPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2UpPos)
	{
		strTemp.Format(_T("| LP2 Up Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoaderPicker2UpPos,
			m_sAutoSetting.dLoaderPicker2UpPos);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker2AlignPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2AlignPos ||
		m_sAutoSetting.dLoaderPicker2AlignPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2AlignPos)
	{
		strTemp.Format(_T("| LP2 ALign Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker2TablePos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2TablePos ||
		m_sAutoSetting.dLoaderPicker2TablePos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2TablePos)
	{
		strTemp.Format(_T("| LP2 Table Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoaderPicker2CartPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2CartPos ||
		m_sAutoSetting.dLoaderPicker2CartPos != gProcessINI.m_sProcessAutoSetting.dLoaderPicker2CartPos)
	{
		strTemp.Format(_T("| LP2 Cart Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}


	if(m_sAutoSetting.dUnloaderPicker1UpPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1UpPos ||
		m_sAutoSetting.dUnloaderPicker1UpPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1UpPos)
	{
		strTemp.Format(_T("| UP1 Up Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dUnloaderPicker1UpPos,
			m_sAutoSetting.dUnloaderPicker1UpPos);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker1AlignPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1AlignPos ||
		m_sAutoSetting.dUnloaderPicker1AlignPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1AlignPos)
	{
		strTemp.Format(_T("| UP1 ALign Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker1TablePos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1TablePos ||
		m_sAutoSetting.dUnloaderPicker1TablePos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1TablePos)
	{
		strTemp.Format(_T("| UP1 Table Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker2UpPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2UpPos ||
		m_sAutoSetting.dUnloaderPicker2UpPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2UpPos)
	{
		strTemp.Format(_T("| UP2 Up Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dUnloaderPicker2UpPos,
			m_sAutoSetting.dUnloaderPicker2UpPos);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker2AlignPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2AlignPos ||
		m_sAutoSetting.dUnloaderPicker2AlignPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2AlignPos)
	{
		strTemp.Format(_T("| UP2 ALign Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker2TablePos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2TablePos ||
		m_sAutoSetting.dUnloaderPicker2TablePos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker2TablePos)
	{
		strTemp.Format(_T("| UP2 Table Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloaderPicker1CartPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1CartPos ||
		m_sAutoSetting.dUnloaderPicker1CartPos != gProcessINI.m_sProcessAutoSetting.dUnloaderPicker1CartPos)
	{
		strTemp.Format(_T("| UP2 Cart Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}
	return strMessage;
}

void CPaneProcessSetupProcess2::EnableControl(BOOL bUse)
{
	m_edtLP1Up.EnableWindow(bUse);
	m_edtLP1Align.EnableWindow(bUse);
	m_edtLP1Table.EnableWindow(bUse);
	m_edtLP2Up.EnableWindow(bUse);
	m_edtLP2Align.EnableWindow(bUse);
	m_edtLP2Table.EnableWindow(bUse);
	m_edtLP2Cart.EnableWindow(bUse);
	m_edtUP1Up.EnableWindow(bUse);
	m_edtUP1Align.EnableWindow(bUse);
	m_edtUP1Table.EnableWindow(bUse);
	m_edtUP2Up.EnableWindow(bUse);
	m_edtUP2Align.EnableWindow(bUse);
	m_edtUP2Table.EnableWindow(bUse);
	m_edtUP1Cart.EnableWindow(bUse);
}

void CPaneProcessSetupProcess2::EnableBtnControl(BOOL bLevel)
{
	CRect rect;
	m_btnLP1Up.EnableWindow(bLevel);
	m_btnLP1Align.EnableWindow(bLevel);
	m_btnLP1Table.EnableWindow(bLevel);
	m_btnLP2Up.EnableWindow(bLevel);
	m_btnLP2Align.EnableWindow(bLevel);
	m_btnLP2Table.EnableWindow(bLevel);
	m_btnLP2Cart.EnableWindow(bLevel);
	m_btnUP1Up.EnableWindow(bLevel);
	m_btnUP1Align.EnableWindow(bLevel);
	m_btnUP1Table.EnableWindow(bLevel);
	m_btnUP2Up.EnableWindow(bLevel);
	m_btnUP2Align.EnableWindow(bLevel);
	m_btnUP2Table.EnableWindow(bLevel);
	m_btnUP2Cart.EnableWindow(bLevel);
}

void CPaneProcessSetupProcess2::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		EnableBtnControl(FALSE);
		break;
	case 1:
	case 2:
	case 3:
		EnableControl(TRUE);
		EnableBtnControl(TRUE);
		break;
	}	
}


BOOL CPaneProcessSetupProcess2::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_Position) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP1Up()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 1 Up Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP1Up.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP1Align()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 1 Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP1Align.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP1Table()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 1 Table Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP1Table.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP2Up()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 2 Up Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP2Up.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP2Align()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 2 Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP2Align.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP2Table()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 2 Table Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP2Table.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonLP2Cart()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Picker 2 Cart Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_LP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLP2Cart.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcess2::OnBnClickedButtonUP1Up()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 1 Up Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP1Up.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP1Align()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 1 Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP1Align.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP1Table()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 1 Table Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP1Table.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP2Up()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 2 Up Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP2Up.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP2Align()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 2 Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP2Align.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP2Table()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 2 Table Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP2Table.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcess2::OnBnClickedButtonUP2Cart()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Picker 1 Cart Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UP1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUP1Cart.SetWindowText( (LPCTSTR)strData );
	}
}
//
//	afx_msg void OnBnClickedButtonUP1Up();
//	afx_msg void OnBnClickedButtonUP1Align();
//	afx_msg void OnBnClickedButtonUP1Table();
//	afx_msg void OnBnClickedButtonUP2Up();
//	afx_msg void OnBnClickedButtonUP2Align();
//	afx_msg void OnBnClickedButtonUP2Table();
//	afx_msg void OnBnClickedButtonUP2Cart();
//
//
//CColorEdit	;		double dLoaderPicker1UpPos;		CColorEdit	m_edtUP1Up;		double dUnloaderPicker1UpPos;	
//CColorEdit	;	double dLoaderPicker1AlignPos;	CColorEdit	m_edtUP1Align;	double dUnloaderPicker1AlignPos
//CColorEdit	;	double dLoaderPicker1TablePos;	CColorEdit	m_edtUP1Table;	double dUnloaderPicker1TablePos
//CColorEdit	m_edtLP2Up;		double dLoaderPicker2UpPos;		CColorEdit	m_edtUP2Up;		double dUnloaderPicker2UpPos;	
//CColorEdit	m_edtLP2Align;	double dLoaderPicker2AlignPos;	CColorEdit	m_edtUP2Align;	double dUnloaderPicker2AlignPos
//CColorEdit	m_edtLP2Table;	double dLoaderPicker2TablePos;	CColorEdit	m_edtUP2Table;	double dUnloaderPicker2TablePos
//CColorEdit	;	double dLoaderPicker2CartPos;	CColorEdit	m_edtUP2Cart;	double dUnloaderPicker2CartPos;
//