#if !defined(AFX_PANEMANUALCONTROLLASERUV_H__64167A21_9EFF_4287_8DC5_789ED4661E54__INCLUDED_)
#define AFX_PANEMANUALCONTROLLASERUV_H__64167A21_9EFF_4287_8DC5_789ED4661E54__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlLaserUV.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaserUV form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneManualControlLaserUV : public CFormView
{
protected:
	CPaneManualControlLaserUV();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlLaserUV)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlLaserUV)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_LASER_UV };
	UEasyButtonEx	m_btnLaserWarmUp;
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntBtn;

// Operations
public:
	void CallDialog();
	void InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlLaserUV)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlLaserUV();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlLaserUV)
	afx_msg void OnButtonLaserWarmUp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLLASERUV_H__64167A21_9EFF_4287_8DC5_789ED4661E54__INCLUDED_)
