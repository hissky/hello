#if !defined(AFX_PANEAUTORUNVIEWDATA_H__D8B57AE0_4710_4D41_9CF4_BA1C2B402130__INCLUDED_)
#define AFX_PANEAUTORUNVIEWDATA_H__D8B57AE0_4710_4D41_9CF4_BA1C2B402130__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewData.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewData form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "LedButton.h"
#include "DlgVacuumViewer.h"
class CPaneAutoRunViewData : public CFormView
{
protected:
	CPaneAutoRunViewData();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewData)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewData)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_DATA };
	UEasyButtonEx	m_btnHandlerCanel;
	UEasyButtonEx	m_btnUnloading;
	UEasyButtonEx	m_btnLoading;
	UEasyButtonEx	m_btnChangeBoard;
	UEasyButtonEx	m_btnChangeBoard2;
	UEasyButtonEx	m_btnUnloadPos;
	UEasyButtonEx	m_btnUCTable;
	UEasyButtonEx	m_btnUCCart;
	UEasyButtonEx	m_btnLoadPos;
	UEasyButtonEx	m_btnLCTable;
	UEasyButtonEx	m_btnLCCart;
	UEasyButtonEx	m_btnVacuumViewer;
	UEasyButtonEx	m_btnAllReject;
	UEasyButtonEx 	m_btnAutoLoaderIF;
	UEasyButtonEx	m_btnMode;
	CLedButton m_ledMainPower;
	CLedButton m_ledLaser;
	CLedButton m_ledEStop;
	CLedButton m_ledAutoRun;
	CLedButton m_ledMotor;
	CLedButton m_ledDummyFree;
	CLedButton m_ledTableSuction;
	CLedButton m_ledTableSuction2;

	CLedButton m_ledAcrylSuction;
	CLedButton m_ledAcrylSuction2;

	CLedButton m_ledClamp;
	CLedButton m_ledClamp2;
	CLedButton m_ledVacuumMotor;
	CLedButton m_ledInit;
	CLedButton m_ledFluorescentLamp;
	CLedButton m_ledReverse;
	CLedButton m_ledVision;
	CColorStatic	m_stcMachineMode;
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;
	CFont m_fntStaticBig;
	CFont m_fntBtn;

	int m_nNGBoxCondition;
	BOOL m_bMotor;
	BOOL m_bLaser;
	BOOL m_bEStop;
	BOOL m_bTableSuction;
	BOOL m_bTableSuction2;
	BOOL m_bClamp;
	BOOL m_bClamp2;
	BOOL m_bVacuumMotor;
	BOOL m_bInit;
	BOOL m_bFluorescentLamp;
	BOOL m_bAutoRun;
	BOOL m_bMainPower;
	BOOL m_bDummyFreeLamp;
	BOOL m_bViewerMoveMode;
	BOOL m_bLoadUnload;
	CPoint m_ptMoveStart;
	CPoint	m_ptDrawRectBack1;
	CPoint	m_ptDrawRectBack2;
	CPoint	m_ptDrawStart;
	BOOL m_bDrawMoveStart;
	BOOL m_bDrillRun;
	int m_nTimer;
	CDlgVacuumViewer	m_dlgVacuumViewer;
	BOOL	m_bHandlerWaitCancel;
	int m_nMachineModeOld;
	int m_nPMCount;
	int m_nRepairCount;

	BOOL m_bLaserConnectOld;
	BOOL m_nLaserDisConnectCnt;
// Operations
public:
	void SetFiredNGInfo(int nNG);
	void CheckInpositionError(int nAxis, BOOL bShow = FALSE);
	void InitialDrawRatio();
	void DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2);
	BOOL IsPickToolVisible(CPoint ptPick);
	void EnableControl(BOOL bUse);
	void SetDrill(BOOL Drill);
	void MessageLoop();
	BOOL WaitHandler(int nCmd, BOOL b1st = TRUE, BOOL b2nd = TRUE);
	BOOL GetAutoRun();
	void DestroyTimer();
	void InitTimer();
	void UpdateLed();
	void InitBtnControl();
	void InitStatic();
	void DrawData();
	BOOL m_bVision;
	BOOL m_bVisionConnectOld;
	BOOL m_nVisionDisConnectCnt;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewData)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewData();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewData)
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonViewVacuum();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonUcCart();
	afx_msg void OnButtonUcTable();
	afx_msg void OnButtonLcTable();
	afx_msg void OnButtonLcCart();
	afx_msg void OnButtonUnloadPos();
	afx_msg void OnButtonLoadPos();
	afx_msg void OnButtonLoading();
	afx_msg void OnButtonUnloading();
	afx_msg void OnButtonChangeBoard1();
	afx_msg void OnButtonChangeBoard2();
	afx_msg void OnCheckTableSuction();
	afx_msg void OnCheckTableSuction2();
	afx_msg void OnCheckVacuumMotor();
	afx_msg void OnCheckFluorescentLamp();
	afx_msg void OnCheckReverse();
	afx_msg void OnButtonAllReject();
	afx_msg void OnCheckTableClamp();
	afx_msg void OnCheckTableClamp2();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnCancelMode();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnCheckDummyFree();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheckAcrylSuction();
	afx_msg void OnBnClickedCheckAcrylSuction2();
	afx_msg void OnBnClickedButtonAutoLoaderIf();
	afx_msg void OnBnClickedCheckVision();
	afx_msg void OnBnClickedButtonHandlerCancel();
	afx_msg void OnBnClickedButtonMode();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWDATA_H__D8B57AE0_4710_4D41_9CF4_BA1C2B402130__INCLUDED_)
