#if !defined(AFX_PANEMAINMENU_H__5A9939DC_1BE5_4FC1_9085_B73C8A01B809__INCLUDED_)
#define AFX_PANEMAINMENU_H__5A9939DC_1BE5_4FC1_9085_B73C8A01B809__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneMainMenu.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneMainMenu form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneMainMenu : public CFormView
{
protected:
	CPaneMainMenu();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneMainMenu)

// Form Data
public:
	//{{AFX_DATA(CPaneMainMenu)
	enum { IDD = IDD_DLG_MAIN_MENU };
	UEasyButtonEx	m_btnAutoRun;
	UEasyButtonEx	m_btnSystemSetup;
	UEasyButtonEx	m_btnRecipeOpen;
	UEasyButtonEx	m_btnRecipeGen;
	UEasyButtonEx	m_btnProcessSetup;
	UEasyButtonEx	m_btnManualDrill;
	UEasyButtonEx	m_btnManualControl;
	UEasyButtonEx	m_btnLogout;
	UEasyButtonEx	m_btnLogManagement;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void	InitBtnControl();

	void	ShowMenuLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneMainMenu)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneMainMenu();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CFont				m_fntBtn;

	// Generated message map functions
	//{{AFX_MSG(CPaneMainMenu)
	afx_msg void OnButtonLogout();
	afx_msg void OnButtonRecipeGen();
	afx_msg void OnButtonAutoRun();
	afx_msg void OnButtonRecipeOpen();
	afx_msg void OnButtonManualDrill();
	afx_msg void OnButtonManualControl();
	afx_msg void OnButtonProcessSetup();
	afx_msg void OnButtonSystemSetup();
	afx_msg void OnButtonLogManagement();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMAINMENU_H__5A9939DC_1BE5_4FC1_9085_B73C8A01B809__INCLUDED_)
