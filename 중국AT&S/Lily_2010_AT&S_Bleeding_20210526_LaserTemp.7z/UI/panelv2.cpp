// panelv2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "panelv2.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLV2

IMPLEMENT_DYNCREATE(CPaneLV2, CFormView)

CPaneLV2::CPaneLV2()
	: CFormView(CPaneLV2::IDD)
{
	//{{AFX_DATA_INIT(CPaneLV2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneLV2::~CPaneLV2()
{
}

void CPaneLV2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLV2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLV2, CFormView)
	//{{AFX_MSG_MAP(CPaneLV2)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLV2 diagnostics

#ifdef _DEBUG
void CPaneLV2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLV2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLV2 message handlers

void CPaneLV2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
#ifdef USE_VISION_PRO
	gVPro.SetDisplayWindow( 3, GetDlgItem(IDC_VISIONPRO_2L) );
#endif
}

void CPaneLV2::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

BEGIN_EVENTSINK_MAP(CPaneLV2, CFormView)
    //{{AFX_EVENTSINK_MAP(CPaneLV2)
	ON_EVENT(CPaneLV2, IDC_VISIONPRO_2L, 5208 /* DblClick */, OnDblClickVisionpro2l, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CPaneLV2::OnDblClickVisionpro2l() 
{
	// TODO: Add your control notification handler code here
/*	if(gSystemINI.m_sHardWare.bUseWideMonitor)
	{
		BOOL bIsSize = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
		if(bIsSize)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
		else
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
		
		
	}
*/
}
