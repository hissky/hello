// HOLECONVERTDATA.h: interface for the HOLECONVERTDATA class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_)
#define AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxtempl.h>

#include "HOLEDATA.h"

struct BLOCK_FIDPOS
{
	CPoint		npBlockPos1;
	CPoint		npBlockPos2;
};

class CBlockFidPosList
{
public:
	int m_nCount;
	BLOCK_FIDPOS* m_pBlockFidPos;

	CBlockFidPosList()
	{
		m_nCount = 0;
		m_pBlockFidPos = NULL;
	};

	virtual ~CBlockFidPosList()	
	{
		if(m_pBlockFidPos)
		{
			delete [] m_pBlockFidPos;
			m_pBlockFidPos = NULL;
		}
		m_nCount = 0;
	};

	BOOL MakeMemory(int nSize)
	{
		if(nSize == m_nCount)
			return TRUE;

		if(m_pBlockFidPos)
		{
			delete [] m_pBlockFidPos;
			m_pBlockFidPos = NULL;
		}
		m_nCount = nSize;
		m_pBlockFidPos = new BLOCK_FIDPOS[nSize];
		return TRUE;
	};

	int GetCount()
	{
		return m_nCount;
	};

	BLOCK_FIDPOS* GetNext(int nIndex)
	{
		if(m_pBlockFidPos)
			return &m_pBlockFidPos[nIndex];
		else
			return FALSE;
	};
};
//typedef CTypedPtrList <CPtrList, BLOCK_FIDPOS*>	CBlockFidPosList;
struct PRE_HOLE_FIND_POS
{
	CPoint		npPreHoleFindPos;
};
typedef CTypedPtrList <CPtrList, PRE_HOLE_FIND_POS*>	PreHoleFindPosList;
class HOLECONVERTDATA  
{
public:
	HOLECONVERTDATA();
	virtual ~HOLECONVERTDATA()	
	{
		RemoveAllBlockData();
	};

	void RemoveAllBlockData()
	{
		/*
		BLOCK_FIDPOS* pdata;
		if(m_pblockPosList)
		{
			POSITION pos = m_pblockPosList->GetHeadPosition();
			while(pos)
			{
				pdata = m_pblockPosList->GetNext(pos);
				delete pdata;
			}
			m_pblockPosList->RemoveAll();
			delete pblockPosList;
		}
		
		m_pblockPosList = NULL;
		*/
		if(m_pblockPosList)
		{
			delete m_pblockPosList;
			m_pblockPosList = NULL;
		}
	};

	void RemoveAllPreHoleFindData(BOOL bRemoveList = FALSE)
	{
		PRE_HOLE_FIND_POS* pdata;
		if(pPreHoleFindPosList)
		{
			POSITION pos = pPreHoleFindPosList->GetHeadPosition();
			while(pos)
			{
				pdata = pPreHoleFindPosList->GetNext(pos);
				delete pdata;
			}
			pPreHoleFindPosList->RemoveAll();
			if(bRemoveList)
				delete pPreHoleFindPosList;
		}
		if(bRemoveList)
			pPreHoleFindPosList = NULL;
	};
	void RemoveAllPostHoleFindData(BOOL bRemoveList = FALSE)
	{
		PRE_HOLE_FIND_POS* pdata;
		if(pPostHoleFindPosList)
		{
			POSITION pos = pPostHoleFindPosList->GetHeadPosition();
			while(pos)
			{
				pdata = pPostHoleFindPosList->GetNext(pos);
				delete pdata;
			}
			pPostHoleFindPosList->RemoveAll();
			if(bRemoveList)
				delete pPostHoleFindPosList;
		}
		if(bRemoveList)
			pPostHoleFindPosList = NULL;
	};

//	void operator delete(void* p);
//	void* operator new(size_t nSize);
//	void* operator new(size_t nSize, LPCSTR lpszFileName, int nLine);
//	void  operator delete(void* p, LPCSTR lpszFileName, int nLine);

	LPHOLEDATA	pOrigin;
	CDPoint		dpLSBPos1;
	CDPoint		dpLSBPos2;
	BOOL		bSelect;
	BOOL		bPreHoleFind;
	PreHoleFindPosList*	pPreHoleFindPosList;

	BOOL		bPostHoleFind;
	PreHoleFindPosList*	pPostHoleFindPosList;
	CBlockFidPosList*	m_pblockPosList;

	BOOL		bDistanceSortingFinish;
	HOLECONVERTDATA*   pNext;
	HOLECONVERTDATA*	pBefore;
};

typedef HOLECONVERTDATA* LPFIREHOLE;
typedef CTypedPtrList <CPtrList, LPFIREHOLE>	FireHoleNoShareList;

class FireHOLEDATAUNIT  
{
public:
	FireHOLEDATAUNIT()
	{
		m_nUnitCount = 0;
	}
	virtual ~FireHOLEDATAUNIT()
	{
	};
	HOLECONVERTDATA m_HoleUnitList[MAX_UNIT_NO];
	int m_nUnitCount;
};
typedef FireHOLEDATAUNIT*	LPFireHOLEDATAUNIT;  
typedef CArray <LPFireHOLEDATAUNIT, LPFireHOLEDATAUNIT>	CFireHoleUnitList;

class FireHoleList
{
public:
	void RemoveAt(POSITION pos);
	void RemoveAll();
	LPFIREHOLE AddTail(HOLECONVERTDATA dData);
	LPFIREHOLE GetNext(POSITION& pos);
	POSITION GetHeadPosition();
	int GetCount();
	FireHoleList();
	virtual ~FireHoleList();
	
private:
	HOLECONVERTDATA* m_pHeadHoleConvertData;
	HOLECONVERTDATA* m_pTailHoleConvertData;
	CFireHoleUnitList m_List;
	int m_nCount;
	int m_nAddCount;
};

#endif // !defined(AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_)
