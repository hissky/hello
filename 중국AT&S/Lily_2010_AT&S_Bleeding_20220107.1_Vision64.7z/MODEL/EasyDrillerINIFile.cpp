// EasyDrillerINIFile.cpp: implementation of the CEasyDrillerINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "EasyDrillerINIFile.h"

#include "DEasyDrillerINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEasyDrillerINIFile::CEasyDrillerINIFile()
{

}

CEasyDrillerINIFile::~CEasyDrillerINIFile()
{

}

BOOL CEasyDrillerINIFile::OpenINIFile(CString strFilePath, DEasyDrillerINI& clsINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START HW OPTION SECTION")) )
		{
			if( FALSE == ParsingHwOption( sFile, clsINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingHwOption"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CollateNoCase(_T("// START DIR SECTION")) )
		{
			if( FALSE == ParsingDirPath( sFile, clsINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingDirPath"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
		else if( 0 == strGetData.CompareNoCase(_T("// END EASYDRILLER INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CEasyDrillerINIFile::ParsingHwOption(CStdioFile& sFile, DEasyDrillerINI& clsINI)
{
	BOOL bRet = 0;
	CString strGetData;
	int nVal = 0;
	
	BOOL bSetPanel, bSetMotor, bSetCam, bSetHead, bSetPower;
	bSetPanel = bSetMotor = bSetCam = bSetHead = bSetPower = FALSE;

	while( sFile.ReadString( strGetData ) )
	{
		// Use Dual Panel
		if( ScanSys( strGetData, _T("USE DUAL PANEL(0:Single,1:Dual) ="), nVal ) )
		{
			bSetPanel = TRUE;
			clsINI.m_clsHwOption.SetUseDualPanel( nVal );
			continue;
		}

		// Calibration Type
		if( ScanSys( strGetData, _T("CALIBRATION TYPE(0:BILIEAR,1:BICUBIC) ="), nVal ) )
		{
			clsINI.m_clsHwOption.SetCalibrationType( nVal );
			continue;
		}

		// Motor Type
		if( ScanSys( strGetData, _T("MOTOR TYPE(0:MP-Type,1:UMAC) ="), nVal ) )
		{
			bSetMotor = TRUE;
			clsINI.m_clsHwOption.SetMotorType( nVal );
			continue;
		}

		// Camera Num
		if( ScanSys( strGetData, _T("CAMERA NUM ="), nVal ) )
		{
			bSetCam = TRUE;
			if( nVal < 1 ) nVal = 1;
			else if( nVal > 4 ) nVal = 4;

			clsINI.m_clsHwOption.SetCameraNum( nVal );
			continue;
		}

		// Height Sensor Num
		if( ScanSys( strGetData, _T("HEIGHT SENSOR NUM ="), nVal ) )
		{
			clsINI.m_clsHwOption.SetHeightSensorNum(nVal);
			continue;
		}

		// Head Num
		if( ScanSys( strGetData, _T("SCANNER HEAD NUM ="), nVal ) )
		{
			bSetHead = TRUE;
			if( nVal < 1 ) nVal = 1;
			else if( nVal > 1 && nVal < 4 ) nVal = 2;
			else if( nVal > 4) nVal = 4;

			clsINI.m_clsHwOption.SetScannerHeadNum(nVal);
			continue;
		}

		// Use Only XY 
		if( ScanSys( strGetData, _T("USE ONLY XY ="), nVal ) ) // 0 : all, 1 : xy, 2 : xyz1
		{
			clsINI.m_clsHwOption.SetUseOnlyXY(nVal);
			continue;
		}

		// Use PowerMeasure
		if( ScanSys( strGetData, _T("USE POWERMEASURE ="), nVal ) )
		{
			bSetPower = TRUE;
			clsINI.m_clsHwOption.SetUsePowerMeasure(nVal);
			continue;
		}
		
		// Use repeat mode
		if( ScanSys( strGetData, _T("USE REPEAT MODE ="), nVal ) )
		{
			bSetPower = TRUE;
			clsINI.m_clsHwOption.m_nRepeatMode = nVal;
			continue;
		}
		
		if( ScanSys( strGetData, _T("MGC MODE ="), nVal ) )
		{
			clsINI.m_clsHwOption.m_nMGCMode = nVal;
			continue;
		}

		if( 0 == strGetData.CompareNoCase(_T("// END HW OPTION SECTION")) )
		{
			// �⺻�� ����
			if(!bSetPanel)
				clsINI.m_clsHwOption.SetUseDualPanel(1);

			if(!bSetMotor)
				clsINI.m_clsHwOption.SetMotorType(1);

			if(!bSetCam)
				clsINI.m_clsHwOption.SetCameraNum(4);

			if(!bSetHead)
				clsINI.m_clsHwOption.SetScannerHeadNum(2);

			if(!bSetPower)
				clsINI.m_clsHwOption.SetUsePowerMeasure(1);

			bRet = 1;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CEasyDrillerINIFile::ParsingDirPath(CStdioFile& sFile, DEasyDrillerINI& clsINI)
{
	BOOL bRet = 0;
	CString strGetData;
	CString strVal;

	while( sFile.ReadString( strGetData ) )
	{
		if( ScanSys( strGetData, _T("ROOT DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetRootDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("PARAMETER DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetParameterDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("CORRECT DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetCorrectDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("PROJECT DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetProjectDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("DATA DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetDataDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("CONVERTED DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetConvertedDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("IMAGE DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetImageDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("ERROR LOG DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetErrorLogDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("PROCESS LOG DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetProcessLogDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("BACKUP DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetBackupDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("SYSTEM DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetSystemDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("APERTURE DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetApertureDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("SCALE LOG DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetScaleLogDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("NETWORK DIR ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetNetworkDir( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("EASY INI FILE ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.Set1stMasterCalFilePath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("PROCESS INI FILE ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.Set1stSlaveCalFilePath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("SYSTEM INI FILE ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.Set2ndMasterCalFilePath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("BEAMPATH INI FILE ="), strVal ) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.Set2ndSlaveCalFilePath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("SCANNER MOVE PROFILE FILE ="), strVal) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetScannerProfileFilePath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("VISION PROJECT FILE ="), strVal) )
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetVisionProjectPath( strVal );
			continue;
		}
		if( ScanSys( strGetData, _T("BARCODE FILE ="), strVal))
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetBarcodeDir(strVal);
			continue;
		}
		if( ScanSys( strGetData, _T("IMPORTANT LOG DIR ="), strVal))
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetImportantLogDir(strVal);
			continue;
		}
		if( ScanSys( strGetData, _T("DATA TEST DIR ="), strVal))
		{
			strVal.TrimLeft(); strVal.TrimRight();
			clsINI.m_clsDirPath.SetDataTestDir(strVal);
			continue;
		}
		if( 0 == strGetData.CompareNoCase(_T("// END DIR SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CEasyDrillerINIFile::SaveINIFile(CString strFilePath, DEasyDrillerINI clsINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
//		CString strMsg;

//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
//		ErrMessage(strMsg, MB_ICONERROR);

		return bRet;
	}

	CString strSetData;

	strSetData.Format(_T("// START EASYDRILLER INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );

	SaveHwOption( sFile, clsINI );
	SaveDirPath( sFile, clsINI );

	strSetData.Format(_T("// END EASYDRILLER INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	sFile.Close();
	bRet = TRUE;

	return bRet;
}

BOOL CEasyDrillerINIFile::SaveHwOption(CStdioFile& sFile, DEasyDrillerINI clsINI)
{
	CString strSetData;

	strSetData.Format(_T("// START HW OPTION SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Dual Panel
	strSetData.Format(_T("USE DUAL PANEL(0:Single,1:Dual) = %d\n"), clsINI.m_clsHwOption.GetUseDualPanel());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Calibration Type
	strSetData.Format(_T("CALIBRATION TYPE(0:BILIEAR,1:BICUBIC) = %d\n"), clsINI.m_clsHwOption.GetCalibrationType());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Motor Type
	strSetData.Format(_T("MOTOR TYPE(0:MP-Type,1:UMAC) = %d\n"), clsINI.m_clsHwOption.GetMotorType());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Camera Num
	strSetData.Format(_T("CAMERA NUM = %d\n"), clsINI.m_clsHwOption.GetCameraNum() );
	sFile.WriteString( (LPCTSTR)strSetData );

	// Height Sensor Num
	strSetData.Format(_T("HEIGHT SENSOR NUM = %d\n"), clsINI.m_clsHwOption.GetHeightSensorNum());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Scanner Head Num
	strSetData.Format(_T("SCANNER HEAD NUM = %d\n"), clsINI.m_clsHwOption.GetScannerHeadNum());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use Only XY
	strSetData.Format(_T("USE ONLY XY = %d\n"), clsINI.m_clsHwOption.GetUseOnlyXY()); // 0 : all, 1 : xy, 2 : xyz1
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use PowerMeasure
	strSetData.Format(_T("USE POWERMEASURE = %d\n"), clsINI.m_clsHwOption.GetUsePowerMeasure());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Use repeat mode
	strSetData.Format(_T("USE REPEAT MODE = %d\n"), clsINI.m_clsHwOption.m_nRepeatMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	// MGC mode
	strSetData.Format(_T("MGC MODE = %d\n"), clsINI.m_clsHwOption.m_nMGCMode);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("// END HW OPTION SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return TRUE;
}

BOOL CEasyDrillerINIFile::SaveDirPath(CStdioFile& sFile, DEasyDrillerINI clsINI)
{
	CString strSetData;

	strSetData.Format(_T("// START DIR SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Root Dir
	strSetData.Format(_T("ROOT DIR = %s\n"), clsINI.m_clsDirPath.GetRootDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Parameter
	strSetData.Format(_T("PARAMETER DIR = %s\n"), clsINI.m_clsDirPath.GetParameterDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Correct
	strSetData.Format(_T("CORRECT DIR = %s\n"), clsINI.m_clsDirPath.GetCorrectDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Project
	strSetData.Format(_T("PROJECT DIR = %s\n"), clsINI.m_clsDirPath.GetProjectDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Data
	strSetData.Format(_T("DATA DIR = %s\n"), clsINI.m_clsDirPath.GetDataDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Converted
	strSetData.Format(_T("CONVERTED DIR = %s\n"), clsINI.m_clsDirPath.GetConvertedDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Image
	strSetData.Format(_T("IMAGE DIR = %s\n"), clsINI.m_clsDirPath.GetImageDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Error Log
	strSetData.Format(_T("ERROR LOG DIR = %s\n"), clsINI.m_clsDirPath.GetErrorLogDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Process Log
	strSetData.Format(_T("PROCESS LOG DIR = %s\n"), clsINI.m_clsDirPath.GetProcessLogDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Backup
	strSetData.Format(_T("BACKUP DIR = %s\n"), clsINI.m_clsDirPath.GetBackupDir());
	sFile.WriteString( (LPCTSTR)strSetData );

	// System
	strSetData.Format(_T("SYSTEM DIR = %s\n"), clsINI.m_clsDirPath.GetSystemDir() );
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Aperture
	strSetData.Format(_T("APERTURE DIR = %s\n"), clsINI.m_clsDirPath.GetApertureDir() );
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// scale log
	strSetData.Format(_T("SCALE LOG DIR = %s\n"), clsINI.m_clsDirPath.GetScaleLogDir() );
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("NETWORK DIR = %s\n"), clsINI.m_clsDirPath.GetNetworkDir() );
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1st Master Cal File Path
	strSetData.Format(_T("EASY INI FILE = %s\n"), clsINI.m_clsDirPath.Get1stMasterCalFilePath());
	sFile.WriteString( (LPCTSTR)strSetData );

	// 1st Slave Cal File Path
	strSetData.Format(_T("PROCESS INI FILE = %s\n"), clsINI.m_clsDirPath.Get1stSlaveCalFilePath());
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2nd Master Cal File Path
	strSetData.Format(_T("SYSTEM INI FILE = %s\n"), clsINI.m_clsDirPath.Get2ndMasterCalFilePath());
	sFile.WriteString( (LPCTSTR)strSetData );

	// 2nd Slave Cal File Path
	strSetData.Format(_T("BEAMPATH INI FILE = %s\n"), clsINI.m_clsDirPath.Get2ndSlaveCalFilePath());
	sFile.WriteString( (LPCTSTR)strSetData );
	
	// Scanner Move Profile File Path
	strSetData.Format(_T("SCANNER MOVE PROFILE FILE = %s\n"), clsINI.m_clsDirPath.GetScannerProfileFilePath());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Vision Project Path
	strSetData.Format(_T("VISION PROJECT FILE = %s\n"), clsINI.m_clsDirPath.GetVisionProjectPath());
	sFile.WriteString( (LPCTSTR)strSetData );

	// Barcode File
	strSetData.Format(_T("BARCODE FILE = %s\n"), clsINI.m_clsDirPath.GetBarcodeDir());
	sFile.WriteString((LPCTSTR)strSetData);

	// Barcode File
	strSetData.Format(_T("IMPORTANT LOG DIR = %s\n"), clsINI.m_clsDirPath.GetImportantLogDir());
	sFile.WriteString((LPCTSTR)strSetData);

	// Data Test
	strSetData.Format(_T("DATA TEST DIR = %s\n"), clsINI.m_clsDirPath.GetDataTestDir());
	sFile.WriteString((LPCTSTR)strSetData);
	strSetData.Format(_T("// END DIR SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return TRUE;
}

void CEasyDrillerINIFile::WriteLog(CString strLog)
{
	CString strPathName;
	strPathName.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}