#pragma once

// CDlgSecsGemConfig1 ��ȭ �����Դϴ�.

#define GEM_SETTINGS_FILENAME  "GEM\\xGem\\GEMSettings.ini"

class CDlgSecsGem1;
class CDlgSecsGemConfig1 : public CDialog
{
	DECLARE_DYNAMIC(CDlgSecsGemConfig1)

public:
	CDlgSecsGemConfig1(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSecsGemConfig1();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_SECS_GEM_CONFIG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedBtnEcidEstablishCommTimeoutSet();
	afx_msg void OnBnClickedBtnEcidT3TimeoutSet();
	afx_msg void OnBnClickedBtnEcidT5TimeoutSet();
	afx_msg void OnBnClickedBtnEcidT6TimeoutSet();
	afx_msg void OnBnClickedBtnEcidT7TimeoutSet();
	afx_msg void OnBnClickedBtnEcidT8TimeoutSet();
	afx_msg void OnBnClickedBtnEcidLinkTestSet();
	afx_msg void OnBnClickedBtnEcidInitControlStateSet();
	afx_msg void OnBnClickedCimIpSet();
public:
	CDlgSecsGem1*		m_pParent;

	CFont	m_fntStatic;
	LOGFONT	m_fntNormal;

	// Control
	CIPAddressCtrl m_ctrlIPAddress;
	CString m_strPort;
	CString m_strIPAddr;

	int m_nEstablishCommTimeout;
	int m_nT3Timeout;
	int m_nT5Timeout;
	int m_nT6Timeout;
	int m_nT7Timeout;
	int m_nT8Timeout;
	int m_nLinkTest;
	int m_nInitControlState;

private:
	virtual BOOL DestroyWindow();
	virtual BOOL OnInitDialog();
	
public:
	void	InitBrush();

	void	Refresh();
	void SaveToFile(CString szFileName);
	BOOL LoadFromFile(CString szFileName);


};
