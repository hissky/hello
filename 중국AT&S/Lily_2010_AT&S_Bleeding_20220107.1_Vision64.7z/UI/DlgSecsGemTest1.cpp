// DlgSecsGemTest1.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "DlgSecsGemTest1.h"
#include "DlgSecsGem1.h"
#include "afxdialogex.h"


// CDlgSecsGemTest1 ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgSecsGemTest1, CDialog)

CDlgSecsGemTest1::CDlgSecsGemTest1(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSecsGemTest1::IDD, pParent)
{

}

CDlgSecsGemTest1::~CDlgSecsGemTest1()
{
}

void CDlgSecsGemTest1::DoDataExchange(CDataExchange* pDX)
{
	DDX_Control(pDX, IDC_COMBO_ECID, m_cmbEcid);
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSecsGemTest1, CDialog)
	ON_BN_CLICKED(IDC_BTN_ALL_ECINFO, &CDlgSecsGemTest1::OnBnClickedBtnAllEcinfo)
	ON_BN_CLICKED(IDC_BTN_ECV_CHANGE, &CDlgSecsGemTest1::OnBnClickedBtnEcvChange)
	ON_BN_CLICKED(IDC_BTN_ALARM_SET, &CDlgSecsGemTest1::OnBnClickedBtnAlarmSet)
	ON_BN_CLICKED(IDC_BTN_ALARM_RESET, &CDlgSecsGemTest1::OnBnClickedBtnAlarmReset)
	ON_BN_CLICKED(IDC_BTN_PPID_SET, &CDlgSecsGemTest1::OnBnClickedBtnPpidSet)
	ON_BN_CLICKED(IDC_BTN_PROCESS_REQ, &CDlgSecsGemTest1::OnBnClickedBtnProcessReq)
	ON_BN_CLICKED(IDC_BTN_PPID_SET2, &CDlgSecsGemTest1::OnBnClickedBtnPpidSet2)
	ON_BN_CLICKED(IDC_BUTTON6, &CDlgSecsGemTest1::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BTN_SEND_MSG, &CDlgSecsGemTest1::OnBnClickedBtnSendMsg)
END_MESSAGE_MAP()


// CDlgSecsGemTest1 �޽��� ó�����Դϴ�.

BOOL CDlgSecsGemTest1::DestroyWindow()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	return CDialog::DestroyWindow();
}

BOOL CDlgSecsGemTest1::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgSecsGemTest1::OnBnClickedBtnAllEcinfo()
{
	for(int i =0; i < m_cmbEcid.GetCount(); i++)
		m_cmbEcid.DeleteString(i);

	m_pParent->m_XGem.GEMReqAllECInfo();
}

void CDlgSecsGemTest1::OnBnClickedBtnEcvChange()
{
	long nIndex = 0;
	long nVid = 0;
	char szText[256];
	CString sEcv = "";

	memset(szText, 0, sizeof(szText));

	nIndex = m_cmbEcid.GetCurSel();
	if (nIndex == -1) { return; } 
	m_cmbEcid.GetLBText(nIndex, szText);

	szText[4] = 0;
	nVid = atoi(szText);

	GetDlgItem(IDC_EDIT_VALUE)->GetWindowText(sEcv);

	m_pParent->m_XGem.GEMSetECVChanged(1, &nVid, &sEcv);
}


void CDlgSecsGemTest1::OnBnClickedBtnAlarmSet()
{
	long nIndex = 0;
	long nAlId = 0;
	CString str = "";

	GetDlgItem(IDC_EDIT_ALID)->GetWindowText(str);
	//state (0 : clear, 1: detect)

	nAlId = atoi(str);
	m_pParent->m_XGem.GEMSetAlarm(nAlId, 1);
}


void CDlgSecsGemTest1::OnBnClickedBtnAlarmReset()
{
	long nIndex = 0;
	long nAlId = 0;
	CString str = "";

	GetDlgItem(IDC_EDIT_ALID)->GetWindowText(str);
	//state (0 : clear, 1: detect)

	nAlId = atoi(str);
	m_pParent->m_XGem.GEMSetAlarm(nAlId, 0);
}


void CDlgSecsGemTest1::OnBnClickedBtnPpidSet()
{
	long nReturn  = 0;
	char szMsg[256];
	CString sPpid = "";
	CString str = "";
	long nLength = 0;

	GetDlgItem(IDC_EDIT_PPID)->GetWindowText(str);


	sPpid = "PPID:";
	sPpid = sPpid+ str + '\n';

	nLength = 10000;

	nReturn = m_pParent->m_XGem.GEMReqPPLoadInquire(sPpid, nLength);
	if( nReturn == 0 ) 
		m_pParent->	AddListBox("Test UI Button - Send GEMReqPPLoadInquire " );
	else 
		m_pParent->	AddListBox("Test UI Button - Send GEMReqPPLoadInquire Fail (%d)", nReturn );
}


void CDlgSecsGemTest1::OnBnClickedBtnProcessReq()
{
	long nReturn  = 0;
	char szMsg[256];
	CString sPpid = "";

	sPpid = "PPID001";

	nReturn = m_pParent->m_XGem.GEMReqPP(sPpid);
	if( nReturn == 0 ) 
		m_pParent->	AddListBox("Test UI Button - Send GEMReqPP " );
	else 
		m_pParent->	AddListBox("Test UI Button - Send GEMReqPP Fail (%d)", nReturn );
}


void CDlgSecsGemTest1::OnBnClickedBtnPpidSet2()
{
	long nReturn  = 0;
	char szMsg[256];
	CString sPpid = "";
	CString sBody = "";

	sPpid = "PPID001";
	sBody = "Body000000000000000000000000000000000a";

	nReturn = m_pParent->m_XGem.GEMReqPPSend(sPpid, sBody);
	if( nReturn == 0 ) 
		m_pParent->	AddListBox("Test UI Button - Send GEMReqPPSend " );
	else 
		m_pParent->	AddListBox("Test UI Button - Fail to GEMReqPPSend (%d)", nReturn );
}


void CDlgSecsGemTest1::OnBnClickedButton6()
{
	long nReturn = 0;
	char szMsg[256];
	CString strTime  = "";

	long nCount = 7;
	long naVid[7];
	CString saValue[7];

	// SVID 
	// 1. 500 : PPID
	// 2. 501 : LOTID
	// 3. 510 : Total Count
	// 4. 511 : Good Count
	// 5. 512 : Reject Count
	// 6. 520 : Lot Start Time
	// 7. 521 : Lot End Time

	CTime t;
	t = CTime::GetCurrentTime();

	strTime.Format("%04d-%02d-%02d %02d:%02d:%02d", t.GetYear(), t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond());

	// SVID	
	naVid[0] = 500; 
	naVid[1] = 501; 
	naVid[2] = 510; 
	naVid[3] = 511; 
	naVid[4] = 512; 
	naVid[5] = 520; 
	naVid[6] = 521; 

	saValue[0] = "PPID_TEST";
	saValue[1] = "LOTID_TEST";
	saValue[2] = "10";
	saValue[3] = "7";
	saValue[4] = "3";
	saValue[5] = strTime;
	saValue[6] = strTime;

	nReturn = m_pParent->m_XGem.GEMSetVariable(nCount, naVid, saValue);

	if( nReturn == 0 ) 
		m_pParent->	AddListBox("Test UI Button - Send LoadComplete Event " );
	else 
		m_pParent->	AddListBox("Test UI Button - Fail to LoadComplete Event (%d)", nReturn );
}


void CDlgSecsGemTest1::OnBnClickedBtnSendMsg()
{
	char szMsg[256];
	long nTid = 0;
	long nReturn = 0;
	CString sTid = "";
	CString sTerminalMsg = "";

	GetDlgItem(IDC_EDIT_TID)->GetWindowText(sTid);
	GetDlgItem(IDC_EDIT_MSG)->GetWindowText(sTerminalMsg);

	nTid = atoi(sTid);
	nReturn = m_pParent->m_XGem.GEMSetTerminalMessage(nTid, sTerminalMsg);
	if( nReturn == 0 ) 
		m_pParent->	AddListBox("Test UI Button - Send GEMSetTerminalMessage " );
	else 
		m_pParent->	AddListBox("Test UI Button - Fail to GEMSetTerminalMessage (%d)", nReturn );
}
