#if !defined(AFX_PANELOGMANAGERLOG_H__E0BF3C97_590F_46E6_BF41_469DC1D6B13E__INCLUDED_)
#define AFX_PANELOGMANAGERLOG_H__E0BF3C97_590F_46E6_BF41_469DC1D6B13E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManagerLog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLog form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"

class CPaneLogManagerLog : public CFormView
{
protected:
	CPaneLogManagerLog();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManagerLog)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManagerLog)
	enum { IDD = IDD_DLG_LOG_MANAGER_LOG };
	UEasyButtonEx	m_btnSearch;
	CListCtrl	m_listLog;
	CColorEdit	m_edtSearch;
	CDateTimeCtrl	m_dtcStart;
	CDateTimeCtrl	m_dtcEnd;
	CComboBox	m_cmbCategory;
	UEasyButtonEx	m_btnView;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnSave;
	int		m_nLogType;
	CString	m_strSearch;
	CTime	m_ctEnd;
	CTime	m_ctStart;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntList;
	CFont		m_fntEdit;
	CFont		m_fntEtc;

	CImageList		m_ImageList;
	CStringArray	m_strLogDetailArray;
	HANDLE			m_pHandle[3];

	CWinThread*		m_pThread;
	BOOL			m_bIsView;

	TCHAR			m_lpszColumnHead[3][20];

// Operations
public:
	void		InitBtnControl();
	void		InitStaticControl();
	void		InitListControl();
	void		InitEditControl();
	void		InitEtcControl();

	void		ShowDetailInformation();
	void		LoadFromCurrentDate();
	CString		GetLogFile(CTime& cTime);
	void		LoadFromFile( CString strFileName, CString strSearch = CString(_T("")) );

	void		UpdateSaveButton();
	void		MakeThreadClear();
	void		EnableNormalButton(BOOL bEnable);
	static UINT		ViewLogThread(LPVOID lpVoid);
	int			GetDays(int nYear, int nMonth);
	void		WriteLogFile(CString& strSaveFileName);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManagerLog)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManagerLog();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManagerLog)
	afx_msg void OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonView();
	afx_msg void OnButtonSave();
	afx_msg void OnButtonSearch();
	afx_msg void OnButtonStop();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELOGMANAGERLOG_H__E0BF3C97_590F_46E6_BF41_469DC1D6B13E__INCLUDED_)
