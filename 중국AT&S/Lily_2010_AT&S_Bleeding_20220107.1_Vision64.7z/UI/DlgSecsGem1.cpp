// DlgSecsGem1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "DlgSecsGem1.h"
//#include "MioSequence.h"
//#include "Handler_Version.h"
#include "PaneAutoRun.h"
#include "DlgSecsGemComm1.h"
#include "DlgSecsGemTest1.h"
//#include "DlgMsgView.h"

#include "Gem/unzip.h"
#include "Gem/zip.h"
//#include "UI/Users.h"
//#include "./XML_Include/xml.h"
#include "../AddIn/Color.h"
#include "../AddIn/JnLib.h"

#include "Temp/LogFile.h"
#include "Temp/IniFile.h"
#include "..\Model\DEasyDrillerInI.h"
#include "..\model\DProcessINI.h"


#include "..\device\hdevicefactory.h"
#include "..\device\deviceMotor.h"
#include "..\model\DBeampathINI.h"

IMPLEMENT_DYNCREATE(CDlgSecsGem1, CFormView)

	/*
	CCode 0���� Layout�� ������
	CCode 1~21���� Parameter�� ������
	*/
#define MAX_USE_TOOL 10
#define MAX_USE_LAYOUT_PARAM 3
#define MAX_USE_TOOL_PARAM 4

#define TOTAL_PARAM_COUNT (MAX_USE_TOOL_PARAM * (MAX_USE_TOOL-1) + MAX_USE_LAYOUT_PARAM)

/////////////////////////////////////////////////////////////////////////////
// CDlgSecsGem1 dialog
/***********************************************************************
		-  Thread
***********************************************************************/
UINT ThreadProcGem1(LPVOID lParam)
{
	CDlgSecsGem1* pParent  = (CDlgSecsGem1*)lParam;

	MSG msg;
	CUMSetEvent* stUMSetEventData = new CUMSetEvent;

	while(TRUE)
	{
		if(!PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			Sleep(10);
			continue;
		}

//		CUMSetEvent* stUMSetEventData = new CUMSetEvent;
		// CEID Set
		CString strValueData;
		COleDateTime date = COleDateTime::GetCurrentTime();
		strValueData.Format(_T("%04d-%02d-%02d %02d/%02d/%02d"), date.GetYear(), date.GetMonth(), date.GetDay(), date.GetHour(), date.GetMinute(), date.GetSecond());
		stUMSetEventData->nVID.Add(SVID_CLOCK);
		stUMSetEventData->saVID.Add(strValueData);

		switch(msg.message)
		{
		case WM_QUIT:
			{
				if(stUMSetEventData != NULL)
				{
					delete stUMSetEventData; 
					stUMSetEventData = NULL;
				}
				return 0L;
			}

		case WM_SET_ALARM:
			{
				stAlarm* stAlarmData = (stAlarm*)msg.wParam;
				pParent->SetAlarm(stAlarmData);
			}
			break;

		case WM_SET_PROCESS_STATE:
			{
				long nState = (_eProcessingState)msg.wParam;
				pParent->SetProcessState(nState);
			}
			break;

		case WM_SET_EVENT:
			{
				CUMSetEvent* UMSetEventData;
				UMSetEventData = (CUMSetEvent*)msg.wParam;

				// Send Event To Host.
				pParent->SetEvent(UMSetEventData);
			}
			break;

		}

		Sleep(10);

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	
	if(stUMSetEventData != NULL)
	{
		delete stUMSetEventData; 
		stUMSetEventData = NULL;
	}
	return 0L;
}





CDlgSecsGem1::CDlgSecsGem1()
	: CFormView(CDlgSecsGem1::IDD)
{

//	m_pParent = pParent;
	
	m_xGemCommStatus = Comm_None;
	m_XGemEQProcessState = Processing_None;

	m_OldEQProcessState = Processing_Idle;	// Set Idle State.
	m_pServer = new CFileShareServer;
	
	m_nXGemStatus = 0;				// 0:Close, 1:init, 2:start, 3:Stop
	
	InitializeCriticalSection(&m_cs);

	for(int i = 0; i < COUNTOF_STAGE; i++)
	{
		m_markPrjName[i] = "";
		m_ParamFileName[i] = "";

		for(int j =0; j < COUNTOF_MARKDSGN; j++)
			m_DsgnFileName[i][j] = "";
	}

	


#ifdef __USE_ZIPFILE__
	m_bZipUse = TRUE;
#else 
	m_bZipUse = FALSE;
#endif
	m_evRecv.ResetEvent();

	m_strInsertRawData = "";
	m_strInsertLotID = "";

	pstTraceDataOld = new STRACEDATA;
	pstTraceDataNew = new STRACEDATA;

	pst_GetLotInfo = new SGETLOTINFO;
	m_RSTSMode = Processing_Idle;		//20171219
	m_RSTSModeChangeEnable = false;
	m_bOccureOPCall = FALSE;
	m_bReceiveLotInfo = FALSE;
	m_bReceivePPSelect = FALSE;
	
	m_bReceiveLotReady = FALSE;
	m_bReceivePPValid = FALSE;
	
	m_strTactEventTime = "";
	m_strTactEventLot = "";
	m_strTactEventQTY = "";
	m_strTactEventTactTime = "";

	
	m_pThread = ::AfxBeginThread(ThreadProcGem1, this, THREAD_PRIORITY_NORMAL);
}


CDlgSecsGem1::~CDlgSecsGem1()
{

	if(pstTraceDataOld)
	{
		delete pstTraceDataOld;
		pstTraceDataOld = NULL;
	}
	if(pstTraceDataNew)
	{
		delete pstTraceDataNew;
		pstTraceDataNew = NULL;
	}
	if(pst_GetLotInfo)
	{
		delete pst_GetLotInfo;
		pst_GetLotInfo = NULL;
	}

}

void CDlgSecsGem1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_EXGEMCTRL1, m_XGem);
	DDX_Control(pDX, IDC_LIST_BOX, m_ctrlMsgList);
	DDX_Control(pDX, IDC_BTN_COMM, m_btnComm);
	DDX_Control(pDX, IDC_BTN_CONFIG, m_btnConfig);
	DDX_Control(pDX, IDC_BTN_XGEM_TEST, m_btnTest);
	DDX_Control(pDX, IDC_STATIC_SECS_TERMSG, m_StaticTerminalMsg);


}


BEGIN_MESSAGE_MAP(CDlgSecsGem1, CFormView)

	ON_BN_CLICKED(IDC_BTN_EXPAND_TOGGLE, OnBtnExpandToggle)
	ON_BN_CLICKED(IDC_BTN_CLOSE, &CDlgSecsGem1::OnBnClickedBtnClose)
	ON_BN_CLICKED(IDC_BTN_COMM, &CDlgSecsGem1::OnBnClickedBtnComm)
	ON_BN_CLICKED(IDC_BTN_CONFIG, &CDlgSecsGem1::OnBnClickedBtnConfig)
	ON_BN_CLICKED(IDC_BTN_XGEM_TEST, &CDlgSecsGem1::OnBnClickedBtnXgemTest)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CDlgSecsGem1::OnBnClickedBtnClear)
	ON_BN_CLICKED(IDC_BTN_APPLY, &CDlgSecsGem1::OnBnClickedBtnApply)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_ABNORMAL_END, &CDlgSecsGem1::OnBnClickedBtnAbnormalEnd)
	ON_BN_CLICKED(IDC_BTN_ABORT, &CDlgSecsGem1::OnBnClickedBtnAbort)
END_MESSAGE_MAP()


// CPaneAutoRunViewAuto diagnostics

#ifdef _DEBUG
void CDlgSecsGem1::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CDlgSecsGem1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG
void CDlgSecsGem1::OnDestroy()
{
	long nRet = 0;
	CString str;

	//Stop
	if((nRet = m_XGem.Close())== 0)
		AddListBox("XGem Closed ");
	else
		AddListBox("XGem Closed Fail(%d)", nRet);

	m_fntStatic1.DeleteObject();

	m_pThread->PostThreadMessage(WM_QUIT, 0, 0);

	WaitForSingleObject(m_pThread->m_hThread, INFINITE);

	delete m_pServer;

	DeleteCriticalSection(&m_cs); 

	CFormView::OnDestroy();
}



void CDlgSecsGem1::OnBtnExpandToggle() 
{
	BOOL bWndVisible;
	bWndVisible = IsWindowVisible();

	ShowWindow(false);

	if(m_bIsExpanded)
	{	SetWindowPos(NULL, 0, 0, m_rcBrief.right, m_rcBrief.bottom, SWP_NOMOVE | SWP_NOZORDER);	
		m_bIsExpanded = false;
	}
	else
	{	SetWindowPos(NULL, 0, 0, m_rcExpand.right, m_rcExpand.bottom, SWP_NOMOVE | SWP_NOZORDER);	
		m_bIsExpanded = true;
	}
	
	
	CenterWindow();
	ShowWindow(bWndVisible);
	
}

void CDlgSecsGem1::OnBnClickedBtnClear()
{
	ClearMsgList();
}

void CDlgSecsGem1::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	
	UpdateData(TRUE);

	// TODO: Add extra initialization here
	m_bIsExpanded = true;
	GetDlgItem(IDC_LIST_BOX)->GetWindowRect(m_rcBrief);
	ScreenToClient(m_rcBrief);		
	m_rcBrief.right+=20;
	m_rcBrief.bottom+=90;
	
	GetWindowRect(m_rcExpand);
	ScreenToClient(m_rcExpand);
	m_rcExpand.bottom = m_rcBrief.bottom;

	OnBtnExpandToggle();

	m_fntStatic1.CreatePointFont(80, _T("Arial Bold"));

	GetDlgItem(IDC_LIST_BOX)->SetFont(&m_fntStatic1);
	
	//---- Init File Path --------
	InitFilePath();
	//----- InitBrush ---------------
	InitBrush();
	InitControl();
	InitGem();
	InitDlg();

	SetTimer(0, 200, NULL);

}

void CDlgSecsGem1::InitFilePath()
{
	//-----------------------
	try
	{
		register CIniFile* IniFile;

		IniFile = new CIniFile(AppPath + FilePath_XGemProjectCfg);
		IniFile->WriteString(_T("Log"),		_T("Dir"),			AppPath + DirPath_GemLog + _T("EquipLog"));
		IniFile->WriteString(_T("XGEM"),	_T("ProjectPath"),	AppPath + FilePath_XGemCfg);
		delete IniFile;

		IniFile = new CIniFile(AppPath + FilePath_XGemCfg);
		IniFile->WriteString(_T("Log"),		_T("Dir"), AppPath  + DirPath_GemLog);
		delete IniFile;

		IniFile = new CIniFile(AppPath + FilePath_HostCfg);

		CString strTemp;
		strTemp.Format("D:\\Viahole\\XGemLog\\XCom");
		IniFile->WriteString("Log", "Dir", strTemp);

		//IniFile->WriteString(_T("Log"),		_T("Dir"),		AppPath + DirPath_GemLog + "XCom");
		//IniFile->WriteString(_T("HSMS"),	_T("IP"),		m_pDlgSecsGemComm1->m_strIPAddr);
		//IniFile->WriteString(_T("HSMS"),	_T("Port"),		m_pDlgCIMTab2->m_strPort);
		delete IniFile;

		IniFile = new CIniFile(AppPath + FilePath_HostTraceCfg);
		IniFile->WriteString(_T("Log"),		_T("Dir"), AppPath + DirPath_GemLog + _T("HostTrace"));
		delete IniFile;
	}
	catch (...)
	{
		::MessageBox(0,_T("Fail to SaveToINI in FilePath of Cim folder"),		//
			"Exception", MB_OK | MB_ICONERROR);	//
	}
}
void CDlgSecsGem1::InitDlg()
{
	int nIndex = -1;
	
	m_pDlgSecsGemComm1.Create(CDlgSecsGemComm1::IDD, GetDlgItem(IDC_STATIC_SUB_VIEW));
	m_pDlgSecsGemComm1.ShowWindow(SW_SHOW);
	m_pDlgSecsGemComm1.m_pParent = this;

	m_pDlgSecsGemTest1.Create(CDlgSecsGemTest1::IDD, GetDlgItem(IDC_STATIC_SUB_VIEW));
	m_pDlgSecsGemTest1.ShowWindow(SW_HIDE);
	m_pDlgSecsGemTest1.m_pParent = this;

	m_pDlgSecsGemConfig1.Create(CDlgSecsGemConfig1::IDD, GetDlgItem(IDC_STATIC_SUB_VIEW));
	m_pDlgSecsGemConfig1.ShowWindow(SW_HIDE);
	m_pDlgSecsGemConfig1.m_pParent = this;
	
}

void CDlgSecsGem1::InitGem()
{
	long nReturn = 0;
	CString str;
	CFileFind fileFind;

	str = AppPath + FilePath_CimCfg;
	
	if(fileFind.FindFile(str))
	{
		if( (nReturn = m_XGem.Initialize(str)) == 0)
			AddListBox("XGem initialized ");
		else
		{	AddListBox("XGem initialize Fail (%d)", nReturn);	return;		}	

		// Start
		if( (nReturn = m_XGem.Start()) == 0) 
			AddListBox("XGem started ");
		else
		{	AddListBox("XGem start Fail (%d)", nReturn);		return;		}
	}
	else 
	{
		str.Format("Open Fail [Gem Config File](%s)", FilePath_CimCfg);
		AfxMessageBox(str, MB_ICONERROR);
		AddListBox(str);
	}
}

void CDlgSecsGem1::InitControl()
{
	// Static
	m_StaticTerminalMsg.SetBackColor(COLOR_DARKGRAY);
	m_StaticTerminalMsg.SetForeColor(COLOR_GREENYELLOW);
	m_StaticTerminalMsg.SetFont(&m_fntStatic1);

	// Button
	m_btnComm.SetFont( &m_fntStatic1 );
	m_btnComm.SetFlat( FALSE );
	m_btnComm.SetImageOrg( 10, 3 );
	m_btnComm.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 0, 128) );  
	m_btnComm.EnableBallonToolTip();
	m_btnComm.SetToolTipText( _T("Comm") );
	m_btnComm.SetBtnCursor( IDC_HAND_1 );

	m_btnConfig.SetFont( &m_fntStatic1 );
	m_btnConfig.SetFlat( FALSE );
	m_btnConfig.SetImageOrg( 10, 3 );
	m_btnConfig.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 0, 128) );  
	m_btnConfig.EnableBallonToolTip();
	m_btnConfig.SetToolTipText( _T("Comm") );
	m_btnConfig.SetBtnCursor( IDC_HAND_1 );

	m_btnTest.SetFont( &m_fntStatic1 );
	m_btnTest.SetFlat( FALSE );
	m_btnTest.SetImageOrg( 10, 3 );
	m_btnTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 0, 128) );  
	m_btnTest.EnableBallonToolTip();
	m_btnTest.SetToolTipText( _T("Comm") );
	m_btnTest.SetBtnCursor( IDC_HAND_1 );

	m_btnComm.SetSelection(1);
	m_btnConfig.SetSelection(0);
	m_btnTest.SetSelection(0);
	
}

void CDlgSecsGem1::InitBrush(void)
{
	static int nButton = 0;
	CWnd *pPrevWnd = GetWindow( GW_CHILD );
	while( pPrevWnd )
	{
		char className[100];
		::GetClassName(
			pPrevWnd->m_hWnd,	// handle to window
			className,			// class name
			100					// size of class name buffer
			);

		if (lstrcmp(className,_T("Button")) == 0)
		{
			CButton *pBtn = (CButton*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic1);

			//TRACE("%d\n",nButton);
		}
		else if (lstrcmp(className,_T("Edit")) == 0)
		{
			CEdit *pBtn = (CEdit*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic1);
		}
		else if (lstrcmp(className,_T("Static")) == 0)
		{
			CStatic *pBtn = (CStatic*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic1);
		};

		pPrevWnd = pPrevWnd->GetWindow( GW_HWNDNEXT );
	}

}


void CDlgSecsGem1::ClearMsgList()
{
	m_ctrlMsgList.ResetContent();
	ASSERT(m_ctrlMsgList.GetCount() == 0);
}		

void CDlgSecsGem1::SetListBoxHorizentalSize()
{
	
	CString str= _T("");
	CSize   sz(0,0);
	int     dx=0;
	CDC*    pDC = m_ctrlMsgList.GetDC();
	
	int nCount = m_ctrlMsgList.GetCount();
	for (int i=0; i <nCount ; i++)
	{
		int n = m_ctrlMsgList.GetTextLen( i );
		if (n >= 0)
		{
			m_ctrlMsgList.GetText( i, str.GetBuffer(n) );
			sz = pDC->GetTextExtent(str);
			str.ReleaseBuffer();
		};
		
		if (sz.cx > dx)
			dx = sz.cx;
	};
	
	m_ctrlMsgList.ReleaseDC(pDC);
	
	// Set the horizontal extent so every character of all strings 
	// can be scrolled to.
#define SCROLL_SIZE 30
	m_ctrlMsgList.SetHorizontalExtent(dx + SCROLL_SIZE);
}

void CDlgSecsGem1::AddListBox(LPCTSTR pFormat, ...)		// myyang 20170927
{
	COleDateTime date = COleDateTime::GetCurrentTime();
	CString strTime = date.Format(_T("%H:%M:%S"));

	char log[65536];
	memset(&log, 0, sizeof(log));
	va_list args;
	va_start(args, pFormat);
	vsprintf_s(log,sizeof(log), pFormat, args); // Visual studio 2010
	va_end(args);

	CString strLog;
	strLog.Format("%s",log);
//	//::AfxGetMainWnd()->SendMessage(UM_REMAIN_LOG_MESSAGE, LOG_GEM, reinterpret_cast<LPARAM>(&strLog));


	strLog.Format(_T("[%s]%s"), strTime, log);

	m_ctrlMsgList.AddString(strLog);
	g_LogFile.Log(SAVE_FILE_VERSION, log);	//�ӽ��ӽ�

	m_ctrlMsgList.SetCurSel(m_ctrlMsgList.GetCount()-1);
}

void CDlgSecsGem1::OnBnClickedBtnClose()
{
	ShowWindow(SW_HIDE);
}
BEGIN_EVENTSINK_MAP(CDlgSecsGem1, CFormView)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 2, CDlgSecsGem1::eGEMCommStateChangedExgemctrl1, VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 3, CDlgSecsGem1::eGEMControlStateChangedExgemctrl1, VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 8, CDlgSecsGem1::eGEMReqDateTimeExgemctrl1, VTS_I4 VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 6, CDlgSecsGem1::eGEMReqGetDateTimeExgemctrl1, VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 17, CDlgSecsGem1::eGEMReqPPDeleteExgemctrl1, VTS_I4 VTS_I4 VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 39, CDlgSecsGem1::eGEMReqPPFmtSend2Exgemctrl1, VTS_I4 VTS_BSTR VTS_BSTR VTS_BSTR VTS_I4 VTS_PBSTR VTS_PI4 VTS_PBSTR VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 18, CDlgSecsGem1::eGEMReqPPListExgemctrl1, VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 11, CDlgSecsGem1::eGEMReqPPLoadInquireExgemctrl1, VTS_I4 VTS_BSTR VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 13, CDlgSecsGem1::eGEMReqPPSendExgemctrl1, VTS_I4 VTS_BSTR VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 10, CDlgSecsGem1::eGEMReqRemoteCommandExgemctrl1, VTS_I4 VTS_BSTR VTS_I4 VTS_PBSTR VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 16, CDlgSecsGem1::eGEMRspPPExgemctrl1, VTS_BSTR VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 22, CDlgSecsGem1::eGEMRspPPFmtExgemctrl1, VTS_BSTR VTS_BSTR VTS_BSTR VTS_I4 VTS_PBSTR VTS_PI4 VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 12, CDlgSecsGem1::eGEMRspPPLoadInquireExgemctrl1, VTS_BSTR VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 24, CDlgSecsGem1::eGEMTerminalMessageExgemctrl1, VTS_I4 VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 25, CDlgSecsGem1::eGEMTerminalMultiMessageExgemctrl1, VTS_I4 VTS_I4 VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 1, CDlgSecsGem1::eSECSMessageReceivedExgemctrl1, VTS_I4 VTS_I4 VTS_I4 VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 27, CDlgSecsGem1::eXGEMStateEventExgemctrl1, VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 28, CDlgSecsGem1::eGEMRspAllECInfoExgemctrl1, VTS_I4 VTS_PI4 VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PBSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 32, CDlgSecsGem1::eGEMRspPPSendExExgemctrl1, VTS_BSTR VTS_BSTR VTS_I4)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 30, CDlgSecsGem1::eGEMRspPPExExgemctrl1, VTS_BSTR VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 31, CDlgSecsGem1::eGEMReqPPExExgemctrl1, VTS_I4 VTS_BSTR VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 15, CDlgSecsGem1::eGEMReqPPExgemctrl1, VTS_I4 VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 29, CDlgSecsGem1::eGEMReqPPSendExExgemctrl1, VTS_I4 VTS_BSTR VTS_BSTR)
	ON_EVENT(CDlgSecsGem1, IDC_EXGEMCTRL1, 21, CDlgSecsGem1::eGEMReqPPFmtExgemctrl1, VTS_I4 VTS_BSTR)
END_EVENTSINK_MAP()


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//										  - xGem Event - 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/****************************************************************************************************
  - 1. Function     : S2 F41  [ H -> EQ]
  - 2. Desciption  :  Host Command Send (HCS) ȣ��Ʈ�κ��� S2 F41�� �޾��� �� Event.
****************************************************************************************************/	
void CDlgSecsGem1::eGEMCommStateChangedExgemctrl1(long nState)
{
	char		szState[64];

	if (nState == Comm_Disabled)			{ strcpy(szState, "[S1F13 H->E]Comm Disabled"); }
	else if(nState == Comm_WaitCRFromHost)	{ strcpy(szState, "[S1F13 H->E]WaitCRFromHost"); }
	else if(nState == Comm_WaitDelay)		{ strcpy(szState, "[S1F13 H->E]WaitDelay"); }
	else if(nState == Comm_WaitCRA)			{ strcpy(szState, "[S1F13 H->E]WaitCRA"); }
	else if(nState == Comm_Communicating)	{ strcpy(szState, "[S1F13 H->E]Communicating"); }

	AddListBox(szState);

	m_xGemCommStatus = (_eCommState)nState;

	// ����Ǹ� �¶��� ��û�Ѵ�.
	if(nState == Comm_Communicating)
	{
		m_XGem.GEMReqRemote();
		AddListBox(_T("[S6F11 E->H] EQ Send GEMReqRemote"));
	}

	if(nState == Comm_WaitCRA)
	{
		m_XGem.GEMReqOffline();
		AddListBox(_T("[S6F11 E->H] EQ Send GEMReqOffline"));
	}
}

/****************************************************************************************************
  - 1. Function     : 
  - 2. Desciption  :  xGem Process ���� Control State ���°� ����ɶ� ȣ�� �Ǵ� event
****************************************************************************************************/	
void CDlgSecsGem1::eGEMControlStateChangedExgemctrl1(long nState)
{
	char		szState[64];

	//Argument : nState value
	//	Control_None = -1, 
	//  Control_EqOffline = 1, 
	//  Control_AttemptOnline, 
	//  Control_HostOffline,
	//  Control_Local, 
	//  Control_Remote

	if (nState == Control_EqOffline)			{ strcpy(szState, "[S1F1] OffLine"); }
	else if(nState == Control_AttemptOnline)	{ strcpy(szState, "[S1F2] Attempt OnLine"); }
	else if(nState == Control_HostOffline)		{ strcpy(szState, "[S1F17] Host OffLine"); }
	else if(nState == Control_Local)			{ strcpy(szState, "[S6F11-CEID2] Online-Local"); }
	else if(nState == Control_Remote)			{ strcpy(szState, "[S6F11-CEID3] Online-Remote"); }

	m_xGemOnlineMode = (_eControlState)nState;

	SendCEID_ControlState(nState);

	AddListBox(szState);
}

/****************************************************************************************************
  - 1. Function     : S1 F13 [EQ -> H]
  - 2. Desciption  :  xGem State �� ����ÿ� �߻��ϴ� event.   
                      xGem State�� [Not Selected -> Selected] ���·� ����� Application�� Gem Driver���� ��Ű���.         
****************************************************************************************************/	
void CDlgSecsGem1::eXGEMStateEventExgemctrl1(long nState)
{
	char		szState[64];

	//Argument : nState value
	//	XGemState_Unknown = -1,
	//	XGemState_Init = 0,
	//	XGemState_Idle,
	//	XGemState_Setup,
	//	XGemState_Ready,
	//	XGemState_Execute

	if (nState == XGemState_Unknown)		{ strcpy(szState, "[XgemOCX] Unknown"); }
	else if(nState == XGemState_Init)		{ strcpy(szState, "[XgemOCX] Init"); }
	else if(nState == XGemState_Idle)		{ strcpy(szState, "[XgemOCX] Idle"); }
	else if(nState == XGemState_Setup)		{ strcpy(szState, "[XgemOCX] Setup"); }
	else if(nState == XGemState_Ready)		{ strcpy(szState, "[XgemOCX] Ready"); }
	else if(nState == XGemState_Execute)	{ strcpy(szState, "[XgemOCX] Execute"); }

	if (nState == XGemState_Execute) {
		//bEnable : 0(Disabled), 1(Enabled)
		m_XGem.GEMSetEstablish(1);
		m_XGem.GEMEQInitialized(1); 
	}

	AddListBox(szState);

	//----------------------------------------------------------
	// 1. MDLN : Euqipment Name			->    SVID 14
	// 2. SOFT Rev : Software revision  ->		SVID 15
	long nCount = 2;
	long naVid[2];
	CString saValue[2];

	naVid[0] = SVID_MDLN;    saValue[0] = Machine_Name;
	naVid[1] = SVID_SOFTREV; saValue[1] = SOFTWARE_VERSION;

	m_XGem.GEMSetVariable(nCount, naVid, saValue);
	//----------------------------------------------------------
}

/****************************************************************************************************
  - 1. Function     :  [H -> EQ]
  - 2. Desciption  :  Host�κ��� S2 F31 ���� ��� �����ϴ� event 
****************************************************************************************************/	//Host ���� ���� �ð����� Set
void CDlgSecsGem1::eGEMReqDateTimeExgemctrl1(long nMsgId, LPCTSTR sSystemTime)
{
	long nReturn = 0;
	nReturn = m_XGem.GEMRspDateTime(nMsgId, 0); 
}

/****************************************************************************************************
  - 1. Function     : S2 F17 [EQ -> H]
  - 2. Desciption  :  Host�� Data and Time ��û
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqGetDateTimeExgemctrl1(long nMsgId)//Host ���� EQ�� �ð��� ���
{
	long nReturn  = 0;
	char szMsg[256];
	char szTime[256];
	SYSTEMTIME oSysTime;

	::GetLocalTime(&oSysTime);
	
	sprintf(szTime, "%04d%02d%02d%02d%02d%02d", oSysTime.wYear, oSysTime.wMonth, oSysTime.wDay,
		oSysTime.wHour, oSysTime.wMinute, oSysTime.wSecond);

	nReturn = m_XGem.GEMRspGetDateTime(nMsgId, szTime);
	if( nReturn == 0 ) 
		AddListBox("[S2F17 E->H] Send GEMRspGetDateTime ");
	else 
		AddListBox("[S2F17 E->H] Fail to GEMRspGetDateTime (%d)", nReturn);
}

/****************************************************************************************************
  - 1. Function     : S7 F17 [ H -> EQ]
  - 2. Desciption  :  PPID ���� ��û�� ȣ��Ʈ�� ���� 
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPDeleteExgemctrl1(long nMsgId, long nCount, BSTR* psPpid)
{
	long nReturn = 0;
	long nResult = 0;
	char szMsg[256];
	CString *psTemp = NULL;
	CPPDelete PPDeleteList;

	AddListBox("[S7F17 H->E] Received GEMReqPPDelete, MsgId = %d, Count = %d", nMsgId, nCount);

	psTemp = new CString[nCount];
	for(int i = 0; i < nCount; i++) {
		psTemp[i] = psPpid[i];
		sprintf(szMsg, "    Ppid = %s", psTemp[i] );
		PPDeleteList.strPPIDList.Add(psTemp[i]);
		AddListBox(szMsg);
	}

	PPDeleteList.nCount = nCount;
	PPDeleteList.nMsgID = nMsgId;
	
	DeletePPID(&PPDeleteList);

	delete [] psTemp; psTemp = NULL;
}

/****************************************************************************************************
  - 1. Function     : S7 F23 [ EQ -> H]
  - 2. Desciption  :  S7 F23 Format ����.  
                           
						   L,2
						     1. <CCode>
							 2. L,p
							    1. <PPARM>                  ->      1. <PPNAME>
								                                              2. <PPVALUE>

****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPFmtSend2Exgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sMdln, LPCTSTR sSoftRev, long nCount, BSTR* psCCoode, long* pnParamCount, BSTR* psParamNames, BSTR* psParamValues)
{
	
}

/****************************************************************************************************
  - 1. Function     : S7 F19 [ H -> EQ]
  - 2. Desciption  :  - PPID  List ��û�� ȣ��Ʈ�� ����    
                            - PPID List������ �÷��ش�.
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPListExgemctrl1(long nMsgId)
{
	long nReturn = 0;
	long nResult = 0;
	char szMsg[256];
	int nIndex = 1;
	int nCount = 0;
	CFileFind fileFind;
	CString strPath;

	CString strFileName = "";
	CStringArray strPPIDList;
	CString* saPpids;
	CString strFilename;
	CString strPrj;

	strPPIDList.RemoveAll();

	AddListBox("[S7F19 H->E] Received GEMReqPPList, MsgId = %d", nMsgId );

	strPath = gEasyDrillerINI.m_clsDirPath.GetProjectDir() + "*.*";
	fileFind.FindFile((LPCTSTR)strPath);

	while(nIndex)
	{
		nIndex = fileFind.FindNextFile();
		strFilename = fileFind.GetFileName();
		
		strPrj.Format(_T("%s"), strFilename.Right(4));
		
		if( 0 == strPrj.CompareNoCase(_T(".prj")) && !fileFind.IsDirectory()) // Ȯ���� prj �̰�, Directory�� �ƴ� ���.
		{
			strPPIDList.Add(strFilename);
		}
	}

	nCount = strPPIDList.GetCount();
	saPpids = new CString[nCount];

	for(int i=0; i< nCount; i++)
	{
		saPpids[i] = strPPIDList.GetAt(i);
	}

	fileFind.Close();

	nReturn = m_XGem.GEMRspPPList(nMsgId, nCount, saPpids);
	if( nReturn == 0 ) 
		AddListBox("[S7F20 E->H] Send GEMRspPPList " );
	else
		AddListBox("[S7F20 E->H] Fail to GEMRspPPList (%d)", nReturn );

	delete[] saPpids; saPpids = NULL;
}

/****************************************************************************************************
  - 1. Function     : S7 F1 [ H -> EQ]
  - 2. Desciption  :  - PPID  
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPLoadInquireExgemctrl1(long nMsgId, LPCTSTR sPpid, long nLength)
{
	/*
	long nReturn = 0;
	long nResult = ResultPPLoadOK;
	char szMsg[256];
	CString strPath = "";
	CFileFind fileFind;

	strcpy_s(m_HostInquire.szPPID, sPpid);
	m_HostInquire.nSize = nLength;

	AddListBox("[S7F1 H->E] Received GEMReqPPLoadInquire, MsgId = %d, Ppid = %s, Result = %d", nMsgId, sPpid, nLength );
	
	// 1. File ���� Ȯ��
	strPath.Format("%s%s", AppPath+FilePath_Project, sPpid);
	if(fileFind.FindFile(strPath, 0) == TRUE)
	{
		nResult = ResultPPLoadAlreadyHave;
	}
	
	// 2. �ϵ��ũ ���� Ȯ��?
	if(FALSE)
		nResult = ResultPPLoadNoSpace;

	// 3. PPID ��ȿ�� Ȯ��
	if(PPIDValidation(sPpid, m_bZipUse) == FALSE)
		nResult = ResultPPLoadInvalidPPID;

	// 4. Busy, try Later ??
	if(FALSE)
		nResult = ResultPPLoadBusy;
	// 5. Will Not Accept
	if(FALSE)
		nResult = ResultPPLoadWillNotAccept;
		
	nReturn = m_XGem.GEMRspPPLoadInquire(nMsgId, sPpid, nResult);
	if( nReturn == 0 ) 
		AddListBox("[S7F2 E->H] Send GEMReqPPLoadInquire " );
	else 
		AddListBox("[S7F2 E->H] Fail to GEMRspPPLoadInquire (%d)", nReturn );
		*/
}

/********************************************************************************
 - 1. Function   : 
 - 2. Desciption : ���� Gem ECID ���� ��� ȣ��. 
********************************************************************************/
void CDlgSecsGem1::eGEMRspAllECInfoExgemctrl1(long lCount, long* plVid, BSTR* psName, BSTR* psValue, BSTR* psDefault, BSTR* psMin, BSTR* psMax, BSTR* psUnit)
{
	int i = 0;
	char szMsg[256];

	long *pnECVid = NULL;
	CString *psECName = NULL;
	CString *psECVal = NULL;
	CString *psECDef = NULL;
	CString *psECMin = NULL;
	CString *psECMax = NULL;
	CString *psECUnit = NULL;

	if (lCount > 0) {
		pnECVid = new long[lCount];
		psECName = new CString[lCount];
		psECVal = new CString[lCount];
		psECDef = new CString[lCount];
		psECMin = new CString[lCount];
		psECMax = new CString[lCount];
		psECUnit = new CString[lCount];
	}

	for(i = 0; i < lCount; i++) {
		pnECVid[i] = plVid[i];
		psECName[i] = psName[i];
		psECVal[i] = psValue[i];
		psECDef[i] = psDefault[i];
		psECMin[i] = psMin[i];
		psECMax[i] = psMax[i];
		psECUnit[i] = psUnit[i];
	}

	m_pDlgSecsGemTest1.m_cmbEcid.Clear();

	sprintf(szMsg, "Received %s, Count = %d", "GEMRspAllECInfo", lCount );
	for( i = 0; i < lCount; i++) {
		sprintf( szMsg, "	Vid(%d), Name(%s), Value(%s), Def(%s), Min(%s), Max(%s), Unit(%s)", 
			pnECVid[i], psECName[i], psECVal[i], psECDef[i], psECMin[i], psECMax[i], psECUnit[i]);

		sprintf( szMsg, "%d - %s", pnECVid[i], psECName[i]);
		m_pDlgSecsGemTest1.m_cmbEcid.DeleteString(i);
		m_pDlgSecsGemTest1.m_cmbEcid.AddString( szMsg );
	}

	if (pnECVid != NULL) { delete [] pnECVid; pnECVid = NULL; }
	if (psECName != NULL) { delete [] psECName; psECName = NULL; }
	if (psECVal != NULL) { delete [] psECVal; psECVal = NULL; }
	if (psECDef != NULL) { delete [] psECDef; psECDef = NULL; }
	if (psECMin != NULL) { delete [] psECMin; psECMin = NULL; }
	if (psECMax != NULL) { delete [] psECMax; psECMax = NULL; }
	if (psECUnit != NULL) { delete [] psECUnit; psECUnit = NULL; }
}

/****************************************************************************************************
  - 1. Function     : S7 F2 [ H -> EQ]
  - 2. Desciption  :  - PPID  LoadInquire Response
****************************************************************************************************/
void CDlgSecsGem1::eGEMRspPPLoadInquireExgemctrl1(LPCTSTR sPpid, long nResult)
{
	CString str;

	AddListBox("[S7F2 H->E] Received GEMReqPPLoadInquire, PPID:%s Value:%d", sPpid, nResult);

	switch(nResult)
	{
	case 0: // OK
		{
			if (m_stPPLoadInquireResult.szPPID == sPpid)
			{
				m_stPPLoadInquireResult.bOK = TRUE;
			}

			break;
		}
	case 1: // Already have
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "Already Have");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	case 2: // No space
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "No Space");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	case 3: // Invalid PPID
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "Invalid PPID");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	case 4: // Busy, try later
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "Busy, try later");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	case 5: // Will not accept
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "Will not Accept");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	default: // Other error
		{
			strcpy_s(m_stPPLoadInquireResult.szMsg , "Other Error");
			m_stPPLoadInquireResult.bOK = FALSE;
			break;
		}
	}

	m_evRecv.SetEvent();
}


/****************************************************************************************************
  - 1. Function     : S7 F3 [ H -> EQ]
  - 2. Desciption  :  PPID DownLoad Request
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPSendExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sBody)
{
	long nReturn = 0;
	long nResult = 0;
	char szMsg[256];

	AddListBox("[S7F3 H->E] Received GEMReqPPSend, MsgId = %d, Ppid = %s, Body = %s", nMsgId, sPpid, sBody );

	nReturn = m_XGem.GEMRspPPSend(nMsgId, sPpid, nResult);
	if( nReturn == 0 ) 
		AddListBox("[S7F4 E->H] Send GEMRspPPSend " );
	else 
		AddListBox("[S7F4 E->H] Fail to GEMRspPPSend (%d)", nReturn );
}

/****************************************************************************************************
  - 1. Function     : S7 F3 [ H -> EQ]
  - 2. Desciption  :  PPID DownLoad Request   [Extension Ȯ��Ÿ��]
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPSendExExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sRecipePath) //CEID �̺κ��� Recipe ������ HOST���� �޾Ƽ� ���� Ǯ�� ���� �̵� �� ����� �ͱ��� �Ǿ� �ֳ׿� ^^
{
	long nReturn = 0;
	long nResult = 0;
	char szMsg[256];
	CString strMsg = "";
	CString strPath = "";
	CString strZipPath = "";
	CString strUnZippath = "";
	CString strPPID = "";
	CString strRecipePath ="";
	int nFind = 0;
	int nCount = 0;

	CRecipeFileList DLRecipe;	
	AddListBox("[S7F3 H->E] Received GEMReqPPSendEx, MsgId = %d, Ppid = %s, RecipePath = %s", nMsgId, sPpid, sRecipePath );

	strRecipePath.Format("%s",sRecipePath);

	CFile File;
	if (File.Open(strRecipePath, CFile::modeRead) == FALSE)
	{
		m_XGem.GEMRspPPSendEx(nMsgId, sPpid, sRecipePath, ResultPPIDNotfound);	// S7 F4 (H<-E) �� ����
		AddListBox(" PPLoad Recipe[sPpid]='%s' read fail on path '%s'", sPpid, strRecipePath);
		AddListBox("[S7F4 E->H] EQ Send RspPPSendEx with Return[%d]", ResultPPIDNotfound);
		return;
	}

	if (m_HostInquire.szPPID == sPpid)
	{
		if ((long)File.GetLength() != m_HostInquire.nSize)
		{
			m_XGem.GEMRspPPSendEx(nMsgId, sPpid, sRecipePath, ResultLengthError);	// S7 F4 (H<-E) �� ����
			AddListBox(" PPLoad Recipe[sPpid]='%s' size Error", sPpid);
			AddListBox("[S7F4 E->H] EQ Send RspPPSendEx with Return[%d]", ResultLengthError);
			return;
		}
	}
	/*
	CRecipeFileList* pRFL = new CRecipeFileList;
	if (DivideRecipeFiles(sPpid, File, pRFL) == FALSE)
	{
		m_XGem.GEMRspPPSendEx(nMsgId, sPpid, sRecipePath, ResultLengthError);	// S7 F4 (H<-E) �� ����
		AddListBox(" PPLoad Recipe[sPpid]='%s' fail to divide ", sPpid);
		AddListBox("[S7F4 E->H] EQ Send RspPPSendEx with Return[%d]", ResultLengthError);
		return;
	}

	//1. Recipe ���� ����
	RecipeCopy(pRFL);
	*/
	// nResult 
	// 0: Accepted
	// 1: Permission not granted
	// 2: Length error
	// 3: Matrix overflow
	// 4: PPID not found
	// 5: Mode unsupported
	
	CString strTargetPath;
	strTargetPath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), sPpid);

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->IsFileExist(strTargetPath) == TRUE) // ���� ������ ���� ���� ó���� ��� �ؾ�����?
	{
		CopyFile(strRecipePath, strTargetPath, FALSE);
	}
	else
	{
		CopyFile(strRecipePath, strTargetPath, FALSE);
	}		

	m_XGem.GEMRspPPSendEx(nMsgId, sPpid, sRecipePath, ResultAccepted);	// S7 F4 (H<-E) �� ����

	// 2. Temp File ����
	DeleteFile(strRecipePath);

	if( nReturn == 0 ) 
		AddListBox("Send GEMRspPPSendEx ");
	else 
		AddListBox("Fail to GEMRspPPSendEx (%d)", nReturn );
}

/****************************************************************************************************
  - 1. Function     : S7 F4 [ H -> EQ]
  - 2. Desciption  :  PPID DownLoad Response
****************************************************************************************************/	
void CDlgSecsGem1::eGEMRspPPSendExExgemctrl1(LPCTSTR sPpid, LPCTSTR sRecipePath, long nResult)
{
	char szMsg[256];
	CString strPath = "";

	strPath.Format("%s%s%s", AppPath, FilePath_XGemRecipe, sPpid);

	DeleteFile(strPath);

	AddListBox("[S7F4 H->E] Received GEMRspPPSendEx, Ppid = %s, Body = %s", sPpid, sRecipePath );
}

/****************************************************************************************************
  - 1. Function     : S7 F5 [ H -> EQ] 
  - 2. Desciption  :  Host ���� PPID Unformatted PPID Download ��û
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPExgemctrl1(long nMsgId, LPCTSTR sPpid)
{
	AddListBox("[S7F5 H->E] Received GEMReqPP, Ppid = %s", sPpid );
}

/****************************************************************************************************
  - 1. Function     : S7 F5 [ H -> EQ] 
  - 2. Desciption  :  Host[Eqjuipment] ���� PPID Unformatted PPID Download ��û   [Extension : Ȯ��Ÿ��]
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqPPExExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sRecipePath)
{
	char szMsg[256];

	CString strPPID = "";

	strPPID.Format("%s", (CString)sPpid );

	int nFind = strPPID.Find('.');
	int nCount = strPPID.GetLength();

	// .prj Delete
	if(nFind >= 0)
	{
		for(int i = nFind; i < nCount; i++)
			strPPID.Delete(nFind);
	}

	strPPID.Format(_T("%s.zip"),strPPID);

	if(MakeRecipeFile(sPpid,NULL, sRecipePath) == TRUE)
		m_XGem.GEMRspPPEx(nMsgId, strPPID, "");

	AddListBox("[S7F5 H->E] Received GEMReqPPex, Ppid = %s, RecipePath = %s", sPpid, sRecipePath );
}


/****************************************************************************************************
  - 1. Function     : S7 F6 [ H <-> EQ] 
  - 2. Desciption  :  Host���� PPID Unformatted PPID Download 
****************************************************************************************************/	
void CDlgSecsGem1::eGEMRspPPExgemctrl1(LPCTSTR sPpid, LPCTSTR sBody)
{
	AddListBox("[S7F6 H<->E] Received GEMRspPP, Ppid = %s, Body = %s", sPpid, sBody );
}


/****************************************************************************************************
  - 1. Function     : S7 F6 [ H <-> EQ] 
  - 2. Desciption  :  Host���� PPID Unformatted PPID Download [Extension : Ȯ��Ÿ��]
****************************************************************************************************/	
void CDlgSecsGem1::eGEMRspPPExExgemctrl1(LPCTSTR sPpid, LPCTSTR sRecipePath)
{
	AddListBox("[S7F6 H<->E] Received GEMRspPPEx, Ppid = %s, RecipePath = %s", sPpid, sRecipePath );
}


/****************************************************************************************************
  - 1. Function     : S7 F24 [ H-> EQ] reply
  - 2. Desciption  :  Host���� PPID Unformatted PPID ������ ���� ����
****************************************************************************************************/	
void CDlgSecsGem1::eGEMRspPPFmtExgemctrl1(LPCTSTR sPpid, LPCTSTR sMdln, LPCTSTR sSoftRev, long nCount, BSTR* psCCode, long* pnParamCount, BSTR* psParamNames)
{
	char szMsg[256];
	CString sTemp = "";
	long nIndex = 0;

	AddListBox("[S7F24 H->E] Received GEMRspPPFmt, Ppid = %s, Mdln = %s, SoftRev = %s, Count = %d", sPpid, sMdln, sSoftRev, nCount );

	nIndex = 0;
	for(int i = 0; i < nCount; i++) 
	{
		sTemp = psCCode[i];
		AddListBox("	CCode = %s, ParamCount = %d", sTemp, pnParamCount[i] );

		for(int j = 0; j < pnParamCount[i]; j++) 
		{
			sTemp = psParamNames[nIndex];
			AddListBox("        ParamName = %s", sTemp);
			nIndex++;
		}
	}
}

/****************************************************************************************************
  - 1. Function     : S2 F41 [ H-> EQ] 
  - 2. Desciption  :  Host���� Remote Command �۽�
                            sRcmd : Remote Command
							nCount : Command Parameter ����
							psNames : CPName
							psValue : CPValue
****************************************************************************************************/	
void CDlgSecsGem1::eGEMReqRemoteCommandExgemctrl1(long nMsgId, LPCTSTR sRcmd, long nCount, BSTR* psNames, BSTR* psVals)
{
	long nReturn  = 0;
	char szMsg[256];
	CString sName, sValue;
	long nHCAck = 0;
	long *pnResult = NULL;

	
	stRemoteCmdResult* stRcmdResult = new stRemoteCmdResult;
	
	// RemoteCommand Insert.
	strcpy_s(stRcmdResult->szRcmd, sRcmd);

	m_stRcmdResultList.AddTail(stRcmdResult);

	// Remote Command ������  ������ �ڵ鷯����...
	CRemoteCommand*	stRCMD = stRCMD = new CRemoteCommand;

	strcpy_s(stRCMD->szRcmd, sRcmd);
	stRCMD->nMsgId = nMsgId;
	stRCMD->nCount = nCount;

	AddListBox("[S2F41 H->E] Remote Command : %s", sRcmd);

	for(int i = 0; i < nCount; i++) {
		sName = psNames[i]; 
		sValue = psVals[i];

		stRCMD->strCPNameList.Add(sName);
		stRCMD->strValueList.Add(sValue);

		AddListBox("		Name: %s, Value: %s", sName, sValue);
	}

	nHCAck = 0;
	pnResult = new long[nCount];
	for(int i = 0; i < nCount; i++) {
		pnResult[i] = 0;
	}

	// Remote Command  send to main Dialog.
	::AfxGetMainWnd()->PostMessage(WM_USER_RCMD_SEND, (WPARAM)stRCMD, 0);

	delete [] pnResult; pnResult = NULL;
}


/****************************************************************************************************
  - 1. Function     : 
  - 2. Desciption  :  Host�κ��� User Defined Message ����
****************************************************************************************************/	
void CDlgSecsGem1::eSECSMessageReceivedExgemctrl1(long nObjectID, long nStream, long nFunction, long nSysbyte)
{
	int a= 0;
	/*//NoUse
	// S7 F26
	if ((nStream == 7) && (nFunction == 25))
	{
		long lCnt;

		// S7 F25 �� PPID ���� �����´�
		CString strPpid;
		m_XGem.GetAscii(nObjectID, &strPpid, &lCnt);
		m_XGem.CloseObject(nObjectID);
		///////////////////////////////////////////////////////

		long lRet = 0;
		long IObjId = 0;

		CString strData;
		m_XGem.MakeObject(&IObjId);
		m_XGem.SetList(IObjId,4);

		strData = strPpid;
		m_XGem.SetAscii( IObjId, strData, strData.GetLength() );
		strData = Machine_Name;
		m_XGem.SetAscii( IObjId, strData, strData.GetLength() );
		strData = SOFTWARE_VERSION;
		m_XGem.SetAscii( IObjId, strData, strData.GetLength() );

		m_XGem.SetList(IObjId, MAX_USE_TOOL);
		
		// ParamList
		long lU2 = 0;
		for(int nTool = 0; nTool < MAX_USE_TOOL; nTool++)
		{
			int nMaxParam;
			if(nTool == 0)
				nMaxParam = MAX_USE_LAYOUT_PARAM;
			else
				nMaxParam = MAX_USE_TOOL_PARAM;

			for(int nParam = 0; nParam < nMaxParam; nParam++)
			{
				double dU4 = 0;
				float fF4 = 0;
				CString strAscii = _T("0");

				// ó������ List ���� ����
				if(nTool == 0)
				{
					if(nParam == 0)
					{
						m_XGem.SetList(IObjId, 2);			// L2
						lU2 = nTool;
						m_XGem.SetU2(IObjId, &lU2,1);		// CCODE
						m_XGem.SetList(IObjId, MAX_USE_LAYOUT_PARAM);			// L5
					}
				}
				else
				{
					if(nParam == 0)
					{
						m_XGem.SetList(IObjId, 2);			// L2
						lU2 = nTool;
						m_XGem.SetU2(IObjId, &lU2,1);		// CCODE
						m_XGem.SetList(IObjId, MAX_USE_TOOL_PARAM);			// L43
					}
				}
				//
				
				GetParamNameAndValue(nTool, nParam, IObjId, dU4, fF4, strAscii);

				if(nTool == 0)
				{
					if(nParam == 2)
					{
						if(fF4 < 0)		// 20191212
							fF4 = 0;

						m_XGem.SetF4(IObjId, &fF4,1);
					}
					else
					{
						if(dU4 < 0)		// 20191212
							dU4 = 0;

						m_XGem.SetU4(IObjId, &dU4,1);
					}
				}
				else
				{
					if(nParam == 11 || nParam == 12 || nParam == 31 || nParam == 32)
					{
						if(fF4 < 0)		// 20191212
							fF4 = 0;

						m_XGem.SetF4(IObjId, &fF4,1);
					}
					else if(nParam == 14 || nParam == 18 || nParam == 34 || nParam == 38)
					{
						if(strAscii.IsEmpty() || strAscii.GetLength() == 0 || strAscii == _T(" "))		// 20191206
							strAscii = _T("0");

						m_XGem.SetAscii(IObjId, strAscii, strAscii.GetLength() );
					}
					else
					{
						if(dU4 < 0)		// 20191212
							dU4 = 0;

						m_XGem.SetU4(IObjId, &dU4,1);
					}
				}
			}
		}

		lRet = m_XGem.SendSECSMessage(IObjId, 7, 26, nSysbyte);
		m_XGem.CloseObject( IObjId );

		if(gXGem1->GetControlStatus() == Control_Local)		
		{
			gXGem1->m_bReceivePPValid = TRUE; 
			// S7 F26 �� �����ų� �ƴϸ� (�ɼǻ���)
			// Online Local ��忡���� 
			// Recipe ���� �޾Ҵٰ� ġ��
			// CEID 404 [Recipe Validation Report] �� ������
			//		gXGem1->SendXGEMEvent(CEID_RECIPE_VALIDATION,gXGem1->m_strInsertLotID);
		}
	}
	*/ //NoUse
}

/****************************************************************************************************
  - 1. Function     : S10 F3
  - 2. Desciption  :  Host�κ��� Terminal Message ����.  - Single
****************************************************************************************************/	
void CDlgSecsGem1::eGEMTerminalMessageExgemctrl1(long nTid, LPCTSTR sMsg)
{
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();

	m_StaticTerminalMsg.SetWindowText(sMsg);
//	ShowWindow(SW_SHOW);		// 20191206


	CString strMsg, strTid;
	strMsg.Format("Received TID = %d, Msg = %s", nTid, sMsg);
	strTid.Format("%d",nTid);

	OpTerminalDlg(strTid, strMsg);

	if(nTid == 3)//E1 ����ó�� Lot�� ���� �� �� �����ϴ�
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_GetLotInfoFromHost(FALSE);
		ErrMessage(strMsg);
		::AfxGetMainWnd()->SendMessage(UM_CLEAR_LOT_INFO);
	}
	else if(nTid == 4)//E6 Recipe�� Select �� �� �����ϴ�
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_GetLotInfoFromHost(FALSE);
		ErrMessage(strMsg);
		//gXGem1->SendXGEMEvent(CEID_CANCEL_REPORT);//CEID 303
	}
	else if(nTid == 5)//E8 Recipe Validation" Result Fail
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_LotReadyFromHost(FALSE);
		ErrMessage(strMsg);
		//gXGem1->SendXGEMEvent(CEID_CANCEL_REPORT);//CEID 303
	}
	else if(nTid == 5)//E10 Start Command" Result Fail
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_LotReadyFromHost(FALSE);
		ErrMessage(strMsg);
		//gXGem1->SendXGEMEvent(CEID_CANCEL_REPORT);//CEID 303
	}
//	else
//		OpTerminalDlg(strTid, strMsg);		// 20191206
}

/****************************************************************************************************
  - 1. Function     : S10 F5
  - 2. Desciption  :  Host�κ��� Terminal Message ����.  - Multi Block.
****************************************************************************************************/	
void CDlgSecsGem1::eGEMTerminalMultiMessageExgemctrl1(long nTid, long nCount, BSTR* psMsg)
{
	CString s, sTemp = "", sMsg = "";
	//char szMsg[256];
	int i = 0;

	char szMsg[256];
	CString strMsg,strTid;

	sprintf(szMsg, "Received %s, Tid = %d, Count = %d", "GEMTerminalMultiMessage", nTid, nCount );
	strTid.Format("%d", nTid);

	for( i = 0; i < nCount; i++) {
		s = psMsg[i];
		sTemp.Format("%s\r\n%s", sMsg, s);
		sMsg = sTemp;

		OpTerminalDlg(strTid, strMsg);
	}

	m_StaticTerminalMsg.SetWindowText(sMsg);
//	ShowWindow(SW_SHOW);		// 20191206
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//										  - User Function- 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Delete Diretory
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::DeleteDiretory(CString	RootDir)
{
	BOOL bRet = FALSE; 
	CString strFileName;
	CString strRoot;

	// �ش� ���丮�� ��� ������ �˻��Ѵ�.
	strRoot.Format(_T("%s\\*.*"), RootDir);
		
	WIN32_FIND_DATA wfd;
	HANDLE hFindFile = ::FindFirstFile(strRoot, &wfd);
	
	do
	{  
		if( FILE_ATTRIBUTE_DIRECTORY != ( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) )
		{
			strFileName.Format(_T("%s\\%s"), RootDir, wfd.cFileName);
			
			DeleteFile(strFileName); 
		}
	} while( ::FindNextFile(hFindFile , & wfd ));

	::FindClose(hFindFile);

	RemoveDirectory( RootDir );          
}


/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Recipe File Copy
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::RecipeCopy(CRecipeFileList* stData)
{
	
	long nResult = ResultAccepted;

	if(m_strLastProjectName == stData->szRecipeID)
	{
		nResult = ResultPermissionNotGranted;
	}
	else
	{
		CFileFind fileFind;
		CString strPrjPath;
		CString strPrjName;
		bool bExistFile = false;

		strPrjName.Format("Project\\%s.prj", stData->szRecipeID);
		strPrjPath = AppPath + strPrjName;

		if(fileFind.FindFile(strPrjPath))
			bExistFile = true;

		CString strFullPath = "";
		strFullPath.Format("%s" ,stData->szFullPath);




		// File ����.
		WIN32_FIND_DATA wfd;
		HANDLE hFindFile = ::FindFirstFile(strFullPath, &wfd);

		do
		{
			CString strFileName;
			CString strFormat;

			// Index �� ����?
			// Main Project 
			if(stData->szMainProjectPath != "")
			{
				if(!PPIDCopytoHWDir(rtProject, (LPCTSTR)stData->szMainProjectPath))
					nResult = ResultPermissionNotGranted;
			}
			
			// MarkBox Project
			if(stData->strMarkProjectPathList.GetCount() > 0)
			{
				if(!PPIDCopytoHWDir(rtMarkBox, stData->strMarkProjectPathList.GetAt(0)))
					nResult = ResultPermissionNotGranted;
			}

			// Mark Parameter 
			if(stData->strMarkParamPathList.GetCount() > 0)
			{
				if(!PPIDCopytoHWDir(rtMarkParam, stData->strMarkParamPathList.GetAt(0)))
					nResult = ResultPermissionNotGranted;
			}

			// Mark Design
			if(stData->strMarkDesignPathList.GetCount() > 0)
			{
				if(!PPIDCopytoHWDir(rtMarkDsgn, stData->strMarkDesignPathList.GetAt(0)))
					nResult = ResultPermissionNotGranted;
			}

			// Strip Editor
			if(stData->szStripEditorPath != "")
			{
				if(!PPIDCopytoHWDir(rtSTEditor, (LPCTSTR)stData->szStripEditorPath))
					nResult = ResultPermissionNotGranted;
			}

		}
		while(::FindNextFile(hFindFile, &wfd) );

		if(!bExistFile)
		{

		}

		::FindClose( hFindFile );
	}
	
	// nResult 
	// 0: Accepted
	// 1: Permission not granted
	// 2: Length error
	// 3: Matrix overflow
	// 4: PPID not found
	// 5: Mode unsupported
	m_XGem.GEMRspPPSendEx(stData->nMsgID, (LPCTSTR)stData->szRecipeID, "", nResult);


}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  PPID ��ȿ�� üũ
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::PPIDCopytoHWDir(_eRecipeType rtType, CString strPPID)
{
	CString strPPIDName = ""; 
	bool bSendToVisionPC = false;
	strPPIDName = ExtractFileName(strPPID);

	CString FilePath;

	switch(rtType)
	{
	case rtNone:
		break;
	case rtProject:
		FilePath = AppPath + FilePath_Project;/*_T("Project\\");*/
		break;
	case rtMarkBox:
		FilePath = AppPath + FilePath_MarkBox;/*_T("MarkBox\\");*/
		break;
	case rtMarkDsgn:
		FilePath = AppPath + FilePath_MarkBox_Dsgn;/*_T("MarkBox\\MarkDsgn\\");*/
		break;
	case rtMarkParam:
		FilePath = AppPath + FilePath_MarkBox_Param;/*_T("MarkBox\\MarkParam\\")*/
		break;
	case rtSTEditor:
		FilePath = AppPath + FilePath_StripEditor;/*_T("STE\\");*/
		break;
	case rtVision:
		FilePath = AppPath + FilePath_Vision_Job;
		bSendToVisionPC = true;
		break;
	}

	if (!::CopyFile(strPPID, FilePath+strPPIDName, FALSE)) // �μ��� TRUE�̸� �� �Լ��� ���и� �����ϸ� FALSE�̸� ���� ������ �����.
	{	
		AfxMessageBox(_T("File copy fail!"));
		return FALSE;
	}

	// Vision Job File Send to VisionPC
	if(bSendToVisionPC)
	{
		int nRet = m_pServer->SendFile(strPPID, 3000);
		CString strLog = "";
		strLog.Format(_T("File Share =======> Recipe Download To Vision from %s. Result: %d."), strPPID, nRet);
		g_LogFile.Log(SAVE_FILE_VERSION, strLog);//�ӽ��ӽ�

		if (nRet != FS_RESULT_SUCCESS)
		{
			AfxMessageBox(_T("Fail to send file to Vision"), MB_ICONERROR);
			return FALSE;
		}
	}
	
	//======================================
	return TRUE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  PPID ��ȿ�� üũ
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::PPIDValidation(CString strPPID, BOOL bZipUse)
{
	BOOL bRet = TRUE;

	return bRet;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Recipe Merge
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::MergeRecipeFiles(CFile& File, CRecipeFileList* pData)
{
	//if(pData == NULL) return FALSE;

	int nMarkPrjCnt = pData->strMarkProjectPathList.GetCount();
	int nMarkDesignCnt = pData->strMarkDesignPathList.GetCount();
	int nMarkParamCnt = pData->strMarkParamPathList.GetCount();

	CString strLog = _T("");
	strLog += _T("MergeRecipeFiles\r\n");
	strLog += (_T("\r\n - UIMainProject : %s"), pData->szMainProjectPath);
	strLog += (_T("\r\n - strUIStripEditor : %s"), pData->szStripEditorPath);

	for(int i =0; i < nMarkPrjCnt; i++)
		strLog += (_T("\r\n - strMarkMainProject%d : %s"), i, pData->strMarkProjectPathList.GetAt(i));
	
	for(int i=0; i< nMarkDesignCnt; i++)
		strLog += (_T("\r\n - strMarkDesign%d : %s"), i, pData->strMarkDesignPathList.GetAt(i));

	for(int i=0; i< nMarkParamCnt; i++)
		strLog += (_T("\r\n - strMarkParam%d : %s"), i, pData->strMarkParamPathList.GetAt(i));
	
	AddListBox(strLog);

	// File Merge
	CArchive ar(&File, CArchive::store);

	int nVersion = 0;
	ar.Write(&nVersion, 4);
	
	CArray<CString, CString> recipes;
	//-----------------------------------------------
	//GetRecipeArray(pData, &recipes);
	recipes.RemoveAll();
	int i=0;
	recipes.Add((LPCTSTR)pData->szMainProjectPath);
	recipes.Add((LPCTSTR)pData->szStripEditorPath);

	for(int i=0; i< nMarkPrjCnt; i++)
		recipes.Add(pData->strMarkProjectPathList.GetAt(i));

	for(int i=0; i< nMarkDesignCnt; i++)
		recipes.Add(pData->strMarkDesignPathList.GetAt(i));

	for(int i=0; i< nMarkParamCnt; i++)
		recipes.Add(pData->strMarkParamPathList.GetAt(i));
	//-------------------------

	char szBuf[40960] = {0};
	CString strRecipe = "";

	int nCount = recipes.GetSize();
	for (int i=0; i<nCount; i++)
	{
		CFile FileUnit;
		strRecipe = recipes.GetAt(i);
		if (FileUnit.Open(strRecipe, CFile::modeRead) == FALSE)
		{
			AddListBox(_T("[Recipe Merge] Recip file open Fail"));
			return FALSE;
		}

		char szFName[_MAX_FNAME]={0}, szExt[_MAX_EXT]={0};
		
		_splitpath_s(recipes[i], NULL,0,NULL,0, szFName, sizeof(szFName),szExt, sizeof(szFName));

		CString strFileName;
		strFileName.Format(_T("%s%s"), szFName, szExt);

		ar << strFileName;

		DWORD dwDataSize = (DWORD)FileUnit.GetLength();
		DWORD dwTotalRead = 0;

		CString strDataSize;
		strDataSize.Format(_T("%ld"), dwDataSize);
		ar << strDataSize;

		while (dwTotalRead < dwDataSize)
		{
			int nRead = FileUnit.Read(szBuf, min(dwDataSize-dwTotalRead, sizeof(szBuf)));
			ar.Write(szBuf, nRead);

			dwTotalRead += nRead;
		}
	}

	return TRUE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  ������ Recipe File  Merge
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::GenerateRecipeFile(CRecipeFileList* pData)
{
	char szFName[_MAX_FNAME]={0}, szExt[_MAX_EXT]={0};
	CString strFName = "";
	CString strExt = "";
	_splitpath_s(pData->szMainProjectPath, NULL, 0, NULL, 0, szFName, sizeof(szFName), szExt, sizeof(szExt));

	CString strDefaultName = _T("");
	strDefaultName.Format(_T("%s%s"), szFName, szExt);

	CFileDialog dlg(FALSE, _T("prj"), strDefaultName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Project File (*.prj) |*.prj||"));
	dlg.m_ofn.lpstrTitle = _T("Gernerate Recipe file one from all.");

	if (dlg.DoModal() != IDOK)
		return FALSE;

	CString strFilePath = dlg.GetPathName();

	CFile File;
	if (File.Open(strFilePath, CFile::modeCreate | CFile::modeWrite) == FALSE)
	{
		AfxMessageBox(_T("File Create fail."));
		return FALSE;
	}

	// File Merge
	if (MergeRecipeFiles(File, pData) == FALSE)
	{
		AfxMessageBox(_T("File merge Fail."));
		File.Close();
		DeleteFile(strFilePath);
		return FALSE;
	}
	
	File.Close();

	return TRUE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Strip Editor & MarkBox File Load
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::ProjectLoad(CString strRecipePath, HZIP hz, CString strFileName)
{
	// Stripe Editor , MarkBox Project
	CString stripEditorPath = "", MarkPrjPath[COUNTOF_STAGE] = {"", };
	register CIniFile*File;
	File = new CIniFile(strRecipePath);

	CString strSection = "", strParam = "";
	strSection = _T("DeviceInfo");

	strParam = _T("StripEditorFileName");
	stripEditorPath = File->ReadString(strSection, strParam, _T(""));
	m_stripEdtName = ExtractFileName(stripEditorPath);
	/*//20171219
	for(int nIndex=0; nIndex<COUNTOF_STAGE; nIndex++)
	{
		CString strSection, strParam;
		strSection.Format("IndexPos(%d)", nIndex+1);

		strParam = _T("MarkBoxFileName");
		MarkPrjPath[nIndex]					=	File->ReadString(strSection, strParam, _T(""));
		m_markPrjName[nIndex] = ExtractFileName(MarkPrjPath[nIndex]);

		// MarkBox Design , Parameter
		CString xmlFile(MarkPrjPath[nIndex]);
		XML	xml(xmlFile);
		XMLElement* pRootElement = xml.GetRootElement();

		XMLElement* pElement = pRootElement->FindElementZ("MarkProjInfo",true);
		int nVersion = 1;
		if (pElement) 
		{	
			nVersion			=	pElement->FindVariableZ("Version"				,true)->GetValueInt();
		};

		if (nVersion == 1)
		{
			pElement = pRootElement->FindElementZ("DsgnFiles",true);
			
				if (pElement)
				{
					for(int i=0; i<COUNTOF_MARKDSGN; i++)
					{
						CString StrDsgn;
						StrDsgn.Format("DSGN#%d",i); 

						XMLElement* pDsgnElement	=	pElement->FindElementZ(StrDsgn				,true);
						if (pDsgnElement)
						{
							char strFilename[256] = {0};
							pDsgnElement->FindVariableZ(_T("Filename"), true)->GetValue( strFilename );
							m_DsgnFileName[nIndex][i] = strFilename;
						}
					};
				};

			pElement = pRootElement->FindElementZ("ParamFiles",true);
			if (pElement)
			{
				char strFilename[256] = {0};
				pElement->FindVariableZ(_T("Filename"), true)->GetValue( strFilename );
				m_ParamFileName[nIndex] = strFilename;
			};		
		}
		else if (nVersion == 2)
		{
			// Design���� �ϳ��� ��� Design��� ������ ������ ����
			pElement = pRootElement->FindElementZ("DsgnFiles",true);
			if (pElement)
			{
				char strFilename[256] = {0};
				pElement->FindVariableZ(_T("Filename"), true)->GetValue( strFilename );
				m_DsgnFileName[nIndex][0] = strFilename;
			};

			pElement = pRootElement->FindElementZ("ParamFiles",true);
			if (pElement)
			{
				char strFilename[256] = {0};
				pElement->FindVariableZ(_T("Filename"), true)->GetValue( strFilename );
				m_ParamFileName[nIndex] = strFilename;
			};
		}
	};
	*/
	delete File;

	return TRUE;
}



/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  ������ Recipe file�� �����.
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::MakeRecipeFile(CString strPPID,CRecipeFileList* pData, CString strRecipePath)
{
	BOOL bRet = TRUE;
	
	LPCTSTR		ppid;
	LPCTSTR		recipePath;
	
	CString		strPath;
	CString		strZipPath;
	CString		strProjectPath;
	CString		strStePath;
	CString		strMarkboxPath;
	CString		strVisionJob;
	CString		strPathSecond;
	CString		strFileName;
	
	int nFind = strPPID.Find('.');
	int nCount = strPPID.GetLength();

	if(nFind >= 0)
	{
		for(int i = nFind; i < nCount; i++)
			strPPID.Delete(nFind);
	}

	if(m_bZipUse)
	{
		// ���� ����
		if(strRecipePath.IsEmpty() || strRecipePath == "")
			strZipPath.Format("%s%s%s.zip", AppPath, FilePath_XGemRecipe, strPPID);
		else 
			strZipPath = strRecipePath;

		HZIP	hz = CreateZip(strZipPath, 0);

		// 1. Project File
		strProjectPath.Format("%s%s%s.prj", AppPath, FilePath_Project, strPPID);
		strFileName.Format("%s.prj", strPPID);
		ZipAdd(hz, strFileName, strProjectPath);
		
		// 2. Strip Editor & MarkBox 
		ProjectLoad(strProjectPath, hz, strFileName);

		// 2. Strip Edit File
		strStePath.Format("%s%s%s",AppPath , FilePath_StripEditor, m_stripEdtName);
		ZipAdd(hz, m_stripEdtName , strStePath);
		
		for(int nIndex=0; nIndex < COUNTOF_STAGE; nIndex++)
		{
			// 3. MarkBox File
			strMarkboxPath.Format("%s%s%s",AppPath , FilePath_MarkBox, m_markPrjName[nIndex]);
			ZipAdd(hz, m_markPrjName[nIndex], strMarkboxPath);

			// 4. MarkBox Parameter
			strMarkboxPath.Format("%s%s%s",AppPath , FilePath_MarkBox_Param, ExtractFileName(m_ParamFileName[nIndex]));
			ZipAdd(hz, ExtractFileName(strMarkboxPath), strMarkboxPath);

			// 5. MarkBox Design
			for(int nMarkDsgn = 0; nMarkDsgn < COUNTOF_MARKDSGN; nMarkDsgn++ )
			{
				strMarkboxPath.Format("%s%s%s",AppPath , FilePath_MarkBox_Dsgn, ExtractFileName(m_DsgnFileName[nIndex][nMarkDsgn]));
				ZipAdd(hz, ExtractFileName(strMarkboxPath), strMarkboxPath);
			}
		}

		// 6. Vision Job File.
		strVisionJob.Format("%s%s%s.job", AppPath, FilePath_Vision_Job, strPPID);
		strFileName.Format("%s.Job", strPPID);
		ZipAdd(hz, strFileName, strVisionJob);

		DeleteFile(strZipPath);
		CloseZip(hz);

		// ���� Job������ �����Ѵ�.
		DeleteFile(strVisionJob);
	}
	else
	{
		// 1. File Merge.
		if(GenerateRecipeFile(pData) == FALSE)
			bRet = FALSE;
		else
			bRet = TRUE;
	}

	return bRet;
}


/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  PPID Delete
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::DeletePPID(CPPDelete* RecipeList)
{
	long nResult = ResultAccepted;
	long nReturn = 0;
	char szMsg[256];

	CFileFind fileFind;
	CString strFileName;
	CString strBackUpName;
	CString *psTemp = NULL;
	CString strMsg = "";
	CString strPath;
	bool bExistFile = true;

	psTemp = new CString[RecipeList->nCount];
	for(int i=0; i< RecipeList->nCount; i++)
	{
		strFileName = AppPath + FilePath_Project +RecipeList->strPPIDList.GetAt(i);

		if(!fileFind.FindFile(strFileName))
		{
			bExistFile = false;
			break;
		}

		psTemp[i] = RecipeList->strPPIDList.GetAt(i);
	}

	if(bExistFile)
	{
		for(int i =0; i < RecipeList->nCount; i++)
		{
			strFileName = AppPath + FilePath_Project + RecipeList->strPPIDList.GetAt(i);

			strPath.Format("%s%s\\Backup\\", AppPath, FilePath_Project);
			CreateDirectory(strPath, NULL);

			strBackUpName = psTemp[i];
			::CopyFile(strFileName, strPath + strBackUpName+_T(".bak"),FALSE);

			if(::DeleteFile((LPCTSTR)strFileName) == 0)
			{
				nResult = ResultPermissionNotGranted;
			}
			else
			{
				strMsg.Format(_T("Received Delete CMD from host   [PPID:%s]"), RecipeList->strPPIDList.GetAt(i));
				Log(strMsg);
				nResult = ResultAccepted;
			}
		}
	}
	else 
	{
		nResult = ResultPPIDNotfound;
	}
	
	
	/*  nReuslt
	 0 : Accepted
	 1 : Permission not granted
	 2 : Length error 
	 3 : Matrix overflow
	 4 : PPID not found
	 5 : Mode unsupported
	 6 : Command will be performed with completion signaled later
	 > 6   : Other error
	*/
	nReturn = m_XGem.GEMRspPPDelete(RecipeList->nMsgID, RecipeList->nCount, psTemp, nResult);
	if( nReturn == 0 ) 
		AddListBox("[S7F17 E->H] Send GEMRspPPDelete " );
	else 
		AddListBox("[S7F17 E->H] Fail to GEMRspPPDelete (%d)", nReturn );

	delete[] psTemp;
	psTemp = NULL;

	return TRUE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Local PPID ���� Request
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::HostRMSPPRequest(CString strPPID, CString strRecipePath)
{

}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  : Remote Command ��� ����
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::SetAckRcmdResult(stRemoteCmdResult* stRcmdResult)
{
	long nReturn  = 0;
	long nAck =0;
	long nHCAck = 0;
	long *pnResult = NULL;

	POSITION pos = m_stRcmdResultList.GetHeadPosition();

	pnResult = new long[stRcmdResult->nCount];
	for(int i = 0; i < stRcmdResult->nCount; i++) {
		pnResult[i] = 0;
	}
	
	while(pos)
	{
		stRemoteCmdResult* pRcmdResult; 
		pRcmdResult = m_stRcmdResultList.GetAt(pos);

		if( pRcmdResult->szRcmd == stRcmdResult->szRcmd)
		{
			pRcmdResult->bReceive = true;
			strcpy_s(pRcmdResult->szResult, stRcmdResult->szResult);

			m_stRcmdResultList.SetAt(pos, pRcmdResult);
			break;
		}
		
		m_stRcmdResultList.GetNext(pos);
	}

	// Recipe Check Fail.
	CString strTemp;
	strTemp.Format("%s",stRcmdResult->szResult);
	if(strTemp == "FAIL")
		nAck = 3;

	nReturn = m_XGem.GEMRspRemoteCommand(stRcmdResult->nMsgId, stRcmdResult->szRcmd, nAck, stRcmdResult->nCount, pnResult);
	if( nReturn == 0 ) {
		TRACE("Send GEMRspRemoteCommand\n");
	}
	else {
		TRACE1("Fail to GEMRspRemoteCommand (%d)\n", nReturn );
	} 
	
	m_evRecv.SetEvent();

	delete[] pnResult; pnResult = NULL;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  : Load Inquire Result Data Reset
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::SetLoadInquireReset()
{
	m_stPPLoadInquireResult.Init();
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  : Remote Command reset
  - 3. Date			: 2016.01.15
****************************************************************************************************/
stRemoteCmdResult CDlgSecsGem1::GetRcmdResult(CString strRcmd)
{
	POSITION pos = m_stRcmdResultList.GetHeadPosition();
	stRemoteCmdResult stRcmdResult;
	CString strRemoteCommand = "";

	while(pos)
	{
		stRemoteCmdResult* pRcmdResult; 

		pRcmdResult = m_stRcmdResultList.GetAt(pos);

		strRemoteCommand.Format("%s",  pRcmdResult->szRcmd);
		if(strRemoteCommand.MakeUpper() == strRcmd.MakeUpper() && pRcmdResult->bReceive)
		{
			memcpy(&stRcmdResult, pRcmdResult , sizeof(stRemoteCmdResult));
			m_stRcmdResultList.RemoveAt(pos);
			break;
		}

		m_stRcmdResultList.GetNext(pos);
	}
	
	return stRcmdResult;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Local PPID ���� UpLoad
	    strPPID - PPID     strRecipePath - File Path      
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::HostRMSPPSend(CRecipeFileList* pData, CString strRecipePath) //CEID �̺κ��� Recipe ������ �ϳ��� Host�� ������.
{
	LPCTSTR		ppid;
	LPCTSTR		recipePath;
	long		nResult = 0;
	CString		strPath;
	CString		strZipPath;
	CString		strProjectPath;
	CString		strStePath;
	CString		strMarkboxPath;
	CString		strPathSecond;
	CFileFind	finder;
	CString		strFileName;
	CString strRecipeID = "";

	strRecipeID.Format("%s", pData->szRecipeID);
	strPath.Format("%s.prj", strRecipeID);

	//////////////////////////////////////////////////////////////////////////
	// ��������
	ppid = strPath;

	if(!strRecipePath.IsEmpty() || strRecipePath != "")
		recipePath = strRecipePath;
	else
		recipePath = "";

	nResult = m_XGem.GEMReqPPSendEx(ppid, strRecipePath);


	AddListBox("[S7F3 E->H] PPID:%s.prj Result:%d", strRecipeID, nResult);

	// �޾Ƽ� ����� Pointer�� ���⼭ �������ش�.
	delete pData;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Equipment Mode change event.
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::HostModeChagnge(_eXGemEquipMode mode, long nID)
{
	CString strMode = "";
	CString str = "";

	if(mode == Auto_Mode)
	{	strMode = "Auto";}
	else if(mode == Manual_Mode)
	{	strMode = "Manual"; }

	m_XGem.GEMSetEvent(nID);
	
	AddListBox("[S6F11 E->H] Change the Equip Mode[%s]", strMode);
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  PPID UnFormated Process Program  (����/ ���� / ����)
						: Mode ( 1: PP Create 2: PP Edited 3: PP Deleted )
  - 3. Date			: 2016.03.03
****************************************************************************************************/
BOOL CDlgSecsGem1::HostRMSUnFormatPPChanged(stRecipeChanged* stRecipeData)
{
	CString str = "";
	LPCTSTR sPpid;
	CString strPPID = "";	
	long nLength = 0;

	strPPID.Format("%s" , stRecipeData->szPPID);
	nLength = strPPID.GetLength();

	if(m_XGem.GEMSetPPChanged(stRecipeData->PPStatus, (LPCTSTR)stRecipeData->szPPID, stRecipeData->nSize, (LPCTSTR)stRecipeData->szPPBody) < 0)
	{
		return FALSE;
	}
	
	m_strLastProjectName.Format("%s", stRecipeData->szPPID);
	AddListBox("[S6F11 E->H] PPID:%s", m_strLastProjectName);

	// �޾Ƽ� ����� Pointer�� ���⼭ �������ش�.
	delete stRecipeData;
	return TRUE;
}


/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Local PPID ����� ȣ��
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::HostRMSPPLoadInquire(CString strPPID)
{
	CString str = "";
	CString strReturnMsg = "";

	long nLength = strPPID.GetLength();
	strcpy_s(m_stPPLoadInquireResult.szPPID, strPPID);	

	if (m_XGem.GEMReqPPLoadInquire((LPCTSTR)strPPID, nLength) < 0)
		return FALSE;

	AddListBox("[S7F1 E->H] PPID:%s", strPPID);

	return FALSE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Set Event
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::SetEvent(CUMSetEvent* UMData)
{
	// ��� ���� ���� �����͸� �迭�� �߰��Ѵ�...??
	BOOL bRet = TRUE;
	long nReturn =0;
	long nCount = 0;
	long* naVid;
	CString* saValue;
	CString str = "";

	//1. Set VID 
	nCount = UMData->nVID.GetCount();

	naVid = new long[nCount];
	saValue = new CString[nCount];

	for(int i=0; i < nCount; i++)
	{
		naVid[i] = UMData->nVID.GetAt(i);
		saValue[i] = UMData->saVID.GetAt(i);
	}
	
	nReturn = m_XGem.GEMSetVariable(nCount, naVid, saValue);

	Sleep(10);
/*
	if(UMData->nCEID == CEID_INDEX_TACT_TIME)
	{
		SendIndexData_S6F11New();
	}
	else if(UMData->nCEID == CEID_LTC_READER)
	{
		SendLTCReader_S6F11New();
	}
	else
	*/
	{
		//2. Set Event
		nReturn &= m_XGem.GEMSetEvent(UMData->nCEID);
	}

	stCEIDLabel* sCEID = new stCEIDLabel;

	TRACE("Set Event : CEID %d , %s\n",UMData->nCEID , sCEID->strCEIDLabel[UMData->nCEID]);
	if(nReturn == 0) 
		AddListBox("[S6F11] Send Event[%d,%s]", UMData->nCEID, sCEID->strCEIDLabel[UMData->nCEID]);
	else 
		AddListBox("[S6F11] Send Event Fail(Return:%d)[%d,%s]", nReturn, UMData->nCEID, sCEID->strCEIDLabel[UMData->nCEID]);

	delete[] naVid;
	delete[] saValue;
	if(sCEID != NULL)
	{
		delete sCEID;
		sCEID = NULL;
	}

	// �޾Ƽ� ����� Pointer�� ���⼭ �������ش�.
	delete UMData;

	return bRet;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  SVID Setting
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::SetSVID(long nCount, long* pnVid, CString* psValue)
{
	long nReturn = 0;

	nReturn = m_XGem.GEMSetVariable(nCount, pnVid, psValue);

	return (nReturn==0);
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  ECID Setting
  - 3. Date			: 2016.01.15
****************************************************************************************************/
BOOL CDlgSecsGem1::SetECV(long nECID, CString strECV)
{
	long nReturn = 0;
	char    szMsg[256];

	nReturn = m_XGem.GEMSetECVChanged(1, &nECID, &strECV);

	if( nReturn == 0 ) 
		AddListBox("[E->H] Send GEMSetECVChanged " );
	else 
		AddListBox("[E->H] Fail to GEMSetECVChanged (%d)", nReturn );

	return nReturn == 0 ? TRUE : FALSE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Alarm Set / Reset
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::SetAlarm(stAlarm* stAlarmData)	// 0: Clear, 1: detect        long nALID, bool bState
{ 
	if(stAlarmData->nAlarmID == 801)
	{
		delete stAlarmData;
		return;
	}

	CString	strMsg = _T("");
	POSITION pos = m_listSettedAlarm.GetHeadPosition();

	if(stAlarmData->bSet)
	{
		while (pos)
		{
			stAlarm* pAlarm = m_listSettedAlarm.GetNext(pos);
			if (pAlarm->nAlarmID == stAlarmData->nAlarmID)
			{	AddListBox("The AlarmID = %d is Already Setted", (int)stAlarmData->nAlarmID);		return ;	}
		}

		stAlarm* pAlarm = new stAlarm;
		pAlarm->nAlarmID = stAlarmData->nAlarmID;
		m_listSettedAlarm.AddTail(pAlarm);		// Add new alarm on List

		AddListBox("[S5F1 E->H] The AlarmID = %d is Setted", (int)stAlarmData->nAlarmID);
		// CEID - Alarm set disable
		long nCeid[1];
		nCeid[0] = 10000;
		m_XGem.GEMSetEventEnable(1, nCeid, FALSE);

		m_XGem.GEMSetAlarm((long)stAlarmData->nAlarmID, (long)stAlarmData->bSet);		// Send Alarm Set
	}
	else
	{
		while (pos)
		{
			POSITION posCurrent = pos;

			stAlarm* pAlarm = m_listSettedAlarm.GetNext(pos);
			if (pAlarm->nAlarmID == stAlarmData->nAlarmID)
			{
				m_listSettedAlarm.RemoveAt(posCurrent);	// Delete alarm.
				delete pAlarm;

				AddListBox("[S5F1 E->H] The AlarmID = %d is deleted", (int)stAlarmData->nAlarmID);

				// CEID - Alarm clear disable
				long nCeid[1];
				nCeid[0] = 90000;
				m_XGem.GEMSetEventEnable(1, nCeid, FALSE);

				m_XGem.GEMSetAlarm((long)stAlarmData->nAlarmID, (long)stAlarmData->bSet); // Send Alarm Reset
				delete stAlarmData;
				return;
			}
		}
	}

	// �޾Ƽ� ����� Pointer�� ���⼭ �������ش�.
	delete stAlarmData;
	return;
}

BOOL CDlgSecsGem1::DivideRecipeFiles(CString strRecipeID, CFile& File, CRecipeFileList* pData)
{
	int nMarkPrjCnt = pData->strMarkProjectPathList.GetCount();
	int nMarkDesignCnt = pData->strMarkDesignPathList.GetCount();
	int nMarkParamCnt = pData->strMarkParamPathList.GetCount();

	CString strLog = _T("");
	strLog += _T("DivideRecipeFiles\r\n");
	strLog += (_T("\r\n - UIMainProject : %s"), pData->szMainProjectPath);
	strLog += (_T("\r\n - strUIStripEditor : %s"), pData->szStripEditorPath);

	for(int i =0 ; i < nMarkPrjCnt ; i++)
		strLog += (_T("\r\n - strMarkMainProject%d : %s"), i, pData->strMarkProjectPathList.GetAt(i));
	
	for(int i =0 ; i < nMarkDesignCnt ; i++)
		strLog += (_T("\r\n - strMarkDesign%d : %s"), i,  pData->strMarkDesignPathList.GetAt(i));

	for(int i =0 ; i < nMarkParamCnt ; i++)
		strLog += (_T("\r\n - strMarkParam%d : %s"), i, pData->strMarkParamPathList.GetAt(i));
	
	AddListBox(strLog);

	//Divided Files
	CString strNewUIMainProject;
	CString strNewVisionProject;

	CString strFileName;

	int nIndex = strRecipeID.Find(".");

	if (nIndex != -1)
		strFileName = strRecipeID.Left(nIndex);
	else
		strFileName = strRecipeID;

	strNewUIMainProject.Format("%s%sTemp\\%s.prj", AppPath, FilePath_XGemRecipe, strFileName);
	strNewVisionProject.Format("%s%sTemp\\%s.job", AppPath, FilePath_XGemRecipe, strFileName);


	CArchive ar(&File, CArchive::load);

	int nVersion = 0;
	ar.Read(&nVersion, 4);

	CArray<CString, CString> recipes;
	//-----------------------------------------------
	//GetRecipeArray(pData, &recipes);
	recipes.RemoveAll();
	int i=0;

	recipes.Add((LPCSTR)pData->szMainProjectPath);
	recipes.Add((LPCSTR)pData->szStripEditorPath);
	
	for(int i=0; i< nMarkPrjCnt; i++)
		recipes.Add(pData->strMarkProjectPathList.GetAt(i));

	for(int i=0; i< nMarkDesignCnt; i++)
		recipes.Add(pData->strMarkDesignPathList.GetAt(i));

	for(int i=0; i< nMarkParamCnt; i++)
		recipes.Add(pData->strMarkParamPathList.GetAt(i));
	//-------------------------
	char szBuf[40960] = {0};

	CString strDefaultPath = _T("");
	strDefaultPath.Format(_T("%s%s\\%s"), AppPath, FilePath_XGemRecipe, strFileName);

	int nCount = recipes.GetSize();
	for (int i=0; i<nCount; i++)
	{
		CString strFileName;
		ar >> strFileName;

		CreateDirectory(strDefaultPath, NULL);

		CFile FileUnit;
		if (FileUnit.Open(strDefaultPath, CFile::modeWrite | CFile::modeCreate) == FALSE)
		{
			AddListBox( _T("Error, Recipe file create fail. %s"), recipes[i] );
			return FALSE;
		}

		DWORD dwDataSize = 0;
		DWORD dwTotalRead = 0;

		CString strDataSize;
		ar >> strDataSize;

		dwDataSize = atoi(strDataSize);
		while (dwTotalRead < dwDataSize)
		{
			int nRead = ar.Read(szBuf, min(dwDataSize-dwTotalRead, sizeof(szBuf)));
			FileUnit.Write(szBuf, nRead);

			dwTotalRead += nRead;
		}
	}

	rename(pData->szMainProjectPath, strNewUIMainProject);

	return TRUE;
}


/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Remove Alarm
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::RemoveSettedAllAlarm()
{
	m_listSettedAlarm.RemoveAll();
	AddListBox(_T("Remove Setted All Alarm."));
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Set Control State
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::ControlState(long nState)
{
	long		nReturn = 0;
	char        szMsg[256];

	switch(nState)
	{
	case Control_EqOffline:
		nReturn = m_XGem.GEMReqOffline();		//S6, F11   Event Report Send       M,H <= E,reply 
		sprintf_s( szMsg, _T("[S6F11 E->H] GEMReqOffline "));
		break;
	case Control_HostOffline:
		nReturn = m_XGem.GEMReqHostOffline();		//S6, F11   Event Report Send       M,H <= E,reply 
		sprintf_s( szMsg, _T("[S6F11 E->H] GEMReqHostOffline "));
		break;
	case Control_Local:
		nReturn = m_XGem.GEMReqLocal();			//S6, F11   Event Report Send       M,H <= E,reply 
		sprintf_s( szMsg, _T("[S6F11 E->H] GEMReqLocal "));
		break;
	case Control_Remote:
		nReturn = m_XGem.GEMReqRemote();		//S6, F11   Event Report Send       M,H <= E,reply 
		sprintf_s( szMsg, _T("[S6F11 E->H] GEMReqRemote "));
		break;
	}

	if( nReturn == 0 ) 
		AddListBox(szMsg);
	else 
		AddListBox(_T("Fail to GEMReqOffline (%d)"), nReturn);
}


void CDlgSecsGem1::SendCEID_ControlState(long nState) 
{
	long		nReturn = 0;
	char        szMsg[256];
	int nCEID = 0;

	CUMSetEvent* stUMSetEventData = new CUMSetEvent;

	int nSendValue = 0;
	switch(nState)
	{
	case Control_EqOffline:
	case Control_HostOffline:
		nCEID = CEID_OFFLINE; //CEID 111
		nSendValue = 3;
		break;
	case Control_Local:
		nCEID = CEID_LOCAL;
		nSendValue = 4;
		break;
	case Control_Remote:
		nCEID = CEID_REMOTE;
		nSendValue = 5;
		break;

	default:
		delete stUMSetEventData;
		return;
	}

	//nSendValue = 5;
	CString strValueData;

	TRACE("Mode %d , Value %d \n",nState,nSendValue);
	
	// CEID Set
	stUMSetEventData->nCEID = nCEID;
	// SVID Set

	strValueData.Format("%d",nSendValue);

	stUMSetEventData->nVID.Add(SVID_CONTROL_STATE);
	stUMSetEventData->saVID.Add(strValueData);

//	ControlState(nSendValue);		// 20191212

	// 20191212 �̰� �߾ȵǳ�?
	if (gXGem1->m_pThread->PostThreadMessage(WM_SET_EVENT, (WPARAM)stUMSetEventData , 0) == 0)
		delete stUMSetEventData;
}


/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  : Process Stats Report
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::SetProcessState(long nState)
{
	m_XGemEQProcessState = (_eProcessingState)nState;


	if(m_XGemEQProcessState == Processing_None)
		return;

	CString strMsg[EndCountOfProcessSts] = {"None", "Idle", "Run", "Down", "PM"};

	if (m_xGemCommStatus == Comm_Communicating)
	{
		// ������ ���°� ���� ���� �ʵ��� Check 
		//if (m_OldEQProcessState == m_XGemEQProcessState/* || m_XGemEQProcessState == Processing_Init*/)	return;

		long nRet = 0;
		long naVIDs[2];
		CString saValue[2];

		naVIDs[0] = SVID_PROCESS_STATE;			// Process State VID
		saValue[0].Format(_T("%d"), m_XGemEQProcessState);

		naVIDs[1] = SVID_PREV_PROCESS_STATE;	// Previous Process State VID
		saValue[1].Format(_T("%d"), m_OldEQProcessState);

		m_XGem.GEMSetVariable(2, naVIDs, saValue);	// 2 : Data Count

		m_XGem.GEMSetEvent(CEID_PROCESSING_STATE_CHANGE);

		AddListBox("[S6F11 E->H] Process State Change (%s->%s)", strMsg[m_OldEQProcessState], strMsg[m_XGemEQProcessState]);

		m_OldEQProcessState = m_XGemEQProcessState;
	}

}

BOOL CDlgSecsGem1::CheckShareServerComm(int nPort)
{
	static int nTimeInterval = 0;
	
	if (!m_pServer->IsOpen() || m_nConnectSts != FS_RESULT_SUCCESS)
	{
		if (nTimeInterval > 50)
		{
			m_pServer->Close();
			// Socket Open
			CString strFileSharePath = AppPath + _T("FileShare");
			m_nConnectSts = m_pServer->Open(nPort, strFileSharePath, strFileSharePath);
			nTimeInterval = 0;
		}
		else
			nTimeInterval++;
	}
	else
	{
		nTimeInterval = 0;
		return TRUE;
	}

	/*
	if (m_nConnectSts == FS_RESULT_UNKNWON)
		m_strCommStatus = _T("NONE");
	else if (m_nConnectSts == FS_RESULT_SUCCESS && m_pServer->IsConnected()) 
		m_strCommStatus = _T("CONNECT");
	else if (m_nConnectSts == FS_RESULT_SUCCESS && !m_pServer->IsConnected())
		m_strCommStatus = _T("Listen..");
	else
		m_strCommStatus = _T("DISCONNECT");
	*/

	return FALSE;
}

BOOL CDlgSecsGem1::IsOnline()
{
	if(!gProcessINI.m_sProcessSystem.bUseSecsGem)
		return FALSE;	

	static BOOL bStabil=FALSE;
	if (GetControlStatus() == Control_Remote || GetControlStatus() == Control_Local)
	{
		if (bStabil==FALSE)
		{
			bStabil = TRUE;
		}
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

/****************************************************************************************************
  - 1. Maker		:  ngkim@eotechincs.com  
  - 2. Desciption  :  Sub Viewer ��ȯ
  - 3. Date			: 2016.01.15
****************************************************************************************************/
void CDlgSecsGem1::ScreenSwitching(int nbtn)
{
	/***********************************************************************
			-  ȭ�� ȹ�� ����
	***********************************************************************/
	//CDlgMsgView dlg;

	int iCurUserLevel = (int)((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel(); 

	switch(nbtn)
	{
		case SCREEN_SWITCHING_COMM: 
			{
				if(iCurUserLevel < 2)
				{
					//dlg.m_strMsg = "Do not have permission.\n If you want to show, please Login master account.";
					//dlg.DoModal();
					AfxMessageBox("Do not have permission.\n If you want to show, please Login master account.");
					return;
				}
			}
			break;
		default:
			break;
	}

	/***********************************************************************
			-  ȭ�� ����.
	***********************************************************************/
	// ����� Hide.
	m_pDlgSecsGemComm1.ShowWindow(SW_HIDE);
	m_pDlgSecsGemConfig1.ShowWindow(SW_HIDE);
	m_pDlgSecsGemTest1.ShowWindow(SW_HIDE);

	m_btnComm.SetSelection(0);
	m_btnConfig.SetSelection(0);
	m_btnTest.SetSelection(0);

	switch(nbtn)
	{
	case SCREEN_SWITCHING_COMM:
		{
			m_pDlgSecsGemComm1.ShowWindow(SW_SHOW);
			m_btnComm.SetSelection(1);
		}
		break;
	case SCREEN_SWITCHING_CONFIG:
		{
			m_pDlgSecsGemConfig1.ShowWindow(SW_SHOW);
			m_btnConfig.SetSelection(1);
		}
		break;
	case SCREEN_SWITCHING_TEST:
		{
			m_pDlgSecsGemTest1.ShowWindow(SW_SHOW);
			m_btnTest.SetSelection(1);
		}
		break;

	default:
		break;
	}
}

void CDlgSecsGem1::OnBnClickedBtnComm()
{
	ScreenSwitching(SCREEN_SWITCHING_COMM);
}

void CDlgSecsGem1::OnBnClickedBtnConfig()
{
	ScreenSwitching(SCREEN_SWITCHING_CONFIG);
}

void CDlgSecsGem1::OnBnClickedBtnXgemTest()
{
	ScreenSwitching(SCREEN_SWITCHING_TEST);
}

void CDlgSecsGem1::OnBnClickedBtnApply()
{
	//m_pDlgSecsGemComm1.Apply();

	OpTerminalDlg("Test", "Test");
}

void CDlgSecsGem1::OnTimer(UINT_PTR nIDEvent)
{
//	if(m_pDlgSecsGemComm1.IsWindowVisible()) 
	{	m_pDlgSecsGemComm1.Refresh(); }

	// jjseo temp
// 	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
// 	{
// 		GetDlgItem(IDC_BTN_ABNORMAL_END)->EnableWindow(FALSE);
// 	}
// 	else
// 	{
//		GetDlgItem(IDC_BTN_ABNORMAL_END)->EnableWindow(TRUE);
//	}

	CFormView::OnTimer(nIDEvent);
}
void CDlgSecsGem1::SendXGEMEvent(int nCEID,CString strData,CString strData2)
{
	if(!gProcessINI.m_sProcessSystem.bUseSecsGem)
		return;

	CString strCurrentTime;
	CString strValueData;
	CString strValueData2;
	COleDateTime date = COleDateTime::GetCurrentTime();

	strCurrentTime.Format(_T("%04d-%02d-%02d %02d/%02d/%02d"), date.GetYear(), date.GetMonth(), date.GetDay(), date.GetHour(), date.GetMinute(), date.GetSecond());
	strValueData.Format(_T("%04d%02d%02d%02d%02d%02d%02d"), date.GetYear(), date.GetMonth(), date.GetDay(), date.GetHour(), date.GetMinute(), date.GetSecond(), date.GetSecond());

	::AfxGetMainWnd()->SendMessage(UM_GET_AUTO_PARAM);

	CUMSetEvent* stUMSetEventData = new CUMSetEvent;
	// CEID Set
	stUMSetEventData->nCEID = nCEID;

	switch (nCEID)
	{
	case CEID_EQ_MODE:
		strValueData.Format("%d",m_bAutoRun_Gem + 1);
		stUMSetEventData->nVID.Add(SVID_EQ_MODE);
		stUMSetEventData->saVID.Add(strValueData);
		break;

	case CEID_LOT_READY:
	case CEID_LOT_START:
	case CEID_LOT_END:
	case CEID_LOT_CANCEL:
	case CEID_LOT_ABORT:
	case CEID_PAUSE:
	case CEID_RESUME:
	case CEID_LOT_ABNORMAL_END:
		strValueData.Format("%s",m_strLotID_Gem);
		stUMSetEventData->nVID.Add(SVID_LOTID);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%s",m_strLotType_Gem);
		stUMSetEventData->nVID.Add(SVID_LOT_TYPE);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%d",m_nInputLot_Gem);
		stUMSetEventData->nVID.Add(SVID_PLAN_QTY);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%d", m_nCurrentLotCount_Gem);
		stUMSetEventData->nVID.Add(SVID_COMPLETE_QTY);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%s",m_strPPID_Gem);
		stUMSetEventData->nVID.Add(SVID_RECIPEID);
		stUMSetEventData->saVID.Add(strValueData);
		break;

	case CEID_PANEL_IN:
	case CEID_PANEL_OUT:
	case CEID_PANEL_IN2:
	case CEID_PANEL_OUT2:

		strValueData.Format("%s",m_strLotID_Gem);
		stUMSetEventData->nVID.Add(SVID_LOTID);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%s",m_strLotType_Gem);
		stUMSetEventData->nVID.Add(SVID_LOT_TYPE);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%s",m_strPPID_Gem);
		stUMSetEventData->nVID.Add(SVID_RECIPEID);
		stUMSetEventData->saVID.Add(strValueData);

		// 20191212
		strValueData = _T("1");
		stUMSetEventData->nVID.Add(SVID_LOCATION);
		stUMSetEventData->saVID.Add(strValueData);

		if(nCEID == CEID_PANEL_IN)
		{
			strValueData= strData;
			stUMSetEventData->nVID.Add(SVID_PANELID_IN);
			stUMSetEventData->saVID.Add(strValueData);

			strValueData= strData2;
			stUMSetEventData->nVID.Add(SVID_PANEL_COUNT_IN);
			stUMSetEventData->saVID.Add(strValueData);
		}
		else if(nCEID == CEID_PANEL_OUT)
		{
			strValueData= strData;
			stUMSetEventData->nVID.Add(SVID_PANELID_OUT);
			stUMSetEventData->saVID.Add(strValueData);

			strValueData= strData2;
			stUMSetEventData->nVID.Add(SVID_PANEL_COUNT_OUT);
			stUMSetEventData->saVID.Add(strValueData);
		}
		if(nCEID == CEID_PANEL_IN2)
		{
			strValueData= strData;
			stUMSetEventData->nVID.Add(SVID_PANELID_IN2);
			stUMSetEventData->saVID.Add(strValueData);

			strValueData= strData2;
			stUMSetEventData->nVID.Add(SVID_PANEL_COUNT_IN2);
			stUMSetEventData->saVID.Add(strValueData);
		}
		else if(nCEID == CEID_PANEL_OUT2)
		{
			strValueData= strData;
			stUMSetEventData->nVID.Add(SVID_PANELID_OUT2);
			stUMSetEventData->saVID.Add(strValueData);

			strValueData= strData2;
			stUMSetEventData->nVID.Add(SVID_PANEL_COUNT_OUT2);
			stUMSetEventData->saVID.Add(strValueData);
		}
		break;

	case CEID_INDEX_TACT_TIME:
		strValueData.Format("%s",strData);//�������� ���ڷ� ����
		stUMSetEventData->nVID.Add(SVID_INDEX_TIME_DATA);
		stUMSetEventData->saVID.Add(strValueData);
		break;



	case CEID_RECIPE_SELECT:
		strValueData.Format("%s",m_strPPID_Gem);
		stUMSetEventData->nVID.Add(SVID_PPID_CURRENT);
		stUMSetEventData->saVID.Add(strValueData);
		break;	


	case CEID_RECIPE_VALIDATION:
		strValueData.Format("%s",m_strPPID_Gem);
		stUMSetEventData->nVID.Add(SVID_RECIPEID); //Lot Event ��
		stUMSetEventData->saVID.Add(strValueData);
		break;
	

	case CEID_LTC_READER:
		strValueData = strData;
		stUMSetEventData->nVID.Add(SVID_LTC_READING_ID);
		stUMSetEventData->saVID.Add(strValueData);
		break;


//////////NO USE//////////////////////////////////
	case CEID_NG_REPORT://No Use
		break;
	case CEID_PANEL_ID_MISMATCHING://No Use
		break;

	case CEID_BCR_READER: // No Use
		strValueData.Format("%s",m_strLotID_Gem);
		stUMSetEventData->nVID.Add(SVID_LOTID);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData.Format("%s",m_strLotType_Gem);
		stUMSetEventData->nVID.Add(SVID_LOT_TYPE);
		stUMSetEventData->saVID.Add(strValueData);

		strValueData = strData;
		stUMSetEventData->nVID.Add(SVID_BCR_READING_ID);
		stUMSetEventData->saVID.Add(strValueData);
		break;

	}

	if (m_pThread->PostThreadMessage(WM_SET_EVENT, (WPARAM)stUMSetEventData , 0) == 0)
		delete stUMSetEventData;
}


void CDlgSecsGem1::SendPPIDList()//CEID 407
{
	if(!gProcessINI.m_sProcessSystem.bUseSecsGem)
		return;

	long nReturn = 0;
	long nResult = 0;
	char szMsg[256];
	int nIndex = 1;
	int nCount = 0;
	CFileFind fileFind;
	CString strPath;

	CString strFileName = "";
	CStringArray strPPIDList;
	CString* saPpids;
	CString strFilename;
	CString strPrj;

	strPPIDList.RemoveAll();

	strPath = gEasyDrillerINI.m_clsDirPath.GetProjectDir() + "*.*";
	fileFind.FindFile((LPCTSTR)strPath);

	while(nIndex)
	{
		nIndex = fileFind.FindNextFile();
		strFilename = fileFind.GetFileName();

		strPrj.Format(_T("%s"), strFilename.Right(4));

		if( 0 == strPrj.CompareNoCase(_T(".prj")) && !fileFind.IsDirectory()) // Ȯ���� prj �̰�, Directory�� �ƴ� ���.
		{
			strPPIDList.Add(strFilename);
		}
	}

	nCount = strPPIDList.GetCount();

	CUMSetEvent* stUMSetEventData = new CUMSetEvent;
	// CEID Set
	stUMSetEventData->nCEID = CEID_RECIPE_UPLOAD;

	for(int i=0; i< nCount; i++)
	{
		// SVID Set
		stUMSetEventData->nVID.Add(SVID_PPID_CURRENT);
	}
	for(int i=0; i< nCount; i++)
	{
		// SVID Data
		stUMSetEventData->saVID.Add(strPPIDList.GetAt(i));
	}

	if (m_pThread->PostThreadMessage(WM_SET_EVENT, (WPARAM)stUMSetEventData , 0) == 0)
		delete stUMSetEventData;
}

void CDlgSecsGem1::SendXGEMTraceData()
{
	if(!gProcessINI.m_sProcessSystem.bUseSecsGem)
		return;

	//TRACE("SendXGEMTraceData\n");

	GetTraceData();



#ifdef __TEST__

	pstTraceDataNew->dGalvanoOffsetX1= 1;
	pstTraceDataNew->dGalvanoOffsetY1= 2;
	pstTraceDataNew->dGalvanoOffsetX2= 3;
	pstTraceDataNew->dGalvanoOffsetY2= 4;
	pstTraceDataNew->dGalvanoOffsetLimitX= 5;
	pstTraceDataNew->dGalvanoOffsetLimitY= 6;
	pstTraceDataNew->dLaserPower1= 7;
	pstTraceDataNew->dLaserPower2= 8;
	pstTraceDataNew->dLaserPowerMinLimit1= 9;
	pstTraceDataNew->dLaserPowerMaxLimit1= 10;
	pstTraceDataNew->dLaserPowerMinLimit2= 11;
	pstTraceDataNew->dLaserPowerMaxLimit2= 12;
	pstTraceDataNew->dChillerCh1Temp= 13;
	pstTraceDataNew->dChillerCh1Flow= 14;
	pstTraceDataNew->dChillerCh1Pressure= 15;
	pstTraceDataNew->dChillerCh2Temp= 16;
	pstTraceDataNew->dChillerCh2Flow= 17;
	pstTraceDataNew->dChillerCh2Pressure= 18;
	pstTraceDataNew->dGalvanoFlow1= 19;
	pstTraceDataNew->dGalvanoFlow2= 20;
	pstTraceDataNew->dLaserHeadFlow1= 21;
	pstTraceDataNew->dLaserHeadFlow2= 22;

#endif

	CString strPrjFileName = ((CEasyDrillerDlg*)GetParent())->GetProjectName (gDProject.m_szProjectName);
	
	pstTraceDataNew->strLotID.Format("%s",m_strLotID_Gem);
	pstTraceDataNew->strRecipeName.Format("%s",strPrjFileName);
	

		CString saValue[MAX_TRACE_COUNT];
		saValue[0].Format("%s",pstTraceDataNew->strLotID);
		saValue[1].Format("%s",pstTraceDataNew->strRecipeName);
		saValue[2].Format("%.3f",pstTraceDataNew->dGalvanoOffsetX1);
		saValue[3].Format("%.3f",pstTraceDataNew->dGalvanoOffsetY1);
		saValue[4].Format("%.3f",pstTraceDataNew->dGalvanoOffsetX2);
		saValue[5].Format("%.3f",pstTraceDataNew->dGalvanoOffsetX2);
		saValue[6].Format("%.3f",pstTraceDataNew->dGalvanoOffsetLimitX);
		saValue[7].Format("%.3f",pstTraceDataNew->dGalvanoOffsetLimitY);
		saValue[8].Format("%.3f",pstTraceDataNew->dLaserPower1);
		saValue[9].Format("%.3f",pstTraceDataNew->dLaserPower2);
		saValue[10].Format("%.3f",pstTraceDataNew->dLaserPowerMinLimit1);
		saValue[11].Format("%.3f",pstTraceDataNew->dLaserPowerMaxLimit1);
		saValue[12].Format("%.3f",pstTraceDataNew->dLaserPowerMinLimit2);
		saValue[13].Format("%.3f",pstTraceDataNew->dLaserPowerMaxLimit2);
		saValue[14].Format("%.3f",pstTraceDataNew->dChillerCh1Temp);
		saValue[15].Format("%.3f",pstTraceDataNew->dChillerCh1Flow);
		saValue[16].Format("%.3f",pstTraceDataNew->dChillerCh1Pressure);
		saValue[17].Format("%.3f",pstTraceDataNew->dChillerCh2Temp);
		saValue[18].Format("%.3f",pstTraceDataNew->dChillerCh2Flow);
		saValue[19].Format("%.3f",pstTraceDataNew->dChillerCh2Pressure);
		saValue[20].Format("%.3f",pstTraceDataNew->dGalvanoFlow1);
		saValue[21].Format("%.3f",pstTraceDataNew->dGalvanoFlow2);
		saValue[22].Format("%.3f",pstTraceDataNew->dLaserHeadFlow1);
		saValue[23].Format("%.3f",pstTraceDataNew->dLaserHeadFlow2);




		BOOL bChange = FALSE;
		for(int ii = 0; ii < MAX_TRACE_COUNT; ii++)
		{
			if(m_saValueOld[ii] != saValue[ii])
				bChange = TRUE;

			m_saValueOld[ii] = saValue[ii];
		}

		if(bChange == TRUE)
		{
			long naVid1[MAX_TRACE_COUNT];
			for(int ii = 0; ii < MAX_TRACE_COUNT; ii++)
			{
				naVid1[ii] = SVID_LOT_ID2 + ii;
			}
			SetSVID(MAX_TRACE_COUNT, naVid1, saValue);
		}
}


void CDlgSecsGem1::GetTraceData()
{
	double dTemp1, dTemp2, dFlow1, dFlow2, dPressure1, dPressure2;//chiller info
	double dVal1,dVal2,dVal3,dVal4,dVal5,dVal6;
	gDeviceFactory.GetMotor()->GetChillerTemp(1,dTemp1,dFlow1,dPressure1);
	dVal1 = dTemp1;
	dVal2 = dFlow1;
	dVal3 = dPressure1;
	gDeviceFactory.GetMotor()->GetChillerTemp(2,dTemp2,dFlow2,dPressure2);
	dVal4 = dTemp2;
	dVal5 = dFlow2;
	dVal6 = dPressure2;

	double dVal7, dVal8, dVal9, dVal10;
	dVal7 = gDeviceFactory.GetMotor()->GetScannerFlow1Value();
	dVal8 = gDeviceFactory.GetMotor()->GetScannerFlow2Value();;
	dVal9 = gDeviceFactory.GetMotor()->GetLaser1FlowValue();
	dVal10 = gDeviceFactory.GetMotor()->GetLaser2FlowValue();

	pstTraceDataNew->dGalvanoOffsetX1= gOPCParam.dCalHeadOffset_M[0];
	pstTraceDataNew->dGalvanoOffsetY1= gOPCParam.dCalHeadOffset_M[1];
	pstTraceDataNew->dGalvanoOffsetX2= gOPCParam.dCalHeadOffset_S[0];
	pstTraceDataNew->dGalvanoOffsetY2= gOPCParam.dCalHeadOffset_S[1];
	pstTraceDataNew->dGalvanoOffsetLimitX= gOPCParam.dCalLimitOffset[0];
	pstTraceDataNew->dGalvanoOffsetLimitY= gOPCParam.dCalLimitOffset[1];
	pstTraceDataNew->dLaserPower1= gOPCParam.dPowerMeasure[0];
	pstTraceDataNew->dLaserPower2= gOPCParam.dPowerMeasure[1];
	pstTraceDataNew->dLaserPowerMinLimit1= gOPCParam.dPowerTargetMin[0];
	pstTraceDataNew->dLaserPowerMaxLimit1= gOPCParam.dPowerTargetMax[0];
	pstTraceDataNew->dLaserPowerMinLimit2= gOPCParam.dPowerTargetMin[1];
	pstTraceDataNew->dLaserPowerMaxLimit2= gOPCParam.dPowerTargetMax[1];
	pstTraceDataNew->dChillerCh1Temp= dVal1;
	pstTraceDataNew->dChillerCh1Flow= dVal2;
	pstTraceDataNew->dChillerCh1Pressure= dVal3;
	pstTraceDataNew->dChillerCh2Temp= dVal4;
	pstTraceDataNew->dChillerCh2Flow= dVal5;
	pstTraceDataNew->dChillerCh2Pressure= dVal6;
	pstTraceDataNew->dGalvanoFlow1= (dVal7 -187) / 187;
	pstTraceDataNew->dGalvanoFlow2= (dVal8 -187) / 187;
	pstTraceDataNew->dLaserHeadFlow1= (dVal9 -130) / 60.0;
	pstTraceDataNew->dLaserHeadFlow2= (dVal10 -130) / 60.0;
  
}

void CDlgSecsGem1::InitGetLotInfo()
{
	pst_GetLotInfo->strRecipeID_LotInfo = "";
	pst_GetLotInfo->nPnlCount_LotInfo = 0;

	pst_GetLotInfo->strLotIDValue = "";
	pst_GetLotInfo->strLotTypeValue = "";

	pst_GetLotInfo->strItemCodeValue = "";
	pst_GetLotInfo->strRevisionValue = "";
	pst_GetLotInfo->nDirectionValue = 0;

	pst_GetLotInfo->strPrj_Comp = "";
	pst_GetLotInfo->strPrj_Sold = "";

	pst_GetLotInfo->strNewPrj_Comp = "";
	pst_GetLotInfo->strNewPrj_Sold = "";

	pst_GetLotInfo->strData_Comp = "";
	pst_GetLotInfo->strData_Sold = "";
}


void CDlgSecsGem1::SendPPChange(bool bExistFile, CString strPPID)
{
	if(IsOnline())
	{
		CString strReturnMsg = "";
		stRecipeChanged* stPPChange = new stRecipeChanged;

		if (bExistFile)	
		{
			stPPChange->PPStatus = PPEdited;// ���� ����
		}
		else	
		{
			stPPChange->PPStatus = PPCreate;// ���� ����
		}

		strcpy_s(stPPChange->szPPID ,strPPID);
		if (m_pThread->PostThreadMessage(WM_PP_CHANGE, (WPARAM)stPPChange , 0) == 0)
			delete stPPChange;

		//--------- ������ Recipe ���ϵ� ����	-------------------------/
		// Recipe ������ ���� ������ ������ �ִ� Recipe ������ ������Ʈ �� ���� �����.

		CRecipeFileList* pData = new CRecipeFileList;
		strcpy_s(pData->szRecipeID ,strPPID);

		if (m_pThread->PostThreadMessage(WM_LOAD_INQUIRE, (WPARAM)pData , 0) == 0)
			delete pData;
	}
	else
	{
		AfxMessageBox(_T("Do not report to host because not online remote mode."), MB_ICONERROR);
	}
}


/****************************************************************************************************
  - 1. Function     : S7 F25 [ H -> EQ] 
  - 2. Desciption  :  Host ���� Prj �Ķ���� ��û
****************************************************************************************************/
/****************************************************************************************************
  - 1. Function     : S7 F26 [ H <- EQ] 
  - 2. Desciption  :  Prj �Ķ���� ����
****************************************************************************************************/

/*
CCode 0���� Layout�� ������
CCode 1~21���� Parameter�� ������
*/
// #define MAX_USE_TOOL 21
// #define MAX_USE_LAYOUT_PARAM 5
// #define MAX_USE_TOOL_PARAM 43
// 
// #define TOTAL_PARAM_COUNT (MAX_USE_TOOL_PARAM * (MAX_USE_TOOL-1) + MAX_USE_LAYOUT_PARAM)
//S7F25 Formatted Process Program Request
void CDlgSecsGem1::eGEMReqPPFmtExgemctrl1(long nMsgId, LPCTSTR sPpid) //20191114
{
	
	::AfxGetMainWnd()->SendMessage(UM_GET_AUTO_PARAM);

	int nCount = 0;
	long nParamCountBy1Tool[MAX_USE_TOOL];
	CString strToolName[MAX_USE_TOOL];
	CStringArray strToolNameList;

	BSTR * pbToolName = NULL;
	BSTR* pbParamValue = NULL;
	BSTR* pbParamName = NULL;


	CPPIDInfo* PPIDInfo = new CPPIDInfo;

	// ParamList
	for(int nTool = 0; nTool < MAX_USE_TOOL; nTool++)
	{
		CString strTool;
		strTool.Format("%d",nTool);
		strToolNameList.Add(strTool);

		int nMaxParam;
		if(nTool == 0)
			nMaxParam = MAX_USE_LAYOUT_PARAM;
		else
			nMaxParam = MAX_USE_TOOL_PARAM;

		for(int nParam = 0; nParam < nMaxParam; nParam++)
		{
			CString strName = "";
			CString strValue = "";

			GetParamNameAndValue(nTool, nParam, strName, strValue);

			if(strName == "")
				strName = "0";
			if(strValue == "")
				strValue = "0";

			PPIDInfo->strParamNameList.Add(strName);
			PPIDInfo->strParamValueList.Add(strValue);
		}

	}

	/// Tool Setting
	pbToolName = new BSTR[MAX_USE_TOOL];
	for(int ii=0; ii < MAX_USE_TOOL; ii++)
	{
        pbToolName[ii] = strToolNameList.GetAt(ii).AllocSysString();
	}
	
	/// Param Setting
	for(int ii=0; ii < MAX_USE_TOOL; ii++)
	{
		if(ii==0)
			nParamCountBy1Tool[ii] = MAX_USE_LAYOUT_PARAM; //Layout
		else
			nParamCountBy1Tool[ii] = MAX_USE_TOOL_PARAM; //Parameter
	}
	pbParamValue = new BSTR[TOTAL_PARAM_COUNT];
	pbParamName = new BSTR[TOTAL_PARAM_COUNT];

	for(int i=0; i < TOTAL_PARAM_COUNT; i++)
	{
		pbParamValue[i] = PPIDInfo->strParamValueList.GetAt(i).AllocSysString();
		pbParamName[i] = PPIDInfo->strParamNameList.GetAt(i).AllocSysString();
	}
	
	CString str_Handler_Version = SOFTWARE_VERSION;

	int nToolCount = MAX_USE_TOOL;

	if(m_strPrjName_Gem == "" || m_strPrjName_Gem == "Untitle.prj")
	{
		delete[] pbToolName; pbToolName = NULL;
		delete[] pbParamValue; pbParamValue = NULL;
		delete[] pbParamName; pbParamName = NULL;

		for(int ii=0; ii < MAX_USE_TOOL; ii++)
			nParamCountBy1Tool[ii] = 0;
		nToolCount = 0;
	}

	//s7 f26
 	m_XGem.GEMRspPPFmt2(nMsgId, sPpid, Machine_Name, str_Handler_Version, nToolCount, pbToolName, nParamCountBy1Tool, pbParamName, pbParamValue);

	if(pbToolName != NULL)
	{
		delete[] pbToolName; pbToolName = NULL;
		delete[] pbParamValue; pbParamValue = NULL;
		delete[] pbParamName; pbParamName = NULL;
	}


	if(gXGem1->GetControlStatus() == Control_Local)		
	{
		gXGem1->m_bReceivePPValid = TRUE; 
		// S7 F26 �� �����ų� �ƴϸ� (�ɼǻ���)
		// Online Local ��忡���� 
		// Recipe ���� �޾Ҵٰ� ġ��
		// CEID 404 [Recipe Validation Report] �� ������
//		gXGem1->SendXGEMEvent(CEID_RECIPE_VALIDATION,gXGem1->m_strInsertLotID);
	}
	
}


void CDlgSecsGem1::GetParamNameAndValue(int nTool, int nParam, CString &strName, CString &strValue)
{
	CString strLayoutName[MAX_USE_LAYOUT_PARAM] = 
	{
		"Field_Divide_Size_X", 
		"Field_Divide_Size_Y", 
		"Separation"
	};

	CString strParameterName[MAX_USE_TOOL_PARAM] = 
	{
		"BeamPathTable_No",
		"ShotTable_No",
		"Frequency",
		"Duty"
	};

	int nToolCount = 0;




	if(nTool == 0) //Layout
	{
		strName = strLayoutName[nParam];
		switch(nParam)
		{
		case 0:
			strValue.Format("%d", gDProject.m_nDivRangeXDisp);
			break;
		case 1:
			strValue.Format("%d", gDProject.m_nDivRangeYDisp);
			break;
		case 2:
			strValue.Format("%d", gDProject.m_nSeparation);
			break;

		}
	}
	else //Parameter
	{
		strName.Format("%s_T%d", strParameterName[nParam], nTool);

		if(!gDProject.m_pToolCode[nTool]->m_bUseTool || !gDProject.m_pToolCode[nTool]->m_bVisible)
		{
			strValue.Format("%s", "NO USE");
			return;
		}

		POSITION pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		if(pos == NULL)
		{
			strValue.Format("%s", "NO USE");
			return;
		}

		SUBTOOLDATA subTool;
		gDProject.GetSubTool(nTool, 0, subTool); 

		int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[subTool.nMask];
		subTool.nFrequency = gShotTableINI.m_sShotGroupTable.nShotFrequency[nShotIndex];
		subTool.dShotDuty[0] = gShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nShotIndex];

		nToolCount = gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount();	// 20191119

		switch(nParam)
		{

		case 0:
			strValue.Format("%d", subTool.nMask);
			break;
		case 1:
			strValue.Format("%d", nShotIndex);
			break;
		case 2:
			strValue.Format("%d", subTool.nFrequency);
			break;
		case 3:
			strValue.Format("%.3f", subTool.dShotDuty[0]);
			break;
		}
	}

}


/*
void CDlgSecsGem1::GetParamNameAndValue(int nTool, int nParam, long nObjId, double &dU4, float &fF4, CString &strAscii)
{
	
	int nToolCount = 0;
	
	if(nTool == 0) //Layout
	{
		switch(nParam)
		{
		case 0:
			{
				dU4 = gDProject.m_nDivRangeXDisp;
			}
			break;
		case 1:
			{
				dU4 = gDProject.m_nDivRangeYDisp;
			}
			break;
		case 2:
			{
				fF4 = gDProject.m_dOcrInterval;
			}
			break;
		case 3:
			{
				dU4 = gDProject.m_bUserSelectUseKitNum;
			}
			break;
		case 4:
			{
				dU4 = gDProject.m_nStripArrayDirection;
			}
			break;
		}

	}
	else //Parameter
	{
		if(!gDProject.m_pToolCode[nTool]->m_bUseTool || !gDProject.m_pToolCode[nTool]->m_bVisible)
		{
			dU4 = 0.0;
			fF4 = 0.0;
			strAscii = _T("0");
			return;
		}

		POSITION pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		if(pos == NULL)
		{
			dU4 = 0.0;
			fF4 = 0.0;
			strAscii = _T("0");
			return;
		}

		SUBTOOLDATA subTool, subTool2;
		gDProject.GetSubTool(nTool, 0, subTool); //Head1
		gDProject.GetSubTool(nTool, 1, subTool2); //Head2

		nToolCount = gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount();	// 20191119

		switch(nParam)
		{
		case 0:
			{
				dU4 = gDProject.m_pToolCode[nTool]->m_nToolSize;
			}
			break;
		case 1:
			{
				dU4 = gDProject.m_pToolCode[nTool]->m_nToolSize2;
			}
			break;
		case 2:
			{
				dU4 = gDProject.m_pToolCode[nTool]->m_nToolContentsIndex;
			}
			break;
		case 3:
			{
				dU4 = subTool.nToolType;
			}
			break;
		case 4:
			{
				dU4 = subTool.nBarcodeToolType;
			}
			break;
		case 5:
			{
				dU4 = subTool.nDrawStep;
			}
			break;
		case 6:
			{
				dU4 = subTool.nJumpStep;
			}
			break;
		case 7:
			{
				dU4 = subTool.nJumpDelay;
			}
			break;
		case 8:
			{
				dU4 = subTool.nLineDelay;
			}
			break;
		case 9:
			{
				dU4 = subTool.nFrequency;
			}
			break;
		case 10:
			{
				dU4 = subTool.nFPS;
			}
			break;
		case 11:
			{
				fF4 = subTool.dCurrent;
			}
			break;
		case 12:
			{
				fF4 = subTool.dZOffset;
			}
			break;
		case 13:
			{
				dU4 = subTool.nRotate;
			}
			break;
		case 14:
			{
				strAscii.Format(_T("%s"), subTool.cFontPath);
			}
			break;
		case 15:
			{
				dU4 = subTool.bFlipX;
			}
			break;
		case 16:
			{
				dU4 = subTool.bFlipY;
			}
			break;
		case 17:
			{
				dU4 = subTool.bUseAperture;
			}
			break;
		case 18:
			{
				strAscii.Format(_T("%s"), subTool.cFilePath);
			}
			break;
		case 19:
			{
				dU4 = gDProject.m_nOcrMarkingPosition;
			}
			break;
		case 20:
			{
				dU4 = subTool.nToolMatrix;
			}
			break;
		case 21:
			{
				dU4 = subTool.bUseBarcodeLineMarking;
			}
			break;
		case 22:
			{
				dU4 = subTool.nBarLineNum;
			}
			break;
		}

		switch(nParam)
		{
		case 23:
			{
				dU4 = subTool2.nToolType;
			}
			break;
		case 24:
			{
				dU4 = subTool2.nBarcodeToolType;
			}
			break;
		case 25:
			{
				dU4 = subTool2.nDrawStep;
			}
			break;
		case 26:
			{
				dU4 = subTool2.nJumpStep;
			}
			break;
		case 27:
			{
				dU4 = subTool2.nJumpDelay;
			}
			break;
		case 28:
			{
				dU4 = subTool2.nLineDelay;
			}
			break;
		case 29:
			{
				dU4 = subTool2.nFrequency;
			}
			break;
		case 30:
			{
				dU4 = subTool2.nFPS;
			}
			break;
		case 31:
			// 20191119 (���� ������ ȣȯ���� SubTool �� 1���϶��� ����ó�� Laser�� �ٸ��� ��������)
			{
				if(nToolCount == 1)
					fF4 = subTool.dCurrent2;
				else
					fF4 = subTool2.dCurrent;
			}
			break;
		case 32:
			{
				fF4 = subTool2.dZOffset;
			}
			break;
		case 33:
			{
				dU4 = subTool2.nRotate;
			}
			break;
		case 34:
			{
				strAscii.Format(_T("%s"), subTool2.cFontPath);
			}
			break;
		case 35:
			{
				dU4 = subTool2.bFlipX;
			}
			break;
		case 36:
			{
				dU4 = subTool2.bFlipY;
			}
			break;
		case 37:
			{
				dU4 = subTool2.bUseAperture;
			}
			break;
		case 38:
			{
				strAscii.Format(_T("%s"), subTool2.cFilePath);
			}
			break;
		case 39:
			{
				dU4 = gDProject.m_nOcrMarkingPosition;
			}
			break;
		case 40:
			{
				dU4 = subTool2.nToolMatrix;
			}
			break;
		case 41:
			{
				dU4 = subTool2.bUseBarcodeLineMarking;
			}
			break;
		case 42:
			{
				dU4 = subTool2.nBarLineNum;
			}
			break;
		}
	}
	
}
*/
void CDlgSecsGem1::SendIndexData_S6F11New()
{
	int nRet = 0;
	long nCount = 1;
	long nVids[1] = {0,};

	CString strClock = m_strTactEventTime;
	CString strPanelIDOut = m_strTactEventLot;
	CString strPanelCountOut = m_strTactEventQTY;
	CString strWasteTime = m_strTactEventTactTime;



	nVids[0]	= SVID_CLOCK;
	nRet = m_XGem.GEMGetVariable( 1, nVids, &strClock );
	
	nVids[0]	= SVID_PANELID_OUT;
	//nRet = m_XGem.GEMGetVariable( 1, nVids, &strPanelIDOut );

	nVids[0]	= SVID_PANEL_COUNT_OUT;
	//nRet = m_XGem.GEMGetVariable( 1, nVids, &strPanelCountOut );

	nVids[0]	= SVID_INDEX_TIME_DATA;
	//nRet = m_XGem.GEMGetVariable( 1, nVids, &strWasteTime );

	long IObjId = 0;

	m_XGem.MakeObject(&IObjId);
	m_XGem.SetList(IObjId,3);
	double dTemp1 = 8;
	m_XGem.SetU4(IObjId, &dTemp1,1);
	double dTemp2 = CEID_INDEX_TACT_TIME;
	m_XGem.SetU4(IObjId, &dTemp2,1);//CEID
	
	m_XGem.SetList(IObjId,3);
	     m_XGem.SetList(IObjId,2);
	         double dRPTID1 = 100;
	         m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 100
	         m_XGem.SetList(IObjId,1);
	            CString strData = strClock;
	            m_XGem.SetAscii( IObjId, strData, strData.GetLength() );
	
		m_XGem.SetList(IObjId,2);
			  dRPTID1 = 610;
			 m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 610
			 m_XGem.SetList(IObjId,2);
			    strData = strPanelIDOut;
			    m_XGem.SetAscii( IObjId, strData, strData.GetLength() );
				long lTemp3 = atoi(strPanelCountOut);//PanelCout_Out
				m_XGem.SetU2(IObjId, &lTemp3,1);

		m_XGem.SetList(IObjId,2);
			  dRPTID1 = 700;
				m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 700
				m_XGem.SetList(IObjId,1);
				 m_XGem.SetList(IObjId,1);
				   m_XGem.SetList(IObjId,2);
				   double dTemp4 = atoi(strWasteTime);//Index Time
				   m_XGem.SetU4(IObjId, &dTemp4,1);
				   long lTemp5 = 1;//Index No
				   m_XGem.SetU2(IObjId, &lTemp5,1);

  long lReturn = m_XGem.SendSECSMessage(IObjId,6,11,0);

  if(lReturn != 0)
  {
	  AfxMessageBox("Fail to Send S6F11");
  }
} //NoUse

void CDlgSecsGem1::SendLTCReader_S6F11New()
{
	int nRet = 0;
	long nCount = 1;
	long nVids[1] = {0,};

	CString strClock;
	CString strControlStatus;
	CString strProcessStatus;
	CString strLTCReadingID;

	nVids[0]	= SVID_CLOCK;
	nRet = m_XGem.GEMGetVariable( 1, nVids, &strClock );

	nVids[0]	= SVID_CONTROL_STATE;
	nRet = m_XGem.GEMGetVariable( 1, nVids, &strControlStatus );

	nVids[0]	= SVID_PROCESS_STATE;
	nRet = m_XGem.GEMGetVariable( 1, nVids, &strProcessStatus );

	nVids[0]	= SVID_LTC_READING_ID;
	nRet = m_XGem.GEMGetVariable( 1, nVids, &strLTCReadingID );

	long IObjId = 0;

	m_XGem.MakeObject(&IObjId);
	m_XGem.SetList(IObjId,3);
	double dTemp1 = 12;
	m_XGem.SetU4(IObjId, &dTemp1,1);
	double dTemp2 = CEID_LTC_READER;
	m_XGem.SetU4(IObjId, &dTemp2,1);//CEID

	m_XGem.SetList(IObjId,4);
	 
	    m_XGem.SetList(IObjId,2);
	     double dRPTID1 = 100;
	     m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 100
	     m_XGem.SetList(IObjId,1);
	       CString strData = strClock;
	       m_XGem.SetAscii( IObjId, strData, strData.GetLength() );

	   m_XGem.SetList(IObjId,2);
	     dRPTID1 = 200;
	     m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 200
	     m_XGem.SetList(IObjId,1);
	        short nTemp3 = atoi(strControlStatus);
	        m_XGem.SetU1(IObjId, &nTemp3,1);

	   m_XGem.SetList(IObjId,2);
	     dRPTID1 = 300;
	     m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 300
		 m_XGem.SetList(IObjId,1);
		     short nTemp4 = atoi(strProcessStatus);
		     m_XGem.SetU1(IObjId, &nTemp4,1);

		m_XGem.SetList(IObjId,2);
		  dRPTID1 = 430;
		  m_XGem.SetU4(IObjId, &dRPTID1,1);//RPTID 430
		  m_XGem.SetList(IObjId,1);
			  m_XGem.SetList(IObjId,1);
			    m_XGem.SetList(IObjId,1);
			       strData = strLTCReadingID;
			        m_XGem.SetAscii( IObjId, strData, strData.GetLength() );

	long lReturn = m_XGem.SendSECSMessage(IObjId,6,11,0);

	if(lReturn != 0)
	{
		AfxMessageBox("Fail to Send S6F11");
	}
} //No U //NoUse

void CDlgSecsGem1::OnBnClickedBtnAbnormalEnd()
{
	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		gXGem1->SendXGEMEvent(CEID_LOT_ABNORMAL_END);//CEID 303
		::AfxGetMainWnd()->SendMessage(UM_CLEAR_LOT_INFO);
	}
}

void CDlgSecsGem1::OnBnClickedBtnAbort()
{
	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		gXGem1->SendXGEMEvent(CEID_LOT_ABORT);//CEID 303
		::AfxGetMainWnd()->SendMessage(UM_CLEAR_LOT_INFO);
	}
}
