﻿// PaneProcessSetup.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetup.h"

#include "PaneProcessSetupLaserScanner.h"
#include "PaneProcessSetupProcess.h"
#include "PaneProcessSetupProcess2.h"
#include "PaneProcessSetupSysSetting.h"
#include "PaneProcessSetupFiducial.h"
#include "PaneProcessSetupOption.h"
#include "PaneProcessSetupOption2.h"
#include "PaneProcessSetupProcessLarge.h"
#include "..\model\DeasydrillerINI.h"
#include "..\model\DProcessINI.h"
#include "..\model\DSystemINI.h"
#include "..\alarmmsg.h"

#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"

#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "PaneAutoRunViewProcess.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetup

IMPLEMENT_DYNCREATE(CPaneProcessSetup, CFormView)

CPaneProcessSetup::CPaneProcessSetup()
	: CFormView(CPaneProcessSetup::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pLaserScanner			= NULL;
	m_pProcess				= NULL;
	m_pSysSetting			= NULL;
	m_pOption				= NULL;
	m_pOption2				= NULL;


}

CPaneProcessSetup::~CPaneProcessSetup()
{
}

void CPaneProcessSetup::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetup)
	DDX_Control(pDX, IDC_TAB_PROCESS_SETUP, m_tabProcessSetup);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetup, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetup)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_TAB_PROCESS_SETUP, OnClickTabProcessSetup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetup diagnostics

#ifdef _DEBUG
void CPaneProcessSetup::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetup::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetup message handlers

void CPaneProcessSetup::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneProcessSetup::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	CString strCh;
	BOOL bRet = 0;

	m_tabProcessSetup.SetFont( &m_fntTab );

		int nPanel = 0;

	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 流程位置 ");
	else
		strCh = " Process Position ";
	bRet = m_tabProcessSetup.AddPane( strCh, RUNTIME_CLASS(CPaneProcessSetupProcessLarge) );
	if( FALSE != bRet )
	{
		m_pProcess = static_cast<CPaneProcessSetupProcessLarge*>(m_tabProcessSetup.GetPane(nPanel++));
		m_pProcess->OnInitialUpdate();
		m_pProcess->SetProcessPosition( gProcessINI.m_sProcessAutoSetting );
	}
	


	// Process Option
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 闲置选项 ");
	else
	{
		//if(gProcessINI.m_sProcessSystem.bNoUsePrework)
		//	strCh = " Idle Option ";
		//else
			strCh = " Prework ";	
	}
	bRet = m_tabProcessSetup.AddPane( strCh, RUNTIME_CLASS(CPaneProcessSetupOption) );
	if( FALSE != bRet )
	{
		m_pOption = static_cast<CPaneProcessSetupOption*>(m_tabProcessSetup.GetPane(nPanel++));
		m_pOption->OnInitialUpdate();
		m_pOption->SetProcessCal( gProcessINI.m_sProcessCal );
	}

	// Process Option'2
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 流程选项 ");
	else
		strCh = " Process Option ";
	bRet = m_tabProcessSetup.AddPane( strCh, RUNTIME_CLASS(CPaneProcessSetupOption2) );
	if( FALSE != bRet )
	{
		m_pOption2 = static_cast<CPaneProcessSetupOption2*>(m_tabProcessSetup.GetPane(nPanel++));
		m_pOption2->OnInitialUpdate();
		m_pOption2->SetProcessOption( gProcessINI.m_sProcessOption );
	}

	// System Setting
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 系统 ");
	else
		strCh = " System ";
	bRet = m_tabProcessSetup.AddPane( strCh, RUNTIME_CLASS(CPaneProcessSetupSysSetting) );
	if( FALSE != bRet )
	{
		m_pSysSetting = static_cast<CPaneProcessSetupSysSetting*>(m_tabProcessSetup.GetPane(nPanel++));
		m_pSysSetting->OnInitialUpdate();
		m_pSysSetting->SetProcessSystem( gProcessINI.m_sProcessSystem );
	}

	// Fiducial
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 基准点 ");
	else
		strCh = " Fiducial ";
	bRet = m_tabProcessSetup.AddPane( strCh, RUNTIME_CLASS(CPaneProcessSetupFiducial) );
	if( FALSE != bRet )
	{
		m_pFiducial = static_cast<CPaneProcessSetupFiducial*>(m_tabProcessSetup.GetPane(nPanel++));
		m_pFiducial->OnInitialUpdate();
		m_pFiducial->SetProcessFidFind( gProcessINI.m_sProcessFidFind );
	}

	m_tabProcessSetup.ShowPane( 0 );
}

void CPaneProcessSetup::OnDestroy() 
{
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetup::OnApply()
{
//	if( NULL != m_pLaserScanner )
//	{
//		m_pLaserScanner->OnApply();
//		m_pLaserScanner->GetProcessLaserScannerData( &gProcessINI.m_sProcessLaserScanner );
//	}
	CString strMessage, strProcess, strSysSetting, strFiducial, strOption;

	if( NULL != m_pProcess )
	{
		if(!m_pProcess->OnApply())
			return;
		strProcess = m_pProcess->GetChangeValueStr();
		m_pProcess->GetProcessPosition( &gProcessINI.m_sProcessAutoSetting );

		gDeviceFactory.GetMotor()->SetAutoSetting( gProcessINI.m_sProcessAutoSetting );
		gDeviceFactory.GetMotor()->DownloadAutoSetting();
		gDeviceFactory.GetMotor()->SetLimitYPos(gProcessINI.m_sProcessAutoSetting.dUnclampLimitY);

		if(0 != strProcess.CompareNoCase(""))
		{
			strMessage.Format(_T("Process Position Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strProcess));
		}
	}



	if( NULL != m_pSysSetting )
	{
		m_pSysSetting->OnApply();
		strSysSetting = m_pSysSetting->GetChangeValueStr();

		BOOL bChange = FALSE;
		BOOL bSchedule = m_pSysSetting->GetUseSchedule();
		if(gProcessINI.m_sProcessSystem.bUseScheduling != bSchedule)
			bChange = TRUE;
		
		m_pSysSetting->GetProcessSystem( &gProcessINI.m_sProcessSystem );

		if(bChange)
		{
			time_t	timeEnd;
			time(&timeEnd);
			gOPCParam.nSwitchUpdateTime[N_SWITCH_SCHEDULE] = (int)timeEnd;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_SWITCH, N_SWITCH_SCHEDULE);
		}

		if(0 != strSysSetting.CompareNoCase(""))
		{
			strMessage.Format(_T("System Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strSysSetting));
		}
	
		

	//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pProcess->SetProcessData(gProcessINI.m_sProcessSystem);
	}

	if( NULL != m_pFiducial )
	{
		if(!m_pFiducial->OnApply())
			return;
		strFiducial = m_pFiducial->GetChangeValueStr();
		m_pFiducial->GetProcessFidFind( &gProcessINI.m_sProcessFidFind );
	//	if(!m_pFiducial->SetAcceptScore())
		//	return;

		if(0 != strFiducial.CompareNoCase(""))
		{
			strMessage.Format(_T("Fiducial Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strFiducial));
		}
	}

	if( NULL != m_pOption )
	{
		m_pOption->OnApply();
		strOption = m_pOption->GetChangeValueStr();
		int nPreheatSpeedXY = gProcessINI.m_sProcessCal.nPreheatSpeedXY;
		int nPreheatFreq = gProcessINI.m_sProcessCal.nPreheatFreq;
 		double dPreheatDuty = gProcessINI.m_sProcessCal.dPreheatDuty;

		m_pOption->GetProcessCal( &gProcessINI.m_sProcessCal );
		
		gProcessINI.m_sProcessCal.nPreheatSpeedXY = nPreheatSpeedXY;
		gProcessINI.m_sProcessCal.nPreheatFreq = nPreheatFreq;
		gProcessINI.m_sProcessCal.dPreheatDuty = dPreheatDuty;
		if(0 != strOption.CompareNoCase(""))
		{
			strMessage.Format(_T("Process Option Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strOption));
		}
	}

	if( NULL != m_pOption2 )
	{
		m_pOption2->OnApply();
		strOption = m_pOption2->GetChangeValueStr();
		

		
		m_pOption2->GetProcessOption( &gProcessINI.m_sProcessOption );

		
		if(0 != strOption.CompareNoCase(""))
		{
			strMessage.Format(_T("Process Option2 Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strOption));
		}
	}	

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
	{
		ErrMsgDlg(STDGNALM108);
	}
	else
	{
		ErrMessage(IDS_DATA_CHANGED);
	}
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pProcess->SetProcessData(gProcessINI.m_sProcessSystem);
}

void CPaneProcessSetup::OnClickTabProcessSetup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	ChangeTab();
	*pResult = 0;
}

void CPaneProcessSetup::ShowTabPane(int nPaneNo)
{
	if( nPaneNo >= 0 && nPaneNo < 5 )
	{
		m_tabProcessSetup.ShowPane( nPaneNo );
		
		m_tabProcessSetup.SetCurSel( nPaneNo );
	}
}

void CPaneProcessSetup::ChangeTab()
{
	// Laser & Scanner
	//	if( FALSE != bRet )
	//	{
	//		m_pLaserScanner->SetProcessLaserScannerData( gProcessINI.m_sProcessLaserScanner );
	//	}

	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, FALSE);
	int nTabNo = m_tabProcessSetup.GetCurSel();
/*	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		// Process Position
		if( 0 == nTabNo )
		{
			m_pOption->SetProcessOption( gProcessINI.m_sProcessOption );
		}
		else if( 2 == nTabNo )
		{
			m_pSysSetting->SetProcessSystem( gProcessINI.m_sProcessSystem );
		}
		else if( 3 == nTabNo )
		{
			m_pFiducial->SetProcessFidFind( gProcessINI.m_sProcessFidFind );
		} 
	}
	else
*/
	{
		// Process Position


		if( 0 == nTabNo )
		{
			m_pProcess->SetProcessPosition( gProcessINI.m_sProcessAutoSetting );

#ifndef __USE_COGNEX_SOCKET__
    			if(gSystemINI.m_sHardWare.bUseWideMonitor)
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, TRUE);
#endif
		}
		else if( 1 == nTabNo )
		{
			m_pOption->SetProcessCal( gProcessINI.m_sProcessCal );
		}
		else if( 2 == nTabNo )
		{
			m_pOption2->SetProcessOption( gProcessINI.m_sProcessOption );
		}
		else if( 3 == nTabNo )
		{
			m_pSysSetting->SetProcessSystem( gProcessINI.m_sProcessSystem );
		}
		else if( 4 == nTabNo )
		{
			m_pFiducial->SetProcessFidFind( gProcessINI.m_sProcessFidFind );
		} 

	}
}

void CPaneProcessSetup::SetAuthorityByLevel(int nLevel)
{
	if(m_pFiducial != NULL)
		m_pFiducial->SetAuthorityByLevel(nLevel);

	if(m_pOption != NULL)
		m_pOption->SetAuthorityByLevel(nLevel);

	if(m_pOption2 != NULL)
		m_pOption2->SetAuthorityByLevel(nLevel);
	
	if(m_pProcess != NULL)
		m_pProcess->SetAuthorityByLevel(nLevel);

	if(m_pSysSetting != NULL)
		m_pSysSetting->SetAuthorityByLevel(nLevel);
}

void CPaneProcessSetup::UpdateIniUI(int nVal)
{
	if(UI_ALL == nVal || (nVal & PROCESS_POSITION))
	{
		if(m_pProcess != NULL)	
			m_pProcess->SetProcessPosition( gProcessINI.m_sProcessAutoSetting );

	}
	if(UI_ALL == nVal || (nVal & PROCESS_PREWORK))
	{
		if(m_pOption != NULL)
			m_pOption->SetProcessCal( gProcessINI.m_sProcessCal );
	}
	if(UI_ALL == nVal || (nVal & PROCESS_OPTION))
	{
		if(m_pOption2 != NULL)
			m_pOption2->SetProcessOption( gProcessINI.m_sProcessOption );
	}
	if(UI_ALL == nVal || (nVal & PROCESS_SYSTEM))
	{

		if(m_pSysSetting != NULL)
			m_pSysSetting->SetProcessSystem( gProcessINI.m_sProcessSystem );
	}
	if(UI_ALL == nVal || (nVal & PROCESS_FIDUCIAL))
	{
		if(m_pFiducial != NULL)
			m_pFiducial->SetProcessFidFind( gProcessINI.m_sProcessFidFind );
	}
}
