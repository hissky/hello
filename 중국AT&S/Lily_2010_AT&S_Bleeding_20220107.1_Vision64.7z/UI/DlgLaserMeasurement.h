#if !defined(AFX_DLGLASERMEASUREMENT_H__03F384D3_0845_4B2B_9A5E_FEED86E995BB__INCLUDED_)
#define AFX_DLGLASERMEASUREMENT_H__03F384D3_0845_4B2B_9A5E_FEED86E995BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLaserMeasurement.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "..\resource.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserMeasurement dialog

class CDlgLaserMeasurement : public CDialog
{
// Construction
public:
	CDlgLaserMeasurement(CWnd* pParent = NULL);   // standard constructor

	BOOL m_bCimMode;
	void StartMeasurement(int nPos);
	void UpdateMeasurement(int nPos, CString strProgress = _T(""));
	void SetUseOnlyOPCWait(BOOL bUseOPC);
	void UpdateStrResult(CString strResult);
// Dialog Data
	//{{AFX_DATA(CDlgLaserMeasurement)
	enum { IDD = IDD_DLG_LASER_MEASUREMENT };
		// NOTE: the ClassWizard will add data members here

	CListBox	m_lboxResult;
	//}}AFX_DATA

	CProgressCtrl m_progMeasure;
	BOOL m_bOPC;
	void UpdateMeasureVlaue(BOOL b2nd,double dPowerValue,int nTool,int nMask);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLaserMeasurement)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgLaserMeasurement)
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnLotCancel();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLASERMEASUREMENT_H__03F384D3_0845_4B2B_9A5E_FEED86E995BB__INCLUDED_)
