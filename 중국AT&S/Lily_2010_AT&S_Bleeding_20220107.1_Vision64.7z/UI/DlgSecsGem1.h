

#pragma once

// DlgSecsGem1.h : header file
//
#include "Gem/XGem.h"
#include "DlgSecsGemComm1.h"
#include "DlgSecsGemTest1.h"
#include "DlgSecsGemConfig1.h"
#include "UI/ColorStatic.h"
#include "UI/UEasyButtonEx.h"
#include "Gem/FileShareServer.h"
#include "Gem/unzip.h"
#include "Gem/zip.h"

#include "..\device\CorrectTime.h"


#define MAX_TRACE_COUNT 24
/////////////////////////////////////////////////////////////////////////////
// CDlgSecsGem1 dialog

struct STRACEDATA 
{

	CString strLotID;
	CString strRecipeName;
	double dGalvanoOffsetX1;
	double dGalvanoOffsetY1;
	double dGalvanoOffsetX2;
	double dGalvanoOffsetY2;
	double dGalvanoOffsetLimitX;
	double dGalvanoOffsetLimitY;
	double dLaserPower1;
	double dLaserPower2;
	double dLaserPowerMinLimit1;
	double dLaserPowerMaxLimit1;
	double dLaserPowerMinLimit2;
	double dLaserPowerMaxLimit2;
	double dChillerCh1Temp;
	double dChillerCh1Flow;
	double dChillerCh1Pressure;
	double dChillerCh2Temp;
	double dChillerCh2Flow;
	double dChillerCh2Pressure;
	double dGalvanoFlow1;
	double dGalvanoFlow2;
	double dLaserHeadFlow1;
	double dLaserHeadFlow2;

	STRACEDATA()
	{
		strRecipeName= "";
		dGalvanoOffsetX1= 0;
		dGalvanoOffsetY1= 0;
		dGalvanoOffsetX2= 0;
		dGalvanoOffsetY2= 0;
		dGalvanoOffsetLimitX= 0;
		dGalvanoOffsetLimitY= 0;
		dLaserPower1= 0;
		dLaserPower2= 0;
		dLaserPowerMinLimit1= 0;
		dLaserPowerMaxLimit1= 0;
		dLaserPowerMinLimit2= 0;
		dLaserPowerMaxLimit2= 0;
		dChillerCh1Temp= 0;
		dChillerCh1Flow= 0;
		dChillerCh1Pressure= 0;
		dChillerCh2Temp= 0;
		dChillerCh2Flow= 0;
		dChillerCh2Pressure= 0;
		dGalvanoFlow1= 0;
		dGalvanoFlow2= 0;
		dLaserHeadFlow1= 0;
		dLaserHeadFlow2= 0;

	}

};
typedef STRACEDATA*	PstTRACEDATA;


struct SGETLOTINFO
{
	CString strRecipeID_LotInfo;
	int nPnlCount_LotInfo;

	CString strLotIDValue;
	CString strLotTypeValue;
	
    CString strItemCodeValue;
	CString strRevisionValue;
	int nDirectionValue;

	CString strPrj_Comp;
	CString strPrj_Sold;

	CString strNewPrj_Comp;
	CString strNewPrj_Sold;

	CString strData_Comp;
	CString strData_Sold;


	SGETLOTINFO()
	{
		 strRecipeID_LotInfo = "";
		 nPnlCount_LotInfo = 0;

		 strLotIDValue = "";
		 strLotTypeValue = "";

		 strItemCodeValue = "";
		 strRevisionValue = "";
		 nDirectionValue = 0;

		 strPrj_Comp = "";
		 strPrj_Sold = "";

		 strNewPrj_Comp = "";
		 strNewPrj_Sold = "";

		 strData_Comp = "";
		 strData_Sold = "";
	}

};
typedef SGETLOTINFO*	PstGETLOTINFO;


class CDlgSecsGem1 : public CFormView
{

DECLARE_DYNCREATE(CDlgSecsGem1)

protected:
	CDlgSecsGem1();           // protected constructor used by dynamic creation
	virtual ~CDlgSecsGem1();
public:


	enum { IDD = IDD_DLG_SECS_GEM1};



#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	
	public:


public:
	_eCommState m_xGemCommStatus;
	_eControlState	m_xGemOnlineMode;
	_eProcessingState m_XGemEQProcessState;
	BOOL m_bZipUse;

	CList<stRemoteCmdResult*, stRemoteCmdResult*> m_stRcmdResultList;
	
public:
	CWinThread*		m_pThread;
	CEvent m_evRecv;

	CRITICAL_SECTION	m_cs;
	CFileShareServer* m_pServer;
	int		m_nConnectSts;

	CWnd*	m_pParent;
	CXGem		m_XGem;
	CString		m_strProjectName;	
	CRect m_rcBrief;
	CRect m_rcExpand;

	bool m_bIsExpanded;
	CString m_strLastProjectName;
	CString m_stripEdtName;
	CString m_markPrjName[COUNTOF_STAGE];
	CString	m_DsgnFileName[COUNTOF_STAGE][COUNTOF_MARKDSGN];
	CString	m_ParamFileName[COUNTOF_STAGE];

	stPPLoadInquire m_stPPLoadInquireResult;
	stPPLoadInquire m_HostInquire;

	CList<stAlarm*, stAlarm*> m_listSettedAlarm;

	
	int m_OldEQProcessState;
	int m_nXGemStatus;				// myyang 20170928 XGem ���� ���¸� Ȯ���ϱ� ���ؼ�. 0:Close, 1:init, 2:start, 3:Stop

	//Control
	CFont				m_fntStatic1;
	CColorStatic		m_StaticTerminalMsg;
	UEasyButtonEx		m_btnComm;
	UEasyButtonEx		m_btnConfig;
	UEasyButtonEx		m_btnTest;

	CComboBox			m_ctrlCmbProcessStat;
	CListBox			m_ctrlMsgList;

	// Sub Dialog..
	CDlgSecsGemComm1		m_pDlgSecsGemComm1;
	CDlgSecsGemConfig1	m_pDlgSecsGemConfig1;
	CDlgSecsGemTest1	m_pDlgSecsGemTest1;




public:
	void InitControl();
	void InitBrush();
	void ClearMsgList();
	void SetListBoxHorizentalSize();
	void InitGem();
	void InitDlg();
	void InitFilePath();
	void AddListBox(LPCTSTR pFormat, ...);		// myyang 20170927

	// Inner Function
	//-------------------------------------------------------------------------------
	stPPLoadInquire WaitPPLoadInquire(int nTime)
	{
		DWORD dwStart = GetTickCount();
		stPPLoadInquire	stRecvLDInquire;

		while(GetTickCount()-dwStart < (DWORD)nTime)
		{
			stRecvLDInquire = GetLoadInquireResult();
			if(stRecvLDInquire.bOK)
				return stRecvLDInquire;
			Sleep(10);
		}

		return stRecvLDInquire;
	}

	_eCommState		GetCommStatus() {return m_xGemCommStatus;};
	_eControlState		GetControlStatus() {return m_xGemOnlineMode;};


	_eProcessingState  GetProcessStatus() { return m_XGemEQProcessState;}
	stPPLoadInquire GetLoadInquireResult()  {return m_stPPLoadInquireResult;}
	//-------------------------------------------------------------------------------

	void		ControlState(long nState);
	void        SendCEID_ControlState(long nState);

	void		RemoveSettedAllAlarm();
	BOOL		SetEvent(CUMSetEvent* UMData);
	BOOL		SetECV(long nECID, CString strECV);
	BOOL		SetSVID(long nCount, long* pnVid, CString* psValue);
	void		SetAlarm(stAlarm* stAlarmData);	
	BOOL		IsOnline();
	BOOL		CheckShareServerComm(int nPort);

	// User Function.
	void		SetAckRcmdResult(stRemoteCmdResult* stRcmdResult);
	void		SetLoadInquireReset();

	stRemoteCmdResult GetRcmdResult(CString strRcmd);

	BOOL		HostRMSUnFormatPPChanged(stRecipeChanged* stRecipeData);
	BOOL		HostRMSPPLoadInquire(CString strPPID);
	void		HostRMSPPSend(CRecipeFileList* pData, CString strRecipePath = "");
	void		HostRMSPPRequest(CString strPPID, CString strRecipePath);
	void		HostModeChagnge(_eXGemEquipMode mode, long nID);



	void		ScreenSwitching(int nbtn);
	void		RecipeCopy(CRecipeFileList* stData);
	void		DeleteDiretory(CString	RootDir);
	void		SetProcessState(long nState);
	BOOL		DeletePPID(CPPDelete* RecipeList);
	BOOL		MakeRecipeFile(CString strPPID, CRecipeFileList* pData, CString strRecipePath = "");
	BOOL		ProjectLoad(CString strRecipePath, HZIP hz, CString strFileName);
	BOOL		GenerateRecipeFile(CRecipeFileList* pData);
	BOOL		MergeRecipeFiles(CFile& File, CRecipeFileList* pData);
	
	BOOL		PPIDValidation(CString strPPID, BOOL bZipUse);
	BOOL		PPIDCopytoHWDir(_eRecipeType rtType, CString strPPID);
	BOOL		DivideRecipeFiles(CString strRecipeID, CFile& File, CRecipeFileList* pData);
	
	void SendXGEMEvent(int nCEID,CString strData = "",CString strData2 = "");


	BOOL m_bAutoRun_Gem;
	BOOL m_bIsFrontSideMarking_Gem;
	int m_nCurrentLotCount_Gem;
	int m_nInputLot_Gem;
	CString m_strLotID_Gem;
	int m_nPanelN0_Gem;
	CString m_strPrjName_Gem;
	CString m_strPPID_Gem;
	CString m_strLotType_Gem;

	CString m_strInsertRawData;
	CString m_strInsertLotID;


	BOOL m_bReceiveLotInfo;
	BOOL m_bReceivePPSelect;

	BOOL m_bReceiveLotReady;
	BOOL m_bReceivePPValid;
	void SendXGEMTraceData();
	void SendPPIDList();

	void GetTraceData();
	CString m_saValueOld[MAX_TRACE_COUNT];

	void SendPPChange(bool bExistFile, CString strPPID);

	PstTRACEDATA pstTraceDataOld;//20180112
	PstTRACEDATA pstTraceDataNew;


	PstGETLOTINFO pst_GetLotInfo;
	void InitGetLotInfo();

	BOOL m_bOccureOPCall;

	_eProcessingState	m_RSTSMode;
	bool		m_RSTSModeChangeEnable;

	void GetParamNameAndValue(int nTool,int nParam,CString &strName,CString &strValue);
//	void GetParamNameAndValue(int nTool,int nParam, long nObjId, double &dU4, float &fF4, CString &strAscii);
	void SendIndexData_S6F11New();
	void SendLTCReader_S6F11New();

		virtual void OnInitialUpdate();
		afx_msg void OnBtnExpandToggle();
	afx_msg void OnBnClickedBtnClose();
	afx_msg void OnBnClickedBtnComm();
	afx_msg void OnBnClickedBtnConfig();
	afx_msg void OnBnClickedBtnXgemTest();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnBnClickedBtnApply();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	
	DECLARE_EVENTSINK_MAP()

	void eGEMCommStateChangedExgemctrl1(long nState);
	void eGEMControlStateChangedExgemctrl1(long nState);
	void eGEMReqDateTimeExgemctrl1(long nMsgId, LPCTSTR sSystemTime);
	void eGEMReqGetDateTimeExgemctrl1(long nMsgId);
	void eGEMReqPPDeleteExgemctrl1(long nMsgId, long nCount, BSTR* psPpid);
	void eGEMReqPPFmtSend2Exgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sMdln, LPCTSTR sSoftRev, long nCount, BSTR* psCCoode, long* pnParamCount, BSTR* psParamNames, BSTR* psParamValues);
	void eGEMReqPPListExgemctrl1(long nMsgId);
	void eGEMReqPPLoadInquireExgemctrl1(long nMsgId, LPCTSTR sPpid, long nLength);
	void eGEMReqPPSendExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sBody);
	void eGEMReqRemoteCommandExgemctrl1(long nMsgId, LPCTSTR sRcmd, long nCount, BSTR* psNames, BSTR* psVals);
	void eGEMRspPPExgemctrl1(LPCTSTR sPpid, LPCTSTR sBody);
	void eGEMRspPPFmtExgemctrl1(LPCTSTR sPpid, LPCTSTR sMdln, LPCTSTR sSoftRev, long nCount, BSTR* psCCode, long* pnParamCount, BSTR* psParamNames);
	void eGEMRspPPLoadInquireExgemctrl1(LPCTSTR sPpid, long nResult);
	void eGEMTerminalMessageExgemctrl1(long nTid, LPCTSTR sMsg);
	void eGEMTerminalMultiMessageExgemctrl1(long nTid, long nCount, BSTR* psMsg);
	void eSECSMessageReceivedExgemctrl1(long nObjectID, long nStream, long nFunction, long nSysbyte);
	void eGEMRspAllECInfoExgemctrl1(long lCount, long* plVid, BSTR* psName, BSTR* psValue, BSTR* psDefault, BSTR* psMin, BSTR* psMax, BSTR* psUnit);
	void eXGEMStateEventExgemctrl1(long nState);
	void eGEMRspPPSendExExgemctrl1(LPCTSTR sPpid, LPCTSTR sRecipePath, long nResult);
	void eGEMRspPPExExgemctrl1(LPCTSTR sPpid, LPCTSTR sRecipePath);
	void eGEMReqPPExExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sRecipePath);
	void eGEMReqPPExgemctrl1(long nMsgId, LPCTSTR sPpid);
	void eGEMReqPPSendExExgemctrl1(long nMsgId, LPCTSTR sPpid, LPCTSTR sRecipePath);
	void eGEMReqPPFmtExgemctrl1(long nMsgId, LPCTSTR sPpid);
	afx_msg void OnBnClickedBtnAbnormalEnd();
	afx_msg void OnBnClickedBtnAbort();



public:
	//20191226 CIM TEST �� �ʿ� ���� �߰�
	CString m_strTactEventTime;
	CString m_strTactEventLot;
	CString m_strTactEventQTY;
	CString m_strTactEventTactTime;


	CCorrectTime m_pTempTime;
};



