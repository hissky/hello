LOADER// PaneProcessSetupSysSetting.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupSysSetting.h"
#include "..\model\DProcessINI.h"
#include "..\model\dsystemini.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HDeviceFactory.h"

#include "..\easydrillerdlg.h"
#include "panemanualcontrol.h"
#include "panemanualcontrolscannercalibration.h"
#include "..\DEVICE\HDeviceFactory.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupSysSetting

IMPLEMENT_DYNCREATE(CPaneProcessSetupSysSetting, CFormView)

CPaneProcessSetupSysSetting::CPaneProcessSetupSysSetting()
	: CFormView(CPaneProcessSetupSysSetting::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupSysSetting)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	memset( &m_sProcessSystem, 0, sizeof(m_sProcessSystem) );
	m_nUserLevel = 0;
}

CPaneProcessSetupSysSetting::~CPaneProcessSetupSysSetting()
{
}

void CPaneProcessSetupSysSetting::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupSysSetting)
	DDX_Control(pDX, IDC_CHECK_NO_USE_DUST_SUCTION, m_chkNoUseDustSuction);
	DDX_Control(pDX, IDC_CHECK_NO_USE_SUCTION, m_chkNoUseSuction);
	DDX_Control(pDX, IDC_CHECK_NO_USE_LOADER_UNLOADER, m_chkNoUseLoaderUnloader);
	DDX_Control(pDX, IDC_CHECK_NO_USE_FIDUCIAL_FIND, m_chkNoUseFidFind);
	DDX_Control(pDX, IDC_CHECK_LOADER_UNLOADER_DOOR_LOCK, m_chkLoaderUnloaderDoorLock);
	DDX_Control(pDX, IDC_CHECK_DRY_RUN_WITHOUT_LASER, m_chkDryRunWithoutLaser);
	//2011526
	DDX_Control(pDX, IDC_CHECK_AOM_ALARM, m_chkNoUseAOMalarm);
	DDX_Control(pDX, IDC_CHECK_NO_USE_ZCAL, m_chkNoUseZCal);
	DDX_Control(pDX, IDC_CHECK_NO_USE_LASER_CAL, m_chkNoUseLaserCal);
	DDX_Control(pDX, IDC_CHECK_NO_USE_T_CAL, m_chkNoUseTCal);

	DDX_Control(pDX, IDC_CHECK_NO_USE_PAPER, m_chkNoUsePaper);
	DDX_Control(pDX, IDC_CHECK_NO_USE_PREWORK, m_chkNoUsePrework);
	DDX_Control(pDX, IDC_CHECK_NO_USE_CHAGNE, m_chkNoUseChangeView);
	DDX_Control(pDX, IDC_CHECK_PREWORK_DATA, m_chkCheckPreworkData);
	DDX_Control(pDX, IDC_CHECK_USE_GET_HIGH_CAM_OFFSET, m_chkUseGetHighCamOffset);
	DDX_Control(pDX, IDC_CHECK_USE_PATTERN_DEVIDE, m_chkUsePatternDevide);
	DDX_Control(pDX, IDC_CHECK_USE_APPLY_SCAL_TO_EOCARD, m_chkUseApplyScalToEocard);
	DDX_Control(pDX, IDC_CHECK_USE_SHOT_SCALE, m_chkUseShotScale);
    DDX_Control(pDX, IDC_CHECK_USE_AUTO_MONITOING, m_chkUseAutoMonitoring);
    DDX_Control(pDX, IDC_CHECK_USE_SHEET_SUCTION, m_chkUseSheetSuction);

	DDX_Control(pDX, IDC_CHECK_USE_EVERY_PANEL_THICKNESS, m_chkUseEveryPanelThickness);
	DDX_Control(pDX, IDC_CHECK_USE_4WAY_SCAL_MAIN, m_chkUse4WayScalMain);
	DDX_Control(pDX, IDC_CHECK_USE_1POINT_VISION_COMPEN, m_chkUse1PointVisionCompen);
	DDX_Control(pDX, IDC_CHECK_USE_AUTO_PREHEAT, m_chkUseAutoPreheat);
	DDX_Control(pDX, IDC_CHECK_SPARE1, m_chkUseSpare1);


	DDX_Control(pDX, IDC_CHECK_USE_EVERY_PANEL_HEADOFFSET, m_chkUseEveryPanelHeadOffset);
	DDX_Control(pDX, IDC_CHECK_NO_USE_NGBOX, m_chkNoUseNGBox);
	DDX_Control(pDX, IDC_CHECK_USE_SCHEDULE, m_chkUseSchedule);
	DDX_Control(pDX, IDC_CHECK_USE_BARCODE_MODE, m_chkUseAIMode);
	DDX_Control(pDX, IDC_CHECK_USE_SECS_GEM, m_chkUseSecsGem);




	DDX_Control(pDX, IDC_CHECK_USE_NEW_PARAMETER, m_chkUseNewParameter3);
	
	DDX_Control(pDX, IDC_CHECK_USE_NEW_BARCODE_CONTENTS, m_chkUseNewBarcodeContents);
	DDX_Control(pDX, IDC_CHECK_USE_ALL_TOOL_SCAL, m_chkUseAllToolScal);
	DDX_Control(pDX, IDC_CHECK_USE_ALL_TOOL_POWER, m_chkUseAllToolPower);


	DDX_Control(pDX, IDC_CHECK_USE_ORIGINAL_INSPECTION, m_chkUseOriginalInspectionMode);
	DDX_Control(pDX, IDC_CHECK_USE_1ST_PANEL_STOP, m_chkUse1stPanelStop);


	DDX_Control(pDX, IDC_CHECK_USE_1ST_PANEL_STOP, m_chkUse1stPanelStop);

	DDX_Control(pDX, IDC_CHECK_NO_USE_MELSEC, m_chkNoUseMelsecInterface);

	DDX_Control(pDX, IDC_CHECK_PASS_MODE, m_chkPassMode);

	DDX_Control(pDX, IDC_CHECK_TURN_PANEL, m_chkUseTurnPanel);
	DDX_Control(pDX, IDC_CHECK_USE_PRE_LPR_LIMIT, m_chkUsePreLPRLimit);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupSysSetting, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupSysSetting)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_DRY_RUN_WITHOUT_LASER, OnCheckDryRunWithoutLaser)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_LOADER_UNLOADER, OnCheckNoUseLoaderUnloader)
	ON_BN_CLICKED(IDC_CHECK_LOADER_UNLOADER_DOOR_LOCK, OnCheckLoaderUnloaderDoorLock)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_SUCTION, OnCheckNoUseSuction)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_FIDUCIAL_FIND, OnCheckNoUseFiducialFind)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_DUST_SUCTION, OnCheckNoUseDustSuction)
	ON_BN_CLICKED(IDC_CHECK_AOM_ALARM, OnCheckNoUseAOMAlarm)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_ROLL, OnCheckNoUseRollUpDown)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_PAPER, OnCheckNoUsePaper)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_PREWORK, OnCheckNoUsePrework)
	ON_BN_CLICKED(IDC_CHECK_PREWORK_DATA, OnCheckPreworkData)
	ON_BN_CLICKED(IDC_CHECK_USE_GET_HIGH_CAM_OFFSET, OnCheckUseGetHighCamOffset)
	ON_BN_CLICKED(IDC_CHECK_USE_EVERY_PANEL_THICKNESS, OnCheckUseEveryPanelThickness)
	ON_BN_CLICKED(IDC_CHECK_USE_EVERY_PANEL_HEADOFFSET, OnCheckUseEveryPanelHeadOffset)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_NGBOX, OnCheckNoUseNGBox)
	ON_BN_CLICKED(IDC_CHECK_USE_SCHEDULE, OnCheckUseScheduling)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_USE_BARCODE_MODE, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseBarcodeMode)
	ON_BN_CLICKED(IDC_CHECK_USE_NEW_PARAMETER, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseNewParameter)

	ON_BN_CLICKED(IDC_CHECK_USE_NEW_BARCODE_CONTENTS, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseNewBarcodeContents)

	ON_BN_CLICKED(IDC_CHECK_USE_ORIGINAL_INSPECTION, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseOriginalInspectionMode)
	ON_BN_CLICKED(IDC_CHECK_USE_1ST_PANEL_STOP, &CPaneProcessSetupSysSetting::OnBnClickedCheckUse1stPanelStop)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_MELSEC, &CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseMelsec)
	
	ON_BN_CLICKED(IDC_CHECK_PASS_MODE, &CPaneProcessSetupSysSetting::OnBnClickedCheckPassMode)
	ON_BN_CLICKED(IDC_CHECK_USE_ALL_TOOL_SCAL, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseAllToolScal)
	ON_BN_CLICKED(IDC_CHECK_USE_ALL_TOOL_POWER, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseAllToolPower)
	ON_BN_CLICKED(IDC_CHECK_TURN_PANEL, &CPaneProcessSetupSysSetting::OnBnClickedCheckTurnPanel)
	
		ON_BN_CLICKED(IDC_CHECK_NO_USE_ZCAL, &CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseZcal)
			ON_BN_CLICKED(IDC_CHECK_NO_USE_LASER_CAL, &CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseLaserCal)

	ON_BN_CLICKED(IDC_CHECK_NO_USE_T_CAL, &CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseTCal)
	ON_BN_CLICKED(IDC_CHECK_USE_4WAY_SCAL_MAIN, &CPaneProcessSetupSysSetting::OnBnClickedCheckUse4wayScalMain)
		ON_BN_CLICKED(IDC_CHECK_USE_PATTERN_DEVIDE, &CPaneProcessSetupSysSetting::OnBnClickedCheckUsePatternDevide)
	ON_BN_CLICKED(IDC_CHECK_USE_APPLY_SCAL_TO_EOCARD, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseApplyScalToEocard)
	ON_BN_CLICKED(IDC_CHECK_USE_SHOT_SCALE, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseShotScale)
		ON_BN_CLICKED(IDC_CHECK_USE_PRE_LPR_LIMIT, OnCheckUsePreLPRLimit)
			ON_BN_CLICKED(IDC_CHECK_USE_1POINT_VISION_COMPEN, &CPaneProcessSetupSysSetting::OnBnClickedCheckUse1pointVisionCompen)
	ON_BN_CLICKED(IDC_CHECK_USE_AUTO_PREHEAT, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseAutoPreheat)

	ON_BN_CLICKED(IDC_CHECK_SPARE1, &CPaneProcessSetupSysSetting::OnBnClickedCheckSpare1)
	ON_BN_CLICKED(IDC_CHECK_USE_AUTO_MONITOING, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseAutoMonitoing)
	ON_BN_CLICKED(IDC_CHECK_USE_SHEET_SUCTION, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseSheetSuction)
	ON_BN_CLICKED(IDC_CHECK_USE_SECS_GEM, &CPaneProcessSetupSysSetting::OnBnClickedCheckUseSecsGem)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupSysSetting diagnostics

#ifdef _DEBUG
void CPaneProcessSetupSysSetting::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupSysSetting::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupSysSetting message handlers

void CPaneProcessSetupSysSetting::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();

#if defined (__NANYA_NEW__)
	GetDlgItem(IDC_CHECK_NO_USE_PAPER)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_NO_USE_NGBOX)->ShowWindow(FALSE);

	GetDlgItem(IDC_CHECK_USE_GET_HIGH_CAM_OFFSET)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_USE_NEW_PARAMETER)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_NO_USE_MELSEC)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_USE_NEW_BARCODE_CONTENTS)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_USE_BARCODE_MODE)->ShowWindow(FALSE);
	
#endif
}

BOOL CPaneProcessSetupSysSetting::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupSysSetting::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_chkDryRunWithoutLaser.SetFont( &m_fntBtn );
	m_chkDryRunWithoutLaser.SetImageOrg( 10, 3 );
	m_chkDryRunWithoutLaser.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkDryRunWithoutLaser.EnableBallonToolTip();
	m_chkDryRunWithoutLaser.SetToolTipText( _T("Dry run without laser") );
	m_chkDryRunWithoutLaser.SetBtnCursor(IDC_HAND_1);

	m_chkLoaderUnloaderDoorLock.SetFont( &m_fntBtn );
	m_chkLoaderUnloaderDoorLock.SetImageOrg( 10, 3 );
	m_chkLoaderUnloaderDoorLock.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkLoaderUnloaderDoorLock.EnableBallonToolTip();
	m_chkLoaderUnloaderDoorLock.SetToolTipText( _T("Loader && Unloader && Main Door Lock") );
	m_chkLoaderUnloaderDoorLock.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseFidFind.SetFont( &m_fntBtn );
	m_chkNoUseFidFind.SetImageOrg( 10, 3 );
	m_chkNoUseFidFind.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseFidFind.EnableBallonToolTip();
	m_chkNoUseFidFind.SetToolTipText( _T("No Use Fiducial Find") );
	m_chkNoUseFidFind.SetBtnCursor(IDC_HAND_1);
	
	//2011526
	m_chkNoUseAOMalarm.SetFont( &m_fntBtn );
	m_chkNoUseAOMalarm.SetImageOrg( 10, 3 );
	m_chkNoUseAOMalarm.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseAOMalarm.EnableBallonToolTip();
	m_chkNoUseAOMalarm.SetToolTipText( _T("No Use Alarm Find") );
	m_chkNoUseAOMalarm.SetBtnCursor(IDC_HAND_1);
	if(gSystemINI.m_sHardWare.nAOMType == 0)
		m_chkNoUseAOMalarm.ShowWindow(SW_HIDE);

	m_chkNoUseLoaderUnloader.SetFont( &m_fntBtn );
	m_chkNoUseLoaderUnloader.SetImageOrg( 10, 3 );
	m_chkNoUseLoaderUnloader.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseLoaderUnloader.EnableBallonToolTip();
	m_chkNoUseLoaderUnloader.SetToolTipText( _T("No Use Loader && Unloader") );
	m_chkNoUseLoaderUnloader.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseSuction.SetFont( &m_fntBtn );
	m_chkNoUseSuction.SetImageOrg( 10, 3 );
	m_chkNoUseSuction.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseSuction.EnableBallonToolTip();
	m_chkNoUseSuction.SetToolTipText( _T("No Use Table Suction") );
	m_chkNoUseSuction.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseDustSuction.SetFont( &m_fntBtn );
	m_chkNoUseDustSuction.SetImageOrg( 10, 3 );
	m_chkNoUseDustSuction.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseDustSuction.EnableBallonToolTip();
	m_chkNoUseDustSuction.SetToolTipText( _T("No Use Dust Suction") );
	m_chkNoUseDustSuction.SetBtnCursor(IDC_HAND_1);

	if(!gSystemINI.m_sHardWare.nDustTableUse)
		m_chkNoUseDustSuction.ShowWindow(SW_HIDE);
	
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		m_chkNoUseLoaderUnloader.EnableWindow(FALSE);
	}

	m_chkNoUsePaper.SetFont( &m_fntBtn );
	m_chkNoUsePaper.SetImageOrg( 10, 3 );
	m_chkNoUsePaper.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUsePaper.EnableBallonToolTip();
	m_chkNoUsePaper.SetToolTipText( _T("No Use Paper Transfer") );
	m_chkNoUsePaper.SetBtnCursor(IDC_HAND_1);

	m_chkNoUsePrework.SetFont( &m_fntBtn );
	m_chkNoUsePrework.SetImageOrg( 10, 3 ); 
	m_chkNoUsePrework.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUsePrework.EnableBallonToolTip();
	m_chkNoUsePrework.SetToolTipText( _T("No Use Prework") );
	m_chkNoUsePrework.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseChangeView.SetFont( &m_fntBtn );
	m_chkNoUseChangeView.SetImageOrg( 10, 3 ); 
	m_chkNoUseChangeView.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseChangeView.EnableBallonToolTip();
	m_chkNoUseChangeView.SetToolTipText( _T("No Use Change AutoRun View") );
	m_chkNoUseChangeView.SetBtnCursor(IDC_HAND_1);

	m_chkCheckPreworkData.SetFont( &m_fntBtn );
	m_chkCheckPreworkData.SetImageOrg( 10, 3 ); 
	m_chkCheckPreworkData.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkCheckPreworkData.EnableBallonToolTip();
	m_chkCheckPreworkData.SetToolTipText( _T("Collect Prework Data and Don't Drill") );
	m_chkCheckPreworkData.SetBtnCursor(IDC_HAND_1);

	m_chkUseGetHighCamOffset.SetFont( &m_fntBtn );
	m_chkUseGetHighCamOffset.SetImageOrg( 10, 3 );
	m_chkUseGetHighCamOffset.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseGetHighCamOffset.EnableBallonToolTip();
	m_chkUseGetHighCamOffset.SetToolTipText( _T("Use Get High Cam Offset") );
	m_chkUseGetHighCamOffset.SetBtnCursor(IDC_HAND_1);

	m_chkUseAutoMonitoring.SetFont( &m_fntBtn );
	m_chkUseAutoMonitoring.SetImageOrg( 10, 3 );
	m_chkUseAutoMonitoring.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAutoMonitoring.EnableBallonToolTip();
	m_chkUseAutoMonitoring.SetToolTipText( _T("Use Get High Cam Offset") );
	m_chkUseAutoMonitoring.SetBtnCursor(IDC_HAND_1);
	
	m_chkUseSheetSuction.SetFont( &m_fntBtn );
	m_chkUseSheetSuction.SetImageOrg( 10, 3 );
	m_chkUseSheetSuction.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseSheetSuction.EnableBallonToolTip();
	m_chkUseSheetSuction.SetToolTipText( _T("Use Sheet Suction") );
	m_chkUseSheetSuction.SetBtnCursor(IDC_HAND_1);

	m_chkUsePatternDevide.SetFont( &m_fntBtn );
	m_chkUsePatternDevide.SetImageOrg( 10, 3 );
	m_chkUsePatternDevide.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePatternDevide.EnableBallonToolTip();
	m_chkUsePatternDevide.SetToolTipText( _T("Use Pattern Devide") );
	m_chkUsePatternDevide.SetBtnCursor(IDC_HAND_1);

	m_chkUseApplyScalToEocard.SetFont( &m_fntBtn );
	m_chkUseApplyScalToEocard.SetImageOrg( 10, 3 );
	m_chkUseApplyScalToEocard.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseApplyScalToEocard.EnableBallonToolTip();
	m_chkUseApplyScalToEocard.SetToolTipText( _T("Use S Cal To Eoard") );
	m_chkUseApplyScalToEocard.SetBtnCursor(IDC_HAND_1);

	m_chkUseShotScale.SetFont( &m_fntBtn );
	m_chkUseShotScale.SetImageOrg( 10, 3 );
	m_chkUseShotScale.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseShotScale.EnableBallonToolTip();
	m_chkUseShotScale.SetToolTipText( _T("Use Shot Scale") );
	m_chkUseShotScale.SetBtnCursor(IDC_HAND_1);

	m_chkUseEveryPanelThickness.SetFont( &m_fntBtn );
	m_chkUseEveryPanelThickness.SetImageOrg( 10, 3 );
	m_chkUseEveryPanelThickness.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseEveryPanelThickness.EnableBallonToolTip();
	m_chkUseEveryPanelThickness.SetToolTipText( _T("Use Evey Panel Thickness Measure") );
	m_chkUseEveryPanelThickness.SetBtnCursor(IDC_HAND_1);

	m_chkUse4WayScalMain.SetFont( &m_fntBtn );
	m_chkUse4WayScalMain.SetImageOrg( 10, 3 );
	m_chkUse4WayScalMain.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUse4WayScalMain.EnableBallonToolTip();
	m_chkUse4WayScalMain.SetToolTipText( _T("Use 4Way Scal") );
	m_chkUse4WayScalMain.SetBtnCursor(IDC_HAND_1);


	m_chkUse1PointVisionCompen.SetFont( &m_fntBtn );
	m_chkUse1PointVisionCompen.SetImageOrg( 10, 3 );
	m_chkUse1PointVisionCompen.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUse1PointVisionCompen.EnableBallonToolTip();
	m_chkUse1PointVisionCompen.SetToolTipText( _T("Use 1 Point Vision Compen") );
	m_chkUse1PointVisionCompen.SetBtnCursor(IDC_HAND_1);

	m_chkUseAutoPreheat.SetFont( &m_fntBtn );
	m_chkUseAutoPreheat.SetImageOrg( 10, 3 );
	m_chkUseAutoPreheat.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAutoPreheat.EnableBallonToolTip();
	m_chkUseAutoPreheat.SetToolTipText( _T("Use Auto Preheat") );
	m_chkUseAutoPreheat.SetBtnCursor(IDC_HAND_1);

	m_chkUseSpare1.SetFont( &m_fntBtn );
	m_chkUseSpare1.SetImageOrg( 10, 3 );
	m_chkUseSpare1.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseSpare1.EnableBallonToolTip();
	m_chkUseSpare1.SetToolTipText( _T("Use Auto Preheat") );
	m_chkUseSpare1.SetBtnCursor(IDC_HAND_1);


	m_chkUseEveryPanelHeadOffset.SetFont( &m_fntBtn );
	m_chkUseEveryPanelHeadOffset.SetImageOrg( 10, 3 );
	m_chkUseEveryPanelHeadOffset.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseEveryPanelHeadOffset.EnableBallonToolTip();
	m_chkUseEveryPanelHeadOffset.SetToolTipText( _T("Check Vision Head Offset for Every Panel") );
	m_chkUseEveryPanelHeadOffset.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseNGBox.SetFont( &m_fntBtn );
	m_chkNoUseNGBox.SetImageOrg( 10, 3 );
	m_chkNoUseNGBox.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseNGBox.EnableBallonToolTip();
	m_chkNoUseNGBox.SetToolTipText( _T("No Use NG Box") );
	m_chkNoUseNGBox.SetBtnCursor(IDC_HAND_1);

	m_chkUseSchedule.SetFont( &m_fntBtn );
	m_chkUseSchedule.SetImageOrg( 10, 3 );
	m_chkUseSchedule.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseSchedule.EnableBallonToolTip();
	m_chkUseSchedule.SetToolTipText( _T("Use Project Scheduling") );
	m_chkUseSchedule.SetBtnCursor(IDC_HAND_1);

	m_chkUseAIMode.SetFont( &m_fntBtn );
	m_chkUseAIMode.SetImageOrg( 10, 3 );
	m_chkUseAIMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAIMode.EnableBallonToolTip();
	m_chkUseAIMode.SetToolTipText( _T("Use Barcode") );
	m_chkUseAIMode.SetBtnCursor(IDC_HAND_1);

	m_chkUseSecsGem.SetFont( &m_fntBtn );
	m_chkUseSecsGem.SetImageOrg( 10, 3 );
	m_chkUseSecsGem.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseSecsGem.EnableBallonToolTip();
	m_chkUseSecsGem.SetToolTipText( _T("Use Secs Gem") );
	m_chkUseSecsGem.SetBtnCursor(IDC_HAND_1);


	m_chkUseNewParameter3.SetFont( &m_fntBtn );
	m_chkUseNewParameter3.SetImageOrg( 10, 3 );
	m_chkUseNewParameter3.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseNewParameter3.EnableBallonToolTip();
	m_chkUseNewParameter3.SetToolTipText( _T("Use New Parameter 3.0") );
	m_chkUseNewParameter3.SetBtnCursor(IDC_HAND_1);

	m_chkUseNewBarcodeContents.SetFont( &m_fntBtn );
	m_chkUseNewBarcodeContents.SetImageOrg( 10, 3 );
	m_chkUseNewBarcodeContents.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseNewBarcodeContents.EnableBallonToolTip();
	m_chkUseNewBarcodeContents.SetToolTipText( _T("Use New Barcode Contents") );
	m_chkUseNewBarcodeContents.SetBtnCursor(IDC_HAND_1);
	

	m_chkUseAllToolScal.SetFont( &m_fntBtn );
	m_chkUseAllToolScal.SetImageOrg( 10, 3 );
	m_chkUseAllToolScal.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAllToolScal.EnableBallonToolTip();
	m_chkUseAllToolScal.SetToolTipText( _T("Use All Tool Scal") );
	m_chkUseAllToolScal.SetBtnCursor(IDC_HAND_1);

	m_chkUseAllToolPower.SetFont( &m_fntBtn );
	m_chkUseAllToolPower.SetImageOrg( 10, 3 );
	m_chkUseAllToolPower.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAllToolPower.EnableBallonToolTip();
	m_chkUseAllToolPower.SetToolTipText( _T("Use All Tool Power") );
	m_chkUseAllToolPower.SetBtnCursor(IDC_HAND_1);


	m_chkUseOriginalInspectionMode.SetFont( &m_fntBtn );
	m_chkUseOriginalInspectionMode.SetImageOrg( 10, 3 );
	m_chkUseOriginalInspectionMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseOriginalInspectionMode.EnableBallonToolTip();
	m_chkUseOriginalInspectionMode.SetToolTipText( _T("Use Use Original Inspection Mode") );
	m_chkUseOriginalInspectionMode.SetBtnCursor(IDC_HAND_1);

	m_chkUse1stPanelStop.SetFont( &m_fntBtn );
	m_chkUse1stPanelStop.SetImageOrg( 10, 3 );
	m_chkUse1stPanelStop.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUse1stPanelStop.EnableBallonToolTip();
	m_chkUse1stPanelStop.SetToolTipText( _T("Use 1st Panel Stop") );
	m_chkUse1stPanelStop.SetBtnCursor(IDC_HAND_1);
	
	m_chkNoUseMelsecInterface.SetFont( &m_fntBtn );
	m_chkNoUseMelsecInterface.SetImageOrg( 10, 3 );
	m_chkNoUseMelsecInterface.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseMelsecInterface.EnableBallonToolTip();
	m_chkNoUseMelsecInterface.SetToolTipText( _T("No Use Melsec (Use PLC)") );
	m_chkNoUseMelsecInterface.SetBtnCursor(IDC_HAND_1);
	
	m_chkPassMode.SetFont( &m_fntBtn );
	m_chkPassMode.SetImageOrg( 10, 3 );
	m_chkPassMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPassMode.EnableBallonToolTip();
	m_chkPassMode.SetToolTipText( _T("No Use Melsec (Use PLC)") );
	m_chkPassMode.SetBtnCursor(IDC_HAND_1);

	m_chkUseTurnPanel.SetFont( &m_fntBtn );
	m_chkUseTurnPanel.SetImageOrg( 10, 3 );
	m_chkUseTurnPanel.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTurnPanel.EnableBallonToolTip();
	m_chkUseTurnPanel.SetToolTipText( _T(" Use Turn Panel") );
	m_chkUseTurnPanel.SetBtnCursor(IDC_HAND_1);
	
	m_chkUsePreLPRLimit.SetFont( &m_fntBtn );
	m_chkUsePreLPRLimit.SetImageOrg( 10, 3 );
	m_chkUsePreLPRLimit.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePreLPRLimit.EnableBallonToolTip();
	m_chkUsePreLPRLimit.SetToolTipText( _T("Use Pre LPR Limit") );
	m_chkUsePreLPRLimit.SetBtnCursor(IDC_HAND_1);

	if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
	{
		m_chkUseEveryPanelHeadOffset.SetToolTipText( _T("Find Temperature - Position Data") );
		m_chkUseEveryPanelHeadOffset.SetWindowText( _T("Find Temperature - Position Data") );
	}


	m_chkNoUseZCal.SetFont( &m_fntBtn );
	m_chkNoUseZCal.SetImageOrg( 10, 3 );
	m_chkNoUseZCal.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseZCal.EnableBallonToolTip();
	m_chkNoUseZCal.SetToolTipText( _T("No Use Alarm Find") );
	m_chkNoUseZCal.SetBtnCursor(IDC_HAND_1);


	m_chkNoUseLaserCal.SetFont( &m_fntBtn );
	m_chkNoUseLaserCal.SetImageOrg( 10, 3 );
	m_chkNoUseLaserCal.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseLaserCal.EnableBallonToolTip();
	m_chkNoUseLaserCal.SetToolTipText( _T("No Use Alarm Find") );
	m_chkNoUseLaserCal.SetBtnCursor(IDC_HAND_1);

	m_chkNoUseTCal.SetFont( &m_fntBtn );
	m_chkNoUseTCal.SetImageOrg( 10, 3 );
	m_chkNoUseTCal.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkNoUseTCal.EnableBallonToolTip();
	m_chkNoUseTCal.SetToolTipText( _T("No Use T Cal") );
	m_chkNoUseTCal.SetBtnCursor(IDC_HAND_1);


	m_chkNoUseNGBox.ShowWindow(FALSE);
	m_chkNoUsePaper.ShowWindow(FALSE);
	m_chkUseSpare1.ShowWindow(FALSE);
	m_chkUseOriginalInspectionMode.ShowWindow(FALSE);
	m_chkUse1stPanelStop.ShowWindow(FALSE);
}

void CPaneProcessSetupSysSetting::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupSysSetting::DispProcessSystem()
{
	// Dry Run
	m_chkDryRunWithoutLaser.SetCheck( m_sProcessSystem.bDryRun );

	// No Use Loader & Unloader
	if(gSystemINI.m_sHardWare.nManualMachine)
		m_chkNoUseLoaderUnloader.SetCheck(TRUE);
	else
		m_chkNoUseLoaderUnloader.SetCheck( m_sProcessSystem.bNoUseLoaderUnloader );

	// Loader & Unloader Door Lock
	m_chkLoaderUnloaderDoorLock.SetCheck( m_sProcessSystem.bLoaderUnloaderDoorLock );

	// No Use Suction
	m_chkNoUseSuction.SetCheck( m_sProcessSystem.bNoUseSuction );
	m_chkUsePreLPRLimit.SetCheck( m_sProcessSystem.bUsePreLPRLimit );
	// No Use Fiducial Find
	m_chkNoUseFidFind.SetCheck( m_sProcessSystem.bNoUseFiducialFind );

	//2011526
	// No Use AOM alarm
	m_chkNoUseAOMalarm.SetCheck( m_sProcessSystem.bNoUseAOMAlarm );

	m_chkNoUseZCal.SetCheck( m_sProcessSystem.bNoUseZCal );
	m_chkNoUseLaserCal.SetCheck( m_sProcessSystem.bNoUseLaserCal );
	m_chkNoUseTCal.SetCheck( m_sProcessSystem.bNoUseTCal );
	// No Use Dust Suction
	m_chkNoUseDustSuction.SetCheck( m_sProcessSystem.bNoUseDustSuction );

	// No Use Paper
	m_chkNoUsePaper.SetCheck( m_sProcessSystem.bNoUsePaper );

	//No Use Prework
	m_chkNoUsePrework.SetCheck( m_sProcessSystem.bNoUsePrework );

	//No Use ChangeView
	m_chkNoUseChangeView.SetCheck( m_sProcessSystem.bNoUseChangeView );

	m_chkCheckPreworkData.SetCheck( m_sProcessSystem.bCheckPreworkData );

	m_chkUseGetHighCamOffset.SetCheck(m_sProcessSystem.bUseGetHighCamOffset );
    m_chkUseAutoMonitoring.SetCheck(m_sProcessSystem.bUseAutoMonitoring );
	m_chkUseSheetSuction.SetCheck(m_sProcessSystem.bUseSheetSuction );

	m_chkUsePatternDevide.SetCheck(m_sProcessSystem.bUsePatternDevide );
	m_chkUseApplyScalToEocard.SetCheck(m_sProcessSystem.bUseApplyScalToEocard );
	m_chkUseShotScale.SetCheck(m_sProcessSystem.bUseShotScale );


	m_chkUseEveryPanelThickness.SetCheck(m_sProcessSystem.bEveryPanelThicknessMeasurement );

	m_chkUse4WayScalMain.SetCheck(m_sProcessSystem.bUse4WayScalMain );

	m_chkUse1PointVisionCompen.SetCheck(m_sProcessSystem.bUse1PointVisionCompen );

	m_chkUseAutoPreheat.SetCheck(m_sProcessSystem.bUseAutoPreHeat );

	m_chkUseSpare1.SetCheck(m_sProcessSystem.bUseSpare1 );

	m_chkUseEveryPanelHeadOffset.SetCheck(m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck );

	m_chkNoUseNGBox.SetCheck(m_sProcessSystem.bNoUseNGBox);

	m_chkUseSchedule.SetCheck(m_sProcessSystem.bUseScheduling);

	m_chkUseAIMode.SetCheck(m_sProcessSystem.bUseAIMode);

	m_chkUseSecsGem.SetCheck(m_sProcessSystem.bUseSecsGem);

	m_chkUseNewParameter3.SetCheck(m_sProcessSystem.bUseNewParameter3);
	
	m_chkUseNewBarcodeContents.SetCheck(m_sProcessSystem.bUseNewBarcodeContents);

	m_chkUseAllToolScal.SetCheck(m_sProcessSystem.bUseAllToolScal);

	m_chkUseAllToolPower.SetCheck(m_sProcessSystem.bUseAllToolPower);

	m_chkUseOriginalInspectionMode.SetCheck(m_sProcessSystem.bUseOriginalInspectionMode);
	
	m_chkUse1stPanelStop.SetCheck(m_sProcessSystem.bUse1stPanelStop);
	
	m_chkUseTurnPanel.SetCheck(m_sProcessSystem.bUseTurnPanel);

	// No Use Melsec Interface
	m_chkNoUseMelsecInterface.SetCheck( m_sProcessSystem.bNoUseMelsecInterface );

	m_chkPassMode.SetCheck( m_sProcessSystem.bPassMode );
	
		m_chkNoUseZCal.SetCheck( m_sProcessSystem.bNoUseZCal );
	m_chkNoUseLaserCal.SetCheck( m_sProcessSystem.bNoUseLaserCal );
	m_chkNoUseTCal.SetCheck( m_sProcessSystem.bNoUseTCal );
}

void CPaneProcessSetupSysSetting::SetProcessSystem(SPROCESSSYSTEM sProcessSystem)
{
	memcpy( &m_sProcessSystem, &sProcessSystem, sizeof(m_sProcessSystem) );

	DispProcessSystem();
}

void CPaneProcessSetupSysSetting::GetProcessSystem(SPROCESSSYSTEM* pProcessSystem)
{
	memcpy( pProcessSystem, &m_sProcessSystem, sizeof( m_sProcessSystem ) );
}

void CPaneProcessSetupSysSetting::OnApply()
{
	// Dry Run
	m_sProcessSystem.bDryRun = m_chkDryRunWithoutLaser.GetCheck();
	if(m_sProcessSystem.bDryRun == TRUE)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BYPASS, TRUE);
	else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BYPASS, FALSE);

	// No Use Loader & Unloader
	if(gSystemINI.m_sHardWare.nManualMachine)
		m_sProcessSystem.bNoUseLoaderUnloader = TRUE;
	else
		m_sProcessSystem.bNoUseLoaderUnloader = m_chkNoUseLoaderUnloader.GetCheck();

	// Loader & Unloader Door Lock
	m_sProcessSystem.bLoaderUnloaderDoorLock = m_chkLoaderUnloaderDoorLock.GetCheck();

	// No Use Suction
	m_sProcessSystem.bNoUseSuction = m_chkNoUseSuction.GetCheck();

	// No Use Fiducial Find
	m_sProcessSystem.bNoUseFiducialFind = m_chkNoUseFidFind.GetCheck();

	m_sProcessSystem.bUsePreLPRLimit = m_chkUsePreLPRLimit.GetCheck();
	//2011526
	// No Use AOM Alarm
	m_sProcessSystem.bNoUseAOMAlarm = m_chkNoUseAOMalarm.GetCheck();

	m_sProcessSystem.bNoUseZCal = m_chkNoUseZCal.GetCheck();
	m_sProcessSystem.bNoUseLaserCal = m_chkNoUseLaserCal.GetCheck();
	m_sProcessSystem.bNoUseTCal = m_chkNoUseTCal.GetCheck();
	// No Use Dust Suction
	m_sProcessSystem.bNoUseDustSuction = m_chkNoUseDustSuction.GetCheck();

	if(m_sProcessSystem.bLoaderUnloaderDoorLock == TRUE)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, FALSE);
	else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, TRUE);

	// No Use Paper
	m_sProcessSystem.bNoUsePaper= m_chkNoUsePaper.GetCheck();

	m_sProcessSystem.bNoUsePrework = m_chkNoUsePrework.GetCheck();

	m_sProcessSystem.bNoUseChangeView = m_chkNoUseChangeView.GetCheck();

	m_sProcessSystem.bCheckPreworkData = m_chkCheckPreworkData.GetCheck();

	m_sProcessSystem.bUseGetHighCamOffset = m_chkUseGetHighCamOffset.GetCheck();
    m_sProcessSystem.bUseAutoMonitoring = m_chkUseAutoMonitoring.GetCheck();
	 
	m_sProcessSystem.bUseSheetSuction = m_chkUseSheetSuction.GetCheck();

	m_sProcessSystem.bUsePatternDevide = m_chkUsePatternDevide.GetCheck();

	m_sProcessSystem.bUseApplyScalToEocard = m_chkUseApplyScalToEocard.GetCheck();

	m_sProcessSystem.bUseShotScale = m_chkUseShotScale.GetCheck();

	m_sProcessSystem.bEveryPanelThicknessMeasurement = m_chkUseEveryPanelThickness.GetCheck();

	m_sProcessSystem.bUse4WayScalMain = m_chkUse4WayScalMain.GetCheck();


	m_sProcessSystem.bUse1PointVisionCompen = m_chkUse1PointVisionCompen.GetCheck();

	m_sProcessSystem.bUseAutoPreHeat = m_chkUseAutoPreheat.GetCheck();
	
	m_sProcessSystem.bUseSpare1 = m_chkUseSpare1.GetCheck();

	m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck = m_chkUseEveryPanelHeadOffset.GetCheck();

	m_sProcessSystem.bNoUseNGBox = m_chkNoUseNGBox.GetCheck();

	m_sProcessSystem.bUseScheduling = m_chkUseSchedule.GetCheck();

	m_sProcessSystem.bUseAIMode = m_chkUseAIMode.GetCheck();

	m_sProcessSystem.bUseSecsGem = m_chkUseSecsGem.GetCheck();

	m_sProcessSystem.bUseNewParameter3 = m_chkUseNewParameter3.GetCheck();

	m_sProcessSystem.bUseNewBarcodeContents = m_chkUseNewBarcodeContents.GetCheck();

	m_sProcessSystem.bUseAllToolScal = m_chkUseAllToolScal.GetCheck();

	m_sProcessSystem.bUseAllToolPower = m_chkUseAllToolPower.GetCheck();

	m_sProcessSystem.bUseOriginalInspectionMode = m_chkUseOriginalInspectionMode.GetCheck();

	m_sProcessSystem.bUse1stPanelStop = m_chkUse1stPanelStop.GetCheck();

	m_sProcessSystem.bUseTurnPanel = m_chkUseTurnPanel.GetCheck();

	// No Use Melsec Interface
	m_sProcessSystem.bNoUseMelsecInterface = m_chkNoUseMelsecInterface.GetCheck();

	m_sProcessSystem.bPassMode = m_chkPassMode.GetCheck();

#ifdef __KUNSAN_SAMSUNG_LARGE__
	gDeviceFactory.GetMotor()->SetNoUseLoadUnload(!m_sProcessSystem.bNoUseLoaderUnloader);
	gDeviceFactory.GetMotor()->SetNoUseSuction(!m_sProcessSystem.bNoUseSuction);
	gDeviceFactory.GetMotor()->SetUseNGBox(!m_sProcessSystem.bNoUseNGBox);
	gDeviceFactory.GetMotor()->SetUsePaperBox(!m_sProcessSystem.bNoUsePaper);
	gDeviceFactory.GetMotor()->SetNoUseChiller(gProcessINI.m_sProcessSystem.bNoUseChillerAlarm);
#endif
}

void CPaneProcessSetupSysSetting::OnCheckDryRunWithoutLaser() 
{
	m_sProcessSystem.bDryRun = !m_sProcessSystem.bDryRun;
	m_chkDryRunWithoutLaser.SetCheck( m_sProcessSystem.bDryRun );
}

void CPaneProcessSetupSysSetting::OnCheckNoUseLoaderUnloader() 
{
	m_sProcessSystem.bNoUseLoaderUnloader = !m_sProcessSystem.bNoUseLoaderUnloader;
	m_chkNoUseLoaderUnloader.SetCheck( m_sProcessSystem.bNoUseLoaderUnloader );
}

void CPaneProcessSetupSysSetting::OnCheckLoaderUnloaderDoorLock() 
{
	m_sProcessSystem.bLoaderUnloaderDoorLock = !m_sProcessSystem.bLoaderUnloaderDoorLock;
	m_chkLoaderUnloaderDoorLock.SetCheck( m_sProcessSystem.bLoaderUnloaderDoorLock );
}

void CPaneProcessSetupSysSetting::OnCheckNoUseSuction() 
{
	m_sProcessSystem.bNoUseSuction = !m_sProcessSystem.bNoUseSuction;
	m_chkNoUseSuction.SetCheck( m_sProcessSystem.bNoUseSuction );
}

void CPaneProcessSetupSysSetting::OnCheckNoUseFiducialFind() 
{
	m_sProcessSystem.bNoUseFiducialFind = !m_sProcessSystem.bNoUseFiducialFind;
	m_chkNoUseFidFind.SetCheck( m_sProcessSystem.bNoUseFiducialFind );
}
//2011526
void CPaneProcessSetupSysSetting::OnCheckNoUseAOMAlarm() 
{
	m_sProcessSystem.bNoUseAOMAlarm = !m_sProcessSystem.bNoUseAOMAlarm;
	m_chkNoUseAOMalarm.SetCheck( m_sProcessSystem.bNoUseAOMAlarm );
}

void CPaneProcessSetupSysSetting::OnCheckNoUseDustSuction()
{
	m_sProcessSystem.bNoUseDustSuction = !m_sProcessSystem.bNoUseDustSuction;
	m_chkNoUseDustSuction.SetCheck( m_sProcessSystem.bNoUseDustSuction );
}

void CPaneProcessSetupSysSetting::OnCheckNoUseRollUpDown() 
{
}

void CPaneProcessSetupSysSetting::OnCheckNoUsePaper() 
{
	m_sProcessSystem.bNoUsePaper = !m_sProcessSystem.bNoUsePaper;
	m_chkNoUsePaper.SetCheck( m_sProcessSystem.bNoUsePaper );
}
void CPaneProcessSetupSysSetting::OnCheckNoUseNGBox() 
{
	m_sProcessSystem.bNoUseNGBox = !m_sProcessSystem.bNoUseNGBox;
	m_chkNoUseNGBox.SetCheck( m_sProcessSystem.bNoUseNGBox );
}
void CPaneProcessSetupSysSetting::OnCheckNoUsePrework() 
{
	m_sProcessSystem.bNoUsePrework = !m_sProcessSystem.bNoUsePrework;
	m_chkNoUsePrework.SetCheck( m_sProcessSystem.bNoUsePrework );	
}

void CPaneProcessSetupSysSetting::OnCheckPreworkData() 
{
	m_sProcessSystem.bCheckPreworkData = !m_sProcessSystem.bCheckPreworkData;
	m_chkCheckPreworkData.SetCheck( m_sProcessSystem.bCheckPreworkData );
}
void CPaneProcessSetupSysSetting::OnCheckUseGetHighCamOffset() 
{
	m_sProcessSystem.bUseGetHighCamOffset = !m_sProcessSystem.bUseGetHighCamOffset;
	m_chkUseGetHighCamOffset.SetCheck( m_sProcessSystem.bUseGetHighCamOffset );
}
void CPaneProcessSetupSysSetting::OnCheckUseEveryPanelThickness()
{
	m_sProcessSystem.bEveryPanelThicknessMeasurement = !m_sProcessSystem.bEveryPanelThicknessMeasurement;
	m_chkUseEveryPanelThickness.SetCheck( m_sProcessSystem.bEveryPanelThicknessMeasurement );
}
void CPaneProcessSetupSysSetting::OnCheckUseEveryPanelHeadOffset()
{
	m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck = !m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck;
	m_chkUseEveryPanelHeadOffset.SetCheck( m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck );
}
void CPaneProcessSetupSysSetting::OnCheckUseScheduling()
{
	m_sProcessSystem.bUseScheduling = !m_sProcessSystem.bUseScheduling;
	m_chkUseSchedule.SetCheck( m_sProcessSystem.bUseScheduling );
	
}
BOOL CPaneProcessSetupSysSetting::GetUseSchedule()
{
	return m_sProcessSystem.bUseScheduling;
}
CString CPaneProcessSetupSysSetting::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	if(m_sProcessSystem.bLoaderUnloaderDoorLock != gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock)
	{
		if(m_sProcessSystem.bLoaderUnloaderDoorLock)
			strTemp.Format(_T("| Use Main Door lock "));
		else
			strTemp.Format(_T("| Don't use Main Door lock "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUseLoaderUnloader != gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(!m_sProcessSystem.bNoUseLoaderUnloader)
			strTemp.Format(_T("| Use Loader/Unloader "));
		else
			strTemp.Format(_T("| Don't use Loader/Unloader "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bDryRun != gProcessINI.m_sProcessSystem.bDryRun)
	{
		if(m_sProcessSystem.bDryRun)
			strTemp.Format(_T("| Dryrun mode "));
		else
			strTemp.Format(_T("| Fire mode "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUseSuction != gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		if(!m_sProcessSystem.bNoUseSuction)
			strTemp.Format(_T("| Use Table Suction "));
		else
			strTemp.Format(_T("| Don't use Table Suction "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUseFiducialFind != gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
	{
		if(!m_sProcessSystem.bNoUseFiducialFind)
			strTemp.Format(_T("| Use Vision "));
		else
			strTemp.Format(_T("| Don't use Vision "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUseScanner != gProcessINI.m_sProcessSystem.bNoUseScanner)
	{
		if(!m_sProcessSystem.bNoUseScanner)
			strTemp.Format(_T("| Use Scanner "));
		else
			strTemp.Format(_T("| Don't use Scanner "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bShowScannerPath != gProcessINI.m_sProcessSystem.bShowScannerPath)
	{
		if(m_sProcessSystem.bShowScannerPath)
			strTemp.Format(_T("| Show Scanner Path "));
		else
			strTemp.Format(_T("| Hide Scanner Path "));
		strMessage += strTemp;
	}

	//2011526
	if(m_sProcessSystem.bNoUseAOMAlarm != gProcessINI.m_sProcessSystem.bNoUseAOMAlarm)
	{
		if(!m_sProcessSystem.bNoUseAOMAlarm)
			strTemp.Format(_T("| Use AOM Alarm "));
		else
			strTemp.Format(_T("| Don't use AOM Alarm "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUseRollUpDown != gProcessINI.m_sProcessSystem.bNoUseRollUpDown)
	{
		if(!m_sProcessSystem.bNoUseRollUpDown)
			strTemp.Format(_T("| Use Roll Up/Down "));
		else
			strTemp.Format(_T("| Don't use Roll Up/Down "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bNoUsePaper != gProcessINI.m_sProcessSystem.bNoUsePaper)
	{
		if(!m_sProcessSystem.bNoUsePaper)
			strTemp.Format(_T("| Use Paper "));
		else
			strTemp.Format(_T("| Don't use Paper "));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bNoUsePrework != gProcessINI.m_sProcessSystem.bNoUsePrework)
	{
		if(!m_sProcessSystem.bNoUsePrework)
			strTemp.Format(_T("| Use Prework "));
		else
			strTemp.Format(_T("| Don't use Prework "));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bNoUseChangeView != gProcessINI.m_sProcessSystem.bNoUseChangeView)
	{
		if(!m_sProcessSystem.bNoUseChangeView)
			strTemp.Format(_T("| Use Change View "));
		else
			strTemp.Format(_T("| Don't use Change View "));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bCheckPreworkData != gProcessINI.m_sProcessSystem.bCheckPreworkData)
	{
		if(!m_sProcessSystem.bCheckPreworkData)
			strTemp.Format(_T("| Use Check Prework Data "));
		else
			strTemp.Format(_T("| Don't use Check Prework Data "));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bUseGetHighCamOffset != gProcessINI.m_sProcessSystem.bUseGetHighCamOffset)
	{
		if(!m_sProcessSystem.bUseGetHighCamOffset)
			strTemp.Format(_T("| Use Get High Cam Offset "));
		else
			strTemp.Format(_T("| No Use Get High Cam Offset "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bUse4WayScalMain != gProcessINI.m_sProcessSystem.bUse4WayScalMain)
	{
		if(!m_sProcessSystem.bUse4WayScalMain)
			strTemp.Format(_T("| Use 4Way Scal "));
		else
			strTemp.Format(_T("| No Use 4Way Scal "));
		strMessage += strTemp;
	}


	if(m_sProcessSystem.bEveryPanelThicknessMeasurement != gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
	{
		if(!m_sProcessSystem.bUseGetHighCamOffset)
			strTemp.Format(_T("| Use Every Panel Thickness Measurement "));
		else
			strTemp.Format(_T("| No Use Every Panel Thickness Measurement "));
		strMessage += strTemp;
	}

	if(m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck != gProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck)
	{
		if(!m_sProcessSystem.bUseGetHighCamOffset)
			strTemp.Format(_T("| Check Vision Head Offset for Every Panel "));
		else
			strTemp.Format(_T("| Don't Check Vision Head Offset for Every Panel "));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bNoUseNGBox != gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		if(!m_sProcessSystem.bNoUseNGBox)
			strTemp.Format(_T("| Use NG Box "));
		else
			strTemp.Format(_T("| No Use NG Box"));
		strMessage += strTemp;
	}
	if(m_sProcessSystem.bUseScheduling != gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(!m_sProcessSystem.bUseScheduling)
			strTemp.Format(_T("| Use Scheduling "));
		else
			strTemp.Format(_T("| No Use Scheduling"));
		strMessage += strTemp;
	}
	return strMessage;
}

void CPaneProcessSetupSysSetting::EnableControl(BOOL bUse)
{
	m_chkDryRunWithoutLaser.EnableWindow(bUse);
	m_chkLoaderUnloaderDoorLock.EnableWindow(bUse);
	m_chkNoUseFidFind.EnableWindow(bUse);
	if(gSystemINI.m_sHardWare.nManualMachine)
		m_chkNoUseLoaderUnloader.EnableWindow(FALSE);
	else
		m_chkNoUseLoaderUnloader.EnableWindow(bUse);
	m_chkNoUseSuction.EnableWindow(bUse);
	
	m_chkNoUseAOMalarm.EnableWindow(bUse);
	m_chkNoUsePrework.EnableWindow(bUse);
	m_chkCheckPreworkData.EnableWindow(bUse);
	m_chkUsePreLPRLimit.EnableWindow(bUse);
	m_chkUseEveryPanelHeadOffset.EnableWindow(bUse);
    m_chkUseAutoMonitoring.EnableWindow(bUse);
	m_chkUseSheetSuction.EnableWindow(bUse);

#if !defined __KUNSAN_SAMSUNG_LARGE__ || defined __NANYA_NEW__
	m_chkNoUseDustSuction.EnableWindow(bUse);
	m_chkNoUseChangeView.EnableWindow(bUse);
	m_chkNoUsePaper.EnableWindow(bUse);
	m_chkNoUseNGBox.EnableWindow(bUse);
	m_chkUseGetHighCamOffset.EnableWindow(bUse);
	m_chkUseEveryPanelThickness.EnableWindow(bUse);
	m_chkUseEveryPanelHeadOffset.EnableWindow(bUse);
#endif
	m_chkUseSchedule.EnableWindow(bUse);
#if defined __NANYA_NEW__

	m_chkUseOriginalInspectionMode.EnableWindow(bUse);
	m_chkUse1stPanelStop.EnableWindow(bUse);
	m_chkUseAllToolScal.EnableWindow(bUse);
	m_chkUseAllToolPower.EnableWindow(bUse);

#endif
	m_chkUsePatternDevide.EnableWindow(bUse);
	m_chkUseApplyScalToEocard.EnableWindow(bUse);
	m_chkUseShotScale.EnableWindow(bUse);
	
	
		m_chkUse1PointVisionCompen.EnableWindow(bUse);
	m_chkUseAutoPreheat.EnableWindow(bUse);
}

void CPaneProcessSetupSysSetting::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
#else
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		break;
	case 1:
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
#endif

	if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
	{
		m_chkUseEveryPanelHeadOffset.SetToolTipText( _T("Find Temperature - Position Data") );
		m_chkUseEveryPanelHeadOffset.SetWindowText( _T("Find Temperature - Position Data") );
	}
	else
	{
		m_chkUseEveryPanelHeadOffset.SetToolTipText( _T("Check Vision Head Offset for Every Panel") );
		m_chkUseEveryPanelHeadOffset.SetWindowText( _T("Check Vision Head Offset for Every Panel") );
	}
}



BOOL CPaneProcessSetupSysSetting::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_SysSetting) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseBarcodeMode()
{
	m_sProcessSystem.bUseAIMode = !m_sProcessSystem.bUseAIMode;
	m_chkUseAIMode.SetCheck( m_sProcessSystem.bUseAIMode );
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseNewParameter()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_sProcessSystem.bUseNewParameter3 = !m_sProcessSystem.bUseNewParameter3;
	m_chkUseNewParameter3.SetCheck( m_sProcessSystem.bUseNewParameter3 );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckUseNewBarcodeContents()
{
	m_sProcessSystem.bUseNewBarcodeContents = !m_sProcessSystem.bUseNewBarcodeContents;
	m_chkUseNewBarcodeContents.SetCheck( m_sProcessSystem.bUseNewBarcodeContents );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckUseOriginalInspectionMode()
{
	m_sProcessSystem.bUseOriginalInspectionMode = !m_sProcessSystem.bUseOriginalInspectionMode;
	m_chkUseOriginalInspectionMode.SetCheck( m_sProcessSystem.bUseOriginalInspectionMode );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckUse1stPanelStop()
{
	m_sProcessSystem.bUse1stPanelStop = !m_sProcessSystem.bUse1stPanelStop;
	m_chkUse1stPanelStop.SetCheck( m_sProcessSystem.bUse1stPanelStop );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseMelsec()
{
	m_sProcessSystem.bNoUseMelsecInterface = !m_sProcessSystem.bNoUseMelsecInterface;
	m_chkNoUseMelsecInterface.SetCheck( m_sProcessSystem.bNoUseMelsecInterface );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckPassMode()
{
	m_sProcessSystem.bPassMode = !m_sProcessSystem.bPassMode;
	m_chkPassMode.SetCheck( m_sProcessSystem.bPassMode );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseAllToolScal()
{
	m_sProcessSystem.bUseAllToolScal = !m_sProcessSystem.bUseAllToolScal;
	m_chkUseAllToolScal.SetCheck( m_sProcessSystem.bUseAllToolScal );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseAllToolPower()
{
	m_sProcessSystem.bUseAllToolPower = !m_sProcessSystem.bUseAllToolPower;
	m_chkUseAllToolPower.SetCheck( m_sProcessSystem.bUseAllToolPower );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckTurnPanel()
{
	m_sProcessSystem.bUseTurnPanel = !m_sProcessSystem.bUseTurnPanel;
	m_chkUseTurnPanel.SetCheck( m_sProcessSystem.bUseTurnPanel );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUse4wayScalMain()
{
	m_sProcessSystem.bUse4WayScalMain = !m_sProcessSystem.bUse4WayScalMain;
	m_chkUse4WayScalMain.SetCheck( m_sProcessSystem.bUse4WayScalMain );
}
void CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseZcal()
{
	m_sProcessSystem.bNoUseZCal = !m_sProcessSystem.bNoUseZCal;
	m_chkNoUseZCal.SetCheck( m_sProcessSystem.bNoUseZCal );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseTCal()
{
		m_sProcessSystem.bNoUseTCal = !m_sProcessSystem.bNoUseTCal;
	m_chkNoUseTCal.SetCheck( m_sProcessSystem.bNoUseTCal );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckNoUseLaserCal()
{
	m_sProcessSystem.bNoUseLaserCal = !m_sProcessSystem.bNoUseLaserCal;
	m_chkNoUseLaserCal.SetCheck( m_sProcessSystem.bNoUseLaserCal );
}
void CPaneProcessSetupSysSetting::OnBnClickedCheckUsePatternDevide() 
{
	m_sProcessSystem.bUsePatternDevide = !m_sProcessSystem.bUsePatternDevide;
	m_chkUsePatternDevide.SetCheck( m_sProcessSystem.bUsePatternDevide );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckUseApplyScalToEocard()
{
	m_sProcessSystem.bUseApplyScalToEocard = !m_sProcessSystem.bUseApplyScalToEocard;
	m_chkUseApplyScalToEocard.SetCheck( m_sProcessSystem.bUseApplyScalToEocard );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseShotScale()
{
	m_sProcessSystem.bUseShotScale = !m_sProcessSystem.bUseShotScale;
	m_chkUseShotScale.SetCheck( m_sProcessSystem.bUseShotScale );
}
void CPaneProcessSetupSysSetting::OnCheckUsePreLPRLimit() 
{
	m_sProcessSystem.bUsePreLPRLimit = !m_sProcessSystem.bUsePreLPRLimit;
	m_chkUsePreLPRLimit.SetCheck( m_sProcessSystem.bUsePreLPRLimit );
}
void CPaneProcessSetupSysSetting::OnBnClickedCheckUse1pointVisionCompen()
{
	m_sProcessSystem.bUse1PointVisionCompen = !m_sProcessSystem.bUse1PointVisionCompen;
	m_chkUse1PointVisionCompen.SetCheck( m_sProcessSystem.bUse1PointVisionCompen );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseAutoPreheat()
{
	m_sProcessSystem.bUseAutoPreHeat = !m_sProcessSystem.bUseAutoPreHeat;
	m_chkUseAutoPreheat.SetCheck( m_sProcessSystem.bUseAutoPreHeat );
}

void CPaneProcessSetupSysSetting::OnBnClickedCheckSpare1()
{
	m_sProcessSystem.bUseSpare1 = !m_sProcessSystem.bUseSpare1;
	m_chkUseSpare1.SetCheck( m_sProcessSystem.bUseSpare1 );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseAutoMonitoing()
{
	m_sProcessSystem.bUseAutoMonitoring = !m_sProcessSystem.bUseAutoMonitoring;
	m_chkUseAutoMonitoring.SetCheck( m_sProcessSystem.bUseAutoMonitoring );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseSheetSuction()
{
	m_sProcessSystem.bUseSheetSuction = !m_sProcessSystem.bUseSheetSuction;
	m_chkUseSheetSuction.SetCheck( m_sProcessSystem.bUseSheetSuction );
}


void CPaneProcessSetupSysSetting::OnBnClickedCheckUseSecsGem()
{
	m_sProcessSystem.bUseSecsGem = !m_sProcessSystem.bUseSecsGem;
	m_chkUseSecsGem.SetCheck( m_sProcessSystem.bUseSecsGem );
}
