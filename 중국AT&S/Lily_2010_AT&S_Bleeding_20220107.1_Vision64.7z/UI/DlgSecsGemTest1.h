#pragma once


// CDlgSecsGemTest1 ��ȭ �����Դϴ�.

class CDlgSecsGem1;
class CDlgSecsGemTest1 : public CDialog
{
	DECLARE_DYNAMIC(CDlgSecsGemTest1)

public:
	CDlgSecsGemTest1(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSecsGemTest1();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_SECS_GEM_TEST1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedBtnAllEcinfo();
	virtual BOOL DestroyWindow();
	virtual BOOL OnInitDialog();

public:
	CDlgSecsGem1*	m_pParent;
	CComboBox	m_cmbEcid;

	afx_msg void OnBnClickedBtnEcvChange();
	afx_msg void OnBnClickedBtnAlarmSet();
	afx_msg void OnBnClickedBtnAlarmReset();
	afx_msg void OnBnClickedBtnPpidSet();
	afx_msg void OnBnClickedBtnProcessReq();
	afx_msg void OnBnClickedBtnPpidSet2();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedBtnSendMsg();
};
