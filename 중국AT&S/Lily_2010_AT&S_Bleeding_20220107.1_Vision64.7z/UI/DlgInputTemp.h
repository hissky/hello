#if !defined(AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_)
#define AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputTemp.h : header file
//
#include "ui/ColorComboEx.h"
#include "LedButton.h"
#include "DlgLaserMeasurement.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp dialog

class CDlgInputTemp : public CDialog
{
// Construction
public:
	CDlgInputTemp(CWnd* pParent = NULL);   // standard constructor

	BOOL  m_bGetLotInfo;

	CFont	m_fnt;
	CStringArray  m_strManageCustom;
	CFont m_fntList;

	CFont					m_fntBtn;
	int m_nTimer;
// Dialog Data
	//{{AFX_DATA(CDlgInputTemp)
	enum { IDD = IDD_DLG_INPUT_TEMP2 };

    CLedButton	m_ledGetLotInfo;
   	CListCtrl	m_listLotInfo; 

	CDlgLaserMeasurement m_dlgGEMWait;
	DWORD m_dwStartTime;


	//}}AFX_DATA




	void InitListControl();
	void ShowLotInfo();
	void InitLotInfo(); 
	void ClearLotInfoData(); 
	void DisplayAutoValue();
	void EnableCtrlForRMS();
	void SaveLotInfo();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputTemp)
	public:
		virtual BOOL Create(CWnd* pParentWnd);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

public:
	// Generated message map functions
	//{{AFX_MSG(CDlgInputTemp)
	afx_msg void OnBtnTemp();
	afx_msg void OnOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnCancel();

	

	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);


	afx_msg void OnTimer(UINT nIDEvent);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

   	afx_msg void OnBnClickedCheckGetLotInfo();
    afx_msg void OnBnClickedBtnInitLotInfo();
	afx_msg void OnBnClickedBtnRms();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_)
