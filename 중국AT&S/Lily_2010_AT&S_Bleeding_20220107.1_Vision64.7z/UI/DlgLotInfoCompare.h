#if !defined(AFX_DlgLotInfoCompare_H__5228A43D_6DEE_440D_B2A9_911B1EC1336B__INCLUDED_)
#define AFX_DlgLotInfoCompare_H__5228A43D_6DEE_440D_B2A9_911B1EC1336B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLotInfoCompare.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgLotInfoCompare dialog

class CDlgLotInfoCompare : public CDialog
{
// Construction
public:
	CDlgLotInfoCompare(CWnd* pParent = NULL);   // standard constructor

	void InitListControl();
	CFont	m_fntStatic ;

// Dialog Data
	//{{AFX_DATA(CDlgLotInfoCompare)
	enum { IDD = IDD_DLG_LOT_INFO_COMPARE };
	CListCtrl	m_ctrlListLotInfo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLotInfoCompare)
public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
	//{{AFX_MSG(CDlgLotInfoCompare)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DlgLotInfoCompare_H__5228A43D_6DEE_440D_B2A9_911B1EC1336B__INCLUDED_)
