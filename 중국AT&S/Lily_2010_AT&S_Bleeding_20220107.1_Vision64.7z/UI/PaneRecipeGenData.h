#if !defined(AFX_PANERECIPEGENDATA_H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_)
#define AFX_PANERECIPEGENDATA_H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// panerecipegendata.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenData form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DrillDataView.h"
#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "..\model\dfiddata.h"
#include "LedButton.h"
#define MAX_FID_BLOCK		50 
#include "..\UI\DlgMessageBox.h"
class DProject;
class CPaneRecipeGen;

class CPaneRecipeGenData : public CFormView
{
protected:
	BOOL	m_bSelectPattern;
	CPoint  m_ptFidPosition;
	CPoint  m_ptTotalMove;
	CPoint	m_ptDrawRectBack1;
	CPoint	m_ptDrawRectBack2;
	CPoint	m_ptFidPos;
	CPoint	m_ptMoveStart;
	CPoint  m_ptDrawStart;
	BOOL	m_bDrawMoveStart;
	BOOL	m_bUnitMoveStart;
	BOOL	m_bDisunifyMode;
	BOOL	m_bAddSubFidMode;

	// ������ Fiducial ���� ����
	BOOL	m_bSetMainFidMode;
	BOOL	m_bResetOneMainFidMode;
	BOOL	m_bSetSubFidMode;
	BOOL	m_bResetOneSubFidMode;
	
	CDrillDataView		m_clsDrillDataView;
	CPaneRecipeGenData();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenData)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenData)
	enum { IDD = IDD_DLG_RECIPE_GEN_DATA };
	double	m_dX;
	double	m_dY;
	CColorEdit m_edtLotIDComp;
	CComboBox	m_cmbSelectComSol;
	UEasyButtonEx	m_btnZoomField;
	UEasyButtonEx	m_btnSelectClear;
	UEasyButtonEx	m_btnExcellonLoad;
	UEasyButtonEx	m_btnEasymarker;
	UEasyButtonEx	m_btnExcellonSave;
	UEasyButtonEx	m_btnFlipX;
	UEasyButtonEx	m_btnFlipY;
	UEasyButtonEx	m_btnRotate;
	UEasyButtonEx	m_btnSkivingSkip;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnRemoveAlldata;
	UEasyButtonEx m_ledOriginalInspection;
	UEasyButtonEx m_ledDataHeader;
   	UEasyButtonEx	m_btnFindPattern;
	CLedButton	m_ledShowStripNo;

	CLedButton	m_ledShowBlockData;
	CLedButton	m_ledShowNoBlockData;
	CLedButton	m_ledShowSelectAreaOnly;
	CLedButton	m_ledShowSelectFidBlockOnly;
	CLedButton	m_ledShowBlockNo;

	CString m_strLotIDComp;
	CString m_strLotIDSold;

	//}}AFX_DATA

// Attributes
public:
	int	m_nUserLevel;

	BOOL m_bShowSortIndex;
	int m_nFieldIndex;
	BOOL m_bEditCursor;
	CString	m_strFile;
	CString m_strFilmName;

	CString m_strProcessCode;
	CString m_strBackwardLevel;

	int  m_nStartFidIndex;
	BOOL m_bHeaderReadComplete;
	int m_nG821Count;
	BOOL m_bSelectFidBlock[MAX_FID_BLOCK];
	BOOL		m_bOriginalInspection;

	BOOL m_bShowHoleIndex;
	int m_nHoleIndex;
// Operations
public:
	BOOL m_bExcellonChange;
	BOOL		m_bShowStripNo;
	void ResetProject();
	void CalRefFidFlipPos(BOOL bX);
	void DisplayRotateInfo();
	BOOL IsPickUnit(CPoint ptPoint);
	void SetDrawRect();
	void DrawSelectionRect(CDC* pDC);
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	void InitStaticControl();
	void InitBtnControl();
	void DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2);
	BOOL m_bViewerMoveMode;
	BOOL IsCheckPathViewMode(CPoint ptPick);
	BOOL IsCheckSelectViewMode(CPoint ptPick);
	BOOL IsPickToolVisible(CPoint ptPick);
	void ChangePosInfo(CPoint ptPick);
	void DrawData();
	CPaneRecipeGen* m_pParent;
	DProject* m_pProject;
	void SetProject(DProject* pProject);
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);
	BOOL SetValue(int nComSol, CString strTXT = _T(""));
	void ClearFiducialIndex();
	void InputScheduleInfo(int nComSol);

	void SetRefFidLeftBottom(int nAxisMode);

	void MesDataFileCheck(int nCompSold =0);
	BOOL MesDataCheck(CString strLotID1, int nComSol);
	CString FindDataName(CString strLotID, CString strManager, CString strLayer, int nComSol);
	CString FindDataNameNew(CString strFileName, CString strManagementCode);
	CString FindDataNameNew2(CString strLotID, CString strManager, int nComSol, CString strProcessCode, CString strBackwardLevel);
	void SetOriginalInspection();

	BOOL ParameterNameCheck();
	BOOL DataAndProjectOpen(int nComSol,CString strRecipeComp, CString strRecipeSold);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenData)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenData();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenData)

	afx_msg void OnSelectHole();

	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonExcellon();
	afx_msg void OnButtonEasymarker();
	afx_msg void OnButtonSaveExcellon();
	afx_msg void OnPaint();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnButtonPlt();
	afx_msg void OnButtonFlipx();
	afx_msg void OnButtonFlipy();
	afx_msg void OnButtonRotate();
	afx_msg void OnButtonMove();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelectFieldOne();
	afx_msg void OnSelectField();
	afx_msg void OnSelectFidBlock(UINT parm_control_id);
	afx_msg void OnSetTableOffset();
	afx_msg void OnStartFiducialSet();
	afx_msg void OnClearFiducialSet();
	afx_msg void OnFiducialAdd();
	afx_msg void OnFiducialMove();
	afx_msg void OnFiducialDel();
	afx_msg void OnSetRefFid();
	afx_msg void OnArrayCopy();
	afx_msg void OnAddSubFid();
	afx_msg void OnDelSubFidAll();
	afx_msg void OnMergeUnit();
	afx_msg void OnDisunifyUnit();
	afx_msg void OnButtonZoomAll();
	afx_msg void OnButtonClear();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnCopyField();
	afx_msg void OnCheckOriginalInspection();
	afx_msg void OnCheckDataHeader();
	afx_msg void OnCheckShowStripNo();
//	afx_msg void OnFiducialSetMain();
//	afx_msg void OnFiducialResetOneMain();
//	afx_msg void OnFiducialResetAllMain();
//	afx_msg void OnFiducialSetSub();
//	afx_msg void OnFiducialResetOneSub();
//	afx_msg void OnFiducialResetAllSub();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnStnClickedStaticView();
	afx_msg void OnBnClickedButtonField2();
	afx_msg void OnBnClickedCheckShowBlockDataOnly();
	afx_msg void OnBnClickedCheckShowNoBlockDataOnly();
	afx_msg void OnBnClickedCheckShowSelectAreaOnly();
	afx_msg void OnBnClickedCheckShowSelectFidblockOnly();
	afx_msg void OnBnClickedCheckShowBlockNo();
	afx_msg void OnBnClickedButtonSkvingSkip2();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENDATA_H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_)
