// DlgSecsGemComm1.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\easydrillerdlg.h"
#include "DlgSecsGemComm1.h"
#include "DlgSecsGem1.h"
//#include "MioSequence.h"
#include "afxdialogex.h"
#include "Temp/IniFile.h"
#include "./addin/JnLib.h"
// CDlgSecsGemComm1 ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgSecsGemComm1, CDialog)

CDlgSecsGemComm1::CDlgSecsGemComm1(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSecsGemComm1::IDD, pParent)
{
}

CDlgSecsGemComm1::~CDlgSecsGemComm1()
{
}

void CDlgSecsGemComm1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STC_COMM_STE_DISABLE,				m_CommunicateSte[Comm_Disabled]);
	DDX_Control(pDX, IDC_STC_COMM_STE_WAIT_CR_FROM_HOST,	m_CommunicateSte[Comm_WaitCRFromHost]);
	DDX_Control(pDX, IDC_STC_COMM_STE_WAIT_DELAY,			m_CommunicateSte[Comm_WaitDelay]);
	DDX_Control(pDX, IDC_STC_COMM_STE_WAIT_CRA,				m_CommunicateSte[Comm_WaitCRA]);
	DDX_Control(pDX, IDC_STC_COMM_STE_COMMUNICATING,		m_CommunicateSte[Comm_Communicating]);

	DDX_Control(pDX, DC_STC_CONTROL_STE_EQ_OFFLINE,				m_ControlSte[Control_EqOffline]);
	DDX_Control(pDX, DC_STC_CONTROL_STE_ATTEMPTING_TO_GO_ONLINE,m_ControlSte[Control_AttemptOnline]);
	DDX_Control(pDX, DC_STC_CONTROL_STE_HOST_OFFLINE,			m_ControlSte[Control_HostOffline]);
	DDX_Control(pDX, DC_STC_CONTROL_STE_LOCAL,					m_ControlSte[Control_Local]);
	DDX_Control(pDX, DC_STC_CONTROL_STE_REMOTE,					m_ControlSte[Control_Remote]);


	DDX_Control(pDX, IDC_STC_PROCESS_STE_IDLE,			m_ProcessSte[Processing_Idle]);
	DDX_Control(pDX, IDC_STC_PROCESS_STE_RUN,		m_ProcessSte[Processing_Run]);
	DDX_Control(pDX, IDC_STC_PROCESS_STE_ALARM,			m_ProcessSte[Processing_Down]);
	DDX_Control(pDX, IDC_STC_PROCESS_STE_PM,			m_ProcessSte[Processing_PM]);
}


BEGIN_MESSAGE_MAP(CDlgSecsGemComm1, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_OFFLINE, &CDlgSecsGemComm1::OnBnClickedBtnControlSteOffline)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_LOCAL, &CDlgSecsGemComm1::OnBnClickedBtnControlSteLocal)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_REMOTE, &CDlgSecsGemComm1::OnBnClickedBtnControlSteRemote)

	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_INITIAL, &CDlgSecsGemComm1::OnBnClickedBtnControlSteInitial)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_CLOSE, &CDlgSecsGemComm1::OnBnClickedBtnControlSteClose)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_START, &CDlgSecsGemComm1::OnBnClickedBtnControlSteStart)
	ON_BN_CLICKED(IDC_BTN_CONTROL_STE_STOP, &CDlgSecsGemComm1::OnBnClickedBtnControlSteStop)
END_MESSAGE_MAP()


// CDlgSecsGemComm1 �޽��� ó�����Դϴ�.

BOOL CDlgSecsGemComm1::DestroyWindow()
{
	return CDialog::DestroyWindow();
}

BOOL CDlgSecsGemComm1::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitBrush();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgSecsGemComm1::InitBrush()
{
	static int nButton = 0;
	CWnd *pPrevWnd = GetWindow( GW_CHILD );
	while( pPrevWnd )
	{
		char className[100];
		::GetClassName(
			pPrevWnd->m_hWnd,           // handle to window
			className,  // class name
			100       // size of class name buffer
			);

		if (lstrcmp(className,_T("Button")) == 0)
		{
			CButton *pBtn = (CButton*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic);

			//TRACE("%d\n",nButton);
		}
		else if (lstrcmp(className,_T("Edit")) == 0)
		{
			CEdit *pBtn = (CEdit*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic);
		}
		else if (lstrcmp(className,_T("Static")) == 0)
		{
			CStatic *pBtn = (CStatic*)pPrevWnd;
			pBtn->SetFont(&m_fntStatic);
		};

		pPrevWnd = pPrevWnd->GetWindow( GW_HWNDNEXT );
	}
}

void CDlgSecsGemComm1::InitBtn(void)
{

	for (int i=1; i<EndCountOfCommSts; i++)
	{
		m_CommunicateSte[i]
		.SetFontName(_T("Arial Bold"))
			.SetFontSize(10)
			.SetTextColor(RGB(0,0,0))
			.SetFontBold(TRUE);
	}

	for (int i=1; i<EndCountOfControlSts; i++)
	{
		m_ControlSte[i]
		.SetFontName(_T("Arial Bold"))
			.SetFontSize(10)
			.SetTextColor(RGB(0,0,0))
			.SetFontBold(TRUE);
	}

	for (int i=1; i<EndCountOfProcessSts; i++)
	{
		m_ProcessSte[i]
		.SetFontName(_T("Arial Bold"))
			.SetFontSize(10)
			.SetTextColor(RGB(0,0,0))
			.SetFontBold(TRUE);
	}

}

void CDlgSecsGemComm1::DispCommunicateSts()
{
	_eCommState CommSte;

	CommSte = m_pParent->GetCommStatus();

	if (m_nOldCommSte != CommSte)
	{
		for (int i=1; i<EndCountOfCommSts; i++)
			m_CommunicateSte[i].SetBkColor(RGB(255,255,255));

		if (CommSte > 0)
			m_CommunicateSte[CommSte].SetBkColor(RGB(150,255,150));

		m_nOldCommSte = CommSte;
	}
}

void CDlgSecsGemComm1::DispControlSts()
{
	_eControlState ControlSte;

	ControlSte = m_pParent->GetControlStatus();

	if (m_nOldControlSte != ControlSte)
	{
		for (int i=1; i<EndCountOfControlSts; i++)
			m_ControlSte[i].SetBkColor(RGB(255,255,255));

		if (ControlSte > 0)
			m_ControlSte[ControlSte].SetBkColor(RGB(150,255,150));

		m_nOldControlSte = ControlSte;
	}
}

void CDlgSecsGemComm1::DispProcessSts()
{
	_eProcessingState	ProcessSte;

	ProcessSte = m_pParent->GetProcessStatus();

	if (m_nOldProcessSte != ProcessSte)
	{
		for (int i=1; i<EndCountOfProcessSts; i++)
			m_ProcessSte[i].SetBkColor(RGB(255,255,255));

		if (ProcessSte > 0)
			m_ProcessSte[ProcessSte].SetBkColor(RGB(150,255,150));

		m_nOldProcessSte = ProcessSte;
	}
}

void CDlgSecsGemComm1::Refresh()
{

	DispCommunicateSts();
	DispControlSts();
	DispProcessSts();

}

void CDlgSecsGemComm1::LoadInfoGem(CString szXGemFilename, CString szHostFilename, CString& strIP, int& nPort, CString& strXGemPath)
{
	register CIniFile* ServerFile;
	register CIniFile* XGemDataFile;
	CString strLog = "";
	CString strTime = "";

	ServerFile = new CIniFile(szHostFilename);
	XGemDataFile = new CIniFile(szXGemFilename);

	strIP = ServerFile->ReadString("HSMS", "IP", "");
	nPort = ServerFile->ReadInteger("HSMS", "Port", 0);

	strXGemPath = XGemDataFile->ReadString("XGEM", "ProjectPath", "");

	delete ServerFile;
	delete XGemDataFile;
}

void CDlgSecsGemComm1::OnBnClickedBtnControlSteOffline()
{
	long		nReturn = 0;
	char        szMsg[256];

	gXGem1->SendCEID_ControlState(Control_EqOffline);
	MessageLoopWait(1000);
	//Argument : None
	nReturn = m_pParent->m_XGem.GEMReqOffline();
	if( nReturn == 0 ) 
		m_pParent->AddListBox("[S1F15 E->H] Button - GEMReqOffline ");
	else 
		m_pParent->AddListBox("[S1F15 E->H] Button - GEMReqOffline Fail(%d)", nReturn );
}


void CDlgSecsGemComm1::OnBnClickedBtnControlSteLocal()
{
	long		nReturn = 0;
	char        szMsg[256];

	//Argument : None
	nReturn = m_pParent->m_XGem.GEMReqLocal();
	if( nReturn == 0 ) 
		m_pParent->AddListBox("[S6F11 E->H] Button - GEMReqLocal " );
	else 
		m_pParent->AddListBox("[S6F11 E->H] Button - GEMReqLocal Fail(%d)", nReturn );
}


void CDlgSecsGemComm1::OnBnClickedBtnControlSteRemote()
{
	long		nReturn = 0;
	char        szMsg[256];

	//Argument : None
	nReturn = m_pParent->m_XGem.GEMReqRemote();
	if( nReturn == 0 ) 
		m_pParent->AddListBox("[S6F11 E->H] Button - GEMReqRemote " );
	else 
		m_pParent->AddListBox("[S6F11 E->H] Button - GEMReqRemote Fail(%d)", nReturn );
}


BEGIN_EVENTSINK_MAP(CDlgSecsGemComm1, CDialog)
END_EVENTSINK_MAP()



void CDlgSecsGemComm1::OnBnClickedBtnControlSteInitial()
{
	long nRet = 0;
	CString str;

	str = AppPath + "Gem\\Config.cfg";

	// Init
	if( (nRet = m_pParent->m_XGem.Initialize(str)) == 0) 
	{	m_pParent->AddListBox("Button - XGem initialized ");		m_pParent->m_nXGemStatus = 1;		}		// 0:Close, 1:init, 2:start, 3:Stop
	else
		m_pParent->AddListBox("Button - XGem initialized Fail (%d)", nRet);
}


void CDlgSecsGemComm1::OnBnClickedBtnControlSteClose()
{
	long nRet = 0;

	// Close
	if( (nRet = m_pParent->m_XGem.Close()) == 0) 
	{	m_pParent->AddListBox("Button - XGem Close ");		m_pParent->m_nXGemStatus = 0;		}		// 0:Close, 1:init, 2:start, 3:Stop
	else 
		m_pParent->AddListBox("Button - XGem Close Fail (%d)", nRet);
}


void CDlgSecsGemComm1::OnBnClickedBtnControlSteStart()
{
	int nRet = 0;
	// Start
	if( (nRet = m_pParent->m_XGem.Start()) == 0) 
	{	m_pParent->AddListBox("Button - XGem started ");		m_pParent->m_nXGemStatus = 2;		}		// 0:Close, 1:init, 2:start, 3:Stop
	else
		m_pParent->AddListBox("Button - XGem start Fail (%d)", nRet);


}


void CDlgSecsGemComm1::OnBnClickedBtnControlSteStop()
{
	int nRet = 0;
	// Stop
	if( (nRet = m_pParent->m_XGem.Stop()) == 0) 
	{	m_pParent->AddListBox("Button - XGem stoped ");		m_pParent->m_nXGemStatus = 3;		}		// 0:Close, 1:init, 2:start, 3:Stop
	else
		m_pParent->AddListBox("Button - XGem stop Fail (%d)", nRet);
}
