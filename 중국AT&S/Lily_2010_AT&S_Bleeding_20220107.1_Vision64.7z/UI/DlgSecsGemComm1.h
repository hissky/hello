#pragma once
#include "Temp\Label.h"
#include "gem\CommonGem.h"


// CDlgSecsGemComm1 ��ȭ �����Դϴ�.

class CDlgSecsGem1;
class CDlgSecsGemComm1 : public CDialog
{
	DECLARE_DYNAMIC(CDlgSecsGemComm1)

public:
	CDlgSecsGemComm1(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSecsGemComm1();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_SECS_GEM_COMM1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual BOOL DestroyWindow();

public:
	CDlgSecsGem1*	 m_pParent;
	CFont	m_fntStatic;
	CLabel	m_CommunicateSte[EndCountOfCommSts];
	CLabel	m_ControlSte[EndCountOfControlSts];
	CLabel	m_ProcessSte[EndCountOfProcessSts];

	_eCommState		m_nOldCommSte;
	_eControlState		m_nOldControlSte;
	_eProcessingState	m_nOldProcessSte;
	
public:
	void InitBrush();
	void	InitBtn();

	void	Refresh();

	void	DispCommunicateSts();
	void	DispControlSts();
	void	DispProcessSts();

	void LoadInfoGem(CString szXGemFilename, CString szHostFilename, CString& strIP, int& nPort, CString& strXGemPath);

	DECLARE_EVENTSINK_MAP()

public:
	afx_msg void OnBnClickedBtnControlSteOffline();
	afx_msg void OnBnClickedBtnControlSteLocal();
	afx_msg void OnBnClickedBtnControlSteRemote();
	afx_msg void OnBnClickedBtnControlSteInitial();
	afx_msg void OnBnClickedBtnControlSteClose();
	afx_msg void OnBnClickedBtnControlSteStart();
	afx_msg void OnBnClickedBtnControlSteStop();
};
