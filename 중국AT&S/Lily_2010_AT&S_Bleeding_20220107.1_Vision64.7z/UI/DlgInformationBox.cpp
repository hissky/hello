// DlgInformationBox.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgInformationBox.h"
#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"

#include "..\device\hdevicefactory.h"
#include "..\device\DeviceMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInformationBox dialog


CDlgInformationBox::CDlgInformationBox(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInformationBox::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInformationBox)
	m_strContent = _T("");
	m_strTitle = _T("");
	m_strSubInput = _T("");
	//}}AFX_DATA_INIT
	m_bOK = -1;
	m_bLotAbort = FALSE;
}


void CDlgInformationBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInformationBox)
	DDX_Text(pDX, IDC_STC_CONTENT, m_strContent);
	DDX_Text(pDX, IDC_STC_TITLE, m_strTitle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInformationBox, CDialog)
	//{{AFX_MSG_MAP(CDlgInformationBox)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL, OnButtonManual)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CDlgInformationBox::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInformationBox message handlers
void CDlgInformationBox::SetDlgFont()
{
	m_dlgFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_STC_TITLE)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STC_CONTENT)->SetFont(&m_dlgFont);

	m_btnFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDOK)->SetFont(&m_btnFont);
}

BOOL CDlgInformationBox::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetDlgFont();
	GetDlgItem(IDC_EDIT_SUB_INPUT)->SetWindowText(_T(""));

	if(m_bLotAbort)
	{
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIsLotProgress == FALSE)
		{
			GetDlgItem(IDOK)->SetWindowText(_T("Lot Cancel"));
//			GetDlgItem(IDCANCEL)->SetWindowText(_T(""));
			GetDlgItem(IDCANCEL)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDOK)->SetWindowText(_T("Lot Abnormal End"));
			GetDlgItem(IDCANCEL)->SetWindowText(_T("Lot Abort"));
		}
		GetDlgItem(IDC_BUTTON_MANUAL)->SetWindowText(_T("Skip"));
		GetDlgItem(IDC_EDIT_SUB_INPUT)->EnableWindow(FALSE);
	}

	return TRUE;
}

void CDlgInformationBox::SetTitleContent(int nIdTitle, LPCTSTR strContent)
{
	m_strTitle.Empty();
	m_strTitle.LoadString(nIdTitle);

	m_strContent.Empty();
	m_strContent = strContent;
}

void CDlgInformationBox::SetTitleContent(int nIdTitle, int nIdContent)
{
	m_strTitle.Empty();
	m_strTitle.LoadString(nIdTitle);

	m_strContent.Empty();
	m_strContent.LoadString(nIdContent);
}

void CDlgInformationBox::SetTitleContent(LPCTSTR strTitle, int nIdContent)
{
	m_strTitle.Empty();
	m_strTitle = strTitle;

	m_strContent.Empty();
	m_strContent.LoadString(nIdContent);
}

void CDlgInformationBox::SetTitleContent(LPCTSTR strTitle, LPCTSTR strContent)
{
	m_strTitle.Empty();
	m_strTitle = strTitle;

	m_strContent.Empty();
	m_strContent = strContent;
}


void CDlgInformationBox::OnOK() 
{
	if(m_bLotAbort)
	{

	}
	else
		GetDlgItem(IDC_EDIT_SUB_INPUT)->GetWindowText(m_strSubInput);

	m_bOK = TRUE;
	CDialog::OnOK();
}

void CDlgInformationBox::OnCancel() 
{
	if(m_bLotAbort)	
	{

 	}
	m_bOK = FALSE;
	CDialog::OnCancel();
}
	/*
BOOL CDlgInformationBox::PreTranslateMessage(MSG* pMsg) 
{

	if(pMsg->message == WM_KEYDOWN)
	{
		if( (GetAsyncKeyState(VK_CONTROL) < 0 ))
		{
			if(pMsg->wParam == 65)	
			{
				if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main != NULL && 
					(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling() || theDlg->m_pAutoRun->m_bDrillPause == TRUE) )
				{
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->ShowWindow(SW_SHOW);
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->SetFocus();
				}
			}
		}
		
		
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->IsWindowVisible())
			
		{
			if(pMsg->wParam == 27)
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->ShowWindow(SW_HIDE);
				return 1;
			}
			
			
			if(pMsg->wParam == VK_RETURN)
				return 1;
		}
		
		if(pMsg->wParam==81)//Q Ű�� �� â �ٲ۴� 
		{
			if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->IsWindowVisible())
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->ChangeView(0);
				return 1;
			}
		}
		if(pMsg->wParam==87)//W Ű�� �� â �ٲ۴� 
		{
			if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->IsWindowVisible())
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->ChangeView(1);
				return 1;
			}
		}
		if(pMsg->wParam==69)//F1 Ű�� �� â �ٲ۴� 
		{
			if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->IsWindowVisible())
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgMotorControl_Main->ChangeView(2);
				return 1;
			}
		}
		
		
	}
	
	return CDlgInformationBox::PreTranslateMessage(pMsg);
}
*/

void CDlgInformationBox::OnButtonManual() 
{	
	if(m_bLotAbort)
	{
		m_bOK = TRUE;
		EndDialog(0);
	}
	else
	{
		/*///�ӽ��ӽ�
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();

		// Manual Mode
		// Cycle Stop 		
		pMotor->SetOutPort(PC_CYCLE_STOP, TRUE);
		pMotor->SetOutPort(PC_AUTO_MODE, 0, 0);
		pMotor->SetOutPort(PC_MANUAL_MODE, 1);		

		theDlg->m_pDlgMotorControl_Main->ShowWindow(SW_SHOW);
		theDlg->m_pDlgMotorControl_Main->SetFocus();	
		*/
	}
}


void CDlgInformationBox::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	GetDlgItem(IDC_EDIT_SUB_INPUT)->GetWindowText(m_strSubInput);

	CDialog::OnOK();
}
