// DlgShotTable.cpp: implementation file
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgSelectedToolEdit.h"
#include "..\model\DShotTableINI.h"
#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "GridCtrl_src/GridCtrl.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "model\DSystemINI.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "..\MODEL\GlobalVariable.h"
#include "..\alarmmsg.h"

#include "..\model\DProcessINI.h"
#include "..\model\DBeampathINI.h"

#define		USETOPHAT_POSITION	 1 
#define		POLARITY_POSITION	 2
#define		VISION_POSION		 6 


#define		COLOR_BEAMPATH		RGB(255, 255, 162)
#define		COLOR_POWEROFFSET	RGB(243, 255, 72)
#define		COLOR_COMPENSATION	RGB(207, 255, 36)
#define		COLOR_SCANNERFACTS	RGB(255, 202, 108)
#define		COLOR_HOLEFACTS		RGB(180, 255, 255)


#define		COLOR_RED		RGB(255, 0, 0)
#define		COLOR_GREEN		RGB(0, 255, 0)

#define		COLOR_WHITE		RGB(255, 255, 255)
#define		COLOR_YELLOW		RGB(255, 255, 0)

#define		COLOR_GREY		RGB(80, 80, 80)


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CDlgSelectedToolEdit::CDlgSelectedToolEdit(CWnd* pParent /*=NULL*/)
: CDialog(CDlgSelectedToolEdit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgShotTable)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT


	m_bInfoCheck = FALSE;
	m_bBeamPathCheck = FALSE;
	m_bPowerOffsetCheck = FALSE;
	m_bpowerCompensationCheck = FALSE;
	m_bScannerFactCheck = FALSE;



	m_nUserLevel = 0;

	for(int i = 0;i < 6; i++)
	{
		m_bCheckBox[i] = FALSE;
	}
	m_bCheckBox[0] =TRUE;
	m_bCheckBox[1] =TRUE;
	m_bCheckBox[2] =TRUE;

	for(int i = 0;i < 3; i++)
	{
		m_bGroupCheckBox[i] = FALSE;
	}
	m_bGroupCheckBox[0] =TRUE;
	m_bGroupCheckBox[1] =TRUE;

	m_bClickList = FALSE;		// ����Ʈ�� Ŭ�������� �� 
	m_ClickID = FALSE;			// ����Ʈ�� �ε����� Ŭ�������� �� 
	m_IdNoToAddDel = 0;	

	strGroupTable0[0] = "No";
	strGroupTable0[1] = "Name";

	strGroupTable1[0] = "Type";
	strGroupTable1[1] = "Mode";
	/*strGroupTable1[2] = "First Wait";
	strGroupTable1[3] = "Use Aom";*/
	strGroupTable1[2] = "Dummy Type";
	//strGroupTable1[5] = "Min Frq (Hz)";
	strGroupTable1[3] = "Frq (Hz)";
	strGroupTable1[4] = "Duty(%)";
	strGroupTable1[5] = "LM(us)";
	strGroupTable1[6] = "Total";
	strGroupTable1[7] = "Burst";
	//strGroupTable1[8] = "RF1(%)";
	strGroupTable1[8] = "Use Aperure";
	strGroupTable1[9] = "Path";
	strGroupTable1[10] = "TextX";
	strGroupTable1[11] = "TextY";
	strGroupTable1[12] = "DrawIn";
	strGroupTable1[13] = "DrawOut";


	strGroupTable2[0] = "LaserOnDelay";
	strGroupTable2[1] = "LaserOffDelay";
	strGroupTable2[2] = "DrawSpeed";
	strGroupTable2[3] = "JumpSpeed";
	strGroupTable2[4] = "ConerDelay";
	strGroupTable2[5] = "JumpDelay";
	strGroupTable2[6] = "LineDelay";

	strTable0[0] = "No";

	strTable1[0] = "[1] Duty";
	strTable1[1] = "[2] Duty";
	strTable1[2] = "Power(W)";
	strTable1[3] = "Tol(%)";
	strTable1[4] = "T_Max(W)";
	strTable1[5] = "T_Min(W)";


	strAOMTable0[0] = "No";
	strAOMTable0[1] = "[1] On";
	strAOMTable0[2] = "[1] Off";

		


	strOpticTable0[0] = "No";
	strOpticTable0[1] = "Name";
	strOpticTable0[2] = "MSize";
	strOpticTable0[3] = "B1";
	strOpticTable0[4] = "B2";
	strOpticTable0[5] = "B3";
	strOpticTable0[6] = "B4";
	strOpticTable0[7] = "M1";
	strOpticTable0[8] = "M2";
	strOpticTable0[9] = "Z1";
	strOpticTable0[10] = "Z2";
	strOpticTable0[11] = "Asc File";

	m_bGroupClickGrid = FALSE;
	m_bClickGrid = FALSE;
	m_bAOMClickGrid = FALSE;

	m_nGroupSelectRow = 1;
	m_nSelectRow = 1;
	m_nAOMSelectRow = 1;

	m_bDeleteAndSaveClick = FALSE;
	m_bDelClick = FALSE;
	m_nSelectedTool = 0;
}

CDlgSelectedToolEdit::~CDlgSelectedToolEdit()
{
}

void CDlgSelectedToolEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgShotTable)

	DDX_Control(pDX, IDC_CHECK_GROUP_TABLE1, m_ChkGroupSubBox[1]);
	DDX_Control(pDX, IDC_CHECK_GROUP_TABLE2, m_ChkGroupSubBox[2]);


	DDX_Control(pDX, IDC_CHECK_BEAMPATH, m_ChkSubBox[1]);
	DDX_Control(pDX, IDC_CHECK_POWER_OFFSET, m_ChkSubBox[2]);
	DDX_Control(pDX, IDC_CHECK_COMPENSATIO, m_ChkSubBox[3]);
	DDX_Control(pDX, IDC_CHECK_SCANNER_FACT, m_ChkSubBox[4]);
	DDX_Control(pDX, IDC_CHECK_HOLE_FACT, m_ChkSubBox[5]);
	DDX_Control(pDX, IDC_BUTTON_REFRESH, m_btnRefresh);

	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_DEL, m_btnDel);


	DDX_Control(pDX, IDC_BUTTON_UP, m_btnUp);
	DDX_Control(pDX, IDC_BUTTON_DOWN, m_btnDown);
//	DDX_Control(pDX, IDC_LIST_GROUP_INFO, m_GroupList);
	DDX_Control(pDX, IDC_BUTTON_GROUP_ADD, m_btnGroupAdd);
	DDX_Control(pDX, IDC_BUTTON_GROUP_DEL, m_btnGroupDel);

	DDX_GridControl(pDX, IDC_GRID, m_Grid);
	DDX_GridControl(pDX, IDC_GRID_GROUP, m_GroupGrid);
	DDX_GridControl(pDX, IDC_GRID_AOM, m_AOMGrid);
	DDX_GridControl(pDX, IDC_GRID_OPTIC, m_OpticGrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSelectedToolEdit, CDialog)
	//{{AFX_MSG_MAP(CDlgShotTable)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_BEAMPATH, OnCheckBeamPath)
	ON_BN_CLICKED(IDC_CHECK_POWER_OFFSET, OnCheckPowerOffset)
	ON_BN_CLICKED(IDC_CHECK_COMPENSATIO, OnCheckPowerCompensation)
	ON_BN_CLICKED(IDC_CHECK_SCANNER_FACT,OnCheckScannerFact)
	ON_BN_CLICKED(IDC_CHECK_HOLE_FACT,OnCheckHoleFact)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH,OnCheckRefresh)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INFO, OnClickList)

	ON_BN_CLICKED(IDC_CHECK_GROUP_TABLE1, OnCheckGroupTable1)
	ON_BN_CLICKED(IDC_CHECK_GROUP_TABLE2, OnCheckGroupTable2)

	ON_BN_CLICKED(IDC_BUTTON_ADD,OnCheckAdd)
	ON_BN_CLICKED(IDC_BUTTON_DEL,OnCheckDel)

	ON_BN_CLICKED(IDC_BUTTON_UP,OnCheckUp)
	ON_BN_CLICKED(IDC_BUTTON_DOWN,OnCheckDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_INFO, OnNMCustomdrawListTest)

	ON_NOTIFY(NM_CLICK, IDC_LIST_GROUP_INFO, OnClickGroupList)
	ON_BN_CLICKED(IDC_BUTTON_GROUP_ADD,OnCheckGroupAdd)
	ON_BN_CLICKED(IDC_BUTTON_GROUP_DEL,OnCheckGroupDel)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_GROUP_INFO, OnNMCustomdrawGroupListTest)

	ON_NOTIFY(NM_CLICK, IDC_GRID, OnGridClick)
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID, OnGridEndEdit)
	ON_NOTIFY(NM_CLICK, IDC_GRID_GROUP, OnGroupGridClick)
	ON_NOTIFY(NM_DBLCLK, IDC_GRID_GROUP, OnGroupGridDoubleClick)

	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_GROUP, OnGroupGridEndEdit)
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_AOM, OnAOMGridEndEdit)
	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_OPTIC, OnOpticGridEndEdit)
	ON_NOTIFY(NM_CLICK, IDC_GRID_AOM, OnAOMGridClick)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_SAVE, &CDlgSelectedToolEdit::OnBnClickedBtnSave)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CDlgSelectedToolEdit::OnBnClickedBtnCancel)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamPath message handlers


BOOL CDlgSelectedToolEdit::OnInitDialog() 
{
	CDialog::OnInitDialog();


	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();


	for(int i = 1; i< 5; i++)
	{
		if( TRUE == m_bCheckBox[i])
			m_ChkSubBox[i].SetCheck(1);
		else
			m_ChkSubBox[i].SetCheck(0);
	}

	for(int i = 1; i< 3; i++)
	{
		if( TRUE == m_bGroupCheckBox[i])
			m_ChkGroupSubBox[i].SetCheck(1);
		else
			m_ChkGroupSubBox[i].SetCheck(0);
	}

	for(int i = 0; i < SHOT_GROUP_COUNT; i++)
		gVariable.m_sgShotGroupTable.bGroupSelectedList[i] = FALSE;

	gVariable.m_sgShotGroupTable.bGroupSelectedList[m_nGroupSelectRow-1] = TRUE;
	//m_GroupGrid.ResetSelectedRange();
	m_GroupGrid.SetFocusCell(1, 1);
	//m_Grid.ResetSelectedRange();
	m_Grid.SetFocusCell(1, 1);
	m_AOMGrid.SetFocusCell(1, 1);

	OnCheckRefresh();
	return TRUE;
}




void CDlgSelectedToolEdit::InitGrid()
{
	/*
	if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	{
		CRect rt;
		GetDlgItem(IDC_LIST_INFO)->GetWindowRect(rt);// GetWindowRect(rt);
		ScreenToClient(rt);
		m_Grid.Create(rt,this,0xffffff);

		CRect rt2;
		GetDlgItem(IDC_LIST_GROUP_INFO)->GetWindowRect(rt2);
		ScreenToClient(rt2);
		m_GroupGrid.Create(rt2,this,0xffffff);
	}
	*/
	m_Grid.SetEditable(TRUE);
	m_Grid.SetListMode(FALSE);
	m_Grid.EnableDragAndDrop(FALSE);
	m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	m_Grid.SetFixedRowCount(1);        //1���� ��
	m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����

	m_GroupGrid.SetEditable(TRUE);
	m_GroupGrid.SetListMode(FALSE);
	m_GroupGrid.EnableDragAndDrop(FALSE);
	m_GroupGrid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_GroupGrid.SetHeaderSort(FALSE);
	m_GroupGrid.SetSingleRowSelection(FALSE);
	m_GroupGrid.SetFixedRowCount(1);        //1���� ��
	m_GroupGrid.SetFixedColumnCount(1);    //1���� ��
	m_GroupGrid.SetRowResize(FALSE);		  //ũ�� ����
	m_GroupGrid.SetColumnResize(FALSE);	  //ũ�� ����

	m_AOMGrid.SetEditable(TRUE);
	m_AOMGrid.SetListMode(FALSE);
	m_AOMGrid.EnableDragAndDrop(FALSE);
	m_AOMGrid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_AOMGrid.SetHeaderSort(FALSE);
	m_AOMGrid.SetSingleRowSelection(FALSE);
	m_AOMGrid.SetFixedRowCount(1);        //1���� ��
	m_AOMGrid.SetFixedColumnCount(1);    //1���� ��
	m_AOMGrid.SetRowResize(FALSE);		  //ũ�� ����
	m_AOMGrid.SetColumnResize(FALSE);	  //ũ�� ����

	m_OpticGrid.SetEditable(TRUE);
	m_OpticGrid.SetListMode(FALSE);
	m_OpticGrid.EnableDragAndDrop(FALSE);
	m_OpticGrid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_OpticGrid.SetHeaderSort(FALSE);
	m_OpticGrid.SetSingleRowSelection(FALSE);
	m_OpticGrid.SetFixedRowCount(1);        //1���� ��
	m_OpticGrid.SetFixedColumnCount(1);    //1���� ��
	m_OpticGrid.SetRowResize(FALSE);		  //ũ�� ����
	m_OpticGrid.SetColumnResize(FALSE);	  //ũ�� ����
}
void CDlgSelectedToolEdit::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial");
	
	m_ChkGroupSubBox[1].SetFont( &m_fntBtn );
	m_ChkGroupSubBox[1].SetImageOrg( 10, 3 );
	m_ChkGroupSubBox[1].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkGroupSubBox[1].EnableBallonToolTip();
	m_ChkGroupSubBox[1].SetToolTipText( _T("Group Table 1") );
	m_ChkGroupSubBox[1].SetBtnCursor(IDC_HAND_1);
	m_ChkGroupSubBox[1].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_BEAMPATH );

	m_ChkGroupSubBox[2].SetFont( &m_fntBtn );
	m_ChkGroupSubBox[2].SetImageOrg( 10, 3 );
	m_ChkGroupSubBox[2].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkGroupSubBox[2].EnableBallonToolTip();
	m_ChkGroupSubBox[2].SetToolTipText( _T("Group Table 2") );
	m_ChkGroupSubBox[2].SetBtnCursor(IDC_HAND_1);
	m_ChkGroupSubBox[2].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_BEAMPATH );


	m_ChkSubBox[1].SetFont( &m_fntBtn );
	m_ChkSubBox[1].SetImageOrg( 10, 3 );
	m_ChkSubBox[1].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[1].EnableBallonToolTip();
	m_ChkSubBox[1].SetToolTipText( _T("Beam Path") );
	m_ChkSubBox[1].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[1].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_BEAMPATH );

	m_ChkSubBox[2].SetFont( &m_fntBtn );
	m_ChkSubBox[2].SetImageOrg( 10, 3 );
	m_ChkSubBox[2].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[2].EnableBallonToolTip();
	m_ChkSubBox[2].SetToolTipText( _T("Power Offset") );
	m_ChkSubBox[2].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[2].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_POWEROFFSET );

	m_ChkSubBox[3].SetFont( &m_fntBtn );
	m_ChkSubBox[3].SetImageOrg( 10, 3 );
	m_ChkSubBox[3].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[3].EnableBallonToolTip();
	m_ChkSubBox[3].SetToolTipText( _T("Power Compensation") );
	m_ChkSubBox[3].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[3].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_COMPENSATION );

	m_ChkSubBox[4].SetFont( &m_fntBtn );
	m_ChkSubBox[4].SetImageOrg( 10, 3 );
	m_ChkSubBox[4].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[4].EnableBallonToolTip();
	m_ChkSubBox[4].SetToolTipText( _T("Scanner Facts") );
	m_ChkSubBox[4].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[4].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_SCANNERFACTS );

	m_ChkSubBox[5].SetFont( &m_fntBtn );
	m_ChkSubBox[5].SetImageOrg( 10, 3 );
	m_ChkSubBox[5].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[5].EnableBallonToolTip();
	m_ChkSubBox[5].SetToolTipText( _T("Hole Facts") );
	m_ChkSubBox[5].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[5].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_HOLEFACTS );

	m_btnRefresh.SetFont( &m_fntBtn );
	m_btnRefresh.SetFlat( FALSE );
	m_btnRefresh.EnableBallonToolTip();
	m_btnRefresh.SetToolTipText( _T("Refresh") );
	m_btnRefresh.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRefresh.SetBtnCursor(IDC_HAND_1);


	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Refresh") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	m_btnDel.SetFont( &m_fntBtn );
	m_btnDel.SetFlat( FALSE );
	m_btnDel.EnableBallonToolTip();
	m_btnDel.SetToolTipText( _T("Refresh") );
	m_btnDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDel.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BTN_SAVE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_BTN_CANCEL)->SetFont( &m_fntBtn );


	m_btnUp.SetFont( &m_fntBtn );
	m_btnUp.SetFlat( FALSE );
	m_btnUp.EnableBallonToolTip();
	m_btnUp.SetToolTipText( _T("Refresh") );
	m_btnUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUp.SetBtnCursor(IDC_HAND_1);

	m_btnDown.SetFont( &m_fntBtn );
	m_btnDown.SetFlat( FALSE );
	m_btnDown.EnableBallonToolTip();
	m_btnDown.SetToolTipText( _T("Refresh") );
	m_btnDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDown.SetBtnCursor(IDC_HAND_1);

	m_btnGroupAdd.SetFont( &m_fntBtn );
	m_btnGroupAdd.SetFlat( FALSE );
	m_btnGroupAdd.EnableBallonToolTip();
	m_btnGroupAdd.SetToolTipText( _T("Refresh") );
	m_btnGroupAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGroupAdd.SetBtnCursor(IDC_HAND_1);

	m_btnGroupDel.SetFont( &m_fntBtn );
	m_btnGroupDel.SetFlat( FALSE );
	m_btnGroupDel.EnableBallonToolTip();
	m_btnGroupDel.SetToolTipText( _T("Refresh") );
	m_btnGroupDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGroupDel.SetBtnCursor(IDC_HAND_1);

	// parameter
	GetDlgItem(IDC_STATIC_OPTIC_TABLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SHOT_TABLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_AOM_TABLE)->SetFont( &m_fntBtn );
}
void CDlgSelectedToolEdit::InitStaticControl()
{

}
void CDlgSelectedToolEdit::InitEditControl()
{
	//m_editwnd.Create(WS_CHILD|ES_NOHIDESEL|ES_AUTOHSCROLL|WS_VISIBLE, CRect(0,0,0,0), this, IDC_EDIT_BOX);
	//m_editwnd.SetFont(GetFont(), FALSE);
	//m_editwnd.SetMargins(4,4);
	//	SetWindowLong(//m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);


}

void CDlgSelectedToolEdit::OnCheckBeamPath()
{

	m_bCheckBox[1] = !m_bCheckBox[1];
	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckPowerOffset()
{
	m_bCheckBox[2] = !m_bCheckBox[2];
	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckPowerCompensation()
{
	m_bCheckBox[3] = !m_bCheckBox[3];
	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckScannerFact()
{

}

void CDlgSelectedToolEdit::OnCheckGroupTable1()
{
	m_bGroupCheckBox[1] = !m_bGroupCheckBox[1];
	OnCheckRefresh();
}
void CDlgSelectedToolEdit::OnCheckGroupTable2()
{
	m_bGroupCheckBox[2] = !m_bGroupCheckBox[2];
	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckHoleFact()
{
	m_bCheckBox[1] = !m_bCheckBox[1];

	OnCheckRefresh();
}
void CDlgSelectedToolEdit::OnCheckRefresh()
{
	//m_editwnd.ShowWindow(SW_HIDE);

	DeleteOpticList();
	SetOpticDrawmember(0);//20170721
	DeleteGroupList();
	int nGrouplistcount = GetGroupListIndex();
	SetGroupDrawMember(nGrouplistcount);
	DeleteList();
	SetDrawMember(3);

	DeleteAOMList();
	int nAOMlistcount = GetAOMListIndex();
	SetAOMDrawMember(nAOMlistcount);
	UpdateGridSelNo();

	/*

	DeleteOpticList();
	SetOpticDrawmember(0);//20170721
	
	DeleteGroupList();
	int nGrouplistcount = GetGroupListIndex();
	SetGroupDrawMember(nGrouplistcount);


	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);


	DeleteAOMList();
	int nAOMlistcount = GetAOMListIndex();
	SetAOMDrawMember(nAOMlistcount);



	UpdateGridSelNo();
	*/
	Invalidate(FALSE);
}


void CDlgSelectedToolEdit::OnCheckRefresh2(int nShowNo)
{
	//m_editwnd.ShowWindow(SW_HIDE);

	if(nShowNo < 1)
	{
		DeleteGroupList();
		int nGrouplistcount = GetGroupListIndex();
		SetGroupDrawMember(nGrouplistcount);
	}

	if(nShowNo < 2)
	{
		DeleteList();
		int nlistcount = GetListIndex();
		SetDrawMember(nlistcount);
	}

	DeleteAOMList();
	int nAOMlistcount = GetAOMListIndex();
	SetAOMDrawMember(nAOMlistcount);


	UpdateGridSelNo();
	Invalidate(FALSE);
}

void CDlgSelectedToolEdit::InitListControl() 
{


	// ����Ʈ ��Ʈ�ѳ� �ѱ� �߰� ��ƾ 
	CFont m_Font;
	m_Font.CreateFont(12, 0,      // Height, Width
		0, 0,      // Escapement, Orientation
		FW_NORMAL, FALSE,              // Weight, Italic
		FALSE, FALSE,                // Underline, StrikeOut
		HANGEUL_CHARSET,                // Character Set
		OUT_DEFAULT_PRECIS,   // OutPrecision
		CLIP_DEFAULT_PRECIS,   // ClipPrecision
		DEFAULT_QUALITY,             // Quality
		DEFAULT_PITCH,               // PitchAndFamily
		"SYSTEM");  

//	m_list.SetFont(&m_Font);
	m_Font.DeleteObject();

//	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT|LVS_EX_INFOTIP|LVS_EX_CHECKBOXES);

	// ����Ʈ ��Ʈ�ѿ� �޺� �ڽ��� �־��µ� ù��° ���� �޺� �ڽ��� �׷��� ������ ������ ����Ʈ�� �ٿ� �ȵǾ���. �׷��� �ణ�� ������ ���� �÷� �ذ� �� ;;;(�ؿ� ���� )



	DeleteGroupList();
	int nGrouplistcount = GetGroupListIndex();
	SetGroupDrawMember(nGrouplistcount);

	CImageList image;
	image.Create(1, 23, ILC_COLORDDB, 1, 0); //���� ������ �ι�° �Ķ���� ���� ����
//	m_list.SetImageList(&image, LVSIL_SMALL); 

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);

	DeleteAOMList();
	int nAOMlistcount = GetAOMListIndex();
	SetAOMDrawMember(nAOMlistcount);

	Invalidate();


}

int CDlgSelectedToolEdit::GetListIndex()		//1: 1���̺� ���, 2: 2���̺� ���, 4: 3�� ���̺� ��� , 8 :4�� ���̺� ���, 16: 5�� ���̺� ��� 
{
	int nCount = 0;

	if(m_bCheckBox[0])
		nCount+=1;
	if(m_bCheckBox[1])
		nCount+=2;
	if(m_bCheckBox[2])
		nCount+=4;
	if(m_bCheckBox[3])
		nCount+=8;
	if(m_bCheckBox[4])
		nCount+=16;
	if(m_bCheckBox[5])
		nCount+=32;
	return nCount;

}
int CDlgSelectedToolEdit::GetGroupListIndex()		//1: 1���̺� ���, 2: 2���̺� ���, 4: 3�� ���̺� ��� , 8 :4�� ���̺� ���, 16: 5�� ���̺� ��� 
{
	int nCount = 0;

	if(m_bGroupCheckBox[0])
		nCount+=1;
	if(m_bGroupCheckBox[1])
		nCount+=2;
	if(m_bGroupCheckBox[2])
		nCount+=4;
	return nCount;

}

int CDlgSelectedToolEdit::GetAOMListIndex()		
{
	int nCount = 1;


	return nCount;

}
void CDlgSelectedToolEdit::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	


	COLORREF pColor = COLOR_GREEN;
	Gvitem.nState = NULL;

	int nUseCount = gVariable.m_sgShotGroupTable.nTotalShotCount[m_nGroupSelectRow-1]-1;

	if(nUseCount < ColCount)
	{
		pColor = COLOR_WHITE;
		Gvitem.nState = GVIS_READONLY;
	}
	BOOL bUseAom = gVariable.m_sgShotGroupTable.bUseAom[m_nGroupSelectRow-1];
	bUseAom = FALSE;

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;


		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nInfoId[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;

		
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));

		DWORD oldMask = Gvitem.mask;
		Gvitem.mask = GVIF_TEXT|GVIF_FORMAT;
		m_Grid.SetItem(&Gvitem);
		Gvitem.mask = oldMask;
		ColumnNo++;



	}
	if(TableNo == TABLE1)
	{
		Gvitem.row = ColCount + 1;
		//strData.Format(_T("%d"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[ColCount]);
		//Gvitem.strText = strData;
		//Gvitem.col = ColumnNo;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		////m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		//m_Grid.SetItem(&Gvitem);
		//if(bUseAom)
		//{
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		//	m_Grid.SetItemState(Gvitem.row, Gvitem.col, 0);
		//}
		//else
		//{
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_GREY);
		//	m_Grid.SetItemState(Gvitem.row, Gvitem.col, GVIS_READONLY);
		//}
		//
		//ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

		//strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[ColCount]);
		//Gvitem.strText = strData;
		//Gvitem.col = ColumnNo;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		////m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		//m_Grid.SetItem(&Gvitem);
		//if(bUseAom)
		//{
		//	if(gVariable.m_sgShotGroupTable.nFirstWaitMode[m_nGroupSelectRow-1])
		//	{
		//		if(Gvitem.row != 1)
		//			m_Grid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		//	}
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		//}
		//else
		//{
		//	m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_GREY);
		//	m_Grid.SetItemState(Gvitem.row, Gvitem.col, GVIS_READONLY);
		//}
		//
		//ColumnNo++;


		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		ColumnNo++;

		double dRefPower = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[ColCount];
		double dTol = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[ColCount];
		double dMin,dMax;

		gVariable.GetMinMaxPower(dRefPower,dTol,dMin,dMax);
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[ColCount] = dMax;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[ColCount] = dMin;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		m_Grid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor);
		m_Grid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		ColumnNo++;
	}

	if(TableNo == TABLE2)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOntimeOffset_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		m_Grid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOntimeOffset2_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;
	}

	m_Grid.AutoSize();
}

void CDlgSelectedToolEdit::InsertOpticGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	
	Gvitem.row = 1;

	strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
//	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, RGB(0xFF, 0xFF, 0xE0));
	ColumnNo++;


	strData.Format(_T("%s"), gVariable.m_sgBeamPath.strInfoName[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, RGB(0xFF, 0xFF, 0xE0));
	ColumnNo++;

	strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dInfoMaskSize[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, RGB(0xFF, 0xFF, 0xE0));
	ColumnNo++;	

	strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos1[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos2[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos3[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos4[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos1[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos2[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos1[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos2[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	strData.Format(_T("%s"),  gVariable.m_sgBeamPath.strBeamPathAscFile[ColCount]);
	Gvitem.strText = strData;
	Gvitem.col = ColumnNo;
	m_OpticGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
	m_OpticGrid.SetItem(&Gvitem);
	m_OpticGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	ColumnNo++;

	m_OpticGrid.AutoSize();
}

void CDlgSelectedToolEdit::InsertGroupGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����

	if(TableNo == TABLE0)
	{
		Gvitem.row = 0 + 1;

		gVariable.m_sgShotGroupTable.nGroupInfoId[ColCount] = ColCount;

		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nGroupInfoId[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));

		m_GroupGrid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%s"), gVariable.m_sgShotGroupTable.strInfoName[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, RGB(0xFF, 0xFF, 0xE0));
		m_GroupGrid.SetItem(&Gvitem);
		ColumnNo++;

	}
	/////////////////////////
	if(TableNo == TABLE1)
	{
		Gvitem.row = 0 + 1;


		//Tool Type
		int nToolType = gVariable.m_sgShotGroupTable.nToolType[ColCount];
		if(nToolType == MARKING_TYPE)
		{
			strData.Format(_T("%s"), "Marking");
		}
		else if(nToolType == SHOT_DRILL_TYPE)
		{
			strData.Format(_T("%s"), "Shot Drill");
		}
		else if(nToolType == TEXT_TYPE)
		{
			strData.Format(_T("%s"), "Text");
		}
		else if(nToolType == LINE_DRILL_TYPE) 
		{
			strData.Format(_T("%s"), "Line Drill");
		}
		else if(nToolType == FLYING_TYPE)
		{
			strData.Format(_T("%s"), "Flying Drill");
		}
		else if(nToolType == BARCODE_TYPE)
		{
			strData.Format(_T("%s"), "Barcode Drill");
		}

		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		CStringArray options;
		options.Add(_T("Marking"));
		options.Add(_T("Shot Drill"));
		options.Add(_T("Text"));
		options.Add(_T("Line Drill"));
		options.Add(_T("Flying Drill"));
		options.Add(_T("Barcode Drill"));

		CGridCellCombo *pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;



		//Shot Mode
		int nShotMode = gVariable.m_sgShotGroupTable.nShotMode[ColCount];
		if(nShotMode == 0)
		{
			strData.Format(_T("%s"), "Cycle");
		}
		else 
		{
			strData.Format(_T("%s"), "Burst");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		options.RemoveAll();

		options.Add(_T("Cycle"));
		options.Add(_T("Burst"));

		pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;


	//	//Shot Mode
	//	int nFirstWaitMode = gVariable.m_sgShotGroupTable.nFirstWaitMode[ColCount];
	//	if(nFirstWaitMode == 0)
	//	{
	//		strData.Format(_T("%s"), "NoUse");
	//	}
	//	else 
	//	{
	//		strData.Format(_T("%s"), "Use");
	//	}
	//	Gvitem.strText = strData;
	//	Gvitem.col = ColumnNo;
	//	m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
	//	//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
	//	options.RemoveAll();

	//	options.Add(_T("NoUse"));
	//	options.Add(_T("Use"));

	//	pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
	//	pCell->SetOptions(options);
	//	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	//	m_GroupGrid.SetItem(&Gvitem);
	//	m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	//	ColumnNo++;

	//	//Use Aom
	//	int bUseAom = gVariable.m_sgShotGroupTable.bUseAom[ColCount];
	//	if(bUseAom == 0)
	//	{
	//		strData.Format(_T("%s"), "NoUse");
	//	}
	//	else 
	//	{
	//		strData.Format(_T("%s"), "Use");
	//	}
	//	Gvitem.strText = strData;
	//	Gvitem.col = ColumnNo;
	//#ifdef __PKG_MODIFY__
	//	m_GroupGrid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
	//#endif
	//	m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
	//	//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
	//	options.RemoveAll();

	//	options.Add(_T("NoUse"));
	//	options.Add(_T("Use"));

	//	pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
	//	pCell->SetOptions(options);
	//	pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
	//	m_GroupGrid.SetItem(&Gvitem);
	//	m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
	//	ColumnNo++;

		//Dummy Type
		int nDummyType = gVariable.m_sgShotGroupTable.nDummyType[ColCount];
		if(nDummyType == DUMMY_NONE)
		{
			strData.Format(_T("%s"), "None");
		}
		else if(nDummyType == DUMMY_FIELD)
		{
			strData.Format(_T("%s"), "Field");
		}
		else if(nDummyType == DUMMY_ALL)
		{
			strData.Format(_T("%s"), "All");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		options.RemoveAll();

		options.Add(_T("None"));
		options.Add(_T("Field"));
		options.Add(_T("All"));

		pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		////Shot Min Frequency
		//strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nShotMinFrequency[ColCount]);
		//Gvitem.strText = strData;
		//Gvitem.col = ColumnNo;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		////m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		//m_GroupGrid.SetItem(&Gvitem);
		//if(bUseAom)
		//{
		//	m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		//	m_GroupGrid.SetItemState(Gvitem.row, Gvitem.col, 0);
		//}
		//else
		//{
		//	m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_GREY);
		//	m_GroupGrid.SetItemState(Gvitem.row, Gvitem.col, GVIS_READONLY);
		//}
		//ColumnNo++;

		//Shot Frequency
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nShotFrequency[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		//Shot Duty %
		strData.Format(_T("%.2f"),  gVariable.m_sgShotGroupTable.dShotDuty_Percent[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		int nFrq = gVariable.m_sgShotGroupTable.nShotFrequency[ColCount];//20160627
		double dPer = gVariable.m_sgShotGroupTable.dShotDuty_Percent[ColCount];
		double dTempLM_us = gVariable.GetLMDuty_us(nFrq,dPer);
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[ColCount] = dTempLM_us;

		//Shot LM
		strData.Format(_T("%.2f"),  gVariable.m_sgShotGroupTable.dShotLMDuty_us[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		m_GroupGrid.SetItemState(Gvitem.row, Gvitem.col,GVIS_READONLY);
		ColumnNo++;

		//Total Shot
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nTotalShotCount[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		//Burst Shot
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nBurstShotCount[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;



		////Votage M
		//strData.Format(_T("%.2f"),  gVariable.m_sgShotGroupTable.dVoltage_M[ColCount]);
		//Gvitem.strText = strData;
		//Gvitem.col = ColumnNo;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		////m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		//m_GroupGrid.SetItem(&Gvitem);
		//m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		//ColumnNo++;



		//Use Aperture
		BOOL bUseAperture = gVariable.m_sgShotGroupTable.bUseAperture[ColCount];
		if(bUseAperture == 0)
		{
			strData.Format(_T("%s"), "OFF");
		}
		else 
		{
			strData.Format(_T("%s"), "ON");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		options.RemoveAll();

		options.Add(_T("OFF"));
		options.Add(_T("ON"));

		pCell = (CGridCellCombo*) m_GroupGrid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		//Aperture Path
		strData.Format(_T("%s"),  gVariable.m_sgShotGroupTable.strAperturePath[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
				m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nTextSizeX[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nTextSizeY[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nCavityDrawInOffset[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nCavityDrawOutOffset[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		//m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;
	}

	if(TableNo == TABLE2)
	{

		Gvitem.row = 0 + 1;


		//Laser On Delay
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nLaserOnDelay[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

		//Laser Off Delay
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nLaserOffDelay[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

		//Draw Speed
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nDrawSpeed[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

		//Jump Speed
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nJumpSpeed[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;


		//Coner Delay
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nConerDelay[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

		//Jump Delay
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nJumpDelay[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

		//Line Delay
		strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.nLineDelay[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_GroupGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_GroupGrid.SetItem(&Gvitem);
		m_GroupGrid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;

	}



	m_GroupGrid.AutoSize();
}


void CDlgSelectedToolEdit::InsertAOMGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	GV_ITEM Gvitem1;
	GV_ITEM Gvitem2;

	COLORREF pColor1 = COLOR_GREEN;
	Gvitem1.nState = NULL;

	int nUseShotCount = gVariable.m_sgShotGroupTable.nTotalShotCount[m_nGroupSelectRow-1];

	int nUseCount = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[m_nSelectRow-1]-1;
	BOOL bUseAom = gVariable.m_sgShotGroupTable.bUseAom[m_nGroupSelectRow-1];

	if(nUseCount < ColCount || nUseShotCount ==0)
	{

		pColor1 = COLOR_WHITE;
		Gvitem1.nState = GVIS_READONLY;
	}
	if(!bUseAom)
	{
		pColor1 = COLOR_GREY;
	}

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;


		//strData.Format(_T("%d"),  gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].nInfoId[ColCount]);
		strData.Format(_T("%d"),  ColCount);


		
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;


		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));

		DWORD oldMask = Gvitem.mask;
		Gvitem.mask = GVIF_TEXT|GVIF_FORMAT;
		m_AOMGrid.SetItem(&Gvitem);
		Gvitem.mask = oldMask;
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_ON_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.nState = Gvitem1.nState;

		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_AOMGrid.SetItem(&Gvitem);
		m_AOMGrid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor1);
		if(bUseAom)
			m_AOMGrid.SetItemState(Gvitem.row, Gvitem.col, 0);
		else
			m_AOMGrid.SetItemState(Gvitem.row, Gvitem.col, GVIS_READONLY);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_OFF_M[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.nState = Gvitem1.nState;

		m_AOMGrid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell));
		m_AOMGrid.SetItem(&Gvitem);
		m_AOMGrid.SetItemBkColour(Gvitem.row, Gvitem.col, pColor1);
		if(bUseAom)
			m_AOMGrid.SetItemState(Gvitem.row, Gvitem.col, 0);
		else
			m_AOMGrid.SetItemState(Gvitem.row, Gvitem.col, GVIS_READONLY);
		ColumnNo++;

	}

	m_AOMGrid.AutoSize();
}





int CDlgSelectedToolEdit::GetColumnSize(int nStrlen)
{

	if( nStrlen < 3)
		nStrlen = (nStrlen * COLUMNWIDTH) + 25;
	else if(nStrlen < 6 )
		nStrlen *= ( COLUMNWIDTH -2);
	else
		nStrlen = (4 * COLUMNWIDTH) + 25 ;	

	return nStrlen;
}

void CDlgSelectedToolEdit::InsertListComumn(int startNo, int TableNo)
{





	int ColumnNo = startNo;
//	m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);



	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(SHOT_SELECT_TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < SHOT_SELECT_TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strTable0[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			if (i == 0)
				nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

			if ( i ==1 )
				nStrLen = 130;		// name �÷��� ������ 

			//m_list.InsertColumn(ColumnNo, strTable0[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strTable0[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}

	else if(TableNo == TABLE1)
	{
		m_Grid.SetColumnCount(m_nColumnCount + SHOT_SELECT_TABLE1_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < SHOT_SELECT_TABLE1_COLUMN_COUNT; i++)
		{	
			nSize = strTable1[i].GetLength();
			nStrLen = GetColumnSize( nSize);

//			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable1[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE2)
	{
		m_Grid.SetColumnCount(m_nColumnCount + SHOT_SELECT_TABLE2_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < SHOT_SELECT_TABLE2_COLUMN_COUNT; i++)
		{	
			nSize = strTable1[i].GetLength();
			nStrLen = GetColumnSize( nSize);

			//			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable1[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}


	else
	{
		//error
	}
}

void CDlgSelectedToolEdit::InsertOpticListComumn()
{
	int ColumnNo = 0;
	//	m_GroupList.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	m_OpticGrid.SetColumnCount(OPTIC_SELECT_TABLE0_COLUMN_COUNT);
	for(int i = 0 ;i < OPTIC_SELECT_TABLE0_COLUMN_COUNT; i++)  
	{
		nSize = strOpticTable0[i].GetLength();
		nStrLen = GetColumnSize(nSize);
		if (i == 0)
			nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

		if ( i ==1 )
			nStrLen = 130;		// name �÷��� ������ 

		//			m_GroupList.InsertColumn(ColumnNo, strGroupTable0[i], LVCFMT_CENTER, nStrLen );
		ColumnNo++;
		nStrLen = 0;

		GV_ITEM Item;
		Item.mask = GVIF_TEXT|GVIF_FORMAT;
		Item.nFormat = DT_LEFT|DT_WORDBREAK;
		Item.row = 0;
		Item.col = i;
		Item.strText = strOpticTable0[i];
		m_OpticGrid.SetItem(&Item);	
		m_OpticGrid.AutoSize();
		m_nOpticColumnCount++;
	}
}

void CDlgSelectedToolEdit::InsertGroupListComumn(int startNo, int TableNo)
{

	int ColumnNo = startNo;
//	m_GroupList.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_GroupGrid.SetColumnCount(SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strGroupTable0[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			if (i == 0)
				nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

			if ( i ==1 )
				nStrLen = 130;		// name �÷��� ������ 

//			m_GroupList.InsertColumn(ColumnNo, strGroupTable0[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strGroupTable0[i];
			m_GroupGrid.SetItem(&Item);	
			m_GroupGrid.AutoSize();
			m_nGroupColumnCount++;
		}
	}
	else if(TableNo == TABLE1)
	{
		m_GroupGrid.SetColumnCount(m_nGroupColumnCount + SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT);
		int nColumnCount = m_nGroupColumnCount;
		for(int i = 0 ;i < SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT; i++)
		{
			nSize = strGroupTable1[i].GetLength();
			nStrLen = GetColumnSize(nSize);

			//			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strGroupTable1[i];
			m_GroupGrid.SetItem(&Item);	
			m_GroupGrid.AutoSize();
			m_nGroupColumnCount++;
		}
	}
	else if(TableNo == TABLE2)
	{
		m_GroupGrid.SetColumnCount(m_nGroupColumnCount + SHOT_SELECT_GROUP_TABLE2_COLUMN_COUNT);
		int nColumnCount = m_nGroupColumnCount;
		for(int i = 0 ;i < SHOT_SELECT_GROUP_TABLE2_COLUMN_COUNT; i++)
		{
			nSize = strGroupTable2[i].GetLength();
			nStrLen = GetColumnSize(nSize);

			//			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strGroupTable2[i];
			m_GroupGrid.SetItem(&Item);	
			m_GroupGrid.AutoSize();
			m_nGroupColumnCount++;
		}
	}
	else
	{
		//error
	}
}


void CDlgSelectedToolEdit::InsertAOMListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_AOMGrid.SetColumnCount(SHOT_SELECT_AOM_TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < SHOT_SELECT_AOM_TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strAOMTable0[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			if (i == 0)
				nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

			if ( i ==1 )
				nStrLen = 130;		// name �÷��� ������ 

			//m_list.InsertColumn(ColumnNo, strTable0[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strAOMTable0[i];
			m_AOMGrid.SetItem(&Item);	
			m_AOMGrid.AutoSize();
			m_nAOMColumnCount++;
		}
	}
	else
	{
		//error
	}
}

void CDlgSelectedToolEdit::DeleteList()
{
	/*	CListCtrl &ctrllist = m_list;
	CHeaderCtrl	*pHeaderCtrl;

	pHeaderCtrl = ctrllist.GetHeaderCtrl();
	int nCount = pHeaderCtrl->GetItemCount();
	*/
	m_nColumnCount = 0;
	/*
	if( -1 ==nCount)
	{
	ErrMessage(_T("Header Column not exist"));
	return;
	}
	else if( 0 < nCount)
	{
	ctrllist.DeleteAllItems();
	for(int i = 0;i <nCount; i++)
	{
	ctrllist.DeleteColumn(0);
	}
	}
	*/
}
void CDlgSelectedToolEdit::DeleteGroupList()
{
	m_nGroupColumnCount = 0;
}
void CDlgSelectedToolEdit::DeleteAOMList()
{
	m_nAOMColumnCount = 0;
}
void CDlgSelectedToolEdit::DeleteOpticList()
{
	m_nOpticColumnCount = 0;
}

void CDlgSelectedToolEdit::SetDrawMember(int listcount)
{
	int i =0;
	//LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount == 2)
	{
		InsertListComumn(0, TABLE1);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			InsertGridValue(Item, 0, TABLE1, i);
		}

	}
	else if(listcount == 3) // 1, 2
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + SHOT_SELECT_TABLE0_COLUMN_COUNT,TABLE1);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + SHOT_SELECT_TABLE0_COLUMN_COUNT ,TABLE1, i);
		}
	}
	else if(listcount == 5) // 1,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + SHOT_SELECT_TABLE0_COLUMN_COUNT,TABLE2);


		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + SHOT_SELECT_TABLE0_COLUMN_COUNT ,TABLE2, i);

		}
	}

	else if(listcount == 7) // 1, 2,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + SHOT_SELECT_TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + SHOT_SELECT_TABLE0_COLUMN_COUNT + SHOT_SELECT_TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{


			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + SHOT_SELECT_TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + SHOT_SELECT_TABLE0_COLUMN_COUNT + SHOT_SELECT_TABLE1_COLUMN_COUNT ,TABLE2, i);
		}
	}

	CRect rect;
	m_Grid.GetWindowRect(&rect);
	int nWidth = 0;
	for(int i = 0; i <m_Grid.GetColumnCount(); i++)
	{
	nWidth += m_Grid.GetColumnWidth(i);
	}

	if(nWidth == 0)
	nWidth = rect.Width();
	m_Grid.SetWindowPos(NULL, 0, 0, nWidth + 20, rect.Height(), SWP_NOMOVE);


}
void CDlgSelectedToolEdit::SetOpticDrawmember(int listcount)
{
	int i = 0;
	//LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	InsertOpticListComumn();
	m_OpticGrid.SetRowCount(2);

	int nSelectOpticTableNo = m_nSelectedTool;
	InsertOpticGridValue(Item, 0, TABLE0, nSelectOpticTableNo);
	
	CRect rect;
	CRect WindowRect;
	this->GetWindowRect(WindowRect);
	m_OpticGrid.GetWindowRect(&rect);
	int nWidth = 0;
	for(int i = 0; i <m_OpticGrid.GetColumnCount(); i++)
	{
		nWidth += m_OpticGrid.GetColumnWidth(i);
	}

	if(nWidth == 0)
		nWidth = rect.Width();
	if(nWidth > WindowRect.Width())
		nWidth = WindowRect.Width() - 5;

	m_OpticGrid.SetWindowPos(NULL, 0, 0, nWidth + 5, rect.Height(), SWP_NOMOVE);
}

void CDlgSelectedToolEdit::SetGroupDrawMember(int listcount)
{
	int i = 0;
	//LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //0
	{
		InsertGroupListComumn(0,TABLE0);
		for( i = m_nGroupRepeatCount ; i >= 0 ;i--)
		{


			m_GroupGrid.SetRowCount(2 + m_nGroupRepeatCount);
			InsertGroupGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount == 3) //0,1
	{
		InsertGroupListComumn(0,TABLE0);
		InsertGroupListComumn(0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT,TABLE1);

	//	for( i = m_nGroupRepeatCount ; i >= 0 ;i--)
	//	{
			m_GroupGrid.SetRowCount(2);
			
			InsertGroupGridValue(Item, 0, TABLE0, gVariable.m_sgBeamPath.nSelectShot[m_nSelectedTool]);
			InsertGroupGridValue(Item, 0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT ,TABLE1, gVariable.m_sgBeamPath.nSelectShot[m_nSelectedTool]);// 3�� �÷� ���� ���� 

	//	}
	}
	else if(listcount ==5) //0,2
	{
		InsertGroupListComumn(0,TABLE0);
		InsertGroupListComumn(0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT,TABLE2);

		for( i = m_nGroupRepeatCount ; i >= 0 ;i--)
		{

			m_GroupGrid.SetRowCount(2 + m_nGroupRepeatCount);
			InsertGroupGridValue(Item, 0, TABLE0, i);
			InsertGroupGridValue(Item, 0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT ,TABLE2, i);
		}
	}
	else if(listcount == 7)  //0,1,2
	{
		InsertGroupListComumn(0,TABLE0);
		InsertGroupListComumn(0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT,TABLE1);
		InsertGroupListComumn(0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT +SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nGroupRepeatCount ; i >= 0 ;i--)
		{

			m_GroupGrid.SetRowCount(2 + m_nGroupRepeatCount);
			InsertGroupGridValue(Item, 0, TABLE0, i);
			InsertGroupGridValue(Item, 0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGroupGridValue(Item, 0 + SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT +SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT ,TABLE2, i);
		}
	}
	/*CRect rect;
	CRect WindowRect;
	this->GetWindowRect(WindowRect);
	m_GroupGrid.GetWindowRect(&rect);
	int nWidth = 0;
	for(int i = 0; i <m_GroupGrid.GetColumnCount(); i++)
	{
	nWidth += m_GroupGrid.GetColumnWidth(i);
	}

	if(nWidth == 0)
	nWidth = rect.Width();
	if(nWidth > WindowRect.Width())
	nWidth = WindowRect.Width() - 20;

	m_GroupGrid.SetWindowPos(NULL, 0, 0, nWidth + 20, rect.Height(), SWP_NOMOVE);*/
}

void CDlgSelectedToolEdit::SetAOMDrawMember(int listcount)
{
	int i = 0;
	//LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertAOMListComumn(0,TABLE0);
		for( i = m_nAOMRepeatCount ; i >= 0 ;i--)
		{
			m_AOMGrid.SetRowCount(2 + m_nAOMRepeatCount);
			InsertAOMGridValue(Item, 0, TABLE0, i);
		}

	}

}


void CDlgSelectedToolEdit::SetOpticTable(SBEAMPATH sOpticTable)
{
	memcpy( &gVariable.m_sgBeamPath, &sOpticTable, sizeof(gVariable.m_sgBeamPath) );
}

void CDlgSelectedToolEdit::GetOpticTable(SBEAMPATH* pOpticTable)
{
	memcpy( pOpticTable, &gVariable.m_sgBeamPath, sizeof(gVariable.m_sgBeamPath) );
}

void CDlgSelectedToolEdit::SetShotGroupTable(SSHOTGROUPTABLE sShotGroupTable)
{
	memcpy( &gVariable.m_sgShotGroupTable, &sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );	
	m_nGroupRepeatCount= gVariable.m_sgShotGroupTable.nGroupLastIndex ;	

	m_nGroupSelectRow = 1;
	m_nRepeatCount= gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nLastIndex;
	m_nSelectRow = 1;

	m_nAOMRepeatCount = AOM_COUNT -1;

}

void CDlgSelectedToolEdit::GetShotGroupTable(SSHOTGROUPTABLE* pShotGroupTable)
{
	gVariable.m_sgShotGroupTable.nGroupLastIndex = m_nGroupRepeatCount;	//����Ʈ�� �� ������ �ε��� ���� 
	memcpy( pShotGroupTable, &gVariable.m_sgShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );
}
void CDlgSelectedToolEdit::OnClickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;



	*pResult = 0;
}
void CDlgSelectedToolEdit::OnClickGroupList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;



	*pResult = 0;
}
BOOL CDlgSelectedToolEdit::PreTranslateMessage(MSG* pMsg) 
{
	if( WM_KEYDOWN == pMsg->message )
	{
		switch( pMsg->wParam )
		{
		case VK_RETURN :
		case VK_SPACE :
			{
				if(GetFocus()->m_hWnd == this->m_hWnd)
					pMsg->wParam = 0;
			}
			break;
		//case VK_ESCAPE :
		//	pMsg->wParam = 0;
		//	break;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}


void CDlgSelectedToolEdit::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nInfoId[yPos] = atoi(str);
	}
	else if(xPos ==1 )
	{

	}

}

void CDlgSelectedToolEdit::FillGroupTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
	{
		gVariable.m_sgShotGroupTable.nGroupInfoId[yPos] = atoi(str);
	}
	else if(xPos ==1 )
	{
		strcpy_s(gVariable.m_sgShotGroupTable.strInfoName[yPos], str);
	}

}

void CDlgSelectedToolEdit::FillGroupTable1Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;
	int nTemp;
	double dTemp;
	if(xPos == 0)
	{
		if(strcmp(str, "Marking") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 0;
		else if(strcmp(str, "Shot Drill") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 1;
		else if(strcmp(str, "Text") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 2;
		else if(strcmp(str, "Line Drill") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 3;
		else if(strcmp(str, "Flying Drill") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 4;
		else if(strcmp(str, "Barcode Drill") == 0)
			gVariable.m_sgShotGroupTable.nToolType[yPos] = 5;
	}
	else if(xPos ==1 )
	{
		if(strcmp(str, "Cycle") == 0)
			gVariable.m_sgShotGroupTable.nShotMode[yPos] = 0;
		else 
			gVariable.m_sgShotGroupTable.nShotMode[yPos] = 1;
	}
	/*else if(xPos == 2 )
	{
		if(strcmp(str, "NoUse") == 0)
			gVariable.m_sgShotGroupTable.nFirstWaitMode[yPos] = 0;
		else 
			gVariable.m_sgShotGroupTable.nFirstWaitMode[yPos] = 1;
	}
	else if(xPos == 3 )
	{
		if(strcmp(str, "NoUse") == 0)
			gVariable.m_sgShotGroupTable.bUseAom[yPos] = 0;
		else 
			gVariable.m_sgShotGroupTable.bUseAom[yPos] = 1;
	}*/
	if(xPos == 2)
	{
		if(strcmp(str, "None") == 0)
			gVariable.m_sgShotGroupTable.nDummyType[yPos] = 0;
		else if(strcmp(str, "Field") == 0)
			gVariable.m_sgShotGroupTable.nDummyType[yPos] = 1;
		else 
			gVariable.m_sgShotGroupTable.nDummyType[yPos] = 2;
	}
	//else if(xPos == 5)
	//{
	//	nTemp =  atoi(str);
	//	if(nTemp < 0 || nTemp > 10000 )
	//	{
	//		ErrMessage(_T(" Shot Min Frequecy : 0 < Shot Min Frequecy < 10000"));
	//		return;
	//	}

	//	gVariable.m_sgShotGroupTable.nShotMinFrequency[yPos] = atoi(str);

	//	//double dTempLM_us = gVariable.GetLMDuty_us(nTemp,gVariable.m_sgShotGroupTable.dShotDuty_Percent[yPos]);//20160627
	//	//gVariable.m_sgShotGroupTable.dShotLMDuty_us[yPos] = dTempLM_us;

	//}
	else if(xPos == 3)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 10000 )
		{
			ErrMessage(_T(" Shot Frequecy : 0 < Shot Frequecy < 10000"));
			return;
		}
		
		gVariable.m_sgShotGroupTable.nShotFrequency[yPos] = atoi(str);

		double dTempLM_us = gVariable.GetLMDuty_us(nTemp,gVariable.m_sgShotGroupTable.dShotDuty_Percent[yPos]);//20160627
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[yPos] = dTempLM_us;

	}
	else if(xPos == 4)
	{
		dTemp =  atof(str);
		/*if(dTemp < 0 || dTemp > 9 )
		{
			ErrMessage( _T(" Duty Limit Percent : 0 < Duty Limit < 9"));
			return FALSE;
		}*/
		gVariable.m_sgShotGroupTable.dShotDuty_Percent[yPos] = atof(str);

		double dTempLM_us = gVariable.GetLMDuty_us(gVariable.m_sgShotGroupTable.nShotFrequency[yPos],dTemp);//20160627
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[yPos] = dTempLM_us;
	}
	else if(xPos == 5)
	{
		/*
		dTemp =  atof(str);
		if(dTemp < 0 || dTemp > 26 )
		{
			ErrMessage( _T(" LM Duty us : 0 < LM Duty < 26"));
			return FALSE;
		}
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[yPos] = atoi(str);
		*/
	}


	else if(xPos == 6)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			ErrMessage(_T(" Total Shot Count : 0 < Total Shot Count < 255"));
			return;
		}
		gVariable.m_sgShotGroupTable.nTotalShotCount[yPos] = atoi(str);
	}
	else if(xPos == 7)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			ErrMessage(_T(" Burst Shot Count : 0 < Burst Shot Count < 255"));
			return;
		}
		gVariable.m_sgShotGroupTable.nBurstShotCount[yPos] = atoi(str);
	}

	/*else if(xPos == 8)
	{
	dTemp =  atof(str);
	if(dTemp < 0 || dTemp > 255 )
	{
	ErrMessage( _T(" Voltage_M Range : 0 < Voltage_M < 255"));
	return;
	}
	gVariable.m_sgShotGroupTable.dVoltage_M[yPos] = atof(str);
	}*/

	else if(xPos == 8)
	{

		if(strcmp(str, "ON") == 0)
			gVariable.m_sgShotGroupTable.bUseAperture[yPos] = 1;
		else 
			gVariable.m_sgShotGroupTable.bUseAperture[yPos] = 0;


	}
	else if(xPos == 9 )
	{
		strcpy_s(gVariable.m_sgShotGroupTable.strAperturePath[yPos], str);
	}
	else if(xPos == 10)
	{
		dTemp =  atoi(str);

		gVariable.m_sgShotGroupTable.nTextSizeX[yPos] = atoi(str);
	}
	else if(xPos == 11)
	{
		dTemp =  atoi(str);

		gVariable.m_sgShotGroupTable.nTextSizeY[yPos] = atoi(str);
	}
	else if(xPos == 12)
	{
		dTemp =  atoi(str);

		gVariable.m_sgShotGroupTable.nCavityDrawInOffset[yPos] = atoi(str);
	}
	else if(xPos == 13)
	{
		dTemp =  atoi(str);

		gVariable.m_sgShotGroupTable.nCavityDrawOutOffset[yPos] = atoi(str);
	}

}
void CDlgSelectedToolEdit::FillGroupTable2Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;
	int nTemp;

	if(xPos == 0)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" On Delay Range : 0 < On Delay < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nLaserOnDelay[yPos] = atoi(str);
	}
	else if(xPos ==1 )
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Off Delay Range : 0 < Off Delay < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nLaserOffDelay[yPos] = atoi(str);
	}
	else if(xPos == 2)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Draw Speed Range : 0 < Draw Speed < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nDrawSpeed[yPos] = atoi(str);
	}
	else if(xPos == 3)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Jump Speed Range : 0 < Jump Speed < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nJumpSpeed[yPos] = atoi(str);
	}
	else if(xPos == 4)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Corner Delay Range : 0 < Corner Delay < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nConerDelay[yPos] = atoi(str);
	}
	else if(xPos == 5)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Jump Delay Range : 0 < Jump Delay < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nJumpDelay[yPos] = atoi(str);
	}
	else if(xPos == 6)
	{
		nTemp =  atoi(str);
		if(nTemp < 0 || nTemp > 255 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Line Delay Range : 0 < Line Delay < 255"));
			return ;
		}
		gVariable.m_sgShotGroupTable.nLineDelay[yPos] = atoi(str);
	}
}

void CDlgSelectedToolEdit::FillTable1Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	double	dTemp;
	double dMax = 0;
	double dMin = 0;

	//if(xPos == 0)
	//{


	//	dTemp =  atof(str);
	//	if(dTemp < 0 || dTemp > 255 )
	//	{
	//		//MultiMessageDlg(STDMESSAGE544, _T(" AOM Num_M Range : 0 < AOM Num_M < 255"));
	//		return ;
	//	}
	//	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[yPos] = atoi(str);

	//}
	if(xPos == 0)
	{
		dTemp =  atoi(str);
		if(dTemp < 0 || dTemp > 28 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Ontime [1] Range : 0 < Ontime < 28"));
			return ;
		}
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[yPos] = atof(str);
	}
	if(xPos == 1)
	{
		dTemp =  atoi(str);
		if(dTemp < 0 || dTemp > 28 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Ontime [1] Range : 0 < Ontime < 28"));
			return ;
		}
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[yPos] = atof(str);
	}
	//else if(xPos == 2)
	//{
	//	dTemp =  atof(str);
	//	if(dTemp < 0 || dTemp > 255 )
	//	{
	//		//MultiMessageDlg(STDMESSAGE544, _T(" AOM Wait Range : 0 < AOM Wait < 255"));
	//		return ;
	//	}
	//	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[yPos] = atof(str);
	//}



	else if(xPos == 2)
	{
		dTemp =  atof(str);
		if(dTemp < 0 || dTemp > 100 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Power Range : 0 < Power < 100"));
			return ;
		}
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[yPos] = atof(str);

		gVariable.GetMinMaxPower(dTemp,gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[yPos],dMin,dMax);//20160627

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[yPos] = dMax;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[yPos] = dMin;
	}
	else if(xPos == 3)
	{
		dTemp =  atof(str);
		if(dTemp < 0 || dTemp > 50 )
		{
			//MultiMessageDlg(STDMESSAGE544, _T(" Power Tol Range : 0 < Power Tol < 50"));
			return ;
		}
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[yPos] = atof(str);

		gVariable.GetMinMaxPower(gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[yPos],dTemp,dMin,dMax);//20160627

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[yPos] = dMax;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[yPos] = dMin;

	}


}

void CDlgSelectedToolEdit::FillTable2Data(int x, int y, CString str)
{


}

void CDlgSelectedToolEdit::FillOpticTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;
	double dTemp = 0;
	int	   nTemp = 0;

	if(xPos == 0)
		gVariable.m_sgBeamPath.nInfoId[yPos] = atoi(str);
	else if(xPos ==1 )
		strcpy_s(gVariable.m_sgBeamPath.strInfoName[yPos], str);
	else if(xPos == 2)
		gVariable.m_sgBeamPath.dInfoMaskSize[yPos] = atof(str);
	else if(xPos ==3)
		gVariable.m_sgBeamPath.dBeamPathBetPos1[yPos] = atof(str);
	else if(xPos ==4 )
		gVariable.m_sgBeamPath.dBeamPathBetPos2[yPos] = atof(str);
	else if(xPos ==5 )
		gVariable.m_sgBeamPath.dBeamPathBetPos3[yPos] = atof(str);
	else if(xPos ==6 )
		gVariable.m_sgBeamPath.dBeamPathBetPos4[yPos] = atof(str);
	else if(xPos == 7)
	{
		nTemp = atoi(str);
		if(nTemp < 0 || nTemp >= 3600 )
		{
			AfxMessageBox(_T("Mask range : 0 <= Mask < 3600"));
			return ;
		}
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[yPos] = atoi(str);
	}
	else if(xPos == 8 )
	{
		nTemp = atoi(str);
		if(nTemp < 0 || nTemp >= 3600 )
		{
			AfxMessageBox(_T("Mask range : 0 <= Mask < 3600"));	
			return ;
		}

		gVariable.m_sgBeamPath.nBeamPathMaskPos2[yPos] = atoi(str);
	}
	
	else if(xPos == 9)
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[yPos] = atof(str);
	else if(xPos == 10)
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[yPos] = atof(str);
	else if(xPos == 11)
		strcpy_s(gVariable.m_sgBeamPath.strBeamPathAscFile[yPos], str);	

}


void CDlgSelectedToolEdit::FillAOMTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].nInfoId[yPos] = atoi(str);
	}
	else if(xPos ==1 )
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_ON_M[yPos] = atof(str);
	}
	else if(xPos ==2 )
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].dAOM_OFF_M[yPos] = atof(str);
	}


}


void CDlgSelectedToolEdit::ListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetListIndex();

	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(listcount == 0)
	{
		return ;
	}
	else if(listcount == 1) //1
	{
		FillTable0Data(xPos,yPos, str);	
	}

	else if( listcount == 2) // 32
	{
		FillTable1Data(xPos,yPos, str);
	}

	else  if(listcount == 3) //1,32
	{
		if(xPos < SHOT_SELECT_TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= SHOT_SELECT_TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);
		}
	}
	else  if(listcount == 5) //1,32
	{
		if(xPos < SHOT_SELECT_TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= SHOT_SELECT_TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);
		}
	}
	else if(listcount == 7) //0,1,2
	{

		if(xPos < SHOT_SELECT_TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(SHOT_SELECT_TABLE0_COLUMN_COUNT <= xPos && xPos <SHOT_SELECT_TABLE0_COLUMN_COUNT + SHOT_SELECT_TABLE1_COLUMN_COUNT)
		{
			xPos -= SHOT_SELECT_TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=SHOT_SELECT_TABLE0_COLUMN_COUNT + SHOT_SELECT_TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}

	}
}
void CDlgSelectedToolEdit::OpticListUpdate(CPoint ClickedPos, CString str)
{
	int xPos = ClickedPos.x;
	int nOpticTableNo = m_nSelectedTool;
	int yPos = nOpticTableNo;

	FillOpticTable0Data(xPos, yPos, str);
}

void CDlgSelectedToolEdit::GroupListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetGroupListIndex();
	int nShotTableNo = gVariable.m_sgBeamPath.nSelectShot[m_nSelectedTool];

	int xPos = ClickedPos.x;
	int yPos = nShotTableNo;

	if(listcount == 0)
	{
		return ;
	}
	else if(listcount == 1) //0
	{
		FillGroupTable0Data(xPos,yPos, str);	
	}
	else if(listcount == 2) //1
	{
		FillGroupTable1Data(xPos,yPos, str);	
	}

	else  if(listcount == 3) //0,1
	{
		if(xPos < SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT)
			FillGroupTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT;
			FillGroupTable1Data(xPos,yPos, str);
		}
	}
	else if(listcount == 4) //2
	{
		FillGroupTable2Data(xPos,yPos, str);	
	}
	else if(listcount == 5) //0,2
	{
		if(xPos < SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT)
			FillGroupTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT;
			FillGroupTable2Data(xPos,yPos, str);
		}
	}
	else if(listcount == 7) //0,1,2
	{

		if(xPos < SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT)
			FillGroupTable0Data(xPos,yPos, str);	
		else if(SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT <= xPos && xPos <SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT + SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT)
		{
			xPos -= SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT;
			FillGroupTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=SHOT_SELECT_GROUP_TABLE0_COLUMN_COUNT + SHOT_SELECT_GROUP_TABLE1_COLUMN_COUNT;
			FillGroupTable2Data(xPos,yPos,str);
		}

	}

}


void CDlgSelectedToolEdit::AOMListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetAOMListIndex();


	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(listcount == 0)
	{
		return ;
	}
	else if(listcount == 1) //0
	{
		FillAOMTable0Data(xPos,yPos, str);	
	}
}
BOOL CDlgSelectedToolEdit::ValidateGroupValue()
{
	CString strMsg = _T("");
//	for(int i = 0 ;i <= m_nGroupRepeatCount; i++)

	int nGroup = m_nGroupSelectRow-1;
	{
		if(gVariable.m_sgShotGroupTable.dVoltage_M[nGroup] < 0.0 || gVariable.m_sgShotGroupTable.dVoltage_M[nGroup] > 100.0)
		{
			strMsg.Format(_T("[%d]Shot 0.0 < Master AOM Voltage < 100.0"), nGroup);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(gVariable.m_sgShotGroupTable.dVoltage_S[nGroup] < 0.0 || gVariable.m_sgShotGroupTable.dVoltage_S[nGroup] > 100.0)
		{
			strMsg.Format(_T("[%d]Shot 0.0 < Slave AOM Voltage < 100.0"), nGroup);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(gVariable.m_sgShotGroupTable.nTotalShotCount[nGroup] < 1 || gVariable.m_sgShotGroupTable.nTotalShotCount[nGroup] > 15)
		{
			strMsg.Format(_T("[%d]Shot 1 <= Total Shot Count <= 15"), nGroup);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(gVariable.m_sgShotGroupTable.nBurstShotCount[nGroup] < 0 || gVariable.m_sgShotGroupTable.nBurstShotCount[nGroup] > gVariable.m_sgShotGroupTable.nTotalShotCount[nGroup])
		{
			strMsg.Format(_T("[%d]Shot 0 <= Burst Shot Count <= %d"), nGroup, gVariable.m_sgShotGroupTable.nTotalShotCount[nGroup]);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(!ValidateShotValue(nGroup))
		{
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CDlgSelectedToolEdit::ValidateShotValue(int nGroup)
{
	double dLimit = 0;
	CString strMsg = _T("");
	for(int i = 0 ;i <= gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nLastIndex; i++)
	{
		if(gVariable.m_sgShotGroupTable.nTotalShotCount[nGroup] < i)//20160628
			continue;
		/*
		dLimit = (1000000./(double)gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nFrqeuncy[i]) * (double)gProcessINI.m_sProcessPowerMeasure.nCompensationDutyLimitPercent / 100;//20160625 Check
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dDuty[i] < 1 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dDuty[i] > dLimit)
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 1us < duty < %dus"), nGroup, i, dLimit);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		*/
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i] > 100)
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0Watt < Shot Power < 100Watt"), nGroup, i);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i] > 100)
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0Watt < Shot Power Tolerance < 100 %"), nGroup, i);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}

		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i] > 10)
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0 <= Master AOM Number <= 10"), nGroup, i);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		else
		{
		
			/*
			double dAomParamSum = 0;
			for(int j = 0; j < gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i]; j++)
			{
				dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].m_sAOMParam[i].dAOM_ON_M[j];
				dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].m_sAOMParam[i].dAOM_OFF_M[j];
			}
			//dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i];//20160625
			if(dAomParamSum > gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime[i])
			{
				strMsg.Format(_T("[%d]Shot [%d]Pulse All Master AOM Parameter's sum(%.1f) is over duty(%.1f)"), nGroup, i, dAomParamSum, gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime[i]);
				//MultiMessageDlg(STDMESSAGE544, strMsg);
				return FALSE;
			}
			*/
	
		}
		/*
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i] > gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i])
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0us <= Master AOM Wait <= %.1fus"), nGroup, i, gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i]);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		*/
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i] > 10)
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0 <= Slave AOM Number <= 10"), nGroup, i);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		else
		{
			/*
			double dAomParamSum = 0;
			for(int j = 0; j < gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i]; j++)
			{
				dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].m_sAOMParam[i].dAOM_ON_S[j];
				dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].m_sAOMParam[i].dAOM_OFF_S[j];
			}
			//dAomParamSum += gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i];//20160625
			if(dAomParamSum > gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i])
			{
				strMsg.Format(_T("[%d]Shot [%d]Pulse 0 <= Slave AOM Number <= 5"), nGroup, i);
				//MultiMessageDlg(STDMESSAGE544, strMsg);
				return FALSE;
			}
			*/
		}
		/*
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i] < 0 || gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i] > gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i])
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse 0us <= Slave AOM Wait <= %.1fus"), nGroup, i, gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i]);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		*/
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMax_M[i] < gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i])
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse %.3f <= Master Target Power Max"), nGroup, i, gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i]);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}
		if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMin_M[i] > gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i])
		{
			strMsg.Format(_T("[%d]Shot [%d]Pulse  Master Target Power Min <= %.3f"), nGroup, i, gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i]);
			//MultiMessageDlg(STDMESSAGE544, strMsg);
			return FALSE;
		}

	}
	return TRUE;
}

void CDlgSelectedToolEdit::SaveChangeValue(int nGroup)
{
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangegroupTable_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}

	TRY
	{
		file.SeekToEnd();

		strDetail = _T("----------------------------------------------------------------------------------------------\n");
		file.Write(strDetail, strDetail.GetLength());

		strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
		file.Write(strDetail, strDetail.GetLength());

		for(int i = 0 ;i <= gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nLastIndex; i++)
		{
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nInfoId[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nInfoId[i])
			{
				str.Format(_T("%d Info ID : %d -> %d\n"), i,gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nInfoId[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nInfoId[i]);
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i])
			{
				str.Format(_T("%d Ontime[1] : %.2f -> %.2f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_M[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i])
			{
				str.Format(_T("%d Ontime[1] : %.2f -> %.2f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dOnTime_S[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dRefPower[i])
			{
				str.Format(_T("%d dPower : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dRefPower[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dRefPower[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i])
			{
				str.Format(_T("%d dPower Tol : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dPower_Tol[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i])
			{
				str.Format(_T("%d dAOMNum_M : %d -> %d\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_M[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i])
			{
				str.Format(_T("%d dAOMWait_M : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_M[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i])
			{
				str.Format(_T("%d dAOMNum_S : %d -> %d\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].nAOMNum_S[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i])
			{
				str.Format(_T("%d dAOMWait_S : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dAOMWait_S[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMax_M[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dTargetMax_M[i])
			{
				str.Format(_T("%d dTargetMax_M : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dTargetMax_M[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMax_M[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMin_M[i] != gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dTargetMin_M[i])
			{
				str.Format(_T("%d dTargetMin_M : %.3f -> %.3f\n"), i,  gShotTableINI.m_sShotGroupTable.m_sShotParam[nGroup].dTargetMin_M[i], gVariable.m_sgShotGroupTable.m_sShotParam[nGroup].dTargetMin_M[i] );
				file.Write(str, str.GetLength());
			}

		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		file.Close();
		return;
	}
	END_CATCH

		file.Close();
}
void CDlgSelectedToolEdit::SaveChangeGroupValue()
{
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeShotGroupTable_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}

	TRY
	{
		file.SeekToEnd();

		strDetail = _T("----------------------------------------------------------------------------------------------\n");
		file.Write(strDetail, strDetail.GetLength());

		strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
		file.Write(strDetail, strDetail.GetLength());


		for(int i = 0 ;i <= m_nGroupRepeatCount; i++)
		{
			if(gVariable.m_sgShotGroupTable.nGroupInfoId[i] != gShotTableINI.m_sShotGroupTable.nGroupInfoId[i])
			{
				str.Format(_T("%d Info ID : %d -> %d\n"), i,gShotTableINI.m_sShotGroupTable.nGroupInfoId[i], gVariable.m_sgShotGroupTable.nGroupInfoId[i]);
				file.Write(str, str.GetLength());

				SaveChangeValue(i);
			}



		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		file.Close();
		return;
	}
	END_CATCH

		file.Close();
}





CString CDlgSelectedToolEdit::GetChangeGroupValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));



	for(int i = 0 ;i <= m_nGroupRepeatCount; i++)
	{
		strTemp.Format(_T(""));
		if(strcmp(gVariable.m_sgShotGroupTable.strInfoName[i], gShotTableINI.m_sShotGroupTable.strInfoName[i]) !=0)
		{
			strTemp.Format(_T(",%s "),gVariable.m_sgShotGroupTable.strInfoName[i] );
		}
		strMessage += strTemp;


		for(int j = 0 ;j <= m_nRepeatCount; j++)
		{
			if( gVariable.m_sgShotGroupTable.m_sShotParam[i].nInfoId[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nInfoId[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dOnTime_M[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_M[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dOnTime_S[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_S[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dRefPower[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dRefPower[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dPower_Tol[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dPower_Tol[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].nAOMNum_M[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_M[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dAOMWait_M[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_M[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].nAOMNum_S[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_S[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dAOMWait_S[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_S[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dTargetMax_M[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMax_M[j]||
				gVariable.m_sgShotGroupTable.m_sShotParam[i].dTargetMin_M[j] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMin_M[j])
			{
				strTemp.Format(_T("| Origin Count: %d, %d : %d ( %.3f, %.3f,%.3f,%.3f,%d,%.3f,%d,%.3f,%.3f,%.3f"), 
					i,
					j,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nInfoId[j],
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_M[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_S[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dRefPower[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dPower_Tol[j] ,

					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_M[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_M[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_S[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_S[j] ,

					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMax_M[j] ,
					gShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMin_M[j]);

				strMessage += strTemp;

				strTemp.Format(_T("| Group Count: %d, %d :  %d ( %.3f, %.3f,%.3f,%.3f,%d,%.3f,%d,%.3f,%.3f,%.3f"), 
					i,
					j,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].nInfoId[j],
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dOnTime_M[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dOnTime_S[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dRefPower[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dPower_Tol[j] ,

					gVariable.m_sgShotGroupTable.m_sShotParam[i].nAOMNum_M[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dAOMWait_M[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].nAOMNum_S[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dAOMWait_S[j] ,

					gVariable.m_sgShotGroupTable.m_sShotParam[i].dTargetMax_M[j] ,
					gVariable.m_sgShotGroupTable.m_sShotParam[i].dTargetMin_M[j]);

				strMessage += strTemp;
			}		

		}


	}




	if(0 != strMessage.Compare( _T("") ))
	{
		strTemp.Format(_T(" )"));
		strMessage += strTemp;
	}

	return strMessage;
}



CString CDlgSelectedToolEdit::GetChangeAOMValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));



	for(int i = 0 ;i <= m_nGroupRepeatCount; i++)
	{



		for(int j = 0 ;j <= m_nRepeatCount; j++)
		{

			for(int k = 0 ;k <= m_nAOMRepeatCount; k++)
			{

				if(

					gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k]||
					gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_M[k] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_M[k]||
					gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k]||
					gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_S[k] != gShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_S[k]



				)
				{
					strTemp.Format(_T("| Count: %d, %d  %d ( %.3f,%.3f,%.3f,%.3f) "), 
						i,
						j,
						k,

						gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k] ,
						gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_M[k] ,
						gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k] ,
						gVariable.m_sgShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_S[k] 
					);
					strMessage += strTemp;
				}
			}		

		}


	}




	if(0 != strMessage.Compare( _T("") ))
	{
		strTemp.Format(_T(" )"));
		strMessage += strTemp;
	}

	return strMessage;
}

void CDlgSelectedToolEdit::OnCheckAdd()
{

	BOOL bSelect= FALSE;


	for(int i =0; i <SHOT_COUNT; i++)
	{
		if(gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i])
			bSelect = TRUE;
	}

	if(!bSelect)
		return;

	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;


	m_nRepeatCount++;

	if(m_nRepeatCount >= SHOT_COUNT)
	{
		m_nRepeatCount--;
		return ;
	}


	m_nSelectRow;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nInfoId[m_nRepeatCount] = m_nRepeatCount;

	if(TRUE == m_ClickID)
	{
		//		int nCopyNo = GetIdNoToAddDel();
		int nCopyNo = 0;
		for(int i = 0; i < SHOT_COUNT; i++)
		{
			if(gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i])
			{
				nCopyNo = i - 1;
				break;
			}
		}

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[nCopyNo] ;

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[nCopyNo] ;

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[nCopyNo] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[m_nRepeatCount]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[nCopyNo] ;

		//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow].TeststrInfoName[m_nRepeatCount],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow].TeststrInfoName[nCopyNo]);

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nLastIndex = m_nRepeatCount;


		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nRepeatCount] = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[nCopyNo] ;

		//		m_ClickID = FALSE; //111021
	}
	else
	{

		//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow].TeststrInfoName[m_nRepeatCount],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow].TeststrInfoName[m_nRepeatCount-1]);

	}

	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckDel()
{

	BOOL bSelect = FALSE;
	if(m_posClicked.y == -1)
		return ;

	for(int i =0; i <SHOT_COUNT; i++)
	{
		if(gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i])
			bSelect = TRUE;
	}

	if(!bSelect)
		return;


	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;

	if(FALSE == m_ClickID)
	{
		//MultiMessageDlg(STDMESSAGE205);
		return ;
	}

	if(m_nRepeatCount < 0)
	{
		return ;
	}

	for(int i = 0; i <SHOT_COUNT; i++)
	{
		//		int nDelNo = GetIdNoToAddDel();
		int nDelNo;
		if(gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i])
			nDelNo = i - 1;
		else 
			continue;


		// 	CString str;									/// �����Ҵ� yes,no ����
		// 	str.Format(_T("%d �׸��� �����մϴ� "),nDelNo);
		// 
		// 	if (ErrMessage(str,MB_YESNO,NULL) ==  IDYES)
		// 	{
		CopyFromOriginaltoTemp(nDelNo,m_nRepeatCount);
		m_nRepeatCount--;	

		CopyFromTempToOriginal();

		OnCheckRefresh();
		InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
		//	}
	}

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nLastIndex = m_nRepeatCount;

	for(int i = 0; i <SHOT_COUNT; i++) //���û����� ���������� ������ 
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	}
	m_nSelectRow = 0;

	m_ClickID = FALSE;



}
void CDlgSelectedToolEdit::OnCheckGroupAdd()
{

	BOOL bSelect= FALSE;


	for(int i =0; i <SHOT_GROUP_COUNT; i++)
	{
		if(gVariable.m_sgShotGroupTable.bGroupSelectedList[i])
			bSelect = TRUE;
	}

	if(!bSelect)
		return;

	if(bSelect)
		m_GroupClickID = TRUE;
	else
		m_GroupClickID = FALSE;


	m_nGroupRepeatCount++;

	if(m_nGroupRepeatCount >= SHOT_GROUP_COUNT)
	{
		m_nGroupRepeatCount--;
		return ;
	}


	gVariable.m_sgShotGroupTable.nGroupInfoId[m_nGroupRepeatCount] = m_nGroupRepeatCount;

	gVariable.m_sgShotGroupTable.nGroupLastIndex = m_nGroupRepeatCount;


	if(TRUE == m_GroupClickID)
	{

		//		int nCopyNo = GetIdNoToAddDel();
		int nCopyNo = 0;
		for(int i = 0; i < SHOT_GROUP_COUNT; i++)
		{
			if(gVariable.m_sgShotGroupTable.bGroupSelectedList[i])
			{
				nCopyNo = i - 1;
				break;
			}
		}



		strcpy_s(gVariable.m_sgShotGroupTable.strInfoName[m_nGroupRepeatCount],gVariable.m_sgShotGroupTable.strInfoName[nCopyNo]);

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow] = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1];



		gVariable.m_sgShotGroupTable.nToolType[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nToolType[nCopyNo];
		gVariable.m_sgShotGroupTable.nShotMode[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nShotMode[nCopyNo];

		gVariable.m_sgShotGroupTable.nDummyType[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nDummyType[nCopyNo];

		gVariable.m_sgShotGroupTable.nShotFrequency[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nShotFrequency[nCopyNo];
		gVariable.m_sgShotGroupTable.nShotMinFrequency[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nShotMinFrequency[nCopyNo];
		
		gVariable.m_sgShotGroupTable.dShotDuty_Percent[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.dShotDuty_Percent[nCopyNo];
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[nCopyNo];

		gVariable.m_sgShotGroupTable.nTotalShotCount[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nTotalShotCount[nCopyNo];
		gVariable.m_sgShotGroupTable.nBurstShotCount[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nBurstShotCount[nCopyNo];
	

		gVariable.m_sgShotGroupTable.dVoltage_M[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.dVoltage_M[nCopyNo];
		gVariable.m_sgShotGroupTable.dVoltage_S[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.dVoltage_S[nCopyNo];
		gVariable.m_sgShotGroupTable.bUseAperture[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.bUseAperture[nCopyNo];
		strcpy_s(gVariable.m_sgShotGroupTable.strAperturePath[m_nGroupRepeatCount],gVariable.m_sgShotGroupTable.strAperturePath[nCopyNo]);


		gVariable.m_sgShotGroupTable.nLaserOnDelay[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nLaserOnDelay[nCopyNo];
		gVariable.m_sgShotGroupTable.nLaserOffDelay[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nLaserOffDelay[nCopyNo];
		gVariable.m_sgShotGroupTable.nDrawSpeed[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nDrawSpeed[nCopyNo];
		gVariable.m_sgShotGroupTable.nJumpSpeed[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nJumpSpeed[nCopyNo];
		gVariable.m_sgShotGroupTable.nConerDelay[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nConerDelay[nCopyNo];
		gVariable.m_sgShotGroupTable.nJumpDelay[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nJumpDelay[nCopyNo];
		gVariable.m_sgShotGroupTable.nLineDelay[m_nGroupRepeatCount] = gVariable.m_sgShotGroupTable.nLineDelay[nCopyNo];




	}
	else
	{

		//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[m_nRepeatCount],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[m_nRepeatCount-1]);

	}

	OnCheckRefresh();
}

void CDlgSelectedToolEdit::OnCheckGroupDel()
{

	BOOL bSelect = FALSE;
	if(m_posGroupClicked.y == -1)
		return ;

	for(int i =0; i <SHOT_COUNT; i++)
	{
		if(gVariable.m_sgShotGroupTable.bGroupSelectedList[i])
			bSelect = TRUE;
	}
	if(bSelect)
		m_GroupClickID = TRUE;
	else
		m_GroupClickID = FALSE;

	if(FALSE == m_GroupClickID)
	{
		//MultiMessageDlg(STDMESSAGE205);
		return ;
	}

	if(m_nGroupRepeatCount < 0)
	{
		return ;
	}

	int nDelNo = -1;
	for(int i = 0; i <SHOT_GROUP_COUNT; i++)
	{
		//		int nDelNo = GetIdNoToAddDel();

		if(gVariable.m_sgShotGroupTable.bGroupSelectedList[i])
			nDelNo = i - 1;
		else 
			continue;

		CopyFromGroupOriginaltoTemp(nDelNo,m_nGroupRepeatCount);
		m_nGroupRepeatCount--;	

		CopyFromTempToGroupOriginal();


		OnCheckRefresh();
		InitGroupDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
		//	}
	}

	for(int i = 0; i <SHOT_GROUP_COUNT; i++) //���û����� ���������� ������ 
	{
		gVariable.m_sgShotGroupTable.bGroupSelectedList[i] = FALSE;
	}

	m_GroupClickID = FALSE;
	if(nDelNo != -1)
	{
		m_bDelClick = TRUE;
		ChangeShotOrderOfToolTable(nDelNo);
	}
}
//del �� ����׸��� �Ѵٰ� �Ͽ��� �� 
//ó�� ����� ������ �׸� ���� ���� ������  temp ����������-> ������ ������ �������� ������ ������ ���� temp ������ ����->
// ������������ ������ ���� ������ �ʱ�ȭ 
void CDlgSelectedToolEdit::CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo)
{
	int i = 0;

	for(i = 0 ;i < nSelectNo; i++)
	{


		m_sTempShotTable.dOnTime_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[i] ;
		m_sTempShotTable.dOnTime_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[i] ;

		m_sTempShotTable.dRefPower[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[i] ;
		m_sTempShotTable.dPower_Tol[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[i] ;
		m_sTempShotTable.nAOMNum_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[i] ;
		m_sTempShotTable.dAOMWait_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[i] ;
		m_sTempShotTable.nAOMNum_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[i] ;
		m_sTempShotTable.dAOMWait_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[i] ;


		m_sTempShotTable.dTargetMax_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[i] ;
		m_sTempShotTable.dTargetMin_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[i] ;

		//strcpy_s(m_sTempShotTable.TeststrInfoName[i],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[i]);

		m_sTempShotTable.m_sAOMParam[i] = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[i] ;


	}

	for(i = nSelectNo + 1; i <= RepeatNo;i++)
	{



		m_sTempShotTable.dOnTime_M[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[i] ;
	    m_sTempShotTable.dOnTime_S[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[i] ;

		m_sTempShotTable.dRefPower[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[i] ;

		m_sTempShotTable.dPower_Tol[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[i] ;

		m_sTempShotTable.nAOMNum_M[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[i] ;
		m_sTempShotTable.dAOMWait_M[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[i] ;
		m_sTempShotTable.nAOMNum_S[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[i] ;
		m_sTempShotTable.dAOMWait_S[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[i] ;


		m_sTempShotTable.dTargetMax_M[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[i] ;
		m_sTempShotTable.dTargetMin_M[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[i] ;

		m_sTempShotTable.m_sAOMParam[i-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[i] ;

		//strcpy_s(m_sTempShotTable.TeststrInfoName[i-1],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[i]);

	}


	// ���� �����Ͱ� ��ĭ�� ���� �ö󰬱� ������ ������ �� ������ ���� �ʱ�ȭ �Ѵ�. 
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nInfoId[RepeatNo] = i;








	//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[RepeatNo],"-");

}

void CDlgSelectedToolEdit::CopyFromGroupOriginaltoTemp(int nSelectNo, int RepeatNo)
{
	int i = 0;

	for(i = 0 ;i < nSelectNo; i++)
	{
		strcpy_s(gVariable.m_sgTempShotGroupTable.strInfoName[i],gVariable.m_sgShotGroupTable.strInfoName[i]);


		gVariable.m_sgTempShotGroupTable.nToolType[i] = gVariable.m_sgShotGroupTable.nToolType[i];
		gVariable.m_sgTempShotGroupTable.nShotMode[i] = gVariable.m_sgShotGroupTable.nShotMode[i];
		gVariable.m_sgTempShotGroupTable.nDummyType[i] = gVariable.m_sgShotGroupTable.nDummyType[i];

		gVariable.m_sgTempShotGroupTable.nShotFrequency[i] = gVariable.m_sgShotGroupTable.nShotFrequency[i];
		gVariable.m_sgTempShotGroupTable.nShotMinFrequency[i] = gVariable.m_sgShotGroupTable.nShotMinFrequency[i];

		gVariable.m_sgTempShotGroupTable.dShotDuty_Percent[i] = gVariable.m_sgShotGroupTable.dShotDuty_Percent[i];
		gVariable.m_sgTempShotGroupTable.dShotLMDuty_us[i] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[i];

		gVariable.m_sgTempShotGroupTable.nTotalShotCount[i] = gVariable.m_sgShotGroupTable.nTotalShotCount[i];
		gVariable.m_sgTempShotGroupTable.nBurstShotCount[i] = gVariable.m_sgShotGroupTable.nBurstShotCount[i];

		gVariable.m_sgTempShotGroupTable.dVoltage_M[i] = gVariable.m_sgShotGroupTable.dVoltage_M[i];
		gVariable.m_sgTempShotGroupTable.dVoltage_S[i] = gVariable.m_sgShotGroupTable.dVoltage_S[i];
		gVariable.m_sgTempShotGroupTable.bUseAperture[i] = gVariable.m_sgShotGroupTable.bUseAperture[i];
		strcpy_s(gVariable.m_sgTempShotGroupTable.strAperturePath[i],gVariable.m_sgShotGroupTable.strAperturePath[i]);


		gVariable.m_sgTempShotGroupTable.nLaserOnDelay[i] = gVariable.m_sgShotGroupTable.nLaserOnDelay[i];
		gVariable.m_sgTempShotGroupTable.nLaserOffDelay[i] = gVariable.m_sgShotGroupTable.nLaserOffDelay[i];
		gVariable.m_sgTempShotGroupTable.nDrawSpeed[i] = gVariable.m_sgShotGroupTable.nDrawSpeed[i];
		gVariable.m_sgTempShotGroupTable.nJumpSpeed[i] = gVariable.m_sgShotGroupTable.nJumpSpeed[i];
		gVariable.m_sgTempShotGroupTable.nConerDelay[i] = gVariable.m_sgShotGroupTable.nConerDelay[i];
		gVariable.m_sgTempShotGroupTable.nJumpDelay[i] = gVariable.m_sgShotGroupTable.nJumpDelay[i];
		gVariable.m_sgTempShotGroupTable.nLineDelay[i] = gVariable.m_sgShotGroupTable.nLineDelay[i];


	}

	for(i = nSelectNo + 1; i <= RepeatNo;i++)
	{
		strcpy_s(gVariable.m_sgTempShotGroupTable.strInfoName[i-1],gVariable.m_sgShotGroupTable.strInfoName[i]);

		gVariable.m_sgTempShotGroupTable.nToolType[i-1] = gVariable.m_sgShotGroupTable.nToolType[i];
		gVariable.m_sgTempShotGroupTable.nShotMode[i-1] = gVariable.m_sgShotGroupTable.nShotMode[i];
		gVariable.m_sgTempShotGroupTable.nDummyType[i-1] = gVariable.m_sgShotGroupTable.nDummyType[i];

		gVariable.m_sgTempShotGroupTable.nShotFrequency[i-1] = gVariable.m_sgShotGroupTable.nShotFrequency[i];
		gVariable.m_sgTempShotGroupTable.nShotMinFrequency[i-1] = gVariable.m_sgShotGroupTable.nShotMinFrequency[i];

		gVariable.m_sgTempShotGroupTable.dShotDuty_Percent[i-1] = gVariable.m_sgShotGroupTable.dShotDuty_Percent[i];
		gVariable.m_sgTempShotGroupTable.dShotLMDuty_us[i-1] = gVariable.m_sgShotGroupTable.dShotLMDuty_us[i];


		gVariable.m_sgTempShotGroupTable.nTotalShotCount[i-1] = gVariable.m_sgShotGroupTable.nTotalShotCount[i];
		gVariable.m_sgTempShotGroupTable.nBurstShotCount[i-1] = gVariable.m_sgShotGroupTable.nBurstShotCount[i];
		gVariable.m_sgTempShotGroupTable.dVoltage_M[i-1] = gVariable.m_sgShotGroupTable.dVoltage_M[i];
		gVariable.m_sgTempShotGroupTable.dVoltage_S[i-1] = gVariable.m_sgShotGroupTable.dVoltage_S[i];
		gVariable.m_sgTempShotGroupTable.bUseAperture[i-1] = gVariable.m_sgShotGroupTable.bUseAperture[i];
		strcpy_s(gVariable.m_sgTempShotGroupTable.strAperturePath[i-1],gVariable.m_sgShotGroupTable.strAperturePath[i]);


		gVariable.m_sgTempShotGroupTable.nLaserOnDelay[i-1] = gVariable.m_sgShotGroupTable.nLaserOnDelay[i];
		gVariable.m_sgTempShotGroupTable.nLaserOffDelay[i-1] = gVariable.m_sgShotGroupTable.nLaserOffDelay[i];
		gVariable.m_sgTempShotGroupTable.nDrawSpeed[i-1] = gVariable.m_sgShotGroupTable.nDrawSpeed[i];
		gVariable.m_sgTempShotGroupTable.nJumpSpeed[i-1] = gVariable.m_sgShotGroupTable.nJumpSpeed[i];
		gVariable.m_sgTempShotGroupTable.nConerDelay[i-1] = gVariable.m_sgShotGroupTable.nConerDelay[i];
		gVariable.m_sgTempShotGroupTable.nJumpDelay[i-1] = gVariable.m_sgShotGroupTable.nJumpDelay[i];
		gVariable.m_sgTempShotGroupTable.nLineDelay[i-1] = gVariable.m_sgShotGroupTable.nLineDelay[i];


	}


	// ���� �����Ͱ� ��ĭ�� ���� �ö󰬱� ������ ������ �� ������ ���� �ʱ�ȭ �Ѵ�. 
	gVariable.m_sgShotGroupTable.nGroupInfoId[RepeatNo] = i;
	strcpy_s(gVariable.m_sgShotGroupTable.strInfoName[RepeatNo],"-");

}



void CDlgSelectedToolEdit::CopyFromTempToOriginal()
{
	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{




		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[i] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[i] ;

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[i] ;
             gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[i] ;    
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[i] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[i] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[i] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[i] ;

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[i] ;
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[i] ;

		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[i]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[i] ;

		//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[i],m_sTempShotTable.TeststrInfoName[i]);

	}
}
void CDlgSelectedToolEdit::CopyFromTempToGroupOriginal()
{
	for(int i = 0 ;i <= m_nGroupRepeatCount; i++)
	{

		strcpy_s(gVariable.m_sgShotGroupTable.strInfoName[i],gVariable.m_sgTempShotGroupTable.strInfoName[i]);

		gVariable.m_sgShotGroupTable.nToolType[i] = gVariable.m_sgTempShotGroupTable.nToolType[i];
		gVariable.m_sgShotGroupTable.nShotMode[i] = gVariable.m_sgTempShotGroupTable.nShotMode[i];
		gVariable.m_sgShotGroupTable.nDummyType[i] = gVariable.m_sgTempShotGroupTable.nDummyType[i];

		gVariable.m_sgShotGroupTable.nShotFrequency[i] = gVariable.m_sgTempShotGroupTable.nShotFrequency[i];
		gVariable.m_sgShotGroupTable.nShotMinFrequency[i] = gVariable.m_sgTempShotGroupTable.nShotMinFrequency[i];

		gVariable.m_sgShotGroupTable.dShotDuty_Percent[i] = gVariable.m_sgTempShotGroupTable.dShotDuty_Percent[i];
		gVariable.m_sgShotGroupTable.dShotLMDuty_us[i] = gVariable.m_sgTempShotGroupTable.dShotLMDuty_us[i];

		gVariable.m_sgShotGroupTable.nTotalShotCount[i] = gVariable.m_sgTempShotGroupTable.nTotalShotCount[i];
		gVariable.m_sgShotGroupTable.nBurstShotCount[i] = gVariable.m_sgTempShotGroupTable.nBurstShotCount[i];

		gVariable.m_sgShotGroupTable.dVoltage_M[i] = gVariable.m_sgTempShotGroupTable.dVoltage_M[i];
		gVariable.m_sgShotGroupTable.dVoltage_S[i] = gVariable.m_sgTempShotGroupTable.dVoltage_S[i];
		gVariable.m_sgShotGroupTable.bUseAperture[i] = gVariable.m_sgTempShotGroupTable.bUseAperture[i];
		strcpy_s(gVariable.m_sgShotGroupTable.strAperturePath[i],gVariable.m_sgTempShotGroupTable.strAperturePath[i]);


		gVariable.m_sgShotGroupTable.nLaserOnDelay[i] = gVariable.m_sgTempShotGroupTable.nLaserOnDelay[i];
		gVariable.m_sgShotGroupTable.nLaserOffDelay[i] = gVariable.m_sgTempShotGroupTable.nLaserOffDelay[i];
		gVariable.m_sgShotGroupTable.nDrawSpeed[i] = gVariable.m_sgTempShotGroupTable.nDrawSpeed[i];
		gVariable.m_sgShotGroupTable.nJumpSpeed[i] = gVariable.m_sgTempShotGroupTable.nJumpSpeed[i];
		gVariable.m_sgShotGroupTable.nConerDelay[i] = gVariable.m_sgTempShotGroupTable.nConerDelay[i];
		gVariable.m_sgShotGroupTable.nJumpDelay[i] = gVariable.m_sgTempShotGroupTable.nJumpDelay[i];
		gVariable.m_sgShotGroupTable.nLineDelay[i] = gVariable.m_sgTempShotGroupTable.nLineDelay[i];


	}
}
void CDlgSelectedToolEdit::SetIdNoToAddDel(int nIdYPos)
{
	m_IdNoToAddDel = nIdYPos;
}

int CDlgSelectedToolEdit::GetIdNoToAddDel()
{
	return m_IdNoToAddDel;
}



void CDlgSelectedToolEdit::InitDataStruct()
{
	m_sTempShotTable.nLastIndex = m_nRepeatCount;


	for(int i = 0 ;i < SHOT_COUNT; i++)
	{
		m_sTempShotTable.nInfoId[i] = i;

		m_sTempShotTable.bSelectedList[i] = FALSE;


		m_sTempShotTable.dOnTime_M[i] = 0;
		m_sTempShotTable.dOnTime_S[i] = 0;
		m_sTempShotTable.dRefPower[i] = 0;
		m_sTempShotTable.dPower_Tol[i] = 0;
		m_sTempShotTable.nAOMNum_M[i] = 0;
		m_sTempShotTable.dAOMWait_M[i] = 0;
		m_sTempShotTable.nAOMNum_S[i] = 0;
		m_sTempShotTable.dAOMWait_S[i] = 0;

		m_sTempShotTable.dTargetMax_M[i] = 0;
		m_sTempShotTable.dTargetMin_M[i] = 0;

		//strcpy_s(m_sTempShotTable.TeststrInfoName[i],"-");

	}
}

void CDlgSelectedToolEdit::InitGroupDataStruct()
{


	gVariable.m_sgTempShotGroupTable.nGroupLastIndex = m_nGroupRepeatCount;


	for(int i = 0 ;i < SHOT_GROUP_COUNT; i++)
	{
		gVariable.m_sgTempShotGroupTable.nGroupInfoId[i] = i;

		gVariable.m_sgTempShotGroupTable.bGroupSelectedList[i] = FALSE;



		strcpy_s(gVariable.m_sgTempShotGroupTable.strInfoName[i],"-");
	}

}

// up, down��  �迭�� ���Ʒ��� �ٲٸ� �Ǳ� ������ ��ü ���縦 ���� �ʰ�
// m_sTempBeamPath ������ 0�� �δ콺 �������� �̿��Ͽ� m_sBeamPath ������ ������ ���� �Ѵ�. 

void CDlgSelectedToolEdit::OnCheckUp()
{
	if(m_nSelectRow <= 1)
		return;

	int SelectNo = m_nSelectRow-1;

	//round 1
	//temp[0] ������ ���õ� �׸��� ������ ���� 



	m_sTempShotTable.dOnTime_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo-1] ;
	m_sTempShotTable.dOnTime_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo-1] ;

	m_sTempShotTable.dRefPower[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo-1] ;
	m_sTempShotTable.dPower_Tol[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo-1] ;
	m_sTempShotTable.nAOMNum_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo-1] ;
	m_sTempShotTable.dAOMWait_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo-1] ;
	m_sTempShotTable.nAOMNum_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo-1] ;
	m_sTempShotTable.dAOMWait_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo-1] ;

	m_sTempShotTable.dTargetMax_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo-1] ;
	m_sTempShotTable.dTargetMin_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo-1] ;

	m_sTempShotTable.m_sAOMParam[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo-1] ;

	//	strcpy_s(m_sTempShotTable.TeststrInfoName[0],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo-1]);



	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo] ;	
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo-1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo] ;
	//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo-1],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo]);










	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo]			=	m_sTempShotTable.dOnTime_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo]			=	m_sTempShotTable.dOnTime_S[0] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo]			=	m_sTempShotTable.dRefPower[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo]			=	m_sTempShotTable.dPower_Tol[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo]			=	m_sTempShotTable.nAOMNum_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo]			=	m_sTempShotTable.dAOMWait_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo]			=	m_sTempShotTable.nAOMNum_S[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo]			=	m_sTempShotTable.dAOMWait_S[0] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo]			=	m_sTempShotTable.dTargetMax_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo]			=	m_sTempShotTable.dTargetMin_M[0] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo]			=	m_sTempShotTable.m_sAOMParam[0] ;

	m_nSelectRow--;
	for(int i = 0; i < SHOT_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[m_nSelectRow-1] = TRUE;

	//m_Grid.ResetSelectedRange();


	m_Grid.SetFocusCell(m_nSelectRow,1);


	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 

}

void CDlgSelectedToolEdit::OnCheckDown()
{
	if(m_nSelectRow >= m_nRepeatCount+1)
		return;

	int SelectNo = m_nSelectRow-1;


	//round 1
	//temp[0] ������ ���õ� �׸��� �Ʒ��� ���� 



	m_sTempShotTable.dOnTime_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo+1] ;
	m_sTempShotTable.dOnTime_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo+1] ;

	m_sTempShotTable.dRefPower[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo+1] ;
	m_sTempShotTable.dPower_Tol[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo+1] ;
	m_sTempShotTable.nAOMNum_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo+1] ;
	m_sTempShotTable.dAOMWait_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo+1] ;
	m_sTempShotTable.nAOMNum_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo+1] ;
	m_sTempShotTable.dAOMWait_S[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo+1] ;

	m_sTempShotTable.dTargetMax_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo+1] ;
	m_sTempShotTable.dTargetMin_M[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo+1] ;

	//strcpy_s(m_sTempShotTable.TeststrInfoName[0],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo+1]);
	m_sTempShotTable.m_sAOMParam[0]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo+1] ;



	//round2
	//���õ� ���� ��ĭ �Ʒ��� �����Ѵ�. 




	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo] ;

	//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo+1],gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo]);


	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo+1]			=	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo] ;


	//round3
	// temp[0]�� ����� ���� ���õ� �׸����� �����Ѵ�.


	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_M[SelectNo]			=	m_sTempShotTable.dOnTime_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dOnTime_S[SelectNo]			=	m_sTempShotTable.dOnTime_S[0] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dRefPower[SelectNo]			=	m_sTempShotTable.dRefPower[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dPower_Tol[SelectNo]			=	m_sTempShotTable.dPower_Tol[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_M[SelectNo]			=	m_sTempShotTable.nAOMNum_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_M[SelectNo]			=	m_sTempShotTable.dAOMWait_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nAOMNum_S[SelectNo]			=	m_sTempShotTable.nAOMNum_S[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dAOMWait_S[SelectNo]			=	m_sTempShotTable.dAOMWait_S[0] ;

	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMax_M[SelectNo]			=	m_sTempShotTable.dTargetMax_M[0] ;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].dTargetMin_M[SelectNo]			=	m_sTempShotTable.dTargetMin_M[0] ;

	//strcpy_s(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].TeststrInfoName[SelectNo],m_sTempShotTable.TeststrInfoName[0]);
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[SelectNo]			=	m_sTempShotTable.m_sAOMParam[0] ;

	m_nSelectRow++;
	for(int i = 0; i < SHOT_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[m_nSelectRow-1] = TRUE;
	//m_Grid.ResetSelectedRange();
	m_Grid.SetFocusCell(m_nSelectRow,1);

	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
}

void CDlgSelectedToolEdit::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	CDialog::OnDestroy();
}

void CDlgSelectedToolEdit::SetCurrentScrollPos(int xPos, int yPos)
{
	CRect rectCell;
//	m_list.GetSubItemRect(yPos, xPos, LVIR_BOUNDS, rectCell);

	CSize size;
	if(yPos <25)
		size.cy = 0;
	else
		size.cy = yPos* rectCell.Height();	

	if(xPos <10 )
		size.cx = 0;
	else if( xPos < 20)
		size.cx = xPos*30;
	else
		size.cx = xPos*50;

//	if(m_list.Scroll(size))
	{
//		m_list.SetItemState(m_posClicked.y,LVIS_SELECTED,LVIS_SELECTED);  
	}
}

int CDlgSelectedToolEdit::GetShowBoxMode(int nXPos)
{
	int listcount = GetListIndex();

	if(listcount == 0)
	{
		return 0;
	}
	else if(listcount == 1) //1
	{
		return 0;
	}
	else if(listcount ==2 )  //2
	{
		if(nXPos == SHOT_SELECT_TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;
	}

	else if(listcount == 3) //1,2
	{

		if(nXPos == SHOT_SELECT_TABLE0_COLUMN_COUNT + SHOT_SELECT_TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;			
	}



	return TRUE;
}

void CDlgSelectedToolEdit::OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult)  //����ֱ� �κ�..
{
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	COLORREF clrNewTextColor, clrNewBkColor;   

	*pResult = CDRF_DODEFAULT;

	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
		*pResult = CDRF_NOTIFYITEMDRAW;
	}
	else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{	
		*pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
	else if ( (CDDS_ITEMPREPAINT | CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{		   

		int listcount = GetListIndex();

		int xPos = pLVCD->iSubItem;

		if(listcount == 0)
		{	
			clrNewTextColor =TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 1) //1
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==2 )  //2
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}


		else if(listcount == 3) //1,2
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;    			
		}

		pLVCD->clrText = clrNewTextColor;
		pLVCD->clrTextBk = clrNewBkColor;     
		*pResult = CDRF_DODEFAULT;  
	}

}
void CDlgSelectedToolEdit::OnNMCustomdrawGroupListTest(NMHDR *pNMHDR, LRESULT *pResult)  //����ֱ� �κ�..
{
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	COLORREF clrNewTextColor, clrNewBkColor;   

	*pResult = CDRF_DODEFAULT;

	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
		*pResult = CDRF_NOTIFYITEMDRAW;
	}
	else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{	
		*pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
	else if ( (CDDS_ITEMPREPAINT | CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{		   

		int listcount = GetListIndex();

		int xPos = pLVCD->iSubItem;

		if(listcount == 0)
		{	
			clrNewTextColor =TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 1) //1
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==2 )  //2
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}


		else if(listcount == 3) //1,2
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;    			
		}

		pLVCD->clrText = clrNewTextColor;
		pLVCD->clrTextBk = clrNewBkColor;     
		*pResult = CDRF_DODEFAULT;  
	}

}


BOOL CDlgSelectedToolEdit::CheckApply()
{
	for(int i = 0; i<= m_nRepeatCount; i++)
	{
		/*
		if(gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].dPowOffsetAomDual1[i] + gVariable.m_sgShotGroupTable.m_sShotTable[m_nGroupSelectRow-1].dPowOffsetAomDual2[i] != 100)
		{
		ErrMessage(_T("Please insert aom percentage total 100"));
		return FALSE;
		}	
		*/
	}
	return TRUE;
}



void CDlgSelectedToolEdit::CellDisable(int y)
{
	for(int x = 0; x < m_Grid.GetRowCount(); x++)
		m_Grid.SetItemState(x, y, m_Grid.GetItemState(x,y) | GVIS_READONLY);
}



void CDlgSelectedToolEdit::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
	if(m_nUserLevel == 3)
		m_bCheckBox[2] = TRUE;
	else
		m_bCheckBox[2] = FALSE;
}
void CDlgSelectedToolEdit::EnableControl(BOOL bEnable)
{
	m_Grid.EnableWindow(bEnable);
	m_btnAdd.EnableWindow(bEnable);
	m_btnDel.EnableWindow(bEnable);

	m_btnGroupAdd.EnableWindow(bEnable);
	m_btnGroupDel.EnableWindow(bEnable);

	for(int i = 1 ; i < 6; i++)
	{
		/*	if((i == 5 || i == 4) && m_nUserLevel == 2)
		{
		m_ChkSubBox[i].SetCheck(FALSE);
		m_ChkSubBox[i].EnableWindow(FALSE);
		continue;
		}
		*/
		m_ChkSubBox[i].EnableWindow(bEnable);

	}
}


void CDlgSelectedToolEdit::SaveChangeOpticValue()
{
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeBeamPath_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}

	TRY
	{
		file.SeekToEnd();

		strDetail = _T("----------------------------------------------------------------------------------------------\n");
		file.Write(strDetail, strDetail.GetLength());

		strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
		file.Write(strDetail, strDetail.GetLength());

		/*
		for(int i = 0 ;i <= m_nRepeatCount; i++)
		{
			if(gVariable.m_sgBeamPath.nInfoId[i] != gBeamPathINI.m_sBeampath.nInfoId[i])
			{
				str.Format(_T("%d Info ID : %d -> %d\n"), i,gBeamPathINI.m_sBeampath.nInfoId[i], gVariable.m_sgBeamPath.nInfoId[i]);
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dInfoMaskSize[i] != gBeamPathINI.m_sBeampath.dInfoMaskSize[i])
			{
				str.Format(_T("%d Mask Size : %.3f -> %.3f\n"),  i,gBeamPathINI.m_sBeampath.dInfoMaskSize[i], gVariable.m_sgBeamPath.dInfoMaskSize[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_M[i])
			{
				str.Format(_T("%d M BET1 Pos : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dBeamPathBetPos1_M[i], gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_M[i])
			{
				str.Format(_T("%d M BET2 Pos : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dBeamPathBetPos2_M[i], gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_S[i])
			{
				str.Format(_T("%d S BET1 Pos : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dBeamPathBetPos1_S[i], gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_S[i])
			{
				str.Format(_T("%d S BET2 Pos : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dBeamPathBetPos2_S[i], gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i] );
				file.Write(str, str.GetLength());
			}


			if(gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1_M[i])
			{
				str.Format(_T("%d M1 Pos : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nBeamPathMaskPos1_M[i], gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2_S[i])
			{
				str.Format(_T("%d M2 Pos : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2_S[i], gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i])
			{
				str.Format(_T("%d Z1 Pos : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i], gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i])
			{
				str.Format(_T("%d Z2 Pos : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i], gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i])
			{
				str.Format(_T("%d Laser Path : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i], gVariable.m_sgBeamPath.bBeamPathLaserPath[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dScannerDuty[i] != gBeamPathINI.m_sBeampath.dScannerDuty[i])
			{
				str.Format(_T("%d Scanner Duty : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dScannerDuty[i], gVariable.m_sgBeamPath.dScannerDuty[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerTotalShot[i] != gBeamPathINI.m_sBeampath.nScannerTotalShot[i])
			{
				str.Format(_T("%d Scanner Total Shot : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerTotalShot[i], gVariable.m_sgBeamPath.nScannerTotalShot[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerVisionCam[i] != gBeamPathINI.m_sBeampath.nScannerVisionCam[i])
			{
				str.Format(_T("%d Scanner Cam : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerVisionCam[i], gVariable.m_sgBeamPath.nScannerVisionCam[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerVisionModelSize[i] != gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i])
			{
				str.Format(_T("%d Scanner Size : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i], gVariable.m_sgBeamPath.dScannerVisionModelSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i])
			{
				str.Format(_T("%d Scanner Accept Size : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i], gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i])
			{
				str.Format(_T("%d Scanner Accept Ratio : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i], gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerPolarity[i] != gBeamPathINI.m_sBeampath.nScannerPolarity[i])
			{
				str.Format(_T("%d Scanner Polarity : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerPolarity[i], gVariable.m_sgBeamPath.nScannerPolarity[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerBrightness[i] != gBeamPathINI.m_sBeampath.dScannerBrightness[i])
			{
				str.Format(_T("%d Scanner Bright : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dScannerBrightness[i], gVariable.m_sgBeamPath.dScannerBrightness[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerRing[i] != gBeamPathINI.m_sBeampath.nScannerRing[i])
			{
				str.Format(_T("%d Scanner Ring : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing[i], gVariable.m_sgBeamPath.nScannerRing[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial[i])
			{
				str.Format(_T("%d Scanner Coaxial : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial[i], gVariable.m_sgBeamPath.nScannerCoaxial[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR[i] != gBeamPathINI.m_sBeampath.nScannerIR[i])
			{
				str.Format(_T("%d Scanner IR1 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR[i], gVariable.m_sgBeamPath.nScannerIR[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nScannerRing2[i] != gBeamPathINI.m_sBeampath.nScannerRing2[i])
			{
				str.Format(_T("%d Scanner Ring : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing2[i], gVariable.m_sgBeamPath.nScannerRing2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial2[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial2[i])
			{
				str.Format(_T("%d Scanner Coaxial : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial2[i], gVariable.m_sgBeamPath.nScannerCoaxial2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR2[i] != gBeamPathINI.m_sBeampath.nScannerIR2[i])
			{
				str.Format(_T("%d Scanner IR2 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR2[i], gVariable.m_sgBeamPath.nScannerIR2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerRing3[i] != gBeamPathINI.m_sBeampath.nScannerRing3[i])
			{
				str.Format(_T("%d Scanner Ring3 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing3[i], gVariable.m_sgBeamPath.nScannerRing3[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial3[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial3[i])
			{
				str.Format(_T("%d Scanner Coaxial3 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial3[i], gVariable.m_sgBeamPath.nScannerCoaxial3[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR3[i] != gBeamPathINI.m_sBeampath.nScannerIR3[i])
			{
				str.Format(_T("%d Scanner IR3 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR3[i], gVariable.m_sgBeamPath.nScannerIR3[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nScannerRing4[i] != gBeamPathINI.m_sBeampath.nScannerRing4[i])
			{
				str.Format(_T("%d Scanner Ring4 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing4[i], gVariable.m_sgBeamPath.nScannerRing4[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial4[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial4[i])
			{
				str.Format(_T("%d Scanner Coaxial4 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial4[i], gVariable.m_sgBeamPath.nScannerCoaxial4[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR4[i] != gBeamPathINI.m_sBeampath.nScannerIR4[i])
			{
				str.Format(_T("%d Scanner IR4 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR4[i], gVariable.m_sgBeamPath.nScannerIR4[i] );
				file.Write(str, str.GetLength());
			}

		}
		*/
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		file.Close();
		return;
	}
	END_CATCH

		file.Close();
}
CString CDlgSelectedToolEdit::GetChangeOpticValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	/*
	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
			gVariable.m_sgBeamPath.nInfoId[i] != gBeamPathINI.m_sBeampath.nInfoId[i]||
			gVariable.m_sgBeamPath.dInfoMaskSize[i] != gBeamPathINI.m_sBeampath.dInfoMaskSize[i]||

			gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_S[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_S[i]||

			gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1_M[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2_S[i]||


			gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
			gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||




			gVariable.m_sgBeamPath.dScannerDuty[i] != gBeamPathINI.m_sBeampath.dScannerDuty[i]||
			gVariable.m_sgBeamPath.nScannerTotalShot[i] != gBeamPathINI.m_sBeampath.nScannerTotalShot[i]||
			gVariable.m_sgBeamPath.nScannerVisionCam[i] != gBeamPathINI.m_sBeampath.nScannerVisionCam[i]||
			gVariable.m_sgBeamPath.dScannerVisionModelSize[i] != gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i]||
			gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i]||
			gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i]||
			gVariable.m_sgBeamPath.nScannerPolarity[i] != gBeamPathINI.m_sBeampath.nScannerPolarity[i]||
			gVariable.m_sgBeamPath.dScannerBrightness[i] != gBeamPathINI.m_sBeampath.dScannerBrightness[i]||
			gVariable.m_sgBeamPath.nScannerRing[i] != gBeamPathINI.m_sBeampath.nScannerRing[i]||
			gVariable.m_sgBeamPath.nScannerCoaxial[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial[i]||
			gVariable.m_sgBeamPath.nScannerIR[i] != gBeamPathINI.m_sBeampath.nScannerIR[i]||
			gVariable.m_sgBeamPath.nScannerRing2[i] != gBeamPathINI.m_sBeampath.nScannerRing2[i]||
			gVariable.m_sgBeamPath.nScannerCoaxial2[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial2[i]

		)
		{
			strTemp.Format(_T("| %d : ( %.d, %.3f,  %.3f, %.3f, %.3f, %.3f   , %d, %d,    %.3f, %.3f,   %d, %d,  %d,   %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %d ,%.3f , %d, %d, %d, %d"), 
				i,
				gVariable.m_sgBeamPath.nInfoId[i] ,
				gVariable.m_sgBeamPath.dInfoMaskSize[i] ,	

				gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i],

				gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] ,
				gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i],

				gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] ,
				gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] ,

				gVariable.m_sgBeamPath.bBeamPathLaserPath[i] ,	

				gVariable.m_sgBeamPath.dScannerDuty[i] ,
				gVariable.m_sgBeamPath.nScannerTotalShot[i] ,
				gVariable.m_sgBeamPath.nScannerVisionCam[i] ,
				gVariable.m_sgBeamPath.dScannerVisionModelSize[i] ,
				gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] ,
				gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] ,


				gVariable.m_sgBeamPath.nScannerPolarity[i] ,
				gVariable.m_sgBeamPath.dScannerBrightness[i],
				gVariable.m_sgBeamPath.nScannerRing[i],
				gVariable.m_sgBeamPath.nScannerCoaxial[i],
				gVariable.m_sgBeamPath.nScannerRing2[i],
				gVariable.m_sgBeamPath.nScannerCoaxial2[i]
			);
			strMessage += strTemp;
		}		

	}
	*/

	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
			strcmp(gVariable.m_sgBeamPath.strInfoName[i], gBeamPathINI.m_sBeampath.strInfoName[i]) !=0 ||
			strcmp( gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0
			)
		{
			strTemp.Format(_T(",%s,%s "),gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gVariable.m_sgBeamPath.strBeamPathAscFile[i]);
		}
		strMessage += strTemp;
	}

	if(0 != strMessage.Compare( _T("") ))
	{
		strTemp.Format(_T(" )"));
		strMessage += strTemp;
	}

	return strMessage;
}

void CDlgSelectedToolEdit::CheckAnyDoPrework()
{
	BOOL bPowerChange = FALSE, bScalChange = FALSE;

	/*
	for(int i = 0; i < m_nRepeatCount; i++)
	{
		if(gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_S[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_S[i]||



			gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1_M[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2_S[i]||


			gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
			gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||

			gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
			bPowerChange = TRUE;
		}

		if(gVariable.m_sgBeamPath.dBeamPathBetPos1_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_M[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_M[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos1_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1_S[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2_S[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2_S[i]||


			gVariable.m_sgBeamPath.nBeamPathMaskPos1_M[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1_M[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos2_S[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2_S[i]||

			gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
			gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
			gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}

		if(strcmp( gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}
	}
	*/
	OnCheckRefresh();
	if(bPowerChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathPusan1) : P"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	if(bScalChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathPusan1) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

}

void CDlgSelectedToolEdit::OnBnClickedBtnSave()
{
	CString strBeamPath = GetChangeOpticValueStr();

	CheckAnyDoPrework();
	SaveChangeOpticValue();
	GetOpticTable( &gBeamPathINI.m_sBeampath );

	CString strMessage,strDumper;

	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
	if(0 != strBeamPath.CompareNoCase(""))
	{
		strMessage.Format(_T("BeamPath Save "));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDumper));
	}
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
	{
		ErrMsgDlg(STDGNALM114);
	}

	CString strShot = GetChangeGroupValueStr();

	if(!ValidateGroupValue())
		return;
	if(!gVariable.IsValidateTableModulationData(gBeamPathINI.m_sBeampath,gVariable.m_sgShotGroupTable))
		return;

	SaveChangeGroupValue();
	GetShotGroupTable( &gShotTableINI.m_sShotGroupTable );
////////////////////////////////////////////////////////////////////
	strShot += GetChangeAOMValueStr();

	if(0 != strShot.CompareNoCase(""))
	{
		strMessage.Format(_T("Shot Table Save "));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strShot));
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SHOT_INI))
	{
		ErrMsgDlg(STDGNALM114);
	}

//	if(m_bDelClick)
		m_bDeleteAndSaveClick = TRUE;
	OnCheckRefresh();

	
	memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );	
	memcpy( &gVariable.m_sgBeamPath, &gBeamPathINI.m_sBeampath, sizeof(gVariable.m_sgBeamPath) );	


}


void CDlgSelectedToolEdit::OnBnClickedBtnCancel()
{
	OnCancel();
}

void CDlgSelectedToolEdit::OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	m_posClicked.x = pItem->iColumn;
	m_posClicked.y = pItem->iRow - 1;
	str = m_Grid.GetItemText( pItem->iRow, pItem->iColumn);
	ListUpdate(m_posClicked, str);

	m_Grid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));


	if(pItem->iColumn == 5||pItem->iColumn == 7 )
	{
		OnCheckRefresh2(2);
	}
	//	OnCheckRefresh();	
}

void CDlgSelectedToolEdit::OnGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	CCellID cCellId;
	cCellId = m_Grid.GetFocusCell();

	for(int i = 0; i < SHOT_COUNT; i++)
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	}
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[pItem->iRow] = TRUE;

	m_nSelectRow = pItem->iRow;
	if(m_nSelectRow <= 0)
		return;

	m_nAOMSelectRow = 1;
	for(int i = 0; i < AOM_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[m_nAOMSelectRow-1] = TRUE;

	if(pItem->iColumn == 0)
	{
		/*
		CGridCellCheck *pCell;

		BOOL bUse = gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bUseShot[pItem->iRow-1]; 
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bUseShot[pItem->iRow-1] = !bUse;

		pCell = (CGridCellCheck*) m_Grid.GetCell(pItem->iRow, 0);
		pCell->SetCheck(!pCell->GetCheck());
		*/
	}

	OnCheckRefresh2(2);
	UpdateGridSelNo();
}
void CDlgSelectedToolEdit::OnOpticGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	m_posGroupClicked.x = pItem->iColumn;
	m_posGroupClicked.y = pItem->iRow - 1;
	str = m_OpticGrid.GetItemText( pItem->iRow, pItem->iColumn);

	OpticListUpdate(m_posGroupClicked, str);
	m_OpticGrid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));

}

void CDlgSelectedToolEdit::OnGroupGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	m_posGroupClicked.x = pItem->iColumn;
	m_posGroupClicked.y = pItem->iRow - 1;
	str = m_GroupGrid.GetItemText( pItem->iRow, pItem->iColumn);

	GroupListUpdate(m_posGroupClicked, str);

	m_GroupGrid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));

	if(pItem->iColumn == 4 && m_bCheckBox[1])
	{
		OnCheckRefresh2(1);
	}

	if(pItem->iColumn == 5)
	{
		OnCheckRefresh2(0);
		OnCheckRefresh2(1);
	}

}

void CDlgSelectedToolEdit::OnGroupGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	m_nGroupSelectRow = gVariable.m_sgBeamPath.nSelectShot[m_nSelectedTool] + 1;

	for(int i = 0; i < SHOT_GROUP_COUNT; i++)
		gVariable.m_sgShotGroupTable.bGroupSelectedList[i] = FALSE;

	gVariable.m_sgShotGroupTable.bGroupSelectedList[m_nGroupSelectRow-1] = TRUE;

	m_nRepeatCount= gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nLastIndex ;

	m_nSelectRow = 1;
	for(int i = 0; i < SHOT_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[m_nSelectRow-1] = TRUE;

	m_nAOMSelectRow = 1;
	for(int i = 0; i < AOM_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[m_nAOMSelectRow-1] = TRUE;

	OnCheckRefresh2(1);

	UpdateGridSelNo();
}
void CDlgSelectedToolEdit::OnAOMGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	CString str;
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	m_posAOMClicked.x = pItem->iColumn;
	m_posAOMClicked.y = pItem->iRow - 1;
	str = m_AOMGrid.GetItemText( pItem->iRow, pItem->iColumn);

	AOMListUpdate(m_posAOMClicked, str);

	m_AOMGrid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));


	//	OnCheckRefresh();	
}

void CDlgSelectedToolEdit::OnAOMGridClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;


	for(int i = 0; i < AOM_COUNT; i++)
	{
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[i] = FALSE;
	}
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[pItem->iRow] = TRUE;

	m_nAOMSelectRow = pItem->iRow;
	UpdateGridSelNo();
}
void CDlgSelectedToolEdit::OnGroupGridDoubleClick(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if(pItem->iRow < 0)
		return;
	m_nGroupSelectRow = pItem->iRow;

	for(int i = 0; i < SHOT_GROUP_COUNT; i++)
		gVariable.m_sgShotGroupTable.bGroupSelectedList[i] = FALSE;

	gVariable.m_sgShotGroupTable.bGroupSelectedList[m_nGroupSelectRow-1] = TRUE;

	m_nRepeatCount= gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].nLastIndex ;

	m_nSelectRow = 1;
	for(int i = 0; i < SHOT_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].bSelectedList[m_nSelectRow-1] = TRUE;


	m_nAOMSelectRow = 1;
	for(int i = 0; i < AOM_COUNT; i++)
		gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[i] = FALSE;
	gVariable.m_sgShotGroupTable.m_sShotParam[m_nGroupSelectRow-1].m_sAOMParam[m_nSelectRow-1].bSelectedList[m_nAOMSelectRow-1] = TRUE;

	if(pItem->iColumn == 14)
	{
		TCHAR BASED_CODE szFilter[] = _T("APL File (*.apl)|*.apl|All Files (*.*)|*.*||");

		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

		CFileDialog dlg(TRUE, _T("*.apl"), NULL, dwFlags, szFilter);

		CString strPath;
		CString strFileName;
		strPath = gEasyDrillerINI.m_clsDirPath.GetApertureDir();

		dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;

		if(IDOK == dlg.DoModal())
		{
			strFileName.Format(_T("%s"), dlg.GetFileName());

			lstrcpy(gVariable.m_sgShotGroupTable.strAperturePath[m_nGroupSelectRow-1],strFileName);
			m_GroupGrid.SetItemText( pItem->iRow, pItem->iColumn, strFileName);

			m_GroupGrid.SetItemBkColour(pItem->iRow, pItem->iColumn, RGB(255, 0, 0));
		}
	}
	OnCheckRefresh2(1);
}

void CDlgSelectedToolEdit::ChangeShotOrderOfToolTable(int nDelShotNo)
{
	/*
	for(int a = 0; a <= gToolTableINI.m_sToolTable.nLastIndex; a++)
	{
		if(gVariable.m_sgBeamPath.nSelectShot[a] >= nDelShotNo)
		{
			gVariable.m_sgBeamPath.nSelectShot[a]--;
		}
	}
	*/
}


void CDlgSelectedToolEdit::UpdateGridSelNo()
{
	CString str;

	str.Format("[ No: %d ]",m_nGroupSelectRow -1);
	GetDlgItem(IDC_STATIC_GROUP_SEL_NO)->SetWindowText(str);
	str.Format("[ No: %d ]",m_nSelectRow -1);
	GetDlgItem(IDC_STATIC_SHOT_SEL_NO)->SetWindowText(str);
	str.Format("[ No: %d ]",m_nAOMSelectRow -1);
	GetDlgItem(IDC_STATIC_AOM_SEL_NO)->SetWindowText(str);
}

void CDlgSelectedToolEdit::SetSelectedTool(int nToolTableNo)
{
	m_nSelectedTool = nToolTableNo;
	m_nGroupSelectRow = gVariable.m_sgBeamPath.nSelectShot[nToolTableNo] + 1;
	
}

HBRUSH CDlgSelectedToolEdit::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO: Change any attributes of the DC here
	if( nCtlColor == CTLCOLOR_STATIC )
	{
		if( GetDlgItem(IDC_STATIC_OPTIC_TABLE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_AOM_TABLE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_SHOT_TABLE)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;

	// TODO:  Return a different brush if the default is not desired
	return hbr;
}
