// DlgLotInfoCompare.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "..\EasyDrillerDlg.h"
#include "DlgLotInfoCompare.h"
#include "..\model\DProject.h"
//#include "LotManagerDetail.h"
#include "..\device\HDeviceFactory.h"
#include "..\model\dprocessini.h"

#include "PaneAutoRun.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLotInfoCompare dialog


CDlgLotInfoCompare::CDlgLotInfoCompare(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLotInfoCompare::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLotInfoCompare)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

}


void CDlgLotInfoCompare::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLotInfoCompare)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_LOT_INFO, m_ctrlListLotInfo);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLotInfoCompare, CDialog)
	//{{AFX_MSG_MAP(CDlgLotInfoCompare)

	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLotInfoCompare message handlers
BOOL CDlgLotInfoCompare::Create(CWnd* pParentWnd) 
{
	return CDialog::Create(IDD, pParentWnd);
}



void CDlgLotInfoCompare::InitListControl()
{
	// Set List Font

	m_fntStatic .CreatePointFont(90, "Arial Bold");

	LV_COLUMN lvcolumn;
	CString strText;
	char szText[256] = {0,};

	const int nMaxColumnNum = 5;
	 m_ctrlListLotInfo.SetFont( &m_fntStatic  );
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for( int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format("Title");
			lvcolumn.cx = 100;
			break;
		case 1 :
			strText.Format("Receive");
			lvcolumn.cx = 80;
			break;

		case 2 :
			strText.Format("Project");
			lvcolumn.cx = 80;
			break;
		case 3 :
			strText.Format("Result");
			lvcolumn.cx = 80;
			break;
		case 4 :
			strText.Format("");
			lvcolumn.cx = 230;
			break;

		}
		sprintf( szText, "%s", strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		

		m_ctrlListLotInfo.InsertColumn(i, &lvcolumn);
		
	}
	
	DWORD dwStyle = m_ctrlListLotInfo.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_ctrlListLotInfo.SetExtendedStyle( dwStyle );
	


	m_ctrlListLotInfo.DeleteAllItems();

	CString str;

	/* SkipSkip
	for(int i=0; i<5; i++)
	*/

	for(int i=0; i< 3; i++)
	{
		m_ctrlListLotInfo.InsertItem(i, _T(""));

		if(i == 0)
			str = "Panel No";
		else if(i == 1)
			str = "KitNum";
		else if(i == 2)
			str = "Contents �ڸ���";
		else if(i == 3)
			str = "Direction";
		else if(i == 4)
			str = "Panel Size";

		m_ctrlListLotInfo.SetItemText(i, 0, (LPSTR)(LPCSTR)str);

		if(i == 0)
			str = gDProject.m_sReceivedData.m_strPanelNoType;
		else if(i == 1)
			str = gDProject.m_sReceivedData.m_strUseKitNum;
		else if(i == 2)
			str = gDProject.m_sReceivedData.m_strCustomerNo;
		else if(i == 3)
			str = gDProject.m_sReceivedData.m_strPanelDirection;
		else if(i == 4)
			str = gDProject.m_sReceivedData.m_strPaneSizeX;

		m_ctrlListLotInfo.SetItemText(i, 1, (LPSTR)(LPCSTR)str);


		if(i == 0)
			str = gDProject.m_sProjectData.m_strPanelNoType;
		else if(i == 1)
			str = gDProject.m_sProjectData.m_strUseKitNum;
		else if(i == 2)
			str = gDProject.m_sProjectData.m_strCustomerNo;
		else if(i == 3)
			str = gDProject.m_sProjectData.m_strPanelDirection;
		else if(i == 4)
			str = gDProject.m_sProjectData.m_strPaneSizeX;

		m_ctrlListLotInfo.SetItemText(i, 2, (LPSTR)(LPCSTR)str);

		str = gDProject.GetCompareResult(i,TRUE);

		m_ctrlListLotInfo.SetItemText(i, 3, (LPSTR)(LPCSTR)str);

		if(i == 0)
			str = "0: Number , 1:Alphabet + Number";
		else if(i == 1)
			str = "0:UnUse , 1: Use";
		else if(i == 2)
			str = "0: 15�ڸ�, 1:24�ڸ�, 2: ����ũ��";
		else if(i == 3)
			str = "0: Comp , 1: Sold , 2: Dual";
		else if(i == 4)
			str = "(mm)";

		m_ctrlListLotInfo.SetItemText(i, 4, (LPSTR)(LPCSTR)str);

	}



}
BOOL CDlgLotInfoCompare::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
    InitListControl();
	return TRUE;                
}

void CDlgLotInfoCompare::OnOK() 
{
	CDialog::OnOK();
}

void CDlgLotInfoCompare::OnCancel() 
{
	CDialog::OnCancel();
}




