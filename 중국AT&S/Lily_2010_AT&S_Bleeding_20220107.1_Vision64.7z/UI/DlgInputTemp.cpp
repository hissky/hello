// DlgInputTemp.cpp : implementation file
//

#include "stdafx.h"



#include "easydriller.h"
#include "DlgInputTemp.h"
#include "model\DProject.h"
#include "EasyDrillerDlg.h"
#include "UI\PaneAutoRun.h"
#include "model\DEasyDrillerINI.h"
#include "model\GlobalVariable.h"
#include "UI\PaneRecipeGenSub.h"
#include "UI\PaneRecipeGen.h"
#include "UI\PaneRecipeGenData.h"

#include "..\alarmmsg.h"
#include "model\DProcessINI.h"
#include "..\device\deviceMotor.h"
#include "..\device\hdevicefactory.h"
#include <math.h>

#include "UI\PaneAutoRunViewOPC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp dialog


CDlgInputTemp::CDlgInputTemp(CWnd* pParent /*=NULL*/)
: CDialog(CDlgInputTemp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInputTemp)

	//}}AFX_DATA_INIT


	m_bGetLotInfo = FALSE;
	m_nTimer = 0;
}


void CDlgInputTemp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputTemp)

	DDX_Control(pDX, IDC_CHECK_GET_LOT_INFO, m_ledGetLotInfo);
	DDX_Control(pDX, IDC_LIST_LOT_INFO, m_listLotInfo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputTemp, CDialog)
//{{AFX_MSG_MAP(CDlgInputTemp)
	ON_BN_CLICKED(IDC_BTN_TEMP, OnBtnTemp)
	ON_BN_CLICKED(IDC_OK, OnOk)


	ON_WM_SHOWWINDOW()

	ON_BN_CLICKED(IDC_CANCEL, OnCancel)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_GET_LOT_INFO, &CDlgInputTemp::OnBnClickedCheckGetLotInfo)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_INIT_LOT_INFO, &CDlgInputTemp::OnBnClickedBtnInitLotInfo)

	ON_BN_CLICKED(IDC_BTN_RMS, &CDlgInputTemp::OnBnClickedBtnRms)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp message handlers
void CDlgInputTemp::OnShowWindow(BOOL bShow, UINT nStatus) 
{	
	// TODO: Add your message handler code here
	if(bShow)
	{
		EnableCtrlForRMS();
	}
}
BOOL CDlgInputTemp::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

void CDlgInputTemp::OnBtnTemp() 
{
	GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->SetWindowText("123456789");	
}

void CDlgInputTemp::OnOk() 
{

	SaveLotInfo();

	/*
	CString strPrj1;
	strPrj1.Format(_T("%s"), gLotInfo.szPrj[0]);

	((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);

	((CEasyDrillerDlg*)GetParent())->SetPrjName( strPrj1 );
	if(FALSE == (((CEasyDrillerDlg*)GetParent())->OpenProject(strPrj1, gLotInfo.bUseOpenTool[0])))
	{	
		ErrMsgDlg(STDGNALM113, strPrj1);
		return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
	}
	*/
	gXGem1->SendXGEMEvent(CEID_RECIPE_SELECT);//CEID 403 

	CDialog::OnCancel();
}


void CDlgInputTemp::SaveLotInfo()
{

	memset(&gLotInfo, 0, sizeof(gLotInfo));



	gLotInfo.nLastIndex = 2;

	strcpy_s(gLotInfo.szLotID[0], gXGem1->pst_GetLotInfo->strLotIDValue);
	strcpy_s(gLotInfo.szLotID[1], gXGem1->pst_GetLotInfo->strLotIDValue);

	strcpy_s(gLotInfo.szPrj[0], gXGem1->pst_GetLotInfo->strPrj_Comp);
	strcpy_s(gLotInfo.szPrj[1], gXGem1->pst_GetLotInfo->strPrj_Sold);

	gLotInfo.nLotCount[0] = gXGem1->pst_GetLotInfo->nPnlCount_LotInfo;
	gLotInfo.nLotCount[1] = gXGem1->pst_GetLotInfo->nPnlCount_LotInfo;

	if(gXGem1->pst_GetLotInfo->nDirectionValue == USE_DUAL)
	{
		gLotInfo.nComSol[0] = 2;
		gLotInfo.nComSol[1] = 3;
	}
	else if(gXGem1->pst_GetLotInfo->nDirectionValue == USE_1ST)
	{
		gLotInfo.nComSol[0] = 0;
		gLotInfo.nComSol[1] = 0;
	}
	else if(gXGem1->pst_GetLotInfo->nDirectionValue == USE_2ND)
	{
		gLotInfo.nComSol[0] = 1;
		gLotInfo.nComSol[1] = 1;
	}
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pOPC->InsertList();
}

BOOL CDlgInputTemp::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_fnt.CreatePointFont(120, "Arial Bold");


	m_fntBtn.CreatePointFont(90, "Arial Bold");
	GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->SetFont( &m_fntBtn );

	InitListControl();
	m_ledGetLotInfo.SetFont( &m_fnt );
	m_ledGetLotInfo.SetImage( IDB_LEDCOLOR, 15 );
	m_ledGetLotInfo.Depress( m_bGetLotInfo );
	m_ledGetLotInfo.ShowWindow(FALSE);
	m_nTimer = SetTimer(1, 1000, NULL);

	m_dlgGEMWait.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgGEMWait.SetUseOnlyOPCWait(TRUE);
	m_dlgGEMWait.ShowWindow(SW_HIDE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgInputTemp::OnCancel() 
{
	// TODO: Add your control notification handler code here
	
	CDialog::OnCancel();
}



BOOL CDlgInputTemp::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(WM_KEYDOWN == pMsg->message)
	{			  
		if((VK_ESCAPE == pMsg->wParam) || (VK_RETURN == pMsg->wParam) || (VK_TAB == pMsg->wParam)|| (VK_SPACE == pMsg->wParam))
		{
			// AfxMessageBox("");
			return TRUE;
		}			  
	}

	return CDialog::PreTranslateMessage(pMsg);
}


void CDlgInputTemp::OnBnClickedCheckGetLotInfo()
{
	m_bGetLotInfo = !m_bGetLotInfo;
	m_ledGetLotInfo.Depress(m_bGetLotInfo);
	Invalidate(FALSE);
}
void CDlgInputTemp::InitListControl()
{
	m_fntList.CreatePointFont(90, "Arial Bold");
	m_listLotInfo.SetFont( &m_fntList );
	const int nMaxColumnNum = 2;
	LV_COLUMN lvcolumn;
	CString strText;
	char szText[256] = {0,};
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_LEFT;
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText = "Name";
			lvcolumn.cx = 120;
			break;
		case 1 :
			strText = "Value";
			lvcolumn.cx = 200;
			break;
		}
		sprintf_s( szText, "%s", strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		m_listLotInfo.InsertColumn(i, &lvcolumn);
	}
	DWORD dwStyle = m_listLotInfo.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	m_listLotInfo.SetExtendedStyle( dwStyle );
}
void CDlgInputTemp::ShowLotInfo()
{
	m_listLotInfo.DeleteAllItems();
	// fiducial scale start
	CString strTemp, strPrjName, strList;
	int nCount = 0;
	LVITEM lv;
	lv.mask =  LVIF_TEXT|LVIF_PARAM;
	lv.lParam = 1;
	lv.state = 0;
	CString strName, strValue;
	for(int i = 0; i < LOT_INFO_COUNT + 1; i++)
	{
		switch(i)
		{
		case 0: 
			strName = "Recipe ID";
			strValue.Format("%s",gXGem1->pst_GetLotInfo->strRecipeID_LotInfo);
			break;
		case 1:
			strName = "Panel Count";
			strValue.Format("%d",gXGem1->pst_GetLotInfo->nPnlCount_LotInfo);
			break;
		case 2:
			strName = "Lot ID";
			strValue.Format("%s",gXGem1->pst_GetLotInfo->strLotIDValue);
			break;
		case 3:
			strName = "Lot Type";
			strValue.Format("%s",gXGem1->pst_GetLotInfo->strLotTypeValue);
			break;
		case 4:
			strName = "Direction";
			if(gXGem1->pst_GetLotInfo->nDirectionValue == USE_DUAL)
				strValue = "DUAL";
			else if(gXGem1->pst_GetLotInfo->nDirectionValue == USE_1ST)
				strValue = "COMP";
			else 
				strValue = "SOLD";
			break;
		}
		//No
		lv.iItem = nCount;
		lv.iSubItem = 0;
		lv.pszText = (LPSTR)(LPCSTR)strName;
		m_listLotInfo.InsertItem(&lv);
		//position list�� �ֱ� 
		lv.iItem = nCount;
		lv.iSubItem = 1;
		m_listLotInfo.SetItemText(nCount,1,(LPSTR)(LPCSTR)strValue);
		nCount++;
	}	

	GetDlgItem(IDC_EDIT_FILE_LOCATION)->SetWindowText(gXGem1->pst_GetLotInfo->strPrj_Comp);
	GetDlgItem(IDC_EDIT_FILE_LOCATION2)->SetWindowText(gXGem1->pst_GetLotInfo->strPrj_Sold);
}
void CDlgInputTemp::OnTimer(UINT nIDEvent) 
{
	if(gXGem1 == NULL)
		return;

	if (gXGem1->GetControlStatus() != Control_Remote)
		return;
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	int nNowSeqNo = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetNowSeqNo_LotInfo();
	if(nNowSeqNo > 0)
	{
		GetDlgItem(IDC_BTN_RMS)->SetWindowText("Cancel");
		GetDlgItem(IDC_BTN_INIT_LOT_INFO)->EnableWindow(FALSE);
		GetDlgItem(IDC_OK)->EnableWindow(FALSE);
		GetDlgItem(IDC_CANCEL)->EnableWindow(FALSE);

		DWORD dwEndTime = timeGetTime();
		int nTemp = dwEndTime - m_dwStartTime;
		if(nNowSeqNo == 100 || nNowSeqNo == 101)		
			m_dlgGEMWait.UpdateMeasurement(nTemp, _T("Wait for [LOT_INFO] Command"));
		else
			m_dlgGEMWait.UpdateMeasurement(nTemp, _T("Wait for [PP_SELECT] Command"));
	}
	else 
	{
	    GetDlgItem(IDC_BTN_RMS)->SetWindowText("RMS");
		GetDlgItem(IDC_BTN_INIT_LOT_INFO)->EnableWindow(TRUE);
		GetDlgItem(IDC_OK)->EnableWindow(TRUE);
		GetDlgItem(IDC_CANCEL)->EnableWindow(TRUE);

		m_dlgGEMWait.ShowWindow(SW_HIDE);
	}

	ShowLotInfo();
	CDialog::OnTimer(nIDEvent);
}


void CDlgInputTemp::InitLotInfo() 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nInputLot = 0;
	gXGem1->InitGetLotInfo();		// ��ư �������� ���� Lot ���� ������ (20191205)


}
void CDlgInputTemp::OnBnClickedBtnInitLotInfo()
{
	InitLotInfo();
	gXGem1->SendXGEMEvent(CEID_LOT_CANCEL);
	::AfxGetMainWnd()->SendMessage(UM_CLEAR_LOT_INFO);
}
void CDlgInputTemp::ClearLotInfoData() 
{
	gXGem1->m_evRecv.SetEvent();
	InitLotInfo();
	ShowLotInfo();
}



void CDlgInputTemp::OnBnClickedBtnRms()
{
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	int nNowSeqNo = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetNowSeqNo_LotInfo();
	if(nNowSeqNo > 0)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_GetLotInfoFromHost(FALSE);
		gXGem1->SendXGEMEvent(CEID_LOT_CANCEL);//CEID 303
		::AfxGetMainWnd()->SendMessage(UM_CLEAR_LOT_INFO);
		if(nNowSeqNo >= 200)
		{
			ErrMessage("PP Select ���� �� �۾��ڰ� �����Ͽ����ϴ�.");
		}
		else
		{
			ErrMessage("Lot Info �������� ���� �� �۾��ڰ� �����Ͽ����ϴ�.");
		}
		return;
	}
	CString str;
	GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->GetWindowText(str);
	//GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->SetWindowText("");
	if(str.IsEmpty())
	{
		AfxMessageBox("������ ����");
		return;
	}
	if(str.Find(_T("}	{")) > 0)
	{
		AfxMessageBox("���鰨��");
		return;
	}
	if(str.Find(_T("}\t{")) > 0)
	{
		AfxMessageBox("���鰨��");
		return;
	}
	if(str.Find(_T("} {")) > 0)
	{
		AfxMessageBox("���鰨��");
		return;
	}

	InitLotInfo();

	 CString strGetLotID;
	 GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->GetWindowText(strGetLotID);
	 if(strGetLotID == "")
	 {
		 AfxMessageBox("Lot ID ���� ����!!");
		 return;
	 }
	 GetDlgItem(IDC_EDIT_OPEN_EXCELLON_FILE)->SetWindowText("");

	 gXGem1->m_strInsertLotID = strGetLotID;
	 gXGem1->m_strInsertRawData = str;
	 //TempTemp
	 //Host�� ���� Lot Info�� �޴´�
	 ((CEasyDrillerDlg*)::AfxGetMainWnd())->StartSeq_GetLotInfoFromHost(TRUE);

	 m_dlgGEMWait.ShowWindow(SW_SHOW);
	 m_dlgGEMWait.StartMeasurement(30000);
	 m_dwStartTime = timeGetTime();
}
void CDlgInputTemp::EnableCtrlForRMS()
{
	BOOL bEnable = TRUE;

	int nControlStatus = gXGem1->GetControlStatus();

	if(gProcessINI.m_sProcessSystem.bUseSecsGem && nControlStatus == Control_Remote)
		bEnable = FALSE;

	GetDlgItem(IDC_BTN_RMS)->EnableWindow(!bEnable);
	GetDlgItem(IDC_BTN_INIT_LOT_INFO)->EnableWindow(!bEnable);
}