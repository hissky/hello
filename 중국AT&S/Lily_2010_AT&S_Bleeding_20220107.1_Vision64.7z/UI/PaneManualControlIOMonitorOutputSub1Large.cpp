// PaneManualControlIOMonitorOutputSub1Large.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutputSub1Large.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\Model\DSystemINI.h"
#include "..\device\HEocard.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "..\model\deasydrillerini.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Large

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutputSub1Large, CFormView)

CPaneManualControlIOMonitorOutputSub1Large::CPaneManualControlIOMonitorOutputSub1Large()
	: CFormView(CPaneManualControlIOMonitorOutputSub1Large::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutputSub1Large)
		// NOTE: the ClassWizard will add member initialization here
	m_nTimerID = 0;
	m_lStatus1 = m_lStatus1Old = 0;
	m_lStatus2 = m_lStatus2Old = 0;
	m_lStatus3 = m_lStatus3old = 0;
	m_lStatus4 = m_lStatus4old = 0;
	m_lStatus5 = m_lStatus5old = 0;
	m_lStatus6 = m_lStatus6old = 0;
	m_lStatus7 = m_lStatus7old = 0;
	m_lStatus8 = m_lStatus8old = 0;
	m_nSuction = m_nSuctionOld = 0;
	m_bSuction1 = m_bSuction1Old = FALSE;
	m_bSuction2 = m_bSuction2Old = FALSE;
	m_bMotor = m_bMotorOld = FALSE;
	m_bMotor2 = m_bMotor2Old = FALSE;
	m_bLamp = m_bLampOld = FALSE;
	m_bChuck = m_bChuckOld = FALSE;
	m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
	m_bBrushSol = m_bBrushSolOld = FALSE;
	m_bStatusLoader1 = FALSE;
	m_bStatusLoader2 = FALSE;
	m_bStatusUnloader1 = FALSE;
	m_bStatusUnloader2 = FALSE;
	m_bStatusTable1 = FALSE;
	m_bStatusTable2 = FALSE;
	m_bStatusAligner = FALSE;
	m_bStatusAligner2 = FALSE;
	m_nRadioVacuumTable = 0;
	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorOutputSub1Large::~CPaneManualControlIOMonitorOutputSub1Large()
{
}

void CPaneManualControlIOMonitorOutputSub1Large::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutputSub1Large)
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_ON, m_btnLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_OFF, m_btnLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, m_btnSafeOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, m_btnSafeOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_X, m_btnInitX);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Y, m_btnInitY);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z1, m_btnInitZ1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z2, m_btnInitZ2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_A1, m_btnInitA1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_A2, m_btnInitA2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M, m_btnInitM);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M2, m_btnInitM2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M3, m_btnInitM3);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_TOPHAT, m_btnInitTopHat);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_ROT, m_btnInitROT);

	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_C, m_btnInitC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_C2, m_btnInitC2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_LC, m_btnInitLC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_UC, m_btnInitUC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_OPEN, m_btnPowermeterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, m_btnPowermeterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, m_btnHeightSensorUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, m_btnHeightSensorDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, m_btnHeightSensorUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, m_btnHeightSensorDown2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, m_btnShutter1Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, m_btnShutter1Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, m_btnShutter2Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, m_btnShutter2Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ALARM, m_btnAlarm);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET, m_btnReset);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, m_btnSuction1On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, m_btnSuction1Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, m_btnSuction2On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, m_btnSuction2Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, m_btnVacuumMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, m_btnVacuumMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON, m_btnVacuumMotor2On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF, m_btnVacuumMotor2Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ALIGN, m_btnLoaderAlign);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_LOAD, m_btnLoaderLoad);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, m_btnLoadElvLoadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, m_btnLoadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, m_btnLoadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, m_btnLoadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS, m_btnLoadCarrAlignPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, m_btnUnloaderUnload);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, m_btnUnloadElvUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, m_btnUnloadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, m_btnUnloadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, m_btnUnloadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_ALIGN_POS, m_btnUnloadCarrAlignPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP, m_btnTableClamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, m_btnTableUnclamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP2, m_btnTableClamp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, m_btnTableUnclamp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP_3RD, m_btnTableClamp3rd);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP_3RD, m_btnTableUnclamp3rd);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_ON, m_btnDoorByPassOn);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_OFF, m_btnDoorByPassOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, m_btnLoadingShutterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, m_btnLoadingShutterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_ON, m_btnBuzzerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_OFF, m_btnBuzzerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, m_btnAirBlowerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, m_btnAirBlowerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, m_btnBrushMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, m_btnBrushMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, m_btnBrushSolUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, m_btnBrushSolDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, m_btnGreenLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, m_btnGreenLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, m_btnYellowLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, m_btnYellowLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_ON, m_btnRedLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_OFF, m_btnRedLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER1, m_btnResetLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER2, m_btnResetLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, m_btnResetLoaderTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER1, m_btnResetUnLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER2, m_btnResetUnLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, m_btnResetUnLoaderTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_TABLE1, m_btnResetTable1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_TABLE2, m_btnResetTable2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON2, m_btnBrushMotorOn2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF2, m_btnBrushMotorOff2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SUCTION_HOOD_ON, m_btnSuctionHoodAirOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SUCTION_HOOD_OFF, m_btnSuctionHoodAirClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_ON, m_btnAcrSuctionOn1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_OFF, m_btnAcrSuctionOff1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_ON2, m_btnAcrSuctionOn2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_OFF2, m_btnAcrSuctionOff2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_CHANGE_DIRECTION_ON, m_btnChangeDirectOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_CHANGE_DIRECTION_OFF, m_btnChangeDirectOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_CHILLER_ON, m_btnChillerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_CHILLER_OFF, m_btnChillerOff);
	DDX_Radio(pDX, IDC_RADIO_TABLE_A, m_nRadioVacuumTable);

	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_1, m_btnAOMNABeamPassUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_1, m_btnAOMNABeamPassDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_2, m_btnAOMNABeamPassUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_2, m_btnAOMNABeamPassDown2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_1, m_btnAOMUseBeamPassUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_1, m_btnAOMUseBeamPassDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_2, m_btnAOMUseBeamPassUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_2, m_btnAOMUseBeamPassDown2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_3, m_btnAOMUseBeamPassUp3);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_3, m_btnAOMUseBeamPassDown3);

	DDX_Control(pDX, IDC_BUTTON_OUTPUT_USE_AOM2, m_btnUseAOM);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_USE_AOM_SHORT2, m_btnUseAOMShort);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_USE_AOM_LONG2, m_btnUseAOMLong);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_NO_USE_AOM2, m_btnNoUseAOM);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_NO_USE_AOM_SHORT2, m_btnNoUseAOMShort);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_NO_USE_AOM_LONG2, m_btnNoUseAOMLong);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutputSub1Large, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutputSub1Large)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_ON, OnButtonOutputLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_OFF, OnButtonOutputLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, OnButtonOutputSafetyModeOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, OnButtonOutputSafetyModeOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_X, OnButtonOutputInitializeX)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Y, OnButtonOutputInitializeY)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z1, OnButtonOutputInitializeZ1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z2, OnButtonOutputInitializeZ2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M, OnButtonOutputInitializeM)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M2, OnButtonOutputInitializeM2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M3, OnButtonOutputInitializeM3)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_C, OnButtonOutputInitializeC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_C2, OnButtonOutputInitializeC2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_LC, OnButtonOutputInitializeLC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_UC, OnButtonOutputInitializeUC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_A1, OnButtonOutputInitializeA1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_A2, OnButtonOutputInitializeA2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_OPEN, OnButtonOutputPowermeterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, OnButtonOutputPowermeterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, OnButtonOutputHeightSensorUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, OnButtonOutputHeightSensorDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, OnButtonOutputHeightSensorUp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, OnButtonOutputHeightSensorDown2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, OnButtonOutputLasershutter1Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, OnButtonOutputLasershutter1Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, OnButtonOutputLasershutter2Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, OnButtonOutputLasershutter2Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ALARM, OnButtonOutputAlarmOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET, OnButtonOutputAlarmReset)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, OnButtonOutputTablesuction1On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, OnButtonOutputTablesuction1Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, OnButtonOutputTablesuction2On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, OnButtonOutputTablesuction2Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, OnButtonOutputVacuumMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, OnButtonOutputVacuumMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON, OnButtonOutputVacuumMotor2On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF, OnButtonOutputVacuumMotor2Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ALIGN, OnButtonOutputLoaderAlign)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_LOAD, OnButtonOutputLoaderLoad)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, OnButtonOutputLoaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, OnButtonOutputLoaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, OnButtonOutputLoaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, OnButtonOutputLoaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, OnButtonOutputUnloaderUnload)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, OnButtonOutputUnloaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, OnButtonOutputUnloaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, OnButtonOutputUnloaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, OnButtonOutputUnloaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP, OnButtonOutputTableClamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, OnButtonOutputTableUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP2, OnButtonOutputTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, OnButtonOutputTableUnclamp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP_3RD, OnButtonOutputTableClamp3rd)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP_3RD, OnButtonOutputTableUnclamp3rd)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_ON, OnButtonDoorByPassOn)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_OFF, OnButtonDoorByPassOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, OnButtonOutputLoadingShutterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, OnButtonOutputLoadingShutterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_ON, OnButtonOutputBuzzerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_OFF, OnButtonOutputBuzzerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, OnButtonOutputAirBlowerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, OnButtonOutputAirBlowerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, OnButtonOutputBrushMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, OnButtonOutputBrushMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON2, OnButtonOutputBrushMotorOn2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF2, OnButtonOutputBrushMotorOff2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, OnButtonOutputBrushSolUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, OnButtonOutputBrushSolDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, OnButtonOutputGreenLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, OnButtonOutputGreenLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, OnButtonOutputYellowLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, OnButtonOutputYellowLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_ON, OnButtonOutputRedLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_OFF, OnButtonOutputRedLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER1, OnButtonOutputResetLoader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER2, OnButtonOutputResetLoader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, OnButtonOutputResetLoaderTable)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER1, OnButtonOutputResetUnloader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER2, OnButtonOutputResetUnloader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, OnButtonOutputResetUnloaderTable)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_TABLE1, OnButtonOutputResetTable1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_TABLE2, OnButtonOutputResetTable2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS, OnButtonOutputLoaderCarrAlignPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_ALIGN_POS, OnButtonOutputUnloaderCarrAlignPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_ON, OnButtonAcrSuctionOn1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_OFF, OnButtonAcrSuctionOff1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_ON2, OnButtonAcrSuctionOn2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ACR_TABLESUCTION_OFF2, OnButtonAcrSuctionOff2)
	ON_BN_CLICKED(IDC_RADIO_TABLE_A,OnRadioTable1A)
	ON_BN_CLICKED(IDC_RADIO_TABLE_B,OnRadioTable1B)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SUCTION_HOOD_ON, OnButtonOutputSuctionHoodOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SUCTION_HOOD_OFF, OnButtonOutputSuctionHoodOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_CHANGE_DIRECTION_ON, OnButtonOutputChangeDirectionOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_CHANGE_DIRECTION_OFF, OnButtonOutputChangeDirectionOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_CHILLER_ON, OnButtonOutputChillerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_CHILLER_OFF, OnButtonOutputChillerOff)

	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_1, OnButtonAOMNABeamPassUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_1, OnButtonAOMNABeamPassDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_2, OnButtonAOMNABeamPassUp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_2, OnButtonAOMNABeamPassDown2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_1, OnButtonAOMUseBeamPassUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_1, OnButtonAOMUseBeamPassDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_2,OnButtonAOMUseBeamPassUp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_2,OnButtonAOMUseBeamPassDown2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_3, OnButtonAOMUseBeamPassUp3)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_3, OnButtonAOMUseBeamPassDown3)


	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_USE_AOM2, OnButtonUseAOM)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_USE_AOM_SHORT2, OnButtonUseAOMShort)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_USE_AOM_LONG2,OnButtonUseAOMLong)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_NO_USE_AOM2,OnButtonNoUseAOM)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_NO_USE_AOM_SHORT2, OnButtonNoUseAOMShort)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_NO_USE_AOM_LONG2, OnButtonNoUseAOMLong)

	//}}AFX_MSG_MAP
	

	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_TOPHAT, &CPaneManualControlIOMonitorOutputSub1Large::OnBnClickedButtonOutputInitializeTophat)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_ROT, &CPaneManualControlIOMonitorOutputSub1Large::OnBnClickedButtonOutputInitializeRot)
	END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Large diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutputSub1Large::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutputSub1Large::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Large message handlers

void CPaneManualControlIOMonitorOutputSub1Large::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();
}

void CPaneManualControlIOMonitorOutputSub1Large::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(95, "Arial Bold");
	
	m_btnLampOn.SetFont( &m_fntBtn );
	m_btnLampOn.SetFlat( FALSE );
	m_btnLampOn.EnableBallonToolTip();
	m_btnLampOn.SetToolTipText( _T("Lamp On") );
	m_btnLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnLampOff.SetFont( &m_fntBtn );
	m_btnLampOff.SetFlat( FALSE );
	m_btnLampOff.EnableBallonToolTip();
	m_btnLampOff.SetToolTipText( _T("Lamp Off") );
	m_btnLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnSafeOn.SetFont( &m_fntBtn );
	m_btnSafeOn.SetFlat( FALSE );
	m_btnSafeOn.EnableBallonToolTip();
	m_btnSafeOn.SetToolTipText( _T("Safety Mode On") );
	m_btnSafeOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOn.SetBtnCursor(IDC_HAND_1);

	m_btnSafeOff.SetFont( &m_fntBtn );
	m_btnSafeOff.SetFlat( FALSE );
	m_btnSafeOff.EnableBallonToolTip();
	m_btnSafeOff.SetToolTipText( _T("Safety Mode Off") );
	m_btnSafeOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOff.SetBtnCursor(IDC_HAND_1);

	m_btnInitX.SetFont( &m_fntBtn );
	m_btnInitX.SetFlat( FALSE );
	m_btnInitX.EnableBallonToolTip();
	m_btnInitX.SetToolTipText( _T("AxisX Initialize") );
	m_btnInitX.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitX.SetBtnCursor(IDC_HAND_1);

	m_btnInitY.SetFont( &m_fntBtn );
	m_btnInitY.SetFlat( FALSE );
	m_btnInitY.EnableBallonToolTip();
	m_btnInitY.SetToolTipText( _T("AxisY Initialize") );
	m_btnInitY.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitY.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ1.SetFont( &m_fntBtn );
	m_btnInitZ1.SetFlat( FALSE );
	m_btnInitZ1.EnableBallonToolTip();
	m_btnInitZ1.SetToolTipText( _T("AxisZ1 Initialize") );
	m_btnInitZ1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ1.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ2.SetFont( &m_fntBtn );
	m_btnInitZ2.SetFlat( FALSE );
	m_btnInitZ2.EnableBallonToolTip();
	m_btnInitZ2.SetToolTipText( _T("AxisZ2 Initialize") );
	m_btnInitZ2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ2.SetBtnCursor(IDC_HAND_1);

	
	m_btnInitA1.SetFont( &m_fntBtn );
	m_btnInitA1.SetFlat( FALSE );
	m_btnInitA1.EnableBallonToolTip();
	m_btnInitA1.SetToolTipText( _T("AxisA1 Initialize") );
	m_btnInitA1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitA1.SetBtnCursor(IDC_HAND_1);

	m_btnInitA2.SetFont( &m_fntBtn );
	m_btnInitA2.SetFlat( FALSE );
	m_btnInitA2.EnableBallonToolTip();
	m_btnInitA2.SetToolTipText( _T("AxisA2 Initialize") );
	m_btnInitA2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitA2.SetBtnCursor(IDC_HAND_1);

	m_btnInitA1.SetWindowText("Axis-B3 Initialize");
	m_btnInitA2.SetWindowText("Axis-B4 Initialize");

	m_btnInitM.SetFont( &m_fntBtn );
	m_btnInitM.SetFlat( FALSE );
	m_btnInitM.EnableBallonToolTip();
	m_btnInitM.SetToolTipText( _T("AxisM Initialize") );
	m_btnInitM.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM.SetBtnCursor(IDC_HAND_1);

	m_btnInitM2.SetFont( &m_fntBtn );
	m_btnInitM2.SetFlat( FALSE );
	m_btnInitM2.EnableBallonToolTip();
	m_btnInitM2.SetToolTipText( _T("AxisM Initialize") );
	m_btnInitM2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM2.SetBtnCursor(IDC_HAND_1);

	m_btnInitM3.SetFont( &m_fntBtn );
	m_btnInitM3.SetFlat( FALSE );
	m_btnInitM3.EnableBallonToolTip();
	m_btnInitM3.SetToolTipText( _T("AxisM Initialize") );
	m_btnInitM3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM3.SetBtnCursor(IDC_HAND_1);
	m_btnInitM3.ShowWindow(SW_HIDE);

	m_btnInitTopHat.SetFont( &m_fntBtn );
	m_btnInitTopHat.SetFlat( FALSE );
	m_btnInitTopHat.EnableBallonToolTip();
	m_btnInitTopHat.SetToolTipText( _T("AxisM Initialize") );
	m_btnInitTopHat.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitTopHat.SetBtnCursor(IDC_HAND_1);
	m_btnInitTopHat.ShowWindow(SW_HIDE);

	m_btnInitROT.SetFont( &m_fntBtn );
	m_btnInitROT.SetFlat( FALSE );
	m_btnInitROT.EnableBallonToolTip();
	m_btnInitROT.SetToolTipText( _T("AxisM Initialize") );
	m_btnInitROT.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitROT.SetBtnCursor(IDC_HAND_1);
    m_btnInitROT.ShowWindow(FALSE);


	m_btnInitC.SetFont( &m_fntBtn );
	m_btnInitC.SetFlat( FALSE );
	m_btnInitC.EnableBallonToolTip();
	m_btnInitC.SetToolTipText( _T("AxisB Initialize") );
	m_btnInitC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitC.SetBtnCursor(IDC_HAND_1);

	m_btnInitC2.SetFont( &m_fntBtn );
	m_btnInitC2.SetFlat( FALSE );
	m_btnInitC2.EnableBallonToolTip();
	m_btnInitC2.SetToolTipText( _T("AxisB2 Initialize") );
	m_btnInitC2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitC2.SetBtnCursor(IDC_HAND_1);

	m_btnInitLC.SetFont( &m_fntBtn );
	m_btnInitLC.SetFlat( FALSE );
	m_btnInitLC.EnableBallonToolTip();
	m_btnInitLC.SetToolTipText( _T("AxisLC Initialize") );
	m_btnInitLC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitLC.SetBtnCursor(IDC_HAND_1);

	m_btnInitUC.SetFont( &m_fntBtn );
	m_btnInitUC.SetFlat( FALSE );
	m_btnInitUC.EnableBallonToolTip();
	m_btnInitUC.SetToolTipText( _T("AxisUC Initialize") );
	m_btnInitUC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitUC.SetBtnCursor(IDC_HAND_1);
	
	m_btnInitLC.ShowWindow(SW_HIDE);
	m_btnInitUC.ShowWindow(SW_HIDE);


	m_btnPowermeterOpen.SetFont( &m_fntBtn );
	m_btnPowermeterOpen.SetFlat( FALSE );
	m_btnPowermeterOpen.EnableBallonToolTip();
	m_btnPowermeterOpen.SetToolTipText( _T("PowerMeter Shutter Open") );
	m_btnPowermeterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnPowermeterClose.SetFont( &m_fntBtn );
	m_btnPowermeterClose.SetFlat( FALSE );
	m_btnPowermeterClose.EnableBallonToolTip();
	m_btnPowermeterClose.SetToolTipText( _T("PowerMeter Shutter Close") );
	m_btnPowermeterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterClose.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp.SetFont( &m_fntBtn );
	m_btnHeightSensorUp.SetFlat( FALSE );
	m_btnHeightSensorUp.EnableBallonToolTip();
	m_btnHeightSensorUp.SetToolTipText( _T("HeightSensor1 Up") );
	m_btnHeightSensorUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorDown.SetFont( &m_fntBtn );
	m_btnHeightSensorDown.SetFlat( FALSE );
	m_btnHeightSensorDown.EnableBallonToolTip();
	m_btnHeightSensorDown.SetToolTipText( _T("HeightSensor1 Down") );
	m_btnHeightSensorDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp2.SetFont( &m_fntBtn );
	m_btnHeightSensorUp2.SetFlat( FALSE );
	m_btnHeightSensorUp2.EnableBallonToolTip();
	m_btnHeightSensorUp2.SetToolTipText( _T("HeightSensor2 Up") );
	m_btnHeightSensorUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnHeightSensorDown2.SetFont( &m_fntBtn );
	m_btnHeightSensorDown2.SetFlat( FALSE );
	m_btnHeightSensorDown2.EnableBallonToolTip();
	m_btnHeightSensorDown2.SetToolTipText( _T("HeightSensor2 Down") );
	m_btnHeightSensorDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown2.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Open.SetFont( &m_fntBtn );
	m_btnShutter1Open.SetFlat( FALSE );
	m_btnShutter1Open.EnableBallonToolTip();
	m_btnShutter1Open.SetToolTipText( _T("LaserShutter1 Open") );
	m_btnShutter1Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Open.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Close.SetFont( &m_fntBtn );
	m_btnShutter1Close.SetFlat( FALSE );
	m_btnShutter1Close.EnableBallonToolTip();
	m_btnShutter1Close.SetToolTipText( _T("LaserShutter1 Close") );
	m_btnShutter1Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Close.SetBtnCursor(IDC_HAND_1);

	m_btnShutter2Open.SetFont( &m_fntBtn );
	m_btnShutter2Open.SetFlat( FALSE );
	m_btnShutter2Open.EnableBallonToolTip();
	m_btnShutter2Open.SetToolTipText( _T("LaserShutter2 Open") );
	m_btnShutter2Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Open.SetBtnCursor(IDC_HAND_1);
	
	m_btnShutter2Close.SetFont( &m_fntBtn );
	m_btnShutter2Close.SetFlat( FALSE );
	m_btnShutter2Close.EnableBallonToolTip();
	m_btnShutter2Close.SetToolTipText( _T("LaserShutter2 Close") );
	m_btnShutter2Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Close.SetBtnCursor(IDC_HAND_1);

	m_btnAlarm.SetFont( &m_fntBtn );
	m_btnAlarm.SetFlat( FALSE );
	m_btnAlarm.EnableBallonToolTip();
	m_btnAlarm.SetToolTipText( _T("Alarm on") );
	m_btnAlarm.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAlarm.SetBtnCursor(IDC_HAND_1);

	m_btnReset.SetFont( &m_fntBtn );
	m_btnReset.SetFlat( FALSE );
	m_btnReset.EnableBallonToolTip();
	m_btnReset.SetToolTipText( _T("Alarm Reset") );
	m_btnReset.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReset.SetBtnCursor(IDC_HAND_1);

	m_btnSuction1On.SetFont( &m_fntBtn );
	m_btnSuction1On.SetFlat( FALSE );
	m_btnSuction1On.EnableBallonToolTip();
	m_btnSuction1On.SetToolTipText( _T("TableSuction1 On") );
	m_btnSuction1On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1On.SetBtnCursor(IDC_HAND_1);

	m_btnSuction1Off.SetFont( &m_fntBtn );
	m_btnSuction1Off.SetFlat( FALSE );
	m_btnSuction1Off.EnableBallonToolTip();
	m_btnSuction1Off.SetToolTipText( _T("TableSuction1 Off") );
	m_btnSuction1Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1Off.SetBtnCursor(IDC_HAND_1);

	m_btnSuction2On.SetFont( &m_fntBtn );
	m_btnSuction2On.SetFlat( FALSE );
	m_btnSuction2On.EnableBallonToolTip();
	m_btnSuction2On.SetToolTipText( _T("TableSuction2 On") );
	m_btnSuction2On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2On.SetBtnCursor(IDC_HAND_1);
	
	m_btnSuction2Off.SetFont( &m_fntBtn );
	m_btnSuction2Off.SetFlat( FALSE );
	m_btnSuction2Off.EnableBallonToolTip();
	m_btnSuction2Off.SetToolTipText( _T("TableSuction2 Off") );
	m_btnSuction2Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2Off.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotorOn.SetFont( &m_fntBtn );
	m_btnVacuumMotorOn.SetFlat( FALSE );
	m_btnVacuumMotorOn.EnableBallonToolTip();
	m_btnVacuumMotorOn.SetToolTipText( _T("VacuumMotor1 On") );
	m_btnVacuumMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotorOff.SetFont( &m_fntBtn );
	m_btnVacuumMotorOff.SetFlat( FALSE );
	m_btnVacuumMotorOff.EnableBallonToolTip();
	m_btnVacuumMotorOff.SetToolTipText( _T("VacuumMotor1 Off") );
	m_btnVacuumMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOff.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotor2On.SetFont( &m_fntBtn );
	m_btnVacuumMotor2On.SetFlat( FALSE );
	m_btnVacuumMotor2On.EnableBallonToolTip();
	m_btnVacuumMotor2On.SetToolTipText( _T("VacuumMotor2 On") );
	m_btnVacuumMotor2On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotor2On.SetBtnCursor(IDC_HAND_1);
	
	m_btnVacuumMotor2Off.SetFont( &m_fntBtn );
	m_btnVacuumMotor2Off.SetFlat( FALSE );
	m_btnVacuumMotor2Off.EnableBallonToolTip();
	m_btnVacuumMotor2Off.SetToolTipText( _T("VacuumMotor2 Off") );
	m_btnVacuumMotor2Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotor2Off.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderAlign.SetFont( &m_fntBtn );
	m_btnLoaderAlign.SetFlat( FALSE );
	m_btnLoaderAlign.EnableBallonToolTip();
	m_btnLoaderAlign.SetToolTipText( _T("Align") );
	m_btnLoaderAlign.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlign.SetBtnCursor(IDC_HAND_1);	

	m_btnLoaderLoad.SetFont( &m_fntBtn );
	m_btnLoaderLoad.SetFlat( FALSE );
	m_btnLoaderLoad.EnableBallonToolTip();
	m_btnLoaderLoad.SetToolTipText( _T("Loading") );
	m_btnLoaderLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderLoad.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvLoadPos.SetFont( &m_fntBtn );
	m_btnLoadElvLoadPos.SetFlat( FALSE );
	m_btnLoadElvLoadPos.EnableBallonToolTip();
	m_btnLoadElvLoadPos.SetToolTipText( _T("LoadElevator move to loading pos") );
	m_btnLoadElvLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvLoadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvOriPos.SetFont( &m_fntBtn );
	m_btnLoadElvOriPos.SetFlat( FALSE );
	m_btnLoadElvOriPos.EnableBallonToolTip();
	m_btnLoadElvOriPos.SetToolTipText( _T("LoadElevator move to origin pos") );
	m_btnLoadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrCartPos.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos.SetFlat( FALSE );
	m_btnLoadCarrCartPos.EnableBallonToolTip();
	m_btnLoadCarrCartPos.SetToolTipText( _T("LoaderCarrier move to cart pos") );
	m_btnLoadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrTablePos.SetFont( &m_fntBtn );
	m_btnLoadCarrTablePos.SetFlat( FALSE );
	m_btnLoadCarrTablePos.EnableBallonToolTip();
	m_btnLoadCarrTablePos.SetToolTipText( _T("LoaderCarrier move to table pos") );
	m_btnLoadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrTablePos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrAlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarrAlignPos.SetFlat( FALSE );
	m_btnLoadCarrAlignPos.EnableBallonToolTip();
	m_btnLoadCarrAlignPos.SetToolTipText( _T("LoaderCarrier move to align pos") );
	m_btnLoadCarrAlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrAlignPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloaderUnload.SetFont( &m_fntBtn );
	m_btnUnloaderUnload.SetFlat( FALSE );
	m_btnUnloaderUnload.EnableBallonToolTip();
	m_btnUnloaderUnload.SetToolTipText( _T("Unloading") );
	m_btnUnloaderUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderUnload.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadElvUnloadPos.SetFlat( FALSE );
	m_btnUnloadElvUnloadPos.EnableBallonToolTip();
	m_btnUnloadElvUnloadPos.SetToolTipText( _T("UnloadElevator move to unload pos") );
	m_btnUnloadElvUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvUnloadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvOriPos.SetFont( &m_fntBtn );
	m_btnUnloadElvOriPos.SetFlat( FALSE );
	m_btnUnloadElvOriPos.EnableBallonToolTip();
	m_btnUnloadElvOriPos.SetToolTipText( _T("UnloadElevator move to origin pos") );
	m_btnUnloadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrCartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrCartPos.SetFlat( FALSE );
	m_btnUnloadCarrCartPos.EnableBallonToolTip();
	m_btnUnloadCarrCartPos.SetToolTipText( _T("UnloaderCarrier move to cart pos") );
	m_btnUnloadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrTablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarrTablePos.SetFlat( FALSE );
	m_btnUnloadCarrTablePos.EnableBallonToolTip();
	m_btnUnloadCarrTablePos.SetToolTipText( _T("UnloaderCarrier move to table pos") );
	m_btnUnloadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrTablePos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnUnloadCarrAlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrAlignPos.SetFlat( FALSE );
	m_btnUnloadCarrAlignPos.EnableBallonToolTip();
	m_btnUnloadCarrAlignPos.SetToolTipText( _T("UnloaderCarrier move to align pos") );
	m_btnUnloadCarrAlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrAlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnTableClamp.SetFont( &m_fntBtn );
	m_btnTableClamp.SetFlat( FALSE );
	m_btnTableClamp.EnableBallonToolTip();
	m_btnTableClamp.SetToolTipText( _T("TableClamp1") );
	m_btnTableClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp.SetFont( &m_fntBtn );
	m_btnTableUnclamp.SetFlat( FALSE );
	m_btnTableUnclamp.EnableBallonToolTip();
	m_btnTableUnclamp.SetToolTipText( _T("TableUnclamp1") );
	m_btnTableUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnTableClamp2.SetFont( &m_fntBtn );
	m_btnTableClamp2.SetFlat( FALSE );
	m_btnTableClamp2.EnableBallonToolTip();
	m_btnTableClamp2.SetToolTipText( _T("TableClamp2") );
	m_btnTableClamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp2.SetFont( &m_fntBtn );
	m_btnTableUnclamp2.SetFlat( FALSE );
	m_btnTableUnclamp2.EnableBallonToolTip();
	m_btnTableUnclamp2.SetToolTipText( _T("TableUnclamp2") );
	m_btnTableUnclamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp2.SetBtnCursor(IDC_HAND_1);

	m_btnTableClamp3rd.SetFont( &m_fntBtn );
	m_btnTableClamp3rd.SetFlat( FALSE );
	m_btnTableClamp3rd.EnableBallonToolTip();
	m_btnTableClamp3rd.SetToolTipText( _T("TableClamp3") );
	m_btnTableClamp3rd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp3rd.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp3rd.SetFont( &m_fntBtn );
	m_btnTableUnclamp3rd.SetFlat( FALSE );
	m_btnTableUnclamp3rd.EnableBallonToolTip();
	m_btnTableUnclamp3rd.SetToolTipText( _T("TableUnclamp3") );
	m_btnTableUnclamp3rd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp3rd.SetBtnCursor(IDC_HAND_1);

	if (gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		m_btnTableClamp.ShowWindow(SW_HIDE);
		m_btnTableUnclamp.ShowWindow(SW_HIDE);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
		m_btnTableClamp3rd.ShowWindow(SW_HIDE);
		m_btnTableUnclamp3rd.ShowWindow(SW_HIDE);
	}
	if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
		m_btnTableClamp3rd.ShowWindow(SW_HIDE);
		m_btnTableUnclamp3rd.ShowWindow(SW_HIDE);
	}
	if(gSystemINI.m_sHardWare.nTableClamp == 2)
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
		m_btnTableClamp3rd.ShowWindow(SW_HIDE);
		m_btnTableUnclamp3rd.ShowWindow(SW_HIDE);
	}
	if(gSystemINI.m_sHardWare.nTableClamp == 3)
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
		m_btnTableClamp3rd.ShowWindow(SW_SHOW);
		m_btnTableUnclamp3rd.ShowWindow(SW_SHOW);
	}

	m_btnDoorByPassOn.SetFont( &m_fntBtn );
	m_btnDoorByPassOn.SetFlat( FALSE );
	m_btnDoorByPassOn.EnableBallonToolTip();
	m_btnDoorByPassOn.SetToolTipText( _T("DoorBypass On") );
	m_btnDoorByPassOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOn.SetBtnCursor(IDC_HAND_1);

	m_btnDoorByPassOff.SetFont( &m_fntBtn );
	m_btnDoorByPassOff.SetFlat( FALSE );
	m_btnDoorByPassOff.EnableBallonToolTip();
	m_btnDoorByPassOff.SetToolTipText( _T("DoorBypass Off") );
	m_btnDoorByPassOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnShutter2Open.ShowWindow(SW_HIDE);
		m_btnShutter2Close.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
	{
		m_btnInitZ1.ShowWindow(SW_HIDE);
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnInitM.ShowWindow(SW_HIDE);
		m_btnInitC.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{
		m_btnSuction2On.ShowWindow(SW_HIDE);
		m_btnSuction2Off.ShowWindow(SW_HIDE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_btnPowermeterOpen.ShowWindow(SW_HIDE);
		m_btnPowermeterClose.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_btnHeightSensorUp.ShowWindow(SW_HIDE);
		m_btnHeightSensorDown.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
	{
//		m_btnHeightSensorUp2.ShowWindow(SW_HIDE);
//		m_btnHeightSensorDown2.ShowWindow(SW_HIDE);
	}

	m_btnLoadingShutterOpen.SetFont( &m_fntBtn );
	m_btnLoadingShutterOpen.SetFlat( FALSE );
	m_btnLoadingShutterOpen.EnableBallonToolTip();
	m_btnLoadingShutterOpen.SetToolTipText( _T("LoadingShutter Open") );
	m_btnLoadingShutterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnLoadingShutterClose.SetFont( &m_fntBtn );
	m_btnLoadingShutterClose.SetFlat( FALSE );
	m_btnLoadingShutterClose.EnableBallonToolTip();
	m_btnLoadingShutterClose.SetToolTipText( _T("LoadingShutter Close") );
	m_btnLoadingShutterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterClose.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOn.SetFont( &m_fntBtn );
	m_btnBuzzerOn.SetFlat( FALSE );
	m_btnBuzzerOn.EnableBallonToolTip();
	m_btnBuzzerOn.SetToolTipText( _T("Buzzer On") );
	m_btnBuzzerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOn.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOff.SetFont( &m_fntBtn );
	m_btnBuzzerOff.SetFlat( FALSE );
	m_btnBuzzerOff.EnableBallonToolTip();
	m_btnBuzzerOff.SetToolTipText( _T("Buzzer Off") );
	m_btnBuzzerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOff.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOn.SetFont( &m_fntBtn );
	m_btnAirBlowerOn.SetFlat( FALSE );
	m_btnAirBlowerOn.EnableBallonToolTip();
	m_btnAirBlowerOn.SetToolTipText( _T("AirBlower On") );
	m_btnAirBlowerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOn.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOff.SetFont( &m_fntBtn );
	m_btnAirBlowerOff.SetFlat( FALSE );
	m_btnAirBlowerOff.EnableBallonToolTip();
	m_btnAirBlowerOff.SetToolTipText( _T("AirBlower Off") );
	m_btnAirBlowerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOn.SetFont( &m_fntBtn );
	m_btnBrushMotorOn.SetFlat( FALSE );
	m_btnBrushMotorOn.EnableBallonToolTip();
//	m_btnBrushMotorOn.SetToolTipText( _T("BrushMotor On") );
	m_btnBrushMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOff.SetFont( &m_fntBtn );
	m_btnBrushMotorOff.SetFlat( FALSE );
	m_btnBrushMotorOff.EnableBallonToolTip();
//	m_btnBrushMotorOff.SetToolTipText( _T("BrushMotor Off") );
	m_btnBrushMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushSolUp.SetFont( &m_fntBtn );
	m_btnBrushSolUp.SetFlat( FALSE );
	m_btnBrushSolUp.EnableBallonToolTip();
//	m_btnBrushSolUp.SetToolTipText( _T("BrushSol Up") );
	m_btnBrushSolUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolUp.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushSolDown.SetFont( &m_fntBtn );
	m_btnBrushSolDown.SetFlat( FALSE );
	m_btnBrushSolDown.EnableBallonToolTip();
//	m_btnBrushSolDown.SetToolTipText( _T("BrushSol Down") );
	m_btnBrushSolDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolDown.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOn.SetFont( &m_fntBtn );
	m_btnGreenLampOn.SetFlat( FALSE );
	m_btnGreenLampOn.EnableBallonToolTip();
	m_btnGreenLampOn.SetToolTipText( _T("GreenLamp On") );
	m_btnGreenLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOff.SetFont( &m_fntBtn );
	m_btnGreenLampOff.SetFlat( FALSE );
	m_btnGreenLampOff.EnableBallonToolTip();
	m_btnGreenLampOff.SetToolTipText( _T("GreenLamp Off") );
	m_btnGreenLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnYellowLampOn.SetFont( &m_fntBtn );
	m_btnYellowLampOn.SetFlat( FALSE );
	m_btnYellowLampOn.EnableBallonToolTip();
	m_btnYellowLampOn.SetToolTipText( _T("YellowLamp On") );
	m_btnYellowLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnYellowLampOff.SetFont( &m_fntBtn );
	m_btnYellowLampOff.SetFlat( FALSE );
	m_btnYellowLampOff.EnableBallonToolTip();
	m_btnYellowLampOff.SetToolTipText( _T("YellowLamp Off") );
	m_btnYellowLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOn.SetFont( &m_fntBtn );
	m_btnRedLampOn.SetFlat( FALSE );
	m_btnRedLampOn.EnableBallonToolTip();
	m_btnRedLampOn.SetToolTipText( _T("RedLamp On") );
	m_btnRedLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOff.SetFont( &m_fntBtn );
	m_btnRedLampOff.SetFlat( FALSE );
	m_btnRedLampOff.EnableBallonToolTip();
	m_btnRedLampOff.SetToolTipText( _T("RedLamp Off") );
	m_btnRedLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		m_btnLoadingShutterOpen.ShowWindow(SW_HIDE);
		m_btnLoadingShutterClose.ShowWindow(SW_HIDE);
		m_btnBuzzerOn.ShowWindow(SW_HIDE);
		m_btnBuzzerOff.ShowWindow(SW_HIDE);
		m_btnAirBlowerOn.ShowWindow(SW_HIDE);
		m_btnAirBlowerOff.ShowWindow(SW_HIDE);
//		m_btnBrushMotorOn.ShowWindow(SW_HIDE);
//		m_btnBrushMotorOff.ShowWindow(SW_HIDE);
//		m_btnBrushSolUp.ShowWindow(SW_HIDE);
//		m_btnBrushSolDown.ShowWindow(SW_HIDE);
		m_btnGreenLampOn.ShowWindow(SW_HIDE);
		m_btnGreenLampOff.ShowWindow(SW_HIDE);
		m_btnYellowLampOn.ShowWindow(SW_HIDE);
		m_btnYellowLampOff.ShowWindow(SW_HIDE);
		m_btnRedLampOn.ShowWindow(SW_HIDE);
		m_btnRedLampOff.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnShutter1Open.ShowWindow(SW_HIDE);
		m_btnShutter1Close.ShowWindow(SW_HIDE);
		m_btnSafeOn.ShowWindow(SW_HIDE);
		m_btnSafeOff.ShowWindow(SW_HIDE);
		m_btnLoaderLoad.ShowWindow(SW_HIDE);
		m_btnUnloaderUnload.ShowWindow(SW_HIDE);

		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableClamp2.EnableWindow(TRUE);
		m_btnTableClamp2.SetWindowText("Chuck Clamp");
		m_btnTableClamp2.SetToolTipText(_T("Chuck Clamp"));
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.EnableWindow(TRUE);
		m_btnTableUnclamp2.SetWindowText("Chuck Unclamp");
		m_btnTableUnclamp2.SetToolTipText(_T("Chuck Unclamp"));

		m_btnSuction1On.SetWindowText("TableSuction On");
		m_btnSuction1On.SetToolTipText( _T("TableSuction On") );
		m_btnSuction1Off.SetWindowText("TableSuction Off");
		m_btnSuction1Off.SetToolTipText( _T("TableSuction Off") );
	}

	m_btnResetLoader1.SetFont( &m_fntBtn );
	m_btnResetLoader1.SetFlat( FALSE );
	m_btnResetLoader1.EnableBallonToolTip();
	m_btnResetLoader1.SetToolTipText( _T("LoaderPicker1 Reset") );
	m_btnResetLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader1.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoader2.SetFont( &m_fntBtn );
	m_btnResetLoader2.SetFlat( FALSE );
	m_btnResetLoader2.EnableBallonToolTip();
	m_btnResetLoader2.SetToolTipText( _T("LoaderPicker2 Reset") );
	m_btnResetLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader2.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoaderTable.SetFont( &m_fntBtn );
	m_btnResetLoaderTable.SetFlat( FALSE );
	m_btnResetLoaderTable.EnableBallonToolTip();
	m_btnResetLoaderTable.SetToolTipText( _T("LoaderTable Reset") );
	m_btnResetLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoaderTable.SetBtnCursor(IDC_HAND_1);

	m_btnResetUnLoader1.SetFont( &m_fntBtn );
	m_btnResetUnLoader1.SetFlat( FALSE );
	m_btnResetUnLoader1.EnableBallonToolTip();
	m_btnResetUnLoader1.SetToolTipText( _T("UnloaderPicker1 Reset") );
	m_btnResetUnLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader1.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoader2.SetFont( &m_fntBtn );
	m_btnResetUnLoader2.SetFlat( FALSE );
	m_btnResetUnLoader2.EnableBallonToolTip();
	m_btnResetUnLoader2.SetToolTipText( _T("UnloaderPicker2 Reset") );
	m_btnResetUnLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader2.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoaderTable.SetFont( &m_fntBtn );
	m_btnResetUnLoaderTable.SetFlat( FALSE );
	m_btnResetUnLoaderTable.EnableBallonToolTip();
	m_btnResetUnLoaderTable.SetToolTipText( _T("UnloaderTable Reset") );
	m_btnResetUnLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoaderTable.SetBtnCursor(IDC_HAND_1);

	m_btnResetTable1.SetFont( &m_fntBtn );
	m_btnResetTable1.SetFlat( FALSE );
	m_btnResetTable1.EnableBallonToolTip();
	m_btnResetTable1.SetToolTipText( _T("Table1 Reset") );
	m_btnResetTable1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTable1.SetBtnCursor(IDC_HAND_1);

	m_btnResetTable2.SetFont( &m_fntBtn );
	m_btnResetTable2.SetFlat( FALSE );
	m_btnResetTable2.EnableBallonToolTip();
	m_btnResetTable2.SetToolTipText( _T("Table2 Reset") );
	m_btnResetTable2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTable2.SetBtnCursor(IDC_HAND_1);

	m_btnBrushMotorOn2.SetFont( &m_fntBtn );
	m_btnBrushMotorOn2.SetFlat( FALSE );
	m_btnBrushMotorOn2.EnableBallonToolTip();
	m_btnBrushMotorOn2.SetToolTipText( _T("Laser Beam Path 2 Fwd") );
	m_btnBrushMotorOn2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOn2.SetBtnCursor(IDC_HAND_1);
	m_btnBrushMotorOn2.ShowWindow(SW_HIDE);

	m_btnBrushMotorOff2.SetFont( &m_fntBtn );
	m_btnBrushMotorOff2.SetFlat( FALSE );
	m_btnBrushMotorOff2.EnableBallonToolTip();
	m_btnBrushMotorOff2.SetToolTipText( _T("Laser Beam Path 2 Bwd") );
	m_btnBrushMotorOff2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOff2.SetBtnCursor(IDC_HAND_1);
	m_btnBrushMotorOff2.ShowWindow(SW_HIDE);

	m_btnSuctionHoodAirOpen.SetFont( &m_fntBtn );
	m_btnSuctionHoodAirOpen.SetFlat( FALSE );
	m_btnSuctionHoodAirOpen.EnableBallonToolTip();
	m_btnSuctionHoodAirOpen.SetToolTipText( _T("Suction Hood Air Open") );
	m_btnSuctionHoodAirOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuctionHoodAirOpen.SetBtnCursor(IDC_HAND_1);

	m_btnSuctionHoodAirClose.SetFont( &m_fntBtn );
	m_btnSuctionHoodAirClose.SetFlat( FALSE );
	m_btnSuctionHoodAirClose.EnableBallonToolTip();
	m_btnSuctionHoodAirClose.SetToolTipText( _T("Suction Hood Air Close") );
	m_btnSuctionHoodAirClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuctionHoodAirClose.SetBtnCursor(IDC_HAND_1);

	m_btnAcrSuctionOn1.SetFont( &m_fntBtn );
	m_btnAcrSuctionOn1.SetFlat( FALSE );
	m_btnAcrSuctionOn1.EnableBallonToolTip();
	m_btnAcrSuctionOn1.SetToolTipText( _T("Acr Suction On1") );
	m_btnAcrSuctionOn1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAcrSuctionOn1.SetBtnCursor(IDC_HAND_1);
	
	m_btnAcrSuctionOff1.SetFont( &m_fntBtn );
	m_btnAcrSuctionOff1.SetFlat( FALSE );
	m_btnAcrSuctionOff1.EnableBallonToolTip();
	m_btnAcrSuctionOff1.SetToolTipText( _T("Acr Suction Off1") );
	m_btnAcrSuctionOff1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAcrSuctionOff1.SetBtnCursor(IDC_HAND_1);
	
	m_btnAcrSuctionOn2.SetFont( &m_fntBtn );
	m_btnAcrSuctionOn2.SetFlat( FALSE );
	m_btnAcrSuctionOn2.EnableBallonToolTip();
	m_btnAcrSuctionOn2.SetToolTipText( _T("Acr Suction On2") );
	m_btnAcrSuctionOn2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAcrSuctionOn2.SetBtnCursor(IDC_HAND_1);
	
	m_btnAcrSuctionOff2.SetFont( &m_fntBtn );
	m_btnAcrSuctionOff2.SetFlat( FALSE );
	m_btnAcrSuctionOff2.EnableBallonToolTip();
	m_btnAcrSuctionOff2.SetToolTipText( _T("Acr Suction Off2") );
	m_btnAcrSuctionOff2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAcrSuctionOff2.SetBtnCursor(IDC_HAND_1);

	m_btnChangeDirectOn.SetFont( &m_fntBtn );
	m_btnChangeDirectOn.SetFlat( FALSE );
	m_btnChangeDirectOn.EnableBallonToolTip();
	m_btnChangeDirectOn.SetToolTipText( _T("Change Direct On") );
	m_btnChangeDirectOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeDirectOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnChangeDirectOff.SetFont( &m_fntBtn );
	m_btnChangeDirectOff.SetFlat( FALSE );
	m_btnChangeDirectOff.EnableBallonToolTip();
	m_btnChangeDirectOff.SetToolTipText( _T("Change Direct Off") );
	m_btnChangeDirectOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeDirectOff.SetBtnCursor(IDC_HAND_1);

	m_btnChillerOn.SetFont( &m_fntBtn );
	m_btnChillerOn.SetFlat( FALSE );
	m_btnChillerOn.EnableBallonToolTip();
	m_btnChillerOn.SetToolTipText( _T("Chiller Remote On") );
	m_btnChillerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChillerOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnChillerOff.SetFont( &m_fntBtn );
	m_btnChillerOff.SetFlat( FALSE );
	m_btnChillerOff.EnableBallonToolTip();
	m_btnChillerOff.SetToolTipText( _T("Chiller Remote Off") );
	m_btnChillerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChillerOff.SetBtnCursor(IDC_HAND_1);



	m_btnAOMNABeamPassUp.SetFont( &m_fntBtn );
	m_btnAOMNABeamPassUp.SetFlat( FALSE );
	m_btnAOMNABeamPassUp.EnableBallonToolTip();
	m_btnAOMNABeamPassUp.SetToolTipText( _T("AOM NA Beam Pass Up") );
	m_btnAOMNABeamPassUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMNABeamPassUp.SetBtnCursor(IDC_HAND_1);


	m_btnAOMNABeamPassDown.SetFont( &m_fntBtn );
	m_btnAOMNABeamPassDown.SetFlat( FALSE );
	m_btnAOMNABeamPassDown.EnableBallonToolTip();
	m_btnAOMNABeamPassDown.SetToolTipText( _T("AOM NA Beam Pass Down") );
	m_btnAOMNABeamPassDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMNABeamPassDown.SetBtnCursor(IDC_HAND_1);

	m_btnAOMNABeamPassUp2.SetFont( &m_fntBtn );
	m_btnAOMNABeamPassUp2.SetFlat( FALSE );
	m_btnAOMNABeamPassUp2.EnableBallonToolTip();
	m_btnAOMNABeamPassUp2.SetToolTipText( _T("AOM NA Beam Pass Up2") );
	m_btnAOMNABeamPassUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMNABeamPassUp2.SetBtnCursor(IDC_HAND_1);

	m_btnAOMNABeamPassDown2.SetFont( &m_fntBtn );
	m_btnAOMNABeamPassDown2.SetFlat( FALSE );
	m_btnAOMNABeamPassDown2.EnableBallonToolTip();
	m_btnAOMNABeamPassDown2.SetToolTipText( _T("AOM NA Beam Pass Down2") );
	m_btnAOMNABeamPassDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMNABeamPassDown2.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassUp.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassUp.SetFlat( FALSE );
	m_btnAOMUseBeamPassUp.EnableBallonToolTip();
	m_btnAOMUseBeamPassUp.SetToolTipText( _T("AOM Use Beam Pass Up") );
	m_btnAOMUseBeamPassUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassUp.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassDown.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassDown.SetFlat( FALSE );
	m_btnAOMUseBeamPassDown.EnableBallonToolTip();
	m_btnAOMUseBeamPassDown.SetToolTipText( _T("AOM Use Beam Pass Down") );
	m_btnAOMUseBeamPassDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassDown.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassUp2.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassUp2.SetFlat( FALSE );
	m_btnAOMUseBeamPassUp2.EnableBallonToolTip();
	m_btnAOMUseBeamPassUp2.SetToolTipText( _T("AOM Use Beam Pass Up2") );
	m_btnAOMUseBeamPassUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassUp2.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassDown2.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassDown2.SetFlat( FALSE );
	m_btnAOMUseBeamPassDown2.EnableBallonToolTip();
	m_btnAOMUseBeamPassDown2.SetToolTipText( _T("AOM Use Beam Pass Down2") );
	m_btnAOMUseBeamPassDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassDown2.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassUp3.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassUp3.SetFlat( FALSE );
	m_btnAOMUseBeamPassUp3.EnableBallonToolTip();
	m_btnAOMUseBeamPassUp3.SetToolTipText( _T("AOM Use Beam Pass Up3") );
	m_btnAOMUseBeamPassUp3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassUp3.SetBtnCursor(IDC_HAND_1);

	m_btnAOMUseBeamPassDown3.SetFont( &m_fntBtn );
	m_btnAOMUseBeamPassDown3.SetFlat( FALSE );
	m_btnAOMUseBeamPassDown3.EnableBallonToolTip();
	m_btnAOMUseBeamPassDown3.SetToolTipText( _T("AOM Use Beam Pass Down3") );
	m_btnAOMUseBeamPassDown3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMUseBeamPassDown3.SetBtnCursor(IDC_HAND_1);

	m_btnUseAOM.SetFont( &m_fntBtn );
	m_btnUseAOM.SetFlat( FALSE );
	m_btnUseAOM.EnableBallonToolTip();
	m_btnUseAOM.SetToolTipText( _T("Use AOM") );
	m_btnUseAOM.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUseAOM.SetBtnCursor(IDC_HAND_1);

	m_btnUseAOMShort.SetFont( &m_fntBtn );
	m_btnUseAOMShort.SetFlat( FALSE );
	m_btnUseAOMShort.EnableBallonToolTip();
	m_btnUseAOMShort.SetToolTipText( _T("Use AOM Short") );
	m_btnUseAOMShort.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUseAOMShort.SetBtnCursor(IDC_HAND_1);

	m_btnUseAOMLong.SetFont( &m_fntBtn );
	m_btnUseAOMLong.SetFlat( FALSE );
	m_btnUseAOMLong.EnableBallonToolTip();
	m_btnUseAOMLong.SetToolTipText( _T("Use AOM Long") );
	m_btnUseAOMLong.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUseAOMLong.SetBtnCursor(IDC_HAND_1);

	m_btnNoUseAOM.SetFont( &m_fntBtn );
	m_btnNoUseAOM.SetFlat( FALSE );
	m_btnNoUseAOM.EnableBallonToolTip();
	m_btnNoUseAOM.SetToolTipText( _T("No Use AOM") );
	m_btnNoUseAOM.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNoUseAOM.SetBtnCursor(IDC_HAND_1);

	m_btnNoUseAOMShort.SetFont( &m_fntBtn );
	m_btnNoUseAOMShort.SetFlat( FALSE );
	m_btnNoUseAOMShort.EnableBallonToolTip();
	m_btnNoUseAOMShort.SetToolTipText( _T("No Use AOM Short") );
	m_btnNoUseAOMShort.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNoUseAOMShort.SetBtnCursor(IDC_HAND_1);

	m_btnNoUseAOMLong.SetFont( &m_fntBtn );
	m_btnNoUseAOMLong.SetFlat( FALSE );
	m_btnNoUseAOMLong.EnableBallonToolTip();
	m_btnNoUseAOMLong.SetToolTipText( _T("No Use AOM Long") );
	m_btnNoUseAOMLong.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNoUseAOMLong.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_RADIO_TABLE_A)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_TABLE_B)->SetFont( &m_fntBtn );

	BOOL bShow = true;

#ifdef __PKG_MODIFY__
	 bShow = false;
#endif


	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_1)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_1)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_UP_2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_NA_BEAMPASS_DOWN_2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_1)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_1)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_UP_3)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_AOM_USE_BEAMPASS_DOWN_3)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_USE_AOM2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_NO_USE_AOM2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_USE_AOM_SHORT2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_USE_AOM_LONG2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_NO_USE_AOM_SHORT2)->ShowWindow(bShow);
	 GetDlgItem(IDC_BUTTON_OUTPUT_NO_USE_AOM_LONG2)->ShowWindow(bShow);
	 GetDlgItem(IDC_STATIC_NOUSE_AOM)->ShowWindow(bShow);
	 GetDlgItem(IDC_STATIC_USE_AOM)->ShowWindow(bShow);

#ifdef __PKG_MODIFY__
		GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_TOPHAT)->SetWindowText("Axis-Collimator Initialize");
#else
	    GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_TOPHAT)->SetWindowText("Axis-TopHat Initialize");
	    GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_ROT)->ShowWindow(FALSE);
#endif
}

void CPaneManualControlIOMonitorOutputSub1Large::UpdateStatus()
{
#ifdef __SERVO_MOTOR__


	if(m_pMotor->IsOrigin(EZ_SERVO_C1))
		m_btnInitC.SetSelection( 1 );
	else 
		m_btnInitC.SetSelection( 0 );

	if(m_pMotor->IsOrigin(EZ_SERVO_C2))
		m_btnInitC2.SetSelection( 1 );
	else 
		m_btnInitC2.SetSelection( 0 );

	if(m_pMotor->IsOrigin(EZ_SERVO_C3))
		m_btnInitA1.SetSelection( 1 );
	else 
		m_btnInitA1.SetSelection( 0 );

	if(m_pMotor->IsOrigin(EZ_SERVO_C4))
		m_btnInitA2.SetSelection( 1 );
	else 
		m_btnInitA2.SetSelection( 0 );


	if(m_pMotor->IsOrigin(EZ_SERVO_M1))
		m_btnInitM.SetSelection( 1 );
	else 
		m_btnInitM.SetSelection( 0 );

	if(m_pMotor->IsOrigin(EZ_SERVO_M2))
		m_btnInitM2.SetSelection( 1 );
	else 
		m_btnInitM2.SetSelection( 0 );


#endif
	if(m_lStatus1 != m_lStatus1Old)
	{
		m_lStatus1Old = m_lStatus1;

		if(m_lStatus1 & 0x0008)
		{
			m_btnSafeOn.SetSelection( 1 );
			m_btnSafeOff.SetSelection( 0 );
		}
		else
		{
			m_btnSafeOn.SetSelection( 0 );
			m_btnSafeOff.SetSelection( 1 );
		}

		if(m_lStatus1 & 0x0010)
		{
			m_btnDoorByPassOn.SetSelection( 1 );
			m_btnDoorByPassOff.SetSelection( 0 );
		}
		else
		{
			m_btnDoorByPassOn.SetSelection( 0 );
			m_btnDoorByPassOff.SetSelection( 1 );
		}

		if(m_lStatus1 & 0x0400)
			m_btnInitX.SetSelection( 1 );
		else
			m_btnInitX.SetSelection( 0 );

		if(m_lStatus1 & 0x4000)
			m_btnInitY.SetSelection( 1 );
		else
			m_btnInitY.SetSelection( 0 );

		if(m_lStatus1 & 0x40000)
		{
			m_btnChillerOn.SetSelection( 1 );
			m_btnChillerOff.SetSelection( 0 );
		}
		else
		{
			m_btnChillerOn.SetSelection( 0 );
			m_btnChillerOff.SetSelection( 1 );
		}

	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		if(m_lStatus2 != m_lStatus2Old)
		{
			m_lStatus2Old = m_lStatus2;

			if(m_lStatus2 & 0x0004)
				m_btnInitZ1.SetSelection( 1 );
			else
				m_btnInitZ1.SetSelection( 0 );

			if(m_lStatus2 & 0x0040)
				m_btnInitZ2.SetSelection( 1 );
			else
				m_btnInitZ2.SetSelection( 0 );

		}
			
		if(m_lStatus3 != m_lStatus3old)
		{
			m_lStatus3old = m_lStatus3;

			
		}
		if(m_lStatus4 != m_lStatus4old)
		{
			m_lStatus4old = m_lStatus4;
			if(m_lStatus4 & 0x0010)
				m_btnBrushMotorOn.SetSelection( 1 );
			else
				m_btnBrushMotorOn.SetSelection( 0 );
			
			if(m_lStatus4 & 0x0020)
				m_btnBrushMotorOff.SetSelection( 1 );
			else
				m_btnBrushMotorOff.SetSelection( 0 );

			if((m_lStatus4 & 0x0001)  && (m_lStatus4 & 0x0004))
				m_btnBrushMotorOn2.SetSelection( 1 );
			else
				m_btnBrushMotorOn2.SetSelection( 0 );
			
			if((m_lStatus4 & 0x0002)  && (m_lStatus4 & 0x0008))
				m_btnBrushMotorOff2.SetSelection( 1 );
			else
				m_btnBrushMotorOff2.SetSelection( 0 );

			if(m_lStatus4 & 0x0010)
				m_btnBrushSolUp.SetSelection( 1 );
			else
				m_btnBrushSolUp.SetSelection( 0 );
			if(m_lStatus4 & 0x0020)
				m_btnBrushSolDown.SetSelection( 1 );
			else
				m_btnBrushSolDown.SetSelection( 0 );


			

			if(m_lStatus4 & 0x0400)
				m_btnInitLC.SetSelection( 1 );
			else
				m_btnInitLC.SetSelection( 0 );

			if(m_lStatus4 & 0x0800)
				m_btnInitUC.SetSelection( 1 );
			else
				m_btnInitUC.SetSelection( 0 );

			if(m_lStatus4 & 0x1000)
				m_btnLoadElvOriPos.SetSelection( 1 );
			else
				m_btnLoadElvOriPos.SetSelection( 0 );

			if(m_lStatus4 & 0x2000)
				m_btnUnloadElvOriPos.SetSelection( 1 );
			else
				m_btnUnloadElvOriPos.SetSelection( 0 );


		}
		
		if(m_lStatus5 != m_lStatus5old)
		{
			m_lStatus5old = m_lStatus5;
		}
		if(m_lStatus6 != m_lStatus6old)
		{
			m_lStatus6old = m_lStatus6;

			if(m_lStatus6 & 0x0010)
				m_btnHeightSensorUp.SetSelection( 1 );
			else
				m_btnHeightSensorUp.SetSelection( 0 );

			if(m_lStatus6 & 0x0020)
				m_btnHeightSensorDown.SetSelection( 1 );
			else
				m_btnHeightSensorDown.SetSelection( 0 );

			if(m_lStatus6 & 0x0080)
				m_btnHeightSensorDown2.SetSelection( 1 );
			else
				m_btnHeightSensorDown2.SetSelection( 0 );

			if(m_lStatus6 & 0x0040)
				m_btnHeightSensorUp2.SetSelection( 1 );
			else
				m_btnHeightSensorUp2.SetSelection( 0 );

			if(m_lStatus6 & 0x0001)
				m_btnShutter1Close.SetSelection( 1 );
			else
				m_btnShutter1Close.SetSelection( 0 );

			if(m_lStatus6 & 0x0002)
				m_btnShutter1Open.SetSelection( 1 );
			else
				m_btnShutter1Open.SetSelection( 0 );

			if(m_lStatus6 & 0x0004)
				m_btnShutter2Close.SetSelection( 1 );
			else
				m_btnShutter2Close.SetSelection( 0 );

			if(m_lStatus6 & 0x0008)
				m_btnShutter2Open.SetSelection( 1 );
			else
				m_btnShutter2Open.SetSelection( 0 );


			
		}

		if(m_lStatus7 != m_lStatus7old)
		{ 
			m_lStatus7old = m_lStatus7;

			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				if(m_lStatus7 & 0x0001)
					m_btnTableClamp.SetSelection( 1 );
				else
					m_btnTableClamp.SetSelection( 0 );
				
				if(m_lStatus7 & 0x0002)
					m_btnTableUnclamp.SetSelection( 1 );
				else
					m_btnTableUnclamp.SetSelection( 0 );
			}
			
			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				if(m_lStatus7 & 0x0004)
					m_btnTableClamp2.SetSelection( 1 );
				else
					m_btnTableClamp2.SetSelection( 0 );
				
				if(m_lStatus7 & 0x0008)
					m_btnTableUnclamp2.SetSelection( 1 );
				else
					m_btnTableUnclamp2.SetSelection( 0 );
			}

			if(m_lStatus7 & 0x0010)
				m_btnPowermeterOpen.SetSelection( 1 );
			else
				m_btnPowermeterOpen.SetSelection( 0 );

			if(m_lStatus7 & 0x0020)
				m_btnPowermeterClose.SetSelection( 1 );
			else
				m_btnPowermeterClose.SetSelection( 0 );

			if(m_lStatus7 & 0x0100)
				m_btnSuctionHoodAirOpen.SetSelection( 1 );
			else
				m_btnSuctionHoodAirOpen.SetSelection( 0 );

			if(m_lStatus7 & 0x0200)
				m_btnSuctionHoodAirClose.SetSelection( 1 );
			else
				m_btnSuctionHoodAirClose.SetSelection( 0 );

		}

		if(m_lStatus8 != m_lStatus8old)
		{
			m_lStatus8old = m_lStatus8;

			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				if(m_lStatus8 & 0x0040)
					m_btnTableClamp3rd.SetSelection( 1 );
				else
					m_btnTableClamp3rd.SetSelection( 0 );
				if(m_lStatus8 & 0x0080)
					m_btnTableUnclamp3rd.SetSelection( 1 );
				else
					m_btnTableUnclamp3rd.SetSelection( 0 );
			}
		}
		
	}

	if(m_bSuction1 != m_bSuction1Old)
	{
		m_bSuction1Old = m_bSuction1;
		if(m_bSuction1)
		{
			m_btnSuction1On.SetSelection(1);
			m_btnSuction1Off.SetSelection(0);
		}
		else
		{
			m_btnSuction1On.SetSelection(0);
			m_btnSuction1Off.SetSelection(1);
		}
	}
	if(m_bSuction2 != m_bSuction2Old)
	{
		m_bSuction2Old = m_bSuction2;
		if(m_bSuction2)
		{
			m_btnSuction2On.SetSelection(1);
			m_btnSuction2Off.SetSelection(0);
		}
		else
		{
			m_btnSuction2On.SetSelection(0);
			m_btnSuction2Off.SetSelection(1);
		}
	}

	m_bMotor = m_pMotor->GetCurrentSuctionMotor();
	if(m_bMotor)
	{
		m_btnVacuumMotorOn.SetSelection( 1 );
		m_btnVacuumMotorOff.SetSelection( 0 );
	}
	else
	{
		m_btnVacuumMotorOn.SetSelection( 0 );
		m_btnVacuumMotorOff.SetSelection( 1 );
	}

	if(m_bLamp != m_bLampOld)
	{
		m_bLampOld = m_bLamp;

		if(m_bLamp)
		{
			m_btnLampOn.SetSelection( 1 );
			m_btnLampOff.SetSelection( 0 );
		}
		else
		{
			m_btnLampOn.SetSelection( 0 );
			m_btnLampOff.SetSelection( 1 );
		}
	}
	BOOL bTemp = m_pMotor->GetCurrentAcrylSuction(TRUE);
	if(bTemp)
	{
		m_btnAcrSuctionOn1.SetSelection( 1 );
		m_btnAcrSuctionOff1.SetSelection( 0 );
	}
	else
	{
		m_btnAcrSuctionOn1.SetSelection( 0 );
		m_btnAcrSuctionOff1.SetSelection( 1 );
	}
	
	bTemp = m_pMotor->GetCurrentAcrylSuction(FALSE);
	if(bTemp)
	{
		m_btnAcrSuctionOn2.SetSelection( 1 );
		m_btnAcrSuctionOff2.SetSelection( 0 );
	}
	else
	{
		m_btnAcrSuctionOn2.SetSelection( 0 );
		m_btnAcrSuctionOff2.SetSelection( 1 );
	}


	
	bTemp = m_pMotor->GetAOMNABeamPassUpDown(TRUE);

	if(bTemp)
	{
		m_btnAOMNABeamPassUp.SetSelection( 1 );
		m_btnAOMNABeamPassDown.SetSelection( 0 );
	}
	else
	{
		m_btnAOMNABeamPassUp.SetSelection( 0 );
		m_btnAOMNABeamPassDown.SetSelection( 1 );
	}

	bTemp = m_pMotor->GetAOMNABeamPassUpDown2(TRUE);

	if(bTemp)
	{
		m_btnAOMNABeamPassUp2.SetSelection( 1 );
		m_btnAOMNABeamPassDown2.SetSelection( 0 );
	}
	else
	{
		m_btnAOMNABeamPassUp2.SetSelection( 0 );
		m_btnAOMNABeamPassDown2.SetSelection( 1 );
	}

	bTemp = m_pMotor->GetAOMUseBeamPassUpDown(TRUE);

	if(bTemp)
	{
		m_btnAOMUseBeamPassUp.SetSelection( 1 );
		m_btnAOMUseBeamPassDown.SetSelection( 0 );
	}
	else
	{
		m_btnAOMUseBeamPassUp.SetSelection( 0 );
		m_btnAOMUseBeamPassDown.SetSelection( 1 );
	}

	bTemp = m_pMotor->GetAOMUseBeamPassUpDown2(TRUE);

	if(bTemp)
	{
		m_btnAOMUseBeamPassUp2.SetSelection( 1 );
		m_btnAOMUseBeamPassDown2.SetSelection( 0 );
	}
	else
	{
		m_btnAOMUseBeamPassUp2.SetSelection( 0 );
		m_btnAOMUseBeamPassDown2.SetSelection( 1 );
	}

	bTemp = m_pMotor->GetAOMUseBeamPassUpDown3(TRUE);

	if(bTemp)
	{
		m_btnAOMUseBeamPassUp3.SetSelection( 1 );
		m_btnAOMUseBeamPassDown3.SetSelection( 0 );
	}
	else
	{
		m_btnAOMUseBeamPassUp3.SetSelection( 0 );
		m_btnAOMUseBeamPassDown3.SetSelection( 1 );
	}


	BOOL bNoAOMShort = m_pMotor->GetBeamPathStatus(TRUE,FALSE);
	BOOL bNoAOMLong = m_pMotor->GetBeamPathStatus(FALSE,FALSE);
	BOOL bUseAOMShort = m_pMotor->GetBeamPathStatus(TRUE,TRUE);
	BOOL bUseAOMLong = m_pMotor->GetBeamPathStatus(FALSE,TRUE);

	m_btnNoUseAOMShort.SetSelection( bNoAOMShort );
	m_btnNoUseAOMLong.SetSelection( bNoAOMLong );

	m_btnUseAOMShort.SetSelection(bUseAOMShort );
	m_btnUseAOMLong.SetSelection( bUseAOMLong );




	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		if(m_bChuck != m_bChuckOld)
		{
			m_bChuckOld = m_bChuck;

			if(m_bChuck)
			{
				m_btnTableClamp2.SetSelection( 1 );
				m_btnTableUnclamp2.SetSelection( 0 );
			}
			else
			{
				m_btnTableClamp2.SetSelection( 0 );
				m_btnTableUnclamp2.SetSelection( 1 );
			}
		}

		if(m_bLoadingShutter != m_bLoadingShutterOld)
		{
			m_bLoadingShutterOld = m_bLoadingShutter;

			if(m_bLoadingShutter)
			{
				m_btnLoadingShutterOpen.SetSelection( 1 );
				m_btnLoadingShutterClose.SetSelection( 0 );
			}
			else
			{
				m_btnLoadingShutterOpen.SetSelection( 0 );
				m_btnLoadingShutterClose.SetSelection( 1 );
			}
		}

		if(m_bBrushSol != m_bBrushSolOld)
		{
			m_bBrushSolOld = m_bBrushSol;

			if(m_bBrushSol)
			{
				m_btnBrushSolUp.SetSelection( 1 );
				m_btnBrushSolDown.SetSelection( 0 );
			}
			else
			{
				m_btnBrushSolUp.SetSelection( 0 );
				m_btnBrushSolDown.SetSelection( 1 );
			}
		}
	}

	// Loader1 Status
	if(gDeviceFactory.GetMotor()->IsLoaderPicker1PCBExist())
		m_bStatusLoader1 = TRUE;
	else
		m_bStatusLoader1 = FALSE;
	
	m_btnResetLoader1.SetSelection(m_bStatusLoader1);
	
	// Loader2 Status
	if(gDeviceFactory.GetMotor()->IsLoaderPicker2PCBExist())
		m_bStatusLoader2 = TRUE;
	else
		m_bStatusLoader2 = FALSE;
	
	m_btnResetLoader2.SetSelection(m_bStatusLoader2);
	
	// Unloader1 Status
	if(gDeviceFactory.GetMotor()->IsUnloaderPicker1PCBExist())
		m_bStatusUnloader1 = TRUE;
	else
		m_bStatusUnloader1 = FALSE;
	
	m_btnResetUnLoader1.SetSelection(m_bStatusUnloader1);
	
	// Unloader2 Status
	if(gDeviceFactory.GetMotor()->IsUnloaderPicker2PCBExist())
		m_bStatusUnloader2 = TRUE;
	else
		m_bStatusUnloader2 = FALSE;
	
	m_btnResetUnLoader2.SetSelection(m_bStatusUnloader2);
	
	// Table1 Status
	if(gDeviceFactory.GetMotor()->IsTable1PCBExist())
		m_bStatusTable1 = TRUE;
	else
		m_bStatusTable1 = FALSE;
	
	m_btnResetTable1.SetSelection(m_bStatusTable1);
	
	// Table2 Status
	if(gDeviceFactory.GetMotor()->IsTable2PCBExist())
		m_bStatusTable2 = TRUE;
	else
		m_bStatusTable2 = FALSE;
	
	m_btnResetTable2.SetSelection(m_bStatusTable2);
	
	// Loader Aligner Status
	if(gDeviceFactory.GetMotor()->IsAlignerPCBExist())
		m_bStatusAligner = TRUE;
	else
		m_bStatusAligner = FALSE;
	
	m_btnResetLoaderTable.SetSelection(m_bStatusAligner);
	
	// Unloader Aligner Status
	if(gDeviceFactory.GetMotor()->IsULAlignerPCBExist())
		m_bStatusAligner2 = TRUE;
	else
		m_bStatusAligner2 = FALSE;

	m_btnResetUnLoaderTable.SetSelection(m_bStatusAligner2);

	if(gDeviceFactory.GetMotor()->IsLCinCartPos())
		m_btnLoadCarrCartPos.SetSelection( 1 );
	else
		m_btnLoadCarrCartPos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsLCinLoadPos())
		m_btnLoadCarrTablePos.SetSelection( 1 );
	else
		m_btnLoadCarrTablePos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsUCinCartPos())
		m_btnUnloadCarrCartPos.SetSelection( 1 );
	else
		m_btnUnloadCarrCartPos.SetSelection( 0 );
	
	if(gDeviceFactory.GetMotor()->IsUCinUnloadPos())
		m_btnUnloadCarrTablePos.SetSelection( 1 );
	else
		m_btnUnloadCarrTablePos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->GetReverseDirection())
	{
		m_btnChangeDirectOn.SetSelection( 1 );
		m_btnChangeDirectOff.SetSelection( 0 );
	}
	else
	{
		m_btnChangeDirectOn.SetSelection( 0 );
		m_btnChangeDirectOff.SetSelection( 1 );
	}

#ifdef __KUNSAN_SAMSUNG_LARGE__

	if(gDeviceFactory.GetMotor()->IsTowerBuzzer())
	{
		m_btnAlarm.SetSelection( 1 );
		m_btnReset.SetSelection( 0 );
	}
	else
	{
		m_btnAlarm.SetSelection( 0 );
		m_btnReset.SetSelection( 1 );
	}
#endif

}

void CPaneManualControlIOMonitorOutputSub1Large::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	m_lStatus1 = m_pMotor->GetCurrentError(STATUS_IO1);
	m_nSuction = m_pMotor->GetCurrentSuction();

	if(m_nSuction & 0x01)
		m_bSuction1 = TRUE;
	else
		m_bSuction1 = FALSE;

	if(m_nSuction & 0x02)
		m_bSuction2 = TRUE;
	else
		m_bSuction2 = FALSE;

	m_bMotor = FALSE; //m_pMotor->GetCurrentVacuumMotor(TRUE);
	m_bMotor2 = FALSE; //m_pMotor->GetCurrentVacuumMotor(FALSE);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{

	}
	else
	{
		m_lStatus2 = m_pMotor->GetCurrentError(STATUS_IO2);
		m_lStatus3 = m_pMotor->GetCurrentError(STATUS_IO3);
		m_lStatus4 = m_pMotor->GetCurrentError(STATUS_IO4);
		m_lStatus5 = m_pMotor->GetCurrentError(STATUS_IO5);
		m_lStatus6 = m_pMotor->GetCurrentError(STATUS_IO6);
		m_lStatus7 = m_pMotor->GetCurrentError(STATUS_IO7);
		m_lStatus8 = m_pMotor->GetCurrentError(STATUS_IO8);
		m_bLamp = m_pMotor->IsFluorescentLampOn();
	}
	
	UpdateStatus();

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorOutputSub1Large::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9981, 300, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
//	SetTimer(9981, 1000, NULL);
}

void CPaneManualControlIOMonitorOutputSub1Large::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
		
		m_lStatus1 = m_lStatus1Old = 0;
		m_lStatus2 = m_lStatus2Old = 0;
		m_lStatus3 = m_lStatus3old = 0;
		m_lStatus4 = m_lStatus4old = 0;

		m_nSuction = m_nSuctionOld = 0;
		m_bMotor = m_bMotorOld = FALSE;
		m_bMotor2 = m_bMotor2Old = FALSE;
		m_bLamp = m_bLampOld = FALSE;
		m_bChuck = m_bChuckOld = FALSE;
		m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
		m_bBrushSol = m_bBrushSolOld = FALSE;
	}
//	KillTimer(9981);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLampOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->WriteOutputIOBIt(1, 6, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLampOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->WriteOutputIOBIt(1, 6, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputSafetyModeOn() 
{
	// TODO: Add your control notification handler code here
	//((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, SAFETY_MODE);
	//m_pMotor->SetOutPort(PORT_SAFETY_MODE_ON, 1);
	
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 1);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputSafetyModeOff() 
{
	// TODO: Add your control notification handler code here
	//((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
	//m_pMotor->SetOutPort(PORT_SAFETY_MODE_ON, 0);

//	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_SAFETY_MODE, 0);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeX() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_X);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeY() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_Y);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeZ1() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	gDeviceFactory.GetMotor()->SetOrigin(AXIS_Z1);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeZ2() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_Z2);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeM() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	m_pMotor->SetOrigin(AXIS_M);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeC() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	m_pMotor->SetOrigin(AXIS_C);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeC2()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	m_pMotor->SetOrigin(AXIS_C2);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeA1() 
{
	// TODO: Add your control notification handler code here

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	//m_pMotor->SetOrigin(AXIS_A1);
	m_pMotor->SetOrigin(AXIS_C3);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeA2()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	//m_pMotor->SetOrigin(AXIS_A2);
	m_pMotor->SetOrigin(AXIS_C4);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeLC() 
{
	// TODO: Add your control notification handler code here
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_L_CARRIER);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeUC() 
{
	// TODO: Add your control notification handler code here
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_UL_CARRIER);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputPowermeterOpen() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_POWER_METER, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputPowermeterClose() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_POWER_METER, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputHeightSensorUp() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputHeightSensorDown() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputHeightSensorUp2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputHeightSensorDown2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLasershutter1Open() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_MASTER, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLasershutter1Close() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_MASTER, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLasershutter2Open() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLasershutter2Close() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputAlarmOn()
{
	m_pMotor->SetOutPort(PORT_ALARM, TRUE);
	::Sleep(100);
	m_pMotor->SetOutPort(PORT_ALARM, FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputAlarmReset()
{
	m_pMotor->MainReset(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTablesuction1On() 
{
	// TODO: Add your control notification handler code here

	m_pMotor->WriteOutputIOBIt(2, 1, FALSE);
	m_pMotor->WriteOutputIOBIt(2, 0, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTablesuction1Off() 
{
	// TODO: Add your control notification handler code here

	m_pMotor->WriteOutputIOBIt(2, 0, FALSE);
	m_pMotor->WriteOutputIOBIt(2, 1, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTablesuction2On() 
{
	// TODO: Add your control notification handler code here

	m_pMotor->WriteOutputIOBIt(2, 3, FALSE);
	m_pMotor->WriteOutputIOBIt(2, 2, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTablesuction2Off() 
{
	// TODO: Add your control notification handler code here

	m_pMotor->WriteOutputIOBIt(2, 2, FALSE);
	m_pMotor->WriteOutputIOBIt(2, 3, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputVacuumMotorOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->Table1VacuumMotor(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputVacuumMotorOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->Table1VacuumMotor(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputVacuumMotor2On() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->Table2VacuumMotor(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputVacuumMotor2Off() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->Table2VacuumMotor(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderAlign() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderLoad() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_LOADER_LOAD);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvLoadPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierCartPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierLoadPos();
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoaderCarrAlignPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierAlignPos();
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderUnload() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierTablePos();
}



void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputUnloaderCarrAlignPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierAlignPos();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableClamp() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableUnclamp() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableClamp2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(TRUE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableUnclamp2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(FALSE, FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableClamp3rd() 
{
	m_pMotor->TableClamp3rd(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputTableUnclamp3rd() 
{
	m_pMotor->TableClamp3rd(FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonDoorByPassOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonDoorByPassOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::EnableButton(BOOL bUse)
{
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_X)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_M)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_C)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_C2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_LC)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_UC)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ALIGN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_LOAD)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD)->EnableWindow(bUse);

/*	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_TABLE1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_TABLE2)->EnableWindow(bUse);
*/
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_ON)->EnableWindow(bUse);
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_OFF)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_OFF)->EnableWindow(bUse);



	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP)->EnableWindow(bUse);
	}
	if(gSystemINI.m_sHardWare.nTableClamp > 1 ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP2)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2)->EnableWindow(bUse);
	}
}

void CPaneManualControlIOMonitorOutputSub1Large::SetAuthorityByLevel(int nLevel)
{
	// 100209 operator�� ��� ����Ҽ� �ְ�
	EnableButton(TRUE);
	return;

	switch(nLevel)
	{
	case 0: // Operator
		EnableButton(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3:// Super Engineer
		EnableButton(TRUE);
		break;
	}
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoadingShutterOpen()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputLoadingShutterClose()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBuzzerOn()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBuzzerOff()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputAirBlowerOn()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputAirBlowerOff()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushMotorOn()
{
//	m_pMotor->WriteOutputIOBIt(9, 0, TRUE);
//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
//	{
		m_pMotor->SetOutPort(PORT_LASER_PASS_TOP, TRUE);
		//m_pMotor->WriteOutPort(PORT_LASER_PASS, TRUE);
//	}
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushMotorOff()
{
//	m_pMotor->WriteOutputIOBIt(9, 1, TRUE);
//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
//	{
		m_pMotor->SetOutPort(PORT_LASER_PASS_TOP, FALSE);
//		m_pMotor->WriteOutPort(PORT_LASER_PASS, FALSE);
//	}
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushMotorOn2()
{
	//	m_pMotor->WriteOutputIOBIt(9, 0, TRUE);
	//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	//	{
	m_pMotor->SetOutPort(PORT_LASER_BEAM_PASS1, TRUE);
	//m_pMotor->WriteOutPort(PORT_LASER_PASS, TRUE);
	//	}
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushMotorOff2()
{
	//	m_pMotor->WriteOutputIOBIt(9, 1, TRUE);
	//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	//	{
	m_pMotor->SetOutPort(PORT_LASER_BEAM_PASS1, FALSE);
	//		m_pMotor->WriteOutPort(PORT_LASER_PASS, FALSE);
	//	}
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushSolUp()
{
	m_pMotor->WriteOutputIOBIt(9, 2, TRUE);

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputBrushSolDown()
{
	m_pMotor->WriteOutputIOBIt(9, 3, TRUE);

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputGreenLampOn()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputGreenLampOff()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputYellowLampOn()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputYellowLampOff()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputRedLampOn()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputRedLampOff()
{

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetLoader1()
{
	m_bStatusLoader1 = !m_bStatusLoader1;
	
	if(m_bStatusLoader1)
		gDeviceFactory.GetMotor()->Loader1PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Loader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetLoader2()
{
	m_bStatusLoader2 = !m_bStatusLoader2;
	
	if(m_bStatusLoader2)
		gDeviceFactory.GetMotor()->Loader2PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Loader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetLoaderTable()
{
	m_bStatusAligner = !m_bStatusAligner;
	
	if(m_bStatusAligner)
		gDeviceFactory.GetMotor()->AlignTablePCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->AlignTablePCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetUnloader1()
{
	m_bStatusUnloader1 = !m_bStatusUnloader1;
	
	if(m_bStatusUnloader1)
		gDeviceFactory.GetMotor()->Unloader1PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Unloader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetUnloader2()
{
	m_bStatusUnloader2 = !m_bStatusUnloader2;
	
	if(m_bStatusUnloader2)
		gDeviceFactory.GetMotor()->Unloader2PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Unloader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetUnloaderTable()
{
	m_bStatusAligner2 = !m_bStatusAligner2;
	
	if(m_bStatusAligner2)
		gDeviceFactory.GetMotor()->ULAlignTablePCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->ULAlignTablePCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetTable1()
{
	m_bStatusTable1 = !m_bStatusTable1;
	
	gDeviceFactory.GetMotor()->TablePCBReset();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputResetTable2()
{
	m_bStatusTable2 = !m_bStatusTable2;
	
	gDeviceFactory.GetMotor()->TablePCBReset();
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeM2()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_M2);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAcrSuctionOn1()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, TRUE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAcrSuctionOff1()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAcrSuctionOn2()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, TRUE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAcrSuctionOff2()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnRadioTable1A()
{
	m_nRadioVacuumTable = 0;
	gDeviceFactory.GetMotor()->SetOutportTableVacuum(FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnRadioTable1B()
{
	m_nRadioVacuumTable = 1;
	gDeviceFactory.GetMotor()->SetOutportTableVacuum(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputSuctionHoodOn() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->HoodOpen(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputSuctionHoodOff() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->HoodOpen(FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputInitializeM3()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_M3);
}

BOOL CPaneManualControlIOMonitorOutputSub1Large::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_IO_Output1) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputChangeDirectionOn()
{
	/*int nCount = 0;
	while(!gDeviceFactory.GetMotor()->GetReverseReady())
	{
		if(nCount >= 1000)
		{
			ErrMsgDlg(STDGNALM1147);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
			return;
		}
			Sleep(5);
		nCount += 20;
	}
	BOOL bDirect = gDeviceFactory.GetMotor()->GetReverseDirection();
	gDeviceFactory.GetMotor()->SetReverseDirection(TRUE);*/
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputChangeDirectionOff()
{
	/*int nCount = 0;
	while(!gDeviceFactory.GetMotor()->GetReverseReady())
	{
		if(nCount >= 1000)
		{
			ErrMsgDlg(STDGNALM1147);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
			return;
		}
			Sleep(5);
		nCount += 20;
	}
	gDeviceFactory.GetMotor()->SetReverseDirection(FALSE);*/
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputChillerOn()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_CHILLER_REMOTE, TRUE);
}
void CPaneManualControlIOMonitorOutputSub1Large::OnButtonOutputChillerOff()
{
	gDeviceFactory.GetMotor()->SetOutPort(PORT_CHILLER_REMOTE, FALSE);
}


void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMNABeamPassUp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMNABeamPassUpDown(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMNABeamPassDown() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMNABeamPassUpDown(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMNABeamPassUp2() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMNABeamPassUpDown2(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMNABeamPassDown2() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMNABeamPassUpDown2(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassUp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassDown() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassUp2() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown2(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassDown2() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown2(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassUp3() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown3(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonAOMUseBeamPassDown3() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->AOMUseBeamPassUpDown3(FALSE);
}


void CPaneManualControlIOMonitorOutputSub1Large::OnButtonUseAOM() 
{
	BOOL bShortPath = TRUE;
	BOOL bUseAom = TRUE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonUseAOMShort() 
{
	BOOL bShortPath = TRUE;
	BOOL bUseAom = TRUE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonUseAOMLong() 
{
	BOOL bShortPath = FALSE;
	BOOL bUseAom = TRUE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);

}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonNoUseAOM() 
{
	BOOL bShortPath = TRUE;
	BOOL bUseAom = FALSE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonNoUseAOMShort() 
{
	BOOL bShortPath = TRUE;
	BOOL bUseAom = FALSE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);
}

void CPaneManualControlIOMonitorOutputSub1Large::OnButtonNoUseAOMLong() 
{
	BOOL bShortPath = FALSE;
	BOOL bUseAom = FALSE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS1, bShortPath, bUseAom);
}






void CPaneManualControlIOMonitorOutputSub1Large::OnBnClickedButtonOutputInitializeTophat()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	m_pMotor->SetOrigin(AXIS_TOPHAT);
}


void CPaneManualControlIOMonitorOutputSub1Large::OnBnClickedButtonOutputInitializeRot()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	//Dummyfree off
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return;
	}

	m_pMotor->SetOrigin(AXIS_ROT);
}
