/*-------------------------------------------------------------------------------
| ���ϸ� : AsyncComm.H
| �뵵   : Asynchronous Serial Communication Component for WIN 32 API
| ����   : 0.9
|-------------------------------------------------------------------------------
|                          ��  ��  ��  ��  ��  ��
|-------------------------------------------------------------------------------
| ��      ¥ | ������ |            ��       ��        ��       ��
|------------|--------|---------------------------------------------------------
| 1999.12.11 | ������ | Start
|            |        | ������ �ҽ��� �������� �Ͽ� ��� ��ƾ�� �������.
|            |        |
|            |        |
|            |        |
--------------------------------------------------------------------------------*/
#ifndef __ASYNCCOMM_H__
#define __ASYNCCOMM_H__

#include "stdio.h"
#include "stdarg.h"

const char XON_CHAR    = 0x11;
const char XOFF_CHAR   = 0x13;

typedef enum _TASSWAITRESULT { wrSignaled, wrTimeout, wrAbandoned, wrError } TAssWaitResult;

typedef enum _TPORT { COM01, COM02, COM03, COM04, COM05, COM06, COM07, COM08,
                      COM09, COM10, COM11, COM12, COM13, COM14, COM15, COM16,
                      COM17, COM18, COM19, COM20, COM21, COM22, COM23, COM24,
                      COM25, COM26, COM27, COM28, COM29, COM30, COM31, COM32
                    } TPort;

typedef enum _TBAUDRATE { ___2400, ___4800, ___9600, __14400, __19200, __38400, 
                          __56000, __57600, _115200, _128000, _256000 } TBaudRate;
typedef enum _TPARITY { NONE, ODD, EVEN, MARK, SPACE } TParity;
typedef enum _TBYTESIZE { _5, _6, _7, _8 } TByteSize;
typedef enum _TSTOPBITS { _1, _1_5, _2 } TStopBits;
typedef enum _TFlowControl { FC_NONE, FC_XONXOFF, FC_RTS } TFlowControl;
typedef enum _TCommEvent { EVRXCHAR, EVRXFLAG, EVTXEMPTY, EVCTS, EVDSR, EVRLSD, EVBREAK,
                           EVERR, EVRING } TCommEvent;

class CAssEvent
{
private:
	volatile HANDLE FHandle;

public:
	CAssEvent(LPSECURITY_ATTRIBUTES EventAttributes = NULL, BOOL ManualReset = false,
				BOOL InitialState = false, char * Name = "");
	virtual ~CAssEvent();
	TAssWaitResult WaitFor(long TimeOut);
	void SetEvent(void);
	void ResetEvent(void);
};

class CAsyncComm
{
	friend UINT procCommThread(LPVOID pParam);

private:
	BOOL StartCommThread(void); // Comm Port �˻�� Thread �� �۵�
	BOOL StopCommThread(void);  // Comm Port �˻�� Thread �� ����

	volatile BOOL CommThreadTerminated; // Comm Port �˻�� Thread �� ���� ���θ�
	CWinThread * m_CommThread; // Comm Port ����� Thread

protected:
	volatile HANDLE FHandle;
	volatile HANDLE m_hevEventCharReceived;

	volatile BOOL FPortOpened; // �ش� Port�� ���ȴ°�?

	DWORD FMaxInQueue;
	DWORD FMaxOutQueue;
	DWORD FTimeOut; // �ִ� ��ٸ� �ð� ����
	BOOL m_bHIOKI8431;

	COMMTIMEOUTS FCommTimeouts;
	DCB FDCB;
	TBaudRate FBaudRate;
	TParity FParity;
	TByteSize FByteSize;
	TStopBits FStopBits;
	TFlowControl FFlowControl;
	BOOL FBinaryMode;
	BOOL FCheckParity;
	BOOL FDiscardNull;
	char FEventChar;
	TPort FPort;
	CString FPortName;
	DWORD FCommEvents;
	DWORD FEventMask;
  
	OVERLAPPED FOVRead, FOVWrite;
	COMSTAT FComStat;

	virtual void FireTXStatus(BOOL Value);
	virtual void FireRXStatus(BOOL Value);
	void FireCommError(int nErrCode, char * szErrDesc);
	virtual void FireTimeOut(void);
	void FireMessage(char * szMsg);
	void FireCommEvents(UINT dwCommEvents);
	virtual void FireReceived(void);
	virtual void FireEventCharReceived(void);
	virtual void FireOpenStatus(BOOL State);

public:
	void SetHIOKI8431(BOOL bHIOKI);
	CAsyncComm(); 
	virtual ~CAsyncComm();
	BOOL OpenComm(void);
	BOOL CloseComm(void);
    
	BOOL InitTimeOut(void);
	BOOL InitDCB(void);
	void SetPort(TPort Value);
	TPort GetPort(void);

	void SetBaudRate(TBaudRate Value);
	TBaudRate GetBaudRate(void);

	void SetParity(TParity Value);
	TParity GetParity(void);

	void SetByteSize(TByteSize Value);
	TByteSize GetByteSize(void);

	void SetStopBits(TStopBits Value);
	TStopBits GetStopBits(void);

	void SetEventChar(char ch);

	void SetFlowControl(TFlowControl Value);
	void SetCommEvents(DWORD Value);
	void SetTimeOut(DWORD Value);

	void ProcessCommError(DWORD dwCommError);

	char * ReadComm(int ACount);
	BOOL ReadChar(char * szRead, DWORD dwToRead);
	char * ReadString(void);

	int Write(char * ABuffer, int ACount);
	BOOL WriteChar(char * szData, DWORD dwToWrite, int * dwWritten);
	BOOL WriteString(char * szData);

	void SetMaxInQueue(DWORD Value);
	void SetMaxOutQueue(DWORD Value);
	DWORD GetMaxInQueue(void);
	DWORD GetMaxOutQueue(void);

	void SetBinaryMode(BOOL Value);
	void CheckParity(BOOL Value);

	BOOL PortOpened(void);

	void SetEventMask(DWORD Value);

	void SetAcceptNULL(BOOL bUse = FALSE);
	void SetCmdSize(int nNum = 0);

	void SetPortOpen(BOOL bOpen);

	int m_nCmdSize;
	BOOL m_bAcceptNULL;
};

UINT	procCommThread(LPVOID pParam);

#endif __ASYNCCOMM_H__



