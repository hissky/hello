// DeviceUMacLarge.cpp: implementation of the DeviceUMacLarge class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DeviceUMacLarge.h"
#include "..\..\MotionControlDLL_2010\MotionControlDll_Interface.h"
#include "..\alarmmsg.h"
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\model\DBeampathINI.h"
#include "..\InterfaceMotorModule.h"
#include "..\model\DSystemINI.h"
#include "..\Model\DProcessINI.h"
#include "..\Model\GlobalVariable.h"
#include "hdevicefactory.h"
#include "devicemotor.h"
#include "..\Model\DProcessINI.h"

#define WRITE_BASE			0x610A0
#define READ_BASE			0x61000
#define SET_XY_PARAM_BASE	0x40

#define TIME_STATUS			50
#define WAIT_COMMAND_TIME	20
#define MAX_STOPOVER_TIME	25.0
#define MP920_SCALE			1000.0

UINT DeviceUMacLarge::ThreadUMacStatus(LPVOID pParam)
{
	DeviceUMacLarge *pUMac = (DeviceUMacLarge *)pParam;
	BOOL bFirst = TRUE;
	
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
		// read
		if(pUMac->m_bReadStatus)
			pUMac->ReadStatus(bFirst);

		if(bFirst)
			bFirst = FALSE;
		
	} while(!pUMac->m_bStatusStop);
	return TRUE;
}

UINT DeviceUMacLarge::ThreadUMacInPosition(LPVOID pParam)
{
	DeviceUMacLarge *pUMac = (DeviceUMacLarge *)pParam;
	
	pUMac->m_bCommandStop = false;
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
			switch(pUMac->m_nInPositionCommand)
			{
			case COMMAND_INPOSITION :		// ���� ����
				if(pUMac->IsMoveEnd(pUMac->m_nInPositionAxis))
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_INORIGIN	:		// ���� ����
				if(pUMac->IsMotorOrigin(pUMac->m_nInPositionAxis))
					pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_LOADSTOP	:		// Loader ����
				//if(pUMac->m_NewStatus.m_bPCBLoadEnd)//20160418 IO
				//	pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_LOADMOVING	:		// Loader ����
				//if(pUMac->m_NewStatus.m_bPCBLoading)//20160418 IO
					///pUMac->m_nIsInPosition = TRUE;
				break;
//			case COMMAND_UNLOADSTOP	:		// Unload ����
//				if(pUMac->m_NewStatus.m_bPCBUnloadEnd)//2)
//					pUMac->m_nIsInPosition = TRUE;
//				break;
//			case COMMAND_UNLOADMOVING	:	// Unload ����
//				if(pUMac->m_NewStatus.m_bPCBUnloading)
//					pUMac->m_nIsInPosition = TRUE;
//				break;
			case COMMAND_ALIGNERSTOP	:	// Aligner ����
				//if(pUMac->m_NewStatus.m_bLoaderAlignEnd)//20160418 IO
				//	pUMac->m_nIsInPosition = TRUE;
				break;
			case COMMAND_ALIGNERMOVING	:	// Aligner ����
				//if(pUMac->m_NewStatus.m_bLoaderAligning)//20160418 IO
				//	pUMac->m_nIsInPosition = TRUE;
				break;
			}
		
		if(pUMac->m_nIsInPosition == TRUE)
			pUMac->m_pStopTime.StartTime();
		
		if(pUMac->m_pStopTime.PresentTime() > MAX_STOPOVER_TIME)
			pUMac->m_nIsInPosition = -1;
	} while(!pUMac->m_bPositionStop);
	return TRUE;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DeviceUMacLarge::DeviceUMacLarge()
{
	m_thdStatus			= NULL;
	m_thdInPosition		= NULL;
	m_bStatusStop		= FALSE;
	m_nMaskPos			= -1;
	m_nMaskPos2			= -1;
	m_nIsInPosition		= FALSE;
	m_bPositionStop		= FALSE;
	m_nInPositionCount	= 0;

	m_lErrorIo			=0;
	m_lErrorLoad		=0;
	m_lErrorLoad2       =0;
	m_lErrorLoad3       =0;
	m_lErrorUnload		=0;
	m_lErrorUnload2		=0;
	m_lErrorUnload3		=0;
	m_lErrorAligner		=0;
	m_lErrorTableLimit	=0;
	m_lErrorOtherLimit	=0;
	m_lErrorTable		=0;
	m_lErrorLaser		=0;

	m_lStatusIO1		=0;
	m_lStatusIO2		=0;
	m_lStatusIO3		=0;

	m_lStatusIO5		=0;
	m_lStatusIO6		=0;
	m_lStatusIO7		=0;
	m_lStatusIO8		=0;

	m_lStatusMelsec		=0;
	m_dFixedMaskPos		=0.0;
	for(BYTE nAxis = 0; nAxis < MOTOR_AXIS_MAX; nAxis++)
	{
		m_lWritePos[nAxis] = 0;			// �̵��� ��ġ
		m_bIsInPosition[nAxis] = FALSE;
		m_dScale[nAxis] = MP920_SCALE;
		m_lSpeed[nAxis] = 0;
	}
	m_dScale[AXIS_M] = 1.0;		// 1���� �Ÿ� 360.0��
	m_dScale[AXIS_M2] = 1.0;		// 1���� �Ÿ� 360.0��
	m_dScale[AXIS_M3] = 1.0;		// 1���� �Ÿ� 360.0��
	m_dScale[AXIS_M4] = 1.0;		// 1���� �Ÿ� 360.0��

	m_dScale[AXIS_TOPHAT] = 1.0;		// 1���� �Ÿ� 360.0��
	m_dScale[AXIS_ROT] = 1.0;		// 1���� �Ÿ� 360.0��

	SetAxisMax(MOTOR_AXIS_MAX);

	m_nNoPCBCount = 0;
	m_nPort = 0;
	m_bConnect = FALSE;
	m_bShowErrMsg = FALSE;
	m_bOldM1 = FALSE;
	m_bOldM2 = FALSE;
	m_bOldM3 = FALSE;
	m_bOldM4 = FALSE;
	m_bReadStatus = TRUE;
	m_bOldBet1 = FALSE;
	m_bOldBet2 = FALSE;
	m_bOldBet3 = FALSE;
	m_bOldBet4 = FALSE;
	m_bOldRot = FALSE;
	m_bOldTopHat = FALSE;
}

DeviceUMacLarge::~DeviceUMacLarge()
{
	m_bStatusStop = TRUE;
	m_bPositionStop = TRUE;

	if(m_thdStatus != NULL)		// Thread ����
		WaitForSingleObject(m_thdStatus->m_hThread, INFINITE);
	m_thdStatus = NULL;

	if(m_thdInPosition != NULL)
	{
		m_thdInPosition->ResumeThread();
		WaitForSingleObject(m_thdInPosition->m_hThread, INFINITE);
	}
#ifdef __SERVO_MOTOR__
	Disconnect();
#endif
	if(::MotionControlDLL_IsInitialized())
	{
		::MotionControlDLL_Uninitialize();
	}
}

BOOL DeviceUMacLarge::Initialize()
{
	CString strPath;
	CString strMotionControlProfile, strPMACProfile, strInputIOProfile, strOutputIOProfile;

	strPath.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	strMotionControlProfile.Format(
		_T("%s\\MotionControl.ini"),
		strPath
		);
	
	strPMACProfile.Format(
		_T("%s\\PMACProfile.ini"),
		strPath
		);
	
	strInputIOProfile.Format(
		_T("%s\\InputIOControl.ini"),
		strPath
		);
	
	strOutputIOProfile.Format(
		_T("%s\\OutputIOControl.ini"),
		strPath
		);
	
	BOOL bResult = ::MotionControlDLL_Initialize(
		strPMACProfile,
		strMotionControlProfile,
		strInputIOProfile,
		strOutputIOProfile
		);

#ifdef __SERVO_MOTOR__
	BOOL bSevroResult = Servo_Connect_E(192, 168,0, 2,EZ_SERVO_C1);
	bSevroResult = bSevroResult && Servo_Connect_E(192, 168,0, 3,EZ_SERVO_C2);
	bSevroResult = bSevroResult && Servo_Connect_E(192, 168,0, 4,EZ_SERVO_C3);
	bSevroResult = bSevroResult && Servo_Connect_E(192, 168,0, 5,EZ_SERVO_C4);
	bSevroResult = bSevroResult && Servo_Connect_E(192, 168,0, 6,EZ_SERVO_M1);
	bSevroResult = bSevroResult && Servo_Connect_E(192, 168,0, 7,EZ_SERVO_M2);

	if(!bSevroResult)
	{
	     ErrMessage("Servo Connect Fail !!");
	}
	else
	{
		bSevroResult = Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		bSevroResult = Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bSevroResult = Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		bSevroResult = Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		bSevroResult = Servo_ServoEnable(EZ_SERVO_C3, TRUE);
		bSevroResult = Servo_ServoEnable(EZ_SERVO_C4, TRUE);


	Sleep(1000);
	BOOL bM1,bM2, bM3, bM4 = TRUE,bB1, bB2, bB3, bB4;
	bM1 = Servo_GetEnable(EZ_SERVO_M1);
	bM2 = Servo_GetEnable(EZ_SERVO_M2);
	bB1 = Servo_GetEnable(EZ_SERVO_C1);
	bB2 = Servo_GetEnable(EZ_SERVO_C2);
	bB3 = Servo_GetEnable(EZ_SERVO_C3);
	bB4 = Servo_GetEnable(EZ_SERVO_C4);
	}
#endif

	if(bResult)
	{
		if(m_thdStatus == NULL)		// Thread  Ȱ��ȭ
		{
			m_thdStatus = ::AfxBeginThread(ThreadUMacStatus, this);
		}

		if(m_thdInPosition == NULL)
		{
			m_thdInPosition = ::AfxBeginThread(ThreadUMacInPosition, this);
			m_thdInPosition->SuspendThread();
		}
	}

	return bResult;
}

void DeviceUMacLarge::ReadStatus(BOOL bFirst)
{
	::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition7), &m_NewStatus);

	ReadPosition();
	ReadErrorIo();
	ReadErrorLoad1();
	ReadErrorLoad2();
	ReadErrorLoad3();
	ReadErrorUnload1();
	ReadErrorUnload2();
	ReadErrorUnload3();
	ReadErrorAligner();
	ReadErrorTableLimit();
	ReadErrorOtherLimit();
	ReadErrorTable();
	ReadErrorLaser();
	ReadErrorOthers();
	ReadErrorOthers2();
	ReadErrorOthers3();
	ReadErrorOthers4();
	ReadErrorOthers5();
	ReadErrorOthers6();

	ReadStatusMelsec();
	ReadStatusIO1();
	ReadStatusIO2();
	ReadStatusIO3();
	ReadStatusIO4();

	ReadStatusIO5();
	ReadStatusIO6();
	ReadStatusIO7();
	ReadStatusIO8();

#ifdef __SERVO_MOTOR__
	BOOL bM1,bM2, bM3, bM4 = TRUE,bB1, bB2, bB3, bB4;
	bM1 = Servo_GetEnable(EZ_SERVO_M1);
	bM2 = Servo_GetEnable(EZ_SERVO_M2);
	bB1 = Servo_GetEnable(EZ_SERVO_C1);
	bB2 = Servo_GetEnable(EZ_SERVO_C2);
	bB3 = Servo_GetEnable(EZ_SERVO_C3);
	bB4 = Servo_GetEnable(EZ_SERVO_C4);

	// �Ѵ� enable�� ����� ������ ����ɷ� ���� 
	if(!bB1 &&!bB2 && !bB3 && !bB4 && !bM1 && !bM2 && !m_bShowErrMsg && m_bConnect)
	{
		//ErrMessage(_T("2 Mask Connection is closed.\nPlease Check Connection and Initial 2 Mask."));
		::AfxMessageBox(_T("2 Mask Connection is closed.\nPlease Check Connection and Initial 2 Mask."));
		m_bConnect = FALSE;
		m_bShowErrMsg = TRUE; 
		Servo_SetReconnect(TRUE);
	}
	//�ٽ� ������ �Ǽ� enable�� ����� ������ m_bConnect Flag�� �ٲ��� 
	if(!m_bOldBet1 && bB1&&!m_bOldBet2 && bB2 &&!m_bOldM1 && bM1&&!m_bOldM2 && bM2 && !m_bOldBet3 && bB3&&!m_bOldBet4 && bB4)
	{
		m_bShowErrMsg = FALSE;
		if(!m_bConnect)
		{
			m_bConnect = TRUE;
		}
	}
	m_bOldBet1 = bB1; 
	m_bOldBet2 = bB2;
	m_bOldBet3 = bB3; 
	m_bOldBet4 = bB4;
	m_bOldM1 = bM1; 
	m_bOldM2 = bM2; 


	if(bB1 &&bB2 && bB3 && bB4 && bM1 && bM2)
	{

		m_bConnect = TRUE;

		DownloadOpticAxisPosToPLC();//20170926

		if(MODE_MPG == GetCurrentMode()) 
			JogMoveOpticAxis();

	}

#endif
	if(bFirst)
	{
		memcpy(&m_OldStatus, &m_NewStatus, sizeof(DpramReadPosition7));
		SetInitialCmd();
	}
}

BOOL DeviceUMacLarge::SetOffset(int nAxis, double dOffset) // offset or TA
{
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E0, (DWORD)dOffset);
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FD, (DWORD)dOffset);
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F0, (DWORD)dOffset);
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset);
	else if(nAxis == AXIS_M2)
		return MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset);
	else if(nAxis == AXIS_M3) //ejpark 110217 c->bet1 / c2 ->bet2
		return MotionControlDLL_WriteOutputDWord(0x61108, (DWORD)dOffset); //0x61104 -> 0x61108
 	else if(nAxis == AXIS_M4) 
		return MotionControlDLL_WriteOutputDWord(0x6110C, (DWORD)dOffset);
	else if(nAxis == AXIS_C) //ejpark 110217 c->bet1 / c2 ->bet2
		return MotionControlDLL_WriteOutputDWord(0x61108, (DWORD)dOffset); //0x61104 -> 0x61108
	else if(nAxis == AXIS_C2) 
		return MotionControlDLL_WriteOutputDWord(0x6110C, (DWORD)dOffset);


	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61110, (DWORD)dOffset);
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61118, (DWORD)dOffset);
	else
		return TRUE;
}

BOOL DeviceUMacLarge::SetOffset(double dOffset[]) // not use
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E0, (DWORD)dOffset[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FD, (DWORD)dOffset[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F0, (DWORD)dOffset[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset[AXIS_M]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset[AXIS_M2]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset[AXIS_M3]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61100, (DWORD)dOffset[AXIS_M4]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61108, (DWORD)dOffset[AXIS_C]); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110C, (DWORD)dOffset[AXIS_C2]); 





	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61110, (DWORD)dOffset[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61118, (DWORD)dOffset[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacLarge::SetSpeed(int nAxis, long lSpeed)
{
	m_lSpeed[nAxis] = lSpeed;
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E2, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FF, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F2, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61102, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_M2)
		return MotionControlDLL_WriteOutputDWord(0x61102, (long)(lSpeed * m_dScale[nAxis]));
			else if(nAxis == AXIS_M3)
		return MotionControlDLL_WriteOutputDWord(0x61102, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_M4)
		return MotionControlDLL_WriteOutputDWord(0x61102, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_C) 
		return MotionControlDLL_WriteOutputDWord(0x6110A, (long)(lSpeed * m_dScale[nAxis])); //61106 -> 6110A
 	else if(nAxis == AXIS_C2) 
		return MotionControlDLL_WriteOutputDWord(0x6110E, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61112, (long)(lSpeed * m_dScale[nAxis]));
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x6111A, (long)(lSpeed * m_dScale[nAxis]));
	else
		return TRUE;
}

BOOL DeviceUMacLarge::SetSpeed(long lSpeed[])
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E2, lSpeed[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FF, lSpeed[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F2, lSpeed[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61102, lSpeed[AXIS_M]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61102, lSpeed[AXIS_M2]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110A, lSpeed[AXIS_M3]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110E, lSpeed[AXIS_M4]);
 	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110A, lSpeed[AXIS_C]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110E, lSpeed[AXIS_C2]);




	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61112, lSpeed[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111A, lSpeed[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacLarge::SetOriginSpeed(int nAxis, long lSpeed) // homeSpeed or TS
{
	if(nAxis == AXIS_X)
		return MotionControlDLL_WriteOutputDWord(0x610E1, lSpeed);
	else if(nAxis == AXIS_Y)
		return MotionControlDLL_WriteOutputDWord(0x610FE, lSpeed);
	else if(nAxis == AXIS_Z1)
		return MotionControlDLL_WriteOutputDWord(0x610F1, lSpeed);
	else if(nAxis == AXIS_M)
		return MotionControlDLL_WriteOutputDWord(0x61101, lSpeed);
	else if(nAxis == AXIS_M2)
		return MotionControlDLL_WriteOutputDWord(0x61101, lSpeed);
	else if(nAxis == AXIS_M3)
		return MotionControlDLL_WriteOutputDWord(0x61101, lSpeed);
	else if(nAxis == AXIS_M4)
		return MotionControlDLL_WriteOutputDWord(0x61101, lSpeed);
	else if(nAxis == AXIS_C) 
		return MotionControlDLL_WriteOutputDWord(0x61109, lSpeed); 
	else if(nAxis == AXIS_C2) 
		return MotionControlDLL_WriteOutputDWord(0x6110D, lSpeed);
	else if(nAxis == AXIS_L_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61111, lSpeed);
	else if(nAxis == AXIS_UL_CARRIER)
		return MotionControlDLL_WriteOutputDWord(0x61119, lSpeed);
	else
		return TRUE;
}

BOOL DeviceUMacLarge::SetOriginSpeed(long lSpeed[]) // homeSpeed or TS
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E1, lSpeed[AXIS_X]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610FE, lSpeed[AXIS_Y]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F1, lSpeed[AXIS_Z1]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61101, lSpeed[AXIS_M]); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61101, lSpeed[AXIS_M2]);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61101, lSpeed[AXIS_M3]); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61101, lSpeed[AXIS_M4]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61109, lSpeed[AXIS_C]); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6110D, lSpeed[AXIS_C2]); 


	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61111, lSpeed[AXIS_L_CARRIER]);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61119, lSpeed[AXIS_UL_CARRIER]);
	return bResult;
}

BOOL DeviceUMacLarge::SetVibration(int nCount, double dDelay, int nLPTime)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610C4, nCount);
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610C5, nLPTime);

//	int nValue = (dDelay + 0.001) * 10;

//	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61108, nCount);
//	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61109, nValue);

	return bResult;
}

BOOL DeviceUMacLarge::SetLimitZ(double dPosZ1Low, double dPosZ1High, double dPosZ2Low, double dPosZ2High, double dXMin, double dXMax)
{
	BOOL bResult = TRUE;
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F5, GetIntPosition(dPosZ1Low, AXIS_Z1));	// z1 limit -
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F6, GetIntPosition(dPosZ1High, AXIS_Z1)); // z1 limit +
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F7, GetIntPosition(dPosZ2Low, AXIS_Z2));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610F8, GetIntPosition(dPosZ2High, AXIS_Z2));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E3, GetIntPosition(dXMin, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E4, GetIntPosition(dXMax, AXIS_X));
	return bResult;
}

DWORD DeviceUMacLarge::GetIntPosition(double dPos, int nAxis)
{
	DWORD nResult = (DWORD)(((dPos + 0.5) / m_dScale[nAxis]) * m_dScale[nAxis]);
	return nResult;
}

void DeviceUMacLarge::SetScale(int nAxis, double dScale)
{
	m_dScale[nAxis] = dScale;
}

BOOL DeviceUMacLarge::SetAxisMax(int nAxisMax)
{
	m_nAxisMax = nAxisMax;
	return TRUE;
}

BOOL DeviceUMacLarge::SetOrigin(int nAxis)
{


	Servo_AlarmReset();

	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	m_nMaskPos2 = -1;

	switch(nAxis)
	{
	case -1:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 0, 1);

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		bResult = Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bResult = Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		bResult = Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		bResult = Servo_ServoEnable(EZ_SERVO_C3, TRUE);
		bResult = Servo_ServoEnable(EZ_SERVO_C4, TRUE);

		bResult = Servo_AllMoveOriginSingleAxis();

		break;
	case AXIS_X:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 1);
		break;
	case AXIS_Y:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 2);
		break;
	case AXIS_Z1:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B1, 1);
		break;
	case AXIS_Z2:
		bResult = MotionControlDLL_WriteOutputDWord(0x610B2, 1);
		break;

	case AXIS_M:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_M1);

		break;
	case AXIS_M2:

		if(!m_bConnect)
			return FALSE;


		bResult = Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_M2);

		break;
	case AXIS_M3:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_M3, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_M3);

		break;

	case AXIS_TOPHAT:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_TOPHAT, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_TOPHAT);

		break;

	case AXIS_C:
		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_C1);

		break;
	case AXIS_C2:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_C2);

		break;
	case AXIS_C3:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_C3, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_C3);

		break;
	case AXIS_C4:

		if(!m_bConnect)
			return FALSE;

		bResult = Servo_ServoEnable(EZ_SERVO_C4, TRUE);
		bResult = Servo_MoveOriginSingleAxis(EZ_SERVO_C4);

		break;
	case AXIS_L_CARRIER:
		bResult = MotionControlDLL_WriteOutputDWord(0x610C1, 1);
		break;
	case AXIS_UL_CARRIER:
		bResult = MotionControlDLL_WriteOutputDWord(0x610D1, 1);
		break;
	}

	return bResult;
}

BOOL DeviceUMacLarge::GetPosition(int nAxis, double &dPosition) // real position
{
	
	if(nAxis == AXIS_X)
		dPosition = m_NewStatus.m_nXActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Y)
		dPosition = m_NewStatus.m_nYActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Z1)
		dPosition = m_NewStatus.m_nZ1ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_Z2)
		dPosition = m_NewStatus.m_nZ2ActualPos / m_dScale[nAxis];
	else if(nAxis == AXIS_M)
	{
		if(!m_bConnect)
			return FALSE;

		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];	

		long lErrorPos;
		Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
		dPosition += (double)lErrorPos/ m_dScale[nAxis];	
		

	}
	else if( nAxis == AXIS_M2)
	{

		if(!m_bConnect)
			return FALSE;

		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];	

		long lErrorPos;
		Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
		dPosition += (double)lErrorPos/ m_dScale[nAxis];

	}

	else if(nAxis == AXIS_C)
	{

		if(!m_bConnect)
			return FALSE;
		
		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];		

	}
	else if(nAxis == AXIS_C2)
	{

		if(!m_bConnect)
			return FALSE;

		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];		

	}
	else if(nAxis == AXIS_C3)
	{

		if(!m_bConnect)
			return FALSE;

		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_C3, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];		

	}
	else if(nAxis == AXIS_C4)
	{

		if(!m_bConnect)
			return FALSE;

		long lCurrPos;
		Servo_GetActualPos(EZ_SERVO_C4, &lCurrPos);
		dPosition = (double)lCurrPos/ m_dScale[nAxis];		

	}


	return TRUE;
}

BOOL DeviceUMacLarge::SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E7, GetIntPosition(dLoadX, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E8, GetIntPosition(dLoadY, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E9, GetIntPosition(dUnload1X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EA, GetIntPosition(dUnload1Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EB, GetIntPosition(dUnload1X, AXIS_X)); // ����� �ϳ��� ��ε���
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EC, GetIntPosition(dUnload1Y, AXIS_Y));
	
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610ED, GetIntPosition(dUnload2X, AXIS_X)); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EE, GetIntPosition(dUnload2Y, AXIS_Y)); 
	return bResult;	
}

BOOL DeviceUMacLarge::SetLoaderUnloaderPos(double dLoadX, double dLoadY, double dUnload1X, double dUnload1Y, double dUnload2X, double dUnload2Y, double dLoadX2, double dLoadY2)
{
	BOOL bResult = TRUE;
	
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E7, GetIntPosition(dLoadX, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E8, GetIntPosition(dLoadY, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610E9, GetIntPosition(dUnload1X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EA, GetIntPosition(dUnload1Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EB, GetIntPosition(dUnload2X, AXIS_X));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EC, GetIntPosition(dUnload2Y, AXIS_Y));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610ED, GetIntPosition(dLoadX2, AXIS_X)); 
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610EE, GetIntPosition(dLoadY2, AXIS_Y)); 
	
	return bResult;	
}

BOOL DeviceUMacLarge::SetLoaderUnloaderPickerPos(double dLoaderCartPos, double dLoaderCartPos2, double dLoaderLoadPos, double dLoaderLoadPos2, double dLoaderAlignPos, double dUnloaderCartPos, double dUnloaderUnloadPos, double dUnloaderUnloadPos2, double dUnloaderAlignPos)
{
	BOOL bResult = TRUE;

	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61113, GetIntPosition(dLoaderCartPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61114, GetIntPosition(dLoaderLoadPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61115, GetIntPosition(dLoaderAlignPos, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61116, GetIntPosition(dLoaderLoadPos2, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x61117, GetIntPosition(dLoaderCartPos2, AXIS_L_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111E, GetIntPosition(dUnloaderUnloadPos2, AXIS_UL_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111D, GetIntPosition(dUnloaderAlignPos, AXIS_UL_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111C, GetIntPosition(dUnloaderCartPos, AXIS_UL_CARRIER));
	bResult = bResult & MotionControlDLL_WriteOutputDWord(0x6111B, GetIntPosition(dUnloaderUnloadPos, AXIS_UL_CARRIER));

	return bResult;
}

BOOL DeviceUMacLarge::DownloadPosition(int nAxis, double dPosition)
{
	int nCount = 0;
	BOOL bResult = TRUE;
	DWORD nSetPos, nGetPos;
	nSetPos = DWORD(dPosition * m_dScale[nAxis]);
	
	while(nCount < 20)
	{
		switch(nAxis)
		{
		case AXIS_X:
			bResult = MotionControlDLL_WriteOutputDWord(0x610E5, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x40, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_Y:
			bResult = MotionControlDLL_WriteOutputDWord(0x610E6, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x48, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_Z1:
			bResult = MotionControlDLL_WriteOutputDWord(0x610F3, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x50, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			} 
			break;
		case AXIS_Z2:
			bResult = MotionControlDLL_WriteOutputDWord(0x610F4, nSetPos);
			::Sleep(WAIT_COMMAND_TIME);
			bResult = MotionControlDLL_ReadInputIO(0x58, nGetPos);
			if(nSetPos == nGetPos)
			{
				m_lWritePos[nAxis] = nSetPos;
				return TRUE;
			}
			break;
		case AXIS_M:
		case AXIS_M2:
		case AXIS_M3:
		case AXIS_C: 
		case AXIS_C2: 
		case AXIS_C3: 
		case AXIS_C4: 

			m_lWritePos[nAxis] = nSetPos;
			return TRUE;


			return TRUE;
			break;




		}
		nCount++;
	}

	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveAxis(int nAxis, double dPosition)
{
	BOOL bResult = TRUE;
	bResult = DownloadPosition(nAxis, dPosition);
	
//	CString strFile, strLog;
//	strFile.Format(_T("Inpos"));
//	strLog.Format(_T("Move[%d] (%.3f)"), nAxis, dPosition);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		switch(nAxis)
		{
			case AXIS_X:
				return MotionControlDLL_WriteOutputDWord(0x610B0, 3);
				break;
			case AXIS_Y:
				return  MotionControlDLL_WriteOutputDWord(0x610B0, 4);
				break;
			case AXIS_Z1:
				return  MotionControlDLL_WriteOutputDWord(0x610B1, 2); 
				break;
			case AXIS_Z2:
				return  MotionControlDLL_WriteOutputDWord(0x610B2, 2);
				break;

			case AXIS_M:
				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , (int)(m_lWritePos[AXIS_M]), m_lSpeed[AXIS_M]);

				break;
			case AXIS_M2:

				if(!m_bConnect)
					return FALSE;

				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , (int)(m_lWritePos[AXIS_M2]), m_lSpeed[AXIS_M2]);
				break;
			case AXIS_M3:
				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_M3 , (int)(m_lWritePos[AXIS_M3]), m_lSpeed[AXIS_M3]);

				break;
			case AXIS_C:

				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , (int)(m_lWritePos[AXIS_C] ), m_lSpeed[AXIS_C]);
				break;
			case AXIS_C2:
				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , (int)(m_lWritePos[AXIS_C2]), m_lSpeed[AXIS_C2]);
				break;
			case AXIS_C3:
				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , (int)(m_lWritePos[AXIS_C3]), m_lSpeed[AXIS_C3]);
				break;
			case AXIS_C4:
				if(!m_bConnect)
					return FALSE;
				return Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , (int)(m_lWritePos[AXIS_C4]), m_lSpeed[AXIS_C4]);
				break;





		}
		return TRUE;
	}
	else
		return FALSE;
	
}

BOOL DeviceUMacLarge::MotorMoveXY(double dPosX, double dPosY)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos");
//	strLog.Format(_T("Move[XY] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(bResult)
	{
		return MotionControlDLL_WriteOutputDWord(0x610B0, 5);
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveZ(double dPosZ1)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B1, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveZ(double dPosZ1, double dPosZ2)
{
	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);

//	CString strFile, strLog;
//	strFile.Format(_T("Inpos");
//	strLog.Format(_T("Move[XYZ] (%.3f, %.3f)"), dPosX, dPosY);
//	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL bTophat)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dPosM);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dPosM);
		bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);
	}
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2); //temp

	if(bResult)
	{
		if(!bTophat)
		{
			return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
				MotionControlDLL_WriteOutputDWord(0x610B6, 2));
		}
		else
		{
			return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B3, 2) & //m1
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) & 
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
				MotionControlDLL_WriteOutputDWord(0x610B6, 2));
		}
	}
	return FALSE;	
}

BOOL DeviceUMacLarge::MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat )
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos);
	}
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));

	}

	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveM(int nMaskPos)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;

	bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2)); // & 
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveM(double dMaskPos)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	if(bResult)
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2)); // & 
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2));
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveMC(double dMaskPos, double dPosC)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) & 
				MotionControlDLL_WriteOutputDWord(0x610B6, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	}

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);

	return bResult;
}

BOOL DeviceUMacLarge::MotorShutterAll(BOOL bOpenMaster/*TRUE*/, BOOL bOpenSlave/*TRUE*/)
{
	BOOL bResult = TRUE;
	bResult = bResult & SetOutPort(PORT_SHUTTER_MASTER, bOpenMaster, FALSE);
	bResult = bResult & SetOutPort(PORT_SHUTTER_SLAVE, bOpenSlave, FALSE);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderOrigin()
{
	return MotionControlDLL_WriteOutputIOBit(3, 0, TRUE);
}

BOOL DeviceUMacLarge::LoaderAlign(BOOL bOn)
{
	return MotionControlDLL_WriteOutputIOBit(3, 2, bOn); 
}

BOOL DeviceUMacLarge::LoaderLoading(BOOL bOn)
{
	return MotionControlDLL_WriteOutputIOBit(3, 1, bOn); 
}

BOOL DeviceUMacLarge::SetDrillStatus(BOOL bDrilling)
{
	return MotionControlDLL_WriteOutputIOBit(3, 3, bDrilling);;
}

BOOL DeviceUMacLarge::UnloadOrigin()
{
	return MotionControlDLL_WriteOutputIOBit(6, 0, TRUE);
}

BOOL DeviceUMacLarge::UnloadUnloading(BOOL bOn)
{
	return MotionControlDLL_WriteOutputIOBit(6, 1, bOn);
} 

BOOL DeviceUMacLarge::Stop(int nAxis)
{
	nAxis;
	switch(nAxis)
	{
	case AXIS_X:
	case AXIS_Y:
		MotionControlDLL_WriteOutputDWord(0x610B0, 9);
		break;
	case AXIS_Z1:
		MotionControlDLL_WriteOutputDWord(0x610B1, 3);
		break;
	case AXIS_Z2:
		MotionControlDLL_WriteOutputDWord(0x610B2, 3);
		break;
	case AXIS_M:
		MotionControlDLL_WriteOutputDWord(0x610B3, 3);
		break;
	case AXIS_C:
		MotionControlDLL_WriteOutputDWord(0x610B5, 3);
		break;
	case AXIS_C2:
		MotionControlDLL_WriteOutputDWord(0x610B6, 3);
		break;
//	case AXIS_M2:
//		MotionControlDLL_WriteOutputDWord(0x610B4, 3);
//		break;
	case AXIS_L_CARRIER:
		MotionControlDLL_WriteOutputDWord(0x610C1, 4);
		break;
	case AXIS_UL_CARRIER:
		MotionControlDLL_WriteOutputDWord(0x610D1, 4);
		break;
	}

	return TRUE;
}

LONG DeviceUMacLarge::GetCurrentError(ERRORCOMMAND nError)
{
	switch(nError)
	{
	case ERROR_IO			:
		return m_lErrorIo;
	case ERROR_LOAD			:
		return m_lErrorLoad;
	case ERROR_LOAD2		:
		return m_lErrorLoad2;
	case ERROR_LOAD3		:
		return m_lErrorLoad3;
	case ERROR_UNLOAD		:
		return m_lErrorUnload;
	case ERROR_UNLOAD2		:
		return m_lErrorUnload2;
	case ERROR_UNLOAD3		:
		return m_lErrorUnload3;
	case ERROR_ALIGN		:
		return m_lErrorAligner;
	case ERROR_TABLELIMIT	:
		return m_lErrorTableLimit;
	case ERROR_OTHERLIMIT	:
		return m_lErrorOtherLimit;
	case ERROR_TABLE		:
		return m_lErrorTable;
	case ERROR_LASER		:
		return m_lErrorLaser;
	case ERROR_OTHERS		:
		return m_lErrorOthers;
	case ERROR_OTHERS2		:
		return m_lErrorOthers2;
	case ERROR_OTHERS3		:
		return m_lErrorOthers3;
	case ERROR_OTHERS4		:
		return m_lErrorOthers4;
	case ERROR_OTHERS5		:
		return m_lErrorOthers5;
	case ERROR_OTHERS6		:
		return m_lErrorOthers6;
	case STATUS_IO1			:
		return m_lStatusIO1;
	case STATUS_IO2			:
		return m_lStatusIO2;
	case STATUS_IO3			:
		return m_lStatusIO3;
	case STATUS_IO4			:
		return m_lStatusIO4;
	case STATUS_IO5			://$6100E 
		return m_lStatusIO5;
	case STATUS_IO6			://$6100F
		return m_lStatusIO6;
	case STATUS_IO7			://$61010
		return m_lStatusIO7;
	case STATUS_IO8			://$61011
		return m_lStatusIO8;




	case STATUS_MELSEC		:
		return m_lStatusMelsec;
	}
	return 0;
}

void DeviceUMacLarge::ReadErrorIo()
{/*
	m_lErrorIo = 0;
	m_lErrorIo += (m_NewStatus.m_bEmergencyStopAlarm)			? 0x0001 : 0x0000; // em stop
	m_lErrorIo += (m_NewStatus.m_bServoPowerOffAlarm)			? 0x0002 : 0x0000; // Servo power off alarm
	m_lErrorIo += (m_NewStatus.m_bMainStationInitialError)		? 0x0004 : 0x0000; // main station init error
//	m_lErrorIo += (m_NewStatus.m_bPCAliveOffError)				? 0x0008 : 0x0000; // pc alive signal off error
	m_lErrorIo += (m_NewStatus.m_bFrontDoorOpenAlarm)			? 0x0010 : 0x0000; // Main Door Open	
	m_lErrorIo += (m_NewStatus.m_bRearDoorOpenAlarm)			? 0x0020 : 0x0000; // rear door open
	m_lErrorIo += (m_NewStatus.m_bLaserPowerOffAlarm)			? 0x0040 : 0x0000; // laser power off error
	m_lErrorIo += (m_NewStatus.m_bMainAirAlarm)					? 0x0080 : 0x0000; // Main Suction Alarm
	m_lErrorIo += (m_NewStatus.m_bHeightSensorUpError)			? 0x0100 : 0x0000; // Height Sensor up error
	m_lErrorIo += (m_NewStatus.m_bHeightSensorDownError)		? 0x0200 : 0x0000; // Height Sensor down error
//	m_lErrorIo += (m_NewStatus.m_bHeightSensor2UpError)			? 0x0400 : 0x0000; // Height Sensor up error
//	m_lErrorIo += (m_NewStatus.m_bHeightSensor2DownError)		? 0x0800 : 0x0000; // Height Sensor down error
	//m_lErrorIo += (m_NewStatus.m_bLoadDoorOpenError)			? 0x0400 : 0x0000; // loader door open
//	m_lErrorIo += (m_NewStatus.m_bUnloadDoorOpenError)			? 0x0800 : 0x0000; // unloader door open
	m_lErrorIo += (m_NewStatus.m_b1stShutterCylinderOpenError)	? 0x1000 : 0x0000; // High Speed Shutter#1 �ΰ��� Sensor ON
	m_lErrorIo += (m_NewStatus.m_b1stShutterCylinderCloseError) ? 0x2000 : 0x0000; // High Speed Shutter#1 �ΰ��� Sensor OFF
	m_lErrorIo += (m_NewStatus.m_b2ndShutterCylinderOpenError)	? 0x4000 : 0x0000; // High Speed Shutter#2 �ΰ��� Sensor ON
	m_lErrorIo += (m_NewStatus.m_b2ndShutterCylinderCloseError) ? 0x8000 : 0x0000; // High Speed Shutter#2 �ΰ��� Sensor OFF
	//m_lErrorIo += (m_NewStatus.m_bMainDoorInOutSensorAlarm)		? 0x10000 : 0x0000; //Main Door In Out Sensor Alarm
	*/
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacLarge::ReadErrorLoad1()
{
	m_lErrorLoad = 0;
	m_lErrorLoad += (m_NewStatus.m_bLoaderAlarm)						? 0x0001 : 0x0000; 
	//	m_lErrorLoad += (m_NewStatus.m_bLDStopRNError)						? 0x0002 : 0x0000;
	//m_lErrorLoad += (m_NewStatus.m_bLoaderCartNoPCB)					? 0x0004 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPCBNotExistError)		? 0x0008 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPCBExistError)		? 0x0010 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadRightPickerPCBNotExistError)	? 0x0020 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadRightPickerPCBExistError)		? 0x0040 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoaderInitialError)					? 0x0080 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadAlignTablePCBNotExistError)		? 0x0100 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadAlignTablePCBExistError)		? 0x0200 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerUpError)			? 0x0400 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerDownError)		? 0x0800 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerDown2Error)		? 0x1000 : 0x0000;
	//m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad2UpError)			? 0x1000 : 0x0000;
	//m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerPad2DownError)		? 0x2000 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerVacuumOnError)		? 0x4000 : 0x0000;
	m_lErrorLoad += (m_NewStatus.m_bLoadLeftPickerVacuumOffError)		? 0x8000 : 0x0000;
//	m_lErrorLoad += (m_NewStatus.m_bLoadEStopError)						? 0x10000 : 0x0000;
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacLarge::ReadErrorLoad2()
{
	m_lErrorLoad2 = 0;
	
	//	m_lErrorLoad2 += (m_NewStatus.m_bLoadLeftPickerBlowOnError)			? 0x0001 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerUpError)		? 0x0002 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerDownError)      ? 0x0004 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerDown2Error)     ? 0x0008 : 0x0000;
	//	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad2UpError)		? 0x0008 : 0x0000;
	//	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerPad2DownError)	    ? 0x0010 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerVacuumOnError)		? 0x0020 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerVacuumOffError)		? 0x0040 : 0x0000;
	//	m_lErrorLoad2 += (m_NewStatus.m_bLoadRightPickerBlowOnError)		? 0x0080 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadCartClampError)				? 0x0100 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadCartUnClampError)				? 0x0200 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignSheetTableForwardError)	? 0x0400 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignSheetTableBackwardError)	? 0x0800 : 0x0000;	
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignGuideForwardError)		? 0x1000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignGuideBackwardError)		? 0x2000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignTableMoveLeftError)		? 0x4000 : 0x0000;
	m_lErrorLoad2 += (m_NewStatus.m_bLoadAlignTableMoveRightError)		? 0x8000 : 0x0000;
	
}

////////////////////////////////////
// Purpose		: LoadSection Error �б�
void DeviceUMacLarge::ReadErrorLoad3()
{
	m_lErrorLoad3 = 0;
	
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorMoveLoadLevelError)	? 0x0001 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorMoveOriginError)		? 0x0002 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElevatorAlarmError)			? 0x0004 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMoveCartPosError)		? 0x0008 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMoveLoadPosError)		? 0x0010 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMotionParamError)		? 0x0020 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierFault)					? 0x0040 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierFollowingError)			? 0x0080 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierOpenLoop)				? 0x0100 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierHomeTimeOver)  			? 0x0200 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadLeftPCBTakeReadyError)			? 0x0400 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadRightPCBTakeReadyError)		? 0x0800 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCartDetectSensorError)			? 0x1000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadElvAxisLimitError)				? 0x2000 : 0x0000;
//	m_lErrorLoad3 += (m_NewStatus.m_bLoadNoPCBError)					? 0x4000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierAxisStopError)			? 0x8000 : 0x0000;
//	m_lErrorLoad3 += (m_NewStatus.m_bLoadRightPickerStatusError)		? 0x4000 : 0x0000;
//	m_lErrorLoad3 += (m_NewStatus.m_bLoadLeftPickerStatusError)			? 0x8000 : 0x0000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadPickerUnableDownError)			? 0x10000 : 0x00000;
	m_lErrorLoad3 += (m_NewStatus.m_bLoadLeftPickerFallPCBError)		? 0x20000 : 0x00000;
	
	m_lErrorLoad3 += (m_NewStatus.m_bLoadCarrierMoveAlignPosError)		? 0x40000 : 0x00000;
	
}

//////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacLarge::ReadErrorUnload1()
{
	m_lErrorUnload = 0;
	
	m_lErrorUnload += (m_NewStatus.m_bUnloaderAlarm)						? 0x0001 : 0x0000;
	//	m_lErrorUnload += (m_NewStatus.m_bUDStopRNError)						? 0x0002 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadTablePCBExistError)				? 0x0004 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadTablePCBNotExistError)			? 0x0008 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPCBNotExistError)		? 0x0010 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPCBExistError)		? 0x0020 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerPCBNotExistError)	? 0x0040 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerPCBExistError)		? 0x0080 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerUpError)			? 0x0100 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerDownError)		? 0x0200 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerDown2Error)		? 0x0400 : 0x0000;
	//	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad2UpError)			? 0x0400 : 0x0000;
	//	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerPad2DownError)		? 0x0800 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerVacuumOnError)		? 0x1000 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerVacuumOffError)		? 0x2000 : 0x0000;
	
	//	m_lErrorUnload += (m_NewStatus.m_bUnloadLeftPickerBlowOnError)			? 0x4000 : 0x0000;
	m_lErrorUnload += (m_NewStatus.m_bUnloadRightPickerUpError)			? 0x8000 : 0x0000;
	
}

////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacLarge::ReadErrorUnload2()
{
	m_lErrorUnload2 = 0;
	
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerDownError)		? 0x0001 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerDown2Error)		? 0x0001 : 0x0000;
	//	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerPad2UpError)		? 0x0002 : 0x0000;
	//	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerPad2DownError)		? 0x0004 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerVacuumOnError)		? 0x0008 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerVacuumOffError)		? 0x0010 : 0x0000;
	//	m_lErrorUnload2 += (m_NewStatus.m_bUnloadRightPickerBlowOnError)		? 0x0020 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCartClampError)				? 0x0040 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCartUnClampError)				? 0x0080 : 0x0000;
	//m_lErrorUnload2 += (m_NewStatus.m_bUnloadTableMoveLeftError)		? 0x0100 : 0x0000;
	//m_lErrorUnload2 += (m_NewStatus.m_bUnloadTableMoveRightError)		? 0x0200 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadElevatorMoveLoadLevelError)	? 0x0400 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadElevatorMoveOriginError)		? 0x0800 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadElevatorAlarmError)			? 0x1000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMoveLoadPosError)		? 0x2000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMoveCartPosError)		? 0x4000 : 0x0000;
	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMotionParamError)		? 0x8000 : 0x0000;

	m_lErrorUnload2 += (m_NewStatus.m_bUnloadCarrierMoveAlignPosError)		? 0x10000 : 0x0000;
	
}
////////////////////////////////////
// Purpose		: UnloadSection Error �б�
void DeviceUMacLarge::ReadErrorUnload3()
{
	m_lErrorUnload3 = 0;
	
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierFault)				? 0x0001 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierFollowingError)		? 0x0002 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierOpenLoop)			? 0x0004 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierHomeTimeOver)		? 0x0008 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadLeftPCBTakeReadyError)		? 0x0010 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadRightPCBTakeReadyError)	? 0x0020 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloaderInitialError)			? 0x0040 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCartDetectSensorError)		? 0x0080 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadElvAxisLimitError)			? 0x0100 : 0x0000;

//	m_lErrorUnload3 += (m_NewStatus.m_bUnloadRightPickerStatusError)	? 0x0200 : 0x0000;
//	m_lErrorUnload3 += (m_NewStatus.m_bUnloadLeftPickerStatusError)		? 0x0400 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadPickerUnableDownError)		? 0x0800 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloaderCartFull)				? 0x1000 : 0x0000;
	m_lErrorUnload3 += (m_NewStatus.m_bUnloadCarrierAxisStopError)		? 0x2000 : 0x0000;
	
	
}

////////////////////////////////////
// Purpose		: Aligner Error �б�
void DeviceUMacLarge::ReadErrorAligner() // not use
{
	m_lErrorAligner = 0;
}

///////////////////////////////////////
// Purpose		: Table Limit Error �б�
void DeviceUMacLarge::ReadErrorTableLimit()
{
	m_lErrorTableLimit = 0;
	return; //20210121 �ӽ� ishwang
	m_lErrorTableLimit += (m_NewStatus.m_bXPositiveLimitOver) ? 0x0001 : 0x0000;	// X+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bXNegativeLimitOver) ? 0x0002 : 0x0000;	// X- Limit
	m_lErrorTableLimit += (m_NewStatus.m_bYPositiveLimitOver) ? 0x0004 : 0x0000;	// Y+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bYNegativeLimitOver) ? 0x0008 : 0x0000;	// Y- Limit

	m_lErrorTableLimit += (m_NewStatus.m_bZ1PositiveLimitOver) ? 0x0040 : 0x0000;	// Z1+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ1NegativeLimitOver) ? 0x0080 : 0x0000;	// Z1- Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ2PositiveLimitOver) ? 0x0100 : 0x0000;	// Z2+ Limit
	m_lErrorTableLimit += (m_NewStatus.m_bZ2NegativeLimitOver) ? 0x0200 : 0x0000;	// Z2- Limit
}

////////////////////////////////////////
// Purpose		: Other Limit Error �б�
void DeviceUMacLarge::ReadErrorOtherLimit()
{
	m_lErrorOtherLimit = 0;
	/*
	//m_lErrorOtherLimit += (m_NewStatus.m_bC1PositiveLimitOver)			? 0x0001 : 0x0000;	// C1+ Limit
	//m_lErrorOtherLimit += (m_NewStatus.m_bC1NegativeLimitOver)			? 0x0002 : 0x0000;	// C1- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bLoadCarrierPositiveLimit)		? 0x0004 : 0x0000;	// P1+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bLoadCarrierNegativeLimit)		? 0x0008 : 0x0000;	// P1- Limit
	//m_lErrorOtherLimit += (m_NewStatus.m_bC2PositiveLimitOver)			? 0x0010 : 0x0000;	// C2+ Limit
//	m_lErrorOtherLimit += (m_NewStatus.m_bC2NegativeLimitOver)			? 0x0020 : 0x0000;	// C2- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bUnloadCarrierPositiveLimit)	? 0x0040 : 0x0000;	// P2+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bUnloadCarrierNegativeLimit)	? 0x0080 : 0x0000;	// P2- Limit
//	m_lErrorOtherLimit += (m_NewStatus.m_bM1PositiveLimitOver)			? 0x0100 : 0x0000;  // M1+ Limit
	//m_lErrorOtherLimit += (m_NewStatus.m_bM1NegativeLimitOver)			? 0x0200 : 0x0000;  // M1- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bA1PositiveLimitOver)			? 0x0400 : 0x0000;  // A1+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bA1NegativeLimitOver)			? 0x0800 : 0x0000;  // A1- Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bA2PositiveLimitOver)			? 0x1000 : 0x0000;  // A2+ Limit
	m_lErrorOtherLimit += (m_NewStatus.m_bA2NegativeLimitOver)			? 0x2000 : 0x0000;  // A2- Limit
	*/
}

//////////////////////////////////
// Purpose		: Table Error �б�
void DeviceUMacLarge::ReadErrorTable()
{
	m_lErrorTable = 0;
	return; //20210121 �ӽ� ishwang
	m_lErrorTable += (m_NewStatus.m_bXYMoveDangerError)					? 0x0001 : 0x0000; // xy move danger error
	m_lErrorTable += (m_NewStatus.m_bXYStopError)						? 0x0002 : 0x0000; // XY Stop Error
	m_lErrorTable += (m_NewStatus.m_bXFault)							? 0x0004 : 0x0000; // X Fault
	m_lErrorTable += (m_NewStatus.m_bXFollowError)						? 0x0008 : 0x0000; // X Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bXOpenLoop)							? 0x0010 : 0x0000; // X Open Loop
	m_lErrorTable += (m_NewStatus.m_bXHomeTimeOver)						? 0x0020 : 0x0000; // X Homing TimeOut
	m_lErrorTable += (m_NewStatus.m_bYFault)							? 0x0040 : 0x0000; // Y Fault
	m_lErrorTable += (m_NewStatus.m_bYFollowError)						? 0x0080 : 0x0000; // Y Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bYOpenLoop)							? 0x0100 : 0x0000; // Y Open Loop
	m_lErrorTable += (m_NewStatus.m_bYHomeTimeOver)						? 0x0200 : 0x0000; // Y Homing TimeOut
	m_lErrorTable += (m_NewStatus.m_bZ1Fault)							? 0x0400 : 0x0000; // Z1 Fault
	m_lErrorTable += (m_NewStatus.m_bZ1FollowError)						? 0x0800 : 0x0000; // Z1 Fatal Following Err
	m_lErrorTable += (m_NewStatus.m_bZ1OpenLoop)						? 0x1000 : 0x0000; // Z1 Open Loop
	m_lErrorTable += (m_NewStatus.m_bZ1HomeTimeOver)					? 0x2000 : 0x0000; // Z1 Homing TimeOUt
	m_lErrorTable += (m_NewStatus.m_bZ2Fault)							? 0x4000 : 0x0000; // Z2 Fault
	m_lErrorTable += (m_NewStatus.m_bZ2FollowError)						? 0x8000 : 0x0000; // Z2 Fatal Following Err

//	m_lErrorTable += (m_NewStatus.m_bXServoTempOver)					? 0x10000 : 0x0000; //
	//m_lErrorTable += (m_NewStatus.m_bYServoTempOver)					? 0x20000 : 0x0000; //
}

//////////////////////////////////
// Purpose		: Laser Error �б�
void DeviceUMacLarge::ReadErrorLaser()
{
	m_lErrorLaser = 0;
	//m_lErrorLaser += (m_NewStatus.m_bChillerOnError) ? 0x0001 : 0x0000;	// Chiller Alarm
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�
void DeviceUMacLarge::ReadErrorOthers()
{
	m_lErrorOthers = 0;
	m_lErrorOthers += (m_NewStatus.m_bEmergencyStopAlarm)			? 0x0001 : 0x0000; // 0
	m_lErrorOthers += (m_NewStatus.m_bServoPowerOffAlarm)			? 0x0002 : 0x0000; // 1
	m_lErrorOthers += (m_NewStatus.m_bMainStationInitialError)		? 0x0004 : 0x0000; // 2
	m_lErrorOthers += (m_NewStatus.m_bFrontDoorOpenAlarm)			? 0x0010 : 0x0000; // 4
	m_lErrorOthers += (m_NewStatus.m_bRearDoorOpenAlarm)			? 0x0020 : 0x0000; // 5
	m_lErrorOthers += (m_NewStatus.m_bMPGOnAlarm)			? 0x0040 : 0x0000; // 6
	m_lErrorOthers += (m_NewStatus.m_bLaserPowerOffAlarm)					? 0x0080 : 0x0000; // 7
	m_lErrorOthers += (m_NewStatus.m_bMainAirAlarm)			? 0x0100 : 0x0000; // 8
	m_lErrorOthers += (m_NewStatus.m_bXYMoveDangerError)		? 0x0200 : 0x0000; // 9
	//m_lErrorOthers += (m_NewStatus.m_bHeightSensor2UpError)			? 0x0400 : 0x0000; // 10
	//m_lErrorOthers += (m_NewStatus.m_bRingBlowerOverCurrentAlarm)		? 0x0800 : 0x0000; // 11
	//m_lErrorOthers += (m_NewStatus.m_bRingBlowerOverTempAlarm)			? 0x1000 : 0x0000; // 12
	//m_lErrorOthers += (m_NewStatus.m_bChillerCH1TempFault_Signal)			? 0x2000 : 0x0000; // 13
	//m_lErrorOthers += (m_NewStatus.m_bChillerCH2TempFault_Signal)	? 0x4000 : 0x0000; //  14
	//m_lErrorOthers += (m_NewStatus.m_bGasDetectAlarm)	? 0x8000 : 0x0000; //  15
	//m_lErrorOthers += (m_NewStatus.m_b1stShutterCylinderCloseError) ? 0x8000 : 0x0000; // 15

}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�2
void DeviceUMacLarge::ReadErrorOthers2()
{
	m_lErrorOthers2 = 0;
	m_lErrorOthers2 += (m_NewStatus.m_bSuctionHoodAirOpenError)			? 0x0001 : 0x0000; // 0
	m_lErrorOthers2 += (m_NewStatus.m_bSuctionHoodAirCloseError)			? 0x0002 : 0x0000; // 1
	//m_lErrorOthers2 += (m_NewStatus.m_bChillerEMOAlarm)						? 0x0004 : 0x0000; // 2
	//m_lErrorOthers2 += (m_NewStatus.m_bRingBlowerRunError)				? 0x0008 : 0x0000; // 3
	m_lErrorOthers2 += (m_NewStatus.m_bHeightSensor1UpError)			? 0x0010 : 0x0000; // 4
	m_lErrorOthers2 += (m_NewStatus.m_bHeightSensor1DownError)			? 0x0020 : 0x0000; // 5
	m_lErrorOthers2 += (m_NewStatus.m_bHeightSensor2UpError)			? 0x0040 : 0x0000; // 6
	m_lErrorOthers2 += (m_NewStatus.m_bHeightSensor2DownError)					? 0x0080 : 0x0000; // 7

	m_lErrorOthers2 += (m_NewStatus.m_b1stTableVacuumOnError)			? 0x0100 : 0x0000; // 8
	m_lErrorOthers2 += (m_NewStatus.m_b1stTableVacuumOffError)		? 0x0200 : 0x0000; // 9
	m_lErrorOthers2 += (m_NewStatus.m_b2ndTableVacuumOnError)			? 0x0400 : 0x0000; // 10
	m_lErrorOthers2 += (m_NewStatus.m_b2ndTableVacuumOffError)		? 0x0800 : 0x0000; // 11

	m_lErrorOthers2 += (m_NewStatus.m_b1stShutterCylinderOpenError)			? 0x1000 : 0x0000; // 12
	m_lErrorOthers2 += (m_NewStatus.m_b1stShutterCylinderCloseError)			? 0x2000 : 0x0000; // 13
	m_lErrorOthers2 += (m_NewStatus.m_b2ndShutterCylinderOpenError)	? 0x4000 : 0x0000; //  14
	m_lErrorOthers2 += (m_NewStatus.m_b2ndShutterCylinderCloseError) ? 0x8000 : 0x0000; // 15
}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�3
void DeviceUMacLarge::ReadErrorOthers3()//$61026
{
	m_lErrorOthers3 = 0;
	//m_lErrorOthers3 += (m_NewStatus.m_bMainVacuumError_1)		? 0x0001 : 0x0000;//0
	//m_lErrorOthers3 += (m_NewStatus.m_bWaterLeakageError_1)	? 0x0002 : 0x0000;//1
	m_lErrorOthers3 += (m_NewStatus.m_bPowerDetectorShutterForwardError)		? 0x0004 : 0x0000;//2
	m_lErrorOthers3 += (m_NewStatus.m_bPowerDetectorShutterBackwardError)	? 0x0008 : 0x0000;//3
	m_lErrorOthers3 += (m_NewStatus.m_bLaserSystemWarningError2)					? 0x0010 : 0x0000;//4
	m_lErrorOthers3 += (m_NewStatus.m_bLaserWaterFlowFaultError2)				? 0x0020 : 0x0000;//5
	m_lErrorOthers3 += (m_NewStatus.m_bLaserOverTempFaultError2)				? 0x0040 : 0x0000;//6
	//m_lErrorOthers3 += (m_NewStatus.m_bLaserSlaveBeamPassDownError)		? 0x0080 : 0x0000;	//7
	m_lErrorOthers3 += (m_NewStatus.m_bTableClampUpError)	? 0x0100 : 0x0000;//8
	m_lErrorOthers3 += (m_NewStatus.m_bTableClampDownError)		? 0x0200 : 0x0000;//9	
	m_lErrorOthers3 += (m_NewStatus.m_bTableClamp2UpError)		? 0x0400 : 0x0000;//10
	m_lErrorOthers3 += (m_NewStatus.m_bTableClamp2DownError)		? 0x0800 : 0x0000;//11
	m_lErrorOthers3 += (m_NewStatus.m_bLaserSystemWarning)		? 0x1000 : 0x0000;//12
	m_lErrorOthers3 += (m_NewStatus.m_bLaserWaterFlowFault)			? 0x2000 : 0x0000;//13
	m_lErrorOthers3 += (m_NewStatus.m_bLaserOverTempFault)			? 0x4000 : 0x0000;//14
	//m_lErrorOthers3 += (m_NewStatus.m_bWaterFlowError)			? 0x8000 : 0x0000;//15
	//	m_lErrorOthers3 += (m_NewStatus.m_bLaserSystemWarning)			? 0x80000 : 0x0000;//15

}

/////////////////////////////////
// Purpos		: ��Ÿ ���� �б�4
void DeviceUMacLarge::ReadErrorOthers4()//$61027
{
	m_lErrorOthers4 = 0;
	m_lErrorOthers4 += (m_NewStatus.m_bXYStopError)			? 0x0001 : 0x0000; // 0
	m_lErrorOthers4 += (m_NewStatus.m_bZ1StopError)			? 0x0002 : 0x0000; // 1
	m_lErrorOthers4 += (m_NewStatus.m_bZ2StopError)		? 0x0004 : 0x0000; // 2
	//m_lErrorOthers4 += (m_NewStatus.m_bMasterClampUpError)				? 0x0008 : 0x0000; // 3

	//m_lErrorOthers4 += (m_NewStatus.m_bDustCollectorVacuumError)			? 0x0010 : 0x0000; // 4

	//m_lErrorOthers4 += (m_NewStatus.m_bSlaveClampUpError)			? 0x0020 : 0x0000; // 5
	//m_lErrorOthers4 += (m_NewStatus.m_bSlaveClampDownError)			? 0x0040 : 0x0000; // 6
	
	//m_lErrorOthers4 += (m_NewStatus.m_bAOM_USE_BeamPass3CylUpError)					? 0x0080 : 0x0000; // 7

	//m_lErrorOthers4 += (m_NewStatus.m_bAOM_USE_BeamPass3CylDownError)			? 0x0100 : 0x0000; // 8
	m_lErrorOthers4 += (m_NewStatus.m_bXYMotionParamError)		? 0x0200 : 0x0000; // 9
	m_lErrorOthers4 += (m_NewStatus.m_bZ1MotionParamError)			? 0x0400 : 0x0000; // 10
	m_lErrorOthers4 += (m_NewStatus.m_bZ2MotionParamError)		? 0x0800 : 0x0000; // 11

	//m_lErrorOthers4 += (!m_NewStatus.m_bChillerFault)			? 0x1000 : 0x0000; // 12

	//m_lErrorOthers4 += (m_NewStatus.m_bMelsecError)			? 0x2000 : 0x0000; // 13
	//m_lErrorOthers4 += (m_NewStatus.m_bMelsecUmacCommunicationerror)	? 0x4000 : 0x0000; //  14
	//m_lErrorOthers4 += (m_NewStatus.m_b2ndShutterCylinderCloseError) ? 0x8000 : 0x0000; // 15
	
}
void DeviceUMacLarge::ReadErrorOthers5()//$61023
{
	m_lErrorOthers5 = 0;
	//m_lErrorOthers5 += (m_NewStatus.m_bChillerEMOAlarm)						? 0x0001 : 0x0000; // 0
	//m_lErrorOthers5 += (m_NewStatus.m_bRingBlowerRunError)					? 0x0002 : 0x0000; // 1
	//m_lErrorOthers5 += (m_NewStatus.m_bHeightSensor1UpError)				? 0x0004 : 0x0000; // 2
	//m_lErrorOthers5 += (m_NewStatus.m_bHeightSensor1DownError)				? 0x0008 : 0x0000; // 3

	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH1TempFaultError)			? 0x0010 : 0x0000; // 0
	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH1FlowFaultError)			? 0x0020 : 0x0000; // 1
	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH1PressureFaultError)		? 0x0040 : 0x0000; // 2

	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH2TempFaultError)			? 0x0080 : 0x0000; // 3
	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH2FlowFaultError)			? 0x0100 : 0x0000; // 4
	//m_lErrorOthers5 += (m_NewStatus.m_bChillerCH2PressureFaultError)		? 0x0200 : 0x0000; // 5

}
void DeviceUMacLarge::ReadErrorOthers6()//$61022
{
	m_lErrorOthers6 = 0;
	//m_lErrorOthers6 += (m_NewStatus.m_bAutomaticLubricatorY1Fault)				? 0x0001 : 0x0000; // 5
	//m_lErrorOthers6 += (m_NewStatus.m_bAutomaticLubricatorY2Fault)				? 0x0002 : 0x0000; // 6
	//m_lErrorOthers6 += (m_NewStatus.m_bAutomaticLubricatorXFault)				? 0x0004 : 0x0000; // 7

	//m_lErrorOthers6 += (m_NewStatus.m_bMasterTableVacuumSuction1_1OnError)		? 0x0008 : 0x0000; // 8
	//m_lErrorOthers6 += (m_NewStatus.m_bMasterTableVacuumSuction1_1OffError)		? 0x0010 : 0x0000; // 9
	//m_lErrorOthers6 += (m_NewStatus.m_bMasterTableVacuumSuction1_2OnError)		? 0x0020 : 0x0000; // 10
	//m_lErrorOthers6 += (m_NewStatus.m_bMasterTableVacuumSuction1_2OffError)		? 0x0040 : 0x0000; // 11

	//m_lErrorOthers6 += (m_NewStatus.m_bSlaveTableVacuumSuction1_1OnError)		? 0x0080 : 0x0000; // 12
	//m_lErrorOthers6 += (m_NewStatus.m_bSlaveTableVacuumSuction1_1OffError)		? 0x0100 : 0x0000; // 13
	//m_lErrorOthers6 += (m_NewStatus.m_bSlaveTableVacuumSuction1_2OnError)		? 0x0200 : 0x0000; //  14
	//m_lErrorOthers6 += (m_NewStatus.m_bSlaveTableVacuumSuction1_2OffError)		? 0x0400 : 0x0000; // 15

}
void DeviceUMacLarge::ReadStatusIO1()
{
	m_lStatusIO1 = 0;
	m_lStatusIO1 += (m_NewStatus.m_bMainRunReady)					? 0x0001 : 0x0000;
	//m_lStatusIO1 += (m_NewStatus.m_bHeightSensor2Down)				? 0x0002 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMachineRunning)					? 0x0004 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bSafetyMode)						? 0x0008 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bDoorBypassStatus)			? 0x0010 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bLeftTablePCBExist)				? 0x0020 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bRightTablePCBExist)				? 0x0040 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainInitialEnd)					? 0x0080 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainInitializing)				? 0x0100 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bMainStationAlarm)				? 0x0200 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInitialEnd)					? 0x0400 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInitializing)					? 0x0800 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXInposition)					? 0x1000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bXRun)							? 0x2000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bYInitialEnd)					? 0x4000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus.m_bYInitializing)					? 0x8000 : 0x0000;
}

void DeviceUMacLarge::ReadStatusIO2()
{
	m_lStatusIO2 = 0;
	m_lStatusIO2 += (m_NewStatus.m_bYInposition)					? 0x0001 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bYRun)							? 0x0002 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1InitialEnd)					? 0x0004 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Initializing)					? 0x0008 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Inposition)					? 0x0010 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ1Run)							? 0x0020 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2InitialEnd)					? 0x0040 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Initializing)					? 0x0080 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Inposition)					? 0x0100 : 0x0000;
	m_lStatusIO2 += (m_NewStatus.m_bZ2Run)							? 0x0200 : 0x0000;

}

void DeviceUMacLarge::ReadStatusIO3()
{
	m_lStatusIO3 = 0;
	m_lStatusIO3 += (m_NewStatus.m_bEMStopSW)				? 0x0001 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bLaserPowerOn)						? 0x0002 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bServoPowerOn)				? 0x0004 : 0x0000; 
	//m_lStatusIO3 += (m_NewStatus.m_bRingBlowerRunStatus)						? 0x0008 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bRingBlowerOverCurrent_Alarm)			? 0x0010 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bRingBlowerOverTemp_Alarm)			? 0x0020 : 0x0000;


	//m_lStatusIO3 += (m_NewStatus.m_bHeightSensorUp)				? 0x0040 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bHeightSensorDown)			? 0x0080 : 0x0000;

     m_lStatusIO3 += (m_NewStatus.m_bResetSW)			? 0x0100 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bPowerDetectorRet)			? 0x0200 : 0x0000;
	m_lStatusIO3 += (m_NewStatus.m_bMasterTableVacuumAIndicator)				? 0x0400 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bMasterTableVacuumBIndicator)			? 0x0800 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bMasterTableVacuumCIndicator)		? 0x1000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bSlaveTableVacuumBIndicator)				? 0x2000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bSlaveTableVacuumCIndicator)				? 0x4000 : 0x0000; 
	//m_lStatusIO3 += (m_NewStatus.m_bC2Initializing_)				? 0x8000 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
	//m_lStatusIO3 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;

}

void DeviceUMacLarge::ReadStatusIO4()
{
	m_lStatusIO4 = 0;
	//m_lStatusIO4 += (m_NewStatus.m_bFrontDoor1CloseSignal)				? 0x0001 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bFrontDoor2CloseSignal)						? 0x0002 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bServoPowerOn)				? 0x0004 : 0x0000; 


	// m_lStatusIO4 += (m_NewStatus.m_bRingBlowerRunStatus)						? 0x0008 : 0x0000;

//#ifdef __NANYA_NEW__
//	m_lStatusIO4 += (m_NewStatus.m_bLightCurtainOn)			? 0x0010 : 0x0000;//20171227
//#endif


	//	m_lStatusIO4 += (m_NewStatus.m_bRingBlowerOverTemp_Alarm)			? 0x0020 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bHeightSensorUp)				? 0x0040 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bHeightSensorDown)			? 0x0080 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bResetSW)			? 0x0100 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bPowerDetectorRet)			? 0x0200 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bMasterTableVacuumAIndicator)				? 0x0400 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bMasterTableVacuumBIndicator)			? 0x0800 : 0x0000;


	m_lStatusIO4 += (m_NewStatus.m_bChillerCH1RunStatusSignal)		? 0x1000 : 0x0000;
	m_lStatusIO4 += (m_NewStatus.m_bChillerCH1TempFault_Signal)				? 0x2000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bChillerCH2RunStatusSignal)				? 0x4000 : 0x0000; 
	//m_lStatusIO4 += (m_NewStatus.m_bChillerCH2TempFault_Signal)				? 0x8000 : 0x0000;
	//	m_lStatusIO4 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
	//m_lStatusIO4 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;
}

void DeviceUMacLarge::ReadStatusIO5()//$6100E 
{
	m_lStatusIO5 = 0;
	//m_lStatusIO5 += (m_NewStatus.m_bLaserWaterFlowSensor)				? 0x0001 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bHeadWaterFlow1Sensor)						? 0x0002 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bHeadWaterFlow2Sensor)				? 0x0004 : 0x0000; 
	//m_lStatusIO5 += (m_NewStatus.m_bStartSwitch)						? 0x0008 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bStopSwitch)			? 0x0010 : 0x0000;
//	m_lStatusIO5 += (m_NewStatus.m_bRingBlowerOverTemp_Alarm)			? 0x0020 : 0x0000;
    m_lStatusIO5 += (m_NewStatus.m_bInitalizeSwitch)				? 0x0040 : 0x0000;
	m_lStatusIO5 += (m_NewStatus.m_bManualModeSwitch)			? 0x0080 : 0x0000;
	m_lStatusIO5 += (m_NewStatus.m_bAutoModeSwitch)			? 0x0100 : 0x0000;
	m_lStatusIO5 += (m_NewStatus.m_bExternalLaserShotSwitch)			? 0x0200 : 0x0000;

	m_lStatusIO5 += (m_NewStatus.m_bFrontDoorSwitch)				? 0x0400 : 0x0000;//20170828 ��������
	m_lStatusIO5 += (m_NewStatus.m_bRearDoorSwitch)			? 0x0800 : 0x0000;
	m_lStatusIO5 += (m_NewStatus.m_bMainAirPressureSwitch)		? 0x1000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bAutomaticLubricatorY1_Fault)				? 0x2000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bAutomaticLubricatorY2_Fault)				? 0x4000 : 0x0000; 
	//m_lStatusIO5 += (m_NewStatus.m_bAutomaticLubricatorX_Fault)				? 0x8000 : 0x0000;
	//	m_lStatusIO5 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
	//m_lStatusIO5 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;
}
void DeviceUMacLarge::ReadStatusIO6()//$6100F
{
	m_lStatusIO6 = 0;
	m_lStatusIO6 += (m_NewStatus.m_bLaserMasterShutterExtend)				? 0x0001 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bLaserMasterShutterRetract)						? 0x0002 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bLaserSlaveShutterExtend)				? 0x0004 : 0x0000; 
	m_lStatusIO6 += (m_NewStatus.m_bLaserSlaveShutterRetract)						? 0x0008 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMasterHeightSensorUpCheck)			? 0x0010 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMasterHeightSensorDownCheck)			? 0x0020 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bSlaveHeightSensorUpCheck)				? 0x0040 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bSlaveHeightSensorDownCheck)			? 0x0080 : 0x0000;
//	m_lStatusIO6 += (m_NewStatus.m_bAutoModeSwitch)			? 0x0100 : 0x0000;
//	m_lStatusIO6 += (m_NewStatus.m_bExternalLaserShotSwitch)			? 0x0200 : 0x0000;

	m_lStatusIO6 += (m_NewStatus.m_bMPGAxisSelect1)				? 0x0400 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMPGAxisSelect2)			? 0x0800 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMPGAxisSelect3)		? 0x1000 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMPGFeedSelect1)				? 0x2000 : 0x0000;
	m_lStatusIO6 += (m_NewStatus.m_bMPGFeedSelect2)				? 0x4000 : 0x0000; 
	m_lStatusIO6 += (m_NewStatus.m_bFrontLowerDoorClose)		? 0x8000 : 0x0000;
	//m_lStatusIO6 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
	//m_lStatusIO6 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
	//m_lStatusIO6 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
	//m_lStatusIO6 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
//	m_lStatusIO6 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
//	m_lStatusIO6 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;
}
void DeviceUMacLarge::ReadStatusIO7()//$61010
{
	m_lStatusIO7 = 0;
	m_lStatusIO7 += (m_NewStatus.m_bTable1PCBClampSensor)				? 0x0001 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bTable1PCBUlclampSensor)						? 0x0002 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bTable2PCBClampSensor)				? 0x0004 : 0x0000; 
	m_lStatusIO7 += (m_NewStatus.m_bTable2PCBUlclampSensor)						? 0x0008 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bLaserPowerDetectorExtendInput)			? 0x0010 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bLaserPowerDetectorRetractInput)			? 0x0020 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bOpticWaterLeakSensor)				? 0x0040 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bDustCollectorVacuumIndicator)			? 0x0080 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bSuctionHoodShutterOpenSensor)			? 0x0100 : 0x0000;
	m_lStatusIO7 += (m_NewStatus.m_bSuctionHoodShutterCloseSensor)			? 0x0200 : 0x0000;


	//m_lStatusIO7 += (m_NewStatus.m_bTable1_1VacuumSuctionValveOn)			? 0x0400 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bTable1_1VacuumSuctionValveOff)				? 0x0800 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bTable1_2VacuumSuctionValveOn)			? 0x1000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bTable1_2VacuumSuctionValveOff)		? 0x2000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bTable2_1VacuumSuctionValveOn)				? 0x4000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bTable2_1VacuumSuctionValveOff)				? 0x8000 : 0x0000; 
//	m_lStatusIO7 += (m_NewStatus.m_bDoorLightCurtainWarning)				? 0x8000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
	//m_lStatusIO7 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
	//	m_lStatusIO7 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
	//	m_lStatusIO7 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;
}
void DeviceUMacLarge::ReadStatusIO8()//$61011
{
	m_lStatusIO8 = 0;
	m_lStatusIO8 += (m_NewStatus.m_bTable2_2VacuumSuctionValveOn)			? 0x0001 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bTable2_2VacuumSuctionValveOff)			? 0x0002 : 0x0000;
		//m_lStatusIO8 += (m_NewStatus.m_bLaserBeamPassSlaveDownSensor)						? 0x0004 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bLaserSystemWarning)				? 0x0008 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bLaserWaterFlowFault)						? 0x0010 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bLaserOverTempFault)				? 0x0020 : 0x0000; 

	/*m_lStatusIO8 += (m_NewStatus.m_bAOM_NA_BeamPass1CylFw)				? 0x0040 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_NA_BeamPass1CylBw)				? 0x0080 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_NA_BeamPass2CylFw)				? 0x0100 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_NA_BeamPass2CylBw)				? 0x0200 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass1CylUp)				? 0x0400 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass1CylDown)			? 0x0800 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass2CylFw)				? 0x1000 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass2CylBw)				? 0x2000 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass3CylFw)				? 0x4000 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM_Use_BeamPass3CylBw)				? 0x8000 : 0x0000; */

	/*//20170828 ��������
	m_lStatusIO8 += (m_NewStatus.m_bTable1PCBClampSensor)				? 0x0040 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bTable1PCBUlclampSensor)			? 0x0080 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bTable2PCBClampSensor)			? 0x0100 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bTable2PCBUlclampSensor)			? 0x0200 : 0x0000;



	m_lStatusIO8 += (m_NewStatus.m_b61012_2)				? 0x0400 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_b61012_3)			? 0x0800 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bAOM1MirrorFWDSensor)		? 0x1000 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bAOM1MirrorBWDSensor)				? 0x2000 : 0x0000;
	m_lStatusIO8 += (m_NewStatus.m_bAOM2MirrorFWDSensor)				? 0x4000 : 0x0000; 
	m_lStatusIO8 += (m_NewStatus.m_bAOM2MirrorBWDSensor)				? 0x8000 : 0x0000;
	*/
//	m_lStatusIO8 += (m_NewStatus.m_bLaserShutter1Ext)			? 0x10000 : 0x0000;
//	m_lStatusIO8 += (m_NewStatus.m_bLaserShutter1Ret)			? 0x20000 : 0x0000;
//	m_lStatusIO8 += (m_NewStatus.m_bA2InitialEnd)				? 0x40000 : 0x0000;
//	m_lStatusIO8 += (m_NewStatus.m_bA2Initializing)				? 0x80000 : 0x0000;
//	m_lStatusIO8 += (m_NewStatus.m_bA2Inposition)				? 0x100000 : 0x0000;
//	m_lStatusIO8 += (m_NewStatus.m_bA2Run)						? 0x200000 : 0x0000;
}
void DeviceUMacLarge::ReadStatusMelsec()
{
	m_lStatusMelsec = 0;
	
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecReady)				? 0x0001 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecAlarmOn)			? 0x0002 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecAlarmOff)			? 0x0004 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecDoNotTableMove)	? 0x0008 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecAlignReady)		? 0x0010 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecAlignRun)			? 0x0020 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecAlignEnd)			? 0x0040 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadReady)			? 0x0080 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadRun)			? 0x0100 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadEnd)			? 0x0200 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecUnloadReady)		? 0x0400 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecUnloadRun)			? 0x0800 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecUnloadEnd)			? 0x1000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadPicker1PCBExist)	? 0x2000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadPicker2PCBExist)	? 0x4000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadingAble)			? 0x8000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadPicker1Down)		? 0x10000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecLoadPicker2Down)		? 0x20000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecUnloaderPicker1Down)	? 0x40000 : 0x0000;
	//m_lStatusMelsec += (m_NewStatus.m_bMelsecUnloaderPicker2Down)	? 0x80000 : 0x0000;
		
}
BYTE DeviceUMacLarge::GetCurrentMode()
{
	if(m_NewStatus.m_bMPGMode)		
		return MODE_MPG; // MPG
	if(m_NewStatus.m_bManualModeSwitchLamp)	return MODE_MANUAL; // manual //20160418 IO
	if(m_NewStatus.m_bAutoModeSwitchLamp)		return MODE_AUTO; // Auto mode

	return MODE_OFF; // off
}

BOOL DeviceUMacLarge::GetCurrentAutoStatus()
{

	if(m_NewStatus.m_bAutoModeSwitchLamp)	
		return 1; // Auto mode

	return 0; // off
}

void DeviceUMacLarge::SetCurrentCycle(BYTE cCycle)
{
	m_cCycleStart = cCycle;
}

BYTE DeviceUMacLarge::GetCurrentEMStop()
{
	return (BYTE)m_NewStatus.m_bEMStopSW;
}

BOOL DeviceUMacLarge::IsLaserKeyOn()
{
	return (BYTE)m_NewStatus.m_bLaserPowerOn;
}

BYTE DeviceUMacLarge::GetCurrentPowerMeter()
{

	if(m_NewStatus.m_bLaserPowerDetectorExtendInput)
	{
		if(m_NewStatus.m_bLaserPowerDetectorRetractInput)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bLaserPowerDetectorRetractInput)
			return 2; // close
		else
			return 3; // half
	}

	return 0; 
}

BYTE DeviceUMacLarge::GetCurrentShutter1()
{
	
	if(m_NewStatus.m_bLaserMasterShutterRetract) 
	{
		if(m_NewStatus.m_bLaserMasterShutterExtend)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bLaserMasterShutterExtend)
			return 2; // close
		else
			return 3; //1; // half
	}
}

BYTE DeviceUMacLarge::GetCurrentShutter2()
{
	
	if(m_NewStatus.m_bLaserSlaveShutterRetract) 
	{
		if(m_NewStatus.m_bLaserSlaveShutterExtend)
			return 3; // half
		else
			return 1; // open
	}
	else
	{
		if(m_NewStatus.m_bLaserSlaveShutterExtend)
			return 2; // close
		else
			return 3; //1; // half
	}
}

BYTE DeviceUMacLarge::GetCurrentLoadDetect()
{
	return (BYTE)(m_NewStatus.m_bLoaderPicker1PCBExist + ((m_NewStatus.m_bLoaderPicker2PCBExist << 1) & 0x02));//(BYTE)(m_NewStatus.m_bLoaderPick1Detector + ((m_NewStatus.m_bLoaderPick2Detector << 1) & 0x02));
}

BYTE DeviceUMacLarge::GetCurrentUnloadDetect()
{
	return 0;
	//return (BYTE)(m_NewStatus.m_bUnloaderPick1Detector + ((m_NewStatus.m_bUnloaderPick2Detector << 1) & 0x02));
}

BYTE DeviceUMacLarge::GetCurrentSuction()
{

	BYTE cVal = 0x00;

	BOOL bMaseterOn1 = m_NewStatus.m_bMasterTableVacuumAIndicator;
	//BOOL bMaseterOn2 = m_NewStatus.m_bMasterTableVacuumBIndicator;

	BOOL bSlaveOn1 = m_NewStatus.m_bSlaveTableVacuumAIndicator;
	//BOOL bSlaveOn2 = m_NewStatus.m_bSlaveTableVacuumBIndicator;

	BOOL bMaster = FALSE;
	BOOL bSlave = FALSE;

	if(!GetTableBUse()) 
	{
		bMaster = bMaseterOn1;
		bSlave = bSlaveOn1;
	}
	else
	{
		bMaster = bMaseterOn1;
		bSlave = bSlaveOn1;
	}

	if(bMaster)
		cVal += 0x01;

	if(bSlave)
		cVal += 0x02;

	return cVal;
}

BOOL DeviceUMacLarge::GetCurrentAcrylSuction(BOOL b1st)
{
	//return TRUE; //�ӽ� �����ؾ��� //ishwang
	if(b1st)
		return m_NewStatus.m_bMasterTableAcrylicSuctionSol;
	else
		return m_NewStatus.m_bSlaveTableAcrylicSuctionSol;

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::GetCurrentVacuumMotor(BOOL b1st)
{
	return TRUE;
/*
	if(b1st)
	{
		if(m_NewStatus.m_bTableVacuumMotor1)
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if(m_NewStatus.m_bTableVacuumMotor2)
			return TRUE;
		else
			return FALSE;
	}
*/
}

BYTE DeviceUMacLarge::GetExternalLaser()
{
	return m_NewStatus.m_bExternalLaserShotSwitch;
}

BOOL DeviceUMacLarge::GetCurrentHeight(BOOL bFirst, BOOL bDown)
{
	
	if(bFirst)
	{
		if(bDown == TRUE)
			return m_NewStatus.m_bMasterHeightSensorDownCheck & !m_NewStatus.m_bMasterHeightSensorUpCheck;
		// Height Sensor Up
		return m_NewStatus.m_bMasterHeightSensorUpCheck & !m_NewStatus.m_bMasterHeightSensorDownCheck;
	}
	else
	{
		if(bDown == TRUE)
			return m_NewStatus.m_bSlaveHeightSensorDownCheck & !m_NewStatus.m_bSlaveHeightSensorUpCheck;
		// Height Sensor Up
		return m_NewStatus.m_bSlaveHeightSensorUpCheck & !m_NewStatus.m_bSlaveHeightSensorDownCheck;
	}
	


}

BOOL DeviceUMacLarge::SetOutPort(BYTE nPortNo, WORD wOnOff, BOOL bUseAom)
{
	BOOL bResult = TRUE;
	BOOL bUp = (BOOL)(wOnOff);
	switch(nPortNo)
	{
		//////// 0 /////////
	case PORT_MANUAL_MODE_ON		:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 3, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 4, (BOOL)(!wOnOff));

		return bResult;
		break;
	case PORT_MARKING_START :
		bResult = MotionControlDLL_WriteOutputIOBit(0, 6, (BOOL)(wOnOff));
		return bResult;
		break;
	case PORT_CHILLER1_REMOTE_ON	:
		//bResult = MotionControlDLL_WriteOutputIOBit(0, 5, wOnOff & 0x01);
		return bResult;
		break;

	case PORT_CHILLER2_REMOTE_ON	:
		//bResult = MotionControlDLL_WriteOutputIOBit(0, 6, wOnOff & 0x01);
		return bResult;
		break;
	case PORT_RING_BLOWER_REMOTE_RUN :
		bResult = MotionControlDLL_WriteOutputIOBit(9, 8, (BOOL)(wOnOff));
		bResult = MotionControlDLL_WriteOutputIOBit(9, 9, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_RING_BLOWER_VAC_POWER :
		//bResult = MotionControlDLL_WriteOutputIOBit(0, 8, (BOOL)(wOnOff &0x01));
		//bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 9, (wOnOff >> 1) & 0x01);
		//bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 10, (wOnOff >> 2) & 0x01);
		return bResult;
		break;

	case PORT_SCANNER_POWER_REMOTE_ON :
		bResult = MotionControlDLL_WriteOutputIOBit(0, 12, (BOOL)(wOnOff));
		return bResult;
		break;
	case PORT_RING_BLOWER_SOL_VALVE_ON	:
		//bResult = MotionControlDLL_WriteOutputIOBit(0, 12, wOnOff & 0x01);
		//bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 13, (wOnOff >> 1) & 0x01);
		//bResult = MotionControlDLL_WriteOutputIOBit(0, 12, (BOOL)(wOnOff));
		//bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 13, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_ALARM	:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 10, wOnOff);
		return bResult;
		break;

	case PORT_PCB_SINGLE	:
		gVariable.m_nUseTable = wOnOff;
		bResult = MotionControlDLL_WriteOutputIOBit(0, 14, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(0, 13, (wOnOff >> 1) & 0x01);
		return bResult;
		break;

	case PORT_TABLE_B_USE	:
		bResult = MotionControlDLL_WriteOutputIOBit(0, 15, wOnOff);
		return bResult;
		break;
	//case PORT_IO_CHECK	://20170828
	//	//bResult = MotionControlDLL_WriteOutputIOBit(0, 15, wOnOff);
	//	return bResult;
	//	break;


//////// 1 /////////

	case PORT_LASER_ETHERNET_CON	:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 1, wOnOff & 0x01);
		return bResult;
		break;
	case PORT_LASER_SHUTTER_CON	:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 2, wOnOff & 0x01);
		return bResult;
		break;
		

	case PORT_USE_LOAD_UNLOAD :
		//bResult = MotionControlDLL_WriteOutputIOBit(1, 3, wOnOff & 0x01);//20160509
		return bResult;
		break;

		
	case PORT_MPG_MODE			:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 2, wOnOff & 0x01);
		bResult = MotionControlDLL_WriteOutputIOBit(1, 3, (wOnOff >> 1) & 0x01);

		return bResult;
		break;


	case PORT_SYSTEM_DOOR_BYPASS:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 5, wOnOff & 0x01);
		return bResult;
		break;

	case PORT_DOOR_LOCK:

		//if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)//20160609
		//	return TRUE;

		//bResult = MotionControlDLL_WriteOutputIOBit(1, 5, wOnOff & 0x01);

		bResult = MotionControlDLL_WriteOutputIOBit(1, 7, (BOOL)(wOnOff));
		bResult = MotionControlDLL_WriteOutputIOBit(1, 8, (BOOL)(!wOnOff));
		return bResult;
		break;

	case PORT_LAMP				:
		bResult = MotionControlDLL_WriteOutputIOBit(1, 6, (BOOL)(wOnOff));
		return bResult;
		break;

	case PORT_NO_USE_CHILLER				:
		//bResult = MotionControlDLL_WriteOutputIOBit(1, 7, (BOOL)(wOnOff));
		return bResult;
		break;
		


		/*//20170828
	case PORT_LOADER_LOCK	: // front door lock unlock
		bResult = MotionControlDLL_WriteOutputIOBit(1, 7, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 8, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_UNLOAD_LOCK	: // rear door lock unlock
		bResult = MotionControlDLL_WriteOutputIOBit(1, 9, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 10, (BOOL)(!wOnOff));
		return bResult;
		break;
		*/



	case PORT_LPC :
		//bResult = MotionControlDLL_WriteOutputIOBit(1, 11, wOnOff & 0x01);
		return bResult;
		break;

	case PORT_USE_TABLE_CLAMP :
		bResult = MotionControlDLL_WriteOutputIOBit(1, 14, (BOOL)(wOnOff));
		return bResult;
		break;

	case PORT_LASER_SIGNAL :
		bResult = MotionControlDLL_WriteOutputIOBit(1, 15, (BOOL)(wOnOff));
		return bResult;
		break;



//////// 2 /////////

	case PORT_TABLE_SUCTION1	:

		bResult = MotionControlDLL_WriteOutputIOBit(1, 0,0);

		bResult = MotionControlDLL_WriteOutputIOBit(2, 0, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 1, !(wOnOff & 0x01));
		return bResult;
		break;
	case PORT_TABLE_SUCTION2	:

		bResult = MotionControlDLL_WriteOutputIOBit(1, 0,0);

		bResult = MotionControlDLL_WriteOutputIOBit(2, 2, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 3, !(wOnOff & 0x01));
		return bResult;
		break;
	case PORT_SHUTTER_MASTER:
		bResult = MotionControlDLL_WriteOutputIOBit(2, 4, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 5, (BOOL)(!wOnOff));
		return bResult;
		break;
	case PORT_SHUTTER_SLAVE	:
		bResult = MotionControlDLL_WriteOutputIOBit(2, 6, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 7, (BOOL)(!wOnOff));
		return bResult;
		break;

	case PORT_WARNING :
		bResult = MotionControlDLL_WriteOutputIOBit(2, 9, (BOOL)(wOnOff));
		return bResult;
		break;
	case PORT_POWER_METER	: // open close cover
		bResult = MotionControlDLL_WriteOutputIOBit(2, 10, (BOOL)(wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 11, (BOOL)!wOnOff);

		return bResult;
		break;

	case PORT_HEIGHT_SENSOR	: // up / down
		bResult = MotionControlDLL_WriteOutputIOBit(2, 12, (BOOL)(!wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 13, (BOOL)wOnOff);
		return bResult;
		break;
	case PORT_HEIGHT_SENSOR_2	: // up / down 
		bResult = MotionControlDLL_WriteOutputIOBit(2, 14, (BOOL)(!wOnOff));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(2, 15, (BOOL)wOnOff);
		return bResult;
		break;

//////// 9 /////////



	case PORT_ACRYL_TABLE_SUCTION	:
		bResult = MotionControlDLL_WriteOutputIOBit(9, 0, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(9, 1, !(wOnOff & 0x01));
		return bResult;
		break;
	case PORT_ACRYL_TABLE_SUCTION2	:
		bResult = MotionControlDLL_WriteOutputIOBit(9, 2, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(9, 3, !(wOnOff & 0x01));
		return bResult;
		break;

	case PORT_TABLE1_CLAMP	:
		bResult = MotionControlDLL_WriteOutputIOBit(9, 4, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(9, 5, !(wOnOff & 0x01));
		return bResult;
		break;
		
	case PORT_TABLE2_CLAMP	:
		bResult = MotionControlDLL_WriteOutputIOBit(9, 6, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(9, 7, !(wOnOff & 0x01));
		return bResult;
		break;

	case PORT_SUCTION_HOOD_SOL	:
		bResult = MotionControlDLL_WriteOutputIOBit(9, 10, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(9, 11, !(wOnOff & 0x01));
		return bResult;
		break;

	case PORT_SUCTION_HOOD_BOLWER	:
		//bResult = MotionControlDLL_WriteOutputIOBit(9, 12, wOnOff & 0x01);
		return bResult;
		break;
	case PORT_MASK_BLOW_SOL	:
		//bResult = MotionControlDLL_WriteOutputIOBit(9, 13, wOnOff & 0x01);
		return bResult;
		break;

	case PORT_OPTIC_BLOW_SOL	:
		//bResult = MotionControlDLL_WriteOutputIOBit(9, 14, wOnOff & 0x01);
		return bResult;
		break;

		

//////// 10 /////////


		/* //20170828 ��������
	case PORT_WARNING_ON :
		bResult = MotionControlDLL_WriteOutputIOBit(10, 0, (BOOL)(wOnOff));
		return bResult;
		break;
		*/
	case PORT_AUTO_LUBRICATOR_REMOTE :
		//bResult = MotionControlDLL_WriteOutputIOBit(10, 1, (BOOL)(wOnOff));
		return bResult;
		break;

	case PORT_LOT_END :
		bResult = MotionControlDLL_WriteOutputIOBit(10, 6, (BOOL)(wOnOff));
		return bResult;
		break;
	case PORT_TOWER_LAMP_OFF :
		//bResult = MotionControlDLL_WriteOutputIOBit(10, 7, (BOOL)(wOnOff));
		return bResult;
		break;


//////// 11 /////////

	case PORT_AOM_NA_BEAMPATH_CYL_UP :
		
		/*bResult = MotionControlDLL_WriteOutputIOBit(11, 2, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 3, !(wOnOff & 0x01));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 4, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 5, !(wOnOff & 0x01));*/

		return bResult;
		break;
	case PORT_AOM_USE_BEAMPATH_CYL_UP :
		/*bResult = MotionControlDLL_WriteOutputIOBit(11, 6, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 7, !(wOnOff & 0x01));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 8, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 9, !(wOnOff & 0x01));
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 10, wOnOff & 0x01);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(11, 11, !(wOnOff & 0x01));*/
		return bResult;
		break;



	}
	return 0;
}

BOOL DeviceUMacLarge::IsMotorStop(BOOL bFlag)
{
	if (bFlag == FALSE)
		m_bCommandStop = FALSE;
	
	return m_bCommandStop;
}

void DeviceUMacLarge::ReadPosition()
{
	m_nInPositionError = 0;
	
	if(m_NewStatus.m_nXCommandPos != m_lWritePos[AXIS_X]) // x command pos , real encoder pos
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 1;
		return;
	}
	if(m_NewStatus.m_nYCommandPos != m_lWritePos[AXIS_Y]) // y
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 2;
		return;
	}
	
	if(m_NewStatus.m_nZ1CommandPos != m_lWritePos[AXIS_Z1]) // z1
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 3;
		return;
	}
	if(m_NewStatus.m_nZ2CommandPos != m_lWritePos[AXIS_Z2]) // z2
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 4;
		return;
	}


    long lGetPos;


	if(!m_bConnect)
		return;


	//m_lWritePos = pos * m_dScale
	Servo_GetActualPos(EZ_SERVO_M1, &lGetPos);
	long lErrorPos;
	Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
	lGetPos += lErrorPos;

	if(lGetPos != m_lWritePos[AXIS_M])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 5;
		return;
	}

	Servo_GetActualPos(EZ_SERVO_M2, &lGetPos);
	Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
	lGetPos += lErrorPos;
	if(lGetPos != m_lWritePos[AXIS_M2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 6;
		return;
	}
	Servo_GetActualPos(EZ_SERVO_M3, &lGetPos);
	Servo_GetPosError(EZ_SERVO_M3, &lErrorPos);
	lGetPos += lErrorPos;
	if(lGetPos != m_lWritePos[AXIS_M3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 7;
		return;
	}

	Servo_GetActualPos(EZ_SERVO_C1, &lGetPos);
	if(lGetPos != m_lWritePos[AXIS_C])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 9;
		return;
	}

	Servo_GetActualPos(EZ_SERVO_C2, &lGetPos);
	if(lGetPos != m_lWritePos[AXIS_C2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 10;
		return;
	}

	Servo_GetActualPos(EZ_SERVO_C3, &lGetPos);
	if(lGetPos != m_lWritePos[AXIS_C3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 11;
		return;
	}

	Servo_GetActualPos(EZ_SERVO_C4, &lGetPos);
	if(lGetPos != m_lWritePos[AXIS_C4])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 12;
		return;
	}

	m_bCommandStop = TRUE;
}

BOOL DeviceUMacLarge::IsInPositionThread(int nAxis, BYTE nCommand)
{
	TRACE(_T("InPosition Start  1\n"));

	CString strLog;

	unsigned char ucMode = GetCurrentMode();
	if(ucMode == MODE_MPG || ucMode == MODE_HOME || ucMode == MODE_SAFE)
		return FALSE;

	if(IsSafetyMode())
		return FALSE;

	if(IsMoveEnd(nAxis))
		return TRUE;

	if(m_thdInPosition != NULL && m_nInPositionCount <= 0)
	{
		m_pStopTime.Pause();
		m_pStopTime.StartTime();

		m_nIsInPosition = FALSE;
		m_nInPositionCommand= nCommand;
		m_nInPositionCount = m_thdInPosition->ResumeThread();
		do
		{
			PeekMessage();
#ifndef __TEST__
			Sleep(TIME_STATUS);
#endif
			if(m_nIsInPosition != FALSE)
			{
				m_nInPositionCount = m_thdInPosition->SuspendThread();
				break;
			}
		} while (!m_bPositionStop);

		// by HJ.Cho 2003. 3. 29
		if (m_nIsInPosition == -1)
		{
			switch(m_nInPositionError)
			{
				case 1:
					ErrMsgDlg(STDGNALM404); // X 
					break;
				case 2:
					ErrMsgDlg(STDGNALM405); // Y
					break;
				case 3:
					ErrMsgDlg(STDGNALM406); // Z1
					break;
				case 4:
					ErrMsgDlg(STDGNALM407); // Z2
					break;
				case 5:
					ErrMsgDlg(STDGNALM408); // M					
					break;
				case 6:
					ErrMsgDlg(STDGNALM409); // M2
					break;

				case 7:
					ErrMsgDlg(STDGNALM408); // M3					
					break;

				case 9:
					ErrMsgDlg(STDGNALM410); // C
					break;

				case 10:
					ErrMsgDlg(STDGNALM411); // C2
					break;

				case 11:
					ErrMsgDlg(STDGNALM411); // C3
					break;
				case 12:
					ErrMsgDlg(STDGNALM411); // C4
					break;


			}
		}
		else if (m_nIsInPosition == -2)
			ErrMessage(_T("Socket time error !!!"));
		else if (m_nIsInPosition == -3)
			m_nIsInPosition = TRUE;
		
		return m_nIsInPosition;
	}
	TRACE(_T("InPos Thread Error\n"));
	return FALSE;
}

BOOL DeviceUMacLarge::IsMoveEnd(int nAxis)
{
#ifdef __SERVO_MOTOR__
	long lGetPos, lSetPos;
	long lErrorPos;
#endif
	if(nAxis == -1) // all axis
	{
		BOOL bCol1 = TRUE, bMask2 = TRUE, bCol2 = TRUE;
		BOOL bM1 = TRUE, bM2= TRUE, bM3= TRUE, bM4= TRUE;
	    BOOL bB1 = TRUE, bB2= TRUE, bB3 = TRUE, bB4= TRUE;
		BOOL bRot = TRUE, bTopHat= TRUE;
		if(!m_NewStatus.m_bXInposition || abs(m_lWritePos[AXIS_X] - m_NewStatus.m_nXActualPos) > 2)	
		{
			m_nInPositionError = 1;
			return FALSE;
		}
		if(!m_NewStatus.m_bYInposition || abs(m_lWritePos[AXIS_Y] - m_NewStatus.m_nYActualPos) > 2)	
		{
			m_nInPositionError = 2;
			return FALSE;
		}
		if(!m_NewStatus.m_bZ1Inposition || abs(m_lWritePos[AXIS_Z1] - m_NewStatus.m_nZ1ActualPos) > 2)	
		{
			m_nInPositionError = 3;
			return FALSE;
		}
		if(!m_NewStatus.m_bZ2Inposition || abs(m_lWritePos[AXIS_Z2] - m_NewStatus.m_nZ2ActualPos) > 2)	
		{
			m_nInPositionError = 4;
			return FALSE;
		}


		if(!m_bConnect)
			return FALSE;

		Servo_GetActualPos(EZ_SERVO_M1 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
		lGetPos += lErrorPos;

		if(abs(m_lWritePos[AXIS_M] - (int)lGetPos) > 2)
		{
			bM1 = FALSE;
			m_nInPositionError = 5;
			return FALSE;
		}

		Servo_GetActualPos(EZ_SERVO_M2 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_M2] - (int)lGetPos) > 2)
		{
			bM2 = FALSE;
			m_nInPositionError = 6;
			return FALSE;
		}

		Servo_GetActualPos(EZ_SERVO_M3 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_M3, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_M3] - (int)lGetPos) > 2)
		{
			bM3 = FALSE;
			m_nInPositionError = 7;
			return FALSE;
		}
		
		Servo_GetActualPos(EZ_SERVO_C1 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_C1, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_C] - (int)lGetPos) > 2)
		{
			bB1 = FALSE;
			m_nInPositionError = 9;
			return FALSE;
		}

		Servo_GetActualPos(EZ_SERVO_C2 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_C2, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_C2] - (int)lGetPos) > 2)
		{
			bB2 = FALSE;
			m_nInPositionError = 10;
			return FALSE;
		}

		Servo_GetActualPos(EZ_SERVO_C3 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_C3, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_C3] - (int)lGetPos) > 2)
		{
			bB3 = FALSE;
			m_nInPositionError = 11;
			return FALSE;
		}

		Servo_GetActualPos(EZ_SERVO_C4 , &lGetPos);
		Servo_GetPosError(EZ_SERVO_C4, &lErrorPos);
		lGetPos += lErrorPos;
		if(abs(m_lWritePos[AXIS_C4] - (int)lGetPos) > 2)
		{
			bB4 = FALSE;
			m_nInPositionError = 12;
			return FALSE;
		}

		return (m_bCommandStop & m_NewStatus.m_bXInposition & m_NewStatus.m_bYInposition &
				m_NewStatus.m_bZ1Inposition & m_NewStatus.m_bZ2Inposition  &
				bCol1 & bMask2 & bCol2 & bM1 & bM2 & bM3 & bB1 & bB2 & bB3 & bB4 );
	}
	else
	{
		switch(nAxis)
		{
		case AXIS_X:
			if( abs(m_NewStatus.m_nXCommandPos - m_NewStatus.m_nXActualPos) < 3
				&& m_NewStatus.m_bXInposition)
				return TRUE;
			m_nInPositionError = 1;
			break;
		case AXIS_Y:
			if( abs(m_NewStatus.m_nYCommandPos - m_NewStatus.m_nYActualPos) < 3
				&& m_NewStatus.m_bYInposition)
			return TRUE;
			m_nInPositionError = 2;
			break;
		case AXIS_Z1:
			if( abs(m_NewStatus.m_nZ1CommandPos - m_NewStatus.m_nZ1ActualPos) < 3
				&& m_NewStatus.m_bZ1Inposition)
			return TRUE;
			m_nInPositionError = 3;
			break;
		case AXIS_Z2:
			if( abs(m_NewStatus.m_nZ2CommandPos - m_NewStatus.m_nZ2ActualPos) < 3
				&& m_NewStatus.m_bZ2Inposition)
			return TRUE;
			m_nInPositionError = 4;
			break;

		case AXIS_M:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_M1, &lGetPos);
			Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
			lGetPos += lErrorPos;
			Servo_GetCommandPos(EZ_SERVO_M1, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 5;
				return FALSE;
			}

			return TRUE;

			break;
		case AXIS_M2 :

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_M2, &lGetPos);
			Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
			lGetPos += lErrorPos;
			Servo_GetCommandPos(EZ_SERVO_M2, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 6;
				return FALSE;
			}

			return TRUE;

			break;

		case AXIS_M3:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_M3, &lGetPos);
			Servo_GetPosError(EZ_SERVO_M3, &lErrorPos);
			lGetPos += lErrorPos;
			Servo_GetCommandPos(EZ_SERVO_M3, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 7;
				return FALSE;
			}

			return TRUE;

			break;

		case AXIS_C:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_C1, &lGetPos);
			Servo_GetCommandPos(EZ_SERVO_C1, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 9;
				return FALSE;
			}

			return TRUE;

			break;

		case AXIS_C2:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_C2, &lGetPos);
			Servo_GetCommandPos(EZ_SERVO_C2, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 10;
				return FALSE;
			}

			return TRUE;

			break;
		case AXIS_C3:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_C3, &lGetPos);
			Servo_GetCommandPos(EZ_SERVO_C3, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 11;
				return FALSE;
			}

			return TRUE;

			break;
		case AXIS_C4:

			if(!m_bConnect)
				return FALSE;
			Servo_GetActualPos(EZ_SERVO_C4, &lGetPos);
			Servo_GetCommandPos(EZ_SERVO_C4, &lSetPos);

			if(abs(lSetPos - lGetPos) < 3)
			{
				m_nInPositionError = 12;
				return FALSE;
			}

			return TRUE;

			break;



		default:
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DeviceUMacLarge::IsMotorOrigin(int nAxis)
{
	if(nAxis == -1) // all axis
	{
		BOOL bCol1 = TRUE, bCol2 = TRUE, bCol3 = TRUE,bCol4 = TRUE, bMask1 = TRUE, bMask2 = TRUE,bMask3 = TRUE,bMask4 = TRUE, bRot = TRUE, bTopHat= TRUE;


		if(!m_bConnect)
			return FALSE;

		bMask1 = Servo_IsOrigin(EZ_SERVO_M1);
		bMask2 = Servo_IsOrigin(EZ_SERVO_M2);
		//bMask3= Servo_IsOrigin(EZ_SERVO_M3);
		//bMask4 = Servo_IsOrigin(EZ_SERVO_M4);

		bCol1 = Servo_IsOrigin(EZ_SERVO_C1);
		bCol2 = Servo_IsOrigin(EZ_SERVO_C2);
		bCol1 = Servo_IsOrigin(EZ_SERVO_C3);
		bCol2 = Servo_IsOrigin(EZ_SERVO_C4);

	
		return (m_NewStatus.m_bXInitialEnd & m_NewStatus.m_bYInitialEnd &
			m_NewStatus.m_bZ1InitialEnd & m_NewStatus.m_bZ2InitialEnd &
			bCol1 & bMask2 & bCol2 & bMask3 & bMask1 & bCol3 & bCol4);
	}
	else
	{
		switch(nAxis)
		{
		case AXIS_X:
			if(m_NewStatus.m_bXInitialEnd)
				return TRUE;
			break;
		case AXIS_Y:
			if(m_NewStatus.m_bYInitialEnd)
				return TRUE;
			break;
		case AXIS_Z1:
			if(m_NewStatus.m_bZ1InitialEnd)
				return TRUE;
			break;
		case AXIS_Z2:
			if(m_NewStatus.m_bZ2InitialEnd)
				return TRUE;
			break;
		case AXIS_M:
			if(Servo_IsOrigin(EZ_SERVO_M1))
				return TRUE;
			break;

		case AXIS_M2:
			if(Servo_IsOrigin(EZ_SERVO_M2))
				return TRUE;
			break;
		case AXIS_M3:
			if(Servo_IsOrigin(EZ_SERVO_M3))
				return TRUE;
			break;

		//case AXIS_M4:
		//	if(Servo_IsOrigin(EZ_SERVO_M4))
		//		return TRUE;
		//	break;

		case AXIS_C:
			if(Servo_IsOrigin(EZ_SERVO_C1))
				return TRUE;
			break;

		case AXIS_C2:
			if(Servo_IsOrigin(EZ_SERVO_C2))
				return TRUE;
			break;

		case AXIS_C3:
			if(Servo_IsOrigin(EZ_SERVO_C3))
				return TRUE;
			break;

		case AXIS_C4:
			if(Servo_IsOrigin(EZ_SERVO_C4))
				return TRUE;
			break;

		default:
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DeviceUMacLarge::PeekMessage()
{
	MSG msg;
	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}
	return FALSE;
}

BOOL DeviceUMacLarge::IsAnyMotorRun()
{


	return (m_NewStatus.m_bXRun | m_NewStatus.m_bYRun | m_NewStatus.m_bZ1Run | m_NewStatus.m_bZ2Run);
}

BOOL DeviceUMacLarge::InPositionStop()
{
	m_nIsInPosition = -3;
	return TRUE;
}

int DeviceUMacLarge::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INPOSITION);
	}
	return IsMoveEnd(nAxis);
}

int DeviceUMacLarge::IsInOrigin(int nAxis, BOOL bWait/*TRUE*/)
{
	//return TRUE;// �ӽ��ӽ�
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INORIGIN);
	}
	return IsMotorOrigin(nAxis);
}

BOOL DeviceUMacLarge::IsLoader(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_LOADSTOP);
		return IsInPositionThread(-1, COMMAND_LOADMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bPCBLoadEnd;
	return m_NewStatus.m_bPCBLoading;//TRUE;
}

BOOL DeviceUMacLarge::IsUnload(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_UNLOADSTOP);
		return IsInPositionThread(-1, COMMAND_UNLOADMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bPCBUnloadEnd;// && m_NewStatus.m_bPCBUnloadReady;
	return m_NewStatus.m_bPCBUnloading;
}

BOOL DeviceUMacLarge::IsAligner(BOOL bStop, BOOL bWait)
{
	if(bWait)
	{
		if(bStop == TRUE)
			return IsInPositionThread(-1, COMMAND_ALIGNERSTOP);
		return IsInPositionThread(-1, COMMAND_ALIGNERMOVING);
	}
	
	if(bStop == TRUE)
		return m_NewStatus.m_bLoaderAlignEnd;// && (m_NewStatus.m_bLoaderAlignEnd || m_NewStatus.m_bLoaderAlignReady));
	return m_NewStatus.m_bLoaderAligning; 
}

BOOL DeviceUMacLarge::IsUnloadertoLoadStart()
{
	return m_NewStatus.m_bPCBLoadRequestReady;
}

BOOL DeviceUMacLarge::IsReady(int nAxis)
{
	return (m_NewStatus.m_bMainRunReady);// & m_NewStatus.m_bLoaderRunReady & m_NewStatus.m_bUnloaderRunReady);
}

BOOL DeviceUMacLarge::IsFlowWater()
{
	return FALSE;
	//return m_NewStatus.m_bWaterFlowError;

}

BOOL DeviceUMacLarge::IsTowerBuzzer()
{
//	return m_NewStatus.m_bTowerBuzzer_;

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsLaserSystemWarning()
{
	return m_NewStatus.m_bLaserSystemWarning;
}

BOOL DeviceUMacLarge::IsLaserOverTempFault()
{
	return m_NewStatus.m_bLaserOverTempFault;
}

BOOL DeviceUMacLarge::IsLaserSystemWarning2()
{
	return m_NewStatus.m_bLaserSystemWarning2;
}

BOOL DeviceUMacLarge::IsLaserOverTempFault2()
{
	return m_NewStatus.m_bLaserOverTempFault2;
}


UINT DeviceUMacLarge::IsScannerFault()
{
	UINT nIsFault = 0;
	
//	nIsFault += (m_NewStatus.m_bX1ScannerFault) ? 1 : 0;
//	nIsFault += (m_NewStatus.m_bY1ScannerFault) ? 2 : 0;
//	nIsFault += (m_NewStatus.m_bX2ScannerFault) ? 4 : 0;
//	nIsFault += (m_NewStatus.m_bY2ScannerFault) ? 8 : 0;


	return nIsFault = 0;
}

BOOL DeviceUMacLarge::IsSystemDoorBypass()
{
	return m_NewStatus.m_bDoorBypassStatus;
}

BOOL DeviceUMacLarge::IsDoorLockOnStatus()
{
	return TRUE;
	//return m_NewStatus.m_bDoorLockOnStatus;
}




BOOL DeviceUMacLarge::IsMainDoorStop()
{
	 return m_NewStatus.m_bFrontDoorOpenAlarm;
}

BOOL DeviceUMacLarge::IsOpticsDoorStop()
{
	return m_NewStatus.m_bRearDoorOpenAlarm;
}

BOOL DeviceUMacLarge::LoaderElvOriginPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C0, 2);
}

BOOL DeviceUMacLarge::LoaderElvLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C0, 1);
}

BOOL DeviceUMacLarge::LoaderCarrierLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 3);
}

BOOL DeviceUMacLarge::LoaderCarrierAlignPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 5);
}

BOOL DeviceUMacLarge::LoaderCarrierAlignPos2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 6);
}

BOOL DeviceUMacLarge::UnloaderElvOriginPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D0, 2);
}

BOOL DeviceUMacLarge::UnloaderElvUnloadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D0, 1);
}

BOOL DeviceUMacLarge::UnloaderCarrierTablePos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D1, 2);
}

BOOL DeviceUMacLarge::UnloaderCarrierUnloadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610D1, 3);
}

BOOL DeviceUMacLarge::LoaderPicker1Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 1);
}

BOOL DeviceUMacLarge::LoaderPicker1Align()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 2);
}

BOOL DeviceUMacLarge::LoaderPicker1Load()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 4);
}

BOOL DeviceUMacLarge::LoaderPicker1P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C2, 3);
}

BOOL DeviceUMacLarge::LoaderPicker2Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 1);
}

BOOL DeviceUMacLarge::LoaderPicker2Align()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 2);
}

BOOL DeviceUMacLarge::LoaderPicker2Load()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 4);
}

BOOL DeviceUMacLarge::LoaderPicker2P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C3, 3);
}

BOOL DeviceUMacLarge::LoaderClampForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 6, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 7, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderClampBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 6, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 7, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderVacuum1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 5, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 6, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderVacuum1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 5, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 6, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderVacuum2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 15, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 0, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderVacuum2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 15, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 0, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderBlow1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 7, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 8, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderBlow1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(4, 7, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(4, 8, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderBlow2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 1, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 2, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderBlow2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 1, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 2, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderTableForward() // ���̺� ��������
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 14, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 15, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderTableBackward() // ���̺� ��������
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 14, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 15, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderAlignXForward() // ����� ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 12, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 13, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderAlignXBackward() // ����� ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 12, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 13, 1);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderAlignYForward() // sheet table ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 10, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 11, 0);
	return bResult;
}

BOOL DeviceUMacLarge::LoaderAlignYBackward() // sheet table ����
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(5, 10, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(5, 11, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderPicker1Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 1);
}

BOOL DeviceUMacLarge::UnloaderPicker1Table()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 2);
}

BOOL DeviceUMacLarge::UnloaderPicker1Unload()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 4);
}

BOOL DeviceUMacLarge::UnloaderPicker1P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610D2, 3);
}

BOOL DeviceUMacLarge::UnloaderPicker2Init()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 1);
}

BOOL DeviceUMacLarge::UnloaderPicker2Table()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 2);
}

BOOL DeviceUMacLarge::UnloaderPicker2Unload()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 4);
}

BOOL DeviceUMacLarge::UnloaderPicker2P2()
{
	return MotionControlDLL_WriteOutputDWord(0x610D3, 3);
}

BOOL DeviceUMacLarge::UnloaderClampForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 6, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 7, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderClampBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 6, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 7, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderVacuum1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 5, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 6, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderVacuum1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 5, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 6, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderVacuum2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 15, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 0, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderVacuum2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 15, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 0, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderBlow1On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 7, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 8, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderBlow1Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(7, 7, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(7, 8, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderBlow2On()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 1, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 2, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderBlow2Off()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 1, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 2, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderTableForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 14, 1);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 15, 0);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderTableBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 14, 0);
	bResult = bResult & MotionControlDLL_WriteOutputIOBit(8, 15, 1);
	return bResult;
}

BOOL DeviceUMacLarge::IsFluorescentLampOn()
{
	
	if(m_NewStatus.m_bFlourcentLampOn)
		return TRUE;
	else
		return FALSE;
	

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsLoaderPicker1PCBExist()
{
	if(m_NewStatus.m_bLoaderPicker1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsLoaderPicker2PCBExist()
{
	if(m_NewStatus.m_bLoaderPicker2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsAlignerPCBExist()
{
	if(m_NewStatus.m_bLoaderAlignTablePCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsULAlignerPCBExist()
{
	if(m_NewStatus.m_bUnloaderAlignTablePCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::TablePCBReset()
{
#ifdef __NANYA__
	return TRUE;
#else
	return MotionControlDLL_WriteOutputIOBit(6, 12, 1);
#endif


}

BOOL DeviceUMacLarge::LoaderPCBReset()
{
	return TRUE;
	//return MotionControlDLL_WriteOutputIOBit(3, 6, 1);
}

BOOL DeviceUMacLarge::UnLoaderPCBReset()
{
	return TRUE;
	//return MotionControlDLL_WriteOutputIOBit(6, 6, 1);
}

BOOL DeviceUMacLarge::IsUnloaderPicker1PCBExist()
{
	if(m_NewStatus.m_bUnloader1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsUnloaderPicker2PCBExist()
{
	if(m_NewStatus.m_bUnloader2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsTable1PCBExist()
{
	if(m_NewStatus.m_bMasterTableVacuumAIndicator)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsTable2PCBExist()
{
	if(m_NewStatus.m_bSlaveTableVacuumAIndicator)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceUMacLarge::IsLoader1Error()
{
#ifdef __TEST__
	return FALSE;
#else
	return m_NewStatus.m_bLoaderAlarm;
#endif
}

BOOL DeviceUMacLarge::IsLoader2Error()
{
	BOOL bError = FALSE;
	return bError;

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsAlignerError()
{
	BOOL bError = FALSE;
	return bError;

return 0; //20160418 IO

}

BOOL DeviceUMacLarge::IsULAlignerError()
{
	BOOL bError = FALSE;
	return bError;

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsUnloader1Error()
{
#ifdef __TEST__
	return FALSE;
#else
	return m_NewStatus.m_bUnloaderAlarm;
#endif
}

BOOL DeviceUMacLarge::IsUnloader2Error()
{
	BOOL bError = FALSE;
	return bError;

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsTable1Error()
{
	BOOL bError = FALSE;



	if(m_NewStatus.m_b1stTableVacuumOnError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	if(m_NewStatus.m_b1stTableVacuumOffError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacLarge::IsTable2Error()
{
	BOOL bError = FALSE;



	if(m_NewStatus.m_b2ndTableVacuumOnError)		bError = bError | TRUE;
	else											bError = bError | FALSE;
	
	if(m_NewStatus.m_b2ndTableVacuumOffError)		bError = bError | TRUE;
	else											bError = bError | FALSE;

	return bError;
}

BOOL DeviceUMacLarge::Loader1PCBExist(BOOL bOn)
{
	BOOL bResult;
	

		bResult = MotionControlDLL_WriteOutputIOBit(3, 6, 1);

		return bResult;


}

BOOL DeviceUMacLarge::Loader2PCBExist(BOOL bOn)
{
	BOOL bResult;
	
//	if(bOn)
//	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 8, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 9, 0);
		return bResult;
//	}
//	else
//	{
//		bResult = MotionControlDLL_WriteOutputIOBit(3, 8, 0);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 9, 1);
//		return bResult;
//	}

}

BOOL DeviceUMacLarge::AlignTablePCBExist(BOOL bOn)
{
	BOOL bResult;

//	if(bOn)
//	{
		bResult = MotionControlDLL_WriteOutputIOBit(3, 10, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 11, 0);
		return bResult;
//	}
//	else
//	{
//		bResult = MotionControlDLL_WriteOutputIOBit(3, 10, 0);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(3, 11, 1);
//		return bResult;
//	}

}

BOOL DeviceUMacLarge::ULAlignTablePCBExist(BOOL bOn)
{
	BOOL bResult;
	
//	if(bOn)
//	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 1);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 0);
		return bResult;
//	}
//	else
//	{
//		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 0);
//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 1);
//		return bResult;
//	}
}

BOOL DeviceUMacLarge::Unloader1PCBExist(BOOL bOn)
{
	BOOL bResult;

//	if(bOn)
	//	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 1);
	//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 7, 0);
		return bResult;
	//	}
	//	else
	//	{
	//		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 0);
	//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 7, 1);
	//		return bResult;
	//	}
	
}

BOOL DeviceUMacLarge::Unloader2PCBExist(BOOL bOn)
{
	BOOL bResult;

//	if(bOn)
	//	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 1);
	//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 9, 0);
		return bResult;
	//	}
	//	else
	//	{
	//		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 0);
	//		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 9, 1);
	//		return bResult;
	//	}
	
}

BOOL DeviceUMacLarge::UnloadTablePCBExist(BOOL bOn)
{
	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(6, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::Table1VacuumMotor(BOOL bOn)
{


	//if(!gSystemINI.m_sHardWare.bUseVacummmotor)
		//bOn = TRUE;

     return SetOutPort(PORT_RING_BLOWER_REMOTE_RUN, bOn, FALSE);
}

BOOL DeviceUMacLarge::TableVacuumSelect(BOOL bOn)
{
	return TRUE;
//	BOOL bResult;
//	
//	if(bOn)
//	{
//		bResult = MotionControlDLL_WriteOutputIOBit(9, 10, 1);
//		return bResult;
//	}
//	else
//	{
//		bResult = MotionControlDLL_WriteOutputIOBit(9, 10, 0);
//		return bResult;
//	}

}

BOOL DeviceUMacLarge::Table2VacuumMotor(BOOL bOn)
{
	return TRUE;

	BOOL bResult;

	if(bOn)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 13, 1);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 14, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(1, 13, 0);
		bResult = bResult & MotionControlDLL_WriteOutputIOBit(1, 14, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::LoaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
	BOOL bResult = TRUE;

	if(nPicker == 1)
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	else
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderPickerPad(int nPicker, int nPad, BOOL bUp)
{
	BOOL bResult = TRUE;
	if(nPicker == 1)
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	else
	{
		if(nPad == 1)
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
		else
		{
			if(bUp)
			{
			}
			else
			{
			}
		}
	}
	return bResult;
}

void DeviceUMacLarge::SetInitialCmd()
{
	m_lWritePos[AXIS_X] = m_NewStatus.m_nXCommandPos;
	m_lWritePos[AXIS_Y] = m_NewStatus.m_nYCommandPos;
	m_lWritePos[AXIS_Z1] = m_NewStatus.m_nZ1CommandPos;
	m_lWritePos[AXIS_Z2] = m_NewStatus.m_nZ2CommandPos;//20160418 IO

}

void DeviceUMacLarge::SetResetCmd()
{
	m_lWritePos[AXIS_X] = 0;
	m_lWritePos[AXIS_Y] = 0;
	m_lWritePos[AXIS_Z1] = 0;
	m_lWritePos[AXIS_Z2] = 0;
	m_lWritePos[AXIS_M] = 0;
    m_lWritePos[AXIS_M2] = 0;
	m_lWritePos[AXIS_M3] = 0;
	m_lWritePos[AXIS_M4] = 0;

	m_lWritePos[AXIS_C] = 0;
   m_lWritePos[AXIS_C2] = 0;
	
   m_lWritePos[AXIS_ROT] = 0;
   m_lWritePos[AXIS_TOPHAT] = 0;
}

BOOL DeviceUMacLarge::IsCmdPosOK()
{
	if(m_NewStatus.m_nXCommandPos != m_lWritePos[AXIS_X]) // x command pos , real encoder pos
	{
		return FALSE;
	}
	if(m_NewStatus.m_nYCommandPos  != m_lWritePos[AXIS_Y]) // y
	{
		return FALSE;
	}
	if(m_NewStatus.m_nZ1CommandPos  != m_lWritePos[AXIS_Z1]) // z1
	{
		return FALSE;
	}
	if(m_NewStatus.m_nZ2CommandPos  != m_lWritePos[AXIS_Z2]) // z2
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL DeviceUMacLarge::SetMoveIO(int nMoveAxis)
{
	BOOL bResult = TRUE;
	if(nMoveAxis == MOVE_XYZ)
		return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2));
	else if(nMoveAxis == MOVE_XY)
		return MotionControlDLL_WriteOutputDWord(0x610B0, 5);
	else if(nMoveAxis == MOVE_XYMC)
	{	bResult = (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
		MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//		MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
		MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
		MotionControlDLL_WriteOutputDWord(0x610B6, 2));


		if(!m_bConnect)
			return FALSE;
		
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);

		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , m_lWritePos[AXIS_C3], m_lSpeed[AXIS_C3]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , m_lWritePos[AXIS_C4], m_lSpeed[AXIS_C4]);

		return bResult;
	}
	else if(nMoveAxis == MOVE_XYZMC)
	{
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 5);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B1, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B2, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B3, 2);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B4, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B5, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B6, 2);

		if(!m_bConnect)
			return FALSE;
		
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);

		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , m_lWritePos[AXIS_C3], m_lSpeed[AXIS_C3]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , m_lWritePos[AXIS_C4], m_lSpeed[AXIS_C4]);

		return bResult;
	}
	else if(nMoveAxis == MOVE_XYMCA)
	{
		bResult = MotionControlDLL_WriteOutputDWord(0x610B0, 5);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B1, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B2, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B3, 2);
//		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B4, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B5, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B6, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B7, 2);
		bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610B8, 2);

		if(!m_bConnect)
			return FALSE;
		
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);

		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , m_lWritePos[AXIS_C3], m_lSpeed[AXIS_C3]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , m_lWritePos[AXIS_C4], m_lSpeed[AXIS_C4]);

		return bResult;
	}
	else
		return TRUE;
}

BOOL DeviceUMacLarge::MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel)
{


	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);

	return bResult;
}

#ifdef __NANYA__
int DeviceUMacLarge::InPositionIO(int nAxis)
{
	CString strFile, strLog;
	strFile.Format(_T("InposCheck"));

	if(gSystemINI.m_sHardWare.bUseFastInposition)
	{
	//	double dTime;
	//	CCorrectTime myTime;
	//	myTime.StartTime();
		InposRam7 InPosInfo;
		::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition7), &m_NewStatus);
		memcpy(&InPosInfo, m_NewStatus.m_61080SFastInpos, sizeof(InPosInfo));
//		dTime = myTime.PresentTime();
//		TRACE(_T("i = %d, SetPos = %d, curPos = %d, Inpos = %d, Move = %d, Time = %.4f \n")), i, nSetPos, InPosInfo.m_nXPos, InPosInfo.m_nXPosInpos, bMove, dTime);
	
		m_NewStatus.m_nXActualPos = InPosInfo.m_nXPos;
		m_NewStatus.m_nYActualPos = InPosInfo.m_nYPos;
		m_NewStatus.m_nZ1ActualPos = InPosInfo.m_nZ1Pos;
		m_NewStatus.m_nZ2ActualPos = InPosInfo.m_nZ2Pos;

	
		if(nAxis & 0x0001)
		{
			if(abs(InPosInfo.m_nXPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
				return IND_X;
			else
			{
				strLog.Format(_T("x Command pos %d - encoder pos %d : %d"),m_lWritePos[AXIS_X], InPosInfo.m_nXPos, abs(InPosInfo.m_nXPos - m_lWritePos[AXIS_X]));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
		
			if(!InPosInfo.m_nXPosInpos)
				return IND_X;
			else
			{
				strLog.Format(_T("x PlcInpos Signal : %d"), InPosInfo.m_nXPosInpos);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}

		}
		if(nAxis >> 1 & 0x0001)
		{
			if(abs(InPosInfo.m_nYPos  - m_lWritePos[AXIS_Y])>2) // y
				return IND_Y;
			else
			{
				strLog.Format(_T("y Command pos %d - encoder pos %d : %d"),m_lWritePos[AXIS_Y], InPosInfo.m_nYPos, abs(InPosInfo.m_nYPos  - m_lWritePos[AXIS_Y]));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
			
			if(!InPosInfo.m_nYPosInpos)
				return IND_Y;
			else
			{
				strLog.Format(_T("y PlcInpos Signal : %d"), InPosInfo.m_nYPosInpos);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
		}

		if(nAxis >> 2 & 0x0001)
		{
			if(abs(InPosInfo.m_nZ1Pos  - m_lWritePos[AXIS_Z1])>2) // z1
				return IND_Z1;
			
			if(!InPosInfo.m_nZ1PosInpos)
				return IND_Z1;
		}

		if(nAxis >> 3 & 0x0001)
		{
			if(abs(InPosInfo.m_nZ2Pos  - m_lWritePos[AXIS_Z2])>2) // z2
				return IND_Z2;
			
			if(!InPosInfo.m_nZ2PosInpos)
				return IND_Z2;
		}


		if(nAxis >> 4 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M]  - m_lWritePos[AXIS_M]/(long)m_dScale[AXIS_M])>2)
				return IND_M1;

		}
		if(nAxis >> 5 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M2]  - m_lWritePos[AXIS_M2]/(long)m_dScale[AXIS_M2])>2)
				return IND_M2;
		}
		if(nAxis >> 6 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M3, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M3, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M3]  - m_lWritePos[AXIS_M3]/(long)m_dScale[AXIS_M3])>2)
				return IND_M3;

		}
		/*if(nAxis >> 7 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M4, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M4, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M4]  - m_lWritePos[AXIS_M4]/(long)m_dScale[AXIS_M4])>2)
				return IND_M4;
		}*/
		if(nAxis >> 8 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C]  - m_lWritePos[AXIS_C]/(long)m_dScale[AXIS_C])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C])>2)
				return IND_C1;

		}

		if(nAxis >> 9 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C2])>2)
				return IND_C2;

		}


		//if(nAxis >> 10 & 0x0001)
		//{

		//	long lCurrPos;
		//	Servo_GetActualPos(EZ_SERVO_ROT, &lCurrPos);
		//	//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
		//	if(labs(lCurrPos  - m_lWritePos[AXIS_ROT])>2)
		//		return IND_ROT;

		//}

		if(nAxis >> 13 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_TOPHAT, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_TOPHAT])>2)
				return IND_TOPHAT;

		}


		return ALL_AXIS_OK;
	}
	else
	{
		::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition7), &m_NewStatus);
		
		if(nAxis & 0x0001)
		{
			if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>2) // x command pos , real encoder pos
				return IND_X;
		
			if(!m_NewStatus.m_bXInposition)
				return IND_X;
		}

		if(nAxis >> 1 & 0x0001)
		{
			if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>2) // y
				return IND_Y;
			
			if(!m_NewStatus.m_bYInposition)
				return IND_Y;
		}

		if(nAxis >> 2 & 0x0001)
		{
			if(abs(m_NewStatus.m_nZ1ActualPos  - m_lWritePos[AXIS_Z1])>2) // z1
				return IND_Z1;
			
			if(!m_NewStatus.m_bZ1Inposition)
				return IND_Z1;
		}

		if(nAxis >> 3 & 0x0001)
		{
			if(abs(m_NewStatus.m_nZ2ActualPos  - m_lWritePos[AXIS_Z2])>2) // z2
				return IND_Z2;
			
			if(!m_NewStatus.m_bZ2Inposition)
				return IND_Z2;
		}

		if(nAxis >> 4 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M]  - m_lWritePos[AXIS_M]/(long)m_dScale[AXIS_M])>2)
				return IND_M1;
		}
		if(nAxis >> 5 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M2]  - m_lWritePos[AXIS_M2]/(long)m_dScale[AXIS_M2])>2)
				return IND_M2;
		}
		if(nAxis >> 6 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M3, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M3, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M3]  - m_lWritePos[AXIS_M3]/(long)m_dScale[AXIS_M3])>2)
				return IND_M3;
		}
		/*if(nAxis >> 7 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M4, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M4, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M4]  - m_lWritePos[AXIS_M4]/(long)m_dScale[AXIS_M4])>2)
				return IND_M4;
		}*/

		if(nAxis >> 8 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
			if(labs(lCurrPos/ (long)m_dScale[AXIS_C]  - m_lWritePos[AXIS_C]/(long)m_dScale[AXIS_C])>2)
				return IND_C1;
		}


		if(nAxis >> 9 & 0x0001)
		{
		long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
			if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
				return IND_C2;
		}
		/*if(nAxis >> 10 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_ROT, &lCurrPos);
			if(labs(lCurrPos/ (long)m_dScale[AXIS_ROT]  - m_lWritePos[AXIS_ROT]/(long)m_dScale[AXIS_ROT])>2)
				return IND_ROT;
		}*/
		if(nAxis >> 13 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_TOPHAT, &lCurrPos);
			if(labs(lCurrPos/ (long)m_dScale[AXIS_TOPHAT]  - m_lWritePos[AXIS_TOPHAT]/(long)m_dScale[AXIS_TOPHAT])>2)
				return IND_TOPHAT;
		}
		return ALL_AXIS_OK;
	}
}
#else
int DeviceUMacLarge::InPositionIO(int nAxis)
{
	if(gSystemINI.m_sHardWare.bUseFastInposition)
	{
	//	double dTime;
	//	CCorrectTime myTime;
	//	myTime.StartTime();
		InposRam7 InPosInfo;
		::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition7), &m_NewStatus);
		memcpy(&InPosInfo, m_NewStatus.m_61080SFastInpos, sizeof(InPosInfo));
//		dTime = myTime.PresentTime();
//		TRACE(_T("i = %d, SetPos = %d, curPos = %d, Inpos = %d, Move = %d, Time = %.4f \n")), i, nSetPos, InPosInfo.m_nXPos, InPosInfo.m_nXPosInpos, bMove, dTime);
	
		m_NewStatus.m_nXActualPos = InPosInfo.m_nXPos;
		m_NewStatus.m_nYActualPos = InPosInfo.m_nYPos;
		m_NewStatus.m_nZ1ActualPos = InPosInfo.m_nZ1Pos;
		m_NewStatus.m_nZ2ActualPos = InPosInfo.m_nZ2Pos;

		int nTableInposCount =  gProcessINI.m_sProcessOption.nTabelInposCount;
		if(nAxis & 0x0001)
		{

			if(abs(InPosInfo.m_nXPos - m_lWritePos[AXIS_X])>nTableInposCount) // x command pos , real encoder pos
				return IND_X;
		
			if(!InPosInfo.m_nXPosInpos)
				return IND_X;
		}
		if(nAxis >> 1 & 0x0001)
		{
	
			if(abs(InPosInfo.m_nYPos  - m_lWritePos[AXIS_Y])>nTableInposCount) // y
				return IND_Y;
			
			if(!InPosInfo.m_nYPosInpos)
				return IND_Y;
		}

		if(nAxis >> 2 & 0x0001)
		{
		
		//5um
			if(abs(InPosInfo.m_nZ1Pos  - m_lWritePos[AXIS_Z1])>5) // z1
				return IND_Z1;
			
			if(!InPosInfo.m_nZ1PosInpos)
				return IND_Z1;
		}

		if(nAxis >> 3 & 0x0001)
		{
		//5um
			if(abs(InPosInfo.m_nZ2Pos  - m_lWritePos[AXIS_Z2])>5) // z2
				return IND_Z2;
			
			if(!InPosInfo.m_nZ2PosInpos)
				return IND_Z2;
		}


		if(nAxis >> 4 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M]  - m_lWritePos[AXIS_M]/(long)m_dScale[AXIS_M])>2)
				return IND_M1;

		}
		if(nAxis >> 5 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C]  - m_lWritePos[AXIS_C]/(long)m_dScale[AXIS_C])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C])>2)
				return IND_C1;

		}

		if(nAxis >> 6 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M2]  - m_lWritePos[AXIS_M2]/(long)m_dScale[AXIS_M2])>2)
				return IND_M2;
		}

		if(nAxis >> 7 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C2])>2)
				return IND_C2;

		}

		if(nAxis >> 14 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C3, &lCurrPos);
			if(labs(lCurrPos  - m_lWritePos[AXIS_C3])>2)
				return IND_C3;

		}

		if(nAxis >> 15 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C4, &lCurrPos);
			if(labs(lCurrPos  - m_lWritePos[AXIS_C4])>2)
				return IND_C4;

		}

		return ALL_AXIS_OK;
	}
	else
	{
		::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition7), &m_NewStatus);
		
		int nTableInposCount =  gProcessINI.m_sProcessOption.nTabelInposCount;
		if(nAxis & 0x0001)
		{
			if(abs(m_NewStatus.m_nXActualPos - m_lWritePos[AXIS_X])>nTableInposCount) // x command pos , real encoder pos
				return IND_X;
		
			if(!m_NewStatus.m_bXInposition)
				return IND_X;
		}

		if(nAxis >> 1 & 0x0001)
		{
			if(abs(m_NewStatus.m_nYActualPos  - m_lWritePos[AXIS_Y])>nTableInposCount) // y
				return IND_Y;
			
			if(!m_NewStatus.m_bYInposition)
				return IND_Y;
		}

		if(nAxis >> 2 & 0x0001)
		{
			if(abs(m_NewStatus.m_nZ1ActualPos  - m_lWritePos[AXIS_Z1])>5) // z1
				return IND_Z1;
			
			if(!m_NewStatus.m_bZ1Inposition)
				return IND_Z1;
		}

		if(nAxis >> 3 & 0x0001)
		{
			if(abs(m_NewStatus.m_nZ2ActualPos  - m_lWritePos[AXIS_Z2])>5) // z2
				return IND_Z2;
			
			if(!m_NewStatus.m_bZ2Inposition)
				return IND_Z2;
		}

		if(nAxis >> 4 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/ (long)m_dScale[AXIS_M]  - m_lWritePos[AXIS_M]/(long)m_dScale[AXIS_M])>2)
				return IND_M1;
		}
			if(nAxis >> 5 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C]  - m_lWritePos[AXIS_C]/(long)m_dScale[AXIS_C])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C])>2)
				return IND_C1;

		}

		if(nAxis >> 6 & 0x0001) 
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
			long lErrorPos;
			Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
			lCurrPos += lErrorPos;	
			if(labs(lCurrPos/(long)m_dScale[AXIS_M2]  - m_lWritePos[AXIS_M2]/(long)m_dScale[AXIS_M2])>2)
				return IND_M2;
		}

		if(nAxis >> 7 & 0x0001)
		{

			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C2])>2)
				return IND_C2;

		}
		
		if(nAxis >> 14 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C3, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C3])>2)
				return IND_C3;
		}

		if(nAxis >> 15 & 0x0001)
		{
			long lCurrPos;
			Servo_GetActualPos(EZ_SERVO_C4, &lCurrPos);
			//if(labs(lCurrPos/ (long)m_dScale[AXIS_C2]  - m_lWritePos[AXIS_C2]/(long)m_dScale[AXIS_C2])>2)
			if(labs(lCurrPos  - m_lWritePos[AXIS_C4])>2)
				return IND_C4;
		}
		return ALL_AXIS_OK;
	}
}
#endif
BOOL DeviceUMacLarge::IsLCinCartPos()
{
	//return m_NewStatus.m_bLCInCartPosition;

	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsLCinLoadPos()
{
	//return m_NewStatus.m_bLCInUnloadPosition;

	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsLCinOriginPos()
{
	//return m_NewStatus.m_bLCInOriginPosition;


	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsLCinReadyPos()
{
	//return m_NewStatus.m_bLCInReadyPosition


		return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsLCinAlignPos()
{
//	return m_NewStatus.m_bLCInAlignPosition;


	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsUCinAlignPos()
{
	//return m_NewStatus.m_bUCInAlignPosition;

	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsUCinCartPos()
{
	//return m_NewStatus.m_bUCInCartPosition;

	return 0;//20160418 IO
//	return TRUE;
}

BOOL DeviceUMacLarge::IsUCinUnloadPos()
{
	//return m_NewStatus.m_bUCInLoadPosition;

	return 0;//20160418 IO
//	return TRUE;
}

BOOL DeviceUMacLarge::IsUCinOriginPos()
{
//	return m_NewStatus.m_bUCInOriginPosition;

	return 0;//20160418 IO
//	return TRUE;
}

BOOL DeviceUMacLarge::IsLP1P1Up()
{
/*	if(m_NewStatus.m_bLoaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick1Pad1Down)
		return FALSE;
	else if(m_NewStatus.m_bLoaderPick1Pad2Down)
		return FALSE;
		*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsLP1P2Up()
{
/*	if(m_NewStatus.m_bLoaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick1Pad1Down)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick1Pad2Down)
		return FALSE;
		*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsLP2P1Up()
{
/*	if(m_NewStatus.m_bLoaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick2Pad1Down)
		return FALSE;
	else if(m_NewStatus.m_bLoaderPick2Pad2Down)
		return FALSE;
*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsLP2P2Up()
{
/*	if(m_NewStatus.m_bLoaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick2Pad1Down)
		return TRUE;
	else if(m_NewStatus.m_bLoaderPick2Pad2Down)
		return FALSE;
*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsULP1P1Up()
{
	/*
	if(m_NewStatus.m_bUnloaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick1Pad1Down)
		return FALSE;
	else if(m_NewStatus.m_bUnloaderPick1Pad2Down)
		return FALSE;
	*/
	return 0; //20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsULP1P2Up()
{
	/*
	if(m_NewStatus.m_bUnloaderPick1Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick1Pad1Down)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick1Pad2Down)
		return FALSE;
	*/
	return 0; //20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsULP2P1Up()
{
	/*
	if(m_NewStatus.m_bUnloaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick2Pad1Down)
		return FALSE;
	else if(m_NewStatus.m_bUnloaderPick2Pad2Down)
		return FALSE;
	*/

	return 0; //20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsULP2P2Up()
{
	/*
	if(m_NewStatus.m_bUnloaderPick2Pad1Up)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick2Pad1Down)
		return TRUE;
	else if(m_NewStatus.m_bUnloaderPick2Pad2Down)
		return FALSE;

	*/
	return 0; //20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsLoaderAlignTableForward()
{
	/*
	if(m_NewStatus.m_bLoaderAlignTblForward)
		return TRUE;
	else if(m_NewStatus.m_bLoaderAlignTblBackward)
		return FALSE;
	*/

	return 0;//20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsUnloaderAlignTableForward()
{
	return TRUE; // ���� Ÿ��
}

BOOL DeviceUMacLarge::IsLoaderCartClamp()
{
/*	if(m_NewStatus.m_bLoaderCartClampUp)
		return FALSE;
	else if(m_NewStatus.m_bLoaderCartClampDown)
		return TRUE;
		*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsAlignSheetTableForward()
{
	//return m_NewStatus.m_bLoaderAlignTblForward; 

	return 0;//20160418 IO
}

BOOL DeviceUMacLarge::IsAlignGuideForward()
{
	return TRUE;
/*	if(m_NewStatus.m_bLoaderAlignGuideForward)
		return TRUE;
	else if(m_NewStatus.m_bLoaderAlignGuideBackward)
		return FALSE;
	else if(!m_NewStatus.m_bLoaderAlignGuideForward && !m_NewStatus.m_bLoaderAlignGuideBackward)
		return 3;

	return TRUE;
*/
}

BOOL DeviceUMacLarge::IsLoaderPicker1Vacuum()
{
	BOOL bResult;
	//bResult = m_NewStatus.m_bLoaderPicker1Vacuum1;
//	bResult = bResult & m_NewStatus.m_bLoaderPicker1Vacuum2;


	return 0;//20160418 IO
	return bResult;
}

BOOL DeviceUMacLarge::IsLoaderPicker2Vacuum()
{
	BOOL bResult;
	//bResult = m_NewStatus.m_bLoaderPicker2Vacuum1;
//	bResult = bResult & m_NewStatus.m_bLoaderPicker2Vacuum2;


	return 0;//20160418 IO
	return bResult;
}

BOOL DeviceUMacLarge::IsLoaderPicker1Blow()
{
	return TRUE; //m_NewStatus.m_bLoaderPicker1Vacuum2;
}

BOOL DeviceUMacLarge::IsLoaderPicker2Blow()
{
	return TRUE; //m_NewStatus.m_bLoaderPicker2Vacuum2;
}

BOOL DeviceUMacLarge::IsUnloaderCartClamp()
{
	/*
	if(m_NewStatus.m_bUnloaderCartClampUp)
		return FALSE;
	else if(m_NewStatus.m_bUnloaderCartClampDown)
		return TRUE;
	*/

	return 0; //20160418 IO
	return TRUE;
}

BOOL DeviceUMacLarge::IsUnloaderPicker1Vacuum()
{
	BOOL bResult;
//	bResult = m_NewStatus.m_bUnloaderPicker1Vacuum1;
	return 0; //20160418 IO
//	bResult = bResult & m_NewStatus.m_bUnloaderPicker1Vacuum2;
	return bResult;
}

BOOL DeviceUMacLarge::IsUnloaderPicker2Vacuum()
{
	BOOL bResult;
//	bResult = m_NewStatus.m_bUnloaderPicker2Vacuum1;
	return 0; //20160418 IO
//	bResult = bResult & m_NewStatus.m_bUnloaderPicker2Vacuum2;
	return bResult;
}

BOOL DeviceUMacLarge::IsUnloaderNGBoxForward()
{
	BOOL bResult;
	//bResult = m_NewStatus.m_bUnloaderNGBoxForward;

	return 0; //20160418 IO
	return bResult;
}

BOOL DeviceUMacLarge::IsUnloaderNGBoxBackward()
{
	BOOL bResult;
//	bResult = m_NewStatus.m_bUnloaderNGBoxBackward;

	return 0; //20160418 IO
	return bResult;
}

BOOL DeviceUMacLarge::IsUnloaderPicker1Blow()
{
	return TRUE; //m_NewStatus.m_bUnloaderPicker1Vacuum2;
}

BOOL DeviceUMacLarge::IsUnloaderPicker2Blow()
{
	return TRUE; //m_NewStatus.m_bUnloaderPicker2Vacuum2;
}

BOOL DeviceUMacLarge::IsLoadCartNoPCB()
{
	return TRUE;
	/*if(m_NewStatus.m_bLoaderElvSheetDetector)
		return FALSE;
	else
		return TRUE;
		*/
}

BOOL DeviceUMacLarge::SendLoadCartNoPCB()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(3, 4, 1);
	return bResult;
}
BOOL DeviceUMacLarge::TableCalibration(BOOL bAxisX)
{
	BOOL bResult;
	if(bAxisX)
		bResult = MotionControlDLL_WriteOutputIOBit(3, 14, 1);
	else
		bResult = MotionControlDLL_WriteOutputIOBit(3, 15, 1);

	return bResult;
}

BOOL DeviceUMacLarge::IsSafetyMode()
{
         //20160418 IO
	return FALSE;
}

BOOL DeviceUMacLarge::TableLoadPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610B0, 6);
}

BOOL DeviceUMacLarge::TableUnloadPos(BOOL b1st)
{
	if(b1st)
		return MotionControlDLL_WriteOutputDWord(0x610B0, 7);
	else
		return MotionControlDLL_WriteOutputDWord(0x610B0, 8);
}

BOOL DeviceUMacLarge::GetCurrentTableClamp(BOOL b1st, BOOL bClamp)
{
	if(b1st)
	{
		if(bClamp)
			return m_NewStatus.m_bTable1PCBClampSensor;
		else
			return m_NewStatus.m_bTable1PCBUlclampSensor;
	}
	else
	{
		if(bClamp)
			return m_NewStatus.m_bTable2PCBClampSensor;
		else
			return m_NewStatus.m_bTable2PCBUlclampSensor;
	}
	
	return 0; 
}

BOOL DeviceUMacLarge::TableClamp(BOOL bClamp, double dLimitY, BOOL bLeft)
{
	//return TRUE;
	BOOL bRet = TRUE;
	if(bClamp)
	{
		if(bLeft)
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 4, TRUE); //MotionControlDLL_WriteOutputDWord(0x610B8, 0);
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 5, FALSE); //MotionControlDLL_WriteOutputDWord(0x610B7, 1);
		}
		else
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 6, TRUE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 7, FALSE);
		}
	}
	else
	{
		if(m_NewStatus.m_nYActualPos > dLimitY * 1000.0)
		{
			ErrMessage(IDS_ERR_UNCLAMP_IMPOSSIBLE);
			return FALSE;
		}

		if(bLeft)
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 4, FALSE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 5, TRUE); 
		}
		else
		{
			bRet = MotionControlDLL_WriteOutputIOBit(9, 6, FALSE); 
			bRet = bRet & MotionControlDLL_WriteOutputIOBit(9, 7, TRUE);
		}
	}
	return bRet;
}

BOOL DeviceUMacLarge::WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff)
{
	return MotionControlDLL_WriteOutputIOBit(nAddr, nBit, bOnOff);
}

BOOL DeviceUMacLarge::WriteOutputDWord(UINT nAddr, DWORD dwVal)
{
	return MotionControlDLL_WriteOutputDWord(nAddr, dwVal);
}

BOOL DeviceUMacLarge::GetCurrentMotorSol()
{
	/*
	if(gSystemINI.m_sHardWare.bUseVacummmotor)
		return m_NewStatus.m_bTableVacuumMotorOn & m_NewStatus.m_bTableVacuumFanOn;
	else
		return TRUE;
	*/

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::UnloaderNGBoxForward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 8, 1);
	return bResult;
}

BOOL DeviceUMacLarge::UnloaderNGBoxBackward()
{
	BOOL bResult;
	bResult = MotionControlDLL_WriteOutputIOBit(8, 9, 1);
	return bResult;
}


BOOL DeviceUMacLarge::IsHandlerReady()
{
	return 1;// m_NewStatus.m_bHandlerReady;
}

BOOL DeviceUMacLarge::IsHandlerAlarm()
{
	return 0;// m_NewStatus.m_bHandlerAlarm;	
}

BOOL DeviceUMacLarge::IsHandlerLotEnd()
{
	return 1;// m_NewStatus.m_bHandlerLotEnd;
}

BOOL DeviceUMacLarge::IsHandler1stTableExist()
{
	return 1;// m_NewStatus.m_bHandler1stTableExist;
}

BOOL DeviceUMacLarge::IsHandler2ndTableExist()
{
	return 1;// m_NewStatus.m_bHandler2ndTableExist;
}

BOOL DeviceUMacLarge::IsHandlerLoadReady()
{
	return 1;// m_NewStatus.m_bHandlerLoadReady;
}

BOOL DeviceUMacLarge::IsHandlerLoadEnd()
{
	return 1;// m_NewStatus.m_bHandlerLoadEnd;	
}

BOOL DeviceUMacLarge::IsHandlerLoadAlarm()
{
	return 1;// m_NewStatus.m_bHandlerLoadAlarm;	
}

BOOL DeviceUMacLarge::IsHandlerUnloadReady()
{
	return 1;// m_NewStatus.m_bHandlerUnloadReady;	
}

BOOL DeviceUMacLarge::IsHandlerUnloadEnd()
{
	return 1;// m_NewStatus.m_bHandlerUnloadEnd;	
}

BOOL DeviceUMacLarge::IsHandlerUnloadAlarm()
{
	return 1;// m_NewStatus.m_bHandlerUnloadAlarm;	
}

BOOL DeviceUMacLarge::MainReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 0, bOn);
}

BOOL DeviceUMacLarge::MainAlarm(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 1, bOn);
}

BOOL DeviceUMacLarge::MainStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 2, bOn);
}

BOOL DeviceUMacLarge::MainStop(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 3, bOn);
}

BOOL DeviceUMacLarge::MainReset(BOOL bOn)
{
#ifdef __SERVO_MOTOR__
	Servo_AlarmReset();
#endif
	return MotionControlDLL_WriteOutputIOBit(0, 2, bOn);
	//return 1;// MotionControlDLL_WriteOutputIOBit(6, 4, bOn);
}

BOOL DeviceUMacLarge::MainUseTable(int nUseTable)
{
	BOOL bRet = MotionControlDLL_WriteOutputIOBit(6, 5, nUseTable & 0x01);
	bRet = bRet & MotionControlDLL_WriteOutputIOBit(6, 6, (nUseTable >> 1) & 0x01);
	return 1;// bRet;
}

BOOL DeviceUMacLarge::MainLoadReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 7, bOn);
}

BOOL DeviceUMacLarge::MainLoadEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 8, bOn);
}

BOOL DeviceUMacLarge::MainUnloadReady(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 9, bOn);
}

BOOL DeviceUMacLarge::MainUnloadEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 10, bOn);
}

BOOL DeviceUMacLarge::MainPCBExist(int nPCBExist)
{
	BOOL bRet = MotionControlDLL_WriteOutputIOBit(6, 11, nPCBExist & 0x01);
	bRet = bRet & MotionControlDLL_WriteOutputIOBit(6, 12, (nPCBExist >> 1) & 0x01);
	return 1;// bRet;
}

BOOL DeviceUMacLarge::MainLotEnd(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 13, bOn);
}

BOOL DeviceUMacLarge::MainLoadStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 14, bOn);
}

BOOL DeviceUMacLarge::MainUnloadStart(BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, 15, bOn);
}

BOOL DeviceUMacLarge::DustSuctionControl(BOOL bLeft, BOOL bUp, double dMin, double dMax)
{
	if(!gSystemINI.m_sHardWare.nDustTableUse)
		return TRUE;

	BOOL bResult;
	if(bLeft)
	{
		if(bUp)
		{
			bResult = MotionControlDLL_WriteOutputDWord(0x610BB, 1);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BC, 0);
		}
		else
		{
			if(m_NewStatus.m_nXActualPos < dMin * 1000.0 || 
				m_NewStatus.m_nXActualPos > dMax * 1000.0)
			{
		ErrMessage(IDS_ERR_DUSTSUCTION_DOWN);
				return FALSE;
			}

			bResult = MotionControlDLL_WriteOutputDWord(0x610BB, 0);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BC, 1);
		}
	}
	else
	{
		if(bUp)
		{
			bResult = MotionControlDLL_WriteOutputDWord(0x610BD, 1);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BE, 0);
		}
		else
		{
			if(m_NewStatus.m_nXActualPos < dMin * 1000.0 || 
				m_NewStatus.m_nXActualPos > dMax * 1000.0)
			{
				ErrMessage(IDS_ERR_DUSTSUCTION_DOWN);
				return FALSE;
			}
			
			bResult = MotionControlDLL_WriteOutputDWord(0x610BD, 0);
			bResult = bResult & MotionControlDLL_WriteOutputDWord(0x610BE, 1);
		}
	}
	return bResult;
}

BOOL DeviceUMacLarge::WriteLoadUnload(int nAdd, BOOL bOn)
{
	return 1;// MotionControlDLL_WriteOutputIOBit(6, nAdd, bOn);
}

double DeviceUMacLarge::GetMPosition(int nIndex)
{
	if(nIndex < 0 || nIndex > 9)
		return 0;
	
	return m_dMaskPosition[nIndex];
}

void DeviceUMacLarge::SetFixedMaskPos(double dPos)
{
	m_dFixedMaskPos = dPos;	
}

BOOL DeviceUMacLarge::MoveTophatShutter(BOOL bUp)
{
	return TRUE;
	
}

BOOL DeviceUMacLarge::MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	}
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_A1, dA1);
	bResult = bResult & DownloadPosition(AXIS_A2, dA2);
	
	return bResult;
}

BOOL DeviceUMacLarge::MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	if(!bTophat)	
	{
		bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition2[nMaskPos2]);
	}
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
			return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B7, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B8, 2));
	}
		return FALSE;
}

BOOL DeviceUMacLarge::MoveZMCA2(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	//	m_nMaskPos = nMaskPos;
	//	m_nMaskPos2 = nMaskPos2;
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	if(!bTophat)	
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	else
		bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B7, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B8, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bTophat)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dPosM);//m_dMaskPosition[nPosM]);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos); //dMaskPosition[10] = Fixed Pos
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dPosM);
//		bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);//m_dMaskPosition2[nPosM]);
	}
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	
	//2011520
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2); 
	
	if(bResult)
	{
			return (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
				MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) & //M2
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) & //C1
				MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B7, 2) &	//A1
				MotionControlDLL_WriteOutputDWord(0x610B8, 2)); //A2

	}
	return FALSE;	
}

BOOL DeviceUMacLarge::MotorMoveAMC2(double dPosA1, double dPosA2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, BOOL bTophat)	//2011517
{
	BOOL bResult = TRUE;
	m_nMaskPos = nMaskPos;
	m_nMaskPos2 = nMaskPos2;
	
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, m_dMaskPosition[nMaskPos]);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dMaskPosition2[nMaskPos2]);
	}
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
			return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B7, 2) &				
				MotionControlDLL_WriteOutputDWord(0x610B8, 2));
	}
	return FALSE;
}

BOOL DeviceUMacLarge::MotorMoveAMC2(double dPosA1, double dPosA2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat)	//2011517
{
	BOOL bResult = TRUE;
	m_nMaskPos = -1;
	
	if(!bTophat)
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, m_dFixedMaskPos);
	}
	else
	{
		bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
		bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);		
	}
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	if(bResult)
	{
			return (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
//				MotionControlDLL_WriteOutputDWord(0x610B4, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
				MotionControlDLL_WriteOutputDWord(0x610B7, 2) &				
				MotionControlDLL_WriteOutputDWord(0x610B8, 2));
	}
	return FALSE;
}
BOOL DeviceUMacLarge::ScannerPower(BOOL bOn)
{
	return MotionControlDLL_WriteOutputIOBit(0, 12, bOn);
}

BOOL DeviceUMacLarge::GetCurrentSuctionMotor()
{
	
	if(gSystemINI.m_sHardWare.bUseVacummmotor)
		return m_NewStatus.m_bRingBlowerRemoteRun;
	else
		return TRUE;
	

	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::SetLimitYPos(double dPos)
{
	return MotionControlDLL_WriteOutputDWord(0x610EF, (DWORD)(dPos * 1000));
}

BOOL DeviceUMacLarge::LoaderCarrierCartPos()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 2);
}

BOOL DeviceUMacLarge::LoaderCarrierCartPos2()
{
	return MotionControlDLL_WriteOutputDWord(0x610C1, 7);
}

BOOL DeviceUMacLarge::UnloaderCarrierAlignPos()
{
	return  MotionControlDLL_WriteOutputDWord(0x610D1, 5);
}

BOOL DeviceUMacLarge::SetAlarmTolLed(BOOL bOn)
{
	/*if(bOn)
		return MotionControlDLL_WriteOutputDWord(0x610AA, 1);
	else
		return MotionControlDLL_WriteOutputDWord(0x610AA, 2);
*/
	MotionControlDLL_WriteOutputIOBit(10, 10, bOn);
	return TRUE;
}

BOOL DeviceUMacLarge::GetScannerStatus()
{
	return m_NewStatus.m_bScannerPowerRemoteOnOff;
}

BOOL DeviceUMacLarge::GetResetSWStatus()
{
	return m_NewStatus.m_bResetSW;
}

BOOL DeviceUMacLarge::GetManualSWStatus()//20150511
{
	return m_NewStatus.m_bManualModeSwitch;
}

BOOL DeviceUMacLarge::GetAutoSWStatus()
{
	return m_NewStatus.m_bAutoModeSwitch;
}

BOOL DeviceUMacLarge::GetStartSWStatus()
{
	return m_NewStatus.m_bStartSwitch;
}

BOOL DeviceUMacLarge::GetStopSWStatus()
{
	return m_NewStatus.m_bStopSwitch;
}


BOOL DeviceUMacLarge::GetBeamPathStatus(BOOL bShortPath, BOOL bAom)
{
	return TRUE;
}
BOOL DeviceUMacLarge::GetTalbeMoveEnableFlag()
{
	return TRUE;
	//return m_NewStatus.m_bTalbeMoveEnableFlag;
}
BOOL DeviceUMacLarge::IsHoodOK(BOOL bOpen)
{
	if(bOpen)
	{
		if(m_NewStatus.m_bSuctionHoodShutterOpenSensor && !m_NewStatus.m_bSuctionHoodShutterCloseSensor)
			return TRUE;
	}
	else
	{
		if(!m_NewStatus.m_bSuctionHoodShutterOpenSensor && m_NewStatus.m_bSuctionHoodShutterCloseSensor)
			return TRUE;
	}
	

	return FALSE;
}

BOOL DeviceUMacLarge::HoodOpen(BOOL bOpen)
{
	BOOL bResult;
	
	if(bOpen)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(9, 10, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(9, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(9, 10, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(9, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::SetAOMPowerON(BOOL bOn)//20160509 AOM ��ȣ �ݴ��
{
	if(bOn)
		return MotionControlDLL_WriteOutputIOBit(1, 11, 0);
	else
		return MotionControlDLL_WriteOutputIOBit(1, 11, 1);
}

BOOL DeviceUMacLarge::GetAOMStatus()//20160509 AOM ��ȣ �ݴ��
{
	return TRUE;
	//return !m_NewStatus.m_bAOMPowerRemoteOnOff;
}

BOOL DeviceUMacLarge::GetAOMAlarm()
{
	return FALSE; // m_NewStatus.m_bAOMAlarm;
}

BOOL DeviceUMacLarge::SetOutportTableVacuum(BOOL bUseBTable)
{
	return MotionControlDLL_WriteOutputIOBit(0, 15, bUseBTable);
}

BOOL DeviceUMacLarge::GetTopHatStatus(BOOL bUp)
{
	/*
	if(bUp)
	{
		if(m_NewStatus.m_bTopHatForwordSensor && !m_NewStatus.m_bTopHatBackwordSensor)
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if(!m_NewStatus.m_bTopHatForwordSensor && m_NewStatus.m_bTopHatBackwordSensor)
			return TRUE;
		else
			return FALSE;
	}
	*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsHandlerPartError(BOOL bLoader)
{
	if(bLoader)
	{
		long nloadError = m_lErrorLoad & 0xFFFFFFFB;
		if(nloadError > 0 || m_lErrorLoad2 > 0 || m_lErrorLoad3 > 0)
			return TRUE;
	}
	else
	{
		if(m_lErrorUnload > 0 || m_lErrorUnload2 > 0 || m_lErrorUnload3 > 0)
			return TRUE;
	}
	
	return FALSE;
}

BOOL DeviceUMacLarge::IsBMMotorHomeEnd()
{

	if(!m_bConnect)
		return FALSE;

	if(Servo_IsOrigin(EZ_SERVO_M1) &&  Servo_IsOrigin(EZ_SERVO_M2) && Servo_IsOrigin(EZ_SERVO_C1) && Servo_IsOrigin(EZ_SERVO_C2) && Servo_IsOrigin(EZ_SERVO_C3) && Servo_IsOrigin(EZ_SERVO_C4))
		return TRUE;

	return FALSE;

	
	return 0; //20160418 IO

	return FALSE;
}

BOOL DeviceUMacLarge::NoUseClamp(BOOL bNoUse)
{
	return WriteOutputIOBIt(1, 14, bNoUse);
}

BOOL DeviceUMacLarge::MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL bTophat)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2); 
	
	if(bResult)
	{
		bResult =  (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
			MotionControlDLL_WriteOutputDWord(0x610B6, 2));

		if(!m_bConnect)
			return FALSE;

		Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);


		Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		Servo_ServoEnable(EZ_SERVO_C2, TRUE);


		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);


		
		return bResult;
	}
	return FALSE;	
}

BOOL DeviceUMacLarge::DoMoveTableClamp(BOOL b1stOn,BOOL b2ndOn)
{

	//if(gProcessINI.m_sProcessSystem.bNoUseTableClamp)
		//return TRUE;

	if(gSystemINI.m_sHardWare.nTableClamp == 0)
		return TRUE;

	BOOL bResult = TRUE;
	BOOL bOK1 = TRUE;
	BOOL bOK2 = TRUE;

	bOK1 = GetCurrentTableClamp(TRUE, b1stOn);

	bResult = bOK1;

	if(gSystemINI.m_sHardWare.nTableClamp == 2)
	{
		bOK2 = GetCurrentTableClamp(FALSE, b2ndOn);

		bResult = bOK1 && bOK2;
	}

	/*double dX = 0.0;
	double dY = 0.0;
	GetPosition(AXIS_X, dX);
	GetPosition(AXIS_Y, dY);

	if(!b1stOn || !b2ndOn)
	{
		if(abs( dX - gProcessINI.m_sProcessAutoSetting.dLoadPosX ) > 0.1)
	}*/

	if(bResult)
		return TRUE;



	MotionControlDLL_WriteOutputIOBit(9, 4, b1stOn); 
	MotionControlDLL_WriteOutputIOBit(9, 5, !b1stOn); 
	
	if(gSystemINI.m_sHardWare.nTableClamp == 2)
	{
		MotionControlDLL_WriteOutputIOBit(9, 6, b2ndOn); 
		MotionControlDLL_WriteOutputIOBit(9, 7, !b2ndOn);
	}


	
	bOK1 = TRUE;
	bOK2 = TRUE;


	int nCount = 0;

	while(TRUE)
	{
		MSG msg;

		if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
		{
			::TranslateMessage((LPMSG)&msg);
			::DispatchMessage((LPMSG )&msg);
		}

		bOK1 = GetCurrentTableClamp(TRUE, b1stOn);

		bResult = bOK1;

		if(gSystemINI.m_sHardWare.nTableClamp == 2)
		{
			bOK2 = GetCurrentTableClamp(FALSE, b2ndOn);

			bResult = bOK1 && bOK2;
		}

		if(bResult)
			break;

		if( nCount >= 50)
			break;
		Sleep(100);
		nCount++;
	}

	CString strMsg;

	if(!bOK1)
	{
		strMsg.Format("Head1 Table Clmap Error");
		ErrMsgDlg(STDGNALM530);
		return FALSE;
	}
	else if(!bOK2)
	{
		strMsg.Format("Head2 Table Clmap Error");
		ErrMsgDlg(STDGNALM531);
		return FALSE;
	}

	return TRUE;	
}

BOOL DeviceUMacLarge::MotorMoveXYZMC3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat , BOOL bTophat)
{

	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;


	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);
	bResult = bResult & DownloadPosition(AXIS_M3, dPosM3);
	//bResult = bResult & DownloadPosition(AXIS_M4, dPosM4);


	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2); 
#ifdef __PKG_MODIFY__
	bResult = bResult & DownloadPosition(AXIS_ROT, dPosRot);
#endif	
	bResult = bResult & DownloadPosition(AXIS_TOPHAT, dPosTopHat); 



	if(bResult)
	{
		bResult =  (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
			MotionControlDLL_WriteOutputDWord(0x610B6, 2));

		if(!m_bConnect)
			return FALSE;

		Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		Servo_ServoEnable(EZ_SERVO_M3, TRUE);
		//Servo_ServoEnable(EZ_SERVO_M4, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M3 , m_lWritePos[AXIS_M3], m_lSpeed[AXIS_M3]);
		//bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M4 , m_lWritePos[AXIS_M4], m_lSpeed[AXIS_M4]);

		Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
#ifdef __PKG_MODIFY__
		Servo_ServoEnable(EZ_SERVO_ROT, TRUE);
#endif
		Servo_ServoEnable(EZ_SERVO_TOPHAT, TRUE);
#ifdef __PKG_MODIFY__
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_ROT , m_lWritePos[AXIS_ROT], m_lSpeed[AXIS_ROT]);
#endif
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_TOPHAT , m_lWritePos[AXIS_TOPHAT], m_lSpeed[AXIS_TOPHAT]);

		return bResult;
	}
	return FALSE;	
}
BOOL DeviceUMacLarge::MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bTophat)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;


	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2); 
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2); 	
	if(bResult)
	{
		bResult =  (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B7, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B8, 2) );

		if(!m_bConnect)
			return FALSE;

		Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
		

		
		return bResult;
	}
	return FALSE;	
}
//20160329
BOOL DeviceUMacLarge::MotorMoveXYZMCA3_B(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2,double dPosM3, double dPosM4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bTophat)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X, dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y, dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2, dPosM2);
	//bResult = bResult & DownloadPosition(AXIS_M3, dPosM3);
	//bResult = bResult & DownloadPosition(AXIS_M4, dPosM4);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2); 
//#ifdef __PKG_MODIFY__
	//bResult = bResult & DownloadPosition(AXIS_ROT, dPosRot);
//#endif
	//bResult = bResult & DownloadPosition(AXIS_TOPHAT, dPosTopHat); 

	if(bResult)
	{
		bResult =  (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
			MotionControlDLL_WriteOutputDWord(0x610B6, 2));
#ifdef __SERVO_MOTOR__
		if(!m_bConnect)
			return FALSE;

		Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		//Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		//Servo_ServoEnable(EZ_SERVO_M3, TRUE);

		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
		//bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M3 , m_lWritePos[AXIS_M3], m_lSpeed[AXIS_M3]);
		//bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M4 , m_lWritePos[AXIS_M4], m_lSpeed[AXIS_M4]);


		Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);

//#ifdef __PKG_MODIFY__
//		Servo_ServoEnable(EZ_SERVO_ROT, TRUE);
//#endif
//		Servo_ServoEnable(EZ_SERVO_TOPHAT, TRUE);
//#ifdef __PKG_MODIFY__
//		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_ROT , m_lWritePos[AXIS_ROT], m_lSpeed[AXIS_ROT]);
//#endif
//		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_TOPHAT , m_lWritePos[AXIS_TOPHAT], m_lSpeed[AXIS_TOPHAT]);
#endif
		
		return bResult;
	}
	return FALSE;	
}

BOOL DeviceUMacLarge::MotorMoveXYZMB(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosC3, double dPosC4)
{
	if(!DoMoveTableClamp(TRUE,TRUE))//20160623
		return FALSE;

	BOOL bResult = TRUE;
	bResult = bResult & DownloadPosition(AXIS_X,	dPosX);
	bResult = bResult & DownloadPosition(AXIS_Y,	dPosY);
	bResult = bResult & DownloadPosition(AXIS_Z1,	dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2,	dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M,	dPosM);
	bResult = bResult & DownloadPosition(AXIS_M2,	dPosM2);
	bResult = bResult & DownloadPosition(AXIS_C,	dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2,	dPosC2); 
	bResult = bResult & DownloadPosition(AXIS_C3,	dPosC3);
	bResult = bResult & DownloadPosition(AXIS_C4,	dPosC4); 

	if(bResult)
	{
		bResult =  (MotionControlDLL_WriteOutputDWord(0x610B0, 5) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B4, 2) &  
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) & 
			MotionControlDLL_WriteOutputDWord(0x610B6, 2));
#ifdef __SERVO_MOTOR__
		if(!m_bConnect)
			return FALSE;

		Servo_ServoEnable(EZ_SERVO_M1, TRUE);
		Servo_ServoEnable(EZ_SERVO_M2, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2 , m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
		Servo_ServoEnable(EZ_SERVO_C1, TRUE);
		Servo_ServoEnable(EZ_SERVO_C2, TRUE);
		Servo_ServoEnable(EZ_SERVO_C3, TRUE);
		Servo_ServoEnable(EZ_SERVO_C4, TRUE);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , m_lWritePos[AXIS_C3], m_lSpeed[AXIS_C3]);
		bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , m_lWritePos[AXIS_C4], m_lSpeed[AXIS_C4]);

#endif

		return bResult;
	}
	return FALSE;	
}

BOOL DeviceUMacLarge::MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);

	if(bResult)
	{

		bResult = (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));

	}
#ifdef __SERVO_MOTOR__
	if(!m_bConnect)
		return FALSE;

	bResult = Servo_MoveSingleAxisAbsPos(0 , (int)(dMaskPos2 * m_dScale[AXIS_M2]), m_lSpeed[AXIS_M2]);

	bResult = Servo_MoveSingleAxisAbsPos(1, (int)(dMaskPos3 * m_dScale[AXIS_M3]), m_lSpeed[AXIS_M3]);

#endif

	return bResult;
}

BOOL DeviceUMacLarge::MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	
	if(bResult)
	{
		
		bResult = (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B7, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B8, 2) );
		
	}
#ifdef __SERVO_MOTOR__
	if(!m_bConnect)
		return FALSE;
	
	bResult = Servo_MoveSingleAxisAbsPos(0 , (int)(dMaskPos2 * m_dScale[AXIS_M2]), m_lSpeed[AXIS_M2]);
	
	bResult = Servo_MoveSingleAxisAbsPos(1, (int)(dMaskPos3 * m_dScale[AXIS_M3]), m_lSpeed[AXIS_M3]);
	
#endif
	
	return bResult;
}
BOOL DeviceUMacLarge::MoveZMC3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;


	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);
	//bResult = bResult & DownloadPosition(AXIS_M4, dMaskPos4);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
#ifdef __PKG_MODIFY__
	bResult = bResult & DownloadPosition(AXIS_ROT, dPosRot);
#endif
	bResult = bResult & DownloadPosition(AXIS_TOPHAT, dPosTopHat);
	if(bResult)
	{

		bResult = (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));

	}

	if(!m_bConnect)
		return FALSE;

	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2, m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M3 , m_lWritePos[AXIS_M3], m_lSpeed[AXIS_M3]);
	//bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M4, m_lWritePos[AXIS_M4], m_lSpeed[AXIS_M4]);

	Servo_ServoEnable(EZ_SERVO_C1, TRUE);
	Servo_ServoEnable(EZ_SERVO_C2, TRUE);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
#ifdef __PKG_MODIFY__
	Servo_ServoEnable(EZ_SERVO_ROT, TRUE);
#endif
	Servo_ServoEnable(EZ_SERVO_TOPHAT, TRUE);
#ifdef __PKG_MODIFY__
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_ROT , m_lWritePos[AXIS_ROT], m_lSpeed[AXIS_ROT]);
#endif
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_TOPHAT , m_lWritePos[AXIS_TOPHAT], m_lSpeed[AXIS_TOPHAT]);

	return bResult;
}

BOOL DeviceUMacLarge::MoveZMCA3_B(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2, double dPosRot, double dPosTopHat, BOOL bZCalUse, BOOL bTophat)
{
	BOOL bResult = TRUE;


	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	//bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);
	//bResult = bResult & DownloadPosition(AXIS_M4, dMaskPos4);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
//#ifdef __PKG_MODIFY__
//	bResult = bResult & DownloadPosition(AXIS_ROT, dPosRot);
//#endif
//	bResult = bResult & DownloadPosition(AXIS_TOPHAT, dPosTopHat);
	if(bResult)
	{

		bResult = (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));

	}

	if(!m_bConnect)
		return FALSE;

	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2, m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
	//bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M3 , m_lWritePos[AXIS_M3], m_lSpeed[AXIS_M3]);
	//bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M4, m_lWritePos[AXIS_M4], m_lSpeed[AXIS_M4]);

	Servo_ServoEnable(EZ_SERVO_C1, TRUE);
	Servo_ServoEnable(EZ_SERVO_C2, TRUE);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
//#ifdef __PKG_MODIFY__
//	Servo_ServoEnable(EZ_SERVO_ROT, TRUE);
//#endif
//	Servo_ServoEnable(EZ_SERVO_TOPHAT, TRUE);
//#ifdef __PKG_MODIFY__
//	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_ROT , m_lWritePos[AXIS_ROT], m_lSpeed[AXIS_ROT]);
//#endif
//	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_TOPHAT , m_lWritePos[AXIS_TOPHAT], m_lSpeed[AXIS_TOPHAT]);

	return bResult;
}


BOOL DeviceUMacLarge::MoveZMC4(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dPosC3, double dPosC4, BOOL bZCalUse)
{
	BOOL bResult = TRUE;


	bResult = bResult & DownloadPosition(AXIS_Z1, dPosZ1);
	bResult = bResult & DownloadPosition(AXIS_Z2, dPosZ2);	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_C3, dPosC3);
	bResult = bResult & DownloadPosition(AXIS_C4, dPosC4);

	if(bResult)
	{

		bResult = (MotionControlDLL_WriteOutputDWord(0x610B3, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B5, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B6, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B1, 2) &
			MotionControlDLL_WriteOutputDWord(0x610B2, 2));

	}

	if(!m_bConnect)
		return FALSE;

	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M1 , m_lWritePos[AXIS_M], m_lSpeed[AXIS_M]);
	bResult = Servo_MoveSingleAxisAbsPos(EZ_SERVO_M2, m_lWritePos[AXIS_M2], m_lSpeed[AXIS_M2]);
	Servo_ServoEnable(EZ_SERVO_C1, TRUE);
	Servo_ServoEnable(EZ_SERVO_C2, TRUE);
	Servo_ServoEnable(EZ_SERVO_C3, TRUE);
	Servo_ServoEnable(EZ_SERVO_C4, TRUE);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C1 , m_lWritePos[AXIS_C], m_lSpeed[AXIS_C]);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C2 , m_lWritePos[AXIS_C2], m_lSpeed[AXIS_C2]);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C3 , m_lWritePos[AXIS_C3], m_lSpeed[AXIS_C3]);
	bResult &= Servo_MoveSingleAxisAbsPos(EZ_SERVO_C4 , m_lWritePos[AXIS_C4], m_lSpeed[AXIS_C4]);


	return bResult;
}

BOOL DeviceUMacLarge::Disconnect()
{
	if(m_bConnect)
	{
		m_bConnect = FALSE;
		Servo_Disconnect();
	}
	return TRUE;
}

BOOL DeviceUMacLarge::Connect(int nPortNo, long lBaudrate)
{
	BOOL bRes = TRUE;
	m_nPort = nPortNo;
	DWORD nBRate = lBaudrate;
	if (!m_bConnect)
	{ 
		bRes = Servo_Connect(m_nPort, lBaudrate);
		if (!bRes)
		{
			ErrMessage(_T("connection failed."));
		}
		else
			m_bConnect = TRUE;
	}
	
	Servo_AlarmReset();

	BOOL b= Servo_ServoEnable(EZ_SERVO_M1, TRUE);
	b= b & Servo_ServoEnable(EZ_SERVO_M2, TRUE);
   // b= b & Servo_ServoEnable(EZ_SERVO_M3, TRUE);
	//b= b & Servo_ServoEnable(EZ_SERVO_M4, TRUE);

	
	b= b & Servo_ServoEnable(EZ_SERVO_C1, TRUE);
	b= b & Servo_ServoEnable(EZ_SERVO_C2, TRUE);
	b= b & Servo_ServoEnable(EZ_SERVO_C3, TRUE);
	b= b & Servo_ServoEnable(EZ_SERVO_C4, TRUE);


	return bRes;
}

BOOL DeviceUMacLarge::SetServoOnOff(int nAxis, BOOL bOn)
{
#ifdef __TEST__
	return TRUE;
#endif
	if (m_bConnect)
		return Servo_ServoEnable(nAxis, bOn);
	
	return FALSE;
}
BOOL DeviceUMacLarge::MotorMoveMC3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);
    ///bResult = bResult & DownloadPosition(AXIS_M4, dMaskPos4);
	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	return bResult;
}
BOOL DeviceUMacLarge::MotorMoveMC3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2)
{
	BOOL bResult = TRUE;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);	
	bResult = bResult & DownloadPosition(AXIS_M4, dMaskPos4);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);

	return bResult;
}
BOOL DeviceUMacLarge::MotorMoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2)
{
	BOOL bResult = TRUE;
	
	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_A1, dPosA1);
	bResult = bResult & DownloadPosition(AXIS_A2, dPosA2);
	return bResult;
}
BOOL DeviceUMacLarge::MotorMoveMCA3DownOnly_B(double dMaskPos, double dMaskPos2,double dMaskPos3, double dMaskPos4, double dPosC, double dPosC2,double dPosC3,double dPosC4)
{
	BOOL bResult = TRUE;

	bResult = bResult & DownloadPosition(AXIS_M, dMaskPos);	
	bResult = bResult & DownloadPosition(AXIS_M2, dMaskPos2);
	//bResult = bResult & DownloadPosition(AXIS_M3, dMaskPos3);	
	//bResult = bResult & DownloadPosition(AXIS_M4, dMaskPos4);

	bResult = bResult & DownloadPosition(AXIS_C, dPosC);
	bResult = bResult & DownloadPosition(AXIS_C2, dPosC2);
	bResult = bResult & DownloadPosition(AXIS_C3, dPosC3);
	bResult = bResult & DownloadPosition(AXIS_C4, dPosC4);

	return bResult;
}
BOOL DeviceUMacLarge::IsOrigin(int nAxis)
{
#ifdef __SERVO_MOTOR__
	if(!m_bConnect)
		return FALSE;

	return Servo_IsOrigin(nAxis);	
#endif
	return TRUE;
}
 
BOOL DeviceUMacLarge::SetPreTATS(int nAxis, long nTA, long nTS)
{
	if(nAxis == AXIS_X)
	{
		return MotionControlDLL_WriteOutputDWord(0x61120, nTA) &
			MotionControlDLL_WriteOutputDWord(0x61121, nTS);
	}
	else if(nAxis == AXIS_Y)
	{
		return MotionControlDLL_WriteOutputDWord(0x61124, nTA) &
			MotionControlDLL_WriteOutputDWord(0x61125, nTS);
	}
	else
		return TRUE;
}

BOOL DeviceUMacLarge::SetNextTATS(int nAxis, long nTA, long nTS)
{
	if(nAxis == AXIS_X)
	{
		return MotionControlDLL_WriteOutputDWord(0x61122, nTA) &
			MotionControlDLL_WriteOutputDWord(0x61123, nTS);
	}
	else if(nAxis == AXIS_Y)
	{
		return MotionControlDLL_WriteOutputDWord(0x61126, nTA) &
			MotionControlDLL_WriteOutputDWord(0x61127, nTS);
	}
	else
		return TRUE;
}

int DeviceUMacLarge::ChangeMotorPosition(double dXPos, double dYPos)
{
	int nCmdPosX, nCmdPosY;
	nCmdPosX = (int)(dXPos * m_dScale[AXIS_X]);
	nCmdPosY = (int)(dYPos * m_dScale[AXIS_Y]);

	if(abs(m_NewStatus.m_nXActualPos - nCmdPosX) > gSystemINI.m_sHardWare.nTableShootLimit) // 10um�̻� Ʋ����
		return 10000 + abs(m_NewStatus.m_nXActualPos - nCmdPosX);
	if(abs(m_NewStatus.m_nYActualPos - nCmdPosY) > gSystemINI.m_sHardWare.nTableShootLimit) // 10um�̻� Ʋ����
		return abs(m_NewStatus.m_nYActualPos - nCmdPosY);

	return FALSE;
}



int DeviceUMacLarge::GetLaser1FlowValue()
{
	return m_NewStatus.m_61036Space[0];
}
int DeviceUMacLarge::GetLaser2FlowValue()
{
	return m_NewStatus.m_61036Space[1];
}
int DeviceUMacLarge::GetMainAirValue()
{
	return m_NewStatus.m_61036Space[2];
}


int DeviceUMacLarge::GetUnLoaderMainPressureValue()
{
	return m_NewStatus.m_61036Space[3];
}
int DeviceUMacLarge::GetLoaderPicker1VacuumValue()
{
	return m_NewStatus.m_61036Space[4];
}
int DeviceUMacLarge::GetLoaderPicker2VacuumValue()
{
	return m_NewStatus.m_61036Space[5];
}
int DeviceUMacLarge::GetUnLoaderPicker1VacuumValue()
{
	return m_NewStatus.m_61036Space[6];
}

int DeviceUMacLarge::GetUnLoaderPicker2VacuumValue()
{
	return m_NewStatus.m_61036Space[7];
}
int DeviceUMacLarge::GetScannerBlockAirValue()
{
	return m_NewStatus.m_61036Space[8];
}


int DeviceUMacLarge::GetTableVauumValue(BOOL b1st,int nIndex)
{
	int nReturn = 0;
	if(b1st)
	{

		switch (nIndex)
		{
		case 0:
			nReturn = m_NewStatus.m_61030Space[0];
				break;
		case 1:
			nReturn = m_NewStatus.m_nMasterTableVacuumB;
			break;
		case 2:
			nReturn = m_NewStatus.m_nMasterTableVacuumC;
			break;
		}

	}
	else 
	{
		switch (nIndex)
		{
		case 0:
			nReturn = m_NewStatus.m_61030Space[1];
			break;
		case 1:
			nReturn = m_NewStatus.m_nSlaveTableVacuumB;
			break;
		case 2:
			nReturn = m_NewStatus.m_nSlaveTableVacuumC;
			break;
		}
	}
	
	return nReturn; 
}

int DeviceUMacLarge::GetDustSuctionValue()
{
	return m_NewStatus.m_61030Space[2];
}
int DeviceUMacLarge::GetLoaderMainPressureValue()
{
	return m_NewStatus.m_61030Space[3];
}

int DeviceUMacLarge::GetScannerFlow1Value()
{
	return m_NewStatus.m_61030Space[4];
}

int DeviceUMacLarge::GetScannerFlow2Value()
{
	return m_NewStatus.m_61030Space[5];
}
void DeviceUMacLarge::GetAllTableVauumValue(int &nMa,int &nMb,int &nMc,int &nSa,int &nSb,int &nSc)
{
	nMa = m_NewStatus.m_nMasterTableVacuumA; 
	nMb = m_NewStatus.m_nMasterTableVacuumB; 
	nMc = m_NewStatus.m_nMasterTableVacuumC; 

	nSa = m_NewStatus.m_nSlaveTableVacuumA; 
	nSb = m_NewStatus.m_nSlaveTableVacuumB; 
	nSc = m_NewStatus.m_nSlaveTableVacuumC; 
}

void DeviceUMacLarge::GetOutputStatus(int &Out1,int &Out2,int &Out3,int &Out4,int &Out5,int &Out6)
{
	Out1 = m_NewStatus.m_Output1_1;
	Out2 = m_NewStatus.m_Output1_2;
	Out3 = m_NewStatus.m_Output2_1;
	Out4 = m_NewStatus.m_Output2_2;
	Out5 = m_NewStatus.m_Output3_1;
	Out6 = m_NewStatus.m_Output3_2;
}	

void DeviceUMacLarge::GetInputStatus(int &In1,int &In2,int &In3,int &In4,int &In5,int &In6)
{
	In1 = m_NewStatus.m_Input1_1;
	In2 = m_NewStatus.m_Input1_2;
	In3 = m_NewStatus.m_Input2_1;
	In4 = m_NewStatus.m_Input2_2;
	In5 = m_NewStatus.m_Input3_1;
	In6 = m_NewStatus.m_Input3_2;
}	

BOOL DeviceUMacLarge::GetChillerRun()
{
	//return m_NewStatus.m_bChillerOnCheck;

		return 0;//20160418 IO
}
BOOL DeviceUMacLarge::SetWaterFlow1Value(double dVal)
{
	return  TRUE;//MotionControlDLL_WriteOutputDWord(0x61128, (DWORD)dVal);
}
BOOL DeviceUMacLarge::SetWaterFlow2Value(double dVal)
{
	return TRUE;//MotionControlDLL_WriteOutputDWord(0x61129, (DWORD)dVal);
}
BOOL DeviceUMacLarge::SetMainAirValue(double dVal)
{
	dVal = dVal * 6.0 + 156;
	return TRUE;//MotionControlDLL_WriteOutputDWord(0x6112A, (DWORD)dVal);
}
BOOL DeviceUMacLarge::SetDustSuctionValue(double dVal)
{
	return TRUE;//MotionControlDLL_WriteOutputDWord(0x6112B, (DWORD)dVal);
}
BOOL DeviceUMacLarge::SetTableVauumValue(BOOL b1st, double dVal)
{
	dVal = dVal * 6.0 + 156;
	if(b1st)
		return TRUE;//MotionControlDLL_WriteOutputDWord(0x6112C, (DWORD)dVal);
	else 
		return TRUE;//MotionControlDLL_WriteOutputDWord(0x6112D, (DWORD)dVal);
}
BOOL DeviceUMacLarge::SetReverseDirection(BOOL bChange)
{
	return MotionControlDLL_WriteOutputIOBit(6, 2, bChange);
}
BOOL DeviceUMacLarge::SetLoadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	BOOL bRes = TRUE;
	bRes &= MotionControlDLL_WriteOutputIOBit(4, 14, b1st);
	bRes &= MotionControlDLL_WriteOutputIOBit(4, 15, b2nd);
	return bRes;
}
BYTE DeviceUMacLarge::GetLoadPickerDownOK()
{
	return TRUE;
	//return ( m_NewStatus.m_bMelsecLoadPicker2Down << 1 & 0x02 ) + (m_NewStatus.m_bMelsecLoadPicker1Down & 0x01); 
}

BOOL DeviceUMacLarge::GetTableBUse()
{
	return  m_NewStatus.m_bUseVacBStatus;
}

BOOL DeviceUMacLarge::SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	BOOL bRes = TRUE;
	bRes &= MotionControlDLL_WriteOutputIOBit(5, 2, b1st);
	bRes &= MotionControlDLL_WriteOutputIOBit(5, 3, b2nd);
	return bRes;
}
BYTE DeviceUMacLarge::GetUnloadPickerDownOK()
{
	return TRUE;
	//return ( m_NewStatus.m_bMelsecUnloaderPicker2Down << 1 & 0x02 ) + (m_NewStatus.m_bMelsecUnloaderPicker1Down & 0x01); 
}
BOOL DeviceUMacLarge::SetTablePCBExist(BOOL b1st, BOOL b2nd)
{
	BOOL bRes = TRUE;
	//bRes &= MotionControlDLL_WriteOutputIOBit(9, 2, b1st);
	//bRes &= MotionControlDLL_WriteOutputIOBit(9, 3, b2nd);
	return bRes;
}
BOOL DeviceUMacLarge::GetReverseReady()
{
	return m_NewStatus.m_bLoaderAlignReady && m_NewStatus.m_bPCBUnloadReady;
}
BOOL DeviceUMacLarge::GetLPCStatus()
{
	//return m_NewStatus.m_bLPCOn;

	return TRUE; //20160418 IO
}
BOOL DeviceUMacLarge::SetNoUseLoadUnload(BOOL bNoUse)
{
	//return  MotionControlDLL_WriteOutputIOBit(1, 3, !bNoUse);
	return TRUE;
}



void DeviceUMacLarge::ReadAllError(int* pnVal)
{
	::MotionControlDLL_ReadMem(32, sizeof(int) * 16, pnVal);
}

BOOL DeviceUMacLarge::IsMainDoorOpen()
{
	if(!m_NewStatus.m_bFrontDoorSwitch || !m_NewStatus.m_bFrontLowerDoorClose)//lsc
		return TRUE;

	return FALSE;
}

BOOL DeviceUMacLarge::IsHandlerDoorOpen()
{
	//if(!m_NewStatus.m_bLoaderDoorCloseSignal || !m_NewStatus.m_bUnloaderDoorCloseSignal)// || !m_NewStatus.m_bLoaderUnloaderSideDoorClose )//20160610
	//	return TRUE;

	return FALSE;

}

BOOL DeviceUMacLarge::SetSuctionHoodAirBlowerSol(BOOL bOn)
{
	//return  MotionControlDLL_WriteOutputIOBit(9, 12, bOn);
	return TRUE;
}
BOOL DeviceUMacLarge::SetMaskSol(BOOL bOn)
{
	//return  MotionControlDLL_WriteOutputIOBit(9, 13, bOn);
	return TRUE;
}

BOOL DeviceUMacLarge::SetAutomaticLubricatorY1Remote(BOOL bOn)
{
	return TRUE;
}
BOOL DeviceUMacLarge::SetAutomaticLubricatorY2Remote(BOOL bOn)
{
	return TRUE;
}
BOOL DeviceUMacLarge::SetAutomaticLubricatorRemote(BOOL bOn)
{
	return  MotionControlDLL_WriteOutputIOBit(10, 1, bOn);
}

BOOL DeviceUMacLarge::SetLaserOn(BOOL bOn)
{
	return  MotionControlDLL_WriteOutputIOBit(1, 15, bOn);
}

BOOL DeviceUMacLarge::SetAOM1MirrorFWDSol(BOOL bOn)
{
	return TRUE;
}
BOOL DeviceUMacLarge::SetAOM1MirrorBWDSol(BOOL bOn)
{
	return TRUE;
}
BOOL DeviceUMacLarge::SetAOM2MirrorFWDSol(BOOL bOn)
{
	return TRUE;
}
BOOL DeviceUMacLarge::SetAOM2MirrorBWDSol(BOOL bOn)
{
	return TRUE;
}

BOOL DeviceUMacLarge::SetNoUseTableClamp(BOOL bNoUse)
{
	return  MotionControlDLL_WriteOutputIOBit(2, 8, bNoUse);
}

BOOL DeviceUMacLarge::SetLampOn(BOOL bOn)
{
	return  MotionControlDLL_WriteOutputIOBit(1, 6, bOn);
}

void DeviceUMacLarge::DownloadOpticAxisPosToPLC()
{
	if(!m_bConnect)
		return;
	
	long lCurrPos;
		long lErrorPos;



	Servo_GetActualPos(EZ_SERVO_M1, &lCurrPos);
	Servo_GetPosError(EZ_SERVO_M1, &lErrorPos);
	lCurrPos += lErrorPos;	
	MotionControlDLL_WriteOutputDWord(0x6112C, (DWORD)(lCurrPos*m_dScale[AXIS_M]));
	

	Servo_GetActualPos(EZ_SERVO_M2, &lCurrPos);
	Servo_GetPosError(EZ_SERVO_M2, &lErrorPos);
	lCurrPos += lErrorPos;	
	MotionControlDLL_WriteOutputDWord(0x6112D, (DWORD)(lCurrPos/m_dScale[AXIS_M2]));


	Servo_GetActualPos(EZ_SERVO_C1, &lCurrPos);
	MotionControlDLL_WriteOutputDWord(0x61128, (DWORD)lCurrPos/m_dScale[AXIS_C] * 1000);
	Servo_GetActualPos(EZ_SERVO_C2, &lCurrPos);
	MotionControlDLL_WriteOutputDWord(0x61129, (DWORD)lCurrPos/m_dScale[AXIS_C] * 1000);
	Servo_GetActualPos(EZ_SERVO_C3, &lCurrPos);
	MotionControlDLL_WriteOutputDWord(0x6112A, (DWORD)lCurrPos/m_dScale[AXIS_C] * 1000);
	Servo_GetActualPos(EZ_SERVO_C4, &lCurrPos);
	MotionControlDLL_WriteOutputDWord(0x6112B, (DWORD)lCurrPos/m_dScale[AXIS_C] * 1000);
}


void DeviceUMacLarge::JogMoveOpticAxis()//20160525
{
	if(!m_bConnect)
		return;



	if(m_NewStatus.m_nJogMoveFlag)
	{
		int nMoveAxisNo= 0;

		int nNo = m_NewStatus.m_nJogMoveOpticTargetAxis - 1;

		if(nNo <0 ||nNo >5 )
			return;

		int nJogTargetPos = GetTargetPos_Optic(nNo);

		if(!IsMoveOpticAxis(nNo,nMoveAxisNo,nJogTargetPos))
			return;

		TRACE("Test Axis:%d   Pos: %.3f \n",nMoveAxisNo,nJogTargetPos/1000.);
		MotorMoveAxis(nMoveAxisNo, nJogTargetPos/1000.);
	}
}

int DeviceUMacLarge::GetTargetPos_Optic(int nNo)//20160525
{
	int nPos = 0;
	switch(nNo)
	{
	case 0:
	case 1:
		nPos = m_NewStatus.m_nJogMoveOpticTargetPos_BET[nNo];
		break;
	case 2:
	case 3:
		nPos = m_NewStatus.m_nJogMoveOpticTargetPos_BET[nNo]*1000;
		break;
	case 4:
		nPos = m_NewStatus.m_nJogMoveOpticTargetPos_Mask[0];
		break;
	case 5:
		nPos = m_NewStatus.m_nJogMoveOpticTargetPos_Mask[1]/1000;
		break;
	}

	return nPos;
}

BOOL DeviceUMacLarge::IsMoveOpticAxis(int nNo,int &nMoveAxisNo,int nTargetPos_um)//20160525
{

	if(!m_bConnect)
		return FALSE;


	nMoveAxisNo = -1;


	
	long lCurrPos;
	Servo_GetActualPos(nNo, &lCurrPos);

	int nCurrentPos_um = (int)lCurrPos;

	

	switch(nNo)
	{
	case EZ_SERVO_C1:

		nMoveAxisNo = AXIS_C;
		break;
	case EZ_SERVO_C2:
		nMoveAxisNo = AXIS_C2;
		break;
	case EZ_SERVO_C3:
		nMoveAxisNo = AXIS_C3;
		break;
	case EZ_SERVO_C4:
		nMoveAxisNo = AXIS_C4;
		break;

	case EZ_SERVO_M1:
		nMoveAxisNo = AXIS_M;
		nCurrentPos_um *= 1000;
		break;
	case EZ_SERVO_M2:
		nMoveAxisNo = AXIS_M2;
		nCurrentPos_um *= 1000;	
		break;
	}

	double dPos =nTargetPos_um/1000.;

	if (!gDeviceFactory.GetMotor()->IsValidAxisPosition(nMoveAxisNo,dPos ))
		return FALSE;


	return TRUE;
}


BOOL DeviceUMacLarge::IsHavePLCError()//20160525
{

	if(!m_lErrorTable && !m_lErrorOthers && !m_lErrorOthers2 /*&& !m_lErrorOthers3*/ && !m_lErrorOthers4 && !m_lErrorOthers5 && !m_lErrorOthers6)
		return FALSE;

	return TRUE;
}
BOOL DeviceUMacLarge::IsRingblowerPower(int nMode)//20160602
{
	/*if(nMode == 2)
	return m_NewStatus.m_bRingBlowerVacuumPowerHigh;
	else if(nMode == 1)
	return m_NewStatus.m_bRingBlowerVacuumPowerMedium;
	else if(nMode == 0)
	return m_NewStatus.m_bRingBlowerVacuumPowerLow;*/
	
	return -1;
}
BOOL DeviceUMacLarge::IsRingblowerSolValve()//20160602
{
	return !m_NewStatus.m_bRingBlowerSolValveOn;
}

BOOL DeviceUMacLarge::SetNoUseChiller(BOOL bNoUse) //20160613
{
	return TRUE;
	//return  MotionControlDLL_WriteOutputIOBit(1, 7, bNoUse);
}

BOOL DeviceUMacLarge::IsMaskBlowerOn()
{

	if(m_NewStatus.m_bMaskBlowerSol)
		return TRUE;
	else
		return FALSE;


	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsOpticBlowerOn()
{
	/* //20170828 ��������
	if(m_NewStatus.m_bOpticBlowerSol)
		return TRUE;
	else
		return FALSE;
		*/
	
	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsAutomaticLubricatorRemoteOn()
{
	/*//20170828 ��������
	if(m_NewStatus.m_bAutomaticLubricatorRemote)
		return TRUE;
	else
		return FALSE;

	*/
	return 0; //20160418 IO
}

BOOL DeviceUMacLarge::IsAnalogLogRecodingStart() //20160829
{
	//if(m_NewStatus.m_bAnalogLogRecordStart )
		//return TRUE;

	return FALSE;
}

BOOL DeviceUMacLarge::GetCurrentSuctionOutput()
{

	BOOL bResult = FALSE;
	bResult = bResult || m_NewStatus.m_bTable1_1VacuumSuctionValveOnOff;
	bResult = bResult || m_NewStatus.m_bTable1_2VacuumSuctionValveOnOff;
	bResult = bResult || m_NewStatus.m_bTable2_1VacuumSuctionValveOnOff;
	bResult = bResult || m_NewStatus.m_bTable2_2VacuumSuctionValveOnOff;

	return bResult;
}

BOOL DeviceUMacLarge::IsServoConnect()
{
#ifdef __TEST__
	return TRUE;
#endif
	BOOL bRet = FALSE;

#ifdef __SERVO_MOTOR__
		return m_bConnect;
#endif
	return TRUE;
}



BOOL DeviceUMacLarge::AOMNABeamPassUpDown(BOOL bUp)
{
	BOOL bResult;
	
	if(bUp)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 2, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 3, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 2, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 3, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::AOMNABeamPassUpDown2(BOOL bUp)
{
	BOOL bResult;
	
	if(bUp)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 4, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 5, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 4, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 5, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::AOMUseBeamPassUpDown(BOOL bUp)
{
	BOOL bResult;
	
	if(bUp)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 7, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 6, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 7, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::AOMUseBeamPassUpDown2(BOOL bUp)
{
	BOOL bResult;
	
	if(bUp)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 9, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 8, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 9, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::AOMUseBeamPassUpDown3(BOOL bUp)
{
	BOOL bResult;
	
	if(bUp)
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 1);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 11, 0);
		return bResult;
	}
	else
	{
		bResult = MotionControlDLL_WriteOutputIOBit(6, 10, 0);
		if(bResult ) bResult = MotionControlDLL_WriteOutputIOBit(6, 11, 1);
		return bResult;
	}
}

BOOL DeviceUMacLarge::GetAOMNABeamPassUpDown(BOOL b1st)
{
	/*if(b1st)
	return m_NewStatus.m_bAOM_NA_BeamPass1CylFw;
	else
	return m_NewStatus.m_bAOM_NA_BeamPass1CylBw;*/
	return TRUE;



}

BOOL DeviceUMacLarge::GetAOMNABeamPassUpDown2(BOOL b1st)
{
	/*if(b1st)
		return m_NewStatus.m_bAOM_NA_BeamPass2CylFw;
	else
		return m_NewStatus.m_bAOM_NA_BeamPass2CylBw;*/
	return TRUE;
}

BOOL DeviceUMacLarge::GetAOMUseBeamPassUpDown(BOOL b1st)
{
	/*if(b1st)
		return m_NewStatus.m_bAOM_Use_BeamPass1CylUp;
	else
		return m_NewStatus.m_bAOM_Use_BeamPass1CylDown;*/
	return TRUE;
}

BOOL DeviceUMacLarge::GetAOMUseBeamPassUpDown2(BOOL b1st)
{
	/*if(b1st)
	return m_NewStatus.m_bAOM_Use_BeamPass2CylFw;
	else
	return m_NewStatus.m_bAOM_Use_BeamPass2CylBw;*/
	return TRUE;
}

BOOL DeviceUMacLarge::GetAOMUseBeamPassUpDown3(BOOL b1st)
{
	/*if(b1st)
	return m_NewStatus.m_bAOM_Use_BeamPass3CylFw;
	else
	return m_NewStatus.m_bAOM_Use_BeamPass3CylBw;*/
	return TRUE;
}

BOOL DeviceUMacLarge::IsInitialSWOn() 
{
	return m_NewStatus.m_bInitalizeSwitch;
}

BOOL DeviceUMacLarge::IsServo_Enable(int nAxis) 
{
	if(nAxis == AXIS_M)
		return m_bOldM1;
	else if(nAxis == AXIS_M2)
		return m_bOldM2;
	else if(nAxis == AXIS_M3) 
		return m_bOldM3; 

	else if(nAxis == AXIS_C) 
		return m_bOldBet1;
	else if(nAxis == AXIS_C2) 
		return m_bOldBet2;
	else if(nAxis == AXIS_C3) 
		return m_bOldBet3;
	else if(nAxis == AXIS_C4) 
		return m_bOldBet4;
	else if(nAxis == AXIS_TOPHAT) 
		return m_bOldTopHat; 

	return TRUE;
}