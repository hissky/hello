#if !defined(AFX_DEVTEMPERCOMPEN_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
#define AFX_DEVTEMPERCOMPEN_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "asynccomm.h"
class CDevTemperCompen :	public CAsyncComm
{
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;

public:
	BOOL SystemStart();
	BOOL SystemStop();
	BOOL StartTrigger();
	void ReadAddress();

	void SetTemperLimit(double dDiff, double dMin, double dMax, double dDelta);
	void SetChannelIndex(int nMTC1, int nMTC2, int nMSB1, int nMSB2, int nSTC1, int nSTC2, int nSSB1, int nSSB2);
	void FireReceived(void);
	virtual void ProcessMonitor(void);
	void ReadTemperature();
	double GetTemperature(int nMainIndex);
	BOOL GetTemperature(double* pdTempVal);
	virtual void Destroy(void);
	virtual BOOL Create(void);
	CDevTemperCompen();
	virtual	~CDevTemperCompen();

    CAssEvent FReceiveEvent;

	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);

	int m_nPortNo;
	int m_nBaudRate;
	int m_nParity;
	int m_nDataBits;
	int m_nStopBits;
	int m_nFlowControl;

	int			m_nTCMasterCH1;
	int			m_nTCMasterCH2;
	int			m_nTCSlaveCH1;
	int			m_nTCSlaveCH2;
	int			m_nSBMasterCH1;
	int			m_nSBMasterCH2;
	int			m_nSBSlaveCH1;
	int			m_nSBSlaveCH2;
	double m_dTemperature[10];
	double m_dOldTemperature[5][10];
	int m_nBackupCount;
	double m_dTemperDiff;
	double m_dTemperMinLimit;
	double m_dTemperMaxLimit;
	double m_dTemperDeltaTLimit;
	time_t  m_TemperatureSaveTime[10];
	char m_cAddress[10];
};
#endif // !defined(AFX_DEVTEMPERCOMPEN_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)

