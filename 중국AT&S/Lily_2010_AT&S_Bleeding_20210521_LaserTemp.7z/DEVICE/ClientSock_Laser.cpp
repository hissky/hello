// ClientSock_Laser.cpp : implementation file
//

#include "stdafx.h"
#include "ClientSock_Laser.h"
#include "..\EasyDriller.h"
#include "..\Model\Glyph.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"
#include "..\model\GlobalVariable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	RECEIVE_STATUS_INIT				0
#define RECEIVED_MASTER_DX_DATA			1
#define RECEIVED_MASTER_DY_DATA			2
#define RECEIVED_MASTER_THETA_DATA		3


#define MAX_SIZE 10000
#define CMD_INDEX 1
#define STATUS_INDEX 8
#define TEMP_INDEX 12
#define TEMP_INDEX2 13
/////////////////////////////////////////////////////////////////////////////
// CClientSock_Laser

CClientSock_Laser::CClientSock_Laser()
{
	m_bConnect = FALSE;
	m_hWnd = NULL;
	m_strLaserStatus = "";
	m_nReceiveCount = 0;
	m_nLaserNo = 0;
}

CClientSock_Laser::~CClientSock_Laser()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSock_Laser, CAsyncSocket)
	//{{AFX_MSG_MAP(CClientSock_Laser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSock_Laser member functions
void CClientSock_Laser::SetWnd(HWND hWnd)
{
	m_hWnd = hWnd;
}

void CClientSock_Laser::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CONNECT, 1, nErrorCode);
	
	if(nErrorCode == 0)
		m_bConnect = TRUE;
	else
		m_bConnect = FALSE;

	CAsyncSocket::OnConnect(nErrorCode);
}

void CClientSock_Laser::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_RECEIVE, 2, nErrorCode);
	ReceiveData();
	m_nReceiveCount++;
	if(m_nReceiveCount == 3600)
		m_nReceiveCount = 0;
	CAsyncSocket::OnReceive(nErrorCode);
}

void CClientSock_Laser::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CLOSE, 3, nErrorCode);

	m_bConnect = FALSE;
	m_nReceiveCount = 0;
	CAsyncSocket::OnClose(nErrorCode);
}

BOOL CClientSock_Laser::Connect(LPCTSTR lpszHostAddress, UINT nHostPort)
{
	BOOL bResult = CAsyncSocket::Connect(lpszHostAddress, nHostPort);
	
	if(bResult == FALSE)
	{
		int nErrorCode = CAsyncSocket::GetLastError();
		
		switch(nErrorCode)
		{
		case WSANOTINITIALISED:
		case WSAENETDOWN:
		case WSAEADDRINUSE:
		case WSAEINPROGRESS:
		case WSAEAFNOSUPPORT:
		case WSAECONNREFUSED:
		case WSAEDESTADDRREQ:
		case WSAEFAULT:
		case WSAEINVAL:
		case WSAEISCONN:
		case WSAEMFILE:
		case WSAENOBUFS:
		case WSAENOTSOCK:
		case WSAETIMEDOUT:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
			break;
		case WSAEWOULDBLOCK:
			// If an error code is WSAWOULDBLOCK, and your application
			// is using the override callbacks,
			// your application will receive an OnConnect message
			// when the connect operation is complete. -> refer to MSDN.
			TRACE(_T("Connection Success.\n"));
		//	m_bConnect = TRUE;
			return TRUE;
		default:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
		}
		return FALSE;
	}
	
	TRACE(_T("Connection Success.\n"));
	

	return (TRUE);
}
#define MAX_TOTAL_SIZE 2000
int CClientSock_Laser::ReceiveData()
{
	char sTemp[MAX_TOTAL_SIZE] = {0,};
	Receive(sTemp, MAX_TOTAL_SIZE);

	//if((strcmp(sTemp, "") != 0))
	//	return RETURN_FAIL_;

	CString strTemp;
	strTemp.Format("%s",sTemp);

	if(strTemp == "")
		return RETURN_FAIL_;


	CString strResult = PasingResult(strTemp,TEMP_INDEX);
	CString strResult2 = PasingResult(strTemp,TEMP_INDEX2);
	int nStatus = PasingStatusResult(strTemp,STATUS_INDEX);

	if(strResult != "CMD_DIFFERNT")
	   m_strLaserStatus = strResult;
	if(strResult2 != "CMD_DIFFERNT")
		m_strLaserStatus2 = strResult2;

	if(nStatus != -1)
		m_nLaserStatus = nStatus;

	return TRUE;
}

void CClientSock_Laser::SendNAK()
{


}

void CClientSock_Laser::SendACK()
{

}

void CClientSock_Laser::ReConnectTry()
{
	unsigned int unClientPort = 0;
	char sClientIPAddr[16] = {0,};
	CString str, str2;
	if(m_nLaserNo == 0)
	{
		str = ::AfxGetApp()->GetProfileString(_T("Settings"), _T("Address2"), _T("169.254.12.13"));
		unClientPort = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("Port2"), 5000);
	}
	else
	{
		str = ::AfxGetApp()->GetProfileString(_T("Settings"), _T("Address3"), _T("169.254.12.15"));
		unClientPort = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("Port3"), 5000);
	}
	strncpy_s(sClientIPAddr, 16, str, 15);
	
	Close();

	SetWnd(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_hWnd);
	Create();
	if(FALSE == Connect(sClientIPAddr, unClientPort))
	{
		m_bConnect = FALSE;
		//		ErrMessage(_T("���� ����"));
		//		return;
	}	
	else
		m_bConnect = TRUE;
}
void CClientSock_Laser::CloseSocket()
{
	Close();
	m_bConnect = FALSE;
}


//#define TEMP_INDEX 12//085

CString CClientSock_Laser::PasingResult(CString strReceive, int nIndex)
{
	char sADSData[MAX_SIZE];
	memset(sADSData, 0 , MAX_SIZE);
	strcpy(sADSData, strReceive);
	char *pToken;
	CString strData,strTemp;

	pToken = strtok(sADSData, "|");

	int nFindCount = 1;

	while ( pToken != NULL )
	{
		strData = pToken;

		if(nFindCount == CMD_INDEX)
		{
			if(strData != "064") //Cmd Check
				return "CMD_DIFFERNT";

		//	if(strData != "085") //085
		}
		else if(nFindCount == nIndex)
		{
			strTemp.Format("%d",atoi(strData));
			return strTemp;
		}

		nFindCount++;
		pToken = strtok(NULL, "|");
	}

	if(nFindCount < 8)
		return "CMD_DIFFERNT";

	return "READ_Fail";
}

int CClientSock_Laser::PasingStatusResult(CString strReceive, int nIndex)
{
	char sADSData[MAX_SIZE];
	memset(sADSData, 0 , MAX_SIZE);
	strcpy(sADSData, strReceive);
	char *pToken;
	int	nStatus;
	CString strData,strTemp;

	pToken = strtok(sADSData, "|");

	int nFindCount = 1;

	while ( pToken != NULL )
	{
		strData = pToken;

		if(nFindCount == CMD_INDEX)
		{
			if(strData != "085") //Cmd Check
				return -1;
		}
		else if(nFindCount == nIndex)
		{
			nStatus= atoi(strData);
			return nStatus;
		}

		nFindCount++;
		pToken = strtok(NULL, "|");
	}

	if(nFindCount < 8)
		return -1;

	return -1;
}

CString CClientSock_Laser::GetLaserTCPTemp(int nTempIndex)
{
	if(nTempIndex == 0)
		return m_strLaserStatus;
	else
		return m_strLaserStatus2;
}

int CClientSock_Laser::GetLaserTCPStatus()
{
	return m_nLaserStatus;
}