// DBlock.cpp: implementation of the DBlock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DBlock.h"
#include "math.h"
#include "sysdef.h"
#include "DOriginLineSort.h"
#include "dprocessini.h"
#include "TSP.h"

struct ORIHOLE_SORT_DATA {
	LPHOLEDATA	pHole;
	BOOL		bUsed;
	int			nSortIndex;
};
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DBlock::DBlock()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
}

DBlock::~DBlock()
{
	ReMoveAllHoleData();
	ReMoveAllLineData();
}

BOOL DBlock::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			// ver 10002
			POSITION pos;
			ar << "Name = " << m_nBlockName << "\n";
			ar << "MinX = " << m_nMinX << "\n";
			ar << "MinY = " << m_nMinY << "\n";
			ar << "MaxX = " << m_nMaxX << "\n";
			ar << "MaxY = " << m_nMaxY << "\n";
			// ver 10002 end
			ar << "HoleNo = " << m_HoleData.GetCount() << "\n";
			LPHOLEDATA pOriHole;
			pos = m_HoleData.GetHeadPosition();
			while (pos) 
			{
				pOriHole = m_HoleData.GetNext(pos);
				ar << "= " << pOriHole->nToolNo << "\n";
				ar << "= " << pOriHole->npPos.x << "\n";
				ar << "= " << pOriHole->npPos.y << "\n";
			}
			

		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DBlock::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	HOLEDATA HoleData;

	CString str;
	int nCount = 0, nTemp = 0;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> m_nBlockName;
			ar >> m_nMinX; 
			ar >> m_nMinY;
			ar >> m_nMaxX;
			ar >> m_nMaxY;

			ar >> nCount;
			for(int i = 0; i < nCount; i++)
			{
				ar >> HoleData.nToolNo;
				ar >> HoleData.npPos.x;
				ar >> HoleData.npPos.y;
				m_HoleData.AddTail(HoleData);
			}
			

		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DBlock::SaveFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			// ver 10002
			ar << "MinX = " << m_nMinX << "\n";
			ar << "MinY = " << m_nMinY << "\n";
			ar << "MaxX = " << m_nMaxX << "\n";
			ar << "MaxY = " << m_nMaxY << "\n";
			// ver 10002 end
			
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DBlock::LoadFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			// ver 10002
			if(nVersion < 10002)
			{

			}
			else
			{
				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}
			// ver 10002 end
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

double DBlock::CalAngle(CDPoint InPo1, CDPoint InPo2)
{
	double angle = atan2( InPo2.y - InPo1.y, InPo2.x - InPo1.x);
	if(isEqual(angle,0.0)) angle=0;//yd 05/24
	if(angle < 0 ) angle += 2.0 * M_PI;
	return ( angle );
}

double DBlock::GetDistance(CDPoint a, CDPoint b)
{
	return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}

bool DBlock::isEqual(double x, double y)
{
	if(fabs(x-y)< 0.001) return true;  // CALCULATION_RESOLUTION = 0.001
	else return false;
}

CDPoint DBlock::Bulge2Arc(CPoint ptStart, CPoint ptEnd, double bulge, double& dRadius)
{
	CDPoint pt1, pt2;
	pt1.x = ptStart.x; pt1.y = ptStart.y;
	pt2.x = ptEnd.x; pt2.y = ptEnd.y;
	double angle;
	CDPoint cen;
	double starta = 0.;
	double enda = 0.;
	angle = CalAngle(pt1, pt2);
	double length = GetDistance(pt1, pt2);
	double a = length / 2.;
	double H = bulge*length/2.;
	double r = (a*a + H*H)/2./H;
	double l =0.;  // the distance to center
	double angler = 0.;  // the angle of center
	
	if(bulge > 0)   //  CCW
	{
		l = r - H;
		angler = angle + M_PI/2.;
		cen.x = pt1.x + a*cos(angle) + l*cos(angler);
		cen.y = pt1.y + a*sin(angle) + l*sin(angler);
	}
	else // Clock-wise
	{
		r = -r;
		H = -H;
		l = r - H;
		angler = angle - M_PI/2.;
		cen.x = pt1.x + a*cos(angle) + l*cos(angler);
		cen.y = pt1.y + a*sin(angle) + l*sin(angler);
	}
	dRadius = r;
	return cen;
}

BOOL DBlock::IsSelect(CPoint point, int nTolerence, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point.x) return FALSE;
	if(m_nMinX > point.x) return FALSE;
	if(m_nMaxY < point.y) return FALSE;
	if(m_nMinY > point.y) return FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		if (point.x < pHole->npPos.x - nTolerence ||
			point.x > pHole->npPos.x + nTolerence ||
			point.y < pHole->npPos.y - nTolerence ||
			point.y > pHole->npPos.y + nTolerence)
			continue;
		else
		{
			return TRUE;
		}
	}
	
	int a = 0, b = 0, c = 0;
	double dRadius = 0, dDistance = 0;
	CDPoint ptdCenterPos, ptdPickPos;
	ptdPickPos.x = (double)point.x;
	ptdPickPos.y = (double)point.y;


	return FALSE;
}

BOOL DBlock::IsSelect(CPoint point1, CPoint point2, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;
	
	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;

	BOOL bIn = FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;

		bIn = TRUE;
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y)
		{
			return FALSE;
		}
	}
	

	if(bIn)
		return TRUE;
	else
		return FALSE;
}

CPoint DBlock::BlockFirstPositionToZero()
{
	CPoint ptStart;
	ptStart.x = ptStart.y = 0;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	BOOL bFirst = TRUE;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		if(bFirst)
		{
			ptStart = pHole->npPos;
			bFirst = FALSE;
		}
		pHole->npPos -= ptStart;
	}
	

	m_nMinX -= ptStart.x;
	m_nMaxX -= ptStart.x;
	m_nMinY -= ptStart.y;
	m_nMaxY -= ptStart.y;
	return ptStart;
}

void DBlock::SortOriginBlockHole()
{
	HoleDataList tempHoleList;
	int nCount = m_HoleData.GetCount();
	TSP sortTSP; 

	if(nCount < 4) // 4�� ���ϸ�
		return;

	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		tempHoleList.AddTail(*pHole);
	}

	ORIHOLE_SORT_DATA* pOriHoleInfoList = NULL;

	int i, nSortIndex;
	pOriHoleInfoList = new ORIHOLE_SORT_DATA[nCount];
	memset(pOriHoleInfoList, NULL, sizeof(ORIHOLE_SORT_DATA) * nCount);

	i = 0;
	
	pos = tempHoleList.GetHeadPosition();
	while (pos) 
	{
		pHole = tempHoleList.GetNext(pos);
		pOriHoleInfoList[i].pHole = pHole;
		pOriHoleInfoList[i].bUsed = FALSE;
		pOriHoleInfoList[i].nSortIndex = i;
		i++;
	}

	int nIndex = 0;

	sortTSP.SetRunParam(TRUE, 7, 2 | 128 | 1024, 1, 1.0, 1.0, FALSE, gProcessINI.m_sProcessSystem.nHoleDistancePitch);
	sortTSP.ResetSortData();
	sortTSP.SetSortCount(nCount);

	for(int i = 0; i < nCount; i++)
		sortTSP.AddHole(pOriHoleInfoList[i].pHole->npPos.x, pOriHoleInfoList[i].pHole->npPos.y); 

	if(sortTSP.RunTSP()) // fail
	{
		if(pOriHoleInfoList)
		{
			delete [] pOriHoleInfoList;
			pOriHoleInfoList = NULL;
		}
		return;
	}

	for(int j = 0; j < nCount; j++)
	{
		nSortIndex = sortTSP.m_pSortHoles[j].nIndex;
		pOriHoleInfoList[nSortIndex].bUsed = TRUE;
		pOriHoleInfoList[j].nSortIndex = nSortIndex;
	}
		
	BOOL bIsValid = TRUE;
	for(int j = 0; j < nCount; j++)
	{
		if(pOriHoleInfoList[j].bUsed == FALSE)
		{
			bIsValid = FALSE;
			break;
		}
	}
	//check valid sort end : bIsValid
	if(bIsValid)
	{
		m_HoleData.RemoveAll(); 
		int nAddCount = 0;
		for(int k = 0; k < nCount; k++)
		{
			m_HoleData.AddTail(*pOriHoleInfoList[pOriHoleInfoList[k].nSortIndex].pHole);
		}
	}
	
	if(pOriHoleInfoList)
	{
		delete [] pOriHoleInfoList;
		pOriHoleInfoList = NULL;
	}
}

void DBlock::Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	if(bX)
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.x = nMaxX + nMinX - pHole->npPos.x;
		}
	}
	else
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.y = nMaxY + nMinY - pHole->npPos.y;
		}
	}
	

}

void DBlock::Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY)
{
	CPoint nCenterP;
	int nX;
	double cosTheta, sinTheta;
	
	nCenterP.x = (nMaxX + nMinX) / 2;
	nCenterP.y = (nMaxY + nMinY) / 2;
	
	nMinX		= INT_MAX;
	nMinY		= INT_MAX;
	nMaxX		= INT_MIN;
	nMaxY		= INT_MIN;
	
	dDeg = dDeg * M_PI / 180; // deg to rad
	cosTheta = cos(dDeg);
	sinTheta = sin(dDeg);
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		nX = (int)(cosTheta*(pHole->npPos.x - nCenterP.x) - sinTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.x);
		pHole->npPos.y = (int)(sinTheta*(pHole->npPos.x - nCenterP.x) + cosTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.y);
		pHole->npPos.x = nX;
		
		if(nMaxX < pHole->npPos.x) nMaxX = pHole->npPos.x;
		if(nMinX > pHole->npPos.x) nMinX = pHole->npPos.x;
		if(nMaxY < pHole->npPos.y) nMaxY = pHole->npPos.y;
		if(nMinY > pHole->npPos.y) nMinY = pHole->npPos.y;
	}
	

}

void DBlock::ReMoveAllLineData()
{

}

void DBlock::ReMoveAllHoleData()
{
	/*
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		delete pData;
	}
	*/
	m_HoleData.RemoveAll();
}

BOOL DBlock::IsDotData(int nTool)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->nToolNo == nTool)
			return TRUE;
	}
	return FALSE;
}

BOOL DBlock::IsLineData(int nTool)
{

	return FALSE;
}

void DBlock::Copy(DBlock *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData = NULL, pCopydata = NULL;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		m_HoleData.AddTail(*pData);
	}
	


	m_nBlockName = pUnit->m_nBlockName;
	m_nMinX = pUnit->m_nMinX;
	m_nMaxX = pUnit->m_nMaxX;
	m_nMinY = pUnit->m_nMinY;
	m_nMaxY = pUnit->m_nMaxY;
}

void DBlock::Move(int nX, int nY)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		pData->npPos.x += nX;
		pData->npPos.y += nY;
	}
	

	
	m_nMinX += nX;
	m_nMaxX += nX;
	m_nMinY += nY;
	m_nMaxY += nY;
}

void DBlock::Copy(DBlock *pUnit, int nOffsetX, int nOffsetY)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	HOLEDATA Copydata;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);

		Copydata.npPos.x = pData->npPos.x + nOffsetX;
		Copydata.npPos.y = pData->npPos.y + nOffsetY;
		Copydata.nToolNo = pData->nToolNo;
		m_HoleData.AddTail(Copydata);
	}
	

	
// �߰� �ؾ���. --> ��� �������� �����	
	m_nMinX = pUnit->m_nMinX + nOffsetX;
	m_nMaxX = pUnit->m_nMaxX + nOffsetX;
	m_nMinY = pUnit->m_nMinY + nOffsetY;
	m_nMaxY = pUnit->m_nMaxY + nOffsetY;
}

void DBlock::Merge(DBlock *pUnit)
{
	return;// no use
}

void DBlock::DelInRect(CPoint point1, CPoint point2, BOOL bReverse)
{
	LPHOLEDATA pHole;
	POSITION posBefore, pos = m_HoleData.GetHeadPosition();
	posBefore = pos;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y) // outer hole
		{
			if(bReverse)
			{
				delete pHole;
				m_HoleData.RemoveAt(posBefore);
			}
		}
		else
		{
			if(!bReverse)
			{
				delete pHole;
				m_HoleData.RemoveAt(posBefore);
			}
		}
		posBefore = pos;
	}
	

}

BOOL DBlock::IsAnyData()
{

		return FALSE;
}

void DBlock::ReCalRect()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	int nCount = 0;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(m_nMaxX < pHole->npPos.x) m_nMaxX = pHole->npPos.x;
		if(m_nMinX > pHole->npPos.x) m_nMinX = pHole->npPos.x;
		if(m_nMaxY < pHole->npPos.y) m_nMaxY = pHole->npPos.y;
		if(m_nMinY > pHole->npPos.y) m_nMinY = pHole->npPos.y;
		nCount++;
	}
	

}




#define SIZE_OF_MAX_UNIT	100 // 100mm
#define SIZE_OF_MIN_DIVIDE		1000 // 1000um
#define PATTERN_DIFF_VAL 3
BOOL DBlock::GetSameBlockIndex(DBlock* pBlock, double& dDistX, double& dDistY)
{
	if(pBlock->m_HoleData.GetCount() != m_HoleData.GetCount())
		return FALSE;

	PATTERN_HOLE_LIST* pPatternHoleList;
	pPatternHoleList = new PATTERN_HOLE_LIST[SIZE_OF_MAX_UNIT * SIZE_OF_MAX_UNIT];


	int nDistanceX = pBlock->m_nMinX - m_nMinX;
	int nDistanceY = pBlock->m_nMinY - m_nMinY;

	dDistX = pBlock->m_nMinX - m_nMinX;
	dDistY = pBlock->m_nMinY - m_nMinY;

	int nX, nY, nXIndex, nYIndex;

	BOOL bResult = TRUE;
	LPHOLEDATA pHole;
	LPHOLEDATA pHole1stData;
	POSITION pos = m_HoleData.GetHeadPosition();
	int nOriginTool = -1;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		nOriginTool = pHole->nToolNo;
		nX = (pHole->npPos.x - m_nMinX)/SIZE_OF_MIN_DIVIDE; 
		nY = (pHole->npPos.y - m_nMinY)/SIZE_OF_MIN_DIVIDE; 
		pPatternHoleList[nX*SIZE_OF_MAX_UNIT+nY].AddTail(pHole);
	}

	BOOL bFound;	
	POSITION pos1stHole;
	pos = pBlock->m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole =  pBlock->m_HoleData.GetNext(pos);
		if(pHole->nToolNo != nOriginTool)
			return FALSE;
		nX = (pHole->npPos.x - pBlock->m_nMinX)/SIZE_OF_MIN_DIVIDE; 
		nY = (pHole->npPos.y - pBlock->m_nMinY)/SIZE_OF_MIN_DIVIDE; 

		// �ʱ�ȭ
		bFound = FALSE;

		for(int i = nX - 1; i <= nX + 1; i++)
		{
			nXIndex = i;
			if(i == nX - 1) nXIndex  = nX;
			if(i == nX) nXIndex  = nX - 1;

			if(nXIndex < 0 || nXIndex >= SIZE_OF_MAX_UNIT)
				continue;
			for(int j = nY - 1; j <= nY + 1; j++)
			{
				nYIndex = j;
				if(j == nY - 1) nYIndex  = nY;
				if(j == nY) nYIndex  = nY - 1;

				if(nYIndex < 0 || nYIndex >= SIZE_OF_MAX_UNIT)
					continue;
				pos1stHole = pPatternHoleList[nXIndex*SIZE_OF_MAX_UNIT+nYIndex].GetHeadPosition();
				while(pos1stHole)
				{
					pHole1stData = pPatternHoleList[nX*SIZE_OF_MAX_UNIT+nY].GetNext(pos1stHole);

					if(abs(pHole1stData->npPos.x + nDistanceX - pHole->npPos.x) < PATTERN_DIFF_VAL && 
						abs(pHole1stData->npPos.y + nDistanceY - pHole->npPos.y) < PATTERN_DIFF_VAL && 
						bFound == FALSE)
					{
						bFound = TRUE;
						break;
					}
				}
				if(bFound)
					break;
			}
			if(bFound)
				break;
		}
		if(!bFound)
		{
			bResult = FALSE;
			goto FUNC_END;
		}
	}
	// compare end

FUNC_END :
	for(int i = 0; i < SIZE_OF_MAX_UNIT * SIZE_OF_MAX_UNIT; i++)
	{
		pPatternHoleList[i].RemoveAll();
	}
	delete [] pPatternHoleList;



	return bResult;
}
