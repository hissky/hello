// DTempINI.cpp: implementation of the DTempINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DTempINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DTempINI gTempINI;

DTempINI::DTempINI()
{
	m_sTempTime.nAutoPreheatEndTime = 0;
	memset(m_sTempTime.nAutoPowerEndTime, 0, sizeof(m_sTempTime.nAutoPowerEndTime));
	memset(m_sTempTime.nAutoScalEndTime, 0, sizeof(m_sTempTime.nAutoScalEndTime));
	memset(m_sTempTime.dAutoScalTemperature, 0, sizeof(m_sTempTime.dAutoScalTemperature));
	memset(m_sTempTime.dAutoScalEndTemperature, 0, sizeof(m_sTempTime.dAutoScalEndTemperature));

	m_sTempTime.d1stFidSecondPosX = 0;
	m_sTempTime.d1stFidSecondPosY = 0;
	m_sTempTime.d2ndFidFirstPosX = 0;
	m_sTempTime.d2ndFidFirstPosY = 0;
	m_sTempTime.d2ndFidSecondPosX = 0;
	m_sTempTime.d2ndFidSecondPosY = 0;
}

DTempINI::~DTempINI()
{

}
