// BeamPathINIFile.h: interface for the CBeamPathINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BEAMPATHINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)
#define AFX_BEAMPATHINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class DBeampathINI;
class DSystemINI;

class CBeamPathINIFile  
{
public:
	CBeamPathINIFile();
	virtual ~CBeamPathINIFile();

	BOOL	GetOldBeamPathData(DBeampathINI& clsBeamPathINI, DSystemINI clsSystemINI);
	BOOL	OpenBeamPathINIFile(CString strFilePath, DBeampathINI& clsBeamPathINI);
	BOOL	ParsingBeamPath(CStdioFile& sFile, DBeampathINI& clsBeamPathINI);

	
	BOOL	SaveBeamPathNIFile(CString strFilePath, DBeampathINI clsBeamPathINI);
	BOOL	SaveBeamPath(CStdioFile& sFile, DBeampathINI clsBeamPathINI);

	
	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_BEAMPATHINIFILE_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)
