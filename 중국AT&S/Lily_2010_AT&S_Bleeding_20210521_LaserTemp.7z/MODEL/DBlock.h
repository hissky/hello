// DBlock.h: interface for the DBlock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBLOCK_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)
#define AFX_DBLOCK_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToolCodeList.h"
#include "HOLEDATA.h"


class DOriginLineSort;

class DBlock  
{
public:
	BOOL GetSameBlockIndex(DBlock* pBlock, double& dDistX, double& dDistY);
	void SortOriginBlockHole();
	CPoint BlockFirstPositionToZero();
	double CalAngle(CDPoint InPo1, CDPoint InPo2);
	double GetDistance(CDPoint a, CDPoint b);
	bool isEqual(double x, double y);
	CDPoint Bulge2Arc(CPoint pt1, CPoint pt2, double bulge, double& dRadius);



	void ReCalRect();
	BOOL IsAnyData();
	void DelInRect(CPoint point1, CPoint point2, BOOL bReverse);
	void Merge(DBlock* pUnit);
	void Copy(DBlock *pUnit, int nOffsetX, int nOffsetY);
	void Move(int nX, int nY);
	void Copy(DBlock* pUnit);
	BOOL IsLineData(int nTool);
	BOOL IsDotData(int nTool);
	void ReMoveAllHoleData();
	void ReMoveAllLineData();
	void Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY);
	void Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY);
	BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);		// 20160420binary
	BOOL LoadFileRect10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFileRect10000(CArchiveMark &ar, int nVersion);
	DBlock();
	virtual ~DBlock();

	HOLEDATA m_OrigHoleData; // temp data


	int	m_nBlockName;
	int	m_nMinX;
	int	m_nMinY;
	int	m_nMaxX;
	int	m_nMaxY;
	HoleDataList	m_HoleData;
};

typedef	DBlock*	LPDBLOCK;
typedef CTypedPtrList <CPtrList, LPDBLOCK>	BlockList;

#endif // !defined(AFX_DBLOCK_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)
