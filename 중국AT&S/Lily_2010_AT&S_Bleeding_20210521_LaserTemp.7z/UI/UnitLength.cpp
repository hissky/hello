// UnitLength.cpp: implementation of the CUnitLength class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "UnitLength.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWndList CUnitLength::m_wndList;
const CString CUnitLength::m_strUnit[NumLength] = {_T(""), _T("um"), _T("mm"), _T("inch")};
const CString CUnitLength::m_strFormat[NumLength] = {_T("%.0f"), _T("%.0f"), _T("%.3f"), _T("%.3f")};
const double CUnitLength::m_dConversion[NumLength] = {1.0, 1.0, 1000.0, 25400.0 };
enLength CUnitLength::m_default = lengthUM;

CUnitLength::CUnitLength()
{
}

CUnitLength::~CUnitLength()
{
}

void CUnitLength::AddWnd(CWnd *pWnd)
{
	ASSERT_VALID(pWnd);
	if (m_wndList.Find(pWnd, NULL) != NULL)
		return;

	m_wndList.AddTail(pWnd);
	
	if (NULL != pWnd && ::IsWindow(pWnd->m_hWnd))
	{
		pWnd->SendMessage(WM_UNITCHANGE, (WPARAM)lengthNone, (LPARAM)m_default);
	}
}

void CUnitLength::RemoveWnd(CWnd *pWnd)
{
	ASSERT_VALID(pWnd);

	POSITION pos = m_wndList.Find(pWnd);
	if (NULL != pos)
	{
		m_wndList.RemoveAt(pos);
	}
}

void CUnitLength::SetDisplayUnit(enLength nNewUnit)
{
	enLength nOldUnit = m_default;
	m_default = nNewUnit;

	POSITION pos = m_wndList.GetHeadPosition();
	while (pos)
	{
		CWnd* pWnd = m_wndList.GetNext(pos);
		if (NULL != pWnd && ::IsWindow(pWnd->m_hWnd))
		{
			pWnd->SendMessage(WM_UNITCHANGE, (WPARAM)nOldUnit, (LPARAM)nNewUnit);
		}
	}
}

double CUnitLength::GetDisplayValue(double dValue, enLength enUnit)
{
	return dValue/m_dConversion[enUnit];
}

double CUnitLength::GetInternalValue(double dValue, enLength enUnit)
{
	return dValue*m_dConversion[enUnit];
}
