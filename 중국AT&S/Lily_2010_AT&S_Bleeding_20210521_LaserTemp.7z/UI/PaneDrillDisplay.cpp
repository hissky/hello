// PaneDrillDisplay.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneDrillDisplay.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplay

IMPLEMENT_DYNCREATE(CPaneDrillDisplay, CFormView)

CPaneDrillDisplay::CPaneDrillDisplay()
	: CFormView(CPaneDrillDisplay::IDD)
{
	//{{AFX_DATA_INIT(CPaneDrillDisplay)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneDrillDisplay::~CPaneDrillDisplay()
{
}

void CPaneDrillDisplay::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneDrillDisplay)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneDrillDisplay, CFormView)
	//{{AFX_MSG_MAP(CPaneDrillDisplay)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplay diagnostics

#ifdef _DEBUG
void CPaneDrillDisplay::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneDrillDisplay::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplay message handlers

void CPaneDrillDisplay::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CRect rtView;
	
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect( rtView );
	ScreenToClient( rtView );

	m_clsDrillDataView.SetViewSize( rtView );
	if( FALSE == m_clsDrillDataView.CreateView( this ) )
		ErrMessage(_T("Can not create drill data view"), MB_ICONERROR);
}
