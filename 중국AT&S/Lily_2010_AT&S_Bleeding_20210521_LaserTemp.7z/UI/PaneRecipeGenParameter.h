#if !defined(AFX_PANERECIPEGENPARAMETER_H__A41F3CE6_45B2_4F0F_AC0F_FA2B5536121A__INCLUDED_)
#define AFX_PANERECIPEGENPARAMETER_H__A41F3CE6_45B2_4F0F_AC0F_FA2B5536121A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenParameter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameter form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "..\model\DProject.h"

//class DProject;

class CPaneRecipeGenParameter : public CFormView
{
protected:
	CPaneRecipeGenParameter();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenParameter)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenParameter)
	enum { IDD = IDD_DLG_RECIPE_GEN_PARAMETER };
	CComboBox	m_cmbDrillMethod;
	UEasyButtonEx	m_btnSetting;
	CListCtrl	m_listLaserControlParam;
	CColorEdit	m_edtTcode;
	CColorEdit	m_edtShotCount;
	CColorEdit	m_edtShotBurstCount;
	CColorEdit	m_edtFreq;
	CColorEdit	m_edtAperturePath;
	CComboBox	m_cmbMask;
	CColorComboEx	m_cmbColor;
	UEasyButtonEx	m_btnParamUpdate;
	UEasyButtonEx	m_btnParamDelete;
	UEasyButtonEx	m_btnApertureOpen;
	UEasyButtonEx	m_chkUseAperture;
	//}}AFX_DATA

// Attributes
public:
	CString		m_strColorName;
// Operations
public:
	void UpdateList(int nIndex);
	void ChangeData(int nSelIndex);
	void ChangeDisplay(int nSelIndex);
	void AddParameter(TOOLDATA toolData);
	BOOL SetData(BOOL bReNew, DProject& mDproject);
	BOOL GetData(DProject& tempDProject);
	void		InitListControl();
	void		InitStaticControl();
	void		InitBtnControl();
	void		InitComboControl();
	void		InitEditControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenParameter)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenParameter();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
	CList <TOOLDATA, TOOLDATA> m_ToolDataList;
	APERTUREDATA m_ApertureData[MAX_SHOT_NO_UV];
	double		m_dPower[MAX_BEAM_HOLE];

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenParameter)
	afx_msg void OnSelchangeComboColor();
	afx_msg void OnButtonApertureOpen();
	afx_msg void OnButtonSetting();
	afx_msg void OnDestroy();
	afx_msg void OnButtonParamUpdate();
	afx_msg void OnClickListLaserControlParameter(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeComboDrillMethod();
	afx_msg void OnCheckUseAperture();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENPARAMETER_H__A41F3CE6_45B2_4F0F_AC0F_FA2B5536121A__INCLUDED_)
