// DlgVisionOnly.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgVisionOnly.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionOnly dialog


CDlgVisionOnly::CDlgVisionOnly(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVisionOnly::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgVisionOnly)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgVisionOnly::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgVisionOnly)
	DDX_Control(pDX, IDOK, m_btnClose);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgVisionOnly, CDialog)
	//{{AFX_MSG_MAP(CDlgVisionOnly)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionOnly message handlers

void CDlgVisionOnly::OnCancel() 
{

}

BOOL CDlgVisionOnly::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgVisionOnly::OnOK() 
{
	this->ShowWindow( SW_HIDE );
}

void CDlgVisionOnly::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("Close") );
	m_btnClose.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDCANCEL)->ShowWindow(SW_HIDE);
}

BOOL CDlgVisionOnly::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

BOOL CDlgVisionOnly::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	
	return CDialog::DestroyWindow();
}
