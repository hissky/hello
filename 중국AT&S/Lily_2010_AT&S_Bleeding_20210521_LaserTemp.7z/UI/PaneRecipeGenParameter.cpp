// PaneRecipeGenParameter.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenParameter.h"
#include "DlgLaserBeamHoleSet.h"
#include "DlgApertureSet.h"

#include "..\model\DProject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameter

IMPLEMENT_DYNCREATE(CPaneRecipeGenParameter, CFormView)

CPaneRecipeGenParameter::CPaneRecipeGenParameter()
	: CFormView(CPaneRecipeGenParameter::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenParameter)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_strColorName		= _T("");
}

CPaneRecipeGenParameter::~CPaneRecipeGenParameter()
{
}

void CPaneRecipeGenParameter::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenParameter)
	DDX_Control(pDX, IDC_COMBO_DRILL_METHOD, m_cmbDrillMethod);
	DDX_Control(pDX, IDC_BUTTON_SETTING, m_btnSetting);
	DDX_Control(pDX, IDC_LIST_LASER_CONTROL_PARAMETER, m_listLaserControlParam);
	DDX_Control(pDX, IDC_EDIT_TCODE_NO, m_edtTcode);
	DDX_Control(pDX, IDC_EDIT_SHOT_COUNT, m_edtShotCount);
	DDX_Control(pDX, IDC_EDIT_SUB_SHOT_COUNT, m_edtShotBurstCount);
	DDX_Control(pDX, IDC_EDIT_FREQ, m_edtFreq);
	DDX_Control(pDX, IDC_EDIT_APERTURE_PATH, m_edtAperturePath);
	DDX_Control(pDX, IDC_COMBO_MASK_NO, m_cmbMask);
	DDX_Control(pDX, IDC_COMBO_COLOR, m_cmbColor);
	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE, m_btnParamUpdate);
	DDX_Control(pDX, IDC_BUTTON_PARAM_DELETE, m_btnParamDelete);
	DDX_Control(pDX, IDC_BUTTON_APERTURE_OPEN, m_btnApertureOpen);
	DDX_Control(pDX, IDC_CHECK_USE_APERTURE, m_chkUseAperture);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenParameter, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenParameter)
	ON_CBN_SELCHANGE(IDC_COMBO_COLOR, OnSelchangeComboColor)
	ON_BN_CLICKED(IDC_BUTTON_APERTURE_OPEN, OnButtonApertureOpen)
	ON_BN_CLICKED(IDC_BUTTON_SETTING, OnButtonSetting)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE, OnButtonParamUpdate)
	ON_NOTIFY(NM_CLICK, IDC_LIST_LASER_CONTROL_PARAMETER, OnClickListLaserControlParameter)
	ON_CBN_SELCHANGE(IDC_COMBO_DRILL_METHOD, OnSelchangeComboDrillMethod)
	ON_BN_CLICKED(IDC_CHECK_USE_APERTURE, OnCheckUseAperture)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameter diagnostics

#ifdef _DEBUG
void CPaneRecipeGenParameter::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenParameter::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameter message handlers

void CPaneRecipeGenParameter::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();
	InitEditControl();
}

BOOL CPaneRecipeGenParameter::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneRecipeGenParameter::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, _T("Arial Bold"));

	m_listLaserControlParam.SetFont( &m_fntList );

	const int nMaxColumnNum = 7;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;

	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("T-Code No"));
			break;
		case 1 :
			strText.Format(_T("Mask No"));
			break;
		case 2 :
			strText.Format(_T("Frequency"));
			break;
		case 3 :
			strText.Format(_T("Shots per hole"));
			break;
		case 4 :
			strText.Format(_T("Color"));
			break;
		case 5 :
			strText.Format(_T("Aperture"));
			break;
		case 6 :
			strText.Format(_T("Drill Method"));
			break;
		}

		_stprintf_s( szText, _T("%s"), strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		lvcolumn.cx = 139;

		m_listLaserControlParam.InsertColumn(i, &lvcolumn);
	}

	DWORD dwStyle = m_listLaserControlParam.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;

	m_listLaserControlParam.SetExtendedStyle( dwStyle );
}

void CPaneRecipeGenParameter::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, _T("Arial Bold"));

	// Shot Count Setting
	m_btnSetting.SetFont( &m_fntBtn );
	m_btnSetting.SetFlat( FALSE );
	m_btnSetting.EnableBallonToolTip();
	m_btnSetting.SetToolTipText( _T("Shot Count Setting") );
	m_btnSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetting.SetBtnCursor(IDC_HAND_1);

	// Aperture Open
	m_btnApertureOpen.SetFont( &m_fntBtn );
	m_btnApertureOpen.SetFlat( FALSE );
	m_btnApertureOpen.EnableBallonToolTip();
	m_btnApertureOpen.SetToolTipText( _T("Aperture File Open") );
	m_btnApertureOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApertureOpen.SetBtnCursor(IDC_HAND_1);

	// Delete Laser Control Parameter
	m_btnParamDelete.SetFont( &m_fntBtn );
	m_btnParamDelete.SetFlat( FALSE );
	m_btnParamDelete.EnableBallonToolTip();
	m_btnParamDelete.SetToolTipText( _T("Delete Laser Control Parameter") );
	m_btnParamDelete.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnParamDelete.SetBtnCursor(IDC_HAND_1);

	// Update Laser Control Parameter
	m_btnParamUpdate.SetFont( &m_fntBtn );
	m_btnParamUpdate.SetFlat( FALSE );
	m_btnParamUpdate.EnableBallonToolTip();
	m_btnParamUpdate.SetToolTipText( _T("Update Laser Control Parameter") );
	m_btnParamUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnParamUpdate.SetBtnCursor(IDC_HAND_1);

	// Use aperture
	m_chkUseAperture.SetFont( &m_fntBtn );
	m_chkUseAperture.SetImageOrg( 10, 3 );
	m_chkUseAperture.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAperture.EnableBallonToolTip();
	m_chkUseAperture.SetToolTipText( _T("Tool Order") );
	m_chkUseAperture.SetBtnCursor(IDC_HAND_1);

	m_chkUseAperture.EnableWindow(FALSE);
}

void CPaneRecipeGenParameter::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// T-Code No
	m_edtTcode.SetFont( &m_fntEdit );
	m_edtTcode.SetForeColor( BLACK_COLOR );
	m_edtTcode.SetBackColor( WHITE_COLOR );
	m_edtTcode.SetReceivedFlag( 1 ); // Integer
	m_edtTcode.EnableWindow( FALSE );

	// Frequency
	m_edtFreq.SetFont( &m_fntEdit );
	m_edtFreq.SetForeColor( BLACK_COLOR );
	m_edtFreq.SetBackColor( WHITE_COLOR );
	m_edtFreq.SetReceivedFlag( 1 ); // Integer
	m_edtFreq.SetWindowText( _T("1000") );
		
	// Shot count
	m_edtShotCount.SetFont( &m_fntEdit );
	m_edtShotCount.SetForeColor( BLACK_COLOR );
	m_edtShotCount.SetBackColor( WHITE_COLOR );
	m_edtShotCount.SetReceivedFlag( 1 ); // Integer
	m_edtShotCount.SetWindowText( _T("3") );

	// Shot burset count
	m_edtShotBurstCount.SetFont( &m_fntEdit );
	m_edtShotBurstCount.SetForeColor( BLACK_COLOR );
	m_edtShotBurstCount.SetBackColor( WHITE_COLOR );
	m_edtShotBurstCount.SetReceivedFlag( 1 ); // Integer
	m_edtShotBurstCount.SetWindowText( _T("3") );

	// Aperture File Path
	m_edtAperturePath.SetFont( &m_fntEdit );
	m_edtAperturePath.SetForeColor( BLACK_COLOR );
	m_edtAperturePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtAperturePath.SetWindowText( _T("") );
	m_edtAperturePath.EnableWindow( FALSE );
}

void CPaneRecipeGenParameter::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_TCODE_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASK_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COLOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SHOT_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_APERTURE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DRILL_METHOD)->SetFont( &m_fntStatic );
}

void CPaneRecipeGenParameter::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbColor.SetFont( &m_fntCombo );
	m_cmbColor.SetCurSel( 0 );

	m_cmbDrillMethod.SetFont( &m_fntCombo );
	m_cmbDrillMethod.SetCurSel( 0 );
}

void CPaneRecipeGenParameter::OnSelchangeComboColor() 
{
	int nSel = m_cmbColor.GetCurSel();

	switch( nSel )
	{
	case 0 :
		m_strColorName.Format(_T("White"));
		break;
	case 1 :
		m_strColorName.Format(_T("Gray"));
		break;
	case 2 :
		m_strColorName.Format(_T("Black"));
		break;
	case 3 :
		m_strColorName.Format(_T("Brown"));
		break;
	case 4 :
		m_strColorName.Format(_T("Red"));
		break;
	case 5 :
		m_strColorName.Format(_T("Magenta"));
		break;
	case 6 :
		m_strColorName.Format(_T("Orange"));
		break;
	case 7 :
		m_strColorName.Format(_T("Pink"));
		break;
	case 8 :
		m_strColorName.Format(_T("Yellow"));
		break;
	case 9 :
		m_strColorName.Format(_T("Cyan"));
		break;
	case 10 :
		m_strColorName.Format(_T("Blue"));
		break;
	case 11 :
		m_strColorName.Format(_T("Green"));
		break;
	}
}

void CPaneRecipeGenParameter::OnButtonApertureOpen() 
{
	// setting aperture info - dlg ������ �Ѵ�
	int sel = m_listLaserControlParam.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("First. select tool"));
		return;
	}

	CDlgApertureSet dlg;

	for(int i = 0; i < MAX_SHOT_NO_UV; i++)
		dlg.m_ApertureData[i] = m_ApertureData[i];

	if(IDOK != dlg.DoModal())
	{
		m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listLaserControlParam.SetFocus();
		m_listLaserControlParam.EnsureVisible(sel, TRUE );
		return;
	}

	for(int i = 0; i < MAX_SHOT_NO_UV; i++)
		m_ApertureData[i] = dlg.m_ApertureData[i];
	
	m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listLaserControlParam.SetFocus();
	m_listLaserControlParam.EnsureVisible(sel, TRUE );

}

void CPaneRecipeGenParameter::OnButtonSetting() 
{
	int sel = m_listLaserControlParam.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("First. select tool"));
		return;
	}

	int nShotCount = 0;

	nShotCount = GetDlgItemInt( IDC_EDIT_SHOT_COUNT );

	if( nShotCount <= 0 || nShotCount > 15)
	{
		ErrMessage(IDS_SHOT_COUNT_INPUT_ERR, MB_ICONERROR);

		m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listLaserControlParam.SetFocus();
		m_listLaserControlParam.EnsureVisible(sel, TRUE );
		return;
	}

	CDlgLaserBeamHoleSet dlg;

//	dlg.SetFireHole( nShotCount, m_dPower );
	
	if(IDOK != dlg.DoModal())
	{
		m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listLaserControlParam.SetFocus();
		m_listLaserControlParam.EnsureVisible(sel, TRUE );
		return;
	}

//	dlg.GetFireHole(m_dPower);

	m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listLaserControlParam.SetFocus();
	m_listLaserControlParam.EnsureVisible(sel, TRUE );

}

void CPaneRecipeGenParameter::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

BOOL CPaneRecipeGenParameter::GetData(DProject &tempDProject)
{
	int i = 0;
	TOOLDATA toolData;
	POSITION pos = m_ToolDataList.GetHeadPosition();
	while(pos)
	{
		toolData = m_ToolDataList.GetNext(pos);
	}
	return TRUE;
}

void CPaneRecipeGenParameter::OnButtonParamUpdate() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listLaserControlParam.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("First. select tool"));
		return;
	}

	ChangeData(sel);
	UpdateList(sel);

	m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listLaserControlParam.SetFocus();
	m_listLaserControlParam.EnsureVisible(sel, TRUE );
}

BOOL CPaneRecipeGenParameter::SetData(BOOL bReNew, DProject& mDproject)
{
/*	TOOLDATA toolData;

	if(!bReNew)
	{
		for(int i = 0; i < mDproject.m_nToolNo; i++)
		{
			POSITION pos = m_ToolDataList.GetHeadPosition();
			while(pos)
			{
				toolData = m_ToolDataList.GetNext(pos);
				if(mDproject.m_ToolData[i].nTcodeNo == toolData.nTcodeNo)
				{
					mDproject.m_ToolData[i] = toolData;
					break;
				}
			}
		}
	}

	m_listLaserControlParam.DeleteAllItems();
	m_ToolDataList.RemoveAll();
	for(int i = 0; i < mDproject.m_nToolNo; i++)
	{
		m_ToolDataList.AddTail(mDproject.m_ToolData[i]);
		AddParameter(mDproject.m_ToolData[i]);
	}

	GetDlgItem(IDC_BUTTON_APERTURE_OPEN)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_DRILL_METHOD)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_USE_APERTURE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);

	if(gDProject.m_nToolNo > 0)
	{
		ChangeDisplay(0);
		m_listLaserControlParam.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
		m_listLaserControlParam.SetFocus();
		m_listLaserControlParam.EnsureVisible( 0, TRUE );
	}
*/	return TRUE;
}

void CPaneRecipeGenParameter::AddParameter(TOOLDATA toolData)
{
	int nIndex;
	LV_ITEM lvItem;
	CString strText;
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.iItem = m_listLaserControlParam.GetItemCount();
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	//Tool No
	lvItem.iSubItem = 0;
	strText.Format(_T("%d"), toolData.nTcodeNo);
	lvItem.pszText = (LPSTR)(LPCSTR)strText;//szText;
	nIndex = m_listLaserControlParam.InsertItem(&lvItem);

	strText.Format(_T("%d"), toolData.nTcodeNo);
	m_listLaserControlParam.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), toolData.nMask);
	m_listLaserControlParam.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), toolData.nFreq);
	m_listLaserControlParam.SetItemText(nIndex, 2, (LPSTR)(LPCSTR)strText);

	strText.Format(_T("%d"), toolData.nShotCount);
	m_listLaserControlParam.SetItemText(nIndex, 3, (LPSTR)(LPCSTR)strText);

	switch( toolData.nColor )
	{
	case 0 :
		strText.Format(_T("White"));
		break;
	case 1 :
		strText.Format(_T("Gray"));
		break;
	case 2 :
		strText.Format(_T("Black"));
		break;
	case 3 :
		strText.Format(_T("Brown"));
		break;
	case 4 :
		strText.Format(_T("Red"));
		break;
	case 5 :
		strText.Format(_T("Magenta"));
		break;
	case 6 :
		strText.Format(_T("Orange"));
		break;
	case 7 :
		strText.Format(_T("Pink"));
		break;
	case 8 :
		strText.Format(_T("Yellow"));
		break;
	case 9 :
		strText.Format(_T("Cyan"));
		break;
	case 10 :
		strText.Format(_T("Blue"));
		break;
	case 11 :
		strText.Format(_T("Green"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 4, (LPSTR)(LPCSTR)strText);

	switch( toolData.bUseAperture )
	{
	case 0 :
		strText.Format(_T("-"));
		break;
	case 1 :
		strText.Format(_T("Use"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 5, (LPSTR)(LPCSTR)strText);

	switch( toolData.nDrillMethod )
	{
	case 0 :
		strText.Format(_T("Burst"));
		break;
	case 1 :
		strText.Format(_T("Cycle"));
		break;
	case 2 :
		strText.Format(_T("Step"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 6, (LPSTR)(LPCSTR)strText);
	
}

void CPaneRecipeGenParameter::OnClickListLaserControlParameter(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int sel = m_listLaserControlParam.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("First. select tool"));
		return;
	}

	ChangeDisplay(sel);

	m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listLaserControlParam.SetFocus();
	m_listLaserControlParam.EnsureVisible(sel, TRUE );

	*pResult = 0;
}

void CPaneRecipeGenParameter::ChangeDisplay(int nSelIndex)
{
	CString str;
	TOOLDATA toolData;

	int i = 0;
	POSITION pos = m_ToolDataList.GetHeadPosition();
	while(pos)
	{
		if(i == nSelIndex) break;
		m_ToolDataList.GetNext(pos);
		i++;
	}
	toolData = m_ToolDataList.GetAt(pos);

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		m_dPower[i] = toolData.dPower[i];

	for(int i = 0; i < MAX_SHOT_NO_UV; i++)
		m_ApertureData[i] = toolData.Aperture[i];
	
	str.Format(_T("%d"), toolData.nTcodeNo);
	m_edtTcode.SetWindowText(str);

	m_cmbMask.SetCurSel(toolData.nMask);
	
	str.Format(_T("%d"), toolData.nFreq);
	m_edtFreq.SetWindowText(str);

	m_cmbColor.SetCurSel(toolData.nColor);

	m_cmbDrillMethod.SetCurSel(toolData.nDrillMethod);

	str.Format(_T("%d"), toolData.nShotCount);
	m_edtShotCount.SetWindowText(str);

	str.Format(_T("%d"), toolData.nBurstShotCount);
	m_edtShotBurstCount.SetWindowText(str);

	m_chkUseAperture.SetCheck(toolData.bUseAperture);

	if(toolData.bUseAperture)
	{
		GetDlgItem(IDC_CHECK_USE_APERTURE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_APERTURE_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_MASK_NO)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_FREQ)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(FALSE);
		//		GetDlgItem(IDC_STATIC)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_DRILL_METHOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_DRILL_METHOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_USE_APERTURE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_MASK_NO)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_FREQ)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(TRUE);
		//		GetDlgItem(IDC_STATIC)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_DRILL_METHOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_DRILL_METHOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
		if(toolData.nDrillMethod == 2) //step
		{
			GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);
		}
	}
	GetDlgItem(IDC_LIST_LASER_CONTROL_PARAMETER)->EnableWindow(TRUE);

	UpdateData(FALSE);

}

void CPaneRecipeGenParameter::ChangeData(int nSelIndex)
{
	CString str;
	int nTempVal;
	TOOLDATA toolData;
	POSITION posIndex;

	int i = 0;
	POSITION pos = m_ToolDataList.GetHeadPosition();
	while(pos)
	{
		if(i == nSelIndex)
		{
			posIndex = pos;
			break;
		}
		m_ToolDataList.GetNext(pos);
		i++;
	}
	toolData = m_ToolDataList.GetAt(pos);

	m_edtTcode.GetWindowText(str);
	nTempVal = atoi(str);
	toolData.nTcodeNo = nTempVal;

	toolData.bUseAperture = m_chkUseAperture.GetCheck();

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		toolData.dPower[i] = m_dPower[i];

	for(int i = 0; i < MAX_SHOT_NO_UV; i++)
		 toolData.Aperture[i] = m_ApertureData[i];

	toolData.nMask = m_cmbMask.GetCurSel();

	if(!toolData.bUseAperture && toolData.nMask == -1)
	{
		m_cmbMask.SetFocus();
		ErrMessage(_T("if use not aperture, you must select mask"));
		return;
	}

	m_edtFreq.GetWindowText(str);
	nTempVal = atoi(str);
	toolData.nFreq = nTempVal;

	if(toolData.nFreq > MAX_FREQ || toolData.nFreq < MIN_FREQ)
	{
		m_edtFreq.SetFocus();
		ErrMessage(_T("1000ha < Freq. < 10000hz"));
		return;
	}

	toolData.nColor = m_cmbColor.GetCurSel();

	toolData.nDrillMethod = m_cmbDrillMethod.GetCurSel();

	m_edtShotCount.GetWindowText(str);
	nTempVal = atoi(str);
	toolData.nShotCount = nTempVal;
	
	if(toolData.nShotCount > MAX_SHOT_NO_CO2 || toolData.nFreq < 0)
	{
		m_edtShotCount.SetFocus();
		ErrMessage(_T("shot is maller than 256"));
		return;
	}

	m_edtShotBurstCount.GetWindowText(str);
	nTempVal = atoi(str);
	toolData.nBurstShotCount = nTempVal;
	
	if(toolData.nShotCount < toolData.nBurstShotCount && !toolData.bUseAperture)
	{
		m_edtShotBurstCount.SetFocus();
		ErrMessage(_T("burset shot <= total shot"));
		return;
	}

	m_ToolDataList.SetAt(pos, toolData);
}

void CPaneRecipeGenParameter::OnSelchangeComboDrillMethod() 
{
	// TODO: Add your control notification handler code here
	int nDrillM = m_cmbDrillMethod.GetCurSel();
	if(nDrillM == 2) // step
	{
		GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);
	}
}

void CPaneRecipeGenParameter::OnCheckUseAperture() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listLaserControlParam.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("First. select tool"));
		return;
	}

	if(m_chkUseAperture.GetCheck())
	{
		GetDlgItem(IDC_BUTTON_APERTURE_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_MASK_NO)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_FREQ)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(FALSE);
		//		GetDlgItem(IDC_STATIC)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_DRILL_METHOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_DRILL_METHOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_BUTTON_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_MASK_NO)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_MASK_NO)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_FREQ)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_FREQ)->EnableWindow(TRUE);
		//		GetDlgItem(IDC_STATIC)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC_DRILL_METHOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_DRILL_METHOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
		if(m_cmbDrillMethod.GetCurSel() == 2) //step
		{
			GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_STATIC_SUBSHOT_COUNT)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_SUB_SHOT_COUNT)->EnableWindow(FALSE);
		}
	}
	GetDlgItem(IDC_LIST_LASER_CONTROL_PARAMETER)->EnableWindow(TRUE);

	m_listLaserControlParam.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listLaserControlParam.SetFocus();
	m_listLaserControlParam.EnsureVisible(sel, TRUE );
}

void CPaneRecipeGenParameter::UpdateList(int nIndex)
{
	TOOLDATA toolData;
	int i = 0;
	CString strText;
	POSITION pos = m_ToolDataList.GetHeadPosition();
	while(pos)
	{
		if(i == nIndex) break;
		m_ToolDataList.GetNext(pos);
		i++;
	}
	toolData = m_ToolDataList.GetAt(pos);
	
	strText.Format(_T("%d"), toolData.nTcodeNo);
	m_listLaserControlParam.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), toolData.nMask);
	m_listLaserControlParam.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), toolData.nFreq);
	m_listLaserControlParam.SetItemText(nIndex, 2, (LPSTR)(LPCSTR)strText);
	
	strText.Format(_T("%d"), toolData.nShotCount);
	m_listLaserControlParam.SetItemText(nIndex, 3, (LPSTR)(LPCSTR)strText);
	
	switch( toolData.nColor )
	{
	case 0 :
		strText.Format(_T("White"));
		break;
	case 1 :
		strText.Format(_T("Gray"));
		break;
	case 2 :
		strText.Format(_T("Black"));
		break;
	case 3 :
		strText.Format(_T("Brown"));
		break;
	case 4 :
		strText.Format(_T("Red"));
		break;
	case 5 :
		strText.Format(_T("Magenta"));
		break;
	case 6 :
		strText.Format(_T("Orange"));
		break;
	case 7 :
		strText.Format(_T("Pink"));
		break;
	case 8 :
		strText.Format(_T("Yellow"));
		break;
	case 9 :
		strText.Format(_T("Cyan"));
		break;
	case 10 :
		strText.Format(_T("Blue"));
		break;
	case 11 :
		strText.Format(_T("Green"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 4, (LPSTR)(LPCSTR)strText);
	
	switch( toolData.bUseAperture )
	{
	case 0 :
		strText.Format(_T("-"));
		break;
	case 1 :
		strText.Format(_T("Use"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 5, (LPSTR)(LPCSTR)strText);
	
	switch( toolData.nDrillMethod )
	{
	case 0 :
		strText.Format(_T("Burst"));
		break;
	case 1 :
		strText.Format(_T("Cycle"));
		break;
	case 2 :
		strText.Format(_T("Step"));
		break;
	}
	m_listLaserControlParam.SetItemText(nIndex, 6, (LPSTR)(LPCSTR)strText);
}
