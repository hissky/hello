﻿// PaneRecipeGen.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGen.h"

#include "PaneRecipeGenData.h"
#include "PaneRecipeGenLayout.h"
#include "PaneRecipeGenDrillMethod.h"
#include "PaneRecipeGenFiducial.h"
#include "PaneRecipeGenParameter.h"
#include "PaneRecipeGenParameterNew.h"
#include "PaneRecipeGenFiducialNew.h"
#include "PaneRecipeGenParameterNewNext.h"
#include "PaneAutoRun.h"

#include "PaneAutoRunViewData.h"

#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemInI.h"
#include "..\model\ExcellonReader.h"
#include "..\model\DUodoRedo.h"

#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"
#include "..\EasyDriller.h"

#include "..\device\HDeviceFactory.h"

#include "..\device\DeviceMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen

IMPLEMENT_DYNCREATE(CPaneRecipeGen, CFormView)

CPaneRecipeGen::CPaneRecipeGen()
	: CFormView(CPaneRecipeGen::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGen)
	//}}AFX_DATA_INIT
	m_pDataLoad			= NULL;
	m_pLayout			= NULL;
//	m_pDrillMethod		= NULL;

	m_pParam			= NULL;
	m_pParamNew			= NULL;
	m_DProject			= DProject();
	m_bProjectOpen		= FALSE;
	m_pFiducialNew		= NULL;
	m_pParamNewNext		= NULL;
	m_nPaneNo			= 0;
}

CPaneRecipeGen::~CPaneRecipeGen()
{
}

void CPaneRecipeGen::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGen)
	DDX_Control(pDX, IDC_STATIC_CAD_PATH, m_stcCadPath);
	DDX_Control(pDX, IDC_BUTTON_CAD_DATA, m_btnCadData);
	DDX_Control(pDX, IDC_TAB_RECIPE, m_tabRecipe);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGen, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGen)
	ON_BN_CLICKED(IDC_BUTTON_CAD_DATA, OnButtonCadData)
	ON_NOTIFY(NM_CLICK, IDC_TAB_RECIPE, OnClickTabRecipe)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen diagnostics

#ifdef _DEBUG
void CPaneRecipeGen::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGen::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen message handlers

void CPaneRecipeGen::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitTabControl();
	InitStaticControl();
}

void CPaneRecipeGen::InitBtnControl()
{
	m_fntBtn.CreatePointFont( 125, "Arial Bold");

	m_btnCadData.SetFont( &m_fntBtn );
	m_btnCadData.SetFlat( TRUE );
	m_btnCadData.SetIcon( IDI_CADOPEN );
	m_btnCadData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCadData.EnableBallonToolTip();
	m_btnCadData.SetToolTipText( _T("CAD data open") );
	m_btnCadData.SetBtnCursor( IDC_HAND_1 );
}

void CPaneRecipeGen::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	CString strCh;
	BOOL bRet = 0;

	m_tabRecipe.SetFont( &m_fntTab );

	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 程式加载 ");
	else
		strCh = " Data Load ";
	bRet = m_tabRecipe.AddPane( strCh, RUNTIME_CLASS(CPaneRecipeGenData) );
	if( FALSE != bRet )
	{
		m_pDataLoad	= static_cast<CPaneRecipeGenData*>(m_tabRecipe.GetPane(0));
		m_pDataLoad->OnInitialUpdate();
		m_pDataLoad->SetProject(&m_DProject);
		m_pDataLoad->m_pParent = this;
	}

	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 布局 ");
	else
		strCh = " Layout ";
	bRet = m_tabRecipe.AddPane( strCh, RUNTIME_CLASS(CPaneRecipeGenLayout) );
	if( FALSE != bRet )
	{
		m_pLayout = static_cast<CPaneRecipeGenLayout*>(m_tabRecipe.GetPane(1));
		m_pLayout->OnInitialUpdate();
	}

//	bRet = m_tabRecipe.AddPane( _T(" Drill Method && PCB Division "), RUNTIME_CLASS(CPaneRecipeGenDrillMethod) );
//	if( FALSE != bRet )
//	{
//		m_pDrillMethod = static_cast<CPaneRecipeGenDrillMethod*>(m_tabRecipe.GetPane(2));
//		m_pDrillMethod->OnInitialUpdate();
//	}
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 参数 ");
	else
		strCh = " Parameter ";
	bRet = m_tabRecipe.AddPane( strCh, RUNTIME_CLASS(CPaneRecipeGenParameterNew) );
	if( FALSE != bRet )
	{
		m_pParamNew = static_cast<CPaneRecipeGenParameterNew*>(m_tabRecipe.GetPane(2));
		m_pParamNew->OnInitialUpdate();
	}
	
//	bRet = m_tabRecipe.AddPane( _T(" Parameter "), RUNTIME_CLASS(CPaneRecipeGenParameter) );
//	if( FALSE != bRet )
//	{
//		m_pParam = static_cast<CPaneRecipeGenParameter*>(m_tabRecipe.GetPane(3));
//		m_pParam->OnInitialUpdate();
//	}
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 基准点 ");
	else
		strCh = " Fiducial ";
	bRet = m_tabRecipe.AddPane( strCh, RUNTIME_CLASS(CPaneRecipeGenFiducialNew) );
	if( FALSE != bRet )
	{
		m_pFiducialNew	= static_cast<CPaneRecipeGenFiducialNew*>(m_tabRecipe.GetPane(3));
		m_pFiducialNew->OnInitialUpdate();
	}

/*	bRet = m_tabRecipe.AddPane( _T(" ParameterNew "), RUNTIME_CLASS(CPaneRecipeGenParameterNewNext) );
	if( FALSE != bRet )
	{
		m_pParamNewNext = static_cast<CPaneRecipeGenParameterNewNext*>(m_tabRecipe.GetPane(4));
		m_pParamNewNext->OnInitialUpdate();
	}
	*/
/* 110516
	bRet = m_tabRecipe.AddPane( _T(" Fiducial "), RUNTIME_CLASS(CPaneRecipeGenFiducial) );
	if( FALSE != bRet )
	{
		m_pFiducial	= static_cast<CPaneRecipeGenFiducial*>(m_tabRecipe.GetPane(4));
		m_pFiducial->SetSkiving(DEFAULT_FID_INDEX);
		m_pFiducial->OnInitialUpdate();
	}

	bRet = m_tabRecipe.AddPane( _T(" Rotation Fiducial "), RUNTIME_CLASS(CPaneRecipeGenFiducial) );
	if( FALSE != bRet )
	{
		m_pFiducialSkiving	= static_cast<CPaneRecipeGenFiducial*>(m_tabRecipe.GetPane(5));
		m_pFiducialSkiving->SetSkiving(ADDED_FID_INDEX);
		m_pFiducialSkiving->OnInitialUpdate();
	}
*/
	m_tabRecipe.ShowPane( 0 );
}

void CPaneRecipeGen::InitStaticControl()
{
	m_fntStatic.CreatePointFont( 130, "Arial Bold");

	m_stcCadPath.SetFont( &m_fntStatic );
	m_stcCadPath.SetForeColor( VALUE_FORE_COLOR );
	m_stcCadPath.SetBackColor( ::GetSysColor( COLOR_BTNFACE ) );
}

void CPaneRecipeGen::OnButtonCadData() 
{
/*	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt)|*.txt|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, _T("*.txt"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();

	if(IDOK != dlg.DoModal())
	{
		return;
	}

	CString strPath;

	strPath.Format(_T("\t%s"), dlg.GetPathName());
	SetDlgItemText(IDC_STATIC_CAD_PATH, (LPCTSTR)strPath);
	
	ExcellonReader excelReader;
	strcpy_s(m_DProject.m_szFileName, dlg.GetPathName());
	
	m_pLayout->GetData(m_DProject);
	excelReader.Read(dlg.GetPathName(), m_DProject.m_nTZS, m_DProject.m_nInputUnit, &m_DProject);
	m_pParam->SetData(FALSE, m_DProject);
*/
}


void CPaneRecipeGen::OnClickTabRecipe(NMHDR* pNMHDR, LRESULT* pResult) 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	int nSel = m_tabRecipe.GetCurSel();

	if( nSel == m_nPaneNo )
		return;
	
	WPARAM wParam = RECIPE_GEN;
	LPARAM lParam = nSel;
	::AfxGetMainWnd()->PostMessage( CHANGE_SUB_PANE, wParam, lParam );
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, FALSE);
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_LPC, FALSE);
	m_nPaneNo = nSel;




	switch( nSel )
	{
	case 0: // GenData
		m_pDataLoad->SetFocus();
		m_pFiducialNew->DestroyTimer();
		m_pDataLoad->SetProject(&m_DProject);
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
	case 1 : // Layout
		m_pLayout->SetFocus();
		m_pFiducialNew->DestroyTimer();
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
		//	case 2 : // Drill Method & PCB Division
		//		m_pDrillMethod->SetFocus();
		//		break;
	case 2 : // Parameter
		m_pParamNew->UpdateList(0,0);
		m_pParamNew->SetFocus();
		
		m_pFiducialNew->DestroyTimer();
		if(!bSideVision)
		{
			m_pParamNew->ConnectView();
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
	case 3 : // Fiducial
		m_pFiducialNew->SetFocus();
		
		m_pFiducialNew->InitTimer();
		if(!bSideVision)
		{
			m_pFiducialNew->ConnectView();
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
			}
		}

		#ifndef __USE_COGNEX_SOCKET__
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, TRUE);
		#else
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, FALSE);
		#endif

		m_pLayout->GetData(m_DProject);
		m_pFiducialNew->SetData(m_DProject, FALSE);
		break;
	case 4 : // Fiducial
		m_pFiducialNew->DestroyTimer();

		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
	case 5 : // skiving Fiducial
		m_pFiducialNew->DestroyTimer();

		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
	}
	
	*pResult = 0;
}

void CPaneRecipeGen::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

BOOL CPaneRecipeGen::SaveProject(CString strPath)
{
	if(FALSE == m_pLayout->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}

	if(FALSE == m_pParamNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pFiducialNew->CheckFidData())
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}


	// - 조건 검사
	int nResult = m_DProject.IsValidParameter();
	
	if(nResult == NONE_SUBPARAM)
	{
		ErrMessage(IDS_DATA_NO_SUB);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == LINE_DOT_MISMATCH)
	{
		ErrMessage(IDS_DATA_MISMATCH);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == DIFF_SUB_TYPE)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BARCODE_SIZE_ERROR)
	{
		ErrMessage(IDS_DATA_BARCODE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == APERTURE_COUNT_ERROR)
	{
		ErrMessage(IDS_DATA_APERTURE_COUNT);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BLOCK_DATA_ERROR)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else
	{
	}
	
	if(!m_DProject.m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		m_pDataLoad->Invalidate(FALSE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}	
	
	int nModeCalcual = gDProject.GetChangeFieldMode(m_DProject);
	
	if((m_DProject.m_nDataLoadStep & 0x0b) >= LOAD_EXCELLON) // 20091029
	{
		if(nModeCalcual == FIELD_CHANGE)
		{
			if(!m_DProject.CheckUnitSize())
			{
				ErrMessage(IDS_DATA_UNIT_SIZE);
				return FALSE;
			}
			if(!m_DProject.PuzzleOut())
			{
				ErrMessage(IDS_DATA_CALCULATION);
				return FALSE;
			}
			m_pDataLoad->Invalidate(FALSE);
		}
		else if (nModeCalcual == FIELD_AXIS_CHANGE)
			m_DProject.PuzzleOutOnlyAxisTrans();
		else
		{
		}
	}
	//
#ifdef __KUNSAN_SAMSUNG_LARGE__
	SetDutyOffset();
#endif

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(strPath, CFile::modeWrite|CFile::modeCreate))
		{
			m_pDataLoad->SetFocus();
			return FALSE;
		}
		
		CString strMessage, strChange;
		strChange = gDProject.GetChangeValue(m_DProject);
		strMessage.Format(_T("Project is saved"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strChange));

		int a = gDProject.m_Glyphs.GetTotalHoleCount();
		int b = m_DProject.m_Glyphs.GetTotalHoleCount();

		gDProject.ChangeMarkingParam(m_DProject, strPath);
		gDProject = m_DProject;

		int c = gDProject.m_Glyphs.GetTotalHoleCount();
		int d = m_DProject.m_Glyphs.GetTotalHoleCount();

		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();
		if(m_pDataLoad->m_bExcellonChange)//strcmp(gDProject.m_szFileName, "Untitle.txt") == 0)
		{
			strcpy_s(gDProject.m_szFileName, gDProject.m_szTempFileName);
			strcpy_s(m_DProject.m_szFileName, gDProject.m_szTempFileName);
		}
	
		CArchiveMark ar(&file, CArchive::store);
		gDProject.Serialize(ar, 10000);
	}
	CATCH (CException, e)
	{
		e->Delete();
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	END_CATCH

	m_pDataLoad->SetFocus();
	m_pDataLoad->m_bExcellonChange = FALSE;
	return TRUE;
}
BOOL CPaneRecipeGen::CheckSameName(CString strPath)
{
	BOOL bExist;
	CFileFind find;
	bExist = find.FindFile(strPath);
	if(bExist)
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CPaneRecipeGen::SetData()
{
	CString str;
	str.Format(_T("  %s"), gDProject.m_szFileName);
	strcpy_s(m_DProject.m_szFileName, gDProject.m_szFileName);
	SetDlgItemText(IDC_STATIC_CAD_PATH, (LPCTSTR)str);


	m_DProject = gDProject;

	m_pDataLoad->SetProject(&m_DProject);
	gDUndoRedo.Initialize(&m_DProject);

	if(FALSE == m_pLayout->SetData())
		return FALSE;
//	if(FALSE == m_pDrillMethod->SetData())
//		return FALSE;
//	if(FALSE == m_pParam->SetData(TRUE, m_DProject))
//		return FALSE;
	if(m_nPaneNo != 2)
		m_pParamNew->m_bConnectVision = FALSE;
	if(FALSE == m_pParamNew->SetData(m_DProject))
		return FALSE;
	if(FALSE == m_pFiducialNew->SetData(m_DProject, FALSE))
		return FALSE;

/*	if(FALSE == m_pParamNewNext->SetData(m_DProject))
		return FALSE;
*/
	m_pDataLoad->m_bExcellonChange = FALSE;
	return TRUE;
}

BOOL CPaneRecipeGen::OpenProject(CString strPath)
{
	CStdioFile file, fileSave;
	TRY
	{
		if (FALSE == file.Open(strPath, CFile::modeRead))
		{
			m_pDataLoad->SetFocus();
			return FALSE;
		}

		if (file.GetLength() < 1)
		{
			file.Close();
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		BOOL bRes = gDProject.Serialize(ar, 10000);	
		file.Close();



		if(!bRes)
		{
			m_pDataLoad->SetFocus();
			m_pDataLoad->ResetProject();
//			file.Close();
			return FALSE;
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		m_pDataLoad->SetFocus();
		m_pDataLoad->ResetProject();
		return FALSE;
	}
	END_CATCH

	if(!SetData())
	{
		m_pDataLoad->SetFocus();
		m_pDataLoad->ResetProject();
//		file.Close();
		return FALSE;
	}

	m_pDataLoad->SetDrawRect();

	m_pDataLoad->SetFocus();
	m_pDataLoad->ClearFiducialIndex();

	SetWindowForSkiving(TRUE);

	gDUndoRedo.Clear();

	gVariable.m_bOpenProject = TRUE;

#ifdef __KUNSAN_SAMSUNG_LARGE__
		GetDutyOffset();
#endif
	
//	file.Close();
	//gDProject.m_dScaleTolerance2 = gProcessINI.m_sProcessFidFind.dRefScale; //데이터 열때 0.02로 무조건 초기화
	m_pLayout->SetData();
	gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit = gProcessINI.m_sProcessFidFind.dRefLengthTol;
	gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 = gProcessINI.m_sProcessFidFind.dRefLengthTol2;
	m_pDataLoad->m_bExcellonChange = FALSE;

	return TRUE;
}

BOOL CPaneRecipeGen::ApplyProject()
{

//	if(FALSE == m_pDrillMethod->GetData())
//		return FALSE;
//	if(FALSE == m_pParam->GetData(m_DProject))
//		return FALSE;
/*	if(FALSE == m_pParamNewNext->GetData())
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	m_pParamNewNext->CheckAnyDoPrework();
*/
	if(FALSE == m_pFiducialNew->CheckFidData())
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pLayout->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	if(FALSE == m_pParamNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}


	int nResult = m_DProject.IsValidParameter();

	if(nResult == NONE_SUBPARAM)
	{
		ErrMessage(IDS_DATA_NO_SUB);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == LINE_DOT_MISMATCH)
	{
		ErrMessage(IDS_DATA_MISMATCH);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == DIFF_SUB_TYPE)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BARCODE_SIZE_ERROR)
	{
		ErrMessage(IDS_DATA_BARCODE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == APERTURE_COUNT_ERROR)
	{
		ErrMessage(IDS_DATA_APERTURE_COUNT);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else if(nResult == BLOCK_DATA_ERROR)
	{
		ErrMessage(IDS_DATA_TYPE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
	else
	{
	}

	if(!m_DProject.m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		m_pDataLoad->Invalidate(FALSE);
		m_pDataLoad->SetFocus();
		return FALSE;
	}	

	int nModeCalcual = gDProject.GetChangeFieldMode(m_DProject);


	if(nModeCalcual == FIELD_CHANGE)
	{
		if(!m_DProject.CheckUnitSize())
		{
			ErrMessage(IDS_DATA_UNIT_SIZE);
			return FALSE;
		}
		if(!m_DProject.PuzzleOut())
		{
			ErrMessage(IDS_DATA_CALCULATION);
			return FALSE;
		}
	}
	else if (nModeCalcual == FIELD_AXIS_CHANGE)
		m_DProject.PuzzleOutOnlyAxisTrans();



/* unit 단위로 개념 바뀌면서 사용안함
	if(!m_DProject.IsValidFiducialIndex() && m_DProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX) > 4)
	{
		ErrMessage(IDS_DATA_FIDUCIAL);
		m_pDataLoad->SetFocus();
		return FALSE;
	}
*/

#ifdef __KUNSAN_SAMSUNG_LARGE__
		SetDutyOffset();
		//gDeviceFactory.GetMotor()->SetTrunPanel(m_DProject.m_bUseTurn);
		//gDeviceFactory.GetMotor()->SetTrunPanel(gProcessINI.m_sProcessSystem.bUseTurnPanel);
		gDeviceFactory.GetMotor()->SetPCBSize(m_DProject.m_nVacuumType);
#endif

	CString strMessage, strChange;
	strChange = gDProject.GetChangeValue(m_DProject);
	
	if(m_pDataLoad->m_bExcellonChange)//strcmp(gDProject.m_szFileName, "Untitle.txt") == 0)
	{
		strcpy_s(m_DProject.m_szFileName, m_DProject.m_szTempFileName);
	}
	else
	{
		strcpy_s(m_DProject.m_szTempFileName, m_DProject.m_szFileName);
	}
	CString strTemp;
	strTemp.Format(_T("%s"), gDProject.m_szProjectName);
	gDProject.ChangeMarkingParam(m_DProject, strTemp);

	

	gDProject = m_DProject;



	if(m_pDataLoad->m_bExcellonChange)
	{
		time_t	timeEnd;
		time(&timeEnd);
		gOPCParam.nSwitchUpdateTime[N_SWITCH_DATA] = (int)timeEnd;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_SWITCH, N_SWITCH_DATA);
	}

	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
	

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();
	
	 strTemp.Format(_T("%s"), gDProject.m_szLotId);
	//change prj 미사용
	//if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CHANGE, reinterpret_cast<LPARAM>(&strTemp)))
	//	return FALSE;

	m_pDataLoad->SetFocus();
	m_pDataLoad->m_bExcellonChange = FALSE;

	strMessage.Format(_T("Project is applyed"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strChange));
	
	gDProject.MonitoringHoleCount();


	return TRUE;
}

void CPaneRecipeGen::SetFocusViewer()
{
	m_pDataLoad->SetFocus();
}

void CPaneRecipeGen::SetAuthorityByLevel(int nLevel)
{
	if(m_pDataLoad != NULL)
		m_pDataLoad->SetAuthorityByLevel(nLevel);
	
	if(m_pLayout != NULL)
		m_pLayout->SetAuthorityByLevel(nLevel);
	
	if(m_pParamNew != NULL)
		m_pParamNew->SetAuthorityByLevel(nLevel);

	if(m_pFiducialNew != NULL)
		m_pFiducialNew->SetAuthorityByLevel(nLevel);
}

void CPaneRecipeGen::SetWindowForSkiving(BOOL bSkiving)
{
	m_pLayout->EnableSkivingHeight(bSkiving);
//	if(m_pFiducialSkiving)
//		m_pFiducialSkiving->EnableAllWindow(bSkiving);
}

void CPaneRecipeGen::SetDataLoadStep(int nStep)
{
	m_DProject.m_nDataLoadStep = nStep;
}

void CPaneRecipeGen::OnMoveVisionView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		if(m_nPaneNo == 2)
			m_pParamNew->OnMoveVisionView();
		else
			m_pFiducialNew->OnMoveVisionView();
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		if(m_nPaneNo == 2)
			m_pParamNew->OnMoveVisionView();
		else
			m_pFiducialNew->OnMoveVisionView();
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(MAIN_VISION_VIEW);
		
		//		CRect rtPos;
		if(m_nPaneNo == 2)
			m_pParamNew->OnMoveVisionView();
		else
			m_pFiducialNew->OnMoveVisionView();
		//		GetDlgItem(IDC_STATIC_MAIN_OMI_VIEW)->GetWindowRect( rtPos );
		//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}
void CPaneRecipeGen::SetShowPane(int nPaneNo)
{
	/*
	m_nPaneNo = nPaneNo;
	m_tabRecipe.ShowPane( m_nPaneNo );
	int nSelectFidIndex = m_pFiducialNew->GetFiducialIndex(gVariable.m_nSelectFidNo, gVariable.m_nSelectBlockNo);
	if(nSelectFidIndex == -1)
		return;
	m_pFiducialNew->ChangeSelectDisplay(nSelectFidIndex);
	*///임시임시
}
void CPaneRecipeGen::ShowTabPane(int nPaneNo)
{
	m_nPaneNo = nPaneNo;

	switch(nPaneNo)
	{
	case 2:
		m_pParamNew->SetFocus();
		m_pParamNew->ConnectView();
		m_pFiducialNew->DestroyTimer();
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
		else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
		else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		break;
	case 3:
		m_pFiducialNew->SetFocus();
		m_pFiducialNew->ConnectView();
		m_pFiducialNew->InitTimer();
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
		else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
		else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
		}
		break;
	default:
		m_pFiducialNew->DestroyTimer();
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
		else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
		else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		break;
	}
}

BOOL CPaneRecipeGen::SortArea()
{
	if(FALSE == m_pFiducialNew->GetData(m_DProject))
	{
		m_pDataLoad->SetFocus();
		return FALSE;
	}

	int nStartFidBlock, nEndFidBlock;
	if(m_DProject.m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; 
		nEndFidBlock = m_DProject.m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1; 
	}

	int nIndex = 0, nTempIndex;
	for(int i = nStartFidBlock; i <= nEndFidBlock; i++)
	{
		m_DProject.ResetToolSumUsedFlag();
		
		if(!gProcessINI.m_sProcessSystem.bNoSortArea)
		{
			if(!m_DProject.SortArea(i, nIndex, nTempIndex))
			{
				m_DProject.RemoveAreaList();
				return FALSE;
			}
			nIndex = nTempIndex;
		}
	}
	return TRUE;
}
void CPaneRecipeGen::GetDutyOffset()
{
	for(int i= 0; i<MAX_TOOL_NO; i++)
	{
		gDProject.m_pToolCode[i]->GetDutyOffsetfromMDB();
	}
}
	
void CPaneRecipeGen::SetDutyOffset()
{
	for(int i= 0; i<MAX_TOOL_NO; i++)
	{
		m_DProject.m_pToolCode[i]->SetDutyOffsettoMDB();
	}
}

void CPaneRecipeGen::EnableTab(BOOL bEnable)
{
	m_tabRecipe.TabChangeEnable(bEnable);
}
