// PaneSysSetupComponentTimeAlarm.cpp : implementation file
//

#include "stdafx.h"
#include "easydriller.h"
#include "PaneSysSetupComponentTimeAlarm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupComponentTimeAlarm dialog


CPaneSysSetupComponentTimeAlarm::CPaneSysSetupComponentTimeAlarm(CWnd* pParent /*=NULL*/)
	: CDialog(CPaneSysSetupComponentTimeAlarm::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPaneSysSetupComponentTimeAlarm)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT


}


void CPaneSysSetupComponentTimeAlarm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupComponentTimeAlarm)
	DDX_Control(pDX, IDC_LIST, m_lShow);
	DDX_Control(pDX, IDC_EDIT_PREACQTIME, m_edtExpireTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupComponentTimeAlarm, CDialog)
	//{{AFX_MSG_MAP(CPaneSysSetupComponentTimeAlarm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupComponentTimeAlarm message handlers

BOOL CPaneSysSetupComponentTimeAlarm::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_lShow.InsertColumn(0, _T("Device"), LVCFMT_CENTER, 160);
	m_lShow.InsertColumn(1, _T("StartDate"), LVCFMT_CENTER, 120); 
	m_lShow.InsertColumn(2, _T("ExpiryDate"), LVCFMT_CENTER, 80);
	m_lShow.InsertColumn(3, _T("Warranty Period"), LVCFMT_CENTER, 120);
	m_lShow.InsertColumn(4, _T("alarm date"), LVCFMT_CENTER, 120);

	m_lShow.ModifyStyle(LVS_TYPEMASK, LVS_REPORT);
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
//cAlarm->AddItem(strC, strStrartDate, strE, strUsingDate, strAlarmDate);
void CPaneSysSetupComponentTimeAlarm::AddItem(CString strC, CString strStrartDate, CString strE, CString strUsingDate, CString strAlarmDate )
{
	CString strData;
//	int nNo = m_lShow.GetItemCount();
	LV_ITEM lvitem;
	
	lvitem.iItem = 0;
	lvitem.mask = LVIF_TEXT;
	lvitem.iSubItem = 0;
	strData.Format(_T("%s"), strC);
	lvitem.pszText = (LPSTR)(LPCTSTR)strData;
	m_lShow.InsertItem(&lvitem);


	m_lShow.SetItemText(lvitem.iItem,1,strStrartDate);
	m_lShow.SetItemText(lvitem.iItem,2,strE);
	m_lShow.SetItemText(lvitem.iItem,3,strUsingDate);
	m_lShow.SetItemText(lvitem.iItem,4,strAlarmDate);

}



void CPaneSysSetupComponentTimeAlarm::SetPreAcqtime(int PreAcqTime)
{
	CString str;
	str.Format(_T("%d"),PreAcqTime);
	m_edtExpireTime.SetWindowText(str);

}
