#if !defined(AFX_PANEMANUALCONTROLSCANNERCALIBRATIONPOS_H__18EC3EBD_0C9C_4E25_8107_5EA74D83B068__INCLUDED_)
#define AFX_PANEMANUALCONTROLSCANNERCALIBRATIONPOS_H__18EC3EBD_0C9C_4E25_8107_5EA74D83B068__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlScannerCalibrationPos.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibrationPos form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\device\CalibrationPath.h"
#include "..\device\hvisionomi.h"

class CPaneManualControlScannerCalibrationPos : public CFormView
{
protected:
	CPaneManualControlScannerCalibrationPos();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlScannerCalibrationPos)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlScannerCalibrationPos)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_SCANNER_CAL_BYPOS };
	CColorEdit		m_edtContrast;
	CColorEdit		m_edtBrightness;
	CColorEdit		m_edtRing;
	CColorEdit		m_edtCoaxial;
	CColorEdit		m_edtSize;
	CColorEdit		m_edtAngle;
	CColorEdit		m_edtAspectRatio;
	CColorEdit		m_edtModelOrientation;
	CColorEdit		m_edtModelSize;
	CColorEdit		m_edtManualYPos;
	CColorEdit		m_edtManualXPos;
	CColorEdit		m_edtManual2ndThickness;
	CColorEdit		m_edtManual1stThickness;
	CColorEdit		m_edtManualPulseWidth;
	CColorEdit		m_edtManualGridX;
	CColorEdit		m_edtManualGridY;
	CColorEdit		m_edtManualGap;
	CComboBox		m_cmbUseVision;
	CComboBox		m_cmbManualMask;
	CComboBox		m_cmbManualHead;
	CComboBox		m_cmbManualMode;
	CListBox		m_lboxResult;
	UEasyButtonEx	m_chkInspArea;
	UEasyButtonEx	m_btnCalStop;
	UEasyButtonEx	m_btnCalStart;
	CColorStatic	m_stcVisionResult;
	int				m_nPolarity;
	//}}AFX_DATA

// Attributes
public:
	SPROCESSSCANNERCAL m_sProcessScannerCal;
	SVISIONINFO		m_sVisionInfo;
	CFont			m_fntBtn;
	CFont			m_fntEdit;
	CFont			m_fntStatic;
	CFont			m_fntListBox;
	CFont			m_fntCombo;
	
	int				m_nCoaxial[4];
	int				m_nRing[4];
	double			m_dContrast[4];
	double			m_dBrightness[4];

	double			m_dStartX;
	double			m_dStartY;
	double			m_dCalGap;
	int				m_nCalGridX;
	int				m_nCalGridY;
	int				m_nProcessMode;

// Operations
public:
	void			SetControlToData();
	void			SetProcessScannerCal(SPROCESSSCANNERCAL sProcessScannerCal);
	void			DispProcessScannerCal();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitListBoxControl();
	void			InitComboControl();
	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			OnMoveVisionView();
	void			SetValue(int nNumber);
	void			SetVisionInfo(void);
	void			EnableCalibrationWindow(BOOL bIsEnable);
	void			WriteCalibrationStopEvent(BOOL bFinish = FALSE);
	void			EnableAutoCalibrationResource(BOOL bEnable = TRUE);
	BOOL			ChangeMask(void);
	BOOL			CheckAllMotorPositionValidity();
	BOOL			IsOutOfAxisValidity(int nAxis, double dVal);
	void			CameraChange(int nCam);
	void			ScannerMoveToCenter();
	void			ApplyVisionParam(int nCam);
	void			StopProcess();
	
	CCalibrationPath* GetMasterPath()	{return &m_CalMasterPath;};
	CCalibrationPath* GetSlavePath()	{return &m_CalSlavePath;};

	CCalibrationPath m_CalMasterPath;
	CCalibrationPath m_CalSlavePath;

	BOOL SearchAndApply();
	BOOL Comparison();
	BOOL MoveAndFire();
	BOOL m_bStartCalPos;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlScannerCalibrationPos)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlScannerCalibrationPos();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlScannerCalibrationPos)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonCalStart();
	afx_msg void OnButtonCalStop();
	afx_msg void OnDestroy();
	afx_msg void OnSelchangeComboUseVision();
	afx_msg void OnKillfocusEdit();
	afx_msg void OnInspectionArea();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLSCANNERCALIBRATIONPOS_H__18EC3EBD_0C9C_4E25_8107_5EA74D83B068__INCLUDED_)
