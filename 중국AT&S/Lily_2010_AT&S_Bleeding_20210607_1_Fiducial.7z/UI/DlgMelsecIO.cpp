// D:\Source\2010_ver\Lily_2010\UI\DlgMelsecIO.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgMelsecIO.h"
#include "afxdialogex.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\DeviceMotor.h"


// CDlgMelsecIO ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgMelsecIO, CDialog)

CDlgMelsecIO::CDlgMelsecIO(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMelsecIO::IDD, pParent)
{
	m_nTimer = -1;
}

CDlgMelsecIO::~CDlgMelsecIO()
{
}

void CDlgMelsecIO::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//  DDX_Control(pDX, IDC_STATIC_1050, m_1050);
	DDX_Control(pDX, IDC_STATIC_1050, m_stc1050);
	DDX_Control(pDX, IDC_STATIC_1051, m_stc1051);
	DDX_Control(pDX, IDC_STATIC_1052, m_stc1052);
	DDX_Control(pDX, IDC_STATIC_1053, m_stc1053);
	DDX_Control(pDX, IDC_STATIC_1054, m_stc1054);
	DDX_Control(pDX, IDC_STATIC_1056, m_stc1056);
	DDX_Control(pDX, IDC_STATIC_1057, m_stc1057);
	DDX_Control(pDX, IDC_STATIC_1060_0, m_stc1060_0);
	DDX_Control(pDX, IDC_STATIC_1060_1, m_stc1060_1);
	DDX_Control(pDX, IDC_STATIC_1060_10, m_stc1060_10);
	DDX_Control(pDX, IDC_STATIC_1060_11, m_stc1060_11);
	DDX_Control(pDX, IDC_STATIC_1060_12, m_stc1060_12);
	DDX_Control(pDX, IDC_STATIC_1060_13, m_stc1060_13);
	DDX_Control(pDX, IDC_STATIC_1060_14, m_stc1060_14);
	DDX_Control(pDX, IDC_STATIC_1060_15, m_stc1060_15);
	DDX_Control(pDX, IDC_STATIC_1060_2, m_stc1060_2);
	DDX_Control(pDX, IDC_STATIC_1060_3, m_stc1060_3);
	DDX_Control(pDX, IDC_STATIC_1060_4, m_stc1060_4);
	DDX_Control(pDX, IDC_STATIC_1060_5, m_stc1060_5);
	DDX_Control(pDX, IDC_STATIC_1060_6, m_stc1060_6);
	DDX_Control(pDX, IDC_STATIC_1060_7, m_stc1060_7);
	DDX_Control(pDX, IDC_STATIC_1060_8, m_stc1060_8);
	DDX_Control(pDX, IDC_STATIC_1060_9, m_stc1060_9);
	DDX_Control(pDX, IDC_STATIC_1061_0, m_stc1061_0);
	DDX_Control(pDX, IDC_STATIC_1061_10, m_stc1061_10);
	DDX_Control(pDX, IDC_STATIC_1061_11, m_stc1061_11);
	DDX_Control(pDX, IDC_STATIC_1061_14, m_stc1061_14);
	DDX_Control(pDX, IDC_STATIC_1061_15, m_stc1061_15);
	DDX_Control(pDX, IDC_STATIC_1061_2, m_stc1061_2);
	DDX_Control(pDX, IDC_STATIC_1061_3, m_stc1061_3);
	DDX_Control(pDX, IDC_STATIC_1061_4, m_stc1061_4);
	DDX_Control(pDX, IDC_STATIC_1061_5, m_stc1061_5);
	DDX_Control(pDX, IDC_STATIC_1061_6, m_stc1061_6);
	DDX_Control(pDX, IDC_STATIC_1061_7, m_stc1061_7);
	DDX_Control(pDX, IDC_STATIC_1061_8, m_stc1061_8);
	DDX_Control(pDX, IDC_STATIC_1062_0, m_stc1062_0);
	DDX_Control(pDX, IDC_STATIC_1062_1, m_stc1062_1);
	DDX_Control(pDX, IDC_STATIC_1062_10, m_stc1062_10);
	DDX_Control(pDX, IDC_STATIC_1062_11, m_stc1062_11);
	DDX_Control(pDX, IDC_STATIC_1062_12, m_stc1062_12);
	DDX_Control(pDX, IDC_STATIC_1062_14, m_stc1062_14);
	DDX_Control(pDX, IDC_STATIC_1062_15, m_stc1062_15);
	DDX_Control(pDX, IDC_STATIC_1062_2, m_stc1062_2);
	DDX_Control(pDX, IDC_STATIC_1062_3, m_stc1062_3);
	DDX_Control(pDX, IDC_STATIC_1062_6, m_stc1062_6);
	DDX_Control(pDX, IDC_STATIC_1062_7, m_stc1062_7);
	DDX_Control(pDX, IDC_STATIC_1062_8, m_stc1062_8);
	DDX_Control(pDX, IDC_STATIC_1062_9, m_stc1062_9);
	DDX_Control(pDX, IDC_STATIC_1063_11, m_stc1063_11);
	DDX_Control(pDX, IDC_STATIC_1063_12, m_stc1063_12);
	DDX_Control(pDX, IDC_STATIC_1063_0, m_stc1063_0);
	DDX_Control(pDX, IDC_STATIC_1063_1, m_stc1063_1);
	DDX_Control(pDX, IDC_STATIC_1063_10, m_stc1063_10);

	DDX_Control(pDX, IDC_STATIC_1063_13, m_stc1063_13);
	DDX_Control(pDX, IDC_STATIC_1063_14, m_stc1063_14);
	DDX_Control(pDX, IDC_STATIC_1063_15, m_stc1063_15);
	DDX_Control(pDX, IDC_STATIC_1063_2, m_stc1063_2);
	DDX_Control(pDX, IDC_STATIC_1063_3, m_stc1063_3);
	DDX_Control(pDX, IDC_STATIC_1063_4, m_stc1063_4);
	DDX_Control(pDX, IDC_STATIC_1063_5, m_stc1063_5);
	DDX_Control(pDX, IDC_STATIC_1063_6, m_stc1063_6);
	DDX_Control(pDX, IDC_STATIC_1063_7, m_stc1063_7);
	DDX_Control(pDX, IDC_STATIC_1063_8, m_stc1063_8);
	DDX_Control(pDX, IDC_STATIC_1063_9, m_stc1063_9);
	DDX_Control(pDX, IDC_STATIC_1070, m_stc1070);
	DDX_Control(pDX, IDC_STATIC_1071, m_stc1071);
	DDX_Control(pDX, IDC_STATIC_1072, m_stc1072);
	DDX_Control(pDX, IDC_STATIC_1073, m_stc1073);
	DDX_Control(pDX, IDC_STATIC_1074, m_stc1074);
	DDX_Control(pDX, IDC_STATIC_1075, m_stc1075); 
	DDX_Control(pDX, IDC_STATIC_5432, m_stc5432);
	DDX_Control(pDX, IDC_STATIC_5433, m_stc5433);
	DDX_Control(pDX, IDC_STATIC_5434, m_stc5434);
	DDX_Control(pDX, IDC_STATIC_5435, m_stc5435);
	DDX_Control(pDX, IDC_STATIC_5436, m_stc5436);
	DDX_Control(pDX, IDC_STATIC_5437, m_stc5437);
	DDX_Control(pDX, IDC_STATIC_5438, m_stc5438);
	DDX_Control(pDX, IDC_STATIC_5439, m_stc5439);
	DDX_Control(pDX, IDC_STATIC_5440, m_stc5440);
	DDX_Control(pDX, IDC_STATIC_5441, m_stc5441);
	DDX_Control(pDX, IDC_STATIC_5442, m_stc5442);
	DDX_Control(pDX, IDC_STATIC_5443, m_stc5443);
	DDX_Control(pDX, IDC_STATIC_5444, m_stc5444);
	DDX_Control(pDX, IDC_STATIC_5445, m_stc5445);
	DDX_Control(pDX, IDC_STATIC_5446, m_stc5446);
	DDX_Control(pDX, IDC_STATIC_5447, m_stc5447);
	DDX_Control(pDX, IDC_STATIC_5448, m_stc5448);
	DDX_Control(pDX, IDC_STATIC_5449, m_stc5449);
	DDX_Control(pDX, IDC_STATIC_5450, m_stc5450);
	DDX_Control(pDX, IDC_STATIC_5451, m_stc5451);
}


BEGIN_MESSAGE_MAP(CDlgMelsecIO, CDialog)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_WM_PAINT()
END_MESSAGE_MAP()

// CDlgMelsecIO �޽��� ó�����Դϴ�.

HBRUSH CDlgMelsecIO::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_INPUT)->GetSafeHwnd() == pWnd->m_hWnd )
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	return hbr;
}

BOOL CDlgMelsecIO::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitStatic();

	if(m_nTimer == -1)
		m_nTimer = SetTimer( 870529, 500, NULL);

	return TRUE;  
}

void CDlgMelsecIO::OnDestroy()
{
	CDialog::OnDestroy();

	if(m_nTimer != -1)
	{
		KillTimer(m_nTimer);
		m_nTimer = -1;
	}
}
void CDlgMelsecIO::InitStatic()
{
	m_stc1050.SetForeColor(BLACK_COLOR);
	m_stc1050.SetBackColor(GRAY_COLOR);

	m_stc1051.SetForeColor(BLACK_COLOR);
	m_stc1051.SetBackColor(GRAY_COLOR);

	m_stc1052.SetForeColor(BLACK_COLOR);
	m_stc1052.SetBackColor(GRAY_COLOR);

	m_stc1053.SetForeColor(BLACK_COLOR);
	m_stc1053.SetBackColor(GRAY_COLOR);

	m_stc1053.SetForeColor(BLACK_COLOR);
	m_stc1053.SetBackColor(GRAY_COLOR);

	m_stc1054.SetForeColor(BLACK_COLOR);
	m_stc1054.SetBackColor(GRAY_COLOR);

	m_stc1056.SetForeColor(BLACK_COLOR);
	m_stc1056.SetBackColor(GRAY_COLOR);

	m_stc1057.SetForeColor(BLACK_COLOR);
	m_stc1057.SetBackColor(GRAY_COLOR);

	m_stc1060_0.SetForeColor(BLACK_COLOR);
	m_stc1060_0.SetBackColor(GRAY_COLOR);

	m_stc1060_1.SetForeColor(BLACK_COLOR);
	m_stc1060_1.SetBackColor(GRAY_COLOR);

	m_stc1060_10.SetForeColor(BLACK_COLOR);
	m_stc1060_10.SetBackColor(GRAY_COLOR);

	m_stc1060_11.SetForeColor(BLACK_COLOR);
	m_stc1060_11.SetBackColor(GRAY_COLOR);

	m_stc1060_12.SetForeColor(BLACK_COLOR);
	m_stc1060_12.SetBackColor(GRAY_COLOR);

	m_stc1060_13.SetForeColor(BLACK_COLOR);
	m_stc1060_13.SetBackColor(GRAY_COLOR);

	m_stc1060_14.SetForeColor(BLACK_COLOR);
	m_stc1060_14.SetBackColor(GRAY_COLOR);

	m_stc1060_15.SetForeColor(BLACK_COLOR);
	m_stc1060_15.SetBackColor(GRAY_COLOR);

	m_stc1060_2.SetForeColor(BLACK_COLOR);
	m_stc1060_2.SetBackColor(GRAY_COLOR);

	m_stc1060_3.SetForeColor(BLACK_COLOR);
	m_stc1060_3.SetBackColor(GRAY_COLOR);
	m_stc1060_4.SetForeColor(BLACK_COLOR);
	m_stc1060_4.SetBackColor(GRAY_COLOR);

	m_stc1060_5.SetForeColor(BLACK_COLOR);
	m_stc1060_5.SetBackColor(GRAY_COLOR);

	m_stc1060_6.SetForeColor(BLACK_COLOR);
	m_stc1060_6.SetBackColor(GRAY_COLOR);

	m_stc1060_7.SetForeColor(BLACK_COLOR);
	m_stc1060_7.SetBackColor(GRAY_COLOR);

	m_stc1060_8.SetForeColor(BLACK_COLOR);
	m_stc1060_8.SetBackColor(GRAY_COLOR);

	m_stc1060_9.SetForeColor(BLACK_COLOR);
	m_stc1060_9.SetBackColor(GRAY_COLOR);

	m_stc1061_0.SetForeColor(BLACK_COLOR);
	m_stc1061_0.SetBackColor(GRAY_COLOR);

	m_stc1061_10.SetForeColor(BLACK_COLOR);
	m_stc1061_10.SetBackColor(GRAY_COLOR);

	m_stc1061_11.SetForeColor(BLACK_COLOR);
	m_stc1061_11.SetBackColor(GRAY_COLOR);

	m_stc1061_14.SetForeColor(BLACK_COLOR);
	m_stc1061_14.SetBackColor(GRAY_COLOR);

	m_stc1061_15.SetForeColor(BLACK_COLOR);
	m_stc1061_15.SetBackColor(GRAY_COLOR);

	m_stc1061_2.SetForeColor(BLACK_COLOR);
	m_stc1061_2.SetBackColor(GRAY_COLOR);

	m_stc1061_3.SetForeColor(BLACK_COLOR);
	m_stc1061_3.SetBackColor(GRAY_COLOR);

	m_stc1061_4.SetForeColor(BLACK_COLOR);
	m_stc1061_4.SetBackColor(GRAY_COLOR);

	m_stc1061_5.SetForeColor(BLACK_COLOR);
	m_stc1061_5.SetBackColor(GRAY_COLOR);

	m_stc1061_6.SetForeColor(BLACK_COLOR);
	m_stc1061_6.SetBackColor(GRAY_COLOR);

	m_stc1061_7.SetForeColor(BLACK_COLOR);
	m_stc1061_7.SetBackColor(GRAY_COLOR);

	m_stc1061_8.SetForeColor(BLACK_COLOR);
	m_stc1061_8.SetBackColor(GRAY_COLOR);

	m_stc1062_0.SetForeColor(BLACK_COLOR);
	m_stc1062_0.SetBackColor(GRAY_COLOR);

	m_stc1062_1.SetForeColor(BLACK_COLOR);
	m_stc1062_1.SetBackColor(GRAY_COLOR);

	m_stc1062_10.SetForeColor(BLACK_COLOR);
	m_stc1062_10.SetBackColor(GRAY_COLOR);

	m_stc1062_11.SetForeColor(BLACK_COLOR);
	m_stc1062_11.SetBackColor(GRAY_COLOR);

	m_stc1062_12.SetForeColor(BLACK_COLOR);
	m_stc1062_12.SetBackColor(GRAY_COLOR);

	m_stc1062_14.SetForeColor(BLACK_COLOR);
	m_stc1062_14.SetBackColor(GRAY_COLOR);

	m_stc1062_15.SetForeColor(BLACK_COLOR);
	m_stc1062_15.SetBackColor(GRAY_COLOR);

	m_stc1062_2.SetForeColor(BLACK_COLOR);
	m_stc1062_2.SetBackColor(GRAY_COLOR);

	m_stc1062_3.SetForeColor(BLACK_COLOR);
	m_stc1062_3.SetBackColor(GRAY_COLOR);

	m_stc1062_6.SetForeColor(BLACK_COLOR);
	m_stc1062_6.SetBackColor(GRAY_COLOR);

	m_stc1062_7.SetForeColor(BLACK_COLOR);
	m_stc1062_7.SetBackColor(GRAY_COLOR);

	m_stc1062_8.SetForeColor(BLACK_COLOR);
	m_stc1062_8.SetBackColor(GRAY_COLOR);

	m_stc1062_9.SetForeColor(BLACK_COLOR);
	m_stc1062_9.SetBackColor(GRAY_COLOR);

	m_stc1063_0.SetForeColor(BLACK_COLOR);
	m_stc1063_0.SetBackColor(GRAY_COLOR);
	
	m_stc1063_1.SetForeColor(BLACK_COLOR);
	m_stc1063_1.SetBackColor(GRAY_COLOR);

	m_stc1063_10.SetForeColor(BLACK_COLOR);
	m_stc1063_10.SetBackColor(GRAY_COLOR);

	m_stc1063_11.SetForeColor(BLACK_COLOR);
	m_stc1063_11.SetBackColor(GRAY_COLOR);

	m_stc1063_12.SetForeColor(BLACK_COLOR);
	m_stc1063_12.SetBackColor(GRAY_COLOR);

	m_stc1063_13.SetForeColor(BLACK_COLOR);
	m_stc1063_13.SetBackColor(GRAY_COLOR);

	m_stc1063_14.SetForeColor(BLACK_COLOR);
	m_stc1063_14.SetBackColor(GRAY_COLOR);

	m_stc1063_15.SetForeColor(BLACK_COLOR);
	m_stc1063_15.SetBackColor(GRAY_COLOR);

	m_stc1063_2.SetForeColor(BLACK_COLOR);
	m_stc1063_2.SetBackColor(GRAY_COLOR);

	m_stc1063_3.SetForeColor(BLACK_COLOR);
	m_stc1063_3.SetBackColor(GRAY_COLOR);

	m_stc1063_4.SetForeColor(BLACK_COLOR);
	m_stc1063_4.SetBackColor(GRAY_COLOR);

	m_stc1063_5.SetForeColor(BLACK_COLOR);
	m_stc1063_5.SetBackColor(GRAY_COLOR);

	m_stc1063_6.SetForeColor(BLACK_COLOR);
	m_stc1063_6.SetBackColor(GRAY_COLOR);

	m_stc1063_7.SetForeColor(BLACK_COLOR);
	m_stc1063_7.SetBackColor(GRAY_COLOR);

	m_stc1063_8.SetForeColor(BLACK_COLOR);
	m_stc1063_8.SetBackColor(GRAY_COLOR);

	m_stc1063_9.SetForeColor(BLACK_COLOR);
	m_stc1063_9.SetBackColor(GRAY_COLOR);

	m_stc1070.SetForeColor(BLACK_COLOR);
	m_stc1070.SetBackColor(GRAY_COLOR);

	m_stc1071.SetForeColor(BLACK_COLOR);
	m_stc1071.SetBackColor(GRAY_COLOR);

	m_stc1072.SetForeColor(BLACK_COLOR);
	m_stc1072.SetBackColor(GRAY_COLOR);

	m_stc1073.SetForeColor(BLACK_COLOR);
	m_stc1073.SetBackColor(GRAY_COLOR);

	m_stc1074.SetForeColor(BLACK_COLOR);
	m_stc1074.SetBackColor(GRAY_COLOR);

	m_stc1075.SetForeColor(BLACK_COLOR);
	m_stc1075.SetBackColor(GRAY_COLOR);

	m_stc5432.SetForeColor(BLACK_COLOR);
	m_stc5432.SetBackColor(GRAY_COLOR);

	m_stc5433.SetForeColor(BLACK_COLOR);
	m_stc5433.SetBackColor(GRAY_COLOR);

	m_stc5434.SetForeColor(BLACK_COLOR);
	m_stc5434.SetBackColor(GRAY_COLOR);

	m_stc5435.SetForeColor(BLACK_COLOR);
	m_stc5435.SetBackColor(GRAY_COLOR);

	m_stc5436.SetForeColor(BLACK_COLOR);
	m_stc5436.SetBackColor(GRAY_COLOR);

	m_stc5437.SetForeColor(BLACK_COLOR);
	m_stc5437.SetBackColor(GRAY_COLOR);

	m_stc5438.SetForeColor(BLACK_COLOR);
	m_stc5438.SetBackColor(GRAY_COLOR);

	m_stc5439.SetForeColor(BLACK_COLOR);
	m_stc5439.SetBackColor(GRAY_COLOR);

	m_stc5440.SetForeColor(BLACK_COLOR);
	m_stc5440.SetBackColor(GRAY_COLOR);

	m_stc5441.SetForeColor(BLACK_COLOR);
	m_stc5441.SetBackColor(GRAY_COLOR);

	m_stc5442.SetForeColor(BLACK_COLOR);
	m_stc5442.SetBackColor(GRAY_COLOR);

	m_stc5443.SetForeColor(BLACK_COLOR);
	m_stc5443.SetBackColor(GRAY_COLOR);

	m_stc5444.SetForeColor(BLACK_COLOR);
	m_stc5444.SetBackColor(GRAY_COLOR);

	m_stc5445.SetForeColor(BLACK_COLOR);
	m_stc5445.SetBackColor(GRAY_COLOR);

	m_stc5446.SetForeColor(BLACK_COLOR);
	m_stc5446.SetBackColor(GRAY_COLOR);

	m_stc5447.SetForeColor(BLACK_COLOR);
	m_stc5447.SetBackColor(GRAY_COLOR);

	m_stc5448.SetForeColor(BLACK_COLOR);
	m_stc5448.SetBackColor(GRAY_COLOR);

	m_stc5449.SetForeColor(BLACK_COLOR);
	m_stc5449.SetBackColor(GRAY_COLOR);
	
	m_stc5450.SetForeColor(BLACK_COLOR);
	m_stc5450.SetBackColor(GRAY_COLOR);

	m_stc5451.SetForeColor(BLACK_COLOR);
	m_stc5451.SetBackColor(GRAY_COLOR);

	Invalidate(FALSE);
}
void CDlgMelsecIO::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent == m_nTimer)
	{
		ChangeDisplay();
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlgMelsecIO::ChangeDisplay()
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	PLC_BIT_SIGNAL_FX stSignal;
#else
	PLC_BIT_SIGNAL stSignal;
#endif
	stSignal = pMotor->GetMelsecIOStuct();

	if(stSignal.bInputLoadBasket)
		m_stc1050.SetForeColor(GREEN_COLOR);
	else
		m_stc1050.SetForeColor(BLACK_COLOR);

	if(stSignal.bOutputLoadBasket)
		m_stc1051.SetForeColor(GREEN_COLOR);
	else
		m_stc1051.SetForeColor(BLACK_COLOR);

	if(stSignal.bInputUnlodBasket)
		m_stc1052.SetForeColor(GREEN_COLOR);
	else
		m_stc1052.SetForeColor(BLACK_COLOR);

	if(stSignal.bOutputUnloadBasket)
		m_stc1053.SetForeColor(GREEN_COLOR);
	else
		m_stc1053.SetForeColor(BLACK_COLOR);

	if(stSignal.bChangeDirection)
		m_stc1054.SetForeColor(GREEN_COLOR);
	else
		m_stc1054.SetForeColor(BLACK_COLOR);
	//load pos 
	//unload pos 

	if(stSignal.bEStopAlarm)
		m_stc1060_0.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_0.SetForeColor(BLACK_COLOR);

	if(stSignal.bPLCBATAlarm)
		m_stc1060_1.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_1.SetForeColor(BLACK_COLOR);

	if(stSignal.bAirDownAlarm)
		m_stc1060_2.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_2.SetForeColor(BLACK_COLOR);

	if(stSignal.bDoorOpenAlarm)
		m_stc1060_3.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_3.SetForeColor(BLACK_COLOR);

	if(stSignal.bAxis1DriveAlarm)
		m_stc1060_4.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_4.SetForeColor(BLACK_COLOR);

	if(stSignal.bAxis2DriveAlarm)
		m_stc1060_5.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_5.SetForeColor(BLACK_COLOR);
	
	if(stSignal.bAxis3DriveAlarm)
		m_stc1060_6.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_6.SetForeColor(BLACK_COLOR);

	if(stSignal.bAxis1ControlAlarm)
		m_stc1060_7.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_7.SetForeColor(BLACK_COLOR);

	if(stSignal.bAxis2ControlAlarm)
		m_stc1060_8.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_8.SetForeColor(BLACK_COLOR);

	if(stSignal.bAxis3ControlAlarm)
		m_stc1060_9.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_9.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadLeftPicker1UpDownCYLAlarm)
		m_stc1060_10.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_10.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadLeftPicker2UpDownCYLAlarm)
		m_stc1060_11.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_11.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadLeftPickerVacuumAlarm)
		m_stc1060_12.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_12.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadRightPicker1UpDownCYLAlarm)
		m_stc1060_13.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_13.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadRightPicker2UpDownCYLAlarm)
		m_stc1060_14.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_14.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadRightPickerVacuumAlam)
		m_stc1060_15.SetForeColor(GREEN_COLOR);
	else
		m_stc1060_15.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadUnloadCollisionAlarm)
		m_stc1061_0.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_0.SetForeColor(BLACK_COLOR);

	if(stSignal.bLAlignTableForBackAlarm)
		m_stc1061_2.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_2.SetForeColor(BLACK_COLOR);

	if(stSignal.bLAlign1LeftAlarm)
		m_stc1061_3.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_3.SetForeColor(BLACK_COLOR);

	if(stSignal.bLAlign1FrontAlarm)
		m_stc1061_4.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_4.SetForeColor(BLACK_COLOR);

	if(stSignal.bLAlignPalteAlarm)
		m_stc1061_5.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_5.SetForeColor(BLACK_COLOR);

		if(stSignal.bLAlignROnOffAlarm)
		m_stc1061_6.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_6.SetForeColor(BLACK_COLOR);

	if(stSignal.bLCardLockAlarm)
		m_stc1061_7.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_7.SetForeColor(BLACK_COLOR);

	if(stSignal.bLLifterAlarm)
		m_stc1061_8.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_8.SetForeColor(BLACK_COLOR);

	if(stSignal.bLNGTableForBackAlarm)
		m_stc1061_10.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_10.SetForeColor(BLACK_COLOR);

	if(stSignal.bLPaperTableForBackAlarm)
		m_stc1061_11.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_11.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadLeftPicker1UpDownCYLAlarm)
		m_stc1061_14.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_14.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadLeftPicker2UpDownCYLAlarm)
		m_stc1061_15.SetForeColor(GREEN_COLOR);
	else
		m_stc1061_15.SetForeColor(BLACK_COLOR);


		if(stSignal.bUnloadLeftPickerVacuumAlarm)
		m_stc1062_0.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_0.SetForeColor(BLACK_COLOR);
		
		if(stSignal.bUnloadRightPicker1UpDownCYLAlarm)
		m_stc1062_1.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_1.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadRightPicker2UpDownCYLAlarm)
		m_stc1062_2.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_2.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadRightPickerVacuumAlam)
		m_stc1062_3.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_3.SetForeColor(BLACK_COLOR);

	if(stSignal.bUAlignTableForBackAlarm)
		m_stc1062_6.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_6.SetForeColor(BLACK_COLOR);

	if(stSignal.bUAlign1LeftAlarm)
		m_stc1062_7.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_7.SetForeColor(BLACK_COLOR);

	if(stSignal.bUAlign1FrontAlarm)
		m_stc1062_8.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_8.SetForeColor(BLACK_COLOR);

	if(stSignal.bUAlignPalteAlarm)
		m_stc1062_9.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_9.SetForeColor(BLACK_COLOR);

	if(stSignal.bUAlignROnOffAlarm)
		m_stc1062_10.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_10.SetForeColor(BLACK_COLOR);

	if(stSignal.bUCardLockAlarm)
		m_stc1062_11.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_11.SetForeColor(BLACK_COLOR);

	if(stSignal.bULifterAlarm)
		m_stc1062_12.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_12.SetForeColor(BLACK_COLOR);
	
	if(stSignal.bUNGTableForBackAlarm)
		m_stc1062_14.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_14.SetForeColor(BLACK_COLOR);

		if(stSignal.bUPaperTableForBackAlarm)
		m_stc1062_15.SetForeColor(GREEN_COLOR);
	else
		m_stc1062_15.SetForeColor(BLACK_COLOR);

	if(stSignal.bTurnTableForBackAlarm)
		m_stc1063_0.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_0.SetForeColor(BLACK_COLOR);

	if(stSignal.bTurnTableUpDownAlarm)
		m_stc1063_1.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_1.SetForeColor(BLACK_COLOR);

	if(stSignal.bTurnTableVacuumAlarm)
		m_stc1063_2.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_2.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadLeftPickerPCBAlarm)
		m_stc1063_3.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_3.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadRightPickerPCBAlarm)
		m_stc1063_4.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_4.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadLeftPickerPCBAlarm)
		m_stc1063_5.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_5.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadRightPickerPCBAlarm)
		m_stc1063_6.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_6.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadPosAlarm)
		m_stc1063_7.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_7.SetForeColor(BLACK_COLOR); 

	if(stSignal.bUnloadPosAlarm)
		m_stc1063_8.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_8.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadBoxNoExist)
		m_stc1063_9.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_9.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadBoxNoExist)
		m_stc1063_10.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_10.SetForeColor(BLACK_COLOR);

		if(stSignal.bNoUsePaperLoadPaper)
		m_stc1063_11.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_11.SetForeColor(BLACK_COLOR);

	if(stSignal.bNoUsePaperUnloadPaper)
		m_stc1063_12.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_12.SetForeColor(BLACK_COLOR);

	if(stSignal.bPaperNoExist)
		m_stc1063_13.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_13.SetForeColor(BLACK_COLOR);

	if(stSignal.bPaperBoxFull)
		m_stc1063_14.SetForeColor(GREEN_COLOR); 
	else
		m_stc1063_14.SetForeColor(BLACK_COLOR);

	if(stSignal.NGBoxFull)
		m_stc1063_15.SetForeColor(GREEN_COLOR);
	else
		m_stc1063_15.SetForeColor(BLACK_COLOR);

	if(stSignal.bLoadSafePos)
		m_stc1070.SetForeColor(GREEN_COLOR);
	else
		m_stc1070.SetForeColor(BLACK_COLOR);

	if(stSignal.bUnloadSafePos)
		m_stc1071.SetForeColor(GREEN_COLOR);
	else
		m_stc1071.SetForeColor(BLACK_COLOR);

	if(stSignal.bLdElvPCBExist)
		m_stc1072.SetForeColor(GREEN_COLOR);
	else
		m_stc1072.SetForeColor(BLACK_COLOR);

	if(stSignal.bStartMode)
		m_stc1073.SetForeColor(GREEN_COLOR);
	else
		m_stc1073.SetForeColor(BLACK_COLOR);

	if(stSignal.bPCBDownDanger)
		m_stc1074.SetForeColor(GREEN_COLOR);
	else
		m_stc1074.SetForeColor(BLACK_COLOR);

	if(stSignal.bAlignTablePCBExist)
		m_stc1075.SetForeColor(GREEN_COLOR);
	else
		m_stc1075.SetForeColor(BLACK_COLOR);


	LONG lMelsec = pMotor->GetCurrentError(STATUS_MELSEC);

	if(lMelsec & 0x0001)
		m_stc5432.SetForeColor(GREEN_COLOR);
	else
		m_stc5432.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0002)
		m_stc5433.SetForeColor(GREEN_COLOR);
	else
		m_stc5433.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0004)
		m_stc5434.SetForeColor(GREEN_COLOR);
	else
		m_stc5434.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0008)
		m_stc5435.SetForeColor(GREEN_COLOR);
	else
		m_stc5435.SetForeColor(BLACK_COLOR);


	if(lMelsec & 0x0010)
		m_stc5436.SetForeColor(GREEN_COLOR);
	else
		m_stc5436.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0020)
		m_stc5437.SetForeColor(GREEN_COLOR);
	else
		m_stc5437.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0040)
		m_stc5438.SetForeColor(GREEN_COLOR);
	else
		m_stc5438.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0080)
		m_stc5439.SetForeColor(GREEN_COLOR);
	else
		m_stc5439.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0100)
		m_stc5440.SetForeColor(GREEN_COLOR);
	else
		m_stc5440.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0200)
		m_stc5441.SetForeColor(GREEN_COLOR);
	else
		m_stc5441.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0400)
		m_stc5442.SetForeColor(GREEN_COLOR);
	else
		m_stc5442.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x0800)
		m_stc5443.SetForeColor(GREEN_COLOR);
	else
		m_stc5443.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x1000)
		m_stc5444.SetForeColor(GREEN_COLOR);
	else
		m_stc5444.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x2000)
		m_stc5445.SetForeColor(GREEN_COLOR);
	else
		m_stc5445.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x4000)
		m_stc5446.SetForeColor(GREEN_COLOR);
	else
		m_stc5446.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x8000)
		m_stc5447.SetForeColor(GREEN_COLOR);
	else
		m_stc5447.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x10000)
		m_stc5448.SetForeColor(GREEN_COLOR);
	else
		m_stc5448.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x20000)
		m_stc5449.SetForeColor(GREEN_COLOR);
	else
		m_stc5449.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x40000)
		m_stc5450.SetForeColor(GREEN_COLOR);
	else
		m_stc5450.SetForeColor(BLACK_COLOR);

	if(lMelsec & 0x80000)
		m_stc5451.SetForeColor(GREEN_COLOR);
	else
		m_stc5451.SetForeColor(BLACK_COLOR);

	Invalidate(FALSE);
#endif
}

void CDlgMelsecIO::OnPaint()
{
	CPaintDC dc(this); 
//	ChangeDisplay();
}
