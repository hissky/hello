// PaneRecipeGenParameterNewNext.cpp : implementation file
//

#include "stdafx.h"
#include "easydriller.h"
#include "PaneRecipeGenParameterNewNext.h"

#include "DlgLaserBeamHoleSet.h"
#include "..\easydrillerdlg.h"

#include "..\model\DProject.h"
#include "..\Model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\alarmmsg.h"
#include "math.h"
#include "..\model\DBeampathINI.h"
#include "DlgLaserBeamHoleSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNewNext

IMPLEMENT_DYNCREATE(CPaneRecipeGenParameterNewNext, CFormView)

#define LIST_EDIT_BOX		1
#define COLOR_COMBO			2
#define USE_TOOL_ORDER_COMBO 3	
#define PREHEAT_COMBO		4
#define POWER_COMBO			5
#define SCANNER_COMBO		6
#define BEAMPATH_COMBO		7
#define DRILL_METHOD_COMBO	8
#define AOM_BUTTON			9
#define	TOOLTYPE_COMBO		10
#define ADD_Del_COMBO		11
#define SETAOM_BUTTON			12
// #define MARK_TABLE_COUNT	16
// #define SHOT_TABLE_COUNT	9
//#define	LIST_WIDTH			10	


// CString strMarkTable[MARK_TABLE_COUNT]= {"T-Code","Sub No.","Color","Size","DrawStep","JumpStep","DS.Period","Step Period",
// "CornerDelay","LineDelay","LaserOnDelay","LaserOffDelay","Frequency","FPS","Mask", "Z Offset"};
// 
// CString strShotTable[]= {"T-Code","Sub No.","Color","Size","Drill Method","Total Shot","Z Offset"};


CString strTable[] = {
		"T-Code",				//0
		"ToolType",				//1
		"Color",				//2
		"Size",					//3
		"Use Tool Order",		//4
		"Prework Power",		//5
		"Power Min",			//6
		"Power Max",			//7
		"BeamPath",				//8	
		" ",				//9
		"Drill Method",			//10
		"Total Shot",			//11
		"Burst Shot",			//12
		" ",				//13
		"DrawStep",				//14
		"JumpStep",				//15
		"Step Period",			//16
		"CornerDelay",			//17
		"JumpDelay",			//18
		"LineDelay",			//19
		"LaserOnDelay",			//20
		"LaserOffDelay",		//21
		"Frequency",			//22
		"Aom"					//23
};
	

CPaneRecipeGenParameterNewNext::CPaneRecipeGenParameterNewNext()
	: CFormView(CPaneRecipeGenParameterNewNext::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenParameterNewNext)
	//}}AFX_DATA_INIT

	m_bGlobalParam = FALSE;
	m_bClickListofLeftMouse = FALSE;		// ���� ���콺�� ����Ʈ�� Ŭ�������� �� 
	m_bClickListofRightMouse =FALSE;		// ������ ���콺�θ���Ʈ Ŭ���� ��
}

CPaneRecipeGenParameterNewNext::~CPaneRecipeGenParameterNewNext()
{
}

void CPaneRecipeGenParameterNewNext::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenParameterNewNext)
	DDX_Control(pDX, IDC_LIST_PARAM, m_ParamList);
	DDX_Control(pDX, IDC_BUTTON_PARAM_OPEN_NEXT, m_btnOpen);
	DDX_Control(pDX, IDC_BUTTON_PARAM_SAVE_NEXT, m_btnSave);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenParameterNewNext, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenParameterNewNext)
	ON_NOTIFY(NM_CLICK, IDC_LIST_PARAM, OnClickListParam)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_PARAM, OnRclickListParam)
	ON_CBN_SELCHANGE(ADD_Del_COMBO,OnSelchangeComboAddDel)
	ON_CBN_KILLFOCUS(ADD_Del_COMBO,OnKillFocusComboAddDel)
	ON_CBN_SELCHANGE(TOOLTYPE_COMBO,OnSelchangeComboToolType)
	ON_CBN_KILLFOCUS(TOOLTYPE_COMBO,OnKillFocusComboToolType)
	ON_CBN_SELCHANGE(COLOR_COMBO,OnSelchangeComboColor)
	ON_CBN_KILLFOCUS(COLOR_COMBO,OnKillFocusComboColor)
	ON_CBN_SELCHANGE(USE_TOOL_ORDER_COMBO ,OnSelchangeComboUseToolOrder)
	ON_CBN_KILLFOCUS(USE_TOOL_ORDER_COMBO ,OnKillFocusComboUseToolOrder)
	ON_CBN_SELCHANGE(PREHEAT_COMBO,OnSelchangeComboPreheat)
	ON_CBN_KILLFOCUS(PREHEAT_COMBO,OnKillFocusComboPreheat)
	ON_CBN_SELCHANGE(POWER_COMBO,OnSelchangeComboPrePower)
	ON_CBN_KILLFOCUS(POWER_COMBO,OnKillFocusComboPrePower)
	ON_CBN_SELCHANGE(SCANNER_COMBO ,OnSelchangeComboPreScanner)
	ON_CBN_KILLFOCUS(SCANNER_COMBO ,OnKillFocusComboPreScanner)
	ON_CBN_SELCHANGE(BEAMPATH_COMBO,OnSelchangeComboBeampath)
	ON_CBN_KILLFOCUS(BEAMPATH_COMBO,OnKillFocusComboBeampath)
	ON_CBN_SELCHANGE(DRILL_METHOD_COMBO,OnSelchangeComboDrillMethod)
	ON_CBN_KILLFOCUS(DRILL_METHOD_COMBO,OnKillFocusComboDrillMethod)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_OPEN_NEXT, OnButtonParamOpenNext)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_SAVE_NEXT, OnButtonParamSaveNext)
	ON_BN_CLICKED(AOM_BUTTON, OnButtonAom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNewNext diagnostics

#ifdef _DEBUG
void CPaneRecipeGenParameterNewNext::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenParameterNewNext::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNewNext message handlers

void CPaneRecipeGenParameterNewNext::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();
	InitEditControl();

//	OnCheckUseTool(); ??
	
	memset(&m_dDuty, 0, sizeof(m_dDuty));
	memset(&m_dAOMDelay, 0, sizeof(m_dAOMDelay));
	memset(&m_dAOMDuty, 0, sizeof(m_dAOMDuty));
	
	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		m_dDuty[i] = 50;
		m_dAOMDelay[i] = 0;
		m_dAOMDuty[i] = 50;
		memcpy(m_cAOMFilePath[i], str, str.GetLength()+1);
	}
	
	m_bUseTool = FALSE;
	m_bToolOrder = FALSE;
	m_bUseAperture = FALSE;
	m_bUseFlipX = FALSE;
	m_bUseFlipY = FALSE;

	
	// TODO: Add your specialized code here and/or call the base class
	
}

void CPaneRecipeGenParameterNewNext::InitListControl()
{
// 	m_fntList.CreatePointFont(120, "Arial Bold");
// 	m_ParamList.SetFont( &m_fntList);

	//m_ParamList.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT|LVS_EX_INFOTIP);
	m_ParamList.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	m_ParamList.InsertColumn(0,"", LVCFMT_CENTER, 150);
	
	LV_ITEM lvitem;
	CString strData;

	for(int i = 0;i < TABLE_COUNT; i++)
	{
		lvitem.iItem = i;
		lvitem.mask = LVIF_TEXT;
		lvitem.iSubItem = 0;
		strData.Format(_T("%s"),  strTable[i]);
		lvitem.pszText = (LPSTR)(LPCTSTR)strData;
		m_ParamList.InsertItem(&lvitem);
	}
}

void CPaneRecipeGenParameterNewNext::InitStaticControl()
{
	m_fntStatic.CreatePointFont(130, "Arial Bold");

}


void CPaneRecipeGenParameterNewNext::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	

	m_btnOpen.SetFont( &m_fntBtn );
	m_btnOpen.SetFlat( FALSE );
	m_btnOpen.EnableBallonToolTip();
	m_btnOpen.SetToolTipText( _T("Open All parameter") );
	m_btnOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpen.SetBtnCursor(IDC_HAND_1);

	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Open All parameter") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

}


void CPaneRecipeGenParameterNewNext::InitComboControl()
{
//	m_fntCombo.CreatePointFont(130, "Arial Bold");

	//TOOLTYPE_COMBO
	m_comToolType.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,TOOLTYPE_COMBO);
	m_comToolType.SetFont(GetFont(),FALSE);
	m_comToolType.AddString("Marking");
	m_comToolType.AddString("ShotDrill");


	//COLOR_COMBO
	m_comColor.Create(  WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,COLOR_COMBO);
	m_comColor.SetFont(GetFont(),FALSE);
 	m_comColor.AddString("0");
 	m_comColor.AddString("1");
	m_comColor.AddString("2");
 	m_comColor.AddString("3");
	m_comColor.AddString("4");
 	m_comColor.AddString("5");
	m_comColor.AddString("6");
 	m_comColor.AddString("7");
	m_comColor.AddString("8");
 	m_comColor.AddString("9");


	//USE_TOOL_ORDER_COMBO 
	m_comUseToolOrder.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,USE_TOOL_ORDER_COMBO);
	m_comUseToolOrder.SetFont(GetFont(),FALSE);
	m_comUseToolOrder.AddString("0");
	m_comUseToolOrder.AddString("1");

	//PREHEAT_COMBO 
	m_comPreheat.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,PREHEAT_COMBO);
	m_comPreheat.SetFont(GetFont(),FALSE);
	m_comPreheat.AddString("0");
	m_comPreheat.AddString("1");

	//POWER_COMBO 
	m_comPower.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,POWER_COMBO);
	m_comPower.SetFont(GetFont(),FALSE);
	m_comPower.AddString("0");
	m_comPower.AddString("1");

	//SCANNER_COMBO 
	m_comScanner.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,SCANNER_COMBO);
	m_comScanner.SetFont(GetFont(),FALSE);
	m_comScanner.AddString("0");
	m_comScanner.AddString("1");

	//BEAMPATH_COMBO 
	m_comBeamPath.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,BEAMPATH_COMBO);
	m_comBeamPath.SetFont(GetFont(),FALSE);
	CString strTool;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("%d"), gBeamPathINI.m_sBeampath.nInfoId[i]);
		m_comBeamPath.AddString(strTool);
	}

	//DRILL_METHOD_COMBO 
	m_comDrillMethod.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,DRILL_METHOD_COMBO);
	m_comDrillMethod.SetFont(GetFont(),FALSE);
	m_comDrillMethod.AddString("burst");
	m_comDrillMethod.AddString("cycle");
	m_comDrillMethod.AddString("step");


	//ADD_Del_COMBO
	m_comAddDel.Create( WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL|CBS_DROPDOWNLIST ,CRect(0,0,0,0),this,ADD_Del_COMBO);
	m_comAddDel.SetFont(GetFont(),FALSE);
	m_comAddDel.AddString("Add");
	m_comAddDel.AddString("Del");

	//aom
	m_btnAom.Create("Aom",WS_CHILD|WS_VISIBLE, CRect(0,0,0,0), this, SETAOM_BUTTON);
	m_btnAom.SetFont(GetFont(),FALSE);

	
	
	
}


void CPaneRecipeGenParameterNewNext::InitEditControl()
{
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	

	//����Ʈ ���� ����Ʈ �ڽ� 
	m_editwnd.Create(WS_CHILD|ES_NOHIDESEL|ES_AUTOHSCROLL|WS_VISIBLE, CRect(0,0,0,0), this, LIST_EDIT_BOX);
	m_editwnd.SetFont(GetFont(), FALSE);
	m_editwnd.SetMargins(4,4);
	SetWindowLong(m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);
}

BOOL CPaneRecipeGenParameterNewNext::SetData(DProject &mDproject)
{
	memset(&m_pToolCode, 0, sizeof(m_pToolCode));
	
	for(int i= 0; i < MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = mDproject.m_pToolCode[i];
	}
	
	DeleteList();
	ChangeDisplay();


	return TRUE;
}

BOOL CPaneRecipeGenParameterNewNext::GetData(DProject &tempDProject)
{
	//	for(int i=0; i<MAX_TOOL_NO; i++)
	//	{
	//		tempDProject.m_pToolCode[i] = m_pToolCode[i];
	//	}
	//  set data���� �̹� pointer�� ���� �߱� ������ ���� �޾ƿ� �ʿ� ����
	return TRUE;
}

BOOL CPaneRecipeGenParameterNewNext::SetData(GlobalVariable &mGlobal, int nMainTool)
{
	// ���� ���� �ҷ�����???->manual�� param
	return TRUE;
}

void CPaneRecipeGenParameterNewNext::ChangeDisplay()
{
	LV_ITEM lvitem;
	CString strData;
	
	int nRowNo = 0;	// x ��ġ 

	m_ParamList.InsertColumn(0,"", LVCFMT_LEFT, 120);
	for(int i = 0;i < TABLE_COUNT; i++)	// 1row ��ä��� (�׸��)
	{
		lvitem.iItem = i;
		lvitem.mask = LVIF_TEXT;
		lvitem.iSubItem = 0; //nRowNo = 0
		strData.Format(_T("%s"),  strTable[i]);
		lvitem.pszText = (LPSTR)(LPCTSTR)strData;
		m_ParamList.InsertItem(&lvitem);
	}	
	nRowNo++;

	int nSubNo;
	for(int i = 0 ;i < MAX_TOOL_NO; i++)
	{	
		if(m_pToolCode[i]->m_bUseTool)
		{
			nSubNo = GetSubToolNumber(i);	//������ ���� ���
			
			for(int j = 0; j < nSubNo; j++)
			{
				GetSubToolData(i,j);	//tool�� subtool ������ ��� 
				m_ParamList.InsertColumn(nRowNo,"", LVCFMT_LEFT, 60);
				for(int z = 0; z < COPYDATA_COUNT; z++)
				{
					m_ParamList.SetItemText(z, nRowNo, m_strCopyData[z]);
				}
				nRowNo++;
			}
		}
	}

	m_nListRowCount = nRowNo;		// ����Ʈ ��ü�� ���� ���� ���� 

}

void CPaneRecipeGenParameterNewNext::DeleteList()
{
	CListCtrl &ctrllist = m_ParamList;
	CHeaderCtrl	*pHeaderCtrl;
	
	pHeaderCtrl = ctrllist.GetHeaderCtrl();
	int nCount = pHeaderCtrl->GetItemCount();
	
	if( -1 ==nCount)
	{
		ErrMessage(_T("Header Column not exist"));
		return;
	}
	else if( 0 < nCount)
	{
		ctrllist.DeleteAllItems();
		for(int i = 0;i <nCount; i++)
		{
			ctrllist.DeleteColumn(0);
		}
	}
}

int CPaneRecipeGenParameterNewNext::GetSubToolNumber(int nToolNo)
{
	int nSubNumber = 0;

	POSITION pos = 	m_pToolCode[nToolNo]->m_SubToolData.GetHeadPosition();

	while(pos)
	{
		m_pToolCode[nToolNo]->m_SubToolData.GetNext(pos);
		nSubNumber++;
	}

	return nSubNumber;
}

void CPaneRecipeGenParameterNewNext::GetSubToolData(int nToolNo, int nSubNo)
{
	int i;
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nToolNo];
	
	int nCount = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();

	for( i = 0; i < nSubNo; i++)
	{
		pToolCode->m_SubToolData.GetNext(pos);
	}

	subData = pToolCode->m_SubToolData.GetAt(pos);


	CString str;
	for( i = 0 ;i < COPYDATA_COUNT; i++)
		m_strCopyData[i] = "";


	if(subData.nToolType == MARKING_TYPE)
	{
		m_strCopyData[0].Format(_T("%d"),nToolNo);
		//m_strCopyData[1].Format(_T("%d"),subData.nToolType);
		if(subData.nToolType == MARKING_TYPE)
		{
			m_strCopyData[1].Format(_T("Marking"));
		}
		else if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			m_strCopyData[1].Format(_T("Shot"));
		}

		m_strCopyData[2].Format(_T("%d"),pToolCode->m_nToolColor);
		m_strCopyData[3].Format(_T("%d"),pToolCode->m_nToolSize);
		//m_strCopyData[4].Format(_T("%d"),pToolCode->m_bToolOrder);
		if(pToolCode->m_bToolOrder == 0)
		{
			m_strCopyData[4].Format(_T("On"));
		}
		else
		{
			m_strCopyData[4].Format(_T("Off"));
		}
		//m_strCopyData[5].Format(_T("%d"),pToolCode->m_bPreworkPower);
		if(pToolCode->m_bPreworkPower == 0)
		{
			m_strCopyData[5].Format(_T("On"));
		}
		else
		{
			m_strCopyData[5].Format(_T("Off"));
		}
		m_strCopyData[6].Format(_T("%.2f"),subData.dMinPower);
		m_strCopyData[7].Format(_T("%.2f"),subData.dMaxPower);
		m_strCopyData[8].Format(_T("%d"),subData.nMask);
		
		m_strCopyData[9].Format(_T("%s"),""); //����
		
		m_strCopyData[10].Format(_T("%s"),"-");
		m_strCopyData[11].Format(_T("%s"),"-");
		m_strCopyData[12].Format(_T("%s"),"-");
		
		m_strCopyData[13].Format(_T("%s"),"");	// ���� 
		
		m_strCopyData[14].Format(_T("%.2f"),subData.dDrawStep);
		m_strCopyData[15].Format(_T("%d"),subData.nJumpStep);
		m_strCopyData[16].Format(_T("%d"),subData.nJumpStepPeriod);
		m_strCopyData[17].Format(_T("%d"),subData.nCornerDelay);
		m_strCopyData[18].Format(_T("%d"),subData.nJumpDelay);
		m_strCopyData[19].Format(_T("%d"),subData.nLineDelay);
		m_strCopyData[20].Format(_T("%d"),subData.nLaserOnDelay);
		m_strCopyData[21].Format(_T("%d"),subData.nLaserOffDelay);
		m_strCopyData[22].Format(_T("%d"),subData.nFrequency);
		m_strCopyData[23].Format(_T("%s"),"AOM");
	}
	else if(subData.nToolType == SHOT_DRILL_TYPE)
	{
		m_strCopyData[0].Format(_T("%d"),nToolNo);
		//m_strCopyData[1].Format(_T("%d"),subData.nToolType);
		if(subData.nToolType == MARKING_TYPE)
		{
			m_strCopyData[1].Format(_T("Marking"));
		}
		else if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			m_strCopyData[1].Format(_T("Shot"));
		}
		m_strCopyData[2].Format(_T("%d"),pToolCode->m_nToolColor);
		m_strCopyData[3].Format(_T("%d"),pToolCode->m_nToolSize);
		//m_strCopyData[4].Format(_T("%d"),pToolCode->m_bToolOrder);
		if(pToolCode->m_bToolOrder == 0)
		{
			m_strCopyData[4].Format(_T("On"));
		}
		else
		{
			m_strCopyData[4].Format(_T("Off"));
		}
		//_strCopyData[5].Format(_T("%d"),pToolCode->m_bPreworkPower);
		if(pToolCode->m_bPreworkPower == 0)
		{
			m_strCopyData[5].Format(_T("On"));
		}
		else
		{
			m_strCopyData[5].Format(_T("Off"));
		}
		m_strCopyData[6].Format(_T("%.2f"),subData.dMinPower);
		m_strCopyData[7].Format(_T("%.2f"),subData.dMaxPower);
		m_strCopyData[8].Format(_T("%d"),subData.nMask);
		
		m_strCopyData[9].Format(_T("%s"),""); //����
		
		//m_strCopyData[10].Format(_T("%d"),subData.nShotMode);
		if(subData.nShotMode ==0)
		{
			m_strCopyData[10].Format(_T("cycle"));
		}
		else if(subData.nShotMode ==1)
		{
			m_strCopyData[10].Format(_T("burst"));
		}
		else if(subData.nShotMode ==2)
		{
			m_strCopyData[10].Format(_T("step"));
		}

		m_strCopyData[11].Format(_T("%d"),subData.nTotalShot);
		if(subData.nShotMode == 2) //step mode
			m_strCopyData[12].Format(_T("%d"),subData.nBurstShot);
		else
			m_strCopyData[12].Format(_T("%s"),"-");
		
		m_strCopyData[13].Format(_T("%s"),"");	// ���� 
		
		m_strCopyData[14].Format(_T("%s"),"-");
		m_strCopyData[15].Format(_T("%s"),"-");
		m_strCopyData[16].Format(_T("%s"),"-");
		m_strCopyData[17].Format(_T("%s"),"-");
		m_strCopyData[18].Format(_T("%s"),"-");
		m_strCopyData[19].Format(_T("%s"),"-");
		m_strCopyData[20].Format(_T("%s"),"-");
		m_strCopyData[21].Format(_T("%s"),"-");
		m_strCopyData[22].Format(_T("%s"),"-");
		m_strCopyData[23].Format(_T("%s"),"AOM");
	}
	else 
	{
		// �߰��Ǵ°� �����....
	}
}

void CPaneRecipeGenParameterNewNext::OnClickListParam(NMHDR* pNMHDR, LRESULT* pResult) 
{

	m_bClickListofLeftMouse = TRUE;

	//���õ� ����Ʈ �׸� ���
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;
	m_posClicked.x=pnmia->iSubItem;
	m_posClicked.y=pnmia->iItem;


	if(m_posClicked.x == 0 || m_posClicked.y  == -1  ||m_posClicked.y == 0)	//  0: ���, -1: ����Ʈ�� �׸��� ���°�, 0: tool no,
	{
		m_bClickListofLeftMouse = FALSE;
		return ;
	}

	if(	m_posClicked.x >= m_nListRowCount || m_posClicked.y >= TABLE_COUNT)
	{
		m_bClickListofLeftMouse = FALSE;
		return; 
	}
	int nLimitMode = LimitClickforMarkShot(m_posClicked);

	if(nLimitMode == MARKING_TYPE)
	{
		if(m_posClicked.y == 10 ||m_posClicked.y == 11 ||m_posClicked.y == 12)
			return ;
	}
	else if(nLimitMode == SHOT_DRILL_TYPE)	// shot�϶� marking ��� param �� �Ⱥ��� 
	{	
		if(m_posClicked.y == 14 ||m_posClicked.y == 15 ||m_posClicked.y == 16||
			m_posClicked.y == 17 ||m_posClicked.y == 18 ||m_posClicked.y == 19||
			m_posClicked.y == 20 ||m_posClicked.y == 21 ||m_posClicked.y == 22)
			return ;
	}
	SetCloseControl();

	// Ŭ����ġ�� �ش��ϴ� ��Ʈ�� ����
	SelectControl(m_posClicked.x,m_posClicked.y);
	*pResult = 0;
}


void CPaneRecipeGenParameterNewNext::OnRclickListParam(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CRect rectCell;

	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;
	m_posClicked.x=pnmia->iSubItem;
	m_posClicked.y=pnmia->iItem;
	
	if(m_posClicked.y == -1 ||m_posClicked.x == 0)
		return ;
	
	SetCloseControl();
	
	//adddel
	m_ParamList.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
	m_comAddDel.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
	m_comAddDel.SetFocus();
	m_comAddDel.ShowDropDown();
		
	*pResult = 0;
		
}

BOOL CPaneRecipeGenParameterNewNext::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message==WM_KEYDOWN && GetFocus()->m_hWnd==m_editwnd.m_hWnd)
	{
		switch (pMsg->wParam)
		{
		case VK_RETURN:
			if(m_bClickListofLeftMouse)
			{
				SetCloseControl();
				m_bClickListofRightMouse = FALSE;

				OnKillfocusEditGrid();
				
				SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
				m_bClickListofLeftMouse = FALSE;
			}
			return TRUE;
			
		case VK_ESCAPE:
			if(m_bClickListofLeftMouse)
			{
				SetCloseControl();
				m_bClickListofRightMouse = FALSE;

				m_posClicked.y=-1;
				SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
				m_bClickListofLeftMouse = FALSE;
			}

			return TRUE;
			
		case VK_UP:
			if(m_bClickListofLeftMouse)
				MoveFocus(m_posClicked.x, m_posClicked.y, VK_UP);

			return TRUE;
			
		case VK_DOWN:
			if(m_bClickListofLeftMouse)
				MoveFocus(m_posClicked.x, m_posClicked.y,VK_DOWN);

			return TRUE;
			
		case VK_RIGHT:
		case VK_TAB:
			if(m_bClickListofLeftMouse)
				MoveFocus(m_posClicked.x, m_posClicked.y,VK_RIGHT);

			return TRUE;
			
		case VK_LEFT:
			if(m_bClickListofLeftMouse)
				MoveFocus(m_posClicked.x, m_posClicked.y, VK_LEFT);

			return TRUE;
			
		default:
			break;
			
		}
		
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneRecipeGenParameterNewNext::OnKillfocusEditGrid()
{
	CString str;
	m_editwnd.GetWindowText(str);

	SetCloseControl();	
	if (m_posClicked.x==-1 || m_posClicked.y==-1)
	{
		DeleteList();
		ChangeDisplay();	// �ٽñ׸��� ��Ŀ�� ����
		return;
	}

	DeleteList();
	UpdateListData(m_posClicked,str);
	ChangeDisplay();
	m_bClickListofLeftMouse = FALSE;

}

void CPaneRecipeGenParameterNewNext::SetCloseControl()
{
	m_editwnd.ShowWindow(SW_HIDE);
	m_comColor.ShowWindow(SW_HIDE);
	m_comUseToolOrder.ShowWindow(SW_HIDE);
	m_comPreheat.ShowWindow(SW_HIDE);
	m_comPower.ShowWindow(SW_HIDE);
	m_comScanner.ShowWindow(SW_HIDE);
	m_comBeamPath.ShowWindow(SW_HIDE);
	m_comDrillMethod.ShowWindow(SW_HIDE);
	m_comToolType.ShowWindow(SW_HIDE);
	m_comAddDel.ShowWindow(SW_HIDE);
	m_btnAom.ShowWindow(SW_HIDE);
}

void CPaneRecipeGenParameterNewNext::SetCurrentScrollPos(int xPos, int yPos)
{
	CRect rectCell;
	m_ParamList.GetSubItemRect(yPos, xPos, LVIR_BOUNDS, rectCell);
	
	
	CSize size;
	if(yPos <25)
		size.cy = 0;
	else
		size.cy = yPos* rectCell.Height();	
	
	if(xPos <10 )
		size.cx = 0;
	else if( xPos < 20)
		size.cx = xPos*30;
	else
		size.cx = xPos*50;
	
	if(m_ParamList.Scroll(size))
	{
		m_ParamList.SetItemState(m_posClicked.y,LVIS_SELECTED,LVIS_SELECTED);
		//	m_ParamList.SetFocus();	// �̰� �ϸ� �ش� �࿡ �Ķ������� �� ��Ÿ��  
	}
}

BOOL CPaneRecipeGenParameterNewNext::MoveFocus(int nXpos, int nYpos, int nMoveType) //nXpos,nypos �̵� ���� �� �����ϰ� ���� 
{
	CString str;
	CRect rectCell;	
	
	// Ŭ�� ���� ������ ������Ʈ 
	m_editwnd.GetWindowText(str);		
	UpdateListData(m_posClicked,str);	
	DeleteList();
	ChangeDisplay();

	
	//�̵� ��ġ�� ����Ʈ �ڽ� �̵� 
	if(TRUE == m_bClickListofLeftMouse)		// m_bClickList ==TRUE �� :����Ʈ�� �׸��� ��Ʈ���� �� 
	{
		
		switch (nMoveType)
		{
		case VK_UP:
			m_posClicked.y--;
			break;
			
		case VK_DOWN:
			m_posClicked.y++;
			break;
			
		case VK_RIGHT:
			m_posClicked.x++;
			break;
			
		case VK_LEFT:
			m_posClicked.x--;
			break;
			
		default:
			break;
		}
		
		// ���� üũ ����Ʈ�� ���� �¿� üũ 
		if(m_posClicked.x == 0 || m_posClicked.y  == -1 )		//id��, �÷� �������� ��Ŀ�� �̵��� 
		{
			//bClickList = FALSE;
			m_posClicked.x = nXpos;		// ��ǥ�� ���� 
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}
	
		int nChecOutofListX, nChecOutofListY;
		nChecOutofListX = m_nListRowCount;		//����Ʈ ���� ũ��
		nChecOutofListY = TABLE_COUNT	;			//����Ʈ ���� ũ�� 
		
		if ( (m_posClicked.x >= nChecOutofListX) || (m_posClicked.y >= nChecOutofListY) )
		{
			m_posClicked.x = nXpos;
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}
		
		// ��ũ�� �̵� ��ƾ 
		SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
		// ��Ʈ�� ���� 
		SelectControl(m_posClicked.x,m_posClicked.y);
		
	}
	return TRUE;
}

void CPaneRecipeGenParameterNewNext::SelectControl(int nXpos, int nYpos)
{
	m_bClickListofLeftMouse = FALSE;	// ����Ű�� ����Ʈ �ڽ��� ��� (����Ʈ �ڽ� �̿��� ��Ʈ���� Ŭ���� ����Ű ��������� �̵�����)

	CString str;
	CRect rectCell;

	if( nYpos ==1)
	{
		//tooltype
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comToolType.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comToolType.SetFocus();
		m_comToolType.ShowDropDown();

	}
	else if(nYpos  == 2)
	{
		//color
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comColor.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comColor.SetFocus();
		m_comColor.ShowDropDown();
	}
	else if(nYpos  == 4)
	{
		//use tool order
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comUseToolOrder.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comUseToolOrder.SetFocus();
		m_comUseToolOrder.ShowDropDown();
	}
// 	else if(nYpos  == 5)
// 	{
// 		//preheat
// 		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
// 		m_comPreheat.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
// 		m_comPreheat.SetFocus();
// 		m_comPreheat.ShowDropDown();
// 	}	
	else if(nYpos  == 5)
	{
		//prework power
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comPower.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comPower.SetFocus();
		m_comPower.ShowDropDown();
	}
// 	else if(nYpos  == 7)
// 	{
// 		//Prework Scamner
// 		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
// 		m_comScanner.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
// 		m_comScanner.SetFocus();
// 		m_comScanner.ShowDropDown();
// 	}
	else if(nYpos  == 8)
	{
		//beampath
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comBeamPath.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comBeamPath.SetFocus();
		m_comBeamPath.ShowDropDown();
	}
	else if(nYpos  == 10)
	{
		//drill method
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_comDrillMethod.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_comDrillMethod.SetFocus();
		m_comDrillMethod.ShowDropDown();
	}
	else if(nYpos == 23)
	{
		// aom
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_btnAom.SetWindowPos(NULL,rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top ,SWP_NOZORDER|SWP_SHOWWINDOW);
		m_btnAom.SetFocus();
		OnButtonAom();
		UpdateListData(m_posClicked,"aom");
	}
	else if(nYpos == 8 || nYpos == 13)
	{
		return ;	// ���� 
	}
	else
	{
		//����Ʈ �ڽ� �׸��� 
		str=m_ParamList.GetItemText(nYpos, nXpos);
		m_editwnd.SetWindowText(str);
		m_ParamList.GetSubItemRect(nYpos, nXpos, LVIR_BOUNDS, rectCell);
		m_editwnd.SetWindowPos(NULL, rectCell.left+26, rectCell.top+32, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top, SWP_NOZORDER|SWP_SHOWWINDOW);
		m_editwnd.SetFocus();
		m_editwnd.SetSel(0, -1);

		m_bClickListofLeftMouse = TRUE;
	}

}

//�ӽ� ������ ��������;;
// m_strCopyData[0].Format(_T("%d"),nToolNo);
// m_strCopyData[1].Format(_T("%d"),subData.nToolType);
// m_strCopyData[2].Format(_T("%d"),pToolCode->m_nToolColor);
// m_strCopyData[3].Format(_T("%d"),pToolCode->m_nToolSize);
// m_strCopyData[4].Format(_T("%d"),pToolCode->m_bToolOrder);
// m_strCopyData[5].Format(_T("%d"),pToolCode->m_bPreworkPreheat);
// m_strCopyData[6].Format(_T("%d"),pToolCode->m_bPreworkPower);
// m_strCopyData[7].Format(_T("%d"),pToolCode->m_bPreworkScanner);
// m_strCopyData[8].Format(_T("%d"),subData.dMinPower);
// m_strCopyData[9].Format(_T("%d"),subData.dMaxPower);
// m_strCopyData[10].Format(_T("%d"),subData.nMask);
// 
// m_strCopyData[11].Format(_T("%s"),"")); //����
// 
// m_strCopyData[12].Format(_T("%d"),subData.nShotMode);
// m_strCopyData[13].Format(_T("%d"),subData.nTotalShot);
// m_strCopyData[14].Format(_T("%d"),subData.nBurstShot);
// 
// m_strCopyData[15].Format(_T("%s"),""));	// ���� 
// 
// m_strCopyData[16].Format(_T("%d"),subData.nDrawStep);
// m_strCopyData[17].Format(_T("%d"),subData.nJumpStep);
// m_strCopyData[18].Format(_T("%d"),subData.nJumpStepPeriod);
// m_strCopyData[19].Format(_T("%d"),subData.nCornerDelay);
// m_strCopyData[20].Format(_T("%d"),subData.nJumpDelay);
// m_strCopyData[21].Format(_T("%d"),subData.nLineDelay);
// m_strCopyData[22].Format(_T("%d"),subData.nLaserOnDelay);
// m_strCopyData[23].Format(_T("%d"),subData.nLaserOffDelay);
// m_strCopyData[24].Format(_T("%d"),subData.nFrequency);
// 		m_strCopyData[25].Format(_T("%s"),"AOM"));



void CPaneRecipeGenParameterNewNext::GetToolSubtoolNo(int ClickedPos, int &nToolNo, int &nSubToolNo)
{
	int nSubNo = 0;
	int nTotalCount = 0;
	for(int i = 0 ;i < MAX_TOOL_NO; i++)
	{	
		if(m_pToolCode[i]->m_bUseTool)
		{
			nSubNo = GetSubToolNumber(i);//m_pToolCode[i]->m_nTotalSubNo ; 
			nTotalCount +=nSubNo;

			if(nTotalCount >=ClickedPos)
			{
				nToolNo = i;		// tool ��ȣ ����

				int ntemp;
				ntemp = nTotalCount - ClickedPos;
				nSubToolNo = nSubNo - ntemp - 1;	//subtool ��ȣ ���� (-1�ϴ� ������ �������� 0������ ������)
				break;
			}
		}
	}

}



void CPaneRecipeGenParameterNewNext::AddSubTool()
{
	int nToolNo, nSubToolNo;
	GetToolSubtoolNo(m_posClicked.x, nToolNo, nSubToolNo);

//	double dTempVal;
	CString str, strMessage, strInfo, strTemp;

	int nListIndex = nToolNo;
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData, Tempsubdata;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int nCount = 1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();

	for(int i = 0 ;i <nSubToolNo; i++ )
	{
		pToolCode->m_SubToolData.GetNext(pos);
		nCount++;
	}
	Tempsubdata = pToolCode->m_SubToolData.GetAt(pos);	// ������ subdata �� ���� ���� ���ԵǴ� ���� ���� �����ϱ�����
		
	memset(&subData, 0, sizeof(subData));

	subData = Tempsubdata;		// �� ���� (����ü �����Ҷ� char �� ����ǳ�;;)

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		subData.dShotDuty[i] = m_dDuty[i];
		subData.dShotAOMDelay[i] = m_dAOMDelay[i];
		subData.dShotAOMDuty[i] = m_dAOMDuty[i];
		memcpy(subData.cAOMFilePath[i], m_cAOMFilePath[i], 255);
	}

	subData.nSubToolNo = nCount+1;

 	CheckSubTool(subData, nToolNo);


	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		strTemp.Format(_T("| %d duty = %.3f"), i, subData.dShotDuty[i]);
		strInfo += strTemp;
		if(gSystemINI.m_sHardWare.nAOMType != 0)
		{
			strTemp.Format(_T("| %d AOM delay = %.3f"), i, subData.dShotAOMDelay[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d AOM duty = %.3f"), i, subData.dShotAOMDuty[i]);
			strInfo += strTemp;
			strTemp.Format(_T("| %d AOM file = %s"), i, subData.cAOMFilePath[i]);
			strInfo += strTemp;
		}
	}
	strTemp.Format(_T("| SubType = %d"), subData.nToolType);
	strInfo += strTemp;
	strTemp.Format(_T("| SubMask = %d"), subData.nMask);
	strInfo += strTemp;
	strTemp.Format(_T("| SubShotMode = %d"), subData.nShotMode);
	strInfo += strTemp;
	strTemp.Format(_T("| SubUseAper = %d"), subData.bUseAperture);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFlip = %d, %d"), subData.bFlipX, subData.bFlipY);
	strInfo += strTemp;
	strTemp.Format(_T("| SubDS = %.2f"), subData.dDrawStep);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJS = %d"), subData.nJumpStep);
	strInfo += strTemp;
	strTemp.Format(_T("| SubDSP = %d"), subData.nDrawStepPeriod);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJSP = %d"), subData.nJumpStepPeriod);
	strInfo += strTemp;
	strTemp.Format(_T("| SubCD = %d"), subData.nCornerDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubJD = %d"), subData.nJumpDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLD = %d"), subData.nLineDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOD = %d"), subData.nLaserOnDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOFFD = %d"), subData.nLaserOffDelay);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFreq = %d"), subData.nFrequency);
	strInfo += strTemp;
	strTemp.Format(_T("| SubFPS = %d"), subData.nFPS);
	strInfo += strTemp;
	strTemp.Format(_T("| SubCurr = %.3f"), subData.dCurrent);
	strInfo += strTemp;
	strTemp.Format(_T("| SubA1 = %.3f"), subData.dA1);
	strInfo += strTemp;
	strTemp.Format(_T("| SubA2 = %.3f"), subData.dA2);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTS = %d"), subData.nTotalShot);
	strInfo += strTemp;
	strTemp.Format(_T("| SubBS = %d"), subData.nBurstShot);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLIn = %d"), subData.nLeadIn);
	strInfo += strTemp;
	strTemp.Format(_T("| SubLOut = %d"), subData.nLeadOut);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTS = %d"), subData.nTableSpeed);
	strInfo += strTemp;
	strTemp.Format(_T("| SubRotate = %d"), subData.nRotate);
	strInfo += strTemp;
	strTemp.Format(_T("| SubPath = %s"), subData.cFilePath);
	strInfo += strTemp;
	strTemp.Format(_T("| SubAB = %d"), subData.nApertureBurst);
	strInfo += strTemp;
	strTemp.Format(_T("| SubTT = %d"), subData.nThermalTrack);
	strInfo += strTemp;
	strTemp.Format(_T("| SubZOff = %.3f"), subData.dZOffset);
	strInfo += strTemp;
	strTemp.Format(_T("| Memo = %s"), subData.cToolMemo);
	strInfo += strTemp;
	strTemp.Format(_T("| MinPower = %.3f"), subData.dMinPower);
	strInfo += strTemp;
	strTemp.Format(_T("| MaxPower = %.3f"), subData.dMaxPower);
	strInfo += strTemp;
	strTemp.Format(_T("| HoleSize = %.2f"), subData.dHoleSize);
	strInfo += strTemp;

	pToolCode->m_SubToolData.AddTail(subData);

// 	if(m_bGlobalParam)				//  manual�� �ִ°� ����....
// 	{
// 		if(!gVariable.SaveGlobalTool())
// 		{
// 			ErrMsgDlg(STDGNALM111);
// 		}
// /*		if(sel == 0)
// 			strMessage.Format(_T("AGC %d Added. "), subData.nSubToolNo);
// 		else */
// 		if(sel == 0)
// 			strMessage.Format(_T("One Hole Param. %d Added. "), subData.nSubToolNo);
// 		else
 			strMessage.Format(_T("PowerMeasurement Param. %d Added. "), subData.nSubToolNo);
// 	}
// 	else
// 	{
// 		strMessage.Format(_T("Tool %d (sub : %d) Added. "), nListIndex, subData.nSubToolNo);
// 	}
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));


}

void CPaneRecipeGenParameterNewNext::DelSubTool()
{
	int nToolNo, nSubToolNo;
	GetToolSubtoolNo(m_posClicked.x, nToolNo, nSubToolNo);

	if(nSubToolNo == 0, 1 == GetSubToolNumber(nToolNo))
	{
		ErrMessage(_T("Need One more subtool"));
		return ;
	}

	int sel = nToolNo;
	int nListIndex = nToolNo;
	if(nListIndex == -1)
		return;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}

	if(i == 0)
		return;

	int selSub = nSubToolNo;
	if(-1 == selSub)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}

	i = 0;
	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;
		
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}	
	pToolCode->m_SubToolData.RemoveAt(pos);


	CString strMessage;
// 	if(m_bGlobalParam)		// manual ���ִ°� ����.. 
// 	{
// 		if(!gVariable.SaveGlobalTool())
// 		{
// 			ErrMsgDlg(STDGNALM111);
// 		}
// /*		if(sel == 0)
// 			strMessage.Format(_T("Delete AGC %d. "), i+1);
// 		else */
// 		if(sel == 0)
// 			strMessage.Format(_T("Delete One Hole Param. "), i+1);
// 		else
// 			strMessage.Format(_T("Delete PowerMeasurement Param. %d. "), i+1);
// 	}
// 	else
// 	{
		strMessage.Format(_T("Delete Tool %d (sub : %d). "), nListIndex, i+1);
//	}
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));

	SUBTOOLDATA subData;

	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subData = pToolCode->m_SubToolData.GetAt(pos);
		if(subData.nSubToolNo > selSub + 1)
		{
			subData.nSubToolNo--;
			pToolCode->m_SubToolData.SetAt(pos, subData);
		}
		pToolCode->m_SubToolData.GetNext(pos);
	}
}

void CPaneRecipeGenParameterNewNext::SetAddDel(BOOL nSelect)
{
	m_bSelectAddDel = nSelect;
}

BOOL CPaneRecipeGenParameterNewNext::GetAddDel()
{
	BOOL  bSelect = m_bSelectAddDel;

	return	bSelect; 
}

BOOL CPaneRecipeGenParameterNewNext::CheckSubTool(SUBTOOLDATA subData, int nToolNum)
{
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(subData.nToolType == FLYING_TYPE)
		{
			ErrMessage(_T("Flying Type can't be used."));
		//	GetDlgItem( IDC_COMBO_SUB_TOOL_TYPE )->SetFocus();
			return FALSE;
		}
		if(subData.dCurrent > 100 || subData.dCurrent <= 80)
		{
			ErrMessage(_T("Current range : 80 % < Current <= 100%"));
		//	GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 50000 || subData.nFrequency > 200000)
		{
			ErrMessage(_T("Frequency range : 50 KHz < Current <= 200 KHz"));
		//	GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}

		if(subData.dA1 < 0 || subData.dA1 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
		//	GetDlgItem( IDC_EDIT_SUB_A1 )->SetFocus();
			return FALSE;
		}
		if(subData.dA2 < 0 || subData.dA2 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
		//	GetDlgItem( IDC_EDIT_SUB_A2 )->SetFocus();
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(subData.dCurrent > 100 || subData.dCurrent <= 0)
		{
			ErrMessage(_T("Current range : 0 % < Current <= 100%"));
		//	GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 1000 || subData.nFrequency > 100000)
		{
			ErrMessage(_T("Frequency range : 1 KHz < Frequency <= 100 KHz"));
		//	GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}
		
		if(subData.dA1 < 0 || subData.dA1 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
		//	GetDlgItem( IDC_EDIT_SUB_A1 )->SetFocus();
			return FALSE;
		}
		if(subData.dA2 < 0 || subData.dA2 >= 3600)
		{
			ErrMessage(_T("Attenuator range : 0 <= Attenuator < 3600"));
		//	GetDlgItem( IDC_EDIT_SUB_A2 )->SetFocus();
			return FALSE;
		}
		if(subData.nMask < 0)
		{
			ErrMessage(_T("Select Mask No."));
		//	GetDlgItem( IDC_COMBO_SUB_MASK )->SetFocus();
			return FALSE;
		}
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(subData.dCurrent < 0 || subData.dCurrent > 100)
			{
				ErrMessage(_T("Current range : 0 < Current <= 100"));
			//	GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
				return FALSE;
			}
			if(subData.nFrequency < 15000 || subData.nFrequency > 100000)
			{
				ErrMessage(_T("Frequency range : 15 KHz < Current <= 100 KHz"));
			//	GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
				return FALSE;
			}
		}
		else
		{
			if(subData.nFrequency < 1000 || subData.nFrequency > 10000)
			{
				ErrMessage(_T("Frequency range : 1 KHz < Current <= 10 KHz"));
			//	GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
				return FALSE;
			}
		}

//		if(subData.nToolType != SHOT_DRILL_TYPE)
//		{
//			ErrMessage(_T("You can only use Shot drill type."));
//			GetDlgItem( IDC_COMBO_SUB_TOOL_TYPE )->SetFocus();
//			return FALSE;
//		}
		if(subData.nMask < 0)
		{
			ErrMessage(_T("Select Mask No."));
		//	GetDlgItem( IDC_COMBO_SUB_MASK )->SetFocus();
			return FALSE;
		}
	}
	
	if(subData.nToolType != FLYING_TYPE)
	{
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Draw Step : Insert 1 ~ 65534."));
			//	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
			//	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || (subData.nToolType == LINE_DRILL_TYPE && m_bGlobalParam && nToolNum == 0))
		{
			if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 5001)
			{
				ErrMessage(_T("Draw Step Period : Insert 20 ~ 5000"));
			//	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}
		else
		{
			if(subData.nDrawStepPeriod < 15 || subData.nDrawStepPeriod > 5001)
			{
				ErrMessage(_T("Draw Step Period : Insert 15 ~ 5000"));
			//	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(IDS_PARAM_JSP);
		//	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nCornerDelay < 0 || subData.nCornerDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Corner Delay : Insert 0 ~ 65534."));
			//	GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nJumpDelay < 0 || subData.nJumpDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Jump Delay : Insert 0 ~ 65534."));
			//	GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nLineDelay < 0 || subData.nLineDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Line Delay : Insert 0 ~ 65534."));
				//GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nLaserOnDelay < 1 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 1 ~ 65534."));
			//GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
				//GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nFPS < 0 || subData.nFPS > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("FPS : Insert 0 ~ 65534."));
				//GetDlgItem( IDC_EDIT_SUB_FPS )->SetFocus();
				return FALSE;
			}
		}

		int nTotalCount = 1;
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nShotMode < 0)
			{
				ErrMessage(IDS_PARAM_SHOT);
			//	GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->SetFocus();
				return FALSE;
			}
			if(subData.nTotalShot < 1 || subData.nTotalShot > 15)
			{
				ErrMessage(_T("Total Shot : Insert 1 ~ 15."));
				//GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->SetFocus();
				return FALSE;
			}
			
			if(subData.nShotMode != 1)
			{
				if(subData.nBurstShot < 0 || subData.nTotalShot < subData.nBurstShot)
				{
					ErrMessage(_T("Burst Shot : Insert 0 ~ Total Shot No."));
				//	GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->SetFocus();
					return FALSE;
				}
			}
			nTotalCount = subData.nTotalShot;
		}
		
		for(int i = 0; i < nTotalCount; i++)
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
			{
				if(subData.dShotDuty[i] / (10000. / subData.nFrequency) <= 0 || 
					subData.dShotDuty[i] / (10000. / subData.nFrequency) > 50) // %
				{
					ErrMessage(_T("Duty range : 0 < Duty < 50 %"));
					return FALSE;
				}
				if(gSystemINI.m_sHardWare.nAOMType != 0)
				{
					if(subData.dShotAOMDelay[i] < 0 || subData.dShotAOMDelay[i] > 1000000 / subData.nFrequency) // %
					{
						ErrMessage(_T("AOM Delay range : 0 < AOM Delay < 1 Freq. period"));
						return FALSE;
					}
					if(subData.dShotAOMDuty[i] < 0 || 
						subData.dShotAOMDelay[i] + subData.dShotAOMDuty[i] > 1000000 / subData.nFrequency) // %
					{
						ErrMessage(_T("AOM Duty range : 0 < AOM Delay + AOM Duty < 1 Freq. period"));
						return FALSE;
					}
					if(subData.cAOMFilePath[i][0] == NULL)
					{
						ErrMessage(IDS_PARAM_AOM);
						return FALSE;
					}
				}
			}
			else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				subData.dShotDuty[i] = 50;
			}
		}
		
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.bUseAperture && subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(IDS_PARAM_APERTURE);
				return FALSE;
			}
//			if(subData.cMoveProfileFilePath[0] == _T('\0'))
//			{
//				ErrMessage(_T("Select a Scanner Move Profile file."));
//				return FALSE;
//			}
		}
		if(subData.nToolType == LINE_DRILL_TYPE || subData.nToolType == BARCODE_TYPE)
		{
			if(!subData.bUseAperture || subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(IDS_PARAM_APERTURE);
				return FALSE;
			}
		}
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nApertureBurst < 1 || subData.nApertureBurst > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Aperture Burst : Insert 1 ~ 65534."));
			//	GetDlgItem( IDC_EDIT_SUB_APERTURE_BURST )->SetFocus();
				return FALSE;
			}
		}
	}
	else // flying type
	{
		if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Draw Step : Insert 1 ~ 65534."));
		//	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
		//	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
			return FALSE;
		}
		if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 5001)
		{
			ErrMessage(_T("Draw Step Period : Insert 20 ~ 5000"));
		//	GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(IDS_PARAM_JSP);
		//	GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOnDelay < 1 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 1 ~ 65534."));
		//	GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
		//	GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
			return FALSE;
		}

		if(subData.nTableSpeed < 0)
		{
			ErrMessage(_T("Table Speed : Insert 1 ~ Max Table Speed."));
		//	GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->SetFocus();
			return FALSE;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
		{
			if(subData.dShotDuty[0] <= 0 || subData.dShotDuty[0] > 50) // %
			{
				ErrMessage(_T("Duty range : 0 < Duty < 50 %"));
				return FALSE;
			}
			if(gSystemINI.m_sHardWare.nAOMType != 0)
			{
				if(subData.dShotAOMDelay[0] < 0 || subData.dShotAOMDelay[0] > 1000000 / subData.nFrequency) // %
				{
					ErrMessage(_T("AOM Delay range : 0 < AOM Delay < 1 Freq. period"));
					return FALSE;
				}
				if(subData.dShotAOMDuty[0] < 0 || 
					subData.dShotAOMDelay[0] + subData.dShotAOMDuty[0] > 1000000 / subData.nFrequency) // %
				{
					ErrMessage(_T("AOM Duty range : 0 < AOM Delay + AOM Duty < 1 Freq. period"));
					return FALSE;
				}
				if(subData.cAOMFilePath[0][0] == NULL)
				{
					ErrMessage(IDS_PARAM_AOM);
					return FALSE;
				}
			}
		}
		//		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		//		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
	}
	if(subData.dZOffset < -5 || subData.dZOffset > 5)
	{
		ErrMessage(_T("Z-axis Offset : Insert -5mm ~ 5mm."));
	//	GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->SetFocus();
		return FALSE;
	}

//	if (subData.dMinPower > subData.dMaxPower )
//	{
//		ErrMessage(IDS_MEASURE_REF_VALUE);
//		SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
//	}
	 if ( subData.dMinPower <= 0 || subData.dMinPower >= 100)
	{
		ErrMessage(_T("0 < Min.Value < 100"));
	//	SetEditBoxActive(IDC_EDIT_MIN_ALLOWABLE);
	}
	else if (subData.dMaxPower <= 0 || subData.dMaxPower >= 100)
	{
		ErrMessage(_T("0 < Max.Value < 100"));
	//	SetEditBoxActive(IDC_EDIT_MAX_ALLOWABLE);
	}

	if(subData.dHoleSize < 0.001 || subData.dHoleSize > 2.0)
	{
		ErrMessage(_T("0.001 < HoleSize < 2.0"));
	//	SetEditBoxActive(IDC_EDIT_HOLE_SIZE);
	}


	return TRUE;
}

void CPaneRecipeGenParameterNewNext::SetEditBoxActive(int i)
{
	GetDlgItem(i)->SetFocus();
	CEdit* pEdit = static_cast<CEdit*>(GetDlgItem(i));
	pEdit->SetSel(0, -1);
}

void CPaneRecipeGenParameterNewNext::UpdateListData(CPoint nPos, CString strData)
{	
	CString str, strInfo, strTemp, strMessage, strAOM1, strAOM2;
	strInfo.Format(_T(""));

	int nToolNo, nSubToolNo;
	GetToolSubtoolNo(m_posClicked.x, nToolNo, nSubToolNo);

	if(-1 == nToolNo) 
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}
	
	if(-1 == nSubToolNo)
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}

	// ������ ��� 
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nToolNo];

	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubToolNo) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	if(i == -1) return;

	subData = pToolCode->m_SubToolData.GetAt(pos);	// �̳� �� ���� 

	// ������ ������Ʈ
	if(nPos.y == 1)
	{
		//tool type
		if(subData.nToolType != GetSelectToolType())
		{
			strTemp.Format(_T("| SubType = %d"), GetSelectToolType());
			strInfo += strTemp;
		}
		subData.nToolType = GetSelectToolType();
		
	}
	else if(nPos.y  == 2)
	{
		pToolCode->m_nToolColor = GetSelectColor();
		
	}
	else if(nPos.y  == 3)
	{
		// size
		if(pToolCode->m_nToolSize !=atoi(strData))
		{
			strTemp.Format(_T("| Size = %d"), atoi(strData));
			strInfo += strTemp;
		}
		pToolCode->m_nToolSize = atoi(strData);

	}
	else if(nPos.y  == 4)
	{
		// use tool order
		if(pToolCode->m_bToolOrder != GetSelectUseToolOrder())
		{
			strTemp.Format(_T("| ToolOrder = %d"), GetSelectUseToolOrder());
			strInfo += strTemp;
		}
		pToolCode->m_bToolOrder = GetSelectUseToolOrder();
	}

	else if(nPos.y  == 5)
	{
		// prewrok power
		if(pToolCode->m_bPreworkPower != GetSelectPrePower())
		{
			strTemp.Format(_T("| PreworkPower = %d"), GetSelectUseToolOrder());
			strInfo += strTemp;
		}
		pToolCode->m_bPreworkPower = GetSelectPrePower();
	}
	else if(nPos.y  == 6)
	{
		// power min
		if(subData.dMinPower != atof(strData) )
		{
			strTemp.Format(_T("| MinPower = %d"), atof(strData));
			strInfo += strTemp;
		}
		subData.dMinPower = atof(strData);
	}
	else if(nPos.y == 7)
	{
		// power max
		if(subData.dMaxPower != atof(strData) )
		{
			strTemp.Format(_T("| MaxPower = %d"), atof(strData));
			strInfo += strTemp;
		}
		subData.dMaxPower = atof(strData);
	}
	else if(nPos.y  == 8)
	{
		// beam path
		if(subData.nMask != GetSelectBeampath() )
		{
			strTemp.Format(_T("| BeamPath = %d"), GetSelectBeampath());
			strInfo += strTemp;
		}
		subData.nMask = GetSelectBeampath();
	}
	else if(nPos.y  == 9)
	{
		// ����
	}
	else if(nPos.y  == 10)
	{
		// Drill Method
		if(subData.nShotMode !=  GetSelectDrillMethod())
		{
			strTemp.Format(_T("| SubShotMode = %d"), GetSelectDrillMethod());
			strInfo += strTemp;
	}
		subData.nShotMode = GetSelectDrillMethod();
	}
	else if(nPos.y  == 11)
	{
		// Total Shot
		if(subData.nTotalShot != atoi(strData))
		{
			strTemp.Format(_T("| SubTS = %d"), atoi(strData));
			strInfo += strTemp;
	}
		subData.nTotalShot = atoi(strData);
	}
	else if(nPos.y  == 12)
	{
		// Burst Shot
		if(subData.nLeadIn != atoi(strData))
		{
			strTemp.Format(_T("| SubLIn = %d"), atoi(strData));
			strInfo += strTemp;
	}
		subData.nBurstShot = atoi(strData);
	}
	else if(nPos.y  == 13)
	{
		// ����
	}
	else if(nPos.y  == 14)
	{
		// DrawStep
		if(subData.dDrawStep !=  atoi(strData))
		{
			strTemp.Format(_T("| SubDS = %d"),  atoi(strData));
			strInfo += strTemp;
		}
		subData.dDrawStep = atoi(strData);
	}
	else if(nPos.y  == 15)
	{
		// JumpStep
		if(subData.nJumpStep != atoi(strData))
		{
			strTemp.Format(_T("| SubJS = %d"), atoi(strData));
			strInfo += strTemp;
	}
		subData.nJumpStep = atoi(strData);
	}
	else if(nPos.y  == 16)
	{
		// Step Period
		if(subData.nJumpStepPeriod != atoi(strData))
		{
			strTemp.Format(_T("| SubJSP = %d"), atoi(strData));
			strInfo += strTemp;
	}
		subData.nJumpStepPeriod = atoi(strData);
	}
	else if(nPos.y  == 17)
	{
		// CornerDelay
		if(subData.nCornerDelay != atoi(strData))
		{
			strTemp.Format(_T("| SubCD = %d"), atoi(strData));
			strInfo += strTemp;
		}
		subData.nCornerDelay = atoi(strData);
	}
	else if(nPos.y  == 18)
	{
		// JumpDelay
		if(subData.nJumpDelay != atoi(strData))
		{
			strTemp.Format(_T("| SubJD = %d"), atoi(strData));
			strInfo += strTemp;
		}
		subData.nJumpDelay = atoi(strData);
	}
	else if(nPos.y  == 19)
	{
		// LineDelay
		if(subData.nLineDelay != atoi(strData))
		{
			strTemp.Format(_T("| SubLD = %d"), atoi(strData));
			strInfo += strTemp;
		}
		subData.nLineDelay = atoi(strData);
	}
	else if(nPos.y  == 20)
	{
		// LaserOnDelay
		if(subData.nLaserOffDelay !=  atoi(strData))
		{
			strTemp.Format(_T("| SubLOFFD = %d"),  atoi(strData));
			strInfo += strTemp;
		}
		subData.nLaserOnDelay = atoi(strData);
	}
	else if(nPos.y  == 21)
	{
		// LaserOffDelay
		if(subData.nFrequency != atoi(strData))
		{
			strTemp.Format(_T("| SubFreq = %d"), atoi(strData));
			strInfo += strTemp;
		}
		subData.nLaserOffDelay = atoi(strData);
	}
	else if(nPos.y  == 22)
	{
		// Frequency
		if(subData.nFPS != atoi(strData))
		{
			strTemp.Format(_T("| SubFPS = %d"), atoi(strData));
			strInfo += strTemp;
		}
		subData.nFrequency = atoi(strData);
	}
	else if(nPos.y ==23)
	{
		//aom
		for(int i = 0; i < MAX_BEAM_HOLE; i++)
		{
			if(subData.dShotDuty[i] != m_dDuty[i])
			{
				strTemp.Format(_T("| %d duty = %.3f"), i, m_dDuty[i]);
				strInfo += strTemp;
			}
			subData.dShotDuty[i] = m_dDuty[i];
			
			if(subData.dShotAOMDelay[i] != m_dAOMDelay[i])
			{
				strTemp.Format(_T("| %d duty = %.3f"), i, m_dAOMDelay[i]);
				strInfo += strTemp;
			}
			subData.dShotAOMDelay[i] = m_dAOMDelay[i];
			
			if(subData.dShotAOMDuty[i] != m_dAOMDuty[i])
			{
				strTemp.Format(_T("| %d duty = %.3f"), i, m_dAOMDuty[i]);
				strInfo += strTemp;
			}
			subData.dShotAOMDuty[i] = m_dAOMDuty[i];
			
			strAOM1.Format(_T("%s"), subData.cAOMFilePath[i]);
			strAOM2.Format(_T("%s"), m_cAOMFilePath[i]);
			if(0 != strAOM1.CompareNoCase(strAOM2))
			{
				strTemp.Format(_T("| %d AOM file = %s"), i, m_cAOMFilePath[i]);
				strInfo += strTemp;
			}
			memcpy(subData.cAOMFilePath[i], m_cAOMFilePath[i], 255);
		}
	}

	//�Է� �Ķ���� ���� üũ 
	CheckSubTool(subData, nToolNo);


	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nToolNo] = pToolCode;

	if(0 != strInfo.CollateNoCase(""))
	{
// 		if(m_bGlobalParam)		//manual->param�� ���� 
// 		{
// 			if(!gVariable.SaveGlobalTool())
// 			{
// 				ErrMsgDlg(STDGNALM111);
// 			}
// /*			if(pToolCode->m_nToolNo == 0)
// 				strMessage.Format(_T("AGC %d is changed. "), subData.nSubToolNo);
// 			else */
// 			if(pToolCode->m_nToolNo == 0)
// 				strMessage.Format(_T("One Hole Param. %d is changed. "), subData.nSubToolNo);
// 			else
// 				strMessage.Format(_T("PowerMeasurement Param. %d is changed. "), subData.nSubToolNo);
// 		}
// 		else
//		{
			strMessage.Format(_T("Tool %d (sub : %d) is changed. "), nToolNo, subData.nSubToolNo);
//		}
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strInfo));
	}


}

void CPaneRecipeGenParameterNewNext::SetSelectToolType(int nSelect)
{
	m_bSelectToolType = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectToolType()
{
	BOOL nMode = m_bSelectToolType;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectColor(int nSelect)
{
	m_bSelectColor = nSelect;

}

int CPaneRecipeGenParameterNewNext::GetSelectColor()
{
	BOOL nMode = m_bSelectColor;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectUseToolorder(int nSelect)
{
	m_bSelectUseToolOrder = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectUseToolOrder()
{
	BOOL nMode = m_bSelectUseToolOrder;;
	return nMode;
}


void CPaneRecipeGenParameterNewNext::SetSelectPreheat(int nSelect)
{
	m_bSelectPreheat = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectPreheat()
{
	BOOL nMode = m_bSelectPreheat;;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectPrePower(int nSelect)
{
	m_bSelectPreworkPower = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectPrePower()
{
	BOOL nMode = m_bSelectPreworkPower;;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectPreScanner(int nSelect)
{
	m_bSelectPreworkScanner = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectPreScanner()
{
	BOOL nMode = m_bSelectPreworkScanner;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectBeampath(int nSelect)
{
	m_bSelectBeampath = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectBeampath()
{
	BOOL nMode = m_bSelectBeampath;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::SetSelectDrillMethod(int nSelect)
{
	m_bSelectDrillMethod = nSelect;
}

int CPaneRecipeGenParameterNewNext::GetSelectDrillMethod()
{
	BOOL nMode = m_bSelectDrillMethod;;
	return nMode;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboAddDel()
{
	m_posAddDelClicked = m_posClicked;	// ���� Ŭ���� ��ġ ���� 
	
	int nNo = m_comAddDel.GetCurSel();
	
	if(nNo == 0)
		SetAddDel(FALSE);
	else if(nNo ==1)
		SetAddDel(TRUE);

}

void CPaneRecipeGenParameterNewNext::OnKillFocusComboAddDel()
{
	if(m_posAddDelClicked != m_posClicked) //add,del �޺��ڽ� ��ġ ���� ���̶�, ��Ŀ�� �������� ��ġ�� �ٸ�
	{
		SetCloseControl();
		DeleteList();
		ChangeDisplay();
		SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
		return ;	
	}
	
	int nSel = GetAddDel();
	if(nSel == 0)
		
		AddSubTool();
	else if(nSel ==1)
		DelSubTool();
	
	SetCloseControl();
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
}


void CPaneRecipeGenParameterNewNext::OnSelchangeComboToolType()
{
	int nNo = m_comToolType.GetCurSel();
	
	if(nNo == 0)
		SetSelectToolType(MARKING_TYPE);
	else if(nNo ==1)
		SetSelectToolType(SHOT_DRILL_TYPE);
	
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboToolType()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"");	// �޺��ڽ��� ��Ŀ���� �������� ��ġ�� �˱� ������ �̰����� ������ ������Ʈ�Ѵ�. 
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboColor()
{
	int nNo = m_comColor.GetCurSel();

	SetSelectColor(nNo);
	
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboColor()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"color");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboUseToolOrder()
{
	int nNo = m_comUseToolOrder.GetCurSel();
	if(nNo ==0)
		SetSelectUseToolorder(FALSE);
	else if(nNo == 1)
		SetSelectUseToolorder(TRUE);
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboUseToolOrder()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"usetoolorder");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboPreheat()
{
	int nNo = m_comPreheat.GetCurSel();

	if(nNo ==0)
		SetSelectPreheat(FALSE);
	else if(nNo == 1)
		SetSelectPreheat(TRUE);
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboPreheat()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"preheat");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboPrePower()
{
	int nNo = m_comPower.GetCurSel();
	
	if(nNo ==0)
		SetSelectPrePower(FALSE);
	else if(nNo == 1)
		SetSelectPrePower(TRUE);
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboPrePower()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"prepower");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboPreScanner()
{
	int nNo = m_comScanner.GetCurSel();
	
	if(nNo ==0)
		SetSelectPreScanner(FALSE);
	else if(nNo == 1)
		SetSelectPreScanner(TRUE);
}
void CPaneRecipeGenParameterNewNext::OnKillFocusComboPreScanner()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"prescanner");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext:: OnSelchangeComboBeampath()
{
	int nNo = m_comBeamPath.GetCurSel();
	
	SetSelectBeampath(nNo);

}

void CPaneRecipeGenParameterNewNext::OnKillFocusComboBeampath()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"beampath");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

void CPaneRecipeGenParameterNewNext::OnSelchangeComboDrillMethod()
{	
	int nNo = m_comDrillMethod.GetCurSel();

	if(nNo ==0)
		SetSelectDrillMethod(0);	//Burst
	else if(nNo == 1)
		SetSelectDrillMethod(1);	//Cycle
	else if(nNo ==2)
		SetSelectDrillMethod(2);	//Step

}

void CPaneRecipeGenParameterNewNext::OnKillFocusComboDrillMethod()
{
	SetCloseControl();
	UpdateListData(m_posClicked,"drillmethod");
	DeleteList();
	ChangeDisplay();
	SetCurrentScrollPos(m_posClicked.x, m_posClicked.y);
	m_bClickListofLeftMouse = FALSE;
}

int CPaneRecipeGenParameterNewNext::LimitClickforMarkShot(CPoint Position)
{
	int nToolNo, nSubToolNo;
	GetToolSubtoolNo(Position.x, nToolNo, nSubToolNo);
	
	
	// ������ ��� 
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nToolNo];
	
	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubToolNo) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	
	subData = pToolCode->m_SubToolData.GetAt(pos);	// �̳� �� ���� 

	if(subData.nToolType == MARKING_TYPE)
		return MARKING_TYPE;
	else if(subData.nToolType == SHOT_DRILL_TYPE)
		return SHOT_DRILL_TYPE;

	return -1;// error
}

void CPaneRecipeGenParameterNewNext::OnButtonParamOpenNext() 
{

// 	int nToolNo, nSubToolNo;
// 	GetToolSubtoolNo(m_posClicked.x, nToolNo, nSubToolNo);
// 
// 	int sel = m_nToolIndex;
// 	if(-1 == sel)
// 	{
// 		ErrMessage(IDS_PARAM_TOOL);
// 		return;
// 	}
// 
// 
// 	{
// 		ErrMessage(IDS_PARAM_TOOL);
// 		return;
// 	}
/*
	if(m_bGlobalParam)
	{
		if(nListIndex == 0)
		{
			if(IDNO == ErrMessage(_T("S.Cal Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO | MB_ICONQUESTION))
				return;
		}
		else if(nListIndex == 1)
		{
			if(IDNO == ErrMessage(_T("OneHole Tool�� �����Ͻðڽ��ϱ�?"), MB_YESNO| MB_ICONQUESTION))
				return;
		}
	}
	else
	{
		CString strMsg;
		strMsg.Format(_T("%d�� Tool�� �����Ͻðڽ��ϱ�?"), nListIndex);
		if(IDNO == ErrMessage(strMsg, MB_YESNO| MB_ICONQUESTION))
			return;
	}
*/
	//
	TCHAR BASED_CODE szFilter[] = _T("PEN File (*.pen)|*.pen|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.pen"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	
	if(IDOK != dlg.DoModal())
	{
		m_ParamList.SetFocus();
		return;
	}
	//
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(dlg.GetPathName(), CFile::modeRead))
		{
			return;
		}
		CArchiveMark ar(&file, CArchive::load);
		CToolCodeList* pToolCode;
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			pToolCode = m_pToolCode[i];			
			pToolCode->LoadFile10000(ar, 10011);
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH

	file.Close();
	
//	if(!ChangeDataMain(sel))
//		return;

	DeleteList();
	ChangeDisplay();
	m_ParamList.SetFocus();	
}

void CPaneRecipeGenParameterNewNext::OnButtonParamSaveNext() 
{
	TCHAR BASED_CODE szFilter[] = _T("PEN File (*.pen)|*.pen|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(FALSE, _T("*.pen"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetParameterDir();
	
	if(IDOK != dlg.DoModal())
	{
		m_ParamList.SetFocus();
		return;
	}
	
	//
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(dlg.GetPathName(), CFile::modeWrite|CFile::modeCreate))
		{
			return;
		}
		CArchiveMark ar(&file, CArchive::store);
		CToolCodeList* pToolCode;
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			pToolCode = m_pToolCode[i];
			pToolCode->SaveFile10000(ar, 10011);
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
		
	m_ParamList.SetFocus();	
}

void CPaneRecipeGenParameterNewNext::OnButtonAom()
{
	int nToolNo, nSubToolNo;
 	GetToolSubtoolNo(m_posClicked.x, nToolNo, nSubToolNo);

	int sel = nToolNo;
	if(-1 == sel) 
	{
		ErrMessage(IDS_PARAM_TOOL);
		return;
	}
	
	int selSub = nSubToolNo;
	if(-1 == selSub) 
	{
		ErrMessage(IDS_PARAM_SUB_TOOL);
		return;
	}
	

		
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nToolNo];
	
	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;
		
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}
	
	subData = pToolCode->m_SubToolData.GetAt(pos);
	

	int nShotCount = 0;
	nShotCount = subData.nTotalShot;
	
	if( nShotCount <= 0 || nShotCount > 15)
	{
		ErrMessage(IDS_SHOT_COUNT_INPUT_ERR, MB_ICONERROR);
		
		m_ParamList.SetFocus();
		return;
	}
	
	for(int i = 0; i<MAX_BEAM_HOLE; i++)
	{
		m_dDuty[i] = subData.dShotDuty[i];
		m_dAOMDelay[i] = subData.dShotAOMDelay[i];
		m_dAOMDuty[i] = subData.dShotAOMDuty[i];
		memcpy(m_cAOMFilePath[i], subData.cAOMFilePath[i], 255);
	}
	
	CDlgLaserBeamHoleSet dlg;
	
//	dlg.SetFireHole( nShotCount, m_dDuty, m_dAOMDelay, m_dAOMDuty, &m_cAOMFilePath[0], m_bGlobalParam);
	
	if(IDOK != dlg.DoModal())
	{
		m_ParamList.SetFocus();
		return;
	}
	
//	dlg.GetFireHole(m_dDuty, m_dAOMDelay, m_dAOMDuty, &m_cAOMFilePath[0]);	
	m_ParamList.SetFocus();

}

void CPaneRecipeGenParameterNewNext::CheckAnyDoPrework()
{
	POSITION gPos, mPos; //global, member
	SUBTOOLDATA gSubTool, mSubTool;
	int gSubNo, mSubNo;
	BOOL bChangeSCal = FALSE, bChangePower = FALSE;
	BOOL bASCNo[BEAMPATH_COUNT];
	memset(bASCNo, 0, sizeof(bASCNo));
	TCHAR gAsc[256] = {0,};
	TCHAR mAsc[256] = {0,};

	int nBeamPathNo[BEAMPATH_COUNT], nBeamPathNoNew[BEAMPATH_COUNT], nCount = 0, nCountNew = 0;

	for(int i =0; i< MAX_TOOL_NO; i++)
	{
		gPos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(gPos)
		{
			if(nCount >= BEAMPATH_COUNT)
			{
				bChangeSCal = TRUE;
				break;
			}
			gSubTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(gPos);

			for(int j = 0; j < gBeamPathINI.m_sBeampath.nLastIndex; j++)
			{
				if(strcmp(gBeamPathINI.m_sBeampath.strBeamPathAscFile[j], gBeamPathINI.m_sBeampath.strBeamPathAscFile[gSubTool.nMask]) == 0)
				{
					nBeamPathNo[nCount] = j;
					nCount++;
					break;
				}
			}
		}
		mPos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(mPos)
		{
			if(nCountNew >= BEAMPATH_COUNT)
			{
				bChangeSCal = TRUE;
				break;
			}
			mSubTool = m_pToolCode[i]->m_SubToolData.GetNext(mPos);
			for(int j = 0; j < gBeamPathINI.m_sBeampath.nLastIndex; j++)
			{
				if(strcmp(gBeamPathINI.m_sBeampath.strBeamPathAscFile[j], gBeamPathINI.m_sBeampath.strBeamPathAscFile[mSubTool.nMask]) == 0)
				{
					nBeamPathNoNew[nCountNew] = j;
					nCountNew++;
					break;
				}
			}
		}
	}
	for(int i = 0; i < nCountNew; i++)
	{
		BOOL bDiff = TRUE;
		for(int j = 0; j < nCount; j++)
		{
			if(nBeamPathNoNew[i] == nBeamPathNo[j])
			{
				bDiff = FALSE;
				break;
			}
		}
		if(bDiff)
		{
			bChangeSCal = TRUE;
			break;
		}
	}

	for(int i =0; i< MAX_TOOL_NO; i++)
	{
		gPos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		mPos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		
		gSubNo = gDProject.m_pToolCode[i]->m_nTotalSubNo;
		mSubNo = m_pToolCode[i]->m_nTotalSubNo;

		if(!gDProject.m_pToolCode[i]->m_bPreworkPower && m_pToolCode[i]->m_bPreworkPower)
		{
			bChangePower = TRUE;
		}

		while(mPos && gPos)
		{
			gSubTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(gPos);
			mSubTool = m_pToolCode[i]->m_SubToolData.GetNext(mPos);

			if(m_pToolCode[i]->m_bPreworkPower) 
			{
				if(	gSubTool.nMask != mSubTool.nMask || 
					gSubTool.dMaxPower != mSubTool.dMaxPower || 
					gSubTool.dMinPower != mSubTool.dMinPower || 
					gSubTool.dShotDuty[0] != mSubTool.dShotDuty[0] ||
					gSubTool.dShotAOMDelay[0] != mSubTool.dShotAOMDelay[0] ||
					gSubTool.dShotAOMDuty[0] != mSubTool.dShotAOMDuty[0] || 
					(strcmp(gSubTool.cAOMFilePath[0], mSubTool.cAOMFilePath[0]) != 0) )
						bChangePower = TRUE;
			}
		}

		 // subtool�� �߰��Ȱ�� 
		//Power ������ ù��° �������� �ϴϱ� �ٽ� üũ�� �ʿ� ���� 
		if(mSubNo > gSubNo)
		{
			while(mPos)
			{
				mSubTool = m_pToolCode[i]->m_SubToolData.GetNext(mPos);
				
				if(m_pToolCode[i]->m_bPreworkPower) 
				{
					bChangePower = TRUE;
				}
			}
		}
	}

	if(bChangeSCal && bChangePower)
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
	else if(bChangeSCal && !bChangePower)
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
	else if(bChangePower && !bChangeSCal)
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER);
}
