// DlgMarkingParam.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgMarkingParam.h"
#include "..\Model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgMarkingParam dialog


CDlgMarkingParam::CDlgMarkingParam(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMarkingParam::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgMarkingParam)
	m_nJumpDelay = 0;
	m_nCornerDelay = 0;
	m_dJumpSpeed = 0;
	m_nLineDelay = 0;
	m_nPreMove = 0;
	m_nJumpDelayShot = 0;
	//}}AFX_DATA_INIT
}


void CDlgMarkingParam::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgMarkingParam)
	DDX_Control(pDX, IDC_EDIT_JUMP_SPEED, m_edtJumpSpeed);
	DDX_Control(pDX, IDC_EDIT_JUMP_DELAY, m_edtJumpDelay);
	DDX_Control(pDX, IDC_EDIT_CORNER_DELAY, m_edtCornerDelay);
	DDX_Control(pDX, IDC_EDIT_LINE_DELAY, m_edtLineDelay);
	DDX_Control(pDX, IDC_EDIT_PREMOVE, m_edtPreMove);
	DDX_Control(pDX, IDC_EDIT_JUMP_DELAY2, m_edtJumpDelayShot);
	DDX_Text(pDX, IDC_EDIT_JUMP_DELAY, m_nJumpDelay);
	DDX_Text(pDX, IDC_EDIT_CORNER_DELAY, m_nCornerDelay);
	DDX_Text(pDX, IDC_EDIT_JUMP_SPEED, m_dJumpSpeed);
	DDX_Text(pDX, IDC_EDIT_LINE_DELAY, m_nLineDelay);
	DDX_Text(pDX, IDC_EDIT_PREMOVE, m_nPreMove);
	DDX_Text(pDX, IDC_EDIT_JUMP_DELAY2, m_nJumpDelayShot);
	
	//}}AFX_DATA_MAP
}


BOOL CDlgMarkingParam::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitStaticControl();
	InitEditControl();

	ChangeDisplay();

	return TRUE;
}
BEGIN_MESSAGE_MAP(CDlgMarkingParam, CDialog)
	//{{AFX_MSG_MAP(CDlgMarkingParam)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgMarkingParam message handlers

void CDlgMarkingParam::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_JUMP_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_JUMP_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CORNER_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LINE_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREMOVE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_JUMP_DELAY2)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_JUMP_DELAY2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_AOM_PER7)->ShowWindow(SW_SHOW);

}

void CDlgMarkingParam::InitEditControl()
{
	m_fntEdit.CreatePointFont(100, "Arial Bold");
	// Jump Speed
	m_edtJumpSpeed.SetFont( &m_fntEdit );
	m_edtJumpSpeed.SetReceivedFlag( 3 );
	m_edtJumpSpeed.SetWindowText( _T("0") );
	
	// Corner Delay
	m_edtCornerDelay.SetFont( &m_fntEdit );
	m_edtCornerDelay.SetReceivedFlag( 1);
	m_edtCornerDelay.SetWindowText( _T("0") );
	
	// Jump Delay
	m_edtJumpDelay.SetFont( &m_fntEdit );
	m_edtJumpDelay.SetReceivedFlag( 1 );
	m_edtJumpDelay.SetWindowText( _T("0") );
	
	//Line Delay
	m_edtLineDelay.SetFont( &m_fntEdit );
	m_edtLineDelay.SetReceivedFlag( 1 );
	m_edtLineDelay.SetWindowText( _T("0") );

	//Premove
	m_edtPreMove.SetFont( &m_fntEdit );
	m_edtPreMove.SetReceivedFlag( 1 );
	m_edtPreMove.SetWindowText( _T("0") );

	//Jump Delay
	m_edtJumpDelayShot.SetFont( &m_fntEdit );
	m_edtJumpDelayShot.SetReceivedFlag( 1 );
	m_edtJumpDelayShot.SetWindowText( _T("0") );


		m_edtJumpDelayShot.ShowWindow(SW_SHOW);
	
}
void CDlgMarkingParam::ChangeDisplay()
{
	CString str;
	str.Format(_T("%.2f"), m_dJumpSpeed);
	m_edtJumpSpeed.SetWindowText(str);
	
	str.Format(_T("%d"), m_nJumpDelay);
	m_edtJumpDelay.SetWindowText(str);
	
	str.Format(_T("%d"), m_nCornerDelay);
	m_edtCornerDelay.SetWindowText(str);
	
	str.Format(_T("%d"), m_nLineDelay);
	m_edtLineDelay.SetWindowText(str);

	str.Format(_T("%d"), m_nPreMove);
	m_edtPreMove.SetWindowText(str);

	str.Format(_T("%d"), m_nJumpDelayShot);
	m_edtJumpDelayShot.SetWindowText(str);
}
void CDlgMarkingParam::SetData(double dJumpSpeed, int nJumpDelay, int nCornerDelay, int nLineDelay, int nPremove, int nJumpDelayShot)
{
	m_dJumpSpeed = (int)dJumpSpeed;
	m_nJumpDelay = nJumpDelay;
	m_nCornerDelay = nCornerDelay;
	m_nLineDelay = nLineDelay;
	m_nPreMove = nPremove;
	m_nJumpDelayShot = nJumpDelayShot;
}

void CDlgMarkingParam::GetData(double &dJumpSpeed, int &nJumpDelay, int &nCornerDelay, int &nLineDelay, int &nPremove, int &nJumpDelayShot)
{
	dJumpSpeed = m_dJumpSpeed;
	nJumpDelay = m_nJumpDelay;
	nCornerDelay = m_nCornerDelay;
	nLineDelay = m_nLineDelay;
	nPremove = m_nPreMove;
	nJumpDelayShot = m_nJumpDelayShot;
}


BOOL CDlgMarkingParam::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_MarkingParam) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
