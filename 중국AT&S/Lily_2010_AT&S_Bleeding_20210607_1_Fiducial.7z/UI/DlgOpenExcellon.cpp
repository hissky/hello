// DlgOpenExcellon.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgOpenExcellon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenExcellon dialog


CDlgOpenExcellon::CDlgOpenExcellon(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOpenExcellon::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOpenExcellon)

	m_nTZS = 0;
	m_nUnit = 0;
	m_nABS = 0;
	m_nLineDistance = 100;
	m_nLineNo = 1;
	m_bZigZag = TRUE;
	m_nLineExtend = 0;

	m_bCheckApplyManualScale = FALSE;
	m_dManualScaleX = 100.00;
	m_dManualScaleY = 100.00;
	//}}AFX_DATA_INIT
}


void CDlgOpenExcellon::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOpenExcellon)
	DDX_Radio(pDX, IDC_RADIO_TZS, m_nTZS);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nABS);
	DDX_Radio(pDX, IDC_RADIO_1UM, m_nUnit);
	DDX_Text(pDX, IDC_EDT_LINE_DIST, m_nLineDistance);
	DDV_MinMaxUInt(pDX, m_nLineDistance, 1, 100000);
	DDX_Text(pDX, IDC_EDT_LINE_NO, m_nLineNo);
	DDV_MinMaxUInt(pDX, m_nLineNo, 1, 10000);
	DDX_Check(pDX, IDC_CHK_ZIGZAG, m_bZigZag);
	DDX_Check(pDX, IDC_CHECK_APPLY_MANUAL_SCALE, m_bCheckApplyManualScale);

	DDX_Text(pDX, IDC_EDT_LINE_EXTEND, m_nLineExtend);

	DDX_Text(pDX, IDC_EDIT_SCALE_MANUAL_X, m_dManualScaleX);
	DDX_Text(pDX, IDC_EDIT_SCALE_MANUAL_Y, m_dManualScaleY);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgOpenExcellon, CDialog)
	//{{AFX_MSG_MAP(CDlgOpenExcellon)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenExcellon message handlers

void CDlgOpenExcellon::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	CDialog::OnOK();
}


BOOL CDlgOpenExcellon::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	GetDlgItem(IDC_EDIT_SCALE_MANUAL_X)->SetWindowText("100.00");
	GetDlgItem(IDC_EDIT_SCALE_MANUAL_Y)->SetWindowText("100.00");





	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
