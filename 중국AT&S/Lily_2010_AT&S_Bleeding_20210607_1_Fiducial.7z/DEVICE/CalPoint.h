#if !defined(AFX_CALPOINT_H__52DA5491_A776_4B6E_BF53_B2640BA71E4F__INCLUDED_)
#define AFX_CALPOINT_H__52DA5491_A776_4B6E_BF53_B2640BA71E4F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalPoint.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CCalPoint command target

class CCalPoint : public CObject
{
// Attributes
public:
	double PosY;
	double PosX;
	CCalPoint operator=(const int a);
	CCalPoint operator=(CCalPoint Data);
	CCalPoint operator+(CCalPoint Data);
	CCalPoint operator+=(CCalPoint Data);
	CCalPoint(const CCalPoint& Data);

// Operations
public:
	CCalPoint();
	virtual ~CCalPoint();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalPoint)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CCalPoint)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALPOINT_H__52DA5491_A776_4B6E_BF53_B2640BA71E4F__INCLUDED_)
