// HLaserCO2.cpp: implementation of the HLaserCO2 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HLaserCO2.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "..\device\hdevicefactory.h"
///////E400 Feedback/////////////////////
//InLIF0 = POWER_FAIL               --> Power Error
//InLIF1 = FLOW ALARM               --> Water Flow
//InLIF2&InLIF3 = SHUTTER SENSOR    --> Shutter sensor check
//InLIF4 = DUTY CYCLE LIMIT //      --> Frequency ��� duty�� 60% �̻��϶� �Ǵ� duty�� 1ms �̻��϶�(E400 ix �� ��쿡�� duty 20% �̻��̰ų� 100us �̻�)
//InLIF5 = VSWR LIMIT  //			--> laser tube <-> RF amplifier signal missmatch
//InLIF6 = DIGITAL_REFLECTED //		--> Laser Tube, RF Connector, Cable error
//////////////////////-->ETS5/////////////

///////////////////////////////////////////////
//const WORD EO_WARN_FORWARD			= 0x0001;
//const WORD EO_WARN_REFLECT			= 0x0002;
//const WORD EO_WARN_MVSWR			= 0x0004;
//const WORD EO_WARN_DUTY				= 0x0008;
//const WORD EO_STATUS_SHUTTER_ON		= 0x0010;
//const WORD EO_STATUS_SHUTTER_OFF	= 0x0020;
//const WORD EO_ERROR_WATER_ALARM		= 0x0040;
//const WORD EO_ERROR_POWER_FAIL		= 0x0080;
/////////////////////-->ETS4 ���� ��ȯ�ؼ� ����ϴµ�.//////////

const WORD EO_WARN_FORWARD			= 0x0080;
const WORD EO_WARN_REFLECT			= 0x0040;
const WORD EO_WARN_MVSWR			= 0x0020;
const WORD EO_WARN_DUTY				= 0x0010;
const WORD EO_STATUS_SHUTTER_ON		= 0x0008;
const WORD EO_STATUS_SHUTTER_OFF	= 0x0004;
const WORD EO_ERROR_WATER_ALARM		= 0x0002;
const WORD EO_ERROR_POWER_FAIL		= 0x0001;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

HLaserCO2::HLaserCO2()
{
	m_pEOCard	= NULL;
	m_bPower	= FALSE;
	m_bShutter	= FALSE;
}

HLaserCO2::~HLaserCO2()
{
#ifndef __NO_USE_INIT_LASER_IF__
	m_pEOCard->SetFunction(0xFFFF);
#endif

}

void HLaserCO2::Initialize()
{
	m_pEOCard = gDeviceFactory.GetEocard();
#ifndef __NO_USE_INIT_LASER_IF__
	m_pEOCard->SetFunction(0xFFFF);
#else
	//USHORT usFunction;
	//if(m_bPower)
	//	usFunction &= 0xFFFB;
	//else
	//	usFunction |= 0x0005;

	//if(m_bShutter)
	//	usFunction &= 0xFFFD;
	//else
	//	usFunction |= 0x0002;

//	m_pEOCard->SetFunction(usFunction);
#endif

}

BOOL HLaserCO2::IsPowerOn()
{
	return m_bPower;
}

BOOL HLaserCO2::IsShutterOpen(int nHeadNo)
{
	UpdateStatus(nHeadNo);
	return m_bShutter;
}

void HLaserCO2::PowerOn(BOOL bFlag, int nHeadNo)
{
	USHORT usFunction = m_pEOCard->GetFunction(nHeadNo);
	if(bFlag)
	{
		usFunction &= 0xFFFB; // 1011 : power on
// 1011 -> time delay -> 1010
// �̷��� �ؾ� E400 ������
//		m_pEOCard->SetFunction(usFunction);
//		::Sleep(10000);
//		usFunction = m_pEOCard->GetFunction();
//		usFunction &= 0xFFFA;
	}
	else
	{
		usFunction |= 0x0005;
	}
	m_pEOCard->SetFunction(usFunction, nHeadNo);

	if(!bFlag)
		m_bPower = bFlag;
}

void HLaserCO2::ShutterOpen(BOOL bFlag, int nHeadNo)
{
	USHORT usFunction = m_pEOCard->GetFunction(nHeadNo);
	if(bFlag)	usFunction &= 0xFFFD;
	else		usFunction |= 0x0002;
	m_pEOCard->SetFunction(usFunction,nHeadNo);
	
	m_bShutter = bFlag;	
}

POWER_STATUS HLaserCO2::GetStatus(int nHeadNo)
{
	UpdateStatus(nHeadNo);
	return m_gStatus;
}

void HLaserCO2::UpdateStatus(int nHeadNo)
{
	WORD wStat = 0;
	
	if(m_pEOCard == NULL) return;

	m_pEOCard->GetStatus( &wStat, nHeadNo );

//	m_gStatus.bDigitalForward = (wStat & EO_WARN_FORWARD) ?	TRUE : FALSE;
	m_gStatus.bDigitalReflect = (wStat & EO_WARN_REFLECT) ?	TRUE : FALSE;
	m_gStatus.bMVSWR		  = (wStat & EO_WARN_MVSWR) ? FALSE : TRUE;
	m_gStatus.bDutyCycleFlect = (wStat & EO_WARN_DUTY) ? FALSE : TRUE;
	m_gStatus.bShutterOn	  = (wStat & EO_STATUS_SHUTTER_ON) ? TRUE : FALSE;
	m_gStatus.bShutterOff	  = (wStat & EO_STATUS_SHUTTER_OFF) ? TRUE : FALSE;
//	m_gStatus.bWaterAlarm	  = (wStat & EO_ERROR_WATER_ALARM) ? TRUE : FALSE;
//	m_gStatus.bPowerFail	  = (wStat & EO_ERROR_POWER_FAIL) ? TRUE : FALSE;

#ifdef __NO_USE_INIT_LASER_IF__
	m_bPower = !m_gStatus.bDigitalReflect;
#endif

	//TRACE(_T("Head: %d ,Reflect: %d \n"),nHeadNo,m_gStatus.bDigitalReflect);

#ifdef __TEST__
	m_gStatus.bShutterOn = m_bShutter;
	m_gStatus.bPowerOn = m_bPower;
#else

	m_bShutter = m_gStatus.bShutterOn;

	m_gStatus.bPowerOn = m_bPower;
#endif
}

void HLaserCO2::EnableOn(int nHeadNo)
{
	USHORT usFunction = m_pEOCard->GetFunction(nHeadNo);
	usFunction &= 0xFFFA;
	m_pEOCard->SetFunction(usFunction, nHeadNo);
	m_bPower = TRUE;
}
