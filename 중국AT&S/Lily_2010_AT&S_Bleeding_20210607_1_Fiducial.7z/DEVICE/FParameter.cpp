// FParameter.cpp: implementation of the FParameter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FParameter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

FParameter::FParameter()
{
	Reset() ;
}

FParameter::~FParameter()
{

}

void FParameter::Reset()
{
	DrawStep = 20 ;
	JumpStep = 200 ;
	StepPeriod = 20 ;
	CornerDelay = 10 ;
	JumpDelay = 600 ;
	LineDelay = 350 ;
	Frequency = 1000 ;
	dDuty = 50 ;
	LaserOnDelay = 400 ;
	LaserOffDelay = 350 ;
	LampCurrent = 64 ;
	PowerChangeDelay = 1700 ;
	dAOMDelay = 0 ;
	dAOMDuty = 50;
	cAOMFilePath[0] = NULL;
	BreakAngle = 180 ;
	AutoSegmentation = 0 ;

	CycleTime = 2; // yhchung 070214 add
	FPSDelay  = 10;
	
	DrawStepPeriod = 15;
	MinShotTime = 400;
}

void FParameter::Copy(FParameter *ptr)
{
	DrawStep = ptr -> DrawStep ;
	JumpStep = ptr -> JumpStep ;
	StepPeriod = ptr -> StepPeriod ;
	CornerDelay = ptr -> CornerDelay ;
	JumpDelay = ptr -> JumpDelay ;
	LineDelay = ptr -> LineDelay ;
	Frequency = ptr -> Frequency ;
	dDuty = ptr -> dDuty ;
	LaserOnDelay = ptr -> LaserOnDelay ;
	LaserOffDelay = ptr -> LaserOffDelay ;
	LampCurrent = ptr -> LampCurrent ;
	PowerChangeDelay = ptr -> PowerChangeDelay ;
	dAOMDelay = ptr -> dAOMDelay ;
	dAOMDuty = ptr -> dAOMDuty ;
	memcpy(cAOMFilePath, ptr -> cAOMFilePath, 255);
	BreakAngle = ptr -> BreakAngle ;
	AutoSegmentation = ptr -> AutoSegmentation ;

	CycleTime = ptr ->CycleTime;  // yhchung 070214 add
	FPSDelay  = ptr ->FPSDelay ;
	
	DrawStepPeriod = ptr ->DrawStepPeriod ;
	MinShotTime = ptr ->MinShotTime ;

}

