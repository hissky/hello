// MVisionLamp.h: interface for the MVisionLamp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MVISIONLAMP_H__E4C321B0_1689_4042_B43A_AAD4F3EA138C__INCLUDED_)
#define AFX_MVISIONLAMP_H__E4C321B0_1689_4042_B43A_AAD4F3EA138C__INCLUDED_

#include "ProtocolCommand.h"
#define BAUDRATE	19200   // baud rate for serial communication

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MVisionLamp  
{
public:
	MVisionLamp();
	virtual ~MVisionLamp();

	void ConectComPort();
	int LampOut(int channel, int value);
	int CloseSerial();
	void SetComPort(int nPort);

	CString m_strPort;
	HWND m_hCommWnd;
	BOOL m_bComPortInit;
	PROTOCOL m_Protocol;
	ProtocolCommand m_Command;
	CCommThread m_ComuPort;

};

#endif // !defined(AFX_MVISIONLAMP_H__E4C321B0_1689_4042_B43A_AAD4F3EA138C__INCLUDED_)
