// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "IAbstractDriver.h"



//##ModelId=4034007F0082
IAbstractDriver::IAbstractDriver()
{
	// ToDo: Add your specialized code here and/or call the base class
}

//##ModelId=4034007F0083
IAbstractDriver::~IAbstractDriver()
{
	// ToDo: Add your specialized code here and/or call the base class
}



//##ModelId=4034007F006D
bool IAbstractDriver::writeIFCard(const ULONG port, const ULONG data, const char type)
{
	// TODO: Add your specialized code here.
	return (bool)0;
}

//##ModelId=4034007F007D
bool IAbstractDriver::readIFCard(ULONG port, ULONG& data, const char type)
{
	// TODO: Add your specialized code here.
	return (bool)0;
}

