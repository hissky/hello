// HLaserTCP.cpp: implementation of the HLaserTCP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HLaserTCP.h"
#include "ClientSock_Laser.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaserTCP::HLaserTCP()
{
	m_pClientSock_Laser		= NULL;
}

HLaserTCP::~HLaserTCP()
{
	if( NULL != m_pClientSock_Laser)
	{
		delete m_pClientSock_Laser;
		m_pClientSock_Laser = NULL;
	}
}

BOOL HLaserTCP::InitLaserTCP(int nHead)
{
	m_pClientSock_Laser = new CClientSock_Laser();
	//m_pClientSock_Laser->ReConnectTry();
	m_pClientSock_Laser->m_nLaserNo = nHead;
	return m_pClientSock_Laser->m_bConnect;
}

int HLaserTCP::ReceiveCount()
{
	return m_pClientSock_Laser->m_nReceiveCount;
}

BOOL HLaserTCP::ConnectStatus()
{
	return m_pClientSock_Laser->m_bConnect;
}
BOOL HLaserTCP::ReConnect()
{
	m_pClientSock_Laser->ReConnectTry();
	return m_pClientSock_Laser->m_bConnect;
}


CString HLaserTCP::GetLaserTCPTemp(int nTempIndex)
{
	return m_pClientSock_Laser->GetLaserTCPTemp(nTempIndex);
}

int HLaserTCP::GetLaserTCPStatus()
{
	return m_pClientSock_Laser->GetLaserTCPStatus();
}

void HLaserTCP::CloseSocket()
{
	m_pClientSock_Laser->CloseSocket();
}