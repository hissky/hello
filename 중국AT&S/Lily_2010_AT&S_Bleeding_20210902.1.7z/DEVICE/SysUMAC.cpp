// SysUMAC.cpp: implementation of the CSysUMAC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "SysUMAC.h"

#include "runtime.h"

#include "DOnlineCmdData.h"

#include "DHandlerMonitor.h"
#include "DHandlerInput.h"

//#include "DRecipeData.h"
//#include "MultiParam.h"
//#include "EODicingDlg.h"
//#include "SysComiDaq.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//CSysUMAC gSysUMAC;

char* szUMACError[] = {
		_T("Command not allowed during program execution"),
		_T("Password error"),
		_T("Data error or unrecognized command"),
		_T("Illegal character: bad value (>127 ASCII) or serial parity/framing error"),
		_T("Command not allowed unless buffer is open"),
		_T("No room in buffer for command"),
		_T("Buffer already in use"),
		_T("MACRO auxiliary communications error"),
		_T("Program structural error (e.g. ENDIF without IF)"),
		_T("Both overtravel limits set for a motor in the C. S."),
		_T("Previous move not completed"),
		_T("A motor in the coordinate system is open-loop"),
		_T("A motor in the coordinate system is not activated"),
		_T("No motors in the coordinate system"),
		_T("Not pointing to valid program buffer"),
		_T("Running improperly structured program (e.g. missing ENDWHILE)"),
		_T("Trying to resume after H or Q with motors out of stopped position"),
		_T("Attempt to perform phase reference during move, move during phase reference., or enabling with phase clock error."),
		_T("Illegal position-change command while moves stored in CCBUFFER")
};

UINT UMACLoop(LPVOID wndParam)
{
	DWORD dwFlag;

	CSysUMAC* pUmac = (CSysUMAC*)wndParam;

	while(1)
	{
		::Sleep(10);

		// Send Command To UMAC Controller
		pUmac->SendCmdToUMAC();

		// Is Execution Motion
		pUmac->IsExecutionMotion();

		dwFlag = ::WaitForSingleObject( pUmac->m_EvtTerminate.m_hObject, 0 );
		if( WAIT_OBJECT_0 == dwFlag )
		{
			TRACE(_T("BREAK UMAC WHILE LOOP\n"));
			break;
		}
	}
	TRACE(_T("TERMINATE UMAC THREAD\n"));
	pUmac->m_EvtGoodbye.SetEvent();

	return 0L;
}

CSysUMAC::CSysUMAC()
{
	m_bDriverOpen			= FALSE;
	m_dwDevice				= 0;
	m_hPmacLib				= NULL;
	m_pThread				= NULL;
	m_clsCmdQueue.DeleteAllQueue();
	m_nMonitorIndex				= 0; 
	m_bCheckMotionStatus	= FALSE;
	m_nMotionStatus			= 0; // 0 : FINISH, 1 : EXECUTION, 2 : IDLE
	m_bMotionError			= 0;	// 0 : No Error, 1 : Error
	m_nHandlerInputIndex	= 0;
	m_strUMACErrMsg.Format(_T(""));
	memset( m_nSysHandlerParam, 0, sizeof(m_nSysHandlerParam) );
	memset( m_nUploadSysHandlerParam, 0, sizeof(m_nUploadSysHandlerParam) );
	memset( m_nSysCoaterParam, 0, sizeof(m_nSysCoaterParam) );
	memset( m_nUploadSysCoaterParam, 0, sizeof(m_nUploadSysCoaterParam) );
	memset( m_nCoatingParam, 0, sizeof(m_nCoatingParam) );
	memset( m_nUploadCoatingParam, 0, sizeof(m_nUploadCoatingParam) );
	memset( m_nCleaningParam, 0, sizeof(m_nCleaningParam) );
	memset( m_nUploadCleaningParam, 0, sizeof(m_nUploadCleaningParam) );
	m_bHandlerSysDownload		= 0;
	m_bSpinnerSysDownload		= 0;
	m_bHandlerSysUpload			= 0;
	m_bSpinnerSysUpload			= 0;
	m_bCoatingParamDownload		= 0;
	m_bCleaningParamDownload	= 0;
	m_bCoatingParamUpload		= 0;
	m_bCleaningParamUpload		= 0;
	m_nCoatingParamSize			= 0;
	m_nCleaningParamSize		= 0;
}

CSysUMAC::~CSysUMAC()
{

}

BOOL CSysUMAC::InitializeUMAC()
{
#ifdef USE_NO_MOTOR
	return TRUE;
#endif

	TCHAR vs[30], ds[30];

	// Get handle to PMAC.DLL
	if(!m_hPmacLib)
		m_hPmacLib = OpenRuntimeLink();
	
	if(m_hPmacLib == NULL)
		return FALSE;
	
	// UMAC Device Open 
	if(m_bDriverOpen)
		return TRUE;
	 
	m_bDriverOpen = DeviceOpen(m_dwDevice);

	if(m_bDriverOpen)
	{
		DeviceGetRomVersion(m_dwDevice,vs,30);
		DeviceGetRomDate(m_dwDevice,ds,30);		
	}
	else 
	{
		// Try Menual Device Connection.
		if ( !PmacConfigureComm(NULL))
		{
			return FALSE;
		}		
	}

	return TRUE;
}

BOOL CSysUMAC::PmacConfigureComm(HWND Wnd)
{
	TCHAR vs[30], ds[30];
	
	if(m_bDriverOpen)
	{
		m_bDriverOpen = !DeviceClose(m_dwDevice);
	}
	
	// Configure Device
	if(DevicePmacConfigure(Wnd,m_dwDevice)) // ReOpen PMAC Device
		m_bDriverOpen = DeviceOpen(m_dwDevice);
	else
		m_bDriverOpen = FALSE;
	
	// Setup View to reflect device open status
	if(m_bDriverOpen)
	{
		DeviceGetRomVersion(m_dwDevice,vs,30);
		DeviceGetRomDate(m_dwDevice,ds,30);
	}
	else
	{
		//ErrMessage(_T("Could not initialize PMAC Comm."));
		return FALSE;
	}

	return TRUE;
}

void CSysUMAC::DestroyUMAC()
{
	// Terminate Thread
	StopUMACThread();
	// Close UMAC LIB
	CloseRuntimeLink();
	// Delete Command Queue
	m_clsCmdQueue.DeleteAllQueue();
}

BOOL CSysUMAC::StartUMACThread()
{
#ifdef USE_NO_MOTOR
	return TRUE;
#endif

	if( NULL == m_pThread )
	{
		m_pThread = ::AfxBeginThread( UMACLoop, this, THREAD_PRIORITY_NORMAL );
		m_clsCmdQueue.AddOnlineCmd(_T("p8000=2"));
		m_clsCmdQueue.AddOnlineCmd(_T("m4000=0"));
		m_clsCmdQueue.AddOnlineCmd(_T("m4001=0"));
		m_clsCmdQueue.AddOnlineCmd(_T("m4002=0"));
		m_clsCmdQueue.AddOnlineCmd(_T("m4003=0"));
	}
	ASSERT( NULL != m_pThread );

	return TRUE;
}

void CSysUMAC::StopUMACThread()
{
#ifdef USE_NO_MOTOR
	return;
#endif

	if( NULL != m_pThread )
	{
		m_EvtTerminate.SetEvent();
		::WaitForSingleObject( m_EvtGoodbye.m_hObject, INFINITE );
		m_pThread = NULL;
	}
}

BOOL CSysUMAC::DPRRealTimeEx(long mask, UINT period, long on)
{
	return DeviceDPRRealTimeEx(m_dwDevice,mask,period,on);
}

BOOL CSysUMAC::DPRUpdateRealtime()
{
	return DeviceDPRUpdateRealtime(m_dwDevice);
}

double CSysUMAC::DPRPosition(int i, double units)
{
	return DeviceDPRPosition( m_dwDevice,i, units);
}

double CSysUMAC::DPRGetVel(int i, double units)
{
	return DeviceDPRGetVel( m_dwDevice, i, units );
}

BOOL CSysUMAC::GetResponse(PCHAR a, UINT maxchar, PCHAR q)
{
	if(m_bDriverOpen && DeviceGetResponse(m_dwDevice,a,maxchar,q) > 0)
		return TRUE;		
	else
		return FALSE;	
}

BOOL CSysUMAC::SendCmdToUMAC()
{
	if( TRUE == m_clsCmdQueue.IsEmptyQueue() )
	{
		//SendHandlerMonitor();
		SendHandlerInput();
	}
	else
	{
		DOnlineCmdData*	pData = NULL;

		pData = (DOnlineCmdData*)m_clsCmdQueue.GetOnlineCmdData();

		if( NULL != pData )
		{
			char szBuf[255] = {0,};

			if( FALSE == pData->IsOnlineData() )
			{//Send Online Command
				GetResponse(szBuf, 255, pData->GetOnlineCmd());
				SetOnlineCmdResponse(pData->GetOnlineCmd(), szBuf);
				//TRACE(_T("SEND CMD : %s, RECEIVE DATA : %s\n"), pData->GetOnlineCmd(), szBuf);
			}
			else
			{// Send DPRAM Data
				if( TRUE == pData->GetIsFloat() )
				{// float type
					DeviceDPRSetMem(m_dwDevice, pData->GetMemOffset(), 
									pData->GetMemSize(), pData->GetDPRamFloatData() );
				}
				else
				{// dword type
					if( FALSE == pData->GetReadDPRam() )
					{// Write DPRAM
						DeviceDPRSetMem(m_dwDevice, pData->GetMemOffset(),
										pData->GetMemSize(), pData->GetDPRamDWORDData() );
						SetDPRamDataType( pData->GetDataType(), 0 );
					}
					else
					{// Read DPRAM for monitoring
						DeviceDPRGetMem(m_dwDevice, pData->GetMemOffset(),
										pData->GetMemSize(), pData->GetDPRamDWORDData() );
						SetDPRamDataType( pData->GetDataType(), 0 );
						SetDPRamUploadData( pData );
					}
				}
			}

			// Delete Queue
			m_clsCmdQueue.DeleteQueue();
		}
	}

	return TRUE;
}

void CSysUMAC::SendHandlerMonitor()
{
	char	szBuf[255] = {0, };
	UINT	offset;
	int		nSize = 0;

	switch( m_nMonitorIndex )
	{
	case 0 : // Sensor Monitoring
		{
			DWORD dwMap[9];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("200"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetSensorMonitoring( dwMap );
		}
		break;
	case 1 : // Position Monitoring
		{
			DWORD dwMap[10];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("251"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetMotorPosition( dwMap );
		}
		break;
	case 2 : // Cassette Slot Status
		{
			DWORD dwMap[27];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("261"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetCassetteSlotStatus( dwMap );

			DWORD dwHighMap[25];

			memset( dwHighMap, 0, sizeof(dwHighMap) );
			strcpy_s( szBuf, _T("281") );
			nSize = sizeof( dwHighMap );

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwHighMap);
			gHandlerMonitor.SetCassetteSlotStatus( dwHighMap, FALSE );
		}
		break;
	case 3 : // Handler Motor & Cylinder Error
		{
			DWORD dwMap[17];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("210"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetHandlerError( dwMap );
		}
		break;
	case 4 : // Handler Process & Wafer Error
		{
			DWORD dwMap[2];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("300"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetHandlerError( dwMap, 2 );
		}
	case 5 : // Chuck Interface
		{
			DWORD dwMap[2];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("164"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, &dwMap);
			gHandlerMonitor.SetStageIF( dwMap[0] );
			gHandlerMonitor.SetBarcodeIF( dwMap[1] );
		}
		break;
	case 6 : // Wafer Status
		{
			DWORD dwMap[15];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("241"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerMonitor.SetWaferStatus( dwMap );
		}
	case 7 : // One Shot Vision Interface
		{
			DWORD dwMap = 0;

			strcpy_s(szBuf, _T("168"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, &dwMap);
			gHandlerMonitor.SetOneShotIF( dwMap );
		}
	}

	m_nMonitorIndex++;
	if( m_nMonitorIndex > 7 )
		m_nMonitorIndex = 0;
}

void CSysUMAC::SendHandlerInput()
{
	char	szBuf[255] = {0, };
	UINT	offset;
	int		nSize = 0;

	switch( m_nMonitorIndex )
	{
	case 0 : // System Input
		{
			DWORD dwMap[4];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("550"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetMotorPos( dwMap );
		}
		break;
/*	case 1 : // Sys & Etc.. Err
		{
			DWORD dwMap[2];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("210"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetSysErr( dwMap );

			DWORD dwEtcMap[7];
			
			memset( dwEtcMap, 0, sizeof(dwEtcMap) );
			strcpy_s(szBuf, _T("260"));
			nSize = sizeof(dwEtcMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwEtcMap);
			gHandlerInput.SetEtcErr( dwEtcMap );
		}
		break;
*/	case 1 : // Motor Error & sensor
		{
			DWORD dwMap[15];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("500"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetMotorErr( dwMap );
			gHandlerInput.SetSysInput(dwMap);
		}
		break;
/*	case 3 : // Motor Position
		{
			DWORD dwMap[15];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("240"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;

			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetMotorPos( dwMap );
		}
		break;
	case 4 : // Wafer Status & Cassette Slot Status
		{
			DWORD dwMap[14];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("280"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetWaferStatus( dwMap );

			DWORD dwSlotMap[25];

			memset( dwSlotMap, 0, sizeof(dwSlotMap) );
			strcpy_s(szBuf, _T("2A0"));
			nSize = sizeof(dwSlotMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwSlotMap);
			gHandlerInput.SetCassetteSlotStatus( dwSlotMap );
		}
		break;
	case 5 :
		{
			DWORD dwMap[16];

			memset( dwMap, 0, sizeof(dwMap) );
			strcpy_s(szBuf, _T("100"));
			nSize = sizeof(dwMap);

			offset = (UINT)HextoNum(szBuf)*4;
			DeviceDPRGetMem(m_dwDevice, offset, nSize, dwMap);
			gHandlerInput.SetPCOutputStatus( dwMap );
		}
		break;
*/	}

	m_nMonitorIndex++;
	if( m_nMonitorIndex > 5 )
		m_nMonitorIndex = 0;
}

BOOL CSysUMAC::SetOnlineCmdResponse(char* szCmd, char* szBuf)
{
	int nLen = strlen(szBuf);

	if( nLen == 0 )
	{
		if( strncmp( szCmd, _T("&1B"), 3 ) == 0 )
		{
			if( GetStartMotion() == 1 )
			{	
				SetStartMotion(0);
				m_EvtStartMotion.SetEvent();
			}
			else
				ErrMessage(_T("Invalid Motion Execution Command "), MB_ICONSTOP);
		}
		return FALSE;
	}

	char szErr[5] = {0,};
	char* pDest = NULL;

	
	*(szBuf+nLen-1) = 0;
	nLen = strlen(szBuf);

	sprintf_s(szErr, 5, _T("%cERR"),0x07);

	pDest = strstr(szBuf, szErr);
	if( NULL != pDest )
	{// Is Error
		if( strncmp( szCmd, _T("&1B"), 3 ) == 0 )
		{
			SetStartMotion(2);
			m_EvtStartMotion.SetEvent();
		}

		int nErrorCode = atoi(pDest+4);
		SetUMACErrorMsg(nErrorCode);
		return FALSE;
	}
	else
	{// Is not Error.
		if( strcmp(szCmd, _T("p8000")) == 0 )
		{
			if( GetCheckMotionStatus() == TRUE )
			{
				m_nMotionStatus = szBuf[0] - _T('0');
				if( 0 == m_nMotionStatus )
				{
					SetCheckMotionStatus(FALSE);
					m_EvtMotion.SetEvent();
					m_clsCmdQueue.AddOnlineCmd(_T("p8000=2"));
					m_clsCmdQueue.AddOnlineCmd(_T("p8000"));
				}
			}
		}
		else if( 0 == strcmp( szCmd, _T("m6075") ) )
		{
			CString str(szBuf);
			str.TrimLeft(); str.TrimRight();
			m_nCoatingParamSize = atoi( (LPSTR)(LPCTSTR)str );
		}
		else if( 0 == strcmp( szCmd, _T("m6076") ) )
		{
			CString str(szBuf);
			str.TrimLeft(); str.TrimRight();
			m_nCleaningParamSize = atoi( (LPSTR)(LPCTSTR)str );
		}
		else if( strncmp( szCmd, _T("&1B"), 3 ) == 0 )
		{
			if( GetStartMotion() == 1 )
			{
				SetStartMotion(0);
				m_EvtStartMotion.SetEvent();
			}
			else
				ErrMessage(_T("Invalid Motion Execution Command "), MB_ICONSTOP);
		}

		if( GetCheckMotionStatus() == TRUE )
		{
			CString strMsg;
			if( gHandlerInput.IsStageMotorErr( strMsg ) )
			{
				SetCheckMotionStatus(FALSE);
				m_EvtMotion.SetEvent();
				m_clsCmdQueue.AddOnlineCmd(_T("p8000=2"));
				m_clsCmdQueue.AddOnlineCmd(_T("p8000"));

				SetMotionError(1);

				return TRUE;
			}
		}
	}

	return TRUE;
}

void CSysUMAC::SetUMACErrorMsg(int nErrorCode)
{
	char szError[255] = {0,};

	//if( nErrorCode >= 0 ) nErrorCode = 1;
	sprintf_s(szError, 255, _T("%s"), szUMACError[nErrorCode]);
	m_strUMACErrMsg.Format(_T("%s"), szError);
	//ErrMessage(szError, MB_ICONERROR);

//	CEODicingDlg* pDlg = (CEODicingDlg*)::AfxGetMainWnd();

//	pDlg->SendMessage(WM_ERROR_MSG, 5000 + nErrorCode, FALSE);
}

BOOL CSysUMAC::SetDPRamResponse(int nSize, DWORD dwOffset, DWORD* pMemData)
{
	return TRUE;
}

void CSysUMAC::MoveMotor(int nAxis, double dPos)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	char szCmd[255] = {0,};

	switch( nAxis )
	{
	case 1 : // STAGE X
		sprintf_s(szCmd, 255, _T("#2j=%.4f"), dPos * STAGE_X_FACTOR);
		break;
	case 2 : // STAGE Y
		sprintf_s(szCmd, 255, _T("#1j=%.4f"), dPos * STAGE_Y_FACTOR);
		break;
	case 3 : // STAGE Z
		sprintf_s(szCmd, 255, _T("#13j=%.4f"), dPos * STAGE_Z_FACTOR);
		break;
	case 4 : // STAGE T
		sprintf_s(szCmd, 255, _T("#3j=%.4f"), dPos * STAGE_T_FACTOR);
		break;
	case 5 : // PRE ALIGNER Z(GRIPPER)
		sprintf_s(szCmd, 255, _T("#5j=%.4f"), dPos * PREALIGNER_X_FACTOR);
		break;
	case 6 : // STAGE PICKER X
		sprintf_s(szCmd, 255, _T("#6j=%.4f"), dPos * STAGEPICKER_X_FACTOR);
		break;
	case 7 : // PRE ALIGNER X(ELEVATOR)
		sprintf_s(szCmd, 255, _T("#7j=%.4f"), dPos * PREALIGNER_Z_FACTOR);
		break;
	case 8 : // COATER PICKER Y
		sprintf_s(szCmd, 255, _T("#8j=%.4f"), dPos * COATERPICKER_Y_FACTOR);
		break;
	case 9 : // COATER PICKER Z
		sprintf_s(szCmd, 255, _T("#9j=%.4f"), dPos * COATERPICKER_Z_FACTOR);
		break;
	case 10 : // POLYGON IS EMPTY
		break;
	case 11 : // Relative Stage X
		sprintf_s( szCmd, 255, _T("#2j:%.4f"), dPos * STAGE_X_FACTOR);
		break;
	case 12 :// Relative Stage Y
		sprintf_s( szCmd, 255, _T("#1j:%.4f"), dPos * STAGE_Y_FACTOR);
		break;
	case 13 :// Relative Stage Z
		break;
	case 14 :// Relative Stage T
		sprintf_s( szCmd, 255, _T("#3j:%.4f"), dPos * STAGE_T_FACTOR);
		break;
	}

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(szCmd);
}

void CSysUMAC::MoveXYTable(double dXPos, double dYPos)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	char szCmd[255] = {0,};

	sprintf_s(szCmd, 255, _T("#1j=.4f/#2j=.4f"), dXPos, dYPos);

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(szCmd);
}

void CSysUMAC::InitializeMotor(int nAxis)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	if(!gHandlerInput.m_clsPCOutput.m_sStageIF.bMachineReady)
	{
		ErrMessage(_T("Stage is not ready. Check the hardware."));
		return;
	}
	char szCmd[255] = {0,};

	switch( nAxis )
	{
	case 0 : // STAGE X
		sprintf_s(szCmd, 255, _T("m4006=1"));
		m_clsCmdQueue.AddOnlineCmd(szCmd);
		break;
	case 1 : // STAGE Y
		sprintf_s(szCmd, 255, _T("m4007=1"));
		m_clsCmdQueue.AddOnlineCmd(szCmd);
		break;
	case 2 : // STAGE Z
		sprintf_s(szCmd, 255, _T("m4009=1"));
		m_clsCmdQueue.AddOnlineCmd(szCmd);
		break;
	case 4 : // STAGE T
		sprintf_s(szCmd, 255, _T("m4008=1"));
		m_clsCmdQueue.AddOnlineCmd(szCmd);
		break;
	case -1 : // Stage All
		sprintf_s(szCmd, 255, _T("m4005=1"));
		m_clsCmdQueue.AddOnlineCmd(szCmd);
		break;
	}

	// Insert Queue

//	sprintf_s(szCmd, 255, _T("m6012=1"));
//	m_clsCmdQueue.AddOnlineCmd(szCmd);
}

void CSysUMAC::SetMotorSpeed(int nAxis, int nSpeed)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	char szCmd[255] = {0,};
	char szAccel[255] = {0,};
	double dTmp = 0., dTA = 0., dTS = 0;

	switch( nAxis )
	{
	case 1 : // STAGE X
		dTmp	= double(nSpeed) *	 6.4;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I222=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I220=%.4f &1I221=%.4f"), dTA, dTS);
		break;
	case 2 : // STAGE Y
		dTmp	= double(nSpeed) * 6.4;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I122=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I120=%.4f &1I121=%.4f"), dTA, dTS);
		break;
	case 13 : // STAGE Z
		dTmp	= double(nSpeed) * 10.;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I1322=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I1320=%.4f &1I1321=%.4f"), dTA, dTS);
		break;
	case 3 : // STAGE T
		dTmp	= double(nSpeed) * 11.3777;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I322=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I320=%.4f &1I321=%.4f"), dTA, dTS);
		break;
	case 4 : // Elevator
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I422=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I420=%.4f &1I421=%.4f"), dTA, dTS);
		break;
	case 5 : // Align Rail
		dTmp	= double(nSpeed) * 0.8192 * 2.0;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I522=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I520=%.4f &1I521=%.4f"), dTA, dTS);
		break;
	case 6 : // Gripper
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I622=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I620=%.4f &1I621=%.4f"), dTA, dTS);
		break;
	case 7 : // Loader Y
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I722=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I720=%.4f &1I721=%.4f"), dTA, dTS);
		break;
	case 8 : // Loader Z
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I822=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I820=%.4f &1I821=%.4f"), dTA, dTS);
		break;
	case 9 : // Buffer Y
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I922=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I920=%.4f &1I921=%.4f"), dTA, dTS);
		break;
	case 10 : // Buffer Z
		dTmp	= double(nSpeed) * 0.8192;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I1022=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I1020=%.4f &1I1021=%.4f"), dTA, dTS);
		break;
	case 11 : // Coater T
		sprintf_s(szCmd, _T("&1I1122=%d"),nSpeed);
		break;
	case 12 : // Coater Z
		dTmp	= double(nSpeed) * 1.6384;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I1222=%d"),nSpeed);
		sprintf_s(szAccel, 255, _T("&1I1220=%.4f &1I1221=%.4f"), dTA, dTS);
		break;
	case 17 : // Coater Arm
		dTmp	= double(nSpeed) * 0.2;
		dTA		= double(nSpeed) * 0.98 * 2.0;
		dTS		= dTA / 3.0;
		sprintf_s(szCmd, 255, _T("&1I1722=%d"),int(dTmp+0.5));
		sprintf_s(szAccel, 255, _T("&1I1720=%.4f &1I1721=%.4f"), dTA, dTS);
		break;
	}

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(szCmd);
	m_clsCmdQueue.AddOnlineCmd(szAccel);
}

void CSysUMAC::StartPolygon(int nSpeed)
{
	/*
#ifndef USE_NO_PG
	gDaq.StartPolygon(nSpeed);

	return;
#endif

#ifdef USE_NO_MOTOR
	return;
#endif

	// Polygon(90��) Start Sequence ///////////////
	// 1. I1300=1
	// 2. P8190 -> User Input RPM -> 7���� 
	// 3. _T("#15j+")
	/////////////////////////////////////////
	// 1. I1300=1
	m_clsCmdQueue.AddOnlineCmd(_T("i1500=1"));

	// 2. P8190 -> User Input RPM
	char szCmd[20] = {0,};
	sprintf_s(szCmd, 20, _T("p8190=%d"), nSpeed);
	m_clsCmdQueue.AddOnlineCmd(szCmd);
	// 3. _T("#13j+")
	m_clsCmdQueue.AddOnlineCmd(_T("#15j+"));*/
}

void CSysUMAC::StopPolygon()
{
	/*
#ifndef USE_NO_MOTOR
	gDaq.StopPolygon();
	return;
#endif

	// Polygon(90��) Stop Sequence ///////////////
	// 1. _T("#7j/")
	/////////////////////////////////////////

	// 1. _T("#15j/")
	m_clsCmdQueue.AddOnlineCmd(_T("#15j/"));
	*/
}

void CSysUMAC::UVLaserOnOffControl(BOOL bOnOff)
{
#ifdef USE_NO_MOTOR
	return;
#endif
	// COMMENT PLC 0
	// LASER ON/OFF�� UMAC CONTROLER���� D/I�� Control �Ѵ�.
	// ���� ������ ��ġ�� ������ Laser On/Off �����ϱ� ������
	// Manual�� Laser On�� PLC 0���� Disable �����ְ�
	// Laser Off�� PLC 0���� Enable �����ش�.
	// PLC 0������ M16 ������ ����ϹǷ� �׷��� �ؾ� �ȴٰ� �Ѵ�... �Ѥ�

	// LASER OFF
	if( FALSE == bOnOff )
	{
		m_clsCmdQueue.AddOnlineCmd(_T("m16=1"));		// LASER OFF
		m_clsCmdQueue.AddOnlineCmd(_T("enaplc 0"));		// Enaplc 0
	}
	// LASER ON
	else
	{
		m_clsCmdQueue.AddOnlineCmd(_T("displc 0"));		// Disable PLC 0
		m_clsCmdQueue.AddOnlineCmd(_T("m16=0"));		// LASER ON
	}
}

void CSysUMAC::CO2LaserOnOffControl(BOOL bOnOff)
{

}

void CSysUMAC::StopMotion(int nCoordinate)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	char szCmd[255] = {0,};

	sprintf_s(szCmd, 255, _T("&%dQ"), nCoordinate);

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(szCmd);

	// Set Motion Finish Status
	memset( szCmd, 0, 255 );
	sprintf_s(szCmd, 255, _T("p8000=0"));
	
	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(szCmd);
}

void CSysUMAC::StartMotion(int nCoordinate, int nMotionNo)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	char szCmd[255] = {0,};

	sprintf_s(szCmd, 255, _T("&%dB%dR"), nCoordinate, nMotionNo);

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd( szCmd );
}

void CSysUMAC::IsExecutionMotion()
{
	if( TRUE == GetCheckMotionStatus() )
	{
		if( m_clsTimer.Finish() > 0.2 )
		{
			if( m_clsCmdQueue.IsEmptyQueue() )
				m_clsCmdQueue.AddOnlineCmd(_T("p8000"));
			m_clsTimer.Start();
		}
	}
}

void CSysUMAC::ChangeCassetteSlot(int nCurSlot, int nSlotStatus)
{
	
}

void CSysUMAC::OnDownloadWaferInfo(int* pWaferStatus, int* pWaferSlot)
{
#ifdef USE_NO_MOTOR
	return;
#endif

	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6112->DP:$60170
	// M6112->DP:$60171
	// M6112->DP:$60172
	// M6112->DP:$60173
	// M6112->DP:$60174
	// M6112->DP:$60175
	// M6112->DP:$60176
	// M6112->DP:$60177
	// M6112->DP:$60178
	// M6112->DP:$60179
	// M6112->DP:$6017A
	// M6112->DP:$6017B
	// M6112->DP:$6017C
	// M6112->DP:$6017D

	DWORD	dwMap[14];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);


	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);
	strcpy_s(szBuf, _T("170"));
	offset = (UINT)HextoNum(szBuf)*4;

	for( int i = 0 ; i < 6 ; i++ )
		dwMap[i] = *(pWaferStatus+i);

	int j = 0;
	for(int i = 8 ; i < 14 ; i++ )
	{
		dwMap[i] = *(pWaferSlot+j);
		j++;
	}

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap );

	// Handler Position Download Flag
	m_clsCmdQueue.AddOnlineCmd(_T("m4014=1"));
}


void CSysUMAC::OnDownloadSysParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6016->DP:$60110
	// M6017->DP:$60111
	// M6018->DP:$60112
	// M6019->DP:$60113
	// M6020->DP:$60114
	// M6021->DP:$60115
	// M6022->DP:$60116
	// M6023->DP:$60117
	// M6024->DP:$60118
	// M6025->DP:$60119
	// M6026->DP:$6011A
	// M6027->DP:$6011B
	// M6028->DP:$6011C
	// M6029->DP:$6011D
	// M6030->DP:$6011E
	// M6031->DP:$6011F
	// M6032->DP:$60120
	// M6033->DP:$60121
	// M6034->DP:$60122
	// M6035->DP:$60123
	// M6036->DP:$60124
	// M6037->DP:$60125
	// M6038->DP:$60126
	// M6039->DP:$60127
	// M6040->DP:$60128
	// M6061->DP:$60129

	DWORD	dwMap[26];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("110"));
	offset = (UINT)HextoNum(szBuf)*4;

	// Positon Flag
	dwMap[0] = 1;

	// Stage Loading Position
	dwMap[1] = (DWORD)( gRecipeData.m_dWaferLoadingPos.x * STAGE_X_FACTOR );
	dwMap[2] = (DWORD)( gRecipeData.m_dWaferLoadingPos.y * STAGE_Y_FACTOR );

	// Pre Align's Rail Loading Position
	dwMap[3] = (DWORD)( gRecipeData.m_sElevator.dLoadPrealignerPos * PREALIGNER_Z_FACTOR );

	// Pre Align's Buffer Loading Position
	dwMap[4] = (DWORD)( gRecipeData.m_sElevator.dLoadBufferPos * PREALIGNER_Z_FACTOR );

	// Pre Align's Cupboard Loading Position
	dwMap[5] = (DWORD)( gRecipeData.m_sElevator.dLoadCupboardPos * PREALIGNER_Z_FACTOR );

	// Low Cassette Fist Slot Position
	dwMap[6] = (DWORD)( gRecipeData.m_sElevator.dCassetteFirstSlotPos * PREALIGNER_Z_FACTOR );

	// High Cassette First Slot Position
	dwMap[7] = (DWORD)( gRecipeData.m_sElevator.dCassetteFirstSlotHighPos * PREALIGNER_Z_FACTOR );

	// Total Slot Of Cassette
	dwMap[8] = (DWORD)( gRecipeData.m_sElevator.nTotalSlotOfCassette );

	// Cassette Slot Pitch
	dwMap[9] = (DWORD)( gRecipeData.m_sElevator.dCassettePitch * PREALIGNER_Z_FACTOR );

	// Pre Aligner Z Axis Speed
	dwMap[10] = (DWORD)( gRecipeData.m_sElevator.nElevatorSpeed );

	// Gripper Grip Position
	dwMap[11] = (DWORD)( gRecipeData.m_sGripper.dGripPos * PREALIGNER_X_FACTOR );

	//Gripper Release Position
	dwMap[12] = (DWORD)( gRecipeData.m_sGripper.dReleasePos * PREALIGNER_X_FACTOR );

	// Gripper Speed
	dwMap[13] = (DWORD)( gRecipeData.m_sGripper.nGripperSpeed );

	// Stage Picker X-Axis Stage Loading Position
	dwMap[14] = (DWORD)( gRecipeData.m_sPicker.dStageLoadingPos * STAGEPICKER_X_FACTOR );

	// Stage Picker X-Axis Prealigner Loading Position
	dwMap[15] = (DWORD)( gRecipeData.m_sPicker.dPreAlignerLoadingPos * STAGEPICKER_X_FACTOR );
	
	// Stage Picker Speed
	dwMap[16] = (DWORD)( gRecipeData.m_sPicker.nPickerSpeed );

	// Coater Picker Y-Axis Coater Loading Position
	dwMap[17] = (DWORD)( gRecipeData.m_sCoaterPicker.dCoaterLoadingPosY * COATERPICKER_Y_FACTOR );

	// Coater Picker Y-Axis Prealigner Loading Position
	dwMap[18] = (DWORD)( gRecipeData.m_sCoaterPicker.dPreAlignerLoadingPosY * COATERPICKER_Y_FACTOR );

	// Coater Picker Y-Axis Speed
	dwMap[19] = (DWORD)( gRecipeData.m_sCoaterPicker.nYSpeed );

	// Coater Picker Z-Axis Coater Position
	dwMap[20] = (DWORD)( gRecipeData.m_sCoaterPicker.dCoaterLoadingPosZ * COATERPICKER_Z_FACTOR );

	// Coater Picker Z-Axis Prealinger Loading Position
	dwMap[21] = (DWORD)( gRecipeData.m_sCoaterPicker.dPreAlignerLoadingPosZ * COATERPICKER_Z_FACTOR );

	// Coater Picker Z-Axis Speed
	dwMap[22] = (DWORD)( gRecipeData.m_sCoaterPicker.nZSpeed );

	// Mask Picker Loading Position X
	dwMap[23] = (DWORD)( gRecipeData.m_dMaskPickerLoadingPosition.x * STAGE_X_FACTOR );

	// Mask Picker Loading Position Y
	dwMap[24] = (DWORD)( gRecipeData.m_dMaskPickerLoadingPosition.y * STAGE_Y_FACTOR );

	// OneShot Vision Trigger Position
	dwMap[25] = (DWORD)( gRecipeData.m_sPicker.dVisionLoadingPos * STAGEPICKER_X_FACTOR );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap );
	*/
}

void CSysUMAC::OnDownloadSysHandlerParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6016->DP:$60110
	// M6017->DP:$60111
	// M6018->DP:$60112
	// M6019->DP:$60113
	// M6020->DP:$60114
	// M6021->DP:$60115
	// M6022->DP:$60116
	// M6023->DP:$60117
	// M6024->DP:$60118
	// M6025->DP:$60119
	// M6026->DP:$6011A
	// M6027->DP:$6011B
	// M6028->DP:$6011C
	// M6029->DP:$6011D
	// M6030->DP:$6011E
	// M6031->DP:$6011F
	// M6032->DP:$60120
	// M6033->DP:$60121
	// M6034->DP:$60122
	// M6035->DP:$60123
	// M6036->DP:$60124
	// M6037->DP:$60125
	// M6038->DP:$60126
	// M6039->DP:$60127
	// M6040->DP:$60128
	// M6041->DP:$60129
	// M6042->DP:$6012A
	// M6043->DP:$6012B
	// M6044->DP:$6012C
	// M6045->DP:$6012D
	// M6046->DP:$6012E
	// M6047->DP:$6012F
	// M6048->DP:$60130
	// M6049->DP:$60131
	// M6050->DP:$60132
	// M6051->DP:$60133
	// M6052->DP:$60134
	// M6053->DP:$60135
	// M6054->DP:$60136
	// M6055->DP:$60137
	// M6056->DP:$60138
	// M6057->DP:$60139
	// M6058->DP:$6013A
	// M6059->DP:$6013B
	// M6060->DP:$6013C
	// M6061->DP:$6013D
	// M6062->DP:$6013E
	// M6063->DP:$6013F

	DWORD	dwMap[48];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("110"));
	offset = (UINT)HextoNum(szBuf)*4;

	// X, Y Loading Position
	dwMap[0] = (DWORD)(gRecipeData.m_dWaferLoadingPos.x * STAGE_X_FACTOR);
	dwMap[1] = (DWORD)(gRecipeData.m_dWaferLoadingPos.y * STAGE_Y_FACTOR);

	// First Slot Wafer Catch Position in Cassette (8")
	dwMap[2] = (DWORD)(gRecipeData.m_sMagazine.d8InchPos * MAGAZINE_ELEVATOR_FACTOR);

	// First Slot Wafer Catch Position in Cassette (12")
	dwMap[3] = (DWORD)(gRecipeData.m_sMagazine.d12InchPos * MAGAZINE_ELEVATOR_FACTOR);

	// Wafer Slot Count (8")
	dwMap[4] = (DWORD)(gRecipeData.m_sMagazine.n8InchSlotNo);

	// Wafer Slot Count (12")
	dwMap[5] = (DWORD)(gRecipeData.m_sMagazine.n12InchSlotNo);

	// Elevator Speed
	dwMap[7] = (DWORD)(gRecipeData.m_sMagazine.nMagazineSpeed);

	// Wafer Grip / Release Position On Rail (8");
	dwMap[8] = (DWORD)(gRecipeData.m_sAlignRail.dReleaseGripper8Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Rail (12");
	dwMap[9] = (DWORD)(gRecipeData.m_sAlignRail.dReleaseGripper12Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Cassette (8");
	dwMap[10] = (DWORD)(gRecipeData.m_sAlignRail.dGripGripper8Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Cassette (12");
	dwMap[11] = (DWORD)(gRecipeData.m_sAlignRail.dGripGripper12Inch * PREALIGN_GRIPPER_FACTOR);

	// Gripper Speed
	dwMap[12] = (DWORD)gRecipeData.m_sAlignRail.nGripperSpeed;

	// Wafer Unloading X Position
	dwMap[13] = (DWORD)(gRecipeData.m_dUnloadingXPos * STAGE_X_FACTOR);

	// 8 Inch Wafer Slot Pitch
	dwMap[14] = (DWORD)(gRecipeData.m_sMagazine.d8InchPitch * MAGAZINE_ELEVATOR_FACTOR);

	// 12 Inch Wafer Slot Pitch
	dwMap[15] = (DWORD)(gRecipeData.m_sMagazine.d12InchPitch * MAGAZINE_ELEVATOR_FACTOR);

	// Align Rail Moving Position (8")
	dwMap[16] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailMovePos8Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Moveing Position (12")
	dwMap[17] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailMovePos12Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Align Position (8")
	dwMap[18] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailAlignPos8Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Align Position (12")
	dwMap[19] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailAlignPos12Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Speed
	dwMap[20] = (DWORD)gRecipeData.m_sAlignRail.nRailSpeed;

	// Loader Picker Y Align Rail Pos
	dwMap[21] = (DWORD)(gRecipeData.m_sLoadPicker.dAlignRailLoadingPosY * LPICKER_Y_FACTOR);

	// Loader Picker Y Coater Pos
	dwMap[22] = (DWORD)(gRecipeData.m_sLoadPicker.dSpinnerLoadingPosY * LPICKER_Y_FACTOR);

	// Loader Picker Y Buffer Pos
	dwMap[23] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosX * LPICKER_Y_FACTOR);

	// Loader Picker Y Stage Pos
	dwMap[24] = (DWORD)(gRecipeData.m_sLoadPicker.dStageLoadingPosX * LPICKER_Y_FACTOR);

	// Loader Picker Y Speed
	dwMap[25] = (DWORD)gRecipeData.m_sLoadPicker.nLoadPickerSpeedX;

	// Loader Picker Z Align Rail Pos
	dwMap[26] = (DWORD)(gRecipeData.m_sLoadPicker.dAlignRailLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Coater Pos
	dwMap[27] = (DWORD)(gRecipeData.m_sLoadPicker.dSpinnerLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Buffer Pos (8")
	dwMap[28] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Buffer Pos (12")
	dwMap[29] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosZ12Inch * LPICKER_Y_FACTOR);

	// Loader Picker Z Stage Pos
	dwMap[30] = (DWORD)(gRecipeData.m_sLoadPicker.dStageLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Speed
	dwMap[31] = (DWORD)gRecipeData.m_sLoadPicker.nLoadPickerSpeedZ;

	// Buffer Picker Y Buffer Pos
	dwMap[32] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosX * BPICKER_Y_FACTOR);

	// Buffer Picker Y Stage Pos
	dwMap[33] = (DWORD)(gRecipeData.m_sBufferPicker.dStageLoadingPosX * BPICKER_Y_FACTOR);

	// Buffer Picker Y Speed
	dwMap[34] = (DWORD)gRecipeData.m_sBufferPicker.nBufferPickerSpeedX;

	// Buffer Picker Z Buffer Pos (8")
	dwMap[35] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosZ * BPICKER_Y_FACTOR);

	// Buffer Picker Z Buffer Pos (12")
	dwMap[36] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosZ12Inch * BPICKER_Y_FACTOR);

	// Buffer Picker Z Stage Pos
	dwMap[37] = (DWORD)(gRecipeData.m_sBufferPicker.dStageLoadingPosZ * BPICKER_Y_FACTOR);

	// Buffer Picker Z Speed
	dwMap[38] = (DWORD)gRecipeData.m_sBufferPicker.nBufferPickerSpeedZ;

	// Scan Start Pos 8 Inch
	dwMap[44] = (DWORD)(gRecipeData.m_sMagazine.dScanStartPos8Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan End Pos 8 Inch
	dwMap[45] = (DWORD)(gRecipeData.m_sMagazine.dScanEndPos8Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan Start Pos 12 Inch
	dwMap[46] = (DWORD)(gRecipeData.m_sMagazine.dScanStartPos12Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan End Pos 12 Inch
	dwMap[47] = (DWORD)(gRecipeData.m_sMagazine.dScanEndPos12Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Set DPRAM Data Type
	SetDPRamDataType( 1, 1 );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, FALSE, 1 );

	// Handler Position Download Flag
	m_clsCmdQueue.AddOnlineCmd(_T("m4008=1"));
	*/
}

void CSysUMAC::OnDownloadSysCoaterParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6064->DP:$60140
	// M6065->DP:$60141
	// M6066->DP:$60142
	// M6067->DP:$60143
	// M6068->DP:$60144
	// M6069->DP:$60145
	// M6070->DP:$60146
	// M6071->DP:$60147
	// M6072->DP:$60148
	// M6073->DP:$60149
	// M6074->DP:$6014A
	// M6075->DP:$6014B
	// M6076->DP:$6014C

	DWORD	dwMap[11];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);


	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);
	strcpy_s(szBuf, _T("140"));
	offset = (UINT)HextoNum(szBuf)*4;

	// Coater Spin Theta Loading Pos 8 Inch
	dwMap[0] = (DWORD)(gRecipeData.m_sSpinCoater.dLoadingPos * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Theta Home Offset
	dwMap[1] = (DWORD)(gRecipeData.m_sSpinCoater.dHomePos * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Theta Speed
	dwMap[2] = (DWORD)gRecipeData.m_sSpinCoater.nRotatingSpeed;

	// Coater Spin Theta Loading Pos 12 Inch
	dwMap[3] = (DWORD)(gRecipeData.m_sSpinCoater.dLoadingPos12Inch * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Z Loading(Up) Position
	//dwMap[3] = (DWORD)(gRecipeData.m_sSpinCoater.dSpinZLoadingPos * SPINCOATER_Z_FACTOR);
	// Coater Spin Z Working(Down) Position
	//dwMap[4] = (DWORD)(gRecipeData.m_sSpinCoater.dSpinZWorkingPos * SPINCOATER_Z_FACTOR);
	// Coater Spin Z Speed
	//dwMap[5] = (DWORD)gRecipeData.m_sSpinCoater.nSpinZSpeed;

	// Coater Arm Nz1 Position
	dwMap[6] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle1Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz2 Position
	dwMap[7] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle2Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz3 Position
	dwMap[8] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle3Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz4 Position
	dwMap[9] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle4Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Speed
	dwMap[10] = (DWORD)gRecipeData.m_sSpinCoater.nArmSwingSpeed;

	// Set DPRAM Data Type
	SetDPRamDataType( 2, 1 );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, FALSE, 2 );

	// Handler Position Download Flag
	m_clsCmdQueue.AddOnlineCmd(_T("m4009=1"));
	*/
}

void CSysUMAC::OnDownloadCoatingParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;
	BOOL	bCheck = FALSE;

	// Start : $60500 ~ $6054F

	DWORD	dwMap[80];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);
	int		nCoatingSize = gMultiParam.GetCoatingParamSize();

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("500"));
	offset = (UINT)HextoNum(szBuf)*4;

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = gMultiParam.GetCoatingParam(i);

		if( NULL == pCoaterParam )
		{
			ErrMessage(_T(_T("Invalid Coating Parameter ")), MB_ICONERROR);
			return;
		}

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSpinSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 1 : // Spin Chuck Slope Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSlopeTime );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				else if( dwMap[nIndex] < 2000 ) bCheck = TRUE;
				break;
			case 2 : // Arm Swing Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSwingSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 3 : // Arm Left Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dLeftPos * SPINCOATER_ARM_FACTOR );
				break;
			case 4 : // Arm Right Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dRightPos * SPINCOATER_ARM_FACTOR );
				break;
			case 5 : // Using Nozzle No
				dwMap[nIndex] = (DWORD)( pCoaterParam->nNozzleNo );
				break;
			case 6 : // Process Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nProcessTime );
				break;
			case 7 : // Using Cover
				dwMap[nIndex] = (DWORD)( pCoaterParam->bCover );
				break;
			}
		}
	}



	// Set DPRAM Data Type
	SetDPRamDataType( 5, 1 );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, FALSE, 5 );

	CString strCmd;
	
	// Coating Step Number
	strCmd.Format(_T("m6075=%d"), nCoatingSize);
	m_clsCmdQueue.AddOnlineCmd((LPSTR)(LPCTSTR)strCmd);

	// Coating Recipe Parameter Download Flag
	m_clsCmdQueue.AddOnlineCmd(_T("m4006=1"));
*/
}

void CSysUMAC::OnDownloadCleaningParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;
	BOOL bCheck = FALSE;

	// Start : $60600 ~ $6064F

	DWORD	dwMap[80];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);
	int		nCoatingSize = gMultiParam.GetCleaningParamSize();

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("600"));
	offset = (UINT)HextoNum(szBuf)*4;

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = gMultiParam.GetCleaningParam(i);

		if( NULL == pCoaterParam )
		{
			ErrMessage(_T("Invalid Cleaning Parameter "), MB_ICONERROR);
			return;
		}

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSpinSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 1 : // Spin Chuck Slope Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSlopeTime );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				else if( dwMap[nIndex] < 2000 ) bCheck = TRUE;
				break;
			case 2 : // Arm Swing Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSwingSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 3 : // Arm Left Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dLeftPos * SPINCOATER_ARM_FACTOR );
				break;
			case 4 : // Arm Right Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dRightPos * SPINCOATER_ARM_FACTOR );
				break;
			case 5 : // Using Nozzle No
				dwMap[nIndex] = (DWORD)( pCoaterParam->nNozzleNo );
				break;
			case 6 : // Process Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nProcessTime );
				break;
			case 7 : // Using Cover
				dwMap[nIndex] = (DWORD)( pCoaterParam->bCover );
				break;
			}
		}
	}



	// Set DPRAM Data Type
	SetDPRamDataType( 6, 1 );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, FALSE, 6 );

	CString strCmd;
	
	// Cleaning Step Number
	strCmd.Format(_T("m6076=%d"), nCoatingSize);
	m_clsCmdQueue.AddOnlineCmd((LPSTR)(LPCTSTR)strCmd);

	// Cleaning Recipe Parameter Download Flag
	m_clsCmdQueue.AddOnlineCmd(_T("m4007=1"));
*/
}

void CSysUMAC::SetDPRamDataType(int nType, BOOL bVal)
{
	switch( nType )
	{
	case 1 :
		m_bHandlerSysDownload = bVal;
		break;
	case 2 :
		m_bSpinnerSysDownload = bVal;
		break;
	case 3 :
		m_bHandlerSysUpload = bVal;
		break;
	case 4 :
		m_bSpinnerSysUpload = bVal;
		break;
	case 5 :
		m_bCoatingParamDownload = bVal;
		break;
	case 6 :
		m_bCleaningParamDownload = bVal;
		break;
	case 7 :
		m_bCoatingParamUpload = bVal;
		break;
	case 8 :
		m_bCleaningParamUpload = bVal;
		break;
	}
}

int CSysUMAC::GetDPRamDataType(int nType)
{
	BOOL bRet = 0;

	switch( nType )
	{
	case 1 :
		bRet = m_bHandlerSysDownload;
		break;
	case 2 :
		bRet = m_bSpinnerSysDownload;
		break;
	case 3 :
		bRet = m_bHandlerSysUpload;
		break;
	case 4 :
		bRet = m_bSpinnerSysUpload;
		break;
	case 5 :
		bRet = m_bCoatingParamDownload;
		break;
	case 6 :
		bRet = m_bCleaningParamDownload;
		break;
	case 7 :
		bRet = m_bCoatingParamDownload;
		break;
	case 8 :
		bRet = m_bCleaningParamDownload;
		break;
	}

	return bRet;
}

void CSysUMAC::OnUploadSysHandlerParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6016->DP:$60110
	// M6017->DP:$60111
	// M6018->DP:$60112
	// M6019->DP:$60113
	// M6020->DP:$60114
	// M6021->DP:$60115
	// M6022->DP:$60116
	// M6023->DP:$60117
	// M6024->DP:$60118
	// M6025->DP:$60119
	// M6026->DP:$6011A
	// M6027->DP:$6011B
	// M6028->DP:$6011C
	// M6029->DP:$6011D
	// M6030->DP:$6011E
	// M6031->DP:$6011F
	// M6032->DP:$60120
	// M6033->DP:$60121
	// M6034->DP:$60122
	// M6035->DP:$60123
	// M6036->DP:$60124
	// M6037->DP:$60125
	// M6038->DP:$60126
	// M6039->DP:$60127
	// M6040->DP:$60128
	// M6041->DP:$60129
	// M6042->DP:$6012A
	// M6043->DP:$6012B
	// M6044->DP:$6012C
	// M6045->DP:$6012D
	// M6046->DP:$6012E
	// M6047->DP:$6012F
	// M6048->DP:$60130
	// M6049->DP:$60131
	// M6050->DP:$60132
	// M6051->DP:$60133
	// M6052->DP:$60134
	// M6053->DP:$60135
	// M6054->DP:$60136
	// M6055->DP:$60137
	// M6056->DP:$60138
	// M6057->DP:$60139
	// M6058->DP:$6013A
	// M6059->DP:$6013B
	// M6060->DP:$6013C
	// M6061->DP:$6013D
	// M6062->DP:$6013E
	// M6063->DP:$6013F

	DWORD	dwMap[48];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("110"));
	offset = (UINT)HextoNum(szBuf)*4;

	// X, Y Loading Position
	dwMap[0] = (DWORD)(gRecipeData.m_dWaferLoadingPos.x * STAGE_X_FACTOR);
	dwMap[1] = (DWORD)(gRecipeData.m_dWaferLoadingPos.y * STAGE_Y_FACTOR);

	// First Slot Wafer Catch Position in Cassette (8")
	dwMap[2] = (DWORD)(gRecipeData.m_sMagazine.d8InchPos * MAGAZINE_ELEVATOR_FACTOR);

	// First Slot Wafer Catch Position in Cassette (12")
	dwMap[3] = (DWORD)(gRecipeData.m_sMagazine.d12InchPos * MAGAZINE_ELEVATOR_FACTOR);

	// Wafer Slot Count (8")
	dwMap[4] = (DWORD)(gRecipeData.m_sMagazine.n8InchSlotNo);

	// Wafer Slot Count (12")
	dwMap[5] = (DWORD)(gRecipeData.m_sMagazine.n12InchSlotNo);

	// Elevator Speed
	dwMap[7] = (DWORD)(gRecipeData.m_sMagazine.nMagazineSpeed);

	// Wafer Grip / Release Position On Rail (8");
	dwMap[8] = (DWORD)(gRecipeData.m_sAlignRail.dReleaseGripper8Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Rail (12");
	dwMap[9] = (DWORD)(gRecipeData.m_sAlignRail.dReleaseGripper12Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Cassette (8");
	dwMap[10] = (DWORD)(gRecipeData.m_sAlignRail.dGripGripper8Inch * PREALIGN_GRIPPER_FACTOR);

	// Wafer Grip / Release Position On Cassette (12");
	dwMap[11] = (DWORD)(gRecipeData.m_sAlignRail.dGripGripper12Inch * PREALIGN_GRIPPER_FACTOR);

	// Gripper Speed
	dwMap[12] = (DWORD)gRecipeData.m_sAlignRail.nGripperSpeed;

	// Wafer Unloading X Position
	dwMap[13] = (DWORD)(gRecipeData.m_dUnloadingXPos * STAGE_X_FACTOR);

	// 8 Inch Wafer Slot Pitch
	dwMap[14] = (DWORD)(gRecipeData.m_sMagazine.d8InchPitch * MAGAZINE_ELEVATOR_FACTOR);

	// 12 Inch Wafer Slot Pitch
	dwMap[15] = (DWORD)(gRecipeData.m_sMagazine.d12InchPitch * MAGAZINE_ELEVATOR_FACTOR);

	// Align Rail Moving Position (8")
	dwMap[16] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailMovePos8Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Moveing Position (12")
	dwMap[17] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailMovePos12Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Align Position (8")
	dwMap[18] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailAlignPos8Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Align Position (12")
	dwMap[19] = (DWORD)(gRecipeData.m_sAlignRail.dAlignRailAlignPos12Inch * PREALIGN_RAIL_FACTOR);

	// Align Rail Speed
	dwMap[20] = (DWORD)gRecipeData.m_sAlignRail.nRailSpeed;

	// Loader Picker Y Align Rail Pos
	dwMap[21] = (DWORD)(gRecipeData.m_sLoadPicker.dAlignRailLoadingPosY * LPICKER_Y_FACTOR);

	// Loader Picker Y Coater Pos
	dwMap[22] = (DWORD)(gRecipeData.m_sLoadPicker.dSpinnerLoadingPosY * LPICKER_Y_FACTOR);

	// Loader Picker Y Buffer Pos
	dwMap[23] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosX * LPICKER_Y_FACTOR);

	// Loader Picker Y Stage Pos
	dwMap[24] = (DWORD)(gRecipeData.m_sLoadPicker.dStageLoadingPosX * LPICKER_Y_FACTOR);

	// Loader Picker Y Speed
	dwMap[25] = (DWORD)gRecipeData.m_sLoadPicker.nLoadPickerSpeedX;

	// Loader Picker Z Align Rail Pos
	dwMap[26] = (DWORD)(gRecipeData.m_sLoadPicker.dAlignRailLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Coater Pos
	dwMap[27] = (DWORD)(gRecipeData.m_sLoadPicker.dSpinnerLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Buffer Pos (8")
	dwMap[28] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Buffer Pos (12")
	dwMap[29] = (DWORD)(gRecipeData.m_sLoadPicker.dBufferLoadingPosZ12Inch * LPICKER_Y_FACTOR);

	// Loader Picker Z Stage Pos
	dwMap[30] = (DWORD)(gRecipeData.m_sLoadPicker.dStageLoadingPosZ * LPICKER_Y_FACTOR);

	// Loader Picker Z Speed
	dwMap[31] = (DWORD)gRecipeData.m_sLoadPicker.nLoadPickerSpeedZ;

	// Buffer Picker Y Buffer Pos
	dwMap[32] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosX * BPICKER_Y_FACTOR);

	// Buffer Picker Y Stage Pos
	dwMap[33] = (DWORD)(gRecipeData.m_sBufferPicker.dStageLoadingPosX * BPICKER_Y_FACTOR);

	// Buffer Picker Y Speed
	dwMap[34] = (DWORD)gRecipeData.m_sBufferPicker.nBufferPickerSpeedX;

	// Buffer Picker Z Buffer Pos (8")
	dwMap[35] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosZ * BPICKER_Y_FACTOR);

	// Buffer Picker Z Buffer Pos (12")
	dwMap[36] = (DWORD)(gRecipeData.m_sBufferPicker.dBufferLoadingPosZ12Inch * BPICKER_Y_FACTOR);

	// Buffer Picker Z Stage Pos
	dwMap[37] = (DWORD)(gRecipeData.m_sBufferPicker.dStageLoadingPosZ * BPICKER_Y_FACTOR);

	// Buffer Picker Z Speed
	dwMap[38] = (DWORD)gRecipeData.m_sBufferPicker.nBufferPickerSpeedZ;

	// Scan Start Pos 8 Inch
	dwMap[44] = (DWORD)(gRecipeData.m_sMagazine.dScanStartPos8Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan End Pos 8 Inch
	dwMap[45] = (DWORD)(gRecipeData.m_sMagazine.dScanEndPos8Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan Start Pos 12 Inch
	dwMap[46] = (DWORD)(gRecipeData.m_sMagazine.dScanStartPos12Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Scan End Pos 12 Inch
	dwMap[47] = (DWORD)(gRecipeData.m_sMagazine.dScanEndPos12Inch * MAGAZINE_ELEVATOR_FACTOR);

	// Set DPRAM Data Type
	SetDPRamDataType( 3, 1 );

	memset( m_nSysHandlerParam, 0, sizeof(m_nSysHandlerParam) );
	memcpy( m_nSysHandlerParam, dwMap, sizeof(m_nSysHandlerParam) );
	memset( dwMap, 0, sizeof(dwMap) );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, TRUE, 3 );
	*/
}

void CSysUMAC::OnUploadSysCoaterParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;

	// M-Variable Definition
	// M6064->DP:$60140
	// M6065->DP:$60141
	// M6066->DP:$60142
	// M6067->DP:$60143
	// M6068->DP:$60144
	// M6069->DP:$60145
	// M6070->DP:$60146
	// M6071->DP:$60147
	// M6072->DP:$60148
	// M6073->DP:$60149
	// M6074->DP:$6014A
	// M6075->DP:$6014B
	// M6076->DP:$6014C

	DWORD	dwMap[11];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("140"));
	offset = (UINT)HextoNum(szBuf)*4;

	// Coater Spin Theta Loading Pos 8 Inch
	dwMap[0] = (DWORD)(gRecipeData.m_sSpinCoater.dLoadingPos * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Theta Home Offset
	dwMap[1] = (DWORD)(gRecipeData.m_sSpinCoater.dHomePos * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Theta Speed
	dwMap[2] = (DWORD)gRecipeData.m_sSpinCoater.nRotatingSpeed;

	// Coater Spin Theta Loading Pos 12 Inch
	dwMap[3] = (DWORD)(gRecipeData.m_sSpinCoater.dLoadingPos12Inch * SPINCOATER_T_FACTOR / 360.);

	// Coater Spin Z Loading(Up) Position
	//dwMap[3] = (DWORD)(gRecipeData.m_sSpinCoater.dSpinZLoadingPos * SPINCOATER_Z_FACTOR);
	// Coater Spin Z Working(Down) Position
	//dwMap[4] = (DWORD)(gRecipeData.m_sSpinCoater.dSpinZWorkingPos * SPINCOATER_Z_FACTOR);
	// Coater Spin Z Speed
	//dwMap[5] = (DWORD)gRecipeData.m_sSpinCoater.nSpinZSpeed;

	// Coater Arm Nz1 Position
	dwMap[6] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle1Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz2 Position
	dwMap[7] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle2Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz3 Position
	dwMap[8] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle3Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Nz4 Position
	dwMap[9] = (DWORD)(gRecipeData.m_sSpinCoater.dNozzle4Pos * SPINCOATER_ARM_FACTOR);

	// Coater Arm Speed
	dwMap[10] = (DWORD)gRecipeData.m_sSpinCoater.nArmSwingSpeed;

	// Set DPRAM Data Type
	SetDPRamDataType( 4, 1 );

	memset( m_nSysCoaterParam, 0, sizeof(m_nSysCoaterParam) );
	memcpy( m_nSysCoaterParam, dwMap, sizeof(m_nSysCoaterParam) );
	memset( dwMap, 0, sizeof(dwMap) );

	// Insert Queue
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, TRUE, 4 );
	*/
}

void CSysUMAC::OnUploadCoatingParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;
	BOOL	bCheck = FALSE;

	// Start : $60500 ~ $6054F

	DWORD	dwMap[80];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);
	int		nCoatingSize = gMultiParam.GetCoatingParamSize();

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("500"));
	offset = (UINT)HextoNum(szBuf)*4;

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = gMultiParam.GetCoatingParam(i);

		if( NULL == pCoaterParam )
		{
			ErrMessage(_T("Invalid Coating Parameter "), MB_ICONERROR);
			return;
		}

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSpinSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 1 : // Spin Chuck Slope Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSlopeTime );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				else if( dwMap[nIndex] < 2000 ) bCheck = TRUE;
				break;
			case 2 : // Arm Swing Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSwingSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 3 : // Arm Left Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dLeftPos * SPINCOATER_ARM_FACTOR );
				break;
			case 4 : // Arm Right Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dRightPos * SPINCOATER_ARM_FACTOR );
				break;
			case 5 : // Using Nozzle No
				dwMap[nIndex] = (DWORD)( pCoaterParam->nNozzleNo );
				break;
			case 6 : // Process Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nProcessTime );
				break;
			case 7 : // Using Cover
				dwMap[nIndex] = (DWORD)( pCoaterParam->bCover );
				break;
			}
		}
	}

	// Set DPRAM Data Type
	SetDPRamDataType( 7, 1 );

	memset( m_nCoatingParam, 0, sizeof(m_nCoatingParam) );
	memcpy( m_nCoatingParam, dwMap, sizeof(m_nCoatingParam) );
	
	memset( dwMap, 0, sizeof(dwMap) );

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(_T("m6075"));
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, TRUE, 7 );
	*/
}

void CSysUMAC::OnUploadCleaningParam()
{
#ifdef USE_NO_MOTOR
	return;
#endif

/*	if( 0 == GetUMACDriver() )
		return ;

	int		nRet = 0;
	BOOL bCheck = FALSE;

	// Start : $60600 ~ $6064F

	DWORD	dwMap[80];
	char	szBuf[255];
	UINT	offset;
	int		nSize = sizeof(dwMap);
	int		nCoatingSize = gMultiParam.GetCleaningParamSize();

	memset(dwMap, 0, nSize);
	memset(szBuf, 0, 255);

	strcpy_s(szBuf, _T("600"));
	offset = (UINT)HextoNum(szBuf)*4;

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = gMultiParam.GetCleaningParam(i);

		if( NULL == pCoaterParam )
		{
			ErrMessage(_T("Invalid Cleaning Parameter "), MB_ICONERROR);
			return;
		}

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSpinSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 1 : // Spin Chuck Slope Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSlopeTime );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				else if( dwMap[nIndex] < 2000 ) bCheck = TRUE;
				break;
			case 2 : // Arm Swing Speed
				dwMap[nIndex] = (DWORD)( pCoaterParam->nSwingSpeed );
				if( 0 == dwMap[nIndex] ) bCheck = TRUE;
				break;
			case 3 : // Arm Left Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dLeftPos * SPINCOATER_ARM_FACTOR );
				break;
			case 4 : // Arm Right Position
				dwMap[nIndex] = (DWORD)( pCoaterParam->dRightPos * SPINCOATER_ARM_FACTOR );
				break;
			case 5 : // Using Nozzle No
				dwMap[nIndex] = (DWORD)( pCoaterParam->nNozzleNo );
				break;
			case 6 : // Process Time
				dwMap[nIndex] = (DWORD)( pCoaterParam->nProcessTime );
				break;
			case 7 : // Using Cover
				dwMap[nIndex] = (DWORD)( pCoaterParam->bCover );
				break;
			}
		}
	}

	// Set DPRAM Data Type
	SetDPRamDataType( 8, 1 );

	memset( m_nCleaningParam, 0, sizeof(m_nCleaningParam) );
	memcpy( m_nCleaningParam, dwMap, sizeof(m_nCleaningParam) );

	memset( dwMap, 0, sizeof(dwMap) );

	// Insert Queue
	m_clsCmdQueue.AddOnlineCmd(_T("m6076"));
	m_clsCmdQueue.AddDPRamDWORDData( nSize, offset, dwMap, TRUE, 8 );
	*/
}

void CSysUMAC::SetDPRamUploadData(DOnlineCmdData* pData)
{
	switch( pData->GetDataType() )
	{
	case 3 :
		memset( m_nUploadSysHandlerParam, 0, sizeof(m_nUploadSysHandlerParam) );
		memcpy( m_nUploadSysHandlerParam, pData->GetDPRamDWORDData(), 
				sizeof(m_nUploadSysHandlerParam) );
		break;
	case 4 :
		memset( m_nUploadSysCoaterParam, 0, sizeof(m_nUploadSysCoaterParam) );
		memcpy( m_nUploadSysCoaterParam, pData->GetDPRamDWORDData(), 
				sizeof(m_nUploadSysCoaterParam) );
		break;
	case 7 :
		memset( m_nUploadCoatingParam, 0, sizeof(m_nUploadCoatingParam) );
		memcpy( m_nUploadCoatingParam, pData->GetDPRamDWORDData(),
				sizeof(m_nUploadCoatingParam) ); 
		break;
	case 8 :
		memset( m_nUploadCleaningParam, 0, sizeof(m_nUploadCleaningParam) );
		memcpy( m_nUploadCleaningParam, pData->GetDPRamDWORDData(),
				sizeof(m_nUploadCleaningParam) );
		break;
	}
}

// FALSE : Is not equal, TRUE : Equal
BOOL CSysUMAC::CompareDPRamData( int nType )
{
	BOOL bIsEqual = TRUE;

	switch( nType )
	{
	case 3 :
		{
			int nSize = sizeof(m_nSysHandlerParam) / sizeof(DWORD);

			for( int i = 0 ; i < nSize ; i++ )
			{
				if( i > 39 && i < 44 )
					continue;

				if( m_nSysHandlerParam[i] != m_nUploadSysHandlerParam[i] )
				{
					bIsEqual = FALSE;
					break;
				}
			}
		}
		break;
	case 4 :
		{
			int nSize = sizeof(m_nSysCoaterParam) / sizeof(DWORD);

			for( int i = 0 ; i < nSize ; i++ )
			{
				if( m_nSysCoaterParam[i] != m_nUploadSysCoaterParam[i] )
				{
					bIsEqual = FALSE;
					break;
				}
			}
		}
		break;
	case 7 :
		{
			int nSize = sizeof(m_nCoatingParam) / sizeof(DWORD);

			for( int i = 0 ; i < nSize ; i++ )
			{
				if( m_nCoatingParam[i] != m_nUploadCoatingParam[i] )
				{
					bIsEqual = FALSE;
					break;
				}
			}
		}
		break;
	case 8 :
		{
			int nSize = sizeof(m_nCleaningParam) / sizeof(DWORD);

			for( int i = 0 ; i < nSize ; i++ )
			{
				if( m_nCleaningParam[i] != m_nUploadCleaningParam[i] )
				{
					bIsEqual = FALSE;
					break;
				}
			}
		}
		break;
	}

	return bIsEqual;
}

void CSysUMAC::OnApplyUploadSysHandlerParam()
{
	// X, Y Loading Position
/*	gRecipeData.m_dWaferLoadingPos.x = double(m_nUploadSysHandlerParam[0]) / STAGE_X_FACTOR;
	gRecipeData.m_dWaferLoadingPos.y = double(m_nUploadSysHandlerParam[1]) / STAGE_Y_FACTOR;

	// First Slot Wafer Catch Position in Cassette (8")
	gRecipeData.m_sMagazine.d8InchPos = double(m_nUploadSysHandlerParam[2]) / MAGAZINE_ELEVATOR_FACTOR;

	// First Slot Wafer Catch Position in Cassette (12")
	gRecipeData.m_sMagazine.d12InchPos = double(m_nUploadSysHandlerParam[3]) / MAGAZINE_ELEVATOR_FACTOR;

	// Wafer Slot Count (8")
	gRecipeData.m_sMagazine.n8InchSlotNo = m_nUploadSysHandlerParam[4];

	// Wafer Slot Count (12")
	gRecipeData.m_sMagazine.n12InchSlotNo = m_nUploadSysHandlerParam[5];

	// Elevator Speed
	gRecipeData.m_sMagazine.nMagazineSpeed = m_nUploadSysHandlerParam[7];

	// Wafer Grip / Release Position On Rail (8");
	gRecipeData.m_sAlignRail.dReleaseGripper8Inch = double(m_nUploadSysHandlerParam[8]) / PREALIGN_GRIPPER_FACTOR;

	// Wafer Grip / Release Position On Rail (12");
	gRecipeData.m_sAlignRail.dReleaseGripper12Inch = double(m_nUploadSysHandlerParam[9]) / PREALIGN_GRIPPER_FACTOR;

	// Wafer Grip / Release Position On Cassette (8");
	gRecipeData.m_sAlignRail.dGripGripper8Inch = double(m_nUploadSysHandlerParam[10]) / PREALIGN_GRIPPER_FACTOR;

	// Wafer Grip / Release Position On Cassette (12");
	gRecipeData.m_sAlignRail.dGripGripper12Inch = double(m_nUploadSysHandlerParam[11]) / PREALIGN_GRIPPER_FACTOR;

	// Gripper Speed
	gRecipeData.m_sAlignRail.nGripperSpeed = m_nUploadSysHandlerParam[12];

	// Wafer Unloading X Position
	gRecipeData.m_dUnloadingXPos = double(m_nUploadSysHandlerParam[13]) / STAGE_X_FACTOR;

	// 8 Inch Wafer Slot Pitch
	gRecipeData.m_sMagazine.d8InchPitch = double(m_nUploadSysHandlerParam[14]) / MAGAZINE_ELEVATOR_FACTOR;

	// 12 Inch Wafer Slot Pitch
	gRecipeData.m_sMagazine.d12InchPitch = double(m_nUploadSysHandlerParam[15]) / MAGAZINE_ELEVATOR_FACTOR;

	// Align Rail Moving Position (8")
	gRecipeData.m_sAlignRail.dAlignRailMovePos8Inch = double(m_nUploadSysHandlerParam[16]) / PREALIGN_RAIL_FACTOR;

	// Align Rail Moveing Position (12")
	gRecipeData.m_sAlignRail.dAlignRailMovePos12Inch = double(m_nUploadSysHandlerParam[17]) / PREALIGN_RAIL_FACTOR;

	// Align Rail Align Position (8")
	gRecipeData.m_sAlignRail.dAlignRailAlignPos8Inch = double(m_nUploadSysHandlerParam[18]) / PREALIGN_RAIL_FACTOR;

	// Align Rail Align Position (12")
	gRecipeData.m_sAlignRail.dAlignRailAlignPos12Inch = double(m_nUploadSysHandlerParam[19]) / PREALIGN_RAIL_FACTOR;

	// Align Rail Speed
	gRecipeData.m_sAlignRail.nRailSpeed = m_nUploadSysHandlerParam[20];

	// Loader Picker Y Align Rail Pos
	gRecipeData.m_sLoadPicker.dAlignRailLoadingPosY = double(m_nUploadSysHandlerParam[21]) / LPICKER_Y_FACTOR;

	// Loader Picker Y Coater Pos
	gRecipeData.m_sLoadPicker.dSpinnerLoadingPosY = double(m_nUploadSysHandlerParam[22]) / LPICKER_Y_FACTOR;

	// Loader Picker Y Buffer Pos
	gRecipeData.m_sLoadPicker.dBufferLoadingPosX = double(m_nUploadSysHandlerParam[23]) / LPICKER_Y_FACTOR;

	// Loader Picker Y Stage Pos
	gRecipeData.m_sLoadPicker.dStageLoadingPosX = double(m_nUploadSysHandlerParam[24]) / LPICKER_Y_FACTOR;

	// Loader Picker Y Speed
	gRecipeData.m_sLoadPicker.nLoadPickerSpeedX = m_nUploadSysHandlerParam[25];

	// Loader Picker Z Align Rail Pos
	gRecipeData.m_sLoadPicker.dAlignRailLoadingPosZ = double(m_nUploadSysHandlerParam[26]) / LPICKER_Y_FACTOR;

	// Loader Picker Z Coater Pos
	gRecipeData.m_sLoadPicker.dSpinnerLoadingPosZ = double(m_nUploadSysHandlerParam[27]) / LPICKER_Y_FACTOR;

	// Loader Picker Z Buffer Pos (8")
	gRecipeData.m_sLoadPicker.dBufferLoadingPosZ = double(m_nUploadSysHandlerParam[28]) / LPICKER_Y_FACTOR;

	// Loader Picker Z Buffer Pos (12")
	gRecipeData.m_sLoadPicker.dBufferLoadingPosZ12Inch = double(m_nUploadSysHandlerParam[29]) / LPICKER_Y_FACTOR;

	// Loader Picker Z Stage Pos
	gRecipeData.m_sLoadPicker.dStageLoadingPosZ = double(m_nUploadSysHandlerParam[30]) / LPICKER_Y_FACTOR;

	// Loader Picker Z Speed
	gRecipeData.m_sLoadPicker.nLoadPickerSpeedZ = m_nUploadSysHandlerParam[31];

	// Buffer Picker Y Buffer Pos
	gRecipeData.m_sBufferPicker.dBufferLoadingPosX = double(m_nUploadSysHandlerParam[32]) / BPICKER_Y_FACTOR;

	// Buffer Picker Y Stage Pos
	gRecipeData.m_sBufferPicker.dStageLoadingPosX = double(m_nUploadSysHandlerParam[33]) / BPICKER_Y_FACTOR;

	// Buffer Picker Y Speed
	gRecipeData.m_sBufferPicker.nBufferPickerSpeedX = m_nUploadSysHandlerParam[34];

	// Buffer Picker Z Buffer Pos (8")
	gRecipeData.m_sBufferPicker.dBufferLoadingPosZ = double(m_nUploadSysHandlerParam[35]) / BPICKER_Y_FACTOR;

	// Buffer Picker Z Buffer Pos (12")
	gRecipeData.m_sBufferPicker.dBufferLoadingPosZ12Inch = double(m_nUploadSysHandlerParam[36]) / BPICKER_Y_FACTOR;

	// Buffer Picker Z Stage Pos
	gRecipeData.m_sBufferPicker.dStageLoadingPosZ = double(m_nUploadSysHandlerParam[37]) / BPICKER_Y_FACTOR;

	// Buffer Picker Z Speed
	gRecipeData.m_sBufferPicker.nBufferPickerSpeedZ = m_nUploadSysHandlerParam[38];

	// Scan Start Pos 8 Inch
	gRecipeData.m_sMagazine.dScanStartPos8Inch = double(m_nUploadSysHandlerParam[44]) / MAGAZINE_ELEVATOR_FACTOR;

	// Scan End Pos 8 Inch
	gRecipeData.m_sMagazine.dScanEndPos8Inch = double(m_nUploadSysHandlerParam[45]) / MAGAZINE_ELEVATOR_FACTOR;

	// Scan Start Pos 12 Inch
	gRecipeData.m_sMagazine.dScanStartPos12Inch = double(m_nUploadSysHandlerParam[46]) / MAGAZINE_ELEVATOR_FACTOR;

	// Scan End Pos 12 Inch
	gRecipeData.m_sMagazine.dScanEndPos12Inch = double(m_nUploadSysHandlerParam[47]) / MAGAZINE_ELEVATOR_FACTOR;
*/
  }

void CSysUMAC::OnApplyUploadSysCoaterParam()
{
	// Coater Spin Theta Loading Pos
/*	gRecipeData.m_sSpinCoater.dLoadingPos = double(m_nUploadSysCoaterParam[0]) / SPINCOATER_T_FACTOR;

	// Coater Spin Theta Home Offset
	gRecipeData.m_sSpinCoater.dHomePos = double(m_nUploadSysCoaterParam[1]) / SPINCOATER_T_FACTOR;

	// Coater Spin Theta Speed
	gRecipeData.m_sSpinCoater.nRotatingSpeed = m_nUploadSysCoaterParam[2];

	// Coater Spin Z Loading(Up) Position
	gRecipeData.m_sSpinCoater.dSpinZLoadingPos = double(m_nUploadSysCoaterParam[3]) / SPINCOATER_Z_FACTOR;

	// Coater Spin Z Working(Down) Position
	gRecipeData.m_sSpinCoater.dSpinZWorkingPos = double(m_nUploadSysCoaterParam[4]) / SPINCOATER_Z_FACTOR;

	// Coater Spin Z Speed
	gRecipeData.m_sSpinCoater.nSpinZSpeed = m_nUploadSysCoaterParam[5];

	// Coater Arm Nz1 Position
	gRecipeData.m_sSpinCoater.dNozzle1Pos = double(m_nUploadSysCoaterParam[6]) / SPINCOATER_ARM_FACTOR;

	// Coater Arm Nz2 Position
	gRecipeData.m_sSpinCoater.dNozzle2Pos = double(m_nUploadSysCoaterParam[7]) / SPINCOATER_ARM_FACTOR;

	// Coater Arm Nz3 Position
	gRecipeData.m_sSpinCoater.dNozzle3Pos = double(m_nUploadSysCoaterParam[8]) / SPINCOATER_ARM_FACTOR;

	// Coater Arm Nz4 Position
	gRecipeData.m_sSpinCoater.dNozzle4Pos = double(m_nUploadSysCoaterParam[9]) / SPINCOATER_ARM_FACTOR;

	// Coater Arm Speed
	gRecipeData.m_sSpinCoater.nArmSwingSpeed = m_nUploadSysCoaterParam[10];
*/
}

void CSysUMAC::OnApplyUploadCoatingParam()
{
/*	int		nCoatingSize = m_nCoatingParamSize;

	if( nCoatingSize < 1 )
	{
		CString str;

		str.Format(_T("Coating Parameter Count(%d) Error"), nCoatingSize);
		ErrMessage( str, MB_ICONSTOP );
		return;
	}

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = new SCOATERPARAM;

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				pCoaterParam->nSpinSpeed = m_nUploadCoatingParam[nIndex];
				break;
			case 1 : // Spin Chuck Slope Time
				pCoaterParam->nSlopeTime = m_nUploadCoatingParam[nIndex];
				break;
			case 2 : // Arm Swing Speed
				pCoaterParam->nSwingSpeed = m_nUploadCoatingParam[nIndex];
				break;
			case 3 : // Arm Left Position
				pCoaterParam->dLeftPos = double( m_nUploadCoatingParam[nIndex] ) / SPINCOATER_ARM_FACTOR;
				break;
			case 4 : // Arm Right Position
				pCoaterParam->dRightPos = double( m_nUploadCoatingParam[nIndex] ) / SPINCOATER_ARM_FACTOR;
				break;
			case 5 : // Using Nozzle No
				pCoaterParam->nNozzleNo = m_nUploadCoatingParam[nIndex];
				break;
			case 6 : // Process Time
				pCoaterParam->nProcessTime = m_nUploadCoatingParam[nIndex];
				break;
			case 7 : // Using Cover
				pCoaterParam->bCover = m_nUploadCoatingParam[nIndex];
				sprintf_s(pCoaterParam->szParamName, _T("Param %d"), i+1);
				break;
			}
		}

		gMultiParam.InsertCoatingParam( pCoaterParam );
	}
	*/
}

void CSysUMAC::OnApplyUploadCleaningParam()
{
/*	int		nCoatingSize = m_nCleaningParamSize;

	if( nCoatingSize < 1 )
	{
		CString str;

		str.Format(_T("Cleaning Parameter Count(%d) Error"), nCoatingSize);
		ErrMessage( str, MB_ICONSTOP );
		return;
	}

	int nIndex = 0, nMode = 0;
	SCOATERPARAM* pCoaterParam = NULL;

	for( int i = 0 ; i < nCoatingSize ; i++ )
	{
		pCoaterParam = new SCOATERPARAM;

		for( int j = 0 ; j < 8 ; j++ )
		{
			nMode = 8 * i;
			nIndex = nMode + j;
			switch( j )
			{
			case 0 : // Spin T Speed
				pCoaterParam->nSpinSpeed = m_nUploadCleaningParam[nIndex];
				break;
			case 1 : // Spin Chuck Slope Time
				pCoaterParam->nSlopeTime = m_nUploadCleaningParam[nIndex];
				break;
			case 2 : // Arm Swing Speed
				pCoaterParam->nSwingSpeed = m_nUploadCleaningParam[nIndex];
				break;
			case 3 : // Arm Left Position
				pCoaterParam->dLeftPos = double( m_nUploadCleaningParam[nIndex] ) / SPINCOATER_ARM_FACTOR;
				break;
			case 4 : // Arm Right Position
				pCoaterParam->dRightPos = double( m_nUploadCleaningParam[nIndex] ) / SPINCOATER_ARM_FACTOR;
				break;
			case 5 : // Using Nozzle No
				pCoaterParam->nNozzleNo = m_nUploadCleaningParam[nIndex];
				break;
			case 6 : // Process Time
				pCoaterParam->nProcessTime = m_nUploadCleaningParam[nIndex];
				break;
			case 7 : // Using Cover
				pCoaterParam->bCover = m_nUploadCleaningParam[nIndex];
				sprintf_s(pCoaterParam->szParamName, _T("Param %d"), i+1);
				break;
			}
		} // for

		gMultiParam.InsertCleaningParam( pCoaterParam );
	}
	*/
}

double CSysUMAC::GetPosition(int nAxis)
{
	if(nAxis == AXIS_X)
		return (gHandlerInput.m_sStagePos.x) / STAGE_X_FACTOR;
	if(nAxis == AXIS_Y)
		return (gHandlerInput.m_sStagePos.y) / STAGE_Y_FACTOR;
	if(nAxis == AXIS_Z1)
		return (gHandlerInput.m_sStagePos.z) / STAGE_Z_FACTOR;
	if(nAxis == AXIS_M)
		return (gHandlerInput.m_sStagePos.t) / STAGE_T_FACTOR;

	return 0;
}

LONG CSysUMAC::GetCurrentError(ERRORCOMMAND nError)
{
	LONG m_lErrorIo, m_lStatusIO1, m_lStatusIO2, m_lStatusIO3;
	LONG m_lErrorTableLimit, m_lErrorOtherLimit, m_lErrorTable, m_lErrorOthers2;
	switch(nError)
	{
	case ERROR_IO			:
		{
			m_lErrorIo = 0;
			m_lErrorIo += (gHandlerInput.m_sSysSensor.bEmergencySwitch)					? 0x0001 : 0x0000; // em stop
//			m_lErrorIo += (m_NewStatus.m_bServoPowerOffAlarm)							? 0x0002 : 0x0000; // Servo power off alarm
			m_lErrorIo += (!gHandlerInput.m_clsPCOutput.m_sStageIF.bAllInitialEnd)		? 0x0004 : 0x0000; // main station init error
//			m_lErrorIo += (m_NewStatus.m_bPCAliveOffError)								? 0x0008 : 0x0000; // pc alive signal off error
			m_lErrorIo += (!gHandlerInput.m_clsPCOutput.m_bDoorByPass & 
							!gHandlerInput.m_sSysSensor.bFrontDoorLockSol)				? 0x0010 : 0x0000; // Main Door Open	
			m_lErrorIo += (gHandlerInput.m_clsPCOutput.m_sStageIF.bDustCollectorAlarm)	? 0x0020 : 0x0000; // rear door open
//			m_lErrorIo += (m_NewStatus.m_bLaserPowerOffAlarm)							? 0x0040 : 0x0000; // laser power off error
			m_lErrorIo += (!gHandlerInput.m_sSysSensor.bSystemAirPressure)				? 0x0080 : 0x0000; // Main Suction Alarm
		}
		return m_lErrorIo;
	case STATUS_IO1			:
		{
			m_lStatusIO1 = 0;
			m_lStatusIO1 += (gHandlerInput.m_clsPCOutput.m_sStageIF.bMachineReady)		? 0x0001 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bPLCAlive)									? 0x0002 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bMachineRunning)								? 0x0004 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bSafteyMode)									? 0x0008 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_clsPCOutput.m_bDoorByPass)					? 0x0010 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_sSysSensor.bTableVacuumSensor)				? 0x0020 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_b2ndTablePCBExist)							? 0x0040 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_clsPCOutput.m_sStageIF.bAllInitialEnd)		? 0x0080 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_clsPCOutput.m_sStageIF.bAllInitializing)	? 0x0100 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bMainStationAlarm)							? 0x0200 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_sStageX.bHomeEnd)							? 0x0400 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_sStageX.bHoming)							? 0x0800 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bXInposition)								? 0x1000 : 0x0000;
//			m_lStatusIO1 += (m_NewStatus.m_bXRun)										? 0x2000 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_sStageY.bHomeEnd)							? 0x4000 : 0x0000;
			m_lStatusIO1 += (gHandlerInput.m_sStageY.bHoming)							? 0x8000 : 0x0000;
		}
		return m_lStatusIO1;
	case STATUS_IO2			:
		{
			m_lStatusIO2 = 0;
			m_lStatusIO2 += (gHandlerInput.m_sStageZ.bHomeEnd)					? 0x0004 : 0x0000;
			m_lStatusIO2 += (gHandlerInput.m_sStageZ.bHoming)					? 0x0008 : 0x0000;
			m_lStatusIO2 += (gHandlerInput.m_sStageT.bHomeEnd)					? 0x0400 : 0x0000;
			m_lStatusIO2 += (gHandlerInput.m_sStageT.bHoming)					? 0x0800 : 0x0000;

		}
		return m_lStatusIO2;
	case STATUS_IO3			:
		{
			m_lStatusIO3 = 0;
			m_lStatusIO3 += (gHandlerInput.m_sSysSensor.bTableVacuumOnSol)	? 0x0400 : 0x0000;
		}
		return m_lStatusIO3;
	case STATUS_IO4			:
		return 0;
	case ERROR_TABLELIMIT	:
		{
			m_lErrorTableLimit = 0;
			m_lErrorTableLimit += (gHandlerInput.m_sStageX.bPlusLimit) ? 0x0001 : 0x0000;	// X+ Limit
			m_lErrorTableLimit += (gHandlerInput.m_sStageY.bMinusLimit) ? 0x0002 : 0x0000;	// X- Limit
			m_lErrorTableLimit += (gHandlerInput.m_sStageY.bPlusLimit) ? 0x0004 : 0x0000;	// Y+ Limit
			m_lErrorTableLimit += (gHandlerInput.m_sStageX.bMinusLimit) ? 0x0008 : 0x0000;	// Y- Limit
			
			m_lErrorTableLimit += (gHandlerInput.m_sStageZ.bPlusLimit) ? 0x0040 : 0x0000;	// Z1+ Limit
			m_lErrorTableLimit += (gHandlerInput.m_sStageZ.bMinusLimit) ? 0x0080 : 0x0000;	// Z1- Limit
		}
		return m_lErrorTableLimit;
	case ERROR_OTHERLIMIT	:
		{
			m_lErrorOtherLimit = 0;
			m_lErrorOtherLimit += (gHandlerInput.m_sStageT.bPlusLimit)			? 0x0100 : 0x0000;  // M1+ Limit
			m_lErrorOtherLimit += (gHandlerInput.m_sStageT.bMinusLimit)			? 0x0200 : 0x0000;  // M1- Limit
		}
		return m_lErrorOtherLimit;
	case ERROR_TABLE	:
		{
			m_lErrorTable = 0;
//			m_lErrorTable += (m_NewStatus.m_bXYMoveDangerError)					? 0x0001 : 0x0000; // xy move danger error
//			m_lErrorTable += (m_NewStatus.m_bXYStopError)						? 0x0002 : 0x0000; // XY Stop Error
			m_lErrorTable += (gHandlerInput.m_sStageX.bDriveFault)							? 0x0004 : 0x0000; // X Fault
			m_lErrorTable += (gHandlerInput.m_sStageX.bFollowingErr)						? 0x0008 : 0x0000; // X Fatal Following Err
			m_lErrorTable += (gHandlerInput.m_sStageX.bOpenLoop)							? 0x0010 : 0x0000; // X Open Loop
			m_lErrorTable += (gHandlerInput.m_sStageX.bHomeTimeOver)						? 0x0020 : 0x0000; // X Homing TimeOut
			m_lErrorTable += (gHandlerInput.m_sStageY.bDriveFault)							? 0x0040 : 0x0000; // Y Fault
			m_lErrorTable += (gHandlerInput.m_sStageY.bFollowingErr)						? 0x0080 : 0x0000; // Y Fatal Following Err
			m_lErrorTable += (gHandlerInput.m_sStageY.bOpenLoop)							? 0x0100 : 0x0000; // Y Open Loop
			m_lErrorTable += (gHandlerInput.m_sStageY.bHomeTimeOver)						? 0x0200 : 0x0000; // Y Homing TimeOut
			m_lErrorTable += (gHandlerInput.m_sStageZ.bDriveFault)							? 0x0400 : 0x0000; // Z1 Fault
			m_lErrorTable += (gHandlerInput.m_sStageZ.bFollowingErr)						? 0x0800 : 0x0000; // Z1 Fatal Following Err
			m_lErrorTable += (gHandlerInput.m_sStageZ.bOpenLoop)						? 0x1000 : 0x0000; // Z1 Open Loop
			m_lErrorTable += (gHandlerInput.m_sStageZ.bHomeTimeOver)					? 0x2000 : 0x0000; // Z1 Homing TimeOUt
//			m_lErrorTable += (m_NewStatus.m_bZ2Fault)							? 0x4000 : 0x0000; // Z2 Fault
//			m_lErrorTable += (m_NewStatus.m_bZ2FollowError)						? 0x8000 : 0x0000; // Z2 Fatal Following Err
		}
		return m_lErrorTable;
	case ERROR_OTHERS2		:
		{
			m_lErrorOthers2 = 0;
			m_lErrorOthers2 += (gHandlerInput.m_sStageT.bDriveFault)			? 0x0040 : 0x0000; // M1 Fault
			m_lErrorOthers2 += (gHandlerInput.m_sStageT.bFollowingErr)			? 0x0080 : 0x0000; // M1 Fatal Following Err
			m_lErrorOthers2 += (gHandlerInput.m_sStageT.bOpenLoop)				? 0x0100 : 0x0000; // M1 OpenLoop
			m_lErrorOthers2 += (gHandlerInput.m_sStageT.bHomeTimeOver)			? 0x0200 : 0x0000; // M1 Homing TimeOut
		}
		return m_lErrorOthers2;
	}
	return 0;
}
