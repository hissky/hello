// ScannerBiCubic.cpp: implementation of the CScannerBiCubic class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScannerBiCubic.h"
#include <cmath>

const int MIN_GRID_SIZE = 4;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CScannerBiCubic::CScannerBiCubic()
{
	m_XGradient = m_YGradient = m_CrossDeriv = NULL;
	m_Coef = NULL;
	m_nXStart = m_nXEnd = m_nYStart = m_nYEnd = 0;
}

CScannerBiCubic::~CScannerBiCubic()
{
	DeleteMemory();
}

void CScannerBiCubic::DeleteMemory()
{
	delete [] m_XGradient;	m_XGradient = NULL;
	delete [] m_YGradient;	m_YGradient = NULL;
	delete [] m_CrossDeriv;	m_CrossDeriv = NULL;
	delete [] m_Coef;		m_Coef = NULL;
}

void CScannerBiCubic::UpdateWholeCalibration()
{
	if (!m_bIsSet)
		return;

	if (m_nGridX < MIN_GRID_SIZE || m_nGridY < MIN_GRID_SIZE)
		return;

	if (!MakeDerivatives())
		return;

	if (!MakeCoefficient())
		return;

	m_nXStart = m_dXStart > MIN_FIELD ? (fmod(m_dXStart, 1.0) == 0.0 ? static_cast<int>(m_dXStart) : static_cast<int>(m_dXStart + 1)) : MIN_FIELD;
	m_nXEnd = m_dXEnd > MAX_FIELD ? MAX_FIELD : static_cast<int>(m_dXEnd);
	m_nYStart = m_dYStart > MIN_FIELD ? (fmod(m_dYStart, 1.0) == 0.0 ? static_cast<int>(m_dYStart) : static_cast<int>(m_dYStart + 1)) : MIN_FIELD;
	m_nYEnd = m_dYEnd > MAX_FIELD ? MAX_FIELD : static_cast<int>(m_dYEnd);

	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
		{
			double dX, dY;
			GetPartialCalibrationOffset(nX /*+ m_dGap * 2*/, nY /*+ m_dGap * 2*/, dX, dY);
			m_Matrix[nX][nY].x = static_cast<float>(dX);
			m_Matrix[nX][nY].y = static_cast<float>(dY);
		}
	}
}

BOOL CScannerBiCubic::MakeCoefficient()
{
	TRY
	{
		delete [] m_Coef;
		m_Coef = NULL;
		
		m_Coef = new COEF[(m_nGridX - 1) * (m_nGridY - 1)];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		DeleteMemory();
		
		return FALSE;
	}
	END_CATCH

	double dVal[4], dXGra[4], dYGra[4], dCross[4];
	for (int i = 0; i < m_nGridX - 1; i++)
	{
		for (int j = 0; j < m_nGridY - 1; j++)
		{
			dVal[0] = m_Offset[m_nGridY * i + j].x;
			dVal[1] = m_Offset[m_nGridY * (i + 1) + j].x;
			dVal[2] = m_Offset[m_nGridY * (i + 1) + j + 1].x;
			dVal[3] = m_Offset[m_nGridY * i + j + 1].x;

			dXGra[0] = m_XGradient[m_nGridY * i + j].x;
			dXGra[1] = m_XGradient[m_nGridY * (i + 1) + j].x;
			dXGra[2] = m_XGradient[m_nGridY * (i + 1) + j + 1].x;
			dXGra[3] = m_XGradient[m_nGridY * i + j + 1].x;

			dYGra[0] = m_YGradient[m_nGridY * i + j].x;
			dYGra[1] = m_YGradient[m_nGridY * (i + 1) + j].x;
			dYGra[2] = m_YGradient[m_nGridY * (i + 1) + j + 1].x;
			dYGra[3] = m_YGradient[m_nGridY * i + j + 1].x;

			dCross[0] = m_CrossDeriv[m_nGridY * i + j].x;
			dCross[1] = m_CrossDeriv[m_nGridY * (i + 1) + j].x;
			dCross[2] = m_CrossDeriv[m_nGridY * (i + 1) + j + 1].x;
			dCross[3] = m_CrossDeriv[m_nGridY * i + j + 1].x;

			SetCoefficient(dVal, dXGra, dYGra, dCross, i, j, true);

			dVal[0] = m_Offset[m_nGridY * i + j].y;
			dVal[1] = m_Offset[m_nGridY * (i + 1) + j].y;
			dVal[2] = m_Offset[m_nGridY * (i + 1) + j + 1].y;
			dVal[3] = m_Offset[m_nGridY * i + j + 1].y;
			
			dXGra[0] = m_XGradient[m_nGridY * i + j].y;
			dXGra[1] = m_XGradient[m_nGridY * (i + 1) + j].y;
			dXGra[2] = m_XGradient[m_nGridY * (i + 1) + j + 1].y;
			dXGra[3] = m_XGradient[m_nGridY * i + j + 1].y;
			
			dYGra[0] = m_YGradient[m_nGridY * i + j].y;
			dYGra[1] = m_YGradient[m_nGridY * (i + 1) + j].y;
			dYGra[2] = m_YGradient[m_nGridY * (i + 1) + j + 1].y;
			dYGra[3] = m_YGradient[m_nGridY * i + j + 1].y;
			
			dCross[0] = m_CrossDeriv[m_nGridY * i + j].y;
			dCross[1] = m_CrossDeriv[m_nGridY * (i + 1) + j].y;
			dCross[2] = m_CrossDeriv[m_nGridY * (i + 1) + j + 1].y;
			dCross[3] = m_CrossDeriv[m_nGridY * i + j + 1].y;
			
			SetCoefficient(dVal, dXGra, dYGra, dCross, i, j, false);
		}
	}

	return TRUE;
}

void CScannerBiCubic::SetCoefficient(double* dVal, double* dXGra, double* dYGra, double* dCross, int nX, int nY, bool bIsX)
{
	static int nWeight[16 * 16] =
	{
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
		-3, 0, 0, 3, 0, 0, 0, 0, -2, 0, 0, -1, 0, 0, 0, 0,
		2, 0, 0, -2, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
		0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
		0, 0, 0, 0, -3, 0, 0, 3, 0, 0, 0, 0, -2, 0, 0, -1,
		0, 0, 0, 0, 2, 0, 0, -2, 0, 0, 0, 0, 1, 0, 0, 1,
		-3, 3, 0, 0, -2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, -3, 3, 0, 0, -2, -1, 0, 0,
		9, -9, 9, -9, 6, 3, -3, -6, 6, -6, -3, 3, 4, 2, 1, 2,
		-6, 6, -6, 6, -4, -2, 2, 4, -3, 3, 3, -3, -2, -1, -1, -2,
		2, -2, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 2, -2, 0, 0, 1, 1, 0, 0,
		-6, 6, -6, 6, -3, -3, 3, 3, -4, 4, 2, -2, -2, -2, -1, -1,
		4, -4, 4, -4, 2, 2, -2, -2, 2, -2, -2, 2, 1, 1, 1, 1
	};

	double cl[16], x[16];

	for (int i = 0; i < 4; i++)
	{
		x[i] = dVal[i];
		x[i + 4] = dXGra[i] * m_dGap;
		x[i + 8] = dYGra[i] * m_dGap;
		x[i + 12] = dCross[i] * m_dGap * m_dGap;
	}

	for (int i = 0; i < 16; i++)
	{
		double xx = 0.0;
		for (int j = 0; j < 16; j++)
			xx += nWeight[16 * i + j] * x[j];
		cl[i] = xx;
	}

	int k = 0;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (bIsX)
				m_Coef[(m_nGridY - 1) * nX + nY].dCoef[i][j].x = cl[k++];
			else
				m_Coef[(m_nGridY - 1) * nX + nY].dCoef[i][j].y = cl[k++];
		}
	}
}

BOOL CScannerBiCubic::MakeDerivatives()
{
	TRY
	{
		DeleteMemory();

		m_XGradient = new DPOINT[m_nGridX * m_nGridY];
		m_YGradient = new DPOINT[m_nGridX * m_nGridY];
		m_CrossDeriv = new DPOINT[m_nGridX * m_nGridY];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		DeleteMemory();
		
		return FALSE;
	}
	END_CATCH

	for (int i = 0; i < m_nGridX; i++)
	{
		for (int j = 0; j < m_nGridY; j++)
		{
			if (i == m_nGridX - 1)
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * (i - 1) + j].x) / m_dGap;
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * (i - 1) + j].y) / m_dGap;
			}
			else if (i == 0)
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * i + j].x) / m_dGap;
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * i + j].y) / m_dGap;
			}
			else
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i - 1) + j].x) / (m_dGap * 2.0);
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i - 1) + j].y) / (m_dGap * 2.0);
			}

			if (j == m_nGridY - 1)
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * i + j - 1].x) / m_dGap;
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * i + j - 1].y) / m_dGap;
			}
			else if (j == 0)
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j].x) / m_dGap;
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j].y) / m_dGap;
			}
			else
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j - 1].x) / (m_dGap * 2.0);
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j - 1].y) / (m_dGap * 2.0);
			}

			if (i == 0 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j].x
					- m_Offset[m_nGridY * i + j + 1].x + m_Offset[m_nGridY * i + j].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j].y
					- m_Offset[m_nGridY * i + j + 1].y + m_Offset[m_nGridY * i + j].y) / m_dGap / m_dGap;
			}
			else if (i == 0 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * i + j].x + m_Offset[m_nGridY * i + j - 1].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * i + j].y + m_Offset[m_nGridY * i + j - 1].y) / m_dGap / m_dGap;
			}
			else if (i == m_nGridX - 1 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j].y) / m_dGap / m_dGap;
			}
			else if (i == m_nGridX - 1 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * i + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * i + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / m_dGap / m_dGap;
			}
			else if (i == 0 && j != 0 && j != m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * i + j + 1].x + m_Offset[m_nGridY * i + j - 1].x) / m_dGap / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * i + j + 1].y + m_Offset[m_nGridY * i + j - 1].y) / m_dGap / (m_dGap * 2.0);
			}
			else if (i == m_nGridX - 1 && j != 0 && j != m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / m_dGap / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / m_dGap / (m_dGap * 2.0);
			}
			else if (i != 0 && i != m_nGridX - 1 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j].x) / (m_dGap * 2.0) / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j].y) / (m_dGap * 2.0) / m_dGap;
			}
			else if (i != 0 && i != m_nGridX - 1 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / (m_dGap * 2.0) / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / (m_dGap * 2.0) / m_dGap;
			}
			else
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / (m_dGap * 2.0) / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / (m_dGap * 2.0) / (m_dGap * 2.0);
			}
		}
	}

	return TRUE;
}

void CScannerBiCubic::GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsInside(dX, dY))
	{
		// index = m_nGridY * nX + nY : linear
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);

		double dXDist = dX - m_dXStart - m_dGap * nX;
		double dYDist = dY - m_dYStart - m_dGap * nY;

		double ax, bx, ay, by;

		if (nX == m_nGridX - 1)
			ax = m_Offset[m_nGridY * nX + nY].x;
		else
			ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			bx = ax;
		else if (nX == m_nGridX - 1 && nY != m_nGridY - 1)
			bx = m_Offset[m_nGridY * nX + nY + 1].x;
		else
			bx = m_Offset[m_nGridY * nX + nY + 1].x + (m_Offset[m_nGridY * (nX + 1) + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			ay = m_Offset[m_nGridY * nX + nY].y;
		else
			ay = m_Offset[m_nGridY * nX + nY].y + (m_Offset[m_nGridY * nX + nY + 1].y - m_Offset[m_nGridY * nX + nY].y) * dYDist / m_dGap;

		if (nX == m_nGridX - 1)
			by = ay;
		else if (nX != m_nGridX - 1 && nY == m_nGridY - 1)
			by = m_Offset[m_nGridY * (nX + 1) + nY].y;
		else
			by = m_Offset[m_nGridY * (nX + 1) + nY].y + (m_Offset[m_nGridY * (nX + 1) + nY + 1].y - m_Offset[m_nGridY * (nX + 1) + nY].y) * dYDist / m_dGap;

		dXOffset = ax + (bx - ax) * dYDist / m_dGap;
		dYOffset = ay + (by - ay) * dXDist / m_dGap;

/*		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
		if (nX == m_nGridX - 1)		nX = m_nGridX - 2;
		if (nY == m_nGridY - 1)		nY = m_nGridY - 2;
		
		double t = (dX - m_dXStart - m_dGap * nX) / m_dGap;
		double u = (dY - m_dYStart - m_dGap * nY) / m_dGap;
		
		DPOINT dCoef[4][4];
		memcpy(dCoef, m_Coef[(m_nGridY - 1) * nX + nY].dCoef, sizeof(DPOINT) * 16);

		dXOffset = dYOffset = 0.0;
		for (int i = 3; i >= 0; i--)
		{
			dXOffset = t * dXOffset + ((dCoef[i][3].x * u + dCoef[i][2].x) * u + dCoef[i][1].x) * u + dCoef[i][0].x;
			dYOffset = t * dYOffset + ((dCoef[i][3].y * u + dCoef[i][2].y) * u + dCoef[i][1].y) * u + dCoef[i][0].y;
		}
*/	}
	else
	{
		dXOffset = dYOffset = 0.0;
	}
}

