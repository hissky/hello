// HEocard.h: interface for the HEocard class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_)
#define AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000





#define __KUNSAN_SAMSUNG_LARGE__ 

#define	MAX_LASER_NO					2
#define USE_ALL_HEAD						0x03

#include "HEocard5Pusan1DualbandNew.h"


class CCalibration;

class HEocard
{
public:
	MARKDATA m_MarkingData;
	virtual BOOL Create();
	virtual void Destroy();
	
	virtual BOOL Initialize();
	
	virtual void RunConfig();
	
	DOUBLE_POINT* m_pM1Asc;
	DOUBLE_POINT* m_pM2Asc;
	DOUBLE_POINT* m_pS1Asc;
	DOUBLE_POINT* m_pS2Asc;

	BOOL	m_b4Beam;
	int		m_nSP;
	int		m_nApertureMode;
	int		m_nBurstShotNo;


	HEocard5Pusan1DualbandNew* m_pEocard5[MAX_LASER_NO];
	CCalibration*	m_Calibration[MAX_LASER_NO];

	/*CCalibration*	m_Calibration;
	CCalibration*	m_SlaveCalibration;*/

public:
	BOOL SetLPCDataReadReady( int nHeadNo = USE_ALL_HEAD);
	BOOL CheckShotDutyLimitDummyOff(double dLimit);
	BOOL CheckShotDutyLimitDummyOn();
	BOOL CheckLaserDutyLimit();
	BOOL GetScannerError(int* nWarningNo, int* nAlarmNo, int* nMaxValue, int* nInposMissNo);
	BOOL ResetScannerPosErrorCount();
	BOOL SetScannerErrorLevel(double dWarning_mm, double dAlarm_mm);
	BOOL SetFieldSizeToEocard();
	BOOL SetMasterSlave(BOOL bMaster);
	BOOL SetInpositionCheckINI(BOOL bUseFile);


	TLpc_Buffer* GetLPCResult(int nHeadNo = 0);

	BOOL GetLPCErrorCount(int& nMinError, int& nMaxError);
	CPoint GetDownHoleFirePos(int nIndex, int nHeadNo = 0);

	void UpdateLPCCalibrationFile(CString strPath);
	BOOL ChangeScannerAxis();
	BOOL SetVoltage(double d1st, double d2nd);
	BOOL GetApplyCalibrationFile(int nBeam);
	BOOL SetApplyCalibrationFile(int nBeam, BOOL bOn);
	BOOL UpdateLaserCalibrationFile(CString strPath, int nHeadIndex);
	void GetLaserOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag);
	void LoadLaserCalibrationFile(CString strPath);
	double GetDummyFreeStart();
	BOOL SubCallStart(int nIndex, BOOL bDryrun, int nHeadNo);
	BOOL SubDownloadStop();
	BOOL SubDownloadReset(int nIndex);
	BOOL SetParameterCavityDuty(BOOL bShortLine);
	BOOL EndMarkDummy();
	BOOL StartMarkDummy();

	int IsStannbyShotRun();
	BOOL  IsSameDumyStatus();
	BOOL DrillStandbyShotStart(BOOL bStart, BOOL bUserStop = FALSE);
	BOOL DrillStandbyShotStartHole(BOOL bStart);
	BOOL StandbyParamSet();
	BOOL StandbyParamSetNew(int nMask);
	BOOL DummyParamSet(BOOL bPowervia = FALSE);
	BOOL DummyStopAndDataShotStart(BOOL bDryRun);
	BOOL DummyFieldStart(int nShotNo, BOOL bDryRun);
	BOOL IsFireCntOK(int& nDownCnt, int& nReadCnt);
	BOOL DownloadAOMProfile(int nTool, int nSubTool, CString strPath, int nMask);
	void ReloadDevice();
	BOOL FieldPreStart(int nShotNo = 0, int nHeadNo = USE_ALL_HEAD);
	BOOL FlyingModeEnable(BOOL bEnable);
	BOOL SetQuantaParam(int nFPK, int nCurrent);
	BOOL markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	BOOL GetAperturePos(int nIndex, int& nX, int& nY, int& nAction);
	BOOL DownloadShotDrillScannerParam(int nJumpDelayPlus = 0);
	BOOL DownloadOneAperture(CString str, int nTool);
	BOOL DownloadOneSubTool(int nTool, SUBTOOLDATA subTool,BOOL bSetPowerLevel = TRUE, BOOL bMakeLPCTable = FALSE);
	BOOL ResetSubToolForAllTool();
	void MoveToCenter();
	void DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd = FALSE);
	BOOL jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd = FALSE);
	BOOL LaserOnOff(BOOL bOn, int nHeadNo = USE_ALL_HEAD);
	void GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY);
	void SetDumperPosition(USHORT usDumpMX, USHORT usDumpMY, USHORT usDumpSX, USHORT usDumpSY );
	BOOL DownloadShotData(unsigned short usX,unsigned short usY,BOOL bIsMaster,BOOL bApplyCalibration,int nTCode);
	BOOL IsDSPBusy();
	BOOL ResetScannerStatusErrorCount();
	BOOL IsDrillTimeOutType(int nHeadNo = USE_ALL_HEAD);
	BOOL IsDrillTimeOut(int nHeadNo = USE_ALL_HEAD);
	BOOL IsMotorFault(int nHeadNo = USE_ALL_HEAD);
	BOOL IsScannerCableError(int nHeadNo = USE_ALL_HEAD);
	void MakeInpositionTable();
	//void mark(int x, int y, int xS, int yS, BOOL bWaitEnd = FALSE);
	//void jump(int x, int y, int xS, int yS, BOOL bWaitEnd = FALSE);

	void mark_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd = FALSE);
	void jump_Use_vm(double x, double y, double xS, double yS, BOOL bWaitEnd = FALSE);


	BOOL DownloadDutyAOM(unsigned int nToolNo, unsigned int  nShotIndex, double dDuty, double dAOMDelay = 0, double dAOMDuty = 0);
	BOOL DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int  nBurstShot, unsigned int nTotalShot, BOOL bUseAperture);
	BOOL GetParameter(FParameter *Para, int nHeadNo = USE_ALL_HEAD);
	void CO2LaserMainShutter(BOOL bOn);
	void CO2LaserEnable(BOOL bEnable);
	BOOL LoadCalibrationFile(char* strM1path, char* strS1path = NULL, char* strM2path = NULL, char* strS2path = NULL );
	void GetASCPos(int &nX, int &nY, int nScannerNo);
	void GetApplyCalPos(int& nX, int& nY, int nScannerNo);
	void DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
				   int xS = HALF_LSB, int yS = HALF_LSB, BOOL bS1ApplyCal = FALSE,
				   int x_2 = HALF_LSB, int y_2 = HALF_LSB, BOOL bM2ApplyCal = FALSE,
				   int xS_2 = HALF_LSB, int yS_2 = HALF_LSB, BOOL bS2ApplyCal = FALSE, BOOL bWaitEnd = FALSE);
	BOOL ShotCountReset();
	int ReadHoleCount();
	BOOL DownloadProfileJumpDelay(int nIndex, int nValue);
	BOOL DownloadProfile(int nIndex, int nValue);
	BOOL MoveProfileReset(int nIndex);
	BOOL SetMoveProfileLength(int nIndex, int nLength);
	BOOL StatusOK(int nStatus);
	BOOL FieldStart(BOOL bDryRun, int nHeadNo = USE_ALL_HEAD);
	void ReStartMark();
	void PauseMark();
	void EStop();
	BOOL DownloadTcode(TCODE_INFO *pToolInfo);
	BOOL SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode);
	BOOL ShotDataReset();
	BOOL DownloadShotData4(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		unsigned short usMasterX2,
		unsigned short usMasterY2,
		unsigned short usSlaveX2,
		unsigned short usSlaveY2,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		BOOL bApplyCalibrationMaster2,
		BOOL bApplyCalibrationSlave2,
		int nTCode);
	/*
	BOOL DownloadShotData2(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode, 
		int nShotFilePosForLPCX = INT_MAX,
		int nShotFilePosForLPCY =INT_MAX);
	*/
	BOOL DownloadShotData2_Use_vm(	double dMasterX,
		double dMasterY,
		double dSlaveX,
		double dSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode, 
		int nShotFilePosForLPCX = INT_MAX,
		int nShotFilePosForLPCY =INT_MAX);

	BOOL DownloadShotDataDummy(	unsigned short usMasterX,
		unsigned short usMasterY,
		unsigned short usSlaveX,
		unsigned short usSlaveY,
		BOOL bApplyCalibrationMaster,
		BOOL bApplyCalibrationSlave,
		int nTCode);
	BOOL DownloadAperture(int nToolNo, int nX, int nY, int nAction);
	BOOL ApertureDataReset(int nToolNo);
	BOOL MoveDrillCenterPos();
	//void mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);
	//void jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd = FALSE);

	void mark_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, int nHeadNo = USE_ALL_HEAD, BOOL bWaitEnd = FALSE);
	void jump_Use_vm(double x, double y, double xS, double yS, double x_2, double y_2, double xS_2, double yS_2, int nHeadNo = USE_ALL_HEAD, BOOL bWaitEnd = FALSE);


	BOOL SetMinShotTime(int us);
	BOOL SetMinCycleTime(int us);
	BOOL SetSelfLineDivide(BOOL bOn);
	BOOL SetParameter(FParameter *pParam, int nMask = 0, double dAOMOffset1 = 0, double dAOMOffset2 = 0,int ShotIndex = 0, double dOnOffset1 = 0, double dOnOffset2 = 0, int nHeadNo = USE_ALL_HEAD);
	
	BOOL InitCard();
	USHORT	GetFunction(int nHeadNo = USE_ALL_HEAD);
	BOOL SetFunction(USHORT Value, int nHeadNo = USE_ALL_HEAD);
	BOOL GetStatus(WORD* pStat, int nHeadNo = USE_ALL_HEAD) const;
	BOOL GetAOMStatus(WORD* pStat) const;
	IEODriverDLPortIO* m_pDriver;
	HEocard();
	virtual ~HEocard();

};

#endif // !defined(AFX_HEocard_H__353B33CB_A0C0_4B8F_B700_AF4B73739AAF__INCLUDED_)
