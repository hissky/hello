// PaneAutoRunViewPreworkScanner.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewPreworkScanner.h"
#include "..\model\DProcessINI.h"
#include "..\model\DProject.h"
#include "..\model\DTempINI.h"
#include "..\model\DBeampathINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE// // 
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkScanner

IMPLEMENT_DYNCREATE(CPaneAutoRunViewPreworkScanner, CFormView)

CPaneAutoRunViewPreworkScanner::CPaneAutoRunViewPreworkScanner()
	: CFormView(CPaneAutoRunViewPreworkScanner::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewPreworkScanner)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	memset(m_dResult, 0 , sizeof(m_dResult));

	memset(m_dResultList, 0 , sizeof(m_dResultList));
	memset(m_nScalToolNo, 0 , sizeof(m_nScalToolNo));
	m_nResultCount = 0;
}

CPaneAutoRunViewPreworkScanner::~CPaneAutoRunViewPreworkScanner()
{
}

void CPaneAutoRunViewPreworkScanner::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewPreworkScanner)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_POWER_TOOL, m_listScannerTool);
	DDX_Control(pDX, IDC_LIST_SCAL, m_listScannerResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewPreworkScanner, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewPreworkScanner)
	ON_WM_CTLCOLOR()
	ON_NOTIFY(NM_CLICK, IDC_LIST_POWER_TOOL, OnClickListPowerTool)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkScanner diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewPreworkScanner::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewPreworkScanner::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkScanner message handlers

BOOL CPaneAutoRunViewPreworkScanner::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewPreworkScanner::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitListControl();
}

void CPaneAutoRunViewPreworkScanner::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_SCANNER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_SETTING2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODULATION_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASTER_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASTER_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SLAVE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SLAVE_Y)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASTER_X_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MASTER_Y_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SLAVE_X_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SLAVE_Y_VAL)->SetFont( &m_fntStatic );

}

void CPaneAutoRunViewPreworkScanner::InitListControl()
{

	m_fntList.CreatePointFont(100, "Arial Bold");
	
	m_listScannerTool.SetFont( &m_fntList );
	m_listScannerTool.SetExtendedStyle(m_listScannerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_listScannerTool.DeleteAllItems();
	
	m_listScannerTool.InsertColumn(0, _T(" Tool "), LVCFMT_CENTER, 76);
	m_listScannerTool.InsertColumn(1, _T(" Hole "), LVCFMT_CENTER, 76);
	m_listScannerTool.InsertColumn(3, _T(" Duty "), LVCFMT_CENTER, 81);
	m_listScannerTool.InsertColumn(4, _T(" AOM Duty "), LVCFMT_CENTER, 111);
	m_listScannerTool.InsertColumn(5, _T(" AOM Delay "), LVCFMT_CENTER, 111);

	m_listScannerResult.SetFont( &m_fntList );
	m_listScannerResult.SetExtendedStyle(m_listScannerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_listScannerResult.DeleteAllItems();
	
	m_listScannerResult.InsertColumn(0, _T(" BeamPath "), LVCFMT_CENTER, 100);
	m_listScannerResult.InsertColumn(1, _T(" 1st X "), LVCFMT_CENTER, 80);
	m_listScannerResult.InsertColumn(3, _T(" 1st Y "), LVCFMT_CENTER, 80);
	m_listScannerResult.InsertColumn(4, _T(" 2nd X "), LVCFMT_CENTER, 80);
	m_listScannerResult.InsertColumn(5, _T(" 2nd Y "), LVCFMT_CENTER, 80);
	
}

HBRUSH CPaneAutoRunViewPreworkScanner::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_SCANNER_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_SETTING2)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewPreworkScanner::ChangeDisplay(int nIndex)
{
	SUBTOOLDATA subTool;
	POSITION pos;
	int nBeamPath = 0;
	pos = gDProject.m_pToolCode[nIndex]->m_SubToolData.GetHeadPosition();
	if(pos)
	{
		subTool = gDProject.m_pToolCode[nIndex]->m_SubToolData.GetNext(pos);
		nBeamPath = subTool.nMask;
	}

	CString str;
	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nValidTime);
	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetWindowText(str);
	
	time_t timeNow;
	time(&timeNow);
	
	time_t timeEnd;
	if(gDProject.m_nSeparation == USE_DUAL || USE_1ST)
		timeEnd = (long)gTempINI.m_sTempTime.nAutoScalEndTime[nBeamPath][0];
	else
		timeEnd = (long)gTempINI.m_sTempTime.nAutoScalEndTime[nBeamPath][1];
	
	double dNowTime;
	
	dNowTime = difftime(timeNow, timeEnd); //sec
	
	dNowTime = dNowTime / 60 / 60 ; // hour  
	str.Format(_T("%.1f"), dNowTime);
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetWindowText(str);
	ResetList();

	str.Format(_T("%d"), (int)(m_dResult[nBeamPath][0] * 1000));
	GetDlgItem(IDC_STATIC_MASTER_X_VAL)->SetWindowText(str);
	str.Format(_T("%d"), (int)(m_dResult[nBeamPath][1] * 1000));
	GetDlgItem(IDC_STATIC_MASTER_Y_VAL)->SetWindowText(str);
	
	str.Format(_T("%d"), (int)(m_dResult[nBeamPath][2] * 1000));
	GetDlgItem(IDC_STATIC_SLAVE_X_VAL)->SetWindowText(str);
	str.Format(_T("%d"), (int)(m_dResult[nBeamPath][3] * 1000));
	GetDlgItem(IDC_STATIC_SLAVE_Y_VAL)->SetWindowText(str);

}

void CPaneAutoRunViewPreworkScanner::ResetList()
{
	m_listScannerTool.DeleteAllItems();

	int nCount = 0;
	CString strData;
	int nSubToolNo;
	TCHAR szASC[50][256] = {0,};
	BOOL bSame = FALSE;

	for(int i = 0; i<MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		
		SUBTOOLDATA subTool;
		POSITION pos;
		pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		
		if(pos == NULL)
			continue;
		
		nSubToolNo = 0;

		while(pos)
		{
			subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
			nSubToolNo++;

			for(int k = 0; k < nCount; k++)
			{
				if(strcmp(szASC[k], gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]) == 0 )
				{	
					bSame = TRUE;
					break;
				}
			}

			if(subTool.nTotalShot <= 0)
				break;

			if(bSame)
			{
				bSame = FALSE;
				continue;
			}
			else
			{
				strcpy_s(szASC[nCount], gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			}
			m_listScannerTool.InsertItem(nCount, _T(""));
			
			//Tool No
			strData.Format(_T("%d - %d"), i, nSubToolNo);
			m_listScannerTool.SetItemText(nCount, 0, strData);
			
			//Hole Size
			strData.Format(_T("%.2f"), subTool.dHoleSize);
			m_listScannerTool.SetItemText(nCount, 1, strData);
			
			//Duty
			strData.Format(_T("%.2f"), subTool.dShotDuty[0]);
			m_listScannerTool.SetItemText(nCount, 2, strData);
			
			//AOM Duty
			strData.Format(_T("%.2f"), subTool.dShotAOMDuty[0]);
			m_listScannerTool.SetItemText(nCount, 3, strData);
			
			//AOM Delay
			strData.Format(_T("%.2f"), subTool.dShotAOMDelay[0]);
			m_listScannerTool.SetItemText(nCount, 4, strData);
			
			nCount++;
		}
	}

}

void CPaneAutoRunViewPreworkScanner::InsertScalResult(double* pResult, int nTool) // tool num -> beam path
{
	m_dResult[nTool][0] =pResult[0];
	m_dResult[nTool][1] =pResult[1];
	m_dResult[nTool][2] =pResult[2];
	m_dResult[nTool][3] =pResult[3];

	if(m_nResultCount == RESULT_MAX_NO)
	{
		for(int i = 0; i < RESULT_MAX_NO - 1; i++)
		{
			m_dResultList[i][0] = m_dResultList[i + 1][0];
			m_dResultList[i][1] = m_dResultList[i + 1][1];
			m_dResultList[i][2] = m_dResultList[i + 1][2];
			m_dResultList[i][3] = m_dResultList[i + 1][3];
			m_nScalToolNo[i] = m_nScalToolNo[i + 1];
		}
		m_dResultList[RESULT_MAX_NO - 1][0] = pResult[0];
		m_dResultList[RESULT_MAX_NO - 1][1] = pResult[1];
		m_dResultList[RESULT_MAX_NO - 1][2] = pResult[2];
		m_dResultList[RESULT_MAX_NO - 1][3] = pResult[3];
		m_nScalToolNo[RESULT_MAX_NO - 1] = nTool;
	}
	else
	{
		m_dResultList[m_nResultCount][0] = pResult[0];
		m_dResultList[m_nResultCount][1] = pResult[1];
		m_dResultList[m_nResultCount][2] = pResult[2];
		m_dResultList[m_nResultCount][3] = pResult[3];
		m_nScalToolNo[m_nResultCount] = nTool;
		m_nResultCount++;
	}
	SCalResultAdd();

//	CString str;
/*	
	str.Format(_T("%.3f"), pResult[0]);
	GetDlgItem(IDC_STATIC_MASTER_X_VAL)->SetWindowText(str);
	str.Format(_T("%.3f"), pResult[1]);
	GetDlgItem(IDC_STATIC_MASTER_Y_VAL)->SetWindowText(str);

	str.Format(_T("%.3f"), pResult[2]);
	GetDlgItem(IDC_STATIC_SLAVE_X_VAL)->SetWindowText(str);
	str.Format(_T("%.3f"), pResult[3]);
	GetDlgItem(IDC_STATIC_SLAVE_Y_VAL)->SetWindowText(str);
	*/
}

void CPaneAutoRunViewPreworkScanner::OnClickListPowerTool(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int nSel = m_listScannerTool.GetSelectionMark();
	if (-1 == nSel)
		return;
	
	TCHAR cTemp[5] = {0,};
	m_listScannerTool.GetItemText(nSel, 0 ,cTemp, 2);
	int nTool = atoi(cTemp);
	ChangeDisplay(nTool); // tool num 
	*pResult = 0;
}

void CPaneAutoRunViewPreworkScanner::SCalResultAdd()
{
	m_listScannerResult.DeleteAllItems();

	int nCount = 0;
	CString strData;
	for(int i = 0; i< m_nResultCount; i++)
	{

			m_listScannerResult.InsertItem(nCount, _T(""));
			
			//Tool No
			strData.Format(_T("%d"), m_nScalToolNo[i]);
			m_listScannerResult.SetItemText(nCount, 0, strData);
			
			//1st x
			strData.Format(_T("%.1f"), m_dResultList[i][0] * 1000);
			m_listScannerResult.SetItemText(nCount, 1, strData);
			
			//1st y
			strData.Format(_T("%.1f"), m_dResultList[i][1] * 1000);
			m_listScannerResult.SetItemText(nCount, 2, strData);
			
			//2nd x
			strData.Format(_T("%.1f"), m_dResultList[i][2] * 1000);
			m_listScannerResult.SetItemText(nCount, 3, strData);
			
			//2nd y
			strData.Format(_T("%.1f"), m_dResultList[i][3] * 1000);
			m_listScannerResult.SetItemText(nCount, 4, strData);
			
			nCount++;

	}
}
