#if !defined(AFX_DLGLOGIN_H__03329915_431A_4BD9_BA33_10D9D6D9656B__INCLUDED_)
#define AFX_DLGLOGIN_H__03329915_431A_4BD9_BA33_10D9D6D9656B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLogin.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgLogin dialog

#include "UEasyButtonEx.h"

class CDlgLogin : public CDialog
{
// Construction
public:
	BOOL		m_bLock;
	BOOL		m_bMoveLock;
	BOOL		m_bMove;
	int			m_nX;
	int			m_nY;
	CDlgLogin(CWnd* pParent = NULL);   // standard constructor

	void		InitStaticControl();
	void		InitEditControl();
	void		InitBtnControl();

	BOOL		CheckUserID();
	int			GetUserLevel()	{ return m_nLevel; }
	void		SetMovePos(int nX, int nY);
	void		SetShowOtherePos(BOOL bMove);
// Dialog Data
	//{{AFX_DATA(CDlgLogin)
	enum { IDD = IDD_DLG_LOGIN };
	UEasyButtonEx	m_btnOk;
	UEasyButtonEx	m_btnCancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLogin)
	public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
	int			m_nLevel;

	// Generated message map functions
	//{{AFX_MSG(CDlgLogin)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDestroy();
	virtual void OnCancel();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual INT_PTR DoModal();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLOGIN_H__03329915_431A_4BD9_BA33_10D9D6D9656B__INCLUDED_)
