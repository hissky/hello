// HLaserQuanta.cpp: implementation of the HLaserQuanta class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HLaserQuanta.h"
#include "hdevicefactory.h"
#include "..\UI\DlgPowerSupplyQuanta.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define ADDRESS_IO_OUTPUT 0x309
#define ADDRESS_IO_INPUT  0x308

#define MIN_QUANTA_CURRENT			0
#define MAX_QUANTA_CURRENT			65535
#define DEFAULT_QUANTA_CURRENT		32767

#define MIN_QUANTA_FREQUENCY		0
#define MAX_QUANTA_FREQUENCY		60000
#define DEFAULT_QUANTA_FREQUENCY	30000
//#define MAX_QUANTA_FREQUENCY		100000


#define MIN_QUANTA_FPK				0 //26214 bdwoo check
#define MAX_QUANTA_FPK				65535
#define DEFAULT_QUANTA_FPK			32767

#define MIN_QUANTA_DUTY				0
#define MAX_QUANTA_DUTY				99
#define DEFAULT_QUANTA_DUTY			50

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaserQuanta::HLaserQuanta()
{
	m_lPortA	= 0x320;
	m_lPortB	= 0x321;
	m_lPortC	= 0x322;
	m_lAutoCard	= 0x328;
	
	m_lPortAPC	= 0x301;//hhwang 090210
	m_bErrorIgnore = false;
}

HLaserQuanta::~HLaserQuanta()
{

}

BOOL HLaserQuanta::Initialize()
{
	m_pEOCard = gDeviceFactory.GetEocard();
	//hhwang 090210

	m_bShutterCheck = FALSE;
	m_bPowerCheck = FALSE;
	m_bFlagImergency = FALSE;
	m_bFlag = FALSE;
	m_bRFFlag = FALSE;
	
	m_nLaserStatusOld_PortC =255;
	m_nLaserStatusOld = 255; //defualt value
	
	setPowerStatus(POWER_OFF);
	
	if(m_iPort == 0)
	{
		if (!m_pEOCard->m_pDriver->writeIFCard(0x323, 0x99))
			return FALSE;
	}
	else
	{
		if (!m_pEOCard->m_pDriver->writeIFCard(0x363, 0x99))
			return FALSE;
	}	
	
	setMultiControlAddress(m_iPort);
	
	//end hhwang
	
	//	if (!m_pEOCard->m_pDriver->writeIFCard(0x323, 0x91))
	//		return false;
	
	m_bIsPowerOnStatus = FALSE;
	
	//COMPANY_CODE_HP = default HP
	//COMPANY_CODE_HP2 = special HP
	//���� SVL110����� ��� PC ���� ���� �� Power On ���¸� ��� ���� �ϹǷ�
	//Initial ���� �߿� Power Supply�� ���¸� �ѹ� Ȯ�� �Ͽ� Power On ��Ȳ�� ���� �����ش�.
//	if(OptiContext->m_nCompanyCode == COMPANY_CODE_HP_SPECIAL)
	{
		getStatusfromScanner();
		
		if(isSystemReady())
		{
			setPowerOff(0);
			Sleep(100);
			setPowerOn(0);
		}	
	}
	
	return TRUE;
}


BOOL HLaserQuanta::setCurrent(int nCurrent)
{
	return TRUE;
}

BOOL HLaserQuanta::setQuataParam(int nFPK, int nCurrent)
{
	nCurrent = nCurrent * 65535 / 100;
	if(nCurrent > 65535)
	{
		return FALSE;
	}
	
	if(nCurrent < 0)
	{
		return FALSE;
	}
	
	if(nFPK > 65535)
	{
		return FALSE;
	}
	
	if(nFPK < 0)
	{
		return FALSE;
	}
	
	m_pEOCard->SetQuantaParam(nFPK, nCurrent);
	::Sleep(10);
	return TRUE;
}

bool HLaserQuanta::setPowerOn(int nStep)
{//��� ��Ŀ��� HP3ȣ��� Power On off�� ������ ���� ���� �Ͽ��� 	
	m_bIsPowerOnStatus = TRUE;
	
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	
	m_bRFFlag = TRUE;//hhwang 090210
	
	//2006.11.14 HP ����� �̻����� systemready�� ������� �ʴ� �ű� ��� ����.
	//�̹� ���ϵ� ������ ���� �κ� ����� ���� COMPANY CODE Optionó�� 
	//COMPANY_CODE_HP = default HP
	//COMPANY_CODE_HP2 = special HP
/*	if(OptiContext->m_nCompanyCode == COMPANY_CODE_HP)
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp |= 0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);	
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp &= ~0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);	
		
	}
	else if( OptiContext->m_nCompanyCode == COMPANY_CODE_HP_SPECIAL )
*/	{
		
		//added by bdwoo 2007.01.08 Power off ���� current 50%�� ���� Quanta laser ����ȭ ���� ����.
		setQuataParam(MAX_QUANTA_FPK,DEFAULT_QUANTA_CURRENT);
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp |= 0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);	
		
	}
	
	setPowerStatus(POWER_ON);	
	
	return true;

}

bool HLaserQuanta::setPowerOff(int nStep)
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	//bdwoo power off ���� current �� fpk �ʱ�ȭ 32767,32767 50%, 50%
	//setQuataParam(32767,32767);
	//Sleep(100);
	
	//2006.11.14 HP ����� �̻����� systemready�� ������� �ʴ� �ű� ��� ����.
	//�̹� ���ϵ� ������ ���� �κ� ����� ���� COMPANY CODE Optionó�� 
	//COMPANY_CODE_HP = default HP
	//COMPANY_CODE_HP2 = special HP
/*	if(OptiContext->m_nCompanyCode == COMPANY_CODE_HP)
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp |= 0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);	
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp &= ~0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);	
		
		//added by bdwoo 2007.01.29
		m_bIsPowerOnStatus = FALSE;
		
		
	}
	else if( OptiContext->m_nCompanyCode == COMPANY_CODE_HP_SPECIAL )
*/	{
		//added by bdwoo 2007.01.08 Power off ���� current 50%�� ���� Quanta laser ����ȭ ���� ����.
		setQuataParam(MAX_QUANTA_FPK,DEFAULT_QUANTA_CURRENT);		
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);	//bdwoo test start
		lTemp &= ~0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);												//bdwoo test end
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp |= 0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);
		
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
		lTemp &= ~0x02;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
		Sleep(100);
		
		//added by bdwoo 2007.01.29
		m_bIsPowerOnStatus = FALSE;
		
		
	}
	
	setPowerStatus(POWER_OFF);
	
	return true;
}

bool HLaserQuanta::setShutterOpenProc()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp |= 0x40;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	setShutterOpen(TRUE);
	
	m_bFlag = true;//hhwang 090210
	
	return true;
}

bool HLaserQuanta::setShutterCloseProc()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp &= ~0x40;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	setShutterOpen(false);
	
	return true;
}

int HLaserQuanta::getStatusfromScanner()
{
	bool bErrorFlag = false;
	ULONG nLaserStatus = 0;
	ULONG nValue = 0;

//	IOptionContext* OptiContext = ((CEasyMarkerApp*)AfxGetApp())->getDeviceInfo()->getOptionContext();	
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortA, nLaserStatus);
	HWND hTarget = ::FindWindow(NULL, _T("GV Series(JV10/20)"));//added by hhwang 080630
	
	//hhwang 090210
	CheckPort_C();// check port_c signal

	if(((nLaserStatus & 0x01) == 0x01) && (!((m_nLaserStatusOld & 0x01) == 0x01)))
	{
		m_bShutterCheck = TRUE;
	}
	else if(((nLaserStatus & 0x40) == 0x40) && (!((m_nLaserStatusOld & 0x40) == 0x40)))
	{
		m_bShutterCheck = TRUE;
	}
	else if(((nLaserStatus & 0x20) == 0x20) && (!((m_nLaserStatusOld & 0x20) == 0x20)))
	{
		m_bShutterCheck = TRUE;
	}
	else
	{
		m_bShutterCheck = FALSE;
	}

	if(nLaserStatus & 0x01)
	{
		setVswr(FALSE);
	}
	else
	{
		setVswr(TRUE);
	}
	
	if(nLaserStatus & 0x40)
	{
		setHighPower(FALSE);
	}
	else
	{
		setHighPower(TRUE);
	}
	

	if(nLaserStatus & 0x10)
	{
		setChiller(FALSE);
	}
	else
	{
		setChiller(TRUE);
	}
	//end hhwang 

	if(nLaserStatus & 0x08)
	{
		setSystemReady(FALSE);
	}
	else
	{
		setSystemReady(TRUE);
	}
	
	
	if(nLaserStatus & 0x20)
		setShutterOpen(FALSE);
	else
	{
		setShutterOpen(TRUE);
		setInterLock(TRUE);
	}
	

	if((nLaserStatus & 0x02) == 0x02)
		setPlus15VError(FALSE);
	else
		setPlus15VError(TRUE);
	
	if((nLaserStatus & 0x04) == 0x04)
		setMinus15VError(FALSE);
	else
		setMinus15VError(TRUE);
	
	
//bdwoo check 0717 15V error check
	if(isErrorIgnore())
	{
		setSystemReady(TRUE);
		setShutterOpen(TRUE);
		setMinus15VError(TRUE);
		setPlus15VError(TRUE);
		setNoError(TRUE);

		setVswr(TRUE);
		setHighPower(TRUE);
		setChiller(TRUE);
		setInterLock(TRUE);
	}
	else
	{
		if(isMinus15VError() || isPlus15VError())
		   setNoError(true);
		else
			setNoError(false);
	}
	m_nLaserStatusOld = nLaserStatus;//added by hhwang 080630 ���� ���Ͷ� ���� 

	return nLaserStatus;
}

ULONG HLaserQuanta::getStatusfromAutomode()
{
	return 0;
}

void HLaserQuanta::DoModal()
{
	CDlgPowerSupplyQuanta dlg(this);
	dlg.DoModal();
}

bool HLaserQuanta::actionCommand()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	if(isGuideBeam())
	{
		setGuideBeam(false);
		lTemp &= ~0x08;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	}
	else
	{
		setGuideBeam(true);
		lTemp |=0x08;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	}
	return true;
}

void HLaserQuanta::TestPuls()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp |= 0x02;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	Sleep(100);
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp &= ~0x02;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	Sleep(100);
}

void HLaserQuanta::setMultiControlAddress(int nIndex)
{
	if(nIndex == 0)
	{
		m_lPortA	= 0x320;
		m_lPortB	= 0x321;
		m_lPortC	= 0x322;
		m_lAutoCard	= 0x328;
	}
	else if(nIndex == 1)
	{
		m_lPortA	= 0x360;
		m_lPortB	= 0x361;
		m_lPortC	= 0x362;
		m_lAutoCard	= 0x368;
	}
}

void HLaserQuanta::CheckPort_C()
{
bool bErrorFlag = false;
	ULONG nLaserStatus = 255;
	
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, nLaserStatus);//0x322 check
//	HWND hTarget = ::FindWindow(NULL, _T("Power Supply - SVL110(JV10)"));//added 
	HWND hTarget = ::FindWindow(NULL, 	_T("GV Series(JV10/20)"));//added by hhwang 080630

	if((nLaserStatus & 0x01) == 0x01)
		setTherMistor(FALSE);
	else
		setTherMistor(TRUE);
	if((nLaserStatus & 0x02) == 0x02)
		setWarmUp(FALSE);
	else
		setWarmUp(TRUE);
	
	if((nLaserStatus & 0x04) == 0x04)
		setSystemOk(FALSE);
	else
		setSystemOk(TRUE);
	if((nLaserStatus & 0x08) == 0x08)
		setLdDriveOk(FALSE);
	else
		setLdDriveOk(TRUE);


	if(!((nLaserStatus & 0x10) == 0x10))
		setOverTemp(FALSE);
	else
		setOverTemp(TRUE);
	if(!((nLaserStatus & 0x20) == 0x20))
		setEnableFB(FALSE);
	else
		setEnableFB(TRUE);
	
	if((nLaserStatus & 0x40) == 0x40)
		setRfPwrOn(FALSE);
	else
		setRfPwrOn(TRUE);
	if(!(nLaserStatus & 0x80))// && (m_nLaserStatusOld_PortC & 0x80)
	{
		setRfLP(FALSE);
	}
	else
		setRfLP(TRUE);

	//if(!(nLaserStatus & 0x80) && (m_nLaserStatusOld & 0x80) && (m_bFlag == true))
//	HWND hTarget2 = ::FindWindow(NULL, _T("Power Supply - GV series(JV10/20)"));//added by hhwang 090210
	HWND hTarget2 = ::FindWindow(NULL, 	_T("GV Series(JV10/20)"));//added by hhwang 080630
	
	
	if(((nLaserStatus & 0x01) == 0x01) && (!((m_nLaserStatusOld_PortC & 0x01) == 0x01)) )
	{
		m_bPowerCheck = TRUE;
	}
	else if(((nLaserStatus & 0x02) == 0x02) && (!((m_nLaserStatusOld_PortC & 0x02) == 0x02)) )
	{
		m_bPowerCheck = TRUE;
	}
	else if(((nLaserStatus & 0x04) == 0x04) && (!((m_nLaserStatusOld_PortC & 0x04) == 0x04)) )
	{
		m_bPowerCheck = TRUE;
	}
	else if(((nLaserStatus & 0x08) == 0x08) && (!((m_nLaserStatusOld_PortC & 0x08) == 0x08)) )
	{
		m_bPowerCheck = TRUE;
	}
	else if( (!((nLaserStatus & 0x10) == 0x10)) && ((m_nLaserStatusOld_PortC & 0x10) == 0x10))
	{
		m_bPowerCheck = TRUE;
		m_bFlagImergency = TRUE;
	}
	else if(((nLaserStatus & 0x40) == 0x40) && (!((m_nLaserStatusOld_PortC & 0x40) == 0x40)) )
	{
		m_bPowerCheck = TRUE;
		m_bFlagImergency = TRUE;
	}
	else
		m_bPowerCheck = FALSE;

	if(hTarget2 == NULL)
	{
		if((m_bPowerCheck == TRUE) && (m_bFlagImergency == FALSE) && (m_bRFFlag == TRUE))
		{
//			AfxLog(_T("Interlock PC3_PowerOFF!"));
			setPowerOff(0);
			m_bFlagImergency = false;
			m_bPowerCheck = FALSE;
			m_bRFFlag = FALSE;
//			if(hTarget2 == NULL)
//				DoModal();
		}
		else if((m_bPowerCheck == TRUE) && (m_bFlagImergency == TRUE) && (m_bRFFlag == TRUE))
		{
//			AfxLog(_T("Interlock TEC"));
			setPowerOff(0);
			m_bPowerCheck = FALSE;
			m_bFlagImergency = FALSE;
			m_bRFFlag = FALSE;
			Sleep(1000);
			setChillerOffProc();

//			if(hTarget2 == NULL)
//				DoModal();

		}
		else
		{
		}
	}
	else
	{
		if((m_bPowerCheck == TRUE) && (m_bFlagImergency == TRUE) && (m_bRFFlag == TRUE))
		{
//			AfxLog(_T("Interlock RF OFF"));
			setPowerOff(0);
			m_bPowerCheck = FALSE;
			m_bFlagImergency = FALSE;
			m_bRFFlag = FALSE;
			Sleep(500);
			setChillerOffProc();
		}
	}
	if(isErrorIgnore())
	{
		
		setTherMistor(TRUE);
		setWarmUp(TRUE);
		setSystemOk(TRUE);
		setLdDriveOk(TRUE);

		setOverTemp(TRUE);
		setEnableFB(TRUE);
		setRfPwrOn(TRUE);
		setRfLP(TRUE);
		
	}

	m_nLaserStatusOld_PortC = nLaserStatus;
}

bool HLaserQuanta::setChillerOnProc()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp |= 0x04;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	setChillerOn(true);
	m_bFlagImergency = FALSE;//090210
	
	return true;
}

void HLaserQuanta::setChillerOffProc()
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortB, lTemp);
	lTemp &= ~0x04;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lTemp);
	setChillerOn(false);
	
	return;
}

bool HLaserQuanta::setApcSolidShutterProc(int ets, int open)
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortAPC, lTemp);
	if(ets == 1)
	{
		if(open == 1) //open
			lTemp |= 0xfe;//0x01;
		else
			lTemp &= 0x01;//0xfe;
	}
	else
	{
		if(open == 1) //open
			lTemp |= 0xfd;//0x02;
		else
			lTemp &= 0x02;//0xfd;	
	}
	
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortAPC, lTemp);
	
	return true;
}

void HLaserQuanta::SetPortNo(int Port)
{
	m_iPort = Port;
}

bool HLaserQuanta::setShutterMasterProc(int ets, int open)
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(ADDRESS_IO_OUTPUT, lTemp);
	if(ets == 0)
	{
		if(open == 1) //open
			lTemp |= 0x20;
		else
			lTemp &= 0xdf;
	}
	else
	{
		if(open == 1) //open
			lTemp |= 0x80;
		else
			lTemp &= 0x7f;
	}
	
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(ADDRESS_IO_OUTPUT, lTemp);
	return true;
}

bool HLaserQuanta::setShutterSlaveProc(int ets, int open)
{
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(ADDRESS_IO_OUTPUT, lTemp);
	if(ets == 0)
	{
		if(open == 1) //open
			lTemp |= 0x40;
		else
			lTemp &= 0xbf;
	}
	else
	{
		if(open == 1) //open
			lTemp |= 0x10;
		else
			lTemp &= 0xef;
	}
	
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(ADDRESS_IO_OUTPUT, lTemp);
	return true;
}

void HLaserQuanta::setPowerStatus(QUANTA_POWER_STATUS powerStatus)
{
	m_PowerStatus = powerStatus;
}

void HLaserQuanta::setShutterOpen(bool bOpen)
{
	m_bShutterOpen = bOpen;
}

bool HLaserQuanta::isErrorIgnore()
{
	return m_bErrorIgnore;
}

void HLaserQuanta::setChillerOn(bool value)
{
	m_bChiller = value;
}

QUANTA_POWER_STATUS HLaserQuanta::getPowerStatus()
{
	return m_PowerStatus;
}

BOOL HLaserQuanta::isShutterOpen()
{
	return m_bShutterOpen;
}

void HLaserQuanta::setErrorIgnore(bool bErrorIgnore)
{
	m_bErrorIgnore = bErrorIgnore;
}
