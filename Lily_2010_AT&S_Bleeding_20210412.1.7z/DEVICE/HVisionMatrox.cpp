// HVisionMatrox.cpp: implementation of the HVisionMatrox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HVisionMatrox.h"
#include "..\easydriller.h"
#include "VisionDll_Interface.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"

#define MAX_PATH_LEN		255

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HVisionMatrox::HVisionMatrox()
{
	m_bIsLive = FALSE;
}

HVisionMatrox::~HVisionMatrox()
{
#ifndef __NO_USE_MATROX_VISION__
// vision�ʿ��� ó��
	::CloseVisionDLL(NULL, NULL);
#endif
}

void HVisionMatrox::InitMatroxVision()
{
#ifndef __NO_USE_MATROX_VISION__
	::StartVisionDLL(NULL, NULL);
#endif
}

void HVisionMatrox::ShowVisionDialog(BOOL bShow)
{
#ifndef __NO_USE_MATROX_VISION__
	if(bShow)
		::ViewVisionDlg(NULL, NULL);
	else
		::HideVisionDlg(NULL, NULL);
#endif
}

void HVisionMatrox::SetViewHandle(HWND* pHwnd)
{
	m_hVision = *pHwnd;
}

void HVisionMatrox::OnLive(BOOL bLive)
{
	m_bIsLive = bLive;

#ifndef __NO_USE_MATROX_VISION__
	if(bLive)
		::GrabContinuous((WPARAM)m_hVision, -2, -2);
	else
		::LiveStop();
#endif
}

BOOL HVisionMatrox::OnFindHole(int nIndex, CString& strMsg)
{
	if(m_bIsLive)
		OnLive(FALSE);
	
	char szBuf[100], szTemp[100];
	long res = 0;

	int nStartX, nStartY, nX, nY;
	
	nStartX = (int)(m_dpStart.x * 2);
	if(nStartX < 0) nStartX = 0;
	nStartY = (int)(m_dpStart.y * 2);
	if(nStartY < 0) nStartY = 0;
	nX = (int)((m_dpEnd.x - m_dpStart.x) * 2);
	if(nStartX + nX > 768) nX = 768 - nStartX;
	nY = (int)((m_dpEnd.y - m_dpStart.y) * 2);
	if(nStartY + nY > 576) nY = 576 - nStartY;
	
	ReturnData returnData;
	returnData.CenterX = returnData.CenterY = 0.0;
#ifndef __NO_USE_MATROX_VISION__
	returnData = ::Trigger_Agc((WPARAM)m_hVision, nIndex, -2, -2, nStartX, nStartY, nX, nY);
#endif
	
#ifdef __TEST__
	returnData.CenterX = returnData.CenterY = 0.0;
#endif
	
	sprintf_s(szBuf, 100, _T("X : %.3f, Y : %.3f"), returnData.CenterX, returnData.CenterY);
	m_dPos.x = returnData.CenterX;
	m_dPos.y = returnData.CenterY;
	
	if( returnData.CenterX == -9999 && returnData.CenterY == -9999 )
	{
		CString strVal;
		strVal.LoadString(IDS_TEXT_INSPECTION_FAIL);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;
		
		strMsg.Format(_T("%s"), szTemp);
		
		return FALSE;
	}
	
	strMsg.Format(_T("%s"), szBuf);
	
	return TRUE;
}

BOOL HVisionMatrox::OnFindFiducial(int nIndex, CString& strMsg)
{
	if(m_bIsLive)
		OnLive(FALSE);

	char szBuf[100], szTemp[100];
	long res = 0;

	ReturnData returnData;
	returnData.CenterX = returnData.CenterY = 0.0;
#ifndef __NO_USE_MATROX_VISION__
	returnData = ::Trigger((WPARAM)m_hVision, nIndex, -2, -2);
#endif
	
#ifdef __TEST__
	returnData.CenterX = returnData.CenterY = 0.0;
#endif

	sprintf_s(szBuf, 100, _T("X : %.3f, Y : %.3f"), returnData.CenterX, returnData.CenterY);
	m_dPos.x = returnData.CenterX;
	m_dPos.y = returnData.CenterY;

	if( returnData.CenterX == -9999 && returnData.CenterY == -9999 )
	{
		CString strVal;
		strVal.LoadString(IDS_TEXT_INSPECTION_FAIL);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;

		strMsg.Format(_T("%s"), szTemp);

		return FALSE;
	}

	strMsg.Format(_T("%s"), szBuf);

	return TRUE;
}

BOOL HVisionMatrox::GetRealPos(DPOINT* rPos, int nIndex, BOOL bTrigger, char* pChar)
{
	CString strMsg;
	
	if(gSystemINI.m_sSystemDevice.nNoUseVision)
	{
		if(pChar != NULL)
		{
			strMsg.Format(_T("X : 0.000, Y : 0.000"));
			memcpy(pChar, strMsg, strMsg.GetLength()+1);
		}
		rPos->x = 0.0;
		rPos->y = 0.0;
		return TRUE;
	}
	
	if(bTrigger)
		OnFindFiducial(nIndex, strMsg); // Trigger
	else
		OnFindHole(nIndex, strMsg); // TriggerAgc
	
	if(pChar != NULL)
	{
		memcpy(pChar, strMsg, strMsg.GetLength()+1);
	}
	
	rPos->x = m_dPos.x;
	rPos->y = m_dPos.y;	
	
#ifdef __TEST__
	rPos->x = m_dPos.x = 0.0;
	rPos->y = m_dPos.y = 0.0;
#endif
	
	if (m_dPos.y == 999 || m_dPos.x == 999)
		return FALSE;
	
	return TRUE;
}

void HVisionMatrox::LoadJobFile(CString strPath)
{
	char szPath[MAX_PATH_LEN];
	lstrcpy(szPath, (LPCTSTR)strPath);

#ifndef __NO_USE_MATROX_VISION__
	::LoadJobFile(szPath);
#endif
}

void HVisionMatrox::OnCamChange(int nCam)
{
#ifndef __NO_USE_MATROX_VISION__
	::ChangeChannel((WPARAM)nCam, NULL);
#endif
}

void HVisionMatrox::SetInspectArea(DPOINT dpStart, DPOINT dpEnd)
{
	m_dpStart = dpStart;
	m_dpEnd = dpEnd;
}

void HVisionMatrox::SetLevel(BOOL bSuperUser)
{
#ifndef __NO_USE_MATROX_VISION__
	::SuperUser(bSuperUser);
#endif
}
