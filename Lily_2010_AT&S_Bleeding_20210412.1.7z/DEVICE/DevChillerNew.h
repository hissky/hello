// DevChillerNew.h: interface for the CDevLaserPower class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVCHILLERNEW_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
#define AFX_DEVCHILLERNEW_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AsyncComm.h"

class CDevChillerNew : public CAsyncComm  
{
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;

public:
	double GetChillerTemp(int nChannel, double &dTemperature, double &dFlowRate, double &dPressure);
	BOOL IsConnect();
	int ConvertASCIItoNum(char ascii);
	double ParsePack(char* szResult, int nChannel);
	char* MakePack(char* szCmd);
	void FireReceived(void);
	virtual void ProcessMonitor(void);
	char* QueryCommand(char* szCmd);
	virtual void Destroy(void);
	virtual BOOL Create(void);
	CDevChillerNew();
	virtual	~CDevChillerNew();

    CAssEvent FReceiveEvent;

	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);
	char m_szCmd[30];
	int m_nPortNo;
	int m_nBaudRate;
	int m_nParity;
	int m_nDataBits;
	int m_nStopBits;
	int m_nFlowControl;

	int m_nTemperature;
	int m_nFlowRate;
	int m_nPressure;
	int m_nStatus;
	int m_nAlarm;
	int m_nRun;
	int m_nRemote;

	int m_nAlarm2;
	int m_nRun2;
	int m_nRemote2;

	int m_nSetRun;
};

#endif // !defined(AFX_DEVCHILLERNEW_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
