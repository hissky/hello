// DAreaInfo.h: interface for the DAreaInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAREAINFO_H__F090761D_B808_4A8E_B1EA_AFB4AE82CAB0__INCLUDED_)
#define AFX_DAREAINFO_H__F090761D_B808_4A8E_B1EA_AFB4AE82CAB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Glyph.h"
#include "GlyphExcellon.h"
#include "HoleConvertData.h"

#define MAX_TOOL_NO			28

class DProject;
class DAreaInfo  
{
public:
	void FieldCopy(DAreaInfo* pAreaInfo, GlyphExcellon *pExcellonm, double dX, double dY, int nCount );
	BOOL LoadFile10000Pusan32(CArchiveMark &ar, int nVersion, GlyphExcellon* pExcellon);
	BOOL IsThereSameBlockData(int nFidBlock,int nSkipBlock = -2);
	BOOL IsInData2(LPLINEDATA pOriginLine, int nMinX, int nMaxX, int nMinY, int nMaxY, int nToolType, int nRealTooNo, int nUnitNo, int &nXLineBigger, int &nYLineBigger);
	int GetUnitForFidCal(int nFidMethod, CToolCodeList** pToolCodes);

	CPoint DisplayBlockDots(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, BlockList* pBlocks,
		BOOL bDrawPath, CPen* pOldPen, CPen* pCurPen, int nPenSize, int nSkipNo);
	BOOL IsDrawData(int nMode, int nX, int nY, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName);
	BOOL IsDrawData(int nMode, CPoint ptStart, CPoint ptEnd, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName);


	BOOL IsThereSameUnit(LPDUNIT pUnit);
	void DrawDoingFire(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, int nMode);
	void GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY);
	void GetXY_Use_vm(int nMode, double dX, double dY, double &dTransX, double &dTransY);
	void ChangeDataWithAxis(int nMode);
	void GetXY(int nMode, int nX, int nY, int& nTransX, int& nTransY, double dStartX, double dStartY, double dScale);
	BOOL IsNewData(int nOrigin, GlyphExcellon* pExcellon, int& nIndex);
	void ClearData();
	void ClearBlockData();

	CPoint DisplayPathInBlock(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, BlockList* pBlocks);
	void CopyArea(DAreaInfo* pOriArea, DUnit *pUnit);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion, GlyphExcellon* pExcellon);
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL IsThereSkivingData(int nIndex, BOOL bSelectMode);
	LPFIREHOLE GetFirstHole(BOOL bSelectOnly, BOOL bAuto);
	int GetFirstToolNo(BOOL bSelectOnly, BOOL bAuto);
	BOOL IsThereSelectData();
	BOOL IsThereData();
	BOOL IsEmpty();
	void DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawPath, BOOL bShowIndex, BOOL bShowHoleIndex, int &nHoleCount, BlockList* pBlocks);
	void Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawPath, BOOL bShowIndex, int nFidPane, BOOL bShowHoleIndex, int &nHoleCount, BlockList* pBlocks);
	BOOL IsInData(LPLINEDATA pOriginLine, int nMinX, int nMaxX, int nMinY, int nMaxY, int nToolType, int nRealTooNo, int nUnitNo);
	BOOL IsInData(LPHOLEDATA pOrigin, int nRealTooNo, int nUnitNo);
	BOOL IsInData(LPHOLEDATA pOrigin, int nMinX, int nMaxX, int nMinY, int nMaxY, int nRealTooNo, int nUnitNo);// 20161111
	BOOL IsInData(CPoint pt, int nFidIndex);
	FireHoleList m_FireHoles[MAX_TOOL_NO];
	FireLineList m_FireLines[MAX_TOOL_NO];
	int m_nMinX;
	int m_nMaxX;
	int m_nMinY;
	int m_nMaxY;
	double m_dCenterX;
	double m_dCenterY;
	double m_dFidChangeCenterX;
	double m_dFidChangeCenterY;
	double m_dTableX;
	double m_dTableY;
	int m_nRefNo;
	int m_nFireStatus;

	int	m_nSortIndex;
	int m_nFieldMinX;
	int m_nFieldMinY;
	int m_nFieldMaxX;
	int m_nFieldMaxY;
	int	m_nFidBlock;

//	BYTE* m_pcField;

	BOOL IsFieldNumber(CPoint pt, int nTolerence, int nMode, double dDrawStartX, double dDrawStartY, double dScale);
	void SetSelectData(BOOL bSelect);
	void SetSelectFidBlock(int nFidBlock, BOOL bSelect);

	BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView, GlyphExcellon* pGlyph);
	BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView, GlyphExcellon* pGlyph);
	void UnSelectAll();

	// Area�� ����Offset
	double m_dTableOffsetX;
	double m_dTableOffsetY;
	
	double m_d1stAngle;
	double m_d2ndAngle;
	
	void SetTableOffset(double dX, double dY);
	void GetTableOffset(double& dX, double& dY);
	
	// ����� fiducial index list
	FidIndexList m_FidIndex; // unit ������ ���� �ٲ�鼭 ������. 20090708 bhLee
	
	BOOL AddFiducialIndex(int nFidIndex);
	BOOL DeleteFiducialIndex(int nFidIndex);
	void ClearFiducialIndex();
	int GetSelectedHoleCount(int nTool);
	
	BOOL m_bCheckIndex;
	UnitList m_Units;
	// 20130419 fiducial ������, block �� ���� �����ϱ� ����
	COLORREF m_cColorFid[MAX_FID_BLOCK];

	DAreaInfo();
	virtual ~DAreaInfo();

};

#endif // !defined(AFX_DAREAINFO_H__F090761D_B808_4A8E_B1EA_AFB4AE82CAB0__INCLUDED_)
