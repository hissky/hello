// DProcessINI.cpp: implementation of the DProcessINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DProcessINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DProcessINI gProcessINI;
SLOTINFO		gLotInfo;

DProcessINI::DProcessINI()
{
//	memset( &m_sProcessLaserScanner, 0, sizeof(m_sProcessLaserScanner) );
	memset( &m_sProcessAutoSetting, 0, sizeof(m_sProcessAutoSetting) );
	memset( &m_sProcessOption, 0, sizeof(m_sProcessOption) );
	memset( &m_sProcessCal, 0, sizeof(m_sProcessCal) );
	memset( &m_sProcessSystem, 0, sizeof(m_sProcessSystem) );
	memset( &m_sProcessFidFind, 0, sizeof(m_sProcessFidFind) );
	memset( &gLotInfo, 0, sizeof(gLotInfo));

	m_sProcessPowerMeasure.nPulseNum = 20;
	//m_sProcessPowerMeasure.nPowerStep = 3;
	m_sProcessPowerMeasure.nConpensationLimitCount = 20;
	m_sProcessPowerMeasure.nCompensationDutyLimitPercent = 18;
	m_sProcessPowerMeasure.dCompensationDutyPerWatt = 5;

	m_sProcessPowerMeasure.dPowerStep = 0.5;

	m_sProcessPowerMeasure.nCompensationPowerSpecPercent = 10;
	m_sProcessPowerMeasure.dCompensationWaitLimit = 8;

	m_sProcessCal.nScalAbsTime = 8;
	m_sProcessCal.nScalRelTime = 8;
	m_sProcessCal.nScalMethod = 2;
	m_sProcessCal.nPowerAbsTime = 8;
	m_sProcessCal.nPowerRelTime = 8;
	m_sProcessCal.nPowerMethod = 2;
	m_sProcessCal.bUsePNLCountUnit = 0;
	m_sProcessCal.nAutoCalibrationFieldCount = 2;
	m_sProcessCal.nVisionCalibrationFieldCount = 3;
	m_sProcessCal.dCalibrationHoleGap = 0.62;
	m_sProcessCal.nVisionCalibrationXCount = 40;
	m_sProcessCal.nVisionCalibrationYCount = 10;
	m_sProcessCal.nAutoCalibrationXCount = 10;
	m_sProcessCal.nAutoCalibrationYCount = 10;
	m_sProcessCal.nAutoRunPreheatJumpDelay = 1000;
//	m_sProcessFidFind.bUseRemoveFid = FALSE;
//	m_sProcessFidFind.nRemoveFid = -1;
	m_sProcessFidFind.dFidAngleLimit = 0.5;
	m_sProcessFidFind.dRefPosX = 600.;
	m_sProcessFidFind.dRefPosY = 700.;
	m_sProcessFidFind.dRefPosX2 = 600.;
	m_sProcessFidFind.dRefPosY2 = 700.;
	m_sProcessFidFind.dRefPosX3 = 600.;
	m_sProcessFidFind.dRefPosY3 = 700.;
	m_sProcessFidFind.dNearPosX = 600.;
	m_sProcessFidFind.dNearPosY = 800.;
	m_sProcessFidFind.dNearPosX2 = 300.;
	m_sProcessFidFind.dNearPosY2 = 800.;
	m_sProcessFidFind.bMultiFidAscentOrder = FALSE;
	m_sProcessFidFind.bAutoFidRecheck = TRUE;
	m_sProcessFidFind.dRecheckTolerance = 0.01;
	m_sProcessFidFind.nHolePreLimit = 10;
	m_sProcessFidFind.nHolePostLimit = 10;
	m_sProcessFidFind.bUseProportionCompensation = FALSE;
	m_sProcessFidFind.dScaleMinusLimit = 99.;
	m_sProcessFidFind.dScalePlusLimit = 101.;

	m_sProcessFidFind.dDiagonalScaleMinusLimit = 99.8;
	m_sProcessFidFind.dDiagonalScalePlusLimit = 100.2;

	m_sProcessFidFind.dPCBLenTolOperatorRunLimit = 0.1; // 20130404 bhlee 
	m_sProcessFidFind.bOperatorCanRunForScaleOver = FALSE;

	m_sProcessFidFind.dAcceptScore = 0.9;
	m_sProcessFidFind.dAcceptEdgeScore = 0.6;
	m_sProcessFidFind.dRotateHoleAcceptScore = 0.6;
	m_sProcessFidFind.dResultScore = 0.6;
	m_sProcessFidFind.dExposure = 0.02;

	m_sProcessFidFind.dFidFindExposure = 0.02;

	m_sProcessSystem.bNoUseFiducialFind = FALSE;

	m_sProcessSystem.bNoUseRollUpDown = 0;
	m_sProcessSystem.bNoUsePaper = 0;
	m_sProcessSystem.bNoUseApplyScal = 0;

	m_sProcessSystem.bUseFindSecondFid = TRUE;
	m_sProcessSystem.bUseSaveFidImage = TRUE;
	m_sProcessSystem.nNoSortHole = FALSE;
	m_sProcessSystem.bNoSortLine = TRUE;
	m_sProcessSystem.nHoleSortPitch = 5;
	m_sProcessSystem.nHoleDistancePitch = -1; // �⺻������ ��� off

	m_sProcessSystem.bRecipeHoleSort = TRUE;

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(i == 1)
		{
			m_sProcessSystem.bToolHoleSort[i] = TRUE; 
		}
		else
		{
			m_sProcessSystem.bToolHoleSort[i] = FALSE; 
		}
	}
	
	m_sProcessSystem.bEveryPanelThicknessMeasurement = 1;
	m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck = TRUE;
	m_sProcessSystem.bUseScheduling = FALSE;
	m_sProcessSystem.bUseAIMode = FALSE;
	m_sProcessSystem.bCheckHoleCount = FALSE;
	m_sProcessSystem.bLaserErrorCheck = FALSE;
	m_sProcessSystem.bUseGetHighCamOffset = FALSE;
	m_sProcessSystem.bUse4WayScalMain = FALSE;
    	m_sProcessSystem.bUsePatternDevide = FALSE;
	m_sProcessSystem.bUseApplyScalToEocard = FALSE;
	m_sProcessSystem.bUseShotScale = FALSE;
    m_sProcessSystem.bUseAutoMonitoring = FALSE;
	m_sProcessSystem.bUseSheetSuction = FALSE;

	m_sProcessSystem.bShowAllFidImage = FALSE;
	m_sProcessSystem.bFailFidCountinue = FALSE;
	m_sProcessSystem.bUseOpenTool = FALSE;
	m_sProcessSystem.dSortAreaYRatio = 1;
	m_sProcessSystem.bNoUseNGBox = TRUE;
	m_sProcessSystem.bNoUsePrework = TRUE;
	m_sProcessSystem.bUseNewParameter3 = FALSE;
	m_sProcessSystem.bUseNewBarcodeContents = FALSE;

	m_sProcessSystem.bUseAllToolScal = FALSE;
	m_sProcessSystem.bUseAllToolPower = FALSE;

	m_sProcessSystem.bUseOriginalInspectionMode = FALSE;
	m_sProcessSystem.bUse1stPanelStop = FALSE;
	m_sProcessSystem.bNoUseMelsecInterface = FALSE;
	m_sProcessSystem.bPassMode = FALSE;
	m_sProcessSystem.bCheckVisionSizeError = FALSE;




	m_sProcessSystem.bUseTurnPanel = TRUE;

	m_sProcessSystem.bDryRunNoPCB = FALSE;
	m_sProcessSystem.bLineToShotFireMode = FALSE; // 20131028

	m_sProcessAutoSetting.dAutoCalMinTablePosX = 0;
	m_sProcessAutoSetting.dAutoCalMinTablePosY = 0;
	m_sProcessAutoSetting.dAutoCalMaxTablePosX = 400;
	m_sProcessAutoSetting.dAutoCalMaxTablePosY = 200;
	m_sProcessAutoSetting.dIdleShotTablePosX = 600;
	m_sProcessAutoSetting.dIdleShotTablePosY = 100;
	m_sProcessAutoSetting.nIdleShotRepeatCount = 20;

	m_sProcessAutoSetting.nOpticMX = 0;
	m_sProcessAutoSetting.nOpticSX = 0;
	m_sProcessAutoSetting.nOpticMY = 0;
	m_sProcessAutoSetting.nOpticSY = 0;

	m_sProcessScannerCal.dMasterCalTablePosX = 0;
	m_sProcessScannerCal.dSlaveCalTablePosX = 0;
	m_sProcessScannerCal.bDefaultLow = TRUE;

	m_sProcessFidFind.nFidImgSaveData = 14;
	m_sProcessFidFind.nLogSaveData = 30;

	m_sProcessOption.bCheckLPCError = FALSE;

	m_sProcessOption.nLPCLogsaveDate = 21;
	m_sProcessOption.nLPCErrorCount = 5;
	m_sProcessOption.nChillerErrCount = 0;
	m_sProcessOption.dDutyLimit = 9;
	m_sProcessOption.bLPCLogDetail = TRUE;

		m_sProcessOption.bMarkingDualMode = TRUE;
		m_sProcessOption.bNoUseTopHat = FALSE;

		m_sProcessOption.bSlaveMeasureStart = FALSE;
		m_sProcessOption.bFullScheduling = FALSE;
		
	// Temperature compensation options
	m_sProcessOption.bWaitTemperDownForAGC = FALSE;
	m_sProcessOption.bTemperCompensationMode = FALSE;
	m_sProcessOption.nTemperMeasureMode = FALSE;
	m_sProcessOption.bTemperVerifyMode = FALSE;
	m_sProcessOption.bTemperDetailLog = FALSE;

	m_sProcessOption.nTemperCompenGridNo = 2; // 2 or 3
	m_sProcessOption.dTemperDeltaT = 0.1;
	m_sProcessOption.dTemperVerifyContrast = 0.5;
	m_sProcessOption.dTemperVerifyBrightness = 0.6;
	m_sProcessOption.nTemperCompenTimeoutMin = 10; // ��
	m_sProcessOption.nTemperCompenRepeatNo = 5;
	m_sProcessOption.nOCRMoveOffset = 20;//mm

	m_sProcessOption.nTempRepeatCompenLotCount = 0; // ����
	m_sProcessOption.nTempCompenVerifyLotCount = 100000; // ����
	m_sProcessOption.nTemperCompenEveryPnl = 0; // ����
	m_sProcessOption.nTemperCompenFireCountForVisionCompen = 0; // 0 �̸� ����
	m_sProcessOption.nTemperCompenFireCountForVisionCompen2 = 0; // 0 �̸� ����
	m_sProcessOption.nTemperCompenFireCountForVisionCompen3 = 0; // 0 �̸� ����
	m_sProcessOption.nTemperCompenFireCountForVisionCompen4 = 0; // 0 �̸� ����
	m_sProcessOption.nTemperCompenFireCountForVisionCompen5 = 0; // 0 �̸� ����

	m_sProcessOption.bTemper2DLinearMode = FALSE;
	m_sProcessOption.dTemperMinTLimit = 17.;
	m_sProcessOption.dTemperMaxTLimit = 30.;
	m_sProcessOption.dTemperEndT = 2.4;
	m_sProcessOption.dTemperTransT = 0.3;
	m_sProcessOption.dTemperDetaTLimit = 0.2;
	m_sProcessOption.dTemperMinusDetaTLimit = 0.2;
	m_sProcessOption.dTemperTWaitScal = 300; // sec
	m_sProcessOption.dTemperDifferTLimit = 0.1;
	m_sProcessOption.nTableMoveWaitTimeMS = 300;
	m_sProcessOption.nSBTemperLongWaitTime= 300;

	m_sProcessOption.nTCMasterCH1 = 0;
	m_sProcessOption.nTCMasterCH2= 1;
	m_sProcessOption.nTCSlaveCH1 = 2;
	m_sProcessOption.nTCSlaveCH2= 3;
	m_sProcessOption.nSBMasterCH1 = 4;
	m_sProcessOption.nSBMasterCH2= 5;
	m_sProcessOption.nSBSlaveCH1 = 6;
	m_sProcessOption.nSBSlaveCH2= 7;

	m_sProcessOption.nTemperDutyStepNo = 0;
	m_sProcessOption.nTemperStartDuty= 15;
	m_sProcessOption.nTemperStepDuty = 5; 

	m_sProcessOption.nTemperStartPower = 8;
	m_sProcessOption.nTemperEndPower = 10;
	m_sProcessOption.nOPCTimeOut = 10; 
	m_sProcessOption.nTabelInposCount = 2; 

	m_sProcessCal.nScalCountTime2 = 10;
	m_sProcessCal.nScalCountTimeForSkive = 10;
	m_sProcessCal.nVisionCalMode = 0;
	m_sProcessOption.nLogCopyTime = 8; 

	m_sProcessOption.nOpcLogSaveData = 90; 
	m_sProcessOption.nLpcLogSaveData = 3; 
	m_sProcessCal.nPostDoPreworkMinimumCount = 20;

	m_sProcessOption.dCCLSize = 2.5;
	m_sProcessOption.dPPGSize = 1.8;
	m_sProcessOption.dVerifySize = 1.8;

	for(int i = 0; i <MAX_LOTID_CNT; i++)
	{
 		gLotInfo.bUseOpenTool[i] = TRUE;
	}
	m_sProcessSystem.bUseSpeedUp = FALSE;
	m_sProcessSystem.bUseAllFidFind = FALSE;
	m_sProcessSystem.bUseDetailLog = FALSE;
	m_sProcessOption.dPCBHeihtAutoTol = 50;
}

DProcessINI::~DProcessINI()
{

}
