// DLineSort.h: interface for the DLineSort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLINESORT_H__0C3ABBD5_AADB_430B_95C9_2D6749FC6F3F__INCLUDED_)
#define AFX_DLINESORT_H__0C3ABBD5_AADB_430B_95C9_2D6749FC6F3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "glyph.h"
#include "DBlock.h"

struct ORIGINLINE_SORT_DATA {
	LPLINEDATA	pLine;
	BOOL		bUsed;
};
typedef CTypedPtrList <CPtrList, ORIGINLINE_SORT_DATA*> OriginLineSortList;

class DOriginLineSort  
{
public:
	void AddDataTail(DOriginLineSort* pLineData, BOOL bReverse);
	void AddDataHead(DOriginLineSort* pLineData, BOOL bReverse);
	void ChangeStartEnd();
	double GetDistance();
	CPoint GetTailPoint();
	CPoint GetHeadPoint();
	void AddHeadLineData(ORIGINLINE_SORT_DATA* pLineData);
	int		m_nMinX;
	int		m_nMinY;
	int		m_nMaxX;
	int		m_nMaxY;
	BOOL	m_bUsed;
	
	void AddLineData(ORIGINLINE_SORT_DATA* pLineData);
	DOriginLineSort();
	virtual ~DOriginLineSort();

	OriginLineSortList m_LineData;

};

#endif // !defined(AFX_DLINESORT_H__0C3ABBD5_AADB_430B_95C9_2D6749FC6F3F__INCLUDED_)
