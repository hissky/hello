#if !defined(AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_)
#define AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputTemp.h : header file
//
#include "ui/ColorComboEx.h"
#include "coloredit.h"
#include "ueasybuttonex.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp dialog

class CDlgInputTemp : public CDialog
{
	// Construction
public:
	enum { IDD = IDD_DLG_INPUT_TEMP };
	CDlgInputTemp(CWnd* pParent = NULL);   // standard constructor
	
public:
	CFont	m_fntStatic;
	CFont	m_fntEdit;
	CFont	m_fntBtn;

	CColorComboEx m_cmbManageCustom;
	CStringArray  m_strManageCustom;
	BOOL m_bRepairMarkingFlag;

	CColorEdit m_editBarcodeContents;
	CColorEdit m_editPnlNo;
	CColorEdit m_editArrayNo;
	CColorEdit m_editLotID;
	CColorEdit m_editTopBottom;
	CColorEdit m_editProductLot;
	CColorEdit m_editProductPN;
	CColorEdit m_editStatic;
	CColorEdit m_editCustomerNo;
	CColorEdit m_editSpare;
	UEasyButtonEx m_btnGetDataFromUI;
	UEasyButtonEx m_btnGenTempData;
	UEasyButtonEx m_btnClear;
	UEasyButtonEx m_btnApplyAndClose;
	UEasyButtonEx m_btnClose;

	CString m_strLotID;
	BOOL m_bCompSold;
	BOOL	m_bCheckModifyArray;
	void SetValue(CString strDate, int nArray);

public:
	virtual BOOL Create(CWnd* pParentWnd);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	afx_msg void OnBtnTemp();
	afx_msg void OnOk();
	afx_msg void OnCancel();
	afx_msg void OnBtnGetDataFromUi();
	afx_msg void OnBtnSetClear();
	afx_msg void OnCheckModifyArray();
	DECLARE_MESSAGE_MAP()

public:
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();

	CString GetDlgData(int m_nIndex); 
	BOOL IsValidDataFormat();
	void SetRepairMarkingFlag(BOOL m_bFlag);
	void ShowArray(BOOL m_bShow);
	

};


#endif // !defined(AFX_DLGINPUTTEMP_H__4957EB51_4195_4570_BF8E_CCD7F94B1463__INCLUDED_)
