#if !defined(AFX_PANEUSERACCOUNTSUB_H__5B199F72_BE41_461D_B09A_FBF9D3DB3887__INCLUDED_)
#define AFX_PANEUSERACCOUNTSUB_H__5B199F72_BE41_461D_B09A_FBF9D3DB3887__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneUserAccountSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccountSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneUserAccountSub : public CFormView
{
protected:
	CPaneUserAccountSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneUserAccountSub)

// Form Data
public:
	//{{AFX_DATA(CPaneUserAccountSub)
	enum { IDD = IDD_DLG_USER_ACCOUNT_SUB };
	UEasyButtonEx	m_btnBack;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneUserAccountSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneUserAccountSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;

	// Generated message map functions
	//{{AFX_MSG(CPaneUserAccountSub)
	afx_msg void OnButtonBack();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEUSERACCOUNTSUB_H__5B199F72_BE41_461D_B09A_FBF9D3DB3887__INCLUDED_)
