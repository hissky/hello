#if !defined(AFX_PANEAUTORUNVIEWPREWORKPOWER_H__F665BFD6_283D_45E4_8720_39F26649B403__INCLUDED_)
#define AFX_PANEAUTORUNVIEWPREWORKPOWER_H__F665BFD6_283D_45E4_8720_39F26649B403__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewPreworkPower.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkPower form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
class CPaneAutoRunViewPreworkPower : public CFormView
{
protected:
	CPaneAutoRunViewPreworkPower();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewPreworkPower)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewPreworkPower)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_PREWORK_POWER_MEASURE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;
	CFont m_fntList;
	CListCtrl	m_listPowerTool;
	CListBox	m_lboxResult;
	int	m_nMeasureCount;
	BOOL m_bOldPanel;
	double m_dAvgPower[MAX_TOOL_NO][2];//master&slave
	BOOL m_bDoPower[MAX_TOOL_NO][2];//master&slave
// Operations
public:
	void RemoveList();
	void InsertAvgResult(int nToolNo, double dResult);
	void InsertPowerResult(double dResult, BOOL b1st, int nToolNo);
	void ResetList();
	void ChangeDisplay(int nIndex = 1);
	void InitListControl();
	void InitStatic();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewPreworkPower)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewPreworkPower();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewPreworkPower)
	afx_msg void OnClickListPowerTool(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWPREWORKPOWER_H__F665BFD6_283D_45E4_8720_39F26649B403__INCLUDED_)
