#if !defined(AFX_PANESYSSETUPDIR_H__CD86299E_58D9_49B0_BCB2_4028A24AE882__INCLUDED_)
#define AFX_PANESYSSETUPDIR_H__CD86299E_58D9_49B0_BCB2_4028A24AE882__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupDir.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupDir form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneSysSetupDir : public CFormView
{
protected:
	CPaneSysSetupDir();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupDir)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupDir)
	enum { IDD = IDD_DLG_SYS_SETUP_DIR };
	CColorEdit	m_edtScaleLog;
	CColorEdit	m_edtNetWork;
	UEasyButtonEx	m_btnScaleLog;
	UEasyButtonEx	m_btnNetwork;
	CColorEdit	m_edtAperture;
	UEasyButtonEx	m_btnAperture;
	CColorEdit	m_edtSystem;
	UEasyButtonEx	m_btnSystem;
	CColorEdit	m_edt1stCalFilePath;
	CColorEdit	m_edtRoot;
	CColorEdit	m_edtProject;
	CColorEdit	m_edtProcesslog;
	CColorEdit	m_edtParam;
	CColorEdit	m_edtImage;
	CColorEdit	m_edtErrorlog;
	CColorEdit	m_edtData;
	CColorEdit	m_edtCorrect;
	CColorEdit	m_edtConverted;
	CColorEdit	m_edtBackup;
	CColorEdit	m_edtScannerProfilePath;
	CColorEdit	m_edtBarcodeFile;
	CColorEdit	m_edtEES;
	UEasyButtonEx	m_btnRoot;
	UEasyButtonEx	m_btnProject;
	UEasyButtonEx	m_btnProcesslog;
	UEasyButtonEx	m_btnParam;
	UEasyButtonEx	m_btnImage;
	UEasyButtonEx	m_btnErrorlog;
	UEasyButtonEx	m_btnData;
	UEasyButtonEx	m_btnCorrect;
	UEasyButtonEx	m_btnConverted;
	UEasyButtonEx	m_btnBackup;
	UEasyButtonEx	m_btn1stCalFile;
	UEasyButtonEx	m_btnScannerProfileFile;
	UEasyButtonEx	m_btnBarcodeFile;
	UEasyButtonEx	m_btnEasyBackup;
	UEasyButtonEx	m_btnEES;
	//}}AFX_DATA

// Attributes
public:
	CString		m_strRoot;
	CString		m_strParam;
	CString		m_strCorrect;
	CString		m_strProject;
	CString		m_strData;
	CString		m_strConverted;
	CString		m_strImage;
	CString		m_strErrorlog;
	CString		m_strProcesslog;
	CString		m_strBackup;
	CString		m_strSystem;
	CString		m_strAperture;
	CString		m_strScaleLog;
	CString		m_str1stCalFilePath;
	CString		m_str1stSlaveCalFilePath;
	CString		m_str2ndCalFilePath;
	CString		m_str2ndSlaveCalFilePath;
	CString		m_strScannerProfilePath;
	CString		m_strBarcodeFilePath;
	CString		m_strNetwork;
	CString		m_strImportantLog;

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;

// Operations
public:
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();

	void SetDirData();
	void GetDirData();

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupDir)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupDir();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupDir)
	afx_msg void OnButtonRoot();
	afx_msg void OnButtonParam();
	afx_msg void OnButtonCorrect();
	afx_msg void OnButtonProject();
	afx_msg void OnButtonData();
	afx_msg void OnButtonConverted();
	afx_msg void OnButtonImage();
	afx_msg void OnButtonErrorLog();
	afx_msg void OnButtonProcessLog();
	afx_msg void OnButtonBackup();
	afx_msg void OnButton1stCalFile();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonSystem();
	afx_msg void OnButtonAperture();
	afx_msg void OnButtonScannerProfile();
	afx_msg void OnButtonBarcodeFile();
	afx_msg void OnButtonEasyBackup();
	afx_msg void OnButtonScalelog();
	afx_msg void OnButtonNetwork();
	afx_msg void OnButtonEES();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPDIR_H__CD86299E_58D9_49B0_BCB2_4028A24AE882__INCLUDED_)
