// PaneManualControlLaser.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlLaser.h"
#include "DlgLaserWarmUp.h"
#include "..\device\hdevicefactory.h"
#include "..\Device\HEoCard.h"
#include "..\Device\HLaser.h"
#include "..\model\DProcessINI.h"
#include "..\model\ProcessINIFile.h"
#include "..\model\DSystemINI.h"
#include "..\model\SystemINIFile.h"
#include "..\easydrillerdlg.h"
#include "..\alarmmsg.h"
#include "paneautorun.h"
#include "..\Model\DEasyDrillerInI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaser

IMPLEMENT_DYNCREATE(CPaneManualControlLaser, CFormView)

CPaneManualControlLaser::CPaneManualControlLaser()
	: CFormView(CPaneManualControlLaser::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlLaser)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bLaserPower				= FALSE;
	m_bReady					= FALSE;
	m_bShutter					= FALSE;
	m_bFault					= FALSE;
	m_bChiller					= FALSE;
	m_bMod						= FALSE;
	m_bWaterFlowAlarm			= FALSE;
	m_bPowerError				= FALSE;
	m_nTimerID					= 0;
	m_pDisp	= NULL;
	m_bAomPower					= FALSE;
	m_bSkipTabControl			= FALSE;
	m_bScannerPower				= FALSE;
	m_bScannerOld				= TRUE;
	m_bLaserPowerOld			= TRUE;
	m_bDummyFree				= FALSE;
	m_bOnDummy					= FALSE;
	m_pMotor					= NULL;
	m_bLPC						= FALSE;
}

CPaneManualControlLaser::~CPaneManualControlLaser()
{
}

void CPaneManualControlLaser::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlLaser)
	DDX_Control(pDX, IDC_CHECK_WATER_FLOW_ALARM, m_ledWaterFlowAlarm);
	DDX_Control(pDX, IDC_CHECK_SHUTTER, m_ledShutter);
	DDX_Control(pDX, IDC_CHECK_READY, m_ledReady);
	DDX_Control(pDX, IDC_CHECK_PWR_ERR, m_ledPowerError);
	DDX_Control(pDX, IDC_CHECK_MOD, m_ledMod);
	DDX_Control(pDX, IDC_CHECK_LASER_POWER, m_ledLaserPower);
	DDX_Control(pDX, IDC_CHECK_FAULT, m_ledFault);
	DDX_Control(pDX, IDC_BUTTON_SHUTTER, m_btnShutter);
	DDX_Control(pDX, IDC_BUTTON_POWER, m_btnPower);
	DDX_Control(pDX, IDC_BUTTON_LASER_WARM_UP, m_btnLaserWarmUp);
	DDX_Control(pDX, IDC_BUTTON_SCANNER_CHECK, m_btnScannerCheck);
	DDX_Control(pDX, IDC_BUTTON_SCANNER_INPOSITION, m_btnScannerInposition);
	DDX_Control(pDX, IDC_BUTTON_ALL_DEVICE_ON, m_btnTurnOn);
	DDX_Control(pDX, IDC_BUTTON_ALL_DEVICE_OFF, m_btnTurnOff);
	DDX_Control(pDX, IDC_BUTTON_AOMPOWER, m_btnAOMPower);
	DDX_Control(pDX, IDC_CHECK_AOMPOWER, m_ledAomPower);
	DDX_Control(pDX, IDC_CHECK_AOMALARM, m_ledAomAlarm);
	DDX_Control(pDX, IDC_BUTTON_SCANNERPOWER, m_btnScannerPower);
	DDX_Control(pDX, IDC_CHECK_SCANNERPOWER, m_ledScannerPower);
	DDX_Control(pDX, IDC_CHECK_DUMMY_FREE, m_ledDummyFree);
	DDX_Control(pDX, IDC_BUTTON_DUMMY_FREE, m_btnDummyFree);
	DDX_Control(pDX, IDC_CHECK_CHILLER, m_ledChiller);
	DDX_Control(pDX, IDC_BUTTON_CHILLER, m_btnChiller);
	DDX_Control(pDX, IDC_BUTTON_LPC, m_btnLPC);
	DDX_Control(pDX, IDC_CHECK_LPC, m_ledLPC);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlLaser, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlLaser)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_ALL_DEVICE_ON, OnButtonTurnOn)
	ON_BN_CLICKED(IDC_BUTTON_ALL_DEVICE_OFF, OnButtonTurnOff)
	ON_BN_CLICKED(IDC_BUTTON_LASER_WARM_UP, OnButtonLaserWarmUp)
	ON_BN_CLICKED(IDC_BUTTON_SCANNER_CHECK, OnButtonScannerCheck)
	ON_BN_CLICKED(IDC_BUTTON_POWER, OnButtonPower)
	ON_BN_CLICKED(IDC_BUTTON_SHUTTER, OnButtonShutter)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_RELAOD, OnButtonRelaod)
	ON_BN_CLICKED(IDC_BUTTON_AOMPOWER, OnButtonAOMPower) //2011527
	ON_BN_CLICKED(IDC_BUTTON_SCANNERPOWER, OnButtonScannerPower)
	ON_BN_CLICKED(IDC_BUTTON_DUMMY_FREE, OnButtonDummyFree)
	ON_BN_CLICKED(IDC_BUTTON_CHILLER, OnButtonChiller)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_SCANNER_INPOSITION, &CPaneManualControlLaser::OnBnClickedButtonScannerInposition)
	ON_BN_CLICKED(IDC_BUTTON_LPC, &CPaneManualControlLaser::OnBnClickedButtonLpc)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaser diagnostics

#ifdef _DEBUG
void CPaneManualControlLaser::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlLaser::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlLaser message handlers

void CPaneManualControlLaser::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	m_pDisp = new CDlgDisp;
	m_pDisp->Create(this);
	m_pDisp->ShowWindow(SW_HIDE);

	//2011527
#ifndef __MP920_MOTOR__
	m_pMotor = gDeviceFactory.GetMotor();
#else
	m_pMotor = gDeviceFactory.GetMotor();
#endif

	InitBtnControl();
	InitStaticControl();

	if(!gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);
	}
	



	GetDlgItem(IDC_STATIC_AOM_CONTROL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_AOM_STATUS)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_AOMPOWER)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_AOMALARM)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON_AOMPOWER)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_STATIC_SCANNER_WORK)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON_SCANNER_CHECK)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON_SCANNER_INPOSITION)->ShowWindow(SW_HIDE);
	

	GetDlgItem(IDC_STATIC_AOM_CONTROL)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_AOM_STATUS)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_CHECK_AOMPOWER)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_CHECK_AOMALARM)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BUTTON_AOMPOWER)->ShowWindow(SW_SHOW);


		GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);


#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_BUTTON_CHILLER)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_CHILLER)->ShowWindow(SW_HIDE);
#endif
	
}

BOOL CPaneManualControlLaser::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlLaser::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(140, "Arial Bold");

	//2011527
	// AOM Power
	m_btnAOMPower.SetFont( &m_fntBtn );
	m_btnAOMPower.SetRectAlign( 1 );
	m_btnAOMPower.SetToolTipText( _T("AOM Power Control") );
	m_btnAOMPower.SetBtnCursor(IDC_HAND_1);

	// Laser Power
	/*m_btnPower.SetFont( &m_fntBtn );
	m_btnPower.SetFlat( FALSE );
	m_btnPower.EnableBallonToolTip();
	m_btnPower.SetToolTipText( _T("Laser Power Control") );
	m_btnPower.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPower.SetBtnCursor(IDC_HAND_1);*/
	m_btnPower.SetFont( &m_fntBtn );
	m_btnPower.SetRectAlign( 1 );
	m_btnPower.SetToolTipText( _T("Laser Power Control") );
	m_btnPower.SetBtnCursor(IDC_HAND_1);

	// Laser Shutter
	/*m_btnShutter.SetFont( &m_fntBtn );
	m_btnShutter.SetFlat( FALSE );
	m_btnShutter.EnableBallonToolTip();
	m_btnShutter.SetToolTipText( _T("Laser Shutter Control") );
	m_btnShutter.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter.SetBtnCursor(IDC_HAND_1);*/
	m_btnShutter.SetFont( &m_fntBtn );
	m_btnShutter.SetRectAlign( 1 );
	m_btnShutter.SetToolTipText( _T("Laser Shutter Control") );
	m_btnShutter.SetBtnCursor(IDC_HAND_1);

	m_btnChiller.SetFont( &m_fntBtn );
	m_btnChiller.SetRectAlign( 1 );
	m_btnChiller.SetToolTipText( _T("Chiller Control") );
	m_btnChiller.SetBtnCursor(IDC_HAND_1);

	m_btnLPC.SetFont( &m_fntBtn );
	m_btnLPC.SetRectAlign( 1 );
	m_btnLPC.SetToolTipText( _T("LPC Control") );
	m_btnLPC.SetBtnCursor(IDC_HAND_1);

	// Laser Warm-Up
	m_btnLaserWarmUp.SetFont( &m_fntBtn );
	m_btnLaserWarmUp.SetFlat( FALSE );
	m_btnLaserWarmUp.EnableBallonToolTip();
	m_btnLaserWarmUp.SetToolTipText( _T("Laser Warm Up") );
	m_btnLaserWarmUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserWarmUp.SetBtnCursor(IDC_HAND_1);

	m_btnScannerCheck.SetFont( &m_fntBtn );
	m_btnScannerCheck.SetFlat( FALSE );
	m_btnScannerCheck.EnableBallonToolTip();
	m_btnScannerCheck.SetToolTipText( _T("Scanner Moving Test for Checking Error") );
	m_btnScannerCheck.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScannerCheck.SetBtnCursor(IDC_HAND_1);

	m_btnScannerInposition.SetFont( &m_fntBtn );
	m_btnScannerInposition.SetFlat( FALSE );
	m_btnScannerInposition.EnableBallonToolTip();
	m_btnScannerInposition.SetToolTipText( _T("Make Scanner Inposition Data") );
	m_btnScannerInposition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScannerInposition.SetBtnCursor(IDC_HAND_1);



	//dummy free
	m_btnDummyFree.SetFont( &m_fntBtn );
	m_btnDummyFree.SetRectAlign( 1 );
	m_btnDummyFree.SetToolTipText( _T("Dummy Free On/Off") );
	m_btnDummyFree.SetBtnCursor(IDC_HAND_1);
	
	// Laser Power
	m_ledLaserPower.SetFont( &m_fntBtn );
	m_ledLaserPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaserPower.Depress( !m_bLaserPower );

	// Ready
	m_ledReady.SetFont( &m_fntBtn );
	m_ledReady.SetImage( IDB_LEDCOLOR, 15 );
	m_ledReady.Depress( !m_bReady );

	// Shutter
	m_ledShutter.SetFont( &m_fntBtn );
	m_ledShutter.SetImage( IDB_LEDCOLOR, 15 );
	m_ledShutter.Depress( !m_bShutter );

	// Fault
	m_ledFault.SetFont( &m_fntBtn );
	m_ledFault.SetImage( IDB_LEDCOLOR, 15 );
	m_ledFault.Depress( !m_bFault );

	// Mod
	m_ledMod.SetFont( &m_fntBtn );
	m_ledMod.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMod.Depress( !m_bMod );

	// Water Flow Alarm
	m_ledWaterFlowAlarm.SetFont( &m_fntBtn );
	m_ledWaterFlowAlarm.SetImage( IDB_LEDCOLOR, 15 );
	m_ledWaterFlowAlarm.Depress( !m_bWaterFlowAlarm );

	// Power Error
	m_ledPowerError.SetFont( &m_fntBtn );
	m_ledPowerError.SetImage( IDB_LEDCOLOR, 15 );
	m_ledPowerError.Depress( !m_bPowerError );

	// Power Error
	m_ledChiller.SetFont( &m_fntBtn );
	m_ledChiller.SetImage( IDB_LEDCOLOR, 15 );
	m_ledChiller.Depress( !m_bPowerError );

	//2011527
	// AOM Power
	m_ledAomPower.SetFont( &m_fntBtn );
	m_ledAomPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAomPower.Depress( TRUE );

	// AOM ALARM
	m_ledAomAlarm.SetFont( &m_fntBtn );
	m_ledAomAlarm.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAomAlarm.Depress( TRUE );
	
	// AOM ALARM
	m_ledDummyFree.SetFont( &m_fntBtn );
	m_ledDummyFree.SetImage( IDB_LEDCOLOR, 15 );
	m_ledDummyFree.Depress( TRUE );

	// LPC
	m_ledLPC.SetFont( &m_fntBtn );
	m_ledLPC.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLPC.Depress( !m_bLPC );


	// All Device Turn On
	m_btnTurnOn.SetFont( &m_fntBtn2 );
	m_btnTurnOn.SetFlat( FALSE );
	m_btnTurnOn.EnableBallonToolTip();
	m_btnTurnOn.SetToolTipText( _T("Turn On All Device") );
	m_btnTurnOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTurnOn.SetBtnCursor(IDC_HAND_1);
	m_btnTurnOn.SetColorType(1); // Blue & Bold Line
	
	// All Device Turn Off
	m_btnTurnOff.SetFont( &m_fntBtn2 );
	m_btnTurnOff.SetFlat( FALSE );
	m_btnTurnOff.EnableBallonToolTip();
	m_btnTurnOff.SetToolTipText( _T("Turn Off All Device") );
	m_btnTurnOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTurnOff.SetBtnCursor(IDC_HAND_1);
	m_btnTurnOff.SetColorType(1); // Blue & Bold Line

	// Scanner Power
	m_ledScannerPower.SetFont( &m_fntBtn );
	m_ledScannerPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledScannerPower.Depress( TRUE );

	// Scanner Power
	m_btnScannerPower.SetFont( &m_fntBtn );
	m_btnScannerPower.SetRectAlign( 1 );
	m_btnScannerPower.SetToolTipText( _T("Scanner Power Control") );
	m_btnScannerPower.SetBtnCursor(IDC_HAND_1);
	
	if(!gSystemINI.m_sHardWare.bUseLPC)
	{
		m_btnLPC.ShowWindow(SW_HIDE);
		m_ledLPC.ShowWindow(SW_HIDE);
	}
}

void CPaneManualControlLaser::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	m_fntStatic2.CreatePointFont(140, "Arial Bold");

	GetDlgItem(IDC_STATIC_ALL_IN_ONE)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_LASER_WORK)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_SCANNER_WORK)->SetFont( &m_fntStatic2 );
	GetDlgItem(IDC_STATIC_LASER_CONTROL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_CONTROL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_CONTROL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LASER_STATUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AOM_STATUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COOLER_STATUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_STATUS)->SetFont( &m_fntStatic );
}

HBRUSH CPaneManualControlLaser::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_ALL_IN_ONE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_WORK)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_WORK)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LASER_CONTROL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_AOM_CONTROL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_CONTROL)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );

	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlLaser::OnButtonTurnOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	if( !m_pMotor->IsLaserKeyOn())
	{
		ErrMsgDlg(STDGNALM1174);
		return;
	}

	m_bSkipTabControl = TRUE;

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE);
	
	m_btnPower.EnableWindow(FALSE);
	m_btnShutter.EnableWindow(FALSE);
	m_btnLaserWarmUp.EnableWindow(FALSE);
	m_btnScannerCheck.EnableWindow(FALSE);
	m_btnAOMPower.EnableWindow(FALSE);
	m_btnTurnOn.EnableWindow(FALSE);
	m_btnTurnOff.EnableWindow(FALSE);
	m_btnScannerPower.EnableWindow(FALSE);
	m_btnScannerInposition.EnableWindow(FALSE);
	m_btnChiller.EnableWindow(FALSE);
	m_btnLPC.EnableWindow(FALSE);
//	m_btnDummyFree.EnableWindow(FALSE);
	// Laser On
	m_bLaserPower = FALSE;
	OnButtonPower();

	int nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	// Shutter Open
	m_bShutter = FALSE;
	OnButtonShutter();

	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	m_bChiller = FALSE;
	OnButtonChiller();


	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	// AOM On
	m_bAomPower = FALSE;
	OnButtonAOMPower();

	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	// Scanner On
	m_bScannerPower = FALSE;
	OnButtonScannerPower();

	m_btnPower.EnableWindow(TRUE);
	m_btnShutter.EnableWindow(TRUE);
	m_btnLaserWarmUp.EnableWindow(TRUE);
	m_btnScannerCheck.EnableWindow(TRUE);
	m_btnAOMPower.EnableWindow(TRUE);
	m_btnTurnOn.EnableWindow(TRUE);
	m_btnTurnOff.EnableWindow(TRUE);
	m_btnScannerPower.EnableWindow(TRUE);
	m_btnScannerInposition.EnableWindow(TRUE);
		m_btnChiller.EnableWindow(TRUE);
		m_btnLPC.EnableWindow(TRUE);
//	m_btnDummyFree.EnableWindow(TRUE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);

	m_bSkipTabControl = FALSE;
}

void CPaneManualControlLaser::OnButtonTurnOff() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	m_bSkipTabControl = TRUE;

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE);
	
	m_btnPower.EnableWindow(FALSE);
	m_btnShutter.EnableWindow(FALSE);
	m_btnLaserWarmUp.EnableWindow(FALSE);
	m_btnScannerCheck.EnableWindow(FALSE);
	m_btnAOMPower.EnableWindow(FALSE);
	m_btnTurnOn.EnableWindow(FALSE);
	m_btnTurnOff.EnableWindow(FALSE);
	m_btnScannerPower.EnableWindow(FALSE);
	m_btnScannerInposition.EnableWindow(FALSE);
	m_btnChiller.EnableWindow(FALSE);
	m_btnLPC.EnableWindow(FALSE);
//	m_btnDummyFree.EnableWindow(FALSE);

	// Scanner Off
	m_bScannerPower = TRUE;
	OnButtonScannerPower();

	int nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);


	m_bChiller = TRUE;
	OnButtonChiller();

	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);
	

	// AOM Off
	m_bAomPower = TRUE;
	OnButtonAOMPower();

	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);
	

	// Shutter Close
	m_bShutter = TRUE;
	OnButtonShutter();

	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	// Dummy Free Close
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		m_btnPower.EnableWindow(TRUE);
		m_btnShutter.EnableWindow(TRUE);
		m_btnLaserWarmUp.EnableWindow(TRUE);
		m_btnScannerCheck.EnableWindow(TRUE);
		m_btnAOMPower.EnableWindow(TRUE);
		m_btnTurnOn.EnableWindow(TRUE);
		m_btnTurnOff.EnableWindow(TRUE);
		m_btnScannerPower.EnableWindow(TRUE);
		m_btnScannerInposition.EnableWindow(TRUE);
		m_btnChiller.EnableWindow(TRUE);
		m_btnLPC.EnableWindow(TRUE);
		return;
	}
	m_bOnDummy = FALSE;
	
	nCnt = 0;
	do 
	{			
		MessageLoop();		
		::Sleep(1);		
		nCnt++;	
	} while(nCnt < 150);

	// Laser Off
	m_bLaserPower = TRUE;
	OnButtonPower();

	m_btnPower.EnableWindow(TRUE);
	m_btnShutter.EnableWindow(TRUE);
	m_btnLaserWarmUp.EnableWindow(TRUE);
	m_btnScannerCheck.EnableWindow(TRUE);
	m_btnAOMPower.EnableWindow(TRUE);
	m_btnTurnOn.EnableWindow(TRUE);
	m_btnTurnOff.EnableWindow(TRUE);
	m_btnScannerPower.EnableWindow(TRUE);
	m_btnScannerInposition.EnableWindow(TRUE);
	m_btnChiller.EnableWindow(TRUE);
	m_btnLPC.EnableWindow(TRUE);
//	m_btnDummyFree.EnableWindow(TRUE);
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);

	m_bSkipTabControl = FALSE;
}

void CPaneManualControlLaser::OnButtonLaserWarmUp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();

	CDlgLaserWarmUp Dlg;
	Dlg.DoModal();

	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
					cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
					cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
					cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, PREHEAT_JOB);
}

void CPaneManualControlLaser::OnButtonPower() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	if( !m_pMotor->IsLaserKeyOn())
	{
		ErrMsgDlg(STDGNALM1174);
		return;
	}
	
	m_bLaserPower = !m_bLaserPower;
	m_btnPower.SetClick( m_bLaserPower );

	CString strEvent;
	
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	if(m_bLaserPower)
	{
		if(!m_bSkipTabControl)
		{
			::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE);

			m_btnPower.EnableWindow(FALSE);
			m_btnShutter.EnableWindow(FALSE);
			m_btnLaserWarmUp.EnableWindow(FALSE);
			m_btnScannerCheck.EnableWindow(FALSE);
			m_btnAOMPower.EnableWindow(FALSE);
			m_btnTurnOn.EnableWindow(FALSE);
			m_btnTurnOff.EnableWindow(FALSE);
			m_btnScannerPower.EnableWindow(FALSE);
			m_btnScannerInposition.EnableWindow(FALSE);
			m_btnLPC.EnableWindow(FALSE);
//			m_btnDummyFree.EnableWindow(FALSE);
		}

		gDeviceFactory.GetLaser()->PowerOn(TRUE);
		strEvent = _T("Laser Enable");		

		int nCnt = 0;
		do 
		{			
			MessageLoop();
			
			::Sleep(5);
			if( FALSE == m_pDisp->IsWindowVisible() )
				m_pDisp->ShowDlg(TRUE, "Please wait...");
			
			nCnt++;	
#ifndef __TEST__
		} while(nCnt < 1000);
#else
		} while(nCnt < 50);
#endif

		gDeviceFactory.GetLaser()->EnableOn();

		if( TRUE == m_pDisp->IsWindowVisible() )
			m_pDisp->ShowDlg(FALSE, "");

		if(!m_bSkipTabControl)
		{
			m_btnPower.EnableWindow(TRUE);
			m_btnShutter.EnableWindow(TRUE);
			m_btnLaserWarmUp.EnableWindow(TRUE);
			m_btnScannerCheck.EnableWindow(TRUE);
			m_btnAOMPower.EnableWindow(TRUE);
			m_btnTurnOn.EnableWindow(TRUE);
			m_btnTurnOff.EnableWindow(TRUE);	
			m_btnScannerPower.EnableWindow(TRUE);
			m_btnScannerInposition.EnableWindow(TRUE);
			m_btnLPC.EnableWindow(TRUE);
//			m_btnDummyFree.EnableWindow(TRUE);
			::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE);
		}
	}
	else
	{
		gDeviceFactory.GetLaser()->PowerOn(FALSE);
		strEvent = _T("Laser Disable");
	}
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));

//	m_ledLaserPower.Depress( !m_bLaserPower );
//	m_ledReady.Depress( !m_bLaserPower );
}

void CPaneManualControlLaser::OnButtonShutter() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	m_bShutter = !m_bShutter;
	m_btnShutter.SetClick( m_bShutter );

// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	CString strEvent;

	if(m_bShutter)
	{
		gDeviceFactory.GetLaser()->ShutterOpen(TRUE);
		strEvent = _T("Shutter Open");
	}
	else
	{
		gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
		strEvent = _T("Shutter Close");
	}

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));

//	m_ledShutter.Depress( !m_bShutter );
}

void CPaneManualControlLaser::OnDestroy() 
{
	if( m_pDisp != NULL )
	{
		m_pDisp->DestroyWindow();
		delete m_pDisp;
		m_pDisp = NULL;
	}

	m_fntBtn.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntStatic2.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlLaser::InitTimer()
{	
	if(m_nTimerID == 0)
		m_nTimerID = SetTimer(1052, 500, NULL);
}

void CPaneManualControlLaser::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneManualControlLaser::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	m_gStatus = gDeviceFactory.GetLaser()->GetStatus();

#ifndef __TEST__
	m_ledReady.Depress( !m_gStatus.bPowerOn );
	m_ledShutter.Depress( !m_gStatus.bShutterOn );
	m_bLaserPower = m_gStatus.bPowerOn;
	m_bShutter = m_gStatus.bShutterOn;
	m_btnLPC.SetClick(m_bLPC);
	m_btnShutter.SetClick( m_bShutter );
	m_btnPower.SetClick(m_bLaserPower);
#else
	m_ledReady.Depress( !m_bLaserPower );
	m_ledShutter.Depress( !m_bShutter );
#endif
	BOOL bTemp, bTemp2;

	bTemp = m_pMotor->GetAOMStatus();
	m_bAomPower = bTemp;
	m_ledAomPower.Depress(!bTemp);
	m_btnAOMPower.SetClick( m_bAomPower );

	bTemp = gDeviceFactory.IsOkAOM();
	m_ledAomAlarm.Depress(bTemp); // ����

	bTemp = m_pMotor->GetScannerStatus();
	m_bScannerPower = bTemp;
	m_btnScannerPower.SetClick( m_bScannerPower );
	m_ledScannerPower.Depress(!bTemp);

	bTemp = m_pMotor->GetChillerRun();
#ifdef __FST_CHILLER_TYPE__
	bTemp2 = m_pMotor->GetChillerRun2();
#else
	bTemp2 = TRUE;
#endif
	if(bTemp && bTemp2)
		m_bChiller = TRUE;
	else
		m_bChiller = FALSE;
	m_btnChiller.SetClick( m_bChiller);
	m_ledChiller.Depress(!bTemp);
	
	int nTemp = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	m_bDummyFree = nTemp & 0x01;

	m_ledDummyFree.Depress(!m_bDummyFree);
	m_btnDummyFree.SetClick(m_bDummyFree);

	//��ĳ�� ������ ��
	if(!bTemp)
	{
		if( m_bScannerOld != bTemp)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
			CString strFile, strLog;
			strFile.GetBuffer(256);
			strLog.GetBuffer(256);
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (ManualControlLaser::OnTimer) : S"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			strFile.ReleaseBuffer();
			strLog.ReleaseBuffer();
		}
	}
	m_bScannerOld = bTemp;

	if(!m_bLaserPower)
	{
		if( m_bLaserPowerOld != m_bLaserPower)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER);
			CString strFile, strLog;
			strFile.GetBuffer(256);
			strLog.GetBuffer(256);
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (ManualControlLaser::OnTimer) : P"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			strFile.ReleaseBuffer();
			strLog.ReleaseBuffer();
		}
	}

	m_bLaserPowerOld = m_bLaserPower;

	m_bLPC = gDeviceFactory.GetMotor()->GetLPCStatus();
	m_ledLPC.Depress(!m_bLPC);
	m_btnLPC.SetClick(m_bLPC);
	

		GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);

	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlLaser::OnButtonRelaod() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetEocard()->ReloadDevice();
}

void CPaneManualControlLaser::SetAuthorityByLevel(int nLevel)
{
	return;

	switch(nLevel)
	{
	case 0:
	case 1:
		GetDlgItem(IDC_BUTTON_RELAOD)->ShowWindow(SW_HIDE);
		break;
	
	case 2:
		GetDlgItem(IDC_BUTTON_RELAOD)->ShowWindow(SW_SHOW);
		break;
	case 3:
		GetDlgItem(IDC_BUTTON_RELAOD)->ShowWindow(SW_SHOW);
		break;
	}
}

//2011527
void CPaneManualControlLaser::OnButtonAOMPower()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	CString strEvent;
	if(!m_bAomPower)
	{
		m_pMotor->SetAOMPowerON(TRUE);
		strEvent = _T("Aom Power On");
	}
	else
	{
		m_pMotor->SetAOMPowerON(FALSE);	
		strEvent = _T("Aom Power Off");
	}
	m_bAomPower = !m_bAomPower;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));
}

void CPaneManualControlLaser::OnButtonScannerPower()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	CString strEvent;
	if(!m_bScannerPower)
	{
		m_btnPower.EnableWindow(FALSE);
		m_btnShutter.EnableWindow(FALSE);
		m_btnLaserWarmUp.EnableWindow(FALSE);
		m_btnScannerCheck.EnableWindow(FALSE);
		m_btnAOMPower.EnableWindow(FALSE);
		m_btnTurnOn.EnableWindow(FALSE);
		m_btnTurnOff.EnableWindow(FALSE);
		m_btnScannerPower.EnableWindow(FALSE);
		m_btnScannerInposition.EnableWindow(FALSE);
		gDeviceFactory.GetEocard()->EStop(); // jhsho�� ��û���� ��ĳ�� ���� �ѱ��� �۾��� �߰���.
		
		CCorrectTime ctFireTime;
		ctFireTime.StartTime();
		BOOL bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			if(ctFireTime.PresentTime() >= 5 )
			{
				ErrMessage(_T("Eocard Error : Busy"));
				m_btnPower.EnableWindow(TRUE);
				m_btnShutter.EnableWindow(TRUE);
				m_btnLaserWarmUp.EnableWindow(TRUE);
				m_btnScannerCheck.EnableWindow(TRUE);
				m_btnAOMPower.EnableWindow(TRUE);
				m_btnTurnOn.EnableWindow(TRUE);
				m_btnTurnOff.EnableWindow(TRUE);
				m_btnScannerPower.EnableWindow(TRUE);
				m_btnScannerInposition.EnableWindow(TRUE);
				return;
			}
			::Sleep(50);
			bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy(); 
		}
		gDeviceFactory.GetEocard()->jump_Use_vm(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
		ctFireTime.StartTime();
		bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			if(ctFireTime.PresentTime() >= 5 )
			{
				ErrMessage(_T("Eocard Error : Busy : Scanner move fail"));
				m_btnPower.EnableWindow(TRUE);
				m_btnShutter.EnableWindow(TRUE);
				m_btnLaserWarmUp.EnableWindow(TRUE);
				m_btnScannerCheck.EnableWindow(TRUE);
				m_btnAOMPower.EnableWindow(TRUE);
				m_btnTurnOn.EnableWindow(TRUE);
				m_btnTurnOff.EnableWindow(TRUE);
				m_btnScannerPower.EnableWindow(TRUE);
				m_btnScannerInposition.EnableWindow(TRUE);
				return;
			}
			::Sleep(50);
			bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy(); 
		}
		m_pMotor->ScannerPower(TRUE);
		int nCount = 0;
		while(!m_pMotor->GetScannerStatus())
		{
			::Sleep(10);
			if(nCount >500)
			{
				ErrMessage(_T("Scanner Power On Error"));
				m_btnPower.EnableWindow(TRUE);
				m_btnShutter.EnableWindow(TRUE);
				m_btnLaserWarmUp.EnableWindow(TRUE);
				m_btnScannerCheck.EnableWindow(TRUE);
				m_btnAOMPower.EnableWindow(TRUE);
				m_btnTurnOn.EnableWindow(TRUE);
				m_btnTurnOff.EnableWindow(TRUE);
				m_btnScannerPower.EnableWindow(TRUE);
				m_btnScannerInposition.EnableWindow(TRUE);
				return;
			}
			nCount++;
		}

		nCount = 0;
		::Sleep(1000);
		while(TRUE)
		{
			gDeviceFactory.GetEocard()->ResetScannerStatusErrorCount();
			::Sleep(1000);
			if(nCount >5)
			{
				ErrMessage(_T("Scanner Power On Error"));
				m_btnPower.EnableWindow(TRUE);
				m_btnShutter.EnableWindow(TRUE);
				m_btnLaserWarmUp.EnableWindow(TRUE);
				m_btnScannerCheck.EnableWindow(TRUE);
				m_btnAOMPower.EnableWindow(TRUE);
				m_btnTurnOn.EnableWindow(TRUE);
				m_btnTurnOff.EnableWindow(TRUE);
				m_btnScannerPower.EnableWindow(TRUE);
				m_btnScannerInposition.EnableWindow(TRUE);
				return;
			}
			if(gDeviceFactory.GetEocard()->IsMotorFault() == 0)
			{
				::Sleep(1000);
				if(gDeviceFactory.GetEocard()->IsMotorFault() == 0)
					break;
			}
			nCount++;
		}

		strEvent = _T("Scanner Power On");
		m_btnPower.EnableWindow(TRUE);
		m_btnShutter.EnableWindow(TRUE);
		m_btnLaserWarmUp.EnableWindow(TRUE);
		m_btnScannerCheck.EnableWindow(TRUE);
		m_btnAOMPower.EnableWindow(TRUE);
		m_btnTurnOn.EnableWindow(TRUE);
		m_btnTurnOff.EnableWindow(TRUE);
		m_btnScannerPower.EnableWindow(TRUE);
		m_btnScannerInposition.EnableWindow(TRUE);
		
		gDeviceFactory.GetEocard()->ResetScannerPosErrorCount();
	}
	else
	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_SCANNER));
		m_pMotor->ScannerPower(FALSE);	
		strEvent = _T("Scanner Power Off");

		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (ManualControlLaser::OnButtonScannerPower) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	m_bScannerPower = !m_bScannerPower;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));
}

void CPaneManualControlLaser::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG )&msg);
	}
}

void CPaneManualControlLaser::OnButtonDummyFree()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(!m_bLaserPower)
	{
		ErrMessage(_T("Laser is off."));
		return;
	}

	
	if(m_bDummyFree)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE, TRUE))
		{
			ErrMsgDlg(STDGNALM781);
			return;
		}
		m_bOnDummy = FALSE;
	}
	else
	{
		if(gSystemINI.m_sHardWare.nUseEocardAxis != 0)
		{
			if(!m_bScannerPower)
			{
				ErrMessage(_T("Turn On Scanner Power!!\n")
					_T("If scanner is not installed, \n")
					_T("Change system.ini option(SCANNER USE INFO = 0)"));
				return;
			}
		}

		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE, TRUE))
		{
			ErrMsgDlg(STDGNALM781);
			return;
		}
		m_bOnDummy = TRUE;
		
	}

}

BOOL CPaneManualControlLaser::GetUserDummyOn()
{
	return m_bOnDummy;
}

void CPaneManualControlLaser::SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
											 int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
											 int ndiff, int nJobType)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strpathName+=_T("JobTime");
	CTime  curDate = CTime::GetCurrentTime();
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//�켱 ���� �˻�
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	
	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strType;
		if(nJobType == PREHEAT_JOB)
			strType.Format(_T("H"));
		else if(nJobType == SCAL_JOB)
			strType.Format(_T("S"));
		else if(nJobType == POWER_JOB)
			strType.Format(_T("P"));
		else
			strType.Format(_T("D"));
		
		strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
			strType,
			nStartYear, nStartMonth, nStartDay, nStartHour, nStartMin, nStartSec, 
			nEndYear, nEndMonth, nEndDay, nEndHour, nEndMin, nEndSec,
			ndiff);
		
		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();

	// copy
	CString strFileName, strMovePath;
	strFileName.Format(_T("JobTime%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strMovePath.Format(_T("%s%d\\%s"), gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo, strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
}

void CPaneManualControlLaser::OnButtonScannerCheck()
{
	m_gStatus = gDeviceFactory.GetLaser()->GetStatus();
	if(m_gStatus.bPowerOn)
	{
		ErrMessage(_T("Please Turn off Laser first"));
		return;
	}
	
	if(!m_pMotor->GetScannerStatus())
	{
		ErrMessage(_T("Please Turn on Scanner Power first"));
		return;
	}
	int	m_nWarningNo[4];
	int	m_nAlarmNo[4];
	int	m_nMaxValue[4];
	int	m_nInposMissNo[4];
	int nLength = 125;

	SUBTOOLDATA subToolResult;
	subToolResult.nSubToolNo = 1;
	subToolResult.nToolType = SHOT_DRILL_TYPE;
	subToolResult.nJumpDelay = 1;
	subToolResult.nLaserOnDelay = 1;
	subToolResult.nLaserOffDelay = 1;
	subToolResult.nFrequency = 1000;
	// Drill
	subToolResult.nShotMode = 1; // cycle mode
	subToolResult.nTotalShot = 1;
	subToolResult.nBurstShot = 1;
	subToolResult.nMask = 0;
	subToolResult.bUseTophat = FALSE;
		
	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	subToolResult.dShotDuty[0] = 50;
	subToolResult.dShotAOMDelay[0] = 20;
	subToolResult.dShotAOMDuty[0] = 30;
	subToolResult.dShotDutyOffsetM[0] = 0;
	subToolResult.dShotDutyOffsetS[0] = 0;
	subToolResult.dShotVolOffsetM[0] = 0;
	subToolResult.dShotVolOffsetS[0] = 0;
	strcpy_s(subToolResult.cAOMFilePath[0], strAOMFile);
	subToolResult.bUseAperture = FALSE;
	subToolResult.nApertureBurst = 1;
	subToolResult.dZOffset = 0;
	subToolResult.cToolMemo[0] = NULL;
		

	if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(SCANNER_CAL_TOOL, subToolResult))
	{
		ErrMessage(_T("DownloadOneSubTool Fail"));
		return;
	}
	int nBackupPreMove = gSystemINI.m_sSystemDevice.nPreMove;
	gSystemINI.m_sSystemDevice.nPreMove = 0;
	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(0))
	{
		gSystemINI.m_sSystemDevice.nPreMove = nBackupPreMove;
		ErrMessage(_T("DownloadShotDrillScannerParam"));
		return;
	}
	gSystemINI.m_sSystemDevice.nPreMove = nBackupPreMove;

	gDeviceFactory.GetEocard()->SetScannerErrorLevel(0.001, 0.01);
	CString strMess;
	while(TRUE)
	{
		if((HALF_LSB + nLength > MAXLSB) || (HALF_LSB - nLength < 0)) 
			break;
		
		gDeviceFactory.GetEocard()->ResetScannerPosErrorCount();
		gDeviceFactory.GetEocard()->ShotDataReset();
		for(int i = 0; i < 200; i++)
		{
			gDeviceFactory.GetEocard()->DownloadShotData2_Use_vm(	HALF_LSB + nLength,
				HALF_LSB + nLength,	HALF_LSB + nLength,	HALF_LSB + nLength,	TRUE, TRUE,	SCANNER_CAL_TOOL);
			gDeviceFactory.GetEocard()->DownloadShotData2_Use_vm(	HALF_LSB - nLength,
				HALF_LSB - nLength,	HALF_LSB - nLength,	HALF_LSB - nLength,	TRUE, TRUE,	SCANNER_CAL_TOOL);
		}
		if(!gDeviceFactory.GetEocard()->FieldPreStart(0))
		{
			ErrMessage(_T("FieldPreStart Fail"));
			gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
			return;
		}
		if(!gDeviceFactory.GetEocard()->FieldStart(TRUE))
		{
			ErrMessage(_T("FieldStart Fail"));
			gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
			return;
		}
		BOOL bResult = TRUE;
		::Sleep(100);
		do
		{
			::Sleep(1);
/*			if(gDeviceFactory.GetEocard()->IsDrillTimeOut())
			{
				ErrMessage(_T("DrillTimeOut"));
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
			if(gDeviceFactory.GetEocard()->IsMotorFault())
			{
				ErrMessage(_T("MotorFault"));
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
*/
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				ErrMsgDlg(STDGNALM1017, _T("Scanner Cable Error."));
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
			else if(bScannerMotorFault)
			{
				if(bScannerMotorFault & 0x01)
					strErrorMsg += _T("Scanner Master X Motor Fault\n");
				if(bScannerMotorFault & 0x02)
					strErrorMsg += _T("Scanner Master Y Motor Fault\n");
				if(bScannerMotorFault & 0x04)
					strErrorMsg += _T("Scanner Slave X Motor Fault\n");
				if(bScannerMotorFault & 0x08)
					strErrorMsg += _T("Scanner Slave Y Motor Fault\n");

				ErrMsgDlg(STDGNALM1017, strErrorMsg);
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
			else if(bScannerDrillTimeOut)
			{
				if(bScannerDrillTimeOut & 0x01)
					strErrorMsg += _T("Scanner Master X Drill Time Out\n");
				if(bScannerDrillTimeOut & 0x02)
					strErrorMsg += _T("Scanner Master Y Drill Time Out\n");
				if(bScannerDrillTimeOut & 0x04)
					strErrorMsg += _T("Scanner Slave X Drill Time Out\n");
				if(bScannerDrillTimeOut & 0x08)
					strErrorMsg += _T("Scanner Slave Y Drill Time Out\n");

				ErrMsgDlg(STDGNALM1017, strErrorMsg);
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
			else if(bTimeOutType)
			{
				if(bTimeOutType & 0x01)
					strErrorMsg += _T("Unknown Time Out\r\n");
				if(bTimeOutType & 0x02)
					strErrorMsg += _T("Drill Time Out\r\n");
				if(bTimeOutType & 0x04)
					strErrorMsg += _T("LPC Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				ErrMsgDlg(STDGNALM566, strErrorMsg);
				gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
				return;
			}
			bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
		}while(bResult);

		if(gDeviceFactory.GetEocard()->GetScannerError(m_nWarningNo, m_nAlarmNo, m_nMaxValue, m_nInposMissNo))
		{
			CTime  curDate = CTime::GetCurrentTime();
			CString strFile, strLog;
			strFile.Format(_T("ScannerPosTest"));
			strLog.Format(_T("%05d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d | %04d"), nLength,
				m_nWarningNo[0], m_nAlarmNo[0], m_nMaxValue[0], m_nWarningNo[1], m_nAlarmNo[1], m_nMaxValue[1],
				m_nWarningNo[2], m_nAlarmNo[2], m_nMaxValue[2], m_nWarningNo[3], m_nAlarmNo[3], m_nMaxValue[3],
				m_nInposMissNo[0], m_nInposMissNo[1]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			strLog.Format(_T("Leng:%05d\t, (X1 Max:%d)\t, (Y1 Max:%d)\t, (X2 Max:%d)\t, (Y2 Max:%d)\n"), nLength,
				m_nMaxValue[0], m_nMaxValue[1], m_nMaxValue[2], m_nMaxValue[3]);
			strMess += strLog;
		}
		nLength *= 2;
	}
	ErrMessage(strMess);
	gDeviceFactory.GetEocard()->SetScannerErrorLevel(gSystemINI.m_sHardWare.dScannerWaringLevelmm, gSystemINI.m_sHardWare.dScannerAlarmLevelmm);
}

void CPaneManualControlLaser::OnBnClickedButtonScannerInposition()
{
	m_btnPower.EnableWindow(FALSE);
	m_btnShutter.EnableWindow(FALSE);
	m_btnLaserWarmUp.EnableWindow(FALSE);
	m_btnScannerCheck.EnableWindow(FALSE);
	m_btnAOMPower.EnableWindow(FALSE);
	m_btnTurnOn.EnableWindow(FALSE);
	m_btnTurnOff.EnableWindow(FALSE);
	m_btnScannerPower.EnableWindow(FALSE);
	m_btnScannerInposition.EnableWindow(FALSE);

	gDeviceFactory.GetEocard()->MakeInpositionTable();

	m_btnPower.EnableWindow(TRUE);
	m_btnShutter.EnableWindow(TRUE);
	m_btnLaserWarmUp.EnableWindow(TRUE);
	m_btnScannerCheck.EnableWindow(TRUE);
	m_btnAOMPower.EnableWindow(TRUE);
	m_btnTurnOn.EnableWindow(TRUE);
	m_btnTurnOff.EnableWindow(TRUE);
	m_btnScannerPower.EnableWindow(TRUE);
	m_btnScannerInposition.EnableWindow(TRUE);
}


BOOL CPaneManualControlLaser::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Laser) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneManualControlLaser::OnButtonChiller()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	m_bChiller = !m_bChiller;
	m_btnChiller.SetClick( m_bChiller );

	CString strEvent;

	if(m_bChiller)
	{
#ifdef __FST_CHILLER_TYPE__
		gDeviceFactory.GetMotor()->SetChillerRun(2);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_CHILLER_REMOTE, TRUE);
		strEvent = _T("Shutter Open");
#endif
	}
	else
	{
#ifdef __FST_CHILLER_TYPE__
		gDeviceFactory.GetMotor()->SetChillerRun(0);
#else
		gDeviceFactory.GetMotor()->SetOutPort(PORT_CHILLER_REMOTE, FALSE);
		strEvent = _T("Shutter Close");
#endif
	}

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));
}

void CPaneManualControlLaser::OnBnClickedButtonLpc()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	m_bLPC = !m_bLPC;
	m_btnLPC.SetClick( m_bLPC );
	CString strEvent;

	if(m_bLPC)
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LPC, TRUE);
		strEvent = _T("LPC Open");
	}
	else
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LPC, FALSE);
		strEvent = _T("LPC Close");
	}

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent));
}
