#if !defined(AFX_PANEMANUALCONTROLSUB_H__035ADD59_4844_4386_BC3E_815C315CD6F0__INCLUDED_)
#define AFX_PANEMANUALCONTROLSUB_H__035ADD59_4844_4386_BC3E_815C315CD6F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneManualControlSub : public CFormView
{
protected:
	CPaneManualControlSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlSub)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlSub)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_SUB };
	UEasyButtonEx	m_btnSetRef;
	UEasyButtonEx	m_btnMoveRef;
	UEasyButtonEx	m_btnFindFiducial;
	UEasyButtonEx	m_btnApplyRef;
	UEasyButtonEx	m_btnBack;
	UEasyButtonEx	m_btnGoFiducial;
	UEasyButtonEx	m_btnGoParameter;

	UEasyButtonEx	m_btnOpenBeampath;
	UEasyButtonEx	m_btnOpenShot;

	UEasyButtonEx	m_btnOpenMoveMotor;

	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void		InitBtnControl();
	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }
	void		ShowBtnControl(int nCmdShow);
	
	void		SetBackButton(BOOL bEnable);

	void SetAuthorityByLevel(int nLevel);

	int				m_nUserLevel;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	CFont		m_fntBtn2;

	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlSub)
	afx_msg void OnButtonBack();
	afx_msg void OnDestroy();
	afx_msg void OnBtnGoFiducial();
	afx_msg void OnBtnGoParameter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonOpenBeampathTable();
	afx_msg void OnBnClickedButtonOpenShotTable();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLSUB_H__035ADD59_4844_4386_BC3E_815C315CD6F0__INCLUDED_)
