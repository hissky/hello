#if !defined(AFX_PANERECIPEGENLAYOUT_H__9A2BB9F3_8393_4CA3_9481_49BF9F5CE013__INCLUDED_)
#define AFX_PANERECIPEGENLAYOUT_H__9A2BB9F3_8393_4CA3_9481_49BF9F5CE013__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenLayout.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenLayout form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButtonEx.h"

class DProject;

class CPaneRecipeGenLayout : public CFormView
{
protected:
	CPaneRecipeGenLayout();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenLayout)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenLayout)
	enum { IDD = IDD_DLG_RECIPE_GEN_LAYOUT };
	CColorStatic	m_stcFieldY;
	CColorStatic	m_stcFieldX;
	CColorEdit	m_edtYAxisRange;
	CColorEdit	m_edtXAxisRange;
	CColorEdit	m_edtFieldSizeYAxis;
	CColorEdit	m_edtFieldSizeXAxis;
	CColorEdit	m_edtPCBThickness;
	CColorEdit	m_edtPCBThickness2nd;
	CColorEdit	m_edtPCBThicknessOffset;
	CColorEdit	m_edtRefFidOffsetX;
	CColorEdit	m_edtRefFidOffsetY;
	CColorEdit	m_edtXAxisTextRange;
	CColorEdit	m_edtYAxisTextRange;
	UEasyButtonEx	m_btnMeasuringThickness;
	UEasyButtonEx	m_chkUseCuDirect;
	UEasyButtonEx	m_chkTurn;
	UEasyButtonEx	m_chkUseFixedAverageScale;

	CColorEdit	m_edtSiteName;

	int		m_nScaleMode;
	int		m_nTypeOfZero;
	int		m_nCoordType;
	int		m_nInputUnit;
	int		m_nUsePanel;
	int		m_nVacuumType;
	int		m_nDummyFreeType;
	int		m_nFindHole;
	int		m_nUserLevel;
	BOOL	m_bTurn;
	BOOL m_bUseFixedAverageScale;
	BOOL	m_bThicknessOK;
	CColorEdit m_edtScaleLimit1;
	CColorEdit m_edtScaleLimit2;
	CColorEdit m_edtScaleManual;
	CColorEdit m_edtScaleManualY;

	CColorEdit m_edtFixedAverageScaleX;
	CColorEdit m_edtFixedAverageScaleY;

	CColorEdit m_edtOCRContents_Machine;
	CColorEdit m_edtOCRContents_LotID;


	CColorEdit m_edtScaleLimit1Minus;
	CColorEdit m_edtScaleLimit2Minus;
	CColorEdit m_edtScaleTolerance1;
	CColorEdit m_edtScaleTolerance2;
	CColorEdit m_edtMeanScale;

	CColorEdit	m_edtPCBThicknessPosX;
	CColorEdit	m_edtPCBThicknessPosY;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void EnableSkivingHeight(BOOL bEnable);
	BOOL SetData();
	BOOL GetData(DProject& tempDProject);
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenLayout)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenLayout();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CFont		m_fntBtn;
	CFont		m_fntBtn2;
	CFont		m_fntStatic;
	CFont		m_fntEdit;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenLayout)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonMeasuringThickness();
	afx_msg void OnCheckUseCudirect();
	afx_msg void OnRadioScaleAuto();
	afx_msg void OnRadioScaleManual();
	afx_msg void OnRadioTableVacummA();
	afx_msg void OnRadioTableVacummB();
	afx_msg void OnRadioTableVacummC();
	afx_msg void OnRadioTableVacummD();
	afx_msg void OnRadioTableVacummE();
	afx_msg void OnRadioTableVacummF();

	afx_msg void OnRadioDummyFreeType1();
	afx_msg void OnRadioDummyFreeType2();
	afx_msg void OnRadioUseHoleNo();
	afx_msg void OnRadioUseHolePre();
	afx_msg void OnRadioUseHolePost();
	afx_msg void OnBnClickedCheckTurn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnBnClickedCheckUseFixedAverageScale();

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENLAYOUT_H__9A2BB9F3_8393_4CA3_9481_49BF9F5CE013__INCLUDED_)
