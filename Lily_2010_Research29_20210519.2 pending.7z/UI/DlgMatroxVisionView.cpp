// DlgMatroxVisionView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionmatrox.h"
#include "..\Model\DSystemINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgMatroxVisionView dialog


CDlgMatroxVisionView::CDlgMatroxVisionView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMatroxVisionView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgMatroxVisionView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nPanelNo = 0;
	m_bSetting = FALSE;
	m_bClick = FALSE;
	
	m_dpStart.x = atof(::AfxGetApp()->GetProfileString("Vision Setting", "Inspection Start X", "0.0"));
	m_dpStart.y = atof(::AfxGetApp()->GetProfileString("Vision Setting", "Inspection Start Y", "0.0"));
	m_dpEnd.x = atof(::AfxGetApp()->GetProfileString("Vision Setting", "Inspection End X", "768.0"));
	m_dpEnd.y = atof(::AfxGetApp()->GetProfileString("Vision Setting", "Inspection End Y", "576.0"));
}


void CDlgMatroxVisionView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgMatroxVisionView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgMatroxVisionView, CDialog)
	//{{AFX_MSG_MAP(CDlgMatroxVisionView)
		// NOTE: the ClassWizard will add message map macros here
	ON_WM_NCHITTEST()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgMatroxVisionView message handlers
BOOL CDlgMatroxVisionView::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_hVision = GetDlgItem(IDC_STATIC_VISION_VIEW)->GetSafeHwnd();
		
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetViewHandle(&m_hVision);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CDlgMatroxVisionView::OnNcHitTest(CPoint point) 
{
	if( TABLE_CAL_VISION_VIEW == m_nPanelNo )
	{
		TRACE("OnNcHitTest()\n");
		UINT nHitTest = CDialog::OnNcHitTest(point);
		return (nHitTest == HTCLIENT) ? HTCAPTION : nHitTest;
	}
	
	return CDialog::OnNcHitTest(point);
}

BOOL CDlgMatroxVisionView::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

void CDlgMatroxVisionView::SetPanelNo(int nNo)
{
	m_nPanelNo = nNo;
}

void CDlgMatroxVisionView::GetInspectArea(DPOINT& dpStart, DPOINT& dpEnd)
{
	dpStart = m_dpStart;
	dpEnd = m_dpEnd;
}

void CDlgMatroxVisionView::SetInspectArea(BOOL bSet)
{
	m_bSetting = bSet;
	
	if(m_bSetting)
	{
		CClientDC dc(GetDlgItem(IDC_STATIC_VISION_VIEW));
		CRect cRect;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect(&cRect);
		
		CPen pen;
		CPen* pOldPen;
		pen.CreatePen(PS_DOT, 1, RGB(255, 255, 0));
		pOldPen = dc.SelectObject(&pen);
		
		dc.MoveTo((int)m_dpStart.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpEnd.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpEnd.x, (int)m_dpEnd.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpEnd.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpStart.y);
		
		dc.SelectObject(pOldPen);
	}
	else
	{
		CString strVal;
		strVal.Format(_T("%.3f"), m_dpStart.x);
		::AfxGetApp()->WriteProfileString("Vision Setting", "Inspection Start X", strVal);
		strVal.Format(_T("%.3f"), m_dpStart.y);
		::AfxGetApp()->WriteProfileString("Vision Setting", "Inspection Start Y", strVal);
		strVal.Format(_T("%.3f"), m_dpEnd.x);
		::AfxGetApp()->WriteProfileString("Vision Setting", "Inspection End X", strVal);
		strVal.Format(_T("%.3f"), m_dpEnd.y);
		::AfxGetApp()->WriteProfileString("Vision Setting", "Inspection End Y", strVal);
	}
}

void CDlgMatroxVisionView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(m_bSetting)
	{
		Invalidate();

		CClientDC dc(GetDlgItem(IDC_STATIC_VISION_VIEW));
		CRect cRect;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect(&cRect);
		ClientToScreen(&point);
		if(cRect.PtInRect(point))
		{
			m_dpStart.x = point.x - cRect.left;
			m_dpStart.y = point.y - cRect.top;
		}
		else
		{
			if(point.x < cRect.left) point.x = cRect.left;
			if(point.x > cRect.right) point.x = cRect.right;
			if(point.y < cRect.top) point.y = cRect.top;
			if(point.y > cRect.bottom) point.y = cRect.bottom;

			m_dpStart.x = point.x - cRect.left;
			m_dpStart.y = point.y - cRect.top;
		}

		m_dpMoving = m_dpStart;

		m_bClick = TRUE;
	}
	
	CDialog::OnLButtonDown(nFlags, point);
}

void CDlgMatroxVisionView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bSetting)
	{
		CClientDC dc(GetDlgItem(IDC_STATIC_VISION_VIEW));
		CRect cRect;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect(&cRect);
		ClientToScreen(&point);
		if(cRect.PtInRect(point))
		{
			m_dpEnd.x = point.x - cRect.left;
			m_dpEnd.y = point.y - cRect.top;
		}
		else
		{
			if(point.x < cRect.left) point.x = cRect.left;
			if(point.x > cRect.right) point.x = cRect.right;
			if(point.y < cRect.top) point.y = cRect.top;
			if(point.y > cRect.bottom) point.y = cRect.bottom;
			
			m_dpEnd.x = point.x - cRect.left;
			m_dpEnd.y = point.y - cRect.top;
		}

		CPen pen;
		CPen* pOldPen;
		pen.CreatePen(PS_DOT, 1, RGB(255, 255, 0));
		pOldPen = dc.SelectObject(&pen);
		
		dc.MoveTo((int)m_dpStart.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpEnd.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpEnd.x, (int)m_dpEnd.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpEnd.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpStart.y);
		
		dc.SelectObject(pOldPen);
		
		m_bClick = FALSE;

		CDPoint dpTemp;
		if(m_dpStart.x > m_dpEnd.x)
		{
			dpTemp.x = m_dpEnd.x;
			m_dpEnd.x = m_dpStart.x;
			m_dpStart.x = dpTemp.x;
		}
		if(m_dpStart.y > m_dpEnd.y)
		{
			dpTemp.y = m_dpEnd.y;
			m_dpEnd.y = m_dpStart.y;
			m_dpStart.y = dpTemp.y;
		}
	}
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CDlgMatroxVisionView::OnMouseMove(UINT nFlag, CPoint point)
{
	if(m_bClick)
	{
		CClientDC dc(GetDlgItem(IDC_STATIC_VISION_VIEW));
		CRect cRect;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect(&cRect);
		ClientToScreen(&point);
		if(cRect.PtInRect(point))
		{
			point.x = point.x - cRect.left;
			point.y = point.y - cRect.top;
		}
		else
		{
			if(point.x < cRect.left) point.x = cRect.left;
			if(point.x > cRect.right) point.x = cRect.right;
			if(point.y < cRect.top) point.y = cRect.top;
			if(point.y > cRect.bottom) point.y = cRect.bottom;
			
			point.x = point.x - cRect.left;
			point.y = point.y - cRect.top;
		}
		
		CPen pen;
		CPen* pOldPen;
		pen.CreatePen(PS_DOT, 1, RGB(255, 255, 0));
		pOldPen = dc.SelectObject(&pen);

		dc.SetROP2(R2_XORPEN);
		
		dc.MoveTo((int)m_dpStart.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpMoving.x, (int)m_dpStart.y);
		dc.LineTo((int)m_dpMoving.x, (int)m_dpMoving.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpMoving.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpStart.y);

		dc.MoveTo((int)m_dpStart.x, (int)m_dpStart.y);
		dc.LineTo((int)point.x, (int)m_dpStart.y);
		dc.LineTo((int)point.x, (int)point.y);
		dc.LineTo((int)m_dpStart.x, (int)point.y);
		dc.LineTo((int)m_dpStart.x, (int)m_dpStart.y);

		m_dpMoving.x = point.x;
		m_dpMoving.y = point.y;
		
		dc.SelectObject(pOldPen);
	}

	CDialog::OnMouseMove(nFlag, point);
}