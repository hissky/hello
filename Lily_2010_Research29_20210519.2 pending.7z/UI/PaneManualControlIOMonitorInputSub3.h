#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB3_H__A3ACF9A5_1538_4501_852F_6CD4D907A204__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUTSUB3_H__A3ACF9A5_1538_4501_852F_6CD4D907A204__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInputSub3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub3 form view

#include "LedButton.h"
#include "..\device\devicemotor.h"

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorInputSub3 : public CFormView
{
protected:
	CPaneManualControlIOMonitorInputSub3();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInputSub3)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInputSub3)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT_SUB3 };
	CFont m_fntBtn;

	CLedButton m_ledLCReady;
	CLedButton m_ledLCBusy;
	CLedButton m_ledLCStop;
	CLedButton m_ledLCInitEnd;

	CLedButton m_ledLdPaperTransFwd;
	CLedButton m_ledLdPaperTransBwd;
	CLedButton m_ledLdPCBTransFwd;
	CLedButton m_ledLdPCBTransBwd;
	CLedButton m_ledLdAlignSheetFwd;
	CLedButton m_ledLdAlignSheetBwd;
	CLedButton m_ledLdAlignGuideFwd;
	CLedButton m_ledLdAlignGuideBwd;
	CLedButton m_ledLdCartClampUp;
	CLedButton m_ledLdCartClampDown;
	
	CLedButton m_ledLP1Ready;
	CLedButton m_ledLP1Busy;
	CLedButton m_ledLP1Stop;
	CLedButton m_ledLP1InitEnd;
	CLedButton m_ledLP1VacuumOn;
	CLedButton m_ledLP1VacuumOff;

	CLedButton m_ledLP2Ready;
	CLedButton m_ledLP2Busy;
	CLedButton m_ledLP2Stop;
	CLedButton m_ledLP2InitEnd;
	CLedButton m_ledLP2VacuumOn;
	CLedButton m_ledLP2VacuumOff;

	CLedButton m_ledLP3Ready;
	CLedButton m_ledLP3Busy;
	CLedButton m_ledLP3Stop;
	CLedButton m_ledLP3InitEnd;
	CLedButton m_ledLP3VacuumOn;
	CLedButton m_ledLP3VacuumOff;

	//}}AFX_DATA

// Attributes
public:
	int m_nTimerID;
	LONG m_lStatusHandlerLoader;
	LONG m_lStatusHandlerLoaderOld;
	
	DeviceMotor* m_pMotor;

// Operations
public:
	void UpdateStatus();
	
	void InitTimer();
	void DestroyTimer();
	
	void InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInputSub3)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInputSub3();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInputSub3)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB3_H__A3ACF9A5_1538_4501_852F_6CD4D907A204__INCLUDED_)
