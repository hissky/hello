#if !defined(AFX_PANESYSSETUPVACUUM_H__E416B784_82BB_4FCC_9CCD_186BCC2A9ECB__INCLUDED_)
#define AFX_PANESYSSETUPVACUUM_H__E416B784_82BB_4FCC_9CCD_186BCC2A9ECB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupVacuum.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupVacuum form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneSysSetupVacuum : public CFormView
{
protected:
	CPaneSysSetupVacuum();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupVacuum)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupVacuum)
	enum { IDD = IDD_DLG_SYS_SETUP_TABLE_VACUUM };
	CColorEdit	m_edtVacuumA1;
	CColorEdit	m_edtVacuumB1;
	CColorEdit	m_edtVacuumC1;
	CColorEdit	m_edtVacuumD1;
	CColorEdit	m_edtVacuumA2;
	CColorEdit	m_edtVacuumB2;
	CColorEdit	m_edtVacuumC2;
	CColorEdit	m_edtVacuumD2;
	CColorEdit	m_edtVacuumOffset;
	//}}AFX_DATA

// Attributes
public:
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	
	SSYSTEMVACUUM	m_sSystemVacuum;
	
// Operations
public:
	CString GetChangeValueStr();
	void		InitStaticControl();
	void		InitEditControl();
	
	void		SetSystemVacuum(SSYSTEMVACUUM sSystemVacuum);
	void		GetSystemVacuum(SSYSTEMVACUUM* pSystemVacuum);
	void		OnApply();

	void		DispValue();
		
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupVacuum)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupVacuum();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupVacuum)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPVACUUM_H__E416B784_82BB_4FCC_9CCD_186BCC2A9ECB__INCLUDED_)
