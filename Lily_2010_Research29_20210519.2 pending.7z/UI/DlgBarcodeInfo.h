#if !defined(AFX_DLGBARCODEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_)
#define AFX_DLGBARCODEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgBarcodeInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeInfo dialog

class CDlgBarcodeInfo : public CDialog
{
// Construction
public:
	int m_nBarType;
	CDlgBarcodeInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgBarcodeInfo)
	enum { IDD = IDD_DLG_BARCODE_INFO };
	CComboBox	m_cmbBarType;
	CString	m_strLotInfo;
	UINT	m_nNo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgBarcodeInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgBarcodeInfo)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGBARCODEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_)
