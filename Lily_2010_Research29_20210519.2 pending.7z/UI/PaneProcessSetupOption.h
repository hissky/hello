#if !defined(AFX_PANEPROCESSSETUPOPTION_H__B4AFDDEF_D941_4A31_9303_2A9B978B754C__INCLUDED_)
#define AFX_PANEPROCESSSETUPOPTION_H__B4AFDDEF_D941_4A31_9303_2A9B978B754C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupOption.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneProcessSetupOption : public CFormView
{
protected:
	CPaneProcessSetupOption();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupOption)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupOption)
	enum { IDD = IDD_DLG_PROCESS_SETUP_OPTION };
	UEasyButtonEx	m_chkUseApplyTolerance;
	UEasyButtonEx	m_chkUsePreworkPerCount;
	UEasyButtonEx	m_chkPowerLotEnd;
	UEasyButtonEx	m_chkUsePowerCompensationMode;
	CColorEdit	m_edtErrorRetryCount;
	CColorEdit	m_edtAutoCal2ndPaneY;
	CColorEdit	m_edtAutoCal2ndPaneX;
	CColorEdit	m_edtAutoCal1stPaneY;
	CColorEdit	m_edtAutoCal1stPaneX;
	CColorEdit	m_edtPreworkAutoCal2ndPaneY;
	CColorEdit	m_edtPreworkAutoCal2ndPaneX;
	CColorEdit	m_edtPreworkAutoCal1stPaneY;
	CColorEdit	m_edtPreworkAutoCal1stPaneX;
	CColorEdit	m_edtAutoCal1stPaneR;
	CColorEdit	m_edtAutoCal2ndPaneR;
	CColorEdit	m_edtPreworkAutoCal1stPaneR;
	CColorEdit	m_edtPreworkAutoCal2ndPaneR;
	CColorEdit	m_edtValidMeasureTime;
	CColorEdit	m_edtValidTime;
	CColorEdit	m_edtSCalRelTime;
	CColorEdit	m_edtSCalPNL;
	CColorEdit	m_edtSCalPNLForSkive;

	CColorEdit m_edtScalFieldCount;
	CColorEdit m_edtVisionCalFieldCount;

	CColorEdit m_edtCalibrationHoleGap;
	CColorEdit m_edtScannerCalXCount;
	CColorEdit m_edtScannerCalYCount;
	CColorEdit m_edtVisionCalXCount;
	CColorEdit m_edtVisionCalYCount;

	CColorEdit	m_edtPowerRelTime;
	CColorEdit	m_edtPowerPNL;
	CColorEdit	m_edtPreheatModulationTime;
	CColorEdit	m_edtPreheatTime;
	CColorEdit	m_edtAutoRunPreheatTime;
	CColorEdit	m_edtPreheatDuty;
	CColorEdit	m_edtPreheatFreq;
	CColorEdit	m_edtPreheatJumpDelayDryRun;

	CColorEdit	m_edtPreheatRelTime;
	CColorEdit	m_edtPreheatPNL;
	CComboBox	m_cmbTool;
	//}}AFX_DATA

// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;
	CFont			m_fntCombo;
	SPROCESSCALIBRATION	m_sProcessCal;
	BOOL			m_bApplyTolerance;
	BOOL			m_bSkipBoardCheck;
	int				m_nLevel;
// Operations
public:
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();
	void InitComboControl();
	void SetProcessCal(SPROCESSCALIBRATION sProcessCal);
	void GetProcessCal(SPROCESSCALIBRATION* pProcessCal);
	void DispProcessCal();
	void OnApply();
	void SetToolComboBox();
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupOption)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupOption();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupOption)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnCheckUseCountUnit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonTest4();
	afx_msg void OnBnClickedButtonTest5();
	afx_msg void OnEnChangeEditAutoCalGap();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPOPTION_H__B4AFDDEF_D941_4A31_9303_2A9B978B754C__INCLUDED_)
