// DDirPath.cpp: implementation of the DDirPath class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\easydriller.h"
#include "DDirPath.h"

#include <direct.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//DDirPath gDirPath;

DDirPath::DDirPath()
{
	m_strRoot.Format(_T("D:\\ViaHole\\"));
	m_strParameter.Format(_T("D:\\ViaHole\\Parameter\\"));
	m_strCorrect.Format(_T("D:\\ViaHole\\Correct\\"));
	m_strProject.Format(_T("D:\\ViaHole\\Project\\"));
	m_strData.Format(_T("D:\\ViaHole\\Data\\"));
	m_strConverted.Format(_T("D:\\ViaHole\\Converted\\"));
	m_strImage.Format(_T("D:\\ViaHole\\Image\\"));
	m_strErrorLog.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	m_strProcessLog.Format(_T("D:\\ViaHole\\ProcessLog\\"));
	m_strLPCLog.Format(_T("D:\\ViaHole\\LPCLog\\"));
	m_strBackup.Format(_T("D:\\ViaHole\\Backup\\"));
	m_strSystem.Format(_T("D:\\ViaHole\\System\\"));
	m_strAperture.Format(_T("D:\\ViaHole\\Aperture\\"));
	m_strScaleLog.Format(_T("Z:\\"));
	m_strNetwork.Format(_T("D:\\ViaHole\\System\\"));
	m_strImportantLog.Format(_T("D:\\ViaHole\\ImportantLog\\"));
	m_str1stMasterCalFilePath.Format(_T("D:\\ViaHole\\Correct\\1stMaster.asc"));
	m_str1stSlaveCalFilePath.Format(_T("D:\\ViaHole\\Correct\\1stSlave.asc"));
	m_str2ndMasterCalFilePath.Format(_T("D:\\ViaHole\\Correct\\2ndMaster.asc"));
	m_str2ndSlaveCalFilePath.Format(_T("D:\\ViaHole\\Correct\\2ndSlave.asc"));
	m_strScannerProfilePath.Format(_T("D:\\ViaHole\\Correct\\Default.pro"));
	m_strVisionProjectPath.Format(_T("D:\\ViaHole\\Vision\\"));
	m_strBarcodeFilePath.Format(_T("D:\\ViaHole\\System\\LotDB.mdb"));
}

DDirPath::~DDirPath()
{

}

void DDirPath::SetRootDir(CString strDir)
{
	m_strRoot.Format(_T("%s"), strDir);
	
	// Temp Directory
	m_strTemp.Format(_T("%sTemp"), m_strRoot);
}

CString DDirPath::GetRootDir()
{
	return m_strRoot;
}

void DDirPath::SetTempDir(CString strDir)
{
	m_strTemp.Format(_T("%s"), strDir);
}

CString DDirPath::GetTempDir()
{
	return m_strTemp;
}

void DDirPath::SetParameterDir(CString strDir)
{
	m_strParameter.Format(_T("%s"), strDir);
}

CString DDirPath::GetParameterDir()
{
	return m_strParameter;
}

void DDirPath::SetCorrectDir(CString strDir)
{
	m_strCorrect.Format(_T("%s"), strDir);
}

CString DDirPath::GetCorrectDir()
{
	return m_strCorrect;
}

void DDirPath::SetProjectDir(CString strDir)
{
	m_strProject.Format(_T("%s"), strDir);
}

CString DDirPath::GetProjectDir()
{
	return m_strProject;
}

void DDirPath::SetDataDir(CString strDir)
{
	m_strData.Format(_T("%s"), strDir);
}

CString DDirPath::GetDataDir()
{
	return m_strData;
}

void DDirPath::SetConvertedDir(CString strDir)
{
	m_strConverted.Format(_T("%s"), strDir);
}

CString DDirPath::GetConvertedDir()
{
	return m_strConverted;
}

void DDirPath::SetImageDir(CString strDir)
{
	m_strImage.Format(_T("%s"), strDir);
}

CString DDirPath::GetImageDir()
{
	return m_strImage;
}

void DDirPath::SetErrorLogDir(CString strDir)
{
	m_strErrorLog.Format(_T("%s"), strDir);
}

CString DDirPath::GetErrorLogDir()
{
	return m_strErrorLog;
}

void DDirPath::SetProcessLogDir(CString strDir)
{
	m_strProcessLog.Format(_T("%s"), strDir);
}

CString DDirPath::GetProcessLogDir()
{
	return m_strProcessLog;
}

void	DDirPath::SetLPCLogDir(CString strDir)
{
	m_strLPCLog.Format(_T("%s"), strDir);
}

CString	DDirPath::GetLPCLogDir()
{
	return m_strLPCLog;
}

void DDirPath::SetBackupDir(CString strDir)
{
	m_strBackup.Format(_T("%s"), strDir);
}

CString DDirPath::GetBackupDir()
{
	return m_strBackup;
}

void DDirPath::SetSystemDir(CString strSys)
{
	m_strSystem.Format(_T("%s"), strSys);
}

CString DDirPath::GetSystemDir()
{
	return m_strSystem;
}

void DDirPath::SetApertureDir(CString strDir)
{
	m_strAperture.Format(_T("%s"), strDir);
}

CString DDirPath::GetApertureDir()
{
	return m_strAperture;
}
void DDirPath::SetBarcodeDir(CString strDir)
{
	m_strBarcodeFilePath.Format(_T("%s"), strDir);	
}

CString DDirPath::GetBarcodeDir()
{
	return m_strBarcodeFilePath;
}

void DDirPath::SetScaleLogDir(CString strDir)
{
	m_strScaleLog.Format(_T("%s"), strDir);
}

CString	DDirPath::GetScaleLogDir()
{
	return m_strScaleLog;
}

void DDirPath::SetNetworkDir(CString strDir)
{
	m_strNetwork.Format(_T("%s"), strDir);
}

CString	DDirPath::GetNetworkDir()
{
	return m_strNetwork;
}

void DDirPath::Set1stMasterCalFilePath(CString strPath)
{
	m_str1stMasterCalFilePath.Format(_T("%s"), strPath);	
}

CString DDirPath::Get1stMasterCalFilePath()
{
	return m_str1stMasterCalFilePath;
}

void DDirPath::Set1stSlaveCalFilePath(CString strPath)
{
	m_str1stSlaveCalFilePath.Format(_T("%s"), strPath);
}

CString DDirPath::Get1stSlaveCalFilePath()
{
	return m_str1stSlaveCalFilePath;
}

void DDirPath::Set2ndMasterCalFilePath(CString strPath)
{
	m_str2ndMasterCalFilePath.Format(_T("%s"), strPath);
}

CString DDirPath::Get2ndMasterCalFilePath()
{
	return m_str2ndMasterCalFilePath;
}

void DDirPath::Set2ndSlaveCalFilePath(CString strPath)
{
	m_str2ndSlaveCalFilePath.Format(_T("%s"), strPath);
}

CString DDirPath::Get2ndSlaveCalFilePath()
{
	return m_str2ndSlaveCalFilePath;
}

void DDirPath::SetScannerProfileFilePath(CString strPath)
{
	m_strScannerProfilePath.Format(_T("%s"), strPath);
}

CString	DDirPath::GetScannerProfileFilePath()
{
	return m_strScannerProfilePath;
}


void DDirPath::SetVisionProjectPath(CString strPath)
{
	m_strVisionProjectPath.Format(_T("%s"), strPath);
}

CString	DDirPath::GetImportantLogDir()
{
	return m_strImportantLog;
}

void DDirPath::SetImportantLogDir(CString strPath)
{
	m_strImportantLog.Format(_T("%s"), strPath);
}

CString	DDirPath::GetVisionProjectPath()
{
	return m_strVisionProjectPath;
}

void DDirPath::CheckDirectory()
{
	char szWorkDir[BUFMAX] = {0,};

	_getcwd( szWorkDir, sizeof(szWorkDir) );

	// Root Dir
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strRoot ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strRoot ); // Create Root Directory

	// Parameter Dir
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strParameter ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strParameter );

	// Correct
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strCorrect ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strCorrect );

	// Project
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strProject ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strProject );

	// Data
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strData ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strData );

	// Converted
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strConverted ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strConverted );

	// Image
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strImage ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strImage );

	// Image backup
	CString strBackupImage;
	strBackupImage.Format(_T("%sBackup\\"), m_strImage);
	if( 0 != _chdir( (LPSTR)(LPCTSTR)strBackupImage ) )
		_mkdir( (LPSTR)(LPCTSTR)strBackupImage );

	// Error Log
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strErrorLog ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strErrorLog );

	// Process Log
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strProcessLog ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strProcessLog ) ;

	// LPC Log
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strLPCLog ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strLPCLog ) ;

	// Backup
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strBackup ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strBackup );

	// System
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strSystem ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strSystem );

	// Aperture
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strAperture ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strAperture );

	// scale log
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strScaleLog ) )
	{
		ErrMessage(_T("Can't link Fiducial Scale Log Folder.") );
	}
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strNetwork ) )
	{
		ErrMessage(_T("Can't link Network Folder.") );
	}
	// Temp
	if( 0 != _chdir( (LPSTR)(LPCTSTR)m_strTemp ) )
		_mkdir( (LPSTR)(LPCTSTR)m_strTemp );

	_chdir( szWorkDir );
}