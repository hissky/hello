// BeamPathINIFile.cpp: implementation of the CBeamPathINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "BeamPathINIFile.h"
#include "DBeampathINI.h"
#include "DSystemINI.h"
#include "DEasyDrillerINI.h"



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBeamPathINIFile::CBeamPathINIFile()
{

}

CBeamPathINIFile::~CBeamPathINIFile()
{

}

BOOL CBeamPathINIFile::	OpenBeamPathINIFile(CString strFilePath, DBeampathINI& clsBeamPathINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START BEAMPATH SECTION")) )
		{
			if( FALSE == ParsingBeamPath( sFile, clsBeamPathINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingLaserScanner"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
	
		else if( 0 == strGetData.CompareNoCase(_T("// END BEAMPATH INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CBeamPathINIFile::GetOldBeamPathData(DBeampathINI& clsBeamPathINI, DSystemINI clsSystemINI)
{
	CString strTemp;
	for(int i = 0; i < 10; i++)
	{
		clsBeamPathINI.m_sBeampath.nLastIndex = 9;
		clsBeamPathINI.m_sBeampath.bSelectedList[i] = FALSE;
		//Information
		clsBeamPathINI.m_sBeampath.nInfoId[i] = i;
		strTemp.Format(_T("M : %.2f - Size : %.2f"), clsSystemINI.m_sSystemCollimator.dMaskSize[i], clsSystemINI.m_sSystemCollimator.dBeamSize[i]);
		sprintf_s( clsBeamPathINI.m_sBeampath.strInfoName[i], BUFMAX,  _T("%s"), strTemp );
		clsBeamPathINI.m_sBeampath.dInfoMaskSize[i] = clsSystemINI.m_sSystemCollimator.dMaskSize[i];
		
		//�����
		clsBeamPathINI.m_sBeampath.dBeamPathBetPos1[i] = clsSystemINI.m_sSystemCollimator.sCollimatorPos[i].dPositon;
		clsBeamPathINI.m_sBeampath.dBeamPathBetPos2[i] = clsSystemINI.m_sSystemCollimator.sCollimatorPos2[i].dPositon;
		clsBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i] = (int)clsSystemINI.m_sSystemCollimator.dMaskPosition[i];
		clsBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i] = 0;
		clsBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i] = 0;
		clsBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i] = 0;

		clsBeamPathINI.m_sBeampath.dBeamPathRotator[i] = 0;
		clsBeamPathINI.m_sBeampath.dBeamPathTopHat[i] = 0;


		clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i] = 0;
		clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i] = 0;
		clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i] = clsSystemINI.m_sSystemDevice.d1stLaserHeight[i];
		clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i] = clsSystemINI.m_sSystemDevice.d2ndLaserHeight[i];
		clsBeamPathINI.m_sBeampath.bBeamPathUseTophat[i] = FALSE;
		clsBeamPathINI.m_sBeampath.bBeamPathLaserPath[i] = FALSE;
		//clsBeamPathINI.m_sBeampath.bBeamPathUseAom[i] = TRUE;
		
		clsBeamPathINI.m_sBeampath.strBeamPathAscFile[i][0] = NULL;
		clsBeamPathINI.m_sBeampath.dBeamPathVoltage1[i] = 0;
		clsBeamPathINI.m_sBeampath.dBeamPathVoltage2[i] = 0;
		
		//Power Offset
		clsBeamPathINI.m_sBeampath.dPowOffsetDuty[i] = clsSystemINI.m_sSystemCollimator.nDutyOffset[i]/100.;
		clsBeamPathINI.m_sBeampath.dPowOffsetAomDelay[i] = clsSystemINI.m_sSystemCollimator.nAOMDelayOffset[i]/100.;
		clsBeamPathINI.m_sBeampath.dPowOffsetAomDuty[i] = clsSystemINI.m_sSystemCollimator.nAOMDutyOffset[i]/100.;
		clsBeamPathINI.m_sBeampath.dPowOffsetAomDual1[i] = 0;
		clsBeamPathINI.m_sBeampath.dPowOffsetAomDual2[i] = 0;
		clsBeamPathINI.m_sBeampath.dPowOffsetVoltage1[i] = 0;
		clsBeamPathINI.m_sBeampath.dPowOffsetVoltage2[i] = 0;
		
		//Power Compensation
		clsBeamPathINI.m_sBeampath.nSelectShot[i] = 0;
		clsBeamPathINI.m_sBeampath.nPowCompensationFrequency[i] = clsSystemINI.m_sSystemCollimator.nPowerFreq[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationDuty[i] = clsSystemINI.m_sSystemCollimator.dPowerWidth[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i] = clsSystemINI.m_sSystemCollimator.dPowerAOMDelay[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i] = clsSystemINI.m_sSystemCollimator.dPowerAOMDuty[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i] = clsSystemINI.m_sSystemCollimator.dPowerMax[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i] = clsSystemINI.m_sSystemCollimator.dPowerMin[i];
		clsBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i] = 0;
		clsBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i] = 10;
		clsBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i] = 10;
		memset(clsBeamPathINI.m_sBeampath.strPowCompensationAomFile, NULL, 255);
		
		//Scanner ���� 
		clsBeamPathINI.m_sBeampath.dScannerDuty[i] = 50;

		clsBeamPathINI.m_sBeampath.dScannerFrq[i] = 1000;


		clsBeamPathINI.m_sBeampath.dScannerAomDuty[i] = 20;
		clsBeamPathINI.m_sBeampath.dScannerAomdelay[i] = 30;
		clsBeamPathINI.m_sBeampath.nScannerTotalShot[i] = 1;
		clsBeamPathINI.m_sBeampath.nScannerVisionCam[i] = 1;				// ���� ī�޶�
		clsBeamPathINI.m_sBeampath.dScannerVisionModelSize[i] = 0.17;
		clsBeamPathINI.m_sBeampath.nScannerPolarity[i] = 0;
		clsBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i] = 20;
		clsBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i] = 30;
		clsBeamPathINI.m_sBeampath.dScannerContrast[i] = 0.8;
		clsBeamPathINI.m_sBeampath.dScannerBrightness[i] = 0.9;
		clsBeamPathINI.m_sBeampath.dScannerJumpDelay = 1000;				//1000����
		
		clsBeamPathINI.m_sBeampath.nHoleVisionCam[i] = 1;				// ���� ī�޶�
		clsBeamPathINI.m_sBeampath.dHoleVisionModelSize[i] = 0.17;
		clsBeamPathINI.m_sBeampath.nHolePolarity[i] = 0;
		clsBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[i] = 20;
		clsBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[i] = 30;
		clsBeamPathINI.m_sBeampath.dHoleContrast[i] = 0.8;
		clsBeamPathINI.m_sBeampath.dHoleBrightness[i] = 0.9;

		clsBeamPathINI.m_sBeampath.nFixedMask = 0;						//Fixed mask2 Position ��ü��
	}
	
	return TRUE;
}

BOOL CBeamPathINIFile::	ParsingBeamPath(CStdioFile& sFile, DBeampathINI& clsBeamPathINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	int nIndex = 0;
	
	while( sFile.ReadString( strGetData ) )
	{
		//total count
		if( ScanSys( strGetData, _T("LASTINDEX ="), clsBeamPathINI.m_sBeampath.nLastIndex ) )
			continue;

	// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
			continue;

		//information

		// id
		clsBeamPathINI.m_sBeampath.nInfoId[nIndex] = nIndex;
		if( ScanSys( strGetData, _T("INFO ID ="), clsBeamPathINI.m_sBeampath.nInfoId[nIndex]) )
			continue;
		// name
// 		if( ScanSys( strGetData, _T("INFO NAME ="),clsBeamPathINI.m_sBeampath.strInfoName[nIndex]) )
// 			continue;
		if( ScanSys( strGetData, _T("INFO NAME ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsBeamPathINI.m_sBeampath.strInfoName[nIndex], BUFMAX, _T("%s"), strTarget );
			continue;
		}

		// mask size
		if( ScanSys( strGetData, _T("INFO MASKSIZE ="), clsBeamPathINI.m_sBeampath.dInfoMaskSize[nIndex]) )
			continue;


		//����� 

		// bet pos1
		if( ScanSys( strGetData, _T("BEAMPATH BET POS1 ="), clsBeamPathINI.m_sBeampath.dBeamPathBetPos1[nIndex]) )
			continue;
		// bet pos2
		if( ScanSys( strGetData, _T("BEAMPATH BET POS2 ="), clsBeamPathINI.m_sBeampath.dBeamPathBetPos2[nIndex]) )
			continue;
		// mask pos1
		if( ScanSys( strGetData, _T("BEAMPATH MASK POS1 ="), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos1[nIndex]) )
			continue;		
		// mask pos2
		if( ScanSys( strGetData, _T("BEAMPATH MASK POS2 ="), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nIndex]) )
			continue;
		// mask pos3
		if( ScanSys( strGetData, _T("BEAMPATH MASK POS3 ="), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nIndex]) )
			continue;
		// mask pos4
		if( ScanSys( strGetData, _T("BEAMPATH MASK POS4 ="), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos4[nIndex]) )
			continue;


		if( ScanSys( strGetData, _T("BEAMPATH ROTATOR ="), clsBeamPathINI.m_sBeampath.dBeamPathRotator[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("BEAMPATH TOPHAT ="), clsBeamPathINI.m_sBeampath.dBeamPathTopHat[nIndex]) )
			continue;

		// att pos1
		if( ScanSys( strGetData, _T("BEAMPATH ATT POS1 ="), clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[nIndex]) )
			continue;		
		// att pos2
		if( ScanSys( strGetData, _T("BEAMPATH ATT POS2 ="), clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[nIndex]) )
			continue;
		// z pos1
		if( ScanSys( strGetData, _T("BEAMPATH ZAxis POS1 ="), clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[nIndex]) )
			continue;		
		// z pos2
		if( ScanSys( strGetData, _T("BEAMPATH ZAxis POS2 ="), clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[nIndex]) )
			continue;
		// z pos2
		if( ScanSys( strGetData, _T("BEAMPATH USE TOP HAT ="), clsBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex]) )
		{
#ifdef __PKG_MODIFY__
			clsBeamPathINI.m_sBeampath.bBeamPathUseTophat[nIndex] = TRUE;
#endif
			continue;
		}
		// z pos2
// 		if( ScanSys( strGetData, _T("BEAMPATH ASC FILE ="),clsBeamPathINI.m_sBeampath.strBeamPathAscFile[nIndex]) )
// 			continue;
		// Voltage1
		if( ScanSys( strGetData, _T("BEAMPATH VOLTAGE 1 ="), clsBeamPathINI.m_sBeampath.dBeamPathVoltage1[nIndex]) )
			continue;
		// Voltage2
		if( ScanSys( strGetData, _T("BEAMPATH VOLTAGE 2 ="), clsBeamPathINI.m_sBeampath.dBeamPathVoltage2[nIndex]) )
			continue;
		
		if( ScanSys( strGetData, _T("BEAMPATH SHORT PATH ="), clsBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex]) )
		{
#ifdef __PKG_MODIFY__
		    clsBeamPathINI.m_sBeampath.bBeamPathLaserPath[nIndex] = TRUE;
#endif
			continue;
		}
		//if( ScanSys( strGetData, _T("BEAMPATH USE AOM ="), clsBeamPathINI.m_sBeampath.bBeamPathUseAom[nIndex]) )
		//	continue;
		

		if( ScanSys( strGetData, _T("BEAMPATH ASC FILE ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsBeamPathINI.m_sBeampath.strBeamPathAscFile[nIndex], BUFMAX, _T("%s"), strTarget );
			continue;
		}


		// power offset

		// duty
		if( ScanSys( strGetData, _T("POWER OFFSET DUTY ="), clsBeamPathINI.m_sBeampath.dPowOffsetDuty[nIndex]) )
			continue;	
		// aom delay 
		if( ScanSys( strGetData, _T("POWER OFFSET AOM DELAY ="), clsBeamPathINI.m_sBeampath.dPowOffsetAomDelay[nIndex]) )
			continue;
		// aom duty
		if( ScanSys( strGetData, _T("POWER OFFSET AOM DUTY ="), clsBeamPathINI.m_sBeampath.dPowOffsetAomDuty[nIndex]) )
			continue;

		// dual master lm %
		if( ScanSys( strGetData, _T("POWER OFFSET MASTER LM ="), clsBeamPathINI.m_sBeampath.dPowOffsetAomDual1[nIndex]) )
			continue;
		// dual slave lm %
		if( ScanSys( strGetData, _T("POWER OFFSET SLAVE LM ="), clsBeamPathINI.m_sBeampath.dPowOffsetAomDual2[nIndex]) )
			continue;
		// AOD V Offset 1
		if( ScanSys( strGetData, _T("POWER OFFSET VOLTAGE 1 ="), clsBeamPathINI.m_sBeampath.dPowOffsetVoltage1[nIndex]) )
			continue;
		// AOD V Offset 2
		if( ScanSys( strGetData, _T("POWER OFFSET VOLTAGE 2 ="), clsBeamPathINI.m_sBeampath.dPowOffsetVoltage2[nIndex]) )
			continue;

		//power compensation

		// frequency
		if( ScanSys( strGetData, _T("SELECT SHOT ="), clsBeamPathINI.m_sBeampath.nSelectShot[nIndex]) )
			continue;	

		// frequency
		if( ScanSys( strGetData, _T("POWER COMPENSATION FREQUENCY ="), clsBeamPathINI.m_sBeampath.nPowCompensationFrequency[nIndex]) )
			continue;		
		// duty
		if( ScanSys( strGetData, _T("POWER COMPENSATION DUTY ="), clsBeamPathINI.m_sBeampath.dPowCompensationDuty[nIndex]) )
			continue;		
		// aom delay
		if( ScanSys( strGetData, _T("POWER COMPENSATION AOM DELAY ="), clsBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nIndex]) )
			continue;
		// aom duty
		if( ScanSys( strGetData, _T("POWER COMPENSATION AOM DUTY ="), clsBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nIndex]) )
			continue;	
		// target min
		if( ScanSys( strGetData, _T("POWER COMPENSATION TARGET MIN ="), clsBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nIndex]) )
			continue;	
		// target max
		if( ScanSys( strGetData, _T("POWER COMPENSATION TARGET MAX ="), clsBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nIndex]) )
			continue;
		// duty offset
		if( ScanSys( strGetData, _T("POWER COMPENSATION DUTY OFFSET ="), clsBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[nIndex]) )
			continue;
		// target Value
		if( ScanSys( strGetData, _T("POWER COMPENSATION TARGET VALUE ="), clsBeamPathINI.m_sBeampath.dPowCompensationTarget[nIndex]) )
			continue;	
		// target max
		if( ScanSys( strGetData, _T("POWER COMPENSATION TARGET PERCENT ="), clsBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[nIndex]) )
			continue;
		// aom file
// 		if( ScanSys( strGetData, _T("POWER COMPENSATION AOM FILE="), clsBeamPathINI.m_sBeampath.strPowCompensationAomFile) )
// 			continue;

		if( ScanSys( strGetData, _T("POWER COMPENSATION AOM FILE ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsBeamPathINI.m_sBeampath.strPowCompensationAomFile, BUFMAX,  _T("%s"), strTarget );
			continue;
		}

		//scanner ����
		
		// duty
		if( ScanSys( strGetData, _T("SCANNER DUTY ="), clsBeamPathINI.m_sBeampath.dScannerDuty[nIndex]) )
			continue;	

		if( ScanSys( strGetData, _T("SCANNER FRQ ="), clsBeamPathINI.m_sBeampath.dScannerFrq[nIndex]) )
			continue;	


		// aom duty
		if( ScanSys( strGetData, _T("SCANNER AOM DUTY ="), clsBeamPathINI.m_sBeampath.dScannerAomDuty[nIndex]) )
			continue;		
		// aom delay
		if( ScanSys( strGetData, _T("SCANNER AOM DELAY ="), clsBeamPathINI.m_sBeampath.dScannerAomdelay[nIndex]) )
			continue;	
		// total shot
		if( ScanSys( strGetData, _T("SCANNER TOTAL SHOT ="), clsBeamPathINI.m_sBeampath.nScannerTotalShot[nIndex]) )
			continue;
		// vision cam
		if( ScanSys( strGetData, _T("SCANNER VISION CAM ="), clsBeamPathINI.m_sBeampath.nScannerVisionCam[nIndex]) )
			continue;
		// vision model size
		if( ScanSys( strGetData, _T("SCANNER VISION MODEL SIZE ="), clsBeamPathINI.m_sBeampath.dScannerVisionModelSize[nIndex]) )
			continue;	
		// accept score size
		if( ScanSys( strGetData, _T("SCANNER SCORE SIZE ="), clsBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[nIndex]) )
			continue;	
		// accept score ratio
		if( ScanSys( strGetData, _T("SCANNER SCORE RATIO ="), clsBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[nIndex]) )
			continue;
		// polarity
		if( ScanSys( strGetData, _T("SCANNER POLARITY ="), clsBeamPathINI.m_sBeampath.nScannerPolarity[nIndex]) )
			continue;	
		// contrast
		if( ScanSys( strGetData, _T("SCANNER CONTRAST ="), clsBeamPathINI.m_sBeampath.dScannerContrast[nIndex]) )
			continue;
		// brightness
		if( ScanSys( strGetData, _T("SCANNER BRIGHTNESS ="), clsBeamPathINI.m_sBeampath.dScannerBrightness[nIndex]) )
			continue;





		// ring
		if( ScanSys( strGetData, _T("SCANNER RING ="), clsBeamPathINI.m_sBeampath.nScannerRing[nIndex]) )
			continue;
		// coaxial
		if( ScanSys( strGetData, _T("SCANNER COAXIAL ="), clsBeamPathINI.m_sBeampath.nScannerCoaxial[nIndex]) )
			continue;

		// coaxial
		if( ScanSys( strGetData, _T("SCANNER IR ="), clsBeamPathINI.m_sBeampath.nScannerIR[nIndex]) )
			continue;


		// coaxial
		if( ScanSys( strGetData, _T("SCANNER IR 2 ="), clsBeamPathINI.m_sBeampath.nScannerIR[nIndex]) )
			continue;
			
		// ring 2
		if( ScanSys( strGetData, _T("SCANNER RING 2 ="), clsBeamPathINI.m_sBeampath.nScannerRing2[nIndex]) )
			continue;
		// coaxial 2
		if( ScanSys( strGetData, _T("SCANNER COAXIAL 2 ="), clsBeamPathINI.m_sBeampath.nScannerCoaxial2[nIndex]) )
			continue;



		// ring3
		if( ScanSys( strGetData, _T("SCANNER RING3 ="), clsBeamPathINI.m_sBeampath.nScannerRing3[nIndex]) )
			continue;
		// coaxial3
		if( ScanSys( strGetData, _T("SCANNER COAXIAL3 ="), clsBeamPathINI.m_sBeampath.nScannerCoaxial3[nIndex]) )
			continue;

		// coaxial3
		if( ScanSys( strGetData, _T("SCANNER IR3 ="), clsBeamPathINI.m_sBeampath.nScannerIR3[nIndex]) )
			continue;


		// ring4
		if( ScanSys( strGetData, _T("SCANNER RING4 ="), clsBeamPathINI.m_sBeampath.nScannerRing4[nIndex]) )
			continue;
		// coaxial4
		if( ScanSys( strGetData, _T("SCANNER COAXIAL4 ="), clsBeamPathINI.m_sBeampath.nScannerCoaxial4[nIndex]) )
			continue;

		// coaxial4
		if( ScanSys( strGetData, _T("SCANNER IR4 ="), clsBeamPathINI.m_sBeampath.nScannerIR4[nIndex]) )
			continue;



// 		// drill method
// 		if( ScanSys( strGetData, _T("SCANNER DRILL METHOD ="), clsBeamPathINI.m_sBeampath.nScannerDrillMethod) )
// 			continue;
		// jump delay
		if( ScanSys( strGetData, _T("SCANNER JUMP DELAY ="), clsBeamPathINI.m_sBeampath.dScannerJumpDelay) )
			continue;


		// fixed mask
		if( ScanSys( strGetData, _T("SCANNER FIXED MASK ="), clsBeamPathINI.m_sBeampath.nFixedMask) )
			continue;

		// vision cam
		if( ScanSys( strGetData, _T("HOLE VISION CAM ="), clsBeamPathINI.m_sBeampath.nHoleVisionCam[nIndex]) )
			continue;
		// vision model size
		if( ScanSys( strGetData, _T("HOLE VISION MODEL SIZE ="), clsBeamPathINI.m_sBeampath.dHoleVisionModelSize[nIndex]) )
			continue;	
		// accept score size
		if( ScanSys( strGetData, _T("HOLE SCORE SIZE ="), clsBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[nIndex]) )
			continue;	
		// accept score ratio
		if( ScanSys( strGetData, _T("HOLE SCORE RATIO ="), clsBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[nIndex]) )
			continue;
		// polarity
		if( ScanSys( strGetData, _T("HOLE POLARITY ="), clsBeamPathINI.m_sBeampath.nHolePolarity[nIndex]) )
			continue;	
		// contrast
		if( ScanSys( strGetData, _T("HOLE CONTRAST ="), clsBeamPathINI.m_sBeampath.dHoleContrast[nIndex]) )
			continue;
		// brightness
		if( ScanSys( strGetData, _T("HOLE BRIGHTNESS ="), clsBeamPathINI.m_sBeampath.dHoleBrightness[nIndex]) )
			continue;
		// ring
		if( ScanSys( strGetData, _T("HOLE RING ="), clsBeamPathINI.m_sBeampath.nHoleRing[nIndex]) )
			continue;
		// coaxial
		if( ScanSys( strGetData, _T("HOLE COAXIAL ="), clsBeamPathINI.m_sBeampath.nHoleCoaxial[nIndex]) )
			continue;
		// IR
		if( ScanSys( strGetData, _T("HOLE IR ="), clsBeamPathINI.m_sBeampath.nHoleIR[nIndex]) )
			continue;
		if( 0 == strGetData.CompareNoCase(_T("// END BEAMPATH SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}
	
	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}



BOOL CBeamPathINIFile::SaveBeamPathNIFile(CString strFilePath, DBeampathINI clsBeamPathINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;
	
	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
		//		CString strMsg;
		
		//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
		//		ErrMessage(strMsg, MB_ICONERROR);
		
		return bRet;
	}
	
	CString strSetData;
	
	strSetData.Format(_T("// START BEAMPATH INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );
	
	SaveBeamPath( sFile, clsBeamPathINI );

	
	strSetData.Format(_T("// END BEAMPATH INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	sFile.Close();
	bRet = TRUE;
	
	return bRet;
}


BOOL CBeamPathINIFile::SaveBeamPath(CStdioFile& sFile, DBeampathINI clsBeamPathINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	int nRepeatcount;


	strSetData.Format(_T("// START BEAMPATH SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	// Total count
	strSetData.Format(_T("LASTINDEX = %d\n"), clsBeamPathINI.m_sBeampath.nLastIndex);
	sFile.WriteString( (LPCTSTR)strSetData );

	nRepeatcount = clsBeamPathINI.m_sBeampath.nLastIndex;

	for(int i = 0 ;i <= nRepeatcount ;i++)
	{
		// Index
		strSetData.Format(_T("INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		//information
		// id
		clsBeamPathINI.m_sBeampath.nInfoId[i] = i;
		strSetData.Format(_T("INFO ID = %d\n"), clsBeamPathINI.m_sBeampath.nInfoId[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// name
		strSetData.Format(_T("INFO NAME = %s\n"), clsBeamPathINI.m_sBeampath.strInfoName[i]);
 		sFile.WriteString( (LPCTSTR)strSetData );
		// mask
		strSetData.Format(_T("INFO MASKSIZE = %.2f\n"), clsBeamPathINI.m_sBeampath.dInfoMaskSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//����� 

		// bet pos1
		strSetData.Format(_T("BEAMPATH BET POS1 = %.2f\n"), clsBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// bet pos2
		strSetData.Format(_T("BEAMPATH BET POS2 = %.2f\n"), clsBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// mask pos1
		strSetData.Format(_T("BEAMPATH MASK POS1 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// mask pos2
		strSetData.Format(_T("BEAMPATH MASK POS2 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// mask pos2
		strSetData.Format(_T("BEAMPATH MASK POS3 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("BEAMPATH MASK POS4 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("BEAMPATH ROTATOR = %.3f\n"), clsBeamPathINI.m_sBeampath.dBeamPathRotator[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("BEAMPATH TOPHAT = %.3f\n"), clsBeamPathINI.m_sBeampath.dBeamPathTopHat[i]);
		sFile.WriteString( (LPCTSTR)strSetData );



		// att pos1
		strSetData.Format(_T("BEAMPATH ATT POS1 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// att pos2
		strSetData.Format(_T("BEAMPATH ATT POS2 = %d\n"), clsBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// z pos1
		strSetData.Format(_T("BEAMPATH ZAxis POS1 = %.3f\n"), clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// z pos2
		strSetData.Format(_T("BEAMPATH ZAxis POS2 = %.3f\n"), clsBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
#ifdef __PKG_MODIFY__
		clsBeamPathINI.m_sBeampath.bBeamPathUseTophat[i] = TRUE;
#endif
		// use top hat
		strSetData.Format(_T("BEAMPATH USE TOP HAT = %d\n"), clsBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// Voltage1
		strSetData.Format(_T("BEAMPATH VOLTAGE 1 = %.1f\n"), clsBeamPathINI.m_sBeampath.dBeamPathVoltage1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// Voltage2
		strSetData.Format(_T("BEAMPATH VOLTAGE 2 = %.1f\n"), clsBeamPathINI.m_sBeampath.dBeamPathVoltage2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
#ifdef __PKG_MODIFY__
        clsBeamPathINI.m_sBeampath.bBeamPathLaserPath[i] = TRUE;
#endif

		strSetData.Format(_T("BEAMPATH SHORT PATH = %d\n"), clsBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//strSetData.Format(_T("BEAMPATH USE AOM = %d\n"), clsBeamPathINI.m_sBeampath.bBeamPathUseAom[i]);
		//sFile.WriteString( (LPCTSTR)strSetData );
		

		// asc file
		strSetData.Format(_T("BEAMPATH ASC FILE = %s\n"), clsBeamPathINI.m_sBeampath.strBeamPathAscFile[i]);
 		sFile.WriteString( (LPCTSTR)strSetData );

		//power offset
		//frequency 
		strSetData.Format(_T("POWER OFFSET DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		//aom delay
		strSetData.Format(_T("POWER OFFSET AOM DELAY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetAomDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		//aom duty
		strSetData.Format(_T("POWER OFFSET AOM DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetAomDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// dual master lm %
		strSetData.Format(_T("POWER OFFSET MASTER LM = %.1f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetAomDual1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// dual slave lm %
		strSetData.Format(_T("POWER OFFSET SLAVE LM = %.1f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetAomDual2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// AOD V Offset 1
		strSetData.Format(_T("POWER OFFSET VOLTAGE 1 = %.1f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetVoltage1[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// AOD V Offset 2
		strSetData.Format(_T("POWER OFFSET VOLTAGE 2 = %.1f\n"), clsBeamPathINI.m_sBeampath.dPowOffsetVoltage2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//power compensation

		//frequency
		strSetData.Format(_T("SELECT SHOT = %d\n"), clsBeamPathINI.m_sBeampath.nSelectShot[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		//frequency
		strSetData.Format(_T("POWER COMPENSATION FREQUENCY = %d\n"), clsBeamPathINI.m_sBeampath.nPowCompensationFrequency[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// duty
		strSetData.Format(_T("POWER COMPENSATION DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// aom delay
		strSetData.Format(_T("POWER COMPENSATION AOM DELAY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// aom duty
		strSetData.Format(_T("POWER COMPENSATION AOM DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// target min
		strSetData.Format(_T("POWER COMPENSATION TARGET MIN = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// target max
		strSetData.Format(_T("POWER COMPENSATION TARGET MAX = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// duty offset
		strSetData.Format(_T("POWER COMPENSATION DUTY OFFSET = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// target Value
		strSetData.Format(_T("POWER COMPENSATION TARGET VALUE = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationTarget[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// target Percent
		strSetData.Format(_T("POWER COMPENSATION TARGET PERCENT = %.2f\n"), clsBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[i]);
		sFile.WriteString( (LPCTSTR)strSetData );



		// scanner ����
		//duty
		strSetData.Format(_T("SCANNER DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("SCANNER FRQ = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerFrq[i]);
		sFile.WriteString( (LPCTSTR)strSetData );



		// aom duty
		strSetData.Format(_T("SCANNER AOM DELAY = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerAomdelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// aom delay
		strSetData.Format(_T("SCANNER AOM DUTY = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerAomDuty[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// total shot
		strSetData.Format(_T("SCANNER TOTAL SHOT = %d\n"), clsBeamPathINI.m_sBeampath.nScannerTotalShot[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// vision cam
		strSetData.Format(_T("SCANNER VISION CAM = %d\n"), clsBeamPathINI.m_sBeampath.nScannerVisionCam[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// vision medel size
		strSetData.Format(_T("SCANNER VISION MODEL SIZE = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerVisionModelSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// score size
		strSetData.Format(_T("SCANNER SCORE SIZE = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// score ratio
		strSetData.Format(_T("SCANNER SCORE RATIO = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// polarity
		strSetData.Format(_T("SCANNER POLARITY = %d\n"), clsBeamPathINI.m_sBeampath.nScannerPolarity[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// contrast
		strSetData.Format(_T("SCANNER CONTRAST = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerContrast[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// brightness
		strSetData.Format(_T("SCANNER BRIGHTNESS = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerBrightness[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// ring
		strSetData.Format(_T("SCANNER RING = %d\n"), clsBeamPathINI.m_sBeampath.nScannerRing[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial
		strSetData.Format(_T("SCANNER COAXIAL = %d\n"), clsBeamPathINI.m_sBeampath.nScannerCoaxial[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial
		strSetData.Format(_T("SCANNER IR = %d\n"), clsBeamPathINI.m_sBeampath.nScannerIR[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial
		strSetData.Format(_T("SCANNER IR 2 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerIR2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// ring 2
		strSetData.Format(_T("SCANNER RING 2 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerRing2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial 2
		strSetData.Format(_T("SCANNER COAXIAL 2 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerCoaxial2[i]);
		sFile.WriteString( (LPCTSTR)strSetData );


		// ring3
		strSetData.Format(_T("SCANNER RING3 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerRing3[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial3
		strSetData.Format(_T("SCANNER COAXIAL3 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerCoaxial3[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial3
		strSetData.Format(_T("SCANNER IR3 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerIR3[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// ring4
		strSetData.Format(_T("SCANNER RING4 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerRing4[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial4
		strSetData.Format(_T("SCANNER COAXIAL4 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerCoaxial4[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// coaxial4
		strSetData.Format(_T("SCANNER IR4 = %d\n"), clsBeamPathINI.m_sBeampath.nScannerIR4[i]);
		sFile.WriteString( (LPCTSTR)strSetData );


		// vision cam
		strSetData.Format(_T("HOLE VISION CAM = %d\n"), clsBeamPathINI.m_sBeampath.nHoleVisionCam[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// vision medel size
		strSetData.Format(_T("HOLE VISION MODEL SIZE = %.2f\n"), clsBeamPathINI.m_sBeampath.dHoleVisionModelSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// score size
		strSetData.Format(_T("HOLE SCORE SIZE = %.2f\n"), clsBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// score ratio
		strSetData.Format(_T("HOLE SCORE RATIO = %.2f\n"), clsBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// polarity
		strSetData.Format(_T("HOLE POLARITY = %d\n"), clsBeamPathINI.m_sBeampath.nHolePolarity[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// contrast
		strSetData.Format(_T("HOLE CONTRAST = %.2f\n"), clsBeamPathINI.m_sBeampath.dHoleContrast[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// brightness
		strSetData.Format(_T("HOLE BRIGHTNESS = %.2f\n"), clsBeamPathINI.m_sBeampath.dHoleBrightness[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// ring
		strSetData.Format(_T("HOLE RING = %d\n"), clsBeamPathINI.m_sBeampath.nHoleRing[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		// brightness
		strSetData.Format(_T("HOLE COAXIAL = %df\n"), clsBeamPathINI.m_sBeampath.nHoleCoaxial[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		//IR
		strSetData.Format(_T("HOLE IR = %df\n"), clsBeamPathINI.m_sBeampath.nHoleIR[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

// 	// drill method
// 	strSetData.Format(_T("SCANNER DRILL METHOD = %d\n"), clsBeamPathINI.m_sBeampath.nScannerDrillMethod);
// 		sFile.WriteString( (LPCTSTR)strSetData );
	// aom file
	strSetData.Format(_T("POWER COMPENSATION AOM FILE = %s\n"), clsBeamPathINI.m_sBeampath.strPowCompensationAomFile);
 		sFile.WriteString( (LPCTSTR)strSetData );
	// jump delay
	strSetData.Format(_T("SCANNER JUMP DELAY = %.2f\n"), clsBeamPathINI.m_sBeampath.dScannerJumpDelay);
	sFile.WriteString( (LPCTSTR)strSetData );
	// fixed mask
	strSetData.Format(_T("SCANNER FIXED MASK = %d\n"), clsBeamPathINI.m_sBeampath.nFixedMask);
	sFile.WriteString( (LPCTSTR)strSetData );

	
	strSetData.Format(_T("// END BEAMPATH SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}


void CBeamPathINIFile::WriteLog(CString strLog)
{
	CString strPathName;
	strPathName.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}