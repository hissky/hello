#if !defined(AFX_DTEMPERCOMPENSATION_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_)
#define AFX_DTEMPERCOMPENSATION_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_REPEAT_NO		20
#define MAX_GRID_NO		9
#define MAX_TEMPER_NO	30

#include "DPoint.h"

class DTemperCompensation
{
public:
	time_t	GetFireEndTime();
	time_t	t_FireEndTime;
	BOOL m_bSavedLowTemp;
	int m_nRepeatDataX[MAX_REPEAT_NO][MAX_REPEAT_NO][MAX_GRID_NO][MAX_GRID_NO]; // [Power] [repeat][x] [y] 
	int m_nRepeatDataY[MAX_REPEAT_NO][MAX_REPEAT_NO][MAX_GRID_NO][MAX_GRID_NO];
	double m_dRepeatTemper[MAX_REPEAT_NO];
	int m_nRepeatIndex;
	int m_nRepeatMax;
	int m_nPowerIndex;
	int m_nStartPower;
	int m_nStepPower;
	int m_nPower[MAX_REPEAT_NO];
	int m_nGrid;
	int m_nOffsetTIndex[MAX_TEMPER_NO];
	int m_nOffsetTMax;
	double m_dStartTemper;
	double m_dDeltaT;
	double m_dTransT;
	double m_dAutoRunStartT;
	double m_dAutoRunEndT;
	double m_dReferenceT;
	BOOL m_bRefTSet;
	BOOL m_bNoCalReturn;

	int m_nOffsetX[MAX_TEMPER_NO][MAX_GRID_NO][MAX_GRID_NO];
	int m_nOffsetY[MAX_TEMPER_NO][MAX_GRID_NO][MAX_GRID_NO];

	double m_dGradient[MAX_TEMPER_NO][MAX_REPEAT_NO][2][MAX_GRID_NO][MAX_GRID_NO];
	double m_dYIntercept[2][MAX_GRID_NO][MAX_GRID_NO];

	double m_dScannerBlockGradient[MAX_TEMPER_NO][2][MAX_GRID_NO][MAX_GRID_NO];
	double m_dSCalTemper[MAX_TEMPER_NO * MAX_REPEAT_NO];
	int m_dSCalTemperIndex;

	void GetOffsetForDeltaT(int nFieldsizeUM, int modx, int mody, int lx, int ly, int hx, int hy, int nPowerIndex, double dDeltaT, double& dXOffset, double& dYOffset);
	int GetTableNo();
	double GetAutoRunLastTemperature();
	void SetCurrentPower(int nIndex, int nPower,  int nStepPower);
	void   SetAutoRunStartTemperature(double dAutoStartT);
	void   SetAutoRunLastTemperature(double dAutoEndT);
	void   SetRefTemperature(double dRefT);
	BOOL GetIsSetRefT();
	BOOL CalLine();
	BOOL SetScannerBlockOneData(double dTemper, DPOINT* dOffset);//double* dX, double* dY);
	BOOL SetOneData(double dTemper, DPOINT* dOffset);//double* dX, double* dY);
	BOOL SetDataInfo(int nGridNo, double dDeltaT, int nRepeatNo, double dTransT);
	BOOL GetCompenPosition(double dCurrTemper, double dSCalTemper, double dSCalEndTemper, int& nXLsb, int& nYLsb, int nFieldsizeUM, double dTemerMin, double dTemperMax, double dPower);
	BOOL LoadTemperCompenFile(CString strFile);
	BOOL SaveTemperCompenFile(CString strFile);
	void SetScalTemperature(double dVal);
	void InitData();
	DTemperCompensation(void);
	~DTemperCompensation(void);
};
#endif // !defined(AFX_DTEMPERCOMPENSATION_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_)

