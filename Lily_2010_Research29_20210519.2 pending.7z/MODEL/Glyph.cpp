// Glyph.cpp: implementation of the Glyph class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "Glyph.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL(Glyph, CObject, 1)

Glyph::Glyph()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	
//	m_bSelect = FALSE;
}

Glyph::~Glyph()
{

}

void Glyph::Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode)
{
	
}

void Glyph::DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode)
{
	
}

BOOL Glyph::IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	return TRUE;
}

BOOL Glyph::IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView)
{
	return TRUE;	
}

void Glyph::Flip(BOOL bX)
{
	
}

void Glyph::Rotate(double dDeg)
{
	 
}

void Glyph::Move(int nX, int nY)
{

}

//BOOL Glyph::IsSelected()
//{
//	return m_bSelect;
//}

BOOL Glyph::IsFidHoleGet(BOOL &bFidList, CPoint pt, int nTolerence, BOOL &bSkiving)
{
	return FALSE;
}

BOOL Glyph::AddFiducial(CPoint pt, int nTolerence, int nFidKind)
{
	return FALSE;
}

BOOL Glyph::DelFiducial(CPoint pt, int nTolerence)
{
	return FALSE;
}

BOOL Glyph::OnSetRefFid(CPoint pt, int nTolerence)
{
	return FALSE;
}

void Glyph::UnSelectAll()
{
	return;
/*
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->bSelect)
			pData->bSelect = FALSE;
	}

	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		if(pLine->bSelect)
			pLine->bSelect = FALSE;
	}
*/
}


