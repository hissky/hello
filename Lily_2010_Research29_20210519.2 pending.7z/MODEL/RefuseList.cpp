// RefuseList.cpp: implementation of the CRefuseList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "RefuseList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRefuseList::CRefuseList()
{

}

CRefuseList::~CRefuseList()
{

}

void CRefuseList::Initialize()
{
	m_nTotalListNo = 0;
}

BOOL CRefuseList::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	POSITIONDATA posData;
	CString str;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			m_RefuseData.RemoveAll();
			
			ar >> str;
			ar >> m_nTotalListNo;
			
			for(int i=0; i<m_nTotalListNo; i++)
			{
				ar >> str;
				ar >> posData.nNo;
				ar >> posData.dPosX;
				ar >> posData.dPosY;
				
				m_RefuseData.AddTail(posData);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
		return TRUE;
}

BOOL CRefuseList::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	POSITIONDATA posData;
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			ar << _T("\n");
			ar << _T("Pos Count = ") << m_RefuseData.GetCount() << _T("\n");
			
			POSITION pos = m_RefuseData.GetHeadPosition();
			while(pos)
			{
				posData = m_RefuseData.GetNext(pos);
				ar << _T("\n");
				ar << _T("Pos No = ") << posData.nNo << _T("\n");
				ar << _T("Pos X = ") << posData.dPosX << _T("\n");
				ar << _T("Pos Y = ") << posData.dPosY << _T("\n");
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
		return TRUE;
}
