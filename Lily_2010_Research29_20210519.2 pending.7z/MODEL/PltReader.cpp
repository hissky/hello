// PltReader.cpp: implementation of the PltReader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "PltReader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Pen State
#define PU	0
#define PD	1
#define PA	2
#define PR	3
// LSB range
#define LSB_MAX		SHRT_MAX
#define LSB_MIN		SHRT_MIN
#define LSB_RANGE	USHRT_MAX
// PLT Type
#define PLTTYPE_SHPGL	0	// plt file for AutoCAD R14
#define PLTTYPE_LHPGL	1	// plt file for AutoCAD 2000
#define PLTTYPE_COREL	2	// plt file for CorelDraw

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

PltReader::PltReader()
{
	m_pGlyphPlt = NULL;
}

PltReader::~PltReader()
{

}

BOOL PltReader::ReadFile(LPCTSTR lpszFileName, GlyphPlt *pGlyphPlt, int nFieldSize)
{
/*	m_pGlyphPlt = pGlyphPlt;

	if (NULL == m_pGlyphPlt)
		return FALSE;

	double dRatio = nFieldSize / 65535.0;
	
	m_pGlyphPlt->m_LineData.RemoveAll();

	TCHAR ch;
	
	CFile readFile;
	FILE* fp;
	
	CString strTemp =(LTCTSR)_T("");
	strTemp.Format(_T("%sTemp"), (CString)lpszFileName);
	if(NULL == fopen_s(&fp, strTemp, _T("w")))
		return FALSE;

	if(!readFile.Open(lpszFileName, CFile::modeRead))
		return FALSE;

	BOOL chNum = FALSE;
	while(readFile.Read(&ch, sizeof(TCHAR)))
	{
		if(ch == _T(' ') && chNum)
			ch = _T(',');

		if(_istdigit(ch) || _T('-') == ch || _T('U') == ch || _T('D') == ch || _T('A') == ch || _T('R') == ch || _T('P') == ch || _T(',') == ch || ';' == ch)
			fprintf(fp, _T("%c"), ch);

		if(_istdigit(ch))
			chNum = TRUE;
		else
			chNum = FALSE;
	}
	readFile.Close();
	fclose(fp);

	
	// ������ �о�´�.
	CFile File;
	CString strBuffer;
	if(!File.Open(strTemp, CFile::modeRead))
		return FALSE;
	
	UINT nPLTType = PLTTYPE_SHPGL;
	
	int nPUPD = PU;
	int nPAPR = PA;
	int nX, nY, nPrevX, nPrevY, nCurrX, nCurrY;
	CRect rect(LSB_MIN, LSB_MAX, LSB_MAX, LSB_MIN);
	
	File.Read(&ch, sizeof(TCHAR));
	while(TRUE)
	{
		if (_T('P') == ch)
		{
			if (!File.Read(&ch, sizeof(TCHAR)))
				break;
			
			if      (_T('U') == ch) { nPUPD = PU; }
			else if (_T('D') == ch) { nPUPD = PD; }
			else if (_T('A') == ch)	{ nPAPR = PA; }
			else if (_T('R') == ch)	{ nPAPR = PR; }
			else    { if (!File.Read(&ch, sizeof(TCHAR))) break; continue; }
			
			while(TRUE)
			{
				// X�� �д´�.
				CString strX;
				while(TRUE)
				{
					if(!File.Read(&ch, sizeof(TCHAR)))	// �� ���ڸ� �д´�.
						break;
					
					if(_istcntrl(ch))					// ���ڰ� ��Ʈ�� ���ڸ� continue
						continue;

					if(VK_SPACE == ch)
						break;
					
					if(!_istdigit(ch) && _T('-') != ch)		// ���ڳ� -�� �ƴϸ� break
						break;
					
					strX += ch;
				}
				nX = _ttoi(strX);						// X�� �д´� �Ϸ�
				
				// X���� Y�� �Ѿ�� ����ǥ
				if (_T(' ') == ch)
				{
					nPLTType = PLTTYPE_COREL;
				}
				else if (_T(',') == ch)
				{
				}
				else
				{
					break;
				}
				
				// Y�� �д´�.
				CString strY;
				while(TRUE)
				{
					if(!File.Read(&ch, sizeof(TCHAR)))	// �� ���ڸ� �д´�.
						break;
					
					if(_istcntrl(ch))					// ���ڰ� ��Ʈ�� ���ڸ� continue
						continue;

					if(VK_SPACE == ch)
						break;
					
					if(!_istdigit(ch) && _T('-') != ch)		// ���ڳ� -�� �ƴϸ� break
						break;
					
					strY += ch;
				}
				nY = _ttoi(strY);						// Y�� �д´� �Ϸ�

				// ���� ���� ���Ѵ�.
				if(PA == nPAPR)
				{
					nCurrX = nX;
					nCurrY = nY;
				}
				else if(PR == nPAPR)
				{
					nCurrX += nX;
					nCurrY += nY;
				}
				
				// LSB ������ ��� ������ offset ��Ų��.
				if (PLTTYPE_COREL != nPLTType)
				{
					if      (nCurrX > LSB_MAX) nCurrX -= LSB_RANGE;
					else if (nCurrX < LSB_MIN) nCurrX += LSB_RANGE;
					if      (nCurrY > LSB_MAX) nCurrY -= LSB_RANGE;
					else if (nCurrY < LSB_MIN) nCurrY += LSB_RANGE;
				}

				// Line�� �߰��Ѵ�.
				if (PD == nPUPD)
				{
					LPLINEDATA pLine = new LINEDATA();
					pLine->nToolNo = 1;
					pLine->npStartPos.x = (int)(nPrevX * dRatio);
					pLine->npStartPos.y = (int)(nPrevY * dRatio);
					pLine->npEndPos.x = (int)(nCurrX * dRatio);
					pLine->npEndPos.y = (int)(nCurrY * dRatio);
					pLine->nRefNo = 1;
//					pLine->bSelect = FALSE;

					m_pGlyphPlt->m_LineData.AddTail(pLine);

					if(m_pGlyphPlt->m_nMaxX < pLine->npStartPos.x) m_pGlyphPlt->m_nMaxX = pLine->npStartPos.x;
					if(m_pGlyphPlt->m_nMinX > pLine->npStartPos.x) m_pGlyphPlt->m_nMinX = pLine->npStartPos.x;
					if(m_pGlyphPlt->m_nMaxY < pLine->npStartPos.y) m_pGlyphPlt->m_nMaxY = pLine->npStartPos.y;
					if(m_pGlyphPlt->m_nMinY > pLine->npStartPos.y) m_pGlyphPlt->m_nMinY = pLine->npStartPos.y;

					if(m_pGlyphPlt->m_nMaxX < pLine->npEndPos.x) m_pGlyphPlt->m_nMaxX = pLine->npEndPos.x;
					if(m_pGlyphPlt->m_nMinX > pLine->npEndPos.x) m_pGlyphPlt->m_nMinX = pLine->npEndPos.x;
					if(m_pGlyphPlt->m_nMaxY < pLine->npEndPos.y) m_pGlyphPlt->m_nMaxY = pLine->npEndPos.y;
					if(m_pGlyphPlt->m_nMinY > pLine->npEndPos.y) m_pGlyphPlt->m_nMinY = pLine->npEndPos.y;
				}

				// Prev ���� �����Ѵ�.
				nPrevX = nCurrX;
				nPrevY = nCurrY;
				
				// Y���� �״��� ���� X�� �Ѿ�� ����ǥ
				if (_T(',') == ch)
				{
					nPLTType = PLTTYPE_LHPGL;
				}
				else
				{
					break;
				}
			}
		}
		else
		{
			if (_T('\r') == ch || _T('\n') == ch)
			{
				nPLTType = PLTTYPE_COREL;
			}

			if(!File.Read(&ch, sizeof(TCHAR)))
				break;
		}
	}	
	File.Close();	// ���� ���� �Ϸ�
	CFile::Remove(strTemp);
*/	return TRUE;
}
