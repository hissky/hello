#ifndef __INC_AVI_MODULE_INTERFACE_HDR__
#define __INC_AVI_MODULE_INTERFACE_HDR__

#define DLLAPI	__declspec( dllexport )

namespace AVIA 
{
	// Initialize Power Supply.
	DLLAPI void InitializeAVIAPower();

	// Destory Power Supply
	DLLAPI void DestroyAVIAPower();

	// Show Power Supply Dialog
	DLLAPI void AVIALaser_DoModal(int nSysLevel);

	// Change Serial Port
	DLLAPI BOOL AVIAChangePort();

	// Check Temperature Ready 
	// TRUE : All Temperature Ready
	// FALSE : All Temperature Not Ready
	DLLAPI BOOL IsAllTempReady();

	// Check Power Supply Error
	// TRUE : Error, szMsg have error string
	// FALSE : No Error
	DLLAPI BOOL IsError(char* szMsg);
	DLLAPI BOOL IsError(CString& strMsg);

	// GET FREQUENCE
	DLLAPI long GetPulseRate();

	// Get Use Laser Gate Signal
	DLLAPI BOOL GetLaserGate();

	// Pulse On/Off Control
	DLLAPI void	SetPulseControl(BOOL bOnOff);
	DLLAPI BOOL GetPulseControl();

	// Set Change Parameter Mode (laser parameter query rapidly in auto running mode)
	DLLAPI BOOL SetChangeParamSection();
	DLLAPI BOOL ResetChangeParamSection();

	// Set Laser Parameter
	DLLAPI BOOL	SetAviaLaserParam(double dCurrent, long nPulseRate, int nThermaTrack);
	DLLAPI BOOL SetAviaLaserParam(char* szCurrent, char* szPulseRate, char* szThermaTrack);
	DLLAPI BOOL SetAviaLaserParam(CString strCurrent, CString strPulseRate, CString strThermaTrack);

	// Get Laser Param
	DLLAPI BOOL GetAviaLaserParam(double* pPower, double* pCurrent, long* pPulseRate, int* pThermaTrack);
	DLLAPI BOOL GetAviaLaserParam(char* szPower, char* szCurrent, char* szPulseRate, char* szThermaTrack);
	DLLAPI BOOL GetAviaLaserParam(CString& strPower, CString& strCurrent, CString& strPulseRate, CString& strThermaTrack);

	// Get Feedback Laser Parameter
	DLLAPI BOOL GetFeedbackAviaLaserParam(double* pPower, double* pCurrentPer, double* pCurrentAmp, long* pPulseRate, int* nThermaTrack);
	DLLAPI BOOL GetFeedbackAviaLaserParam(char* szPower, char* szCurrentPer, char* pCurrentAmp, char* szPulseRate, char* szThermaTrack);
	DLLAPI BOOL GetFeedbackAviaLaserParam(CString strPower, CString& strCurrentPer, CString& strCurrentAmp, CString& strPulseRate, CString& strThermaTrack);

	// Pop Up Parameter Table Dialog
	DLLAPI BOOL ShowParameterTableDlg(char* szPower, char* szCurrent, char* szPulseRate, char* szThermaTrackPos);
	
	DLLAPI BOOL	AVIAisPowerOn();
	DLLAPI BOOL	AVIAisShutterOpen();
	DLLAPI BOOL	AVIAisPulseOpen();
	
	DLLAPI void AVIAPowerOn(BOOL bFlag);
	DLLAPI void AVIAShutterOpen(BOOL bFlag);
	DLLAPI void AVIAPulseOpen(BOOL bFlag);
	DLLAPI int GetAVIATriggerMode();
}

using namespace AVIA;

#endif // __INC_AVI_MODULE_INTERFACE_HDR__