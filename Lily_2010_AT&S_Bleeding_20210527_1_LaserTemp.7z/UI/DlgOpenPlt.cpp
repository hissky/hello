// DlgOpenPlt.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgOpenPlt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenPlt dialog


CDlgOpenPlt::CDlgOpenPlt(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOpenPlt::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOpenPlt)
	m_nFieldSize = 50000;
	//}}AFX_DATA_INIT
}


void CDlgOpenPlt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOpenPlt)
	DDX_Text(pDX, IDC_EDT_FIELD_SIZE, m_nFieldSize);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgOpenPlt, CDialog)
	//{{AFX_MSG_MAP(CDlgOpenPlt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOpenPlt message handlers

void CDlgOpenPlt::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	CDialog::OnOK();
}
