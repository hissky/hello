#pragma once
#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "..\MODEL\DProject.h"

// CDlgFiducialView dialog

class CDlgFiducialView : public CFormView
{
	DECLARE_DYNCREATE(CDlgFiducialView)

public:
	BOOL	m_bFiducialAllViewDlgShow; // fiducial all view dlg�� ���µ� ��� side vision ��ġ�� fiducial all dlg�� ����Ǿ� �Ѵ�.
	CDlgFiducialView();   // standard constructor
	virtual ~CDlgFiducialView();

	void ResetAllBitMap();
	void SetBitMap(HBITMAP hBitmap, BOOL bFirst, int nFidIndex, int nFidBlock);
	HBITMAP m_hBitmap[MAX_FID_BLOCK][2][4]; //fidblock, master/slave, index
	int m_nFocusUIIndex;
	void DrawFidFimage();
	void DrawBmp(CDC *pDC, CRect rc, BOOL bFirst, int nIndex, int nFidBlock);
	void GetVisionRect(CRect &cRect);

// Dialog Data
	enum { IDD = IDD_DLG_FIDUCIAL_VIEWER };

	void SetReSize(BOOL bExt);

	CSize m_siExtendSize;
	CSize m_siNormalSize;
	virtual void OnInitialUpdate();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CDlgFiducialView)

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:

	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	CComboBox m_cmbSelectFidBlock;
	afx_msg void OnSetFocus(CWnd* pOldWnd);
};
