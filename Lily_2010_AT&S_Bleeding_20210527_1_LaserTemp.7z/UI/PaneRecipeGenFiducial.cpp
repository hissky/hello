// PaneRecipeGenFiducial.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenFiducial.h"

#include "..\model\DProject.h"
#include "..\model\DSystemINI.h"
#include "..\model\deasydrillerini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducial

IMPLEMENT_DYNCREATE(CPaneRecipeGenFiducial, CFormView)

CPaneRecipeGenFiducial::CPaneRecipeGenFiducial()
	: CFormView(CPaneRecipeGenFiducial::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenFiducial)
	m_nPolarity			= 0;
	//}}AFX_DATA_INIT
	m_nModelType		= 1;
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = 150;
		m_nRing[i] = 150;
		m_dContrast[i] = 0.6;
		m_dBrightness[i] = 0.6;
	}
	m_bSkiving = FALSE;
	m_strPath = _T("");
}

CPaneRecipeGenFiducial::~CPaneRecipeGenFiducial()
{
}

void CPaneRecipeGenFiducial::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenFiducial)
	DDX_Control(pDX, IDC_EDIT_JOB_FILE, m_edtPath);
	DDX_Control(pDX, IDC_EDIT_VISION_ORIENTATION, m_edtOrientation);
	DDX_Control(pDX, IDC_STATIC_PIC, m_stcPic);
	DDX_Control(pDX, IDC_EDIT_SIZE_C, m_edtSizeC);
	DDX_Control(pDX, IDC_EDIT_SIZE_B, m_edtSizeB);
	DDX_Control(pDX, IDC_EDIT_SIZE_A, m_edtSizeA);
	DDX_Control(pDX, IDC_EDIT_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_CONTRAST, m_edtContrast);
	DDX_Control(pDX, IDC_EDIT_COAXIAL, m_edtCoaxial);
	DDX_Control(pDX, IDC_EDIT_BRIGHTNESS, m_edtBrightness);
	DDX_Control(pDX, IDC_EDIT_ASPECTRATIO, m_edtAspectRatio);
	DDX_Control(pDX, IDC_EDIT_ANGLE, m_edtAngle);
	DDX_Control(pDX, IDC_COMBO_TYPE, m_cmbType);
	DDX_Radio(pDX, IDC_RADIO_DARK, m_nPolarity);
	DDX_Control(pDX, IDC_COMBO_CAM_NO, m_cmbCamNo);
	DDX_Control(pDX, IDC_BUTTON_JOB_FILE_OPEN, m_btnJobFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenFiducial, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenFiducial)
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_COMBO_TYPE, OnSelchangeComboType)
	ON_CBN_SELCHANGE(IDC_COMBO_CAM_NO, OnSelchangeComboCamNo)
	ON_EN_KILLFOCUS(IDC_EDIT_COAXIAL, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_RING, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_CONTRAST, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_BRIGHTNESS, OnKillfocusEdit)
	ON_BN_CLICKED(IDC_BUTTON_JOB_FILE_OPEN, OnButtonJobFileOpen)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducial diagnostics

#ifdef _DEBUG
void CPaneRecipeGenFiducial::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenFiducial::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducial message handlers

void CPaneRecipeGenFiducial::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBitmap();
	InitBtnControl();
	InitEditControl();
	InitStaticControl();
	InitComboControl();
	
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
	{
		GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
	}

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
		ChangeControl(FALSE);
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		ChangeControl(FALSE);
	}
	else
	{
		ChangeControl(TRUE);
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
			GetDlgItem(IDC_STATIC_ASPECT_RATIO)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_ASPECTRATIO)->EnableWindow(FALSE);
		}
	}
}

BOOL CPaneRecipeGenFiducial::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneRecipeGenFiducial::InitBitmap()
{
	m_imgAnnulus.LoadBitmap(IDB_ANNULUS);
	m_imgCircle.LoadBitmap(IDB_CIRCLE);
	m_imgCross.LoadBitmap(IDB_CROSS);
	m_imgDiamond.LoadBitmap(IDB_DIAMOND);
	m_imgDouble.LoadBitmap(IDB_DOUBLERECT);
	m_imgRect.LoadBitmap(IDB_RECT);
	m_imgTriangle.LoadBitmap(IDB_TRIANGLE);
	m_imgUserImage.LoadBitmap(IDB_USER_IMAGE);
}

void CPaneRecipeGenFiducial::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_RADIO_DARK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LIGHT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_NONE)->SetFont( &m_fntBtn );

	m_fntBtn2.CreatePointFont(120, "Arial Bold");
	
	m_btnJobFile.SetFont( &m_fntBtn2 );
	m_btnJobFile.SetFlat( FALSE );
	m_btnJobFile.EnableBallonToolTip();
	m_btnJobFile.SetToolTipText( _T("Job FilePath Selection") );
	m_btnJobFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobFile.SetBtnCursor(IDC_HAND_1);
}

void CPaneRecipeGenFiducial::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Size A
	m_edtSizeA.SetFont( &m_fntEdit );
	m_edtSizeA.SetForeColor( BLACK_COLOR );
	m_edtSizeA.SetBackColor( WHITE_COLOR );
	m_edtSizeA.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeA.SetWindowText( _T("0.0") );

	// Size B
	m_edtSizeB.SetFont( &m_fntEdit );
	m_edtSizeB.SetForeColor( BLACK_COLOR );
	m_edtSizeB.SetBackColor( WHITE_COLOR );
	m_edtSizeB.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeB.SetWindowText( _T("0.0") );

	// Size C
	m_edtSizeC.SetFont( &m_fntEdit );
	m_edtSizeC.SetForeColor( BLACK_COLOR );
	m_edtSizeC.SetBackColor( WHITE_COLOR );
	m_edtSizeC.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeC.SetWindowText( _T("0.0") );

	// Size
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetForeColor( BLACK_COLOR );
	m_edtSize.SetBackColor( WHITE_COLOR );
	m_edtSize.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSize.SetWindowText( _T("0.0") );

	m_edtOrientation.SetFont( &m_fntEdit );
	m_edtOrientation.SetReceivedFlag( 1 );
	m_edtOrientation.SetWindowText( _T("0") );

	// Angle
	m_edtAngle.SetFont( &m_fntEdit );
	m_edtAngle.SetForeColor( BLACK_COLOR );
	m_edtAngle.SetBackColor( WHITE_COLOR );
	m_edtAngle.SetReceivedFlag( 3 ); // Floating-Point
	m_edtAngle.SetWindowText( _T("0.0") );

	// Aspect Ratio
	m_edtAspectRatio.SetFont( &m_fntEdit );
	m_edtAspectRatio.SetForeColor( BLACK_COLOR );
	m_edtAspectRatio.SetBackColor( WHITE_COLOR );
	m_edtAspectRatio.SetReceivedFlag( 3 ); // Floating-Point
	m_edtAspectRatio.SetWindowText( _T("0.0") );

	// Coaxial
	m_edtCoaxial.SetFont( &m_fntEdit );
	m_edtCoaxial.SetForeColor( BLACK_COLOR );
	m_edtCoaxial.SetBackColor( WHITE_COLOR );
	m_edtCoaxial.SetReceivedFlag( 1 ); // Floating-Point
	m_edtCoaxial.SetWindowText( _T("150") );

	// Ring
	m_edtRing.SetFont( &m_fntEdit );
	m_edtRing.SetForeColor( BLACK_COLOR );
	m_edtRing.SetBackColor( WHITE_COLOR );
	m_edtRing.SetReceivedFlag( 1 ); // Floating-Point
	m_edtRing.SetWindowText( _T("150") );

	// Contrast
	m_edtContrast.SetFont( &m_fntEdit );
	m_edtContrast.SetForeColor( BLACK_COLOR );
	m_edtContrast.SetBackColor( WHITE_COLOR );
	m_edtContrast.SetReceivedFlag( 3 ); // Floating-Point
	m_edtContrast.SetWindowText( _T("0.5") );

	// Brightness
	m_edtBrightness.SetFont( &m_fntEdit );
	m_edtBrightness.SetForeColor( BLACK_COLOR );
	m_edtBrightness.SetBackColor( WHITE_COLOR );
	m_edtBrightness.SetReceivedFlag( 3 ); // Floating-Point
	m_edtBrightness.SetWindowText( _T("0.5") );

	m_fntEdit2.CreatePointFont(120, "Arial Bold");

	// Job File Path
	m_edtPath.SetFont( &m_fntEdit2 );
	m_edtPath.SetForeColor( BLACK_COLOR );
	m_edtPath.SetBackColor( WHITE_COLOR );
	m_edtPath.SetWindowText( (LPCTSTR)m_strPath );
}

void CPaneRecipeGenFiducial::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Camera No
	GetDlgItem(IDC_STATIC_CAMERA)->SetFont( &m_fntStatic );

	// Model
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_B)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ORIENTATION)->SetFont( &m_fntStatic );

	// Accept Score
	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CAM)->SetFont( &m_fntStatic );
	// Light
	GetDlgItem(IDC_STATIC_LIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );

	// Contrast & Brightness
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONTRAST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->SetFont( &m_fntStatic );

	// JobFile
	GetDlgItem(IDC_STATIC_JOB_FILE)->SetFont( &m_fntStatic );
}

void CPaneRecipeGenFiducial::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbCamNo.SetFont( &m_fntCombo );
	m_cmbCamNo.SetCurSel( 0 );
	SetValue( 0 );

	m_cmbType.SetFont( &m_fntCombo );
	m_cmbType.SetCurSel( m_nModelType );
	SelectPic( m_nModelType );
}

HBRUSH CPaneRecipeGenFiducial::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MODEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POLARITY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAM)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_JOB_FILE)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );

	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneRecipeGenFiducial::SelectPic(int nType)
{
	switch( nType )
	{
	case 0 : // Annulus
		m_stcPic.SetBitmap( m_imgAnnulus );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 1 : // Circle
		m_stcPic.SetBitmap( m_imgCircle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 2 : // Cross
		m_stcPic.SetBitmap( m_imgCross );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( TRUE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 3 : // Diamond
		m_stcPic.SetBitmap( m_imgDiamond );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 4 : // Double Rectangle
		m_stcPic.SetBitmap( m_imgDouble );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 5 : // Rectangle
		m_stcPic.SetBitmap( m_imgRect );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 6 : // Triangle
		m_stcPic.SetBitmap( m_imgTriangle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 7 : // User Image
		m_stcPic.SetBitmap( m_imgUserImage );
		m_edtSizeA.EnableWindow( FALSE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	}
}

void CPaneRecipeGenFiducial::OnSelchangeComboType() 
{
	m_nModelType = m_cmbType.GetCurSel();

	SelectPic( m_nModelType );
}

void CPaneRecipeGenFiducial::SetValue(int nNumber)
{
	CString str1, str2, str3, str4;
	str1.Format(_T("%d"), m_nCoaxial[nNumber]);
	str2.Format(_T("%d"), m_nRing[nNumber]);
	str3.Format(_T("%.1f"), m_dContrast[nNumber]);
	str4.Format(_T("%.1f"), m_dBrightness[nNumber]);

	m_edtCoaxial.SetWindowText(str1);
	m_edtRing.SetWindowText(str2);
	m_edtContrast.SetWindowText(str3);
	m_edtBrightness.SetWindowText(str4);	

	UpdateData(FALSE);
}

void CPaneRecipeGenFiducial::OnSelchangeComboCamNo() 
{
	SetValue( m_cmbCamNo.GetCurSel() );
}

void CPaneRecipeGenFiducial::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

BOOL CPaneRecipeGenFiducial::GetData(DProject &tempDProject)
{
	UpdateData(TRUE);
	CString str;
	double dTempVal;
	int	nTempVal;

	m_edtPath.GetWindowText(str);
	if(str.GetLength() < 1 && gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		m_edtPath.SetFocus();
		ErrMessage(_T("Select Job File"));
		return FALSE;
	}
	else if(str.GetLength() < 1 && gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		m_edtPath.SetFocus();
		ErrMessage(_T("Select Job File"));
		return FALSE;
	}
	lstrcpy(tempDProject.m_szJobFilePath, (LPCSTR)str);

	tempDProject.m_FidInfo[m_bSkiving].nModelType = (long)m_nModelType;
	
	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
	{
		m_edtSizeA.SetFocus();
		ErrMessage(_T("0 < SizeA <= 5(mm)"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dSizeA = (float)dTempVal;

	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
	{
		m_edtSizeB.SetFocus();
		ErrMessage(_T("0 < SizeB <= 5(mm)"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dSizeB = (float)dTempVal;

	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
	{
		m_edtSizeC.SetFocus();
		ErrMessage(_T("0 < SizeC <= 5(mm)"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dSizeC = (float)dTempVal;

	tempDProject.m_FidInfo[m_bSkiving].nPolarity = (long)m_nPolarity;

	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtSize.SetFocus();
		ErrMessage(_T("0 <= Size <= 100(%)"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dScoreSize = nTempVal;
	
	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_ANGLE || nTempVal < 0) 
	{
		m_edtAngle.SetFocus();
		ErrMessage(_T("0 <= Angle <= 360"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dScoreAngle = nTempVal;

	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
		return FALSE;
	}
	tempDProject.m_FidInfo[m_bSkiving].dAspectRatio = nTempVal;
	
	for(int i=0; i<4; i++)
	{
		tempDProject.m_FidInfo[m_bSkiving].nCoaxial[i] = m_nCoaxial[i];
		tempDProject.m_FidInfo[m_bSkiving].nRing[i] = m_nRing[i];
		tempDProject.m_FidInfo[m_bSkiving].dBrightness[i] = m_dBrightness[i];
		tempDProject.m_FidInfo[m_bSkiving].dContrast[i] = m_dContrast[i];
	}
	
	return TRUE;
}

BOOL CPaneRecipeGenFiducial::SetData()
{
	CString str;

	m_edtPath.SetWindowText((CString)gDProject.m_szJobFilePath);

	m_nModelType = (int)gDProject.m_FidInfo[m_bSkiving].nModelType;
	m_cmbType.SetCurSel(m_nModelType);
	SelectPic( m_nModelType );

	str.Format(_T("%.2f"), gDProject.m_FidInfo[m_bSkiving].dSizeA);
	m_edtSizeA.SetWindowText(str);

	str.Format(_T("%.2f"), gDProject.m_FidInfo[m_bSkiving].dSizeB);
	m_edtSizeB.SetWindowText(str);

	str.Format(_T("%.2f"), gDProject.m_FidInfo[m_bSkiving].dSizeC);
	m_edtSizeC.SetWindowText(str);

	m_nPolarity = (int)gDProject.m_FidInfo[m_bSkiving].nPolarity;

	str.Format(_T("%.0f"), gDProject.m_FidInfo[m_bSkiving].dScoreSize);
	m_edtSize.SetWindowText(str);

	str.Format(_T("%.0f"), gDProject.m_FidInfo[m_bSkiving].dScoreAngle);
	m_edtAngle.SetWindowText(str);
	
	str.Format(_T("%.0f"), gDProject.m_FidInfo[m_bSkiving].dAspectRatio);
	m_edtAspectRatio.SetWindowText(str);

	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = gDProject.m_FidInfo[m_bSkiving].nCoaxial[i];
		m_nRing[i] = gDProject.m_FidInfo[m_bSkiving].nRing[i];
		m_dBrightness[i] = gDProject.m_FidInfo[m_bSkiving].dBrightness[i];
		m_dContrast[i] = gDProject.m_FidInfo[m_bSkiving].dContrast[i];
	}

	str.Format(_T("%d"), m_nCoaxial[m_cmbCamNo.GetCurSel()]);
	m_edtCoaxial.SetWindowText(str);

	str.Format(_T("%d"), m_nRing[m_cmbCamNo.GetCurSel()]);
	m_edtRing.SetWindowText(str);

	str.Format(_T("%.1f"), m_dBrightness[m_cmbCamNo.GetCurSel()]);
	m_edtBrightness.SetWindowText(str);

	str.Format(_T("%.1f"), m_dContrast[m_cmbCamNo.GetCurSel()]);
	m_edtContrast.SetWindowText(str);

	UpdateData(FALSE);
	return TRUE;
}

void CPaneRecipeGenFiducial::OnKillfocusEdit()
{
	UpdateData(TRUE);

	CString str;
	int nTempVal;
	double dTempVal;
	int nCam = m_cmbCamNo.GetCurSel();

	m_edtCoaxial.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nCoaxial[nCam] = nTempVal;
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nRing[nCam] = nTempVal;
	
	m_edtBrightness.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dBrightness[nCam] = dTempVal;
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dContrast[nCam] = dTempVal;
}

void CPaneRecipeGenFiducial::OnButtonJobFileOpen()
{
	TCHAR BASED_CODE szFilter[] = _T("Job Files (*.Job)|*.job|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.Job"), NULL, dwFlags, szFilter);
	
	CString strPath;
	strPath.Format(_T("%s\\JobFile\\"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	dlg.m_ofn.lpstrInitialDir = strPath;
	
	if(IDOK != dlg.DoModal())
		return;

	m_strPath = dlg.GetPathName();

	m_edtPath.SetWindowText(m_strPath);
}

void CPaneRecipeGenFiducial::ChangeControl(BOOL bUse)
{
	GetDlgItem(IDC_COMBO_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_C)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_DARK)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_NONE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_ANGLE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_ASPECTRATIO)->ShowWindow(bUse);
	GetDlgItem(IDC_COMBO_CAM_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_BRIGHTNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C_MM)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_PIC)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ANGLE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_SIZE_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ANGLE_DEG)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CAMERA)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CONTRAST_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_BRIGHTNESS_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CAM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->ShowWindow(bUse);

	GetDlgItem(IDC_STATIC_JOB_FILE)->ShowWindow(!bUse);
	GetDlgItem(IDC_EDIT_JOB_FILE)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN)->ShowWindow(!bUse);
	
	if(!bUse)
	{
		CRect rtPos1, rtPos2;
		GetDlgItem(IDC_STATIC_LIGHT)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_STATIC_MODEL)->GetWindowRect( rtPos2 );
		rtPos2.top = rtPos2.top - 29;
		GetDlgItem(IDC_STATIC_LIGHT)->MoveWindow( rtPos2.left - 32, rtPos2.top, rtPos2.Width(), rtPos1.Height(), TRUE );

		GetDlgItem(IDC_STATIC_COAXIAL)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_STATIC_TYPE)->GetWindowRect( rtPos2 );
		rtPos2.left = rtPos2.left - 32;
		rtPos2.top = rtPos2.top - 29;
		GetDlgItem(IDC_STATIC_COAXIAL)->MoveWindow( rtPos2.left, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		int nWidth = rtPos1.Width() + 15;
		GetDlgItem(IDC_EDIT_COAXIAL)->MoveWindow( rtPos2.left + nWidth, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		GetDlgItem(IDC_STATIC_RING)->MoveWindow( rtPos2.left + nWidth * 2, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		GetDlgItem(IDC_EDIT_COAXIAL)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_EDIT_RING)->MoveWindow( rtPos2.left + nWidth * 3, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
	}
}

void CPaneRecipeGenFiducial::SetSkiving(BOOL bSkiving)
{
	m_bSkiving = bSkiving;
}

void CPaneRecipeGenFiducial::EnableAllWindow(BOOL bEnable)
{
	GetDlgItem(IDC_COMBO_TYPE)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SIZE_A)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SIZE_B)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SIZE_C)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_DARK)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_LIGHT)->EnableWindow(bEnable);
	GetDlgItem(IDC_RADIO_NONE)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_SIZE)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_ANGLE)->EnableWindow(bEnable);
	if(gSystemINI.m_sHardWare.nVisionType != OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_ASPECT_RATIO)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_ASPECTRATIO)->EnableWindow(bEnable);
	}
	GetDlgItem(IDC_EDIT_ASPECTRATIO)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_CAM_NO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_CONTRAST)->EnableWindow(bEnable);
	GetDlgItem(IDC_EDIT_BRIGHTNESS)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_TYPE)->EnableWindow(bEnable);
	m_edtSizeA.EnableWindow( bEnable );
	m_edtSizeB.EnableWindow( bEnable );
	m_edtSizeC.EnableWindow( bEnable );
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A_MM)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_SIZE_B_MM)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_SIZE_C_MM)->EnableWindow(bEnable);
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_PIC)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_SIZE)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_ANGLE)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->EnableWindow(bEnable);
//	GetDlgItem(IDC_STATIC_SIZE_PER)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_ANGLE_DEG)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO_PER)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_CAMERA)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_CONTRAST)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_CONTRAST_PER)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_BRIGHTNESS_PER)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_MODEL)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_POLARITY)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_CAM)->EnableWindow(bEnable);
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->EnableWindow(bEnable);

	if(gSystemINI.m_sHardWare.nUseLampRS232)
	{
		GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(bEnable);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(bEnable);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(bEnable);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(bEnable);
	}

	if(bEnable)
		SelectPic( m_nModelType );

}
