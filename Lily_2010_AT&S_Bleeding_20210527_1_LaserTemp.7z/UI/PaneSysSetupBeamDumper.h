#if !defined(AFX_PANESYSSETUPBEAMDUMPER_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)
#define AFX_PANESYSSETUPBEAMDUMPER_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupBeamDumper.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumper form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "ColorEdit.h"

class CPaneSysSetupBeamDumper : public CFormView
{
protected:
	CPaneSysSetupBeamDumper();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupBeamDumper)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupBeamDumper)
	enum { IDD = IDD_DLG_SYS_SETUP_BEAM_DUMPER };
	CColorEdit	m_edt2ndPanelPosY;
	CColorEdit	m_edt2ndPanelPosX;
	CColorEdit	m_edt1stPanelPosY;
	CColorEdit	m_edt1stPanelPosX;
	CColorEdit	m_edtDummyShotNo;
	CColorEdit	m_edtDummyInterval;
	CColorEdit	m_edtDummyFreq;
	CColorEdit	m_edtDummyDuty;
	CColorEdit	m_edtDummyAOMDelay;
	CColorEdit	m_edtDummyAOMDuty;
	CColorEdit	m_edtStandbyTime;
	CColorEdit	m_edtStandbyMinFreq;
	CColorEdit	m_edtStandbyMaxFreq;
	CColorEdit	m_edtStandbyInterval;
	CColorEdit	m_edtStandbyDuty;
	CColorEdit	m_edtStandbyInpositionTime;
	CColorEdit	m_edtStandbyTime2;
	CColorEdit	m_edtStandbyMinFreq2;
	CColorEdit	m_edtStandbyMaxFreq2;
	CColorEdit	m_edtStandbyInterval2;
	CColorEdit	m_edtStandbyDuty2;
	CColorEdit	m_edtStandbyInpositionTime2;
	//}}AFX_DATA

// Attributes
public:
	int			m_nUseDummy;
// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntEdit;

// Operations
public:
	void GetSystemDevice(SSYSTEMDUMP* pSystemDump);
	CString GetChangeValueStr();
	void SetSystemDevice(SSYSTEMDUMP sSystemDump);
	SSYSTEMDUMP			m_sSystemDump;
	void			OnApply();
	void			SetBeamDumperData();
	void		InitBtnControl();
	void		InitEditControl();
	void		InitStaticControl();
	void		 OnRadioNoUse();
	void		 OnRadioDumperShot();
	void		 OnRadioDummyFree();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupBeamDumper)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupBeamDumper();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupBeamDumper)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPBEAMDUMPER_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)
