#if !defined(AFX_USIMPLETAB_H__7A3FB696_E285_4A0F_BA27_CE1461BE11C5__INCLUDED_)
#define AFX_USIMPLETAB_H__7A3FB696_E285_4A0F_BA27_CE1461BE11C5__INCLUDED_

#include "USimpleTab.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// USimpleTab.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Pane Array
typedef CTypedPtrArray<CPtrArray, CFormView *> CPaneArray;

/////////////////////////////////////////////////////////////////////////////
// USimpleTab window

// yhchung 2011.08.05 �Ϻ�TabŬ���ؼ� ��ȭ������

class USimpleTab : public CTabCtrl
{
// Construction
public:
	USimpleTab();

// Attributes
public:
	int	m_nSkipIndex;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(USimpleTab)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetSkipIndex(int nIndex) { m_nSkipIndex = nIndex;} // 2011.08.05

	void TabChangeEnable(BOOL bEnable);
	
	void ShowPane(int iIndex);
	CFormView * GetPane(int iIndex);
	int GetPaneSize();
	BOOL AddPane(LPCTSTR pszPaneTitle, CFormView *pPane);
	BOOL AddPane(LPCTSTR pszPaneTitle, CRuntimeClass *pRuntimeClass);
	virtual ~USimpleTab();

	// Generated message map functions
protected:
	virtual void DrawItemTextAndImage(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void DrawItemBorder(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void DrawMainBorder(LPDRAWITEMSTRUCT lpDrawItemStruct);

	BOOL		m_bTabChangeEnable;
	COLORREF m_clrForeUnselected;
	COLORREF m_clrForeSelected;
	COLORREF m_clrBackUnselected;
	COLORREF m_clrBackSelected;
	COLORREF m_clrBorderUnselected;
	COLORREF m_clrBorderSelected;
	COLORREF m_clrTabBackground;
	CFormView * m_pCurrentPane;
	CPaneArray m_PaneArray;
	//{{AFX_MSG(USimpleTab)
	afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USIMPLETAB_H__7A3FB696_E285_4A0F_BA27_CE1461BE11C5__INCLUDED_)
