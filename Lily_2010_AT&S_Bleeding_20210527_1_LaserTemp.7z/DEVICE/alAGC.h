// alAGC.h: interface for the CalAGC class.
//
//////////////////////////////////////////////////////////////////////


#if !defined(AFX_ALAGC_H__C07CC1EE_1417_40E3_A2A1_BF1E49230E27__INCLUDED_)
#define AFX_ALAGC_H__C07CC1EE_1417_40E3_A2A1_BF1E49230E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_AGC_PATH	255

class AFX_EXT_CLASS CalAGC  
{
public:
	int GetVersion();
	BOOL SaveCalOffsetFile(CString strPath);
	void TransOffsetData();
	void SortTablePos();
	int GetTableAxis(int nMode, BOOL bXHeadMove, BOOL bYHeadMove);
	int GetChangeAxis(int nMode, int nRefMode);
	void SetBackupFolder( char* cBackupFolder);
	int CreateAGCFile();
	void AddOffsetInfo(double dTableX, double dTableY, double dOffsetX, double dOffsetY);
	BOOL SetAGCInfo(int nMatrix, char* cSaveFile, BOOL bShowMessage = FALSE, BOOL bBackup = TRUE, BOOL bLinearCal = FALSE, int nCubicLimit = 9);
	BOOL SetFieldSize(double dAGCSize, double dZeroSize);
	BOOL SetAxisInfo(int nTableMode, BOOL bXHeadMove, BOOL bYHeadMove, int nScannerMode, int nVisionMode);
	CalAGC();
	virtual ~CalAGC();

protected:	
	int m_nCubicLimit;
	BOOL m_bLinearCal;
	char m_cAgcFilePath[MAX_AGC_PATH];
	char m_cBackupFolder[MAX_AGC_PATH];
	int m_nMatrix;
	int m_nDataCnt;
	double m_dZeroSize;
	double m_dAGCSize;
	int m_nVisionAxisMode;
	int m_nScannerAxisMode;
	int m_nTableAxisMode;
	BOOL m_bFileBackup;
	BOOL m_bShowMessage;
	double* m_pdTableX;
	double* m_pdTableY;
	double* m_pdOffsetX;
	double* m_pdOffsetY;
};

#endif // !defined(AFX_ALAGC_H__C07CC1EE_1417_40E3_A2A1_BF1E49230E27__INCLUDED_)
