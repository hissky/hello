#if !defined(AFX_HVISION2DBARCODESOCK_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
#define AFX_HVISION2DBARCODESOCK_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientSock.h : header file
//
#include <afxsock.h>
#include "..\Model\DPoint.h"

#define WM_CLIENT_CONNECT			WM_USER + 773
#define WM_CLIENT_RECEIVE			WM_USER + 774
#define WM_CLIENT_CLOSE				WM_USER + 775

#define SEND_OK_			0
#define TIME_OUT_			100
#define SEND_FAIL_			101
#define RETURN_FAIL_		102

/////////////////////////////////////////////////////////////////////////////
// HVision2DBarcodeSock command target

class HVision2DBarcodeSock : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	BOOL m_bConnect;
	char m_szRecv[256];
	void SetWnd(HWND hWnd);

	HVision2DBarcodeSock();
	virtual ~HVision2DBarcodeSock();

// Overrides
public:
	CString GetResult();
	BOOL ResultEncoding();
	BOOL GetTrigger();
	BOOL SetTrigger(BOOL bOn);
	void WaitRecv();
	BOOL SendData(CString strCmd);
	CString GetBarcodeID();
	CString GetFileName();
	void ReceiveData();
	BOOL Connect(LPCTSTR lpszHostAddress, UINT nHostPort);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientSock)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CClientSock)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:


};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HVISION2DBARCODESOCK_H__4F32D0C2_40C8_4BD1_B9D9_194FA8A17866__INCLUDED_)
