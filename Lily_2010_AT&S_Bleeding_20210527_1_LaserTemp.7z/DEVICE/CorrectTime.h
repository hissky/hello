// CrrectTime.h: interface for the CCrrectTime class.
/////////////////////////////////////////////////////
#if !defined(AFX_CORRECTTIME_H__BF4B1AF3_9559_11D5_A2F8_004F490C60A0__INCLUDED_)
#define AFX_CORRECTTIME_H__BF4B1AF3_9559_11D5_A2F8_004F490C60A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCorrectTime  
{
public:
	CCorrectTime();
	virtual ~CCorrectTime();

public:
	// BOOL	StartTime();
	// Purpose	: Start timing
	BOOL		StartTime();

	// BOOL	Pause(BOOL bFlag = TRUE);
	// Purpose	: Pause timing
	// Remark	: bFlag = TRUE	-> Stop
	//			: bFlag = False	-> Restart
	BOOL		Pause(BOOL bFlag = TRUE);

	// double PresentTime()
	// Purpose	: Present timing and get elapsed time in seconds
	double	PresentTime();

	// double	Finish();
	// Purpose	: stop timing and get elapsed time in seconds
	double	Finish();

private:
	BOOL		m_bAvailable;		// Frequency Flag
	BOOL		m_bPause;			// Pause Flag

	__int64	m_nStart;			// Time ������ġ
	__int64	m_nFinish;			// Time ������ġ
	__int64	m_nFrequency;		// Time �ֱ�

	__int64	m_nPauseTime;		// ������ �ð�
	__int64	m_nPauseStart;		// ���� ������ġ
	__int64	m_nPauseFinish;		// ���� ������ġ
};

#endif // !defined(AFX_CORRECTTIME_H__BF4B1AF3_9559_11D5_A2F8_004F490C60A0__INCLUDED_)
