// MVisionLamp.cpp: implementation of the MVisionLamp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MVisionLamp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MVisionLamp::MVisionLamp()
{
	
}

MVisionLamp::~MVisionLamp()
{
	CloseSerial();
}

void MVisionLamp::ConectComPort()
{
	// ������ ���
	int nPort = 0;	// Port Number
	// set MPU baud rate to be the same as the computer terminal
	m_ComuPort.WriteComm((UCHAR *)(LPCTSTR)&(m_Protocol = m_Command.BaudRateControl(BAUDRATE)),sizeof(m_Protocol));
	m_bComPortInit = TRUE;
//	if(!m_ComuPort.OpenPort(m_strPort, BAUDRATE, nPort+1,m_hCommWnd)) 
//	{
//		ErrMessage(_T("Failed init COM port!"));
//		m_bComPortInit = FALSE;
//	}
}

int MVisionLamp::LampOut(int channel, int value)
{
	if(!m_bComPortInit)
		return 0;
	
	if(value > 255) value = 255;
	if(value < 0 ) value = 0;
	
	m_ComuPort.WriteComm((UCHAR *)(LPCTSTR)&(m_Protocol = m_Command.PwmDataCtrl(channel, value)),sizeof(m_Protocol));
	::Sleep(10);

	return TRUE;
}

int MVisionLamp::CloseSerial()
{
//	if(gSystemINI.m_sHardWare.nUseLampRS232)
	{
		if(!m_bComPortInit)
			return 0;
		
//		for(int i = 0; i < 8; i++)	//turn the light off when exit the program
//		{   
//			LampOut(i, 0);
//			Sleep(50);
//		}
	}
//	m_ComuPort.ClosePort();  // close RS-232 port 

	return TRUE;
}

void MVisionLamp::SetComPort(int nPort)
{
//	if(gSystemINI.m_sHardWare.nUseLampRS232)
	{
		m_strPort.Format(_T("COM%d"), nPort);
	}
}