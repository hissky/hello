// DBeampathINI.cpp: implementation of the DBeampathINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DBeampathINI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DBeampathINI gBeamPathINI;

DBeampathINI::DBeampathINI()
{
	memset( &m_sBeampath, 0, sizeof(m_sBeampath) );
	
	m_sBeampath.dScannerJumpDelay = 1000;
	
	for(int i = 0 ;i < BEAMPATH_COUNT; i++)
	{
		strcpy_s(m_sBeampath.strBeamPathAscFile[i],_T("-"));
		strcpy_s(m_sBeampath.strInfoName[i],_T("-"));		
	}
	strcpy_s(m_sBeampath.strPowCompensationAomFile,_T("-"));


}

DBeampathINI::~DBeampathINI()
{

}
